::  Urbit owns pairing and exactly-once CLI job claims. No provider tokens.
/-  c=cli-inference, p=native-coding-provider
/+  default-agent, law=cli-inference, web=cli-inference-http, source=cli-connector-source
=>
|%
+$  card  card:agent:gall
++  bind-page
  ^-  card
  [%pass /cli/bind %arvo %e %connect [~ /apps/pataphor-cli] %cli-inference]
++  notices
  |=  [our=@p values=(list notice:c)]
  ^-  (list card)
  %+  turn  values
  |=  n=notice:c
  [%pass /native-coding/result/(scot %ux id.n) %agent [our %viki] %poke %noun !>([%native-coding-event id.n session.n outcome.n])]
++  answer
  |=  [id=@ta code=@ud body=json]
  ^-  (list card)
  (answer-text id code (en:json:html body))
++  answer-text
  |=  [id=@ta code=@ud text=@t]
  ^-  (list card)
  =/  header  [code ~[['content-type' 'application/json; charset=utf-8'] ['cache-control' 'no-store'] ['x-content-type-options' 'nosniff']]]
  =/  data=(unit octs)  `[(met 3 text) text]
  =/  path=path  /http-response/[id]
  :~  [%give %fact ~[path] %http-response-header !>(header)]
      [%give %fact ~[path] %http-response-data !>(data)]
      [%give %kick ~[path] ~]
  ==
++  viki-read
  :: A blocked or missing scry bails the event; +mole cannot catch it. Check
  :: liveness by %gu, then read as * and validate shape here. Viki must answer
  :: every /qpc/cli path with a unit value, never [~ ~], and be deployed first.
  |=  [our=@p at=@da =path]
  ^-  (unit *)
  ?.  .^(? %gu /(scot %p our)/viki/(scot %da at)/$)  ~
  `.^(* %gx (weld /(scot %p our)/viki/(scot %da at)/qpc/cli path))
++  ready-context
  |=  [our=@p at=@da id=@ux]
  ^-  (unit ready-context:c)
  =/  raw  (viki-read our at /readiness/(scot %ux id)/noun)
  ?~  raw  ~
  =/  parsed  ((soft ,(unit ready-context:c)) u.raw)
  ?~  parsed  ~
  ?.  =(u.raw u.parsed)  ~
  u.parsed
++  next-context
  |=  [our=@p at=@da id=@ux]
  ^-  (unit next-context:c)
  =/  raw  (viki-read our at /window/(scot %ux id)/noun)
  ?~  raw  ~
  =/  parsed  ((soft ,(unit next-context:c)) u.raw)
  ?~  parsed  ~
  ?.  =(u.raw u.parsed)  ~
  u.parsed
++  dispatch-context
  |=  [our=@p at=@da id=@ux]
  ^-  dispatch-context:c
  =/  raw  (viki-read our at /dispatch/(scot %ux id)/noun)
  ?~  raw  [%refused %dispatch-context-unavailable]
  =/  parsed  ((soft ,(unit dispatch-context:c)) u.raw)
  ?~  parsed  [%refused %dispatch-context-malformed]
  ?.  &(=(u.raw u.parsed) ?=(^ u.parsed))  [%refused %dispatch-context-unavailable]
  u.u.parsed
++  readiness-hint
  :: Carry the exact immutable offer locator; Viki must not pick another offer.
  |=  [our=@p value=(unit [intent=@ux receipt=receipt-key:c])]
  ^-  (list card)
  ?~  value  ~
  =/  =wire  /qpc/cli/ready/(scot %ux intent.u.value)/(scot %ux nonce.receipt.u.value)
  ~[[%pass wire %agent [our %viki] %poke %noun !>([%qpc-cli-ready-v1 intent.u.value receipt.u.value])]]
--
=/  state=runtime:c  empty-runtime:law
=|  bound=?
^-  agent:gall
|_  =bowl:gall
+*  this  .
    def  ~(. (default-agent this %.n) bowl)
++  on-init
  ^-  (quip card _this)
  [~[bind-page] this(state state(legacy legacy.state(nonce `@uv`(shax (jam [eny.bowl now.bowl %cli-control])))), bound %.n)]
++  on-save  !>(state)
++  on-load
  |=  old=vase
  ^-  (quip card _this)
  =/  parsed  (restore:law q.old)
  ?>  ?=(^ parsed)
  ::  Reconnect never redispatches claimed jobs; capabilities remain until revoked.
  ::  Keep the existing exact native callback nonce rotation, without normalizing
  ::  it in preservation checks. Every other legacy field remains exact.
  [~[bind-page] this(state u.parsed(legacy legacy.u.parsed(nonce `@uv`(shax (jam [eny.bowl now.bowl nonce.legacy.u.parsed])))), bound %.n)]
++  on-poke
  |=  [=mark =vase]
  ^-  (quip card _this)
  ?:  =(%noun mark)
    ?>  =(our.bowl src.bowl)
    ?:  ?=([%cli-inference-local ?] q.vase)
      `this(state state(legacy legacy.state(local +.q.vase)))
    ?:  =(%cli-inference-rebind q.vase)  [~[bind-page] this(bound %.n)]
    =/  parsed
      ((soft ,$%([%native-coding-infer key=@tas request=request:p] [%native-coding-cancel id=@ux] [%native-coding-observe id=@ux])) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(u.parsed q.vase)
    =/  cmd  u.parsed
    =/  moved=runtime-change:c
      ?:  ?=(%native-coding-infer -.cmd)
        :: Historical exact duplicate observation needs no current pending row.
        ?:  (~(has by jobs.legacy.state) id.request.cmd)
          (lift:law state (submit:law legacy.state %.y key.cmd request.cmd))
        (submit-runtime:law state now.bowl key.cmd request.cmd (dispatch-context our.bowl now.bowl id.request.cmd))
      (lift:law state (observe:law legacy.state %.y id.cmd ?=(%native-coding-cancel -.cmd)))
    [(notices our.bowl notices.moved) this(state state.moved)]
  ?>  =(%handle-http-request mark)
  =+  !<([id=@ta req=inbound-request:eyre] vase)
  ?.  (transport:web local.legacy.state req)
    [(answer id 403 (status:law 'secure-transport-required')) this]
  =/  path=@t  url.request.req
  =/  owner=?  &(authenticated.req =(our.bowl src.bowl))
  ?:  =('/apps/pataphor-cli/source' path)
    ?.  &(=('GET' method.request.req) owner)
      [(answer id 403 (status:law 'owner-required')) this]
    =/  desk=@tas
      .^(@tas %gd /(scot %p our.bowl)/cli-inference/(scot %da now.bowl)/$)
    =/  raw=*
      .^(* %cx /(scot %p our.bowl)/[desk]/(scot %da now.bowl)/data/cli-connector/txt)
    =/  lines  ((soft wain) raw)
    ?~  lines  [(answer id 409 (status:law 'source-package-invalid')) this]
    =/  text=@t  (of-wain:format u.lines)
    ?.  (carrier-valid:source text)
      [(answer id 409 (status:law 'source-package-invalid')) this]
    [(answer-text id 200 text) this]
  ?:  |(=('/apps/pataphor-cli/control' path) =('/apps/pataphor-cli' path) =('/apps/pataphor-cli/' path))
    ?.  &(=('GET' method.request.req) owner)
      [(answer id 403 (status:law 'owner-required')) this]
    [(answer id 200 (control:web legacy.state)) this]
  ?.  =('POST' method.request.req)
    [(answer id 405 (status:law 'post-required')) this]
  ?.  (lien header-list.request.req |=([key=@t value=@t] &(=('content-type' key) |(=('application/json' value) =('application/json; charset=utf-8' value)))))
    [(answer id 415 (status:law 'json-required')) this]
  =/  body  body.request.req
  ?~  body  [(answer id 400 (status:law 'body-required')) this]
  ?.  &(=(p.u.body (met 3 q.u.body)) (lte p.u.body 4.194.304))
    [(answer id 413 (status:law 'body-too-large')) this]
  =/  capability=@uv  (shax (jam [%cli-pair eny.bowl now.bowl nonce.legacy.state q.u.body]))
  =/  next=@uv  (shax (jam [%cli-control eny.bowl now.bowl nonce.legacy.state]))
  =/  moved=runtime-change:c
    ?:  =('/apps/pataphor-cli/ready' path)
      =/  input  (ready-input:web q.u.body)
      ?~  input  (runtime-refused:law state %malformed-request)
      ?~  (authenticated:law legacy.state connector.u.input capability.u.input)
        (runtime-refused:law state %capability)
      =/  ctx  (ready-context our.bowl now.bowl intent.u.input)
      ?~  ctx  (runtime-refused:law state %readiness-context-unavailable)
      (offer-ready:law state our.bowl now.bowl u.input u.ctx)
    ?:  =('/apps/pataphor-cli/next' path)
      =/  input  (next-input:web q.u.body)
      ?~  input  (runtime-refused:law state %malformed-request)
      ?~  (authenticated:law legacy.state connector.u.input capability.u.input)
        (runtime-refused:law state %capability)
      =/  ctx  (next-context our.bowl now.bowl window.u.input)
      ?~  ctx  (runtime-refused:law state %next-context-unavailable)
      (next-ready:law state our.bowl u.input u.ctx)
    ?:  =('/apps/pataphor-cli/claim-exact' path)
      =/  input  (exact-input:web q.u.body)
      ?~  input  (runtime-refused:law state %malformed-request)
      ?~  (authenticated:law legacy.state connector.u.input capability.u.input)
        (runtime-refused:law state %capability)
      (claim-protected:law state now.bowl u.input (dispatch-context our.bowl now.bowl request.u.input))
    ?:  =('/apps/pataphor-cli/claim' path)
      =/  input  (claim-input:web q.u.body)
      ?~  input  (runtime-refused:law state %malformed-request)
      ?~  (authenticated:law legacy.state connector.u.input capability.u.input)
        (runtime-refused:law state %capability)
      =/  candidate  (ordinary-candidate:law state u.input)
      ?~  candidate  [state (status:law 'idle') ~ ~]
      (claim-ordinary:law state u.input (dispatch-context our.bowl now.bowl u.candidate))
    (track-legacy:law state (handle:web legacy.state owner path q.u.body capability next) =('/apps/pataphor-cli/pair' path))
  [(weld (readiness-hint our.bowl wake.moved) (weld (notices our.bowl notices.moved) (answer id 200 response.moved))) this(state state.moved)]
++  on-peek
  |=  path=path
  ^-  (unit (unit cage))
  ?.  =(our.bowl src.bowl)  ~
  ?:  =(/x/public-bindings path)
    =/  rows=(list [@tas public-binding:c])
      %+  turn  ~(tap by bindings.legacy.state)
      |=  [key=@tas b=binding:c]
      [key (public:law b)]
    ``noun+!>((malt rows))
  ?:  =(/x/summary path)
    ``noun+!>([%cli-inference-summary-v1 bound ~(wyt by bindings.legacy.state) ~(wyt by jobs.legacy.state)])
  ?:  =(/x/readiness path)
    ``noun+!>([%cli-readiness-v1 extra.state (queue-view:law legacy.state)])
  ?:  ?=([%x %pairing @ ~] path)
    =/  b  (~(get by bindings.legacy.state) i.t.t.path)
    =/  g  (~(get by generations.extra.state) i.t.t.path)
    =/  result=(unit [binding=public-binding:c generation=@ud])
      ?~(b ~ ?~(g ~ `[(public:law u.b) u.g]))
    ``noun+!>(result)
  ?:  ?=([%x %job-current @ ~] path)
    =/  id  (slaw %ux i.t.t.path)
    ?~  id  [~ ~]
    ?.  =((scot %ux u.id) i.t.t.path)  [~ ~]
    ``noun+!>((current-job:law legacy.state u.id))
  ?:  ?=([%x %job @ ~] path)
    =/  id  (slaw %ux i.t.t.path)
    ?~  id  [~ ~]
    ?.  =((scot %ux u.id) i.t.t.path)  [~ ~]
    ``noun+!>((~(get by jobs.legacy.state) u.id))
  ?:  ?=([%x %binding @ ~] path)
    =/  found  (~(get by bindings.legacy.state) i.t.t.path)
    =/  result=(unit public-binding:c)  ?~(found ~ `(public:law u.found))
    ``noun+!>(result)
  [~ ~]
++  on-watch
  |=  path=path
  ^-  (quip card _this)
  ?.  ?=([%http-response @ ~] path)  (on-watch:def path)
  ::  Eyre subscribes before authentication; this emits no private data.
  `this
++  on-arvo
  |=  [wire=wire sign=sign-arvo]
  ^-  (quip card _this)
  ?:  &(=(/cli/bind wire) ?=([%eyre %bound *] sign))
    `this(bound accepted.sign)
  (on-arvo:def wire sign)
++  on-agent  on-agent:def
++  on-leave  on-leave:def
++  on-fail  on-fail:def
--
