::  Explicit owner source delivery. This agent never compiles or activates code.
::  Clay ACKs are not receipts; only an owner Observe asks the canonical reader.
/+  default-agent, runtime=native-coding-source-import-runtime
=>
|%
+$  saved  [%native-coding-source-import-state-v1 entries=state:runtime]
--
=|  entries=state:runtime
^-  agent:gall
|_  =bowl:gall
+*  this  .
    def  ~(. (default-agent this %.n) bowl)
++  on-init  `this
++  on-save  !>(`saved`[%native-coding-source-import-state-v1 entries])
++  on-load
  |=  old=vase
  ^-  (quip card:agent:gall _this)
  =/  parsed  ((soft saved) q.old)
  ?>  ?=(^ parsed)
  ?>  =(q.old u.parsed)
  ?>  (valid:runtime our.bowl entries.u.parsed)
  ::  Preserve submitted/unknown outcomes exactly. No observation or resend.
  `this(entries entries.u.parsed)
++  on-poke
  |=  [=mark =vase]
  ^-  (quip card:agent:gall _this)
  ?>  &(=(our.bowl src.bowl) =(%noun mark))
  =/  parsed  ((soft command:runtime) q.vase)
  ?>  ?=(^ parsed)
  ?>  =(q.vase u.parsed)
  =/  moved  (act:runtime bowl entries u.parsed)
  ?:  ?=(%| -.moved)
    ~|  [%native-coding-source-import-refused p.moved]
    !!
  [cards.p.moved this(entries state.p.moved)]
++  on-watch
  |=  =path
  ^-  (quip card:agent:gall _this)
  ?>  &(=(our.bowl src.bowl) =(/status path))
  [~[[%give %fact ~ %noun !>([%native-coding-source-import-snapshot-v1 (status:runtime entries)])]] this]
++  on-peek
  |=  =path
  ^-  (unit (unit cage))
  ?.  =(our.bowl src.bowl)  ~
  ?:  =(/x/reservations path)  ``noun+!>((reservations:runtime entries))
  ?:  =(/x/status path)  ``noun+!>((status:runtime entries))
  ?.  ?=([%x %record @ ~] path)  [~ ~]
  =/  id  (slaw %ux i.t.t.path)
  ?~  id  [~ ~]
  ?.  =((scot %ux u.id) i.t.t.path)  [~ ~]
  ``noun+!>((~(get by entries) u.id))
++  on-arvo
  |=  [=wire =sign-arvo]
  ^-  (quip card:agent:gall _this)
  ?:  ?=([%native-source-import @ @ ~] wire)  `this
  (on-arvo:def wire sign-arvo)
++  on-leave  on-leave:def
++  on-agent  on-agent:def
++  on-fail  on-fail:def
--
