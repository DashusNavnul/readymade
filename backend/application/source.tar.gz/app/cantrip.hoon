::  /app/cantrip.hoon -- THE JUDGE.
::
::  Cantrip does not hold Graf's canon.  It judges what may enter canon and
::  directly defines the multiplayer protocol.  The separation is the design:
::
::    graf's canon   the STATUTE     (law facts + prescriptions)
::    cantrip        the JUDGE       (what may be engraved; what the
::                                    current regime admits)
::    the moon       the ENFORCER    (masked argmax under held law)
::    the derivation the AUDITOR     (canon-root + law id + dig)
::
::  No organ both writes law and enforces it.  No organ both enforces
::  and judges outcomes.
::
::  THE CANON INTERLEAVE IS READ-SHAPED.  Cantrip never pokes Graf to approve
::  canon; Graf scries Cantrip on every %propose-canon, at a path Graf already
::  builds today (app/graf +core-canon-approved). Multiplayer judgments are a
::  separate protocol: Cantrip decides them, then appends evidence to Graf.
::
::    /(our)/[governor]/(now)/law/approve/[jam rel]/[reps]/[principal]/noun
::
::  That is a CONTRACT, verified against graf's source, not a guess.
::  Read-shaped means it cannot deadlock and cannot double-write.
::
::  Law-window state is a reconstructible judgment cache: residue/streak/health
::  and their accepted-id index rebuild from exact Graf facts.  Boxy admission
::  receipts are a separate bounded durable ledger because Boxy must be able to
::  reopen an exact verdict watch after either agent reloads.
::
/-  bx=boxy, ca=cantrip-action, cl=canon-law, cls=cantrip-lease,
    vd=vibecoding-dispatch, vdr=vibecoding-dispatch-receipt,
    vp=vibecoding-proposal, ss=seat-session,
    rm=ring-migration, ct=cantrip, jm=juggler-match,
    cm=cantrip-multiplayer, gr=graf, sg=seiv-guidance,
    pa=cantrip-project-access, native-review-protocol=native-coding-review,
    review-inspection=native-coding-review-inspection,
    completion-review-protocol=native-coding-completion-review, lin=siev
/+  graf-relations, cantrip-law-engine, cantrip-law-window, act-law, siev-seat,
    bca=boxy-cantrip-admission, cbal=cantrip-boxy-admission-ledger,
    sll=siev-lineage-law, sal=siev-anchor-law,
    cle=cantrip-lease, crc=cantrip-record-cache,
    crrl=cantrip-ratification-readiness,
    cvdr=cantrip-vibecoding-dispatch-read,
    cvlr=cantrip-vibecoding-local-read,
    cvcr=cantrip-vibecoding-compile-read,
    cvlpr=vibecoding-local-preview-read,
    cvll=cantrip-vibecoding-local-land,
    cvllr=cantrip-vibecoding-local-land-read,
    cvllw=cantrip-vibecoding-local-land-wire,
    editor=cantrip-editor-save, editor-read=cantrip-editor-save-read,
    elaw=cantrip-editor-flect, acts=cantrip-act-lane, lflect=cantrip-land-flect,
    clflect=cantrip-connected-land-flect,
    project-save=cantrip-project-save, project-save-read=cantrip-project-save-read,
    native-tools=cantrip-native-coding, native-accept=native-coding-accept,
    revoke-actor=cantrip-native-revoke-actor,
    request-ceiling=native-coding-request-ceiling,
    request-ceiling-read=native-coding-request-ceiling-read,
    permissions=readymade-permissions,
    native-job-runner=native-coding-job-runner,
    native-deploy=native-coding-deployment, deploy-runtime=cantrip-native-deployment,
    coding-compiler-runtime=native-coding-compiler-runtime,
    coding-assembly-runtime=native-coding-terminal-assembly-runtime,
    coding-exports=native-coding-compiler-exports-runtime,
    coding-attachments=native-coding-compiler-attachment-runtime,
    coding-prefixes=native-coding-compiler-prefix-runtime,
    prefix-runner=native-coding-compiler-prefix-runner,
    gls-toolchain=native-coding-gls-toolchain,
    check-authorization=native-coding-check-authorization,
    coding-worker=native-coding-worker-owner-runtime,
    qpc-assessment=qpc-native-assessment-agent,
    qpc-admission=qpc-native-admission-agent, qpc-flow=qpc-native-flow-agent,
    coding-tool-worker=native-coding-worker-tool-owner,
    coding-derivations=native-coding-compiler-derivation,
    coding-reuse=native-coding-compiler-reuse,
    attachment-store=native-coding-compiler-attachment-store,
    exports-store=native-coding-compiler-exports-store,
    coding-hoon-runtime=native-coding-hoon-artifact,
    coding-hoon-store=native-coding-hoon-store,
    compiler-store=native-coding-compiler-store,
    native-review=cantrip-native-review,
    inspected-review=cantrip-native-inspected-review,
    completion-review=cantrip-native-completion-review,
    connected-write=cantrip-connected-write,
    connected-runtime=cantrip-connected-write-runtime,
    compile-ledger=cantrip-connected-compile-ledger,
    compile-runtime=cantrip-connected-compile-runtime,
    checks=cantrip-connected-checks, checks-read=cantrip-connected-checks-read,
    checks-preview=vibecoding-connected-preview-read,
    connected-land=cantrip-connected-land, connected-land-read=cantrip-connected-land-read,
    project-access=cantrip-project-access-runtime,
    project-receipt=cantrip-project-receipt,
    project-session=cantrip-project-session-runtime,
    project-sessions=cantrip-project-sessions-runtime,
    readymade-pact-read=cantrip-readymade-pact-read,
    vsg=viki-scry-guard,
    cvp=cantrip-vibecoding-proposal,
    cml=cantrip-multiplayer-law,
    csgl=cantrip-star-govern-law,
    sgl=seiv-guidance,
    cmr=cantrip-multiplayer-retry,
    vdrl=vibecoding-dispatch-receipt,
    shadow=cantrip-shadow, flect-law,
    hand-bind, sentinel-law, default-agent, dbug, qpc-gate=qpc-session-gate
|%
+$  card  card:agent:gall
::  Historical cache before Graf citation and duplicate-id enforcement.
+$  state-0
  $:  %0
      residue=residue:cantrip-law-window
      streak=@ud                        ::  consecutive verified passes
      health=(unit @ud)                 ::  latest sample; ~ = no data
  ==
+$  state-1  [%1 cache=cache:crc]
+$  state-any-v1  $%(state-1 state-0)
+$  state-2  [%2 cache=cache:crc admissions=ledger:cbal]
+$  state-3
  $:  %3
      cache=cache:crc
      admissions=ledger:cbal
      mp-inbox=(map @t mp-inbox-entry:ct)
      mp-allow=(set @p)
  ==
+$  state-4
  $:  %4
      cache=cache:crc
      admissions=ledger:cbal
      mp-inbox=(map @t mp-inbox-entry:ct)
      mp-allow=(set @p)
      leases=table:cls
  ==
+$  state-5
  $:  %5
      cache=cache:crc
      admissions=ledger:cbal
      mp-inbox=(map @t mp-inbox-entry:ct)
      mp-allow=(set @p)
      leases=table:cls
      dispatches=ledger:vdr
  ==
::  Pre-recovery outbox entries carried no durable timer cursor. Keep the exact
::  noun shape so state v6 can migrate instead of silently dropping its moves.
+$  mp-outbox-entry-1
  $:  move=mp-move:ct
      target-ship=@p
      status=mp-outbox-status:ct
      status-at=@da
      reason=(unit @t)
  ==
+$  state-6
  $:  %6
      cache=cache:crc
      admissions=ledger:cbal
      mp-inbox=(map @t mp-inbox-entry:ct)
      mp-allow=(set @p)
      leases=table:cls
      dispatches=ledger:vdr
      mp-outbox=(map @t mp-outbox-entry-1)
  ==
+$  state-7
  $:  %7
      cache=cache:crc
      admissions=ledger:cbal
      mp-inbox=(map @t mp-inbox-entry:ct)
      mp-allow=(set @p)
      leases=table:cls
      dispatches=ledger:vdr
      mp-outbox=(map @t mp-outbox-entry:ct)
  ==
+$  governor-cache-entry
  $:  source=@p
      record=governor-record:csgl
      received-at=@da
  ==
+$  state-8
  $:  %8
      cache=cache:crc
      admissions=ledger:cbal
      mp-inbox=(map @t mp-inbox-entry:ct)
      mp-allow=(set @p)
      leases=table:cls
      dispatches=ledger:vdr
      mp-outbox=(map @t mp-outbox-entry:ct)
      governor-star=(unit @p)
      governor-cache=(unit governor-cache-entry)
  ==
+$  saved-state-1  [%cantrip-judge-state-v1 state=state-any-v1]
+$  saved-state-2  [%cantrip-judge-state-v2 state=state-2]
+$  saved-state-3  [%cantrip-judge-state-v3 state=state-3]
+$  saved-state-4  [%cantrip-judge-state-v4 state=state-4]
+$  saved-state-5  [%cantrip-judge-state-v5 state=state-5]
+$  saved-state-6  [%cantrip-judge-state-v6 state=state-6]
+$  saved-state-7  [%cantrip-judge-state-v7 state=state-7]
+$  saved-state-8  [%cantrip-judge-state-v8 state=state-8]
+$  state-9
  $:  %9
      cache=cache:crc
      admissions=ledger:cbal
      mp-inbox=(map @t mp-inbox-entry:ct)
      mp-allow=(set @p)
      leases=table:cls
      dispatches=ledger:vdr
      mp-outbox=(map @t mp-outbox-entry:ct)
      governor-star=(unit @p)
      governor-cache=(unit governor-cache-entry)
      local-lands=ledger:cvll
  ==
+$  saved-state-9  [%cantrip-judge-state-v9 state=state-9]
+$  state-10
  $:  %10
      cache=cache:crc
      admissions=ledger:cbal
      mp-inbox=(map @t mp-inbox-entry:ct)
      mp-allow=(set @p)
      leases=table:cls
      dispatches=ledger:vdr
      mp-outbox=(map @t mp-outbox-entry:ct)
      governor-star=(unit @p)
      governor-cache=(unit governor-cache-entry)
      local-lands=ledger:cvll
      editor-saves=ledger-v1:editor
  ==
+$  saved-state-10  [%cantrip-judge-state-v10 state=state-10]
+$  state-11
  $:  %11
      cache=cache:crc
      admissions=ledger:cbal
      mp-inbox=(map @t mp-inbox-entry:ct)
      mp-allow=(set @p)
      leases=table:cls
      dispatches=ledger:vdr
      mp-outbox=(map @t mp-outbox-entry:ct)
      governor-star=(unit @p)
      governor-cache=(unit governor-cache-entry)
      local-lands=ledger:cvll
      editor-saves=ledger:editor
  ==
+$  saved-state-11  [%cantrip-judge-state-v11 state=state-11]
::  Keep the whole v11 noun, including its version tag and editor ledger.
+$  saved-state-12
  [%cantrip-judge-state-v12 legacy=saved-state-11 connected=ledger:connected-write]
+$  saved-state-13
  [%cantrip-judge-state-v13 legacy=saved-state-12 grants=grants:pa records=records:pa]
+$  saved-state-14
  [%cantrip-judge-state-v14 legacy=saved-state-13 compilations=ledger:compile-ledger]
+$  saved-state-15
  [%cantrip-judge-state-v15 legacy=saved-state-14 connected-v2=ledger-v2:connected-write]
+$  saved-state-16
  [%cantrip-judge-state-v16 legacy=saved-state-15 compilations-v2=ledger-v2:compile-ledger]
+$  saved-state-17
  [%cantrip-judge-state-v17 legacy=saved-state-16 checks=ledger:checks]
+$  saved-state-18
  [%cantrip-judge-state-v18 legacy=saved-state-17 landings=ledger:connected-land]
+$  saved-state-19
  [%cantrip-judge-state-v19 legacy=saved-state-18 projects=ledger:project-save]
+$  saved-state-20
  [%cantrip-judge-state-v20 legacy=saved-state-19 tools=organ:native-tools]
+$  saved-state-21
  [%cantrip-judge-state-v21 legacy=saved-state-20 candidates=ledger:native-accept]
+$  saved-state-22
  [%cantrip-judge-state-v22 legacy=saved-state-21 deployment=organ:native-deploy]
+$  saved-state-23
  [%cantrip-judge-state-v23 legacy=saved-state-22 compiler=organ-v1:coding-compiler-runtime]
+$  saved-state-24
  [%cantrip-judge-state-v24 legacy=saved-state-23 reviews=ledger:native-review]
+$  saved-state-25
  [%cantrip-judge-state-v25 legacy=saved-state-24 compiler-store=organ-v1:compiler-store]
+$  saved-state-26
  [%cantrip-judge-state-v26 legacy=saved-state-25 compiler=organ:coding-compiler-runtime compiler-store=organ:compiler-store]
+$  saved-state-27
  [%cantrip-judge-state-v27 legacy=saved-state-26 assembly=organ:coding-assembly-runtime]
+$  saved-state-28
  [%cantrip-judge-state-v28 legacy=saved-state-27 hoon=organ:coding-hoon-runtime]
+$  saved-state-29
  [%cantrip-judge-state-v29 legacy=saved-state-28 archive=organ:coding-hoon-store]
+$  saved-state-30
  [%cantrip-judge-state-v30 legacy=saved-state-29 proofs=proofs:inspected-review]
+$  saved-state-31
  [%cantrip-judge-state-v31 legacy=saved-state-30 jobs=state:native-job-runner]
+$  saved-state-32
  [%cantrip-judge-state-v32 legacy=saved-state-31 exports=organ:coding-exports archive=organ:exports-store]
+$  saved-state-33
  [%cantrip-judge-state-v33 legacy=saved-state-32 attachments=organ:coding-attachments]
+$  saved-state-34
  [%cantrip-judge-state-v34 legacy=saved-state-33 derivations=organ:coding-derivations]
+$  saved-state-35
  [%cantrip-judge-state-v35 legacy=saved-state-34 archive=organ:attachment-store]
+$  saved-state-36
  [%cantrip-judge-state-v36 legacy=saved-state-35 completions=ledger:completion-review]
+$  saved-state-37
  [%cantrip-judge-state-v37 legacy=saved-state-36 prefixes=organ:coding-prefixes]
+$  saved-state-38
  [%cantrip-judge-state-v38 legacy=saved-state-37 gls=organ:gls-toolchain]
+$  saved-state-39
  [%cantrip-judge-state-v39 legacy=saved-state-38 acts=organ:acts]
::  v40 carries v39 unchanged. The native-coding tool-args/operation unions
::  widened (the `patches` multi-file candidate tool, 2026-10-31); the load
::  guard requires a versioned save for that, not a code-only reload.
+$  saved-state-40
  [%cantrip-judge-state-v40 legacy=saved-state-39 carried=~]
+$  saved-state-41
  [%cantrip-judge-state-v41 legacy=saved-state-40 ceilings=ledger:request-ceiling]
+$  landing-status
  [%cantrip-connected-land-status-v2 digest=@ux record=(unit record:connected-land)]
+$  checks-status
  [%cantrip-connected-checks-status-v2 nonce=@ux record=(unit record:checks)]
+$  record-action  [%record kind=@tas id=@t body=*]
+$  lease-action
  $%  [%mirror-moon-lease id=@t holder=@t expires=@da]
      [%release-lease id=@t]
  ==
+$  boxy-admission-action
  $%  [%admit-boxy-motion request=boxy-motion-admission-request:ca]
      [%admit-boxy-motion-approved request=boxy-motion-admission-request:ca]
      [%retire-boxy-verdict key=@ux]
  ==
+$  juggler-admission-action
  [%admit-juggler-match request=juggler-match-admission-request:ca]
+$  multiplayer-action
  $%  [%receive-mp-move move=mp-move:ct]
      [%accept-mp-move move-id=@t]
      [%refuse-mp-move move-id=@t reason=@t]
      [%hold-mp-move move-id=@t]
      [%complete-mp-move move-id=@t]
      [%abandon-mp-move move-id=@t reason=@t]
      [%mp-allow ship=@p]
      [%mp-deny ship=@p]
      [%send-mp-move target=@p move=mp-move:ct]
      [%retry-mp-move move-id=@t]
      [%retire-mp-move move-id=@t]
      ::  OPERATOR CLOSE OF AN OUTBOX ENTRY.  An outbox entry changes only by a
      ::  receipt from its target; a target that never acks (a dead lane on the
      ::  day it was sent) leaves the entry active forever, and every active
      ::  entry counts as outstanding-unverified -- which, under a %grounding
      ::  clamp, refuses ALL new dispatch (measured 2026-08-30: 20 such entries
      ::  from the previous day clamped baldur).  Local only, recorded, and it
      ::  moves the entry to %abandoned so %retire-mp-move may then take it.
      [%close-mp-outbox move-id=@t reason=@t]
      [%override-star-govern verdict-id=@t reason=@t]
      [%set-star-governor star=@p]
      [%receive-star-govern record=governor-record:csgl]
      [%push-star-govern target=@p]
  ==
+$  mp-change
  [next=(map @t mp-inbox-entry:ct) entry=mp-inbox-entry:ct]
+$  mp-outbox-change
  [next=(map @t mp-outbox-entry:ct) entry=mp-outbox-entry:ct]
+$  mp-outbox-control-record
  [action=@tas move-id=@t target=@p status=mp-outbox-status:ct at=@da]
+$  mp-outbox-recovery
  [next=(map @t mp-outbox-entry:ct) cards=(list card)]
::  Preserve every v8 field. Reuse the existing historical migration path;
::  a restored local submission grants no new dispatch and emits no card.
++  with-local-lands
  |=  [old=state-8 lands=ledger:cvll]
  ^-  state-9
  [%9 cache.old admissions.old mp-inbox.old mp-allow.old leases.old dispatches.old mp-outbox.old governor-star.old governor-cache.old lands]
++  without-local-lands
  |=  old=state-9
  ^-  state-8
  [%8 cache.old admissions.old mp-inbox.old mp-allow.old leases.old dispatches.old mp-outbox.old governor-star.old governor-cache.old]
++  with-editor-saves
  |=  [old=state-9 saves=ledger:editor]
  ^-  state-11
  [%11 cache.old admissions.old mp-inbox.old mp-allow.old leases.old dispatches.old mp-outbox.old governor-star.old governor-cache.old local-lands.old saves]
++  without-editor-saves
  |=  old=state-11
  ^-  state-9
  [%9 cache.old admissions.old mp-inbox.old mp-allow.old leases.old dispatches.old mp-outbox.old governor-star.old governor-cache.old local-lands.old]
++  max-mp-inbox  256
++  max-mp-outbox  256
++  max-mp-move-bytes  65.536
++  max-mp-source-active  64
++  mp-allowed
  |=  verdict=verdict:cm
  ^-  ?
  ?=(%& -.verdict)
::  Fair-share pressure counts only work the receiver has not closed. Terminal
::  history remains bounded by max-mp-inbox, but cannot let one peer reserve
::  every active slot forever.
++  mp-source-active-count
  |=  [inbox=(map @t mp-inbox-entry:ct) who=@p]
  ^-  @ud
  %-  lent
  %+  skim  ~(tap by inbox)
  |=  [id=@t entry=mp-inbox-entry:ct]
  ^-  ?
  ?:  =(who source-ship.entry)
    ?=(?(%pending %held %accepted) status.entry)
  %.n
::  Read only the eight closed record kinds.  Every failed kind read fails the
::  whole rebuild closed; a partial history must never masquerade as the law.
++  graf-kind-facts
  |=  [base=path kind=@tas]
  ^-  (unit (list record:crc))
  =/  read=(each (list *) tang)
    %-  mule
    |.(.^((list *) %gx (weld base /by-kind/[kind]/noun)))
  ?-  -.read
    %|  ~
    %&  (decode-records:crc p.read)
  ==
++  graf-record-facts
  |=  [our=@p now=@da]
  ^-  (unit (list record:crc))
  ::  Missing-agent scries cancel the event; +mule cannot catch them.
  ?.  (agent-live:vsg our now %graf)  ~
  =/  base=path  /(scot %p our)/graf/(scot %da now)
  =/  kinds=(list @tas)  ~(tap in record-kinds:crc)
  =|  facts=(list record:crc)
  |-  ^-  (unit (list record:crc))
  ?~  kinds  `facts
  =/  read=(unit (list record:crc))  (graf-kind-facts base i.kinds)
  ?~  read  ~
  $(kinds t.kinds, facts (weld u.read facts))
++  rebuild-from-graf
  |=  [our=@p now=@da]
  ^-  (unit cache:crc)
  =/  facts=(unit (list record:crc))  (graf-record-facts our now)
  ?~  facts  ~
  `(rebuild:crc u.facts)
::  BANDS FROM HISTORY, not from arguments.  The window is a judgment
::  about what actually happened -- which is why a brain cannot widen
::  its own law by passing nicer numbers: it can only record outcomes,
::  and outcomes move the bands.
++  bands-for
  |=  [r=residue:cantrip-law-window sk=@ud]
  ^-  bands:cantrip-law-window
  :*  focus=?:((gth turn.r 0) %high %medium)
      goal-distance=?:((gth sk 0) %low %high)
      evidence=?:((gte sk 2) %high ?:((gte sk 1) %medium %low))
      drift=?:((gte contraindications.r 2) %high ?:((gte contraindications.r 1) %medium %low))
      rival=?:((gth rivals.r 0) %high %low)
  ==
++  law-window-for
  |=  [r=residue:cantrip-law-window sk=@ud]
  ^-  window:cantrip-law-window
  (window-of:cantrip-law-window (bands-for r sk) r)
::  THE SHIP'S WINDOW: the regime's, under the operator's act law
::  (lib/act-law).  What every reader of /x/law/window/current obeys.
++  ship-window
  |=  [our=@p now=@da r=residue:cantrip-law-window sk=@ud]
  ^-  window:cantrip-law-window
  (restrict:cantrip-law-window (law-window-for r sk) (forbidden-acts:act-law our now))
::  A SEAT'S WINDOW: the ship's, narrowed by siev's reading of that seat's
::  own record (lib/siev-seat).  A seat can lose acts the ship admits; it can
::  never hold one the ship does not.
++  seat-window
  |=  [our=@p now=@da r=residue:cantrip-law-window sk=@ud seat=@tas]
  ^-  window:cantrip-law-window
  (restrict:cantrip-law-window (ship-window our now r sk) blocked:(read:siev-seat our now seat))
::  the health-earned ceiling: a degraded ship does not act, it
::  convalesces.  ~ (no sample) leaves the tier standing -- absence of
::  evidence never UPGRADES, and only a real bad sample downgrades.
++  ceiling-for
  |=  h=(unit @ud)
  ^-  @tas
  ?~  h  %full
  (ceiling-for:sentinel-law %.y %full u.h)
::  HELD LAW for the worker.  Today canon holds no oracle law, so the
::  judge serves the measured, twinned pre-canon binding the moon already
::  holds.  When canon engraves the oracle law, this arm reads it from graf
::  instead, and NOTHING ELSE IN THE SYSTEM CHANGES.
++  held-for
  ^-  held:cl
  pre-canon-held:cl
::
++  boxy-authority-for
  |=  [our=@p now=@da]
  ^-  (unit state:bx)
  =/  read=(each state:bx tang)
    %-  mule
    |.(.^(state:bx %gx /(scot %p our)/boxy/(scot %da now)/state/noun))
  ?-  -.read
    %|  ~
    %&  `p.read
  ==
::
++  boxy-verdict-path
  |=  key=@ux
  ^-  path
  /boxy/motion/verdict/(scot %ux key)
::
++  boxy-verdict-card
  |=  [key=@ux verdict=boxy-motion-admission-verdict:ca]
  ^-  card
  [%give %fact ~[(boxy-verdict-path key)] %noun !>(verdict)]
::
++  juggler-verdict-path
  |=  proposal-id=@t
  ^-  path
  /juggler-match/verdict/(scot %uw (jam proposal-id))
::
++  juggler-verdict-card
  |=  verdict=admission:jm
  ^-  card
  [%give %fact ~[(juggler-verdict-path proposal-id.verdict)] %noun !>(verdict)]
::
::  WHAT THE MOVE ACTUALLY SAID.
::
::  The relation summary used to carry only the ENVELOPE -- kind, source,
::  status, move-id -- and the payload never left cantrip's mp-inbox, which has
::  no peek path.  A governing star reading these relations could therefore see
::  THAT a member submitted work and WHO, but not what the outcome was.
::
::  Measured on ~rocten 2026-08-29: a real dispatch produced a verified
::  artifact (verdict=pass, checker=codex-cli), star-report read those values
::  out of the verifier's own graf fact and sent them, and what reached the
::  star's observable window was "familiar-submit from ~baldur-tannum
::  status=pending move=star-0xf7aa...".  star-govern then ran its qualia math
::  on that boilerplate.  A star whose window cannot distinguish pass from fail
::  is not governing on outcomes.
::
::  One line per kind, chosen as the field a HUMAN would want to read: the
::  submitted result, the shared intent, the offered prompt.  Nothing parses
::  this string programmatically -- it is observed as text -- so widening it is
::  additive.
++  payload-text
  |=  p=mp-payload:ct
  ^-  @t
  ?-  -.p
    %familiar-submit     summary.p
    %task-share          intent.p
    %request-review      summary.p
    %cantrip-offer       explanation.p
    %continuation-offer  state-summary.p
  ==
::
++  mp-graf-card
  |=  [=bowl:gall entry=mp-inbox-entry:ct]
  ^-  card
  =/  move=mp-move:ct  move.entry
  =/  status=@tas  status.entry
  =/  source=@t  (scot %p source-ship.entry)
  =/  target=@t  (scot %p our.bowl)
  =/  relation-id=@t
    (crip "mp-{(trip (scot %tas status))}-{(trip move-id.move)}")
  =/  relation=graf-relation:gr
    :*  handle=[type=%relation version=1 id=relation-id hash=source]
        relation-kind=`@tas`(cat 3 'mp-' status)
        source=[type=%ship version=1 id=source hash=source]
        target=[type=%ship version=1 id=target hash=target]
        label=kind.move
        summary=(crip "{(trip (scot %tas kind.move))} from {(trip source)} status={(trip (scot %tas status))} move={(trip move-id.move)} :: {(trip (payload-text payload.move))}")
    ==
  =/  meta=dispatch-meta:gr
    :*  batch-id=(cat 3 'mp-graf-' relation-id)
        batch-hash=''
        source-slug=`'cantrip-multiplayer'
        dispatched-at=now.bowl
        idempotency-key=(cat 3 'mp-graf-' relation-id)
        sequence=0
    ==
  [%pass /mp-graf %agent [our.bowl %graf] %poke %graf-action !>(`graf-action:gr`[%record-relation meta relation])]
::
++  mp-evidence-cards
  |=  [=bowl:gall entry=mp-inbox-entry:ct]
  ^-  (list card)
  =/  move=mp-move:ct  move.entry
  :~  [%give %fact ~[/multiplayer] %noun !>(entry)]
      (mp-graf-card bowl entry)
      (mp-receipt-card bowl source-ship.entry move-id.move status.entry refuse-reason.entry)
  ==
::
++  mp-receipt-card
  |=  [=bowl:gall target=@p move-id=@t status=mp-inbox-status:ct reason=(unit @t)]
  ^-  card
  =/  ack=mp-receipt:ct
    [%cantrip-mp-receipt-v1 move-id our.bowl status reason now.bowl]
  [%pass /mp-receipt %agent [target %cantrip] %poke %cantrip-mp-receipt !>(ack)]
::
++  mp-outbox-graf-card
  |=  [=bowl:gall entry=mp-outbox-entry:ct]
  ^-  card
  =/  move=mp-move:ct  move.entry
  =/  status=@tas  status.entry
  =/  source=@t  (scot %p our.bowl)
  =/  target=@t  (scot %p target-ship.entry)
  =/  relation-id=@t
    (crip "mp-ack-{(trip (scot %tas status))}-{(trip move-id.move)}")
  =/  relation=graf-relation:gr
    :*  handle=[type=%relation version=1 id=relation-id hash=target]
        relation-kind=`@tas`(cat 3 'mp-ack-' status)
        source=[type=%ship version=1 id=source hash=source]
        target=[type=%ship version=1 id=target hash=target]
        label=kind.move
        summary=(crip "{(trip (scot %tas kind.move))} to {(trip target)} acknowledged={(trip (scot %tas status))} move={(trip move-id.move)}")
    ==
  =/  meta=dispatch-meta:gr
    :*  batch-id=(cat 3 'mp-ack-graf-' relation-id)
        batch-hash=''
        source-slug=`'cantrip-multiplayer'
        dispatched-at=now.bowl
        idempotency-key=(cat 3 'mp-ack-graf-' relation-id)
        sequence=0
    ==
  [%pass /mp-ack-graf %agent [our.bowl %graf] %poke %graf-action !>(`graf-action:gr`[%record-relation meta relation])]
::
++  mp-outbox-evidence-cards
  |=  [=bowl:gall entry=mp-outbox-entry:ct]
  ^-  (list card)
  :~  [%give %fact ~[/multiplayer/outbox] %noun !>(entry)]
      (mp-outbox-graf-card bowl entry)
  ==
::
++  mp-outbox-control-graf-card
  |=  [=bowl:gall action=@tas entry=mp-outbox-entry:ct]
  ^-  card
  =/  move=mp-move:ct  move.entry
  =/  source=@t  (scot %p our.bowl)
  =/  target=@t  (scot %p target-ship.entry)
  =/  relation-id=@t
    (crip "mp-{(trip (scot %tas action))}-{(trip move-id.move)}-{(trip (scot %da now.bowl))}")
  =/  relation=graf-relation:gr
    :*  handle=[type=%relation version=1 id=relation-id hash=target]
        relation-kind=`@tas`(cat 3 'mp-' action)
        source=[type=%ship version=1 id=source hash=source]
        target=[type=%ship version=1 id=target hash=target]
        label=status.entry
        summary=(crip "outbox {(trip (scot %tas action))} status={(trip (scot %tas status.entry))} move={(trip move-id.move)} target={(trip target)}")
    ==
  =/  meta=dispatch-meta:gr
    :*  batch-id=(cat 3 'mp-control-' relation-id)
        batch-hash=''
        source-slug=`'cantrip-multiplayer'
        dispatched-at=now.bowl
        idempotency-key=(cat 3 'mp-control-' relation-id)
        sequence=0
    ==
  [%pass /mp-control-graf %agent [our.bowl %graf] %poke %graf-action !>(`graf-action:gr`[%record-relation meta relation])]
::
++  mp-outbox-control-cards
  |=  [=bowl:gall action=@tas entry=mp-outbox-entry:ct]
  ^-  (list card)
  =/  move=mp-move:ct  move.entry
  =/  record=mp-outbox-control-record
    [action move-id.move target-ship.entry status.entry now.bowl]
  :~  [%give %fact ~[/multiplayer/outbox/control] %noun !>(record)]
      (mp-outbox-control-graf-card bowl action entry)
  ==
::
++  mp-retry-wake-card
  |=  [=bowl:gall move-id=@t attempt=@ud generation=@ud delay=@dr]
  ^-  card
  :*  %pass
      (retry-wire:cmr [move-id attempt generation])
      %arvo
      %b
      %wait
      (add now.bowl delay)
  ==
::
::  Admission is evaluated against the local star's CURRENT Graf read.  This
::  source is first deployed on rocten, whose own Graf is the star record; a
::  fleet-wide deployment needs the explicit remote-star cache in step 26.
::  Until then, do not ship this build to a member and pretend local Graf is
::  the star.
++  mp-governance-counts
  |=  [outbox=(map @t mp-outbox-entry:ct) at=@da]
  ^-  [outstanding=@ud recent=@ud]
  =/  cutoff=@da  (sub at ~m1)
  =/  entries=(list [@t mp-outbox-entry:ct])  ~(tap by outbox)
  =|  outstanding=@ud
  =|  recent=@ud
  |-
  ?~  entries  [outstanding recent]
  =/  entry=mp-outbox-entry:ct  +.i.entries
  %=  $
    entries      t.entries
    outstanding  ?:((active:cmr status.entry) +(outstanding) outstanding)
    recent       ?:  ?&  !=(%refused status.entry)
                            (gte sent-at.move.entry cutoff)
                        ==
                     +(recent)
                   recent
  ==
::
::  the local circulation record, guarded.  The regime of a worker is visible
::  where its verifier wrote it: on this ship for this ship's own executor,
::  and on a member for the member's.  Cross-ship regime visibility rides the
::  star-report path and is NOT claimed here.
++  circulation-rows
  |=  =bowl:gall
  ^-  (list row:sg)
  ?.  .^(? %gu /(scot %p our.bowl)/graf/(scot %da now.bowl)/$)  ~
  .^  (list row:sg)  %gx
      /(scot %p our.bowl)/graf/(scot %da now.bowl)/circulation/page/0/64/noun
  ==
::
++  worker-regime-of
  |=  [=bowl:gall target=(unit @p)]
  ^-  (unit @tas)
  ?~  target  ~
  ::  with revocation: a standing older than regime-ttl no longer refuses.
  `(regime-of-since:sgl (circulation-rows bowl) (ship-term:sgl u.target) (horizon-of:sgl now.bowl))
::
::  GUIDANCE TRAVELS WITH A %task-share.  The packet is attached as text at
::  the end of the intent, so the payload type is unchanged and a peer on an
::  older desk still reads the whole thing.  No packet when the local queue
::  does not know the task: the intent goes as written and nothing is implied.
++  attach-guidance
  |=  [=bowl:gall move=mp-move:ct]
  ^-  mp-move:ct
  ?.  ?=(%task-share -.payload.move)  move
  =/  p=task-share-payload:ct  +.payload.move
  =/  seg=(unit @tas)  (slaw %tas task-id.p)
  ?~  seg  move
  ?.  .^(? %gu /(scot %p our.bowl)/multiplayer-queue/(scot %da now.bowl)/$)  move
  =/  g=(unit task-guidance:sg)
    .^  (unit task-guidance:sg)  %gx
        /(scot %p our.bowl)/multiplayer-queue/(scot %da now.bowl)/guidance/(scot %tas u.seg)/noun
    ==
  ?~  g  move
  move(payload [%task-share p(intent (share-intent:sgl u.g intent.p))])
::
::  an operator override of a guidance-based refusal is recorded WITH the
::  regime distribution it overrode (the S78 override discipline, extended).
++  override-reason
  |=  [=bowl:gall reason=@t]
  ^-  @t
  =/  c=regime-census:sg  (census-since:sgl (circulation-rows bowl) (horizon-of:sgl now.bowl))
  (rap 3 ~[reason ' | overrode regime-census: ' (census-text:sgl c)])
::
++  mp-governance-decision
  |=  $:  =bowl:gall
          kind=admission-kind:csgl
          outbox=(map @t mp-outbox-entry:ct)
          governor-star=(unit @p)
          governor-cache=(unit governor-cache-entry)
          target=(unit @p)
      ==
  ^-  decision:csgl
  =/  signal=governor-read:csgl
    ?:  ?|(=(~ governor-star) =(`our.bowl governor-star))
      .^  governor-read:csgl  %gx
          /(scot %p our.bowl)/graf/(scot %da now.bowl)/star-govern/latest/noun
      ==
    ?~  governor-cache
      [%no-signal %missing ~ ~]
    =/  cached=governor-cache-entry  u.governor-cache
    ?:  (gte now.bowl expires-at.record.cached)
      [%no-signal %stale `observed-at.record.cached `expires-at.record.cached]
    [%signal record.cached]
  =/  override=(unit override-fact:csgl)
    ?:  ?|(=(~ governor-star) =(`our.bowl governor-star))
      .^  (unit override-fact:csgl)  %gx
          /(scot %p our.bowl)/graf/(scot %da now.bowl)/star-govern/override/latest/noun
      ==
    ~
  =/  counts  (mp-governance-counts outbox now.bowl)
  =/  context=context:csgl
    :*  kind
        operator=our.bowl
        now=now.bowl
        outstanding-unverified=outstanding.counts
        dispatches-in-rate-window=recent.counts
        max-dispatches-per-window=4
        override-from-star=override
    ==
  (decide-guided:csgl signal context (worker-regime-of bowl target))
::
++  upgrade-mp-outbox
  |=  old=(map @t mp-outbox-entry-1)
  ^-  (map @t mp-outbox-entry:ct)
  %-  ~(run by old)
  |=  entry=mp-outbox-entry-1
  ^-  mp-outbox-entry:ct
  :*  move.entry
      target-ship.entry
      status.entry
      status-at.entry
      reason.entry
      ?:((active:cmr status.entry) `0 ~)
      0
  ==
::
::  Reload invalidates every pre-reload timer by advancing its generation.
::  Only active entries with retry budget remaining receive one replacement.
++  recover-mp-outbox
  |=  [=bowl:gall outbox=(map @t mp-outbox-entry:ct)]
  ^-  mp-outbox-recovery
  =/  entries=(list [@t mp-outbox-entry:ct])  ~(tap by outbox)
  =/  next=(map @t mp-outbox-entry:ct)  outbox
  =|  cards=(list card)
  |-
  ?~  entries  [next (flop cards)]
  =/  [id=@t entry=mp-outbox-entry:ct]  i.entries
  ?.  (active:cmr status.entry)
    $(entries t.entries)
  ?~  retry-attempt.entry
    $(entries t.entries)
  =/  updated=mp-outbox-entry:ct
    entry(retry-generation +(retry-generation.entry))
  =/  wake=card
    %:  mp-retry-wake-card
      bowl  id  u.retry-attempt.entry  retry-generation.updated
      (retry-delay:cmr u.retry-attempt.entry)
    ==
  %=  $
    entries  t.entries
    next     (~(put by next) id updated)
    cards    [wake cards]
  ==
::
++  transition-mp
  |=  [host=@p source=@p inbox=(map @t mp-inbox-entry:ct) move-id=@t to=mp-inbox-status:ct reason=(unit @t)]
  ^-  (unit mp-change)
  =/  found=(unit mp-inbox-entry:ct)  (~(get by inbox) move-id)
  ?~  found  ~
  =/  verdict=verdict:cm
    (transition:cml [host source status.u.found to])
  ?.  ?=(%& -.verdict)  ~
  =/  updated=mp-inbox-entry:ct
    u.found(status to, refuse-reason reason)
  `[(~(put by inbox) move-id updated) updated]
::
++  transition-mp-outbox
  |=  [source=@p outbox=(map @t mp-outbox-entry:ct) ack=mp-receipt:ct]
  ^-  (unit mp-outbox-change)
  =/  found=(unit mp-outbox-entry:ct)
    (~(get by outbox) move-id.ack)
  ?~  found  ~
  =/  verdict=verdict:cm
    (receipt:cml [source found ack])
  ?.  ?=(%& -.verdict)  ~
  =/  next-status=mp-outbox-status:ct  status.ack
  =/  updated=mp-outbox-entry:ct
    %=  u.found
      status         next-status
      status-at      at.ack
      reason         reason.ack
      retry-attempt  ?:((active:cmr next-status) retry-attempt.u.found ~)
    ==
  `[(~(put by outbox) move-id.ack updated) updated]
++  checks-key
  |=  text=@t
  ^-  (unit @ux)
  =/  key  (slaw %ux text)
  ?~  key  ~
  ?.  &(!=(0 u.key) (lte (met 0 u.key) 128) =(text (scot %ux u.key)))  ~
  key
++  landing-key
  |=  text=@t
  ^-  (unit @ux)
  =/  key  (slaw %ux text)
  ?~  key  ~
  ?.  &(!=(0 u.key) (lte (met 0 u.key) 256) =(text (scot %ux u.key)))  ~
  key
++  landing-report
  |=  [key=@ux found=(unit record:connected-land)]
  ^-  card
  [%give %fact ~[/vibecoding/connected-land-v2/(scot %ux key)] %noun !>(`landing-status`[%cantrip-connected-land-status-v2 key found])]
--
%-  cantrip:qpc-flow
%-  agent:coding-tool-worker
%-  agent:coding-worker
%-  agent:qpc-admission
%-  agent:qpc-assessment
%-  agent:check-authorization
%+  agent:qpc-gate  %cantrip
%-  agent:dbug
=|  coding-reviews=ledger:native-review
=|  coding-completion-reviews=ledger:completion-review
=|  coding-review-proofs=proofs:inspected-review
=|  coding-store=organ:compiler-store
=|  coding-compiler=organ:coding-compiler-runtime
=|  coding-assembly=organ:coding-assembly-runtime
=/  compiler-exports=organ:coding-exports  empty:coding-exports
=/  compiler-attachments=organ:coding-attachments  empty:coding-attachments
=/  compiler-prefixes=organ:coding-prefixes  empty:coding-prefixes
=/  gls-toolchains=organ:gls-toolchain  empty:gls-toolchain
=/  compiler-derivations=organ:coding-derivations  empty:coding-derivations
=/  attachment-archive=organ:attachment-store  empty:attachment-store
=/  exports-archive=organ:exports-store  empty:exports-store
=|  coding-hoon=organ:coding-hoon-runtime
=|  hoon-archive=organ:coding-hoon-store
=|  act-lane=organ:acts
=|  coding-deployment=organ:native-deploy
=|  coding-candidates=ledger:native-accept
=|  coding-tools=organ:native-tools
=|  request-ceilings=ledger:request-ceiling
=|  coding-job-handles=state:native-job-runner
=|  project-saves=ledger:project-save
=|  landings=ledger:connected-land
=|  checked-runs=ledger:checks
=|  compilations-v2=ledger-v2:compile-ledger
=|  connected-v2=ledger-v2:connected-write
=|  compilations=ledger:compile-ledger
=|  project-grants=grants:pa
=|  project-records=records:pa
=|  connected=ledger:connected-write
=|  state-11
=*  state  -
^-  agent:gall
|_  =bowl:gall
+*  this  .
    def   ~(. (default-agent this %|) bowl)
    cache  cache.state
    admissions  admissions.state
    mp-inbox  mp-inbox.state
    mp-allow  mp-allow.state
    leases  leases.state
    dispatches  dispatches.state
    mp-outbox  mp-outbox.state
    governor-star  governor-star.state
    governor-cache  governor-cache.state
    local-lands  local-lands.state
    editor-saves  editor-saves.state
    residue  residue.cache
    streak  streak.cache
    health  health.cache
    permission-snapshot
      (project:permissions our.bowl (law-window-for residue streak) (forbidden-acts:act-law our.bowl now.bowl) coding-tools coding-candidates)
    permission-cards
      |=  [tools=organ:native-tools candidates=ledger:native-accept]
      ^-  (list card)
      (facts:permissions bowl (law-window-for residue streak) (forbidden-acts:act-law our.bowl now.bowl) tools candidates)
    permission-connect
      ::  Gall retains subscription identity; no new saved authority/cache.
      ^-  (list card)
      ?:  (~(has by wex.bowl) [/readymade-permissions-graf [our.bowl %graf]])  ~
      ~[[%pass /readymade-permissions-graf %agent [our.bowl %graf] %watch /updates]]
    native-legacy-ready
      ?&  (ready:project-save project-saves now.bowl)
          (old-ready:project-save editor-saves connected connected-v2 now.bowl)
          (legacy-ready:connected-land our.bowl now.bowl landings)
          (levy ~(val by local-lands) |=(r=record:cvll =(%applied status.r)))
          !(lien ~(val by compilations) pending:compile-ledger)
          !(lien ~(val by compilations-v2) pending-v2:compile-ledger)
      ==
    native-heavy-ready
      &((ready:coding-hoon-store hoon-archive) (ready:exports-store exports-archive) (ready:attachment-store attachment-archive) !(lien ~(val by records.coding-tools) |=(r=record:native-tools &((executable:native-tools -.arguments.request.r) ?=(?(%running %unknown) stage.r)))))
    native-source-ready
      &((ready-at:native-accept our.bowl now.bowl coding-candidates) (ready:native-deploy coding-deployment) native-heavy-ready)
    native-deployment-idle
      &(native-legacy-ready (ready-at:native-accept our.bowl now.bowl coding-candidates) native-heavy-ready)
    project-save-observe
      ::  Both explicit owner observation and a matching native Clay reply use
      ::  the same complete-source reader. Neither an ACK nor a clock is proof.
      |=  key=@ux
      ^-  (quip card _this)
      =/  found  (~(get by project-saves) key)
      ?~  found  `this
      ?:  =(%applied status.u.found)
        [~[(report:project-save key found)] this]
      =/  observed  (observe:project-save-read our.bowl our.bowl now.bowl u.found)
      ?:  ?=(%| -.observed)
        [~[(report:project-save key found)] this]
      ?:  =(u.found p.observed)
        [~[(report:project-save key found)] this]
      :_  this(project-saves (~(put by project-saves) key p.observed))
      :~  [%pass /project-save-evidence %agent [our.bowl %graf] %poke %graf-action !>([%attest [%cantrip-project-save-record (digest:project-save p.observed) p.observed]])]
          (report:project-save key `p.observed)
      ==
++  on-init
  =/  rebuilt=(unit cache:crc)
    (rebuild-from-graf our.bowl now.bowl)
  [permission-connect this(state (with-editor-saves (with-local-lands [%8 ?~(rebuilt empty:crc u.rebuilt) *ledger:cbal ~ ~ *table:cls *ledger:vdr ~ ~ ~] *ledger:cvll) *ledger:editor))]
++  on-save
  =/  legacy=saved-state-22
    [%cantrip-judge-state-v22 [%cantrip-judge-state-v21 [%cantrip-judge-state-v20 [%cantrip-judge-state-v19 [%cantrip-judge-state-v18 [%cantrip-judge-state-v17 [%cantrip-judge-state-v16 [%cantrip-judge-state-v15 [%cantrip-judge-state-v14 [%cantrip-judge-state-v13 [%cantrip-judge-state-v12 [%cantrip-judge-state-v11 state] connected] project-grants project-records] compilations] connected-v2] compilations-v2] checked-runs] landings] project-saves] coding-tools] coding-candidates] coding-deployment]
  =/  previous=saved-state-25
    [%cantrip-judge-state-v25 [%cantrip-judge-state-v24 [%cantrip-judge-state-v23 legacy (legacy:coding-compiler-runtime coding-compiler)] coding-reviews] (legacy:compiler-store coding-store)]
  =/  current=saved-state-26
    [%cantrip-judge-state-v26 previous coding-compiler coding-store]
  =/  previous-27=saved-state-27
    [%cantrip-judge-state-v27 current coding-assembly]
  =/  previous-28=saved-state-28
    [%cantrip-judge-state-v28 previous-27 coding-hoon]
  =/  previous-29=saved-state-29
    [%cantrip-judge-state-v29 previous-28 hoon-archive]
  =/  previous-31=saved-state-31
    [%cantrip-judge-state-v31 [%cantrip-judge-state-v30 previous-29 coding-review-proofs] coding-job-handles]
  =/  previous-32=saved-state-32
    [%cantrip-judge-state-v32 previous-31 compiler-exports exports-archive]
  =/  previous-33=saved-state-33
    [%cantrip-judge-state-v33 previous-32 compiler-attachments]
  =/  previous-34=saved-state-34
    [%cantrip-judge-state-v34 previous-33 compiler-derivations]
  =/  previous-35=saved-state-35
    [%cantrip-judge-state-v35 previous-34 attachment-archive]
  =/  previous-36=saved-state-36
    [%cantrip-judge-state-v36 previous-35 coding-completion-reviews]
  =/  previous-37=saved-state-37
    [%cantrip-judge-state-v37 previous-36 compiler-prefixes]
  =/  previous-38=saved-state-38
    [%cantrip-judge-state-v38 previous-37 gls-toolchains]
  =/  previous-39=saved-state-39
    [%cantrip-judge-state-v39 previous-38 act-lane]
  =/  previous-40=saved-state-40
    [%cantrip-judge-state-v40 previous-39 ~]
  !>(`saved-state-41`[%cantrip-judge-state-v41 previous-40 request-ceilings])
++  on-load
  |=  v=vase
  ^-  (quip card _this)
  =/  current-41=(unit saved-state-41)  ((soft saved-state-41) q.v)
  ?>  |(?!(?=([%cantrip-judge-state-v41 *] q.v)) ?=(^ current-41))
  ?>  ?~(current-41 %.y =(u.current-41 q.v))
  =/  ceilings  (restore:request-ceiling our.bowl ?~(current-41 ~ ceilings.u.current-41))
  ?>  ?=(^ ceilings)
  =.  request-ceilings  u.ceilings
  =.  v  ?~(current-41 v !>(legacy.u.current-41))
  ::  v40 is a pure carry of v39: unwrap it, then restore exactly as before.
  =/  carried=(unit saved-state-40)  ((soft saved-state-40) q.v)
  ?>  |(?!(?=([%cantrip-judge-state-v40 *] q.v)) ?=(^ carried))
  ?>  ?~(carried %.y =(u.carried q.v))
  =.  v  ?~(carried v !>(legacy.u.carried))
  =/  current-39=(unit saved-state-39)  ((soft saved-state-39) q.v)
  ?>  |(?!(?=([%cantrip-judge-state-v39 *] q.v)) ?=(^ current-39))
  ?>  ?~(current-39 %.y =(u.current-39 q.v))
  ::  The act lane's residue and open contentions are the law's own record;
  ::  reloading never re-judges an act or re-attests a verdict.
  =.  act-lane  ?~(current-39 empty:acts acts.u.current-39)
  =.  v  ?~(current-39 v !>(legacy.u.current-39))
  =/  current-38=(unit saved-state-38)  ((soft saved-state-38) q.v)
  ?>  |(?!(?=([%cantrip-judge-state-v38 *] q.v)) ?=(^ current-38))
  ?>  ?~(current-38 %.y =(u.current-38 q.v))
  =.  gls-toolchains  ?~(current-38 empty:gls-toolchain gls.u.current-38)
  ::  Trust is opt-in. Existing byte admissions and false GLS reports are
  ::  preserved without promotion; reloading never executes any check.
  =.  v  ?~(current-38 v !>(legacy.u.current-38))
  =/  current-37=(unit saved-state-37)  ((soft saved-state-37) q.v)
  ?>  |(?!(?=([%cantrip-judge-state-v37 *] q.v)) ?=(^ current-37))
  ?>  ?~(current-37 %.y =(u.current-37 q.v))
  =.  compiler-prefixes  ?~(current-37 empty:coding-prefixes prefixes.u.current-37)
  ::  Preserve the whole v36 state. Restoring checkpoints never runs a
  ::  compiler, reads current Clay, or resubmits a completed native job.
  =.  v  ?~(current-37 v !>(legacy.u.current-37))
  =/  current-36=(unit saved-state-36)  ((soft saved-state-36) q.v)
  ?>  |(?!(?=([%cantrip-judge-state-v36 *] q.v)) ?=(^ current-36))
  ?>  ?~(current-36 %.y =(u.current-36 q.v))
  =.  coding-completion-reviews  ?~(current-36 ~ completions.u.current-36)
  ?>  (valid:completion-review our.bowl coding-completion-reviews)
  ::  Retained completion admissions are historical evidence. Reload does not
  ::  read current grants, resubmit contributions, or complete a coding session.
  =.  v  ?~(current-36 v !>(legacy.u.current-36))
  =/  current-35=(unit saved-state-35)  ((soft saved-state-35) q.v)
  ?>  |(?!(?=([%cantrip-judge-state-v35 *] q.v)) ?=(^ current-35))
  ?>  ?~(current-35 %.y =(u.current-35 q.v))
  =.  attachment-archive  ?~(current-35 empty:attachment-store archive.u.current-35)
  ::  Keep archive intents and compact receipts as data; reload never reads
  ::  Clay to reconstruct results, resends a write, or retires provenance.
  =.  v  ?~(current-35 v !>(legacy.u.current-35))
  =/  current-34=(unit saved-state-34)  ((soft saved-state-34) q.v)
  ?>  |(?!(?=([%cantrip-judge-state-v34 *] q.v)) ?=(^ current-34))
  ?>  ?~(current-34 %.y =(u.current-34 q.v))
  =.  compiler-derivations  ?~(current-34 empty:coding-derivations derivations.u.current-34)
  ::  Restore the exact producing receipt joins, never derive or admit again.
  =.  v  ?~(current-34 v !>(legacy.u.current-34))
  =/  current-33=(unit saved-state-33)  ((soft saved-state-33) q.v)
  ?>  |(?!(?=([%cantrip-judge-state-v33 *] q.v)) ?=(^ current-33))
  ?>  ?~(current-33 %.y =(u.current-33 q.v))
  =.  compiler-attachments  ?~(current-33 empty:coding-attachments attachments.u.current-33)
  ::  Admission, revocation and retained results remain data. Never execute
  ::  or infer source/entry certification while restoring the exact v32 state.
  =.  v  ?~(current-33 v !>(legacy.u.current-33))
  =/  current-32=(unit saved-state-32)  ((soft saved-state-32) q.v)
  ?>  |(?!(?=([%cantrip-judge-state-v32 *] q.v)) ?=(^ current-32))
  ?>  ?~(current-32 %.y =(u.current-32 q.v))
  =.  compiler-exports  ?~(current-32 empty:coding-exports exports.u.current-32)
  =.  exports-archive  ?~(current-32 empty:exports-store archive.u.current-32)
  ::  Full typed artifacts and archive intents remain data on reload.
  =.  v  ?~(current-32 v !>(legacy.u.current-32))
  =/  current-31=(unit saved-state-31)  ((soft saved-state-31) q.v)
  ?>  |(?!(?=([%cantrip-judge-state-v31 *] q.v)) ?=(^ current-31))
  ?>  ?~(current-31 %.y =(u.current-31 q.v))
  =.  coding-job-handles  ?~(current-31 ~ jobs.u.current-31)
  ::  Preserve exact handles and early facts. Never replay a start or stop.
  =.  v  ?~(current-31 v !>(legacy.u.current-31))
  =/  current-30=(unit saved-state-30)  ((soft saved-state-30) q.v)
  ?>  |(?!(?=([%cantrip-judge-state-v30 *] q.v)) ?=(^ current-30))
  ?>  ?~(current-30 %.y =(u.current-30 q.v))
  =.  coding-review-proofs  ?~(current-30 ~ proofs.u.current-30)
  ::  Validate proof joins after restoring the exact prior review ledger.
  =.  v  ?~(current-30 v !>(legacy.u.current-30))
  =/  current-29=(unit saved-state-29)  ((soft saved-state-29) q.v)
  ?>  |(?!(?=([%cantrip-judge-state-v29 *] q.v)) ?=(^ current-29))
  ?>  ?~(current-29 %.y =(u.current-29 q.v))
  =.  hoon-archive  ?~(current-29 empty:coding-hoon-store archive.u.current-29)
  ::  Archive validation follows restoration of its shared cache and jobs.
  ::  Loading never observes, resends an archive write or retires an artifact.
  =.  v  ?~(current-29 v !>(legacy.u.current-29))
  =/  current-28=(unit saved-state-28)  ((soft saved-state-28) q.v)
  ?>  |(?!(?=([%cantrip-judge-state-v28 *] q.v)) ?=(^ current-28))
  ?>  ?~(current-28 %.y =(u.current-28 q.v))
  =.  coding-hoon  ?~(current-28 empty:coding-hoon-runtime hoon.u.current-28)
  ?>  (valid:coding-hoon-runtime coding-hoon)
  ::  Stored vases remain data. Migration does not rerun Ford or checks.
  =.  v  ?~(current-28 v !>(legacy.u.current-28))
  =/  current-27=(unit saved-state-27)  ((soft saved-state-27) q.v)
  ?>  |(?!(?=([%cantrip-judge-state-v27 *] q.v)) ?=(^ current-27))
  ?>  ?~(current-27 %.y =(u.current-27 q.v))
  =.  coding-assembly
    ?~(current-27 empty:coding-assembly-runtime assembly.u.current-27)
  ?>  (valid:coding-assembly-runtime coding-assembly)
  ::  Preserve the complete v26 envelope; loading never reruns assembly.
  =.  v  ?~(current-27 v !>(legacy.u.current-27))
  =/  current-26=(unit saved-state-26)  ((soft saved-state-26) q.v)
  ?>  |(?!(?=([%cantrip-judge-state-v26 *] q.v)) ?=(^ current-26))
  ?>  ?~(current-26 %.y =(u.current-26 q.v))
  =.  v  ?~(current-26 v !>(legacy.u.current-26))
  =/  current-25=(unit saved-state-25)  ((soft saved-state-25) q.v)
  ?>  |(?!(?=([%cantrip-judge-state-v25 *] q.v)) ?=(^ current-25))
  ?>  ?~(current-25 %.y =(u.current-25 q.v))
  =/  old-store=organ-v1:compiler-store
    ?~(current-25 *organ-v1:compiler-store compiler-store.u.current-25)
  =.  coding-store  ?~(current-26 (migrate:compiler-store old-store) compiler-store.u.current-26)
  ?>  =(old-store (legacy:compiler-store coding-store))
  ?>  (valid:compiler-store our.bowl coding-store)
  ::  Preserve pending Clay intents; a reload never sends a cache write.
  =.  v  ?~(current-25 v !>(legacy.u.current-25))
  =/  current-24=(unit saved-state-24)  ((soft saved-state-24) q.v)
  ?>  |(?!(?=([%cantrip-judge-state-v24 *] q.v)) ?=(^ current-24))
  ?>  ?~(current-24 %.y =(u.current-24 q.v))
  =.  coding-reviews  ?~(current-24 ~ reviews.u.current-24)
  ?>  (valid:inspected-review our.bowl coding-reviews coding-review-proofs)
  ::  Verdicts survive reload. Loading never requests or settles a review.
  =.  v  ?~(current-24 v !>(legacy.u.current-24))
  =/  current-23=(unit saved-state-23)  ((soft saved-state-23) q.v)
  ?>  |(?!(?=([%cantrip-judge-state-v23 *] q.v)) ?=(^ current-23))
  ?>  ?~(current-23 %.y =(u.current-23 q.v))
  =/  old-compiler=organ-v1:coding-compiler-runtime
    ?~(current-23 *organ-v1:coding-compiler-runtime compiler.u.current-23)
  =.  coding-compiler  ?~(current-26 (migrate:coding-compiler-runtime old-compiler) compiler.u.current-26)
  ?>  =(old-compiler (legacy:coding-compiler-runtime coding-compiler))
  ?>  (valid:coding-compiler-runtime coding-compiler)
  ::  Add only the optional compiler state. The complete v22 envelope follows
  ::  its existing migration path; loading never runs or installs a compiler.
  =.  v  ?~(current-23 v !>(legacy.u.current-23))
  =/  current-22=(unit saved-state-22)  ((soft saved-state-22) q.v)
  =.  coding-deployment  ?~(current-22 *organ:native-deploy deployment.u.current-22)
  ?>  (valid:native-deploy our.bowl coding-deployment)
  ::  Restoring a deployment never clones, activates or retries a thread.
  =.  v  ?~(current-22 v !>(legacy.u.current-22))
  =/  current-21=(unit saved-state-21)  ((soft saved-state-21) q.v)
  =.  coding-candidates  ?~(current-21 ~ candidates.u.current-21)
  ?>  (valid:native-accept coding-candidates)
  =.  v  ?~(current-21 v !>(legacy.u.current-21))
  =/  current-20=(unit saved-state-20)  ((soft saved-state-20) q.v)
  =.  coding-tools  ?~(current-20 *organ:native-tools tools.u.current-20)
  ?>  (valid:native-tools our.bowl coding-tools)
  ?>  (bound:request-ceiling our.bowl request-ceilings coding-tools)
  ?>  (valid:native-job-runner our.bowl coding-job-handles coding-tools)
  ?>  (valid:coding-exports our.bowl compiler-exports seed.coding-assembly coding-tools)
  ?>  (valid:coding-attachments our.bowl compiler-attachments coding-tools)
  ?>  (valid:coding-prefixes our.bowl compiler-prefixes coding-tools)
  ?>  (valid:prefix-runner our.bowl compiler-prefixes coding-job-handles coding-tools)
  ?>  (valid:gls-toolchain our.bowl gls-toolchains compiler-attachments coding-candidates coding-tools)
  ?>  (valid:coding-derivations our.bowl compiler-derivations compiler-attachments coding-tools)
  ?>  (valid:attachment-store our.bowl attachment-archive coding-store compiler-attachments coding-tools hoon-archive exports-archive compiler-derivations)
  ?>  (valid:exports-store our.bowl exports-archive coding-store compiler-exports coding-tools hoon-archive)
  ?>  (valid:coding-hoon-store our.bowl hoon-archive coding-store coding-hoon coding-tools)
  ?>  %+  levy  ~(tap by records.coding-hoon)
      |=  [id=@ux a=artifact:coding-hoon-runtime]
      =/  job  (~(get by records.coding-tools) id)
      ?~  job  %.n
      ?.  =(request.input.a request.u.job)  %.n
      =/  scope  (~(get by grants.coding-tools) grant.u.job)
      ?~  scope  %.n
      &(=(project.input.a project.grant.u.scope) =(scope.a (scope-digest:coding-hoon-runtime u.scope(revoked ~))))
  ?>  %+  levy  ~(tap by results.coding-assembly)
      |=  [id=@ux r=retained:coding-assembly-runtime]
      =/  job  (~(get by records.coding-tools) id)
      ?~  job  %.n
      ?.  =(request.input.r request.u.job)  %.n
      =/  scope  (~(get by grants.coding-tools) grant.u.job)
      ?~  scope  %.n
      &(=(project.input.r project.grant.u.scope) =(scope.r (scope-digest:coding-assembly-runtime u.scope(revoked ~))))
  ::  Preserve the full prior envelope. Native tool jobs never replay on load.
  =.  v  ?~(current-20 v !>(legacy.u.current-20))
  =/  lands=ledger:cvll  *ledger:cvll
  =/  saves=ledger:editor  *ledger:editor
  =/  held=ledger:connected-write  *ledger:connected-write
  =/  current-19=(unit saved-state-19)  ((soft saved-state-19) q.v)
  =.  project-saves  ?~(current-19 ~ projects.u.current-19)
  ?>  (valid:project-save project-saves)
  ?>  %+  levy  ~(val by project-saves)
      |=  r=record:project-save
      ?&  =(our.bowl owner.basis.request.admission.r)
          (lte at.admission.r now.bowl)
          ?~(fence.r %.y (lte at.u.fence.r now.bowl))
          ?~(history.r %.y (lte at.u.history.r now.bowl))
      ==
  ::  Preserve every reservation exactly; loading NEVER emits project writes.
  =/  current-18=(unit saved-state-18)
    ?~(current-19 ((soft saved-state-18) q.v) `legacy.u.current-19)
  =/  restored-landings
    (restore:connected-land our.bowl now.bowl ?~(current-18 ~ landings.u.current-18))
  ?>  ?=(%& -.restored-landings)
  =.  landings  p.restored-landings
  =/  current-17=(unit saved-state-17)
    ?~(current-18 ((soft saved-state-17) q.v) `legacy.u.current-18)
  =/  runs=ledger:checks  ?~(current-17 ~ checks.u.current-17)
  =/  restored  (restore:checks our.bowl now.bowl runs)
  ?>  ?=(%& -.restored)
  ::  Landing history must remain joined to our complete native checks.
  ?>  %+  levy  ~(val by landings)
      |=  r=record:connected-land
      =/  checked=record:checks  record.body.judgment.selected.admission.r
      =(`checked (~(get by runs) nonce.request.checked))
  =/  current-16=(unit saved-state-16)
    ?~(current-17 ((soft saved-state-16) q.v) `legacy.u.current-17)
  =/  compiling-v2=ledger-v2:compile-ledger  ?~(current-16 ~ compilations-v2.u.current-16)
  ::  A saved outcome cannot invent its source compilation on migration.
  ?>  %+  levy  ~(val by runs)
      |=  r=record:checks
      =/  e  (~(get by compiling-v2) write.request.r)
      ?~  e  %.n
      =(`compilation.r record.u.e)
  =/  current-15=(unit saved-state-15)
    ?~(current-16 ((soft saved-state-15) q.v) `legacy.u.current-16)
  =/  modern=ledger-v2:connected-write  ?~(current-15 ~ connected-v2.u.current-15)
  =/  current-14=(unit saved-state-14)
    ?~(current-15 ((soft saved-state-14) q.v) `legacy.u.current-15)
  =/  compiling=ledger:compile-ledger  ?~(current-14 ~ compilations.u.current-14)
  =/  current-13=(unit saved-state-13)
    ?~(current-14 ((soft saved-state-13) q.v) `legacy.u.current-14)
  =/  grants=grants:pa  ?~(current-13 ~ grants.u.current-13)
  =/  records=records:pa  ?~(current-13 ~ records.u.current-13)
  ?>  (valid:project-access our.bowl grants records)
  =/  finish
    |=  loaded=state-8
    ^-  (quip card _this)
    ?>  (valid:cbal admissions.loaded)
    ?>  (valid:cle leases.loaded)
    ?>  (valid:vdrl dispatches.loaded)
    ?>  (ledger-valid:cvll lands)
    ?>  (levy ~(val by lands) |=(r=record:cvll =(our.bowl actor.admission.r)))
    ?>  (ledger-valid:editor saves)
    ?>  (levy ~(val by saves) |=(r=record:editor =(our.bowl owner.change.admission.r)))
    =/  rebuilt=(unit cache:crc)
      (rebuild-from-graf our.bowl now.bowl)
    =/  normalized=state-8
      loaded(cache ?~(rebuilt cache.loaded u.rebuilt))
    =/  recovered=mp-outbox-recovery
      (recover-mp-outbox bowl mp-outbox.normalized)
    ?>  (compatible:connected-write held modern saves)
    ?>  %+  levy  ~(tap by project-saves)
        |=  [key=@ux r=record:project-save]
        ?&  !(~(has by saves) key)
            !(~(has by held) key)  !(~(has by modern) key)
        ==
    ?>  |((ready:project-save project-saves now.bowl) (old-ready:project-save saves held modern now.bowl))
    ?>  (shared:compile-runtime our.bowl compiling compiling-v2 held modern saves)
    =/  resumed  (reload:connected-runtime our.bowl now.bowl held saves)
    =/  resumed-v2  (reload-v2:connected-runtime our.bowl now.bowl next.resumed modern saves)
    =/  compiled  (reload:compile-runtime our.bowl now.bowl compiling next.resumed saves)
    =/  compiled-v2
      (reload-v2:compile-runtime our.bowl now.bowl next.compiled compiling-v2 next.resumed next.resumed-v2 saves)
    =/  cards=(list card)
      (weld (weld (weld cards.recovered cards.resumed) cards.compiled) ?~(current-13 ~ (kicks:project-access bowl ~)))
    [(weld permission-connect (weld (weld cards cards.resumed-v2) cards.compiled-v2)) this(state (with-editor-saves (with-local-lands normalized(mp-outbox next.recovered) lands) saves), connected next.resumed, connected-v2 next.resumed-v2, project-grants grants, project-records records, compilations next.compiled, compilations-v2 next.compiled-v2, checked-runs runs)]
  ?^  current-13
    =/  old=state-11  state.legacy.legacy.u.current-13
    (finish(lands local-lands.old, saves editor-saves.old, held connected.legacy.u.current-13) (without-local-lands (without-editor-saves old)))
  =/  current-12=(unit saved-state-12)  ((soft saved-state-12) q.v)
  ?^  current-12
    =/  old=state-11  state.legacy.u.current-12
    (finish(lands local-lands.old, saves editor-saves.old, held connected.u.current-12) (without-local-lands (without-editor-saves old)))
  =/  current-11=(unit saved-state-11)  ((soft saved-state-11) q.v)
  ?^  current-11
    (finish(lands local-lands.state.u.current-11, saves editor-saves.state.u.current-11) (without-local-lands (without-editor-saves state.u.current-11)))
  =/  current-10=(unit saved-state-10)  ((soft saved-state-10) q.v)
  ?^  current-10
    =/  old=state-10  state.u.current-10
    =/  prior=state-8
      [%8 cache.old admissions.old mp-inbox.old mp-allow.old leases.old dispatches.old mp-outbox.old governor-star.old governor-cache.old]
    (finish(lands local-lands.old, saves (upgrade-ledger:editor editor-saves.old)) prior)
  =/  current-9=(unit saved-state-9)  ((soft saved-state-9) q.v)
  ?^  current-9
    (finish(lands local-lands.state.u.current-9) (without-local-lands state.u.current-9))
  =/  current-8=(unit saved-state-8)  ((soft saved-state-8) q.v)
  ?^  current-8
    (finish state.u.current-8)
  =/  current-7=(unit saved-state-7)  ((soft saved-state-7) q.v)
  ?^  current-7
    %-  finish
    :*  %8  cache.state.u.current-7  admissions.state.u.current-7
        mp-inbox.state.u.current-7  mp-allow.state.u.current-7
        leases.state.u.current-7  dispatches.state.u.current-7
        mp-outbox.state.u.current-7  ~  ~
    ==
  =/  current-6=(unit saved-state-6)  ((soft saved-state-6) q.v)
  ?^  current-6
    %-  finish
    :*  %8  cache.state.u.current-6  admissions.state.u.current-6
        mp-inbox.state.u.current-6  mp-allow.state.u.current-6
        leases.state.u.current-6  dispatches.state.u.current-6
        (upgrade-mp-outbox mp-outbox.state.u.current-6)  ~  ~
    ==
  =/  current-5=(unit saved-state-5)  ((soft saved-state-5) q.v)
  ?^  current-5
    (finish [%8 cache.state.u.current-5 admissions.state.u.current-5 mp-inbox.state.u.current-5 mp-allow.state.u.current-5 leases.state.u.current-5 dispatches.state.u.current-5 ~ ~ ~])
  =/  current=(unit saved-state-4)  ((soft saved-state-4) q.v)
  ?^  current
    (finish [%8 cache.state.u.current admissions.state.u.current mp-inbox.state.u.current mp-allow.state.u.current leases.state.u.current *ledger:vdr ~ ~ ~])
  =/  latest=(unit saved-state-3)  ((soft saved-state-3) q.v)
  ?^  latest
    (finish [%8 cache.state.u.latest admissions.state.u.latest mp-inbox.state.u.latest mp-allow.state.u.latest *table:cls *ledger:vdr ~ ~ ~])
  =/  prior=(unit saved-state-2)  ((soft saved-state-2) q.v)
  ?^  prior
    (finish [%8 cache.state.u.prior admissions.state.u.prior ~ ~ *table:cls *ledger:vdr ~ ~ ~])
  =/  saved=(unit saved-state-1)  ((soft saved-state-1) q.v)
  ?~  saved  !!
  =/  old=state-any-v1  state.u.saved
  =/  fallback=cache:crc
    ?-  -.old
      ::  The historical cache predates citations.  If Graf is unavailable,
      ::  migrating it forward as trusted judgment would launder uncited law.
      %0  (legacy-fallback:crc [residue.old streak.old health.old])
      %1  cache.old
    ==
  =/  rebuilt=(unit cache:crc)
    (rebuild-from-graf our.bowl now.bowl)
  (finish [%8 ?~(rebuilt fallback u.rebuilt) *ledger:cbal ~ ~ *table:cls *ledger:vdr ~ ~ ~])
++  on-poke
  |=  [=mark =vase]
  ^-  (quip card _this)
  ::  A %siev lineage amendment (lib/siev-lineage-law): judged against %siev's
  ::  own current entry and this ship's law window, the verdict given on the
  ::  exact path %siev watches.  No ledger: %siev's .rev bump spends it.
  ?:  &(=(%noun mark) ?=([%siev-lineage-admit-v1 *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  a=lineage-amendment:lin  (need ((soft lineage-amendment:lin) +.q.vase))
    =/  entry=(unit formula-lineage:lin)
      .^((unit formula-lineage:lin) %gx /(scot %p our.bowl)/siev/(scot %da now.bowl)/lineage/formula/[formula.a]/noun)
    =/  barred=?
      !(~(has in admissible:(ship-window our.bowl now.bowl residue streak)) %inscribe)
    =/  v=lineage-verdict:lin  (verdict-for:sll entry a barred)
    [~[[%give %fact ~[/siev/lineage/verdict/(scot %ux key.v)] %noun !>(v)]] this]
  ::  A %siev source-anchor amendment (lib/siev-anchor-law): the same
  ::  judgement against %siev's own current entry and this ship's window.
  ?:  &(=(%noun mark) ?=([%siev-anchor-admit-v1 *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  a=anchor-amendment:lin  (need ((soft anchor-amendment:lin) +.q.vase))
    =/  entry=(unit anchor-entry:lin)
      .^((unit anchor-entry:lin) %gx /(scot %p our.bowl)/siev/(scot %da now.bowl)/anchors/entry/[`@ta`law-id.a]/noun)
    =/  barred=?
      !(~(has in admissible:(ship-window our.bowl now.bowl residue streak)) %inscribe)
    =/  v=anchor-verdict:lin  (verdict-for:sal entry a barred)
    [~[[%give %fact ~[/siev/anchor/verdict/(scot %ux key.v)] %noun !>(v)]] this]
  ?:  &(=(%noun mark) ?=([%readymade-permissions-action-v1 *] q.vase))
    =/  parsed  ((soft command:permissions) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(u.parsed q.vase)
    =/  resolved
      (resolve:permissions our.bowl src.bowl (law-window-for residue streak) (forbidden-acts:act-law our.bowl now.bowl) coding-tools coding-candidates u.parsed)
    ?:  ?=(%| -.resolved)  ~|(p.resolved !!)
    ::  Delegate through the existing native handler with the original bowl.
    ::  No browser verdict, scope noun or source revision enters authority.
    (on-poke %noun !>(p.resolved))
  ?:  &(?=(%noun mark) ?=([?(%native-coding-compiler-prefix-admit-v1 %native-coding-compiler-prefix-revoke-v1 %native-coding-compiler-prefix-select-v1 %native-coding-compiler-prefix-unselect-v1) *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  parsed  ((soft command:coding-prefixes) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(u.parsed q.vase)
    ?>  |(?!(?=(%native-coding-compiler-prefix-admit-v1 -.u.parsed)) native-heavy-ready)
    =/  changed  (act:coding-prefixes bowl compiler-prefixes coding-tools u.parsed)
    ?>  ?=(%& -.changed)
    ?:  =(compiler-prefixes p.changed)  `this
    ::  Owner commands select programs, never supply reusable checkpoints.
    [~[(evidence:native-tools our.bowl [%compiler-prefix (shax (jam u.parsed))])] this(compiler-prefixes p.changed)]
  ?:  &(?=(%noun mark) ?=([?(%native-coding-compiler-attachment-store-v1 %native-coding-compiler-attachment-store-observe-v1 %native-coding-compiler-attachment-retire-v1) *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  parsed  ((soft command:attachment-store) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(u.parsed q.vase)
    =/  idle=?
      &((permission:editor (law-window-for residue streak)) native-legacy-ready native-source-ready)
    =/  changed
      (act:attachment-store bowl attachment-archive coding-store compiler-attachments coding-tools hoon-archive exports-archive compiler-derivations u.parsed idle)
    ?>  ?=(%& -.changed)
    [cards.p.changed this(attachment-archive state.p.changed, coding-store cache.p.changed, compiler-attachments compiled.p.changed)]
  ?:  &(?=(%noun mark) ?=([%native-coding-compiler-derive-v1 *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  parsed  ((soft command:coding-derivations) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(u.parsed q.vase)
    ?>  native-heavy-ready
    =/  changed  (act:coding-derivations bowl compiler-derivations compiler-attachments coding-tools u.parsed)
    ?>  ?=(%& -.changed)
    ?:  &(=(compiler-derivations state.p.changed) =(compiler-attachments attachments.p.changed))  `this
    [~[(evidence:native-tools our.bowl [%compiler-derivation (shax (jam u.parsed))])] this(compiler-derivations state.p.changed, compiler-attachments attachments.p.changed)]
  ?:  &(?=(%noun mark) ?=([?(%native-coding-gls-toolchain-trust-v1 %native-coding-gls-toolchain-revoke-v1) *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  parsed  ((soft command:gls-toolchain) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(u.parsed q.vase)
    ?>  |(?!(?=(%native-coding-gls-toolchain-trust-v1 -.u.parsed)) native-source-ready)
    =/  changed  (act:gls-toolchain bowl gls-toolchains compiler-attachments u.parsed)
    ?>  ?=(%& -.changed)
    ?:  =(gls-toolchains p.changed)  `this
    [~[(evidence:native-tools our.bowl [%gls-toolchain (shax (jam u.parsed))])] this(gls-toolchains p.changed)]
  ?:  &(?=(%noun mark) ?=([?(%native-coding-compiler-attachment-admit-v1 %native-coding-compiler-attachment-revoke-v1 %native-coding-compiler-attachment-select-v1 %native-coding-compiler-attachment-unselect-v1 %native-coding-compiler-attachment-retain-v1) *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  parsed  ((soft command:coding-attachments) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(u.parsed q.vase)
    ::  Admission waits for bounded native jobs. Revocation and retention
    ::  must remain possible while those jobs are running or uncertain.
    ?>  |(?!(?=(%native-coding-compiler-attachment-admit-v1 -.u.parsed)) native-heavy-ready)
    ::  A retained archive intent seals its exact result, even after retirement.
    ?>  ?:  ?=(%native-coding-compiler-attachment-retain-v1 -.u.parsed)
          !(~(has by records.attachment-archive) id.u.parsed)
        %.y
    =/  changed  (act:coding-attachments bowl compiler-attachments coding-tools u.parsed)
    ?>  ?=(%& -.changed)
    ?:  =(compiler-attachments p.changed)  `this
    [~[(evidence:native-tools our.bowl [%compiler-attachment (shax (jam u.parsed))])] this(compiler-attachments p.changed)]
  ?:  &(?=(%noun mark) ?=([?(%native-coding-compiler-exports-store-v1 %native-coding-compiler-exports-store-observe-v1 %native-coding-compiler-exports-retire-v1) *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  parsed  ((soft command:exports-store) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(u.parsed q.vase)
    =/  idle=?
      &((permission:editor (law-window-for residue streak)) native-legacy-ready native-source-ready)
    =/  changed
      (act:exports-store bowl exports-archive coding-store compiler-exports coding-tools hoon-archive u.parsed idle)
    ?>  ?=(%& -.changed)
    [cards.p.changed this(exports-archive state.p.changed, coding-store cache.p.changed, compiler-exports compiled.p.changed)]
  ?:  &(?=(%noun mark) ?=([?(%native-coding-compiler-exports-configure-v1 %native-coding-compiler-exports-revoke-v1 %native-coding-compiler-exports-retain-v1) *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  parsed  ((soft command:coding-exports) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(u.parsed q.vase)
    ::  Archival seals the result against retention pokes, including after retirement.
    ?>  ?:  ?=(%native-coding-compiler-exports-retain-v1 -.u.parsed)
          !(~(has by records.exports-archive) id.u.parsed)
        %.y
    =/  changed  (act:coding-exports bowl compiler-exports coding-tools seed.coding-assembly u.parsed)
    ?>  ?=(%& -.changed)
    ?:  =(compiler-exports p.changed)  `this
    [~[(evidence:native-tools our.bowl [%compiler-exports (shax (jam u.parsed))])] this(compiler-exports p.changed)]
  ?:  &(?=(%noun mark) ?=([?(%native-coding-hoon-store-v1 %native-coding-hoon-store-observe-v1 %native-coding-hoon-artifact-retire-v1) *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  parsed  ((soft command:coding-hoon-store) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(u.parsed q.vase)
    =/  idle=?
      ?.  ?=(%native-coding-hoon-store-v1 -.u.parsed)  %.n
      ?&  (permission:editor (law-window-for residue streak))
          native-legacy-ready  native-heavy-ready
          (ready-at:native-accept our.bowl now.bowl coding-candidates)
          (ready:native-deploy coding-deployment)
      ==
    =/  changed
      (act:coding-hoon-store bowl hoon-archive coding-store coding-hoon coding-tools u.parsed idle)
    ?>  ?=(%& -.changed)
    ::  Three related states move in the same Gall event before any Clay card.
    [cards.p.changed this(hoon-archive state.p.changed, coding-store cache.p.changed, coding-hoon artifacts.p.changed)]
  ?:  &(?=(%noun mark) ?=([%native-coding-hoon-artifact-retain-v1 *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  parsed  ((soft command:coding-hoon-runtime) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(u.parsed q.vase)
    =/  changed  (act:coding-hoon-runtime bowl coding-hoon coding-tools u.parsed)
    ?>  ?=(%& -.changed)
    ?:  =(coding-hoon p.changed)  `this
    :_  this(coding-hoon p.changed)
    ~[(evidence:native-tools our.bowl [%hoon-artifact id.u.parsed digest.value.u.parsed product.value.u.parsed])]
  ?:  &(?=(%noun mark) ?=([?(%native-coding-terminal-assembly-install-v1 %native-coding-terminal-assembly-retain-v1) *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  parsed  ((soft command:coding-assembly-runtime) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(u.parsed q.vase)
    ?>  |(?!(?=(%native-coding-terminal-assembly-install-v1 -.u.parsed)) native-heavy-ready)
    =/  changed  (act:coding-assembly-runtime bowl coding-assembly coding-tools u.parsed)
    ?>  ?=(%& -.changed)
    ?>  (valid:coding-exports our.bowl compiler-exports seed.p.changed coding-tools)
    ?:  =(coding-assembly p.changed)  `this
    :_  this(coding-assembly p.changed)
    ~[(evidence:native-tools our.bowl [%terminal-assembly (shax (jam u.parsed))])]
  ?:  &(?=(%noun mark) ?=([?(%native-coding-compiler-store-configure-v1 %native-coding-compiler-store-revoke-v1 %native-coding-compiler-store-v1 %native-coding-compiler-store-observe-v1) *] q.vase))
    =/  parsed  ((soft command:compiler-store) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(u.parsed q.vase)
    =/  idle=?
      ?&  (permission:editor (law-window-for residue streak))
          native-legacy-ready  (ready-at:native-accept our.bowl now.bowl coding-candidates)
          (ready:native-deploy coding-deployment)
          (ready:coding-hoon-store hoon-archive)
          (ready:exports-store exports-archive)
          (ready:attachment-store attachment-archive)
      ==
    =/  changed  (act:compiler-store bowl coding-store coding-compiler coding-tools u.parsed idle)
    [cards.changed this(coding-store state.changed)]
  ?:  &(?=(%noun mark) ?=([%native-coding-completion-review-admit-v1 *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  parsed  ((soft command:completion-review-protocol) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(u.parsed q.vase)
    =/  changed  (act:completion-review bowl coding-completion-reviews coding-tools u.parsed)
    [cards.changed this(coding-completion-reviews next.changed)]
  ?:  &(?=(%noun mark) ?=([%native-coding-review-admit-v1 *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  parsed  ((soft command:native-review-protocol) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(u.parsed q.vase)
    =/  key=key:native-review  [campaign.u.parsed request.u.parsed]
    =/  prior  (~(get by coding-reviews) key)
    =/  inspected=?
      ?^  prior
        =('native-ai-review-standing-scope-v2' law.admission.verdict.u.prior)
      ?>  (agent-live:vsg our.bowl now.bowl %viki)
      =/  captured=(unit entry:review-inspection)
        .^((unit entry:review-inspection) %gx /(scot %p our.bowl)/viki/(scot %da now.bowl)/native-coding/review-inspection/(scot %ux campaign.key)/(scot %ux request.key)/noun)
      ?=(^ captured)
    ?:  inspected
      ::  The helper rereads Viki and validates the captured native inspection.
      ::  A present but invalid proof cannot fall back to the legacy law.
      =/  changed
        (act:inspected-review bowl coding-reviews coding-review-proofs coding-candidates grants.coding-tools u.parsed)
      [cards.changed this(coding-reviews next.changed, coding-review-proofs proofs.changed)]
    =/  changed
      (act:native-review bowl coding-reviews coding-candidates grants.coding-tools u.parsed)
    [cards.changed this(coding-reviews next.changed)]
  ?:  &(?=(%noun mark) ?=([?(%native-coding-compiler-install-v1 %native-coding-compiler-retain-v1 %native-coding-compiler-mapping-configure-v1 %native-coding-compiler-mapping-revoke-v1) *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  parsed  ((soft command:coding-compiler-runtime) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(u.parsed q.vase)
    ?>  |(?!(?=(%native-coding-compiler-install-v1 -.u.parsed)) native-heavy-ready)
    =/  changed  (act:coding-compiler-runtime bowl coding-compiler coding-tools u.parsed)
    ?>  ?=(%& -.changed)
    =/  cards=(list card)
      ?.  ?=(%native-coding-compiler-retain-v1 -.u.parsed)  ~
      ?:  (~(has by emissions.coding-compiler) id.u.parsed)  ~
      ?.  (ready:exports-store exports-archive)  ~
      ?.  (ready:attachment-store attachment-archive)  ~
      (auto:compiler-store our.bowl coding-store p.changed id.u.parsed)
    [cards this(coding-compiler p.changed)]
  ?:  &(?=(%noun mark) ?=([?(%native-coding-deployment-grant-v1 %native-coding-deployment-revoke-v1 %native-coding-deploy-v1 %native-coding-deployment-observe-v1 %native-coding-deployment-activate-v1 %native-coding-deployment-cancel-v1) *] q.vase))
    =/  parsed  ((soft ,command:deploy-runtime) q.vase)
    ?>  ?=(^ parsed)
    =/  changed  (act:deploy-runtime bowl coding-deployment coding-candidates u.parsed (law-window-for residue streak) native-deployment-idle)
    [cards.changed this(coding-deployment next.changed)]
  ?:  &(?=(%noun mark) ?=([?(%native-coding-worker-apply-v1 %native-coding-worker-capacity-v1) @] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  key=@ux  +.q.vase
    ?>  &(!=(0 key) (lte (met 0 key) 256))
    =/  route=@tas  ?:(=(%native-coding-worker-capacity-v1 -.q.vase) %capacity %completion)
    ::  A key names the wrapper's retained authenticated receipt. The caller
    ::  cannot supply a report, a permission, or a synthetic Khan callback.
    =/  completed=(unit completion:coding-worker)
      .^((unit completion:coding-worker) %gx /(scot %p our.bowl)/cantrip/(scot %da now.bowl)/native-coding/worker/[route]/(scot %ux key)/noun)
    ?~  completed  `this
    ?>  ?:(=(%capacity route) &(=(key candidate.u.completed) =(outcome.u.completed [%refused %worker-capacity])) =(key ticket.u.completed))
    =/  ticket=@ux  ticket.u.completed
    =/  found  (~(get by coding-candidates) candidate.u.completed)
    ?~  found  `this
    =/  r=record:native-accept  u.found
    ?.  &((check-dispatched:native-accept r) =(ticket (digest:native-accept [%native-coding-check-ticket-v1 r])))  `this
    =/  outcome=outcome:coding-worker  outcome.u.completed
    =/  changed=change:native-accept
      ?:  ?=(%checked -.outcome)
        (checked:native-accept our.bowl coding-candidates id.candidate.r report.outcome)
      (put:native-accept our.bowl coding-candidates r(stage ?:(?=(%refused -.outcome) %refused %unknown), reason `reason.outcome) ~)
    [(weld cards.changed (permission-cards coding-tools next.changed)) this(coding-candidates next.changed)]
  ?:  &(?=(%noun mark) ?=([?(%native-coding-review-v1 %native-coding-decide-v1 %native-coding-candidate-observe-v1 %native-coding-candidate-recheck-v1) *] q.vase))
    =/  parsed  ((soft ,command:native-accept) q.vase)
    ?>  ?=(^ parsed)
    ?>  |(?=(%native-coding-candidate-observe-v1 -.u.parsed) &(native-legacy-ready native-heavy-ready (ready:native-deploy coding-deployment)))
    =/  changed  (candidate-act:gls-toolchain bowl gls-toolchains compiler-attachments coding-tools coding-candidates u.parsed (ship-window our.bowl now.bowl residue streak))
    [(weld cards.changed (permission-cards coding-tools next.changed)) this(coding-candidates next.changed)]
  ?:  &(?=(%noun mark) ?=([%native-coding-request-ceiling-v1 *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  parsed  ((soft ,[tag=%native-coding-request-ceiling-v1 value=request:request-ceiling]) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(q.vase u.parsed)
    =/  proposed  (read:request-ceiling-read bowl coding-tools value.u.parsed)
    ~|  [%request-ceiling-admission proposed]
    ?>  ?=(%& -.proposed)
    =/  next  (narrow:request-ceiling our.bowl request-ceilings p.proposed)
    ~|  [%request-ceiling-attenuation next]
    ?>  ?=(%& -.next)
    [~ this(request-ceilings p.next)]
  ?:  &(?=(%noun mark) ?=([%native-coding-revoke-actor-v1 *] q.vase))
    ::  Owner sweep after removing a member: every live grant that ship holds
    ::  in that project is revoked through the ordinary single-revoke path.
    ?>  =(our.bowl src.bowl)
    =/  parsed  ((soft ,[tag=%native-coding-revoke-actor-v1 project=@t actor=@p]) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(q.vase u.parsed)
    =/  ids=(list @ux)  (targets:revoke-actor coding-tools project.u.parsed actor.u.parsed)
    =|  cards=(list card)
    |-  ^-  (quip card _this)
    ?~  ids  [(weld cards (permission-cards coding-tools coding-candidates)) this]
    =/  changed  (act:native-job-runner bowl coding-job-handles coding-tools [%native-coding-revoke-v1 i.ids])
    %=  $
      ids  t.ids
      cards  (weld cards cards.changed)
      coding-tools  tools.changed
      coding-job-handles  state.changed
    ==
  ?:  &(?=(%noun mark) ?=([?(%native-coding-grant-v1 %native-coding-revoke-v1 %native-coding-execute-v1 %native-coding-observe-v1 %native-coding-cancel-v1) *] q.vase))
    =/  parsed  ((soft command:native-tools) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(u.parsed q.vase)
    ?>  ?:  ?=(%native-coding-execute-v1 -.u.parsed)
          |(!(executable:native-tools -.arguments.request.u.parsed) (~(has by records.coding-tools) (key:native-tools request.u.parsed)) &(native-legacy-ready native-source-ready))
        %.y
    =/  changed  (act:native-job-runner bowl coding-job-handles coding-tools u.parsed)
    [(weld cards.changed (permission-cards tools.changed coding-candidates)) this(coding-tools tools.changed, coding-job-handles state.changed)]
  ?:  &(?=(%noun mark) ?=([%cantrip-project-save-v1 *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  parsed  ((soft ,request:project-save) q.vase)
    ?>  ?=(^ parsed)
    =/  r=request:project-save  u.parsed
    =/  prior  (lookup:project-save project-saves r)
    ~|  [%project-save-refused prior]
    ?>  ?=(%& -.prior)
    ?^  p.prior  `this
    ?>  native-source-ready
    ?>  &(!(~(has by editor-saves) nonce.r) !(~(has by connected) nonce.r) !(~(has by connected-v2) nonce.r))
    ?>  (old-ready:project-save editor-saves connected connected-v2 now.bowl)
    ?>  (legacy-ready:connected-land our.bowl now.bowl landings)
    ?>  (levy ~(val by local-lands) |=(r=record:cvll =(%applied status.r)))
    =/  admitted
      (admit:project-save-read our.bowl src.bowl now.bowl r (law-window-for residue streak))
    ~|  [%project-save-admission-refused admitted]
    ?>  ?=(%& -.admitted)
    =/  reserved  (reserve:project-save our.bowl now.bowl project-saves p.admitted)
    ~|  [%project-save-reservation-refused reserved]
    ?>  ?=(%& -.reserved)
    ::  Canonical reads, law, reservation and ONE atomic %info share this
    ::  event. No caller-supplied pass flag or Graf fact admits a write.
    :_  this(project-saves next.p.reserved)
    :~  card.p.reserved
        (completion:project-save our.bowl record.p.reserved)
        (report:project-save nonce.r `record.p.reserved)
    ==
  ?:  &(?=(%noun mark) ?=([%cantrip-project-save-observe-v1 *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  parsed  ((soft ,[%cantrip-project-save-observe-v1 nonce=@ux]) q.vase)
    ?>  ?=(^ parsed)
    (project-save-observe nonce.u.parsed)
  ?:  &(?=(%noun mark) ?=([%cantrip-connected-land-v2 *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  parsed  ((soft ,command:connected-land) q.vase)
    ?>  ?=(^ parsed)
    =/  c=command:connected-land  u.parsed
    =/  prior  (lookup:connected-land our.bowl src.bowl now.bowl landings c)
    ~|  [%connected-land-refused prior]
    ?>  ?=(%& -.prior)
    ?^  p.prior  [~[(landing-report digest.c p.prior)] this]
    ?>  native-source-ready
    ?>  (ready:project-save project-saves now.bowl)
    ?>  (lth ~(wyt by landings) 128)
    ?>  (legacy-ready:connected-land our.bowl now.bowl landings)
    =/  old  (reconcile-legacy:connected-land-read our.bowl src.bowl now.bowl local-lands)
    ~|  [%connected-land-legacy-observation-refused old]
    ?>  ?=(%& -.old)
    =/  own=owned:connected-land-read  [checked-runs compilations-v2 connected-v2 editor-saves]
    =/  window  (law-window-for residue streak)
    =/  [started=(each transition:connected-land @tas) ev=(unit act:clflect)]
      (start-evidence:connected-land-read our.bowl src.bowl now.bowl landings p.old c own window)
    ::  GEOMETRY DECIDES (phase 11, the last lane, 2026-09-27) whenever the
    ::  read yielded the act: the landing against the connected-land law
    ::  (lib/cantrip-connected-land-flect, proven to agree with the judge on
    ::  every fixture).  The judge is the CONTROL: any disagreement refuses
    ::  and names itself; a refusal names the reason and the axes.  A refusal
    ::  before the judge ran (no act), and a replay, are the read's own.
    =/  env  `env:clflect`[our.bowl src.bowl now.bowl window]
    =/  sh=(unit shadow:shadow)
      ?~  ev  ~
      `(shadow-with:shadow %connected-land land-law:clflect !>(`act:clflect`u.ev) env started)
    =/  judge-ok=?  ?=(%& -.started)
    =/  fit=(unit ?)  ?~(sh ~ `fit.verdict.receipt.u.sh)
    ?:  ?&(?=(^ fit) !=(u.fit judge-ok))
      ~|([%connected-land-control-disagrees law=(need fit) judge=started] !!)
    ?:  ?&(?=(^ fit) !u.fit)
      ~|  :+  %connected-land-refused
            ?~(sh ~ (reason:clflect receipt.u.sh (need ev) env))
          axes=?~(sh ~ (turn misses.verdict.receipt.u.sh |=(mi=miss:flect-law axis.mi)))
      !!
    ?.  judge-ok  ~|([%connected-land-refused started] !!)
    ?>  ?=(%& -.started)
    =/  receipt-cards=(list card)
      ?~  sh  ~
      ~[[%pass /connected-land-evidence %agent [our.bowl %graf] %poke %graf-action !>([%attest (fact:shadow u.sh)])]]
    ::  The reconciled legacy fence and the new reservation share the write.
    :_  this(landings next.p.started, state state(local-lands p.old))
    %+  weld
      (snoc cards.p.started (landing-report digest.c `record.p.started))
    receipt-cards
  ?:  &(?=(%noun mark) ?=([%cantrip-connected-land-observe-v2 *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  parsed  ((soft ,[%cantrip-connected-land-observe-v2 digest=@ux]) q.vase)
    ?>  ?=(^ parsed)
    =/  key=@ux  digest.u.parsed
    ?>  &(!=(0 key) (lte (met 0 key) 256))
    =/  held  (~(get by landings) key)
    ?~  held  [~[(landing-report key ~)] this]
    =/  observed  (observe:connected-land-read our.bowl src.bowl now.bowl u.held)
    ~|  [%connected-land-observation-refused observed]
    ?>  ?=(%& -.observed)
    [~[(landing-report key `p.observed)] this(landings (~(put by landings) key p.observed))]
  ?:  &(?=(%noun mark) ?=([%cantrip-connected-checks-run-v2 *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  parsed  ((soft ,command:checks) q.vase)
    ?>  ?=(^ parsed)
    =/  c=command:checks  u.parsed
    ?>  |((~(has by checked-runs) nonce.c) native-source-ready)
    =/  own=owned-v2:checks-preview
      [(~(get by compilations-v2) write.c) [(~(get by connected-v2) write.c) (~(get by editor-saves) write.c)]]
    =/  started
      (from-owned:checks-read our.bowl src.bowl now.bowl checked-runs c own (law-window-for residue streak))
    ~|  [%connected-checks-refused started]
    ?>  ?=(%& -.started)
    ::  Computation, retention and publication share this one native event.
    :_  this(checked-runs next.p.started)
    ~[[%give %fact ~[/vibecoding/connected-checks-v2/(scot %ux nonce.c)] %noun !>(`checks-status`[%cantrip-connected-checks-status-v2 nonce.c `record.p.started])]]
  =/  compile-act-v2=(unit command-v2:compile-ledger)
    ?.  =(%noun mark)  ~
    ((soft ,command-v2:compile-ledger) q.vase)
  ?^  compile-act-v2
    ?>  |((~(has by compilations-v2) nonce.u.compile-act-v2) native-source-ready)
    =/  started
      (start-v2:compile-runtime bowl compilations compilations-v2 connected connected-v2 editor-saves u.compile-act-v2 (law-window-for residue streak))
    ~|  [%connected-compile-v2-refused started]
    ?>  ?=(%& -.started)
    [cards.p.started this(compilations-v2 next.p.started)]
  =/  compile-act=(unit command:compile-ledger)
    ?.  =(%noun mark)  ~
    ((soft ,command:compile-ledger) q.vase)
  ?^  compile-act
    ?>  |((~(has by compilations) nonce.u.compile-act) native-source-ready)
    =/  started
      (start-v1-shared:compile-runtime bowl compilations compilations-v2 connected connected-v2 editor-saves u.compile-act (law-window-for residue streak))
    ~|  [%connected-compile-refused started]
    ?>  ?=(%& -.started)
    [cards.p.started this(compilations next.p.started)]
  =/  project-act=(unit action:pa)
    ?.  =(%noun mark)  ~
    ((soft ,action:pa) q.vase)
  ?^  project-act
    =/  changed
      (act:project-access bowl project-grants project-records u.project-act (law-window-for residue streak))
    ?:  ?=(%| -.changed)  ~|([%project-access-refused p.changed] !!)
    [cards.p.changed this(project-grants grants.p.changed, project-records records.p.changed)]
  =/  connected-act-v2=(unit request-v2:connected-write)
    ?.  =(%noun mark)  ~
    ((soft ,request-v2:connected-write) q.vase)
  ?^  connected-act-v2
    ?>  |((~(has by connected-v2) nonce.u.connected-act-v2) native-source-ready)
    ?>  !(~(has by project-saves) nonce.u.connected-act-v2)
    ?>  |((~(has by connected-v2) nonce.u.connected-act-v2) (ready:project-save project-saves now.bowl))
    =/  started
      (start-v2:connected-write our.bowl src.bowl now.bowl connected connected-v2 editor-saves u.connected-act-v2)
    ~|  [%connected-write-v2-refused started]
    ?>  ?=(%& -.started)
    [cards.p.started this(connected-v2 next.p.started, state state(editor-saves saves.p.started))]
  =/  connected-act=(unit request:connected-write)
    ?.  =(%noun mark)  ~
    ((soft ,request:connected-write) q.vase)
  ?^  connected-act
    ?>  |((~(has by connected) nonce.u.connected-act) native-source-ready)
    ?>  !(~(has by project-saves) nonce.u.connected-act)
    ?>  |((~(has by connected) nonce.u.connected-act) (ready:project-save project-saves now.bowl))
    =/  started
      (start-v1-shared:connected-write our.bowl src.bowl now.bowl connected connected-v2 editor-saves u.connected-act)
    ~|  [%connected-write-refused started]
    ?>  ?=(%& -.started)
    [cards.p.started this(connected next.p.started, state state(editor-saves saves.p.started))]
  ::  THE ACT LANE (phase 15's producer): the five-verdict law, live.  The
  ::  operator submits [act summary move]; the law judges it against the
  ::  current bands and regime and the lane's residue; every verdict, and any
  ::  contention it opens or resolves, is a graf fact the delay can draw.
  =/  act-sub=(unit [%cantrip-submit-act sub=act-submission:ct])
    ?.  =(%noun mark)  ~
    ((soft ,[%cantrip-submit-act sub=act-submission:ct]) q.vase)
  ?^  act-sub
    ?>  =(our.bowl src.bowl)
    =/  window  (law-window-for residue streak)
    =/  law  (law-state-of:acts (bands-for residue streak) regime.window)
    =/  out  (submit:acts act-lane sub.u.act-sub law our.bowl now.bowl)
    :_  this(act-lane o.out)
    %+  turn  facts.out
    |=  f=*
    ^-  card
    [%pass /act-lane %agent [our.bowl %graf] %poke %graf-action !>([%attest f])]
  =/  edit-act=(unit action:editor)
    ?.  =(%noun mark)  ~
    ((soft ,action:editor) q.vase)
  ?^  edit-act
    ?>  =(our.bowl src.bowl)
    ?-  -.u.edit-act
      %pataphor-editor-save
        =/  change  change.u.edit-act
        =/  prior  (lookup:editor editor-saves change)
        ::  Every refusal below names ONLY itself: a `~|` wraps the rest of
        ::  the arm, so labels stacked above a crash all print, and a label
        ::  for a check that passed reads as if it failed.
        ?.  ?=(%& -.prior)  ~|([%editor-save-refused prior] !!)
        ::  A replay is a read of the reservation, before any stale-source
        ::  checks. Different bytes under the same nonce are refused above.
        ?^  p.prior  `this
        ?>  native-source-ready
        ?>  !(~(has by project-saves) nonce.change)
        ?>  (ready:project-save project-saves now.bowl)
        =/  window  (law-window-for residue streak)
        =/  basis-read  (read:editor-read our.bowl src.bowl now.bowl)
        ?.  ?=(%& -.basis-read)  ~|([%editor-save-refused basis-read] !!)
        ::  GEOMETRY DECIDES (phase 9 cut-over, 2026-09-27).  The act
        ::  [change basis] is judged by the editor law (lib/cantrip-editor-flect:
        ::  the type-law plus the judge's predicates as gates, proven to agree
        ::  with the judge on every fixture, verdict and reason).  The lane's
        ::  judge runs as the CONTROL: a disagreement in either direction
        ::  refuses the save and names itself.  The receipt keeps both verdicts
        ::  as an append-only graf fact (%cantrip-receipt); the facts are the
        ::  measurement.
        =/  act  !>(`act:elaw`[change p.basis-read])
        =/  env  `env:elaw`[our.bowl src.bowl now.bowl window]
        =/  judged  (judge:editor our.bowl src.bowl now.bowl change p.basis-read window)
        =/  sh  (shadow-with:shadow %editor-save editor-law:elaw act env judged)
        =/  fit=?  fit.verdict.receipt.sh
        ?.  =(fit ?=(%& -.judged))
          ~|([%editor-save-control-disagrees law=fit judge=judged] !!)
        ?.  fit
          ~|  :+  %editor-save-refused
                (reason:elaw receipt.sh [change p.basis-read] env)
              axes=(turn misses.verdict.receipt.sh |=(mi=miss:flect-law axis.mi))
          !!
        ?>  ?=(%& -.judged)
        =/  reserved  (reserve:editor editor-saves p.judged our.bowl now.bowl)
        ?.  ?=(%& -.reserved)  ~|([%editor-save-reservation-refused reserved] !!)
        =/  receipt-card=card
          [%pass /editor-save-evidence %agent [our.bowl %graf] %poke %graf-action !>([%attest (fact:shadow sh)])]
        ::  Current Cantrip law, canonical Clay reads, reservation and the
        ::  sole fixed-path source effect share this exact Gall event.
        [~[card.p.reserved receipt-card] this(state state(editor-saves next.p.reserved))]
      %pataphor-editor-save-observe
        =/  key=@ux  nonce.u.edit-act
        =/  held  (~(get by editor-saves) key)
        ?~  held  `this
        ?:  =(%applied status.u.held)  `this
        =/  observed  (observe:editor-read our.bowl src.bowl now.bowl u.held)
        ?~  observed  `this
        =/  next=record:editor  (observe:editor u.held u.observed)
        ?>  (record-valid:editor next)
        ?:  =(next u.held)  `this
        :_  this(state state(editor-saves (~(put by editor-saves) key next)))
        ~[[%pass /editor-save-evidence %agent [our.bowl %graf] %poke %graf-action !>([%attest (fact:editor next)])]]
    ==
  =/  land-act=(unit action:cvll)
    ?.  =(%noun mark)  ~
    ((soft ,action:cvll) q.vase)
  ?^  land-act
    ?>  =(our.bowl src.bowl)
    =/  key=@ux  judgment.u.land-act
    ?-  -.u.land-act
      %vibecoding-local-land
        ::  A repeated key returns no write, even after a lost response or
        ::  reload. The caller reconciles the canonical retained row.
        ?:  (~(has by local-lands) key)  `this
        ?>  native-source-ready
        ?>  (ready:project-save project-saves now.bowl)
        ?>  (legacy-ready:connected-land our.bowl now.bowl landings)
        =/  window  (law-window-for residue streak)
        =/  [judged=decision:cvll ev=(unit act:lflect)]
          (read-evidence:cvllr our.bowl src.bowl now.bowl key window)
        ::  GEOMETRY DECIDES (phase 11 cut-over, 2026-09-27) whenever the read
        ::  yielded the act: the landing against the land law
        ::  (lib/cantrip-land-flect, proven to agree with the judge on every
        ::  fixture).  The judge is the CONTROL: any disagreement refuses and
        ::  names itself; a refusal names the reason and the axes.  A refusal
        ::  before the judge ran (no act) is the read's own.
        =/  env  `env:lflect`[our.bowl src.bowl now.bowl window]
        =/  sh=(unit shadow:shadow)
          ?~  ev  ~
          `(shadow-with:shadow %local-land land-law:lflect !>(`act:lflect`u.ev) env judged)
        =/  judge-ok=?  ?=(%& -.judged)
        =/  fit=(unit ?)  ?~(sh ~ `fit.verdict.receipt.u.sh)
        ?:  ?&(?=(^ fit) !=(u.fit judge-ok))
          ~|([%local-land-control-disagrees law=(need fit) judge=judged] !!)
        ?:  ?&(?=(^ fit) !u.fit)
          ~|  :+  %local-land-refused
                ?~(sh ~ (reason:lflect receipt.u.sh (need ev) env))
              axes=?~(sh ~ (turn misses.verdict.receipt.u.sh |=(mi=miss:flect-law axis.mi)))
          !!
        ?.  judge-ok  ~|([%local-land-refused judged] !!)
        ?>  ?=(%& -.judged)
        =/  reserved  (reserve:cvll local-lands p.judged our.bowl now.bowl)
        ?.  ?=(%& -.reserved)  ~|([%local-land-reservation-refused reserved] !!)
        ::  the receipt -- both verdicts -- is an append-only graf fact
        =/  receipt-cards=(list card)
          ?~  sh  ~
          ~[[%pass /local-land-evidence %agent [our.bowl %graf] %poke %graf-action !>([%attest (fact:shadow u.sh)])]]
        ::  Admission, durable reservation and exact Clay effect are one
        ::  Gall event; no asynchronous read or permission token in between.
        :_  this(state state(local-lands next.p.reserved))
        %+  weld
          ~[card.p.reserved (card-for:cvllw our.bowl now.bowl key `record.p.reserved)]
        receipt-cards
      %vibecoding-local-land-observe
        =/  held  (~(get by local-lands) key)
        ?~  held  `this
        =/  observed  (observe:cvllr our.bowl src.bowl now.bowl u.held)
        ?~  observed  `this
        =/  next=record:cvll  (observe:cvll u.held u.observed)
        ?>  (record-valid:cvll next)
        :_  this(state state(local-lands (~(put by local-lands) key next)))
        :~  [%pass /local-land-evidence %agent [our.bowl %graf] %poke %graf-action !>([%attest (fact:cvll next)])]
            (card-for:cvllw our.bowl now.bowl key `next)
        ==
    ==
  ?:  =(%cantrip-mp-receipt mark)
    =/  decoded=(unit mp-receipt:ct)
      ((soft mp-receipt:ct) q.vase)
    ?~  decoded  `this
    =/  ack=mp-receipt:ct  u.decoded
    =/  before=(unit mp-outbox-entry:ct)
      (~(get by mp-outbox) move-id.ack)
    ?~  before  `this
    =/  changed=(unit mp-outbox-change)
      (transition-mp-outbox src.bowl mp-outbox ack)
    ?~  changed  `this
    ?:  =(status.u.before status.entry.u.changed)
      `this
    =.  state  state(mp-outbox next.u.changed)
    [(mp-outbox-evidence-cards bowl entry.u.changed) this]
  ?.  ?=(%cantrip-action mark)  (on-poke:def mark vase)
  =/  lease-act=(unit lease-action)
    ((soft lease-action) q.vase)
  ?^  lease-act
    ?.  =(our.bowl src.bowl)
      `this
    =/  moved=transition:cls
      ?-  -.u.lease-act
        %mirror-moon-lease
          %:  mirror:cle
            leases
            id.u.lease-act
            holder.u.lease-act
            expires.u.lease-act
            now.bowl
          ==
        %release-lease
          (release:cle leases id.u.lease-act now.bowl)
      ==
    ?.  allowed.verdict.moved
      `this
    `this(state state(leases next.moved))
  =/  dispatch-act=(unit vibecoding-dispatch-action:ca)
    ((soft vibecoding-dispatch-action:ca) q.vase)
  ?^  dispatch-act
    =/  request=request:vdr  request.u.dispatch-act
    =/  law=law-binding:vp
      (law-binding-for:cvp 1 (law-window-for residue streak))
    =/  decision=decision:vd
      %-  read:cvdr
      :*  our.bowl  now.bowl  src.bowl  proposal-digest.request
          seat.request  sequence.request  leases  law
      ==
    =/  receipt=receipt:vdr
      (receipt-for:vdrl request src.bowl decision now.bowl)
    =/  recorded=(unit transition:vdr)
      (record:vdrl dispatches receipt)
    ?~  recorded  `this
    `this(state state(dispatches next.u.recorded))
  =/  juggler-act=(unit juggler-admission-action)
    ((soft juggler-admission-action) q.vase)
  ?^  juggler-act
    ?.  =(our.bowl src.bowl)
      ~&  >>>  [%cantrip %juggler-admission-rejected-src src.bowl]
      `this
    =/  verdict=admission:jm
      (juggler-match-admission-for:ca request.u.juggler-act)
    [~[(juggler-verdict-card verdict)] this]
  =/  boxy-act=(unit boxy-admission-action)
    ((soft boxy-admission-action) q.vase)
  ?^  boxy-act
    ::  Admission is stricter than ordinary record ingestion: only the resident
    ::  principal Boxy can ask Cantrip to judge its authoritative state.
    ?.  =(our.bowl src.bowl)
      ~&  >>>  [%cantrip %boxy-admission-rejected-src src.bowl]
      `this
    ?:  ?=([%admit-boxy-motion-approved *] u.boxy-act)
      ::  THE CONSENT SETTLEMENT (ladder 9): Hand's principal-only approval
      ::  lane is the sole sender.  The request is re-validated against
      ::  Boxy's live authoritative workspace, the consumed refused receipt
      ::  is released, and the principal-approved verdict is recorded in the
      ::  same event.  Fail-loud on any refusal so the consenting Hand's
      ::  ack is truthful: ack means recorded, nack retains the consent.
      =/  request=boxy-motion-admission-request:ca  request.u.boxy-act
      =/  authority=state:bx
        (need (boxy-authority-for our.bowl now.bowl))
      ?>  =('boxy-constitutional-state-v3' version.authority)
      =/  workspace=workspace-state:bx
        (~(got by workspaces.authority) workspace.binding.request)
      ?>  (request-valid:bca workspace request)
      =/  verdict=boxy-motion-admission-verdict:ca
        (expected-verdict-approved:cbal request)
      =/  key=@ux  (request-key-for:bca request)
      =/  next=ledger:cbal
        (need (record:cbal (retire:cbal admissions key) request verdict))
      =.  state  state(admissions next)
      [~[(boxy-verdict-card key verdict)] this]
    ?:  ?=([%retire-boxy-verdict *] u.boxy-act)
      ::  The retirement law: the resident principal releases a consumed
      ::  receipt; deletion is idempotent and capacity returns to the
      ::  bounded ledger.
      `this(state state(admissions (retire:cbal admissions key.u.boxy-act)))
    =/  request=boxy-motion-admission-request:ca  request.u.boxy-act
    =/  authority=(unit state:bx)
      (boxy-authority-for our.bowl now.bowl)
    ?~  authority
      ~&  >>>  [%cantrip %boxy-authority-unavailable]
      `this
    ?.  =('boxy-constitutional-state-v3' version.u.authority)
      ~&  >>>  [%cantrip %boxy-authority-version-refused version.u.authority]
      `this
    =/  workspace=(unit workspace-state:bx)
      (~(get by workspaces.u.authority) workspace.binding.request)
    ?~  workspace
      ~&  >>>  [%cantrip %boxy-workspace-not-found workspace.binding.request]
      `this
    ?.  (request-valid:bca u.workspace request)
      ~&  >>>  [%cantrip %boxy-request-invalid (request-key-for:bca request)]
      `this
    =/  verdict=boxy-motion-admission-verdict:ca
      (verdict-for:bca u.workspace request)
    =/  next=(unit ledger:cbal)
      (record:cbal admissions request verdict)
    ?~  next
      ~&  >>>  [%cantrip %boxy-verdict-ledger-refused (request-key-for:bca request)]
      `this
    =.  state  state(admissions u.next)
    [~[(boxy-verdict-card (request-key-for:bca request) verdict)] this]
  =/  mp-act=(unit multiplayer-action)
    ((soft multiplayer-action) q.vase)
  =/  apply-mp-transition
    |=  [move-id=@t to=mp-inbox-status:ct reason=(unit @t)]
    ^-  (quip card _this)
    =/  changed=(unit mp-change)
      (transition-mp our.bowl src.bowl mp-inbox move-id to reason)
    ?~  changed
      `this
    =.  state  state(mp-inbox next.u.changed)
    [(mp-evidence-cards bowl entry.u.changed) this]
  ?^  mp-act
    ?-  -.u.mp-act
      %mp-allow
        ?.  (mp-allowed (administer-allowlist:cml our.bowl src.bowl))
          `this
        `this(state state(mp-allow (~(put in mp-allow) ship.u.mp-act)))
      %mp-deny
        ?.  (mp-allowed (administer-allowlist:cml our.bowl src.bowl))
          `this
        `this(state state(mp-allow (~(del in mp-allow) ship.u.mp-act)))
      %set-star-governor
        ?.  =(our.bowl src.bowl)
          `this
        `this(state state(governor-star `star.u.mp-act, governor-cache ~))
      %receive-star-govern
        ?~  governor-star
          `this
        ?.  =(src.bowl u.governor-star)
          `this
        =/  record=governor-record:csgl  record.u.mp-act
        ?.  ?&  =(source.record src.bowl)
                (lte observed-at.record now.bowl)
                (lth now.bowl expires-at.record)
            ==
          `this
        =/  cached=governor-cache-entry  [src.bowl record now.bowl]
        `this(state state(governor-cache `cached))
      %push-star-govern
        ?.  =(our.bowl src.bowl)
          `this
        =/  current=governor-read:csgl
          .^  governor-read:csgl  %gx
              /(scot %p our.bowl)/graf/(scot %da now.bowl)/star-govern/latest/noun
          ==
        ?.  ?=([%signal *] current)
          `this
        =/  outbound=multiplayer-action
          [%receive-star-govern record.current]
        :_  this
        ~[[%pass /star-govern-push %agent [target.u.mp-act %cantrip] %poke %cantrip-action !>(outbound)]]
      %receive-mp-move
        =/  move=mp-move:ct  move.u.mp-act
        =/  existing=(unit mp-inbox-entry:ct)
          (~(get by mp-inbox) move-id.move)
        =/  verdict=verdict:cm
          %-  receive:cml
          :*  our.bowl
              src.bowl
              (~(has in mp-allow) src.bowl)
              ?=(^ existing)
              (gth (met 3 (jam move)) max-mp-move-bytes)
              (gte (mp-source-active-count mp-inbox src.bowl) max-mp-source-active)
              (gte ~(wyt by mp-inbox) max-mp-inbox)
              move
          ==
        ?.  ?=(%& -.verdict)
          ?:  ?&  =(%duplicate-move-id p.verdict)
                  ?=(^ existing)
                  =(src.bowl source-ship.u.existing)
                  =(move move.u.existing)
              ==
            :_  this
            ~[(mp-receipt-card bowl src.bowl move-id.move status.u.existing refuse-reason.u.existing)]
          =/  reason=@t  (scot %tas p.verdict)
          :_  this
          ~[(mp-receipt-card bowl src.bowl move-id.move %refused `reason)]
        ::  DRIFT AS LAW (S101).  A member whose desk hash is not canon --
        ::  as the star's net computes from the member's own heartbeats, and
        ::  only while the operator has enforcement on -- is refused with a
        ::  reason it can act on.  Guarded: no net, no drift.
        =/  drifted=?
          ?.  .^(? %gu /(scot %p our.bowl)/net/(scot %da now.bowl)/$)  %.n
          .^(? %gx /(scot %p our.bowl)/net/(scot %da now.bowl)/drifted/(scot %p src.bowl)/noun)
        ?:  drifted
          :_  this
          ~[(mp-receipt-card bowl src.bowl move-id.move %refused `'desk-drift: your desk is not canon; pull from the star and retry')]
        =/  entry=mp-inbox-entry:ct
          [move src.bowl now.bowl %pending ~]
        =.  state  state(mp-inbox (~(put by mp-inbox) move-id.move entry))
        [(mp-evidence-cards bowl entry) this]
      %accept-mp-move
        (apply-mp-transition move-id.u.mp-act %accepted ~)
      %refuse-mp-move
        (apply-mp-transition move-id.u.mp-act %refused `reason.u.mp-act)
      %hold-mp-move
        (apply-mp-transition move-id.u.mp-act %held ~)
      %complete-mp-move
        (apply-mp-transition move-id.u.mp-act %completed ~)
      %abandon-mp-move
        (apply-mp-transition move-id.u.mp-act %abandoned `reason.u.mp-act)
      %send-mp-move
        ?.  (mp-allowed (send:cml our.bowl src.bowl))
          `this
        =/  move=mp-move:ct  (attach-guidance bowl move.u.mp-act)
        ?:  (~(has by mp-outbox) move-id.move)
          `this
        ?:  (gte ~(wyt by mp-outbox) max-mp-outbox)
          `this
        ::  A %familiar-submit is a REPORT, not a dispatch: it says work already
        ::  finished and already passed verification.  Classifying it as
        ::  %new-dispatch made the clamp close the one channel that could end
        ::  the condition the clamp was reacting to (S78).  The kind is read
        ::  from the payload head, which +receive already requires to match
        ::  kind.move, so it cannot be spoofed independently of the move itself.
        =/  admission=admission-kind:csgl
          ?:(?=(%familiar-submit -.payload.move) %report %new-dispatch)
        =/  governed=decision:csgl
          (mp-governance-decision bowl admission mp-outbox governor-star governor-cache `target.u.mp-act)
        ?.  ?=([%admit *] governed)
          =/  why=@t  (scot %tas reason.governed)
          =/  refused=mp-outbox-entry:ct
            [move target.u.mp-act %refused now.bowl `why ~ 0]
          :_  this(state state(mp-outbox (~(put by mp-outbox) move-id.move refused)))
          (mp-outbox-evidence-cards bowl refused)
        =/  entry=mp-outbox-entry:ct
          [move target.u.mp-act %sent now.bowl ~ `0 0]
        =/  outbound=multiplayer-action  [%receive-mp-move move]
        =/  pass=card
          [%pass /mp-out %agent [target.u.mp-act %cantrip] %poke %cantrip-action !>(outbound)]
        =/  cards=(list card)
          %+  weld  (mp-outbox-evidence-cards bowl entry)
          ~[pass (mp-retry-wake-card bowl move-id.move 0 0 (retry-delay:cmr 0))]
        :_  this(state state(mp-outbox (~(put by mp-outbox) move-id.move entry)))
        cards
      %retry-mp-move
        =/  found=(unit mp-outbox-entry:ct)
          (~(get by mp-outbox) move-id.u.mp-act)
        ?~  found  `this
        ?.  (mp-allowed (retry:cml [our.bowl src.bowl found]))
          `this
        =/  entry=mp-outbox-entry:ct  u.found
        =/  governed=decision:csgl
          (mp-governance-decision bowl %retry mp-outbox governor-star governor-cache `target-ship.entry)
        ?.  ?=([%admit *] governed)
          =/  why=@t  (scot %tas reason.governed)
          =/  refused=mp-outbox-entry:ct
            entry(status %refused, status-at now.bowl, reason `why, retry-attempt ~)
          :_  this(state state(mp-outbox (~(put by mp-outbox) move-id.u.mp-act refused)))
          (weld (mp-outbox-evidence-cards bowl refused) (mp-outbox-control-cards bowl %govern-refused refused))
        =/  outbound=multiplayer-action  [%receive-mp-move move.entry]
        =/  pass=card
          [%pass /mp-retry %agent [target-ship.entry %cantrip] %poke %cantrip-action !>(outbound)]
        :_  this
        (weld (mp-outbox-control-cards bowl %retry entry) ~[pass])
      %retire-mp-move
        =/  found=(unit mp-outbox-entry:ct)
          (~(get by mp-outbox) move-id.u.mp-act)
        ?~  found  `this
        ?.  (mp-allowed (retire:cml [our.bowl src.bowl found]))
          `this
        =/  entry=mp-outbox-entry:ct  u.found
        :_  this(state state(mp-outbox (~(del by mp-outbox) move-id.u.mp-act)))
        (mp-outbox-control-cards bowl %retired entry)
      %close-mp-outbox
        ?.  =(our.bowl src.bowl)
          `this
        ?:  =(0 (met 3 reason.u.mp-act))
          `this
        =/  found=(unit mp-outbox-entry:ct)
          (~(get by mp-outbox) move-id.u.mp-act)
        ?~  found  `this
        ?.  (active:cmr status.u.found)  `this
        =/  entry=mp-outbox-entry:ct
          %=  u.found
            status         %abandoned
            status-at      now.bowl
            reason         `reason.u.mp-act
            retry-attempt  ~
          ==
        :_  this(state state(mp-outbox (~(put by mp-outbox) move-id.u.mp-act entry)))
        (weld (mp-outbox-evidence-cards bowl entry) (mp-outbox-control-cards bowl %closed entry))
      %override-star-govern
        ?.  =(our.bowl src.bowl)
          `this
        ?:  =(0 (met 3 reason.u.mp-act))
          `this
        =/  current=governor-read:csgl
          .^  governor-read:csgl  %gx
              /(scot %p our.bowl)/graf/(scot %da now.bowl)/star-govern/latest/noun
          ==
        ?.  ?=([%signal *] current)
          `this
        ?.  =(verdict-id.u.mp-act verdict-id.record.current)
          `this
        =/  fact=override-fact:csgl
          :*  %star-govern-override-v1
              override-id=(scot %uv (mug [our.bowl verdict-id.u.mp-act reason.u.mp-act now.bowl]))
              verdict-id=verdict-id.u.mp-act
              actor=our.bowl
              reason=(override-reason bowl reason.u.mp-act)
              recorded-at=now.bowl
          ==
        :_  this
        ~[[%pass /star-govern-override %agent [our.bowl %graf] %poke %noun !>([%record-star-govern-override fact])]]
    ==
  ::  THE SHIP-GATE (hostile-review D1-D4; NARROWED by operator ruling
  ::  2026-08-14).  Only THIS SHIP may move the law that governs it.
  ::  Cross-fleet signal arrives as graf ATTESTATION -- never by writing
  ::  cantrip's local state.  Without this, any ship could steer the window
  ::  that gates every irreversible act.
  ::
  ::  The gate used to admit our own moons as well, deliberately.  The
  ::  consolidation changed what that window steers: it now sets Ring's grant
  ::  set and Hand's host-effect ceiling, not just repair's grants.  The
  ::  operator ruled that moons do not move law, so the `sein` clause is gone.
  ::  This is the shallower half of the ruling -- the load-bearing half is the
  ::  law-record gate in graf-core-engine, because the window is rebuilt from
  ::  Graf's facts and a stored fact carries no author.  A moon that cannot
  ::  land a law RECORD cannot move the window no matter who pokes here.
  ?.  =(our.bowl src.bowl)
    ~&  >>>  [%cantrip %rejected-src src.bowl]
    `this
  =/  decoded=(unit record-action)
    ((soft record-action) q.vase)
  ?~  decoded
    ~&  >>>  [%cantrip %unsupported-action]
    `this
  =/  act=record-action  u.decoded
  =/  rec=record:crc  [kind.act id.act body.act]
  ::  an unknown kind is REFUSED, not silently absorbed: a law that
  ::  accepts anything records nothing.
  ?.  (valid:crc rec)
    ~&  >>>  [%cantrip %unknown-record-kind kind.act]
    `this
  ::  Recompute from Graf rather than incrementing local state.  This makes
  ::  replay order independent of poke interleaving and exact duplicates inert.
  =/  rebuilt=(unit cache:crc)
    (rebuild-from-graf our.bowl now.bowl)
  ?~  rebuilt
    ~&  >>>  [%cantrip %graf-record-history-unavailable id.act]
    `this
  =/  old-window  (ship-window our.bowl now.bowl residue streak)
  =/  admitted=?  (cited:crc u.rebuilt rec)
  =.  state  state(cache u.rebuilt)
  ::  PUSH, don't poll: when the window MOVES, say so in the same event
  ::  chain.  The repair-governor pattern -- consumers track the law
  ::  instantly, and a dropped subscription self-heals by scry.
  =/  new-window  (ship-window our.bowl now.bowl residue streak)
  =/  cards=(list card)
    %+  weld  (permission-cards coding-tools coding-candidates)
    ^-  (list card)
    ?:  =(old-window new-window)  ~
    ~[[%give %fact ~[/law/window] %noun !>(new-window)]]
  ?.  admitted
    ~&  >>>  [%cantrip %uncited-or-conflicting-record id.act]
    [cards this]
  [cards this]
++  on-watch
  |=  =path
  ^-  (quip card _this)
  ::  %siev's lineage verdict path: the verdict comes from the admit poke
  ?:  ?=([%siev %lineage %verdict @ ~] path)
    ?>  =(our.bowl src.bowl)
    `this
  ?:  ?=([%siev %anchor %verdict @ ~] path)
    ?>  =(our.bowl src.bowl)
    `this
  ::  Optional law watches refuse safely on older agents; no discovery scry.
  ?:  =(/law/readymade/capabilities path)
    ?>  =(our.bowl src.bowl)
    [~[[%give %fact ~ %noun !>([%cantrip-readymade-pact-capabilities-v1 our.bowl %readymade-pact-law-v1])]] this]
  ?:  ?=([%law %readymade %pact @ ~] path)
    ?>  =(our.bowl src.bowl)
    =/  id=(unit @ux)  (slaw %ux i.t.t.t.path)
    ?>  ?=(^ id)
    ?>  =(i.t.t.t.path (scot %ux u.id))
    =/  observed
      (observe:readymade-pact-read our.bowl src.bowl now.bowl u.id (ship-window our.bowl now.bowl residue streak))
    [~[[%give %fact ~ %noun !>(observed)]] this]
  ?:  ?=([%law %readymade %artifact *] path)
    ?>  =(our.bowl src.bowl)
    =/  key  (artifact-key:readymade-pact-read path)
    ?>  ?=(^ key)
    =/  observed
      (observe-artifact:readymade-pact-read our.bowl src.bowl now.bowl id.u.key generation.u.key purpose.u.key selected.u.key (ship-window our.bowl now.bowl residue streak))
    [~[[%give %fact ~ %noun !>(observed)]] this]
  ?:  =(/readymade/permissions path)
    ?>  =(our.bowl src.bowl)
    [(weld ~[[%give %fact ~ %noun !>(permission-snapshot)]] permission-connect) this]
  ?:  ?=([%native-coding %completion-review-admission @ @ ~] path)
    ?>  =(our.bowl src.bowl)
    =/  campaign  (landing-key i.t.t.path)
    =/  request  (landing-key i.t.t.t.path)
    ?>  &(?=(^ campaign) ?=(^ request))
    =/  verdict  (lookup:completion-review coding-completion-reviews [u.campaign u.request])
    [~[[%give %fact ~ %noun !>(verdict)]] this]
  ?:  ?=([%native-coding %review-admission @ @ ~] path)
    ?>  =(our.bowl src.bowl)
    =/  campaign  (landing-key i.t.t.path)
    =/  request  (landing-key i.t.t.t.path)
    ?>  &(?=(^ campaign) ?=(^ request))
    =/  verdict  (lookup:native-review coding-reviews [u.campaign u.request])
    [~[[%give %fact ~ %noun !>(verdict)]] this]
  ?:  ?=([%project-receipt *] path)
    =/  watched  (watch:project-receipt bowl project-grants project-records path (law-window-for residue streak))
    ?:  ?=(%| -.watched)  ~|([%project-receipt-watch-refused p.watched] !!)
    [p.watched this]
  ?:  ?=([%project-view *] path)
    =/  watched  (watch-view:project-access bowl project-grants path (law-window-for residue streak))
    ?:  ?=(%| -.watched)  ~|([%project-view-watch-refused p.watched] !!)
    [p.watched this]
  ?:  ?=([%project-session *] path)
    =/  watched  (watch:project-session bowl project-grants grants.coding-tools path (law-window-for residue streak))
    ?:  ?=(%| -.watched)  ~|([%project-session-watch-refused p.watched] !!)
    [p.watched this]
  ?:  ?=([%project-sessions *] path)
    =/  watched  (watch:project-sessions bowl grants.coding-tools path (law-window-for residue streak))
    ?:  ?=(%| -.watched)  ~|([%project-sessions-watch-refused p.watched] !!)
    [p.watched this]
  ?:  ?=([%project-access *] path)
    =/  watched  (watch:project-access bowl project-grants path (law-window-for residue streak))
    ?:  ?=(%| -.watched)  ~|([%project-access-watch-refused p.watched] !!)
    [p.watched this]
  ?+  path  (on-watch:def path)
    [%project-save @ ~]
      ?>  =(our.bowl src.bowl)
      =/  key  (key-for:project-save path)
      ?>  ?=(^ key)
      =/  value=status:project-save
        [%cantrip-project-save-status-v1 u.key (~(get by project-saves) u.key)]
      [~[[%give %fact ~ %noun !>(value)]] this]
    [%vibecoding %connected-land-v2 @ ~]
      ?>  =(our.bowl src.bowl)
      =/  key  (landing-key i.t.t.path)
      ?>  ?=(^ key)
      [~[[%give %fact ~ %noun !>(`landing-status`[%cantrip-connected-land-status-v2 u.key (~(get by landings) u.key)])]] this]
    [%vibecoding %connected-checks-v2 @ ~]
      ?>  =(our.bowl src.bowl)
      =/  key  (checks-key i.t.t.path)
      ?>  ?=(^ key)
      [~[[%give %fact ~ %noun !>(`checks-status`[%cantrip-connected-checks-status-v2 u.key (~(get by checked-runs) u.key)])]] this]
    [%vibecoding %connected-compile-v2 @ ~]
      ?.  =(our.bowl src.bowl)  (on-watch:def path)
      =/  key  (key-for-v2:compile-ledger [%connected-compile-v2 i.t.t.path ~])
      ?~  key  (on-watch:def path)
      =/  observed  (observe-v2:compile-runtime our.bowl src.bowl compilations-v2 u.key)
      ?>  ?=(%& -.observed)
      [~[[%give %fact ~ %noun !>(p.observed)]] this]
    [%vibecoding %connected-compile @ ~]
      ?.  =(our.bowl src.bowl)  (on-watch:def path)
      =/  key  (key-for:compile-ledger [%connected-compile i.t.t.path ~])
      ?~  key  (on-watch:def path)
      [~[[%give %fact ~ %noun !>((read:compile-ledger compilations u.key))]] this]
    [%vibecoding %local-land @ ~]
      ?.  =(our.bowl src.bowl)  (on-watch:def path)
      =/  key  (key-for:cvllw path)
      ?~  key  (on-watch:def path)
      ::  This versioned current-state fact also identifies protocol support.
      ::  No application, source read, or reconciliation runs on subscription.
      [~[(card-for:cvllw our.bowl now.bowl u.key (~(get by local-lands) u.key))] this]
    ::  Multiplayer facts can contain task and review payloads, so this is a
    ::  local event stream, not a remote read surface.  There is deliberately
    ::  no replay here: consumers reconcile durable relations from graf after
    ::  subscribing, which also repairs a fact missed across reload.
    [%multiplayer ~]
      ?.  =(our.bowl src.bowl)  (on-watch:def path)
      [~ this]
    ::  a subscriber gets the CURRENT window immediately, so it is
    ::  never briefly governed by a law it has not seen.
    [%law %window ~]
      :_  this
      (weld ~[[%give %fact ~ %noun !>((ship-window our.bowl now.bowl residue streak))]] permission-connect)
    [%juggler-match %verdict @ ~]
      ?.  =(our.bowl src.bowl)  (on-watch:def path)
      [~ this]
    [%boxy %motion %verdict @ ~]
      ?.  =(our.bowl src.bowl)  (on-watch:def path)
      =/  key=(unit @ux)  (slaw %ux i.t.t.t.path)
      ?~  key  (on-watch:def path)
      =/  result=watch-result:cbal  (watch-for:cbal admissions u.key)
      ?-  -.result
        ::  Accept the subscription before a verdict exists.  If the poke wins
        ::  the race instead, the later watch takes the %ready branch below.
        %pending  [~ this]
        %ready    [~[(boxy-verdict-card u.key verdict.result)] this]
      ==
  ==
++  on-peek
  |=  =path
  ^-  (unit (unit cage))
  ?:  =(/x/readymade/permissions path)
    ?.  =(our.bowl src.bowl)  ~
    ``noun+!>(permission-snapshot)
  ::  READYMADE PACT READ-THROUGH: no mirrored grants or execution authority.
  ?:  ?=([%x %law %readymade %pact *] path)
    ?.  =(our.bowl src.bowl)  ~
    ?+  path  [~ ~]
      [%x %law %readymade %pact @ ~]
        =/  id=(unit @ux)  (slaw %ux i.t.t.t.t.path)
        ?~  id  [~ ~]
        ?.  =(i.t.t.t.t.path (scot %ux u.id))  [~ ~]
        ``noun+!>((observe:readymade-pact-read our.bowl src.bowl now.bowl u.id (ship-window our.bowl now.bowl residue streak)))
      [%x %law %readymade %pact @ ?(%land %publish) @ ~]
        =/  id=(unit @ux)  (slaw %ux i.t.t.t.t.path)
        =/  artifact=(unit @ux)  (slaw %ux i.t.t.t.t.t.t.path)
        ?~  id  [~ ~]
        ?~  artifact  [~ ~]
        ?.  &(=(i.t.t.t.t.path (scot %ux u.id)) =(i.t.t.t.t.t.t.path (scot %ux u.artifact)))  [~ ~]
        ``noun+!>((judge:readymade-pact-read our.bowl src.bowl now.bowl u.id i.t.t.t.t.t.path u.artifact (ship-window our.bowl now.bowl residue streak)))
    ==
  ?:  ?=([%x %law %readymade %artifact *] path)
    ?.  =(our.bowl src.bowl)  ~
    =/  key  (artifact-key:readymade-pact-read t.path)
    ?~  key  [~ ~]
    ``noun+!>((observe-artifact:readymade-pact-read our.bowl src.bowl now.bowl id.u.key generation.u.key purpose.u.key selected.u.key (ship-window our.bowl now.bowl residue streak)))
  ?:  ?=([%x %act-lane ~] path)  ``noun+!>(act-lane)
  ?:  ?=([%x %native-coding *] path)
    ?.  =(our.bowl src.bowl)  ~
    ?+  path  [~ ~]
      [%x %native-coding %used-sessions ~]
        ::  Revocation does not make an old session identity reusable.
        =/  granted=(list @ux)
          (turn ~(val by grants.coding-tools) |=(g=scope:native-tools session.grant.g))
        =/  requested=(list @ux)
          (turn ~(val by records.coding-tools) |=(r=record:native-tools session.context.request.r))
        ``noun+!>((silt (weld granted requested)))
      [%x %native-coding %reserved-desks ~]
        ::  Derive reservations from every retained phase, including unknown
        ::  writes and revoked scopes. No historical namespace is released here.
        =/  tool-scopes=(list (list @tas))
          %+  turn  ~(val by grants.coding-tools)
          |=  g=scope:native-tools
          ~[working.project.grant.g base-desk.spec.project.grant.g]
        =/  tool-jobs=(list @tas)
          (turn ~(val by records.coding-tools) |=(r=record:native-tools desk.source.context.request.r))
        =/  candidates=(list (list @tas))
          %+  turn  ~(val by coding-candidates)
          |=  r=record:native-accept
          ^-  (list @tas)
          :*  (staging-desk:native-accept id.candidate.r)
              working.project.r  base-desk.spec.project.r
              desk.source.context.candidate.r  desk.accepted.candidate.r
              desk.revision.basis.candidate.r
              (weld ?~(staging.r ~ ~[desk.revision.u.staging.r]) ?~(landed.r ~ ~[desk.revision.u.landed.r]))
          ==
        =/  deploy-scopes=(list (list @tas))
          %+  turn  ~(val by grants.coding-deployment)
          |=  g=scope:native-deploy
          ~[working.project.grant.g base-desk.spec.project.grant.g]
        =/  deployments=(list (list @tas))
          %+  turn  ~(val by records.coding-deployment)
          |=  r=record:native-deploy
          ^-  (list @tas)
          :*  (desk-for:native-deploy id.request.r)
              working.project.grant.r  base-desk.spec.project.grant.r
              (weld ?~(runtime.r ~ ~[desk.revision.u.runtime.r]) ?~(previous.r ~ ~[desk.revision.source.u.previous.r]))
          ==
        =/  cache-config=(list @tas)
          ?~  config.coding-store  ~
          ~[desk.origin.u.config.coding-store desk.current.u.config.coding-store]
        =/  cache-records=(list (list @tas))
          %+  turn  ~(val by records.coding-store)
          |=  e=entry:compiler-store
          ^-  (list @tas)
          [desk.revision.before.e ?~(saved.e ~ ~[desk.u.saved.e])]
        =/  attachment-records=(list (list @tas))
          %+  turn  ~(val by records.attachment-archive)
          |=  e=entry:attachment-store
          ^-  (list @tas)
          [desk.before.e ?~(saved.e ~ ~[desk.u.saved.e])]
        =/  desks=(set @tas)
          (silt `(list @tas)`(zing `(list (list @tas))`~[(zing tool-scopes) tool-jobs (zing candidates) (zing deploy-scopes) (zing deployments) cache-config (zing cache-records) (zing attachment-records)]))
        ``noun+!>(desks)
      [%x %native-coding %completion-review-admissions ~]
        ``noun+!>(coding-completion-reviews)
      [%x %native-coding %completion-review-admission @ @ ~]
        =/  campaign  (landing-key i.t.t.t.path)
        =/  request  (landing-key i.t.t.t.t.path)
        ?~  campaign  [~ ~]
        ?~  request  [~ ~]
        ``noun+!>((lookup:completion-review coding-completion-reviews [u.campaign u.request]))
      [%x %native-coding %review-proofs ~]
        ``noun+!>(coding-review-proofs)
      [%x %native-coding %review-proof @ ~]
        =/  id  (landing-key i.t.t.t.path)
        ?~  id  [~ ~]
        ``noun+!>((~(get by coding-review-proofs) u.id))
      [%x %native-coding %review-admission @ @ ~]
        =/  campaign  (landing-key i.t.t.t.path)
        =/  request  (landing-key i.t.t.t.t.path)
        ?~  campaign  [~ ~]
        ?~  request  [~ ~]
        ``noun+!>((lookup:native-review coding-reviews [u.campaign u.request]))
      [%x %native-coding %compiler ~]
        ``noun+!>(bundle.coding-compiler)
      [%x %native-coding %tool-state ~]
        ``noun+!>(coding-tools)
      [%x %native-coding %compiler-prefix ~]
        ``noun+!>(compiler-prefixes)
      [%x %native-coding %compiler-prefix-choices ~]
        ``noun+!>(choices.compiler-prefixes)
      [%x %native-coding %compiler-prefix-program @ ~]
        =/  id  (landing-key i.t.t.t.path)
        ?~  id  [~ ~]
        ``noun+!>((~(get by programs.compiler-prefixes) u.id))
      [%x %native-coding %compiler-prefix-result @ ~]
        =/  id  (landing-key i.t.t.t.path)
        ?~  id  [~ ~]
        ``noun+!>((~(get by results.compiler-prefixes) u.id))
      [%x %native-coding %compiler-prefix-prepared @ ~]
        =/  id  (landing-key i.t.t.t.path)
        ?~  id  [~ ~]
        ``noun+!>((prepare:coding-prefixes our.bowl now.bowl compiler-prefixes coding-tools u.id))
      [%x %native-coding %compiler-derivations ~]
        ``noun+!>(compiler-derivations)
      [%x %native-coding %compiler-derivation @ ~]
        =/  id  (landing-key i.t.t.t.path)
        ?~  id  [~ ~]
        ``noun+!>((~(get by records.compiler-derivations) u.id))
      [%x %native-coding %gls-toolchains ~]
        ``noun+!>(gls-toolchains)
      [%x %native-coding %gls-toolchain @ @ ~]
        =/  configuration  (landing-key i.t.t.t.path)
        ?~  configuration  [~ ~]
        ?.  =((scot %ux u.configuration) i.t.t.t.path)  [~ ~]
        =/  target=@tas  `@tas`i.t.t.t.t.path
        ``noun+!>((lookup:gls-toolchain our.bowl gls-toolchains compiler-attachments [u.configuration target]))
      [%x %native-coding %compiler-attachments ~]
        ``noun+!>(compiler-attachments)
      [%x %native-coding %compiler-attachment-choices ~]
        ``noun+!>(choices.compiler-attachments)
      [%x %native-coding %compiler-attachment @ ~]
        =/  id  (landing-key i.t.t.t.path)
        ?~  id  [~ ~]
        ``noun+!>((~(get by attachments.compiler-attachments) u.id))
      [%x %native-coding %compiler-attachment-result @ ~]
        =/  id  (landing-key i.t.t.t.path)
        ?~  id  [~ ~]
        ``noun+!>((~(get by results.compiler-attachments) u.id))
      [%x %native-coding %compiler-attachment-store ~]
        ``noun+!>(attachment-archive)
      [%x %native-coding %compiler-attachment-archive-status @ ~]
        =/  id  (landing-key i.t.t.t.path)
        ?~  id  [~ ~]
        ``noun+!>((~(get by records.attachment-archive) u.id))
      [%x %native-coding %compiler-attachment-archive @ ~]
        =/  id  (landing-key i.t.t.t.path)
        ?~  id  [~ ~]
        =/  held  (~(get by records.attachment-archive) u.id)
        ?~  held  ``noun+!>(`(each retained:coding-attachments @tas)`[%| %compiler-attachment-archive-missing])
        ``noun+!>((exact:attachment-store our.bowl now.bowl u.held compiler-attachments coding-tools))
      [%x %native-coding %compiler-exports ~]
        ``noun+!>(compiler-exports)
      [%x %native-coding %compiler-export-choices ~]
        ``noun+!>(choices.compiler-exports)
      [%x %native-coding %compiler-export @ ~]
        =/  id  (landing-key i.t.t.t.path)
        ?~  id  [~ ~]
        ``noun+!>((~(get by results.compiler-exports) u.id))
      [%x %native-coding %compiler-exports-store ~]
        ``noun+!>(exports-archive)
      [%x %native-coding %compiler-export-archive-status @ ~]
        =/  id  (landing-key i.t.t.t.path)
        ?~  id  [~ ~]
        ``noun+!>((~(get by records.exports-archive) u.id))
      [%x %native-coding %compiler-export-archive @ ~]
        =/  id  (landing-key i.t.t.t.path)
        ?~  id  [~ ~]
        =/  held  (~(get by records.exports-archive) u.id)
        ?~  held  ``noun+!>(`(each retained:coding-exports @tas)`[%| %compiler-export-archive-missing])
        ``noun+!>((exact:exports-store our.bowl now.bowl u.held coding-tools))
      [%x %native-coding %hoon-artifacts ~]
        ``noun+!>(coding-hoon)
      [%x %native-coding %job-handles ~]
        ``noun+!>([%native-coding-job-handles-v1 (murn ~(tap in ~(key by coding-job-handles)) |=(id=@ux (view:native-job-runner coding-job-handles id)))])
      [%x %native-coding %job-handle @ ~]
        =/  id  (landing-key i.t.t.t.path)
        ?~  id  [~ ~]
        ``noun+!>((view:native-job-runner coding-job-handles u.id))
      [%x %native-coding %hoon-store ~]
        ``noun+!>(hoon-archive)
      [%x %native-coding %hoon-archive-status @ ~]
        =/  id  (landing-key i.t.t.t.path)
        ?~  id  [~ ~]
        ``noun+!>((~(get by records.hoon-archive) u.id))
      [%x %native-coding %hoon-archive @ ~]
        =/  id  (landing-key i.t.t.t.path)
        ?~  id  [~ ~]
        =/  held  (~(get by records.hoon-archive) u.id)
        ?~  held  ``noun+!>(`(each artifact:coding-hoon-runtime @tas)`[%| %hoon-archive-missing])
        ``noun+!>((exact:coding-hoon-store our.bowl now.bowl u.held coding-tools))
      [%x %native-coding %hoon-artifact @ ~]
        =/  id  (landing-key i.t.t.t.path)
        ?~  id  [~ ~]
        ``noun+!>((get:coding-hoon-runtime coding-hoon u.id))
      [%x %native-coding %compiler-assembly ~]
        ``noun+!>(coding-assembly)
      [%x %native-coding %compiler-assembly-result @ ~]
        =/  id  (landing-key i.t.t.t.path)
        ?~  id  [~ ~]
        ``noun+!>((~(get by results.coding-assembly) u.id))
      [%x %native-coding %compiler-mappings ~]
        ``noun+!>(mappings.coding-compiler)
      [%x %native-coding %compiler-mapping @ @ ~]
        =/  configuration  (landing-key i.t.t.t.path)
        ?~  configuration  [~ ~]
        ?.  =((scot %ux u.configuration) i.t.t.t.path)  [~ ~]
        =/  target=@tas  `@tas`i.t.t.t.t.path
        ``noun+!>((mapping:coding-compiler-runtime coding-compiler u.configuration target))
      [%x %native-coding %compiler-store ~]
        ``noun+!>(coding-store)
      [%x %native-coding %compiler-cache @ ~]
        =/  id  (landing-key i.t.t.t.path)
        ?~  id  [~ ~]
        ``noun+!>((lookup:compiler-store bowl coding-store coding-compiler coding-tools u.id))
      [%x %native-coding %compiler-reuse @ ~]
        =/  id  (landing-key i.t.t.t.path)
        ?~  id  [~ ~]
        ``noun+!>((read:coding-reuse our.bowl now.bowl coding-tools compiler-attachments attachment-archive compiler-exports exports-archive seed.coding-assembly u.id))
      [%x %native-coding %compiler-status ~]
        ``noun+!>([%native-coding-compiler-status-v1 ?~(bundle.coding-compiler ~ `digest.u.bundle.coding-compiler) ~(wyt by emissions.coding-compiler)])
      [%x %native-coding %compiler-emission @ ~]
        =/  id  (landing-key i.t.t.t.path)
        ?~  id  [~ ~]
        ``noun+!>((~(get by emissions.coding-compiler) u.id))
      [%x %native-coding %grants ~]  ``noun+!>(grants.coding-tools)
      [%x %native-coding %request-ceilings ~]  ``noun+!>(request-ceilings)
      [%x %native-coding %request-ceiling @ ~]
        =/  id  (landing-key i.t.t.t.path)
        ?~  id  [~ ~]
        ?.  =((scot %ux u.id) i.t.t.t.path)  [~ ~]
        ``noun+!>((~(get by request-ceilings) u.id))
      [%x %native-coding %grant @ ~]
        =/  id  (landing-key i.t.t.t.path)
        ?~  id  [~ ~]
        ``noun+!>((~(get by grants.coding-tools) u.id))
      [%x %native-coding %job @ ~]
        =/  id  (landing-key i.t.t.t.path)
        ?~  id  [~ ~]
        ``noun+!>((~(get by records.coding-tools) u.id))
      [%x %native-coding %candidate-ledger ~]  ``noun+!>(coding-candidates)
      [%x %native-coding %candidate @ ~]
        =/  id  (landing-key i.t.t.t.path)
        ?~  id  [~ ~]
        ``noun+!>((~(get by coding-candidates) u.id))
      [%x %native-coding %deployment-grants ~]
        ``noun+!>(grants.coding-deployment)
      [%x %native-coding %deployment-grant @ ~]
        =/  id  (landing-key i.t.t.t.path)
        ?~  id  [~ ~]
        ``noun+!>((~(get by grants.coding-deployment) u.id))
      [%x %native-coding %deployment @ ~]
        =/  id  (landing-key i.t.t.t.path)
        ?~  id  [~ ~]
        ``noun+!>((~(get by records.coding-deployment) u.id))
      [%x %native-coding %deployments ~]
        =/  rows
          %+  turn  ~(tap by records.coding-deployment)
          |=  [id=@ux r=record:native-deploy]
          [id request.r phase.r reason.r]
        ``noun+!>([%native-coding-deployments-v1 rows])
    ==
  ?:  ?=([%x %project-access *] path)
    ?.  =(our.bowl src.bowl)  ~
    ?+  path  [~ ~]
      [%x %project-access %grants ~]  ``noun+!>(project-grants)
      [%x %project-access %records ~]  ``noun+!>(project-records)
    ==
  ?+    path  (on-peek:def path)
      [%x %vibecoding %connected-land-v2 @ ~]
    ?.  =(our.bowl src.bowl)  ~
    =/  key  (landing-key i.t.t.t.path)
    ?~  key  [~ ~]
    ``noun+!>((~(get by landings) u.key))
      [%x %vibecoding %connected-checks-v2 @ ~]
    ?.  =(our.bowl src.bowl)  ~
    =/  key  (checks-key i.t.t.t.path)
    ?~  key  [~ ~]
    ``noun+!>((~(get by checked-runs) u.key))
      [%x %vibecoding %connected-checks-current-v2 @ ~]
    ?.  =(our.bowl src.bowl)  ~
    =/  key  (checks-key i.t.t.t.path)
    ?~  key  [~ ~]
    =/  run  (~(get by checked-runs) u.key)
    ?~  run  ``noun+!>(`(each observation:checks @tas)`[%| %checks-missing])
    =/  c=command:checks  request.u.run
    =/  own=owned-v2:checks-preview
      [(~(get by compilations-v2) write.c) [(~(get by connected-v2) write.c) (~(get by editor-saves) write.c)]]
    ``noun+!>((observe-owned:checks-read our.bowl src.bowl now.bowl checked-runs c own (law-window-for residue streak)))
      [%x %vibecoding %connected-compile-v2 @ ~]
    ?.  =(our.bowl src.bowl)  ~
    =/  key  (key-for-v2:compile-ledger [%connected-compile-v2 i.t.t.t.path ~])
    ?~  key  [~ ~]
    =/  observed  (observe-v2:compile-runtime our.bowl src.bowl compilations-v2 u.key)
    ?>  ?=(%& -.observed)
    ``noun+!>(entry.p.observed)
      [%x %vibecoding %connected-compile @ ~]
    ?.  =(our.bowl src.bowl)  ~
    =/  key  (key-for:compile-ledger [%connected-compile i.t.t.t.path ~])
    ?~  key  [~ ~]
    ``noun+!>((~(get by compilations) u.key))
      [%x %vibecoding %connected-write-v2 @ ~]
    ?.  =(our.bowl src.bowl)  ~
    =/  key  (key-for-v2:connected-write [%connected-write-v2 i.t.t.t.path ~])
    ?~  key  [~ ~]
    ``noun+!>((~(get by connected-v2) u.key))
      [%x %vibecoding %connected-write @ ~]
    ?.  =(our.bowl src.bowl)  ~
    =/  key  (key-for:connected-write [%connected-write i.t.t.t.path ~])
    ?~  key  [~ ~]
    ``noun+!>((~(get by connected) u.key))
      [%x %editor %save @ ~]
    ?.  =(our.bowl src.bowl)  ~
    =/  key=(unit @ux)  (slaw %ux i.t.t.t.path)
    ?~  key  [~ ~]
    ?.  &(!=(0 u.key) (lte (met 0 u.key) 256) =((scot %ux u.key) i.t.t.t.path))  [~ ~]
    ``noun+!>((~(get by editor-saves) u.key))
      [%x %project-save @ ~]
    ?.  =(our.bowl src.bowl)  ~
    =/  key  (key-for:project-save [%project-save i.t.t.path ~])
    ?~  key  [~ ~]
    ``noun+!>((~(get by project-saves) u.key))
      [%x %project-save %basis @ @ ~]
    ?.  =(our.bowl src.bowl)  ~
    =/  id=@t  i.t.t.t.path
    =/  desk=@tas  i.t.t.t.t.path
    ``noun+!>((read:project-save-read our.bowl src.bowl now.bowl id desk))
  ::
  ::  ---- RING MIGRATION (read-only exact fingerprinted donor export) ----
      [%x %migration %ring ~]
    =/  exact=cantrip-exact:rm  [%2 cache admissions]
    ``noun+!>((export-cantrip:rm exact))
  ::
  ::  ---- THE CANON GATE (graf scries these) ----
  ::  The three arities are graf's, not ours: app/graf builds the
  ::  3-arity path on every %propose-canon.  The 1- and 2-arity forms
  ::  are kept for callers that have no reputation/principal context.
      [%x %law %approve @ ~]
    =/  r=rel:graf-relations  ;;(rel:graf-relations (cue (slav %ud i.t.t.t.path)))
    ``noun+!>(`?`(approves:cantrip-law-engine r))
  ::
      [%x %law %approve @ @ ~]
    =/  r=rel:graf-relations  ;;(rel:graf-relations (cue (slav %ud i.t.t.t.path)))
    =/  reps=@ud  (slav %ud i.t.t.t.t.path)
    ``noun+!>(`?`(approves-attested:cantrip-law-engine r reps))
  ::
  ::  the live gate: reputation binds a NON-PRINCIPAL proposer; the
  ::  ship's own engraving acts are a separate authority channel,
  ::  already src- and window-gated upstream.
      [%x %law %approve @ @ @ ~]
    =/  r=rel:graf-relations  ;;(rel:graf-relations (cue (slav %ud i.t.t.t.path)))
    =/  reps=@ud  (slav %ud i.t.t.t.t.path)
    =/  principal=?  =(0 (slav %f i.t.t.t.t.t.path))
    ``noun+!>(`?`(approves-gated:cantrip-law-engine r reps principal))
  ::
  ::  a gate must explain its refusals (rule 12): the same shapes, but
  ::  returning the REASONS rather than a bare loobean.
      [%x %law %rejections @ ~]
    =/  r=rel:graf-relations  ;;(rel:graf-relations (cue (slav %ud i.t.t.t.path)))
    ``noun+!>((rejections:cantrip-law-engine r))
  ::
      [%x %law %rejections @ @ @ ~]
    =/  r=rel:graf-relations  ;;(rel:graf-relations (cue (slav %ud i.t.t.t.path)))
    =/  reps=@ud  (slav %ud i.t.t.t.t.path)
    =/  principal=?  =(0 (slav %f i.t.t.t.t.t.path))
    ``noun+!>((rejections-gated:cantrip-law-engine r reps principal))
  ::
  ::  ---- THE WINDOW (brains consult before acting) ----
      [%x %law %window %current ~]
    ``noun+!>((ship-window our.bowl now.bowl residue streak))
  ::  ---- THE SEATS (siev, re-pointed: lib/siev-seat) ----
  ::  a seat's own window, its reading, and every seat's reading
      [%x %law %window %seat @ ~]
    ``noun+!>((seat-window our.bowl now.bowl residue streak `@tas`i.t.t.t.t.path))
      [%x %law %seat @ ~]
    ``noun+!>((read:siev-seat our.bowl now.bowl `@tas`i.t.t.t.path))
      [%x %law %seats ~]
    ``noun+!>((read-all:siev-seat our.bowl now.bowl))
      [%x %law %ratification %readiness ~]
    =/  window=window:cantrip-law-window  (law-window-for residue streak)
    ``noun+!>((build:crrl window residue streak))
  ::
  ::  ---- CANONICAL LEASE MIRROR ----
  ::
  ::  BOTH app/viki and app/moon-warden scry this exact path, expecting
  ::  `(unit mirrored-lease)`, and CANTRIP NEVER SERVED IT.  The path fell
  ::  to `?+ path (on-peek:def path)`, which answers ~, which makes the
  ::  caller's `.^` BAIL -- and both callers wrap that in +mule, which
  ::  does not catch a failed scry.  So every mirror readback crashed the
  ::  event, on both agents, whenever cantrip was running.
  ::
  ::  This answers ABSENCE AS A VALUE instead.  +apply-mirror-readback
  ::  already has the branch for it and calls it
  ::  'canonical Cantrip mirror is missing' -- fail-closed, the lease does
  ::  not activate.  Same outcome as the crash, minus the crash, and it
  ::  says why.
  ::
      [%x %lease @ ~]
    ``noun+!>((lookup:cle leases i.t.t.path now.bowl))
      [%x %leases ~]
    ``noun+!>((snapshot:cle leases now.bowl))
  ::
  ::  ---- NATIVE VIBECODING DISPATCH DECISION ----
  ::  The path carries no actor.  Ames src is the actor; the reader joins every
  ::  other fact from its canonical owner and returns not-decided when required
  ::  evidence is absent.  This admits one act and executes nothing.
      [%x %vibecoding %local-land-check @ ~]
    =/  key=(unit @ux)  (slaw %ux i.t.t.t.path)
    ?~  key  [~ ~]
    ?.  =(our.bowl src.bowl)  ``noun+!>(`decision:cvll`[%| %foreign-actor])
    ?:  (~(has by local-lands) u.key)  ``noun+!>(`decision:cvll`[%| %already-submitted])
    ``noun+!>((read:cvllr our.bowl src.bowl now.bowl u.key (law-window-for residue streak)))
      [%x %vibecoding %local-land-record @ ~]
    ?.  =(our.bowl src.bowl)  [~ ~]
    =/  key=(unit @ux)  (slaw %ux i.t.t.t.path)
    ?~  key  [~ ~]
    ``noun+!>((~(get by local-lands) u.key))
      [%x %vibecoding %compile-request @ @ ~]
    =/  write=(unit @ux)  (slaw %ux i.t.t.t.path)
    =/  binding=(unit @ux)  (slaw %ux i.t.t.t.t.path)
    ?~  write  [~ ~]
    ?~  binding  [~ ~]
    ``noun+!>((read:cvcr our.bowl src.bowl now.bowl u.write u.binding (law-window-for residue streak)))
      [%x %vibecoding %compile-dispatch @ ~]
    =/  key=(unit @ux)  (slaw %ux i.t.t.t.path)
    ?~  key  [~ ~]
    ``noun+!>((admit:cvcr our.bowl src.bowl now.bowl u.key (law-window-for residue streak)))
      [%x %vibecoding %local-preview @ @ ~]
    =/  write=(unit @ux)  (slaw %ux i.t.t.t.path)
    =/  image=(unit @ux)  (slaw %ux i.t.t.t.t.path)
    ?~  write  [~ ~]
    ?~  image  [~ ~]
    ``noun+!>((read:cvlpr our.bowl src.bowl now.bowl u.write u.image (law-window-for residue streak)))
      [%x %vibecoding %local-write @ @ ~]
    =/  candidate=(unit @ux)  (slaw %ux i.t.t.t.path)
    =/  review=(unit @ux)  (slaw %ux i.t.t.t.t.path)
    ?~  candidate  [~ ~]
    ?~  review  [~ ~]
    ::  Separate sovereign-local authority; never impersonate a moon seat.
    ``noun+!>((read:cvlr our.bowl src.bowl now.bowl u.candidate u.review (law-window-for residue streak)))
      [%x %vibecoding %dispatch @ @ @ ~]
    =/  digest=(unit @ux)  (slaw %ux i.t.t.t.path)
    ?~  digest  [~ ~]
    =/  seat=(unit seat:ss)  ((soft seat:ss) i.t.t.t.t.path)
    ?~  seat  [~ ~]
    =/  sequence=(unit @ud)  (slaw %ud i.t.t.t.t.t.path)
    ?~  sequence  [~ ~]
    =/  law=law-binding:vp
      (law-binding-for:cvp 1 (law-window-for residue streak))
    =/  decision=decision:vd
      (read:cvdr our.bowl now.bowl src.bowl u.digest u.seat u.sequence leases law)
    ``noun+!>(decision)
      [%x %vibecoding %dispatch-receipt @ ~]
    =/  key=(unit @ux)  (slaw %ux i.t.t.t.path)
    ?~  key  [~ ~]
    ``noun+!>((lookup:vdrl dispatches u.key))
      [%x %vibecoding %dispatch-receipts %count ~]
    ``noun+!>(`@ud`~(wyt by dispatches))
  ::
      [%x %law %residue ~]   ``noun+!>(residue)
      [%x %law %streak ~]    ``noun+!>(streak)
      [%x %law %health ~]    ``noun+!>(health)
      [%x %law %ceiling ~]   ``noun+!>((ceiling-for health))
  ::
  ::  Hand's runtime host-effect admission.  The legacy four-segment form is
  ::  deliberately unapproved; only Hand's principal-only approval route uses
  ::  the explicit %yes form for a destructive effect.
      [%x %law %admit %host @ ~]
    =/  effect=@tas  i.t.t.t.t.path
    ``noun+!>((host-admit:hand-bind (ceiling-for health) effect %.n))
      [%x %law %admit %host @ %no ~]
    =/  effect=@tas  i.t.t.t.t.path
    ``noun+!>((host-admit:hand-bind (ceiling-for health) effect %.n))
      [%x %law %admit %host @ %yes ~]
    =/  effect=@tas  i.t.t.t.t.path
    ``noun+!>((host-admit:hand-bind (ceiling-for health) effect %.y))
      [%x %law %records ~]
    ``noun+!>([%cantrip-record-cache accepted=`@ud`~(wyt by records.cache) conflicts=~(tap in conflicts.cache)])
  ::
  ::  ---- CANTRIP MULTIPLAYER LAW ----
      [%x %multiplayer %inbox ~]
    ``noun+!>(mp-inbox)
      [%x %multiplayer %allow ~]
    ``noun+!>(mp-allow)
      [%x %multiplayer %count ~]
    ``noun+!>(`@ud`~(wyt by mp-inbox))
      [%x %multiplayer %move @ ~]
    =/  found=(unit mp-inbox-entry:ct)
      (~(get by mp-inbox) i.t.t.t.path)
    ``noun+!>(found)
      [%x %multiplayer %outbox ~]
    ``noun+!>(mp-outbox)
      [%x %multiplayer %outbox %count ~]
    ``noun+!>(`@ud`~(wyt by mp-outbox))
      [%x %multiplayer %outbox @ ~]
    =/  found=(unit mp-outbox-entry:ct)
      (~(get by mp-outbox) i.t.t.t.path)
    ``noun+!>(found)
      [%x %multiplayer %governor ~]
    ``noun+!>([governor-star governor-cache])
      [%x %multiplayer %status ~]
    =/  status
      :*  %cantrip-multiplayer-status-v1
          allowed=`@ud`~(wyt in mp-allow)
          inbox=`@ud`~(wyt by mp-inbox)
          outbox=`@ud`~(wyt by mp-outbox)
          max-inbox=max-mp-inbox
          max-outbox=max-mp-outbox
          max-move-bytes=max-mp-move-bytes
          max-source-active=max-mp-source-active
          max-retry-attempts=max-attempts:cmr
          authenticated-receipts=%.y
          retry-recovery=%.y
          graf-evidence=%.y
      ==
    ``noun+!>(status)
      [%x %multiplayer %law ~]
    ``noun+!>([%cantrip-multiplayer-law-v4 max-inbox=max-mp-inbox max-outbox=max-mp-outbox max-move-bytes=max-mp-move-bytes max-source-active=max-mp-source-active reload-recovery=%.y stale-wake-rejection=%.y authenticated-receipts=%.y ames-authenticates=%.y viki-leases=%.y graf-evidence=%.y])
      [%x %boxy %motion %verdict @ ~]
    =/  key=(unit @ux)  (slaw %ux i.t.t.t.t.path)
    ?~  key  [~ ~]
    =/  found=(unit admission-record:cbal)  (lookup:cbal admissions u.key)
    ?~  found  [~ ~]
    ``noun+!>(verdict.u.found)
  ::
  ::  what the worker should hold.  One arm, so the moon and the asker
  ::  cannot disagree about what the law currently is.
      [%x %law %held ~]
    ``noun+!>(held-for)
  ::
  ::  the judge explains itself in one read.
      [%x %law %state ~]
    =/  w  (law-window-for residue streak)
    :^  ~  ~  %noun
    !>  :*  %cantrip
            regime=regime.w
            admissible=admissible.w
            never-auto=never-auto.w
            ceiling=(ceiling-for health)
            residue=residue
            streak=streak
            records=`@ud`~(wyt by records.cache)
            conflicts=`@ud`~(wyt in conflicts.cache)
        ==
  ==
++  on-agent
  |=  [=wire =sign:agent:gall]
  ^-  (quip card _this)
  ?:  =(/readymade-permissions-graf wire)
    ?.  =(our.bowl src.bowl)  `this
    ?:  ?=(%kick -.sign)  [permission-connect this]
    ?.  ?=(%fact -.sign)  `this
    ?.  =(%noun p.cage.sign)  `this
    =/  fact  ((soft act-fact:act-law) q.q.cage.sign)
    ?~  fact  `this
    ?.  =(our.bowl who.u.fact)  `this
    ::  The event only invalidates observations. Graf's retained law is read
    ::  again; the publication body never becomes a second law cache.
    :_  this
    %+  weld  (permission-cards coding-tools coding-candidates)
    ^-  (list card)
    ~[[%give %fact ~[/law/window] %noun !>((ship-window our.bowl now.bowl residue streak))]]
  ?:  ?=([%native-job @ @ ~] wire)
    =/  changed
      (on-agent:prefix-runner bowl coding-job-handles coding-tools compiler-prefixes wire sign)
    [(weld cards.changed (permission-cards tools.changed coding-candidates)) this(coding-tools tools.changed, coding-job-handles state.changed, compiler-prefixes prefixes.changed)]
  ?:  =(wire /native-completion-review-evidence)  `this
  ?:  |(=(wire /native-review-evidence) =(wire /native-coding-result) =(wire /native-coding-evidence) =(wire /native-candidate-evidence) =(wire /native-candidate-status) =(wire /native-deployment-evidence) =(wire /native-deployment-status))  `this
  ?+  wire  (on-agent:def wire sign)
    [%connected-compile-v2 @ ~]
      =/  changed
        (event-v2:compile-runtime bowl compilations compilations-v2 connected connected-v2 editor-saves wire sign (law-window-for residue streak))
      [cards.changed this(compilations-v2 next.changed)]
    [%connected-compiler-order-v2 @ ~]
      =/  changed  (poke-ack-v2:compile-runtime bowl compilations compilations-v2 wire sign)
      [cards.changed this(compilations-v2 next.changed)]
    [%connected-compile @ ~]
      =/  changed
        (event-v1-shared:compile-runtime bowl compilations compilations-v2 connected connected-v2 editor-saves wire sign (law-window-for residue streak))
      [cards.changed this(compilations next.changed)]
    [%connected-compiler-order @ ~]
      =/  changed  (poke-ack:compile-runtime bowl compilations wire sign)
      [cards.changed this(compilations next.changed)]
    [%connected-write-v2 @ ~]
      ?.  (ready:native-deploy coding-deployment)  `this
      ?.  (ready:project-save project-saves now.bowl)  `this
      =/  changed
        (event-v2:connected-runtime bowl connected connected-v2 editor-saves wire sign (law-window-for residue streak))
      [cards.changed this(connected-v2 next.changed, state state(editor-saves saves.changed))]
    [%connected-write-request-v2 @ ~]
      `this
    [%connected-write @ ~]
      ?.  (ready:native-deploy coding-deployment)  `this
      ?.  (ready:project-save project-saves now.bowl)  `this
      =/  changed
        (event:connected-runtime bowl connected editor-saves wire sign (law-window-for residue streak))
      ::  The active event, both journals and the existing editor Clay card
      ::  are committed in this one Gall transition. Graf is not the origin.
      [cards.changed this(connected next.changed, state state(editor-saves saves.changed))]
    [%connected-write-request @ ~]
      ::  Poke acknowledgment cannot admit source or establish Viki review.
      `this
    [%local-land-evidence ~]
      ::  Graf acknowledgment does not establish retention; Cantrip's saved
      ::  ledger is the canonical operation state, independently scryable.
      `this
    [%mp-out ~]
      ?+  -.sign  `this
        %poke-ack  `this
      ==
    [%mp-receipt ~]
      ?+  -.sign  `this
        %poke-ack  `this
      ==
  ==
++  on-arvo
  |=  [=wire sign=sign-arvo]
  ^-  (quip card _this)
  ?:  ?=([%native-compiler-attachment-store @ ~] wire)
    ::  Observation can advance the shared cache head while this writer owns it.
    =/  changed
      (arvo:attachment-store bowl attachment-archive coding-store compiler-attachments coding-tools hoon-archive exports-archive wire sign)
    [cards.changed this(attachment-archive state.changed, coding-store cache.changed, compiler-attachments compiled.changed)]
  ?:  ?=([%native-compiler-exports-store @ ~] wire)
    =/  changed
      (arvo:exports-store bowl exports-archive coding-store compiler-exports coding-tools hoon-archive wire sign)
    [cards.changed this(exports-archive state.changed, coding-store cache.changed, compiler-exports compiled.changed)]
  ?:  ?=([%native-hoon-store @ ~] wire)
    ::  A pending write blocks new writers, never its own observation.
    =/  changed
      (arvo:coding-hoon-store bowl hoon-archive coding-store coding-hoon coding-tools wire sign)
    [cards.changed this(hoon-archive state.changed, coding-store cache.changed, coding-hoon artifacts.changed)]
  ?:  ?=([%native-compiler-store @ ~] wire)
    =/  changed  (arvo:compiler-store bowl coding-store wire sign)
    [cards.changed this(coding-store state.changed)]
  ?:  ?=([%native-deployment @ @ ~] wire)
    =/  changed  (arvo:deploy-runtime bowl coding-deployment coding-candidates wire sign (law-window-for residue streak) native-deployment-idle)
    [cards.changed this(coding-deployment next.changed)]
  ?:  ?=([%native-candidate @ @ ~] wire)
    =/  changed  (arvo:gls-toolchain bowl gls-toolchains compiler-attachments coding-tools coding-candidates wire sign (ship-window our.bowl now.bowl residue streak))
    [(weld cards.changed (permission-cards coding-tools candidates.changed)) this(gls-toolchains state.changed, coding-candidates candidates.changed)]
  ?:  ?=([%native-coding @ ~] wire)
    =/  changed  (arvo:native-tools bowl coding-tools wire sign)
    [(weld cards.changed (permission-cards next.changed coding-candidates)) this(coding-tools next.changed)]
  ?:  ?=([%project-save-ready @ ~] wire)
    ?.  =(our.bowl src.bowl)  `this
    =/  key  (key-for:project-save /project-save/[i.t.wire])
    ?~  key  `this
    =/  found  (~(get by project-saves) u.key)
    ?~  found  `this
    ?.  (completion-matches:project-save u.found wire sign)  `this
    (project-save-observe u.key)
  ?:  ?=([%connected-compile-v2 @ ~] wire)
    =/  changed  (wake-v2:compile-runtime bowl compilations compilations-v2 wire sign)
    [cards.changed this(compilations-v2 next.changed)]
  ?:  ?=([%connected-compile @ ~] wire)
    =/  changed  (wake:compile-runtime bowl compilations wire sign)
    [cards.changed this(compilations next.changed)]
  ?:  ?=([%connected-write-v2 @ ~] wire)
    =/  changed  (wake-v2:connected-runtime bowl connected connected-v2 editor-saves wire sign)
    [cards.changed this(connected-v2 next.changed, state state(editor-saves saves.changed))]
  ?:  ?=([%connected-write @ ~] wire)
    =/  changed  (wake:connected-runtime bowl connected editor-saves wire sign)
    [cards.changed this(connected next.changed, state state(editor-saves saves.changed))]
  ::  An effect response alone cannot certify the source; observe reads Clay.
  ?:  ?=([%editor-save @ ~] wire)  `this
  ?:  ?=([%project-save @ ~] wire)  `this
  ?:  ?=([%vibecoding-local-land @ ~] wire)  `this
  ?:  ?=([%connected-land-v2 @ ~] wire)  `this
  =/  ticket=(unit retry-ticket:cmr)
    (parse-retry-wire:cmr wire)
  ?~  ticket
    ?:  ?=([%mp-auto-retry *] wire)  `this
    (on-arvo:def wire sign)
  ?.  ?=([%behn %wake *] sign)  (on-arvo:def wire sign)
  =/  found=(unit mp-outbox-entry:ct)
    (~(get by mp-outbox) move-id.u.ticket)
  ?~  found  `this
  ?.  (mp-allowed (retry:cml [our.bowl our.bowl found]))
    `this
  =/  entry=mp-outbox-entry:ct  u.found
  ?.  =(generation.u.ticket retry-generation.entry)
    `this
  ?~  retry-attempt.entry
    `this
  ?.  =(attempt.u.ticket u.retry-attempt.entry)
    `this
  =/  decision=retry-decision:cmr
    (decide:cmr status.entry attempt.u.ticket)
  ?-  -.decision
    %stop
      ?.  =(%exhausted reason.decision)  `this
      =/  exhausted=mp-outbox-entry:ct  entry(retry-attempt ~)
      :_  this(state state(mp-outbox (~(put by mp-outbox) move-id.u.ticket exhausted)))
      (mp-outbox-control-cards bowl %retry-exhausted exhausted)
    %retry
      =/  advanced=mp-outbox-entry:ct
        entry(retry-attempt `next-attempt.decision)
      =/  outbound=multiplayer-action  [%receive-mp-move move.entry]
      =/  pass=card
        [%pass /mp-auto-retry %agent [target-ship.entry %cantrip] %poke %cantrip-action !>(outbound)]
      =/  wake=card
        %:  mp-retry-wake-card
          bowl  move-id.u.ticket  next-attempt.decision
          generation.u.ticket  next-delay.decision
        ==
      :_  this(state state(mp-outbox (~(put by mp-outbox) move-id.u.ticket advanced)))
      %+  weld  (mp-outbox-control-cards bowl %auto-retry advanced)
      ~[pass wake]
  ==
++  on-leave  on-leave:def
++  on-fail   on-fail:def
--
