::  Native terminal adapter. Viki is the only owner of coding work.
/-  pc=pataphor-project-coding
/+  default-agent, con=pataphor-project-console,
    project=pataphor-development-workspace, presentation=pataphor-native-console-http,
    web=pataphor-terminal-http, coding=native-coding-http,
    guard=viki-scry-guard, cr=codex-responses,
    editor=native-coding-terminal-state,
    source-http=native-coding-source-import-http, asset=ui-asset,
    ark=qpc-terminal-view, reload=native-console-load-guard
=>
|%
+$  card  card:agent:gall
+$  saved  [%native-console-v1 token=@uv waiting=(map @ta @t) last=(unit delivery:presentation)]
+$  coding-state  [token=@uv waiting=(map @ta viewer:coding) delivery=@t]
+$  envelope  [%native-console-v2 legacy=saved coding=coding-state]
+$  installed  [%native-console-v3 legacy=saved coding=coding-state editor=state:editor]
--
=|  state=saved
=|  native=coding-state
=/  editing=state:editor  empty:editor
=|  connected=?
=|  feed=connection:presentation
::  Transient evidence of this core's last successful load, never saved DATA.
=|  reload-status=(unit [tag=%checked at=@da parts=@ud])
^-  agent:gall
|_  =bowl:gall
+*  this  .
    def  ~(. (default-agent this %.n) bowl)
    boot
      ^-  card
      [%pass /bind %arvo %e %connect [~ /apps/pataphor-native] %pataphor-native-console]
    watch
      ^-  card
      [%pass /viki %agent [our.bowl %viki] %watch /development/pataphor]
    unwatch
      ^-  card
      [%pass /viki %agent [our.bowl %viki] %leave ~]
    read
      ^-  (each view:pc @tas)
      ?:  =(%failed feed)  [%| %viki-watch-unavailable]
      (read:project our.bowl our.bowl now.bowl)
    snapshot
      (snapshot:presentation token.state read feed last.state)
    wake
      ^-  (list card)
      ?:  =(~ waiting.state)  ~
      =/  body=json  snapshot
      %-  zing
      (turn ~(tap by waiting.state) |=([id=@ta cursor=@t] (json-response:web id 200 body)))
    coding-watch
      ^-  card
      [%pass /coding-viki %agent [our.bowl %viki] %watch /native-coding]
    coding-rewatch
      ^-  (list card)
      ~[[%pass /coding-viki %agent [our.bowl %viki] %leave ~] coding-watch]
    coding-view
      |=  view=viewer:coding
      ^-  json
      (snapshot:coding our.bowl now.bowl token.native connected session.view after.view delivery.native (view:editor editing session.view))
    coding-wake
      ^-  (list card)
      %-  zing
      %+  turn  ~(tap by waiting.native)
      |=  [id=@ta view=viewer:coding]
      (json-response:web id 200 (coding-view view))
    coding-edit
      |=  [id=@ta object=json]
      ^-  (quip card _this)
      ?.  &((agent-live:guard our.bowl now.bowl %viki) connected)
        [(failure:web id 503 'Native coding unavailable.') this]
      =/  decoded
        %-  mole
        |.
        ?>  =(`(scot %uv token.native) (string:cr object 'nonce'))
        [(hex:coding object 'session') (need (string:cr object 'edit')) (need (string:cr object 'text'))]
      ?~  decoded  [(failure:web id 409 'Editor token or input invalid. Reconnect to observe.') this]
      =/  [session=@ux kind=@t text=@t]  u.decoded
      =/  current  (read:coding our.bowl now.bowl)
      ?~  current  [(failure:web id 503 'Native sessions unavailable.') this]
      ?.  (lien sessions.u.current |=(s=public-session:loop:coding =(session id.session.s)))
        [(failure:web id 409 'Select a retained native session first.') this]
      =/  reduced  (step:editor editing session kind text)
      ?:  ?=(%| -.reduced)
        =.  delivery.native  (cat 3 'Editor refused: ' (scot %tas p.reduced))
        [(json-response:web id 200 (coding-view [session 0 '0x0'])) this]
      =/  effect=effect:editor  effect.p.reduced
      =/  nonce=@ux  (shax (jam [%native-coding-terminal our.bowl token.native session effect]))
      =/  cards=(list card)
        ?:  ?=(%none -.effect)  ~
        =/  action
          ?:  ?=(%command -.effect)  [%terminal session nonce text.effect]
          [%pause session ?=(%interrupt -.effect)]
        ~[[%pass /coding-command/(scot %ux session)/(scot %ux nonce) %agent [our.bowl %viki] %poke %noun !>([%native-coding-action-v1 action])]]
      =.  editing  state.p.reduced
      =.  token.native  `@uv`(sham [token.native eny.bowl now.bowl %coding-edit])
      =.  delivery.native
        ?:  ?=(%none -.effect)
          ?:  =('Editor refused: ' (cut 3 [0 16] delivery.native))  ''
          delivery.native
        (command-status:coding session nonce %submitted)
      [(weld cards (weld coding-wake (json-response:web id 200 (coding-view [session 0 '0x0'])))) this(waiting.native ~)]
    coding-http
      |=  [id=@ta req=inbound-request:eyre]
      ^-  (quip card _this)
      =/  url=@t  url.request.req
      ?:  =('GET' method.request.req)
        ?:  |(=('/apps/pataphor-native/coding' url) =('/apps/pataphor-native/coding/' url))
          [(respond:web id 200 'text/html; charset=utf-8' page:coding %.n) this]
        =/  served=(unit [p=path q=@t])
          =/  prefix=@t  '/apps/pataphor-native/coding/'
          =/  size=@ud  (met 3 prefix)
          ?.  &((gth (met 3 url) size) =(prefix (end [3 size] url)))  ~
          =/  file=@t  (rsh [3 size] url)
          ?:  =('xterm.css' file)  `[/ui/xterm/css 'text/css; charset=utf-8']
          =/  scripts=(list @t)
            :~  'native-coding.js'  'native-coding-files.js'  'codemirror.js'  'hoon-editor.js'
                'native-coding-completion.js'  'native-coding-onboarding.js'  'native-coding-session-workspace.js'
                'native-coding-compiler-mapping.js'  'native-coding-compiler-exports.js'  'native-coding-deployment.js'
                'native-coding-flow.js'  'xterm.js'
            ==
          ?.  (lien scripts |=(n=@t =(n file)))  ~
          =/  base=@ta  `@ta`(end [3 (sub (met 3 file) 3)] file)
          `[(latest:asset bowl base %js) 'application/javascript; charset=utf-8']
        ?^  served
          =/  found=(unit @t)  (read:asset bowl p.u.served)
          ?~  found  [(failure:web id 404 'Asset not present on this desk.') this]
          [(respond:web id 200 q.u.served u.found %.n) this]
        =/  git-proposal  (git-proposal-get:coding our.bowl now.bowl url)
        ?^  git-proposal  [(json-response:web id 200 u.git-proposal) this]
        =/  completion  (completion-get:coding our.bowl now.bowl url)
        ?^  completion  [(json-response:web id 200 u.completion) this]
        =/  workspace  (workspace-get:coding our.bowl now.bowl url)
        ?^  workspace  [(json-response:web id 200 u.workspace) this]
        =/  mapping  (compiler-mapping-get:coding our.bowl now.bowl url)
        ?^  mapping  [(json-response:web id 200 u.mapping) this]
        =/  exports  (compiler-exports-get:coding our.bowl now.bowl url)
        ?^  exports  [(json-response:web id 200 u.exports) this]
        =/  deployment  (deployment-get:coding our.bowl now.bowl url)
        ?^  deployment  [(json-response:web id 200 u.deployment) this]
        =/  prefix=@t  '/apps/pataphor-native/coding/state?'
        =/  events=@t  '/apps/pataphor-native/coding/events?'
        =/  initial=?  =(prefix (cut 3 [0 (met 3 prefix)] url))
        ?.  |(initial =(events (cut 3 [0 (met 3 events)] url)))
          [(failure:web id 404 'Unknown native coding address.') this]
        =/  query  (query:coding (rsh [3 (met 3 ?:(initial prefix events))] url))
        ?~  query  [(failure:web id 400 'Invalid native view cursor.') this]
        =/  snapshot=json  (coding-view u.query)
        =/  available=?  (agent-live:guard our.bowl now.bowl %viki)
        =/  watches=(list card)
          ?:  &(initial available !connected)
            coding-rewatch
          ~
        ?:  |(initial !=(`cursor.u.query (string:cr snapshot 'cursor')) ?=([~ %b %&] (field:cr snapshot 'more')))
          [(weld watches (json-response:web id 200 snapshot)) this]
        ?:  (gte ~(wyt by waiting.native) 16)
          [(failure:web id 429 'Too many coding viewers.') this]
        [~ this(waiting.native (~(put by waiting.native) id u.query))]
      ?.  &(=('POST' method.request.req) =('/apps/pataphor-native/coding/action' url))
        [(failure:web id 405 'Use an explicit coding action.') this]
      =/  headers  (~(gas by *(map @t @t)) header-list.request.req)
      ?.  &(!=(0 token.native) =(`'application/json' (~(get by headers) 'content-type')))
        [(failure:web id 415 'Use a same-origin JSON command.') this]
      =/  body  body.request.req
      ?~  body  [(failure:web id 400 'Missing command.') this]
      ?.  &(=(p.u.body (met 3 q.u.body)) (lte p.u.body 131.072))
        [(failure:web id 413 'Command too large.') this]
      =/  object  (de:json:html q.u.body)
      ?~  object  [(failure:web id 400 'Invalid JSON.') this]
      ?:  =(`'edit' (string:cr u.object 'kind'))  (coding-edit id u.object)
      =/  prepared  (command:coding our.bowl now.bowl token.native q.u.body)
      ?:  ?=(%| -.prepared)
        [(failure:web id 409 'Command refused. Reconnect to observe before submitting again.') this]
      ?.  &((agent-live:guard our.bowl now.bowl target.p.prepared) connected)
        [(failure:web id 503 'Native target or notification feed unavailable.') this]
      =/  receipt=@ux  (shax (jam [%native-coding-delivery token.native]))
      =/  card=card
        [%pass /coding-command/(scot %ux id.p.prepared)/(scot %ux receipt) %agent [our.bowl target.p.prepared] %poke %noun !>(payload.p.prepared)]
      =.  token.native  `@uv`(sham [token.native eny.bowl now.bowl %coding-command])
      =.  delivery.native  (command-status:coding id.p.prepared receipt %submitted)
      =/  snapshot=json  (coding-view [id.p.prepared 0 '0x0'])
      ?>  ?=(%o -.snapshot)
      =.  p.snapshot
        (~(put by p.snapshot) 'commandReceipt' (command-receipt:files:coding receipt target.p.prepared id.p.prepared payload.p.prepared))
      [(weld ~[card] (weld coding-wake (json-response:web id 202 snapshot))) this(waiting.native ~)]
    source-import-http
      |=  [id=@ta req=inbound-request:eyre]
      ^-  (quip card _this)
      =/  url=@t  url.request.req
      ?:  =('GET' method.request.req)
        ?:  =('/apps/pataphor-native/source-import/state' url)
          [(json-response:web id 200 (state:source-http our.bowl now.bowl token.native)) this]
        =/  asset=(unit [p=path q=@t])
          ?:  |(=('/apps/pataphor-native/source-import' url) =('/apps/pataphor-native/source-import/' url))
            `[/ui/native-coding-source-import/html 'text/html; charset=utf-8']
          ?:  =('/apps/pataphor-native/source-import.js' url)
            `[/ui/native-coding-source-import/js 'application/javascript; charset=utf-8']
          ~
        ?~  asset  [(failure:web id 404 'Unknown source preparation address.') this]
        =/  body=@t  .^(@t %cx (weld ~[(scot %p our.bowl) q.byk.bowl (scot %da now.bowl)] p.u.asset))
        [(respond:web id 200 q.u.asset body %.n) this]
      ?.  &(=('POST' method.request.req) =('/apps/pataphor-native/source-import/action' url))
        [(failure:web id 405 'Use an explicit source import action.') this]
      =/  headers  (~(gas by *(map @t @t)) header-list.request.req)
      ?.  &(!=(0 token.native) =(`'application/json' (~(get by headers) 'content-type')))
        [(failure:web id 415 'Use a same-origin JSON command.') this]
      =/  body  body.request.req
      ?~  body  [(failure:web id 400 'Missing source import command.') this]
      ?.  &(=(p.u.body (met 3 q.u.body)) (lte p.u.body body-limit:source-http))
        [(failure:web id 413 'Source import batch too large.') this]
      =/  decoded  (decode:source-http our.bowl now.bowl token.native q.u.body)
      ?:  ?=(%| -.decoded)
        [(failure:web id 409 (cat 3 'Source import refused: ' p.decoded)) this]
      ?.  (agent-live:guard our.bowl now.bowl %native-coding-source-import)
        [(failure:web id 503 'Native source import journal unavailable.') this]
      =/  receipt=@ux  (shax (jam [%native-source-import-delivery token.native]))
      =/  card=card
        [%pass /source-import-command/(scot %ux receipt) %agent [our.bowl %native-coding-source-import] %poke %noun !>(p.decoded)]
      =.  token.native  `@uv`(sham [token.native eny.bowl now.bowl %source-import-command])
      [(weld ~[card] (json-response:web id 202 (state:source-http our.bowl now.bowl token.native))) this]
++  on-init
  ^-  (quip card _this)
  [~[boot watch] this(feed %pending, token.state `@uv`(sham [eny.bowl now.bowl %native-console]), token.native `@uv`(sham [eny.bowl now.bowl %native-coding]))]
++  on-save  !>(`installed`[%native-console-v3 state native editing])
++  on-load
  |=  old=vase
  ^-  (quip card _this)
  =/  newer  ((soft ,envelope) q.old)
  =/  latest  ((soft ,installed) q.old)
  =.  state
    ?:  &(?=(^ latest) =(u.latest q.old))  legacy.u.latest
    ?:  &(?=(^ newer) =(u.newer q.old))  legacy.u.newer
    !<(saved old)
  =.  native
    ?:  &(?=(^ latest) =(u.latest q.old))  coding.u.latest
    ?:  &(?=(^ newer) =(u.newer q.old))  coding.u.newer
    [`@uv`(sham [eny.bowl now.bowl %native-coding]) ~ '']
  =.  editing
    ?:  &(?=(^ latest) =(u.latest q.old))  editor.u.latest
    empty:editor
  ?>  (state-valid:editor editing)
  ?>  &(!=(0 token.native) (lte ~(wyt by waiting.native) 16))
  ?>  &(!=(0 token.state) (lte ~(wyt by waiting.state) 16))
  ::  Refuse before computing replies: a reload must not consume a waiter.
  ~|  %console-reload-waiters
  ?>  (idle:reload waiting.state waiting.native)
  =/  normalized=vase  on-save
  =.  feed  %pending
  ::  Gall retains subscriptions across reload. A duplicate watch may not
  ::  acknowledge again, so explicitly replace it before awaiting readiness.
  =/  cards=(list card)
    (weld ~[boot unwatch watch] (weld coding-rewatch (weld wake coding-wake)))
  =/  next  this(waiting.state ~, waiting.native ~, connected %.n)
  =/  checked  (check:reload old normalized on-save:next cards our.bowl)
  ?:  ?=(%| -.checked)  ~|(p.checked !!)
  ::  The guard checks all three normalized saved parts: legacy, coding, editor.
  [cards next(reload-status `[%checked now.bowl 3])]
++  on-poke
  |=  [=mark =vase]
  ^-  (quip card _this)
  ?:  =(%noun mark)
    ?>  =(our.bowl src.bowl)
    =/  incoming
      ((soft ,[%native-coding-editor-install-v1 bundle=bundle:editor]) q.vase)
    ?>  &(?=(^ incoming) =(q.vase u.incoming))
    =/  accepted  (install:editor editing bundle.u.incoming)
    ?>  ?=(%& -.accepted)
    =.  editing  p.accepted
    [coding-wake this(waiting.native ~)]
  ?>  =(%handle-http-request mark)
  =+  !<([id=@ta req=inbound-request:eyre] vase)
  ?.  &(authenticated.req =(src.bowl our.bowl))
    [(failure:web id 403 'Owner authentication required.') this]
  =/  url=@t  url.request.req
  =/  method=@t  method.request.req
  =/  source-prefix=@t  '/apps/pataphor-native/source-import'
  ?:  =(source-prefix (cut 3 [0 (met 3 source-prefix)] url))  (source-import-http id req)
  =/  coding-prefix=@t  '/apps/pataphor-native/coding'
  ?:  =(coding-prefix (cut 3 [0 (met 3 coding-prefix)] url))  (coding-http id req)
  ?:  =('GET' method)
    ?:  |(=('/apps/pataphor-native' url) =('/apps/pataphor-native/' url))
      [(respond:web id 200 'text/html; charset=utf-8' page:presentation %.n) this]
    ?:  =('/apps/pataphor-native/native-console.js' url)
      =/  js=@t  .^(@t %cx (scot %p our.bowl) q.byk.bowl (scot %da now.bowl) /ui/native-console/js)
      [(respond:web id 200 'application/javascript; charset=utf-8' js %.n) this]
    ?:  =('/apps/pataphor-native/state' url)
      =/  reconnect=?  !=(%live feed)
      =.  feed  ?:(reconnect %pending feed)
      [(weld ?:(reconnect ~[unwatch watch] ~) (json-response:web id 200 snapshot)) this]
    =/  prefix=@t  '/apps/pataphor-native/events?cursor='
    =/  size=@ud  (met 3 prefix)
    ?.  &(=(prefix (cut 3 [0 size] url)) (lte (met 3 url) (add size 90)))
      [(failure:web id 404 'Unknown native terminal address.') this]
    =/  cursor=@t  (rsh [3 size] url)
    =/  expected  (slaw %ux cursor)
    ?~  expected  [(failure:web id 400 'Invalid view cursor.') this]
    ?.  =(cursor (scot %ux u.expected))
      [(failure:web id 400 'Invalid view cursor.') this]
    =/  current  read
    ?:  |(=(%failed feed) !=(u.expected (view-cursor:presentation current feed last.state)))
      [(json-response:web id 200 (snapshot:presentation token.state current feed last.state)) this]
    ?:  (gte ~(wyt by waiting.state) 16)
      [(failure:web id 429 'Too many native terminal viewers.') this]
    [~ this(waiting.state (~(put by waiting.state) id cursor))]
  ?.  &(=('POST' method) =('/apps/pataphor-native/command' url))
    [(failure:web id 405 'Use a terminal command.') this]
  =/  headers  (~(gas by *(map @t @t)) header-list.request.req)
  ?.  =(`'application/json' (~(get by headers) 'content-type'))
    [(failure:web id 415 'Use a JSON terminal command.') this]
  =/  body  body.request.req
  ?~  body  [(failure:web id 400 'Missing command.') this]
  ?.  &(=(p.u.body (met 3 q.u.body)) (lte p.u.body 8.192))
    [(failure:web id 413 'Command too large.') this]
  =/  decoded  (command:presentation q.u.body token.state)
  ?~  decoded  [(failure:web id 409 'Command token changed. Reconnect to observe before continuing.') this]
  =/  parsed  (parse:con line.u.decoded)
  ?:  ?=(%| -.parsed)
    [(failure:web id 400 (cat 3 'Command refused: ' (scot %tas p.parsed))) this]
  =/  current  read
  ?:  ?=(%| -.current)
    [(failure:web id 503 (cat 3 'Project unavailable: ' (scot %tas p.current))) this]
  =/  nonce=@ux  `@ux`(sham [%native-command our.bowl token.state u.decoded])
  =/  prepared  (prepare:con our.bowl src.bowl nonce manifest.u.decoded p.parsed p.current)
  ?:  ?=(%| -.prepared)
    [(failure:web id 409 (cat 3 'Command refused: ' (scot %tas p.prepared))) this]
  =/  action  p.prepared
  ?:  ?=(%ark -.action)
    =/  text=@t  (render:ark our.bowl key.action (ark-read:project our.bowl src.bowl now.bowl))
    =/  response=json
      (pairs:enjs:format ~[['text' s+text] ['state' (snapshot:presentation token.state current feed last.state)]])
    ::  Reading emits only the HTTP reply. Tokens, delivery and work stay put.
    [(json-response:web id 200 response) this]
  ?:  !=(%live feed)
    [(failure:web id 503 'Viki notifications unavailable. Reconnect before submitting.') this]
  =/  cards=(list card)
    ?-  -.action
      %text  ~
      %request  ~[(start:project our.bowl request.action)]
      %observe  ~[[%pass /observe %agent [our.bowl %viki] %poke %noun !>([%viki-project-observe key.action])]]
      %law  ~[(law-card:con our.bowl nonce cmd.action)]
    ==
  =/  text=@t
    ?-  -.action
      %text  body.action
      %request  (rap 3 ~['Submitted ' (scot %ux nonce.request.action) '. Waiting for Viki retention.'])
      %observe  'Observing retained work. No model request was resent.'
      %law  'Submitted law change to Viki. Read native state in ARK to confirm the saved revision; delivery alone is not confirmation.'
    ==
  =.  last.state
    ?:  ?=(%request -.action)  `[nonce.request.action %submitted `@tas`0]
    ?:  ?=(%law -.action)  `[nonce %submitted `@tas`0]
    last.state
  =.  token.state  `@uv`(sham [token.state eny.bowl now.bowl %native-command])
  =/  response=json
    (pairs:enjs:format ~[['text' s+text] ['state' (snapshot:presentation token.state current feed last.state)]])
  [(weld cards (json-response:web id 200 response)) this]
++  on-agent
  |=  [=wire =sign:agent:gall]
  ^-  (quip card _this)
  ::  Source-import state is observed through its journal. Delivery ACKs do
  ::  not confirm a batch or cause it to be resent.
  ?:  ?=([%source-import-command @ ~] wire)  `this
  ?.  =(our.bowl src.bowl)  `this
  ?:  ?=([%coding-command @ @ ~] wire)
    ?.  ?=(%poke-ack -.sign)  `this
    =/  session  (slaw %ux i.t.wire)
    =/  receipt  (slaw %ux i.t.t.wire)
    ?~  session  `this
    ?~  receipt  `this
    ?.  &(=(i.t.wire (scot %ux u.session)) =(i.t.t.wire (scot %ux u.receipt)))  `this
    ?.  =(delivery.native (command-status:coding u.session u.receipt %submitted))  `this
    =.  delivery.native
      (command-status:coding u.session u.receipt ?~(p.sign %delivered %refused))
    [coding-wake this(waiting.native ~)]
  ?:  ?=([%coding-command @ ~] wire)  `this
  ?:  =(/coding-viki wire)
    =.  connected
      ?:  ?=(%watch-ack -.sign)  ?~(p.sign %.y %.n)
      ?:  ?=(%kick -.sign)  %.n
      ?:  ?=(%fact -.sign)  %.y
      connected
    ::  A loop refusal is a fact, not a nack; without this the browser only
    ::  ever sees 'submitted' for a command Viki declined to run.
    =?  delivery.native  ?=(%fact -.sign)
      =/  refused  ((soft ,[%native-coding-refused-v1 id=@ux reason=@tas]) q.q.cage.sign)
      ?~  refused  delivery.native
      (rap 3 ~['Refused ' (scot %ux id.u.refused) ' at ' (scot %da now.bowl) ': ' (scot %tas reason.u.refused)])
    [coding-wake this(waiting.native ~)]
  ?:  ?=([%glass-goal @ ~] wire)
    ?.  ?=(%poke-ack -.sign)  `this
    ?~  last.state  `this
    ?.  =(i.t.wire (scot %ux nonce.u.last.state))  `this
    ?.  =(%submitted phase.u.last.state)  `this
    =.  last.state
      `u.last.state(phase ?~(p.sign %accepted %refused), reason ?~(p.sign `@tas`0 %viki-poke-refused))
    [wake this(waiting.state ~)]
  ?.  =(/viki wire)  (on-agent:def wire sign)
  ?:  ?=(%watch-ack -.sign)
    =.  feed  ?~(p.sign %live %failed)
    [wake this(waiting.state ~)]
  ?:  ?=(%fact -.sign)
    ?>  =(%noun p.cage.sign)
    =/  event
      ((soft ,$?([%pataphor-development-changed-v1 @ux] [%pataphor-development-refused-v1 nonce=@ux reason=@tas])) q.q.cage.sign)
    ?>  ?=(^ event)
    =.  feed  %live
    ?:  ?=(%pataphor-development-refused-v1 -.u.event)
      ?~  last.state  `this
      ?.  =(nonce.u.event nonce.u.last.state)  `this
      =.  last.state  `[nonce.u.event %refused reason.u.event]
      [wake this(waiting.state ~)]
    [wake this(waiting.state ~)]
  ?:  ?=(%kick -.sign)
    =.  feed  %failed
    [wake this(waiting.state ~)]
  `this
++  on-leave
  |=  =path
  ^-  (quip card _this)
  ?.  =(our.bowl src.bowl)  `this
  ?.  ?=([%http-response @ ~] path)  (on-leave:def path)
  `this(waiting.state (~(del by waiting.state) i.t.path), waiting.native (~(del by waiting.native) i.t.path))
++  on-peek
  |=  =path
  ^-  (unit (unit cage))
  ?:  ?=([%x %load-guard ~] path)  ``noun+!>(reload-status)
  (on-peek:def path)
++  on-watch
  |=  =path
  ^-  (quip card _this)
  ?.  ?=([%http-response @ ~] path)  (on-watch:def path)
  ::  Eyre's empty preauthentication subscription carries no private data.
  `this
++  on-arvo
  |=  [=wire =sign-arvo]
  ^-  (quip card _this)
  ::  A successful acknowledgment of our exact route is not a command.
  ?:  &(=(/bind wire) =([%eyre %bound %.y ~ /apps/pataphor-native] sign-arvo))
    `this
  (on-arvo:def wire sign-arvo)
++  on-fail  on-fail:def
--
