::  /app/viki.hoon -- VIKI, THE SHIP'S FAMILIAR.
::
::  Not a goal runner with a doorbell.  A RESIDENT: it wakes on its own
::  tick, reads the loom, and either wants something or rests.  Goals
::  are what it finds while living, not why it runs.
::
::    |link %viki     talk to your familiar.  Your words thread
::                         into its life; its answers cite what it
::                         read; the exchange stays.
::
::  THE THREAD IS ITS MEMORY.  This agent normally holds a CURSOR -- the number
::  of the next free turn -- plus one result while Graf owes a semantic receipt.
::  The chain of turns (sur/familiar) is durable, immutable and walkable,
::  so a crash costs a cursor and anyone can audit its whole life
::  without asking it.
::
::  THE AUTHORITY IT LIVES UNDER:
::    - Viki and the Bride are one sovereign cognition-and-judgment entity.
::      Cantrip never decides whether Viki may think, speak, or choose work;
::      it binds the replaceable model organ and any connected Bachelor output.
::    - resting is THREADED, never skipped, and always carries a named
::      reason.  A gap in the chain is indistinguishable from a crash.
::    - it is SUMMONED deliberately: installing starts nothing.
::
::  CHANGING IT: an edit here rebuilds the whole agent on %host-viki (a
::  ceremony; 12 min with the ship silent on 2026-10-13).  Behaviour that
::  changes often belongs in a hot module on %hot-viki: seconds, no rebuild.
::
::  VIKI OWNS THE LANDING (operator ruling): the courier lights nothing.
::  When a result comes home, Viki retains and submits one complete transaction;
::  Graf derives and lands its fact, terminal index, and thread in ONE event.
::
/-  dvn=derivation, fam=familiar, gol=goal, itn=intent,
    vi=viki-inference, va=vibecoding-artifact, gpr=viki-glass-project,
    vd=vibecoding-dispatch, vdr=vibecoding-dispatch-receipt,
    vp=vibecoding-proposal,
    vjv=vibecoding-judgment, cl=canon-law,
    vl=viki-landing, mb=model-bridge, vr=glass-moon-route, vco=viki-cockpit,
    bc=boxy-cockpit, fc=frag-cockpit, gc=graf-cockpit, pc=pataphor-cockpit,
    wis=weight-interpretation, wi=weight-inquiry, vrc=viki-recovery,
    vww=viki-weight-workflow, vgw=viki-goal-workflow,
    vcf=viki-config, vw=viki-worker, vb=viki-bridge, mg=moon-grant, ct=cantrip,
    wwc=waterwheel-cockpit, vto=viki-tensor-organ, vsl=viki-seat,
    vmi=viki-model-io, mr=model-admission-registry,
    graf-sur=graf, gsc=graf-seat-claim, pcode=pataphor-project-coding,
    nct=native-coding, nft=native-coding-fleet, nri=native-coding-review-inspection
/+  shoe, tick, ask-build, gep=graf-evidence-packet, satisfy, default-agent, aj=a2a-judgment,
    bj=bride-judgment, bjc=bride-judgment-chain,
    vj=viki-judgment, ves=viki-evidence-search, vc=viki-candidate-compare,
    cr=viki-candidate-round, vrec=viki-recurrence,
    vni=viki-nick-intent, vwi=viki-weight-intent, vil=viki-intent,
    cvp=cantrip-vibecoding-proposal, clw=cantrip-law-window,
    vci=viki-connected-intake,
    vdrl=vibecoding-dispatch-receipt,
    val=vibecoding-artifact, vvj=viki-vibecoding-judgment,
    vlj=viki-vibecoding-local-judgment, vljr=viki-vibecoding-local-read,
    vcj=viki-vibecoding-connected-judgment, vcjr=viki-vibecoding-connected-judgment-read,
    vwr=viki-weight-ratify, vgs=viki-goal-submit, vgr=viki-goal-ratify,
    vwm=viki-worker-migration, vwa=viki-worker-authority,
    vbm=viki-bridge-migration,
    moon-guardian, moon-graf-effect, viki-worker-engine, viki-worker-cards,
    pln=plan, esc=escalate,
    qcq=qpc-ct-qualia,
    vtg=viki-tensor-govern,
    vta=viki-tensor-absorb, vt=viki-tensor,
    vsa=viki-seat-absorb,
    vsg=viki-scry-guard,
    ::  NOT vgs -- that face is viki-goal-submit, two lines up.
    vgseat=viki-graf-seat, vgsr=viki-graf-seat-reassignment,
    vml=viki-model-io, mar=model-admission-registry,
    vmr=viki-route, vms=seat-session, vgc=viki-glass-coding,
    gcl=viki-glass-coding-loop, gcr=glass-coding-result, gpl=viki-glass-project,
    generation=cantrip-glass-generation, gflect=cantrip-glass-flect, shadow=cantrip-shadow,
    gcc=viki-glass-correction, gcan=viki-glass-coding-cancel,
    devc=viki-project-coding, devread=pataphor-project-coding-read,
    ncode=native-coding-loop, nprovider=native-coding-inference,
    nhistory=native-coding-history, ncontext-view=native-coding-context-view,
    nfleet=native-coding-fleet-runtime, nrelay=native-coding-moon-relay,
    nreview=native-coding-review, naccept=native-coding-accept,
    nworkspace=viki-native-workspace, ndeploy=native-coding-deployment,
    nopening=viki-native-opening, ncampaign=native-coding-review-orchestration,
    nreviewer=native-coding-review-worker, nonboard=viki-native-onboarding,
    nfinish=native-coding-fleet-settlement,
    ncompletion=native-coding-completion-runtime,
    qpc-task-completion=qpc-native-task-completion-runtime,
    nccampaign=native-coding-completion-review-orchestration,
    ncreviewed=native-coding-reviewed-completion,
    ncreviewer=native-coding-completion-review-worker,
    nsession-workspace=native-coding-session-workspace,
    nbootstrap=native-coding-bootstrap,
    nsession=native-coding-session,
    wl=weight-leaves-smollm2, rf=readymade-fleet-agent,
    dbug, verb, qpc-gate=qpc-session-gate, qpc-observer=qpc-observer,
    qpc-stream=qpc-observation-stream, local-review=native-coding-local-review-agent,
    qpc-instrument=qpc-instrument, qpc-law=qpc-law,
    qpc-prospective=qpc-native-owner-agent, qpc-declaration=qpc-native-declaration-agent,
    qpc-state=qpc-native-app-state, qpc-flow=qpc-native-flow-agent,
    qpc-selected=qpc-native-selected-agent, qpc-selected-note=qpc-native-selected-note,
    qpc-selected-project=qpc-selected-session-project,
    qpc-campaign=qpc-native-campaign-agent, qpc-status=qpc-native-status-agent,
    qpc-onboard=qpc-task-onboard-agent,
    qpc-readiness=qpc-native-readiness-agent,
    qpc-controller=qpc-native-controller-agent, qpc-note=qpc-native-controller-note,
    hot-owner=hot-module-agent, hotm=hot-module, lguard=load-guard
|%
::  cross-agent reads are guarded by +agent-live:viki-scry-guard --
::  `mule` does NOT catch a failed `.^`, so the only way to survive a
::  missing agent is not to ask it.  See that lib for the measurements.
+$  card  card:shoe
+$  state-0
  $:  %0
      armed=?                             ::  summoned?
      head=@ud                            ::  next free thread turn number
      pending=(unit [t=turn-id:fam aid=@ux])
      budget=@ud                          ::  self-directed wants left
      every=@dr                           ::  tick interval
      said=(unit @t)                      ::  operator line owed a reply
      seen=@ud                            ::  fact count at the last tick
  ==
+$  flight-1  [t=turn-id:fam want=want:dvn]
+$  state-1
  $:  %1
      armed=?
      head=@ud
      pending=(unit flight-1)
      budget=@ud
      every=@dr
      said=(unit @t)
      seen=@ud
  ==
+$  flight-2  [t=turn-id:fam want=want:dvn result=(unit result:vi)]
+$  state-2
  $:  %2
      armed=?
      head=@ud
      pending=(unit flight-2)
      budget=@ud
      every=@dr
      said=(unit @t)
      seen=@ud
  ==
+$  state-3
  $:  %3
      armed=?
      head=@ud
      pending=(unit flight-2)
      organ=@p                             ::  configured immediate child moon
      budget=@ud
      every=@dr
      said=(unit @t)
      seen=@ud
  ==
+$  connected-route  connected-route:vr
+$  model-route  model-route:vr
+$  flight
  $:  t=turn-id:fam
      want=want:dvn
      request=request-v2:vi
      sent=@da
      result=(unit result:vi)
  ==
+$  state-4
  $:  %4
      armed=?
      head=@ud
      pending=(unit flight)
      route=model-route
      budget=@ud
      every=@dr
      said=(unit @t)
      seen=@ud
  ==
+$  state-5
  $:  %5
      armed=?
      head=@ud
      pending=(unit flight)
      route=model-route
      retry-policy=(unit policy:esc)       ::  operator-set; ~ disables retries
      budget=@ud
      every=@dr
      said=(unit @t)
      seen=@ud
  ==
+$  state-6
  $:  %6
      armed=?
      head=@ud                            ::  next free thread turn number
      pending=(unit flight)
      route=model-route
      retry-policy=(unit policy:esc)       ::  operator-set; ~ disables retries
      budget=@ud
      every=@dr
      said=(unit @t)
      seen=@ud
  ==
+$  candidate-call  call:cr
+$  candidate-round  round:cr
+$  judgment-authority  authority:bjc
+$  judgment-chain      chain:bjc
+$  state-7
  $:  %7
      armed=?
      head=@ud                            ::  next free thread turn number
      pending=(unit flight)
      routes=(list model-route)           ::  bounded, operator-selected organs
      round=(unit candidate-round)        ::  goal-only sequential deliberation
      retry-policy=(unit policy:esc)       ::  operator-set; ~ disables retries
      budget=@ud
      every=@dr
      said=(unit @t)
      seen=@ud
  ==
+$  state-8
  $:  %8
      armed=?
      head=@ud
      pending=(unit flight)
      routes=(list model-route)
      round=(unit candidate-round)
      retry-policy=(unit policy:esc)
      budget=@ud
      every=@dr
      said=(unit @t)
      seen=@ud
      judgments=judgment-chain            ::  Viki/Bride, never Waterwheel
  ==
+$  reconsideration-work
  [id=@ux targets=(list reconsideration-target:vj)]
+$  state-9
  $:  %9
      armed=?
      head=@ud
      pending=(unit flight)
      routes=(list model-route)
      round=(unit candidate-round)
      retry-policy=(unit policy:esc)
      budget=@ud
      every=@dr
      said=(unit @t)
      seen=@ud
      judgments=judgment-chain
      last-reconsideration=(unit @ux)
      reconsideration=(unit reconsideration-work)
  ==
+$  route-change  route-change:vr
+$  route-change-kind  route-change-kind:vr
+$  state-10
  $:  %10
      armed=?
      head=@ud
      pending=(unit flight)
      routes=(list model-route)
      round=(unit candidate-round)
      retry-policy=(unit policy:esc)
      budget=@ud
      every=@dr
      said=(unit @t)
      seen=@ud
      judgments=judgment-chain
      last-reconsideration=(unit @ux)
      reconsideration=(unit reconsideration-work)
      route-revision=@ud
      route-history=(list route-change)
  ==
+$  state-any  $%(state-10 state-9 state-8 state-7 state-6 state-5 state-4 state-3 state-2 state-1 state-0)
+$  saved-state-1  [%viki-familiar-state-v1 state=state-any]
+$  saved-state-2
  [%viki-familiar-state-v2 state=state-any workers=worker-organ:vw]
+$  saved-state-3
  $:  %viki-familiar-state-v3
      state=state-any
      workers=worker-organ:vw
      bridge=bridge-organ-1:vb
  ==
+$  saved-state-4
  $:  %viki-familiar-state-v4
      state=state-any
      workers=worker-organ:vw
      bridge=bridge-organ-1:vb
      tensor=organ:vto
  ==
::  v5: the cortex split's Viki half -- the bound-worker seats and advice
::  inbox ride beside the tensor organ.
+$  saved-state-5
  $:  %viki-familiar-state-v5
      state=state-any
      workers=worker-organ:vw
      bridge=bridge-organ-1:vb
      tensor=organ:vto
      seats=organ:vsl
  ==
::  v6: the absorbed model I/O organ (ladder 13) -- %model-gateway's
::  one-at-a-time admission and untrusted-claim law plus %model-terminal's
::  correlation law, transports still in the shells until cutover.
+$  saved-state-6
  $:  %viki-familiar-state-v6
      state=state-any
      workers=worker-organ:vw
      bridge=bridge-organ-1:vb
      tensor=organ:vto
      seats=organ:vsl
      modelio=organ:vmi
  ==
::  v7: canonical edited-model admission and lifecycle state is owned by Viki
::  itself.  No sidecar Gall agent can impersonate this authority boundary.
+$  saved-state-7
  $:  %viki-familiar-state-v7
      state=state-any
      workers=worker-organ:vw
      bridge=bridge-organ-1:vb
      tensor=organ:vto
      seats=organ:vsl
      modelio=organ:vmi
      registry=registry:mr
  ==
::  v8: authenticated operator turns and irreducible stated intents are owned
::  by Viki.  The complete build lifecycle remains a derived projection over
::  Cantrip, session/workspace, Clay, and Graf evidence.
+$  saved-state-8
  $:  %viki-familiar-state-v8
      state=state-any
      workers=worker-organ:vw
      bridge=bridge-organ-1:vb
      tensor=organ:vto
      seats=organ:vsl
      modelio=organ:vmi
      registry=registry:mr
      intents=organ:itn
  ==
::  v9: the model-bridge shadow is per-seat -- bridge-organ now embeds
::  bridge-state-v2 (ports as a map).  Everything else is v8 unchanged.
+$  saved-state
  $:  %viki-familiar-state-v9
      state=state-any
      workers=worker-organ:vw
      bridge=bridge-organ:vb
      tensor=organ:vto
      seats=organ:vsl
      modelio=organ:vmi
      registry=registry:mr
      intents=organ:itn
  ==
+$  route-update
  [revision=@ud routes=(list model-route) history=(list route-change)]
+$  saved-state-10
  ::  Preserve the complete v9 envelope. This journal only reserves explicit
  ::  decisions and observes Graf retention; it grants no landing authority.
  [%viki-familiar-state-v10 legacy=saved-state connected=ledger:vcj]
+$  saved-state-11
  ::  Only provider/session configuration is new. Coordinator, Graf and Clay
  ::  retain execution, evidence and source; no second job journal lives here.
  [%viki-familiar-state-v11 legacy=saved-state-10 moons=(list moon-route:vr)]
+$  saved-state-12
  ::  Saved callback references are Viki's continuation, not another copy of
  ::  coordinator, compiler or Cantrip effect authority. Restore observes only.
  [%viki-familiar-state-v12 legacy=saved-state-11 coding=organ:gcl]
+$  saved-state-13
  [%viki-familiar-state-v13 legacy=saved-state-12 projects=organ:gpl]
+$  saved-state-14
  ::  Versioned prepared inputs preserve every v1 noun and root/child entry.
  [%viki-familiar-state-v14 legacy=saved-state-11 coding=organ:gcl projects=organ:gpl]
+$  saved-state-15
  ::  Compiler rejection continuations extend the flow; old entries stay exact.
  [%viki-familiar-state-v15 legacy=saved-state-11 coding=organ:gcl projects=organ:gpl]
+$  saved-state-16
  [%viki-familiar-state-v16 legacy=saved-state-15 development=organ:devc]
+$  saved-state-17
  [%viki-familiar-state-v17 legacy=saved-state-16 native-coding=state-1:ncode]
+$  saved-state-18
  [%viki-familiar-state-v18 legacy=saved-state-16 native-coding=state:ncode]
+$  saved-state-19
  [%viki-familiar-state-v19 legacy=saved-state-18 reviews=state:nreview]
+$  saved-state-20
  [%viki-familiar-state-v20 legacy=saved-state-19 workspace=state:nworkspace]
+$  saved-state-21
  [%viki-familiar-state-v21 legacy=saved-state-20 openings=ledger-v1:nopening]
+$  saved-state-22
  [%viki-familiar-state-v22 legacy=saved-state-21 campaigns=state-v1:ncampaign]
+$  saved-state-23
  [%viki-familiar-state-v23 legacy=saved-state-22 onboarding=state:nonboard]
+$  saved-state-24
  [%viki-familiar-state-v24 legacy=saved-state-23 settlements=state:nfinish]
+$  saved-state-25
  [%viki-familiar-state-v25 legacy=saved-state-24 session-workspaces=state:nsession-workspace]
+$  saved-state-26
  [%viki-familiar-state-v26 legacy=saved-state-25 campaigns=state:ncampaign]
+$  saved-state-27
  [%viki-familiar-state-v27 legacy=saved-state-26 openings=ledger:nopening]
+$  saved-state-28
  [%viki-familiar-state-v28 legacy=saved-state-27 completions=state:ncompletion]
+$  saved-state-29
  [%viki-familiar-state-v29 legacy=saved-state-28 campaigns=state:nccampaign reviewed=state:ncreviewed]
::  v30 carries v29 unchanged. The native-coding tool-args/operation unions
::  widened (the `patches` multi-file candidate tool, 2026-10-31); the load
::  guard requires a versioned save for that, not a code-only reload.
+$  saved-state-30
  [%viki-familiar-state-v30 legacy=saved-state-29 carried=~]
::  v31 preserves v30 DATA while admitting atomic create/replace requests.
+$  saved-state-31
  [%viki-familiar-state-v31 legacy=saved-state-30 carried=~]
+$  pending-recovery
  [pending=(unit flight) cards=(list card)]
+$  awaiting-search  [gid=gid:gol id=@t key=*]
+$  bridge-observation  [ready=? protocol=(unit @tas) busy=?]
+$  retry-candidate
  [goal=goal:gol search=search:ves prior=derivation:dvn key=*]
+$  resolved-search  [id=@t key=*]
+$  retry-prior  [search=search:ves prior=derivation:dvn]
+$  compared-result
  $:  chosen=derivation:dvn
      verdict=verdict:satisfy
      refs=(list @t)
      comparison=(unit comparison:vc)
  ==
+$  command  [%say line=@t]
::  this familiar's name on the thread.
++  fid  ^-(@t 'viki')
::  DEFAULTS, and they are exactly the numbers the operator has not
::  ruled on yet.  Named here, in one place, so changing them is a
::  decision rather than an archaeology expedition.
++  default-every   ^-(@dr ~m5)           ::  how often it wakes
++  default-budget  ^-(@ud 3)             ::  self-directed wants per arming
++  max-route-history  ^-(@ud 16)
++  moon  ^-(@p ~bacden-ripmyl-dashus-navnul)
++  default-route  ^-(model-route [%local moon])
::  the oracle and law a want is built under.  Until canon engraves the
::  oracle law, the worker's own held law decides -- viki asks with the
::  law it believes and the moon refuses if it is wrong.  A refusal is
::  a FACT, so being wrong here is recorded, not silent.
++  ask-law  ^-(gen-law:dvn [%greedy 256 %chatml ~])
::  Viki's own view of the canon-held law, and the ask-law a purpose
::  must cite under it.  Viki asks with the law it believes; the worker
::  refuses if it is wrong -- a refusal is a FACT.
++  canon-held-view
  |=  [our=@p now=@da]
  ^-  held:cl
  =/  canon=(list [src=* kind=@tas dst=*])
    =/  r
      ?.  (agent-live:vsg our now %graf)  [%| ~]
      %-  mule  |.
      ;;  (list [src=* kind=@tas dst=*])
      %~  tap  in
      .^((set *) %gx /(scot %p our)/graf/(scot %da now)/canon/noun)
    ?-(-.r %& p.r, %| ~)
  (held-from-canon:cl pre-canon-held:cl canon)
++  law-for-purpose
  |=  [h=held:cl p=@tas base=gen-law:dvn]
  ^-  gen-law:dvn
  =/  vid  (~(get by pres.h) p)
  ?~  vid  base
  =/  known  (~(get by vocabs.h) u.vid)
  ?~  known  base
  base(vocab `[u.vid root.u.known])
++  init-judgments  ^-(judgment-chain init:bjc)
++  trusted-judgment-authority
  |=  ship=@p
  ^-  judgment-authority
  (trusted-authority:bjc ship)
++  append-judgment
  |=  [log=judgment-chain judgment=bound-judgment:bj authority=judgment-authority]
  ^-  (unit judgment-chain)
  (append:bjc log judgment authority)
++  graf-poke
  |=  [our=@p act=*]
  ^-  card
  [%pass /graf %agent [our %graf] %poke %graf-action !>(act)]
++  light-card
  |=  [our=@p f=*]
  ^-  card
  (graf-poke our [%light f])
::  ---- THE DOOR'S JUDGMENT IS VIKI'S (roadmap 34) ----
::
::  Cantrip publishes every inbox entry on /multiplayer.  Viki watches, and for
::  each %pending move whose origin is a2a:<principal> it applies the door law
::  (lib/a2a-judgment) over facts it reads itself, then issues the verdict as
::  cantrip's own transition and records it in Graf.  The door never judges;
::  it labors on %accepted.
++  a2a-watch-card
  |=  our=@p
  ^-  card
  [%pass /a2a-judge %agent [our %cantrip] %watch /multiplayer]
++  a2a-peek
  |=  [our=@p now=@da app=@tas =path]
  ^-  (unit *)
  ?.  .^(? %gu /(scot %p our)/[app]/(scot %da now)/$)  ~
  =/  read=(each * tang)
    %-  mule
    |.(.^(* %gx (weld /(scot %p our)/[app]/(scot %da now) (weld path /noun))))
  ?:(?=(%| -.read) ~ `p.read)
++  a2a-facts
  |=  [our=@p now=@da who=@t intent=@t]
  ^-  facts:aj
  =/  trusted=?
    =/  r  (a2a-peek our now %a2a /trusted)
    ?~  r  %.n
    ?~  ((soft (list @t)) u.r)  %.n
    ?=(^ (find ~[who] ;;((list @t) u.r)))
  =/  live=@ud
    =/  r  (a2a-peek our now %a2a /live/[`@ta`who])
    ?~  r  0
    ?~  ((soft @ud) u.r)  0
    ;;(@ud u.r)
  =/  ceiling=@tas
    =/  r  (a2a-peek our now %cantrip /law/ceiling)
    ?~  r  %closed
    ?~  ((soft @tas) u.r)  %closed
    ;;(@tas u.r)
  =/  ready=?
    =/  r  (a2a-peek our now %model-bridge /peer/protocol)
    ?~  r  %.n
    ?~  ((soft (unit @tas)) u.r)  %.n
    ?=(^ ;;((unit @tas) u.r))
  [trusted (met 3 intent) ceiling live ready]
++  a2a-verdict-cards
  |=  [our=@p now=@da entry=mp-inbox-entry:ct]
  ^-  (list card)
  =/  move=mp-move:ct  move.entry
  ?.  ?=(%pending status.entry)  ~
  ?~  origin.move  ~
  =/  o=tape  (trip u.origin.move)
  ?.  &((gth (lent o) 4) =("a2a:" (scag 4 o)))  ~
  =/  who=@t  (crip (slag 4 o))
  =/  intent=@t  ?:(?=(%task-share -.payload.move) intent.payload.move '')
  =/  f=facts:aj  (a2a-facts our now who intent)
  =/  v=verdict:aj  (judge:aj f)
  =/  act=*
    ?-  v
      %accept  [%accept-mp-move move-id.move]
      %hold    [%hold-mp-move move-id.move]
      %refuse  [%refuse-mp-move move-id.move (reason-text:aj v f)]
    ==
  :~  [%pass /a2a-judge/verdict %agent [our %cantrip] %poke %cantrip-action !>(act)]
      (publish-card our [[%a2a move-id.move] %verdict v])
  ==
++  publish-card
  |=  [our=@p r=rel:dvn]
  ^-  card
  (graf-poke our [%publish %viki r])
++  record-card
  |=  [our=@p kind=@tas id=@t]
  ^-  card
  [%pass /rec %agent [our %cantrip] %poke %cantrip-action !>([%record kind id 0])]
++  record-cards
  |=  [our=@p kind=@tas id=@t]
  ^-  (list card)
  ::  Graf citation first, then the Cantrip cache trigger.  The exact same
  ::  [kind id body] noun is both evidence and action payload.
  ~[(light-card our [kind id 0]) (record-card our kind id)]
++  publish-plan-cards
  |=  [our=@p p=plan:pln ask=ask:dvn]
  ^-  (list card)
  =/  cards=(list card)  ~[(light-card our (fact:pln p))]
  =/  cards
    %+  weld  cards
    %+  turn  (relations:pln p)
    |=(relation=rel:gol (publish-card our relation))
  (snoc cards (publish-card our (serves-rel:dvn ask goal.p)))
++  weight-inquiry-cards
  |=  [our=@p item=inquiry:vwi]
  ^-  (list card)
  =/  cards=(list card)  ~[(light-card our (inquiry-fact:vwi item))]
  %+  weld  cards
  %+  turn  (inquiry-relations:vwi item)
  |=(relation=rel:dvn (publish-card our relation))
++  weight-ratification-cards
  |=  [our=@p admission=admission:vwr]
  ^-  (list card)
  =/  cards=(list card)  ~[(light-card our hypothesis.admission)]
  %+  weld  cards
  %+  turn  relations.admission
  |=(relation=rel:dvn (publish-card our relation))
++  goal-submission-cards
  |=  [our=@p admission=admission:vgs]
  ^-  (list card)
  ?.  created.admission  ~
  :~  (light-card our (goal-fact:gol record.admission))
      (publish-card our (status-rel:gol gid.record.admission %planning))
  ==
++  goal-ratification-cards
  |=  [our=@p admission=admission:vgr]
  ^-  (list card)
  =/  cards=(list card)  ~[(light-card our (fact:vgr record.admission))]
  %+  weld  cards
  %+  turn  relations.admission
  |=(relation=rel:dvn (publish-card our relation))
++  derivation-judgment-cards
  |=  [our=@p judgment=judgment:vj d=derivation:dvn verdict=verdict:satisfy continuing=?]
  ^-  (list card)
  =/  cards=(list card)  ~[(light-card our (fact:vj judgment))]
  =/  continuation=(unit continuation:vj)
    (continuation-for:vj judgment continuing)
  =/  cards
    ?~  continuation  cards
    (snoc cards (light-card our (continuation-fact:vj u.continuation)))
  ?~  goal.judgment  cards
  %+  weld  cards
  %+  turn  (derivation-goal-relations:vj u.goal.judgment d verdict continuing)
  |=(relation=rel:gol (publish-card our relation))
++  refusal-judgment-cards
  |=  [our=@p judgment=judgment:vj]
  ^-  (list card)
  =/  cards=(list card)  ~[(light-card our (fact:vj judgment))]
  =/  continuation=(unit continuation:vj)
    (continuation-for:vj judgment %.n)
  =/  cards
    ?~  continuation  cards
    (snoc cards (light-card our (continuation-fact:vj u.continuation)))
  ?~  goal.judgment  cards
  %+  weld  cards
  %+  turn  (refusal-goal-relations:vj u.goal.judgment)
  |=(relation=rel:gol (publish-card our relation))
++  tick-card
  |=  [now=@da every=@dr]
  ^-  card
  [%pass /tick %arvo %b %wait (add now every)]
++  landing-retry-card
  |=  [now=@da every=@dr]
  ^-  card
  [%pass /landing-retry %arvo %b %wait (add now every)]
::  Model selection belongs to Viki.  Cantrip binds the request produced from
::  that selection; neither the local moon nor a connected transport chooses
::  its own identity after dispatch.
++  route-allowed
  |=  [our=@p route=model-route]
  ^-  ?
  ?.  (route-valid:vr route)  %.n
  ?-  -.route
    %local
      ?&  !=(our organ.route)
          =(our (^sein:title organ.route))
      ==
    %connected  %.y
  ==
++  primary-route
  |=  routes=(list model-route)
  ^-  model-route
  ?~  routes  default-route
  i.routes
++  active-route
  |=  [routes=(list model-route) round=(unit candidate-round)]
  ^-  model-route
  ?~  round  (primary-route routes)
  =/  active=(unit candidate-call)  (current:cr u.round)
  ?~  active  (primary-route routes)
  route.u.active
++  oracle-for-route
  |=  route=model-route
  ^-  oracle-id:dvn
  ?-  -.route
    %local      pre-canon-oracle:cl
    %connected  oracle.config.route
  ==
++  routes-allowed
  |=  [our=@p routes=(list model-route)]
  ^-  ?
  =/  count=@ud  (lent routes)
  =/  keys=(list @ux)
    %+  turn  routes
    |=(route=model-route `@ux`(shax (jam (oracle-for-route route))))
  =/  unique=(set @ux)  (~(gas in *(set @ux)) keys)
  ?&  (gth count 0)
      (lte count max-calls:cr)
      (levy routes |=(route=model-route (route-allowed our route)))
      =(count (lent ~(tap in unique)))
  ==
++  request-for-route-output
  |=  [route=model-route want=want:dvn output=output-space:vi]
  ^-  request-v2:vi
  ?-  -.route
    %local  (request-for:vi want local-smollm2-backend:vi output ~m5)
    %connected
      =/  provider=(unit @tas)
        (slaw %tas provider-id.spec.config.route)
      ?>  ?=(^ provider)
      %-  request-for:vi
      :*  want
          [%connected u.provider tag.oracle.config.route (scot %ux wgt.oracle.config.route)]
          output
          ~m5
      ==
  ==
++  request-for-route
  |=  [route=model-route want=want:dvn]
  ^-  request-v2:vi
  (request-for-route-output route want [%text max.law.ask.want])
++  model-timeout-card
  |=  held=flight
  ^-  card
  [%pass /model-timeout/(scot %ux request-id.request.held) %arvo %b %wait (add sent.held timeout.request.held)]
++  cancel-timeout-card
  |=  held=flight
  ^-  card
  [%pass /model-timeout/(scot %ux request-id.request.held) %arvo %b %rest (add sent.held timeout.request.held)]
++  local-model-card
  |=  [organ=@p request=request-v2:vi]
  ^-  card
  :*  %pass
      /model
      %agent
      [organ %viki-model]
      %poke
      %viki-inference
      !>(`action:vi`[%derive request])
  ==
++  bridge-request
  |=  held=flight
  ^-  model-bridge-request:mb
  =/  request-id=@t  (scot %ux request-id.request.held)
  =/  session-id=@t  fid.t.held
  =/  parent=@t
    (rap 3 ~[fid.t.held ':' (scot %ud n.t.held)])
  =/  commitment=@t
    (scot %ux `@ux`(shax (jam context.body.constraint.request.held)))
  :*  %1
      request-id
      session-id
      parent
      (connected-body:vi request.held)
      commitment
      (scot %ux digest.constraint.request.held)
  ==
++  bridge-watch-card
  |=  [our=@p held=flight]
  ^-  card
  =/  request-id=@t  (scot %ux request-id.request.held)
  =/  session-id=@t  fid.t.held
  [%pass /model-bridge/[session-id]/[request-id] %agent [our %model-bridge] %watch /request/[session-id]/[request-id]]
++  bridge-request-card
  |=  [our=@p config=connected-route held=flight]
  ^-  card
  =/  request=model-bridge-request:mb  (bridge-request held)
  :*  %pass
      /model-bridge-request/[request-id.request]
      %agent
      [our %model-bridge]
      %poke
      %model-bridge-action
      !>(`model-bridge-action:mb`[%submit spec.config request])
  ==
++  bridge-leave-card
  |=  [our=@p held=flight]
  ^-  card
  =/  request-id=@t  (scot %ux request-id.request.held)
  =/  session-id=@t  fid.t.held
  [%pass /model-bridge/[session-id]/[request-id] %agent [our %model-bridge] %leave ~]
++  bridge-cancel-card
  |=  [our=@p held=flight why=@t]
  ^-  card
  =/  request-id=@t  (scot %ux request-id.request.held)
  =/  session-id=@t  fid.t.held
  =/  cancel=model-bridge-cancel:mb
    [%1 request-id session-id why]
  [%pass /model-bridge-cancel/[request-id] %agent [our %model-bridge] %poke %model-bridge-action !>(`model-bridge-action:mb`[%cancel cancel])]
++  start-model-cards
  |=  [our=@p route=model-route held=flight]
  ^-  (list card)
  ::  Recheck the actual dispatched route, including a retained round's route.
  ?>  (route-allowed our route)
  =/  transport=(list card)
    ?-  -.route
      %local  ~[(local-model-card organ.route request.held)]
      %connected
        :~  (bridge-watch-card our held)
            (bridge-request-card our config.route held)
        ==
    ==
  (snoc transport (model-timeout-card held))
++  refusal-result
  |=  [our=@p now=@da held=flight why=@tas]
  ^-  result:vi
  (bind-result:vi request.held [%no `refusal:dvn`[ask.want.held why our now]])
++  bridge-error-why
  |=  code=model-bridge-error-code:mb
  ^-  @tas
  ?-  code
    %not-ready        %model-not-ready
    %busy             %busy
    %invalid-request  %invalid-request
    %transport        %transport
    %process          %process
    %protocol         %protocol
    %timeout          %timed-out
    %cancelled        %cancelled
  ==
++  bridge-event-result
  |=  [our=@p now=@da config=connected-route held=flight event=model-bridge-event:mb]
  ^-  (unit result:vi)
  =/  request=model-bridge-request:mb  (bridge-request held)
  ?.  (model-bridge-event-matches-request:mb spec.config request event)
    ~
  ?-  -.event
    %ready      ~
    %accepted   ~
    %error
      `(refusal-result our now held (bridge-error-why code.error.event))
    %cancelled
      `(refusal-result our now held %cancelled)
    %result
      ?.  (request-accepts-text:vi request.held content.result.event)
        `(refusal-result our now held %invalid-output)
      =/  derivation=derivation:dvn
        :*  ask.want.held
            ~
            content.result.event
            `@ux`(shax (jam result.event))
            %eos
            our
            ~
            now
        ==
      `(bind-result:vi request.held [%ok derivation])
  ==
++  flight-for
  |=  [route=model-route t=turn-id:fam want=want:dvn now=@da]
  ^-  flight
  [t want (request-for-route route want) now ~]
++  migrate-flight-1
  |=  old=flight-1
  ^-  flight
  [t.old want.old (local-request:vi want.old) at.want.old ~]
++  migrate-flight-2
  |=  old=flight-2
  ^-  flight
  [t.old want.old (local-request:vi want.old) at.want.old result.old]
++  reserve-pending-head
  |=  [head=@ud pending=(unit flight)]
  ^-  @ud
  ?~  pending  head
  (max head +(n.t.u.pending))
++  normalize-state
  |=  old=state-10
  ^-  state-10
  old(head (reserve-pending-head head.old pending.old))
++  lift-state-9
  |=  old=state-9
  ^-  state-10
  :*  %10  armed.old  head.old  pending.old  routes.old  round.old
      retry-policy.old  budget.old  every.old  said.old  seen.old
      judgments.old  last-reconsideration.old  reconsideration.old  0  ~
  ==
++  lift-state-8
  |=  old=state-8
  ^-  state-10
  %-  lift-state-9
  :*  %9  armed.old  head.old  pending.old  routes.old  round.old
      retry-policy.old  budget.old  every.old  said.old  seen.old
      judgments.old  ~  ~
  ==
++  route-update-for
  |=  $:  kind=route-change-kind
          revision=@ud
          history=(list route-change)
          previous=(list model-route)
          next=(list model-route)
          target=(unit @ud)
          at=@da
      ==
  ^-  route-update
  =/  next-revision=@ud  +(revision)
  =/  change=route-change
    [kind next-revision at previous next target]
  :*  next-revision
      next
      (scag max-route-history `(list route-change)`[change history])
  ==
++  landing-card
  |=  [our=@p t=turn-id:fam result=result:vi]
  ^-  card
  :*  %pass  /landing  %agent  [our %graf]  %poke
      %viki-landing  !>(`action:vl`[%land [t result]])
  ==
++  say-card
  |=  =tape
  ^-  card
  [%shoe ~ %sole %txt tape]
++  recover-pending
  |=  $:  our=@p
          now=@da
          routes=(list model-route)
          round=(unit candidate-round)
          pending=(unit flight)
          every=@dr
      ==
  ^-  pending-recovery
  ?~  pending  [~ ~]
  =/  held=flight  u.pending
  =/  route=model-route  (active-route routes round)
  ?.  (route-allowed our route)
    ::  Reload preserves the held request for explicit operator recovery.
    ::  It must neither resend to a foreign route nor act on the saved DATA.
    [pending ~]
  ?^  result.held
    ::  INCIDENT AMNESTY (ptf-484, 2026-08-14): re-emitting the landing
    ::  from a reload crash-loops the pier — the nested landing chain dies
    ::  at gall's take (kernel-level, unfixed) and every reload re-armed
    ::  it, including the reload of the commit carrying any fix.  Until
    ::  the landing path is repaired and rig-proven, a reload DROPS a
    ::  held-but-unlanded result: the want stays open in Graf and the
    ::  moon re-derives on demand — nothing durable is lost, and the
    ::  ship stays up.  Revert this branch with the landing fix.
    ~&  >>>  [%viki %amnesty-dropped-held-result]
    [~ ~]
  =/  deadline=@da  (add sent.held timeout.request.held)
  ?:  (gte now deadline)
    =/  timed=result:vi  (refusal-result our now held %timed-out)
    =/  cleanup=(list card)
      ?-  -.route
        %local  ~
        %connected
          :~  (bridge-cancel-card our held 'viki recovered an expired model request')
              (bridge-leave-card our held)
          ==
      ==
    :-  `held(result `timed)
    %+  weld  cleanup
    :~  (landing-card our t.held timed)
        (landing-retry-card now every)
    ==
  =/  transport=(list card)
    ?-  -.route
      %local  ~[(local-model-card organ.route request.held)]
      %connected  ~[(bridge-watch-card our held)]
    ==
  [pending (snoc transport (model-timeout-card held))]
++  resume-state
  |=  [our=@p now=@da resumed=state-10]
  ^-  [state=state-10 cards=(list card)]
  ::  Behn waits are transient.  Restore one regular tick for an armed
  ::  familiar, then resume exactly the one durable in-flight operation.
  =/  cards=(list card)
    :-  (a2a-watch-card our)
    ?:(armed.resumed ~[(tick-card now every.resumed)] ~)
  =/  recovered=pending-recovery
    (recover-pending our now routes.resumed round.resumed pending.resumed every.resumed)
  [resumed(pending pending.recovered) (weld cards cards.recovered)]
::  THE TURN LANDING.  A turn's relations are emitted TOGETHER with
::  whatever fact it carries -- a turn that lands without its %follows
::  link is a break in the chain, and a derivation that lands without
::  its index is a want that will be derived twice.
::
::  ---------------------------------------------------------------
::  THE GRAF READS.  Header core, not the door, and every one is
::  mule-guarded: a tick that CRASHES on an absent agent is worse than
::  one that rests, because a crash leaves no link in the thread.
::
::  Cost, measured on the live ship: /x/by-kind filters IN-LOOM and
::  returns only matches (0.56s over conn for a kind with 10 facts
::  among 29.872), so the familiar never ships the whole floor to find
::  its goals.  /x/health gives the count for free.  At the default
::  five-minute tick this is nothing; if the tick ever drops toward
::  seconds, revisit.
++  facts-count
  |=  [our=@p now=@da]
  ^-  @ud
  =/  r
    ?.  (agent-live:vsg our now %graf)  [%| ~]
    %-  mule
    |.  ^-  @ud
        =/  h  .^(* %gx /(scot %p our)/graf/(scot %da now)/health/noun)
        ?.  ?=([@ @ @ @ @ *] h)  0
        `@ud`+<+<.h
  ?-(-.r %& p.r, %| 0)
::  Every goal-shaped fact, including unattributed historical rows.  This
::  surface reserves their ids and feeds operator views; it does not grant
::  them execution authority.
++  goal-entries-on-floor
  |=  [our=@p now=@da]
  ^-  (list goal-entry:gol)
  =/  r
    ?.  (agent-live:vsg our now %graf)  [%| ~]
    %-  mule
    |.  ^-  (list *)
        .^((list *) %gx /(scot %p our)/graf/(scot %da now)/by-kind/goal/noun)
  =/  fs=(list *)  ?-(-.r %& p.r, %| ~)
  %+  murn  fs
  |=(f=* (goal-entry-of:gol f))
::
::  The cognition loop receives only attributable goals.  A bare historical
::  row stays visible but cannot silently become an autonomous instruction.
++  goals-on-floor
  |=  [our=@p now=@da]
  ^-  (list goal:gol)
  %+  murn  (goal-entries-on-floor our now)
  |=(entry=goal-entry:gol (goal-from-entry:gol entry))
::  viki's own published slot: its plan, its index, its thread.
++  my-slot
  |=  [our=@p now=@da]
  ^-  (set rel:dvn)
  =/  r
    ?.  (agent-live:vsg our now %graf)  [%| ~]
    %-  mule
    |.  ^-  (set rel:dvn)
        .^  (set rel:dvn)  %gx
            /(scot %p our)/graf/(scot %da now)/slot/viki/noun
        ==
  ?-(-.r %& p.r, %| *(set rel:dvn))
++  reconsideration-offer
  |=  [our=@p now=@da]
  ^-  (unit @ux)
  =/  r=(each (unit @ux) tang)
    ?.  (agent-live:vsg our now %waterwheel)  [%| ~]
    %-  mule
    |.  .^  (unit @ux)  %gx
            /(scot %p our)/waterwheel/(scot %da now)/viki/reconsideration/noun
        ==
  ?-(-.r %& p.r, %| ~)
++  reconsideration-by-id
  |=  [our=@p now=@da id=@ux]
  ^-  (unit reconsideration:vj)
  =/  r=(each (list *) tang)
    ?.  (agent-live:vsg our now %graf)  [%| ~]
    %-  mule
    |.  .^  (list *)  %gx
            /(scot %p our)/graf/(scot %da now)/by-id/viki-reconsideration/(scot %ux id)/noun
        ==
  =/  rows=(list *)  ?-(-.r %& p.r, %| ~)
  ?~  rows  ~
  ?^  t.rows  ~
  ?.  ?=([%viki-reconsideration @ *] i.rows)  ~
  ?.  =((scot %ux id) `@t`+<.i.rows)  ~
  =/  found=(unit reconsideration:vj)
    ((soft reconsideration:vj) +>.i.rows)
  ?~  found  ~
  ?.  =(id (reconsideration-id:vj u.found))  ~
  found
++  reconsideration-work-for
  |=  [our=@p now=@da id=@ux]
  ^-  (unit reconsideration-work)
  =/  found=(unit reconsideration:vj)
    (reconsideration-by-id our now id)
  ?~  found  ~
  ?~  targets.u.found  ~
  `[id targets.u.found]
++  discover-reconsideration
  |=  [our=@p now=@da last=(unit @ux)]
  ^-  [last=(unit @ux) work=(unit reconsideration-work)]
  =/  offered=(unit @ux)  (reconsideration-offer our now)
  ?~  offered  [last ~]
  ?:  ?&  ?=(^ last)  =(u.last u.offered)  ==  [last ~]
  =/  work=(unit reconsideration-work)
    (reconsideration-work-for our now u.offered)
  ?~  work  [last ~]
  [`u.offered work]
++  max-reconsideration-continuations  256
++  reconsideration-target-current
  |=  [our=@p now=@da target=reconsideration-target:vj]
  ^-  ?
  =/  r=(each (list *) tang)
    ?.  (agent-live:vsg our now %graf)  [%| ~]
    %-  mule
    |.  .^  (list *)  %gx
            /(scot %p our)/graf/(scot %da now)/by-kind/viki-continuation/noun
        ==
  ?-  -.r
    %|  %.n
    %&
      ?:  (gth (lent p.r) max-reconsideration-continuations)  %.n
      =/  pairs=(list [@ux continuation:vj])
        %+  murn  p.r
        |=  row=*
        ^-  (unit [@ux continuation:vj])
        ?.  ?=([%viki-continuation @ *] row)  ~
        =/  found=(unit continuation:vj)
          ((soft continuation:vj) +>.row)
        ?~  found  ~
        =/  id=@ux  (continuation-id:vj u.found)
        ?.  =((scot %ux id) `@t`+<.row)  ~
        `[id u.found]
      ?.  =((lent pairs) (lent p.r))  %.n
      =/  latest=(list reconsideration-target:vj)
        (retryable-targets:vrec (~(gas by *(map @ux continuation:vj)) pairs))
      (lien latest |=(item=reconsideration-target:vj =(item target)))
  ==
++  advance-reconsideration
  |=  work=reconsideration-work
  ^-  (unit reconsideration-work)
  =/  rest=(list reconsideration-target:vj)
    (slag 1 targets.work)
  ?~  rest  ~
  `[id.work rest]
++  awaiting-search-for
  |=  [slot=(set rel:dvn) gid=gid:gol]
  ^-  (unit awaiting-search)
  =/  l=(list rel:dvn)  ~(tap in slot)
  |-
  ?~  l  ~
  =/  r=rel:dvn  i.l
  ?.  =(%awaiting-evidence kind.r)  $(l t.l)
  ?.  =((goal-key:gol gid) src.r)  $(l t.l)
  ?.  ?=([%viki-evidence-search @] dst.r)  $(l t.l)
  ?:  (resolved-key:ves slot dst.r)  $(l t.l)
  `[gid +.dst.r dst.r]
++  search-by-id
  |=  [our=@p now=@da id=@t]
  ^-  (unit search:ves)
  =/  r
    ?.  (agent-live:vsg our now %graf)  [%| ~]
    %-  mule
    |.  ^-  (list *)
        .^  (list *)  %gx
            /(scot %p our)/graf/(scot %da now)/by-id/viki-evidence-search/[id]/noun
        ==
  =/  rows=(list *)  ?-(-.r %& p.r, %| ~)
  ?~  rows  ~
  ?^  t.rows  ~
  ?.  ?=([%viki-evidence-search @ *] i.rows)  ~
  ?.  =(id `@t`+<.i.rows)  ~
  =/  found=(unit search:ves)  ((soft search:ves) +>.i.rows)
  ?~  found  ~
  ?.  =(id (scot %ux (sid:ves u.found)))  ~
  found
++  resolved-search-for
  |=  [slot=(set rel:dvn) ask=ask:dvn]
  ^-  (unit resolved-search)
  =/  matches=(list resolved-search)
    %+  murn  ~(tap in slot)
    |=  r=rel:dvn
    ^-  (unit resolved-search)
    ?.  =(%resolved-by kind.r)  ~
    ?.  =((ask-key:dvn ask) dst.r)  ~
    ?.  ?=([%viki-evidence-search @] src.r)  ~
    `[+.src.r src.r]
  ?~  matches  ~
  ?^  t.matches  ~
  `i.matches
++  retry-prior-for
  |=  [our=@p now=@da slot=(set rel:dvn) held=flight]
  ^-  (unit retry-prior)
  ?.  =(%retry-evidence purpose.want.held)  ~
  =/  resolved=(unit resolved-search)
    (resolved-search-for slot ask.want.held)
  ?~  resolved  ~
  =/  search=(unit search:ves)  (search-by-id our now id.u.resolved)
  ?~  search  ~
  ?.  =(key.u.resolved (key:ves u.search))  ~
  =/  prior=(unit derivation:dvn)  (derivation-by slot aid.u.search)
  ?~  prior  ~
  ?.  =(result-hash.u.search `@ux`(shax (jam u.prior)))  ~
  `[u.search u.prior]
++  retry-candidate-for
  |=  $:  our=@p
          now=@da
          slot=(set rel:dvn)
          goals=(list goal:gol)
          waiting=awaiting-search
      ==
  ^-  (unit retry-candidate)
  =/  search=(unit search:ves)  (search-by-id our now id.waiting)
  ?~  search  ~
  ?.  =(key.waiting (key:ves u.search))  ~
  ?~  goal.u.search  ~
  ?.  =(gid.waiting u.goal.u.search)  ~
  ?~  fresh.u.search  ~
  =/  prior=(unit derivation:dvn)  (derivation-by slot aid.u.search)
  ?~  prior  ~
  ?.  =(result-hash.u.search `@ux`(shax (jam u.prior)))  ~
  =/  goal=(unit goal:gol)  (goal-by goals gid.waiting)
  ?~  goal  ~
  `[u.goal u.search u.prior key.waiting]
++  attempts-for
  |=  [slot=(set rel:dvn) gid=gid:gol]
  ^-  @ud
  %-  lent
  %+  skim  ~(tap in slot)
  |=  r=rel:dvn
  ?&  =(%serves kind.r)
      =((goal-key:gol gid) dst.r)
  ==
++  resolve-search-cards
  |=  [our=@p key=* gid=gid:gol outcome=* why=reason:gol]
  ^-  (list card)
  :~  (publish-card our (resolution-rel-key:ves key outcome))
      (publish-card our (blocked-rel:gol gid why))
      (publish-card our (status-rel:gol gid %blocked))
  ==
++  open-wants
  |=  slot=(set rel:dvn)
  ^-  (list want:dvn)
  =/  l=(list rel:dvn)  ~(tap in slot)
  |-  ^-  (list want:dvn)
  ?~  l  ~
  ?.  =(%wanted-by kind.i.l)  $(l t.l)
  ?.  ?=([%want *] dst.i.l)   $(l t.l)
  =/  w  ((soft want:dvn) +.dst.i.l)
  ?~  w  $(l t.l)
  ?^  (find-answer:dvn slot ask.u.w)   $(l t.l)
  ?^  (find-refusal:dvn slot ask.u.w)  $(l t.l)
  [u.w $(l t.l)]
::  a goal is closed to model work once it awaits ratification, is ratified,
::  or is blocked.  Anything else -- including a goal nobody has touched yet
::  -- is open, which is how a goal lit across the membrane becomes work.
++  closed-gids
  |=  [slot=(set rel:dvn) retry=(unit gid:gol)]
  ^-  (set gid:gol)
  %-  ~(gas in *(set gid:gol))
  %+  murn  ~(tap in slot)
  |=  r=rel:dvn
  ^-  (unit gid:gol)
  ?:  =(%awaiting-evidence kind.r)
    ?.  ?=([%goal @] src.r)  ~
    ?:  (resolved-key:ves slot dst.r)  ~
    ?:  ?&  ?=(^ retry)  =(u.retry +<.src.r)  ==  ~
    `+<.src.r
  ?.  =(%status kind.r)  ~
  ?.  ?=([%goal @] src.r)  ~
  ?.  ?=([%status @] dst.r)  ~
  ?.  ?|  =(%awaiting-ratification +.dst.r)
          =(%ratified +.dst.r)
          =(%blocked +.dst.r)
      ==
    ~
  `+<.src.r
++  open-goal-ids
  |=  [gs=(list goal:gol) slot=(set rel:dvn) retry=(unit gid:gol)]
  ^-  (list gid:gol)
  =/  shut  (closed-gids slot retry)
  =/  open=(list gid:gol)
    %+  skim  (turn gs |=(g=goal:gol gid.g))
    |=(g=gid:gol !(~(has in shut) g))
  ?~  retry  open
  ::  Finish a search already paid for before opening unrelated work.  The
  ::  gid tie-break keeps the order total and deterministic.
  %+  sort  open
  |=  [a=gid:gol b=gid:gol]
  =/  aw=?  ?=(^ (awaiting-search-for slot a))
  =/  bw=?  ?=(^ (awaiting-search-for slot b))
  ?:  !=(aw bw)  aw
  (aor a b)
::  a derivation that came home but was never threaded -- the recovery
::  path after a crash between landing and judging.  Normally empty,
::  because viki judges on receipt.
++  unjudged
  |=  slot=(set rel:dvn)
  ^-  (list derivation-ref:tick)
  =/  threaded=(set @ux)
    %-  ~(gas in *(set @ux))
    %+  murn  ~(tap in slot)
    |=  r=rel:dvn
    ^-  (unit @ux)
    ?.  =(%derived-by kind.r)  ~
    ?.  ?=([%derivation *] dst.r)  ~
    =/  d  ((soft derivation:dvn) +.dst.r)
    ?~(d ~ `(aid:dvn ask.u.d))
  %+  murn  ~(tap in slot)
  |=  r=rel:dvn
  ^-  (unit derivation-ref:tick)
  ?.  =(%answered-by kind.r)  ~
  ?.  ?=([%derivation *] dst.r)  ~
  =/  d  ((soft derivation:dvn) +.dst.r)
  ?~  d  ~
    =/  k  (aid:dvn ask.u.d)
    ?:  (~(has in threaded) k)  ~
    =/  goal  (find-goal:dvn slot ask.u.d)
    `[k ?~(goal '' u.goal)]
::  Ask Graf for the already-bounded evidence packet.  Graf never pays its
::  38s slow rebuild on this path; a stale index produces an explicit gap
::  and an empty ref list, so Viki keeps moving without pretending it saw
::  evidence that was not available.
++  recall-for
  |=  [our=@p now=@da query=@t]
  ^-  (list ref:ask-build)
  =/  r
    ?.  (agent-live:vsg our now %graf)  [%| ~]
    %-  mule
    |.  ^-  packet:gep
        .^(packet:gep %gx /(scot %p our)/graf/(scot %da now)/evidence/(scot %ud 3)/[query]/noun)
  ?-  -.r
    %&  refs.p.r
    %|  ~
  ==
++  graf-cockpit-for
  |=  [our=@p now=@da billed=?]
  ^-  (unit snapshot:gc)
  ?.  billed  ~
  =/  r
    ?.  (agent-live:vsg our now %graf)  [%| ~]
    %-  mule
    |.  ^-  snapshot:gc
        .^(snapshot:gc %gx /(scot %p our)/graf/(scot %da now)/cockpit/noun)
  ?-  -.r
    %&  `p.r
    %|  ~
  ==
++  frag-cockpit-for
  |=  [our=@p now=@da billed=?]
  ^-  (unit snapshot:fc)
  ?.  billed  ~
  =/  r
    ::  short-circuit to a mule-shaped FAILURE so the ?- below takes this
    ::  arm's own default, unchanged.  See +agent-live: mule cannot catch
    ::  a scry against an agent that is not installed.
    ?.  (agent-live:vsg our now %frag)  [%| ~]
    %-  mule
    |.  ^-  snapshot:fc
        .^(snapshot:fc %gx /(scot %p our)/frag/(scot %da now)/cockpit/noun)
  ?-  -.r
    %&  `p.r
    %|  ~
  ==
++  waterwheel-cockpit-for
  |=  [our=@p now=@da billed=?]
  ^-  (unit snapshot:wwc)
  ?.  billed  ~
  =/  r
    ?.  (agent-live:vsg our now %waterwheel)  [%| ~]
    %-  mule
    |.  ^-  snapshot:wwc
        .^(snapshot:wwc %gx /(scot %p our)/waterwheel/(scot %da now)/cockpit/noun)
  ?-  -.r
    %&  `p.r
    %|  ~
  ==
++  boxy-cockpit-for
  |=  [our=@p now=@da billed=?]
  ^-  (unit snapshot:bc)
  ?.  billed  ~
  =/  r
    ?.  (agent-live:vsg our now %boxy)  [%| ~]
    %-  mule
    |.  ^-  snapshot:bc
        .^(snapshot:bc %gx /(scot %p our)/boxy/(scot %da now)/cockpit/noun)
  ?-  -.r
    %&  `p.r
    %|  ~
  ==
++  local-model-status-for
  |=  [organ=@p now=@da]
  ^-  (unit model-organ-status:vi)
  =/  r
    ?.  (agent-live:vsg organ now %viki-model)  [%| ~]
    %-  mule
    |.  ^-  model-organ-status:vi
        .^(model-organ-status:vi %gx /(scot %p organ)/viki-model/(scot %da now)/status/noun)
  ?-  -.r
    %&  `p.r
    %|  ~
  ==
++  bridge-observation-for
  |=  [our=@p now=@da]
  ^-  (unit bridge-observation)
  =/  r
    ?.  (agent-live:vsg our now %model-bridge)  [%| ~]
    %-  mule
    |.  ^-  bridge-observation
        =/  ready=?
          .^(? %gx /(scot %p our)/model-bridge/(scot %da now)/ready/noun)
        =/  protocol=(unit @tas)
          .^((unit @tas) %gx /(scot %p our)/model-bridge/(scot %da now)/peer/protocol/noun)
        =/  busy=?
          .^(? %gx /(scot %p our)/model-bridge/(scot %da now)/pending/noun)
        [ready protocol busy]
  ?-  -.r
    %&  `p.r
    %|  ~
  ==
++  route-readiness-for
  |=  [our=@p now=@da route=model-route]
  ^-  route-readiness:vco
  ?-  -.route
    %local
      =/  observed=(unit model-organ-status:vi)
        ::  %gu is a host-local Gall liveness probe, not an Ames protocol.
        ::  Asking it about a moon can bail the whole cockpit before the
        ::  route can honestly report %unknown.
        ?:(=(our organ.route) (local-model-status-for organ.route now) ~)
      ?~  observed
        [route %unknown ~ ~ ~ ~]
      =/  actual=(unit backend:vi)  model.u.observed
      =/  state=readiness-state:vco
        ?:  busy.u.observed  %busy
        ?:  ?~(actual %.n !=(u.actual local-smollm2-backend:vi))
          %mismatch
        ?:  service-ready.u.observed  %ready
        %unavailable
      :*  route
          state
          actual
          `accelerated.u.observed
          `governed.u.observed
          ~
      ==
    %connected
      =/  provider=(unit @tas)
        (slaw %tas provider-id.spec.config.route)
      =/  backend=(unit backend:vi)
        ?~  provider  ~
        `[%connected u.provider tag.oracle.config.route (scot %ux wgt.oracle.config.route)]
      =/  target=model-target:mb  target.spec.config.route
      =/  expected=(unit @tas)
        ?-  -.target
          %local-session  `protocol.target
          %http-json      ~
          %gall-agent     ~
        ==
      =/  supported=?
        ?-  -.target
          %local-session  =(%pataphor-codex port.target)
          %http-json      %.n
          %gall-agent     %.n
        ==
      =/  observed=(unit bridge-observation)
        (bridge-observation-for our now)
      ?~  observed
        [route %unknown backend ~ ~ ~]
      =/  state=readiness-state:vco
        ?.  supported  %unavailable
        ?:  busy.u.observed  %busy
        ?.  ready.u.observed  %unavailable
        ?:  ?~(expected %.y ?~(protocol.u.observed %.n =(u.expected u.protocol.u.observed)))
          %ready
        %mismatch
      [route state backend ~ ~ protocol.u.observed]
  ==
++  weight-for-index
  |=  [our=@p now=@da index=@ud]
  ^-  (unit packet:wis)
  =/  r
    ?.  (agent-live:vsg our now %graf)  [%| ~]
    %-  mule
    |.  ^-  packet:wis
        .^(packet:wis %gx /(scot %p our)/graf/(scot %da now)/weight/index/(scot %ud index)/noun)
  ?-  -.r
    %&  `p.r
    %|  ~
  ==
++  weight-inquiries-for-index
  |=  [our=@p now=@da index=@ud]
  ^-  (unit history:wi)
  =/  r
    ?.  (agent-live:vsg our now %graf)  [%| ~]
    %-  mule
    |.  ^-  history:wi
        .^(history:wi %gx /(scot %p our)/graf/(scot %da now)/weight/inquiries/index/(scot %ud index)/noun)
  ?-  -.r
    %&  `p.r
    %|  ~
  ==
++  evidence-search
  |=  $:  our=@p
          now=@da
          d=derivation:dvn
          verdict=verdict:satisfy
          goal=(unit gid:gol)
          prior=(list @t)
      ==
  ^-  (unit search:ves)
  ?.  =(%unclear -.verdict)  ~
  =/  query=(unit @t)  (query-of:ves text.d)
  ?~  query  ~
  =/  found=(list ref:ask-build)  (recall-for our now u.query)
  `(make:ves d goal u.query prior found now)
++  evidence-search-cards
  |=  [our=@p judgment=@ux search=search:ves]
  ^-  (list card)
  %+  weld
    ~[(light-card our (fact:ves search))]
  %+  turn  (relations:ves judgment search)
  |=(relation=rel:dvn (publish-card our relation))
++  candidate-comparison-cards
  |=  [our=@p comparison=comparison:vc judgment=judgment:vj]
  ^-  (list card)
  =/  cards=(list card)  ~[(light-card our (fact:vc comparison))]
  =/  cards
    %+  weld  cards
    %+  turn  (relations:vc comparison)
    |=(relation=rel:dvn (publish-card our relation))
  (snoc cards (publish-card our [[%viki-judgment (scot %ux (jid:vj judgment))] %based-on (key:vc comparison)]))
++  candidate-calls
  |=  [routes=(list model-route) p=plan:pln now=@da refs=(list ref:ask-build)]
  ^-  (list candidate-call)
  %+  turn  routes
  |=  route=model-route
  =/  ask=ask:dvn
    (build:ask-build (request-task:pln p) refs (oracle-for-route route) ask-law)
  =/  want=want:dvn
    (want-for:ask-build ask %viki %act now refs)
  [route want]
++  candidate-round-plan-cards
  |=  [our=@p round=candidate-round]
  ^-  (list card)
  =/  plan=plan:cr  (plan-for:cr round)
  %+  weld  ~[(light-card our (plan-fact:cr plan))]
  %+  turn  (plan-relations:cr plan)
  |=(relation=rel:dvn (publish-card our relation))
++  candidate-round-receipt-cards
  |=  [our=@p receipt=receipt:cr]
  ^-  (list card)
  %+  weld  ~[(light-card our (fact:cr receipt))]
  %+  turn  (relations:cr receipt)
  |=(relation=rel:dvn (publish-card our relation))
++  candidate-start-cards
  |=  $:  our=@p
          round=candidate-round
          call=candidate-call
          held=flight
      ==
  ^-  (list card)
  %+  weld
    :~  (light-card our [%want want.call])
        (publish-card our (wanted-rel:dvn want.call))
        (publish-card our (serves-rel:dvn ask.want.call gid.goal.round))
    ==
  (start-model-cards our route.call held)
++  candidate-by-aid
  |=  [candidates=(list derivation:dvn) aid=@ux]
  ^-  (unit derivation:dvn)
  =/  hits=(list derivation:dvn)
    (skim candidates |=(d=derivation:dvn =(aid (aid:dvn ask.d))))
  ?~  hits  ~
  ?^  t.hits  ~
  `i.hits
++  compare-round
  |=  [round=candidate-round refs=(list @t) at=@da anchor=derivation:dvn]
  ^-  compared-result
  =/  items=(list [d=derivation:dvn verdict=verdict:satisfy])
    %+  turn  candidates.round
    |=(d=derivation:dvn [d (judge:satisfy (step-for:gol goal.round) d)])
  =/  comparison=comparison:vc  (make:vc `gid.goal.round items at)
  ?-  -.decision.comparison
    %select
      =/  chosen=(unit derivation:dvn)
        (candidate-by-aid candidates.round aid.decision.comparison)
      ?~  chosen
        [anchor [%unclear %invalid-candidate-set] refs `comparison]
      =/  verdict=verdict:satisfy
        (judge:satisfy (step-for:gol goal.round) u.chosen)
      [u.chosen verdict refs `comparison]
    %more-evidence
      [anchor [%unclear why.decision.comparison] refs `comparison]
    %refuse
      [anchor [%fail why.decision.comparison] refs `comparison]
  ==
::  the derivation behind an aid, from viki's own index.
++  goal-by
  |=  [gs=(list goal:gol) g=gid:gol]
  ^-  (unit goal:gol)
  =/  hit  (skim gs |=(x=goal:gol =(g gid.x)))
  ?~  hit  ~
  ::  A gid names one sovereign intent.  Two different bodies under the same
  ::  id are an ambiguity, never an invitation to let set order choose law.
  ?^  t.hit  ~
  `i.hit
++  judgment-step
  |=  [g=(unit goal:gol) d=derivation:dvn]
  ^-  step:gol
  ?^  g  (step-for:gol u.g)
  [['' 0] prompt.ask.d %converse ~]
++  compare-retry-result
  |=  $:  our=@p
          now=@da
          slot=(set rel:dvn)
          held=flight
          current=derivation:dvn
          goal=(unit gid:gol)
          goal-record=(unit goal:gol)
      ==
  ^-  compared-result
  =/  current-verdict=verdict:satisfy
    (judge:satisfy (judgment-step goal-record current) current)
  =/  fallback=compared-result
    [current current-verdict refs.want.held ~]
  =/  retry=(unit retry-prior)  (retry-prior-for our now slot held)
  ?~  retry  fallback
  =/  prior-verdict=verdict:satisfy
    (judge:satisfy (judgment-step goal-record prior.u.retry) prior.u.retry)
  =/  items=(list [d=derivation:dvn verdict=verdict:satisfy])
    :~  [prior.u.retry prior-verdict]
        [current current-verdict]
    ==
  =/  comparison=comparison:vc
    (make:vc goal items now)
  ?-  -.decision.comparison
    %select
      ?:  =(aid.decision.comparison (aid:dvn ask.current))
        [current current-verdict refs.want.held `comparison]
      ?.  =(aid.decision.comparison (aid:dvn ask.prior.u.retry))
        [current [%unclear %invalid-candidate-set] refs.want.held `comparison]
      =/  prior-want=(unit want:dvn)  (find-want:dvn slot ask.prior.u.retry)
      [prior.u.retry prior-verdict ?~(prior-want ~ refs.u.prior-want) `comparison]
    %more-evidence
      [current [%unclear why.decision.comparison] refs.want.held `comparison]
    %refuse
      [current [%fail why.decision.comparison] refs.want.held `comparison]
  ==
++  derivation-by
  |=  [slot=(set rel:dvn) k=@ux]
  ^-  (unit derivation:dvn)
  =/  l=(list rel:dvn)  ~(tap in slot)
  |-  ^-  (unit derivation:dvn)
  ?~  l  ~
  ?.  =(%answered-by kind.i.l)  $(l t.l)
  ?.  ?=([%derivation *] dst.i.l)  $(l t.l)
  =/  d  ((soft derivation:dvn) +.dst.i.l)
  ?~  d  $(l t.l)
  ?.  =(k (aid:dvn ask.u.d))  $(l t.l)
  d
++  refusal-by
  |=  [slot=(set rel:dvn) k=@ux]
  ^-  (unit refusal:dvn)
  =/  l=(list rel:dvn)  ~(tap in slot)
  |-  ^-  (unit refusal:dvn)
  ?~  l  ~
  ?.  =(%refused-by kind.i.l)  $(l t.l)
  ?.  ?=([%refusal *] dst.i.l)  $(l t.l)
  =/  r  ((soft refusal:dvn) +.dst.i.l)
  ?~  r  $(l t.l)
  ?.  =(k (aid:dvn ask.u.r))  $(l t.l)
  r
++  weight-run-for
  |=  [slot=(set rel:dvn) record=fact:wi]
  ^-  inquiry-run:vww
  =/  inquiry=inquiry:wi  item.record
  =/  answer=(unit derivation:dvn)  (derivation-by slot ask-id.inquiry)
  =/  result=result:vww
    ?^  answer  [%answered text.u.answer]
    =/  refusal=(unit refusal:dvn)  (refusal-by slot ask-id.inquiry)
    ?^  refusal  [%refused why.u.refusal]
    [%pending ~]
  [handle.record ask-id.inquiry requested-at.inquiry result]
++  weight-workflow-for
  |=  [our=@p now=@da index=@ud]
  ^-  snapshot:vww
  =/  packet=(unit packet:wis)  (weight-for-index our now index)
  ?~  packet
    [%viki-weight-workflow-v1 index %unmapped ~ 0 ~ %complete-mapping]
  =/  history=(unit history:wi)
    (weight-inquiries-for-index our now index)
  =/  total=@ud  ?~(history 0 total.u.history)
  =/  records=(list fact:wi)  ?~(history ~ records.u.history)
  =/  slot=(set rel:dvn)  (my-slot our now)
  =/  runs=(list inquiry-run:vww)
    (turn records |=(record=fact:wi (weight-run-for slot record)))
  ?~  runs
    [%viki-weight-workflow-v1 index %ready packet total ~ %ask-model]
  =/  stage=stage:vww
    ?-  -.result.i.runs
      %pending   %running
      %answered  %answered
      %refused   %refused
    ==
  =/  next=next-action:vww
    ?-  -.result.i.runs
      %pending   %wait-or-recover
      %answered  %review-and-ratify
      %refused   %retry-or-reroute
    ==
  [%viki-weight-workflow-v1 index stage packet total runs next]
++  workflow-source
  |=  [our=@p now=@da kind=@tas]
  ^-  (unit (list *))
  =/  r
    ?.  (agent-live:vsg our now %graf)  [%| ~]
    %-  mule
    |.  ^-  (list *)
        .^((list *) %gx /(scot %p our)/graf/(scot %da now)/by-kind/[kind]/noun)
  ?-  -.r
    %|  ~
    %&  `p.r
  ==
++  goal-workflows-for
  |=  [our=@p now=@da pending=(unit flight)]
  ^-  catalog:vgw
  =/  slot=(set rel:dvn)  (my-slot our now)
  =/  active-goal=(unit gid:gol)
    ?~  pending  ~
    (find-goal:dvn slot ask.want.u.pending)
  %-  catalog-for:vgw
  :*  (workflow-source our now %goal)
      (workflow-source our now %viki-plan)
      (workflow-source our now %viki-judgment)
      (workflow-source our now %viki-continuation)
      slot
      active-goal
  ==
++  thread-cards
  |=  [our=@p t=turn-id:fam k=turn-kind:fam gs=(list gid:gol)]
  ^-  (list card)
  %+  turn  (turn-rels:fam t k gs)
  |=(r=rel:fam (publish-card our r))
++  connected-report
  |=  [nonce=@ux result=(each (unit entry:vcj) @tas)]
  ^-  card
  [%give %fact ~[/vibecoding/connected-judgments-v2/(scot %ux nonce)] %noun !>(`status:vcj`[%viki-connected-judgment-status-v2 nonce result])]
++  moon-configuration-valid
  |=  [our=@p now=@da selected=(list moon-route:vr)]
  ^-  ?
  ?~  selected  %.y
  ::  Restore checks identity and shape only. Configuration cannot substitute
  ::  for the canonical seat/lease/law reads performed at every dispatch.
  =/  table=table:vms
    (~(gas by *table:vms) (turn selected |=(r=moon-route:vr [seat.seat-session.r seat-session.r])))
  (routes-allowed:vmr our now table selected)
++  glass-generation-report
  |=  [nonce=@ux result=(each @ux @tas)]
  ^-  card
  [%give %fact ~[/glass/coding] %noun !>([%viki-glass-generation-status-v1 nonce result])]
++  connected-observe
  |=  [our=@p at=@da held=ledger:vcj nonce=@ux]
  ^-  [(list card) ledger:vcj]
  =/  prior  (~(get by held) nonce)
  ?~  prior  [~[(connected-report nonce [%& ~])] held]
  =/  seen  (retained:vcjr our our at judgment.u.prior)
  =/  updated  (observed:vcj our at u.prior seen)
  ?:  ?=(%| -.updated)  [~[(connected-report nonce [%| p.updated])] held]
  [~[(connected-report nonce [%& `p.updated])] (~(put by held) nonce p.updated)]
++  hot-specs
  ::  Behaviour served hot from the hot desk (law; %hot-viki) /hot/<name>/hoon. A module must fit
  ::  these compiled types (checked once, at install) or it is refused and the
  ::  compiled default keeps running. See lib/hot-module-agent.
  ^-  (list spec:hot-owner)
  :~  [%review-status -:!>(*[bowl:gall state:nreview state:ncode @ux record:naccept]) -:!>(*change:nreview)]
      [%review-act -:!>(*[bowl:gall state:nreview state:ncode command:nreview]) -:!>(*change:nreview)]
      ::  the coding loop's three events (lib/native-coding-loop)
      [%loop-model -:!>(*[bowl:gall state:ncode @ux @ux outcome:nprovider]) -:!>(*(quip card:agent:gall state:ncode))]
      [%loop-tool -:!>(*[bowl:gall state:ncode tool-result:nct]) -:!>(*(quip card:agent:gall state:ncode))]
      [%loop-deadline -:!>(*[bowl:gall state:ncode @ux @ux]) -:!>(*(quip card:agent:gall state:ncode))]
  ==
++  owned
  ::  Production saved-DATA extractor, also used by full-VASE rehearsal.
  |=  v=vase
  ^-  (list part:lguard)
  (viki:qpc-state v)
++  hot-gate
  ::  The hot module owner (second wrapper, under the load guard) holds
  ::  installed gates.
  |=  [b=bowl:gall name=term]
  ^-  (unit vase)
  .^((unit vase) %gx /(scot %p our.b)/viki/(scot %da now.b)/hot-module/[name]/noun)
--
%-  (agent:lguard owned)
%-  (agent:hot-owner hot-specs)
%-  agent:qpc-status
%-  agent:qpc-readiness
%-  agent:qpc-onboard
%-  agent:qpc-campaign
%-  viki:qpc-flow
%-  agent:qpc-selected
%-  agent:qpc-controller
%-  agent:qpc-prospective
%-  agent:qpc-declaration
%-  agent:qpc-law
%-  agent:qpc-instrument
%-  agent:local-review
%-  agent:qpc-stream
%-  agent:qpc-observer
%+  agent:qpc-gate  %viki
=+  tensor=^-(organ:vto init-organ:vta)
=+  seats=^-(organ:vsl init-organ:vsa)
=+  modelio=^-(organ:vmi init-organ:vml)
=+  registry=^-(registry:mr empty:mr)
=+  intents=^-(organ:itn init-organ:vil)
=+  bridge=^-(bridge-organ:vb init-organ:vbm)
=+  workers=^-(worker-organ:vw init-organ:vwm)
=+  connected-judgments=*ledger:vcj
=+  moon-routes=*(list moon-route:vr)
=+  coding=*organ:gcl
=+  projects=*organ:gpl
=+  development=*organ:devc
=+  native-coding=empty:ncode
=|  native-reviews=state:nreview
=|  native-workspace=state:nworkspace
=|  native-openings=ledger:nopening
=+  native-campaigns=empty:ncampaign
=|  native-onboarding=state:nonboard
=|  native-settlements=state:nfinish
=|  native-session-workspaces=state:nsession-workspace
=|  native-completions=state:ncompletion
=+  completion-campaigns=empty:nccampaign
=|  reviewed-completions=state:ncreviewed
=+  state=^-(state-10 [%10 %.n 0 ~ ~[default-route] ~ ~ default-budget default-every ~ 0 init-judgments ~ ~ 0 ~])
%-  agent:rf
%+  verb  |
%-  agent:dbug
^-  agent:gall
%-  (agent:shoe command)
^-  (shoe:shoe command)
|_  =bowl:gall
+*  this  .
    armed  armed.state
    head  head.state
    pending  pending.state
    routes  routes.state
    round  round.state
    retry-policy  retry-policy.state
    budget  budget.state
    every  every.state
    said  said.state
    seen  seen.state
    judgments  judgments.state
    last-reconsideration  last-reconsideration.state
    reconsideration  reconsideration.state
    route-revision  route-revision.state
    route-history  route-history.state
    worker-organ  workers
    bridge-shadow  bridge
    model-registry  registry
    def   ~(. (default-agent this %|) bowl)
    des   ~(. (default:shoe this command) bowl)
    native-local-used
      ::  Viki's own session uses, apart from Cantrip's grants and records.
      ^-  (set @ux)
      =/  used=(set @ux)  ~(key by sessions.native-coding)
      =.  used  (~(uni in used) ~(key by bindings.native-coding))
      =.  used  (~(uni in used) ~(key by native-openings))
      =.  used  (~(uni in used) (silt (turn ~(val by pending.native-coding) |=(r=tool-request:nct session.context.r))))
      (~(uni in used) (silt (turn ~(val by tasks.fleet.fleet.native-coding) |=(e=entry:nft session.context.task.e))))
    native-workspace-constraints-with
      |=  reserved=(set @tas)
      ::  Include retained/unknown ownership, not just currently running sessions.
      ^-  [used=(set @ux) reserved=(set @tas)]
      =/  used=(set @ux)
        %-  ~(uni in native-local-used)
        .^((set @ux) %gx /(scot %p our.bowl)/cantrip/(scot %da now.bowl)/native-coding/used-sessions/noun)
      =.  reserved
        %-  ~(uni in reserved)
        %+  roll  ~(val by bootstraps.native-workspace)
        |=  [r=record:nbootstrap held=(set @tas)]
        (~(put in held) working.project.request.r)
      =.  reserved
        %-  ~(uni in reserved)
        %+  roll  ~(val by native-onboarding)
        |=  [e=entry:nonboard held=(set @tas)]
        (~(put in held) working.project.request.e)
      =.  reserved
        %-  ~(uni in reserved)
        %+  roll  ~(val by native-openings)
        |=  [r=record:nopening held=(set @tas)]
        (~(put in (~(put in held) working.project.r)) base-desk.spec.project.r)
      =.  reserved
        %-  ~(uni in reserved)
        %+  roll  ~(val by sessions.native-coding)
        |=  [e=entry:nsession held=(set @tas)]
        =.  held  (~(put in held) desk.working.session.e)
        ?~  workspace.session.e  held
        (~(put in (~(put in held) fork.u.workspace.session.e)) base.u.workspace.session.e)
      =.  reserved
        %-  ~(uni in reserved)
        %+  roll  ~(val by pending.native-coding)
        |=  [r=tool-request:nct held=(set @tas)]
        (~(put in held) desk.source.context.r)
      =.  reserved
        %-  ~(uni in reserved)
        %+  roll  ~(val by tasks.fleet.fleet.native-coding)
        |=  [e=entry:nft held=(set @tas)]
        =.  held  (~(put in (~(put in held) desk.source.context.task.e)) desk.accepted.task.e)
        ?~  assignment.e  held
        =/  r=reservation:nct  reservation.u.assignment.e
        (~(put in (~(put in (~(put in held) desk.source.context.r)) fork.workspace.r)) base.workspace.r)
      [used reserved]
    native-workspace-constraints
      (native-workspace-constraints-with .^((set @tas) %gx /(scot %p our.bowl)/cantrip/(scot %da now.bowl)/native-coding/reserved-desks/noun))
++  on-init  [~[(a2a-watch-card our.bowl)] this]
++  on-save
  =/  legacy=saved-state-21
    [%viki-familiar-state-v21 [%viki-familiar-state-v20 [%viki-familiar-state-v19 [%viki-familiar-state-v18 [%viki-familiar-state-v16 [%viki-familiar-state-v15 [%viki-familiar-state-v11 [%viki-familiar-state-v10 [%viki-familiar-state-v9 state workers bridge tensor seats modelio registry intents] connected-judgments] moon-routes] coding projects] development] native-coding] native-reviews] native-workspace] (legacy:nopening native-openings)]
  =/  prior=saved-state-25
    [%viki-familiar-state-v25 [%viki-familiar-state-v24 [%viki-familiar-state-v23 [%viki-familiar-state-v22 legacy (legacy:ncampaign native-campaigns)] native-onboarding] native-settlements] native-session-workspaces]
  =/  previous=saved-state-27
    [%viki-familiar-state-v27 [%viki-familiar-state-v26 prior native-campaigns] native-openings]
  =/  previous-28=saved-state-28
    [%viki-familiar-state-v28 previous native-completions]
  =/  previous-29=saved-state-29
    [%viki-familiar-state-v29 previous-28 completion-campaigns reviewed-completions]
  =/  previous-30=saved-state-30
    [%viki-familiar-state-v30 previous-29 ~]
  !>(`saved-state-31`[%viki-familiar-state-v31 previous-30 ~])
++  on-load
  |=  v=vase
  ^-  (quip card _this)
  ::  v31 carries v30 unchanged; malformed envelopes must never fall back.
  =/  atomic=(unit saved-state-31)  ((soft saved-state-31) q.v)
  ?>  |(?!(?=([%viki-familiar-state-v31 *] q.v)) ?=(^ atomic))
  ?>  ?~(atomic %.y =(u.atomic q.v))
  =.  v  ?~(atomic v !>(legacy.u.atomic))
  ::  v30 is a pure carry of v29: unwrap it, then restore exactly as before.
  =/  carried=(unit saved-state-30)  ((soft saved-state-30) q.v)
  ?>  |(?!(?=([%viki-familiar-state-v30 *] q.v)) ?=(^ carried))
  ?>  ?~(carried %.y =(u.carried q.v))
  =.  v  ?~(carried v !>(legacy.u.carried))
  =/  automated=(unit saved-state-29)  ((soft saved-state-29) q.v)
  ?>  |(?!(?=([%viki-familiar-state-v29 *] q.v)) ?=(^ automated))
  ?>  ?~(automated %.y =(u.automated q.v))
  =.  completion-campaigns  ?~(automated empty:nccampaign campaigns.u.automated)
  =.  reviewed-completions  ?~(automated ~ reviewed.u.automated)
  ?>  (valid:nccampaign our.bowl completion-campaigns)
  ::  Restore distinct automated provenance before unwrapping owner decisions.
  =.  v  ?~(automated v !>(legacy.u.automated))
  =/  completed=(unit saved-state-28)  ((soft saved-state-28) q.v)
  ?>  |(?!(?=([%viki-familiar-state-v28 *] q.v)) ?=(^ completed))
  ?>  ?~(completed %.y =(u.completed q.v))
  =.  native-completions  ?~(completed ~ completions.u.completed)
  ::  Restore evidence only; reload never makes an owner decision or reruns it.
  =.  v  ?~(completed v !>(legacy.u.completed))
  =/  delegated=(unit saved-state-27)  ((soft saved-state-27) q.v)
  ?>  |(?!(?=([%viki-familiar-state-v27 *] q.v)) ?=(^ delegated))
  ?>  ?~(delegated %.y =(u.delegated q.v))
  =.  v  ?~(delegated v !>(legacy.u.delegated))
  =/  inspection=(unit saved-state-26)  ((soft saved-state-26) q.v)
  ?>  |(?!(?=([%viki-familiar-state-v26 *] q.v)) ?=(^ inspection))
  ?>  ?~(inspection %.y =(u.inspection q.v))
  =.  v  ?~(inspection v !>(legacy.u.inspection))
  =/  scoped=(unit saved-state-25)  ((soft saved-state-25) q.v)
  ?>  |(?!(?=([%viki-familiar-state-v25 *] q.v)) ?=(^ scoped))
  ?>  ?~(scoped %.y =(u.scoped q.v))
  =.  native-session-workspaces  ?~(scoped *state:nsession-workspace session-workspaces.u.scoped)
  ?>  (valid:nsession-workspace our.bowl native-session-workspaces)
  ::  Restore fork intents without replaying clone or permission effects.
  =.  v  ?~(scoped v !>(legacy.u.scoped))
  =/  settlements=(unit saved-state-24)  ((soft saved-state-24) q.v)
  ?>  |(?!(?=([%viki-familiar-state-v24 *] q.v)) ?=(^ settlements))
  ?>  ?~(settlements %.y =(u.settlements q.v))
  =.  native-settlements  ?~(settlements ~ settlements.u.settlements)
  ?>  (valid:nfinish our.bowl native-settlements)
  =.  v  ?~(settlements v !>(legacy.u.settlements))
  =/  onboarding=(unit saved-state-23)  ((soft saved-state-23) q.v)
  ?>  |(?!(?=([%viki-familiar-state-v23 *] q.v)) ?=(^ onboarding))
  ?>  ?~(onboarding %.y =(u.onboarding q.v))
  =.  native-onboarding  ?~(onboarding ~ onboarding.u.onboarding)
  ?>  (valid:nonboard our.bowl native-onboarding)
  ::  Catalog installation and private workspace creation never replay on load.
  =.  v  ?~(onboarding v !>(legacy.u.onboarding))
  =/  campaigns=(unit saved-state-22)  ((soft saved-state-22) q.v)
  ?>  |(?!(?=([%viki-familiar-state-v22 *] q.v)) ?=(^ campaigns))
  ?>  ?~(campaigns %.y =(u.campaigns q.v))
  =.  native-campaigns
    ?~  inspection
      ?~(campaigns empty:ncampaign (migrate:ncampaign campaigns.u.campaigns))
    ?>  ?=(^ campaigns)
    ?>  =((legacy:ncampaign campaigns.u.inspection) campaigns.u.campaigns)
    campaigns.u.inspection
  ?>  (valid:ncampaign our.bowl native-campaigns)
  =.  v  ?~(campaigns v !>(legacy.u.campaigns))
  =/  openings=(unit saved-state-21)  ((soft saved-state-21) q.v)
  ?>  |(?!(?=([%viki-familiar-state-v21 *] q.v)) ?=(^ openings))
  ?>  ?~(openings %.y =(u.openings q.v))
  =.  native-openings
    ?~  delegated  ?~(openings ~ openings.u.openings)
    ?>  ?=(^ openings)
    ?>  =((legacy:nopening openings.u.delegated) openings.u.openings)
    openings.u.delegated
  ?>  (valid:nopening our.bowl native-openings)
  ::  Owner observation may reconcile a grant; loading never resends or opens.
  =.  v  ?~(openings v !>(legacy.u.openings))
  =/  workspace=(unit saved-state-20)  ((soft saved-state-20) q.v)
  =.  native-workspace  ?~(workspace *state:nworkspace workspace.u.workspace)
  ?>  (valid:nworkspace our.bowl native-workspace)
  ::  Provisioning and deployment observations restore without any replay.
  =.  v  ?~(workspace v !>(legacy.u.workspace))
  =/  reviewed=(unit saved-state-19)  ((soft saved-state-19) q.v)
  =.  native-reviews  ?~(reviewed ~ reviews.u.reviewed)
  ?>  (lte ~(wyt by native-reviews) 128)
  ::  Retain review requests and unknown writes without resubmitting on load.
  =.  v  ?~(reviewed v !>(legacy.u.reviewed))
  =/  fleet-saved=(unit saved-state-18)  ((soft saved-state-18) q.v)
  =/  native=(unit saved-state-17)  ((soft saved-state-17) q.v)
  ::  Preserve the complete old native journal and add the fleet organ once.
  =.  native-coding
    ?^  fleet-saved  native-coding.u.fleet-saved
    ?~  native  empty:ncode
    (migrate:ncode native-coding.u.native)
  ?>  (valid:ncompletion our.bowl native-completions native-coding)
  ?>  (valid:ncreviewed our.bowl reviewed-completions native-coding)
  =/  v=vase
    ?^  fleet-saved  !>(legacy.u.fleet-saved)
    ?~  native  v
    !>(legacy.u.native)
  =/  latest=(unit saved-state-16)  ((soft saved-state-16) q.v)
  =.  development  (reload:devc our.bowl ?~(latest *organ:devc development.u.latest))
  =/  v=vase  ?~(latest v !>(legacy.u.latest))
  =/  continuation=(unit saved-state-15)  ((soft saved-state-15) q.v)
  =/  v=vase
    ?~  continuation  v
    !>(`saved-state-14`[%viki-familiar-state-v14 legacy.u.continuation coding.u.continuation projects.u.continuation])
  =/  corrected=(unit saved-state-14)  ((soft saved-state-14) q.v)
  ::  Only unwrap the new envelope; the existing loader restores the complete
  ::  continuation map once. No prior prepared/result/judgment is rebuilt.
  =/  v=vase
    ?~  corrected  v
    !>(`saved-state-13`[%viki-familiar-state-v13 [%viki-familiar-state-v12 legacy.u.corrected coding.u.corrected] projects.u.corrected])
  =/  project-state=(unit saved-state-13)  ((soft saved-state-13) q.v)
  =.  projects  (restore:gpl our.bowl ?~(project-state *organ:gpl projects.u.project-state))
  =/  v=vase  ?~(project-state v !>(legacy.u.project-state))
  =/  current=(unit saved-state-12)  ((soft saved-state-12) q.v)
  =.  coding  (restore:gcl our.bowl ?~(current *organ:gcl coding.u.current))
  =/  v=vase  ?~(current v !>(legacy.u.current))
  =;  loaded=(quip card _this)
    =/  restored=_this  +.loaded
    =/  resumed  (recover:devc bowl development.restored moon-routes.restored workers.restored)
    =/  native-resumed  (recover:ncode our.bowl native-coding.restored)
    =/  review-watches  (reload:ncampaign bowl native-campaigns.restored)
    =/  completion-watches  (reload:nccampaign our.bowl completion-campaigns.restored)
    =/  settlement-reads  (reload:nfinish our.bowl native-settlements.restored)
    [(weld cards.completion-watches (weld settlement-reads (weld cards.review-watches (weld -.native-resumed (weld (recover-cards:gcl now.bowl coding) (weld -.loaded `(list card)`-.resumed)))))) restored(development +.resumed, native-coding +.native-resumed, native-campaigns state.review-watches, completion-campaigns state.completion-watches)]
  =/  newest=(unit saved-state-11)  ((soft saved-state-11) q.v)
  =/  restored-moons=(list moon-route:vr)  ?~(newest ~ moons.u.newest)
  ?>  (moon-configuration-valid our.bowl now.bowl restored-moons)
  =.  moon-routes  restored-moons
  =/  v=vase  ?~(newest v !>(legacy.u.newest))
  =/  modern=(unit saved-state-10)  ((soft saved-state-10) q.v)
  =/  restored-judgments
    (restore:vcj our.bowl now.bowl ?~(modern *ledger:vcj connected.u.modern))
  ?>  ?=(%& -.restored-judgments)
  =.  connected-judgments  p.restored-judgments
  ::  Original legacy vases keep their metadata. A v10 envelope supplies its
  ::  complete typed v9 value to the unchanged legacy normalizer below.
  =/  v=vase  ?~(modern v !>(legacy.u.modern))
  =/  saved=(unit saved-state)  ((soft saved-state) q.v)
  =/  prior-8=(unit saved-state-8)  ((soft saved-state-8) q.v)
  =/  prior-7=(unit saved-state-7)  ((soft saved-state-7) q.v)
  =/  prior-6=(unit saved-state-6)  ((soft saved-state-6) q.v)
  =/  prior-5=(unit saved-state-5)  ((soft saved-state-5) q.v)
  =/  prior-4=(unit saved-state-4)  ((soft saved-state-4) q.v)
  =/  prior-3=(unit saved-state-3)  ((soft saved-state-3) q.v)
  =/  prior-2=(unit saved-state-2)  ((soft saved-state-2) q.v)
  =/  prior=(unit saved-state-1)  ((soft saved-state-1) q.v)
  ?:  ?&  ?=(~ saved)  ?=(~ prior-8)  ?=(~ prior-7)  ?=(~ prior-6)  ?=(~ prior-5)  ?=(~ prior-4)  ?=(~ prior-3)  ?=(~ prior-2)  ?=(~ prior)  ==  !!
  =/  old=state-any
    ?^  saved  state.u.saved
    ?^  prior-8  state.u.prior-8
    ?^  prior-7  state.u.prior-7
    ?^  prior-6  state.u.prior-6
    ?^  prior-5  state.u.prior-5
    ?^  prior-4  state.u.prior-4
    ?^  prior-3  state.u.prior-3
    ?^  prior-2  state.u.prior-2
    state:(need prior)
  =/  restored=worker-organ:vw
    ?^  saved  workers.u.saved
    ?^  prior-8  workers.u.prior-8
    ?^  prior-7  workers.u.prior-7
    ?^  prior-6  workers.u.prior-6
    ?^  prior-5  workers.u.prior-5
    ?^  prior-4  workers.u.prior-4
    ?^  prior-3  workers.u.prior-3
    ?^  prior-2  workers.u.prior-2
    init-organ:vwm
  ::  Every pre-v9 save carries the single-port organ; +upgrade-organ lifts
  ::  it into the per-port shape, then the same restart law applies.
  =/  restored-bridge=bridge-organ:vb
    ?^  saved  (restart-shadow:vbm bridge.u.saved)
    ?^  prior-8  (restart-shadow:vbm (upgrade-organ:vbm bridge.u.prior-8))
    ?^  prior-7  (restart-shadow:vbm (upgrade-organ:vbm bridge.u.prior-7))
    ?^  prior-6  (restart-shadow:vbm (upgrade-organ:vbm bridge.u.prior-6))
    ?^  prior-5  (restart-shadow:vbm (upgrade-organ:vbm bridge.u.prior-5))
    ?^  prior-4  (restart-shadow:vbm (upgrade-organ:vbm bridge.u.prior-4))
    ?^  prior-3  (restart-shadow:vbm (upgrade-organ:vbm bridge.u.prior-3))
    init-organ:vbm
  =.  tensor
    ?^  saved  tensor.u.saved
    ?^  prior-8  tensor.u.prior-8
    ?^  prior-7  tensor.u.prior-7
    ?^  prior-6  tensor.u.prior-6
    ?^  prior-5  tensor.u.prior-5
    ?^  prior-4  tensor.u.prior-4
    init-organ:vta
  ::  v5 lifts carry the seat organ; every earlier save begins fresh.
  =.  seats
    ?^  saved  seats.u.saved
    ?^  prior-8  seats.u.prior-8
    ?^  prior-7  seats.u.prior-7
    ?^  prior-6  seats.u.prior-6
    ?^  prior-5  seats.u.prior-5
    init-organ:vsa
  ::  v6 lifts carry the model I/O organ; every earlier save begins fresh.
  =.  modelio
    ?^  saved  modelio.u.saved
    ?^  prior-8  modelio.u.prior-8
    ?^  prior-7  modelio.u.prior-7
    ?^  prior-6  modelio.u.prior-6
    init-organ:vml
  ::  v7 is the first save that carries edited-model registry authority; v8
  ::  preserves it unchanged beside the new intent organ.
  =.  registry
    =/  restored-registry=registry:mr
      ?^  saved  registry.u.saved
      ?^  prior-8  registry.u.prior-8
      ?^  prior-7  registry.u.prior-7
      empty:mr
    ?>  (valid:mar restored-registry)
    restored-registry
  ::  v8 is the first save that carries authenticated operator turns.  Older
  ::  saves migrate to the empty organ; malformed v8 state fails closed.
  =.  intents
    ?^  saved
      ?>  (valid-organ:vil intents.u.saved)
      intents.u.saved
    ?~  prior-8  init-organ:vil
    ?>  (valid-organ:vil intents.u.prior-8)
    intents.u.prior-8
  ?-  -.old
    %0
      ::  The old state remembered only an aid, so reconstructing the want
      ::  would invent prompt bytes.  Clear it; the next tick reads Graf.
      =/  migrated=state-10
        (normalize-state (lift-state-8 [%8 armed.old head.old ~ ~[default-route] ~ ~ budget.old every.old said.old seen.old init-judgments]))
      =/  resumed  (resume-state our.bowl now.bowl migrated)
      [cards.resumed this(state state.resumed, workers restored, bridge restored-bridge)]
    %1
      =/  migrated=state-10
        %-  normalize-state
        %-  lift-state-8
        :*  %8  armed.old  head.old
            ?~(pending.old ~ `(migrate-flight-1 u.pending.old))
            ~[default-route]  ~  ~  budget.old  every.old  said.old  seen.old  init-judgments
        ==
      =/  resumed  (resume-state our.bowl now.bowl migrated)
      [cards.resumed this(state state.resumed, workers restored, bridge restored-bridge)]
    %2
      =/  migrated=state-10
        %-  normalize-state
        %-  lift-state-8
        :*  %8  armed.old  head.old
            ?~(pending.old ~ `(migrate-flight-2 u.pending.old))
            ~[default-route]  ~  ~  budget.old  every.old  said.old  seen.old  init-judgments
        ==
      =/  resumed  (resume-state our.bowl now.bowl migrated)
      [cards.resumed this(state state.resumed, workers restored, bridge restored-bridge)]
    %3
      =/  migrated=state-10
        %-  normalize-state
        %-  lift-state-8
        :*  %8  armed.old  head.old
            ?~(pending.old ~ `(migrate-flight-2 u.pending.old))
            ~[[%local organ.old]]  ~  ~  budget.old  every.old  said.old  seen.old  init-judgments
        ==
      =/  resumed  (resume-state our.bowl now.bowl migrated)
      [cards.resumed this(state state.resumed, workers restored, bridge restored-bridge)]
    %4
      =/  migrated=state-10
        %-  normalize-state
        %-  lift-state-8
        :*  %8  armed.old  head.old  pending.old  ~[route.old]  ~  ~
            budget.old  every.old  said.old  seen.old  init-judgments
        ==
      =/  resumed  (resume-state our.bowl now.bowl migrated)
      [cards.resumed this(state state.resumed, workers restored, bridge restored-bridge)]
    %5
      =/  migrated=state-10
        %-  normalize-state
        %-  lift-state-8
        :*  %8  armed.old  head.old  pending.old  ~[route.old]  ~  retry-policy.old
            budget.old  every.old  said.old  seen.old  init-judgments
        ==
      =/  resumed  (resume-state our.bowl now.bowl migrated)
      [cards.resumed this(state state.resumed, workers restored, bridge restored-bridge)]
    %6
      =/  migrated=state-8
        :*  %8  armed.old  head.old  pending.old  ~[route.old]  ~  retry-policy.old
            budget.old  every.old  said.old  seen.old  init-judgments
        ==
      =/  resumed  (resume-state our.bowl now.bowl (normalize-state (lift-state-8 migrated)))
      [cards.resumed this(state state.resumed, workers restored, bridge restored-bridge)]
    %7
      =/  migrated=state-8
        :*  %8  armed.old  head.old  pending.old  routes.old  round.old  retry-policy.old
            budget.old  every.old  said.old  seen.old  init-judgments
        ==
      =/  resumed  (resume-state our.bowl now.bowl (normalize-state (lift-state-8 migrated)))
      [cards.resumed this(state state.resumed, workers restored, bridge restored-bridge)]
    %8
      =/  resumed  (resume-state our.bowl now.bowl (normalize-state (lift-state-8 old)))
      [cards.resumed this(state state.resumed, workers restored, bridge restored-bridge)]
    %9
      =/  resumed
        (resume-state our.bowl now.bowl (normalize-state (lift-state-9 old)))
      [cards.resumed this(state state.resumed, workers restored, bridge restored-bridge)]
    %10
      =/  resumed  (resume-state our.bowl now.bowl (normalize-state old))
      [cards.resumed this(state state.resumed, workers restored, bridge restored-bridge)]
  ==
++  on-poke
  |=  [=mark =vase]
  ^-  (quip card _this)
  ?:  &(=(%noun mark) ?=([%qpc-native-note-v1 *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  parsed  ((soft command:qpc-note) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(u.parsed q.vase)
    =/  next  (apply:qpc-note bowl native-coding u.parsed)
    [-.next this(native-coding +.next)]
  ?:  &(=(%noun mark) ?=([?(%qpc-selected-open-v1 %qpc-selected-pending-v1) *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  parsed  ((soft command:qpc-selected-note) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(u.parsed q.vase)
    ?.  ?:  ?=(%qpc-selected-open-v1 -.u.parsed)
          (available:qpc-selected-project native-session-workspaces plan.u.parsed)
        %.y
      [~ this]
    =/  next  (apply:qpc-selected-note bowl native-coding u.parsed)
    [-.next this(native-coding +.next)]
  ?:  &(=(%noun mark) ?=([%native-coding-completion-review-finish-v1 *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  parsed  ((soft command:ncreviewed) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(u.parsed q.vase)
    =/  next  (finish:ncreviewed bowl reviewed-completions native-coding scopes.native-campaigns campaign.u.parsed)
    [cards.next this(reviewed-completions state.next, native-coding coding.next)]
  ?:  &(=(%noun mark) ?=([%native-coding-completion-review-action-v1 *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  parsed  ((soft ,[%native-coding-completion-review-action-v1 action=action:nccampaign]) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(u.parsed q.vase)
    =/  next  (act:nccampaign bowl completion-campaigns native-coding scopes.native-campaigns action.u.parsed)
    ?:  ?=(%| -.next)  [~[(refused:ncode 0x0 p.next)] this]
    [(weld cards.p.next ~[(changed:ncode 0x0 0)]) this(completion-campaigns state.p.next)]
  ?:  &(=(%noun mark) ?=([%native-coding-completion-review-event-v1 *] q.vase))
    =/  parsed  ((soft event:ncreviewer) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(u.parsed q.vase)
    =/  next  (receive:nccampaign bowl completion-campaigns native-coding scopes.native-campaigns u.parsed)
    =/  notices=(list card)  ?:(=(completion-campaigns state.next) ~ ~[(changed:ncode 0x0 0)])
    [(weld cards.next notices) this(completion-campaigns state.next)]
  ?:  &(=(%noun mark) ?=([%qpc-native-task-complete-v1 *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  parsed  ((soft command:qpc-task-completion) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(u.parsed q.vase)
    =/  next  (act:qpc-task-completion bowl native-coding native-reviews u.parsed)
    [cards.next this(native-coding coding.next)]
  ?:  &(=(%noun mark) ?=([%native-coding-completion-decide-v1 *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  parsed  ((soft command:ncompletion) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(u.parsed q.vase)
    =/  next  (act:ncompletion bowl native-completions native-coding u.parsed)
    [cards.next this(native-completions state.next, native-coding coding.next)]
  ?:  &(=(%noun mark) ?=([%native-coding-session-workspace-action-v1 *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  parsed  ((soft ,[%native-coding-session-workspace-action-v1 action=command:nsession-workspace]) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(u.parsed q.vase)
    =/  action=command:nsession-workspace  action.u.parsed
    ?:  ?=(%observe -.action)
      =/  next  (act:nsession-workspace bowl native-session-workspaces projects.native-coding ~ ~ action)
      [cards.next this(native-session-workspaces state.next)]
    ?.  (agent-live:vsg our.bowl now.bowl %cantrip)
      [~[(refused:ncode session.request.action %session-workspace-cantrip-unavailable)] this]
    =/  limits  native-workspace-constraints
    =/  next  (act:nsession-workspace bowl native-session-workspaces projects.native-coding used.limits reserved.limits action)
    [cards.next this(native-session-workspaces state.next)]
  ?:  &(=(%noun mark) ?=([%native-coding-fleet-progress-v1 *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  parsed  ((soft request:nfinish) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(u.parsed q.vase)
    =/  next  (observe:nfinish bowl native-settlements native-coding native-reviews moon-routes coding session.u.parsed)
    [cards.next this(native-settlements state.next, native-coding coding.next)]
  ?:  &(=(%noun mark) ?=([%native-coding-fleet-enqueue-session-v1 *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  parsed  ((soft enqueue-request:ncode) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(u.parsed q.vase)
    =/  next  (enqueue-session:ncode bowl native-coding moon-routes coding u.parsed)
    [-.next this(native-coding +.next)]
  ?:  &(=(%noun mark) ?=([%native-coding-review-negative-v1 *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  parsed  ((soft negative-request:nreview) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(u.parsed q.vase)
    =/  next  (negative:nreview bowl native-reviews native-coding campaign.u.parsed request.u.parsed)
    [cards.next this(native-reviews reviews.next, native-coding coding.next)]
  ?:  &(=(%noun mark) ?=([%native-coding-onboarding-action-v1 *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  parsed  ((soft ,[%native-coding-onboarding-action-v1 action=command:nonboard]) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(u.parsed q.vase)
    =/  next  (act:nonboard bowl native-onboarding native-workspace native-coding action.u.parsed)
    [cards.next this(native-onboarding onboarding.next, native-workspace workspace.next, native-coding coding.next)]
  ?:  &(=(%noun mark) ?=([%native-coding-review-campaign-action-v1 *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  parsed  ((soft ,[%native-coding-review-campaign-action-v1 action=action:ncampaign]) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(u.parsed q.vase)
    =/  next  (act:ncampaign bowl native-campaigns action.u.parsed)
    ?:  ?=(%| -.next)  [~[(refused:ncode 0x0 p.next)] this]
    =/  out=change:ncampaign  p.next
    =/  held  (reconcile:nccampaign bowl completion-campaigns scopes.state.out)
    [(weld cards.held (weld cards.out ~[(changed:ncode 0x0 0)])) this(native-campaigns state.out, completion-campaigns state.held)]
  ?:  &(=(%noun mark) ?=([%native-coding-review-inspection-event-v1 *] q.vase))
    =/  parsed  ((soft event:nri) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(u.parsed q.vase)
    =/  next  (inspection-event:ncampaign bowl native-campaigns u.parsed)
    =/  notices=(list card)  ?:(=(native-campaigns state.next) ~ ~[(changed:ncode 0x0 0)])
    [(weld cards.next notices) this(native-campaigns state.next)]
  ?:  &(=(%noun mark) ?=([%native-coding-review-event-v1 *] q.vase))
    =/  parsed  ((soft event:nreviewer) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(u.parsed q.vase)
    =/  next  (receive:ncampaign bowl native-campaigns u.parsed)
    =/  notices=(list card)  ?:(=(native-campaigns state.next) ~ ~[(changed:ncode 0x0 0)])
    [(weld cards.next notices) this(native-campaigns state.next)]
  ?:  &(=(%noun mark) ?=([?(%native-coding-session-open-v1 %native-coding-session-open-v2) *] q.vase))
    ?.  =(our.bowl src.bowl)  `this
    =/  parsed  ((soft request:nopening) q.vase)
    ?~  parsed  `this
    ?>  =(u.parsed q.vase)
    =/  next  (begin:nopening bowl native-openings native-coding u.parsed)
    [cards.next this(native-openings openings.next, native-coding coding.next)]
  ?:  &(=(%noun mark) ?=([%native-coding-session-open-observe-v1 *] q.vase))
    ?.  =(our.bowl src.bowl)  `this
    =/  parsed  ((soft ,[%native-coding-session-open-observe-v1 id=@ux]) q.vase)
    ?~  parsed  `this
    ?>  =(u.parsed q.vase)
    =/  next  (observe:nopening bowl native-openings native-coding id.u.parsed)
    [cards.next this(native-openings openings.next, native-coding coding.next)]
  ?:  &(=(%noun mark) ?=([%native-coding-bootstrap-action-v1 *] q.vase))
    ?.  =(our.bowl src.bowl)  `this
    =/  parsed  ((soft ,[%native-coding-bootstrap-action-v1 action=command:nworkspace]) q.vase)
    ?~  parsed  `this
    =/  next  (act:nworkspace bowl native-workspace native-coding action.u.parsed)
    [cards.next this(native-workspace workspace.next, native-coding coding.next)]
  ?:  &(=(%noun mark) ?=([%native-coding-deployment-status-v1 *] q.vase))
    ?.  =(our.bowl src.bowl)  `this
    =/  parsed  ((soft ,[%native-coding-deployment-status-v1 id=@ux record=record:ndeploy]) q.vase)
    ?~  parsed  `this
    =/  next  (deployment-status:nworkspace bowl native-workspace native-coding id.u.parsed record.u.parsed)
    [cards.next this(native-workspace workspace.next)]
  ?:  &(=(%noun mark) ?=([%native-coding-review-action-v1 *] q.vase))
    ?.  =(our.bowl src.bowl)  `this
    =/  parsed  ((soft ,[%native-coding-review-action-v1 action=command:nreview]) q.vase)
    ?~  parsed  `this
    =/  hot  (hot-gate bowl %review-act)
    =/  next=change:nreview
      ?~  hot  (act:nreview bowl native-reviews native-coding action.u.parsed)
      (run:hotm change:nreview u.hot [bowl native-reviews native-coding action.u.parsed])
    [cards.next this(native-reviews reviews.next, native-coding coding.next)]
  ?:  &(=(%noun mark) ?=([%native-coding-candidate-status-v1 *] q.vase))
    ?.  =(our.bowl src.bowl)  `this
    =/  parsed  ((soft ,[%native-coding-candidate-status-v1 candidate=@ux record=record:naccept]) q.vase)
    ?~  parsed  `this
    =/  hot  (hot-gate bowl %review-status)
    =/  next=change:nreview
      ?~  hot  (status:nreview bowl native-reviews native-coding candidate.u.parsed record.u.parsed)
      (run:hotm change:nreview u.hot [bowl native-reviews native-coding candidate.u.parsed record.u.parsed])
    [cards.next this(native-reviews reviews.next, native-coding coding.next)]
  ?:  &(=(%noun mark) ?=([%native-coding-judge-v1 *] q.vase))
    ?.  =(our.bowl src.bowl)  `this
    =/  parsed  ((soft ,[%native-coding-judge-v1 session=@ux request=@ux]) q.vase)
    ?~  parsed  `this
    ?>  =(u.parsed q.vase)
    =/  held  (~(get by sessions.native-coding) session.u.parsed)
    ?~  held  `this
    ?.  &(=(%judgment phase.u.held) (gth turn.u.held 0))  `this
    ?.  =(request.u.parsed (request-id:nsession session.u.parsed (dec turn.u.held)))  `this
    =/  started
      (act:nccampaign bowl completion-campaigns native-coding scopes.native-campaigns [%start session.u.parsed])
    ?:  ?=(%& -.started)
      [(weld cards.p.started ~[(changed:ncode session.u.parsed `@ud`request.u.parsed)]) this(completion-campaigns state.p.started)]
    ?.  =(%completion-candidate-path p.started)
      [~[(refused:ncode session.u.parsed p.started)] this]
    =/  next  (complete:nreview bowl native-reviews native-coding session.u.parsed request.u.parsed)
    [(weld cards.next ~[(progress:nfinish our.bowl session.u.parsed)]) this(native-reviews reviews.next, native-coding coding.next)]
  ?:  &(=(%noun mark) ?=([%native-coding-fleet-action-v1 *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  parsed  ((soft ,[%native-coding-fleet-action-v1 action=action:nfleet]) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(q.vase u.parsed)
    =/  next  (fleet-action:ncode bowl native-coding moon-routes coding action.u.parsed)
    [-.next this(native-coding +.next)]
  ?:  &(=(%noun mark) ?=([%native-coding-fleet-wake-v1 *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  parsed  ((soft ,[%native-coding-fleet-wake-v1 revision=@ud]) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(q.vase u.parsed)
    =/  next  (fleet-wake:ncode bowl native-coding moon-routes coding revision.u.parsed)
    [-.next this(native-coding +.next)]
  ?:  &(=(%noun mark) ?=([%native-coding-moon-inspection *] q.vase))
    =/  parsed  ((soft inspection:nrelay) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(q.vase u.parsed)
    =/  next  (fleet-inspection:ncode bowl native-coding u.parsed)
    [-.next this(native-coding +.next)]
  ?:  &(=(%noun mark) ?=([%native-coding-moon-event *] q.vase))
    =/  parsed  ((soft event:nrelay) q.vase)
    ?>  ?=(^ parsed)
    ?>  =(q.vase u.parsed)
    =/  next  (moon-event:ncode bowl native-coding u.parsed)
    [-.next this(native-coding +.next)]
  ?:  &(=(%noun mark) ?=([%native-coding-action-v1 *] q.vase))
    ?.  =(our.bowl src.bowl)  `this
    =/  parsed  ((soft ,[%native-coding-action-v1 action=action:ncode]) q.vase)
    ?~  parsed  `this
    =/  next  (act:ncode bowl native-coding action.u.parsed)
    [-.next this(native-coding +.next)]
  ?:  &(=(%noun mark) ?=([%native-coding-event *] q.vase))
    ?.  =(our.bowl src.bowl)  `this
    =/  parsed  ((soft event:nprovider) q.vase)
    ?~  parsed  `this
    =/  hot  (hot-gate bowl %loop-model)
    =/  next=(quip card:agent:gall state:ncode)
      ?~  hot  (model-event:ncode bowl native-coding id.u.parsed session.u.parsed outcome.u.parsed)
      (run:hotm (quip card:agent:gall state:ncode) u.hot [bowl native-coding id.u.parsed session.u.parsed outcome.u.parsed])
    [-.next this(native-coding +.next)]
  ?:  &(=(%noun mark) ?=([%native-coding-tool-result-v1 *] q.vase))
    ?.  =(our.bowl src.bowl)  `this
    =/  parsed  ((soft tool-result:nct) q.vase)
    ?~  parsed  `this
    =/  hot  (hot-gate bowl %loop-tool)
    =/  next=(quip card:agent:gall state:ncode)
      ?~  hot  (tool-event:ncode bowl native-coding u.parsed)
      (run:hotm (quip card:agent:gall state:ncode) u.hot [bowl native-coding u.parsed])
    [-.next this(native-coding +.next)]
  ?:  &(=(%noun mark) ?=([%viki-project-develop *] q.vase))
    ?.  =(our.bowl src.bowl)  `this
    =/  parsed  ((soft ,[%viki-project-develop request=request:pcode]) q.vase)
    ?~  parsed  `this
    =/  occupied=(set @p)
      %-  silt
      %+  murn  ~(val by coding)
      |=  e=entry:gcl
      ?:  =(%finished phase.e)  ~
      `(model-moon:gcl e)
    =/  begun  (begin:devc bowl development occupied moon-routes workers request.u.parsed)
    ?:  ?=(%| -.begun)
      :_  this
      :~  (glass-generation-report nonce.request.u.parsed [%| p.begun])
          [%give %fact ~[/development/pataphor] %noun !>([%pataphor-development-refused-v1 nonce.request.u.parsed p.begun])]
      ==
    [(weld -.p.begun (change-cards:devc development +.p.begun)) this(development +.p.begun)]
  ?:  &(=(%noun mark) ?=([%viki-project-observe @] q.vase))
    ?.  =(our.bowl src.bowl)  `this
    =/  key=@ux  ;;(@ux +.q.vase)
    =/  next  (observe:devc bowl development moon-routes workers key)
    [(weld -.next (change-cards:devc development +.next)) this(development +.next)]
  ?:  &(=(%noun mark) ?=([%viki-glass-project-request-v1 *] q.vase))
    ?.  =(our.bowl src.bowl)  `this
    =/  parsed=(unit request:gpr)  ((soft ,request:gpr) q.vase)
    ?~  parsed  `this
    =/  begun  (begin:gpl bowl projects intents u.parsed)
    ?:  ?=(%| -.begun)
      [~[(glass-generation-report nonce.u.parsed [%| p.begun])] this]
    [cards.p.begun this(projects (~(put by projects) nonce.u.parsed entry.p.begun), intents intents.p.begun)]
  ?:  &(=(%noun mark) ?=([%viki-moon-routes-v1 *] q.vase))
    ?.  =(our.bowl src.bowl)  `this
    =/  parsed=(unit [%viki-moon-routes-v1 selected=(list moon-route:vr)])
      ((soft ,[%viki-moon-routes-v1 selected=(list moon-route:vr)]) q.vase)
    ?~  parsed  `this
    ?.  (agent-live:vsg our.bowl now.bowl %seat-warden)  `this
    =/  table=table:vms
      .^(table:vms %gx /(scot %p our.bowl)/seat-warden/(scot %da now.bowl)/table/noun)
    ?.  (routes-allowed:vmr our.bowl now.bowl table selected.u.parsed)  `this
    [~ this(moon-routes selected.u.parsed)]
  ?:  &(=(%noun mark) ?=([%viki-glass-coding-generate *] q.vase))
    ?.  =(our.bowl src.bowl)  `this
    =/  parsed=(unit action:vgc)  ((soft ,action:vgc) q.vase)
    ?~  parsed  `this
    =/  a=action:vgc  u.parsed
    ::  Replay lookup precedes fresh source/law reads. Keep the original
    ::  admission time and request instead of manufacturing a new attempt.
    =/  prior  (~(get by coding) nonce.a)
    ?^  prior
      ?.  =(a (action-for:gcr (prepared:gcl u.prior)))
        [~[(glass-generation-report nonce.a [%| %attempt-conflict])] this]
      [~[(report:gcl u.prior)] this]
    =/  ready  (prepare:vgc our.bowl src.bowl now.bowl moon-routes intents workers a)
    ?:  ?=(%| -.ready)  [~[(glass-generation-report nonce.a [%| p.ready])] this]
    ?:  %+  lien  ~(val by development)
        |=  e=entry:devc
        &(!=(%finished stage.e) =((moon:devc e) moon.seat-session.route:(base:vgc p.ready)))
      [~[(glass-generation-report nonce.a [%| %moon-session-busy])] this]
    =/  begun  (start:gcl our.bowl src.bowl now.bowl coding p.ready)
    ?:  ?=(%| -.begun)  [~[(glass-generation-report nonce.a [%| p.begun])] this]
    ::  GEOMETRY CONTROLS (flect phase 11, the glass lane): the admitted
    ::  generation act [nonce evidence] against the glass law
    ::  (lib/cantrip-glass-flect, proven to agree with the judge on every
    ::  fixture, verdict and reason).  The judge admitted; if the law does
    ::  not, the generation is refused as %law-control-disagrees -- fail
    ::  closed, named.  The receipt is an append-only graf fact.
    =/  adm=admission:generation  admission:(base:vgc p.ready)
    =/  sh
      %-  shadow-with:shadow
      :*  %glass-generation  glass-law:gflect
          !>(`act:gflect`[nonce.adm evidence.adm])
          `env:gflect`[our.bowl src.bowl now.bowl]  [%& ~]
      ==
    ?.  fit.verdict.receipt.sh
      [~[(glass-generation-report nonce.a [%| %law-control-disagrees])] this]
    =/  receipt-card=card:agent:gall
      [%pass /glass-generation-evidence %agent [our.bowl %graf] %poke %graf-action !>([%attest (fact:shadow sh)])]
    [(snoc -.p.begun receipt-card) this(coding (~(put by coding) nonce.a +.p.begun))]
  ?:  &(=(%noun mark) ?=([%viki-glass-coding-cancel @ @] q.vase))
    ?.  =(our.bowl src.bowl)  `this
    =/  [key=@ux expected=@ux]  ;;([@ux @ux] +.q.vase)
    =/  next  (start:gcan bowl coding key expected)
    ?:  ?=(%| -.next)
      [~[(glass-generation-report key [%| p.next])] this]
    [-.p.next this(coding +.p.next)]
  ?:  &(=(%noun mark) ?=([%viki-glass-coding-correct @] q.vase))
    ?.  =(our.bowl src.bowl)  `this
    =/  key=@ux  ;;(@ux +.q.vase)
    =/  cancelled  (~(get by coding) key)
    ?:  ?&  ?=(^ cancelled)  =(%finished phase.u.cancelled)
            paused.u.cancelled  =(`%operator-cancelled reason.u.cancelled)
        ==
      [~[(report:gcl u.cancelled)] this]
    =/  next  (start:gcc bowl coding moon-routes intents workers key)
    ?:  ?=(%& -.next)  [-.p.next this(coding +.p.next)]
    =/  prior  (~(get by coding) key)
    ?~  prior  [~[(glass-generation-report key [%| p.next])] this]
    =/  e=entry:gcl  u.prior(reason `p.next)
    [~[(report:gcl e)] this(coding (~(put by coding) key e))]
  ?:  &(=(%noun mark) ?=([%viki-glass-coding-observe @] q.vase))
    ?.  =(our.bowl src.bowl)  `this
    =/  key=@ux  ;;(@ux +.q.vase)
    =/  prior  (~(get by coding) key)
    ?~  prior  [~[(glass-generation-report key [%| %attempt-missing])] this]
    =/  observed  ~(observe hc:gcl [bowl u.prior moon-routes intents workers])
    [-.observed this(coding (~(put by coding) key +.observed))]
  ?:  &(=(%noun mark) ?=([%viki-connected-judge-v2 *] q.vase))
    ?.  =(our.bowl src.bowl)  `this
    =/  parsed=(unit action:vcj)  ((soft ,action:vcj) q.vase)
    ?~  parsed  `this
    =/  a=action:vcj  u.parsed
    =/  prior  (lookup:vcj our.bowl src.bowl now.bowl connected-judgments a)
    ?:  ?=(%| -.prior)  [~[(connected-report nonce.a [%| p.prior])] this]
    ?^  p.prior  [~[(connected-report nonce.a prior)] this]
    ?:  (gte ~(wyt by connected-judgments) 128)
      [~[(connected-report nonce.a [%| %judgment-capacity])] this]
    =/  judged  (from-viki:vcjr our.bowl src.bowl now.bowl intents a)
    ?:  ?=(%| -.judged)  [~[(connected-report nonce.a [%| p.judged])] this]
    =/  reserved  (reserve:vcj our.bowl src.bowl now.bowl connected-judgments a p.judged)
    ?:  ?=(%| -.reserved)  [~[(connected-report nonce.a [%| p.reserved])] this]
    :_  this(connected-judgments next.p.reserved)
    :~  [%pass /connected-judgment-retain/(scot %ux nonce.a)/(scot %ux digest.p.judged) %agent [our.bowl %graf] %poke %graf-action !>([%attest (fact:vcj p.judged)])]
        (connected-report nonce.a [%& `entry.p.reserved])
    ==
  ?:  &(=(%noun mark) ?=([%viki-connected-judge-observe-v2 *] q.vase))
    ?.  =(our.bowl src.bowl)  `this
    =/  parsed=(unit [%viki-connected-judge-observe-v2 nonce=@ux])
      ((soft ,[%viki-connected-judge-observe-v2 nonce=@ux]) q.vase)
    ?~  parsed  `this
    ?.  (nonce-valid:vcj nonce.u.parsed)  `this
    =/  observed  (connected-observe our.bowl now.bowl connected-judgments nonce.u.parsed)
    [-.observed this(connected-judgments +.observed)]
  ?:  &(=(%noun mark) ?=([%viki-connected-review *] q.vase))
    [(start:vci our.bowl src.bowl now.bowl q.vase) this]
  ?:  &(=(%noun mark) ?=([%viki-connected-review-v2 *] q.vase))
    [(start-v2:vci bowl q.vase) this]
  ::  The cockpit may state intent, but it cannot supply provenance, sequence,
  ::  time, role, or authority.  This transition records only; it emits no
  ::  execution, model, Graf, or wake card.
  ?:  =(%viki-intent-submit mark)
    =/  item=(unit action:itn)  ((soft action:itn) q.vase)
    ?~  item
      ~&  >>>  [%viki %intent-submit-malformed]
      `this
    =/  applied=result:itn
      (apply:vil intents u.item our.bowl src.bowl now.bowl)
    ?-  -.verdict.applied
      %refused
        ~&  >>>  [%viki %intent-submit-refused reason.verdict.applied]
        `this
      %accepted
        =/  next  this(intents organ.applied)
        ?.  created.admission.verdict.applied  `next
        :_  next
        ~[[%give %fact ~[/intents] %noun !>(record.admission.verdict.applied)]]
    ==
  ::  A proposal is selected by Viki, judged against Cantrip's current law,
  ::  and retained in Graf whether admitted or refused.  It remains inert:
  ::  execution-admitted is false by construction and no dispatch card exists.
  ?:  =(%viki-vibecoding-proposal mark)
    ?.  =(our.bowl src.bowl)
      ~&  >>>  [%viki %foreign-vibecoding-proposal-refused src.bowl]
      `this
    =/  item=(unit action:vp)  ((soft action:vp) q.vase)
    ?~  item
      ~&  >>>  [%viki %vibecoding-proposal-malformed]
      `this
    =/  proposal=proposal:vp  proposal.u.item
    =/  intent-id=intent-id:itn  intent-id.origin.body.proposal
    =/  source=(unit intent:itn)  (~(get by intents-by-id.intents) intent-id)
    ?~  source
      ~&  >>>  [%viki %vibecoding-proposal-intent-missing intent-id]
      `this
    ?.  (agent-live:vsg our.bowl now.bowl %cantrip)
      ~&  >>>  [%viki %vibecoding-proposal-cantrip-unavailable]
      `this
    =/  window=window:clw
      .^  window:clw  %gx
          /(scot %p our.bowl)/cantrip/(scot %da now.bowl)/law/window/current/noun
      ==
    =/  law=law-binding:vp  (law-binding-for:cvp 1 window)
    =/  verdict=verdict:vp
      (judge:cvp proposal u.source request.u.item result.u.item law)
    =/  record=record:vp  (record-for:cvp proposal verdict now.bowl)
    :_  this
    :~  (light-card our.bowl (fact:cvp record))
        [%give %fact ~[/vibecoding-proposals] %noun !>(record)]
    ==
  ::  The bounded worker result is evidence, not authority.  Only the
  ::  sovereign ship may submit it, and the exact proposal record must already
  ::  exist in Graf.  Its dispatch must be an exact canonical Cantrip receipt;
  ::  a caller-supplied verdict alone has no authority.  Viki recomputes the
  ::  artifact verdict before retention.
  ?:  =(%viki-vibecoding-artifact mark)
    ?.  =(our.bowl src.bowl)
      ~&  >>>  [%viki %foreign-vibecoding-artifact-refused src.bowl]
      `this
    =/  item=(unit action:va)  ((soft action:va) q.vase)
    ?~  item
      ~&  >>>  [%viki %vibecoding-artifact-malformed]
      `this
    =/  proposal-record=record:vp  proposal.u.item
    ?.  (record-valid:cvp proposal-record)
      ~&  >>>  [%viki %vibecoding-artifact-proposal-invalid]
      `this
    ?.  (agent-live:vsg our.bowl now.bowl %graf)
      ~&  >>>  [%viki %vibecoding-artifact-graf-unavailable]
      `this
    =/  proposal-fact=*  (fact:cvp proposal-record)
    =/  proposal-present=?
      .^  ?  %gx
          /(scot %p our.bowl)/graf/(scot %da now.bowl)/contains/(scot %uw (jam proposal-fact))/noun
      ==
    ?.  proposal-present
      ~&  >>>  [%viki %vibecoding-artifact-proposal-missing digest.proposal-record]
      `this
    =/  proposal=proposal:vp  proposal.body.proposal-record
    =/  receipt=receipt:vdr  receipt.u.item
    ?.  (valid-receipt:vdrl receipt)
      ~&  >>>  [%viki %vibecoding-artifact-receipt-invalid key.receipt]
      `this
    ?.  (agent-live:vsg our.bowl now.bowl %cantrip)
      ~&  >>>  [%viki %vibecoding-artifact-cantrip-unavailable]
      `this
    =/  observed=(unit receipt:vdr)
      .^  (unit receipt:vdr)  %gx
          /(scot %p our.bowl)/cantrip/(scot %da now.bowl)/vibecoding/dispatch-receipt/(scot %ux key.receipt)/noun
      ==
    ?~  observed
      ~&  >>>  [%viki %vibecoding-artifact-receipt-missing key.receipt]
      `this
    ?.  =(u.observed receipt)
      ~&  >>>  [%viki %vibecoding-artifact-receipt-mismatch key.receipt]
      `this
    =/  decision=decision:vd  decision.body.receipt
    ?.  decided.decision
      ~&  >>>  [%viki %vibecoding-artifact-dispatch-undecided key.receipt]
      `this
    ?~  result.decision
      ~&  >>>  [%viki %vibecoding-artifact-dispatch-result-missing key.receipt]
      `this
    =/  dispatch=verdict:vd  u.result.decision
    ?.  allowed.dispatch
      ~&  >>>  [%viki %vibecoding-artifact-dispatch-refused key.receipt]
      `this
    =/  artifact=artifact:va  artifact.u.item
    =/  verdict=verdict:va  (inspect:val artifact proposal dispatch)
    =/  record=record:va
      (record-for:val proposal-record receipt dispatch artifact verdict now.bowl our.bowl)
    :_  this
    :~  (light-card our.bowl (fact:val record))
        [%give %fact ~[/vibecoding-artifacts] %noun !>(record)]
    ==
  ::  Local work has no moon dispatch receipt. Viki reads its exact native
  ::  write/image/run evidence and its OWN intent organ before judging it.
  ::  Judgment remains inert; neither a fact nor an ACK means files landed.
  ?:  =(%viki-vibecoding-local-judgment mark)
    ?.  =(our.bowl src.bowl)  `this
    =/  item=(unit action:vlj)  ((soft ,action:vlj) q.vase)
    ?~  item  `this
    =/  judged=result:vlj
      (judge:vljr our.bowl src.bowl now.bowl intents u.item)
    =/  report=card
      [%give %fact ~[/vibecoding-local-judgments] %noun !>([nonce.u.item judged])]
    ?:  ?=(%| -.judged)  [~[report] this]
    :_  this
    :~  [%pass /local-judgment/(scot %ux digest.p.judged) %agent [our.bowl %graf] %poke %graf-action !>([%attest (fact:vlj p.judged)])]
        report
    ==
  ::  An operator judgment cites the exact content-addressed artifact.  Viki
  ::  authenticates the actor from Ames, recomputes artifact readiness, and
  ::  publishes an immutable fact; it does not execute or land anything.
  ?:  =(%viki-vibecoding-judgment mark)
    =/  item=(unit action:vjv)  ((soft action:vjv) q.vase)
    ?~  item
      ~&  >>>  [%viki %vibecoding-judgment-malformed]
      `this
    =/  judged=result:vjv
      (judge:vvj u.item our.bowl src.bowl now.bowl)
    ?-  -.judged
      %refused
        ~&  >>>  [%viki %vibecoding-judgment-refused reasons.judged]
        `this
      %accepted
        :_  this
        :~  (light-card our.bowl (fact:vvj judgment.judged))
            [%give %fact ~[/vibecoding-judgments] %noun !>(judgment.judged)]
        ==
    ==
  ::  Edited-model lifecycle authority lives inside canonical Viki.  The
  ::  same-ship check authenticates sovereign ingress; only this app owns and
  ::  persists the resulting registry state.
  ?:  =(%viki-model-registry-action mark)
    ?.  =(our.bowl src.bowl)
      ~&  >>>  [%viki %foreign-model-registry-action-refused src.bowl]
      `this
    =/  action=(unit action:mr)  ((soft action:mr) q.vase)
    ?~  action
      ~&  >>>  [%viki %malformed-model-registry-action]
      `this
    =/  applied  (apply:mar registry u.action leaves:wl now.bowl)
    ?:  ?=(%| -.applied)
      ~&  >>>  [%viki %model-registry-action-refused p.applied]
      `this
    `this(registry p.applied)
  ::  Bridge migration is a self-only, cardless shadow import.  It cannot
  ::  claim Lick or dispatch model work; those remain with %model-bridge.
  =/  bridge-action=(unit bridge-action:vb)
    ?:(=(%noun mark) ((soft bridge-action:vb) q.vase) ~)
  ?^  bridge-action
    ?.  =(our.bowl src.bowl)
      ~&  >>>  [%viki %foreign-bridge-migration-refused src.bowl]
      `this
    =/  migrated=migration-result:vb
      (apply-action:vbm bridge u.bridge-action our.bowl now.bowl)
    `this(bridge organ.migrated)
  ::  Absorbed tensor observations are self-only pure transitions of the
  ::  native organ; no card can result.
  =/  tensor-action=(unit action:vto)
    ?:(=(%noun mark) ((soft action:vto) q.vase) ~)
  ?^  tensor-action
    ?.  =(our.bowl src.bowl)
      ~&  >>>  [%viki %foreign-tensor-observation-refused src.bowl]
      `this
    `this(tensor (apply:vta tensor u.tensor-action))
  ::  THE RECURRENCE BEAT (rehearsal finding R1).  Waterwheel owns recurrence
  ::  but is a CLOCK, not a data broker: it wakes a target and carries no
  ::  payload.  The donors' timers fetched first and poked second, so the
  ::  absorbed observation surfaces above require the observed datum as their
  ::  payload.  A beat therefore SELF-FETCHES: Viki reads the latest result
  ::  from its OWN bridge shadow -- no scry, no card, and no dependence on the
  ::  retiring donor.  Dedup by request id lives in the pure transition, so a
  ::  beat with nothing new is inert.  The trailing entry id the scheduler
  ::  sends is accepted and ignored.
  ?:  ?&(=(%noun mark) ?=([%viki-tensor-beat *] q.vase))
    ?.  =(our.bowl src.bowl)
      ~&  >>>  [%viki %foreign-tensor-beat-refused src.bowl]
      `this
    =/  latest=(unit model-bridge-result:mb)  latest-result.working.bridge
    ?~  latest  `this
    `this(tensor (observe-model:vta tensor u.latest))
  ::  THE GOVERNANCE CLOCK (F5, donor viki-tensor-governor).  The absorbed
  ::  policy is computed law, not stored state: the beat recomputes the
  ::  organ's own verdict so the ~m5 clock proves the loop is watched, and
  ::  says so out loud when it degrades.  The donor's ACTIVE intervention
  ::  (%turn-seed) stays retired behind the autonomy gate -- re-entry is an
  ::  operator ruling, never a timer side-effect.  Trailing entry id the
  ::  scheduler sends is accepted and ignored.
  ?:  ?&(=(%noun mark) ?=([%tensor-govern-sync *] q.vase))
    ?.  =(our.bowl src.bowl)
      ~&  >>>  [%viki %foreign-govern-sync-refused src.bowl]
      `this
    =/  q=ct-qualia-full:qcq
      (soma-qualia:qcq window.tensor obs:vta 1.000.000)
    =/  verdict=@tas  verdict:(ct-govern:qcq q)
    ~?  =(%degenerate verdict)  [%viki %tensor-govern-sync %degenerate-verdict]
    ::  THE LAW HEARTBEAT (repair-governor pattern): every govern-sync
    ::  beat rebuilds the canon-held law and pushes it to the model
    ::  organ.  Idempotent; a missed push self-heals on the next beat.
    =/  pushed=held:cl  (canon-held-view our.bowl now.bowl)
    :_  this
    :~  :*  %pass  /hold-push  %agent  [moon %viki-model]  %poke
            %viki-inference  !>(`action:vi`[%hold pushed])
        ==
        ::  the console worker holds the SAME law: one canon, two
        ::  enforcement sites, no drift between the lanes.
        :*  %pass  /hold-push-serve  %agent  [moon %llm-serve]  %poke
            %viki-inference  !>(`action:vi`[%hold pushed])
        ==
    ==
  ::  Absorbed cortex seats + advice (the split's Viki half): self-only
  ::  pure transitions of the native organ; the LEASE leg reads the worker
  ::  shadow's Warden grants in-core.  No card can result.  (The donor
  ::  admitted its own moons; Viki is stricter until the consent lane
  ::  routes delegated proposals.)
  =/  seat-action=(unit action:vsl)
    ?:(=(%noun mark) ((soft action:vsl) q.vase) ~)
  ?^  seat-action
    ?.  =(our.bowl src.bowl)
      ~&  >>>  [%viki %foreign-seat-action-refused src.bowl]
      `this
    `this(seats (apply:vsa seats grants.core.workers u.seat-action now.bowl))
  ::  A GRAF SEAT CLAIM.  Note this is a DIFFERENT seat from the arm above:
  ::  that one is the absorbed cortex's bound-worker seat, this is a write
  ::  region in graf's axis tree.  The names collide; the things do not.
  ::
  ::  Unlike every other arm here, this one admits a foreign src -- that is
  ::  the whole point.  graf now refuses %record-seat-write from anyone but
  ::  this ship, so a moon asks HERE, where the moon-grants live, and viki
  ::  records the claim on its behalf if the lease bears it.
  ::
  ::  The decision itself is lib/viki-graf-seat, proven by
  ::  ted/ph/viki-graf-seat-proof.  Nothing below decides anything; it
  ::  gathers the three inputs the law needs and sends what the law says.
  =/  seat-claim=(unit claim-request:gsc)
    ?:(=(%noun mark) ((soft claim-request:gsc) q.vase) ~)
  ?^  seat-claim
    =*  req  u.seat-claim
    =/  sponsor=@p  (^sein:title src.bowl)
    ::  the law re-checks this; the check here is about not doing work for
    ::  strangers, not about authority.  Do not "deduplicate" them -- the
    ::  law must stay complete enough for a thread to prove standalone.
    ?.  ?|(=(our.bowl src.bowl) =(our.bowl sponsor))
      ~&  >>>  [%viki %graf-seat-claim-refused %not-family seat.req src.bowl]
      `this
    ::  OCCUPANCY IS READ FROM GRAF, AND AN UNREADABLE GRAF REFUSES.
    ::  Treating a graf we cannot read as an empty seat would fail OPEN in
    ::  exactly the way the measured takeover did.
    ::
    ::  MEASURED 2026-08-16 on ~sampel-palnet, because the obvious version
    ::  of this was wrong in two ways at once and built perfectly anyway:
    ::
    ::    - `mule` does NOT catch a failed `.^`.  The first draft wrapped
    ::      both scries in mule and would have CRASHED this poke whenever
    ::      the seat was free -- the commonest case there is.
    ::    - a %gu beam needs the trailing /$.  Without it the scry bails
    ::      rather than answering %.n.
    ::
    ::  So neither scry below may be allowed to fail.  %gu answers whether
    ::  graf is running, and /seat/<id>/holder answers with a unit, which
    ::  is why that peek was added to graf rather than reusing /latest --
    ::  /latest expresses "unheld" and "unreadable" as the same crash.
    ?.  .^(? %gu (weld /(scot %p our.bowl)/graf/(scot %da now.bowl) /$))
      ~&  >>>  [%viki %graf-seat-claim-refused %graf-unreadable seat.req src.bowl]
      `this
    ::  a path literal cannot interpolate a variable, and the seat is one.
    =/  seat-path=path
      %+  weld  /(scot %p our.bowl)/graf/(scot %da now.bowl)/seat
      ~[seat.req %holder %noun]
    =/  holder  .^((unit graf-seat-write:graf-sur) %gx seat-path)
    =/  held=(list graf-seat-write:graf-sur)
      (occupancy:vgsr our.bowl src.bowl root-id.req seat.req session.req now.bowl holder workers)
    =/  verdict
      %:  claim-action:vgseat
        grants.core.workers  held  root-id.req  seat.req
        src.bowl  sponsor  our.bowl  session.req
        seq.core.workers  now.bowl
      ==
    ?:  ?=(%| -.verdict)
      ~&  >>>  [%viki %graf-seat-claim-refused why.p.verdict seat.req src.bowl note.p.verdict]
      `this
    :_  this
    ~[(graf-poke our.bowl p.verdict)]
  ::  Absorbed model I/O (ladder 13): the gateway's one-at-a-time admission
  ::  and untrusted-claim law plus the terminal's correlation law as
  ::  self-only pure transitions.  Model output is retained as typed data
  ::  and never executed; transports stay in the donor shells until cutover.
  =/  modelio-action=(unit action:vmi)
    ?:(=(%noun mark) ((soft action:vmi) q.vase) ~)
  ?^  modelio-action
    ?.  =(our.bowl src.bowl)
      ~&  >>>  [%viki %foreign-model-io-refused src.bowl]
      `this
    `this(modelio (apply:vml modelio u.modelio-action now.bowl))
  ::  Waterwheel submits inert candidate data through the universal noun mark;
  ::  this soft cast is the typed authority boundary.
  ?:  ?&(=(%noun mark) ?=([%viki-glass-judge *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  candidate=(unit candidate:bj)
      ((soft candidate:bj) +.q.vase)
    ?~  candidate  `this
    =/  judged=(unit bound-judgment:bj)
      (adjudicate:bj u.candidate)
    ?~  judged
      ~&  >>>  [%viki %glass-candidate-over-budget]
      `this
    =/  authority=judgment-authority
      (trusted-judgment-authority our.bowl)
    =/  next=(unit judgment-chain)
      (append-judgment judgments u.judged authority)
    ?~  next
      ~&  >>>  [%viki %glass-judgment-chain-invalid]
      `this
    :_  this(judgments.state u.next)
    ~[[%pass /glass/judgment %agent [our.bowl %waterwheel] %poke %noun !>([%viki-glass-judged evidence-digest.u.judged])]]
  ?:  ?&(=(%noun mark) ?=([%viki-reconsider @] q.vase))
    ?>  =(our.bowl src.bowl)
    ?^  reconsideration  `this
    =/  id=(unit @ux)  ((soft @ux) +.q.vase)
    ?~  id  `this
    ?:  ?&  ?=(^ last-reconsideration)  =(u.id u.last-reconsideration)  ==  `this
    =/  work=(unit reconsideration-work)
      (reconsideration-work-for our.bowl now.bowl u.id)
    ?~  work  `this
    :_  this(last-reconsideration.state `u.id, reconsideration.state work)
    ?:(armed ~[(tick-card now.bowl ~s0)] ~)
  ?+    mark  (on-poke:def mark vase)
  ::  Worker-control migration and cutover are self-only.  Commands execute
  ::  consequences only after the imported worker organ becomes authoritative.
      %viki-worker-action
    =/  move=worker-action:vw  !<(worker-action:vw vase)
    ?-  -.move
      %viki-worker-bootstrap
        ?>  =(our.bowl src.bowl)
        ?.  (agent-live:vsg our.bowl now.bowl %nets)
          ~&  >>>  [%viki %worker-bootstrap-refused %nets-unavailable]
          `this
        =/  donor=(unit worker-snapshot:vw)
          .^((unit worker-snapshot:vw) %gx /(scot %p our.bowl)/nets/(scot %da now.bowl)/migration/viki-worker-export/noun)
        =/  nets-authoritative=?
          .^(? %gx /(scot %p our.bowl)/nets/(scot %da now.bowl)/shadow/moon-warden/authoritative/noun)
        =/  boot=migration-result:vw
          (bootstrap:vwa workers donor nets-authoritative)
        `this(workers organ.boot)
      %viki-worker-import
        ?>  =(our.bowl src.bowl)
        =/  migrated=migration-result:vw
          (import-shadow:vwm workers snapshot.move our.bowl now.bowl)
        `this(workers organ.migrated)
      %viki-worker-replace
        ?>  =(our.bowl src.bowl)
        =/  migrated=migration-result:vw
          (replace-shadow:vwm workers expected.move snapshot.move our.bowl now.bowl)
        `this(workers organ.migrated)
      %viki-worker-promote
        ?>  =(our.bowl src.bowl)
        =/  observed=(each ? tang)
          ?.  (agent-live:vsg our.bowl now.bowl %nets)  [%| ~]
          %-  mule
          |.(.^(? %gx /(scot %p our.bowl)/nets/(scot %da now.bowl)/shadow/moon-warden/authoritative/noun))
        =/  nets-authoritative=?  ?:(?=(%& -.observed) p.observed %.y)
        =/  promoted=migration-result:vw
          (promote:vwa workers expected.move nets-authoritative)
        `this(workers organ.promoted)
      %viki-worker-demote
        ?>  =(our.bowl src.bowl)
        `this(workers (demote:vwa workers reason.move))
      %viki-worker-command
        ?.  authoritative.workers  `this
        =/  action=warden-action:mg  action.move
        =/  grantee-sponsor=@p
          ?+  -.action  our.bowl
            %grant-moon-authority  (^sein:title grantee.action)
          ==
        =/  donor=worker-engine-result:vw
          %-  apply-action:viki-worker-engine
          :*  (donor-organ:vwa workers)  action  now.bowl  src.bowl
              our.bowl  (^sein:title src.bowl)  grantee-sponsor
          ==
        =/  next-workers=worker-organ:vw  (absorb-donor:vwa workers donor)
        :_  this(workers next-workers)
        (materialize:viki-worker-cards our.bowl now.bowl donor)
    ==
  ::
  ::  SUMMON.  A familiar is armed deliberately; installing it starts
  ::  nothing.  Arming threads its genesis turn and starts the tick.
      %viki-arm
    ?>  =(our.bowl src.bowl)
    ?.  (routes-allowed our.bowl routes)
      [~[(say-card "Choose an owner-valid model route before arming Viki.")] this]
    ?:  armed  `this
    :_  this(armed.state %.y, head.state +(head), budget.state default-budget)
    :-  (tick-card now.bowl every)
    (thread-cards our.bowl [fid head] [%rest %nothing-new] ~)
  ::
      %viki-disarm
    ?>  =(our.bowl src.bowl)
    `this(armed.state %.n)
  ::
  ::  OPERATOR SURGERY (incident ptf-484): drop the held flight and its
  ::  landing-retry loop.  The 2026-08-14 landing chain crashes the pier
  ::  at gall's take (kernel-level, unfixed); a held result re-attempts
  ::  that landing every `every` FOREVER, including from on-load — so a
  ::  poisoned flight must be droppable without a landing.  The want
  ::  stays open in Graf: clearing pending loses no durable state, only
  ::  the in-memory result, which the moon can re-derive.
      %viki-clear-pending
    ?>  =(our.bowl src.bowl)
    `this(pending.state ~, round.state ~)
  ::
  ::  Recover one exact durable model flight. Resume recreates only transient
  ::  effects. Cancel becomes a bound refusal and still requires Graf's
  ::  semantic landing before the flight can clear.
      %viki-recovery
    ?>  =(our.bowl src.bowl)
    =/  selected=(unit action:vrc)  ((soft action:vrc) q.vase)
    ?~  selected  `this
    ?~  pending  `this
    =/  held=flight  u.pending
    ?.  =(request-id.u.selected request-id.request.held)  `this
    ?-  -.u.selected
      %resume
        =/  recovered=pending-recovery
          (recover-pending our.bowl now.bowl routes round pending every)
        [cards.recovered this(pending.state pending.recovered)]
      %cancel
        ?^  result.held  `this
        =/  route=model-route  (active-route routes round)
        =/  refused=result:vi
          (refusal-result our.bowl now.bowl held %cancelled)
        =/  cleanup=(list card)
          ?-  -.route
            %local  ~
            %connected
              :~  (bridge-cancel-card our.bowl held 'operator cancelled viki model request')
                  (bridge-leave-card our.bowl held)
              ==
          ==
        :_  this(pending.state `held(result `refused))
        %+  weld  cleanup
        :~  (cancel-timeout-card held)
            (landing-card our.bowl t.held refused)
            (landing-retry-card now.bowl every)
        ==
    ==
  ::
  ::  Restore only operational configuration from a digest-bound snapshot of
  ::  this ship. Cognition, identity, pending work, judgments, and Graf memory
  ::  are intentionally absent from the snapshot and cannot be rewound here.
      %viki-config-restore
    ?>  =(our.bowl src.bowl)
    ?:  ?|(?=(^ pending) ?=(^ round))  `this
    =/  backup=(unit snapshot:vcf)  ((soft snapshot:vcf) q.vase)
    ?~  backup  `this
    ?.  (intact:vcf u.backup)  `this
    ?.  =(our.bowl source-ship.u.backup)  `this
    ?.  (routes-allowed our.bowl routes.u.backup)  `this
    ?:  =(routes routes.u.backup)
      `this(retry-policy.state retry-policy.u.backup, budget.state budget.u.backup, every.state interval.u.backup)
    =/  update=route-update
      (route-update-for %restore route-revision route-history routes routes.u.backup ~ now.bowl)
    `this(routes.state routes.update, route-revision.state revision.update, route-history.state history.update, retry-policy.state retry-policy.u.backup, budget.state budget.u.backup, every.state interval.u.backup)
  ::
  ::  MODEL ROUTE CONFIGURATION.  One typed action selects either an immediate
  ::  child moon or a connected Bachelor.  An in-flight want freezes the
  ::  selected route, and connected identity must agree with its oracle.
      %viki-route
    ?>  =(our.bowl src.bowl)
    ?:  ?|(?=(^ pending) ?=(^ round))  `this
    =/  selected=(unit model-route)
      ((soft model-route) q.vase)
    ?~  selected  `this
    ?.  (route-allowed our.bowl u.selected)  `this
    =/  next=(list model-route)  ~[u.selected]
    ?:  =(routes next)  `this
    =/  update=route-update
      (route-update-for %replace route-revision route-history routes next ~ now.bowl)
    `this(routes.state routes.update, route-revision.state revision.update, route-history.state history.update)
  ::
  ::  A goal may ask several distinct model identities, but Viki dispatches
  ::  them serially and remains the only component that compares the results.
      %viki-routes
    ?>  =(our.bowl src.bowl)
    ?:  ?|(?=(^ pending) ?=(^ round))  `this
    =/  selected=(unit (list model-route))
      ((soft (list model-route)) q.vase)
    ?~  selected  `this
    ?.  (routes-allowed our.bowl u.selected)  `this
    ?:  =(routes u.selected)  `this
    =/  update=route-update
      (route-update-for %replace route-revision route-history routes u.selected ~ now.bowl)
    `this(routes.state routes.update, route-revision.state revision.update, route-history.state history.update)
  ::
  ::  Restore the route set that preceded a retained replacement revision.
  ::  The rollback is itself journaled as a new revision; it never rewinds
  ::  Viki/Bride identity, Graf memory, judgments, or in-flight work.
      %viki-route-rollback
    ?>  =(our.bowl src.bowl)
    ?:  ?|(?=(^ pending) ?=(^ round))  `this
    =/  target=(unit @ud)  ((soft @ud) q.vase)
    ?~  target  `this
    =/  matches=(list route-change)
      %+  skim  route-history
      |=(change=route-change =(revision.change u.target))
    ?~  matches  `this
    =/  next=(list model-route)  previous.i.matches
    ?.  (routes-allowed our.bowl next)  `this
    ?:  =(routes next)  `this
    =/  update=route-update
      (route-update-for %rollback route-revision route-history routes next `u.target now.bowl)
    `this(routes.state routes.update, route-revision.state revision.update, route-history.state history.update)
  ::
  ::  BOUNDED NICK TURN.  Viki deliberately supplies the finite response
  ::  vocabulary.  The same output noun binds local Maroon logits or becomes
  ::  the connected provider enum; the returned term is only a derivation for
  ::  Viki to judge and is never dispatched as an action here.
      %viki-nick
    ?>  =(our.bowl src.bowl)
    ?.  armed  `this
    ?.  (routes-allowed our.bowl routes)
      [~[(say-card "Choose an owner-valid model route before requesting model work.")] this]
    ?:  ?|(?=(^ pending) ?=(^ round))  `this
    =/  item=intent:vni  !<(intent:vni vase)
    ?.  (valid:vni item)  `this
    =/  route=model-route  (primary-route routes)
    =/  refs=(list ref:ask-build)
      (recall-for our.bowl now.bowl prompt.item)
    =/  ordered=(list ref:ask-build)  (order-refs:ask-build refs)
    =/  moves=(list @tas)  (normalized-moves:vni moves.item)
    =/  nick-law=gen-law:dvn
      (law-for-purpose (canon-held-view our.bowl now.bowl) %nick ask-law)
    =/  a=ask:dvn
      (build:ask-build (task:vni item) ordered (oracle-for-route route) nick-law)
    =/  slot=(set rel:dvn)  (my-slot our.bowl now.bowl)
    =/  t=turn-id:fam  [fid head]
    =/  cached=(unit derivation:dvn)  (find-answer:dvn slot a)
    ?^  cached
      :_  this(head.state +(head))
      %+  snoc
        (thread-cards our.bowl t [%thought u.cached] ~)
      (say-card (trip text.u.cached))
    =/  refused=(unit refusal:dvn)  (find-refusal:dvn slot a)
    ?^  refused
      :_  this(head.state +(head))
      %+  snoc
        (thread-cards our.bowl t [%rest %nothing-wanted] ~)
      (say-card (trip (rap 3 ~['[refused: ' why.u.refused ']'])))
    =/  wnt=want:dvn
      [a %viki %nick now.bowl (turn ordered |=(ref=ref:ask-build handle.ref))]
    =/  request=request-v2:vi
      (request-for-route-output route wnt [%nick moves])
    =/  held=flight  [t wnt request now.bowl ~]
    :_  this(head.state +(head), pending.state `held)
    %+  snoc
      %+  weld
        :~  (light-card our.bowl [%want wnt])
            (publish-card our.bowl (wanted-rel:dvn wnt))
        ==
      (start-model-cards our.bowl route held)
    (say-card "thinking within the Nick move-space...")
  ::
  ::  WEIGHT INTERPRETATION TURN.  Graf resolves the logical scalar and owns
  ::  every cited evidence or hypothesis handle.  Viki freezes that packet
  ::  into one ordinary bound model request; its prose answer gains no write,
  ::  tool, or execution authority.
      %viki-weight
    ?>  =(our.bowl src.bowl)
    ?.  armed  `this
    ?.  (routes-allowed our.bowl routes)
      [~[(say-card "Choose an owner-valid model route before requesting model work.")] this]
    ?:  ?|(?=(^ pending) ?=(^ round))  `this
    =/  item=intent:vwi  !<(intent:vwi vase)
    ?.  (valid:vwi item)  `this
    =/  packet=(unit packet:wis)
      (weight-for-index our.bowl now.bowl index.item)
    ?~  packet  `this
    =/  route=model-route  (primary-route routes)
    =/  ordered=(list ref:ask-build)  (refs:vwi u.packet)
    =/  a=ask:dvn
      %-  build:ask-build
      :*  (task:vwi item u.packet)
          ordered
          (oracle-for-route route)
          ask-law
      ==
    =/  inquiry=inquiry:vwi
      (inquiry-for:vwi item u.packet a now.bowl)
    =/  slot=(set rel:dvn)  (my-slot our.bowl now.bowl)
    =/  t=turn-id:fam  [fid head]
    =/  cached=(unit derivation:dvn)  (find-answer:dvn slot a)
    ?^  cached
      :_  this(head.state +(head))
      %+  snoc
        %+  weld
          (weight-inquiry-cards our.bowl inquiry)
        (thread-cards our.bowl t [%thought u.cached] ~)
      (say-card (trip text.u.cached))
    =/  refused=(unit refusal:dvn)  (find-refusal:dvn slot a)
    ?^  refused
      :_  this(head.state +(head))
      %+  snoc
        %+  weld
          (weight-inquiry-cards our.bowl inquiry)
        (thread-cards our.bowl t [%rest %nothing-wanted] ~)
      (say-card (trip (rap 3 ~['[refused: ' why.u.refused ']'])))
    =/  wnt=want:dvn
      [a %viki %weight now.bowl (turn ordered |=(ref=ref:ask-build handle.ref))]
    =/  request=request-v2:vi  (request-for-route route wnt)
    =/  held=flight  [t wnt request now.bowl ~]
    :_  this(head.state +(head), pending.state `held)
    %+  snoc
      %+  weld
        (weight-inquiry-cards our.bowl inquiry)
      %+  weld
        :~  (light-card our.bowl [%want wnt])
            (publish-card our.bowl (wanted-rel:dvn wnt))
        ==
      (start-model-cards our.bowl route held)
    (say-card "interpreting the mapped weight through its cited evidence...")
  ::
  ::  WEIGHT ROLE RATIFICATION.  This is a Bride/Viki judgment, never model
  ::  output.  Viki reconstructs current Graf truth, verifies the cited inquiry
  ::  and packet digest, then admits only evidence handles frozen by that
  ::  inquiry.  Cantrip has no veto over this sovereign admission.
      %viki-weight-ratify
    ?>  =(our.bowl src.bowl)
    ?.  armed  `this
    =/  item=action:vwr  !<(action:vwr vase)
    ?.  (action-valid:vwr item)  `this
    =/  packet=(unit packet:wis)
      (weight-for-index our.bowl now.bowl index.item)
    ?~  packet  `this
    =/  history=(unit history:wi)
      (weight-inquiries-for-index our.bowl now.bowl index.item)
    ?~  history  `this
    =/  admission=(unit admission:vwr)
      (admit:vwr item u.packet u.history our.bowl now.bowl)
    ?~  admission  `this
    :_  this
    (weight-ratification-cards our.bowl u.admission)
  ::
  ::  GOAL INGRESS.  The operator names bounded intent; Viki supplies origin
  ::  and time, refuses an id collision, writes canonical Graf truth, and wakes
  ::  the existing cognition loop without gaining a second workflow engine.
      %viki-goal-submit
    ?>  =(our.bowl src.bowl)
    =/  item=action:vgs  !<(action:vgs vase)
    ?.  (action-valid:vgs item)
      ~&  >>>  [%viki %goal-submit-invalid goal.item]
      `this
    =/  admission=(unit admission:vgs)
      (admit:vgs item (goal-entries-on-floor our.bowl now.bowl) now.bowl)
    ?~  admission
      ~&  >>>  [%viki %goal-submit-conflict goal.item]
      `this
    :_  this
    %+  weld  (goal-submission-cards our.bowl u.admission)
    ?:  ?&(armed created.u.admission)
      ~[(tick-card now.bowl ~s0)]
    ~
  ::
  ::  Ratification is a separate operator act after Viki/Bride has judged.
      %viki-goal-ratify
    ?>  =(our.bowl src.bowl)
    ?.  armed  `this
    =/  item=action:vgr  !<(action:vgr vase)
    =/  slot=(set rel:dvn)  (my-slot our.bowl now.bowl)
    =/  admission=(unit admission:vgr)
      %-  admit:vgr
      :*  item
          slot
          (workflow-source our.bowl now.bowl %viki-judgment)
          (workflow-source our.bowl now.bowl %viki-continuation)
          our.bowl
      ==
    ?~  admission  `this
    :_  this
    (goal-ratification-cards our.bowl u.admission)
  ::
  ::  RETRY POLICY.  Absence means retries are disabled.  The operator may
  ::  install a positive ceiling or clear it, but cannot change the rule under
  ::  an in-flight want.  Persisting the policy does not itself execute a retry.
      %viki-retry-policy
    ?>  =(our.bowl src.bowl)
    ?:  ?|(?=(^ pending) ?=(^ round))  `this
    =/  selected=(unit policy-action:esc)
      ((soft policy-action:esc) q.vase)
    ?~  selected  `this
    ?-  -.u.selected
      %disable  `this(retry-policy.state ~)
      %set
        ?.  (valid:esc rule.u.selected)  `this
        `this(retry-policy.state `rule.u.selected)
    ==
  ::
  ::  Graf's semantic receipt is the only event that clears a completed
  ::  model result.  Gall's transport ACK is deliberately insufficient.
      %viki-landing
    ?.  =(our.bowl src.bowl)  `this
    =/  action  !<(action:vl vase)
    ?.  ?=(%landed -.action)  `this
    ?~  pending  `this
    ?~  result.u.pending  `this
    =/  item=landing:vl  [t.u.pending u.result.u.pending]
    ?.  =(aid.action (aid-of:vl item))  `this
    =/  held=flight  u.pending
    =/  slot  (my-slot our.bowl now.bowl)
    =/  goal=(unit gid:gol)  (find-goal:dvn slot ask.want.held)
    =/  goal-record=(unit goal:gol)
      ?~  goal  ~
      (goal-by (goals-on-floor our.bowl now.bowl) u.goal)
    =/  result=result:vi  u.result.u.pending
    =/  outcome=outcome:vi  (outcome-of:vi result)
    ?^  round
      =/  answer=outcome:cr
        ?-  -.outcome
          %ok  [%ok d.outcome]
          %no  [%no r.outcome]
        ==
      =/  progressed=candidate-round  (record:cr u.round answer)
      ?.  =(+(cursor.u.round) cursor.progressed)
        ~&  >>>  [%viki %rejected-candidate-round-result aid.action]
        `this
      ?.  (complete:cr progressed)
        =/  next-call=(unit candidate-call)  (current:cr progressed)
        ?~  next-call
          ~&  >>>  [%viki %invalid-candidate-round-cursor (rid:cr progressed)]
          `this
        =/  next-turn=turn-id:fam  [fid head]
        =/  next-flight=flight
          (flight-for route.u.next-call next-turn want.u.next-call now.bowl)
        :_  this(head.state +(head), pending.state `next-flight, round.state `progressed)
        (candidate-start-cards our.bowl progressed u.next-call next-flight)
      =/  receipt=(unit receipt:cr)  (finish:cr progressed now.bowl)
      ?~  receipt
        ~&  >>>  [%viki %invalid-candidate-round-finish (rid:cr progressed)]
        `this
      =/  receipt-cards=(list card)
        (candidate-round-receipt-cards our.bowl u.receipt)
      ?~  candidates.progressed
        =/  refusal=refusal:dvn  (rear refusals.progressed)
        =/  judgment=judgment:vj
          (from-refusal:vj refusal `gid.goal.progressed refs.want.held now.bowl)
        =/  cards=(list card)
          (weld receipt-cards (refusal-judgment-cards our.bowl judgment))
        =/  cards
          (snoc cards (publish-card our.bowl [[%viki-judgment (scot %ux (jid:vj judgment))] %based-on (key:cr u.receipt)]))
        :_  this(pending.state ~, round.state ~)
        (snoc cards (say-card (trip (rap 3 ~['[all candidates refused: ' why.refusal ']']))))
      =/  evaluated=compared-result
        (compare-round progressed refs.want.held now.bowl i.candidates.progressed)
      =/  comparison=comparison:vc  (need comparison.evaluated)
      =/  chosen=derivation:dvn  chosen.evaluated
      =/  verdict=verdict:satisfy  verdict.evaluated
      =/  refs=(list @t)  refs.evaluated
      =/  judgment=judgment:vj
        (from-derivation:vj chosen verdict `gid.goal.progressed refs now.bowl)
      =/  search=(unit search:ves)
        (evidence-search our.bowl now.bowl chosen verdict `gid.goal.progressed refs)
      =/  continuing=?  ?~(search %.n ?=(^ fresh.u.search))
      =/  kind  (record-kind:satisfy verdict)
      =/  cards=(list card)
        (weld receipt-cards (derivation-judgment-cards our.bowl judgment chosen verdict continuing))
      =/  cards
        (weld cards (candidate-comparison-cards our.bowl comparison judgment))
      =/  cards
        ?~  search  cards
        (weld cards (evidence-search-cards our.bowl (jid:vj judgment) u.search))
      =/  cards
        ?~  kind  cards
        (weld cards (record-cards our.bowl u.kind (scot %ux (aid:dvn ask.chosen))))
      =/  cards
        (snoc cards (publish-card our.bowl [[%viki-judgment (scot %ux (jid:vj judgment))] %based-on (key:cr u.receipt)]))
      :_  this(pending.state ~, round.state ~)
      ?-  -.decision.comparison
        %select  (snoc cards (say-card (trip text.chosen)))
        %more-evidence
          (snoc cards (say-card (trip (rap 3 ~['[candidate round needs more evidence: ' why.decision.comparison ']']))))
        %refuse
          (snoc cards (say-card (trip (rap 3 ~['[candidate round refused: ' why.decision.comparison ']']))))
      ==
    ?-  -.outcome
      %no
        =/  judgment=judgment:vj
          (from-refusal:vj r.outcome goal refs.want.held now.bowl)
        :_  this(pending.state ~)
        %+  snoc  (refusal-judgment-cards our.bowl judgment)
        (say-card (trip (rap 3 ~['[refused: ' why.r.outcome ']'])))
      %ok
        =/  evaluated=compared-result
          %-  compare-retry-result
          :*  our.bowl  now.bowl  slot  held  d.outcome  goal  goal-record
          ==
        =/  chosen=derivation:dvn  chosen.evaluated
        =/  verdict=verdict:satisfy  verdict.evaluated
        =/  refs=(list @t)  refs.evaluated
        =/  judgment=judgment:vj
          (from-derivation:vj chosen verdict goal refs now.bowl)
        =/  search=(unit search:ves)
          (evidence-search our.bowl now.bowl chosen verdict goal refs)
        =/  continuing=?
          ?~(search %.n ?=(^ fresh.u.search))
        =/  kind  (record-kind:satisfy verdict)
        =/  cards=(list card)
          =/  base
            (derivation-judgment-cards our.bowl judgment chosen verdict continuing)
          =/  base
            ?~  comparison.evaluated  base
            (weld base (candidate-comparison-cards our.bowl u.comparison.evaluated judgment))
          =/  base
            ?~  search  base
            (weld base (evidence-search-cards our.bowl (jid:vj judgment) u.search))
          ?~  kind  base
          (weld base (record-cards our.bowl u.kind (scot %ux (aid:dvn ask.chosen))))
        :_  this(pending.state ~)
        (snoc cards (say-card (trip text.chosen)))
    ==
  ::
  ::  THE ANSWER COMES HOME DIRECTLY FROM VIKI'S MODEL ORGAN.  Retain it
  ::  until Graf has atomically landed the fact, terminal index, and thread.
      %viki-inference
    =/  route=model-route  (active-route routes round)
    ?.  ?=(%local -.route)
      ~&  >>>  [%viki %rejected-local-result-on-connected-route src.bowl]
      `this
    ?.  =(organ.route src.bowl)
      ~&  >>>  [%viki %rejected-derived src.bowl]
      `this
    =/  action  !<(action:vi vase)
    ?.  ?=(%result -.action)  `this
    =/  d=result:vi  result.action
    ?~  pending
      ~&  >>>  [%viki %rejected-unexpected-result src.bowl]
      `this
    =/  held=flight  u.pending
    ?.  (result-matches-request:vi request.held d)
      ~&  >>>  [%viki %rejected-mismatched-result src.bowl]
      `this
    ?^  result.held
      ?:  =(d u.result.held)  `this
      ~&  >>>  [%viki %rejected-conflicting-result src.bowl]
      `this
    :_  this(pending.state `held(result `d))
    :~  (cancel-timeout-card held)
        (landing-card our.bowl t.held d)
        (landing-retry-card now.bowl every)
    ==
  ==
++  on-arvo
  |=  [=wire sign=sign-arvo]
  ^-  (quip card _this)
  ?:  (owns:nsession-workspace native-session-workspaces wire)
    =/  next  (arvo:nsession-workspace bowl native-session-workspaces projects.native-coding wire sign)
    [cards.next this(native-session-workspaces state.next)]
  ?:  ?=([%native-coding %deadline @ @ ~] wire)
    ?.  ?=([%behn %wake *] sign)  `this
    =/  hot  (hot-gate bowl %loop-deadline)
    =/  next=(quip card:agent:gall state:ncode)
      ?~  hot  (deadline:ncode bowl native-coding (slav %ux i.t.t.wire) (slav %ux i.t.t.t.wire))
      (run:hotm (quip card:agent:gall state:ncode) u.hot [bowl native-coding (slav %ux i.t.t.wire) (slav %ux i.t.t.t.wire)])
    [-.next this(native-coding +.next)]
  ?:  ?=([%native-coding-bootstrap @ @ ~] wire)
    =/  next  (arvo:nworkspace bowl native-workspace native-coding wire sign)
    [cards.next this(native-workspace workspace.next, native-coding coding.next)]
  ?:  ?=([%project-coding *] wire)
    =/  next  (arvo:devc bowl development moon-routes workers wire sign)
    [(weld -.next (change-cards:devc development +.next)) this(development +.next)]
  ?:  ?=([%glass-project @ ~] wire)
    ?.  ?=([%behn %wake *] sign)  `this
    =/  key  (path-key:vcj i.t.wire)
    ?~  key  `this
    =/  next  (continue:gpl bowl projects coding moon-routes intents workers u.key)
    [cards.next this(projects projects.next, coding coding.next)]
  ?:  ?=([%glass-coding %wake @ ~] wire)
    ?.  ?=([%behn %wake *] sign)  `this
    =/  key  (find-wire:gcl coding wire)
    ?~  key  `this
    =/  prior  (~(got by coding) u.key)
    =/  observed  ~(observe hc:gcl [bowl prior moon-routes intents workers])
    [-.observed this(coding (~(put by coding) u.key +.observed))]
  ?:  ?=([%connected-intake *] wire)
    [(wake:vci our.bowl now.bowl wire sign) this]
  ?:  ?=([%connected-intake-v2 *] wire)
    [(wake-v2:vci our.bowl now.bowl wire sign) this]
  =/  worker-context
    ?:  authoritative.workers
      (resolve-dispatch:viki-worker-engine (donor-organ:vwa workers) wire)
    ~
  ?^  worker-context
    ?.  ?=([%behn %wake *] sign)  (on-arvo:def wire sign)
    ?.  ?=([~ %fact *] read-spec.u.worker-context)  `this
    =/  spec  spec.u.worker-context
    =/  got=(each (list *) tang)
      ?.  (agent-live:vsg our.bowl now.bowl %graf)  [%| ~]
      %-  mule
      |.(.^((list *) %gx /(scot %p our.bowl)/graf/(scot %da now.bowl)/by-id/[kind.u.read-spec.u.worker-context]/[id.u.read-spec.u.worker-context]/noun))
    =/  visible=?
      ?:(?=(%| -.got) %.n (fact-present:moon-graf-effect expected.u.read-spec.u.worker-context p.got))
    ?:  visible
      =/  donor=worker-engine-result:vw
        (dispatch-ack:viki-worker-engine (donor-organ:vwa workers) proposal-id.spec lease-id.spec tool.spec now.bowl)
      =/  next-workers=worker-organ:vw  (absorb-donor:vwa workers donor)
      :_  this(workers next-workers)
      (materialize:viki-worker-cards our.bowl now.bowl donor)
    =/  summary=@t
      (rap 3 'dispatch ' proposal-id.spec ' remains in flight: canonical Graf fact not visible' ~)
    =/  pending
      (pending-readback:viki-worker-engine (donor-organ:vwa workers) lease-id.spec summary now.bowl)
    =/  next-workers=worker-organ:vw  (absorb-donor:vwa workers result.pending)
    =/  retry-cards=(list card)
      =/  retry-wire  (wire-of:moon-graf-effect effect.u.worker-context)
      ?~  retry-wire  ~
      ~[[%pass u.retry-wire %arvo %b %wait (add now.bowl ~s1)]]
    :_  this(workers next-workers)
    (weld ~[(event-card:viki-worker-cards event.pending)] retry-cards)
  =/  worker-wake
    ?:  authoritative.workers  (parse-expiry-wake:moon-guardian wire sign)
    ~
  ?^  worker-wake
    =/  donor=worker-engine-result:vw
      (expiry-wake:viki-worker-engine (donor-organ:vwa workers) lease-id.u.worker-wake expires.u.worker-wake now.bowl)
    =/  next-workers=worker-organ:vw  (absorb-donor:vwa workers donor)
    :_  this(workers next-workers)
    (materialize:viki-worker-cards our.bowl now.bowl donor)
  ?:  ?=([%landing-retry ~] wire)
    ?~  pending  `this
    =/  held=flight  u.pending
    ?~  result.held  `this
    :_  this
    :~  (landing-retry-card now.bowl every)
        (landing-card our.bowl t.held u.result.held)
    ==
  ?:  ?=([%model-timeout @ ~] wire)
    ?.  ?=([%behn %wake *] sign)  (on-arvo:def wire sign)
    ?~  pending  `this
    =/  held=flight  u.pending
    =/  route=model-route  (active-route routes round)
    ?^  result.held  `this
    =/  request-id=@ux  (slav %ux i.t.wire)
    ?.  =(request-id request-id.request.held)  `this
    =/  timed=result:vi  (refusal-result our.bowl now.bowl held %timed-out)
    =/  cleanup=(list card)
      ?-  -.route
        %local  ~
        %connected
          :~  (bridge-cancel-card our.bowl held 'viki model request timed out')
              (bridge-leave-card our.bowl held)
          ==
      ==
    :_  this(pending.state `held(result `timed))
    %+  weld  cleanup
    :~  (landing-card our.bowl t.held timed)
        (landing-retry-card now.bowl every)
    ==
  ?.  ?=([%tick ~] wire)  (on-arvo:def wire sign)
  ?.  armed  `this
  ?.  (routes-allowed our.bowl routes)
    [~[(say-card "Viki disarmed: its model route is not valid for this owner.")] this(armed.state %.n)]
  ::  THE TICK.  Read the loom, decide, act, and always set the next
  ::  wake -- a familiar that forgets to re-arm its timer has died
  ::  quietly, which is the one failure mode a thread cannot record.
  ::  Waterwheel's state is only a durable offer pointer.  The batch itself
  ::  must exist under its content address in Graf before Viki retains it.
  =.  state
    ?^  reconsideration  state
    =/  discovered
      (discover-reconsideration our.bowl now.bowl last-reconsideration)
    state(last-reconsideration last.discovered, reconsideration work.discovered)
  ::  READ THE LOOM.  One slot read serves three questions -- what is
  ::  open, what is unjudged, and what viki has already threaded.
  =/  slot  (my-slot our.bowl now.bowl)
  =/  goals  (goals-on-floor our.bowl now.bowl)
  =/  n-now  (facts-count our.bowl now.bowl)
  =/  retry-target=(unit reconsideration-target:vj)
    ?~  reconsideration  ~
    ?~  targets.u.reconsideration  ~
    `i.targets.u.reconsideration
  =/  target-current=?
    ?~  retry-target  %.n
    (reconsideration-target-current our.bowl now.bowl u.retry-target)
  =/  current-reconsideration=(unit reconsideration-work)
    ?~  reconsideration  ~
    ?~  retry-target  reconsideration
    ?:(target-current reconsideration (advance-reconsideration u.reconsideration))
  =.  state  state(reconsideration current-reconsideration)
  =.  retry-target  ?:(target-current retry-target ~)
  =/  retry-gid=(unit gid:gol)
    ?:  ?&  ?=(^ retry-target)
            target-current
            ?=(^ retry-policy)
        ==
      `goal.u.retry-target
    ~
  =/  open-goals=(list gid:gol)
    (open-goal-ids goals slot retry-gid)
  ::  A canonical continuation can already have been resolved by a newer
  ::  relation.  Consume that stale target instead of reopening ordinary work.
  =/  stale-target=?
    ?~  retry-gid  %.n
    !(lien open-goals |=(gid=gid:gol =(gid u.retry-gid)))
  =/  remaining-reconsideration=(unit reconsideration-work)
    ?.  stale-target  reconsideration
    ?~  reconsideration  ~
    (advance-reconsideration u.reconsideration)
  =.  state  state(reconsideration remaining-reconsideration)
  =.  retry-target  ?:(stale-target ~ retry-target)
  =.  retry-gid  ?:(stale-target ~ retry-gid)
  =/  v=view:tick
    :*  armed=armed
        in-flight=?=(^ pending)
        spoken-to=said
        answered=(unjudged slot)
        open-goals=open-goals
        loom-changed=(gth n-now seen)
        budget=budget
    ==
  =/  d  (decide:tick v)
  =/  t=turn-id:fam  [fid head]
  =/  next  (tick-card now.bowl every)
  =/  route=model-route  (primary-route routes)
  ::  Graf is the queue.  After a %0 migration (or any cleared transient
  ::  slot), offer the exact durable want before creating a new one.
  =/  waiting=(list want:dvn)  (open-wants slot)
  ?:  ?&(=(~ pending) ?=(^ waiting))
    =/  wnt=want:dvn  i.waiting
    =/  held=flight  (flight-for route [fid head] wnt now.bowl)
    :_  this(head.state +(head), seen.state n-now, pending.state `held)
    (weld ~[next] (start-model-cards our.bowl route held))
  ?-  -.d
    ::  the operator is owed a reply: build the ask, plant the want,
    ::  and thread the turn.  Conversation does not spend the budget.
    %converse
      =/  a=ask:dvn
        (build:ask-build said.d ~ (oracle-for-route route) ask-law)
      ::  Same ask, same derivation: a repeated operator line is a Graf read,
      ::  never a second model run.  Thread the read so the conversation stays
      ::  whole, but do not plant another want or repeat model execution.
      =/  cached=(unit derivation:dvn)  (find-answer:dvn slot a)
      ?^  cached
        :_  this(said.state ~, seen.state n-now, head.state +(head))
        %+  snoc
          (weld ~[next] (thread-cards our.bowl t [%thought u.cached] ~))
        (say-card (trip text.u.cached))
      =/  refused=(unit refusal:dvn)  (find-refusal:dvn slot a)
      ?^  refused
        :_  this(said.state ~, seen.state n-now, head.state +(head))
        %+  snoc
          (weld ~[next] (thread-cards our.bowl t [%rest %nothing-wanted] ~))
        (say-card (trip (rap 3 ~['[refused: ' why.u.refused ']'])))
      =/  wnt=want:dvn  [a %viki %converse now.bowl ~]
      =/  held=flight  (flight-for route t wnt now.bowl)
      :_  this(said.state ~, head.state +(head), seen.state n-now, pending.state `held)
      %+  snoc
        %+  weld
          :~  next
              (light-card our.bowl [%want wnt])
              (publish-card our.bowl (wanted-rel:dvn wnt))
          ==
        (start-model-cards our.bowl route held)
      (say-card "thinking...")
    ::
    ::  WANT: turn an open goal into a question worth asking.  Search
    ::  the loom, pin what it found, and plant the want -- the refs go
    ::  into the WANT so the audit shows what the familiar was looking
    ::  at, and ask-build renders only that recorded list.
    %want
      =/  g  (goal-by goals gid.d)
      ?~  g  [~[next] this(seen.state n-now)]
      ::  An unresolved evidence search owns this goal before a fresh plan can
      ::  be created.  Disabled policy keeps the goal closed above; enabled
      ::  policy either spends one changed ask or parks with a named reason.
      =/  waiting=(unit awaiting-search)  (awaiting-search-for slot gid.d)
      ?^  waiting
        =/  remaining-reconsideration=(unit reconsideration-work)
          ?:  ?&  ?=(^ reconsideration)
                  ?=(^ retry-target)
                  =(gid.d goal.u.retry-target)
              ==
            (advance-reconsideration u.reconsideration)
          reconsideration
        =.  state  state(reconsideration remaining-reconsideration)
        ?~  retry-policy
          :_  this(head.state +(head), seen.state n-now)
          %+  weld  ~[next]
          %+  weld
            (resolve-search-cards our.bowl key.u.waiting gid.d [%park %unclear] %unclear)
          (thread-cards our.bowl t [%rest %nothing-wanted] ~[gid.d])
        =/  candidate=(unit retry-candidate)
          (retry-candidate-for our.bowl now.bowl slot goals u.waiting)
        ?~  candidate
          :_  this(head.state +(head), seen.state n-now)
          %+  weld  ~[next]
          %+  weld
            (resolve-search-cards our.bowl key.u.waiting gid.d [%park %unclear] %unclear)
          (thread-cards our.bowl t [%rest %nothing-wanted] ~[gid.d])
        =/  item=retry-candidate  u.candidate
        =/  verdict=verdict:satisfy
          (judge:satisfy (step-for:gol goal.item) prior.item)
        =/  history=history:esc
          :*  attempts=(attempts-for slot gid.d)
              last=`verdict
              refs-seen=(lent prior.search.item)
              refs-available=(add (lent prior.search.item) (lent fresh.search.item))
          ==
        =/  move=next-move:esc  (next:esc u.retry-policy history)
        ?.  ?=(%retry-with-more-evidence -.move)
          =/  why=reason:gol
            ?:  ?=(%park -.move)  why.move
            %unclear
          :_  this(head.state +(head), seen.state n-now)
          %+  weld  ~[next]
          %+  weld
            (resolve-search-cards our.bowl key.item gid.d move why)
          (thread-cards our.bowl t [%rest %nothing-wanted] ~[gid.d])
        =/  a=ask:dvn
          (retry-build:ask-build ask.prior.item query.search.item fresh.search.item)
        ?.  !=(a ask.prior.item)
          :_  this(head.state +(head), seen.state n-now)
          %+  weld  ~[next]
          %+  weld
            (resolve-search-cards our.bowl key.item gid.d [%park %unclear] %unclear)
          (thread-cards our.bowl t [%rest %nothing-wanted] ~[gid.d])
        =/  refs=(list @t)
          (merge-handles:ask-build prior.search.item fresh.search.item)
        =/  p=plan:pln  (make:pln goal.item refs)
        =/  wnt=want:dvn  [a %viki %retry-evidence now.bowl refs]
        =/  held=flight  (flight-for route t wnt now.bowl)
        :_  this(head.state +(head), seen.state n-now, budget.state (dec budget), pending.state `held)
        %+  weld
          %+  weld
            %+  weld  ~[next]
            (publish-plan-cards our.bowl p a)
          :~  (light-card our.bowl [%want wnt])
              (publish-card our.bowl (wanted-rel:dvn wnt))
              (publish-card our.bowl (resolution-rel:ves search.item (ask-key:dvn a)))
          ==
        (start-model-cards our.bowl route held)
      =/  refs  (recall-for our.bowl now.bowl text.u.g)
      =/  handles=(list @t)
        (turn (order-refs:ask-build refs) |=(r=ref:ask-build handle.r))
      =/  p=plan:pln  (make:pln u.g handles)
      =/  calls=(list candidate-call)
        (candidate-calls routes p now.bowl refs)
      =/  opened=(unit candidate-round)  (open:cr u.g calls now.bowl)
      ?~  opened
        :_  this(head.state +(head), seen.state n-now)
        [next (thread-cards our.bowl t [%rest %nothing-wanted] ~[gid.d])]
      =/  active=(unit candidate-call)  (current:cr u.opened)
      ?~  active
        :_  this(head.state +(head), seen.state n-now)
        [next (thread-cards our.bowl t [%rest %nothing-wanted] ~[gid.d])]
      =/  held=flight
        (flight-for route.u.active t want.u.active now.bowl)
      :_  this(head.state +(head), seen.state n-now, budget.state ?:(=(0 budget) 0 (dec budget)), pending.state `held, round.state `u.opened)
      %+  weld
        %+  weld
          %+  weld  ~[next]
          (publish-plan-cards our.bowl p ask.want.u.active)
        (candidate-round-plan-cards our.bowl u.opened)
      (candidate-start-cards our.bowl u.opened u.active held)
    ::
    ::  JUDGE: a derivation landed but was never threaded -- the
    ::  recovery path after a crash between landing and judging.  The
    ::  fact and index already exist, so this only threads and records.
    %judge
      =/  dv  (derivation-by slot aid.d.d)
      ?~  dv  [~[next] this(seen.state n-now)]
      =/  goal=(unit gid:gol)
        ?:  !=('' gid.d.d)  `gid.d.d
        (find-goal:dvn slot ask.u.dv)
      =/  goal-record=(unit goal:gol)
        ?~  goal  ~
        (goal-by goals u.goal)
      =/  v
        (judge:satisfy (judgment-step goal-record u.dv) u.dv)
      =/  want  (find-want:dvn slot ask.u.dv)
      =/  refs=(list @t)  ?~(want ~ refs.u.want)
      =/  judgment=judgment:vj
        (from-derivation:vj u.dv v goal refs now.bowl)
      =/  search=(unit search:ves)
        (evidence-search our.bowl now.bowl u.dv v goal refs)
      =/  continuing=?
        ?~(search %.n ?=(^ fresh.u.search))
      =/  rk  (record-kind:satisfy v)
      =/  base
        %+  weld  (thread-cards our.bowl t [%thought u.dv] ?~(goal ~ ~[u.goal]))
        (derivation-judgment-cards our.bowl judgment u.dv v continuing)
      =/  base
        ?~  search  base
        (weld base (evidence-search-cards our.bowl (jid:vj judgment) u.search))
      :_  this(seen.state n-now, head.state +(head))
      :-  next
      ?~  rk  base
      (weld base (record-cards our.bowl u.rk (scot %ux (aid:dvn ask.u.dv))))
    ::  RESTED, THREADED, NAMED.  The turn advances even when nothing
    ::  was wanted, because the thread must show that it woke, looked,
    ::  and chose.
    %rest
      :_  this(head.state +(head), seen.state n-now)
      [next (thread-cards our.bowl t [%rest why.d] ~)]
  ==
++  on-peek
  |=  =path
  ^-  (unit (unit cage))
  ?:  ?=([%x %native-coding *] path)
    ?.  =(our.bowl src.bowl)  ~
    ?:  ?=([%x %native-coding %completion-proposal @ ~] path)
      =/  id  (slaw %ux i.t.t.t.path)
      ?~  id  [~ ~]
      ?.  =((scot %ux u.id) i.t.t.t.path)  [~ ~]
      ``noun+!>((prepare:ncompletion bowl native-coding u.id))
    =/  task-completion  (peek:qpc-task-completion bowl native-coding native-reviews path)
    ?^  task-completion  task-completion
    =/  completion  (peek:ncompletion native-completions path)
    ?^  completion  completion
    =/  reviewed-completion  (peek:ncreviewed reviewed-completions path)
    ?^  reviewed-completion  reviewed-completion
    =/  completion-campaign
      (peek:nccampaign bowl completion-campaigns native-coding scopes.native-campaigns path)
    ?^  completion-campaign  completion-campaign
    ?:  |(=(/x/native-coding/reserved-desks path) ?=([%x %native-coding %reserved-desks %except-worker-export @ ~] path))
      ::  Import admission reads native ownership only. Do not include the
      ::  importer's own reservation set here: it must be able to observe its
      ::  pending target without circularly disqualifying itself.
      ?>  (agent-live:vsg our.bowl now.bowl %cantrip)
      =/  limits
        ?:  =(/x/native-coding/reserved-desks path)  native-workspace-constraints
        ?>  ?=([%x %native-coding %reserved-desks %except-worker-export @ ~] path)
        =/  desk=@tas  i.t.t.t.t.path
        (native-workspace-constraints-with .^((set @tas) %gx /(scot %p our.bowl)/cantrip/(scot %da now.bowl)/native-coding/reserved-desks/except-worker-export/[desk]/noun))
      =/  held=(set @tas)  reserved.limits
      =.  held
        %-  ~(uni in held)
        %+  roll  ~(val by projects.native-coding)
        |=  [p=project:nct desks=(set @tas)]
        (~(put in (~(put in desks) working.p)) base-desk.spec.p)
      =.  held
        %-  ~(uni in held)
        %+  roll  ~(val by sessions.native-session-workspaces)
        |=  [e=entry:nsession-workspace desks=(set @tas)]
        (~(put in (~(put in desks) working.request.e)) base-desk.spec.base.e)
      =.  held
        %-  ~(uni in held)
        %+  roll  ~(val by bootstraps.native-workspace)
        |=  [r=record:nbootstrap desks=(set @tas)]
        (~(put in desks) desk.baseline.request.r)
      =.  held
        %-  ~(uni in held)
        %+  roll  ~(val by native-onboarding)
        |=  [e=entry:nonboard desks=(set @tas)]
        (~(put in desks) desk.baseline.request.e)
      ``noun+!>(held)
    ?:  =(/x/native-coding/used-sessions path)
      ?.  (agent-live:vsg our.bowl now.bowl %cantrip)  [~ ~]
      ``noun+!>(used.native-workspace-constraints)
    ?:  =(/x/native-coding/local-used-sessions path)
      ``noun+!>(native-local-used)
    ?:  =(/x/native-coding/session-projects path)
      =/  scoped=(map @ux project:nct)
        %-  malt
        %+  turn  ~(tap by sessions.native-session-workspaces)
        |=  [id=@ux e=entry:nsession-workspace]
        [id (scoped:nsession-workspace e)]
      ``noun+!>(scoped)
    ?:  ?=([%x %native-coding %session-project @ ~] path)
      =/  id  (slaw %ux i.t.t.t.path)
      ?~  id  [~ ~]
      ?.  =((scot %ux u.id) i.t.t.t.path)  [~ ~]
      =/  selected=(unit (each project:nct @tas))
        (resolve:qpc-selected-project bowl native-coding native-session-workspaces u.id)
      ``noun+!>(selected)
    =/  scoped  (peek:nsession-workspace native-session-workspaces path)
    ?^  scoped  scoped
    ?:  =(/x/native-coding/fleet/settlements path)  ``noun+!>(native-settlements)
    =/  onboarding  (peek:nonboard native-onboarding path)
    ?^  onboarding  onboarding
    =/  campaigns  (peek:ncampaign native-campaigns path)
    ?^  campaigns  campaigns
    =/  openings  (peek:nopening native-openings path)
    ?^  openings  openings
    =/  workspace  (peek:nworkspace native-workspace path)
    ?^  workspace  workspace
    =/  reviewed  (peek:nreview native-reviews path)
    ?^  reviewed  reviewed
    =/  context-view  (peek:ncontext-view bowl projects.native-coding sessions.native-coding path)
    ?^  context-view  context-view
    =/  historical  (peek:nhistory bowl projects.native-coding sessions.native-coding path)
    ?^  historical  historical
    (peek:ncode native-coding path)
  ?:  =(/x/development/pataphor path)
    ?.  =(our.bowl src.bowl)  ~
    =/  observed  (read:devread our.bowl src.bowl now.bowl)
    =/  manifest=(unit manifest:pcode)  ?:(?=(%& -.observed) `p.observed ~)
    ``noun+!>((view:devc our.bowl manifest development))
  ?:  =(/x/glass/projects path)
    ?.  =(our.bowl src.bowl)  ~
    ``noun+!>((catalog:gpl projects coding))
  ?:  =(/x/glass/coding path)
    ?.  =(our.bowl src.bowl)  ~
    ``noun+!>(coding)
  ?:  =(/x/glass/moon-routes path)
    ?.  =(our.bowl src.bowl)  ~
    ``noun+!>([%viki-moon-routes-v1 moon-routes])
  ?:  ?=([%x %vibecoding %connected-judgments-v2 *] path)
    ?.  =(our.bowl src.bowl)  ~
    ?:  =(/x/vibecoding/connected-judgments-v2 path)
      ``noun+!>(connected-judgments)
    ?.  ?=([%x %vibecoding %connected-judgments-v2 @ ~] path)  [~ ~]
    =/  key  (path-key:vcj i.t.t.t.path)
    ?~  key  [~ ~]
    ``noun+!>((~(get by connected-judgments) u.key))
  ?+    path  (on-peek:def path)
      [%x %intent @ ~]
    =/  id=intent-id:itn  `intent-id:itn`i.t.t.path
    ``noun+!>((record-by-id:vil intents id))
      [%x %intents %count ~]
    ``noun+!>(`@ud`~(wyt by intents-by-id.intents))
      [%x %intents %latest ~]
    ``noun+!>((latest-record:vil intents))
      [%x %conversation @ @ @ ~]
    =/  convo=convo-id:itn  `convo-id:itn`i.t.t.path
    =/  start=(unit @ud)  (slaw %ud i.t.t.t.path)
    ?~  start  ~
    =/  limit=(unit @ud)  (slaw %ud i.t.t.t.t.path)
    ?~  limit  ~
    ``noun+!>((thread-page-for:vil intents convo u.start u.limit))
      [%x %model-registry ~]
    ``noun+!>(registry)
      [%x %model-registry %current ~]
    ``noun+!>(current.registry)
      [%x %model-registry %entries ~]
    ``noun+!>(entries.registry)
    ::  qtensor absorbed: the live consciousness-tensor peek, computed
    ::  on-ship via lib/qpc-ct-qualia over path-segment model outputs.
    ::  Stateless and identical to the donor's /x/q surface.
      [%x %q *]
    =/  outs=(list @t)  ;;((list @t) t.t.path)
    =/  o=observable:qcq
      :*  o00=[pos=& mag=1.000.000]
          o01=[pos=& mag=0]
          o10=[pos=& mag=0]
          o11=[pos=& mag=1.000.000]
      ==
    =/  q=ct-qualia:qcq  (qualia-of-outputs:qcq outs o 1.000.000)
    =/  v  (ct-control-verdict:qcq q)
    ``noun+!>([%q a-bar=a-bar.q valence=valence.q geometry=geometry.q cmunu=cmunu.q verdict=v])
    ::  tensor-governor policy absorbed: the two executable safety proofs,
    ::  computed from Viki's own copy of the law (lib/viki-tensor-govern).
      [%x %tensor %homeostasis-proof ~]
    ``noun+!>(homeostasis-proof:vtg)
      [%x %tensor %loop-safety-proof ~]
    ``noun+!>(loop-safety-proof:vtg)
    ::  model-tensor + soma absorbed: the native telemetry ring, entropy
    ::  stats, and proprioceptive vitals over the organ's own window.
      [%x %tensor %ktensor ~]
    ``noun+!>([k-abar=(k-abar-vec:vt ring.tensor) samples=(lent ring.tensor)])
      [%x %tensor %entropy ~]
    ``noun+!>(entropy.tensor)
      [%x %tensor %status ~]
    ``noun+!>([last-id.tensor (lent ring.tensor)])
      [%x %tensor %vitals ~]
    ``noun+!>((vitals:vta tensor))
    ::  model I/O absorbed (ladder 13): donor-shaped readback over the
    ::  native organ; gateway payloads noun-identical to the donor's peeks.
      [%x %model-io %last ~]
    ``noun+!>(last.modelio)
      [%x %model-io %gateway ~]
    ``noun+!>(gateway.modelio)
      [%x %model-io %gateway %latest ~]
    ``noun+!>(latest.gateway.modelio)
      [%x %model-io %gateway %events ~]
    ``noun+!>(sensor-events.gateway.modelio)
      [%x %model-io %gateway %sensor-status ~]
    ``noun+!>([next-sensor-event.gateway.modelio (lent sensor-events.gateway.modelio)])
      [%x %model-io %terminal ~]
    ``noun+!>(terminal.modelio)
      [%x %model-io %terminal %latest ~]
    ``noun+!>(latest.terminal.modelio)
    ::  cortex seats + advice absorbed: donor-shaped readback over the
    ::  native organ (payloads noun-identical to the donor's peeks).
      [%x %advice %pending ~]
    =/  all=(list advice-rec:vsl)
      (turn advice-order.seats |=(i=@t (~(got by advice.seats) i)))
    ``noun+!>((skim all |=(r=advice-rec:vsl =(%pending status.r))))
      [%x %advice %count ~]
    ``noun+!>((lent advice-order.seats))
      [%x %advice @ ~]
    ``noun+!>((~(get by advice.seats) i.t.t.path))
      [%x %seat @ *]
    =/  s=seat-rec:vsl
      (~(gut by seats.seats) (slav %p i.t.t.path) fresh-seat:vsa)
    ?+  t.t.t.path  ~
      [%verdict ~]      ``noun+!>(verdict.s)
      [%reg ~]          ``noun+!>(reg.st.s)
      [%val ~]          ``noun+!>(val.st.s)
      [%count ~]        ``noun+!>(count.led.s)
      [%quarantined ~]  ``noun+!>(quarantined.s)
      [%permitted ~]    ``noun+!>(permitted.s)
      [%denied ~]       ``noun+!>(denied.s)
    ==
    ::  the familiar explains itself: is it alive, how far along is its
    ::  thread, is it thinking, what may it still want?
      [%x %familiar ~]
    :^  ~  ~  %noun
    !>  :*  %familiar
            fid=fid
            armed=armed
            head=head
            thinking=?=(^ pending)
            result-held=?:(?=(^ pending) ?=(^ result.u.pending) %.n)
            pending-aid=?~(pending ~ `(aid:dvn ask.want.u.pending))
            route=(primary-route routes)
            retry-policy=retry-policy
            last-reconsideration=last-reconsideration
            reconsideration=?~(reconsideration ~ `[id.u.reconsideration (lent targets.u.reconsideration)])
            backend=?~(pending ~ `backend.request.u.pending)
            budget=budget
            every=every
        ==
      [%x %candidate-round ~]
    :^  ~  ~  %noun
    !>  :*  %candidate-round
            routes=routes
            active-route=(active-route routes round)
            id=?~(round ~ `(rid:cr u.round))
            cursor=?~(round ~ `cursor.u.round)
            count=?~(round ~ `(lent calls.u.round))
            candidates=?~(round ~ `(lent candidates.u.round))
            refusals=?~(round ~ `(lent refusals.u.round))
        ==
      [%x %migration %export ~]
    ``noun+!>(state)
      [%x %workers ~]
    ``noun+!>(workers)
      [%x %workers %migration ~]
    ``noun+!>([imported.workers last.workers])
      [%x %workers %cutover-ready ~]
    ``noun+!>((cutover-ready:vwm workers))
      [%x %bridge %shadow ~]
    ``noun+!>(bridge)
      [%x %bridge %shadow %state ~]
    ``noun+!>(working.bridge)
      [%x %bridge %shadow %migration ~]
    ``noun+!>([imported.bridge last.bridge])
      [%x %bridge %shadow %authoritative ~]
    ``noun+!>(authoritative.bridge)
      [%x %bridge %shadow %cutover-ready ~]
    ``noun+!>((cutover-ready:vbm bridge))
      [%x %operations %config %export ~]
    ``noun+!>((snapshot-for:vcf our.bowl now.bowl routes retry-policy budget every))
      [%x %cockpit ~]
    ::  Liveness is not identity.  Another desk may run an app with the same
    ::  name but a different peek contract (the live %frag is currently from
    ::  %warpnet).  Only read projections billed into Viki's own desk; an
    ::  unbilled same-name app is unavailable, never a substitute organ.
    =/  billed=(list dude:gall)
      .^  (list dude:gall)  %cx
          (weld ~[(scot %p our.bowl) q.byk.bowl (scot %da now.bowl)] /desk/bill)
      ==
    =/  has-app
      |=  app=@tas
      ^-  ?
      (lien billed |=(candidate=dude:gall =(app candidate)))
    =/  slot=(set rel:dvn)  (my-slot our.bowl now.bowl)
    =/  goals=(list goal:gol)  (goals-on-floor our.bowl now.bowl)
    =/  open=(list gid:gol)  (open-goal-ids goals slot ~)
    =/  active=(unit active-model:vco)
      ?~  pending  ~
      =/  model=active-model:vco
        :*  request-id.request.u.pending
            backend.request.u.pending
            constraint.request.u.pending
            sent.u.pending
            ?=(^ result.u.pending)
        ==
      `model
    =/  progress=(unit candidate-progress:vco)
      ?~  round  ~
      =/  item=candidate-progress:vco
        :*  (rid:cr u.round)
            cursor.u.round
            (lent calls.u.round)
            (lent candidates.u.round)
            (lent refusals.u.round)
        ==
      `item
    =/  reconsider=(unit reconsideration-progress:vco)
      ?~  reconsideration  ~
      `[id.u.reconsideration (lent targets.u.reconsideration)]
    =/  graf=(unit snapshot:gc)
      (graf-cockpit-for our.bowl now.bowl (has-app %graf))
    =/  frag=(unit snapshot:fc)
      (frag-cockpit-for our.bowl now.bowl (has-app %frag))
    =/  waterwheel=(unit snapshot:wwc)
      (waterwheel-cockpit-for our.bowl now.bowl (has-app %waterwheel))
    =/  boxy=(unit snapshot:bc)
      (boxy-cockpit-for our.bowl now.bowl (has-app %boxy))
    =/  model-routes=(list route-readiness:vco)
      %+  turn  routes
      |=(route=model-route (route-readiness-for our.bowl now.bowl route))
    =/  viki=snapshot:vco
      :*  %viki-bride-cockpit-v3
          armed
          head
          (lent goals)
          open
          ?~(pending ~ refs.want.u.pending)
          active
          model-routes
          route-revision
          route-history
          progress
          count.judgments
          head.judgments
          (lent (unjudged slot))
          reconsider
          ?=(^ retry-policy)
          budget
          every
      ==
    =/  snap=snapshot:pc
      :*  %pataphor-cockpit-v4
          viki
          ?~(graf %unavailable %ready)
          graf
          ?~(frag %unavailable %ready)
          frag
          ?~(waterwheel %unavailable %ready)
          waterwheel
          ?~(boxy %unavailable %ready)
          boxy
      ==
    ``noun+!>(snap)
      [%x %glass %judgment %chain ~]
    ``noun+!>(judgments)
      [%x %weight %index @ ~]
    =/  index=(unit @ud)  (slaw %ud i.t.t.t.path)
    ?~  index  [~ ~]
    =/  packet=(unit packet:wis)
      (weight-for-index our.bowl now.bowl u.index)
    ?~  packet  [~ ~]
    ``noun+!>(u.packet)
      [%x %weight %inquiries %index @ ~]
    =/  index=(unit @ud)  (slaw %ud i.t.t.t.t.path)
    ?~  index  [~ ~]
    =/  history=(unit history:wi)
      (weight-inquiries-for-index our.bowl now.bowl u.index)
    ?~  history  [~ ~]
    ``noun+!>(u.history)
      [%x %workflows %weight @ ~]
    =/  index=(unit @ud)  (slaw %ud i.t.t.t.path)
    ?~  index  [~ ~]
    ``noun+!>((weight-workflow-for our.bowl now.bowl u.index))
      [%x %workflows %goals ~]
    ``noun+!>((goal-workflows-for our.bowl now.bowl pending))
  ==
++  on-agent
  |=  [=wire sign=sign:agent:gall]
  ^-  (quip card _this)
  ?:  ?=([%native-completion-campaign *] wire)
    =/  next  (on-agent:nccampaign bowl completion-campaigns native-coding scopes.native-campaigns wire sign)
    ?~  next  `this
    =/  notices=(list card)  ?:(=(completion-campaigns state.u.next) ~ ~[(changed:ncode 0x0 0)])
    [(weld cards.u.next notices) this(completion-campaigns state.u.next)]
  ?:  ?=([%native-session-workspace-claim @ ~] wire)
    =/  next  (claim-event:nsession-workspace bowl native-session-workspaces projects.native-coding wire sign)
    [cards.next this(native-session-workspaces state.next)]
  ?:  =(/native-session-workspace-evidence wire)  `this
  ?:  ?=([%native-fleet-settlement *] wire)
    =/  next  (on-agent:nfinish bowl native-settlements native-coding native-reviews moon-routes coding wire sign)
    ?~  next  `this
    [cards.u.next this(native-settlements state.u.next, native-coding coding.u.next)]
  ?:  ?=([%native-onboarding *] wire)
    =/  next  (event:nonboard bowl native-onboarding native-workspace native-coding wire sign)
    [cards.next this(native-onboarding onboarding.next, native-workspace workspace.next, native-coding coding.next)]
  ?:  ?=([?(%native-review-campaign %native-review-inspection) *] wire)
    =/  next  (on-agent:ncampaign bowl native-campaigns wire sign)
    ?~  next  `this
    =/  notices=(list card)  ?:(=(native-campaigns state.u.next) ~ ~[(changed:ncode 0x0 0)])
    [(weld cards.u.next notices) this(native-campaigns state.u.next)]
  ?:  ?=([%native-opening *] wire)
    =/  next  (event:nopening bowl native-openings native-coding wire sign)
    [cards.next this(native-openings openings.next, native-coding coding.next)]
  ?:  ?=([%native-workspace *] wire)  `this
  ?:  ?=([%native-fleet *] wire)
    =/  next  (fleet-ack:ncode bowl native-coding wire sign)
    [-.next this(native-coding +.next)]
  ?:  ?=([%native-coding *] wire)
    ::  Private correlated outcome pokes advance native state; a delivery ack
    ::  alone is never interpreted as an inference/tool result.
    `this
  ?:  ?=([%project-coding *] wire)
    =/  next  (event:devc bowl development moon-routes workers wire sign)
    [(weld -.next (change-cards:devc development +.next)) this(development +.next)]
  ?:  ?=([%glass-project @ ~] wire)
    ?.  &(=(src.bowl our.bowl) ?=(%poke-ack -.sign))  `this
    =/  key  (path-key:vcj i.t.wire)
    ?~  key  `this
    =/  next  (continue:gpl bowl projects coding moon-routes intents workers u.key)
    [cards.next this(projects projects.next, coding coding.next)]
  ?:  ?=([%glass-coding-cancel *] wire)
    =/  next  (callback:gcan bowl coding wire sign)
    ?:  ?=(%| -.next)  `this
    [-.p.next this(coding +.p.next)]
  ?:  |(?=([%glass-coding *] wire) ?=([%glass-coding-compile *] wire))
    =/  key  (find-wire:gcl coding wire)
    ?~  key  `this
    =/  prior  (~(got by coding) u.key)
    =/  next  (~(event hc:gcl [bowl prior moon-routes intents workers]) wire sign)
    [-.next this(coding (~(put by coding) u.key +.next))]
  ?:  ?=([%connected-judgment-retain *] wire)
    ?.  &(=(our.bowl src.bowl) ?=(%poke-ack -.sign))  `this
    ?.  ?=([%connected-judgment-retain @ @ ~] wire)  `this
    =/  key  (path-key:vcj i.t.wire)
    ?~  key  `this
    =/  prior  (~(get by connected-judgments) u.key)
    ?~  prior  `this
    ?.  =((scot %ux digest.judgment.u.prior) i.t.t.wire)  `this
    =/  observed  (connected-observe our.bowl now.bowl connected-judgments u.key)
    [-.observed this(connected-judgments +.observed)]
  ?:  ?=([%connected-intake *] wire)
    [(event:vci our.bowl now.bowl wire sign) this]
  ?:  ?=([%connected-intake-v2 *] wire)
    [(event-v2:vci bowl wire sign) this]
  ?:  ?=([%connected-intake-retain *] wire)  `this
  ?:  ?=([%connected-intake-retain-v2 *] wire)  `this
  ?:  ?=([%a2a-judge ~] wire)
    ?-    -.sign
        %kick       [~[(a2a-watch-card our.bowl)] this]
        %watch-ack  `this
        %poke-ack   `this
        %fact
      =/  entry=(unit mp-inbox-entry:ct)  ((soft mp-inbox-entry:ct) q.q.cage.sign)
      ?~  entry  `this
      [(a2a-verdict-cards our.bowl now.bowl u.entry) this]
    ==
  ?:  ?=([%a2a-judge %verdict ~] wire)  `this
  =/  mirror
    ?:  authoritative.workers  (parse-mirror-wire:moon-guardian wire)
    ~
  ?^  mirror
    ?+  -.sign  (on-agent:def wire sign)
      %poke-ack
        =/  donor=worker-engine-result:vw
          ?^  p.sign
            %-  mirror-failure:viki-worker-engine
            :*  (donor-organ:vwa workers)  lease-id.u.mirror  expires.u.mirror
                'Cantrip mirror poke failed'  now.bowl
            ==
          =/  read=(each (unit mirrored-lease:mg) tang)
            ?.  (agent-live:vsg our.bowl now.bowl %cantrip)  [%| ~]
            %-  mule
            |.(.^((unit mirrored-lease:mg) %gx /(scot %p our.bowl)/cantrip/(scot %da now.bowl)/lease/[lease-id.u.mirror]/noun))
          =/  observed=(unit mirrored-lease:mg)
            ?:(?=(%| -.read) ~ p.read)
          %-  mirror-readback:viki-worker-engine
          [(donor-organ:vwa workers) lease-id.u.mirror expires.u.mirror observed now.bowl]
        =/  next-workers=worker-organ:vw  (absorb-donor:vwa workers donor)
        :_  this(workers next-workers)
        (materialize:viki-worker-cards our.bowl now.bowl donor)
    ==
  =/  context
    ?:  authoritative.workers
      (resolve-dispatch:viki-worker-engine (donor-organ:vwa workers) wire)
    ~
  ?^  context
    ?+  -.sign  (on-agent:def wire sign)
      %poke-ack
        =/  spec  spec.u.context
        =/  donor=worker-engine-result:vw
          ?^  p.sign
            %-  dispatch-nack:viki-worker-engine
            :*  (donor-organ:vwa workers)  proposal-id.spec  lease-id.spec
                tool.spec  'native Graf effect poke failed'  now.bowl
            ==
          ?~  read-spec.u.context
            %-  dispatch-nack:viki-worker-engine
            :*  (donor-organ:vwa workers)  proposal-id.spec  lease-id.spec
                tool.spec  'native Graf effect cannot be reconstructed'  now.bowl
            ==
          ?-  -.u.read-spec.u.context
            %fact
              =/  got=(each (list *) tang)
                ?.  (agent-live:vsg our.bowl now.bowl %graf)  [%| ~]
                %-  mule
                |.(.^((list *) %gx /(scot %p our.bowl)/graf/(scot %da now.bowl)/by-id/[kind.u.read-spec.u.context]/[id.u.read-spec.u.context]/noun))
              ?:  ?=(%| -.got)
                %-  dispatch-nack:viki-worker-engine
                :*  (donor-organ:vwa workers)  proposal-id.spec  lease-id.spec
                    tool.spec  'canonical Graf fact readback unavailable'  now.bowl
                ==
              ?:  (fact-present:moon-graf-effect expected.u.read-spec.u.context p.got)
                (dispatch-ack:viki-worker-engine (donor-organ:vwa workers) proposal-id.spec lease-id.spec tool.spec now.bowl)
              %-  dispatch-nack:viki-worker-engine
              :*  (donor-organ:vwa workers)  proposal-id.spec  lease-id.spec
                  tool.spec  'exact canonical Graf fact missing after acknowledgement'  now.bowl
              ==
            %slot
              =/  got=(each (set relation:moon-graf-effect) tang)
                ?.  (agent-live:vsg our.bowl now.bowl %graf)  [%| ~]
                %-  mule
                |.(.^((set relation:moon-graf-effect) %gx /(scot %p our.bowl)/graf/(scot %da now.bowl)/slot/[app.u.read-spec.u.context]/noun))
              ?:  ?=(%| -.got)
                %-  dispatch-nack:viki-worker-engine
                :*  (donor-organ:vwa workers)  proposal-id.spec  lease-id.spec
                    tool.spec  'canonical Graf relation readback unavailable'  now.bowl
                ==
              ?:  (relation-present:moon-graf-effect expected.u.read-spec.u.context p.got)
                (dispatch-ack:viki-worker-engine (donor-organ:vwa workers) proposal-id.spec lease-id.spec tool.spec now.bowl)
              %-  dispatch-nack:viki-worker-engine
              :*  (donor-organ:vwa workers)  proposal-id.spec  lease-id.spec
                  tool.spec  'exact canonical Graf relation missing after acknowledgement'  now.bowl
              ==
          ==
        =/  next-workers=worker-organ:vw  (absorb-donor:vwa workers donor)
        :_  this(workers next-workers)
        (materialize:viki-worker-cards our.bowl now.bowl donor)
    ==
  ?:  ?=([%model-bridge @ @ ~] wire)
    ?.  ?=(%fact -.sign)  (on-agent:def wire sign)
    ?.  =(%model-bridge-event p.cage.sign)  (on-agent:def wire sign)
    =/  event=(unit model-bridge-event:mb)
      ((soft model-bridge-event:mb) q.q.cage.sign)
    ?~  event  `this
    ?~  pending  `this
    =/  route=model-route  (active-route routes round)
    ?.  ?=(%connected -.route)  `this
    =/  held=flight  u.pending
    =/  request-id=@t  (scot %ux request-id.request.held)
    =/  session-id=@t  fid.t.held
    ?.  ?&  =(session-id `@t`i.t.wire)
            =(request-id `@t`i.t.t.wire)
        ==
      `this
    =/  converted=(unit result:vi)
      (bridge-event-result our.bowl now.bowl config.route held u.event)
    ?~  converted  `this
    =/  d=result:vi  u.converted
    ?.  (result-matches-request:vi request.held d)
      ~&  >>>  [%viki %rejected-mismatched-bridge-result request-id]
      `this
    ?^  result.held
      ?:  =(d u.result.held)  `this
      ~&  >>>  [%viki %rejected-conflicting-bridge-result request-id]
      `this
    :_  this(pending.state `held(result `d))
    :~  (cancel-timeout-card held)
        (bridge-leave-card our.bowl held)
        (landing-card our.bowl t.held d)
        (landing-retry-card now.bowl every)
    ==
  ?.  ?|  ?=([%model ~] wire)
          ?=([%landing ~] wire)
          ?=([%model-bridge-request @ ~] wire)
      ==
    (on-agent:def wire sign)
  ?.  ?=(%poke-ack -.sign)  `this
  ?~  p.sign
    ::  FLATTENED LANDING (incident ptf-484): Graf's positive ack IS the
    ::  semantic receipt — the %viki-landed callback poke is retired, and
    ::  with it the extra duct layer every pier-killing trace ran through.
    ::  Completion is the same law as the poke arm; the aid self-derives
    ::  from pending, so the callback carried no information.  Idempotent:
    ::  a cleared pending no-ops.
    ?.  ?=([%landing ~] wire)  `this
    ?~  pending  `this
    ?~  result.u.pending  `this
    %+  on-poke  %viki-landing
    !>(`action:vl`[%landed (aid-of:vl [t.u.pending u.result.u.pending])])
  ?:  ?=([%landing ~] wire)
    ~&  >>>  [%viki %graf-landing-rejected p.sign]
    `this
  ::  A model transport rejection must still close the turn reserved at
  ::  dispatch.  Retain a refusal and send it through the same atomic Graf
  ::  landing instead of clearing pending and leaving a permanent thread gap.
  ~&  >>>  [%viki %model-rejected p.sign]
  ?~  pending  `this
  =/  held=flight  u.pending
  =/  route=model-route  (active-route routes round)
  ?^  result.held  `this
  =/  refused=result:vi  (refusal-result our.bowl now.bowl held %model-rejected)
  =/  cleanup=(list card)
    ?-  -.route
      %local  ~
      %connected  ~[(bridge-leave-card our.bowl held)]
    ==
  :_  this(pending.state `held(result `refused))
  %+  weld  cleanup
  :~  (cancel-timeout-card held)
      (landing-card our.bowl t.held refused)
      (landing-retry-card now.bowl every)
  ==
++  on-watch
  |=  =path
  ^-  (quip card _this)
  ?:  =(/native-coding path)
    ?>  =(our.bowl src.bowl)
    [~[(changed:ncode 0x0 0)] this]
  ?:  =(/development/pataphor path)
    ?>  =(our.bowl src.bowl)
    [~[[%give %fact ~ %noun !>([%pataphor-development-changed-v1 (shax (jam development))])]] this]
  ?:  =(/glass/coding path)
    ?>  =(our.bowl src.bowl)
    [~ this]
  ?:  ?=([%vibecoding %connected-judgments-v2 *] path)
    ?>  =(our.bowl src.bowl)
    ?>  ?=([%vibecoding %connected-judgments-v2 @ ~] path)
    =/  key  (path-key:vcj i.t.t.path)
    ?>  ?=(^ key)
    ::  This is the reserved/observed status, never a claim of fresh landing
    ::  authority. Explicit observe checks the exact owner Graf fact again.
    [[%give %fact ~ %noun !>(`status:vcj`[%viki-connected-judgment-status-v2 u.key [%& (~(get by connected-judgments) u.key)]])]~ this]
  ?:  =(/vibecoding-connected-reviews path)
    ?>  =(our.bowl src.bowl)
    [~ this]
  ?:  =(/vibecoding-local-judgments path)
    ::  Correlated decisions/refusals, not proof of Graf retention or landing.
    ?>  =(our.bowl src.bowl)
    [~ this]
  ?:  =(/vibecoding-artifacts path)
    ::  Change-only exact work evidence.  Graf is the durable owner.
    ?>  =(our.bowl src.bowl)
    [~ this]
  ?:  =(/vibecoding-proposals path)
    ::  Change-only proposal evidence.  Graf is the durable owner; Viki emits
    ::  the exact same record in the accepted event for immediate readback.
    ?>  =(our.bowl src.bowl)
    [~ this]
  ?:  =(/vibecoding-judgments path)
    ::  The feed contains accepted immutable judgments only.  Graf remains
    ::  the durable store; this is a same-event readback surface.
    ?>  =(our.bowl src.bowl)
    [~ this]
  ?:  =(/intents path)
    ::  Change-only feed: the exact record is emitted by the same accepted
    ::  transition that persists it.  Replays and refusals emit nothing.
    ?>  =(our.bowl src.bowl)
    [~ this]
  ?.  =(/cockpit path)  (on-watch:def path)
  ::  Hawk and other local presentation membranes may read the composite
  ::  cockpit, but no remote ship may open this operator projection.  Seed the
  ::  requesting duct only; the reader closes immediately after the first fact.
  ?>  =(our.bowl src.bowl)
  =/  read=(unit (unit cage))  (on-peek /x/cockpit)
  ?~  read  `this
  ?~  u.read  `this
  [[%give %fact ~ u.u.read]~ this]
++  on-leave  on-leave:def
++  on-fail   on-fail:def
::
::  ---- THE CONSOLE: |link %viki ----
::  A human line is not a side channel.  It becomes a want with
::  purpose=%converse and flows through the SAME machinery as every
::  other want -- which is what stops this from quietly becoming an
::  ungoverned back door later.
++  command-parser
  |=  =sole-id:shoe
  ^+  |~(nail *(like [? command]))
  %+  stag  |
  (cook |=(t=tape `command`[%say (crip t)]) (plus prn))
++  tab-list
  |=  =sole-id:shoe
  ^-  (list [@t tank])
  ~[['<anything>' leaf+"say it to your familiar"]]
++  on-command
  |=  [=sole-id:shoe =command]
  ^-  (quip card _this)
  ?.  armed
    :_  this
    ~[(say-card "[viki is not summoned -- :viki &viki-arm ~]")]
  ::  hold the line and wake immediately: being spoken to should not
  ::  wait out a tick interval.
  :_  this(said.state `line.command)
  ~[(tick-card now.bowl ~s0)]
++  can-connect
  |=  =sole-id:shoe
  ^-  ?
  (team:title [our src]:bowl)
++  on-connect     on-connect:des
++  on-disconnect  on-disconnect:des
--
