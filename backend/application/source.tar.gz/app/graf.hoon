::  /app/graf.hoon
::
::  Canonical Graf: constitutional graph plus the open fact/territory substrate.
::  The root remains one host-owned field with explicit domain summaries and
::  handle-bearing object families for positioned ships, relations,
::  projections, search nouns, and fleet-owned facts.
::
/-  graf-sur=graf, mc=multiplayer-collaboration, snap=graf-snapshot, vl=viki-landing,
    gc=graf-cockpit, gb=graf-board, gsv=graf-siev-shadow,
    gwr=graf-write-receipt, sg=star-govern
/+  graf-attic, graf-ac, mcg=multiplayer-collaboration-graf,
    gce=graf-core-engine, graf-http, graf-substrate,
    graf-relations, graf-clinamen, wh=weight-hypothesis, gbs=graf-board-shadow,
    gse=graf-siev-evidence, gal=graf-axis-law, gwrl=graf-write-receipt,
    fs=fedwiki-store, rm=readymade-memory-agent, re=readymade-evidence-agent,
    gki=graf-kind-agent, gra=graf-read-access, default-agent, dbug
|%
+$  legacy-graf-state
  $:  version=@ud
      graph=graph-state:graf-sur
      machine=machine-topology:graf-sur
      impulses=(list impulse:graf-sur)
      bundles=(list bundle-ref:graf-sur)
      circulation=(list circulation-fact:graf-sur)
      recent-keys=(list @t)
      last-dispatch=(unit dispatch-receipt:graf-sur)
  ==
::
+$  graf-runtime-status  graf-runtime-status:graf-sur
::
+$  legacy-graf-state-v2
  $:  version=@ud
      graph=graph-state:graf-sur
      machine=machine-topology:graf-sur
      impulses=(list impulse:graf-sur)
      bundles=(list bundle-ref:graf-sur)
      circulation=(list circulation-fact:graf-sur)
      recent-keys=(list @t)
      last-dispatch=(unit dispatch-receipt:graf-sur)
      last-governor=(unit graf-governor-record:graf-sur)
      last-slice=(unit graf-slice:graf-sur)
      last-traversal=(unit graf-traversal-decision:graf-sur)
      last-write-intent=(unit graf-write-intent:graf-sur)
      last-residue=(unit graf-residue:graf-sur)
      last-sieve-verdict=(unit graf-sieve-verdict:graf-sur)
      last-continuation=(unit graf-continuation:graf-sur)
      runtime-status=(unit graf-runtime-status)
  ==
::
+$  graf-app-state-v3
  $:  version=@ud
      root-id=@t
      graph=graph-state:graf-sur
      machine=machine-topology:graf-sur
      impulses=(list impulse:graf-sur)
      bundles=(list bundle-ref:graf-sur)
      circulation=(list circulation-fact:graf-sur)
      seat-writes=(list graf-seat-write:graf-sur)
      recent-keys=(list @t)
      last-dispatch=(unit dispatch-receipt:graf-sur)
      last-governor=(unit graf-governor-record:graf-sur)
      last-slice=(unit graf-slice:graf-sur)
      last-traversal=(unit graf-traversal-decision:graf-sur)
      last-write-intent=(unit graf-write-intent:graf-sur)
      last-residue=(unit graf-residue:graf-sur)
      last-sieve-verdict=(unit graf-sieve-verdict:graf-sur)
      last-continuation=(unit graf-continuation:graf-sur)
      last-seat-write=(unit graf-seat-write:graf-sur)
      runtime-status=(unit graf-runtime-status)
  ==
::
+$  graf-proof-latest
  $:  version=@ud
      last-dispatch=(unit dispatch-receipt:graf-sur)
      runtime-status=(unit graf-runtime-status)
      last-governor=(unit graf-governor-record:graf-sur)
      last-packet=(unit graf-packet:graf-sur)
      last-seat-write=(unit graf-seat-write:graf-sur)
      last-axis-write=(unit graf-axis-write:graf-sur)
      last-ship-position=(unit graf-ship-position:graf-sur)
      last-slice=(unit graf-slice:graf-sur)
      last-traversal=(unit graf-traversal-decision:graf-sur)
      last-write-intent=(unit graf-write-intent:graf-sur)
      last-residue=(unit graf-residue:graf-sur)
      last-sieve-verdict=(unit graf-sieve-verdict:graf-sur)
      last-continuation=(unit graf-continuation:graf-sur)
      last-relation=(unit graf-relation:graf-sur)
      last-projection=(unit graf-projection:graf-sur)
      last-search-tree=(unit graf-search-tree:graf-sur)
      last-search-result=(unit graf-search-result:graf-sur)
      last-provenance=(unit graf-provenance:graf-sur)
      last-proof-bundle=(unit graf-proof-bundle:graf-sur)
      last-bride-nets=(unit graf-bride-nets:graf-sur)
      last-bride-milky-way=(unit graf-bride-milky-way:graf-sur)
  ==
::
+$  graf-watch-manifest
  $:  version=@ud
      watch-paths=(list @tas)
  ==
::
+$  noun-family-entry
  $:  familyid=@t
      familyversion=@ud
      sourceclassification=@tas
      handlebearingdefault=?
      pageeligibility=@tas
      attributable=?
      expectation=@t
      stablemembers=(list @t)
      currenthandletypes=(list @tas)
      currentproofactions=(list @tas)
      currentsurfaces=(list @t)
  ==
::
+$  graf-app-state-v4
  $:  version=@ud
      root-id=@t
      graph=graph-state:graf-sur
      machine=machine-topology:graf-sur
      impulses=(list impulse:graf-sur)
      bundles=(list bundle-ref:graf-sur)
      circulation=(list circulation-fact:graf-sur)
      seat-writes=(list graf-seat-write:graf-sur)
      handle-registry=(list graf-handle:graf-sur)
      ship-positions=(list graf-ship-position:graf-sur)
      relations=(list graf-relation:graf-sur)
      projections=(list graf-projection:graf-sur)
      search-trees=(list graf-search-tree:graf-sur)
      search-results=(list graf-search-result:graf-sur)
      proof-bundles=(list graf-proof-bundle:graf-sur)
      recent-keys=(list @t)
      last-dispatch=(unit dispatch-receipt:graf-sur)
      last-governor=(unit graf-governor-record:graf-sur)
      last-seat-write=(unit graf-seat-write:graf-sur)
      last-ship-position=(unit graf-ship-position:graf-sur)
      last-slice=(unit graf-slice:graf-sur)
      last-traversal=(unit graf-traversal-decision:graf-sur)
      last-write-intent=(unit graf-write-intent:graf-sur)
      last-residue=(unit graf-residue:graf-sur)
      last-sieve-verdict=(unit graf-sieve-verdict:graf-sur)
      last-continuation=(unit graf-continuation:graf-sur)
      last-relation=(unit graf-relation:graf-sur)
      last-projection=(unit graf-projection:graf-sur)
      last-search-tree=(unit graf-search-tree:graf-sur)
      last-search-result=(unit graf-search-result:graf-sur)
      last-proof-bundle=(unit graf-proof-bundle:graf-sur)
      runtime-status=(unit graf-runtime-status)
  ==
::
+$  graf-app-state-v5
  $:  version=@ud
      root-id=@t
      graph=graph-state:graf-sur
      machine=machine-topology:graf-sur
      impulses=(list impulse:graf-sur)
      bundles=(list bundle-ref:graf-sur)
      circulation=(list circulation-fact:graf-sur)
      seat-writes=(list graf-seat-write:graf-sur)
      axis-writes=(list graf-axis-write:graf-sur)
      handle-registry=(list graf-handle:graf-sur)
      ship-positions=(list graf-ship-position:graf-sur)
      relations=(list graf-relation:graf-sur)
      projections=(list graf-projection:graf-sur)
      search-trees=(list graf-search-tree:graf-sur)
      search-results=(list graf-search-result:graf-sur)
      proof-bundles=(list graf-proof-bundle:graf-sur)
      recent-keys=(list @t)
      last-dispatch=(unit dispatch-receipt:graf-sur)
      last-governor=(unit graf-governor-record:graf-sur)
      last-seat-write=(unit graf-seat-write:graf-sur)
      last-axis-write=(unit graf-axis-write:graf-sur)
      last-ship-position=(unit graf-ship-position:graf-sur)
      last-slice=(unit graf-slice:graf-sur)
      last-traversal=(unit graf-traversal-decision:graf-sur)
      last-write-intent=(unit graf-write-intent:graf-sur)
      last-residue=(unit graf-residue:graf-sur)
      last-sieve-verdict=(unit graf-sieve-verdict:graf-sur)
      last-continuation=(unit graf-continuation:graf-sur)
      last-relation=(unit graf-relation:graf-sur)
      last-projection=(unit graf-projection:graf-sur)
      last-search-tree=(unit graf-search-tree:graf-sur)
      last-search-result=(unit graf-search-result:graf-sur)
      last-proof-bundle=(unit graf-proof-bundle:graf-sur)
      runtime-status=(unit graf-runtime-status)
  ==
::
+$  graf-app-state-v6
  $:  version=@ud
      root-id=@t
      graph=graph-state:graf-sur
      machine=machine-topology:graf-sur
      impulses=(list impulse:graf-sur)
      bundles=(list bundle-ref:graf-sur)
      packets=(list graf-packet:graf-sur)
      circulation=(list circulation-fact:graf-sur)
      seat-writes=(list graf-seat-write:graf-sur)
      axis-writes=(list graf-axis-write:graf-sur)
      handle-registry=(list graf-handle:graf-sur)
      ship-positions=(list graf-ship-position:graf-sur)
      relations=(list graf-relation:graf-sur)
      projections=(list graf-projection:graf-sur)
      search-trees=(list graf-search-tree:graf-sur)
      search-results=(list graf-search-result:graf-sur)
      provenances=(list graf-provenance:graf-sur)
      proof-bundles=(list graf-proof-bundle:graf-sur)
      recent-keys=(list @t)
      last-dispatch=(unit dispatch-receipt:graf-sur)
      last-governor=(unit graf-governor-record:graf-sur)
      last-packet=(unit graf-packet:graf-sur)
      last-seat-write=(unit graf-seat-write:graf-sur)
      last-axis-write=(unit graf-axis-write:graf-sur)
      last-ship-position=(unit graf-ship-position:graf-sur)
      last-slice=(unit graf-slice:graf-sur)
      last-traversal=(unit graf-traversal-decision:graf-sur)
      last-write-intent=(unit graf-write-intent:graf-sur)
      last-residue=(unit graf-residue:graf-sur)
      last-sieve-verdict=(unit graf-sieve-verdict:graf-sur)
      last-continuation=(unit graf-continuation:graf-sur)
      last-relation=(unit graf-relation:graf-sur)
      last-projection=(unit graf-projection:graf-sur)
      last-search-tree=(unit graf-search-tree:graf-sur)
      last-search-result=(unit graf-search-result:graf-sur)
      last-provenance=(unit graf-provenance:graf-sur)
      last-proof-bundle=(unit graf-proof-bundle:graf-sur)
      runtime-status=(unit graf-runtime-status)
  ==
::
+$  graf-app-state-v7
  $:  version=@ud
      root-id=@t
      graph=graph-state:graf-sur
      machine=machine-topology:graf-sur
      impulses=(list impulse:graf-sur)
      bundles=(list bundle-ref:graf-sur)
      packets=(list graf-packet:graf-sur)
      circulation=(list circulation-fact:graf-sur)
      seat-writes=(list graf-seat-write:graf-sur)
      axis-writes=(list graf-axis-write:graf-sur)
      handle-registry=(list graf-handle:graf-sur)
      ship-positions=(list graf-ship-position:graf-sur)
      relations=(list graf-relation:graf-sur)
      projections=(list graf-projection:graf-sur)
      search-trees=(list graf-search-tree:graf-sur)
      search-results=(list graf-search-result:graf-sur)
      provenances=(list graf-provenance:graf-sur)
      proof-bundles=(list graf-proof-bundle:graf-sur)
      event-log=(list graf-event-log-entry:graf-sur)
      reduction-agent=graf-reduction-agent-state:graf-sur
      cantrip-bindings=(list cantrip-graf-binding:graf-sur)
      tasks=(list graf-task:graf-sur)
      task-results=(list graf-task-result:graf-sur)
      bride-nets=(unit graf-bride-nets:graf-sur)
      bride-milky-way=(unit graf-bride-milky-way:graf-sur)
      recent-keys=(list @t)
      last-dispatch=(unit dispatch-receipt:graf-sur)
      last-governor=(unit graf-governor-record:graf-sur)
      last-packet=(unit graf-packet:graf-sur)
      last-seat-write=(unit graf-seat-write:graf-sur)
      last-axis-write=(unit graf-axis-write:graf-sur)
      last-ship-position=(unit graf-ship-position:graf-sur)
      last-slice=(unit graf-slice:graf-sur)
      last-traversal=(unit graf-traversal-decision:graf-sur)
      last-write-intent=(unit graf-write-intent:graf-sur)
      last-residue=(unit graf-residue:graf-sur)
      last-sieve-verdict=(unit graf-sieve-verdict:graf-sur)
      last-continuation=(unit graf-continuation:graf-sur)
      last-relation=(unit graf-relation:graf-sur)
      last-projection=(unit graf-projection:graf-sur)
      last-search-tree=(unit graf-search-tree:graf-sur)
      last-search-result=(unit graf-search-result:graf-sur)
      last-provenance=(unit graf-provenance:graf-sur)
      last-proof-bundle=(unit graf-proof-bundle:graf-sur)
      last-event-log-entry=(unit graf-event-log-entry:graf-sur)
      last-cantrip-binding=(unit cantrip-graf-binding:graf-sur)
      last-task=(unit graf-task:graf-sur)
      last-task-result=(unit graf-task-result:graf-sur)
      runtime-status=(unit graf-runtime-status)
  ==
::
::  a graf-minted content hash for a record graf itself stored: mint is
::  (shax (jam record)) computed ship-side at write time, never asserted
::  by the caller.  /x/verify-proof answers from these, not from mentions.
::
+$  graf-mint
  $:  handle=graf-handle:graf-sur
      mint=@t
  ==
::
::  FAILURE RING.  Before this, a rejected action set last-dispatch -- one
::  overwritable slot -- and minted nothing, so refusals left NO trace.  The
::  record was therefore blind to exactly the events worth reconstructing: a
::  session that recorded five ceremony milestones recorded zero of its four
::  real failures.  finalize-graf is the single arm every action path passes
::  through, so noting the rejection there is automatic; nothing has to
::  remember.  Bounded like every other family, and like every other family
::  the cap bounds the WORKING SET only: overflow stashes into the attic,
::  never into oblivion.  graf's operator ruling already forbids the
::  alternative -- facts append, cursors move, nothing is destroyed -- and a
::  failure log that erases its own oldest evidence is the one place that
::  ruling matters most.
+$  graf-failure
  $:  at=@da
      source=@tas
      action=@tas
      code=@tas
      detail=@t
      batch-id=@t
      idempotency-key=@t
  ==
::
::  v8 state: v7 plus graf-minted hashes.  the unfaced v7 tail keeps
::  every existing field addressable without another copy-pasted record.
::
+$  graf-app-state-v8
  $:  mints=(list graf-mint)
      graf-app-state-v7
  ==
::
::  v9 state (%8): the immutability ruling.  attic = append-only
::  archive of everything the working-set rings shed; the six flow
::  families (slice/traversal/write-intent/residue/sieve-verdict/
::  continuation) graduate from single-slot cursors to real rings.
::  facts append, cursors move, nothing is destroyed.
::
+$  graf-app-state-v9
  $:  attic=attic:graf-attic
      slices=(list graf-slice:graf-sur)
      traversals=(list graf-traversal-decision:graf-sur)
      write-intents=(list graf-write-intent:graf-sur)
      residues=(list graf-residue:graf-sur)
      sieve-verdicts=(list graf-sieve-verdict:graf-sur)
      continuations=(list graf-continuation:graf-sur)
      graf-app-state-v8
  ==
::
::  current state (%9): the hostile-review repairs — governor records
::  become a ring (they were the one family still destroyed on write).
::
+$  graf-app-state-v10
  $:  governors=(list graf-governor-record:graf-sur)
      graf-app-state-v9
  ==
::
::  the %16 graf shape: the failure ring atop the v10 tail.  Kept verbatim
::  so persisted state still softs.
+$  graf-app-state-v16
  $:  failures=(list graf-failure)
      failures-stashed=@ud
      graf-app-state-v10
  ==
::
::  current graf shape (%17): star-govern, its overrides, and the
::  circulation config graduate from attic stashes to PRIMARY RINGS
::  (operator direction, wiring walk R1a).  The attic returns to its
::  designed role -- archive of ring sheds only; ring overflow still
::  archives through the same lawful path, so nothing is destroyed.
+$  graf-app-state
  $:  sg-ring=(list verdict:sg)
      sg-stashed=@ud
      sgo-ring=(list override:sg)
      sgo-stashed=@ud
      cfg-ring=(list circulation-config-record)
      cfg-stashed=@ud
      graf-app-state-v16
  ==
::
::  Graf Core's state is nested intact inside canonical Graf.  The two
::  namespaces describe different graph layers: the constitutional record
::  graph above and the open fact/territory substrate below.  Keeping the
::  boundary explicit makes the merge lossless and the later donor import
::  mechanically auditable.
::
+$  graf-core-state  state:gce
+$  graf-core-state-v4  state-v4:gce
+$  graf-core-state-v5  state-v5:gce
+$  graf-core-writer-link  writer-link:gce
+$  graf-core-territory-event  territory-event:gce
+$  snapshot-control  snapshot-control:snap
+$  snapshot-action  snapshot-action:snap
::
+$  graf-unified-state-v10
  $:  core=graf-core-state-v4
      graf=graf-app-state-v10
  ==
+$  previous-current-state  [%10 unified=graf-unified-state-v10]
::  the %11 shape: gce's core BEFORE the recall index.  Kept verbatim so
::  the state written by the running agent still SOFTS -- on-load falls
::  through to !! if nothing matches, so an un-migratable shape does not
::  degrade, it CRASHES the agent holding 29.872 facts.
+$  graf-unified-state-v11
  $:  control=snapshot-control
      core=graf-core-state-v4
      graf=graf-app-state-v10
  ==
+$  v11-state  [%11 unified=graf-unified-state-v11]
::  the %13 shape: before the %siev shadow absorption.  Kept verbatim so the
::  state written by the running agent still softs.
+$  graf-unified-state-v13
  $:  control=snapshot-control
      core=graf-core-state
      graf=graf-app-state-v10
  ==
+$  graf-unified-state-v14
  $:  control=snapshot-control
      core=graf-core-state
      graf=graf-app-state-v10
      siev=siev-shadow:gsv
  ==
+$  graf-unified-state
  $:  control=snapshot-control
      core=graf-core-state
      graf=graf-app-state
      siev=siev-shadow:gsv
      receipts=(list receipt:gwr)
  ==
+$  circulation-config-record
  $:  version=%graf-circulation-config-v1
      limit=@ud
      changed-at=@da
  ==
::  the %15 shape: identical but for the graf field, which carried no
::  failure ring.  Kept verbatim so persisted state still softs.
+$  graf-unified-state-v15
  $:  control=snapshot-control
      core=graf-core-state
      graf=graf-app-state-v10
      siev=siev-shadow:gsv
      receipts=(list receipt:gwr)
  ==
+$  graf-unified-state-v12
  $:  control=snapshot-control
      core=graf-core-state-v5
      graf=graf-app-state-v10
  ==
::
+$  legacy-versioned-state
  $%  [%0 graf=legacy-graf-state]
      [%1 graf=legacy-graf-state-v2]
      [%2 graf=graf-app-state-v3]
      [%3 graf=graf-app-state-v4]
      [%4 graf=graf-app-state-v5]
      [%5 graf=graf-app-state-v6]
      [%6 graf=graf-app-state-v7]
      [%7 graf=graf-app-state-v8]
      [%8 graf=graf-app-state-v9]
      [%9 graf=graf-app-state-v10]
  ==
+$  v12-state  [%12 unified=graf-unified-state-v12]
+$  v13-state  [%13 unified=graf-unified-state-v13]
+$  v14-state  [%14 unified=graf-unified-state-v14]
+$  v15-state  [%15 unified=graf-unified-state-v15]
::  the %16 unified shape: identical but for the graf field, which had no
::  primary rings.  Kept verbatim so persisted state still softs.
+$  graf-unified-state-v16
  $:  control=snapshot-control
      core=graf-core-state
      graf=graf-app-state-v16
      siev=siev-shadow:gsv
      receipts=(list receipt:gwr)
  ==
+$  v16-state  [%17 unified=graf-unified-state-v16]
+$  current-state  [%17 unified=graf-unified-state]
+$  card   card:agent:gall
+$  search-candidate  [h=graf-handle:graf-sur n=*]
::
++  publish-viki-rels
  |=  [tiers=tiers:graf-relations rels=(list rel:vl)]
  ^-  tiers:graf-relations
  =/  current=(set rel:vl)
    (slot-of:graf-relations tiers %viki)
  =/  next=(set rel:vl)
    (~(gas in current) rels)
  tiers(published (~(put by published.tiers) %viki next))
++  viki-terminal-conflict
  |=  [slot=(set rel:vl) expected=rel:vl]
  ^-  ?
  %+  lien  ~(tap in slot)
  |=  existing=rel:vl
  ?&  =(src.expected src.existing)
      ?|  =(%answered-by kind.existing)
          =(%refused-by kind.existing)
      ==
      !=(expected existing)
  ==
++  max-impulses  64
++  max-bundles  64
++  max-packets  64
++  max-circulation  128
++  max-configured-circulation  8.192
++  max-seat-writes  256
++  max-axis-writes  512
++  max-graph-nodes  256
++  max-graph-edges  256
++  max-handle-registry  512
++  max-ship-positions  256
++  max-relations  256
++  max-projections  256
++  max-search-trees  128
++  max-search-results  128
++  max-provenances  256
++  max-proof-bundles  128
++  max-event-log  256
++  max-reduction-outputs  128
++  max-reduction-candidates  128
++  max-reduction-verdicts  128
++  max-convergence-records  128
::  Configuration is an append-only operator record in Graf's existing attic.
::  This gives it durable history without changing the live state mold.  The
::  newest well-formed record wins; malformed archive data fails to the old
::  compiled default instead of widening the working set.
++  circulation-config
  |=  graf=graf-app-state
  ^-  circulation-config-record
  =/  records  cfg-ring.graf
  |-
  ?~  records
    [%graf-circulation-config-v1 max-circulation *@da]
  ?:  ?|(=(0 limit.i.records) (gth limit.i.records max-configured-circulation))
    $(records t.records)
  i.records
++  star-govern-history
  |=  [graf=graf-app-state requested=@ud]
  ^-  (list verdict:sg)
  (scag ?:((gth requested primary-ring-cap) primary-ring-cap requested) sg-ring.graf)
++  latest-star-govern
  |=  graf=graf-app-state
  ^-  (unit verdict:sg)
  ?~(sg-ring.graf ~ `i.sg-ring.graf)
++  star-govern-read
  |=  [graf=graf-app-state at=@da]
  ^-  read:sg
  =/  latest=(unit verdict:sg)  (latest-star-govern graf)
  ?~  latest
    [%no-signal %missing ~ ~]
  ?:  (gte at expires-at.u.latest)
    [%no-signal %stale `observed-at.u.latest `expires-at.u.latest]
  [%signal u.latest]
++  star-govern-override-history
  |=  [graf=graf-app-state requested=@ud]
  ^-  (list override:sg)
  (scag ?:((gth requested primary-ring-cap) primary-ring-cap requested) sgo-ring.graf)
++  latest-star-govern-override
  |=  graf=graf-app-state
  ^-  (unit override:sg)
  ?~(sgo-ring.graf ~ `i.sgo-ring.graf)
++  max-tasks  128
++  max-task-results  128
++  max-recent-keys  128
::  the mint ring must be at least as deep as every mint-bearing
::  working set COMBINED, or verify-proof un-verifies records graf
::  still holds (hostile-review defect: 512 was smaller than the
::  ~4000-record certified surface)
++  max-mints  8.192
++  max-cantrip-bindings  128
++  max-flow  128
++  max-search-scan  512
++  max-search-terms  64
++  max-search-domains  16
++  max-search-term-bytes  4.096
::
++  root-axis  1
++  domain-trunk-axis  2
++  seat-trunk-axis  3
::
++  domain-axis-for
  |=  domain=@tas
  ^-  @ud
  ?+    domain  domain-trunk-axis
      %handle-registry  4
      %graph-matter  5
      %machine-topology  8
      %runtime-state  9
      %bundle-packet-state  10
      %circulation-facts  11
      %bride-memory  16
      %crossing-lane  17
      %projection-views  18
  ==
::
::  FIXED 2026-08-16.  The seats used to sit at 6, 7, 12, 13, 14, 15, 24,
::  25, 26 -- axes that CONTAIN one another in the binary tree, so %flunky
::  writing at relative axis 2 landed inside %policeman's region and the
::  gate allowed it.  Ten nesting pairs, one axis claimed by three seats.
::  The roster now lives at 48-56 (same depth, therefore disjoint by
::  construction) and the gate re-checks where the graft lands.
::
::  One site: lib/graf-axis-law is the law, this is the call.
::
++  seat-region-axis-for
  |=  seat-id=@tas
  ^-  (unit @ud)
  (seat-region-axis-for:gal seat-id)
::
++  init-graf
  ^-  graf-app-state-v7
  [ version=10
    root-id='graf-host-root-v1'
    graph=[~ ~]
    machine=[~ ~]
    impulses=~
    bundles=~
    packets=~
    circulation=~
    seat-writes=~
    axis-writes=~
    handle-registry=~
    ship-positions=~
    relations=~
    projections=~
    search-trees=~
    search-results=~
    provenances=~
    proof-bundles=~
    event-log=~
    reduction-agent=[~ ~ ~ ~]
    cantrip-bindings=~
    tasks=~
    task-results=~
    bride-nets=~
    bride-milky-way=~
    recent-keys=~
    last-dispatch=~
    last-governor=~
    last-packet=~
    last-seat-write=~
    last-axis-write=~
    last-ship-position=~
    last-slice=~
    last-traversal=~
    last-write-intent=~
    last-residue=~
    last-sieve-verdict=~
    last-continuation=~
    last-relation=~
    last-projection=~
    last-search-tree=~
    last-search-result=~
    last-provenance=~
    last-proof-bundle=~
    last-event-log-entry=~
    last-cantrip-binding=~
    last-task=~
    last-task-result=~
    runtime-status=~
  ]
::
++  upgrade-graf
  |=  old=legacy-graf-state
  ^-  graf-app-state-v7
  [ version=10
    root-id='graf-host-root-v1'
    graph=graph.old
    machine=machine.old
    impulses=impulses.old
    bundles=bundles.old
    packets=~
    circulation=circulation.old
    seat-writes=~
    axis-writes=~
    handle-registry=~
    ship-positions=~
    relations=~
    projections=~
    search-trees=~
    search-results=~
    provenances=~
    proof-bundles=~
    event-log=~
    reduction-agent=[~ ~ ~ ~]
    cantrip-bindings=~
    tasks=~
    task-results=~
    bride-nets=~
    bride-milky-way=~
    recent-keys=recent-keys.old
    last-dispatch=last-dispatch.old
    last-governor=~
    last-packet=~
    last-seat-write=~
    last-axis-write=~
    last-ship-position=~
    last-slice=~
    last-traversal=~
    last-write-intent=~
    last-residue=~
    last-sieve-verdict=~
    last-continuation=~
    last-relation=~
    last-projection=~
    last-search-tree=~
    last-search-result=~
    last-provenance=~
    last-proof-bundle=~
    last-event-log-entry=~
    last-cantrip-binding=~
    last-task=~
    last-task-result=~
    runtime-status=~
  ]
::
++  upgrade-graf-v2
  |=  old=legacy-graf-state-v2
  ^-  graf-app-state-v7
  [ version=10
    root-id='graf-host-root-v1'
    graph=graph.old
    machine=machine.old
    impulses=impulses.old
    bundles=bundles.old
    packets=~
    circulation=circulation.old
    seat-writes=~
    axis-writes=~
    handle-registry=~
    ship-positions=~
    relations=~
    projections=~
    search-trees=~
    search-results=~
    provenances=~
    proof-bundles=~
    event-log=~
    reduction-agent=[~ ~ ~ ~]
    cantrip-bindings=~
    tasks=~
    task-results=~
    bride-nets=~
    bride-milky-way=~
    recent-keys=recent-keys.old
    last-dispatch=last-dispatch.old
    last-governor=last-governor.old
    last-packet=~
    last-seat-write=~
    last-axis-write=~
    last-ship-position=~
    last-slice=last-slice.old
    last-traversal=last-traversal.old
    last-write-intent=last-write-intent.old
    last-residue=last-residue.old
    last-sieve-verdict=last-sieve-verdict.old
    last-continuation=last-continuation.old
    last-relation=~
    last-projection=~
    last-search-tree=~
    last-search-result=~
    last-provenance=~
    last-proof-bundle=~
    last-event-log-entry=~
    last-cantrip-binding=~
    last-task=~
    last-task-result=~
    runtime-status=runtime-status.old
  ]
::
++  upgrade-graf-v3
  |=  old=graf-app-state-v3
  ^-  graf-app-state-v7
  [ version=10
    root-id=root-id.old
    graph=graph.old
    machine=machine.old
    impulses=impulses.old
    bundles=bundles.old
    packets=~
    circulation=circulation.old
    seat-writes=seat-writes.old
    axis-writes=~
    handle-registry=~
    ship-positions=~
    relations=~
    projections=~
    search-trees=~
    search-results=~
    provenances=~
    proof-bundles=~
    event-log=~
    reduction-agent=[~ ~ ~ ~]
    cantrip-bindings=~
    tasks=~
    task-results=~
    bride-nets=~
    bride-milky-way=~
    recent-keys=recent-keys.old
    last-dispatch=last-dispatch.old
    last-governor=last-governor.old
    last-packet=~
    last-seat-write=last-seat-write.old
    last-axis-write=~
    last-ship-position=~
    last-slice=last-slice.old
    last-traversal=last-traversal.old
    last-write-intent=last-write-intent.old
    last-residue=last-residue.old
    last-sieve-verdict=last-sieve-verdict.old
    last-continuation=last-continuation.old
    last-relation=~
    last-projection=~
    last-search-tree=~
    last-search-result=~
    last-provenance=~
    last-proof-bundle=~
    last-event-log-entry=~
    last-cantrip-binding=~
    last-task=~
    last-task-result=~
    runtime-status=runtime-status.old
  ]
::
++  upgrade-graf-v4
  |=  old=graf-app-state-v4
  ^-  graf-app-state-v7
  [ version=10
    root-id=root-id.old
    graph=graph.old
    machine=machine.old
    impulses=impulses.old
    bundles=bundles.old
    packets=~
    circulation=circulation.old
    seat-writes=seat-writes.old
    axis-writes=~
    handle-registry=handle-registry.old
    ship-positions=ship-positions.old
    relations=relations.old
    projections=projections.old
    search-trees=search-trees.old
    search-results=search-results.old
    provenances=~
    proof-bundles=proof-bundles.old
    event-log=~
    reduction-agent=[~ ~ ~ ~]
    cantrip-bindings=~
    tasks=~
    task-results=~
    bride-nets=~
    bride-milky-way=~
    recent-keys=recent-keys.old
    last-dispatch=last-dispatch.old
    last-governor=last-governor.old
    last-packet=~
    last-seat-write=last-seat-write.old
    last-axis-write=~
    last-ship-position=last-ship-position.old
    last-slice=last-slice.old
    last-traversal=last-traversal.old
    last-write-intent=last-write-intent.old
    last-residue=last-residue.old
    last-sieve-verdict=last-sieve-verdict.old
    last-continuation=last-continuation.old
    last-relation=last-relation.old
    last-projection=last-projection.old
    last-search-tree=last-search-tree.old
    last-search-result=last-search-result.old
    last-provenance=~
    last-proof-bundle=last-proof-bundle.old
    last-event-log-entry=~
    last-cantrip-binding=~
    last-task=~
    last-task-result=~
    runtime-status=runtime-status.old
  ]
::
++  upgrade-graf-v5
  |=  old=graf-app-state-v5
  ^-  graf-app-state-v7
  [ version=10
    root-id=root-id.old
    graph=graph.old
    machine=machine.old
    impulses=impulses.old
    bundles=bundles.old
    packets=~
    circulation=circulation.old
    seat-writes=seat-writes.old
    axis-writes=axis-writes.old
    handle-registry=handle-registry.old
    ship-positions=ship-positions.old
    relations=relations.old
    projections=projections.old
    search-trees=search-trees.old
    search-results=search-results.old
    provenances=~
    proof-bundles=proof-bundles.old
    event-log=~
    reduction-agent=[~ ~ ~ ~]
    cantrip-bindings=~
    tasks=~
    task-results=~
    bride-nets=~
    bride-milky-way=~
    recent-keys=recent-keys.old
    last-dispatch=last-dispatch.old
    last-governor=last-governor.old
    last-packet=~
    last-seat-write=last-seat-write.old
    last-axis-write=last-axis-write.old
    last-ship-position=last-ship-position.old
    last-slice=last-slice.old
    last-traversal=last-traversal.old
    last-write-intent=last-write-intent.old
    last-residue=last-residue.old
    last-sieve-verdict=last-sieve-verdict.old
    last-continuation=last-continuation.old
    last-relation=last-relation.old
    last-projection=last-projection.old
    last-search-tree=last-search-tree.old
    last-search-result=last-search-result.old
    last-provenance=~
    last-proof-bundle=last-proof-bundle.old
    last-event-log-entry=~
    last-cantrip-binding=~
    last-task=~
    last-task-result=~
    runtime-status=runtime-status.old
  ]
::
++  upgrade-graf-v6
  |=  old=graf-app-state-v6
  ^-  graf-app-state-v7
  [ version=10
    root-id=root-id.old
    graph=graph.old
    machine=machine.old
    impulses=impulses.old
    bundles=bundles.old
    packets=packets.old
    circulation=circulation.old
    seat-writes=seat-writes.old
    axis-writes=axis-writes.old
    handle-registry=handle-registry.old
    ship-positions=ship-positions.old
    relations=relations.old
    projections=projections.old
    search-trees=search-trees.old
    search-results=search-results.old
    provenances=provenances.old
    proof-bundles=proof-bundles.old
    event-log=~
    reduction-agent=[~ ~ ~ ~]
    cantrip-bindings=~
    tasks=~
    task-results=~
    bride-nets=~
    bride-milky-way=~
    recent-keys=recent-keys.old
    last-dispatch=last-dispatch.old
    last-governor=last-governor.old
    last-packet=last-packet.old
    last-seat-write=last-seat-write.old
    last-axis-write=last-axis-write.old
    last-ship-position=last-ship-position.old
    last-slice=last-slice.old
    last-traversal=last-traversal.old
    last-write-intent=last-write-intent.old
    last-residue=last-residue.old
    last-sieve-verdict=last-sieve-verdict.old
    last-continuation=last-continuation.old
    last-relation=last-relation.old
    last-projection=last-projection.old
    last-search-tree=last-search-tree.old
    last-search-result=last-search-result.old
    last-provenance=last-provenance.old
    last-proof-bundle=last-proof-bundle.old
    last-event-log-entry=~
    last-cantrip-binding=~
    last-task=~
    last-task-result=~
    runtime-status=runtime-status.old
  ]
::
++  lift-v8
  |=  old=graf-app-state-v8
  ^-  graf-app-state-v9
  [*attic:graf-attic ~ ~ ~ ~ ~ ~ old]
::
++  lift-v9
  |=  old=graf-app-state-v9
  ^-  graf-app-state-v10
  [~ old(version 10)]
::  v10 -> current: an empty failure ring.  Nothing is invented for the
::  past; the ring starts where the recording starts.
++  lift-v10
  |=  old=graf-app-state-v10
  ^-  graf-app-state-v16
  [~ 0 old(version 11)]
::
++  current-graf
  |=  st=legacy-versioned-state
  ^-  graf-app-state-v10
  ?-  -.st
    %0  (lift-v9 (lift-v8 [~ (upgrade-graf graf.st)]))
    %1  (lift-v9 (lift-v8 [~ (upgrade-graf-v2 graf.st)]))
    %2  (lift-v9 (lift-v8 [~ (upgrade-graf-v3 graf.st)]))
    %3  (lift-v9 (lift-v8 [~ (upgrade-graf-v4 graf.st)]))
    %4  (lift-v9 (lift-v8 [~ (upgrade-graf-v5 graf.st)]))
    %5  (lift-v9 (lift-v8 [~ (upgrade-graf-v6 graf.st)]))
    %6  (lift-v9 (lift-v8 [~ graf.st]))
    %7  (lift-v9 (lift-v8 graf.st))
    %8  (lift-v9 graf.st)
    %9  graf.st
  ==
::
::  ring insert under the immutability ruling: the cap bounds the
::  WORKING SET only — everything past it stashes into the attic,
::  never into oblivion.
::
++  overflow
  |=  [graf=graf-app-state family=@tas drops=(list *)]
  ^-  graf-app-state
  graf(attic (stash:graf-attic attic.graf family drops))
::
++  add-impulse
  |=  [graf=graf-app-state impulse=impulse:graf-sur]
  ^-  graf-app-state
  =/  full  (weld ~[impulse] impulses.graf)
  =.  graf  (overflow graf %impulses (slag max-impulses full))
  graf(impulses (scag max-impulses full))
::
++  add-bundle
  |=  [graf=graf-app-state bund=bundle-ref:graf-sur]
  ^-  graf-app-state
  =/  full  (weld ~[bund] bundles.graf)
  =.  graf  (overflow graf %bundles (slag max-bundles full))
  graf(bundles (scag max-bundles full))
::
++  add-packet
  |=  [graf=graf-app-state packet=graf-packet:graf-sur]
  ^-  graf-app-state
  =/  full  (weld ~[packet] packets.graf)
  =.  graf  (overflow graf %packets (slag max-packets full))
  %=  graf
    packets  (scag max-packets full)
    last-packet  `packet
  ==
::
++  add-circulation
  |=  [graf=graf-app-state fact=circulation-fact:graf-sur limit=@ud]
  ^-  graf-app-state
  =/  full  (weld ~[fact] circulation.graf)
  =.  graf  (overflow graf %circulation (slag limit full))
  graf(circulation (scag limit full))
::
++  add-seat-write
  |=  [graf=graf-app-state seat-write=graf-seat-write:graf-sur]
  ^-  graf-app-state
  =/  full  (weld ~[seat-write] seat-writes.graf)
  =.  graf  (overflow graf %seat-writes (slag max-seat-writes full))
  %=  graf
    seat-writes  (scag max-seat-writes full)
    last-seat-write  `seat-write
  ==
::
++  add-axis-write
  |=  [graf=graf-app-state axis-write=graf-axis-write:graf-sur]
  ^-  graf-app-state
  =/  full  (weld ~[axis-write] axis-writes.graf)
  =.  graf  (overflow graf %axis-writes (slag max-axis-writes full))
  %=  graf
    axis-writes  (scag max-axis-writes full)
    last-axis-write  `axis-write
  ==
::
::  full equality including hash: a re-mentioned handle asserting a
::  DIFFERENT hash is a conflicting claim and must be preserved as a
::  new registry entry, never silently dropped (newest-first order
::  means readers see the latest assertion; history keeps the conflict)
::
++  same-handle
  |=  [a=graf-handle:graf-sur b=graf-handle:graf-sur]
  ^-  ?
  ?&  =(type.a type.b)
      =(version.a version.b)
      =(id.a id.b)
      =(hash.a hash.b)
  ==
::
++  seen-handle
  |=  [handles=(list graf-handle:graf-sur) target=graf-handle:graf-sur]
  ^-  ?
  ?~  handles  %.n
  ?:  (same-handle i.handles target)
    %.y
  $(handles t.handles)
::
++  remember-handle
  |=  [graf=graf-app-state handle=graf-handle:graf-sur]
  ^-  graf-app-state
  ?:  (seen-handle handle-registry.graf handle)
    graf
  =/  full  (weld ~[handle] handle-registry.graf)
  =.  graf  (overflow graf %handle-registry (slag max-handle-registry full))
  graf(handle-registry (scag max-handle-registry full))
::
++  remember-handle-list
  |=  [graf=graf-app-state handles=(list graf-handle:graf-sur)]
  ^-  graf-app-state
  ?~  handles  graf
  $(graf (remember-handle graf i.handles), handles t.handles)
::
::  supersession-aware readers: newest-first lists may hold superseded
::  versions beneath the current one; these views keep only the first
::  (newest) record per identity, so counts and inventories describe
::  the PRESENT while the rings keep the past.
::
++  latest-nodes
  |=  nodes=(list concept-node:graf-sur)
  ^-  (list concept-node:graf-sur)
  =/  seen  *(set @tas)
  |-  ^-  (list concept-node:graf-sur)
  ?~  nodes  ~
  ?:  (~(has in seen) id.i.nodes)
    $(nodes t.nodes)
  [i.nodes $(nodes t.nodes, seen (~(put in seen) id.i.nodes))]
::
++  latest-edges
  |=  edges=(list relation-edge:graf-sur)
  ^-  (list relation-edge:graf-sur)
  =/  seen  *(set [@tas @tas @tas])
  |-  ^-  (list relation-edge:graf-sur)
  ?~  edges  ~
  =/  key  [from.i.edges to.i.edges label.i.edges]
  ?:  (~(has in seen) key)
    $(edges t.edges)
  [i.edges $(edges t.edges, seen (~(put in seen) key))]
::
++  latest-positions
  |=  positions=(list graf-ship-position:graf-sur)
  ^-  (list graf-ship-position:graf-sur)
  =/  seen  *(set @tas)
  |-  ^-  (list graf-ship-position:graf-sur)
  ?~  positions  ~
  ?:  (~(has in seen) seat-id.i.positions)
    $(positions t.positions)
  [i.positions $(positions t.positions, seen (~(put in seen) seat-id.i.positions))]
::
++  latest-relations
  |=  relations=(list graf-relation:graf-sur)
  ^-  (list graf-relation:graf-sur)
  =/  seen  *(set @t)
  |-  ^-  (list graf-relation:graf-sur)
  ?~  relations  ~
  ?:  (~(has in seen) id.handle.i.relations)
    $(relations t.relations)
  [i.relations $(relations t.relations, seen (~(put in seen) id.handle.i.relations))]
::
::  supersession, not strip-and-replace: newest-first order means every
::  find-* reader gets the current version for free while prior versions
::  survive beneath (and eventually in the attic).
::
++  add-ship-position
  |=  [graf=graf-app-state position=graf-ship-position:graf-sur]
  ^-  graf-app-state
  =/  full  (weld ~[position] ship-positions.graf)
  =.  graf  (overflow graf %ship-positions (slag max-ship-positions full))
  %=  graf
    ship-positions  (scag max-ship-positions full)
    last-ship-position  `position
  ==
::
++  add-concept-node
  |=  [graf=graf-app-state node=concept-node:graf-sur]
  ^-  graf-app-state
  =/  full  (weld ~[node] nodes.graph.graf)
  =.  graf  (overflow graf %graph-nodes (slag max-graph-nodes full))
  graf(graph graph.graf(nodes (scag max-graph-nodes full)))
::
++  add-relation-edge
  |=  [graf=graf-app-state edge=relation-edge:graf-sur]
  ^-  graf-app-state
  =/  full  (weld ~[edge] edges.graph.graf)
  =.  graf  (overflow graf %graph-edges (slag max-graph-edges full))
  graf(graph graph.graf(edges (scag max-graph-edges full)))
::
++  add-relation
  |=  [graf=graf-app-state relation=graf-relation:graf-sur]
  ^-  graf-app-state
  =/  full  (weld ~[relation] relations.graf)
  =.  graf  (overflow graf %relations (slag max-relations full))
  %=  graf
    relations  (scag max-relations full)
    last-relation  `relation
  ==
::
++  add-projection
  |=  [graf=graf-app-state projection=graf-projection:graf-sur]
  ^-  graf-app-state
  =/  full  (weld ~[projection] projections.graf)
  =.  graf  (overflow graf %projections (slag max-projections full))
  %=  graf
    projections  (scag max-projections full)
    last-projection  `projection
  ==
::
++  add-search-tree
  |=  [graf=graf-app-state tree=graf-search-tree:graf-sur]
  ^-  graf-app-state
  =/  full  (weld ~[tree] search-trees.graf)
  =.  graf  (overflow graf %search-trees (slag max-search-trees full))
  %=  graf
    search-trees  (scag max-search-trees full)
    last-search-tree  `tree
  ==
::
++  add-search-result
  |=  [graf=graf-app-state result=graf-search-result:graf-sur]
  ^-  graf-app-state
  =/  full  (weld ~[result] search-results.graf)
  =.  graf  (overflow graf %search-results (slag max-search-results full))
  %=  graf
    search-results  (scag max-search-results full)
    last-search-result  `result
  ==
::
++  add-provenance
  |=  [graf=graf-app-state provenance=graf-provenance:graf-sur]
  ^-  graf-app-state
  =/  full  (weld ~[provenance] provenances.graf)
  =.  graf  (overflow graf %provenances (slag max-provenances full))
  %=  graf
    provenances  (scag max-provenances full)
    last-provenance  `provenance
  ==
::
++  add-proof-bundle
  |=  [graf=graf-app-state bundle=graf-proof-bundle:graf-sur]
  ^-  graf-app-state
  =/  full  (weld ~[bundle] proof-bundles.graf)
  =.  graf  (overflow graf %proof-bundles (slag max-proof-bundles full))
  %=  graf
    proof-bundles  (scag max-proof-bundles full)
    last-proof-bundle  `bundle
  ==
::
++  controlled-agency-proof-bundle-relation
  |=  bundle=graf-proof-bundle:graf-sur
  ^-  graf-relation:graf-sur
  =/  rel-id=@t  (crip "controlled-agency-proof-bundle-{(trip source.bundle)}")
  :*  handle=[type=%relation version=1 id=rel-id hash=receipt-hash.bundle]
      relation-kind=%controlled-agency-proof-bundle
      source=[type=%controlled-agency-run version=1 id=source.bundle hash=source.bundle]
      target=handle.bundle
      label=%reconstructs-proof-bundle
      summary=(crip "Controlled-agency proof bundle {(trip id.handle.bundle)} reconstructs run {(trip source.bundle)}")
  ==
::
::
::
::
++  add-bachelor-output
  |=  [graf=graf-app-state output=graf-bachelor-output:graf-sur]
  ^-  graf-app-state
  =/  old  reduction-agent.graf
  =/  full  (weld ~[output] outputs.old)
  =.  graf  (overflow graf %reduction-outputs (slag max-reduction-outputs full))
  graf(reduction-agent old(outputs (scag max-reduction-outputs full)))
::
++  add-reduction-candidate
  |=  [graf=graf-app-state candidate=graf-reduction-candidate:graf-sur]
  ^-  graf-app-state
  =/  old  reduction-agent.graf
  =/  full  (weld ~[candidate] candidates.old)
  =.  graf  (overflow graf %reduction-candidates (slag max-reduction-candidates full))
  graf(reduction-agent old(candidates (scag max-reduction-candidates full)))
::
++  add-reduction-verdict
  |=  [graf=graf-app-state verdict=graf-reduction-verdict:graf-sur]
  ^-  graf-app-state
  =/  old  reduction-agent.graf
  =/  full  (weld ~[verdict] verdicts.old)
  =.  graf  (overflow graf %reduction-verdicts (slag max-reduction-verdicts full))
  graf(reduction-agent old(verdicts (scag max-reduction-verdicts full)))
::
++  add-convergence-record
  |=  [graf=graf-app-state convergence=graf-convergence-record:graf-sur]
  ^-  graf-app-state
  =/  old  reduction-agent.graf
  =/  full  (weld ~[convergence] convergences.old)
  =.  graf  (overflow graf %convergence-records (slag max-convergence-records full))
  graf(reduction-agent old(convergences (scag max-convergence-records full)))
::
++  add-event-log-entry
  |=  [graf=graf-app-state entry=graf-event-log-entry:graf-sur]
  ^-  graf-app-state
  =/  full  (weld ~[entry] event-log.graf)
  =.  graf  (overflow graf %event-log (slag max-event-log full))
  %=  graf
    event-log  (scag max-event-log full)
    last-event-log-entry  `entry
  ==
::
++  add-task
  |=  [graf=graf-app-state task=graf-task:graf-sur]
  ^-  graf-app-state
  =/  full  (weld ~[task] tasks.graf)
  =.  graf  (overflow graf %tasks (slag max-tasks full))
  %=  graf
    tasks  (scag max-tasks full)
    last-task  `task
  ==
::
++  add-task-result
  |=  [graf=graf-app-state result=graf-task-result:graf-sur]
  ^-  graf-app-state
  =/  full  (weld ~[result] task-results.graf)
  =.  graf  (overflow graf %task-results (slag max-task-results full))
  %=  graf
    task-results  (scag max-task-results full)
    last-task-result  `result
  ==
++  add-cantrip-binding
  |=  [graf=graf-app-state binding=cantrip-graf-binding:graf-sur]
  ^-  graf-app-state
  =/  full  (weld ~[binding] cantrip-bindings.graf)
  =.  graf  (overflow graf %cantrip-bindings (slag max-cantrip-bindings full))
  %=  graf
    cantrip-bindings  (scag max-cantrip-bindings full)
    last-cantrip-binding  `binding
  ==
::
::  wholesale replacers archive the prior structure before replacing:
::  the ship never forgets what it used to believe.
::
++  set-bride-nets
  |=  [graf=graf-app-state nets=graf-bride-nets:graf-sur]
  ^-  graf-app-state
  =?  graf  ?=(^ bride-nets.graf)
    (overflow graf %bride-nets ~[u.bride-nets.graf])
  graf(bride-nets `nets)
::
++  set-bride-milky-way
  |=  [graf=graf-app-state milky-way=graf-bride-milky-way:graf-sur]
  ^-  graf-app-state
  =?  graf  ?=(^ bride-milky-way.graf)
    (overflow graf %bride-milky-way ~[u.bride-milky-way.graf])
  graf(bride-milky-way `milky-way)
::
++  seen-key
  |=  [keys=(list @t) target=@t]
  ^-  ?
  ?~  keys  %.n
  ?:  =(i.keys target)
    %.y
  $(keys t.keys)
::
++  seen-seat-id
  |=  [seat-ids=(list @tas) target=@tas]
  ^-  ?
  ?~  seat-ids  %.n
  ?:  =(i.seat-ids target)
    %.y
  $(seat-ids t.seat-ids)
::
++  duplicate-seat-id-present
  |=  [seat-writes=(list graf-seat-write:graf-sur) seen=(list @tas)]
  ^-  ?
  ?~  seat-writes  %.n
  ?:  (seen-seat-id seen seat-id.i.seat-writes)
    %.y
  $(seat-writes t.seat-writes, seen [seat-id.i.seat-writes seen])
::
++  seen-text
  |=  [texts=(list @t) target=@t]
  ^-  ?
  ?~  texts  %.n
  ?:  =(i.texts target)
    %.y
  $(texts t.texts)
::
++  duplicate-session-id-present
  |=  [seat-writes=(list graf-seat-write:graf-sur) seen=(list @t)]
  ^-  ?
  ?~  seat-writes  %.n
  ?:  (seen-text seen session-id.i.seat-writes)
    %.y
  $(seat-writes t.seat-writes, seen [session-id.i.seat-writes seen])
::
++  duplicate-assigned-ship-id-present
  |=  [seat-writes=(list graf-seat-write:graf-sur) seen=(list @t)]
  ^-  ?
  ?~  seat-writes  %.n
  ?:  (seen-text seen assigned-ship-id.i.seat-writes)
    %.y
  $(seat-writes t.seat-writes, seen [assigned-ship-id.i.seat-writes seen])
::
++  seat-write-collision-codes
  |=  seat-writes=(list graf-seat-write:graf-sur)
  ^-  (list @tas)
  =/  collisions=(list @tas)  ~
  =.  collisions
    ?:  (duplicate-seat-id-present seat-writes ~)
      [%duplicate-seat-id collisions]
    collisions
  =.  collisions
    ?:  (duplicate-session-id-present seat-writes ~)
      [%duplicate-session-id collisions]
    collisions
  =.  collisions
    ?:  (duplicate-assigned-ship-id-present seat-writes ~)
      [%duplicate-assigned-ship-id collisions]
    collisions
  (flop collisions)
::
++  nonzero-ud
  |=  value=@ud
  ^-  ?
  ?:(=(value 0) %.n %.y)
::
::  the gate is lib/graf-axis-law's now -- this is the adapter that hands
::  it the seat claims out of state.  Proven by ted/ph/graf-axis-law-proof,
::  which a thread can import and this agent cannot.
::
++  axis-write-authorized
  |=  [graf=graf-app-state axis-write=graf-axis-write:graf-sur]
  ^-  ?
  (axis-write-authorized:gal seat-writes.graf axis-write)
::
++  filter-axis-writes
  |=  [axis-writes=(list graf-axis-write:graf-sur) seat-id=@tas]
  ^-  (list graf-axis-write:graf-sur)
  ?~  axis-writes  ~
  ?:  =(seat-id.i.axis-writes seat-id)
    [i.axis-writes $(axis-writes t.axis-writes)]
  $(axis-writes t.axis-writes)
::
++  count-axis-writes-for-seat
  |=  [axis-writes=(list graf-axis-write:graf-sur) seat-id=@tas]
  ^-  @ud
  ?~  axis-writes  0
  ?:  =(seat-id.i.axis-writes seat-id)
    (add 1 $(axis-writes t.axis-writes))
  $(axis-writes t.axis-writes)
::
++  latest-axis-write-for-seat
  |=  [axis-writes=(list graf-axis-write:graf-sur) seat-id=@tas]
  ^-  (unit graf-axis-write:graf-sur)
  ?~  axis-writes  ~
  ?:  =(seat-id.i.axis-writes seat-id)
    `i.axis-writes
  $(axis-writes t.axis-writes)
::
++  axis-ancestor-axes
  |=  axis=@ud
  ^-  (list @ud)
  ?:  =(axis 1)
    ~[1]
  (weld $(axis (div axis 2)) ~[axis])
::
++  axis-slot-path
  |=  axis=@ud
  ^-  (list @ud)
  ?:  =(axis 1)
    ~
  =/  parent-axis=@ud  (div axis 2)
  =/  step=@ud
    ?:  =(axis (mul 2 parent-axis))
      2
    3
  (weld $(axis parent-axis) ~[step])
::
++  remember-key
  |=  [graf=graf-app-state key=@t]
  ^-  graf-app-state
  graf(recent-keys (scag max-recent-keys (weld ~[key] recent-keys.graf)))
::
++  summarize-graph
  |=  graf=graf-app-state
  ^-  graph-summary:graf-sur
  ::  Include first-class relation records in the operator-visible graph
  ::  summary; otherwise real %record-relation writes stay invisible here.
  ::  Counts are of CURRENT versions; superseded copies stay in the rings.
  :-  (lent (latest-nodes nodes.graph.graf))
  %+  add
    (lent (latest-edges edges.graph.graf))
  (lent (latest-relations relations.graf))
::
++  summarize-root
  |=  graf=graf-app-state
  ^-  graf-root-summary:graf-sur
  =/  lsid=(unit @tas)
    ?~  last-seat-write.graf
      ~
    `seat-id.u.last-seat-write.graf
  [ root-id=root-id.graf
    contribution-count=(add (lent seat-writes.graf) (lent axis-writes.graf))
    seat-count=(lent (latest-positions ship-positions.graf))
    last-seat-id=lsid
  ]
::
++  unit-count
  |=  maybe=(unit *)
  ^-  @ud
  ?~  maybe  0
  1
::
++  sum-ud-list
  |=  counts=(list @ud)
  ^-  @ud
  ?~  counts  0
  (add i.counts $(counts t.counts))
::
++  handle-last-id
  |=  handles=(list graf-handle:graf-sur)
  ^-  (unit @t)
  ?~  handles  ~
  `id.i.handles
::
++  bundle-last-id
  |=  bundles=(list bundle-ref:graf-sur)
  ^-  (unit @t)
  ?~  bundles  ~
  `bundle-id.i.bundles
::
++  packet-last-id
  |=  packets=(list graf-packet:graf-sur)
  ^-  (unit @t)
  ?~  packets  ~
  `id.handle.i.packets
::
++  fact-last-id
  |=  facts=(list circulation-fact:graf-sur)
  ^-  (unit @t)
  ?~  facts  ~
  `fact-id.i.facts
::
++  build-root-domains
  |=  graf=graf-app-state
  ^-  graf-root-domains:graf-sur
  =/  graph-count=@ud
    (add (lent nodes.graph.graf) (add (lent edges.graph.graf) (lent relations.graf)))
  =/  machine-count=@ud
    (add (lent nodes.machine.graf) (add (lent edges.machine.graf) (lent ship-positions.graf)))
  =/  runtime-proof-count=@ud
    (sum-ud-list ~[(lent search-trees.graf) (lent proof-bundles.graf)])
  =/  runtime-event-count=@ud
    (sum-ud-list ~[(unit-count last-governor.graf) (unit-count last-seat-write.graf) (unit-count last-axis-write.graf) (unit-count last-ship-position.graf) (unit-count last-slice.graf) (unit-count last-traversal.graf) (unit-count last-write-intent.graf) (unit-count last-residue.graf) (unit-count last-sieve-verdict.graf) (unit-count last-continuation.graf)])
  =/  runtime-count=@ud
    (sum-ud-list ~[(lent impulses.graf) runtime-event-count runtime-proof-count (unit-count runtime-status.graf)])
  =/  bride-proof-count=@ud
    (sum-ud-list ~[(lent proof-bundles.graf) (unit-count runtime-status.graf)])
  =/  bride-count=@ud
    (sum-ud-list ~[(unit-count last-seat-write.graf) (unit-count last-axis-write.graf) (unit-count last-residue.graf) (unit-count last-continuation.graf) (lent provenances.graf) bride-proof-count (unit-count bride-nets.graf) (unit-count bride-milky-way.graf)])
  =/  collaboration-crossing-count=@ud
    (crossing-count:mcg attic.graf)
  =/  crossing-count=@ud
    %+  add  collaboration-crossing-count
    (add (unit-count last-sieve-verdict.graf) (unit-count last-continuation.graf))
  =/  projection-count=@ud
    (add (lent projections.graf) (lent search-results.graf))
  =/  bundle-packet-count=@ud
    (sum-ud-list ~[(lent bundles.graf) (lent packets.graf)])
  =/  graph-last-id=(unit @t)
    ?~  last-relation.graf
      ?~  last-seat-write.graf
        ~
      `id.handle.u.last-seat-write.graf
    `id.handle.u.last-relation.graf
  =/  machine-last-id=(unit @t)
    ?~  last-ship-position.graf
      ~
    `id.handle.u.last-ship-position.graf
  =/  runtime-last-id=(unit @t)
    ?~  runtime-status.graf
      ?~  last-proof-bundle.graf
        ?~  last-search-tree.graf
          ?~  last-slice.graf
            ~
          `id.handle.u.last-slice.graf
        `id.handle.u.last-search-tree.graf
      `id.handle.u.last-proof-bundle.graf
    `id.handle.u.runtime-status.graf
  =/  bride-last-id=(unit @t)
    ?~  bride-nets.graf
      ?~  bride-milky-way.graf
        ?~  last-provenance.graf
          ?~  last-proof-bundle.graf
            ?~  last-continuation.graf
              ?~  last-residue.graf
                ?~  last-axis-write.graf
                  ?~  last-seat-write.graf
                    ~
                  `id.handle.u.last-seat-write.graf
                `id.handle.u.last-axis-write.graf
              `id.handle.u.last-residue.graf
            `id.handle.u.last-continuation.graf
          `id.handle.u.last-proof-bundle.graf
        `id.handle.u.last-provenance.graf
      `id.handle.u.bride-milky-way.graf
    `id.handle.u.bride-nets.graf
  =/  crossing-last-id=(unit @t)
    =/  collaboration-last  (crossing-last-id:mcg attic.graf)
    ?^  collaboration-last  collaboration-last
    ?~  last-sieve-verdict.graf
      ?~  last-continuation.graf
        ~
      `id.handle.u.last-continuation.graf
    `id.handle.u.last-sieve-verdict.graf
  =/  projection-last-id=(unit @t)
    ?~  last-projection.graf
      ?~  last-search-result.graf
        ~
      `id.handle.u.last-search-result.graf
    `id.handle.u.last-projection.graf
  =/  bundle-packet-last-id=(unit @t)
    ?~  last-packet.graf
      ?~  (packet-last-id packets.graf)
        (bundle-last-id bundles.graf)
      (packet-last-id packets.graf)
    `id.handle.u.last-packet.graf
  =/  summaries=(list graf-domain-summary:graf-sur)
    :~  [domain=%handle-registry count=(lent handle-registry.graf) last-id=(handle-last-id handle-registry.graf)]
        [domain=%graph-matter count=graph-count last-id=graph-last-id]
        [domain=%machine-topology count=machine-count last-id=machine-last-id]
        [domain=%runtime-state count=runtime-count last-id=runtime-last-id]
        [domain=%bundle-packet-state count=bundle-packet-count last-id=bundle-packet-last-id]
        [domain=%circulation-facts count=(lent circulation.graf) last-id=(fact-last-id circulation.graf)]
        [domain=%bride-memory count=bride-count last-id=bride-last-id]
        [domain=%crossing-lane count=crossing-count last-id=crossing-last-id]
        [domain=%projection-views count=projection-count last-id=projection-last-id]
    ==
  [root-id=root-id.graf domains=summaries]
::
++  anchor-domain
  |=  summary=graf-domain-summary:graf-sur
  ^-  graf-domain-anchor:graf-sur
  [ domain=domain.summary
    axis=(domain-axis-for domain.summary)
    count=count.summary
    last-id=last-id.summary
  ]
::
++  latest-seat-writes
  |=  [seat-writes=(list graf-seat-write:graf-sur) seen=(list @tas)]
  ^-  (list graf-seat-write:graf-sur)
  ?~  seat-writes  ~
  ?:  (seen-seat-id seen seat-id.i.seat-writes)
    $(seat-writes t.seat-writes, seen seen)
  [i.seat-writes $(seat-writes t.seat-writes, seen [seat-id.i.seat-writes seen])]
::
++  make-seat-region
  |=  [seat-write=graf-seat-write:graf-sur axis-writes=(list graf-axis-write:graf-sur)]
  ^-  graf-seat-region:graf-sur
  =/  latest-axis  (latest-axis-write-for-seat axis-writes seat-id.seat-write)
  =/  last-relative-axis=(unit @ud)
    ?~  latest-axis
      ~
    `relative-axis.u.latest-axis
  =/  last-absolute-axis=(unit @ud)
    ?~  latest-axis
      ~
    `absolute-axis.u.latest-axis
  [ handle=[type=%seat-region version=1 id=(crip (trip (scot %tas seat-id.seat-write))) hash=hash.handle.seat-write]
    root-id=root-id.seat-write
    seat-id=seat-id.seat-write
    session-id=session-id.seat-write
    lease-id=lease-id.seat-write
    assigned-ship-id=assigned-ship-id.seat-write
    ship-position=ship-position.seat-write
    region-path=region-path.seat-write
    region-axis=(seat-region-axis-for seat-id.seat-write)
    axis-write-count=(count-axis-writes-for-seat axis-writes seat-id.seat-write)
    last-relative-axis=last-relative-axis
    last-absolute-axis=last-absolute-axis
    writable=%.y
  ]
::
++  collect-seat-regions
  |=  [seat-writes=(list graf-seat-write:graf-sur) axis-writes=(list graf-axis-write:graf-sur)]
  ^-  (list graf-seat-region:graf-sur)
  ?~  seat-writes  ~
  [(make-seat-region i.seat-writes axis-writes) $(seat-writes t.seat-writes, axis-writes axis-writes)]
::
++  build-root-field
  |=  graf=graf-app-state
  ^-  graf-root-field:graf-sur
  =/  domain-summary  (build-root-domains graf)
  =/  latest  (latest-seat-writes seat-writes.graf ~)
  [ root-id=root-id.graf
    root-axis=root-axis
    domain-trunk-axis=domain-trunk-axis
    seat-trunk-axis=seat-trunk-axis
    domains=(turn domains.domain-summary anchor-domain)
    seat-regions=(collect-seat-regions latest axis-writes.graf)
    contribution-count=(add (lent seat-writes.graf) (lent axis-writes.graf))
    axis-write-count=(lent axis-writes.graf)
    collision-codes=(seat-write-collision-codes latest)
  ]
::
++  runtime-status-for
  |=  act=graf-constitutional-action:graf-sur
  ^-  graf-runtime-status
  =/  meta  (action-meta act)
  [ handle=[type=%runtime version=1 id=batch-id.meta hash=batch-hash.meta]
    status=(action-name act)
    detail=batch-id.meta
  ]
::
++  active-bride-net-count
  |=  nets=(list graf-bride-net:graf-sur)
  ^-  @ud
  ?~  nets  0
  ?:  active.i.nets
    (add 1 $(nets t.nets))
  $(nets t.nets)
::
++  bride-net-canon-count
  |=  nets=(list graf-bride-net:graf-sur)
  ^-  @ud
  ?~  nets  0
  ?:  active.i.nets
    (add (lent canon-snippets.i.nets) $(nets t.nets))
  $(nets t.nets)
::
++  bride-net-crossing-count
  |=  nets=(list graf-bride-net:graf-sur)
  ^-  @ud
  ?~  nets  0
  ?:  active.i.nets
    (add (lent crossing-kinds.i.nets) $(nets t.nets))
  $(nets t.nets)
::
++  retained-milky-count
  |=  items=(list graf-milky-way-item:graf-sur)
  ^-  @ud
  ?~  items  0
  ?:  retained.i.items
    (add 1 $(items t.items))
  $(items t.items)
::
++  native-readiness
  |=  graf=graf-app-state
  ^-  graf-native-readiness:graf-sur
  =/  nets-ready=?
    ?~  bride-nets.graf
      %.n
    ?&  (nonzero-ud (active-bride-net-count nets.u.bride-nets.graf))
        (nonzero-ud (bride-net-canon-count nets.u.bride-nets.graf))
        (nonzero-ud (bride-net-crossing-count nets.u.bride-nets.graf))
    ==
  =/  milky-ready=?
    ?~  bride-milky-way.graf
      %.n
    (nonzero-ud (retained-milky-count items.u.bride-milky-way.graf))
  =/  blockers=(list @t)  ~
  =.  blockers
    ?:  nets-ready
      blockers
    ['nets state missing or incomplete' blockers]
  =.  blockers
    ?:  milky-ready
      blockers
    ['milky way canon missing or incomplete' blockers]
  =/  ready=?
    ?&  nets-ready
        milky-ready
    ==
  =/  updated=@da
    ?~  bride-nets.graf
      ?~  bride-milky-way.graf
        ~1970.1.1
      updated.u.bride-milky-way.graf
    ?~  bride-milky-way.graf
      updated.u.bride-nets.graf
    ?:  (gth updated.u.bride-nets.graf updated.u.bride-milky-way.graf)
      updated.u.bride-nets.graf
    updated.u.bride-milky-way.graf
  [ handle=[type=%native-readiness version=1 id=root-id.graf hash=root-id.graf]
    nets-ready=nets-ready
    milky-way-ready=milky-ready
    ready=ready
    blockers=(flop blockers)
    updated=updated
  ]
::
++  make-ship-position
  |=  [meta=dispatch-meta:graf-sur seat-write=graf-seat-write:graf-sur]
  ^-  (unit graf-ship-position:graf-sur)
  ?~  ship-position.seat-write  ~
  ?~  region-path.seat-write  ~
  =/  position=graf-ship-position:graf-sur
    [ handle=[type=%ship-position version=1 id=(crip (trip (scot %tas seat-id.seat-write))) hash=batch-hash.meta]
      root-id=root-id.seat-write
      seat-id=seat-id.seat-write
      assigned-ship-id=assigned-ship-id.seat-write
      ship-position=u.ship-position.seat-write
      region-path=u.region-path.seat-write
      writable=%.y
    ]
  [~ position]
::
++  mint-hash
  |=  record=*
  ^-  @t
  (crip (trip (scot %ux (shax (jam record)))))
::
++  add-mint
  |=  [graf=graf-app-state handle=graf-handle:graf-sur record=*]
  ^-  graf-app-state
  =/  entry=graf-mint  [handle (mint-hash record)]
  =/  full  (weld ~[entry] mints.graf)
  =.  graf  (overflow graf %mints (slag max-mints full))
  graf(mints (scag max-mints full))
::
++  find-mint
  |=  [mints=(list graf-mint) handle-id=@t]
  ^-  (unit graf-mint)
  ?~  mints  ~
  ?:  =(id.handle.i.mints handle-id)
    `i.mints
  $(mints t.mints)
::
::  the primary stored record for an action, if the action stores one:
::  this is what gets a graf-minted content hash.  handle-less actions
::  (graph seeds, circulation facts, governor, session bindings) mint
::  nothing here.
::
++  action-record
  |=  act=graf-constitutional-action:graf-sur
  ^-  (unit [handle=graf-handle:graf-sur record=*])
  ?+    -.act  ~
      %record-packet-state  `[handle.proof.act proof.act]
      %record-seat-write  `[handle.proof.act proof.act]
      %record-axis-write  `[handle.proof.act proof.act]
      %record-ship-position  `[handle.proof.act proof.act]
      %record-slice  `[handle.proof.act proof.act]
      %record-traversal  `[handle.proof.act proof.act]
      %record-write-intent  `[handle.proof.act proof.act]
      %record-residue  `[handle.proof.act proof.act]
      %record-sieve-verdict  `[handle.proof.act proof.act]
      %record-continuation  `[handle.proof.act proof.act]
      %record-relation  `[handle.proof.act proof.act]
      %record-projection  `[handle.proof.act proof.act]
      %record-search-tree  `[handle.proof.act proof.act]
      %record-search-result  `[handle.proof.act proof.act]
      %record-provenance  `[handle.proof.act proof.act]
      %record-proof-bundle  `[handle.proof.act proof.act]
      %record-controlled-agency-proof-bundle  `[handle.proof.act proof.act]
      %submit-bachelor-output  `[handle.proof.act proof.act]
      %reduce-outputs  `[handle.proof.act proof.act]
      %record-reduction-verdict  `[handle.proof.act proof.act]
      %record-convergence  `[handle.proof.act proof.act]
      %record-event-log-entry  `[handle.proof.act proof.act]
      %record-task  `[handle.proof.act proof.act]
      %record-task-result  `[handle.proof.act proof.act]
      %record-bride-nets  `[handle.proof.act proof.act]
      %record-bride-milky-way  `[handle.proof.act proof.act]
  ==
::
++  core-projection-fact
  |=  [act=graf-constitutional-action:graf-sur source-ship=@p]
  ^-  graf-core-projection-fact:graf-sur
  =/  meta  (action-meta act)
  =/  primary  (action-record act)
  =/  legacy-handle=(unit graf-handle:graf-sur)
    ?~(primary ~ `handle.u.primary)
  =/  projection-source
    :*  1
        (action-name act)
        legacy-handle
        idempotency-key.meta
        source-ship
        source-slug.meta
        dispatched-at.meta
        act
    ==
  =/  core-fact-id=@ux  (shax (jam projection-source))
  :*  %legacy-graf-projection
      1
      (action-name act)
      legacy-handle
      idempotency-key.meta
      source-ship
      source-slug.meta
      dispatched-at.meta
      core-fact-id
      act
  ==
::
++  parse-action
  |=  [mark=@tas payload=vase]
  ^-  (unit graf-constitutional-action:graf-sur)
  ?+    mark  ~
      %graf-action
    ((soft graf-constitutional-action:graf-sur) q.payload)
      %noun
    ((soft graf-constitutional-action:graf-sur) q.payload)
  ==
::
++  failure-cap  `@ud`128
++  primary-ring-cap  `@ud`128
::  Newest-first, and what falls off the end goes to the attic exactly as
::  every other ring family's overflow does.  failures-stashed says how many
::  live there rather than in the working set, so a reader knows where the
::  rest are -- it is a cursor, not a tally of destroyed records.
++  note-failure
  |=  [graf=graf-app-state entry=graf-failure]
  ^-  graf-app-state
  =/  full=(list graf-failure)  [entry failures.graf]
  =/  shed=(list graf-failure)  (slag failure-cap full)
  =.  graf  (overflow graf %failures shed)
  %=  graf
    failures          (scag failure-cap full)
    failures-stashed  (add failures-stashed.graf (lent shed))
  ==
::
++  finalize-graf
  |=  [graf=graf-app-state act=graf-constitutional-action:graf-sur accepted=? duplicate=?]
  ^-  graf-app-state
  ::  mint a ship-computed content hash for every record graf stores,
  ::  so /x/verify-proof answers from graf's own evidence rather than
  ::  the writer's asserted hash.  rejects and duplicates mint nothing.
  =?  graf  &(accepted !duplicate)
    =/  primary  (action-record act)
    ?~  primary  graf
    (add-mint graf u.primary)
  ::  AUTOMATIC CAPTURE.  Every action path ends here, so a rejection is
  ::  recorded without any caller cooperating.  A duplicate is NOT a failure
  ::  -- that is idempotency working as designed -- so only !accepted is noted.
  =?  graf  !accepted
    =/  meta  (action-meta act)
    %+  note-failure  graf
    :*  dispatched-at.meta
        %graf
        -.act
        %rejected
        ''
        batch-id.meta
        idempotency-key.meta
    ==
  %=  graf
    last-dispatch  `(receipt act accepted duplicate)
    runtime-status  `(runtime-status-for act)
  ==
::
++  find-impulse
  |=  [impulses=(list impulse:graf-sur) impulse-id=@tas]
  ^-  (unit impulse:graf-sur)
  ?~  impulses  ~
  ?:  =(impulse-id.i.impulses impulse-id)
    `i.impulses
  $(impulses t.impulses)
::
++  find-bundle
  |=  [bundles=(list bundle-ref:graf-sur) bundle-id=@tas]
  ^-  (unit bundle-ref:graf-sur)
  ?~  bundles  ~
  ?:  =(bundle-id.i.bundles bundle-id)
    `i.bundles
  $(bundles t.bundles)
::
++  find-fact
  |=  [facts=(list circulation-fact:graf-sur) fact-id=@tas]
  ^-  (unit circulation-fact:graf-sur)
  ?~  facts  ~
  ?:  =(fact-id.i.facts fact-id)
    `i.facts
  $(facts t.facts)
::
++  find-seat-write
  |=  [seat-writes=(list graf-seat-write:graf-sur) seat-id=@tas]
  ^-  (unit graf-seat-write:graf-sur)
  ?~  seat-writes  ~
  ?:  =(seat-id.i.seat-writes seat-id)
    `i.seat-writes
  $(seat-writes t.seat-writes)
::
++  find-axis-write
  |=  [axis-writes=(list graf-axis-write:graf-sur) seat-id=@tas relative-axis=@ud]
  ^-  (unit graf-axis-write:graf-sur)
  ?~  axis-writes  ~
  ?:  ?&  =(seat-id.i.axis-writes seat-id)
          =(relative-axis.i.axis-writes relative-axis)
      ==
    `i.axis-writes
  $(axis-writes t.axis-writes)
::
++  find-axis-write-by-absolute
  |=  [axis-writes=(list graf-axis-write:graf-sur) absolute-axis=@ud]
  ^-  (unit graf-axis-write:graf-sur)
  ?~  axis-writes  ~
  ?:  =(absolute-axis.i.axis-writes absolute-axis)
    `i.axis-writes
  $(axis-writes t.axis-writes)
::
++  find-ship-position
  |=  [positions=(list graf-ship-position:graf-sur) seat-id=@tas]
  ^-  (unit graf-ship-position:graf-sur)
  ?~  positions  ~
  ?:  =(seat-id.i.positions seat-id)
    `i.positions
  $(positions t.positions)
::
++  find-seat-region
  |=  [seat-writes=(list graf-seat-write:graf-sur) axis-writes=(list graf-axis-write:graf-sur) seat-id=@tas]
  ^-  (unit graf-seat-region:graf-sur)
  =/  found  (find-seat-write seat-writes seat-id)
  ?~  found  ~
  [~ (make-seat-region u.found axis-writes)]
::
++  sparse-tree-set
  |=  [tree=* axis=@ud value=*]
  ^-  *
  ?:  =(axis 1)
    value
  =/  head
    ?^  tree
      -.tree
    0
  =/  tail
    ?^  tree
      +.tree
    0
  ?:  =(0 (mod axis 2))
    [(sparse-tree-set head (div axis 2) value) tail]
  [head (sparse-tree-set tail (div axis 2) value)]
::
++  build-seat-tree
  |=  axis-writes=(list graf-axis-write:graf-sur)
  ^-  *
  ?~  axis-writes  0
  (sparse-tree-set $(axis-writes t.axis-writes) relative-axis.i.axis-writes value.i.axis-writes)
::
++  find-seat-tree
  |=  [graf=graf-app-state seat-id=@tas]
  ^-  (unit *)
  =/  found  (find-seat-write seat-writes.graf seat-id)
  ?~  found  ~
  [~ (build-seat-tree (filter-axis-writes axis-writes.graf seat-id))]
::
++  make-axis-page
  |=  axis-write=graf-axis-write:graf-sur
  ^-  graf-axis-page:graf-sur
  =/  page-key=@t  (ud-text absolute-axis.axis-write)
  [ handle=[type=%axis-page version=1 id=page-key hash=hash.handle.axis-write]
    source=handle.axis-write
    root-id=root-id.axis-write
    seat-id=seat-id.axis-write
    region-axis=region-axis.axis-write
    relative-axis=relative-axis.axis-write
    absolute-axis=absolute-axis.axis-write
    page-key=page-key
    title=page-key
    value=value.axis-write
    value-kind=value-kind.axis-write
    summary=summary.axis-write
  ]
::
++  make-axis-trail
  |=  axis-write=graf-axis-write:graf-sur
  ^-  graf-axis-trail:graf-sur
  =/  page-key=@t  (ud-text absolute-axis.axis-write)
  [ handle=[type=%axis-trail version=1 id=page-key hash=hash.handle.axis-write]
    source=handle.axis-write
    root-id=root-id.axis-write
    seat-id=seat-id.axis-write
    region-axis=region-axis.axis-write
    relative-axis=relative-axis.axis-write
    absolute-axis=absolute-axis.axis-write
    ancestor-axes=(axis-ancestor-axes absolute-axis.axis-write)
    slot-path=(axis-slot-path absolute-axis.axis-write)
    relative-slot-path=(axis-slot-path relative-axis.axis-write)
    page-key=page-key
    summary=summary.axis-write
  ]
::
++  find-handle
  |=  [handles=(list graf-handle:graf-sur) handle-id=@t]
  ^-  (unit graf-handle:graf-sur)
  ?~  handles  ~
  ?:  =(id.i.handles handle-id)
    `i.handles
  $(handles t.handles)
::
++  find-relation
  |=  [relations=(list graf-relation:graf-sur) handle-id=@t]
  ^-  (unit graf-relation:graf-sur)
  ?~  relations  ~
  ?:  =(id.handle.i.relations handle-id)
    `i.relations
  $(relations t.relations)
::
++  find-governor
  |=  [governors=(list graf-governor-record:graf-sur) governor-id=@t]
  ^-  (unit graf-governor-record:graf-sur)
  ?~  governors  ~
  ?:  =(governor-id.i.governors governor-id)
    `i.governors
  $(governors t.governors)
::
++  find-slice
  |=  [slices=(list graf-slice:graf-sur) handle-id=@t]
  ^-  (unit graf-slice:graf-sur)
  ?~  slices  ~
  ?:  =(id.handle.i.slices handle-id)
    `i.slices
  $(slices t.slices)
::
++  find-traversal
  |=  [traversals=(list graf-traversal-decision:graf-sur) handle-id=@t]
  ^-  (unit graf-traversal-decision:graf-sur)
  ?~  traversals  ~
  ?:  =(id.handle.i.traversals handle-id)
    `i.traversals
  $(traversals t.traversals)
::
++  find-write-intent
  |=  [intents=(list graf-write-intent:graf-sur) handle-id=@t]
  ^-  (unit graf-write-intent:graf-sur)
  ?~  intents  ~
  ?:  =(id.handle.i.intents handle-id)
    `i.intents
  $(intents t.intents)
::
++  find-residue
  |=  [residues=(list graf-residue:graf-sur) handle-id=@t]
  ^-  (unit graf-residue:graf-sur)
  ?~  residues  ~
  ?:  =(id.handle.i.residues handle-id)
    `i.residues
  $(residues t.residues)
::
++  find-sieve-verdict
  |=  [verdicts=(list graf-sieve-verdict:graf-sur) handle-id=@t]
  ^-  (unit graf-sieve-verdict:graf-sur)
  ?~  verdicts  ~
  ?:  =(id.handle.i.verdicts handle-id)
    `i.verdicts
  $(verdicts t.verdicts)
::
++  find-continuation
  |=  [continuations=(list graf-continuation:graf-sur) handle-id=@t]
  ^-  (unit graf-continuation:graf-sur)
  ?~  continuations  ~
  ?:  =(id.handle.i.continuations handle-id)
    `i.continuations
  $(continuations t.continuations)
::
++  find-projection
  |=  [projections=(list graf-projection:graf-sur) handle-id=@t]
  ^-  (unit graf-projection:graf-sur)
  ?~  projections  ~
  ?:  =(id.handle.i.projections handle-id)
    `i.projections
  $(projections t.projections)
::
++  find-search-tree
  |=  [trees=(list graf-search-tree:graf-sur) handle-id=@t]
  ^-  (unit graf-search-tree:graf-sur)
  ?~  trees  ~
  ?:  =(id.handle.i.trees handle-id)
    `i.trees
  $(trees t.trees)
::
++  find-search-result
  |=  [results=(list graf-search-result:graf-sur) handle-id=@t]
  ^-  (unit graf-search-result:graf-sur)
  ?~  results  ~
  ?:  =(id.handle.i.results handle-id)
    `i.results
  $(results t.results)
::
++  handle-query-match
  |=  [handle=graf-handle:graf-sur query=@t]
  ^-  ?
  ?|  =(id.handle query)
      =(hash.handle query)
      =((tas-text type.handle) query)
  ==
::
++  concept-query-match
  |=  [node=concept-node:graf-sur query=@t]
  ^-  ?
  ?|  =((tas-text id.node) query)
      =((tas-text kind.node) query)
      =(name.node query)
  ==
::
++  edge-query-match
  |=  [edge=relation-edge:graf-sur query=@t]
  ^-  ?
  ?|  =((tas-text from.edge) query)
      =((tas-text to.edge) query)
      =((tas-text label.edge) query)
  ==
::
++  domain-query-match
  |=  [domain=graf-domain-summary:graf-sur query=@t]
  ^-  ?
  ?|  =((tas-text domain.domain) query)
      ?~(last-id.domain %.n =(u.last-id.domain query))
  ==
::
++  axis-write-query-match
  |=  [axis-write=graf-axis-write:graf-sur query=@t]
  ^-  ?
  ?|  (handle-query-match handle.axis-write query)
      =((ud-text absolute-axis.axis-write) query)
      =((ud-text relative-axis.axis-write) query)
      =(value.axis-write query)
      =(summary.axis-write query)
      =(session-id.axis-write query)
      =(lease-id.axis-write query)
      =(assigned-ship-id.axis-write query)
  ==
::
++  relation-query-match
  |=  [relation=graf-relation:graf-sur query=@t]
  ^-  ?
  ?|  (handle-query-match handle.relation query)
      (handle-query-match source.relation query)
      (handle-query-match target.relation query)
      =((tas-text relation-kind.relation) query)
      =((tas-text label.relation) query)
      =(summary.relation query)
  ==
::
++  controlled-agency-relation
  |=  relation=graf-relation:graf-sur
  ^-  ?
  ?|  =(%intent-run relation-kind.relation)
      =(%run-policy relation-kind.relation)
      =(%run-builder-role relation-kind.relation)
      =(%run-reviewer-role relation-kind.relation)
      =(%role-tools relation-kind.relation)
      =(%role-allowed-tool relation-kind.relation)
      =(%role-forbidden-tool relation-kind.relation)
      =(%run-builder-moon relation-kind.relation)
      =(%run-reviewer-moon relation-kind.relation)
      =(%builder-codex-session relation-kind.relation)
      =(%reviewer-codex-session relation-kind.relation)
      =(%moon-codex-session relation-kind.relation)
      =(%builder-artifact relation-kind.relation)
      =(%artifact-hash-evidence relation-kind.relation)
      =(%artifact-run-evidence relation-kind.relation)
      =(%reviewer-inspection relation-kind.relation)
      =(%reviewer-review relation-kind.relation)
      =(%reviewer-denial relation-kind.relation)
      =(%run-cantrip-verdict relation-kind.relation)
      =(%controlled-agency-proof-bundle relation-kind.relation)
  ==
::
++  controlled-agency-relation-compatible
  |=  relation=graf-relation:graf-sur
  ^-  ?
  ?.  (controlled-agency-relation relation)
    %.y
  ?+    relation-kind.relation  %.n
      %intent-run  =(%intends-run label.relation)
      %run-policy  =(%uses-policy label.relation)
      %run-builder-role  =(%assigns-builder-role label.relation)
      %run-reviewer-role  =(%assigns-reviewer-role label.relation)
      %role-tools  =(%permits-tools label.relation)
      %role-allowed-tool  =(%permits-tools label.relation)
      %role-forbidden-tool  =(%forbids-tool label.relation)
      %run-builder-moon  =(%built-by-moon label.relation)
      %run-reviewer-moon  =(%reviewed-by-moon label.relation)
      %builder-codex-session  =(%backs-builder-codex-session label.relation)
      %reviewer-codex-session  =(%backs-reviewer-codex-session label.relation)
      %moon-codex-session  =(%backs-codex-session label.relation)
      %builder-artifact  =(%produces-artifact label.relation)
      %artifact-hash-evidence  =(%has-hash-evidence label.relation)
      %artifact-run-evidence  =(%has-run-evidence label.relation)
      %reviewer-inspection  =(%performs-inspection label.relation)
      %reviewer-review  =(%records-review label.relation)
      %reviewer-denial  =(%records-denial label.relation)
      %run-cantrip-verdict  =(%has-cantrip-verdict label.relation)
      %controlled-agency-proof-bundle  =(%reconstructs-proof-bundle label.relation)
  ==
::
++  relation-connects
  |=  [relation=graf-relation:graf-sur source-id=@t target-id=@t]
  ^-  ?
  ?&  =(id.source.relation source-id)
      =(id.target.relation target-id)
  ==
::
++  search-concepts
  |=  [nodes=(list concept-node:graf-sur) query=@t]
  ^-  (list json)
  ?~  nodes  ~
  ?:  (concept-query-match i.nodes query)
    [(concept-node-json i.nodes) $(nodes t.nodes)]
  $(nodes t.nodes)
::
++  search-edges
  |=  [edges=(list relation-edge:graf-sur) query=@t]
  ^-  (list json)
  ?~  edges  ~
  ?:  (edge-query-match i.edges query)
    [(relation-edge-json i.edges) $(edges t.edges)]
  $(edges t.edges)
::
++  search-domains
  |=  [domains=(list graf-domain-summary:graf-sur) query=@t]
  ^-  (list json)
  ?~  domains  ~
  ?:  (domain-query-match i.domains query)
    [(domain-summary-json i.domains) $(domains t.domains)]
  $(domains t.domains)
::
++  search-axes
  |=  [axis-writes=(list graf-axis-write:graf-sur) query=@t]
  ^-  (list json)
  ?~  axis-writes  ~
  ?:  (axis-write-query-match i.axis-writes query)
    [(axis-write-summary-json `i.axis-writes) $(axis-writes t.axis-writes)]
  $(axis-writes t.axis-writes)
::
++  search-relations
  |=  [relations=(list graf-relation:graf-sur) query=@t]
  ^-  (list json)
  ?~  relations  ~
  ?:  (relation-query-match i.relations query)
    [(relation-json i.relations) $(relations t.relations)]
  $(relations t.relations)
::
::  The constitutional search action is externally supplied, so both its
::  automaton and its evidence pass need hard limits.  `slag` checks list
::  overflow after at most the configured cap; term bytes short-circuit as
::  soon as the aggregate limit is crossed.
::
++  search-term-bytes-safe
  |=  [terms=(list @t) remaining=@ud]
  ^-  ?
  ?~  terms  %.y
  =/  size=@ud  (met 3 i.terms)
  ?:  (gth size remaining)  %.n
  $(terms t.terms, remaining (sub remaining size))
::
++  search-input-safe
  |=  tree=graf-search-tree:graf-sur
  ^-  ?
  =/  terms=(list @t)  (weld match-terms.tree match-tags.tree)
  ?&  ?|(=(0 budget.tree) (lte budget.tree max-search-scan))
      =(~ (slag max-search-terms terms))
      =(~ (slag max-search-domains match-domains.tree))
      (search-term-bytes-safe terms max-search-term-bytes)
  ==
::
++  search-attic-families
  |=  domains=(list @tas)
  ^-  (list attic-family:graf-attic)
  =/  want
    |=  family=@tas
    ?|  =(~ domains)
        (lien domains |=(domain=@tas =(domain family)))
    ==
  %+  skim
    `(list attic-family:graf-attic)`~[%relations %provenances %proof-bundles %packets %event-log %tasks %seat-writes %axis-writes]
  want
::
::  Erased attic nouns are never trusted.  A family mismatch or malformed
::  record returns null; the action gate treats any null as archive corruption
::  and refuses the search instead of returning partial evidence as complete.
::
++  attic-search-candidate
  |=  item=attic-record:graf-attic
  ^-  (unit search-candidate)
  ?+    family.item  ~
      %relations
    =/  parsed=(unit graf-relation:graf-sur)
      ((soft graf-relation:graf-sur) value.item)
    ?~(parsed ~ `[handle.u.parsed `*`u.parsed])
      %provenances
    =/  parsed=(unit graf-provenance:graf-sur)
      ((soft graf-provenance:graf-sur) value.item)
    ?~(parsed ~ `[handle.u.parsed `*`u.parsed])
      %proof-bundles
    =/  parsed=(unit graf-proof-bundle:graf-sur)
      ((soft graf-proof-bundle:graf-sur) value.item)
    ?~(parsed ~ `[handle.u.parsed `*`u.parsed])
      %packets
    =/  parsed=(unit graf-packet:graf-sur)
      ((soft graf-packet:graf-sur) value.item)
    ?~(parsed ~ `[handle.u.parsed `*`u.parsed])
      %event-log
    =/  parsed=(unit graf-event-log-entry:graf-sur)
      ((soft graf-event-log-entry:graf-sur) value.item)
    ?~(parsed ~ `[handle.u.parsed `*`u.parsed])
      %tasks
    =/  parsed=(unit graf-task:graf-sur)
      ((soft graf-task:graf-sur) value.item)
    ?~(parsed ~ `[handle.u.parsed `*`u.parsed])
      %seat-writes
    =/  parsed=(unit graf-seat-write:graf-sur)
      ((soft graf-seat-write:graf-sur) value.item)
    ?~(parsed ~ `[handle.u.parsed `*`u.parsed])
      %axis-writes
    =/  parsed=(unit graf-axis-write:graf-sur)
      ((soft graf-axis-write:graf-sur) value.item)
    ?~(parsed ~ `[handle.u.parsed `*`u.parsed])
  ==
::
++  attic-search-candidates
  |=  records=(list attic-record:graf-attic)
  ^-  [safe=? candidates=(list search-candidate)]
  ?~  records  [%.y ~]
  =/  candidate  (attic-search-candidate i.records)
  ?~  candidate  [%.n ~]
  =/  rest  $(records t.records)
  [safe.rest [u.candidate candidates.rest]]
::
++  relation-paths
  |=  [relations=(list graf-relation:graf-sur) source-id=@t target-id=@t]
  ^-  (list graf-relation:graf-sur)
  ?~  relations  ~
  ?:  (relation-connects i.relations source-id target-id)
    [i.relations $(relations t.relations)]
  $(relations t.relations)
::
++  controlled-agency-relations
  |=  relations=(list graf-relation:graf-sur)
  ^-  (list graf-relation:graf-sur)
  ?~  relations  ~
  ?:  (controlled-agency-relation i.relations)
    [i.relations $(relations t.relations)]
  $(relations t.relations)
::
++  controlled-agency-relations-by-query
  |=  [relations=(list graf-relation:graf-sur) query=@t]
  ^-  (list graf-relation:graf-sur)
  ?~  relations  ~
  ?:  ?&((controlled-agency-relation i.relations) (relation-query-match i.relations query))
    [i.relations $(relations t.relations)]
  $(relations t.relations)
::
++  controlled-agency-has-kind
  |=  [relations=(list graf-relation:graf-sur) kind=@tas]
  ^-  ?
  ?~  relations  %.n
  ?:  =(relation-kind.i.relations kind)
    %.y
  $(relations t.relations)
::
++  controlled-agency-missing-kinds
  |=  [relations=(list graf-relation:graf-sur) kinds=(list @tas)]
  ^-  (list @tas)
  ?~  kinds  ~
  ?:  (controlled-agency-has-kind relations i.kinds)
    $(kinds t.kinds)
  [i.kinds $(kinds t.kinds)]
::
++  find-packet
  |=  [packets=(list graf-packet:graf-sur) handle-id=@t]
  ^-  (unit graf-packet:graf-sur)
  ?~  packets  ~
  ?:  =(id.handle.i.packets handle-id)
    `i.packets
  $(packets t.packets)
::
++  find-provenance
  |=  [provenances=(list graf-provenance:graf-sur) handle-id=@t]
  ^-  (unit graf-provenance:graf-sur)
  ?~  provenances  ~
  ?:  =(id.handle.i.provenances handle-id)
    `i.provenances
  $(provenances t.provenances)
::
++  find-proof-bundle
  |=  [bundles=(list graf-proof-bundle:graf-sur) handle-id=@t]
  ^-  (unit graf-proof-bundle:graf-sur)
  ?~  bundles  ~
  ?:  =(id.handle.i.bundles handle-id)
    `i.bundles
  $(bundles t.bundles)
::
::
::
::
++  find-bachelor-output
  |=  [outputs=(list graf-bachelor-output:graf-sur) output-id=@t]
  ^-  (unit graf-bachelor-output:graf-sur)
  ?~  outputs  ~
  ?:  =(output-id.i.outputs output-id)  `i.outputs
  $(outputs t.outputs)
::
++  find-reduction-verdict
  |=  [verdicts=(list graf-reduction-verdict:graf-sur) verdict-id=@t]
  ^-  (unit graf-reduction-verdict:graf-sur)
  ?~  verdicts  ~
  ?:  =(verdict-id.i.verdicts verdict-id)  `i.verdicts
  $(verdicts t.verdicts)
::
++  find-convergence-record
  |=  [records=(list graf-convergence-record:graf-sur) convergence-id=@t]
  ^-  (unit graf-convergence-record:graf-sur)
  ?~  records  ~
  ?:  =(convergence-id.i.records convergence-id)  `i.records
  $(records t.records)
++  find-event-log-entry
  |=  [entries=(list graf-event-log-entry:graf-sur) event-id=@t]
  ^-  (unit graf-event-log-entry:graf-sur)
  ?~  entries  ~
  ?:  =(event-id.i.entries event-id)
    `i.entries
  $(entries t.entries)
++  find-task
  |=  [tasks=(list graf-task:graf-sur) task-id=@t]
  ^-  (unit graf-task:graf-sur)
  ?~  tasks  ~
  ?:  =(task-id.i.tasks task-id)
    `i.tasks
  $(tasks t.tasks)
::
++  find-task-result
  |=  [results=(list graf-task-result:graf-sur) task-id=@t]
  ^-  (unit graf-task-result:graf-sur)
  ?~  results  ~
  ?:  =(task-id.i.results task-id)
    `i.results
  $(results t.results)
++  build-proof-latest
  |=  graf=graf-app-state
  ^-  graf-proof-latest
  [ version=version.graf
    last-dispatch=last-dispatch.graf
    runtime-status=runtime-status.graf
    last-governor=last-governor.graf
    last-packet=last-packet.graf
    last-seat-write=last-seat-write.graf
    last-axis-write=last-axis-write.graf
    last-ship-position=last-ship-position.graf
    last-slice=last-slice.graf
    last-traversal=last-traversal.graf
    last-write-intent=last-write-intent.graf
    last-residue=last-residue.graf
    last-sieve-verdict=last-sieve-verdict.graf
    last-continuation=last-continuation.graf
    last-relation=last-relation.graf
    last-projection=last-projection.graf
    last-search-tree=last-search-tree.graf
    last-search-result=last-search-result.graf
    last-provenance=last-provenance.graf
    last-proof-bundle=last-proof-bundle.graf
    last-bride-nets=bride-nets.graf
    last-bride-milky-way=bride-milky-way.graf
  ]
::
++  dispatch-viki-ref
  |=  dispatch=dispatch-receipt:graf-sur
  ^-  graf-viki-ref:graf-sur
  [ ref-id=batch-id.dispatch
    kind=%dispatch
    summary=(tas-text action.dispatch)
    path=`(crip "/x/dispatch/latest")
  ]
::
++  proof-viki-ref
  |=  bundle=graf-proof-bundle:graf-sur
  ^-  graf-viki-ref:graf-sur
  [ ref-id=id.handle.bundle
    kind=%proof-bundle
    summary=result-summary.bundle
    path=`(crip "/x/proof/latest")
  ]
::
::  a circulation fact (e.g. a sentinel/fleet guardian-learned fact) as a viki
::  memory-ref, so bounded recent circulation surfaces to the runner AND to the
::  %fleet publish path (fleet's local-facts filters these summaries). The fact
::  cord rides in `summary`; `kind` carries its stage (%verified | %learned | ..).
++  circulation-viki-ref
  |=  fact=circulation-fact:graf-sur
  ^-  graf-viki-ref:graf-sur
  [ ref-id=fact-id.fact
    kind=stage.fact
    summary=summary.fact
    path=`'/x/circulation/latest'
  ]
::
++  clip-viki-text
  |=  [text=@t maximum=@ud]
  ^-  @t
  ?:  (gth (met 3 text) maximum)
    (end [3 maximum] text)
  text
::
++  provenance-viki-ref
  |=  provenance=graf-provenance:graf-sur
  ^-  graf-viki-ref:graf-sur
  [ ref-id=id.handle.provenance
    kind=provenance-kind.provenance
    summary=(clip-viki-text body.provenance 384)
    path=`(cat 3 '/x/provenance/' id.handle.provenance)
  ]
::
::  Provenance is newest-first.  Expose at most four completed chat turns from
::  the requested session; other provenance families never enter live prompt
::  memory through this projection.
++  recent-session-viki-refs
  |=  $:  provenances=(list graf-provenance:graf-sur)
          session-id=@t
          remaining=@ud
      ==
  ^-  (list graf-viki-ref:graf-sur)
  ?:  =(0 remaining)  ~
  ?~  provenances  ~
  ?:  ?&  =(%model-chat provenance-kind.i.provenances)
          =(session-id session-id.i.provenances)
      ==
    :_  $(provenances t.provenances, remaining (dec remaining))
    (provenance-viki-ref i.provenances)
  $(provenances t.provenances)
::
++  relation-handle-id
  |=  relation=graf-relation:graf-sur
  ^-  @t
  id.handle.relation
::
++  graf-viki-context-for
  |=  [graf=graf-app-state session-id=@t]
  ^-  graf-viki-context:graf-sur
  =/  session-refs=(list graf-viki-ref:graf-sur)
    (recent-session-viki-refs provenances.graf session-id 4)
  [ version='graf-viki-context-v2'
    memory-refs=(weld session-refs (turn (scag 4 circulation.graf) circulation-viki-ref))
    proof-refs=?~(last-proof-bundle.graf ~ ~[(proof-viki-ref u.last-proof-bundle.graf)])
    dispatch-refs=?~(last-dispatch.graf ~ ~[(dispatch-viki-ref u.last-dispatch.graf)])
    relation-handles=(turn (scag 16 relations.graf) relation-handle-id)
    residue=?~(last-residue.graf ~ ~[residue.u.last-residue.graf])
    context-summary='Graf context binds memory/proof/dispatch/relation references for Viki before model generation.'
  ]
::
++  graf-watch-paths
  ^-  (list @tas)
  :~  %graf-circulation
      %graf-bundles
      %graf-packets
      %graf-machine-topology
      %graf-root
      %graf-seat-writes
      %graf-axis-writes
      %graf-positions
      %graf-governor
      %graf-slice
      %graf-traversal
      %graf-write-intent
      %graf-residue
      %graf-sieve-verdict
      %graf-continuation
      %graf-proofs
      %graf-relations
      %graf-projections
      %graf-search
      %graf-provenance
      %graf-runtime
      %graf-bride-nets
      %graf-bride-milky-way
      %graf-bride-native
  ==
::
++  build-watch-manifest
  ^-  graf-watch-manifest
  [version=1 watch-paths=graf-watch-paths]
::
++  tas-text
  |=  sym=@tas
  ^-  @t
  (crip (trip (scot %tas sym)))
::
++  ud-text
  |=  num=@ud
  ^-  @t
  (crip (trip (scot %ud num)))
::
++  ud-list-json
  |=  values=(list @ud)
  ^-  json
  [%a (turn values |=(v=@ud (numb:enjs:format v)))]
::
++  tas-list-json
  |=  values=(list @tas)
  ^-  json
  [%a (turn values |=(v=@tas s+(tas-text v)))]
::
++  text-list-json
  |=  values=(list @t)
  ^-  json
  [%a (turn values |=(v=@t s+v))]
::
++  present-json
  |=  present=?
  ^-  json
  %-  pairs:enjs:format
  :~  ['present' [%b present]]
  ==
::
++  ok-error-json
  |=  [ok=? error=(unit @t)]
  ^-  json
  %-  pairs:enjs:format
  :~  ['ok' [%b ok]]
      :-  'error'
      ?~  error  ~
      s+u.error
  ==
::
++  handle-exists-json
  |=  [graf=graf-app-state handle-id=@t]
  ^-  json
  =/  found  (find-handle handle-registry.graf handle-id)
  %-  pairs:enjs:format
  :~  ['ok' [%b %.y]]
      ['error' ~]
      ['handle-id' s+handle-id]
      ['exists' [%b ?~(found %.n %.y)]]
  ==
::
++  verify-proof-json
  |=  [graf=graf-app-state handle-id=@t]
  ^-  json
  ::  verified means graf stored the record itself and minted a content
  ::  hash over it at write time.  a handle that is merely referenced by
  ::  other records is reported as mentioned, never as verified.
  =/  minted  (find-mint mints.graf handle-id)
  =/  mentioned  (find-handle handle-registry.graf handle-id)
  %-  pairs:enjs:format
  :~  ['ok' [%b %.y]]
      ['error' ~]
      ['handle-id' s+handle-id]
      ['verified' [%b ?~(minted %.n %.y)]]
      ['mentioned' [%b ?~(mentioned %.n %.y)]]
      :-  'minted-hash'
      ?~  minted  ~
      s+mint.u.minted
      :-  'asserted-hash'
      ?~  minted  ~
      s+hash.handle.u.minted
      :-  'handle'
      ?~  mentioned  ~
      (graf-handle-json u.mentioned)
  ==
::
++  cantrip-binding-json
  |=  binding=(unit cantrip-graf-binding:graf-sur)
  ^-  json
  ?~  binding
    (present-json %.n)
  %-  pairs:enjs:format
  :~  ['present' [%b %.y]]
      ['binding-id' s+binding-id.u.binding]
      ['session-id' s+session-id.u.binding]
      ['mode' s+(tas-text mode.u.binding)]
  ==
::
++  cantrip-binding-inventory-json
  |=  graf=graf-app-state
  ^-  json
  %-  pairs:enjs:format
  :~  ['root-id' s+root-id.graf]
      ['binding-count' (numb:enjs:format (lent cantrip-bindings.graf))]
      ['bindings' [%a (turn cantrip-bindings.graf |=(binding=cantrip-graf-binding:graf-sur (cantrip-binding-json (some binding))))]]
  ==
::
++  attic-family-summary-json
  |=  fam=attic-family-summary:graf-attic
  ^-  json
  %-  pairs:enjs:format
  :~  ['family' s+(tas-text family.fam)]
      ['epoch-count' (numb:enjs:format epoch-count.fam)]
      ['archived-count' (numb:enjs:format archived-count.fam)]
      ['staged-count' (numb:enjs:format staged-count.fam)]
  ==
::
++  attic-summary-json
  |=  graf=graf-app-state
  ^-  json
  %-  pairs:enjs:format
  :~  ['root-id' s+root-id.graf]
      ['next-seq' (numb:enjs:format next-seq.attic.graf)]
      ['epoch-count' (numb:enjs:format (lent epochs.attic.graf))]
      ['families' [%a (turn (summary:graf-attic attic.graf) attic-family-summary-json)]]
  ==
::
++  surface-visible-json
  |=  [surface-kind=@t surface-id=@t visible=?]
  ^-  json
  %-  pairs:enjs:format
  :~  ['ok' [%b %.y]]
      ['error' ~]
      ['surface-kind' s+surface-kind]
      ['surface-id' s+surface-id]
      ['visible' [%b visible]]
  ==
::
++  noun-family-entry-json
  |=  entry=noun-family-entry
  ^-  json
  %-  pairs:enjs:format
  :~  ['family-id' s+familyid.entry]
      ['family-version' (numb:enjs:format familyversion.entry)]
      ['source-classification' s+(tas-text sourceclassification.entry)]
      ['handle-bearing-default' [%b handlebearingdefault.entry]]
      ['page-eligibility' s+(tas-text pageeligibility.entry)]
      ['attributable' [%b attributable.entry]]
      ['expectation' s+expectation.entry]
      ['stable-members' (text-list-json stablemembers.entry)]
      ['current-handle-types' (tas-list-json currenthandletypes.entry)]
      ['current-proof-actions' (tas-list-json currentproofactions.entry)]
      ['current-surfaces' (text-list-json currentsurfaces.entry)]
  ==
::
++  family-inventory-json
  ^-  json
  =/  families=(list json)
    :~  (noun-family-entry-json [familyid='graf-structural-field-v1' familyversion=1 sourceclassification=%source handlebearingdefault=%.n pageeligibility=%fragment-only attributable=%.y expectation='Canonical field placement remains axis-first and attributable writes must preserve seat/session/lease/ship identity.' stablemembers=~['host-root domain object' 'seat or ship region object' 'structural leaf or interior node object' 'attributed write record'] currenthandletypes=~[%seat-write %seat-region %axis-write %ship-position] currentproofactions=~[%record-seat-write %record-axis-write %record-ship-position] currentsurfaces=~['graf-root-field' 'graf-root-summary' 'graf-root-domains' 'graf-seat-write' 'graf-seat-region' 'graf-axis-write' 'graf-ship-position']])
        (noun-family-entry-json [familyid='graf-handle-v1' familyversion=1 sourceclassification=%source handlebearingdefault=%.y pageeligibility=%fragment-only attributable=%.n expectation='Stable secondary names must resolve back to canonical axes or durable object references without replacing them.' stablemembers=~['object handle' 'subtree handle' 'page handle' 'executable handle' 'receipt handle'] currenthandletypes=~ currentproofactions=~ currentsurfaces=~['graf-handle']])
        (noun-family-entry-json [familyid='graf-executable-v1' familyversion=1 sourceclassification=%mixed handlebearingdefault=%.y pageeligibility=%mixed attributable=%.n expectation='Stored executable matter must stay narrow enough for Cantrip admission while remaining durable and referentially stable.' stablemembers=~['try' 'projection' 'continuation'] currenthandletypes=~[%slice %traversal %write-intent %continuation %search-tree] currentproofactions=~[%record-slice %record-traversal %record-write-intent %record-continuation %record-search-tree] currentsurfaces=~['graf-slice' 'graf-traversal-decision' 'graf-write-intent' 'graf-continuation' 'graf-search-tree']])
        (noun-family-entry-json [familyid='graf-result-receipt-v1' familyversion=1 sourceclassification=%derived handlebearingdefault=%.y pageeligibility=%mixed attributable=%.n expectation='Execution outputs and receipts must remain durable Graf matter, with proof bundles and runtime status staying fetchable as first-class evidence.' stablemembers=~['result object' 'receipt object' 'declarative effect object' 'execution divergence object'] currenthandletypes=~[%residue %sieve %search-result %proof-bundle %runtime] currentproofactions=~[%record-residue %record-sieve-verdict %record-search-result %record-proof-bundle] currentsurfaces=~['graf-residue' 'graf-sieve-verdict' 'graf-search-result' 'graf-proof-bundle' 'graf-runtime-status']])
        (noun-family-entry-json [familyid='graf-relation-v1' familyversion=1 sourceclassification=%derived handlebearingdefault=%.n pageeligibility=%fragment-only attributable=%.n expectation='Non-local linkage must stay explicit instead of being smuggled into structural position or page projection.' stablemembers=~['structural link' 'context link' 'operation link' 'link trail' 'projection-edge receipt'] currenthandletypes=~[%relation] currentproofactions=~[%record-relation] currentsurfaces=~['graf-relation']])
        (noun-family-entry-json [familyid='graf-projection-v1' familyversion=1 sourceclassification=%derived handlebearingdefault=%.y pageeligibility=%page-bearing attributable=%.n expectation='Derived operator-visible views must stay explicit and never silently replace their source matter.' stablemembers=~['page-bearing object' 'fragment or card object' 'projection object' 'invalidation marker' 'regeneration record'] currenthandletypes=~[%axis-page %axis-trail %projection] currentproofactions=~[%record-projection] currentsurfaces=~['graf-axis-page' 'graf-axis-trail' 'graf-projection']])
        (noun-family-entry-json [familyid='graf-contract-v1' familyversion=1 sourceclassification=%mixed handlebearingdefault=%.y pageeligibility=%usually-page-bearing attributable=%.n expectation='Source-derived machine contracts must become durable Graf objects instead of staying trapped in shell-side catalogs.' stablemembers=~['app interface contract' 'mark contract' 'typed boundary contract' 'thread contract' 'runtime surface contract' 'contract relation edge'] currenthandletypes=~ currentproofactions=~ currentsurfaces=~])
        (noun-family-entry-json [familyid='graf-packet-corpus-state-v1' familyversion=1 sourceclassification=%mixed handlebearingdefault=%.y pageeligibility=%page-bearing attributable=%.n expectation='Bounded packet and corpus-state law must stay explicit so selector, bundle, and packet routing can be audited inside Graf.' stablemembers=~['packet object' 'reduced packet view' 'corpus-state profile' 'top concept object' 'machine role object' 'operation object' 'integrity object'] currenthandletypes=~[%packet] currentproofactions=~[%record-packet-state] currentsurfaces=~['graf-packet']])
        (noun-family-entry-json [familyid='graf-provenance-v1' familyversion=1 sourceclassification=%mixed handlebearingdefault=%.y pageeligibility=%often-page-bearing attributable=%.n expectation='Session briefs, decisions, investigations, and live updates must remain durable evidence rather than shell residue.' stablemembers=~['session brief object' 'bootstrap prompt object' 'decision record' 'investigation cycle record' 'live update record' 'evidence reference object'] currenthandletypes=~[%provenance] currentproofactions=~[%record-provenance] currentsurfaces=~['graf-provenance']])
    ==
  %-  pairs:enjs:format
  :~  ['common-envelope-fields' (text-list-json ~['family_id' 'family_version' 'source_classification' 'location_ref' 'handle' 'attribution'])]
      ['attribution-fields' (text-list-json ~['session_id' 'seat_id' 'lease_id' 'assigned_ship_id'])]
      ['noun-family-count' (numb:enjs:format (lent families))]
      ['noun-families' [%a families]]
  ==
::
++  graph-summary-json
  |=  summary=graph-summary:graf-sur
  ^-  json
  %-  pairs:enjs:format
  :~  ['concept-count' (numb:enjs:format concept-count.summary)]
      ['relation-count' (numb:enjs:format relation-count.summary)]
  ==
::
++  root-summary-json
  |=  root=graf-root-summary:graf-sur
  ^-  json
  %-  pairs:enjs:format
  :~  ['root-id' s+root-id.root]
      ['contribution-count' (numb:enjs:format contribution-count.root)]
      ['seat-count' (numb:enjs:format seat-count.root)]
      :-  'last-seat-id'
      ?~  last-seat-id.root  ~
      s+(tas-text u.last-seat-id.root)
  ==
::
++  domain-summary-json
  |=  summary=graf-domain-summary:graf-sur
  ^-  json
  %-  pairs:enjs:format
  :~  ['domain' s+(tas-text domain.summary)]
      ['count' (numb:enjs:format count.summary)]
      :-  'last-id'
      ?~  last-id.summary  ~
      s+u.last-id.summary
  ==
::
++  domain-anchor-json
  |=  anchor=graf-domain-anchor:graf-sur
  ^-  json
  %-  pairs:enjs:format
  :~  ['domain' s+(tas-text domain.anchor)]
      ['axis' (numb:enjs:format axis.anchor)]
      ['count' (numb:enjs:format count.anchor)]
      :-  'last-id'
      ?~  last-id.anchor  ~
      s+u.last-id.anchor
  ==
::
++  root-domains-json
  |=  domains=graf-root-domains:graf-sur
  ^-  json
  %-  pairs:enjs:format
  :~  ['root-id' s+root-id.domains]
      ['domains' [%a (turn domains.domains domain-summary-json)]]
  ==
::
++  seat-region-json
  |=  region=graf-seat-region:graf-sur
  ^-  json
  %-  pairs:enjs:format
  :~  ['handle' (graf-handle-json handle.region)]
      ['root-id' s+root-id.region]
      ['seat-id' s+(tas-text seat-id.region)]
      ['session-id' s+session-id.region]
      ['lease-id' s+lease-id.region]
      ['assigned-ship-id' s+assigned-ship-id.region]
      :-  'ship-position'
      ?~  ship-position.region  ~
      s+u.ship-position.region
      :-  'region-path'
      ?~  region-path.region  ~
      s+u.region-path.region
      :-  'region-axis'
      ?~  region-axis.region  ~
      (numb:enjs:format u.region-axis.region)
      ['axis-write-count' (numb:enjs:format axis-write-count.region)]
      :-  'last-relative-axis'
      ?~  last-relative-axis.region  ~
      (numb:enjs:format u.last-relative-axis.region)
      :-  'last-absolute-axis'
      ?~  last-absolute-axis.region  ~
      (numb:enjs:format u.last-absolute-axis.region)
      ['writable' [%b writable.region]]
  ==
::
++  seat-region-summary-json
  |=  region=(unit graf-seat-region:graf-sur)
  ^-  json
  ?~  region
    (present-json %.n)
  %-  pairs:enjs:format
  :~  ['present' [%b %.y]]
      ['handle' (graf-handle-json handle.u.region)]
      ['root-id' s+root-id.u.region]
      ['seat-id' s+(tas-text seat-id.u.region)]
      ['session-id' s+session-id.u.region]
      ['lease-id' s+lease-id.u.region]
      ['assigned-ship-id' s+assigned-ship-id.u.region]
      :-  'ship-position'
      ?~  ship-position.u.region  ~
      s+u.ship-position.u.region
      :-  'region-path'
      ?~  region-path.u.region  ~
      s+u.region-path.u.region
      :-  'region-axis'
      ?~  region-axis.u.region  ~
      (numb:enjs:format u.region-axis.u.region)
      ['axis-write-count' (numb:enjs:format axis-write-count.u.region)]
      :-  'last-relative-axis'
      ?~  last-relative-axis.u.region  ~
      (numb:enjs:format u.last-relative-axis.u.region)
      :-  'last-absolute-axis'
      ?~  last-absolute-axis.u.region  ~
      (numb:enjs:format u.last-absolute-axis.u.region)
      ['writable' [%b writable.u.region]]
  ==
::
++  seat-regions-json
  |=  regions=(list graf-seat-region:graf-sur)
  ^-  json
  [%a (turn regions |=(region=graf-seat-region:graf-sur (seat-region-summary-json `region)))]
::
++  ship-position-json
  |=  position=(unit graf-ship-position:graf-sur)
  ^-  json
  ?~  position
    (present-json %.n)
  %-  pairs:enjs:format
  :~  ['present' [%b %.y]]
      ['handle' (graf-handle-json handle.u.position)]
      ['root-id' s+root-id.u.position]
      ['seat-id' s+(tas-text seat-id.u.position)]
      ['assigned-ship-id' s+assigned-ship-id.u.position]
      ['ship-position' s+ship-position.u.position]
      ['region-path' s+region-path.u.position]
      ['writable' [%b writable.u.position]]
  ==
::
++  ship-positions-json
  |=  positions=(list graf-ship-position:graf-sur)
  ^-  json
  [%a (turn positions |=(position=graf-ship-position:graf-sur (ship-position-json `position)))]
::
++  root-field-json
  |=  field=graf-root-field:graf-sur
  ^-  json
  %-  pairs:enjs:format
  :~  ['root-id' s+root-id.field]
      ['root-axis' (numb:enjs:format root-axis.field)]
      ['domain-trunk-axis' (numb:enjs:format domain-trunk-axis.field)]
      ['seat-trunk-axis' (numb:enjs:format seat-trunk-axis.field)]
      ['domains' [%a (turn domains.field domain-anchor-json)]]
      ['seat-regions' [%a (turn seat-regions.field seat-region-json)]]
      ['contribution-count' (numb:enjs:format contribution-count.field)]
      ['axis-write-count' (numb:enjs:format axis-write-count.field)]
      ['collision-codes' (tas-list-json collision-codes.field)]
  ==
::
++  seat-inventory-json
  |=  graf=graf-app-state
  ^-  json
  =/  latest  (latest-seat-writes seat-writes.graf ~)
  =/  regions  (collect-seat-regions latest axis-writes.graf)
  %-  pairs:enjs:format
  :~  ['root-id' s+root-id.graf]
      ['seat-count' (numb:enjs:format (lent regions))]
      ['axis-write-count' (numb:enjs:format (lent axis-writes.graf))]
      ['collision-codes' (tas-list-json (seat-write-collision-codes latest))]
      ['seats' (seat-regions-json regions)]
  ==
::
++  position-inventory-json
  |=  graf=graf-app-state
  ^-  json
  =/  current  (latest-positions ship-positions.graf)
  %-  pairs:enjs:format
  :~  ['root-id' s+root-id.graf]
      ['position-count' (numb:enjs:format (lent current))]
      ['positions' (ship-positions-json current)]
  ==
::
++  graf-state-json
  |=  graf=graf-app-state
  ^-  json
  =/  graph-summary  (summarize-graph graf)
  =/  root-summary  (summarize-root graf)
  =/  root-domains  (build-root-domains graf)
  =/  root-field  (build-root-field graf)
  %-  pairs:enjs:format
  :~  ['version' (numb:enjs:format version.graf)]
      ['root-id' s+root-id.graf]
      ['family-inventory' family-inventory-json]
      ['graph-summary' (graph-summary-json graph-summary)]
      ['root-summary' (root-summary-json root-summary)]
      ['root-domains' (root-domains-json root-domains)]
      ['root-field' (root-field-json root-field)]
      ['seat-inventory' (seat-inventory-json graf)]
      ['position-inventory' (position-inventory-json graf)]
      ['impulse-count' (numb:enjs:format (lent impulses.graf))]
      ['bundle-count' (numb:enjs:format (lent bundles.graf))]
      ['packet-count' (numb:enjs:format (lent packets.graf))]
      ['circulation-count' (numb:enjs:format (lent circulation.graf))]
      ['handle-count' (numb:enjs:format (lent handle-registry.graf))]
      ['mint-count' (numb:enjs:format (lent mints.graf))]
      ['attic-epoch-count' (numb:enjs:format (lent epochs.attic.graf))]
      ['relation-count' (numb:enjs:format (lent relations.graf))]
      ['projection-count' (numb:enjs:format (lent projections.graf))]
      ['search-tree-count' (numb:enjs:format (lent search-trees.graf))]
      ['search-result-count' (numb:enjs:format (lent search-results.graf))]
      ['provenance-count' (numb:enjs:format (lent provenances.graf))]
      ['proof-bundle-count' (numb:enjs:format (lent proof-bundles.graf))]
      ['recent-key-count' (numb:enjs:format (lent recent-keys.graf))]
      ['last-dispatch' (dispatch-latest-json last-dispatch.graf)]
      ['runtime-status' (runtime-status-json runtime-status.graf)]
  ==
::
++  dispatch-receipt-json
  |=  receipt=dispatch-receipt:graf-sur
  ^-  json
  %-  pairs:enjs:format
  :~  ['present' [%b %.y]]
      ['app' s+(tas-text app.receipt)]
      ['action' s+(tas-text action.receipt)]
      ['batch-id' s+batch-id.receipt]
      ['batch-hash' s+batch-hash.receipt]
      :-  'source-slug'
      ?~  source-slug.receipt  ~
      s+u.source-slug.receipt
      ['dispatched-at' s+(scot %da dispatched-at.receipt)]
      ['idempotency-key' s+idempotency-key.receipt]
      ['sequence' (numb:enjs:format sequence.receipt)]
      ['accepted' [%b accepted.receipt]]
      ['duplicate' [%b duplicate.receipt]]
  ==
::
++  dispatch-latest-json
  |=  receipt=(unit dispatch-receipt:graf-sur)
  ^-  json
  ?~  receipt
    (present-json %.n)
  (dispatch-receipt-json u.receipt)
::
++  graf-handle-json
  |=  handle=graf-handle:graf-sur
  ^-  json
  %-  pairs:enjs:format
  :~  ['type' s+(tas-text type.handle)]
      ['version' (numb:enjs:format version.handle)]
      ['id' s+id.handle]
      ['hash' s+hash.handle]
  ==
::
++  runtime-status-json
  |=  status=(unit graf-runtime-status)
  ^-  json
  ?~  status
    (present-json %.n)
  %-  pairs:enjs:format
  :~  ['present' [%b %.y]]
      ['handle' (graf-handle-json handle.u.status)]
      ['status' s+(tas-text status.u.status)]
      ['detail' s+detail.u.status]
  ==
::
++  residue-json
  |=  residue=(unit graf-residue:graf-sur)
  ^-  json
  ?~  residue
    (present-json %.n)
  %-  pairs:enjs:format
  :~  ['present' [%b %.y]]
      ['handle' (graf-handle-json handle.u.residue)]
      ['source-id' s+source-id.u.residue]
      ['residue' s+residue.u.residue]
  ==
::
++  packet-concept-json
  |=  concept=graf-packet-concept:graf-sur
  ^-  json
  %-  pairs:enjs:format
  :~  ['concept-id' s+concept-id.concept]
      ['name' s+name.concept]
      :-  'cluster-label'
      ?~  cluster-label.concept  ~
      s+u.cluster-label.concept
      ['reason' s+reason.concept]
      :-  'why-it-matters'
      ?~  why-it-matters.concept  ~
      s+u.why-it-matters.concept
      :-  'evidence-excerpt'
      ?~  evidence-excerpt.concept  ~
      s+u.evidence-excerpt.concept
      :-  'paper'
      ?~  paper.concept  ~
      s+u.paper.concept
  ==
::
++  packet-role-json
  |=  role=graf-packet-role:graf-sur
  ^-  json
  %-  pairs:enjs:format
  :~  ['name' s+name.role]
      ['concept-matches' (text-list-json concept-matches.role)]
      ['formula-matches' (text-list-json formula-matches.role)]
      ['runtime-surfaces' (text-list-json runtime-surfaces.role)]
      ['why' s+why.role]
  ==
::
++  packet-operation-json
  |=  operation=graf-packet-operation:graf-sur
  ^-  json
  %-  pairs:enjs:format
  :~  ['name' s+name.operation]
      ['concept-matches' (text-list-json concept-matches.operation)]
      ['formula-matches' (text-list-json formula-matches.operation)]
      ['runtime-surfaces' (text-list-json runtime-surfaces.operation)]
      ['why' s+why.operation]
  ==
::
++  packet-json
  |=  packet=(unit graf-packet:graf-sur)
  ^-  json
  ?~  packet
    (present-json %.n)
  %-  pairs:enjs:format
  :~  ['present' [%b %.y]]
      ['handle' (graf-handle-json handle.u.packet)]
      ['packet-id' s+packet-id.u.packet]
      ['name' s+name.u.packet]
      ['packet-family' s+packet-family.u.packet]
      ['selector-family' s+selector-family.u.packet]
      ['status' s+status.u.packet]
      ['doctrine-visibility' s+doctrine-visibility.u.packet]
      ['packet-hidden' [%b packet-hidden.u.packet]]
      ['indications' (text-list-json indications.u.packet)]
      ['contraindications' (text-list-json contraindications.u.packet)]
      ['expected-effects' (text-list-json expected-effects.u.packet)]
      ['selection-notes' s+selection-notes.u.packet]
      ['evidence-explanation' s+evidence-explanation.u.packet]
      ['proof-refs' (text-list-json proof-refs.u.packet)]
      ['top-concepts' [%a (turn top-concepts.u.packet packet-concept-json)]]
      ['machine-roles' [%a (turn machine-roles.u.packet packet-role-json)]]
      ['operations' [%a (turn operations.u.packet packet-operation-json)]]
      :-  'profile-path'
      ?~  profile-path.u.packet  ~
      s+u.profile-path.u.packet
      :-  'profile-sha256'
      ?~  profile-sha256.u.packet  ~
      s+u.profile-sha256.u.packet
      :-  'packet-digest'
      ?~  packet-digest.u.packet  ~
      s+u.packet-digest.u.packet
      ['created' s+(scot %da created.u.packet)]
  ==
::
++  provenance-json
  |=  provenance=(unit graf-provenance:graf-sur)
  ^-  json
  ?~  provenance
    (present-json %.n)
  %-  pairs:enjs:format
  :~  ['present' [%b %.y]]
      ['handle' (graf-handle-json handle.u.provenance)]
      ['provenance-kind' s+(tas-text provenance-kind.u.provenance)]
      ['session-id' s+session-id.u.provenance]
      ['seat-id' s+(tas-text seat-id.u.provenance)]
      ['lease-id' s+lease-id.u.provenance]
      ['assigned-ship-id' s+assigned-ship-id.u.provenance]
      ['title' s+title.u.provenance]
      ['body' s+body.u.provenance]
      :-  'source-handle'
      ?~  source-handle.u.provenance  ~
      (graf-handle-json u.source-handle.u.provenance)
      ['evidence-refs' (text-list-json evidence-refs.u.provenance)]
      ['created' s+(scot %da created.u.provenance)]
  ==
::
++  axis-write-summary-json
  |=  axis-write=(unit graf-axis-write:graf-sur)
  ^-  json
  ?~  axis-write
    (present-json %.n)
  %-  pairs:enjs:format
  :~  ['present' [%b %.y]]
      ['handle' (graf-handle-json handle.u.axis-write)]
      ['root-id' s+root-id.u.axis-write]
      ['seat-id' s+(tas-text seat-id.u.axis-write)]
      ['session-id' s+session-id.u.axis-write]
      ['lease-id' s+lease-id.u.axis-write]
      ['assigned-ship-id' s+assigned-ship-id.u.axis-write]
      :-  'ship-position'
      ?~  ship-position.u.axis-write  ~
      s+u.ship-position.u.axis-write
      :-  'region-path'
      ?~  region-path.u.axis-write  ~
      s+u.region-path.u.axis-write
      ['region-axis' (numb:enjs:format region-axis.u.axis-write)]
      ['relative-axis' (numb:enjs:format relative-axis.u.axis-write)]
      ['absolute-axis' (numb:enjs:format absolute-axis.u.axis-write)]
      ['value' s+value.u.axis-write]
      ['value-kind' s+(tas-text value-kind.u.axis-write)]
      ['summary' s+summary.u.axis-write]
  ==
::
++  axis-page-json
  |=  axis-write=(unit graf-axis-write:graf-sur)
  ^-  json
  ?~  axis-write
    (present-json %.n)
  =/  page  (make-axis-page u.axis-write)
  %-  pairs:enjs:format
  :~  ['present' [%b %.y]]
      ['handle' (graf-handle-json handle.page)]
      ['source' (graf-handle-json source.page)]
      ['root-id' s+root-id.page]
      ['seat-id' s+(tas-text seat-id.page)]
      ['region-axis' (numb:enjs:format region-axis.page)]
      ['relative-axis' (numb:enjs:format relative-axis.page)]
      ['absolute-axis' (numb:enjs:format absolute-axis.page)]
      ['page-key' s+page-key.page]
      ['title' s+title.page]
      ['value' s+value.page]
      ['value-kind' s+(tas-text value-kind.page)]
      ['summary' s+summary.page]
  ==
::
++  axis-trail-json
  |=  axis-write=(unit graf-axis-write:graf-sur)
  ^-  json
  ?~  axis-write
    (present-json %.n)
  =/  trail  (make-axis-trail u.axis-write)
  %-  pairs:enjs:format
  :~  ['present' [%b %.y]]
      ['handle' (graf-handle-json handle.trail)]
      ['source' (graf-handle-json source.trail)]
      ['root-id' s+root-id.trail]
      ['seat-id' s+(tas-text seat-id.trail)]
      ['region-axis' (numb:enjs:format region-axis.trail)]
      ['relative-axis' (numb:enjs:format relative-axis.trail)]
      ['absolute-axis' (numb:enjs:format absolute-axis.trail)]
      ['ancestor-axes' (ud-list-json ancestor-axes.trail)]
      ['slot-path' (ud-list-json slot-path.trail)]
      ['relative-slot-path' (ud-list-json relative-slot-path.trail)]
      ['page-key' s+page-key.trail]
      ['summary' s+summary.trail]
  ==
::
++  projection-json
  |=  projection=(unit graf-projection:graf-sur)
  ^-  json
  ?~  projection
    (present-json %.n)
  %-  pairs:enjs:format
  :~  ['present' [%b %.y]]
      ['handle' (graf-handle-json handle.u.projection)]
      ['projection-kind' s+(tas-text projection-kind.u.projection)]
      ['source' (graf-handle-json source.u.projection)]
      ['page-key' s+page-key.u.projection]
      ['title' s+title.u.projection]
      ['summary' s+summary.u.projection]
  ==
::
++  relation-json
  |=  relation=graf-relation:graf-sur
  ^-  json
  %-  pairs:enjs:format
  :~  ['present' [%b %.y]]
      ['handle' (graf-handle-json handle.relation)]
      ['relation-kind' s+(tas-text relation-kind.relation)]
      ['source' (graf-handle-json source.relation)]
      ['target' (graf-handle-json target.relation)]
      ['label' s+label.relation]
      ['summary' s+summary.relation]
  ==
::
++  relation-inventory-json
  |=  graf=graf-app-state
  ^-  json
  %-  pairs:enjs:format
  :~  ['root-id' s+root-id.graf]
      ['relation-count' (numb:enjs:format (lent relations.graf))]
      ['relations' [%a (turn relations.graf relation-json)]]
  ==
::
++  relation-summary-json
  |=  graf=graf-app-state
  ^-  json
  %-  pairs:enjs:format
  :~  ['root-id' s+root-id.graf]
      ['relation-count' (numb:enjs:format (lent relations.graf))]
      :-  'latest-relation'
      ?~  last-relation.graf  ~
      (relation-json u.last-relation.graf)
  ==
::
++  controlled-agency-relation-kinds
  ^-  (list @tas)
  :~  %intent-run
      %run-policy
      %run-builder-role
      %run-reviewer-role
      %role-tools
      %role-allowed-tool
      %role-forbidden-tool
      %run-builder-moon
      %run-reviewer-moon
      %builder-codex-session
      %reviewer-codex-session
      %moon-codex-session
      %builder-artifact
      %artifact-hash-evidence
      %artifact-run-evidence
      %reviewer-inspection
      %reviewer-review
      %reviewer-denial
      %run-cantrip-verdict
      %controlled-agency-proof-bundle
  ==
::
++  controlled-agency-required-proof-kinds
  ^-  (list @tas)
  :~  %intent-run
      %run-policy
      %run-builder-role
      %run-reviewer-role
      %role-allowed-tool
      %role-forbidden-tool
      %run-builder-moon
      %run-reviewer-moon
      %builder-codex-session
      %reviewer-codex-session
      %builder-artifact
      %artifact-hash-evidence
      %artifact-run-evidence
      %reviewer-inspection
      %reviewer-review
      %reviewer-denial
      %run-cantrip-verdict
      %controlled-agency-proof-bundle
  ==
::
++  controlled-agency-relation-labels
  ^-  (list @tas)
  :~  %intends-run
      %uses-policy
      %assigns-builder-role
      %assigns-reviewer-role
      %permits-tools
      %forbids-tool
      %built-by-moon
      %reviewed-by-moon
      %backs-builder-codex-session
      %backs-reviewer-codex-session
      %backs-codex-session
      %produces-artifact
      %has-hash-evidence
      %has-run-evidence
      %performs-inspection
      %records-review
      %records-denial
      %has-cantrip-verdict
      %reconstructs-proof-bundle
  ==
::
++  controlled-agency-vocabulary-json
  ^-  json
  %-  pairs:enjs:format
  :~  ['graph' s+'controlled-agency']
      ['relation-kinds' (tas-list-json controlled-agency-relation-kinds)]
      ['labels' (tas-list-json controlled-agency-relation-labels)]
      ['proof-bundle-readback' s+'/x/relation/controlled-agency/proof-bundle/<run-id>']
      ['proof-bundle-expects' (tas-list-json controlled-agency-required-proof-kinds)]
  ==
::
++  controlled-agency-inventory-json
  |=  graf=graf-app-state
  ^-  json
  =/  found  (controlled-agency-relations relations.graf)
  %-  pairs:enjs:format
  :~  ['root-id' s+root-id.graf]
      ['graph' s+'controlled-agency']
      ['relation-count' (numb:enjs:format (lent found))]
      ['relations' [%a (turn found relation-json)]]
  ==
::
++  controlled-agency-summary-json
  |=  graf=graf-app-state
  ^-  json
  =/  found  (controlled-agency-relations relations.graf)
  %-  pairs:enjs:format
  :~  ['root-id' s+root-id.graf]
      ['graph' s+'controlled-agency']
      ['relation-count' (numb:enjs:format (lent found))]
      ['relation-kinds' (tas-list-json controlled-agency-relation-kinds)]
      :-  'latest-relation'
      ?~  last-relation.graf  ~
      ?:  (controlled-agency-relation u.last-relation.graf)
        (relation-json u.last-relation.graf)
      ~
  ==
::
++  relation-list-json
  |=  [graf=graf-app-state readback=@t found=(list graf-relation:graf-sur)]
  ^-  json
  %-  pairs:enjs:format
  :~  ['root-id' s+root-id.graf]
      ['readback' s+readback]
      ['relation-count' (numb:enjs:format (lent found))]
      ['relations' [%a (turn found relation-json)]]
  ==
::
++  controlled-agency-proof-bundle-json
  |=  [graf=graf-app-state run-id=@t]
  ^-  json
  =/  found  (controlled-agency-relations-by-query relations.graf run-id)
  =/  missing  (controlled-agency-missing-kinds found controlled-agency-required-proof-kinds)
  %-  pairs:enjs:format
  :~  ['root-id' s+root-id.graf]
      ['graph' s+'controlled-agency']
      ['readback' s+'proof-bundle-by-run-id']
      ['run-id' s+run-id]
      ['complete' [%b =(0 (lent missing))]]
      ['expected-kinds' (tas-list-json controlled-agency-required-proof-kinds)]
      ['missing-kinds' (tas-list-json missing)]
      ['relation-count' (numb:enjs:format (lent found))]
      ['relations' [%a (turn found relation-json)]]
  ==
::
++  projection-inventory-json
  |=  graf=graf-app-state
  ^-  json
  %-  pairs:enjs:format
  :~  ['root-id' s+root-id.graf]
      ['projection-count' (numb:enjs:format (lent projections.graf))]
      ['projections' [%a (turn projections.graf |=(projection=graf-projection:graf-sur (projection-json (some projection))))]]
  ==
::
++  projection-summary-json
  |=  graf=graf-app-state
  ^-  json
  %-  pairs:enjs:format
  :~  ['root-id' s+root-id.graf]
      ['projection-count' (numb:enjs:format (lent projections.graf))]
      :-  'latest-projection'
      ?~  last-projection.graf  ~
      (projection-json last-projection.graf)
  ==
::
++  concept-node-json
  |=  node=concept-node:graf-sur
  ^-  json
  %-  pairs:enjs:format
  :~  ['present' [%b %.y]]
      ['surface' s+'concept']
      ['id' s+(tas-text id.node)]
      ['kind' s+(tas-text kind.node)]
      ['name' s+name.node]
      ['rank' (numb:enjs:format rank.node)]
  ==
::
++  relation-edge-json
  |=  edge=relation-edge:graf-sur
  ^-  json
  %-  pairs:enjs:format
  :~  ['present' [%b %.y]]
      ['surface' s+'graph-edge']
      ['from' s+(tas-text from.edge)]
      ['to' s+(tas-text to.edge)]
      ['label' s+(tas-text label.edge)]
      ['weight' (numb:enjs:format weight.edge)]
  ==
::
++  search-query-json
  |=  [graf=graf-app-state query=@t]
  ^-  json
  =/  domain-summary  (build-root-domains graf)
  =/  concept-results=(list json)  (search-concepts (latest-nodes nodes.graph.graf) query)
  =/  edge-results=(list json)  (search-edges (latest-edges edges.graph.graf) query)
  =/  domain-results=(list json)  (search-domains domains.domain-summary query)
  =/  axis-results=(list json)  (search-axes axis-writes.graf query)
  =/  relation-results=(list json)  (search-relations (latest-relations relations.graf) query)
  =/  result-count=@ud
    (sum-ud-list ~[(lent concept-results) (lent edge-results) (lent domain-results) (lent axis-results) (lent relation-results)])
  %-  pairs:enjs:format
  :~  ['present' [%b ?:(=(result-count 0) %.n %.y)]]
      ['query' s+query]
      ['result-count' (numb:enjs:format result-count)]
      ['concept-count' (numb:enjs:format (lent concept-results))]
      ['edge-count' (numb:enjs:format (lent edge-results))]
      ['domain-count' (numb:enjs:format (lent domain-results))]
      ['axis-count' (numb:enjs:format (lent axis-results))]
      ['relation-count' (numb:enjs:format (lent relation-results))]
      ['concepts' [%a concept-results]]
      ['edges' [%a edge-results]]
      ['domains' [%a domain-results]]
      ['axes' [%a axis-results]]
      ['relations' [%a relation-results]]
  ==
::
++  traversal-path-json
  |=  [graf=graf-app-state source-id=@t target-id=@t]
  ^-  json
  =/  paths=(list graf-relation:graf-sur)  (relation-paths (latest-relations relations.graf) source-id target-id)
  %-  pairs:enjs:format
  :~  ['present' [%b ?:(=(0 (lent paths)) %.n %.y)]]
      ['source-id' s+source-id]
      ['target-id' s+target-id]
      ['path-count' (numb:enjs:format (lent paths))]
      ['paths' [%a (turn paths relation-json)]]
  ==
::
++  search-tree-json
  |=  tree=graf-search-tree:graf-sur
  ^-  json
  %-  pairs:enjs:format
  :~  ['present' [%b %.y]]
      ['handle' (graf-handle-json handle.tree)]
      ['root-handle' (graf-handle-json root-handle.tree)]
      ['tree-kind' s+(tas-text tree-kind.tree)]
      ['budget' (numb:enjs:format budget.tree)]
      ['match-terms' (text-list-json match-terms.tree)]
      ['match-domains' (tas-list-json match-domains.tree)]
      ['match-tags' (text-list-json match-tags.tree)]
  ==
::
++  search-result-json
  |=  result=graf-search-result:graf-sur
  ^-  json
  %-  pairs:enjs:format
  :~  ['present' [%b %.y]]
      ['handle' (graf-handle-json handle.result)]
      ['tree-handle' (graf-handle-json tree-handle.result)]
      ['root-handle' (graf-handle-json root-handle.result)]
      ['tree-kind' s+(tas-text tree-kind.result)]
      ['result-count' (numb:enjs:format (lent result-handles.result))]
      ['result-handles' [%a (turn result-handles.result graf-handle-json)]]
      ['scanned-count' (numb:enjs:format scanned-count.result)]
      ['exhausted' [%b exhausted.result]]
  ==
::
++  search-tree-inventory-json
  |=  graf=graf-app-state
  ^-  json
  %-  pairs:enjs:format
  :~  ['root-id' s+root-id.graf]
      ['search-tree-count' (numb:enjs:format (lent search-trees.graf))]
      ['search-trees' [%a (turn search-trees.graf search-tree-json)]]
  ==
::
++  search-result-inventory-json
  |=  graf=graf-app-state
  ^-  json
  %-  pairs:enjs:format
  :~  ['root-id' s+root-id.graf]
      ['search-result-count' (numb:enjs:format (lent search-results.graf))]
      ['search-results' [%a (turn search-results.graf search-result-json)]]
  ==
::
++  search-tree-summary-json
  |=  graf=graf-app-state
  ^-  json
  %-  pairs:enjs:format
  :~  ['root-id' s+root-id.graf]
      ['search-tree-count' (numb:enjs:format (lent search-trees.graf))]
      :-  'latest-search-tree'
      ?~  last-search-tree.graf  ~
      (search-tree-json u.last-search-tree.graf)
  ==
::
++  search-result-summary-json
  |=  graf=graf-app-state
  ^-  json
  %-  pairs:enjs:format
  :~  ['root-id' s+root-id.graf]
      ['search-result-count' (numb:enjs:format (lent search-results.graf))]
      :-  'latest-search-result'
      ?~  last-search-result.graf  ~
      (search-result-json u.last-search-result.graf)
  ==
::
++  search-summary-json
  |=  graf=graf-app-state
  ^-  json
  %-  pairs:enjs:format
  :~  ['root-id' s+root-id.graf]
      ['search-tree-count' (numb:enjs:format (lent search-trees.graf))]
      ['search-result-count' (numb:enjs:format (lent search-results.graf))]
      :-  'latest-search-tree'
      ?~  last-search-tree.graf  ~
      (search-tree-json u.last-search-tree.graf)
      :-  'latest-search-result'
      ?~  last-search-result.graf  ~
      (search-result-json u.last-search-result.graf)
  ==
::
++  provenance-inventory-json
  |=  graf=graf-app-state
  ^-  json
  %-  pairs:enjs:format
  :~  ['root-id' s+root-id.graf]
      ['provenance-count' (numb:enjs:format (lent provenances.graf))]
      ['provenances' [%a (turn provenances.graf |=(provenance=graf-provenance:graf-sur (provenance-json (some provenance))))]]
  ==
::
++  provenance-summary-json
  |=  graf=graf-app-state
  ^-  json
  %-  pairs:enjs:format
  :~  ['root-id' s+root-id.graf]
      ['provenance-count' (numb:enjs:format (lent provenances.graf))]
      :-  'latest-provenance'
      ?~  last-provenance.graf  ~
      (provenance-json last-provenance.graf)
  ==
::
++  proof-bundle-json
  |=  bundle=graf-proof-bundle:graf-sur
  ^-  json
  %-  pairs:enjs:format
  :~  ['present' [%b %.y]]
      ['handle' (graf-handle-json handle.bundle)]
      ['source' s+source.bundle]
      ['ship' s+ship.bundle]
      ['desk' s+desk.bundle]
      ['dispatch-path' s+dispatch-path.bundle]
      ['result-summary' s+result-summary.bundle]
      ['receipt-hash' s+receipt-hash.bundle]
      ['proof-refs' (text-list-json proof-refs.bundle)]
      ['created' s+(scot %da created.bundle)]
      ['current' [%b current.bundle]]
  ==
::
++  proof-bundle-inventory-json
  |=  graf=graf-app-state
  ^-  json
  %-  pairs:enjs:format
  :~  ['root-id' s+root-id.graf]
      ['proof-bundle-count' (numb:enjs:format (lent proof-bundles.graf))]
      ['proof-bundles' [%a (turn proof-bundles.graf proof-bundle-json)]]
  ==
::
++  proof-bundle-summary-json
  |=  graf=graf-app-state
  ^-  json
  %-  pairs:enjs:format
  :~  ['root-id' s+root-id.graf]
      ['proof-bundle-count' (numb:enjs:format (lent proof-bundles.graf))]
      :-  'latest-proof-bundle'
      ?~  last-proof-bundle.graf  ~
      (proof-bundle-json u.last-proof-bundle.graf)
  ==
::
::
::
::
++  bachelor-output-json
  |=  output=(unit graf-bachelor-output:graf-sur)
  ^-  json
  ?~  output  (present-json %.n)
  %-  pairs:enjs:format
  :~  ['present' b+%.y]
      ['handle' (graf-handle-json handle.u.output)]
      ['output-id' s+output-id.u.output]
      ['bachelor' s+bachelor.u.output]
      ['summary' s+summary.u.output]
      ['body' s+body.u.output]
      ['session-id' s+session-id.u.output]
      ['seat-id' s+seat-id.u.output]
      ['assigned-ship-id' s+assigned-ship-id.u.output]
      ['created' s+(scot %da created.u.output)]
  ==
::
++  reduction-candidate-json
  |=  candidate=(unit graf-reduction-candidate:graf-sur)
  ^-  json
  ?~  candidate  (present-json %.n)
  %-  pairs:enjs:format
  :~  ['present' b+%.y]
      ['handle' (graf-handle-json handle.u.candidate)]
      ['candidate-id' s+candidate-id.u.candidate]
      ['output-id' s+output-id.u.candidate]
      ['score' (numb:enjs:format score.u.candidate)]
      ['summary' s+summary.u.candidate]
      ['created' s+(scot %da created.u.candidate)]
  ==
::
++  reduction-verdict-json
  |=  verdict=(unit graf-reduction-verdict:graf-sur)
  ^-  json
  ?~  verdict  (present-json %.n)
  %-  pairs:enjs:format
  :~  ['present' b+%.y]
      ['handle' (graf-handle-json handle.u.verdict)]
      ['verdict-id' s+verdict-id.u.verdict]
      ['candidate-id' s+candidate-id.u.verdict]
      ['accepted' b+accepted.u.verdict]
      ['reason' s+reason.u.verdict]
      ['created' s+(scot %da created.u.verdict)]
  ==
::
++  convergence-record-json
  |=  convergence=(unit graf-convergence-record:graf-sur)
  ^-  json
  ?~  convergence  (present-json %.n)
  %-  pairs:enjs:format
  :~  ['present' b+%.y]
      ['handle' (graf-handle-json handle.u.convergence)]
      ['convergence-id' s+convergence-id.u.convergence]
      ['summary' s+summary.u.convergence]
      ['created' s+(scot %da created.u.convergence)]
  ==
::
++  reduction-agent-summary-json
  |=  graf=graf-app-state
  ^-  json
  =/  red  reduction-agent.graf
  %-  pairs:enjs:format
  :~  ['output-count' (numb:enjs:format (lent outputs.red))]
      ['candidate-count' (numb:enjs:format (lent candidates.red))]
      ['verdict-count' (numb:enjs:format (lent verdicts.red))]
      ['convergence-count' (numb:enjs:format (lent convergences.red))]
      ['outputs' a+(turn outputs.red |=(o=graf-bachelor-output:graf-sur (bachelor-output-json (some o))))]
      ['candidates' a+(turn candidates.red |=(c=graf-reduction-candidate:graf-sur (reduction-candidate-json (some c))))]
      ['verdicts' a+(turn verdicts.red |=(v=graf-reduction-verdict:graf-sur (reduction-verdict-json (some v))))]
      ['convergences' a+(turn convergences.red |=(c=graf-convergence-record:graf-sur (convergence-record-json (some c))))]
  ==
++  event-log-entry-json
  |=  entry=(unit graf-event-log-entry:graf-sur)
  ^-  json
  ?~  entry
    (present-json %.n)
  %-  pairs:enjs:format
  :~  ['present' [%b %.y]]
      ['handle' (graf-handle-json handle.u.entry)]
      ['event-id' s+event-id.u.entry]
      ['event-kind' s+(tas-text event-kind.u.entry)]
      ['summary' s+summary.u.entry]
      ['body' s+body.u.entry]
      ['session-id' s+session-id.u.entry]
      ['seat-id' s+seat-id.u.entry]
      ['assigned-ship-id' s+assigned-ship-id.u.entry]
      ['created' s+(scot %da created.u.entry)]
  ==
::
++  event-log-inventory-json
  |=  graf=graf-app-state
  ^-  json
  %-  pairs:enjs:format
  :~  ['root-id' s+root-id.graf]
      ['event-log-count' (numb:enjs:format (lent event-log.graf))]
      ['entries' [%a (turn event-log.graf |=(entry=graf-event-log-entry:graf-sur (event-log-entry-json (some entry))))]]
  ==
::
++  event-log-summary-json
  |=  graf=graf-app-state
  ^-  json
  %-  pairs:enjs:format
  :~  ['root-id' s+root-id.graf]
      ['event-log-count' (numb:enjs:format (lent event-log.graf))]
      :-  'latest-event-log-entry'
      ?~  last-event-log-entry.graf  ~
      (event-log-entry-json last-event-log-entry.graf)
  ==
++  task-json
  |=  task=(unit graf-task:graf-sur)
  ^-  json
  ?~  task
    (present-json %.n)
  %-  pairs:enjs:format
  :~  ['present' [%b %.y]]
      ['handle' (graf-handle-json handle.u.task)]
      ['task-id' s+task-id.u.task]
      :-  'parent-task-id'
      ?~  parent-task-id.u.task  ~
      s+u.parent-task-id.u.task
      ['worker-form-id' s+worker-form-id.u.task]
      ['intent' s+intent.u.task]
      ['requested-by' s+requested-by.u.task]
      ['created-at' s+(scot %da created-at.u.task)]
      ['session-id' s+session-id.u.task]
      ['seat-id' s+seat-id.u.task]
      ['lease-id' s+lease-id.u.task]
      ['assigned-ship-id' s+assigned-ship-id.u.task]
      ['status' s+(tas-text status.u.task)]
  ==
::
++  task-inventory-json
  |=  graf=graf-app-state
  ^-  json
  %-  pairs:enjs:format
  :~  ['root-id' s+root-id.graf]
      ['task-count' (numb:enjs:format (lent tasks.graf))]
      ['tasks' [%a (turn tasks.graf |=(task=graf-task:graf-sur (task-json (some task))))]]
  ==
::
++  task-summary-json
  |=  graf=graf-app-state
  ^-  json
  %-  pairs:enjs:format
  :~  ['root-id' s+root-id.graf]
      ['task-count' (numb:enjs:format (lent tasks.graf))]
      :-  'latest-task'
      ?~  last-task.graf  ~
      (task-json last-task.graf)
  ==
::
++  task-result-json
  |=  result=(unit graf-task-result:graf-sur)
  ^-  json
  ?~  result
    (present-json %.n)
  %-  pairs:enjs:format
  :~  ['present' [%b %.y]]
      ['handle' (graf-handle-json handle.u.result)]
      ['task-id' s+task-id.u.result]
      ['status' s+(tas-text status.u.result)]
      ['started-at' s+started-at.u.result]
      ['finished-at' s+finished-at.u.result]
      ['trace-hash' s+trace-hash.u.result]
      ['worker-id' s+worker-id.u.result]
      :-  'output'
      ?~  output.u.result  ~
      s+u.output.u.result
      ['session-id' s+session-id.u.result]
      ['seat-id' s+seat-id.u.result]
      ['lease-id' s+lease-id.u.result]
      ['assigned-ship-id' s+assigned-ship-id.u.result]
  ==
::
++  task-result-inventory-json
  |=  graf=graf-app-state
  ^-  json
  %-  pairs:enjs:format
  :~  ['root-id' s+root-id.graf]
      ['task-result-count' (numb:enjs:format (lent task-results.graf))]
      ['task-results' [%a (turn task-results.graf |=(result=graf-task-result:graf-sur (task-result-json (some result))))]]
  ==
::
++  task-result-summary-json
  |=  graf=graf-app-state
  ^-  json
  %-  pairs:enjs:format
  :~  ['root-id' s+root-id.graf]
      ['task-result-count' (numb:enjs:format (lent task-results.graf))]
      :-  'latest-task-result'
      ?~  last-task-result.graf  ~
      (task-result-json last-task-result.graf)
  ==
++  bride-net-json
  |=  net=graf-bride-net:graf-sur
  ^-  json
  %-  pairs:enjs:format
  :~  ['net-id' s+(tas-text net-id.net)]
      ['demand' s+demand.net]
      ['canon-snippets' (text-list-json canon-snippets.net)]
      ['crossing-kinds' (tas-list-json crossing-kinds.net)]
      ['active' [%b active.net]]
      ['updated' s+(scot %da updated.net)]
  ==
::
++  bride-nets-json
  |=  nets=(unit graf-bride-nets:graf-sur)
  ^-  json
  ?~  nets
    (present-json %.n)
  %-  pairs:enjs:format
  :~  ['present' [%b %.y]]
      ['handle' (graf-handle-json handle.u.nets)]
      :-  'source-handle'
      ?~  source-handle.u.nets  ~
      (graf-handle-json u.source-handle.u.nets)
      ['summary' s+summary.u.nets]
      ['updated' s+(scot %da updated.u.nets)]
      ['net-count' (numb:enjs:format (lent nets.u.nets))]
      ['nets' [%a (turn nets.u.nets bride-net-json)]]
  ==
::
++  milky-way-item-json
  |=  item=graf-milky-way-item:graf-sur
  ^-  json
  %-  pairs:enjs:format
  :~  ['canon-id' s+canon-id.item]
      ['title' s+title.item]
      ['excerpt' s+excerpt.item]
      ['retained' [%b retained.item]]
      ['rank' (numb:enjs:format rank.item)]
  ==
::
++  bride-milky-way-json
  |=  milky=(unit graf-bride-milky-way:graf-sur)
  ^-  json
  ?~  milky
    (present-json %.n)
  %-  pairs:enjs:format
  :~  ['present' [%b %.y]]
      ['handle' (graf-handle-json handle.u.milky)]
      :-  'source-handle'
      ?~  source-handle.u.milky  ~
      (graf-handle-json u.source-handle.u.milky)
      ['summary' s+summary.u.milky]
      ['updated' s+(scot %da updated.u.milky)]
      ['canon-item-count' (numb:enjs:format (lent items.u.milky))]
      ['items' [%a (turn items.u.milky milky-way-item-json)]]
  ==
::
++  native-readiness-json
  |=  readiness=graf-native-readiness:graf-sur
  ^-  json
  %-  pairs:enjs:format
  :~  ['handle' (graf-handle-json handle.readiness)]
      ['nets-ready' [%b nets-ready.readiness]]
      ['milky-way-ready' [%b milky-way-ready.readiness]]
      ['ready' [%b ready.readiness]]
      ['blockers' (text-list-json blockers.readiness)]
      ['updated' s+(scot %da updated.readiness)]
  ==
::
++  proof-latest-json
  |=  proof=graf-proof-latest
  ^-  json
  %-  pairs:enjs:format
  :~  ['version' (numb:enjs:format version.proof)]
      ['last-dispatch' (dispatch-latest-json last-dispatch.proof)]
      ['runtime-status' (runtime-status-json runtime-status.proof)]
      :-  'last-governor'
      ?~  last-governor.proof  ~
      (present-json %.y)
      :-  'last-packet'
      ?~  last-packet.proof  ~
      (present-json %.y)
      :-  'last-seat-write'
      ?~  last-seat-write.proof  ~
      (present-json %.y)
      :-  'last-axis-write'
      ?~  last-axis-write.proof  ~
      (present-json %.y)
      :-  'last-ship-position'
      ?~  last-ship-position.proof  ~
      (present-json %.y)
      :-  'last-slice'
      ?~  last-slice.proof  ~
      (present-json %.y)
      :-  'last-traversal'
      ?~  last-traversal.proof  ~
      (present-json %.y)
      :-  'last-write-intent'
      ?~  last-write-intent.proof  ~
      (present-json %.y)
      :-  'last-residue'
      ?~  last-residue.proof  ~
      (present-json %.y)
      :-  'last-sieve-verdict'
      ?~  last-sieve-verdict.proof  ~
      (present-json %.y)
      :-  'last-continuation'
      ?~  last-continuation.proof  ~
      (present-json %.y)
      :-  'last-relation'
      ?~  last-relation.proof  ~
      (present-json %.y)
      :-  'last-projection'
      ?~  last-projection.proof  ~
      (present-json %.y)
      :-  'last-search-tree'
      ?~  last-search-tree.proof  ~
      (present-json %.y)
      :-  'last-search-result'
      ?~  last-search-result.proof  ~
      (present-json %.y)
      :-  'last-provenance'
      ?~  last-provenance.proof  ~
      (present-json %.y)
      :-  'last-proof-bundle'
      ?~  last-proof-bundle.proof  ~
      (present-json %.y)
      ['last-bride-nets' (bride-nets-json last-bride-nets.proof)]
      ['last-bride-milky-way' (bride-milky-way-json last-bride-milky-way.proof)]
  ==
::
++  watch-manifest-json
  |=  manifest=graf-watch-manifest
  ^-  json
  %-  pairs:enjs:format
  :~  ['version' (numb:enjs:format version.manifest)]
      ['watch-paths' (tas-list-json watch-paths.manifest)]
  ==
::
++  circulation-card
  |=  fact=circulation-fact:graf-sur
  ^-  card
  [%give %fact ~[/graf-circulation] %noun !>(fact)]
::
++  bundle-card
  |=  bundle=bundle-ref:graf-sur
  ^-  card
  [%give %fact ~[/graf-bundles] %noun !>(bundle)]
::
++  packet-card
  |=  packet=graf-packet:graf-sur
  ^-  card
  [%give %fact ~[/graf-packets] %noun !>(packet)]
::
++  machine-card
  |=  machine=machine-topology:graf-sur
  ^-  card
  [%give %fact ~[/graf-machine-topology] %noun !>(machine)]
::
++  root-card
  |=  root=graf-root-summary:graf-sur
  ^-  card
  [%give %fact ~[/graf-root] %noun !>(root)]
::
++  governor-card
  |=  governor=graf-governor-record:graf-sur
  ^-  card
  [%give %fact ~[/graf-governor] %noun !>(governor)]
::
++  seat-write-card
  |=  seat-write=graf-seat-write:graf-sur
  ^-  card
  [%give %fact ~[/graf-seat-writes] %noun !>(seat-write)]
::
++  axis-write-card
  |=  axis-write=graf-axis-write:graf-sur
  ^-  card
  [%give %fact ~[/graf-axis-writes] %noun !>(axis-write)]
::
++  ship-position-card
  |=  position=graf-ship-position:graf-sur
  ^-  card
  [%give %fact ~[/graf-positions] %noun !>(position)]
::
++  slice-card
  |=  slice=graf-slice:graf-sur
  ^-  card
  [%give %fact ~[/graf-slice] %noun !>(slice)]
::
++  traversal-card
  |=  traversal=graf-traversal-decision:graf-sur
  ^-  card
  [%give %fact ~[/graf-traversal] %noun !>(traversal)]
::
++  write-intent-card
  |=  write-intent=graf-write-intent:graf-sur
  ^-  card
  [%give %fact ~[/graf-write-intent] %noun !>(write-intent)]
::
++  residue-card
  |=  residue=graf-residue:graf-sur
  ^-  card
  [%give %fact ~[/graf-residue] %noun !>(residue)]
::
++  sieve-verdict-card
  |=  verdict=graf-sieve-verdict:graf-sur
  ^-  card
  [%give %fact ~[/graf-sieve-verdict] %noun !>(verdict)]
::
++  continuation-card
  |=  continuation=graf-continuation:graf-sur
  ^-  card
  [%give %fact ~[/graf-continuation] %noun !>(continuation)]
::
++  proof-bundle-card
  |=  bundle=graf-proof-bundle:graf-sur
  ^-  card
  [%give %fact ~[/graf-proofs] %noun !>(bundle)]
::
++  relation-card
  |=  relation=graf-relation:graf-sur
  ^-  card
  [%give %fact ~[/graf-relations] %noun !>(relation)]
::
++  projection-card
  |=  projection=graf-projection:graf-sur
  ^-  card
  [%give %fact ~[/graf-projections] %noun !>(projection)]
::
++  search-tree-card
  |=  tree=graf-search-tree:graf-sur
  ^-  card
  [%give %fact ~[/graf-search] %noun !>(tree)]
::
++  search-result-card
  |=  result=graf-search-result:graf-sur
  ^-  card
  [%give %fact ~[/graf-search] %noun !>(result)]
::
++  provenance-card
  |=  provenance=graf-provenance:graf-sur
  ^-  card
  [%give %fact ~[/graf-provenance] %noun !>(provenance)]
::
::
::
::
++  bachelor-output-card
  |=  output=graf-bachelor-output:graf-sur
  ^-  card
  [%give %fact ~[/graf-reduction] %noun !>(output)]
::
++  reduction-candidate-card
  |=  candidate=graf-reduction-candidate:graf-sur
  ^-  card
  [%give %fact ~[/graf-reduction] %noun !>(candidate)]
::
++  reduction-verdict-card
  |=  verdict=graf-reduction-verdict:graf-sur
  ^-  card
  [%give %fact ~[/graf-reduction] %noun !>(verdict)]
::
++  convergence-card
  |=  convergence=graf-convergence-record:graf-sur
  ^-  card
  [%give %fact ~[/graf-reduction] %noun !>(convergence)]
++  event-log-card
  |=  entry=graf-event-log-entry:graf-sur
  ^-  card
  [%give %fact ~[/graf-event-log] %noun !>(entry)]
++  task-card
  |=  task=graf-task:graf-sur
  ^-  card
  [%give %fact ~[/graf-tasks] %noun !>(task)]
::
++  task-result-card
  |=  result=graf-task-result:graf-sur
  ^-  card
  [%give %fact ~[/graf-tasks] %noun !>(result)]
++  bride-nets-card
  |=  nets=graf-bride-nets:graf-sur
  ^-  card
  [%give %fact ~[/graf-bride-nets] %noun !>(nets)]
::
++  bride-milky-way-card
  |=  milky-way=graf-bride-milky-way:graf-sur
  ^-  card
  [%give %fact ~[/graf-bride-milky-way] %noun !>(milky-way)]
::
++  bride-native-card
  |=  readiness=graf-native-readiness:graf-sur
  ^-  card
  [%give %fact ~[/graf-bride-native] %noun !>(readiness)]
::
++  action-name
  |=  act=graf-constitutional-action:graf-sur
  ^-  @tas
  ?-    -.act
      %seed-graph  %seed-graph
      %record-concept-node  %record-concept-node
      %record-relation-edge  %record-relation-edge
      %register-machine  %register-machine
      %issue-impulse  %issue-impulse
      %build-bundle  %build-bundle
      %record-governor  %record-governor
      %record-cast  %record-cast
      %record-trace  %record-trace
      %record-return  %record-return
      %record-sieve  %record-sieve
      %record-packet-state  %record-packet-state
      %record-seat-write  %record-seat-write
      %record-axis-write  %record-axis-write
      %record-ship-position  %record-ship-position
      %record-slice  %record-slice
      %record-traversal  %record-traversal
      %record-write-intent  %record-write-intent
      %record-residue  %record-residue
      %record-sieve-verdict  %record-sieve-verdict
      %record-continuation  %record-continuation
      %record-relation  %record-relation
      %record-projection  %record-projection
      %record-search-tree  %record-search-tree
      %record-search-result  %record-search-result
      %record-provenance  %record-provenance
      %record-proof-bundle  %record-proof-bundle
      %record-controlled-agency-proof-bundle  %record-controlled-agency-proof-bundle
      %submit-bachelor-output  %submit-bachelor-output
      %reduce-outputs  %reduce-outputs
      %record-reduction-verdict  %record-reduction-verdict
      %record-convergence  %record-convergence
      %record-event-log-entry  %record-event-log-entry
      %record-task  %record-task
      %record-task-result  %record-task-result
      %record-collaboration-crossing  %record-collaboration-crossing
      %record-bride-nets  %record-bride-nets
      %record-bride-milky-way  %record-bride-milky-way
      %bind-cantrip-session  %bind-cantrip-session
      %emit-cantrip-law  %emit-cantrip-law
  ==
::
++  action-meta
  |=  act=graf-constitutional-action:graf-sur
  ^-  dispatch-meta:graf-sur
  ?-    -.act
      %seed-graph  meta.act
      %record-concept-node  meta.act
      %record-relation-edge  meta.act
      %register-machine  meta.act
      %issue-impulse  meta.act
      %build-bundle  meta.act
      %record-governor  meta.act
      %record-cast  meta.act
      %record-trace  meta.act
      %record-return  meta.act
      %record-sieve  meta.act
      %record-packet-state  meta.act
      %record-seat-write  meta.act
      %record-axis-write  meta.act
      %record-ship-position  meta.act
      %record-slice  meta.act
      %record-traversal  meta.act
      %record-write-intent  meta.act
      %record-residue  meta.act
      %record-sieve-verdict  meta.act
      %record-continuation  meta.act
      %record-relation  meta.act
      %record-projection  meta.act
      %record-search-tree  meta.act
      %record-search-result  meta.act
      %record-provenance  meta.act
      %record-proof-bundle  meta.act
      %record-controlled-agency-proof-bundle  meta.act
      %submit-bachelor-output  meta.act
      %reduce-outputs  meta.act
      %record-reduction-verdict  meta.act
      %record-convergence  meta.act
      %record-event-log-entry  meta.act
      %record-task  meta.act
      %record-task-result  meta.act
      %record-collaboration-crossing  meta.act
      %record-bride-nets  meta.act
      %record-bride-milky-way  meta.act
      %bind-cantrip-session  meta.act
      %emit-cantrip-law  meta.act
  ==
::
++  receipt
  |=  [act=graf-constitutional-action:graf-sur accepted=? duplicate=?]
  ^-  dispatch-receipt:graf-sur
  =/  meta  (action-meta act)
  [ app=%graf
    action=(action-name act)
    batch-id=batch-id.meta
    batch-hash=batch-hash.meta
    source-slug=source-slug.meta
    dispatched-at=dispatched-at.meta
    idempotency-key=idempotency-key.meta
    sequence=sequence.meta
    accepted=accepted
    duplicate=duplicate
  ]
::
++  core-canon-approved
  |=  $:  core=graf-core-state
          act=graf-core-action:graf-sur
          our=@p
          src=@p
          now=@da
      ==
  ^-  ?
  ::  both engraving and retraction consult the governor.  The relation
  ::  is bound through a unit because `?|(?=(a) ?=(b))` does not refine,
  ::  so r.act must be reached inside a branch that does.
  =/  rel=(unit [src=* kind=@tas dst=*])
    ?:  ?=(%propose-canon -.act)  `r.act
    ?:  ?=(%decanonize -.act)     `r.act
    ~
  ?~  rel  %.n
  ?~  governor.core  %.n
  =/  fact=*  ?@(src.u.rel src.u.rel +.src.u.rel)
  =/  reputation=@ud  ~(wyt in (~(get ju attests.core) fact))
  =/  principal=?  =(our src)
  =/  pax=path
    :~  (scot %p our)
        u.governor.core
        (scot %da now)
        %law  %approve  (scot %ud (jam u.rel))
        (scot %ud reputation)  (scot %f principal)  %noun
    ==
  .^(? %gx pax)
::
++  weight-hypothesis-count
  |=  rows=(list *)
  ^-  @ud
  ?~  rows  0
  =/  found=(unit fact:wh)  (decode:wh i.rows)
  (add ?:(?=(^ found) 1 0) $(rows t.rows))
::
++  write-receipt-for
  |=  $:  act=graf-constitutional-action:graf-sur
          source-ship=@p
          accepted=?
          duplicate=?
          reason=@tas
          revision=@ud
          recorded-at=@da
      ==
  ^-  receipt:gwr
  =/  meta=dispatch-meta:graf-sur  (action-meta act)
  (make:gwrl idempotency-key.meta (action-name act) source-ship act accepted duplicate reason revision recorded-at)
::
++  note-write-receipt
  |=  $:  unified=graf-unified-state
          act=graf-constitutional-action:graf-sur
          source-ship=@p
          accepted=?
          duplicate=?
          reason=@tas
          recorded-at=@da
      ==
  ^-  graf-unified-state
  =/  item=receipt:gwr
    (write-receipt-for act source-ship accepted duplicate reason revision.control.unified recorded-at)
  unified(receipts (put:gwrl receipts.unified item))
::
++  write-receipt-reason
  |=  [act=graf-constitutional-action:graf-sur accepted=? duplicate=?]
  ^-  @tas
  ?:  duplicate  %duplicate
  ?:  accepted  %accepted
  ?+    -.act  %rejected
      %record-axis-write  %axis-write-unauthorized
      %record-relation  %controlled-agency-incompatible
      %record-search-tree  %search-refused
      %record-collaboration-crossing  %collaboration-refused
  ==
::  Graf records its own Board's territory events the way it records a feed's
::  (+place-structural under %graf-board, counted on that writer link).
++  record-board-event
  |=  [core=graf-core-state event=territory-event:gce]
  ^-  graf-core-state
  =/  placed
    (place-structural:gce territories.core facts.core plots.core %graf-board fact.event)
  %=  core
    facts  facts.placed
    plots  plots.placed
    writer-links  (bump-link:gce writer-links.core %graf-board status.placed)
  ==
::  On load, record every event still in the Board's outbox, oldest first.
::  A recorded event is an identical plot, so this is idempotent; only new
::  ones are counted.
++  record-board-outbox
  |=  [core=graf-core-state board=(unit board-shadow:gsv)]
  ^-  graf-core-state
  ?~  board  core
  =/  events=(list territory-event:gce)  (flop outbox.board.u.board)
  |-
  ?~  events  core
  =/  placed
    (place-structural:gce territories.core facts.core plots.core %graf-board fact.i.events)
  ?.  ?=(%accepted status.placed)  $(events t.events)
  $(events t.events, core (record-board-event core i.events))
--
::
%-  agent:re
%-  agent:rm
:-  %facts
%-  agent:gki
%-  agent:dbug
=|  state=current-state
^-  agent:gall
|_  =bowl:gall
+*  this  .
    def   ~(. (default-agent this %.n) bowl)
    set-graf  |=(next=graf-app-state this(state [%17 unified.state(graf next)]))
    set-core-write
      |=  next=graf-core-state
      =/  changed=?  !=(core.unified.state next)
      =/  next-control
        (record-write:gce control.unified.state changed)
      this(state [%17 unified.state(control next-control, core next)])
::
++  on-init
  ^-  (quip card _this)
  =/  unified=graf-unified-state
    [init-control:gce init:gce [~ 0 ~ 0 ~ 0 (lift-v10 (lift-v9 (lift-v8 [~ init-graf])))] *siev-shadow:gsv ~]
  =/  prepared  (prepare:gce our.bowl core.unified)
  :-  [http-bind-card:gce cards.prepared]
  this(state [%17 unified(core state.prepared)])
::
++  on-save
  ^-  vase
  !>(state)
::
++  on-load
  |=  old=vase
  ^-  (quip card _this)
  =/  current=(unit current-state)  ((soft current-state) q.old)
  =/  unified=graf-unified-state
    ?^  current
      ::  A same-version reload performs no state migration, so maintenance is
      ::  vacuous here.  Preserve the operator-selected mode: every desk
      ::  commit reloads this agent, and resetting to maintenance would accept
      ::  board writes while silently suppressing all their effects.
      unified.u.current
    ::  %16 -> %17: star-govern, override, and circulation-config move
    ::  from attic stashes to primary rings (operator direction, walk
    ::  R1a).  Rings start EMPTY -- nothing is invented for the past, the
    ::  attic keeps every historic record under the append-only ruling,
    ::  and the live cadence refills the working set in minutes.  This IS a
    ::  version migration, so control restarts into maintenance and the
    ::  operator thaw is the intended cost.
    =/  v16=(unit v16-state)  ((soft v16-state) q.old)
    ?^  v16
      :*  (restart-control:gce control.unified.u.v16)
          core.unified.u.v16
          [~ 0 ~ 0 ~ 0 graf.unified.u.v16]
          siev.unified.u.v16
          receipts.unified.u.v16
      ==
    ::  soft demands bit-exact mold round-trip; a semantically-%16 noun
    ::  that fails it must still migrate, not crash the reload (measured:
    ::  the %exit at the legacy !! was THIS, wiring walk R1a).  When the
    ::  head tag says %16, clam -- the total mold reshapes, never bails.
    ?:  ?=([%16 *] q.old)
      =/  u16  (graf-unified-state-v16 +.q.old)
      :*  (restart-control:gce control.u16)
          core.u16
          [~ 0 ~ 0 ~ 0 graf.u16]
          siev.u16
          receipts.u16
      ==
    ::  %15 -> %16: add the failure ring.  Every other field crosses by name
    ::  and the ring starts empty -- nothing is invented for the past.  This
    ::  IS a version migration, so control restarts into maintenance: the
    ::  freeze is the case the law actually protects, and an operator thaw
    ::  is the intended cost.
    =/  v15=(unit v15-state)  ((soft v15-state) q.old)
    ?^  v15
      :*  (restart-control:gce control.unified.u.v15)
          core.unified.u.v15
          [~ 0 ~ 0 ~ 0 (lift-v10 graf.unified.u.v15)]
          siev.unified.u.v15
          receipts.unified.u.v15
      ==
    ::  %14 -> %15: add the bounded write-receipt index without changing
    ::  constitutional law or importing transport acknowledgements as truth.
    =/  v14=(unit v14-state)  ((soft v14-state) q.old)
    ?^  v14
      :*  (restart-control:gce control.unified.u.v14)
          core.unified.u.v14
          [~ 0 ~ 0 ~ 0 (lift-v10 graf.unified.u.v14)]
          siev.unified.u.v14
          ~
      ==
    ::  %13 -> %15: every prior field crosses by name; the %siev shadow
    ::  starts empty (no board copy, no evidence import) until absorbed.
    =/  v13=(unit v13-state)  ((soft v13-state) q.old)
    ?^  v13
      :*  (restart-control:gce control.unified.u.v13)
          core.unified.u.v13
          [~ 0 ~ 0 ~ 0 (lift-v10 graf.unified.u.v13)]
          *siev-shadow:gsv
          ~
      ==
    ::  %12 -> %13: preserve the exact recall cache and add an empty component
    ::  evidence index.  It remains unused until explicitly rebaked.
    =/  v12=(unit v12-state)  ((soft v12-state) q.old)
    ?^  v12
      :*  (restart-control:gce control.unified.u.v12)
          (upgrade-v5:gce core.unified.u.v12)
          [~ 0 ~ 0 ~ 0 (lift-v10 graf.unified.u.v12)]
          *siev-shadow:gsv
          ~
      ==
    ::  %11 -> %13: both caches start empty; every prior field crosses by name.
    =/  v11=(unit v11-state)  ((soft v11-state) q.old)
    ?^  v11
      :*  (restart-control:gce control.unified.u.v11)
          (upgrade-v4:gce core.unified.u.v11)
          [~ 0 ~ 0 ~ 0 (lift-v10 graf.unified.u.v11)]
          *siev-shadow:gsv
          ~
      ==
    =/  previous=(unit previous-current-state)
      ((soft previous-current-state) q.old)
    ?^  previous
      [upgrade-control:gce (upgrade-v4:gce core.unified.u.previous) [~ 0 ~ 0 ~ 0 (lift-v10 graf.unified.u.previous)] *siev-shadow:gsv ~]
    =/  legacy=(unit legacy-versioned-state)
      ((soft legacy-versioned-state) q.old)
    ?~  legacy  !!
    [upgrade-control:gce init:gce [~ 0 ~ 0 ~ 0 (lift-v10 (current-graf u.legacy))] *siev-shadow:gsv ~]
  ::  Authority normalization is maintenance, not a write.  It must run even
  ::  while snapshot control is frozen; the freeze still suppresses watches
  ::  and every ordinary mutation below.
  =.  core.unified  (normalize-state:gce core.unified)
  ?.  (writes-open:gce control.unified)
    [[http-bind-card:gce ~] this(state [%17 unified])]
  =/  prepared  (prepare:gce our.bowl core.unified)
  =/  recorded  (record-board-outbox state.prepared board.siev.unified)
  [(weld [http-bind-card:gce ~] cards.prepared) this(state [%17 unified(core recorded)])]
::
++  on-poke
  |=  [=mark =vase]
  ^-  (quip card _this)
  ::  star-govern observations are typed, expiring facts in the existing
  ::  attic.  Keeping them out of the circulation input prevents the
  ::  governor from training its next verdict on its previous verdict.
  ?:  ?&(=(mark %noun) ?=([%record-star-govern *] q.vase))
    ?.  =(our.bowl src.bowl)
      ~&  >>  [%graf %star-govern-record-refused src=src.bowl]
      `this
    =/  decoded=(unit verdict:sg)
      ((soft verdict:sg) +.q.vase)
    ?~  decoded
      ~|([%graf %invalid-star-govern-record] !!)
    =/  record=verdict:sg  u.decoded
    ?.  ?&  =(source.record our.bowl)
            (gth window-size.record 0)
            (lte window-size.record max-circulation)
            (gth samples.record 0)
            (lte samples.record window-size.record)
            (gth expires-at.record observed-at.record)
        ==
      ~|([%graf %invalid-star-govern-record-fields verdict-id.record] !!)
    =/  control  control.unified.state
    ?.  (writes-open:gce control)
      =/  blocked  (block-write:gce control)
      `this(state [%17 unified.state(control blocked)])
    =/  graf  graf.unified.state
    =/  full=(list verdict:sg)  [record sg-ring.graf]
    =/  shed  (slag primary-ring-cap full)
    =/  recorded=graf-app-state
      %=  graf
        sg-ring     (scag primary-ring-cap full)
        sg-stashed  (add sg-stashed.graf (lent shed))
        attic       (stash:graf-attic attic.graf %star-govern shed)
      ==
    =/  changed=?  !=(graf recorded)
    =/  next-control  (record-write:gce control changed)
    `this(state [%17 unified.state(control next-control, graf recorded)])
  ::  Overrides are star-visible facts, never a boolean buried in cantrip.
  ::  Graf admits only the local operator, a nonempty reason, and the exact
  ::  current unexpired verdict id.  A member cannot mint a different verdict
  ::  or attach an override to a stale one through this route.
  ?:  ?&(=(mark %noun) ?=([%record-star-govern-override *] q.vase))
    ?.  =(our.bowl src.bowl)
      ~&  >>  [%graf %star-govern-override-refused src=src.bowl]
      `this
    =/  decoded=(unit override:sg)
      ((soft override:sg) +.q.vase)
    ?~  decoded
      ~|([%graf %invalid-star-govern-override] !!)
    =/  override=override:sg  u.decoded
    =/  current=read:sg  (star-govern-read graf.unified.state now.bowl)
    ?.  ?=([%signal *] current)
      ~|([%graf %override-without-current-verdict] !!)
    ?.  ?&  =(actor.override our.bowl)
            =(verdict-id.override verdict-id.record.current)
            (gth (met 3 reason.override) 0)
            (lte recorded-at.override now.bowl)
        ==
      ~|([%graf %invalid-star-govern-override-fields override-id.override] !!)
    =/  control  control.unified.state
    ?.  (writes-open:gce control)
      =/  blocked  (block-write:gce control)
      `this(state [%17 unified.state(control blocked)])
    =/  graf  graf.unified.state
    =/  full=(list override:sg)  [override sgo-ring.graf]
    =/  shed  (slag primary-ring-cap full)
    =/  recorded=graf-app-state
      %=  graf
        sgo-ring     (scag primary-ring-cap full)
        sgo-stashed  (add sgo-stashed.graf (lent shed))
        attic        (stash:graf-attic attic.graf %star-govern-override shed)
      ==
    =/  changed=?  !=(graf recorded)
    =/  next-control  (record-write:gce control changed)
    `this(state [%17 unified.state(control next-control, graf recorded)])
  ::  The circulation cap is operator state, not a compile-time constant.
  ::  Shrinking it archives the displaced tail through the same attic path
  ::  used by ordinary ring overflow; raising it affects future writes only.
  ?:  ?&(=(mark %noun) ?=([%set-circulation-limit @] q.vase))
    ?.  =(our.bowl src.bowl)
      ~&  >>  [%graf %circulation-config-refused src=src.bowl]
      `this
    =/  req  !<([tag=@tas limit=@ud] vase)
    ?:  ?|(=(0 limit.req) (gth limit.req max-configured-circulation))
      ~|([%graf %invalid-circulation-limit limit.req] !!)
    =/  control  control.unified.state
    ?.  (writes-open:gce control)
      =/  blocked  (block-write:gce control)
      `this(state [%17 unified.state(control blocked)])
    =/  graf  graf.unified.state
    =/  record=circulation-config-record
      [%graf-circulation-config-v1 limit.req now.bowl]
    =/  cfg-full=(list circulation-config-record)  [record cfg-ring.graf]
    =/  cfg-shed  (slag primary-ring-cap cfg-full)
    =/  configured=graf-app-state
      %=  graf
        cfg-ring     (scag primary-ring-cap cfg-full)
        cfg-stashed  (add cfg-stashed.graf (lent cfg-shed))
        attic        (stash:graf-attic attic.graf %circulation-config cfg-shed)
      ==
    =/  compacted
      =/  stashed
        (overflow configured %circulation (slag limit.req circulation.configured))
      stashed(circulation (scag limit.req circulation.configured))
    =/  changed=?  !=(graf compacted)
    =/  next-control  (record-write:gce control changed)
    `this(state [%17 unified.state(control next-control, graf compacted)])
  ::  connclose readback (lib/graf-clinamen): gall %gx peeks return null over
  ::  conn on the connclose vere, so a %noun [%clinamen-export q k] poke makes
  ::  graf compute the SAME swerve the /x/clinamen peek computes and land it in
  ::  clay, where conn-peek CAN read it.  The %repair-export pattern.
  ::  EXTERNAL REPORTERS.  A failure that happens OUTSIDE graf -- a law that
  ::  fails to build, a proof returning a nonzero fail count, a landing that
  ::  aborts -- files here.  No new mark and no new constitutional action, so
  ::  reporting costs a caller one poke.  Self and our own moons only: a
  ::  failure log any ship may write is a place to hide, not a record.
  ?:  ?&(=(mark %noun) ?=([%note-failure *] q.vase))
    ?.  ?|(=(our.bowl src.bowl) =(our.bowl (^sein:title src.bowl)))
      ~|([%graf %note-failure-refused src=src.bowl] !!)
    =/  entry=(unit graf-failure)  ((soft graf-failure) +.q.vase)
    ?~  entry  `this
    `(set-graf (note-failure graf.unified.state u.entry))
  ?:  ?&(=(mark %noun) ?=([%clinamen-export @ @] q.vase))
    ::  Operator readback only: conn.sock speaks AS the ship, so self is the
    ::  whole audience.  Ungated, this arm let ANY poking ship land a clay
    ::  write in %base and drive an attacker-chosen edit-distance walk over
    ::  every node name.  writes-open is deliberately NOT consulted here: this
    ::  branch mutates no graf state, and a diagnostic must still answer while
    ::  writes are blocked.
    ::  rule 12: a silent refusal explains nothing.  Say who was turned
    ::  away, without bailing -- a crash here would make a foreign poke
    ::  into a denial-of-service surface.
    ?.  =(our.bowl src.bowl)
      ~&  >>  [%graf %clinamen-export-refused src=src.bowl]
      `this
    =/  req  !<([tag=@tas q=@t k=@ud] vase)
    =/  graf  graf.unified.state
    =/  names=(set *)
      %-  ~(gas in *(set *))
      (turn nodes.graph.graf |=(n=concept-node:graf-sur `*`name.n))
    =/  swerve  (clinamen:graf-clinamen names q.req k.req *(set *))
    :_  this
    :~  :*  %pass  /clinamen-export  %arvo  %c
        [%info %base %& ~[[/clinamen-export/noun %ins %noun !>([q.req k.req swerve])]]]
    ==  ==
  ::  Viki's result, answer/refusal index, and thread link are one durable
  ::  transaction.  A transport ACK is not the receipt: only this branch's
  ::  explicit %landed card authorizes Viki to clear its pending result.
  ?:  =(%viki-landing mark)
    =/  action  !<(action:vl vase)
    ?.  ?=(%land -.action)  `this
    ?.  =(our.bowl src.bowl)  `this
    =/  control  control.unified.state
    ?.  (writes-open:gce control)  `this
    =/  item=landing:vl  landing.action
    =/  core  core.unified.state
    =/  expected=rel:vl  (terminal-rel:vl item)
    =/  slot=(set rel:vl)
      (slot-of:graf-relations tiers.core %viki)
    ?:  (viki-terminal-conflict slot expected)
      `this
    =/  next-core
      %=  core
        facts  (light:graf-substrate facts.core (fact-of:vl item))
        tiers  (publish-viki-rels tiers.core (relations:vl item))
      ==
    ::  FLATTENED LANDING (incident ptf-484): no callback poke — the
    ::  positive ack of THIS poke is Viki's completion signal.  The
    ::  %viki-landed hop added a duct layer that every pier-killing
    ::  trace ran through, and carried nothing Viki could not derive.
    ?:  =(core next-core)
      `this
    =/  next-control
      (record-write:gce control %.y)
    `this(state [%17 unified.state(control next-control, core next-core)])
  ::  Graf hosts the Board law natively (the donor %siev holds no board since
  ::  2026-10-20).  Same ship gate as the donor authority.  Each accepted
  ::  territory event is RECORDED here, under %graf-board, exactly as a feed's
  ::  event is (+place-structural); the kernel's bounded outbox keeps it too.
  ::  Zero cards: nothing leaves graf.
  ?:  ?=(%graf-board-action mark)
    ?.  ?|(=(our.bowl src.bowl) =(our.bowl (^sein:title src.bowl)))
      `this
    ?.  (writes-open:gce control.unified.state)
      =/  blocked  (block-write:gce control.unified.state)
      `this(state [%17 unified.state(control blocked)])
    =/  act=(unit board-action:gb)  ((soft board-action:gb) q.vase)
    ?~  act  `this
    =/  sh=board-shadow:gsv
      ?~(board.siev.unified.state initial:gbs u.board.siev.unified.state)
    =/  moved  (transition:gbs sh u.act src.bowl our.bowl bowl)
    =/  boarded  unified.state(siev siev.unified.state(board `sh.moved))
    ?~  event.moved  `this(state [%17 boarded])
    =/  recorded  (record-board-event core.boarded u.event.moved)
    =/  next-control  (record-write:gce control.boarded !=(core.boarded recorded))
    `this(state [%17 boarded(control next-control, core recorded)])
  ::  siev absorption (evidence): the exact fingerprint-bound donor snapshot,
  ::  imported once by the resident principal.  A replay of the identical
  ::  snapshot is inert; a conflicting snapshot refuses; history is retained,
  ::  never evaluated.
  ?:  ?=(%graf-siev-evidence mark)
    ?.  =(our.bowl src.bowl)
      `this
    ?.  (writes-open:gce control.unified.state)
      =/  blocked  (block-write:gce control.unified.state)
      `this(state [%17 unified.state(control blocked)])
    =/  act=(unit evidence-action:gsv)  ((soft evidence-action:gsv) q.vase)
    ?~  act  `this
    =/  res=result:gse
      (import:gse evidence.siev.unified.state snapshot.u.act our.bowl now.bowl)
    ?.  ok.receipt.res  `this
    `this(state [%17 unified.state(siev siev.unified.state(evidence evidence.res))])
  ::  Canonical Graf now owns the Core HTTP surface as well as both action
  ::  families.  The bind card targets %graf, never the donor app.
  ?:  ?=(%handle-http-request mark)
    =+  !<([id=@ta req=inbound-request:eyre] vase)
    ::  W-HR/S103.52: the record is not a LAN broadcast.  Unauthenticated
    ::  callers get 403 and nothing else; only the authed session (the
    ::  same gate portal trusts) may read the store over HTTP, and only as
    ::  this ship: a poke claiming `authenticated` from anyone else is refused.
    ?.  &(authenticated.req =(src.bowl our.bowl))
      =/  rpath=path  /http-response/[id]
      :_  this
      :~  [%give %fact ~[rpath] %http-response-header !>(`response-header:http`[403 ~[['content-type' 'text/plain']]])]
          [%give %fact ~[rpath] %http-response-data !>(`(unit octs)``(as-octs:mimes:html 'forbidden'))]
          [%give %kick ~[rpath] ~]
      ==
    =/  core  core.unified.state
    =/  url=@t  url.request.req
    =/  base=tape  (trip url)
    =/  cut=tape
      =/  q  (find "?" base)
      ?~(q base (scag u.q base))
    =/  pax=path
      =/  p  (rush (crip cut) stap)
      ?~(p / u.p)
    =/  sub=path  ?:(?=([%graf *] pax) t.pax pax)
    =/  jon=json  (handle:graf-http facts.core sub)
    =/  data=octs  (as-octs:mimes:html (en:json:html jon))
    =/  rpath=path  /http-response/[id]
    :_  this
    :~  [%give %fact ~[rpath] %http-response-header !>(`response-header:http`[200 ~[['content-type' 'application/json']]])]
        [%give %fact ~[rpath] %http-response-data !>(`(unit octs)``data)]
        [%give %kick ~[rpath] ~]
    ==
  ?:  ?=(%graf-snapshot-action mark)
    =/  maybe-snapshot=(unit snapshot-action)
      ((soft snapshot-action) q.vase)
    ?~  maybe-snapshot
      `this
    =/  control  control.unified.state
    ?.  (snapshot-authorized:gce our.bowl src.bowl)
      =/  denied
        (note-result:gce control (snapshot-action-name:gce u.maybe-snapshot) %.n %snapshot-operator-law ~)
      `this(state [%17 unified.state(control denied)])
    =/  applied
      %-  apply-snapshot:gce
      :*  control
          core.unified.state
          u.maybe-snapshot
          our.bowl
          %graf
          now.bowl
          %graf-core
      ==
    :-  cards.applied
    this(state [%17 unified.state(control control.applied, core state.applied)])
  =/  maybe-core=(unit graf-core-action:graf-sur)
    ?:(?=(%graf-action mark) ((soft graf-core-action:graf-sur) q.vase) ~)
  ?^  maybe-core
    =/  control  control.unified.state
    =/  core  core.unified.state
    =/  source-authorized
      (core-source-authorized:gce core our.bowl src.bowl)
    =/  approved
      ?:(source-authorized (core-canon-approved core u.maybe-core our.bowl src.bowl now.bowl) %.n)
    =/  authorization
      (authorize:gce core u.maybe-core [our.bowl src.bowl now.bowl approved])
    ?.  accepted.authorization
      =/  denied
        (note-result:gce control -.u.maybe-core %.n reason.authorization ~)
      `this(state [%17 unified.state(control denied)])
    ?.  (writes-open:gce control)
      =/  blocked  (block-write:gce control)
      `this(state [%17 unified.state(control blocked)])
    =/  applied
      (apply:gce core u.maybe-core [our.bowl src.bowl now.bowl approved])
    =/  changed=?  !=(core state.applied)
    =/  next-control  (record-write:gce control changed)
    :-  cards.applied
    this(state [%17 unified.state(control next-control, core state.applied)])
  =/  maybe-act  (parse-action mark vase)
  ?~  maybe-act
    `this
  =/  act  u.maybe-act
  =/  write-control  control.unified.state
  ::  legacy mutations remain self-or-moon only, even for Core-attached ships
  ?.  (legacy-authorized:gce our.bowl src.bowl)
    =/  denied
      (note-result:gce write-control (action-name act) %.n %legacy-source-law ~)
    =/  next=graf-unified-state  unified.state(control denied)
    =.  next
      (note-write-receipt next act src.bowl %.n %.n %legacy-source-law now.bowl)
    `this(state [%17 next])
  ::  SEAT CLAIMS ARE VIKI'S.  Ruled 2026-08-16: viki keeps track of the
  ::  seats, and viki is where the moon-grants live.  So a moon may not
  ::  claim a graf seat directly -- it asks viki, viki checks the lease it
  ::  already holds, and viki records the claim from this ship.
  ::
  ::  MEASURED before this guard existed (ted/ph/graf-seat-claim-measure):
  ::  any ship in the sponsorship family could take any seat and lock out
  ::  its holder, forging nothing, because %record-seat-write had no
  ::  per-seat check at all while %record-axis-write had one.
  ::
  ::  Deliberately NOT a grant cache in graf's state.  Holding a copy of
  ::  viki's leases here would be a second site for a mature model and a
  ::  state migration on a live agent; keeping the authority where the
  ::  grants are is both smaller and more honest.
  ?:  ?&(?=(%record-seat-write -.act) !=(our.bowl src.bowl))
    =/  denied
      (note-result:gce write-control (action-name act) %.n %seat-claim-not-self ~)
    =/  next=graf-unified-state  unified.state(control denied)
    =.  next
      (note-write-receipt next act src.bowl %.n %.n %seat-claim-not-self now.bowl)
    `this(state [%17 next])
  ::  A FOREIGN AXIS WRITE MUST NAME ITS OWN SENDER.
  ::
  ::  MEASURED 2026-08-16 across two real ships: a moon wrote the PLANET's
  ::  seat region by copying that seat's root/seat/session/lease/ship into
  ::  its own axis write.  +seat-write-authorizes-axis:gal compares the
  ::  write's CLAIMED fields against the seat write, and every one of those
  ::  fields is published by graf's own /x/seat peeks -- so the forgery is a read
  ::  and a copy.  The landed write carried assigned-ship-id
  ::  '~sampel-palnet' and value 'moon-value'.
  ::
  ::  Exactly the seat-claim hole one level down: the gate was working
  ::  correctly against a claim nothing AUTHENTICATED.  Ames already knows
  ::  who sent this; the law just never asked.
  ::
  ::  The host is exempt because it is the principal and legitimately
  ::  writes on behalf of seats it grants -- the same asymmetry the seat
  ::  guard above relies on.
  ?:  ?&  ?=(%record-axis-write -.act)
          !(axis-write-sender-authorized:gal proof.act src.bowl our.bowl)
      ==
    =/  denied
      (note-result:gce write-control (action-name act) %.n %axis-write-not-sender ~)
    =/  next=graf-unified-state  unified.state(control denied)
    =.  next
      (note-write-receipt next act src.bowl %.n %.n %axis-write-not-sender now.bowl)
    `this(state [%17 next])
  ::  AND A FOREIGN CIRCULATION FACT MUST NAME A SEAT ITS SENDER HOLDS.
  ::
  ::  MEASURED 2026-08-16: the moon recorded a fact with actor %flunky --
  ::  the planet's seat -- and it landed.  circulation-fact.actor is a
  ::  seat by convention and was bound to nothing, and the activity page
  ::  is built from exactly these facts, so the page could be made to lie
  ::  about who did what.  Attribution is the whole point of that view.
  ?:  ?&  ?=(?(%record-cast %record-trace %record-return %record-sieve) -.act)
          ?!  %:  circulation-actor-authorized:gal
                seat-writes.graf.unified.state
                actor.fact.act
                src.bowl
                our.bowl
              ==
      ==
    =/  denied
      (note-result:gce write-control (action-name act) %.n %actor-not-held ~)
    =/  next=graf-unified-state  unified.state(control denied)
    =.  next
      (note-write-receipt next act src.bowl %.n %.n %actor-not-held now.bowl)
    `this(state [%17 next])
  ?.  (writes-open:gce write-control)
    =/  blocked  (block-write:gce write-control)
    =/  next=graf-unified-state  unified.state(control blocked)
    =.  next
      (note-write-receipt next act src.bowl %.n %.n %mode-blocked now.bowl)
    `this(state [%17 next])
  =/  graf  graf.unified.state
  =/  active-config=circulation-config-record
    (circulation-config graf)
  =/  circulation-limit  limit.active-config
  =/  meta  (action-meta act)
  ::  a replay is a burned key (128-key cursor window) OR a primary
  ::  record whose graf-minted content hash equals the newest mint for
  ::  the same handle — so exact-content replays dedup even after the
  ::  key window has rolled past
  =/  duplicate
    ?:  (seen-key recent-keys.graf idempotency-key.meta)  &
    =/  primary  (action-record act)
    ?~  primary  |
    =/  known  (find-mint mints.graf id.handle.u.primary)
    ?~  known  |
    ?&  (same-handle handle.u.known handle.u.primary)
        =(mint.u.known (mint-hash record.u.primary))
    ==
  ?:  duplicate
    ::  a replayed key still receipts (readbacks poll /x/dispatch/latest)
    ::  but must not claim fresh processing via runtime-status or mint.
    ::  the replayed payload is stashed, not judged: if it differed from
    ::  the original, the attic holds the evidence.
    =/  dup-graf  (overflow graf %replayed-actions ~[`*`act])
    =/  dup-graf  dup-graf(last-dispatch `(receipt act %.y %.y))
    =/  next=graf-unified-state  unified.state(graf dup-graf)
    =.  next
      (note-write-receipt next act src.bowl %.y %.y %duplicate now.bowl)
    `this(state [%17 next])
  ::  every processed action updates runtime-status; give it on the
  ::  /graf-runtime path the watch manifest has always advertised
  ::  (subscribers starved before this wrapper)
  =^  cards=(list card)  this
  ?-    -.act
      %seed-graph
    =/  new-graf  (remember-key graf idempotency-key.meta)
    ::  archive the replaced graph: wholesale replace never destroys
    =.  new-graf  (overflow new-graf %graph-seeds ~[`*`graph.new-graf])
    =/  updated  new-graf(graph graph.act)
    =/  final  (finalize-graf updated act %.y %.n)
    [~ (set-graf final)]
  ::
      %record-concept-node
    =/  new-graf  (add-concept-node graf node.act)
    =/  updated  (remember-key new-graf idempotency-key.meta)
    =/  final  (finalize-graf updated act %.y %.n)
    [~ (set-graf final)]
  ::
      %record-relation-edge
    =/  new-graf  (add-relation-edge graf edge.act)
    =/  updated  (remember-key new-graf idempotency-key.meta)
    =/  final  (finalize-graf updated act %.y %.n)
    [~ (set-graf final)]
  ::
      %register-machine
    =/  new-graf  (remember-key graf idempotency-key.meta)
    ::  archive the replaced topology: wholesale replace never destroys
    =.  new-graf  (overflow new-graf %machine-topologies ~[`*`machine.new-graf])
    =/  updated  new-graf(machine machine.act)
    =/  final  (finalize-graf updated act %.y %.n)
    :_  (set-graf final)
    ~[(machine-card machine.act)]
  ::
      %issue-impulse
    =/  new-graf  (add-impulse graf impulse.act)
    =/  updated  (remember-key new-graf idempotency-key.meta)
    =/  final  (finalize-graf updated act %.y %.n)
    [~ (set-graf final)]
  ::
      %build-bundle
    =/  new-graf  (add-bundle graf bundle.act)
    =/  updated  (remember-key new-graf idempotency-key.meta)
    =/  final  (finalize-graf updated act %.y %.n)
    :_  (set-graf final)
    ~[(bundle-card bundle.act)]
  ::
      %record-governor
    =/  new-graf  (remember-key graf idempotency-key.meta)
    ::  governor records are facts, not cursors: ring + attic, with
    ::  last-governor kept as the moving pointer
    =/  full  (weld ~[governor.act] governors.new-graf)
    =.  new-graf  (overflow new-graf %governors (slag max-flow full))
    =/  updated
      new-graf(governors (scag max-flow full), last-governor `governor.act)
    =/  final  (finalize-graf updated act %.y %.n)
    :_  (set-graf final)
    ~[(governor-card governor.act)]
  ::
      %record-cast
    =/  new-graf  (add-circulation graf fact.act circulation-limit)
    =/  updated  (remember-key new-graf idempotency-key.meta)
    =/  final  (finalize-graf updated act %.y %.n)
    :_  (set-graf final)
    ~[(circulation-card fact.act)]
  ::
      %record-trace
    =/  new-graf  (add-circulation graf fact.act circulation-limit)
    =/  updated  (remember-key new-graf idempotency-key.meta)
    =/  final  (finalize-graf updated act %.y %.n)
    :_  (set-graf final)
    ~[(circulation-card fact.act)]
  ::
      %record-return
    =/  new-graf  (add-circulation graf fact.act circulation-limit)
    =/  updated  (remember-key new-graf idempotency-key.meta)
    =/  final  (finalize-graf updated act %.y %.n)
    :_  (set-graf final)
    ~[(circulation-card fact.act)]
  ::
      %record-sieve
    =/  new-graf  (add-circulation graf fact.act circulation-limit)
    =/  updated  (remember-key new-graf idempotency-key.meta)
    =/  final  (finalize-graf updated act %.y %.n)
    :_  (set-graf final)
    ~[(circulation-card fact.act)]
  ::
      %record-packet-state
    =/  new-graf  (add-packet graf proof.act)
    =/  handled  (remember-handle new-graf handle.proof.act)
    =/  updated  (remember-key handled idempotency-key.meta)
    =/  final  (finalize-graf updated act %.y %.n)
    :_  (set-graf final)
    ~[(packet-card proof.act)]
  ::
      %record-seat-write
    =/  new-graf  (add-seat-write graf proof.act)
    =/  handled  (remember-handle new-graf handle.proof.act)
    =/  maybe-position  (make-ship-position meta proof.act)
    =/  positioned
      ?~  maybe-position
        handled
      (remember-handle (add-ship-position handled u.maybe-position) handle.u.maybe-position)
    =/  updated  (remember-key positioned idempotency-key.meta)
    =/  final  (finalize-graf updated act %.y %.n)
    :_  (set-graf final)
    ?~  maybe-position
      ~[(root-card (summarize-root final)) (seat-write-card proof.act)]
    ~[(root-card (summarize-root final)) (seat-write-card proof.act) (ship-position-card u.maybe-position)]
  ::
      %record-axis-write
    ?:  (axis-write-authorized graf proof.act)
      =/  new-graf  (add-axis-write graf proof.act)
      =/  handled  (remember-handle new-graf handle.proof.act)
      =/  updated  (remember-key handled idempotency-key.meta)
      =/  final  (finalize-graf updated act %.y %.n)
      :_  (set-graf final)
      ~[(root-card (summarize-root final)) (axis-write-card proof.act)]
    ::  unauthorized axis writes are refused durably: stash the evidence
    =/  rejected  (overflow graf %rejected-actions ~[`*`act])
    =/  final  (finalize-graf rejected act %.n %.n)
    [~ (set-graf final)]
  ::
      %record-ship-position
    =/  new-graf  (add-ship-position graf proof.act)
    =/  handled  (remember-handle new-graf handle.proof.act)
    =/  updated  (remember-key handled idempotency-key.meta)
    =/  final  (finalize-graf updated act %.y %.n)
    :_  (set-graf final)
    ~[(ship-position-card proof.act)]
  ::
      %record-slice
    =/  new-graf  (remember-key graf idempotency-key.meta)
    =/  handled  (remember-handle new-graf handle.proof.act)
    =/  full  (weld ~[proof.act] slices.handled)
    =.  handled  (overflow handled %slices (slag max-flow full))
    =/  updated  handled(slices (scag max-flow full), last-slice `proof.act)
    =/  final  (finalize-graf updated act %.y %.n)
    :_  (set-graf final)
    ~[(slice-card proof.act)]
  ::
      %record-traversal
    =/  new-graf  (remember-key graf idempotency-key.meta)
    =/  handled  (remember-handle new-graf handle.proof.act)
    =/  full  (weld ~[proof.act] traversals.handled)
    =.  handled  (overflow handled %traversals (slag max-flow full))
    =/  updated  handled(traversals (scag max-flow full), last-traversal `proof.act)
    =/  final  (finalize-graf updated act %.y %.n)
    :_  (set-graf final)
    ~[(traversal-card proof.act)]
  ::
      %record-write-intent
    =/  new-graf  (remember-key graf idempotency-key.meta)
    =/  handled  (remember-handle new-graf handle.proof.act)
    =/  full  (weld ~[proof.act] write-intents.handled)
    =.  handled  (overflow handled %write-intents (slag max-flow full))
    =/  updated  handled(write-intents (scag max-flow full), last-write-intent `proof.act)
    =/  final  (finalize-graf updated act %.y %.n)
    :_  (set-graf final)
    ~[(write-intent-card proof.act)]
  ::
      %record-residue
    =/  new-graf  (remember-key graf idempotency-key.meta)
    =/  handled  (remember-handle new-graf handle.proof.act)
    =/  full  (weld ~[proof.act] residues.handled)
    =.  handled  (overflow handled %residues (slag max-flow full))
    =/  updated  handled(residues (scag max-flow full), last-residue `proof.act)
    =/  final  (finalize-graf updated act %.y %.n)
    :_  (set-graf final)
    ~[(residue-card proof.act)]
  ::
      %record-sieve-verdict
    =/  new-graf  (remember-key graf idempotency-key.meta)
    =/  handled  (remember-handle new-graf handle.proof.act)
    =/  full  (weld ~[proof.act] sieve-verdicts.handled)
    =.  handled  (overflow handled %sieve-verdicts (slag max-flow full))
    =/  updated  handled(sieve-verdicts (scag max-flow full), last-sieve-verdict `proof.act)
    =/  final  (finalize-graf updated act %.y %.n)
    :_  (set-graf final)
    ~[(sieve-verdict-card proof.act)]
  ::
      %record-continuation
    =/  new-graf  (remember-key graf idempotency-key.meta)
    =/  handled  (remember-handle new-graf handle.proof.act)
    =/  full  (weld ~[proof.act] continuations.handled)
    =.  handled  (overflow handled %continuations (slag max-flow full))
    =/  updated  handled(continuations (scag max-flow full), last-continuation `proof.act)
    =/  final  (finalize-graf updated act %.y %.n)
    :_  (set-graf final)
    ~[(continuation-card proof.act)]
  ::
      %record-relation
    ?.  (controlled-agency-relation-compatible proof.act)
      ::  do not burn the idempotency key on a reject: a corrected resend
      ::  with the same key must be applied, not swallowed as a duplicate.
      ::  the refusal itself is durable evidence — stash the rejected act.
      =/  rejected  (overflow graf %rejected-actions ~[`*`act])
      =/  final  (finalize-graf rejected act %.n %.n)
      [~ (set-graf final)]
    =/  new-graf  (add-relation graf proof.act)
    =/  handled  (remember-handle (remember-handle (remember-handle new-graf handle.proof.act) source.proof.act) target.proof.act)
    =/  updated  (remember-key handled idempotency-key.meta)
    =/  final  (finalize-graf updated act %.y %.n)
    :_  (set-graf final)
    ~[(relation-card proof.act)]
  ::
      %record-projection
    =/  new-graf  (add-projection graf proof.act)
    =/  handled  (remember-handle (remember-handle new-graf handle.proof.act) source.proof.act)
    =/  updated  (remember-key handled idempotency-key.meta)
    =/  final  (finalize-graf updated act %.y %.n)
    :_  (set-graf final)
    ~[(projection-card proof.act)]
  ::
      %record-search-tree
    ::  The outer on-poke gate has already authenticated src.bowl as this ship
    ::  or one of its moons.  Search is therefore an authority-bearing Gall
    ::  action, not a public reducer.  Reject hostile query size before storing
    ::  the tree or constructing an automaton.
    ?.  (search-input-safe proof.act)
      =/  rejected  (overflow graf %rejected-actions ~[`*`act])
      =/  final  (finalize-graf rejected act %.n %.n)
      [~ (set-graf final)]
    ::  Graf answers the query at write time.  The active rings are finite by
    ::  state law; the attic is consumed by page:graf-attic under the SAME
    ::  record budget, including bounded epoch-header work.  No records-for
    ::  materialization occurs on this execution path.
    =/  terms=(list @t)
      (weld match-terms.proof.act match-tags.proof.act)
    =/  want
      |=  fam=@tas
      ?|  =(~ match-domains.proof.act)
          (lien match-domains.proof.act |=(d=@tas =(d fam)))
      ==
    =/  active=(list search-candidate)
    ;:  weld
      ?.((want %relations) ~ (turn relations.graf |=(r=graf-relation:graf-sur [handle.r `*`r])))
      ?.((want %provenances) ~ (turn provenances.graf |=(p=graf-provenance:graf-sur [handle.p `*`p])))
      ?.((want %proof-bundles) ~ (turn proof-bundles.graf |=(b=graf-proof-bundle:graf-sur [handle.b `*`b])))
      ?.((want %packets) ~ (turn packets.graf |=(p=graf-packet:graf-sur [handle.p `*`p])))
      ?.((want %event-log) ~ (turn event-log.graf |=(e=graf-event-log-entry:graf-sur [handle.e `*`e])))
      ?.((want %tasks) ~ (turn tasks.graf |=(t=graf-task:graf-sur [handle.t `*`t])))
      ?.((want %seat-writes) ~ (turn seat-writes.graf |=(s=graf-seat-write:graf-sur [handle.s `*`s])))
      ?.((want %axis-writes) ~ (turn axis-writes.graf |=(a=graf-axis-write:graf-sur [handle.a `*`a])))
    ==
    =/  budget  ?:(=(0 budget.proof.act) 64 budget.proof.act)
    =/  active-scan=(list search-candidate)  (scag budget active)
    =/  active-exhausted=?  =((lent active-scan) (lent active))
    =/  remaining=@ud  (sub budget (lent active-scan))
    =/  archive-page=attic-page:graf-attic
      ?:  active-exhausted
        (page:graf-attic attic.graf (search-attic-families match-domains.proof.act) remaining)
      [~ 0 0 %.n %.y]
    =/  archived
      (attic-search-candidates records.archive-page)
    ::  A corrupt epoch, oversized legacy blob, selector overflow, or erased
    ::  noun that does not cast to its declared family refuses the action.
    ?.  &(safe.archive-page safe.archived)
      =/  rejected  (overflow graf %rejected-actions ~[`*`act])
      =/  final  (finalize-graf rejected act %.n %.n)
      [~ (set-graf final)]
    =/  scan=(list search-candidate)
      (weld active-scan candidates.archived)
    =/  found
      ?~  terms  ~
      ?:  =(%exact tree-kind.proof.act)
        =/  tset  (~(gas in *(set @t)) terms)
        (skim scan |=(candidate=search-candidate (leaf-mentions:graf-ac tset n.candidate)))
      =/  eng  (build-str:graf-ac terms)
      (skim scan |=(candidate=search-candidate (term-mentions:graf-ac eng n.candidate)))
    ::  supersession can put the same handle in the ring twice: dedup
    =/  hits=(list graf-handle:graf-sur)
      %~  tap  in
      %-  ~(gas in *(set graf-handle:graf-sur))
      (turn found |=(candidate=search-candidate h.candidate))
    =/  result=graf-search-result:graf-sur
      :*  handle=[type=%search-result version=1 id=(cat 3 'result-' id.handle.proof.act) hash=batch-hash.meta]
          tree-handle=handle.proof.act
          root-handle=root-handle.proof.act
          tree-kind=tree-kind.proof.act
          result-handles=hits
          scanned-count=(lent scan)
          exhausted=&(active-exhausted exhausted.archive-page)
      ==
    =/  new-graf  (add-search-tree graf proof.act)
    =/  handled
      (remember-handle (remember-handle new-graf handle.proof.act) root-handle.proof.act)
    =.  handled  (add-search-result handled result)
    =.  handled  (remember-handle handled handle.result)
    =.  handled  (add-mint handled handle.result result)
    =/  updated  (remember-key handled idempotency-key.meta)
    =/  final  (finalize-graf updated act %.y %.n)
    :_  (set-graf final)
    ~[(search-tree-card proof.act) (search-result-card result)]
  ::
      %record-search-result
    =/  new-graf  (add-search-result graf proof.act)
    =/  handled  (remember-handle-list (remember-handle (remember-handle (remember-handle new-graf handle.proof.act) tree-handle.proof.act) root-handle.proof.act) result-handles.proof.act)
    =/  updated  (remember-key handled idempotency-key.meta)
    =/  final  (finalize-graf updated act %.y %.n)
    :_  (set-graf final)
    ~[(search-result-card proof.act)]
  ::
      %record-provenance
    =/  new-graf  (add-provenance graf proof.act)
    =/  handled  (remember-handle new-graf handle.proof.act)
    =/  sourced
      ?~  source-handle.proof.act
        handled
      (remember-handle handled u.source-handle.proof.act)
    =/  updated  (remember-key sourced idempotency-key.meta)
    =/  final  (finalize-graf updated act %.y %.n)
    :_  (set-graf final)
    ~[(provenance-card proof.act)]
  ::
      %record-proof-bundle
    =/  new-graf  (add-proof-bundle graf proof.act)
    =/  handled  (remember-handle new-graf handle.proof.act)
    =/  updated  (remember-key handled idempotency-key.meta)
    =/  final  (finalize-graf updated act %.y %.n)
    :_  (set-graf final)
    ~[(proof-bundle-card proof.act)]
  ::
      %record-controlled-agency-proof-bundle
    =/  relation  (controlled-agency-proof-bundle-relation proof.act)
    =/  bundled  (add-proof-bundle graf proof.act)
    =/  new-graf  (add-relation bundled relation)
    =/  handled  (remember-handle (remember-handle (remember-handle (remember-handle new-graf handle.proof.act) handle.relation) source.relation) target.relation)
    =/  updated  (remember-key handled idempotency-key.meta)
    =/  final  (finalize-graf updated act %.y %.n)
    :_  (set-graf final)
    ~[(proof-bundle-card proof.act) (relation-card relation)]
  ::
      %submit-bachelor-output
    =/  new-graf  (add-bachelor-output graf proof.act)
    =/  handled  (remember-handle new-graf handle.proof.act)
    =/  updated  (remember-key handled idempotency-key.meta)
    =/  final  (finalize-graf updated act %.y %.n)
    :_  (set-graf final)
    ~[(bachelor-output-card proof.act)]
  ::
      %reduce-outputs
    =/  new-graf  (add-reduction-candidate graf proof.act)
    =/  handled  (remember-handle new-graf handle.proof.act)
    =/  updated  (remember-key handled idempotency-key.meta)
    =/  final  (finalize-graf updated act %.y %.n)
    :_  (set-graf final)
    ~[(reduction-candidate-card proof.act)]
  ::
      %record-reduction-verdict
    =/  new-graf  (add-reduction-verdict graf proof.act)
    =/  handled  (remember-handle new-graf handle.proof.act)
    =/  updated  (remember-key handled idempotency-key.meta)
    =/  final  (finalize-graf updated act %.y %.n)
    :_  (set-graf final)
    ~[(reduction-verdict-card proof.act)]
  ::
      %record-convergence
    =/  new-graf  (add-convergence-record graf proof.act)
    =/  handled  (remember-handle new-graf handle.proof.act)
    =/  updated  (remember-key handled idempotency-key.meta)
    =/  final  (finalize-graf updated act %.y %.n)
    :_  (set-graf final)
    ~[(convergence-card proof.act)]
  ::
      %record-event-log-entry
    =/  new-graf  (add-event-log-entry graf proof.act)
    =/  handled  (remember-handle new-graf handle.proof.act)
    =/  updated  (remember-key handled idempotency-key.meta)
    =/  final  (finalize-graf updated act %.y %.n)
    :_  (set-graf final)
    ~[(event-log-card proof.act)]
  ::
      %record-task
    =/  new-graf  (add-task graf proof.act)
    =/  handled  (remember-handle new-graf handle.proof.act)
    =/  updated  (remember-key handled idempotency-key.meta)
    =/  final  (finalize-graf updated act %.y %.n)
    :_  (set-graf final)
    ~[(task-card proof.act)]
  ::
      %record-task-result
    =/  new-graf  (add-task-result graf proof.act)
    =/  handled  (remember-handle new-graf handle.proof.act)
    =/  updated  (remember-key handled idempotency-key.meta)
    =/  final  (finalize-graf updated act %.y %.n)
    :_  (set-graf final)
    ~[(task-result-card proof.act)]
  ::
      %record-collaboration-crossing
    =/  decoded=(unit graf-collaboration-crossing-request:graf-sur)
      =/  cued  (mule |.((cue request.act)))
      ?.  ?=(%& -.cued)  ~
      ((soft graf-collaboration-crossing-request:graf-sur) p.cued)
    ?~  decoded
      =/  final  (finalize-graf graf act %.n %.n)
      [~ (set-graf final)]
    =/  request=graf-collaboration-crossing-request:graf-sur  u.decoded
    =/  admitted=crossing-admission:mc
      %:  ingest-stored:mcg
        attic.graf
        expected.request
        prior.request
        candidate.request
        now.bowl
      ==
    ?-    -.admitted
        %record
      =/  record=crossing-record:mc  record.admitted
      =/  archived
        graf(attic (stash-record:mcg attic.graf record))
      =/  handled
        (remember-handle archived (record-handle:mcg record))
      =/  updated  (remember-key handled idempotency-key.meta)
      =/  final  (finalize-graf updated act %.y %.n)
      [~ (set-graf final)]
        %duplicate
      =/  updated  (remember-key graf idempotency-key.meta)
      =/  final  (finalize-graf updated act %.y %.y)
      [~ (set-graf final)]
        %refused
      =/  final  (finalize-graf graf act %.n %.n)
      [~ (set-graf final)]
    ==
  ::
      %record-bride-nets
    =/  new-graf  (set-bride-nets graf proof.act)
    =/  handled  (remember-handle new-graf handle.proof.act)
    =/  sourced
      ?~  source-handle.proof.act
        handled
      (remember-handle handled u.source-handle.proof.act)
    =/  updated  (remember-key sourced idempotency-key.meta)
    =/  final  (finalize-graf updated act %.y %.n)
    :_  (set-graf final)
    ~[(bride-nets-card proof.act) (bride-native-card (native-readiness final))]
  ::
      %record-bride-milky-way
    =/  new-graf  (set-bride-milky-way graf proof.act)
    =/  handled  (remember-handle new-graf handle.proof.act)
    =/  sourced
      ?~  source-handle.proof.act
        handled
      (remember-handle handled u.source-handle.proof.act)
    =/  updated  (remember-key sourced idempotency-key.meta)
    =/  final  (finalize-graf updated act %.y %.n)
    :_  (set-graf final)
    ~[(bride-milky-way-card proof.act) (bride-native-card (native-readiness final))]
  ::
      %bind-cantrip-session
    =/  new-graf  (add-cantrip-binding graf proof.act)
    =/  updated  (remember-key new-graf idempotency-key.meta)
    =/  final  (finalize-graf updated act %.y %.n)
    [~ (set-graf final)]
  ::
      %emit-cantrip-law
    ::  the emitted law is durable evidence: land it in the event log
    ::  under a graf-minted handle instead of dropping it on the floor
    =/  entry=graf-event-log-entry:graf-sur
      [ handle=[type=%cantrip-law version=1 id=batch-id.meta hash=batch-hash.meta]
        event-id=batch-id.meta
        event-kind=%cantrip-law
        summary='cantrip law emitted through graf'
        body=proof.act
        session-id=''
        seat-id=''
        assigned-ship-id=''
        created=dispatched-at.meta
      ]
    =/  new-graf  (add-mint (add-event-log-entry graf entry) handle.entry entry)
    =/  handled  (remember-handle new-graf handle.entry)
    =/  updated  (remember-key handled idempotency-key.meta)
    =/  final  (finalize-graf updated act %.y %.n)
    :_  (set-graf final)
    ~[(event-log-card entry)]
  ==
  =/  final-unified=graf-unified-state  unified.state
  =/  final-graf=graf-app-state  graf.final-unified
  =/  final-dispatch  last-dispatch.final-graf
  =/  accepted=?  ?~(final-dispatch %.n accepted.u.final-dispatch)
  =/  duplicate=?  ?~(final-dispatch %.n duplicate.u.final-dispatch)
  =.  this
    ?:  ?&  accepted
            !?=(%record-collaboration-crossing -.act)
        ==
      =/  projection  (core-projection-fact act src.bowl)
      =/  core  core.final-unified
      =/  projected-core
        core(facts (light:graf-substrate facts.core projection))
      =/  changed=?  !=(core projected-core)
      =/  next-control
        (record-write:gce control.final-unified changed)
      this(state [%17 final-unified(control next-control, core projected-core)])
    this
  =/  receipt-reason=@tas  (write-receipt-reason act accepted duplicate)
  =/  with-receipt=graf-unified-state
    %:  note-write-receipt
      unified.state
      act
      src.bowl
      accepted
      duplicate
      receipt-reason
      now.bowl
    ==
  =.  this  this(state [%17 with-receipt])
  :_  this
  [[%give %fact ~[/graf-runtime] %noun !>((runtime-status-for act))] cards]
::
++  on-watch
  |=  =path
  ^-  (quip card _this)
  ::  Reads are authority too.  Every path below streams graf's own records as
  ::  they land — /graf-provenance carries %model-chat bodies (session briefs,
  ::  decisions). Readers are this ship and its own sponsored children;
  ::  the two bounded fedwiki page routes also admit this ship's sponsor.
  ::  No named collaborator inherits access on somebody else's installation.
  ::  This read policy does not grant board writes.
  ::  Refuse loudly: a nack names the ship and path rather than handing back
  ::  an empty subscription.
  ::
  ::  Eyre watches /http-response/<id> AS THE REQUESTER: a signed-out visitor
  ::  is a random guest @p, which the gate below refused, so Eyre answered
  ::  500 instead of graf's own 403.  The path carries only the reply on-poke
  ::  writes for that id, and on-poke serves data to this ship alone.
  ?:  ?=([%http-response *] path)  `this
  ::  One card, once, for a fork (lib/fedwiki-store, ted/fedwiki-fork): the
  ::  newest version's [rev page], or ~ when this ship has no such card,
  ::  then a kick.  Admitted for the ships the gate below admits AND this
  ::  ship's sponsor, so a planet forks its moon's card as the moon forks
  ::  its planet's.
  ::  a hosted site's card (lib/fedwiki-store +site-pages): the stores this
  ::  ship keeps for the ships it speaks for -- flunky for its guest moons
  ?:  ?=([%fedwiki %site @ %page @ ~] path)
    ?.  (watch:gra our.bowl src.bowl path)
      ~|([%graf %watch-refused src=src.bowl path] !!)
    =/  site=(unit @p)  (slaw %p i.t.t.path)
    =/  v
      ?~  site  ~
      %-  ~(get by (site-pages:fs (facts:graf-substrate facts.core.unified.state) u.site))
      i.t.t.t.t.path
    =/  got  ?~(v ~ `[rev.u.v page.u.v])
    :_  this
    :~  [%give %fact ~ %noun !>(got)]
        [%give %kick ~ ~]
    ==
  ?:  ?=([%fedwiki %page @ ~] path)
    ?.  (watch:gra our.bowl src.bowl path)
      ~|([%graf %watch-refused src=src.bowl path] !!)
    =/  v  %-  ~(get by (pages:fs (facts:graf-substrate facts.core.unified.state)))
           i.t.t.path
    =/  got  ?~(v ~ `[rev.u.v page.u.v])
    :_  this
    :~  [%give %fact ~ %noun !>(got)]
        [%give %kick ~ ~]
    ==
  ?.  (watch:gra our.bowl src.bowl path)
    ~|([%graf %watch-refused src=src.bowl path] !!)
  ?+  path  `this
    [%graf-circulation ~]  `this
    [%graf-bundles ~]  `this
    [%graf-packets ~]  `this
    [%graf-machine-topology ~]  `this
    [%graf-root ~]  `this
    [%graf-seat-writes ~]  `this
    [%graf-axis-writes ~]  `this
    [%graf-positions ~]  `this
    [%graf-governor ~]  `this
    [%graf-slice ~]  `this
    [%graf-traversal ~]  `this
    [%graf-write-intent ~]  `this
    [%graf-residue ~]  `this
    [%graf-sieve-verdict ~]  `this
    [%graf-continuation ~]  `this
    [%graf-proofs ~]  `this
    [%graf-relations ~]  `this
    [%graf-projections ~]  `this
    [%graf-search ~]  `this
    [%graf-provenance ~]  `this
    [%graf-runtime ~]  `this
    [%graf-event-log ~]  `this
    [%graf-reduction ~]  `this
    [%graf-tasks ~]  `this
    [%graf-bride-nets ~]  `this
    [%graf-bride-milky-way ~]  `this
    [%graf-bride-native ~]  `this
    [%updates ~]  `this
    [%http-response *]  `this
  ==
::
++  on-leave
  |=  =path
  ^-  (quip card _this)
  `this
::
++  on-peek
  |=  =path
  ^-  (unit (unit cage))
  =/  core  core.unified.state
  ::  Only the typed inner wrapper call sees this private derived-index input.
  ?:  =(floor-path:gki path)
    ?.  =(src.bowl our.bowl)  ~
    ``noun+!>(facts.core)
  =/  graf  graf.unified.state
  =/  unified-snapshot-result
    (peek-unified-snapshot:gce control.unified.state core graf path)
  ?^  unified-snapshot-result  unified-snapshot-result
  =/  snapshot-result  (peek-snapshot:gce control.unified.state path)
  ?^  snapshot-result  snapshot-result
  =/  core-result  (peek:gce core path our.bowl)
  ?^  core-result  core-result
  ?+  path  ~
    [%x %write-receipt @ @ ~]
      =/  request-id=(unit @ux)  (slaw %ux i.t.t.path)
      ?~  request-id  [~ ~]
      =/  request-digest=(unit @ux)  (slaw %ux i.t.t.t.path)
      ?~  request-digest  [~ ~]
      ``noun+!>((find:gwrl receipts.unified.state u.request-id u.request-digest))
    ::  S103.44: the head of the receipt list -- who has been writing.
    [%x %receipts %recent @ ~]
      =/  n=(unit @ud)  (slaw %ud i.t.t.t.path)
      ?~  n  [~ ~]
      =/  rs=(list receipt:gwr)  (scag (min u.n 40) receipts.unified.state)
      ``noun+!>((turn rs |=(r=receipt:gwr [action=action.r who=source-ship.r ok=accepted.r why=reason.r rev=revision.r at=recorded-at.r])))
    ::  F3 (lane C/D): Graf's copy is the ONLY board.  (%siev runs hosted
    ::  again since 2026-10-16, for formula lineage; no board authority.)
    ::  The %shadow-prefixed route survives as a compatibility alias for
    ::  absorption-era readers; the unprefixed route is the authority
    ::  surface.  Same organ behind both.
    [%x %graf-board %shadow *]
      =/  sh=board-shadow:gsv
        ?~(board.siev.unified.state initial:gbs u.board.siev.unified.state)
      (peek-board-shadow:gbs sh t.t.t.path bowl)
    [%x %graf-board *]
      =/  sh=board-shadow:gsv
        ?~(board.siev.unified.state initial:gbs u.board.siev.unified.state)
      (peek-board-shadow:gbs sh t.t.path bowl)
    ::  siev absorption (evidence): the donor's durable readback surface
    ::  over the exact imported snapshot.
    [%x %siev-evidence *]
      (peek-evidence:gse evidence.siev.unified.state t.t.path)
    [%x %cockpit ~]
      =/  fact-count=@ud  (count:graf-substrate facts.core)
      =/  recall-n=@ud  ?~(recall-index.core 0 n.u.recall-index.core)
      =/  recall-exact=?  (recall-cache-valid:gce core)
      =/  recall-status=index-status:gc
        :*  ?=(^ recall-index.core)
            recall-exact
            recall-n
            fact-count
            ?:((gth fact-count recall-n) (sub fact-count recall-n) 0)
            ?~(recall-index.core *@da at.u.recall-index.core)
            ?:(recall-exact %index %slow-rebuild)
        ==
      =/  attested-count=@ud  ~(wyt by attests.core)
      =/  component-n=@ud
        ?~(component-index.core 0 n.u.component-index.core)
      =/  component-exact=?  (component-cache-valid:gce core)
      =/  component-status=index-status:gc
        :*  ?=(^ component-index.core)
            component-exact
            component-n
            attested-count
            ?:((gth attested-count component-n) (sub attested-count component-n) 0)
            ?~(component-index.core *@da at.u.component-index.core)
            ?:(component-exact %component-index %linear-attested-scan)
        ==
      =/  latest-search=(unit latest-search:gc)
        ?~  last-search-result.graf  ~
        =/  item=latest-search:gc
          :*  id.handle.u.last-search-result.graf
              tree-kind.u.last-search-result.graf
              (lent result-handles.u.last-search-result.graf)
              scanned-count.u.last-search-result.graf
              exhausted.u.last-search-result.graf
          ==
        `item
      =/  latest-axis=(unit latest-axis:gc)
        ?~  last-axis-write.graf  ~
        =/  item=latest-axis:gc
          :*  id.handle.u.last-axis-write.graf
              seat-id.u.last-axis-write.graf
              relative-axis.u.last-axis-write.graf
              absolute-axis.u.last-axis-write.graf
          ==
        `item
      =/  disconnected=@ud
        %-  lent
        %+  skim  ~(tap by writer-links.core)
        |=  [app=@tas link=graf-core-writer-link]
        !connected.link
      =/  mapping=mapping-progress:gc
        :*  (lent seat-writes.graf)
            (lent axis-writes.graf)
            (weight-hypothesis-count (facts:graf-substrate facts.core))
            latest-axis
        ==
      =/  view=snapshot:gc
        :*  %graf-cockpit-v1
            root-id.graf
            fact-count
            recall-status
            component-status
            (lent search-trees.graf)
            (lent search-results.graf)
            latest-search
            ~(wyt by writer-links.core)
            disconnected
            mapping
        ==
      ``noun+!>(view)
    [%x %family %inventory ~]
      ``json+!>(family-inventory-json)
    [%x %graph %summary ~]
      ``json+!>((graph-summary-json (summarize-graph graf)))
    ::  pataphysical recall (lib/graf-clinamen): nearest lit concept names to a
    ::  name that names no concept, within edit-budget k.  /x/clinamen/<name>/<k>.
    [%x %clinamen @ @ ~]
      =/  q=@t  i.t.t.path
      =/  k=@ud  (slav %ud i.t.t.t.path)
      =/  names=(set *)
        %-  ~(gas in *(set *))
        (turn nodes.graph.graf |=(n=concept-node:graf-sur `*`name.n))
      ``noun+!>((clinamen:graf-clinamen names q k *(set *)))
    [%x %root %summary ~]
      ``json+!>((root-summary-json (summarize-root graf)))
    [%x %root %field ~]
      ``json+!>((root-field-json (build-root-field graf)))
    [%x %root %domains ~]
      ``json+!>((root-domains-json (build-root-domains graf)))
    [%x %handle @ ~]
      =/  found  (find-handle handle-registry.graf i.t.t.path)
      ?~  found  [~ ~]
      ``noun+!>(u.found)
    [%x %machine %topology ~]
      ``noun+!>(machine.graf)
    [%x %impulse @ ~]
      =/  found  (find-impulse impulses.graf i.t.t.path)
      ?~  found  [~ ~]
      ``noun+!>(u.found)
    [%x %bundle @ ~]
      =/  found  (find-bundle bundles.graf i.t.t.path)
      ?~  found  [~ ~]
      ``noun+!>(u.found)
    [%x %packet %latest ~]
      ``json+!>((packet-json last-packet.graf))
    [%x %packet @ ~]
      ``json+!>((packet-json (find-packet packets.graf i.t.t.path)))
    [%x %star-govern %latest ~]
      ``noun+!>((star-govern-read graf now.bowl))
    [%x %star-govern %history @ ~]
      =/  requested=@ud  (slav %ud i.t.t.t.path)
      ``noun+!>((star-govern-history graf requested))
    [%x %star-govern %override %latest ~]
      ``noun+!>((latest-star-govern-override graf))
    [%x %star-govern %override %history @ ~]
      =/  requested=@ud  (slav %ud i.t.t.t.t.path)
      ``noun+!>((star-govern-override-history graf requested))
    [%x %circulation %latest ~]
      ``noun+!>((scag 16 circulation.graf))
    [%x %circulation %config ~]
      ``noun+!>((circulation-config graf))
    [%x %circulation %page @ @ ~]
      =/  offset=@ud  (slav %ud i.t.t.t.path)
      =/  requested=@ud  (slav %ud i.t.t.t.t.path)
      =/  page-size=@ud
        ?:  (gth requested max-circulation)
          max-circulation
        requested
      ``noun+!>((scag page-size (slag offset circulation.graf)))
    [%x %relation %inventory ~]
      ``json+!>((relation-inventory-json graf))
    [%x %relation %summary ~]
      ``json+!>((relation-summary-json graf))
    [%x %relation %controlled-agency %vocabulary ~]
      ``json+!>(controlled-agency-vocabulary-json)
    [%x %relation %controlled-agency %inventory ~]
      ``json+!>((controlled-agency-inventory-json graf))
    [%x %relation %controlled-agency %summary ~]
      ``json+!>((controlled-agency-summary-json graf))
    [%x %relation %controlled-agency %run @ ~]
      ``json+!>((relation-list-json graf i.t.t.t.t.path (controlled-agency-relations-by-query relations.graf i.t.t.t.t.path)))
    [%x %relation %controlled-agency %artifact @ ~]
      ``json+!>((relation-list-json graf i.t.t.t.t.path (controlled-agency-relations-by-query relations.graf i.t.t.t.t.path)))
    [%x %relation %controlled-agency %moon @ ~]
      ``json+!>((relation-list-json graf i.t.t.t.t.path (controlled-agency-relations-by-query relations.graf i.t.t.t.t.path)))
    [%x %relation %controlled-agency %codex-session @ ~]
      ``json+!>((relation-list-json graf i.t.t.t.t.path (controlled-agency-relations-by-query relations.graf i.t.t.t.t.path)))
    [%x %relation %controlled-agency %proof-bundle @ ~]
      ``json+!>((controlled-agency-proof-bundle-json graf i.t.t.t.t.path))
    [%x %dispatch %latest ~]
      ``json+!>((dispatch-latest-json last-dispatch.graf))
    [%x %proof %latest ~]
      ``json+!>((proof-latest-json (build-proof-latest graf)))
    [%x %viki %context ~]
      ``noun+!>((graf-viki-context-for graf ''))
    [%x %viki %context @ ~]
      =/  encoded-session=(unit @t)  (slaw %t i.t.t.t.path)
      =/  session-id=@t  ?~(encoded-session i.t.t.t.path u.encoded-session)
      ``noun+!>((graf-viki-context-for graf session-id))
    [%x %verify-proof @ ~]
      ``json+!>((verify-proof-json graf i.t.t.path))
    [%x %handle-exists @ ~]
      ``json+!>((handle-exists-json graf i.t.t.path))
    [%x %cantrip %binding %latest ~]
      ``json+!>((cantrip-binding-json last-cantrip-binding.graf))
    [%x %cantrip %binding %inventory ~]
      ``json+!>((cantrip-binding-inventory-json graf))
    [%x %bride %nets ~]
      ``json+!>((bride-nets-json bride-nets.graf))
    [%x %bride %milky-way ~]
      ``json+!>((bride-milky-way-json bride-milky-way.graf))
    [%x %bride %native ~]
      ``json+!>((native-readiness-json (native-readiness graf)))
    [%x %axis @ %latest ~]
      =/  absolute-axis=(unit @ud)  (slaw %ud i.t.t.path)
      ?~  absolute-axis  [~ ~]
      =/  found  (find-axis-write-by-absolute axis-writes.graf u.absolute-axis)
      ?~  found  [~ ~]
      ``noun+!>(u.found)
    [%x %axis @ %summary ~]
      =/  absolute-axis=(unit @ud)  (slaw %ud i.t.t.path)
      ?~  absolute-axis  [~ ~]
      ``json+!>((axis-write-summary-json (find-axis-write-by-absolute axis-writes.graf u.absolute-axis)))
    [%x %axis @ %page ~]
      =/  absolute-axis=(unit @ud)  (slaw %ud i.t.t.path)
      ?~  absolute-axis  [~ ~]
      ``json+!>((axis-page-json (find-axis-write-by-absolute axis-writes.graf u.absolute-axis)))
    [%x %axis @ %trail ~]
      =/  absolute-axis=(unit @ud)  (slaw %ud i.t.t.path)
      ?~  absolute-axis  [~ ~]
      ``json+!>((axis-trail-json (find-axis-write-by-absolute axis-writes.graf u.absolute-axis)))
    [%x %governor %latest ~]
      ?~  last-governor.graf  [~ ~]
      ``noun+!>(u.last-governor.graf)
    [%x %governor @ ~]
      =/  found  (find-governor governors.graf i.t.t.path)
      ?~  found  [~ ~]
      ``noun+!>(u.found)
    [%x %watch-paths ~]
      ``json+!>((watch-manifest-json build-watch-manifest))
    [%x %crossing @ ~]
      =/  found  (find-fact circulation.graf i.t.t.path)
      ?~  found  [~ ~]
      ``noun+!>(u.found)
    [%x %seat %inventory ~]
      ``json+!>((seat-inventory-json graf))
    [%x %surface-visible %seat @ %summary ~]
      =/  found  (find-seat-region seat-writes.graf axis-writes.graf i.t.t.t.path)
      ``json+!>((surface-visible-json 'seat-summary' i.t.t.t.path ?~(found %.n %.y)))
    [%x %seat @ %axis @ %latest ~]
      =/  relative-axis=(unit @ud)  (slaw %ud i.t.t.t.t.path)
      ?~  relative-axis  [~ ~]
      =/  found  (find-axis-write axis-writes.graf i.t.t.path u.relative-axis)
      ?~  found  [~ ~]
      ``noun+!>(u.found)
    [%x %surface-visible %seat @ %axis @ %summary ~]
      =/  relative-axis=(unit @ud)  (slaw %ud i.t.t.t.t.t.path)
      ?~  relative-axis
        ``json+!>((ok-error-json %.n [~ 'invalid relative axis']))
      =/  found  (find-axis-write axis-writes.graf i.t.t.t.path u.relative-axis)
      ``json+!>((surface-visible-json 'seat-axis-summary' (ud-text u.relative-axis) ?~(found %.n %.y)))
    [%x %seat @ %axis @ %summary ~]
      =/  relative-axis=(unit @ud)  (slaw %ud i.t.t.t.t.path)
      ?~  relative-axis  [~ ~]
      ``json+!>((axis-write-summary-json (find-axis-write axis-writes.graf i.t.t.path u.relative-axis)))
    [%x %seat @ %latest ~]
      =/  found  (find-seat-write seat-writes.graf i.t.t.path)
      ?~  found  [~ ~]
      ``noun+!>(u.found)
    ::  WHO HOLDS THIS SEAT -- absence returned as a VALUE, not a failure.
    ::
    ::  /latest above answers [~ ~] for an unheld seat, which makes the
    ::  caller's `.^` BAIL.  Measured 2026-08-16 on ~sampel-palnet: `mule`
    ::  does NOT catch a failed `.^`, so an authorization gate built on
    ::  /latest crashes on the commonest case -- claiming a free seat --
    ::  while every proof of it stays green.
    ::
    ::  A caller that must tell "nobody holds it" from "I could not read
    ::  it" cannot use a peek that expresses both as the same crash.  So
    ::  this one always answers, and a failure here means graf, not the
    ::  seat.  Same rule as rule 12, one layer down.
    [%x %seat @ %holder ~]
      ``noun+!>(`(unit graf-seat-write:graf-sur)`(find-seat-write seat-writes.graf i.t.t.path))
    [%x %seat @ %summary ~]
      =/  found  (find-seat-region seat-writes.graf axis-writes.graf i.t.t.path)
      ``json+!>((seat-region-summary-json found))
    [%x %seat @ %region ~]
      =/  found  (find-seat-region seat-writes.graf axis-writes.graf i.t.t.path)
      ?~  found  [~ ~]
      ``noun+!>(u.found)
    [%x %seat @ %noun ~]
      =/  found  (find-seat-tree graf i.t.t.path)
      ?~  found  [~ ~]
      ``noun+!>(u.found)
    [%x %position %inventory ~]
      ``json+!>((position-inventory-json graf))
    [%x %position @ %latest ~]
      =/  found  (find-ship-position ship-positions.graf i.t.t.path)
      ?~  found  [~ ~]
      ``noun+!>(u.found)
    [%x %position @ %summary ~]
      =/  found  (find-ship-position ship-positions.graf i.t.t.path)
      ``json+!>((ship-position-json found))
    [%x %surface-visible %axis @ %summary ~]
      =/  absolute-axis=(unit @ud)  (slaw %ud i.t.t.t.path)
      ?~  absolute-axis
        ``json+!>((ok-error-json %.n [~ 'invalid absolute axis']))
      =/  found  (find-axis-write-by-absolute axis-writes.graf u.absolute-axis)
      ``json+!>((surface-visible-json 'axis-summary' (ud-text u.absolute-axis) ?~(found %.n %.y)))
    [%x %slice %latest ~]
      ?~  last-slice.graf  [~ ~]
      ``noun+!>(u.last-slice.graf)
    [%x %slice @ ~]
      =/  found  (find-slice slices.graf i.t.t.path)
      ?~  found  [~ ~]
      ``noun+!>(u.found)
    [%x %traversal %latest ~]
      ?~  last-traversal.graf  [~ ~]
      ``noun+!>(u.last-traversal.graf)
    [%x %traversal @ ~]
      =/  found  (find-traversal traversals.graf i.t.t.path)
      ?~  found  [~ ~]
      ``noun+!>(u.found)
    [%x %traversal %path @ @ ~]
      ``json+!>((traversal-path-json graf i.t.t.t.path i.t.t.t.t.path))
    [%x %write-intent %latest ~]
      ?~  last-write-intent.graf  [~ ~]
      ``noun+!>(u.last-write-intent.graf)
    [%x %write-intent @ ~]
      =/  found  (find-write-intent write-intents.graf i.t.t.path)
      ?~  found  [~ ~]
      ``noun+!>(u.found)
    [%x %residue %latest ~]
      ``json+!>((residue-json last-residue.graf))
    [%x %residue @ ~]
      ``json+!>((residue-json (find-residue residues.graf i.t.t.path)))
    [%x %sieve %latest ~]
      ?~  last-sieve-verdict.graf  [~ ~]
      ``noun+!>(u.last-sieve-verdict.graf)
    [%x %sieve @ ~]
      =/  found  (find-sieve-verdict sieve-verdicts.graf i.t.t.path)
      ?~  found  [~ ~]
      ``noun+!>(u.found)
    [%x %continuation %latest ~]
      ?~  last-continuation.graf  [~ ~]
      ``noun+!>(u.last-continuation.graf)
    [%x %continuation @ ~]
      =/  found  (find-continuation continuations.graf i.t.t.path)
      ?~  found  [~ ~]
      ``noun+!>(u.found)
    [%x %attic %summary ~]
      ``json+!>((attic-summary-json graf))
    [%x %failure %count ~]
      ``noun+!>(`@ud`(lent failures.graf))
    ::  how many failures live in the ATTIC rather than the working set.
    ::  Nothing was destroyed; this says where to look for the rest.
    [%x %failure %stashed ~]
      ``noun+!>(`@ud`failures-stashed.graf)
    [%x %failure %latest ~]
      ?~  failures.graf  [~ ~]
      ``noun+!>(`graf-failure`i.failures.graf)
    [%x %failure %page @ ~]
      =/  budget=(unit @ud)  (slaw %ud i.t.t.t.path)
      ?~  budget  [~ ~]
      ``noun+!>(`(list graf-failure)`(scag u.budget failures.graf))
    [%x %collaboration %crossing %count ~]
      ``noun+!>((crossing-count:mcg attic.graf))
    [%x %collaboration %crossing %latest ~]
      ``noun+!>((crossing-latest:mcg attic.graf))
    [%x %collaboration %crossing %page @ ~]
      =/  budget=(unit @ud)  (slaw %ud i.t.t.t.t.path)
      ?~  budget  [~ ~]
      ``noun+!>((crossing-page:mcg attic.graf u.budget))
    [%x %attic %epoch @ ~]
      =/  seq=(unit @ud)  (slaw %ud i.t.t.t.path)
      ?~  seq  [~ ~]
      =/  found  (find-epoch:graf-attic attic.graf u.seq)
      ?~  found  [~ ~]
      ``noun+!>(u.found)
    [%x %relation %latest ~]
      ``json+!>(?~(last-relation.graf ~ (relation-json u.last-relation.graf)))
    [%x %relation @ ~]
      =/  found  (find-relation relations.graf i.t.t.path)
      ``json+!>(?~(found ~ (relation-json u.found)))
    [%x %projection %inventory ~]
      ``json+!>((projection-inventory-json graf))
    [%x %projection %summary ~]
      ``json+!>((projection-summary-json graf))
    [%x %projection %latest ~]
      ``json+!>((projection-json last-projection.graf))
    [%x %surface-visible %projection @ ~]
      =/  found  (find-projection projections.graf i.t.t.t.path)
      ``json+!>((surface-visible-json 'projection' i.t.t.t.path ?~(found %.n %.y)))
    [%x %projection @ ~]
      =/  found  (find-projection projections.graf i.t.t.path)
      ``json+!>((projection-json found))
    [%x %search %summary ~]
      ``json+!>((search-summary-json graf))
    [%x %search %query @ ~]
      ``json+!>((search-query-json graf i.t.t.t.path))
    [%x %search %tree %inventory ~]
      ``json+!>((search-tree-inventory-json graf))
    [%x %search %tree %summary ~]
      ``json+!>((search-tree-summary-json graf))
    [%x %search %tree %latest ~]
      ?~  last-search-tree.graf  [~ ~]
      ``noun+!>(u.last-search-tree.graf)
    [%x %search %tree @ ~]
      =/  found  (find-search-tree search-trees.graf i.t.t.t.path)
      ?~  found  [~ ~]
      ``noun+!>(u.found)
    [%x %search %result %inventory ~]
      ``json+!>((search-result-inventory-json graf))
    [%x %search %result %summary ~]
      ``json+!>((search-result-summary-json graf))
    [%x %search %result %latest ~]
      ?~  last-search-result.graf  [~ ~]
      ``noun+!>(u.last-search-result.graf)
    [%x %search %result @ ~]
      =/  found  (find-search-result search-results.graf i.t.t.t.path)
      ?~  found  [~ ~]
      ``noun+!>(u.found)
    [%x %provenance %inventory ~]
      ``json+!>((provenance-inventory-json graf))
    [%x %provenance %summary ~]
      ``json+!>((provenance-summary-json graf))
    [%x %provenance %latest ~]
      ``json+!>((provenance-json last-provenance.graf))
    [%x %surface-visible %provenance @ ~]
      =/  found  (find-provenance provenances.graf i.t.t.t.path)
      ``json+!>((surface-visible-json 'provenance' i.t.t.t.path ?~(found %.n %.y)))
    [%x %provenance @ ~]
      ``json+!>((provenance-json (find-provenance provenances.graf i.t.t.path)))
    [%x %surface-visible %packet @ ~]
      =/  found  (find-packet packets.graf i.t.t.t.path)
      ``json+!>((surface-visible-json 'packet' i.t.t.t.path ?~(found %.n %.y)))
    [%x %proof-bundle %inventory ~]
      ``json+!>((proof-bundle-inventory-json graf))
    [%x %proof-bundle %summary ~]
      ``json+!>((proof-bundle-summary-json graf))
    [%x %proof-bundle %latest ~]
      ``json+!>(?~(last-proof-bundle.graf ~ (proof-bundle-json u.last-proof-bundle.graf)))
    [%x %proof @ ~]
      =/  found  (find-proof-bundle proof-bundles.graf i.t.t.path)
      ?~  found  [~ ~]
      ``json+!>((proof-bundle-json u.found))
    [%x %proof-bundle @ ~]
      =/  found  (find-proof-bundle proof-bundles.graf i.t.t.path)
      ``json+!>(?~(found ~ (proof-bundle-json u.found)))
    [%x %task %inventory ~]
      ``json+!>((task-inventory-json graf))
    [%x %task %summary ~]
      ``json+!>((task-summary-json graf))
    [%x %task %latest ~]
      ``json+!>((task-json last-task.graf))
    [%x %task @ ~]
      ``json+!>((task-json (find-task tasks.graf i.t.t.path)))
    [%x %task-result %inventory ~]
      ``json+!>((task-result-inventory-json graf))
    [%x %task-result %summary ~]
      ``json+!>((task-result-summary-json graf))
    [%x %task-result %latest ~]
      ``json+!>((task-result-json last-task-result.graf))
    [%x %task-result @ ~]
      ``json+!>((task-result-json (find-task-result task-results.graf i.t.t.path)))
    [%x %reduction %summary ~]
      ``json+!>((reduction-agent-summary-json graf))
    [%x %reduction %output @ ~]
      ``json+!>((bachelor-output-json (find-bachelor-output outputs.reduction-agent.graf i.t.t.t.path)))
    [%x %reduction %verdict @ ~]
      ``json+!>((reduction-verdict-json (find-reduction-verdict verdicts.reduction-agent.graf i.t.t.t.path)))
    [%x %reduction %convergence @ ~]
      ``json+!>((convergence-record-json (find-convergence-record convergences.reduction-agent.graf i.t.t.t.path)))
    [%x %event-log %inventory ~]
      ``json+!>((event-log-inventory-json graf))
    [%x %event-log %summary ~]
      ``json+!>((event-log-summary-json graf))
    [%x %event-log %latest ~]
      ``json+!>((event-log-entry-json last-event-log-entry.graf))
    [%x %event-log @ ~]
      ``json+!>((event-log-entry-json (find-event-log-entry event-log.graf i.t.t.path)))
    [%x %runtime %status %latest ~]
      ``json+!>((runtime-status-json runtime-status.graf))
    [%x %state ~]
      ``json+!>((graf-state-json graf))
  ==
::
++  on-agent
  |=  [=wire =sign:agent:gall]
  ^-  (quip card _this)
  ?.  ?=([%territory @ @ ~] wire)  (on-agent:def wire sign)
  ?.  (writes-open:gce control.unified.state)  `this
  =/  app=@tas  `@tas`i.t.wire
  =/  generation=(unit @ud)  (slaw %ud i.t.t.wire)
  ?~  generation  (on-agent:def wire sign)
  =/  core  core.unified.state
  =/  current  (~(get by writer-links.core) app)
  ?~  current  (on-agent:def wire sign)
  ?.  =(u.generation generation.u.current)  `this
  ?+  -.sign  (on-agent:def wire sign)
    %watch-ack
      ?~  p.sign
        `(set-core-write core(writer-links (set-connected:gce writer-links.core app %.y)))
      :_  (set-core-write core(writer-links (set-connected:gce writer-links.core app %.n)))
      ?:  (gte retries.u.current 12)  ~
      ~[(retry-card:gce app u.generation now.bowl)]
    %kick
      :_  (set-core-write core(writer-links (set-connected:gce writer-links.core app %.n)))
      ?:  (gte retries.u.current 12)  ~
      ~[(retry-card:gce app u.generation now.bowl)]
    %fact
      ?.  =(%noun p.cage.sign)
        `(set-core-write core(writer-links (bump-link:gce writer-links.core app %refused)))
      =/  event  ((soft graf-core-territory-event) q.q.cage.sign)
      ?~  event
        `(set-core-write core(writer-links (bump-link:gce writer-links.core app %refused)))
      =/  placed
        (place-structural:gce territories.core facts.core plots.core app fact.u.event)
      =.  facts.core  facts.placed
      =.  plots.core  plots.placed
      =.  writer-links.core
        (bump-link:gce writer-links.core app status.placed)
      `(set-core-write core)
  ==
::
++  on-arvo
  |=  [=wire sign=sign-arvo]
  ^-  (quip card _this)
  ?:  =(/bind wire)  `this
  ?.  ?=([%territory-retry @ @ ~] wire)  (on-arvo:def wire sign)
  ?.  ?=([%behn %wake *] sign)  (on-arvo:def wire sign)
  ?.  (writes-open:gce control.unified.state)  `this
  =/  app=@tas  `@tas`i.t.wire
  =/  generation=(unit @ud)  (slaw %ud i.t.t.wire)
  ?~  generation  (on-arvo:def wire sign)
  =/  core  core.unified.state
  =/  current  (~(get by writer-links.core) app)
  ?~  current  `this
  ?.  =(u.generation generation.u.current)  `this
  ::  S103.44: retry budget (the S103.35 storm).  Twelve watches per
  ::  reload, then the link parks silently -- no card, no core-write, no
  ::  revision churn; the next reload re-arms it with a fresh budget.
  ?:  (gte retries.u.current 12)  `this
  =/  next=graf-core-writer-link
    u.current(generation +(generation.u.current), connected %.n, retries +(retries.u.current))
  :_  (set-core-write core(writer-links (~(put by writer-links.core) app next)))
  ~[(watch-card:gce our.bowl app generation.next)]
::
++  on-fail   on-fail:def
--
