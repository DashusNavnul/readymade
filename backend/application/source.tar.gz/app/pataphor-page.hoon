::  /app/pataphor-page
::
::  THE PAGE. /apps/pataphor -- the workspace page, its scripts and the private
::  conversation. This is the part of the workspace that changes often, cut
::  out of %pataphor-chat so that changing it compiles ~12 files in seconds
::  instead of ~208 in two minutes (one core; a compile stops the ship for its
::  whole length). The heavy workspaces -- editor, glass, coding, results,
::  project sharing -- are %pataphor-work's, at /apps/pataphor-work.
::
::  The conversation lives here. On first boot the page adopts
::  %pataphor-chat's conversation state through its own-ship /x/state peek
::  (entries, the poll timer), so the cut loses nothing; it never pokes the
::  chat. Everything after that is lib/pataphor-chat-runtime: the same boot,
::  act, sign and tick. The connected chats (Noltbook notes) are gone with the
::  Noltbook app (2026-09-23); old ?note= ?connect= ?collaborate= links come
::  back to the conversation.
::
::  Eyre allows one owner per path. If %pataphor-chat still holds
::  /apps/pataphor when this agent asks for it, the bind is refused and the
::  page answers nothing until a %rebind poke (a %noun poke from this ship)
::  asks again -- after the chat has let go.
::
/-  pc=pataphor-chat
/+  rt=pataphor-chat-runtime, http=pataphor-chat-http, ui=pataphor-chat-page,
    asset=ui-asset, static-ui=ui-static-response, login-gate=readymade-page-http-gate, default-agent, fs=fedwiki-store, fws=fedwiki-serve,
    cv=clay-view, lv=law-view, history=readymade-history,
    compose=readymade-compose, publish=readymade-compose-publisher,
    execution=readymade-execution, execute=readymade-execution-publisher,
    projects=readymade-projects, changes=readymade-changes-publisher, model-setup=readymade-model-setup,
    apps=readymade-apps, tlon=readymade-tlon, management=readymade-app-management, resume=readymade-app-resume, remote=readymade-remote, bench-compose=readymade-bench-compose
=>  |%
    ::  one whole answer: header, body (none for HEAD), kick.  Untyped
    ::  because in this agent `http` is the page's own pataphor-chat-http,
    ::  not zuse's.
    ++  give
      |=  [id=@ta head=? status=@ud type=@t body=@t]
      ^-  (list card:rt)
      =/  header
        :-  status
        :~  ['content-type' type]
            ['cache-control' 'no-store']
            ['x-content-type-options' 'nosniff']
        ==
      =/  data=(unit octs)  ?:(head ~ `(as-octs:mimes:html body))
      =/  route=path  /http-response/[id]
      :~  [%give %fact ~[route] %http-response-header !>(header)]
          [%give %fact ~[route] %http-response-data !>(data)]
          [%give %kick ~[route] ~]
      ==
    ::  A shared projection for change subscribers and the seeded latest view.
    ++  exchange-fact
      |=  [entries=(list entry:pc) paths=(list path)]
      ^-  (list card:rt)
      ?~  entries  ~
      =/  e=entry:pc  i.entries
      :~  :*  %give  %fact  paths  %noun
              !>([%exchange-v1 id.e status.e request.e output.e (lent entries)])
          ==
      ==
    ::  Entries are newest-first. Existing /exchanges watchers get no replay.
    ++  spoke
      |=  [before=state-0:pc after=state-0:pc b=bowl:gall]
      ^-  (list card:rt)
      =/  latest=(list card:rt)
        ?:  =((mug entries.before) (mug entries.after))  ~
        (exchange-fact entries.after ~[/exchanges /exchanges/latest])
      ?.  (changed:history before after)  latest
      (weld latest (facts:history b after))
    --
::  remote-nacks is transient (not saved): the reasons Bench gave for refusing
::  a seat submission from the remote, read back beside the receipt.
=|  $:  state=state-0:pc  receipts=ledger:compose
        execution-cache=cache:execute  execution-poll=(unit @da)
        project-watches=watching:projects  asset-cache=(unit manifest:asset)
        management-journal=journal:management
        resume-journal=journal:resume
        remote-nacks=(map @uv @t)
        ::  shell actions and decisions a remote asked for: the answers by key,
        ::  and the ones still waiting on the terminal's response facts
        remote-replies=(map @uv reply:remote)
        remote-inflight=(map @uv [status=(unit @ud) body=(unit @t)])
    ==
^-  agent:gall
|_  =bowl:gall
+*  this  .
    def  ~(. (default-agent this %.n) bowl)
    with-execution
      |=  $:  cards=(list card:rt)  next=state-0:pc  ledger=ledger:compose
              known=cache:execute  poll=(unit @da)
          ==
      ^-  (quip card:rt _this)
      =/  refreshed=[cards=(list card:rt) known=cache:execute poll=(unit @da) chat=state-0:pc]
        (update:execute bowl next known poll)
      =/  observed=(list card:rt)
        (weld (spoke next chat.refreshed bowl) (spoke:publish bowl next chat.refreshed ledger ledger))
      [(coalesce:execute cards (weld cards.refreshed observed)) this(state chat.refreshed, receipts ledger, execution-cache known.refreshed, execution-poll poll.refreshed)]
    with-projects
      |=  out=(quip card:rt _this)
      ^-  (quip card:rt _this)
      =/  requested=watching:projects
        (~(uni in (desired:projects bowl)) (desks:changes our.bowl sup.bowl))
      =/  present=(set @tas)  .^((set @tas) %cd ~[(scot %p our.bowl) '' (scot %da now.bowl)])
      =/  subscriptions  (reconcile-desks:projects bowl project-watches (~(int in requested) present))
      =/  next=_this  +.out
      [(weld -.out cards.subscriptions) next(project-watches watching.subscriptions)]
    ::  the remote's one write, shared by the HTTP route and a moon's poke:
    ::  [status body cards next]; a status of 300 or more is a refusal whose
    ::  body carries the reason. The phone's id, the ship's nonce.
    remote-submit
      |=  sub=submission:remote
      ^-  [status=@ud body=json cards=(list card:rt) next=_this]
      ?:  ?=(%private -.destination.sub)
        ::  a known id never re-enters admission: its receipt is the answer
        =/  known=(unit stored:compose)  (~(get by receipts) id.sub)
        ?^  known
          ?.  (replay-ok:remote u.known state text.sub)
            [409 (error-json:remote 'Submission id was reused with a different command.') ~ this]
          [200 (private-receipt-json:remote reply.u.known) ~ this]
        ::  the same admission as the composer's %noun poke, answered in-line
        =/  cmd=command:compose
          [%readymade-command-v1 id.sub nonce.state [%ask text.sub]]
        =/  choice=decision:compose  (admit:compose our.bowl our.bowl cmd state receipts)
        ?:  ?=(%refuse -.choice)
          [409 (error-json:remote reason.choice) ~ this]
        ?:  ?=(%replay -.choice)
          [200 (private-receipt-json:remote reply.record.choice) ~ this]
        =/  next=state-0:pc
          state(nonce `@uv`(sham [nonce.state eny.bowl now.bowl]))
        =/  ctx  ~(. hc:rt bowl next)
        =/  out  (arm:ctx (act:ctx command.choice))
        =/  record=stored:compose
          (settle:compose our.bowl now.bowl cmd state +.out -.out)
        =/  next-receipts=ledger:compose  (remember:compose receipts record)
        =/  done
          (with-execution (weld -.out (weld (spoke state +.out bowl) (facts:publish bowl +.out next-receipts))) +.out next-receipts execution-cache execution-poll)
        [200 (private-receipt-json:remote reply.record) -.done +.done]
      ::  a seat: Bench admits it with its own nonce; the receipt is read back.
      ::  An id Bench already answered is replayed from that receipt, no poke.
      =/  prior=(unit bench-submission-lite:remote)
        (bench-receipt:remote our.bowl now.bowl id.sub)
      ?:  &(?=(^ prior) ?=(^ reply.u.prior))
        [200 (bench-receipt-json:remote id.sub reply.u.prior (~(get by remote-nacks) id.sub)) ~ this]
      =/  nonce=(unit @uv)  (bench-nonce:remote our.bowl now.bowl)
      ?~  nonce
        [503 (error-json:remote 'Bench is not available.') ~ this]
      =/  seat=@tas  seat.destination.sub
      =/  cmd=command:bench-compose  [%readymade-bench-command-v1 id.sub u.nonce seat text.sub]
      :^    202  (submitted-json:remote id.sub seat)
          ~[[%pass /remote/bench/(scot %uv id.sub) %agent [our.bowl %bench] %poke %noun !>(cmd)]]
      this(remote-nacks (~(del by remote-nacks) id.sub))
    ::  the remote's reads, shared by the HTTP routes and a moon's subscriptions
    remote-read
      |=  w=want:remote
      ^-  json
      ?-    -.w
          %receipt
        ?:  ?=(%private -.destination.w)
          =/  record=(unit stored:compose)  (~(get by receipts) id.w)
          ?~  record
            (pairs:enjs:format ~[['known' b+%.n] ['destination' s+'private'] ['id' s+(scot %uv id.w)]])
          (private-receipt-json:remote reply.u.record)
        =/  found=(unit bench-submission-lite:remote)  (bench-receipt:remote our.bowl now.bowl id.w)
        (bench-receipt-json:remote id.w ?~(found ~ reply.u.found) (~(get by remote-nacks) id.w))
      ::
          %execution
        (execution-json:remote id.w (bench-execution:remote our.bowl now.bowl id.w))
      ::
          %state   (state-json:remote bowl state ~(wyt by receipts) cursor.w)
          %terminal  (terminal-json:remote our.bowl now.bowl app.w offset.w)
          %coding    (coding-json:remote our.bowl now.bowl sid.w after.w)
          %board     (board-json:remote our.bowl now.bowl)
          %reply     (reply-json:remote (~(get by remote-replies) key.w))
          %page    ~
          %submit  ~
          %terminal-act  ~
          %decide  ~
      ==
    ::  a shell action from the remote: this agent plays Eyre toward its own
    ::  terminal agent (watch the response path, poke the request); the
    ::  answer is kept by key and given on /remote/reply/<key>
    remote-act
      |=  [key=@uv app=@tas nonce=@uv body=@t]
      ^-  (list card:rt)
      =/  id=@ta  `@ta`(cat 3 'remote-terminal-' (scot %uv key))
      :~  [%pass /remote-term/(scot %uv key) %agent [our.bowl app] %watch /http-response/[id]]
          [%pass /remote-term/(scot %uv key) %agent [our.bowl app] %poke %handle-http-request !>((terminal-request:remote id app nonce body))]
      ==
    ::  a candidate decision from the remote: the desk's own noun to cantrip;
    ::  cantrip's ack or nack is the answer
    remote-decide-cards
      |=  [key=@uv source=@ux action=@tas id=@ux]
      ^-  (list card:rt)
      ~[[%pass /remote-decide/(scot %uv key) %agent [our.bowl %cantrip] %poke %noun !>([%readymade-permissions-action-v1 source [action id]])]]
    remote-settle
      |=  [key=@uv r=reply:remote]
      ^-  (quip card:rt _this)
      =/  pax=path  /remote/reply/(scot %uv key)
      =/  kept=(map @uv reply:remote)
        ?:((gth ~(wyt by remote-replies) 128) ~ remote-replies)
      :_  this(remote-replies (~(put by kept) key r), remote-inflight (~(del by remote-inflight) key))
      :~  [%give %fact ~[pax] %noun !>([%readymade-remote-json-v1 (en:json:html (reply-json:remote `r))])]
          [%give %kick ~[pax] ~]
      ==
    remote-error
      |=  msg=@t
      ^-  @t
      (en:json:html (error-json:remote msg))
++  on-init
  ^-  (quip card:rt _this)
  ::  adopt the chat's conversation if the chat is here to give it; else fresh.
  =/  adopted=(unit state-0:pc)
    ?.  .^(? %gu /(scot %p our.bowl)/pataphor-chat/(scot %da now.bowl)/$)  ~
    ((soft state-0:pc) .^(* %gx /(scot %p our.bowl)/pataphor-chat/(scot %da now.bowl)/state/noun))
  =/  token=@uv  `@uv`(sham [eny.bowl now.bowl %pataphor-page])
  =/  next=state-0:pc
    ?^  adopted  u.adopted(nonce token, poll-at ~)
    state(nonce token, epoch `@ta`(cat 3 'pataphor-private-' (scot %uv token)), next 1)
  =/  ctx  ~(. hc:rt bowl next)
  =/  out  (arm:ctx [boot:ctx next])
  (with-projects (with-execution (weld -.out (weld (facts:history bowl +.out) (facts:publish bowl +.out receipts))) +.out receipts ~ ~))
::  Execution caches and viewer timers are transient; the whole v2 save stays.
++  on-save
  !>([%pataphor-page-state-v4 [%pataphor-page-state-v2 state receipts] management-journal resume-journal])
++  on-load
  |=  old=vase
  ^-  (quip card:rt _this)
  =/  resumed  (unwrap:resume our.bowl old)
  ?>  ?=(^ resumed)
  =.  resume-journal  resume.u.resumed
  =/  unpacked  (unwrap:management our.bowl previous.u.resumed)
  ?>  ?=(^ unpacked)
  =.  management-journal  management.u.unpacked
  ?>  (valid-journal:resume our.bowl management-journal resume-journal)
  =/  saved  (restore:compose previous.u.unpacked)
  ::  An incompatible save must refuse adoption, never initialize over it.
  ?>  ?=(^ saved)
  =/  next=state-0:pc  chat.u.saved
  ::  Expire old forms; keep the transcript and execution ids. Forget the poll
  ::  timer: a wake set before this load may never arrive, and boot re-arms
  ::  one whenever a request is still active.
  =.  nonce.next  `@uv`(sham [eny.bowl now.bowl nonce.next])
  =.  poll-at.next  ~
  =/  ctx  ~(. hc:rt bowl next)
  =/  out  (arm:ctx [boot:ctx next])
  =/  saved-receipts=ledger:compose  receipts.u.saved
  (with-projects (with-execution (weld -.out (weld (facts:history bowl +.out) (facts:publish bowl +.out saved-receipts))) +.out saved-receipts ~ ~))
++  on-poke
  |=  [=mark =vase]
  ^-  (quip card:rt _this)
  ?.  =(%handle-http-request mark)
    ::  a moon's submission (lib/readymade-remote): the same gate as the
    ::  phone's POST; a refusal is this poke's nack, carrying the reason
    ?:  &(=(%noun mark) ?=([%readymade-remote-submit-v1 *] q.vase))
      ?>  |((team:title our.bowl src.bowl) (moon:title our.bowl src.bowl))
      =/  sub=(unit submission:remote)  (parse-submit-noun:remote q.vase)
      ?~  sub  ~|('Send id, destination and text.' !!)
      =/  out  (remote-submit u.sub)
      ?:  (gte status.out 300)  ~|((text-field:remote body.out 'error') !!)
      [cards.out next.out]
    ?:  &(=(%noun mark) ?=([%readymade-remote-terminal-v1 *] q.vase))
      ?>  |((team:title our.bowl src.bowl) (moon:title our.bowl src.bowl))
      =/  act=(unit moon-terminal:remote)  (parse-terminal-noun:remote q.vase)
      ?~  act  ~|('Send key, app, nonce and body.' !!)
      [(remote-act key.u.act app.u.act nonce.u.act body.u.act) this]
    ?:  &(=(%noun mark) ?=([%readymade-remote-decide-v1 *] q.vase))
      ?>  |((team:title our.bowl src.bowl) (moon:title our.bowl src.bowl))
      =/  dec=(unit moon-decide:remote)  (parse-decide-noun:remote q.vase)
      ?~  dec  ~|('Send key, source, action and id.' !!)
      [(remote-decide-cards key.u.dec source.u.dec action.u.dec id.u.dec) this]
    ?>  =(src.bowl our.bowl)
    ?>  =(%noun mark)
    ?:  =([%readymade-project-refresh-v1 ~] q.vase)
      (with-projects [(weld (facts:projects bowl) (facts:changes bowl ~)) this])
    ?:  =(%rebind q.vase)
      =/  ctx  ~(. hc:rt bowl state)
      =/  out  (arm:ctx [boot:ctx state])
      (with-execution -.out +.out receipts execution-cache execution-poll)
    =/  command=(unit command:compose)  ((soft command:compose) q.vase)
    ?>  ?=(^ command)
    =/  choice=decision:compose  (admit:compose our.bowl src.bowl u.command state receipts)
    ?:  ?=(%refuse -.choice)
      ~|  reason.choice
      !!
    ?:  ?=(%replay -.choice)
      (with-execution (facts:publish bowl state receipts) state receipts execution-cache execution-poll)
    =/  next=state-0:pc
      state(nonce `@uv`(sham [nonce.state eny.bowl now.bowl]))
    =/  ctx  ~(. hc:rt bowl next)
    =/  out  (arm:ctx (act:ctx command.choice))
    =/  record=stored:compose
      (settle:compose our.bowl now.bowl u.command state +.out -.out)
    =/  next-receipts=ledger:compose  (remember:compose receipts record)
    (with-execution (weld -.out (weld (spoke state +.out bowl) (facts:publish bowl +.out next-receipts))) +.out next-receipts execution-cache execution-poll)
  ::  Anonymous HTTP is answered only on its watch's current duct. A foreign
  ::  poke must never broadcast even a redirect to a guessed owner's id.
  ?.  =(src.bowl our.bowl)  `this
  =+  !<([id=@ta req=inbound-request:eyre] vase)
  =/  head=?  =('HEAD' method.request.req)
  ?.  &(authenticated.req =(src.bowl our.bowl))
    [(respond:http id 307 '' ~[['location' '/~/login?redirect=%2Fapps%2Fpataphor']] head) this]
  ::  Reconnection is one fixed native publisher task, separately journaled.
  ?:  =(base:resume (end [3 (met 3 base:resume)] url.request.req))
    =/  result=response:resume  (handle:resume bowl req management-journal resume-journal)
    :_  this(resume-journal journal.result)
    (weld cards.result (give id head code.result 'application/json; charset=utf-8' (en:json:html body.result)))
  ::  The management helper authenticates this owner request and journals first.
  ?:  =(base:management (end [3 (met 3 base:management)] url.request.req))
    =/  result=response:management
      (gate-pause:resume our.bowl resume-journal (handle:management bowl req management-journal))
    :_  this(management-journal journal.result)
    (weld cards.result (give id head code.result 'application/json; charset=utf-8' (en:json:html body.result)))
  ::  Installed Tlon tasks: owner-only metadata/preparation, never dispatch.
  ?:  =('/apps/pataphor/app-tasks/tlon/capabilities.json' url.request.req)
    ?.  |(=('GET' method.request.req) head)
      [(respond:http id 405 'Use GET or HEAD.' ~[['allow' 'GET, HEAD']] head) this]
    [(give id head 200 'application/json; charset=utf-8' (en:json:html (native-capabilities:tlon bowl))) this]
  ?:  =('/apps/pataphor/app-tasks/tlon/prepare.json' url.request.req)
    ?.  =('POST' method.request.req)
      [(respond:http id 405 'Use POST.' ~[['allow' 'POST']] head) this]
    =/  headers=(map @t @t)  (~(gas by *(map @t @t)) header-list.request.req)
    ?.  =(`'application/json' (~(get by headers) 'content-type'))
      [(respond:http id 415 'Use application/json.' ~ %.n) this]
    =/  body=(unit octs)  body.request.req
    ?~  body  [(respond:http id 400 'Empty preparation request.' ~ %.n) this]
    ?.  &((lte p.u.body 32.768) =(p.u.body (met 3 q.u.body)))
      [(respond:http id 413 'Preparation request exceeds its bound.' ~ %.n) this]
    =/  prepared  (native-prepare:tlon bowl `@t`q.u.body)
    [(give id %.n status.prepared 'application/json; charset=utf-8' (en:json:html value.prepared)) this]
  ?:  =('/apps/pataphor/installed-apps.json' url.request.req)
    ?.  |(=('GET' method.request.req) head)
      [(respond:http id 405 'Use GET or HEAD.' ~[['allow' 'GET, HEAD']] head) this]
    [(give id head 200 'application/json; charset=utf-8' (en:json:html (native:apps bowl))) this]
  ?:  =('/apps/pataphor/model-setup.json' url.request.req)
    ?.  =('GET' method.request.req)
      [(respond:http id 405 'Use GET.' ~[['allow' 'GET']] head) this]
    =/  read=reader:model-setup
      |=  [agent=@tas query=path]
      (native:model-setup bowl agent query)
    =/  data=json  (view:model-setup our.bowl now.bowl read)
    [(give id %.n 200 'application/json; charset=utf-8' (en:json:html data)) this]
  ::  the remote (lib/readymade-remote): a phone's page and its one read-only
  ::  projection of the conversation, Bench's seats and Cantrip's candidates
  ::  (the local face is not `remote`: that would shadow the library alias)
  =/  rem=(unit want:remote)  (route:remote url.request.req)
  ?^  rem
    =/  jtype=@t  'application/json; charset=utf-8'
    ::  the one write: the phone's id and text, the ship's nonce
    ?:  ?=(%submit -.u.rem)
      ?.  =('POST' method.request.req)
        [(respond:http id 405 'Use POST.' ~[['allow' 'POST']] %.n) this]
      =/  parsed=(unit submission:remote)
        (parse-submit:remote header-list.request.req body.request.req)
      ?~  parsed
        [(give id %.n 400 jtype (en:json:html (error-json:remote 'Send JSON with id, destination and text.'))) this]
      =/  out  (remote-submit u.parsed)
      [(weld cards.out (give id %.n status.out jtype (en:json:html body.out))) next.out]
    ::  the two writes that answer later, by key: a shell action, a decision
    ?:  ?=(%terminal-act -.u.rem)
      ?.  =('POST' method.request.req)
        [(respond:http id 405 'Use POST.' ~[['allow' 'POST']] %.n) this]
      =/  act  (parse-act:remote header-list.request.req body.request.req)
      ?~  act
        [(give id %.n 400 jtype (en:json:html (error-json:remote 'Send JSON with the terminal nonce header.'))) this]
      =/  key=@uv  `@uv`(sham [eny.bowl now.bowl id %remote-terminal])
      [(weld (remote-act key app.u.rem nonce.u.act body.u.act) (give id %.n 202 jtype (en:json:html (accepted-json:remote key)))) this]
    ?:  ?=(%decide -.u.rem)
      ?.  =('POST' method.request.req)
        [(respond:http id 405 'Use POST.' ~[['allow' 'POST']] %.n) this]
      =/  dec  (parse-decide:remote header-list.request.req body.request.req)
      ?~  dec
        [(give id %.n 400 jtype (en:json:html (error-json:remote 'Send JSON with source, action and id.'))) this]
      =/  key=@uv  `@uv`(sham [eny.bowl now.bowl id %remote-decide])
      [(weld (remote-decide-cards key source.u.dec action.u.dec id.u.dec) (give id %.n 202 jtype (en:json:html (accepted-json:remote key)))) this]
    ?.  |(=('GET' method.request.req) head)
      [(respond:http id 405 'Use GET or HEAD.' ~[['allow' 'GET, HEAD']] head) this]
    ?:  ?=(%page -.u.rem)
      [(respond:http id 200 (page:remote our.bowl) ~ head) this]
    [(give id head 200 jtype (en:json:html (remote-read u.rem))) this]
  ::  Static Hawk heads resolve current module revisions through small,
  ::  uncached redirects; the destination alone has immutable cache policy.
  =/  bootstrap=@t  '/apps/pataphor/bootstrap/'
  ?:  =(bootstrap (end [3 (met 3 bootstrap)] url.request.req))
    ?.  |(=('GET' method.request.req) head)
      [(respond:http id 405 'Use GET or HEAD.' ~[['allow' 'GET, HEAD']] head) this]
    =/  name=(unit @ta)
      ?:  =('/apps/pataphor/bootstrap/readymade-compose.js' url.request.req)  `%readymade-compose
      ?:  =('/apps/pataphor/bootstrap/readymade-workspace.js' url.request.req)  `%readymade-workspace
      ?:  =('/apps/pataphor/bootstrap/readymade-editor.js' url.request.req)  `%readymade-editor
      ~
    ?~  name  [(respond:http id 404 'Unknown bootstrap module.' ~ head) this]
    =/  current=manifest:asset  (refresh:asset bowl asset-cache)
    =/  next=_this  this(asset-cache `current)
    =/  ref=(unit reference:asset)  (~(get by files.current) u.name)
    ?~  ref  [(respond:http id 404 'Asset not present on this desk.' ~ head) next]
    [(respond:http id 302 '' ~[['location' (url:asset u.ref)]] head) next]
  ::  Aliases and the manifest refresh one bounded cache by Clay revisions.
  ::  An immutable URL reads its exact revision, never the newest alias.
  =/  script=(unit request:asset)  (route:asset url.request.req)
  ?^  script
    ?.  |(=('GET' method.request.req) head)
      [(respond:http id 405 'Use GET or HEAD.' ~[['allow' 'GET, HEAD']] head) this]
    ?:  ?=(%bad -.u.script)
      [(respond:http id 404 'Asset not present on this desk.' ~ head) this]
    ?:  ?=(%immutable -.u.script)
      =/  found=(unit @t)  (read-reference:asset bowl ref.u.script)
      ?~  found  [(respond:http id 404 'Asset not present on this desk.' ~ head) this]
      [(immutable:static-ui header-list.request.req u.found (give id head 200 'application/javascript; charset=utf-8' u.found)) this]
    =/  current=manifest:asset  (refresh:asset bowl asset-cache)
    =/  next=_this  this(asset-cache `current)
    ?:  ?=(%manifest -.u.script)
      [(give id head 200 'application/json; charset=utf-8' (en:json:html (json:asset current))) next]
    =/  ref=(unit reference:asset)  (~(get by files.current) base.u.script)
    ?~  ref  [(respond:http id 404 'Asset not present on this desk.' ~ head) next]
    =/  found=(unit @t)  (read-reference:asset bowl u.ref)
    ?~  found  [(respond:http id 404 'Asset not present on this desk.' ~ head) this]
    [(revalidate:static-ui header-list.request.req u.found (give id head 200 'application/javascript; charset=utf-8' u.found)) next]
  ::  Bounded owner-only desk tasks. The helper reserves malformed task paths;
  ::  these reads emit HTTP answers only and never change project watches.
  =/  desk-task=(unit task-request:projects)  (task-path:projects url.request.req)
  ?^  desk-task
    ?.  |(=('GET' method.request.req) head)
      [(respond:http id 405 'Use GET or HEAD.' ~[['allow' 'GET, HEAD']] head) this]
    =/  out  (serve-task:projects bowl u.desk-task)
    [(give id head status.out 'application/json; charset=utf-8' body.out) this]
  ::  the review pane (lib/clay-view): Ford-free reads of desks, a desk's
  ::  files and a file's text; and one write, a POST that saves a file on a
  ::  bachelor's dead fork (one %info, emitted with the answer)
  =/  clay=(unit want:cv)  (clay-path:cv url.request.req)
  ?^  clay
    ::  (?= inside &() would not refine u.clay; its own ?: does)
    ?:  ?=(%save -.u.clay)
      ?.  =('POST' method.request.req)
        [(respond:http id 405 'A save is a POST.' ~[['allow' 'POST']] head) this]
      =/  out  (save:cv our.bowl now.bowl desk.u.clay path.u.clay header-list.request.req body.request.req)
      [(weld cards.out (give id %.n status.out type.out body.out)) this]
    ?.  |(=('GET' method.request.req) head)
      [(respond:http id 405 'Use GET or HEAD.' ~[['allow' 'GET, HEAD']] head) this]
    =/  out  (serve:cv our.bowl now.bowl u.clay)
    [(give id head status.out type.out body.out) this]
  ::  the law panel (lib/law-view): bench's words, cantrip's acts, and the
  ::  act law's one write (a POST that lights a graf fact)
  =/  law  (law-path:lv url.request.req)
  ?^  law
    ?:  ?=(^ u.law)
      ?.  =('POST' method.request.req)
        [(respond:http id 405 'Use POST.' ~[['allow' 'POST']] head) this]
      =/  out  (act:lv our.bowl now.bowl verb.u.law act.u.law header-list.request.req)
      [(weld cards.out (give id %.n status.out 'application/json; charset=utf-8' body.out)) this]
    ?.  |(=('GET' method.request.req) head)
      [(respond:http id 405 'Use GET or HEAD.' ~[['allow' 'GET, HEAD']] head) this]
    =/  out  ?-(u.law %acts (acts:lv our.bowl now.bowl), %words (words:lv our.bowl now.bowl))
    [(give id head status.out 'application/json; charset=utf-8' body.out) this]
  ::  the heavy workspaces are %pataphor-work's at /apps/pataphor-work. A link
  ::  that still says /apps/pataphor?glass=... (an old page, the native
  ::  console's pages) is sent there with its query intact; 307 keeps a POST a
  ::  POST. The conversation's old keys (?note= ?connect= ?collaborate=, the
  ::  connected chats) come back to the conversation itself.
  =/  query=(unit tape)
    =/  url=@t  url.request.req
    =/  prefix=@t  '/apps/pataphor?'
    =/  size=@ud  (met 3 prefix)
    ?.  &((gth (met 3 url) size) =(prefix (end [3 size] url)))  ~
    =/  rest=tape  (trip (rsh [3 size] url))
    `(scag (fall (find "=" rest) (lent rest)) rest)
  ?^  query
    ?:  ?|(=("note" u.query) =("connect" u.query) =("collaborate" u.query))
      [(respond:http id 307 '' ~[['location' '/apps/pataphor']] head) this]
    ?.  .^(? %gu /(scot %p our.bowl)/pataphor-work/(scot %da now.bowl)/$)
      [(respond:http id 503 '<p>Advanced Work pages are unavailable on this ship. <a href="/apps/pataphor">Open Readymade</a>.</p>' ~ head) this]
    =/  to=@t  (cat 3 '/apps/pataphor-work' (rsh [3 14] url.request.req))
    [(respond:http id 307 '' ~[['location' to]] head) this]
  ::  the ship's root and any route whose agent is gone are bound here (eyre
  ::  keeps a binding after its agent stops): the root goes to the page,
  ::  anything else is not found
  ?:  |(=('/' url.request.req) =('/?' (end [3 2] url.request.req)))
    [(respond:http id 307 '' ~[['location' '/apps/pataphor']] head) this]
  ::  the ship's cards as a fedwiki site: GET /<slug>.json and
  ::  /system/sitemap.json (lib/fedwiki-serve), read from graf's
  ::  %fedwiki-page facts.  Signed in only, like everything on this page,
  ::  until the operator opens the site to other fedwiki clients.
  =/  wiki  (wiki-path:fws url.request.req)
  ?^  wiki
    ?.  |(=('GET' method.request.req) head)
      [(respond:http id 405 'Use GET or HEAD.' ~[['allow' 'GET, HEAD']] head) this]
    ?.  .^(? %gu /(scot %p our.bowl)/graf/(scot %da now.bowl)/$)
      [(respond:http id 503 'graf is not running' ~ head) this]
    =/  out  (serve:fws u.wiki (pages:fs (read-facts:fws our.bowl now.bowl)))
    [(give id head status.out (cat 3 type.out '; charset=utf-8') body.out) this]
  ::  the conversation: the page, or a form
  =/  location=(unit location:http)  (locate:http url.request.req)
  ?~  location
    [(respond:http id 404 'Not found.' ~ head) this]
  ?:  |(=('GET' method.request.req) head)
    =/  view=view:pc  [our.bowl state ~ %.n ~ ~ ~]
    =/  current=manifest:asset  (refresh:asset bowl asset-cache)
    ::  Presentation availability comes only from this owner's native app state.
    =/  work=?  .^(? %gu /(scot %p our.bowl)/pataphor-work/(scot %da now.bowl)/$)
    =/  coding=?  .^(? %gu /(scot %p our.bowl)/pataphor-native-console/(scot %da now.bowl)/$)
    [(respond:http id 200 (page-with-capabilities:ui view current work coding) ~ head) this(asset-cache `current)]
  ?.  =('POST' method.request.req)
    [(respond:http id 405 'Use GET or POST.' ~[['allow' 'GET, HEAD, POST']] %.n) this]
  =/  headers=(map @t @t)  (~(gas by *(map @t @t)) header-list.request.req)
  =/  ct=(unit @t)  (~(get by headers) 'content-type')
  ?.  =(`'application/x-www-form-urlencoded' ct)
    [(respond:http id 415 'Use the workspace form.' ~ %.n) this]
  =/  body=(unit octs)  body.request.req
  ?~  body
    [(respond:http id 400 'Empty form.' ~ %.n) this]
  ?:  (gth p.u.body 16.384)
    [(respond:http id 413 'Form too large.' ~ %.n) this]
  =/  command=(unit action:pc)  (decode:http nonce.state q.u.body)
  ?~  command
    [(respond:http id 403 'Invalid or expired form. Reload Pataphor before submitting again.' ~ %.n) this]
  =/  next=state-0:pc
    state(nonce `@uv`(sham [nonce.state eny.bowl now.bowl]))
  =/  ctx  ~(. hc:rt bowl next)
  =/  out  (arm:ctx (act:ctx u.command))
  (with-execution (weld -.out (weld (spoke state +.out bowl) (weld (spoke:publish bowl state +.out receipts receipts) (respond:http id 303 '' ~[['location' '/apps/pataphor']] %.n)))) +.out receipts execution-cache execution-poll)
++  on-agent
  |=  [=wire event=sign:agent:gall]
  ^-  (quip card:rt _this)
  ::  Gall authenticates the response on the wire sent to our own Hood.
  ?:  ?=([%reconnect @ ~] wire)
    ?.  &(=(src.bowl our.bowl) ?=(%poke-ack -.event))  `this
    =/  request=@t  `@t`i.t.wire
    ?.  (uuid:management request)  `this
    =/  accepted=?  =(~ p.event)
    =/  observed=snapshot:management
      ?:  (needs-observation:resume resume-journal request accepted)
        (native:management bowl)
      [%.n our.bowl ~ ~]
    `this(resume-journal (acknowledge:resume our.bowl management-journal resume-journal request accepted observed))
  ?:  ?=([%management @ ~] wire)
    ?.  &(=(src.bowl our.bowl) ?=(%poke-ack -.event))  `this
    =/  request=@t  `@t`i.t.wire
    ?.  (uuid:management request)  `this
    =/  known=(unit receipt:management)  (~(get by management-journal) request)
    ?~  known  `this
    ?.  &(=(%pending status.u.known) =(%none ack.u.known))  `this
    `this(management-journal (acknowledge:management our.bowl management-journal request =(~ p.event) ?~(p.event (native:management bowl) [%.n our.bowl ~ ~])))
  ::  a remote's shell action: the terminal agent answers as it would Eyre,
  ::  a header fact, a data fact, then a kick; a refusal at either hop is
  ::  itself the answer
  ?:  ?=([%remote-term @ ~] wire)
    =/  key=(unit @uv)  (slaw %uv i.t.wire)
    ?~  key  `this
    ?-    -.event
        %poke-ack
      ?~  p.event  `this
      (remote-settle u.key [502 (remote-error 'The terminal refused the request.')])
    ::
        %watch-ack
      ?~  p.event  `this
      (remote-settle u.key [502 (remote-error 'The terminal refused the watch.')])
    ::
        %kick
      =/  cur=(unit [status=(unit @ud) body=(unit @t)])  (~(get by remote-inflight) u.key)
      ?~  cur  (remote-settle u.key [502 (remote-error 'The terminal closed without an answer.')])
      ?~  status.u.cur  (remote-settle u.key [502 (remote-error 'The terminal closed without an answer.')])
      (remote-settle u.key [u.status.u.cur (fall body.u.cur '')])
    ::
        %fact
      =/  cur=[status=(unit @ud) body=(unit @t)]  (fall (~(get by remote-inflight) u.key) [~ ~])
      ::  (`http` here is the chat library alias, so the kernel's record is spelled out)
      ?:  =(%http-response-header p.cage.event)
        =/  hdr  !<([status-code=@ud headers=*] q.cage.event)
        `this(remote-inflight (~(put by remote-inflight) u.key cur(status `status-code.hdr)))
      ?:  =(%http-response-data p.cage.event)
        =/  dat  !<((unit octs) q.cage.event)
        =/  text=@t  ?~(dat '' `@t`q.u.dat)
        `this(remote-inflight (~(put by remote-inflight) u.key cur(body `text)))
      `this
    ==
  ?:  ?=([%remote-decide @ ~] wire)
    ?.  ?=(%poke-ack -.event)  `this
    =/  key=(unit @uv)  (slaw %uv i.t.wire)
    ?~  key  `this
    ?~  p.event  (remote-settle u.key [200 '{"acked":true}'])
    (remote-settle u.key [409 (remote-error (nack-reason:remote u.p.event))])
  ::  a seat submission from the remote: Bench's nack reason is kept for the
  ::  receipt read; an ack needs nothing, the receipt itself is Bench's
  ?:  ?=([%remote %bench @ ~] wire)
    ?.  ?=(%poke-ack -.event)  `this
    ?~  p.event  `this
    =/  rid=(unit @uv)  (slaw %uv i.t.t.wire)
    ?~  rid  `this
    `this(remote-nacks (remember-nack:remote remote-nacks u.rid (nack-reason:remote u.p.event)))
  =/  out  (sign:~(. hc:rt bowl state) wire event)
  (with-execution (weld -.out (weld (spoke state +.out bowl) (spoke:publish bowl state +.out receipts receipts))) +.out receipts execution-cache execution-poll)
++  on-arvo
  |=  [=wire =sign-arvo]
  ^-  (quip card:rt _this)
  =/  desk=(unit @tas)  (wake:projects wire sign-arvo)
  ?^  desk
    ?.  (~(has in project-watches) u.desk)  `this
    =/  cards=(list card:rt)
      (weld (changed:projects bowl u.desk) (facts:changes bowl `u.desk))
    ?:  (~(has in (desired:projects bowl)) u.desk)  [cards this]
    [(snoc cards (watch:projects bowl u.desk)) this]
  ?.  ?=([%behn %wake *] sign-arvo)  `this
  ?:  ?=([%readymade-execution *] wire)
    ?.  (wake:execute wire execution-poll)  `this
    (with-execution ~ state receipts execution-cache ~)
  =/  out  (tick:~(. hc:rt bowl state) wire)
  (with-execution (weld -.out (weld (spoke state +.out bowl) (spoke:publish bowl state +.out receipts receipts))) +.out receipts execution-cache execution-poll)
++  on-peek
  |=  =path
  ^-  (unit (unit cage))
  ?~  path  ~
  ?:  ?=([%x %changes *] path)
    ?.  =(our.bowl src.bowl)  ~
    =/  req  (route:changes t.path)
    ?~  req  ~
    ``noun+!>((project:changes bowl u.req))
  ?:  ?=([%x %projects *] path)
    ?.  =(our.bowl src.bowl)  ~
    =/  req  (route:projects t.path)
    ?~  req  ~
    ``noun+!>((project:projects bowl u.req))
  ?:  ?=([%x %conversation %execution *] path)
    ?.  =(our.bowl src.bowl)  ~
    =/  r=(unit request:execute)  (route:execute t.path)
    ?~  r  ~
    ``noun+!>((project:execute bowl u.r state))
  ?:  |(=(/x/conversation/compose path) ?=([%x %conversation %submission *] path))
    ?.  =(our.bowl src.bowl)  ~
    =/  value  (project:publish t.path state receipts)
    ?~  value  ~
    ``noun+!>(u.value)
  ?:  ?=([%x %conversation %history *] path)
    ?.  =(our.bowl src.bowl)  ~
    =/  r=(unit request:history)  (route:history t.path)
    ?~  r  ~
    ``noun+!>((project:history act.bowl u.r state))
  ?+  path  ~
    [%x %state ~]
      ?.(=(our.bowl src.bowl) ~ ``noun+!>(state))
    [%x %status ~]
      ?.  =(our.bowl src.bowl)  ~
      ``noun+!>([epoch.state (lent entries.state) active.state ~(wyt by connected.state) ?=(^ pending.state) error.state])
    [%x %conversation %execution-status ~]
      ?.  =(our.bowl src.bowl)  ~
      ``noun+!>([%readymade-execution-publisher-v1 (lent (paths:execute our.bowl sup.bowl)) ~(wyt by execution-cache) execution-poll])
    [%x %ui @ ~]
      =/  name=@ta  i.t.t.path
      ?.  =(our.bowl src.bowl)  ~
      ``noun+!>((latest:asset bowl name %js))
    [%x %ui-manifest ~]
      ?.  =(our.bowl src.bowl)  ~
      ``noun+!>((refresh:asset bowl asset-cache))
  ==
++  on-watch
  |=  =path
  ^-  (quip card:rt _this)
  ?:  ?=([%http-response @ ~] path)
    =/  answer=(unit (list card:rt))
      (watch:login-gate our.bowl src.bowl path sup.bowl)
    ?>  ?=(^ answer)
    [u.answer this]
  ::  a moon's one-shot read (lib/readymade-remote): one fact, then a kick
  ?:  ?=([%remote *] path)
    ?>  |((team:title our.bowl src.bowl) (moon:title our.bowl src.bowl))
    =/  w=(unit want:remote)  (watch-route:remote path)
    ?>  ?=(^ w)
    ::  a reply not yet known is given on this path when it settles
    ?:  ?=(%reply -.u.w)
      ?.  (~(has by remote-replies) key.u.w)  `this
      [(json-fact:remote (remote-read u.w)) this]
    [(json-fact:remote (remote-read u.w)) this]
  ?:  ?=([%changes *] path)
    ?>  =(our.bowl src.bowl)
    =/  req  (route:changes path)
    ?>  ?=(^ req)
    ?>  (admit:changes path (paths:changes our.bowl sup.bowl))
    (with-projects [~[[%give %fact ~[path] %noun !>((project:changes bowl u.req))]] this])
  ?:  ?=([%projects *] path)
    ?>  =(our.bowl src.bowl)
    =/  req  (route:projects path)
    ?>  ?=(^ req)
    ?>  (admit:projects path (paths:projects our.bowl sup.bowl))
    (with-projects [~[[%give %fact ~[path] %noun !>((project:projects bowl u.req))]] this])
  ?:  ?=([%conversation %execution *] path)
    ?>  =(our.bowl src.bowl)
    =/  r=(unit request:execute)  (route:execute path)
    ?>  ?=(^ r)
    ?>  (retained:execute u.r state)
    =/  wanted=(list (list @ta))  (paths:execute our.bowl sup.bowl)
    ?>  (admit:execute path wanted)
    =/  value=snapshot:execution  (project:execute bowl u.r state)
    =/  known=cache:execute  (prune:execute execution-cache wanted)
    =/  timer  (arm:execute now.bowl execution-poll %.y)
    [(weld ~[[%give %fact ~ %noun !>(value)]] -.timer) this(execution-cache (~(put by known) path value), execution-poll +.timer)]
  ?:  |(=(/conversation/compose path) ?=([%conversation %submission *] path))
    ?>  =(our.bowl src.bowl)
    =/  value  (project:publish path state receipts)
    ?>  ?=(^ value)
    [~[[%give %fact ~ %noun !>(u.value)]] this]
  ?:  ?=([%conversation %history *] path)
    ?>  =(our.bowl src.bowl)
    =/  r=(unit request:history)  (route:history path)
    ?>  ?=(^ r)
    [~[[%give %fact ~ %noun !>((project:history act.bowl u.r state))]] this]
  ::  /exchanges: this ship's own watchers hear the conversation move -- one
  ::  fact per change to the latest entry -- with nothing replayed; the page
  ::  already shows the transcript. What used to need "refresh the conversation".
  ?.  |(=(/exchanges path) =(/exchanges/latest path))  (on-watch:def path)
  ?>  =(our.bowl src.bowl)
  ?:  =(/exchanges/latest path)
    [(exchange-fact entries.state ~[/exchanges/latest]) this]
  `this
++  on-leave
  |=  =path
  ^-  (quip card:rt _this)
  ?:  ?=([%http-response @ ~] path)
    ::  No persistent HTTP subscriber state; anonymous redirect already kicked.
    `this
  ?:  |(?=([%projects *] path) ?=([%changes *] path))  (with-projects [~ this])
  ?.  ?=([%conversation %execution *] path)  (on-leave:def path)
  ::  Native Gall removes the departing duct before constructing this bowl.
  ::  Other viewers of the same path still keep its cache and single timer.
  =/  wanted=(list (list @ta))  (paths:execute our.bowl sup.bowl)
  =/  timer  (arm:execute now.bowl execution-poll ?=(^ wanted))
  [-.timer this(execution-cache (prune:execute execution-cache wanted), execution-poll +.timer)]
++  on-fail   on-fail:def
--
