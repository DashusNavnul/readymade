::  Owner-governed project offers and bilateral consent over authenticated Ames.
::  This agent never runs a model, activates source, or authorizes deployment.
/-  c=readymade-collab, pact=readymade-pact, j=readymade-collab-jobs, a=readymade-artifact-collab
/+  default-agent, flow=readymade-collab, web=readymade-collab-http, network=readymade-network, jobs=readymade-collab-jobs, ops=readymade-collab-operations, jobs-web=readymade-collab-jobs-http, archive=readymade-collab-graf, guard=viki-scry-guard, law-watch=readymade-collab-cantrip, graf-select=readymade-collab-graf-selection, graf-admit=readymade-collab-graf-admission, saved-kit=readymade-collab-saved, artifact=readymade-artifact-collab, state-read=readymade-collab-state, artifact-prep=readymade-artifact-prepare, artifact-web=readymade-artifact-http, artifact-actions=readymade-artifact-actions, executor=readymade-artifact-executor, login-gate=readymade-page-http-gate, source-review=readymade-artifact-source-review, artifact-history=readymade-artifact-history, artifact-task=readymade-artifact-task
/+  session-pages=readymade-session-catalog-http, project-members=readymade-project-members-http
/+  invitations=readymade-project-invitations, invitation-web=readymade-project-invitations-http, invitation-wire=readymade-project-invitations-transport
/+  invitation-pages=readymade-project-invitation-catalog
/+  sharing=readymade-project-sharing, sharing-web=readymade-project-sharing-http, sharing-wire=readymade-project-sharing-transport, sharing-saved=readymade-project-sharing-saved
/+  workspace-saved=readymade-workspace-saved, workspace-requests=readymade-workspace-requests, workspace-dispatch=readymade-workspace-dispatch
/+  workspace-completion=readymade-workspace-completion-read
/+  workspace-result=readymade-workspace-result-http
/+  result-return=readymade-workspace-return, return-web=readymade-workspace-return-http, return-saved=readymade-workspace-return-saved
/+  rich-return=readymade-workspace-return-rich, rich-return-web=readymade-workspace-return-rich-http, rich-return-saved=readymade-workspace-return-rich-saved
/+  workspace-wire=readymade-workspace-transport
/+  workspace-web=readymade-workspace-http
/+  workspace-catalog=readymade-workspace-catalog, workspace-preview=readymade-workspace-preview
/+  workspace-page=readymade-workspace-page
/+  project-view=readymade-project-view-client, project-view-web=readymade-project-view-http
/+  project-suggest=readymade-project-suggest-client, project-suggest-web=readymade-project-suggest-http
/+  project-sessions=readymade-project-sessions-client, project-sessions-web=readymade-project-sessions-http
/+  session-sharing=readymade-session-sharing, session-sharing-web=readymade-session-sharing-http
/+  project-inbox=readymade-project-inbox-http
/+  workspace-import=readymade-workspace-import, import-read=readymade-workspace-import-read, import-web=readymade-workspace-import-http
=>
|%
+$  card  card:agent:gall
++  bind-page
  ^-  card
  [%pass /collab/bind %arvo %e %connect [~ /apps/readymade-collab] %readymade-collab]
++  answer
  |=  [id=@ta code=@ud text=@t mime=@t]
  ^-  (list card)
  =/  header  [code ~[['content-type' mime] ['cache-control' 'no-store'] ['x-content-type-options' 'nosniff']]]
  =/  data=(unit octs)  `[(met 3 text) text]
  =/  path=path  /http-response/[id]
  :~  [%give %fact ~[path] %http-response-header !>(header)]
      [%give %fact ~[path] %http-response-data !>(data)]
      [%give %kick ~[path] ~]
  ==
++  json-answer
  |=  [id=@ta code=@ud data=json]
  ^-  (list card)
  (answer id code (en:json:html data) 'application/json; charset=utf-8')
+$  archive-transition
  $:  state=state:c
      pending=pending:archive
      cards=(list card)
  ==
++  queue-evidence
  |=  [our=@p state=state:c held=pending:archive candidate=(unit fact:archive)]
  ^-  archive-transition
  ?~  candidate  [state held ~]
  =/  moved=change:archive  (queue:archive our held u.candidate)
  =/  next=state:c
    ?~(receipt.moved state (record:flow state u.receipt.moved))
  [next pending.moved cards.moved]
++  graf-readback
  ::  Existing exact membership route. Only our canonical bounded retained
  ::  metadata is encoded here; arbitrary remote query text never reaches cue.
  |=  [b=bowl:gall value=fact:archive]
  ^-  (unit ?)
  ?.  (agent-live:guard our.b now.b %graf)  ~
  ((soft ?) .^(* %gx /(scot %p our.b)/graf/(scot %da now.b)/contains/(scot %uw (jam value))/noun))
++  transmit
  |=  [peer=@p event=envelope:c]
  ^-  card
  [%pass /collab/send/[request.event] %agent [peer %readymade-collab] %poke %noun !>(event)]
++  watch-pending
  |=  [our=@p ledger=ledger:j]
  ^-  (list card)
  %+  murn  ~(tap by ledger)
  |=  [tid=@ta work=job:j]
  ?.  =(%pending phase.work)  ~
  `[%pass /collab/job/[tid] %agent [our %spider] %watch /thread-result/[tid]]
++  legacy-watchers
  ::  Running old TED cores retain their original parser across source updates.
  |=  ledger=ledger:j
  ^-  (set @ta)
  %-  silt
  %+  murn  ~(tap by ledger)
  |=  [tid=@ta work=job:j]
  ?.  &(!=(%release kind.work) |(=(%pending phase.work) =(%uncertain phase.work)))  ~
  `tid
++  legacy-active
  |=  [ledger=ledger:j retained=(set @ta)]
  ^-  ?
  %+  lien  ~(tap in retained)
  |=  tid=@ta
  =/  work=(unit job:j)  (~(get by ledger) tid)
  ?~  work  %.n
  |(=(%pending phase.u.work) =(%uncertain phase.u.work))
++  connected
  |=  b=bowl:gall
  ^-  ?
  ?.  (agent-live:guard our.b now.b %call)  %.n
  =/  links=state:network
    ;;(state:network .^(* %gx /(scot %p our.b)/call/(scot %da now.b)/network/noun))
  =/  peer=(unit peer:network)  (~(get by peers.links) src.b)
  ?~  peer  %.n
  =(%connected phase.u.peer)
++  module-source
  |=  b=bowl:gall
  ^-  (unit @t)
  =/  desks=(set @tas)
    .^((set @tas) %cd /(scot %p our.b)//(scot %da now.b))
  =/  todo=(list [desk=@tas file=path])
    :~  [q.byk.b /ui/readymade-collaboration-v14/js]
        [%glass-desktop-build /ui/readymade-collaboration-v14/js]
        [%host-readymade-collab /ui/readymade-collaboration-v14/js]
        [q.byk.b /ui/readymade-collaboration-v13/js]
        [%glass-desktop-build /ui/readymade-collaboration-v13/js]
        [%host-readymade-collab /ui/readymade-collaboration-v13/js]
        [q.byk.b /ui/readymade-collaboration-v12/js]
        [%glass-desktop-build /ui/readymade-collaboration-v12/js]
        [%host-readymade-collab /ui/readymade-collaboration-v12/js]
        [q.byk.b /ui/readymade-collaboration-v11/js]
        [%glass-desktop-build /ui/readymade-collaboration-v11/js]
        [%host-readymade-collab /ui/readymade-collaboration-v11/js]
        [q.byk.b /ui/readymade-collaboration-v10/js]
        [%glass-desktop-build /ui/readymade-collaboration-v10/js]
        [%host-readymade-collab /ui/readymade-collaboration-v10/js]
        [q.byk.b /ui/readymade-collaboration-v9/js]
        [%glass-desktop-build /ui/readymade-collaboration-v9/js]
        [%host-readymade-collab /ui/readymade-collaboration-v9/js]
        [q.byk.b /ui/readymade-collaboration-v8/js]
        [%glass-desktop-build /ui/readymade-collaboration-v8/js]
        [%host-readymade-collab /ui/readymade-collaboration-v8/js]
        [q.byk.b /ui/readymade-collaboration-v7/js]
        [%glass-desktop-build /ui/readymade-collaboration-v7/js]
        [%host-readymade-collab /ui/readymade-collaboration-v7/js]
        [q.byk.b /ui/readymade-collaboration-v6/js]
        [%glass-desktop-build /ui/readymade-collaboration-v6/js]
        [%host-readymade-collab /ui/readymade-collaboration-v6/js]
        [q.byk.b /ui/readymade-collaboration-v5/js]
        [%glass-desktop-build /ui/readymade-collaboration-v5/js]
        [%host-readymade-collab /ui/readymade-collaboration-v5/js]
        [%glass-desktop-build /ui/readymade-collaboration-v4/js]
        [%host-readymade-collab /ui/readymade-collaboration-v4/js]
        [%glass-desktop-build /ui/readymade-collaboration-v3/js]
        [%host-readymade-collab /ui/readymade-collaboration-v3/js]
        [%glass-desktop-build /ui/readymade-collaboration-v2/js]
        [%host-readymade-collab /ui/readymade-collaboration-v2/js]
        [%host-readymade-collab /ui/readymade-collaboration/js]
        [q.byk.b /ui/readymade-collaboration/js]
    ==
  |-  ^-  (unit @t)
  ?~  todo  ~
  ?.  (~(has in desks) desk.i.todo)  $(todo t.todo)
  =/  at=path
    (weld ~[(scot %p our.b) desk.i.todo (scot %da now.b)] file.i.todo)
  ?.  .^(? %cu at)  $(todo t.todo)
  ((soft @t) .^(* %cq at))
--
=/  state=state:c  empty:flow
=|  commands=(map @t @ux)
=|  ledger=ledger:j
=|  graf-pending=pending:archive
=/  artifacts=state:a  empty:artifact
=|  executions=journal:executor
=|  invitation-journal=journal:invitations
=|  sharing-journal=journal:sharing
=|  workspace=state:workspace-requests
=|  submissions=journal:workspace-dispatch
=|  returns=journal:result-return
=|  rich-returns=journal:rich-return
::  Private source observations are transient; never part of saved authority.
=|  project-views=journal:project-view
::  Shared-session lists are transient observations too; never saved.
=|  project-session-lists=journal:project-sessions
=|  project-suggestions=journal:project-suggest
=|  project-suggestion-recoveries=journal:project-suggest
::  Transient compatibility barrier, reconstructed on every load, no retries.
=|  legacy-jobs=(set @ta)
::  Optional observation metadata is transient, never saved pact authority.
=/  law-view=model:law-watch  initial:law-watch
::  Private page witnesses are transient and never saved or sent to peers.
=|  graf-choices=(unit cache:graf-select)
^-  agent:gall
|_  =bowl:gall
+*  this  .
    def  ~(. (default-agent this %.n) bowl)
    receive-event
      |=  event=envelope:c
      ^-  (quip card _this)
        =/  moved  (receive:flow state our.bowl src.bowl event)
        ?>  accepted.moved
        ?:  duplicate.moved  `this
        =/  archived
          (queue-evidence our.bowl state.moved graf-pending (event:archive our.bowl src.bowl event))
        [cards.archived this(state state.archived, graf-pending pending.archived)]
    prepare
      |=  [cmd=command:c peer=@p]
      ^-  [state=state:c event=envelope:c]
      ?:  =('propose' op.cmd)
        =/  hash=@ux  (need (slaw %ux reference.cmd))
        =/  item=package:c  (~(got by packages.state) hash)
        =/  offer  offer.value.item
        ?>  |(&(=(sender.body.offer our.bowl) =(recipient.body.offer peer)) &(=(recipient.body.offer our.bowl) =(sender.body.offer peer)))
        ?>  (agent-live:guard our.bowl now.bowl %cantrip)
        =/  window=*
          .^(* %gx /(scot %p our.bowl)/cantrip/(scot %da now.bowl)/law/window/current/noun)
        =/  terms=terms:pact
          [1 our.bowl peer title.item hash graf-root.body.offer (shax terms.cmd) (shax (jam window)) (shax (jam [eny.bowl now.bowl request.cmd]))]
        =/  event=envelope:c  [%readymade-collab-wire-v1 request.cmd [%propose reference.cmd terms.cmd terms]]
        =/  moved  (receive:flow state our.bowl our.bowl event)
        ?>  accepted.moved
        [state.moved event]
      =/  hash=@ux  (need (slaw %ux id.cmd))
      =/  item=agreement:c  (~(got by pacts.state) hash)
      ?>  =((scot %ux hash) digest.cmd)
      =/  pact-state  value.item
      ?>  |(&(=(left.terms.pact-state our.bowl) =(right.terms.pact-state peer)) &(=(right.terms.pact-state our.bowl) =(left.terms.pact-state peer)))
      =/  seq=@ud  +(?:(=(our.bowl left.terms.pact-state) left-sequence.pact-state right-sequence.pact-state))
      ?>  =(reference.cmd (spat ~[(scot %ud generation.pact-state) (scot %ud seq)]))
      =/  move=request:pact
        [generation.pact-state hash seq ?:(=('pact-revoke' op.cmd) [%revoke ~] [%accept ~])]
      =/  event=envelope:c  [%readymade-collab-wire-v1 request.cmd [%pact hash move]]
      =/  moved  (receive:flow state our.bowl our.bowl event)
      ?>  accepted.moved
      [state.moved event]
    http-request
      |=  [=mark =vase]
      ^-  (quip card _this)
      ?>  =(%handle-http-request mark)
      :: Anonymous requests are answered only by their watch's current duct.
      :: A guessed response id must never produce a foreign poke broadcast.
      ?.  =(our.bowl src.bowl)  `this
      =+  !<([id=@ta req=inbound-request:eyre] vase)
      ?.  authenticated.req
        [(json-answer id 403 (status:web 'refused' 'Owner login required.')) this]
      =/  url=@t  url.request.req
      ?:  =('/apps/readymade-collab/project-inbox' url)
        =/  selected  (request:project-inbox req)
        ?~  selected  [(json-answer id 400 (status:web 'refused' 'Exact owner inbox selector required.')) this]
        =/  observed  (observe:project-inbox our.bowl src.bowl now.bowl u.selected)
        ?:  ?=(%| -.observed)
          [(json-answer id ?:(=(%receipt-missing p.observed) 404 409) (status:web 'refused' (scot %tas p.observed))) this]
        [(json-answer id 200 p.observed) this]
      ?:  =('/apps/readymade-collab/project-suggest-recovery-result' url)
        =/  key  (recovery-result-request:project-suggest-web req)
        ?~  key  [(json-answer id 400 (status:web 'refused' 'Exact recovery selector required.')) this]
        =/  found  (~(get by project-suggestion-recoveries) u.key)
        ?~  found  [(json-answer id 404 (status:web 'unknown' 'Recovery observation not retained; original outcome stays unknown.')) this]
        =/  held  (result:project-suggest now.bowl u.key project-suggestion-recoveries)
        ?~  held  [(json-answer id 410 (status:web 'expired' 'Recovery observation expired; no suggestion resent.')) this]
        [(json-answer id ?:((active:project-suggest u.held) 202 200) (recovery-response:project-suggest-web our.bowl u.held)) this]
      ?:  =('/apps/readymade-collab/project-suggest-recover' url)
        =/  cmd  (recover-request:project-suggest-web req)
        ?~  cmd  [(json-answer id 400 (status:web 'refused' 'Exact owner-origin recovery intent required.')) this]
        =/  wanted=command:project-suggest-web  command.u.cmd
        =/  key=selector:project-view  view.wanted(query query.view.wanted(nonce request.wanted))
        =/  started
          (recover:project-suggest our.bowl now.bowl key nonce.query.view.wanted grant.u.cmd root.u.cmd snapshot-digest.u.cmd pax.wanted source.wanted project-suggestion-recoveries)
        ?:  ?=(%| -.result.started)
          [(json-answer id 409 (status:web 'refused' (scot %tas p.result.started))) this]
        [(weld (json-answer id ?:((active:project-suggest p.result.started) 202 200) (recovery-response:project-suggest-web our.bowl p.result.started)) cards.started) this(project-suggestion-recoveries journal.started)]
      ?:  =('/apps/readymade-collab/project-suggest-result' url)
        =/  key  (result-request:project-suggest-web req)
        ?~  key  [(json-answer id 400 (status:web 'refused' 'Exact suggestion selector required.')) this]
        =/  found  (~(get by project-suggestions) u.key)
        ?~  found  [(json-answer id 404 (status:web 'unknown' 'Suggestion not retained; do not resend an unknown outcome.')) this]
        =/  held  (result:project-suggest now.bowl u.key project-suggestions)
        ?~  held  [(json-answer id 410 (status:web 'expired' 'Suggestion observation expired; no retry issued.')) this]
        [(json-answer id ?:((active:project-suggest u.held) 202 200) (response:project-suggest-web our.bowl u.held)) this]
      ?:  =('/apps/readymade-collab/project-suggest' url)
        =/  cmd  (post-request:project-suggest-web req)
        ?~  cmd  [(json-answer id 400 (status:web 'refused' 'Exact owner-origin suggestion required.')) this]
        =/  observed  (result:project-view now.bowl view.u.cmd project-views)
        ?~  observed  [(json-answer id 409 (status:web 'refused' 'Exact retained source observation required.')) this]
        =/  started  (begin:project-suggest our.bowl now.bowl request.u.cmd u.observed pax.u.cmd source.u.cmd project-suggestions)
        ?:  ?=(%| -.result.started)
          [(json-answer id 409 (status:web 'refused' (scot %tas p.result.started))) this(project-suggestions journal.started)]
        [(weld (json-answer id 202 (response:project-suggest-web our.bowl p.result.started)) cards.started) this(project-suggestions journal.started)]
      ?:  =('/apps/readymade-collab/project-sessions-result' url)
        =/  key  (result-request:project-sessions-web req)
        ?~  key  [(json-answer id 400 (status:web 'refused' 'Exact shared session list selector required.')) this]
        =/  found  (~(get by project-session-lists) u.key)
        ?~  found  [(json-answer id 404 (status:web 'unknown' 'List not retained; no retry was issued.')) this]
        =/  held  (result:project-sessions now.bowl u.key project-session-lists)
        ?~  held  [(json-answer id 410 (status:web 'expired' 'Historical list expired.')) this]
        =/  body  (response:project-sessions-web our.bowl u.held)
        ?~  body  [(json-answer id 503 (status:web 'unavailable' 'List encoding refused.')) this]
        [(json-answer id ?:(=(%pending phase.u.held) 202 200) u.body) this]
      ?:  =('/apps/readymade-collab/project-sessions' url)
        =/  cmd  (post-request:project-sessions-web req)
        ?~  cmd  [(json-answer id 400 (status:web 'refused' 'Exact owner-origin shared session list command required.')) this]
        =/  nonce=@ux
          `@ux`(mod (shax (jam [our.bowl now.bowl eny.bowl act.bowl %project-sessions u.cmd])) (bex 128))
        =.  nonce  ?:(=(0 nonce) 0x1 nonce)
        =/  key=selector:project-sessions  [owner.u.cmd [project.u.cmd nonce]]
        =/  started  (begin:project-sessions our.bowl now.bowl key project-session-lists)
        ?:  ?=(%| -.result.started)
          [(json-answer id 409 (status:web 'refused' (scot %tas p.result.started))) this(project-session-lists journal.started)]
        =/  body  (response:project-sessions-web our.bowl p.result.started)
        ?~  body  [(json-answer id 503 (status:web 'unavailable' 'List selector encoding refused.')) this]
        [(weld (json-answer id 202 u.body) cards.started) this(project-session-lists journal.started)]
      ?:  =('/apps/readymade-collab/project-view-result' url)
        =/  key  (result-request:project-view-web req)
        ?~  key  [(json-answer id 400 (status:web 'refused' 'Exact project view selector required.')) this]
        =/  found  (~(get by project-views) u.key)
        ?~  found  [(json-answer id 404 (status:web 'unknown' 'Observation not retained; no retry was issued.')) this]
        =/  held  (result:project-view now.bowl u.key project-views)
        ?~  held  [(json-answer id 410 (status:web 'expired' 'Historical observation expired.')) this]
        =/  body  (response:project-view-web our.bowl u.held)
        ?~  body  [(json-answer id 503 (status:web 'unavailable' 'Observation encoding refused.')) this]
        [(json-answer id ?:(=(%pending phase.u.held) 202 200) u.body) this]
      ?:  =('/apps/readymade-collab/project-view' url)
        =/  cmd  (post-request:project-view-web req)
        ?~  cmd  [(json-answer id 400 (status:web 'refused' 'Exact owner-origin source view command required.')) this]
        =/  nonce=@ux
          `@ux`(mod (shax (jam [our.bowl now.bowl eny.bowl act.bowl u.cmd])) (bex 128))
        =.  nonce  ?:(=(0 nonce) 0x1 nonce)
        =/  key=selector:project-view  [owner.u.cmd [project.u.cmd generation.u.cmd nonce]]
        =/  started  (begin:project-view our.bowl now.bowl key project-views)
        ?:  ?=(%| -.result.started)
          [(json-answer id 409 (status:web 'refused' (scot %tas p.result.started))) this(project-views journal.started)]
        =/  body  (response:project-view-web our.bowl p.result.started)
        ?~  body  [(json-answer id 503 (status:web 'unavailable' 'Observation selector encoding refused.')) this]
        [(weld (json-answer id 202 u.body) cards.started) this(project-views journal.started)]
      ?:  =('GET' method.request.req)
        ?:  =('/apps/readymade-collab/session-sharing' url)
          =/  query  (read-request:session-sharing-web req)
          ?~  query  [(json-answer id 400 (status:web 'refused' 'Project and peer required.')) this]
          =/  observed  (mole |.((read:session-sharing-web bowl project.u.query)))
          ?~  observed  [(json-answer id 503 (status:web 'unavailable' 'Session sharing state unavailable.')) this]
          ?:  ?=(%| -.u.observed)
            [(json-answer id 409 (status:web 'refused' (scot %tas p.u.observed))) this]
          [(json-answer id 200 (snapshot:session-sharing-web p.u.observed peer.u.query)) this]
        ?:  =('/apps/readymade-collab/project-sharing' url)
          =/  query  (read-request:sharing-web req)
          ?~  query  [(json-answer id 400 (status:web 'refused' 'Project and peer required.')) this]
          =/  observed  (mole |.((read:sharing-wire bowl project.u.query)))
          ?~  observed  [(json-answer id 503 (status:web 'unavailable' 'Sharing state unavailable.')) this]
          ?:  ?=(%| -.u.observed)
            [(json-answer id 409 (status:web 'refused' (scot %tas p.u.observed))) this]
          [(json-answer id 200 (snapshot:sharing-web p.u.observed peer.u.query)) this]
        ?:  =('/apps/readymade-collab/project-sharing-result' url)
          =/  request  (result-request:sharing-web req)
          ?~  request  [(json-answer id 400 (status:web 'refused' 'Exact request identifier required.')) this]
          =/  held  (~(get by sharing-journal) u.request)
          ?~  held  [(json-answer id 404 (status:web 'missing' 'No retained sharing request; an earlier request may still arrive.')) this]
          =/  observed  (mole |.((read:sharing-wire bowl project.command.u.held)))
          ?~  observed  [(json-answer id 503 (status:web 'unavailable' 'Canonical sharing outcome unavailable.')) this]
          ?:  ?=(%| -.u.observed)
            [(json-answer id 503 (status:web 'unavailable' (scot %tas p.u.observed))) this]
          [(json-answer id 200 (view:sharing-web p.u.observed u.held)) this]
        ?:  =('/apps/readymade-collab/workspace-import-options' url)
          =/  session  (session-request:import-web req)
          ?~  session  [(json-answer id 400 (status:web 'refused' 'Valid session selection required.')) this]
          =/  result  (mole |.((options:import-read bowl u.session)))
          ?~  result  [(json-answer id 503 (status:web 'unavailable' 'Import choices unavailable.')) this]
          ?:  ?=(%| -.u.result)
            [(json-answer id 409 (status:web 'refused' (scot %tas p.u.result))) this]
          [(json-answer id 200 p.u.result) this]
        ?:  =('/apps/readymade-collab/workspace-import-messages' url)
          =/  query  (messages-request:import-web req)
          ?~  query  [(json-answer id 400 (status:web 'refused' 'Note and message page required.')) this]
          =/  result  (mole |.((messages:import-read bowl note.u.query page.u.query)))
          ?~  result  [(json-answer id 503 (status:web 'unavailable' 'Shared messages unavailable.')) this]
          ?:  ?=(%| -.u.result)
            [(json-answer id 409 (status:web 'refused' (scot %tas p.u.result))) this]
          [(json-answer id 200 p.u.result) this]
        ?:  =('/apps/readymade-collab/workspace' url)
          [(answer id 200 (html:workspace-page our.bowl) 'text/html; charset=utf-8') this]
        ?:  =('/apps/readymade-collab/workspace-ui.js' url)
          =/  raw  (mole |.((modules:workspace-page bowl)))
          ?~  raw  [(json-answer id 503 (status:web 'unavailable' 'Workspace interface source unavailable.')) this]
          ?~  u.raw  [(json-answer id 503 (status:web 'unavailable' 'Workspace interface source missing.')) this]
          [(answer id 200 u.u.raw 'application/javascript; charset=utf-8') this]
        ?:  =('/apps/readymade-collab/workspace-requests' url)
          =/  query  (read-request:workspace-catalog req)
          ?~  query  [(json-answer id 400 (status:web 'refused' 'Exact workspace catalog cursor required.')) this]
          =/  page  (page:workspace-catalog our.bowl u.query workspace submissions)
          ?:  ?=(%| -.page)
            [(json-answer id 409 (status:web 'refused' (scot %tas p.page))) this]
          [(json-answer id 200 p.page) this]
        ?:  =('/apps/readymade-collab/workspace-preview' url)
          =/  key  (read-request:workspace-web req)
          ?~  key  [(json-answer id 400 (status:web 'refused' 'Exact requester and request nonce required.')) this]
          =/  checked  (mole |.((read:workspace-preview bowl workspace u.key)))
          ?~  checked  [(json-answer id 503 (status:web 'unavailable' 'Current execution evidence unavailable.')) this]
          ?:  ?=(%| -.u.checked)
            [(json-answer id 409 (status:web 'refused' (scot %tas p.u.checked))) this]
          [(json-answer id 200 (view:workspace-preview p.u.checked)) this]
        ?:  =('/apps/readymade-collab/workspace-completion' url)
          =/  key  (read-request:workspace-web req)
          ?~  key  [(json-answer id 400 (status:web 'refused' 'Exact requester and request nonce required.')) this]
          =/  observed  (mole |.((view:workspace-completion bowl workspace submissions u.key)))
          ?~  observed  [(json-answer id 503 (status:web 'unavailable' 'Native completion evidence unavailable.')) this]
          ?:  ?=(%| -.u.observed)
            [(json-answer id 409 (status:web 'refused' (scot %tas p.u.observed))) this]
          [(json-answer id 200 p.u.observed) this]
        ?:  =('/apps/readymade-collab/workspace-result' url)
          =/  key  (read-request:workspace-web req)
          ?~  key  [(json-answer id 400 (status:web 'refused' 'Exact requester and nonce required.')) this]
          ?.  =(our.bowl -.u.key)  [(json-answer id 403 (status:web 'refused' 'Owner required.')) this]
          =/  observed  (mole |.((read-view:workspace-result bowl workspace submissions u.key)))
          ?~  observed  [(json-answer id 503 (status:web 'unavailable' 'Request-attributed source or evidence unavailable.')) this]
          ?:  ?=(%| -.u.observed)
            [(json-answer id 409 (status:web 'unavailable' (scot %tas p.u.observed))) this]
          [(json-answer id 200 p.u.observed) this]
        ?:  =('/apps/readymade-collab/workspace-return-rich-result' url)
          =/  key  (read-request:workspace-web req)
          ?~  key  [(json-answer id 400 (status:web 'refused' 'Exact requester and nonce required.')) this]
          ?.  =(our.bowl -.u.key)  [(json-answer id 403 (status:web 'refused' 'Owner required.')) this]
          ?:  (~(has by returns) u.key)
            [(json-answer id 409 (status:web 'version-conflict' 'A v1 reply is retained. Observe the v1 result; never send again.')) this]
          =/  held  (~(get by rich-returns) u.key)
          ?~  held  [(json-answer id 404 (status:web 'missing' 'No retained rich reply; do not resend an unknown attempt.')) this]
          =/  observed  (mole |.((observe:rich-return bowl rich-returns u.key)))
          =/  next=journal:rich-return  ?~(observed rich-returns u.observed)
          =/  row=record:rich-return  (~(got by next) u.key)
          [(json-answer id 200 (view:rich-return-web preview.row ?~(posted.row %reserved %posted) posted.row)) this(rich-returns next)]
        ?:  =('/apps/readymade-collab/workspace-return-result' url)
          =/  key  (read-request:workspace-web req)
          ?~  key  [(json-answer id 400 (status:web 'refused' 'Exact requester and nonce required.')) this]
          ?.  =(our.bowl -.u.key)  [(json-answer id 403 (status:web 'refused' 'Owner required.')) this]
          ?:  (~(has by rich-returns) u.key)
            [(json-answer id 409 (status:web 'version-conflict' 'A v2 reply is retained. Observe the rich result; never send again.')) this]
          =/  held  (~(get by returns) u.key)
          ?~  held  [(json-answer id 404 (status:web 'missing' 'No retained reply; do not resend an unknown attempt.')) this]
          =/  observed  (mole |.((observe:result-return bowl returns u.key)))
          =/  next=journal:result-return  ?~(observed returns u.observed)
          =/  row=record:result-return  (~(got by next) u.key)
          [(json-answer id 200 (view:return-web preview.row ?~(posted.row %reserved %posted) posted.row)) this(returns next)]
        ?:  =('/apps/readymade-collab/workspace-request' url)
          =/  key  (read-request:workspace-web req)
          ?~  key  [(json-answer id 400 (status:web 'refused' 'Exact requester and request nonce required.')) this]
          =/  view  (lookup:workspace-web our.bowl workspace submissions u.key)
          ?~  view  [(json-answer id 404 (status:web 'missing' 'No matching retained workspace request.')) this]
          [(json-answer id 200 u.view) this]
        ?:  =('/apps/readymade-collab/project-invitation-requests' url)
          =/  query  (read-request:invitation-pages req)
          ?~  query  [(json-answer id 400 (status:web 'refused' 'Exact retained invitation page required.')) this]
          =/  page  (page:invitation-pages our.bowl u.query invitation-journal)
          ?:  ?=(%| -.page)
            [(json-answer id 409 (status:web 'refused' (scot %tas p.page))) this]
          [(json-answer id 200 p.page) this]
        ?:  =('/apps/readymade-collab/project-invitation-result' url)
          =/  request  (result-request:invitation-web req)
          ?~  request  [(json-answer id 400 (status:web 'refused' 'Exact request identifier required.')) this]
          =/  held  (~(get by invitation-journal) u.request)
          ?~  held  [(json-answer id 404 (status:web 'missing' 'No retained invitation command.')) this]
          [(json-answer id 200 (view:invitation-web u.held)) this]
        ?:  =('/apps/readymade-collab/artifact-task' url)
          =/  parsed  (read-request:artifact-task req)
          ?~  parsed  [(json-answer id 400 (status:web 'refused' 'Exact retained task command required.')) this]
          =/  cmd=command:artifact-task  u.parsed
          ?.  =(our.bowl owner.cmd)  [(json-answer id 403 (status:web 'refused' 'Receiver owner required.')) this]
          =/  prepared
            (mole |.((prepare:artifact-task our.bowl src.bowl cmd executions packages.state)))
          ?~  prepared  [(json-answer id 503 (status:web 'uncertain' 'Native retained task unavailable.')) this]
          ?:  ?=(%| -.u.prepared)
            [(json-answer id 409 (status:web 'refused' (scot %tas p.u.prepared))) this]
          =/  observed  (mole |.((read:artifact-task bowl p.u.prepared)))
          ?~  observed  [(json-answer id 503 (status:web 'uncertain' 'Native retained task evidence unavailable.')) this]
          ?:  ?=(%| -.u.observed)
            [(json-answer id 503 (status:web 'uncertain' (scot %tas p.u.observed))) this]
          [(json-answer id 200 p.u.observed) this]
        ?:  =('/apps/readymade-collab/artifact-history' url)
          =/  parsed  (read-request:artifact-history req)
          ?~  parsed  [(json-answer id 400 (status:web 'refused' 'Exact retained history command required.')) this]
          =/  cmd=command:artifact-history  u.parsed
          ?.  =(our.bowl owner.cmd)  [(json-answer id 403 (status:web 'refused' 'Receiver owner required.')) this]
          =/  observed
            (mole |.((read:artifact-history our.bowl src.bowl cmd ledger executions)))
          ?~  observed  [(json-answer id 503 (status:web 'uncertain' 'Native retained history unavailable.')) this]
          ?:  ?=(%| -.u.observed)
            =/  code=@ud  ?:(=(%history-response-bytes p.u.observed) 503 409)
            [(json-answer id code (status:web 'refused' (scot %tas p.u.observed))) this]
          [(json-answer id 200 p.u.observed) this]
        ?:  =('/apps/readymade-collab/artifact-review' url)
          =/  parsed  (read-request:source-review req)
          ?~  parsed  [(json-answer id 400 (status:web 'refused' 'Exact source review command required.')) this]
          =/  cmd=command:source-review  u.parsed
          ?.  =(our.bowl owner.cmd)  [(json-answer id 403 (status:web 'refused' 'Receiver owner required.')) this]
          =/  held=saved:saved-kit
            [%readymade-collab-app-v4 state commands ledger graf-pending artifacts]
          =/  observed
            (mole |.((read:source-review bowl peer.cmd pact.cmd guard.cmd selected.cmd held)))
          ?~  observed  [(json-answer id 503 (status:web 'uncertain' 'Native pinned source unavailable.')) this]
          ?:  ?=(%| -.u.observed)  [(json-answer id 409 (status:web 'refused' (scot %tas p.u.observed))) this]
          [(json-answer id 200 (json-view:source-review p.u.observed)) this]
        ?:  =('/apps/readymade-collab/project-members' url)
          =/  query  (read-request:project-members req)
          ?~  query  [(json-answer id 400 (status:web 'refused' 'Valid project, page kind, offset and catalog required.')) this]
          =/  observed  (mole |.((read:project-members bowl u.query)))
          ?~  observed  [(json-answer id 503 (status:web 'uncertain' 'Project membership unavailable.')) this]
          ?:  ?=(%| -.u.observed)
            =/  code=@ud  ?:(?=(?(%project-members-stale %project-members-cursor) p.u.observed) 409 503)
            [(json-answer id code (status:web 'refused' (scot %tas p.u.observed))) this]
          [(json-answer id 200 p.u.observed) this]
        ?:  =('/apps/readymade-collab/artifact-executor-sessions-v2' url)
          =/  query  (read-request:session-pages req)
          ?~  query  [(json-answer id 400 (status:web 'refused' 'Valid session page offset and catalog required.')) this]
          =/  observed  (mole |.((read:session-pages bowl u.query)))
          ?~  observed  [(json-answer id 503 (status:web 'uncertain' 'Native session metadata unavailable.')) this]
          ?:  ?=(%| -.u.observed)
            =/  code=@ud  ?:(?=(?(%session-catalog-stale %session-catalog-cursor) p.u.observed) 409 503)
            [(json-answer id code (status:web 'refused' (scot %tas p.u.observed))) this]
          [(json-answer id 200 p.u.observed) this]
        ?:  =('/apps/readymade-collab/artifact-executor-sessions' url)
          =/  observed  (mole |.((native-sessions:executor bowl)))
          ?~  observed  [(json-answer id 503 (status:web 'uncertain' 'Native session metadata unavailable.')) this]
          ?:  ?=(%| -.u.observed)  [(json-answer id 503 (status:web 'uncertain' (scot %tas p.u.observed))) this]
          [(json-answer id 200 p.u.observed) this]
        ?:  =('/apps/readymade-collab/artifact-executor-result' url)
          =/  raw  (command-header:executor req)
          ?~  raw  [(json-answer id 400 (status:web 'refused' 'Exact retained executor command required.')) this]
          =/  parsed  (parse:executor u.raw)
          ?~  parsed  [(json-answer id 400 (status:web 'refused' 'Invalid executor command.')) this]
          =/  cmd=command:executor  u.parsed
          ?.  =(our.bowl owner.cmd)  [(json-answer id 403 (status:web 'refused' 'Receiver owner required.')) this]
          =/  found  (~(get by executions) (key:executor cmd))
          ?~  found  [(json-answer id 404 (status:web 'uncertain' 'Not recorded; an earlier POST may still arrive. Do not resubmit.')) this]
          =/  observed  (mole |.((observe:executor our.bowl now.bowl u.found)))
          =/  next=entry:executor  ?~(observed u.found u.observed)
          :-  (json-answer id ?:(?=(?(%pending %uncertain) phase.next) 202 200) (json-result:executor our.bowl next))
          this(executions (~(put by executions) (key:executor cmd) next))
        ?:  =('/apps/readymade-collab/artifact-result' url)
          =/  parsed  (read-result-request:artifact-actions req)
          ?~  parsed
            [(json-answer id 400 (status:web 'refused' 'Exact retained artifact command required.')) this]
          =/  held=saved:saved-kit
            [%readymade-collab-app-v4 state commands ledger graf-pending artifacts]
          =/  observed  (lookup:artifact-actions our.bowl u.parsed held)
          [(json-answer id code.observed body.observed) this]
        ?:  =('/apps/readymade-collab/ui.js' url)
          =/  raw=(unit @t)  (module-source bowl)
          ?~  raw
            [(json-answer id 503 (status:web 'refused' 'Collaboration UI source unavailable.')) this]
          [(answer id 200 u.raw 'application/javascript; charset=utf-8') this]
        =/  offset=(unit @ud)  (route:graf-admit url)
        ?^  offset
          =/  page=(each view:graf-admit refusal:graf-admit)  (read:graf-admit bowl u.offset)
          ?:  ?=(%| -.page)
            [(json-answer id 503 (status:web 'refused' 'Native Graf candidate page unavailable.')) this]
          =/  data=(unit json)  (page-json:graf-admit our.bowl src.bowl p.page)
          ?~  data
            [(json-answer id 503 (status:web 'refused' 'Native Graf candidate page invalid.')) this]
          [(json-answer id 200 u.data) this(graf-choices `cache.p.page)]
        =/  prefix=@t  '/apps/readymade-collab/state.json?peer='
        ?.  =(prefix (end [3 (met 3 prefix)] url))
          [(json-answer id 404 (status:web 'refused' 'Unknown collaboration route.')) this]
        =/  peer=(unit @p)  (slaw %p (rsh [3 (met 3 prefix)] url))
        ?~  peer  [(json-answer id 400 (status:web 'refused' 'Invalid peer.')) this]
        =/  snapshot=json
          (project:law-watch our.bowl u.peer state law-view (snapshot:artifact-web our.bowl u.peer state ledger artifacts (snapshot:jobs-web our.bowl u.peer now.bowl state ledger)))
        =/  epoch=@ux  (shax (jam [%readymade-cantrip-observation-v1 our.bowl u.peer now.bowl eny.bowl id epoch.law-view]))
        =/  started  (begin:law-watch our.bowl u.peer epoch now.bowl state law-view)
        [(weld (json-answer id 200 snapshot) cards.started) this(law-view model.started)]
      ?:  |(=('/apps/readymade-collab/workspace-return-rich-preview' url) =('/apps/readymade-collab/workspace-return-rich-confirm' url))
        =/  parsed  (post-request:rich-return-web req)
        ?~  parsed  [(json-answer id 400 (status:web 'refused' 'Explicit v2 owner-origin disclosure required.')) this]
        =/  cmd=command:rich-return-web  u.parsed
        ?.  &(=(our.bowl requester.key.cmd) =(=(%preview operation.cmd) =('/apps/readymade-collab/workspace-return-rich-preview' url)))
          [(json-answer id 409 (status:web 'refused' 'Return owner or operation mismatch.')) this]
        ?:  (~(has by returns) key.cmd)
          [(json-answer id 409 (status:web 'version-conflict' 'A v1 reply is retained. Check the original result only.')) this]
        ?.  (available:rich-return returns rich-returns key.cmd)
          [(json-answer id 409 (status:web 'refused' 'Reply already attempted or combined capacity reached. Never resend.')) this]
        =/  observed  (mole |.((read:rich-return bowl workspace submissions key.cmd summary.cmd)))
        ?~  observed  [(json-answer id 503 (status:web 'unavailable' 'Complete attributed report or conversation unavailable.')) this]
        ?:  ?=(%| -.u.observed)
          [(json-answer id 409 (status:web 'refused' (scot %tas p.u.observed))) this]
        =/  p=preview:rich-return  p.u.observed
        ?.  (bounded:rich-return-web p)
          [(json-answer id 409 (status:web 'refused' 'Complete disclosure exceeds response capacity. Nothing truncated or sent.')) this]
        ?:  =(%preview operation.cmd)
          [(json-answer id 200 (view:rich-return-web p %preview ~)) this]
        ?~  expected.cmd  [(json-answer id 400 (status:web 'refused' 'Exact reviewed rich disclosure digest required.')) this]
        =/  moved  (reserve:rich-return our.bowl returns rich-returns p u.expected.cmd)
        ?.  accepted.moved
          [(json-answer id 409 (status:web 'refused' (scot %tas reason.moved))) this]
        [(weld (json-answer id 200 (view:rich-return-web p %reserved ~)) cards.moved) this(rich-returns journal.moved)]
      ?:  |(=('/apps/readymade-collab/workspace-return-preview' url) =('/apps/readymade-collab/workspace-return-confirm' url))
        =/  parsed  (post-request:return-web req)
        ?~  parsed  [(json-answer id 400 (status:web 'refused' 'Explicit owner-origin disclosure required.')) this]
        =/  cmd=command:return-web  u.parsed
        ?.  &(=(our.bowl requester.key.cmd) =(=(%preview operation.cmd) =('/apps/readymade-collab/workspace-return-preview' url)))
          [(json-answer id 409 (status:web 'refused' 'Return owner or operation mismatch.')) this]
        ?:  (~(has by rich-returns) key.cmd)
          [(json-answer id 409 (status:web 'version-conflict' 'A v2 reply is retained. Check the rich result only.')) this]
        ?:  (gte (add ~(wyt by returns) ~(wyt by rich-returns)) 256)
          [(json-answer id 409 (status:web 'refused' 'Combined reply capacity reached.')) this]
        ?:  (~(has by returns) key.cmd)
          [(json-answer id 409 (status:web 'refused' 'Reply already attempted. Check result; never resend.')) this]
        =/  observed  (mole |.((read:result-return bowl workspace submissions key.cmd summary.cmd)))
        ?~  observed  [(json-answer id 503 (status:web 'unavailable' 'Canonical completion or conversation unavailable.')) this]
        ?:  ?=(%| -.u.observed)
          [(json-answer id 409 (status:web 'refused' (scot %tas p.u.observed))) this]
        =/  p=preview:result-return  p.u.observed
        =/  view=json  (view:return-web p %preview ~)
        ?:  (gth (met 3 (en:json:html view)) 130.000)
          [(json-answer id 409 (status:web 'refused' 'Disclosure preview capacity exceeded.')) this]
        ?:  =(%preview operation.cmd)  [(json-answer id 200 view) this]
        ?~  expected.cmd  [(json-answer id 400 (status:web 'refused' 'Exact reviewed disclosure digest required.')) this]
        =/  moved  (reserve:result-return our.bowl returns p u.expected.cmd)
        ?.  accepted.moved
          [(json-answer id 409 (status:web 'refused' (scot %tas reason.moved))) this]
        [(weld (json-answer id 200 (view:return-web p %reserved ~)) cards.moved) this(returns journal.moved)]
      ?:  |(=('/apps/readymade-collab/workspace-import-preview' url) =('/apps/readymade-collab/workspace-import-confirm' url))
        =/  parsed  (post-request:import-web req)
        ?~  parsed  [(json-answer id 400 (status:web 'refused' 'Explicit owner-origin import references required.')) this]
        =/  cmd=command:import-web  u.parsed
        ?.  =(=(%preview operation.cmd) =('/apps/readymade-collab/workspace-import-preview' url))
          [(json-answer id 400 (status:web 'refused' 'Import action does not match this route.')) this]
        =/  key=key:workspace-dispatch  [our.bowl nonce.cmd]
        =/  prior  (~(get by requests.workspace) key)
        ?^  prior
          =/  old  value.u.prior
          =/  bound  (~(get by bindings.workspace) binding.old)
          ?~  bound  [(json-answer id 409 (status:web 'refused' 'Retained request binding unavailable.')) this]
          ?.  ?&  =(%confirm operation.cmd)  =(session.choice.cmd session.old)
                  =(note.choice.cmd note.spec.u.bound)  =(grant.choice.cmd grant.old)
                  ?^  message.old  =(eid.choice.cmd eid.u.message.old)
                  %.n
              ==  [(json-answer id 409 (status:web 'refused' 'Import nonce is already retained with different references.')) this]
          =/  view  (lookup:workspace-web our.bowl workspace submissions key)
          ?>  ?=(^ view)
          [(json-answer id 200 u.view) this]
        =/  evidence  (mole |.((read:import-read bowl choice.cmd)))
        ?~  evidence  [(json-answer id 503 (status:web 'unavailable' 'Current shared-message evidence unavailable.')) this]
        ?:  ?=(%| -.u.evidence)
          [(json-answer id 409 (status:web 'refused' (scot %tas p.u.evidence))) this]
        =/  current  p.u.evidence
        =/  proposed  (prospect:workspace-import our.bowl src.bowl workspace nonce.cmd current.current selected.current)
        ?:  ?=(%| -.proposed)
          [(json-answer id 409 (status:web 'refused' (scot %tas p.proposed))) this]
        ?:  =(%preview operation.cmd)
          [(json-answer id 200 (view:import-web our.bowl p.proposed)) this]
        ?~  expected.cmd  [(json-answer id 400 (status:web 'refused' 'Reviewed import digest required.')) this]
        =/  moved
          (confirm:workspace-import our.bowl src.bowl workspace p.proposed u.expected.cmd current.current selected.current)
        ?.  accepted.moved
          [(json-answer id 409 (status:web 'refused' (scot %tas reason.moved))) this]
        =/  view  (lookup:workspace-web our.bowl state.moved submissions key)
        ?>  ?=(^ view)
        [(json-answer id 200 u.view) this(workspace state.moved)]
      ?:  |(=('/apps/readymade-collab/workspace-submit' url) =('/apps/readymade-collab/workspace-recover' url))
        =/  parsed  (post-request:workspace-web our.bowl req)
        ?~  parsed  [(json-answer id 400 (status:web 'refused' 'Explicit owner-origin workspace command required.')) this]
        =/  cmd=command:workspace-web  u.parsed
        =/  selected-key=key:workspace-dispatch
          ?:  ?=(%submit -.cmd)  key.cmd
          key.cmd
        ?.  =(?=(%submit -.cmd) =('/apps/readymade-collab/workspace-submit' url))
          [(json-answer id 400 (status:web 'refused' 'Workspace action does not match this route.')) this]
        =/  prior  (lookup:workspace-web our.bowl workspace submissions selected-key)
        ?~  prior  [(json-answer id 404 (status:web 'missing' 'No matching retained workspace request.')) this]
        =/  observed
          %-  mole
          |.
          ?:  ?=(%submit -.cmd)
            (begin:workspace-wire bowl workspace submissions key.cmd approval.cmd)
          (recover:workspace-wire bowl workspace submissions key.cmd)
        ?~  observed  [(json-answer id 503 (status:web 'uncertain' 'Native evidence unavailable. Inspect the retained request before another action.')) this]
        =/  moved=change:workspace-wire  u.observed
        =/  view  (lookup:workspace-web our.bowl workspace journal.moved selected-key)
        ?>  ?=(^ view)
        ?>  ?=(%o -.u.view)
        =/  body=json  [%o (~(put by p.u.view) 'reason' s+reason.moved)]
        =/  held  (~(get by journal.moved) selected-key)
        =/  code=@ud
          ?~  held  409
          ?:(?=(?(%submitted %unknown) status.u.held) 202 200)
        [(weld (json-answer id code body) cards.moved) this(submissions journal.moved)]
      ?:  =('/apps/readymade-collab/session-sharing' url)
        =/  cmd  (post-request:session-sharing-web our.bowl req)
        ?~  cmd  [(json-answer id 400 (status:web 'refused' 'Explicit owner-origin session sharing command required.')) this]
        =/  observed  (mole |.((read:session-sharing-web bowl project.u.cmd)))
        ?~  observed  [(json-answer id 503 (status:web 'unavailable' 'Session sharing state unavailable.')) this]
        ?:  ?=(%| -.u.observed)
          [(json-answer id 409 (status:web 'refused' (scot %tas p.u.observed))) this]
        =/  planned  (plan:session-sharing p.u.observed command.u.cmd)
        ?:  ?=(%| -.planned)
          [(json-answer id 409 (status:web 'refused' (scot %tas p.planned))) this]
        ::  The owner's own pokes go out with the receipt. No ACK confirms them.
        [(weld (json-answer id 202 (receipt:session-sharing-web command.u.cmd (lent p.planned))) p.planned) this]
      ?:  =('/apps/readymade-collab/project-sharing' url)
        =/  cmd  (post-request:sharing-web req)
        ?~  cmd  [(json-answer id 400 (status:web 'refused' 'Explicit owner-origin sharing command required.')) this]
        =/  observed  (mole |.((read:sharing-wire bowl project.u.cmd)))
        ?~  observed  [(json-answer id 503 (status:web 'unavailable' 'Sharing state unavailable; inspect the retained request before resubmitting.')) this]
        ?:  ?=(%| -.u.observed)
          [(json-answer id 409 (status:web 'refused' (scot %tas p.u.observed))) this]
        =/  planned  (plan:sharing-wire our.bowl src.bowl p.u.observed sharing-journal u.cmd)
        ?:  ?=(%| -.planned)
          [(json-answer id 409 (status:web 'refused' (scot %tas p.planned))) this]
        =/  moved=change:sharing-wire  p.planned
        ::  Persist and send together. ACK never confirms the grant outcome.
        :-  (weld (json-answer id 202 (view:sharing-web p.u.observed record.moved)) cards.moved)
        this(sharing-journal journal.moved)
      ?:  =('/apps/readymade-collab/project-invitation' url)
        =/  cmd  (post-request:invitation-web req)
        ?~  cmd  [(json-answer id 400 (status:web 'refused' 'Explicit authenticated invitation command required.')) this]
        =/  begun  (begin:invitation-wire our.bowl invitation-journal u.cmd)
        ?:  ?=(?(%invalid-command %request-conflict %action-retained %journal-full) reason.begun)
          [(json-answer id 409 (status:web 'refused' (scot %tas reason.begun))) this]
        =/  held  (~(got by journal.begun) request.u.cmd)
        [(weld (json-answer id 200 (view:invitation-web held)) cards.begun) this(invitation-journal journal.begun)]
      ?:  =('/apps/readymade-collab/artifact-execute' url)
        ?.  =('POST' method.request.req)
          [(json-answer id 405 (status:web 'refused' 'Explicit POST required.')) this]
        ?.  (ready-request:executor req)
          [(json-answer id 403 (status:web 'refused' 'Owner origin, JSON and explicit executor header required.')) this]
        ?~  body.request.req  [(json-answer id 400 (status:web 'refused' 'Exact command body required.')) this]
        =/  body  u.body.request.req
        ?.  &(=(p.body (met 3 q.body)) (lte p.body 4.096))
          [(json-answer id 413 (status:web 'refused' 'Executor body exceeds bound.')) this]
        =/  parsed  (parse:executor q.body)
        ?~  parsed  [(json-answer id 400 (status:web 'refused' 'Invalid executor command.')) this]
        =/  cmd=command:executor  u.parsed
        ?:  (legacy-active ledger legacy-jobs)
          [(json-answer id 409 (refusal-json:executor our.bowl cmd %legacy-job-compatibility-active)) this]
        =/  prior=saved:saved-kit  [%readymade-collab-app-v4 state commands ledger graf-pending artifacts]
        =/  prepared  (mole |.((native-start:executor bowl cmd prior executions)))
        ?~  prepared  [(json-answer id 409 (refusal-json:executor our.bowl cmd %native-receiver-precondition-refused)) this]
        =/  result  u.prepared
        ?:  ?=(%| -.result)  [(json-answer id 409 (refusal-json:executor our.bowl cmd p.result)) this]
        =/  next  p.result
        =/  nonce=@ux  (key:executor cmd)
        =/  entry=entry:executor  (~(got by journal.next) nonce)
        =/  cards=(list card)
          ?:  duplicate.next  ~
          ~[[%pass /collab/execute/(scot %ux nonce) %agent [our.bowl %viki] %poke %noun !>([%native-coding-action-v1 [%artifact-proposal session.cmd nonce]])]]
        :-  (weld (json-answer id ?:(?=(?(%pending %uncertain) phase.entry) 202 200) (json-result:executor our.bowl entry)) cards)
        this(executions journal.next)
      ?:  =('/apps/readymade-collab/artifact-action' url)
        ?.  ?&  =('POST' method.request.req)
                (ready-request:artifact-actions req)
            ==
          [(json-answer id 403 (status:web 'refused' 'Owner JSON origin and explicit artifact header required.')) this]
        ?~  body.request.req
          [(json-answer id 400 (status:web 'refused' 'Body required.')) this]
        =/  body  u.body.request.req
        ?.  &(=(p.body (met 3 q.body)) (lte p.body 8.192))
          [(json-answer id 413 (status:web 'refused' 'Artifact command exceeds its bound.')) this]
        =/  parsed  (parse:artifact-actions q.body)
        ?~  parsed
          [(json-answer id 400 (status:web 'refused' 'Invalid exact artifact command.')) this]
        =/  cmd=command:artifact-actions  u.parsed
        =/  held=saved:saved-kit
          [%readymade-collab-app-v4 state commands ledger graf-pending artifacts]
        =/  attempted
          (mole |.((native:artifact-actions bowl cmd held)))
        ?~  attempted
          [(json-answer id 409 (result-json:artifact-actions our.bowl cmd 'refused' 'Exact artifact, current law or private target refused.' %.n)) this]
        =/  moved  u.attempted
        ?:  ?=(%| -.moved)
          [(json-answer id 409 (result-json:artifact-actions our.bowl cmd 'refused' (scot %tas p.moved) %.n)) this]
        =/  next  p.moved
        =/  reply=json
          (result-json:artifact-actions our.bowl cmd 'confirmed' 'Recorded locally. Peer approval and execution remain separate.' duplicate.next)
        =/  cards=(list card)
          ?~  event.next  ~
          ~[[%pass /collab/send/[request.cmd] %agent [peer.cmd %readymade-collab] %poke %noun !>(u.event.next)]]
        :-  (weld (json-answer id 200 reply) cards)
        this(state state.saved.next, commands commands.saved.next, artifacts artifacts.saved.next)
      ?.  &(=('POST' method.request.req) =('/apps/readymade-collab/action' url))
        [(json-answer id 405 (status:web 'refused' 'POST action required.')) this]
      ?.  (lien header-list.request.req |=([key=@t val=@t] &(=('content-type' key) |(=('application/json' val) =('application/json; charset=utf-8' val)))))
        [(json-answer id 415 (status:web 'refused' 'JSON required.')) this]
      ?~  body.request.req
        [(json-answer id 400 (status:web 'refused' 'Body required.')) this]
      =/  body  u.body.request.req
      ?.  &(=(p.body (met 3 q.body)) (lte p.body 16.384))
        [(json-answer id 413 (status:web 'refused' 'Invalid body length.')) this]
      =/  parsed  (parse:web q.body)
      ?~  parsed  [(json-answer id 400 (status:web 'refused' 'Invalid action.')) this]
      =/  cmd=command:c  u.parsed
      ?.  =(owner.cmd (scot %p our.bowl))
        [(json-answer id 403 (status:web 'refused' 'Wrong owner.')) this]
      =/  peer=(unit @p)  (slaw %p peer.cmd)
      ?~  peer  [(json-answer id 400 (status:web 'refused' 'Invalid peer.')) this]
      ?.  &(!=(our.bowl u.peer) =(peer.cmd (scot %p u.peer)))
        [(json-answer id 400 (status:web 'refused' 'Select another ship.')) this]
      =/  prior  (~(get by commands) request.cmd)
      ?^  prior
        =/  exact=?  =(u.prior (shax (jam cmd)))
        [(json-answer id ?:(exact 200 409) (status:web ?:(exact 'submitted' 'refused') ?:(exact 'Existing request observed; not resent.' 'Request identifier conflict.'))) this]
      ?:  &((gte ~(wyt by commands) 4.096) !=('pact-revoke' op.cmd))
        [(json-answer id 409 (status:web 'refused' 'Request capacity reached.')) this]
      ?:  =('artifact-import' op.cmd)
        =/  held=saved:saved-kit
          [%readymade-collab-app-v4 state commands ledger graf-pending artifacts]
        =/  prepared  (prepare-import:artifact-web our.bowl u.peer cmd held)
        ?.  ?=(%& -.prepared)
          [(json-answer id 409 (status:web 'refused' 'Exact owner/peer/pact/job/build-proof metadata import refused.')) this]
        =/  reply=json
          %-  pairs:enjs:format
          :~  ['schema' s+'readymade-artifact-import-result-v1']
              ['status' s+'confirmed']
              ['op' s+'artifact-import']
              ['owner' s+owner.cmd]
              ['peer' s+peer.cmd]
              ['request' s+request.cmd]
              ['pact' s+id.cmd]
              ['tid' s+reference.cmd]
              ['buildProof' s+digest.cmd]
              ['metadataOnly' b+%.y]
              ['sharedExecution' b+%.n]
              ['message' s+'Canonical local build metadata imported. No message, approval or execution was authorized.']
          ==
        :-  (json-answer id 200 reply)
        this(artifacts artifacts.saved.p.prepared, commands (~(put by commands) request.cmd (shax (jam cmd))))
      ?:  (lien `(list @t)`~['offer' 'inspect' 'accept' 'decline' 'build'] |=(op=@t =(op op.cmd)))
        ::  Resolve an owner-native witness and freshly verify exact Graf
        ::  membership BEFORE start:ops can journal/start a source release.
        =/  graf-ok=?
          ?:  !=('offer' op.cmd)  %.y
          ?.  (offer-valid:ops cmd)  %.n
          ?~  graf-choices  %.n
          =/  hash=(unit @ux)  (slaw %ux digest.cmd)
          ?~  hash  %.n
          ?.  =(digest.cmd (scot %ux u.hash))  %.n
          =/  admitted=(each witness:graf-select refusal:graf-admit)
            (verify:graf-admit bowl u.graf-choices u.hash)
          ?=(%& -.admitted)
        ?.  graf-ok
          [(json-answer id 409 (status:web 'refused' 'Graf record unresolved or exact native membership unverified. Load a native Graf record page and select an existing record before offering.')) this]
        =/  begun  (start:ops bowl state ledger cmd)
        ?~  begun
          [(json-answer id 409 (status:web 'refused' 'Native operation refused; check source, package state, ownership and pending jobs.')) this]
        =/  next  u.begun
        :-  (weld (json-answer id 200 (status:web 'submitted' message.next)) cards.next)
        this(state state.next, ledger ledger.next, commands (~(put by commands) request.cmd (shax (jam cmd))))
      ?.  (lien `(list @t)`~['propose' 'pact-accept' 'pact-revoke'] |=(op=@t =(op op.cmd)))
        [(json-answer id 409 (status:web 'refused' 'Native source inspection and build integration are not available yet.')) this]
      =/  prepared=(unit [state=state:c event=envelope:c])
        (mole |.((prepare cmd u.peer)))
      ?~  prepared
        [(json-answer id 409 (status:web 'refused' 'Exact source, package, pact or native law observation was refused.')) this]
      =/  next  u.prepared
      =/  stored=state:c
        (record:flow state.next [request.cmd op.cmd %confirmed our.bowl 'Recorded locally; peer consent and Graf readback remain separate observations.'])
      =/  archived
        (queue-evidence our.bowl stored graf-pending (event:archive our.bowl u.peer event.next))
      :-  (weld (json-answer id 200 (status:web 'submitted' 'Recorded locally and submitted over Ames.')) [(transmit u.peer event.next) cards.archived])
      this(state state.archived, graf-pending pending.archived, commands ?:((gte ~(wyt by commands) 4.096) commands (~(put by commands) request.cmd (shax (jam cmd)))))
++  on-init  [~[bind-page] this]
++  on-save  !>([%readymade-collab-app-v10 [%readymade-collab-app-v9 [%readymade-collab-app-v8 [%readymade-collab-app-v7 [%readymade-collab-app-v6 [%readymade-collab-app-v5 [%readymade-collab-app-v4 state commands ledger graf-pending artifacts] executions] invitation-journal] workspace submissions] sharing-journal] returns] rich-returns])
++  on-load
  |=  old=vase
  ^-  (quip card _this)
  =/  restored=(unit saved:rich-return-saved)  (restore:rich-return-saved our.bowl q.old)
  ?>  ?=(^ restored)
  =/  return-prior=saved:return-saved  previous.u.restored
  =/  shared-prior=saved:sharing-saved  previous.return-prior
  =/  workspace-prior=saved:workspace-saved  previous.shared-prior
  =/  prior=saved:invitation-wire  previous.workspace-prior
  =/  held=saved:saved-kit  previous.previous.prior
  ::  Rewatch existing jobs only. Neither Graf nor artifact effects replay.
  :-  (weld (reload:project-suggest our.bowl wex.bowl) (weld (reload:project-sessions our.bowl wex.bowl) (weld (reload:project-view our.bowl wex.bowl) (weld `(list card)`~[bind-page] (watch-pending our.bowl ledger.held)))))
  this(state state.held, commands commands.held, ledger ledger.held, graf-pending pending.held, artifacts artifacts.held, executions executions.previous.prior, invitation-journal invitations.prior, workspace workspace.workspace-prior, submissions submissions.workspace-prior, sharing-journal sharing.shared-prior, returns returns.return-prior, rich-returns rich-returns.u.restored, legacy-jobs (legacy-watchers ledger.held), graf-choices ~, project-views ~, project-suggestions ~, project-suggestion-recoveries ~)
++  on-poke
  |=  [=mark =vase]
  ^-  (quip card _this)
  ?:  &(=(%noun mark) ?=([%readymade-workspace-action-v1 *] q.vase))
    ?>  =(our.bowl src.bowl)
    =/  envelope  ((soft ,[%readymade-workspace-action-v1 action=command:workspace-wire]) q.vase)
    ?>  ?=(^ envelope)
    =/  cmd=command:workspace-wire  action.u.envelope
    ?:  ?=(%bind -.cmd)
      =/  moved  (bind:workspace-requests workspace our.bowl src.bowl expected.cmd spec.cmd)
      ?>  accepted.moved
      `this(workspace state.moved)
    ?:  ?=(%reserve -.cmd)
      =/  moved  (reserve:workspace-requests workspace our.bowl src.bowl request.cmd)
      ?>  accepted.moved
      `this(workspace state.moved)
    ?:  ?=(%disable -.cmd)
      =/  moved  (disable:workspace-requests workspace our.bowl src.bowl binding.cmd)
      ?>  accepted.moved
      `this(workspace state.moved)
    =/  moved=change:workspace-wire
      ?:  ?=(%submit -.cmd)
        (begin:workspace-wire bowl workspace submissions key.cmd approval.cmd)
      (recover:workspace-wire bowl workspace submissions key.cmd)
    [cards.moved this(submissions journal.moved)]
  ?:  =(%noun mark)
    =/  imported
      ((soft ,[%readymade-artifact-import-v1 pact=@ux tid=@ta]) q.vase)
    ?^  imported
      ?>  =(our.bowl src.bowl)
      =/  held=saved:saved-kit
        [%readymade-collab-app-v4 state commands ledger graf-pending artifacts]
      =/  moved
        (import-build:artifact-prep our.bowl src.bowl pact.u.imported tid.u.imported held)
      ?>  ?=(%& -.moved)
      ::  Canonical receipt metadata only. No message, approval or replay.
      `this(artifacts artifacts.saved.p.moved)
    =/  parsed=(unit envelope:c)  ((soft envelope:c) q.vase)
    ?^  parsed
      =/  event=envelope:c  u.parsed
      ?.  |(=(our.bowl src.bowl) (revoking:flow event))
        ?>  (connected bowl)
        (receive-event event)
      (receive-event event)
    =/  parsed=(unit envelope:a)  ((soft envelope:a) q.vase)
    ?>  ?=(^ parsed)
    ::  Local artifact approvals require a future owner/current-law preparation
    ::  surface. Raw local v2 pokes cannot supply that missing authorization.
    ?>  !=(our.bowl src.bowl)
    =/  event=envelope:a  u.parsed
    =/  revoking=?  ?&  ?=([%revoke *] payload.event)
                         ?=([%revoke *] action.move.payload.event)
                     ==
    ?>  |(revoking (connected bowl))
    =/  held=saved:saved-kit
      [%readymade-collab-app-v4 state commands ledger graf-pending artifacts]
    =/  moved=(each saved:saved-kit @tas)
      (receive-routed:saved-kit held our.bowl src.bowl event)
    ?>  ?=(%& -.moved)
    `this(state state.p.moved, artifacts artifacts.p.moved)
  (http-request mark vase)
++  on-peek
  |=  path=path
  ^-  (unit (unit cage))
  ?.  =(our.bowl src.bowl)  ~
  ?:  =(/x/workspace path)  ``noun+!>([%readymade-workspace-state-v1 workspace submissions])
  ?:  =(/x/state path)
    ?:  (legacy-active ledger legacy-jobs)  ``noun+!>(state)
    =/  packet=executor-packet:state-read
      [%readymade-collab-state-v5 [%readymade-collab-state-v4 state artifacts] %native-artifact-executor-v1 executions]
    ``noun+!>(packet)
  ?:  =(/x/jobs path)  ``noun+!>(ledger)
  ?:  =(/x/graf/pending path)  ``noun+!>(graf-pending)
  ?:  ?=([%x %pending @ ~] path)
    =/  found=(list command:c)
      %+  murn  ~(val by ledger)
      |=  work=job:j
      ?.  &(=(%release kind.work) =(%pending phase.work) =(i.t.t.path request.command.work))  ~
      `command.work
    ``noun+!>(?~(found `(unit command:c)`~ `i.found))
  [~ ~]
++  on-watch
  |=  path=path
  ^-  (quip card _this)
  =/  answer=(unit (list card))
    (watch:login-gate our.bowl src.bowl path sup.bowl)
  ?>  ?=(^ answer)
  [u.answer this]
++  on-agent
  |=  [wire=wire sign=sign:agent:gall]
  ^-  (quip card _this)
  ::  ACK/NACK is not delivery evidence; only exact canonical readback settles.
  ?:  ?=([%workspace-return @ ~] wire)  `this
  ?:  ?=([%workspace-return-rich @ ~] wire)  `this
  ?:  ?=([%collab %project-suggest-recover *] wire)
    =/  moved  (receive:project-suggest our.bowl src.bowl now.bowl project-suggestion-recoveries wire sign)
    [cards.moved this(project-suggestion-recoveries journal.moved)]
  ?:  ?=([%collab %project-suggest *] wire)
    =/  moved  (receive:project-suggest our.bowl src.bowl now.bowl project-suggestions wire sign)
    [cards.moved this(project-suggestions journal.moved)]
  ?:  ?=([%collab %project-view *] wire)
    =/  moved  (receive:project-view our.bowl src.bowl now.bowl project-views wire sign)
    [cards.moved this(project-views journal.moved)]
  ?:  ?=([%collab %project-sessions *] wire)
    =/  moved  (receive:project-sessions our.bowl src.bowl now.bowl project-session-lists wire sign)
    [cards.moved this(project-session-lists journal.moved)]
  ::  Both ACK and NACK leave the retained request for canonical GET readback.
  ?:  ?=([%collab %sharing @ ~] wire)  `this
  ?:  ?=([%collab %session-sharing @ ~] wire)  `this
  ?:  ?=([%collab ?(%invitation %invitation-send) @ ~] wire)
    =/  moved  (receive:invitation-wire bowl invitation-journal wire sign)
    [cards.moved this(invitation-journal journal.moved)]
  ?:  ?=([%collab %execute @ ~] wire)
    ?.  &(=(our.bowl src.bowl) ?=([%poke-ack ^] sign))  `this
    =/  nonce  (slaw %ux i.t.t.wire)
    ?~  nonce  `this
    ?.  =(wire /collab/execute/(scot %ux u.nonce))  `this
    =/  held  (~(get by executions) u.nonce)
    ?~  held  `this
    ?.  =(%pending phase.u.held)  `this
    `this(executions (~(put by executions) u.nonce u.held(phase %uncertain, reason %native-handoff-unconfirmed)))
  ?:  ?=([%collab %law *] wire)
    ?.  =(our.bowl src.bowl)  `this
    =/  moved  (receive:law-watch our.bowl now.bowl state law-view wire sign)
    [cards.moved this(law-view model.moved)]
  ?:  ?=([%collab %graf @ ~] wire)
    ?.  =(our.bowl src.bowl)  `this
    ?.  ?=([%poke-ack *] sign)  `this
    =/  hash=(unit @ux)  (slaw %ux i.t.t.wire)
    ?~  hash  `this
    ?.  =(wire /collab/graf/(scot %ux u.hash))  `this
    =/  held=(unit entry:archive)  (~(get by graf-pending) u.hash)
    ?~  held  `this
    ::  Both ACK and NACK require canonical readback. A NACK alone cannot
    ::  establish whether this exact immutable fact was retained.
    =/  observed=(unit ?)  (graf-readback bowl fact.u.held)
    =/  moved=change:archive  (settle:archive our.bowl graf-pending u.hash observed)
    =/  next=state:c
      ?~(receipt.moved state (record:flow state u.receipt.moved))
    [cards.moved this(state next, graf-pending pending.moved)]
  ?:  ?=([%collab %job @ ~] wire)
    =/  tid=@ta  i.t.t.wire
    =/  found  (~(get by ledger) tid)
    ?~  found  `this
    =/  work=job:j  u.found
    ?.  =(%pending phase.work)  `this
    ?:  ?=([%fact *] sign)
      ?:  =(%thread-done p.cage.sign)
        =/  completed  (complete:jobs our.bowl state ledger tid q.q.cage.sign)
        ?.  accepted.completed  `this
        =/  peer=@p  (need (slaw %p peer.command.work))
        =/  archived
          (queue-evidence our.bowl state.completed graf-pending (operation:archive our.bowl tid (~(got by ledger.completed) tid)))
        =/  cards=(list card)
          [[%pass wire %agent [our.bowl %spider] %leave ~] cards.archived]
        =/  sent=archive-transition
          ?~  outgoing.completed  archived
          (queue-evidence our.bowl state.archived pending.archived (event:archive our.bowl peer u.outgoing.completed))
        =.  cards
          ?~  outgoing.completed  cards
          (weld cards [(transmit peer u.outgoing.completed) cards.sent])
        [cards this(state state.sent, ledger ledger.completed, graf-pending pending.sent)]
      ?:  =(%thread-fail p.cage.sign)
        =/  phase=?(%refused %uncertain)  ?:(=(%inspect kind.work) %refused %uncertain)
        =/  next  work(phase phase)
        =/  stored=state:c
          (record:flow state [request.command.work op.command.work phase our.bowl 'Native thread failed; inspect its retained job before another operation.'])
        =/  archived
          (queue-evidence our.bowl stored graf-pending (operation:archive our.bowl tid next))
        [[[%pass wire %agent [our.bowl %spider] %leave ~] cards.archived] this(state state.archived, ledger (~(put by ledger) tid next), graf-pending pending.archived)]
      `this
    ?:  |(?=([%poke-ack ^] sign) ?=([%watch-ack ^] sign) ?=([%kick *] sign))
      `this(state (record:flow state [request.command.work op.command.work %uncertain our.bowl 'Native job outcome unconfirmed; no restart or retry was issued.']))
    `this
  ?:  ?=([%collab %send @ ~] wire)
    ?:  ?=([%poke-ack ^] sign)
      =/  request=@t  i.t.t.wire
      `this(state (record:flow state [request 'delivery' %uncertain our.bowl 'Peer refused delivery; no retry was issued.']))
    `this
  (on-agent:def wire sign)
++  on-arvo
  |=  [wire=wire sign=sign-arvo]
  ^-  (quip card _this)
  ?:  &(?=([%collab %project-suggest-recover *] wire) ?=([%behn %wake *] sign))
    =/  moved  (wake:project-suggest now.bowl project-suggestion-recoveries wire)
    [cards.moved this(project-suggestion-recoveries journal.moved)]
  ?:  &(?=([%collab %project-suggest *] wire) ?=([%behn %wake *] sign))
    =/  moved  (wake:project-suggest now.bowl project-suggestions wire)
    [cards.moved this(project-suggestions journal.moved)]
  ?:  &(?=([%collab %project-view *] wire) ?=([%behn %wake *] sign))
    =/  moved  (wake:project-view now.bowl project-views wire)
    [cards.moved this(project-views journal.moved)]
  ?:  &(?=([%collab %project-sessions *] wire) ?=([%behn %wake *] sign))
    =/  moved  (wake:project-sessions now.bowl project-session-lists wire)
    [cards.moved this(project-session-lists journal.moved)]
  ?:  &(=(/collab/bind wire) ?=([%eyre %bound *] sign))  `this
  (on-arvo:def wire sign)
++  on-leave  on-leave:def
++  on-fail  on-fail:def
--
