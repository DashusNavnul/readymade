::  /app/multiplayer-runtime
::
::  Urbit-native multiplayer workflow and judgment authority.  No Earthside
::  loop; the browser/cockpit is only a transport client of durable Gall state.
::
/-  mce=multiplayer-contributor-export, mcr=multiplayer-cockpit-review,
    mr=multiplayer-receipt, mrp=multiplayer-reputation,
    mrt=multiplayer-runtime
/+  default-agent, mcel=multiplayer-contributor-export,
    mrpl=multiplayer-reputation,
    mrtl=multiplayer-runtime
|%
+$  export-query
  [%multiplayer-contributor-export-request-v1 project=@t nonce=@ud]
+$  card  card:agent:gall
--
=|  state=state:mrt
^-  agent:gall
|_  =bowl:gall
+*  this  .
    def   ~(. (default-agent this %.n) bowl)
++  on-init  `this(state initial-state:mrtl)
++  on-save  !>(state)
++  on-load
  |=  old=vase
  =/  restored=(unit state:mrt)  ((soft state:mrt) q.old)
  ?^  restored  `this(state u.restored)
  =/  legacy-6=(unit state-6:mrt)  ((soft state-6:mrt) q.old)
  ?^  legacy-6  `this(state (migrate-6:mrtl u.legacy-6))
  =/  legacy-5=(unit state-5:mrt)  ((soft state-5:mrt) q.old)
  ?^  legacy-5  `this(state (migrate-5:mrtl u.legacy-5))
  =/  legacy-4=(unit state-4:mrt)  ((soft state-4:mrt) q.old)
  ?^  legacy-4  `this(state (migrate-4:mrtl u.legacy-4))
  =/  legacy-3=(unit state-3:mrt)  ((soft state-3:mrt) q.old)
  ?^  legacy-3  `this(state (migrate-3:mrtl u.legacy-3))
  =/  legacy-2=(unit state-2:mrt)  ((soft state-2:mrt) q.old)
  ?^  legacy-2  `this(state (migrate-2:mrtl u.legacy-2))
  =/  legacy=(unit state-1:mrt)  ((soft state-1:mrt) q.old)
  ?^  legacy  `this(state (migrate:mrtl u.legacy))
  `this(state initial-state:mrtl)
++  on-arvo   on-arvo:def
++  on-agent  on-agent:def
++  on-watch
  |=  =path
  ^-  (quip card _this)
  ?+  path  (on-watch:def path)
    [%outcomes ~]
      ?.  ?|(=(our.bowl src.bowl) =(our.bowl (^sein:title src.bowl)))
        ~|([%multiplayer-runtime %watch-refused src=src.bowl path] !!)
      `this
    ::  Membership changes, for this ship's own agents only: who joined or
    ::  left which project. Grants are held elsewhere (Cantrip, Viki); their
    ::  holder listens here so a leave or a rejoin ends old grants at once,
    ::  with no timer.
    [%membership ~]
      ?.  =(our.bowl src.bowl)
        ~|([%multiplayer-runtime %watch-refused src=src.bowl path] !!)
      `this
    [%refusals ~]
      ?.  ?|(=(our.bowl src.bowl) =(our.bowl (^sein:title src.bowl)))
        ~|([%multiplayer-runtime %watch-refused src=src.bowl path] !!)
      `this
    [%receipts ~]
      ?.  ?|(=(our.bowl src.bowl) =(our.bowl (^sein:title src.bowl)))
        ~|([%multiplayer-runtime %watch-refused src=src.bowl path] !!)
      [[%give %fact ~[/receipts] %noun !>(`receipt-event:mrt`[%ready ~])]~ this]
    [?(%actions %action-receipts) @ @ ~]
      =/  project=@t  (slav %ux i.t.path)
      =/  owner=@p  (slav %p i.t.t.path)
      ?.  =(owner src.bowl)
        ~|([%multiplayer-runtime %watch-owner-refused src=src.bowl owner path] !!)
      ?.  (may-observe-action:mcel state project src.bowl)
        ~|([%multiplayer-runtime %watch-project-refused src=src.bowl project path] !!)
      ?:  =(%action-receipts i.path)
        =/  item  (~(get by catalog.state) project)
        ?~  item  ~|(%receipt-project-missing !!)
        ?.  =(our.bowl authority.spec.u.item)
          ~|(%receipt-foreign-authority !!)
        [[%give %fact ~[path] %noun !>(`receipt-event:mrt`[%ready ~])]~ this]
      `this
    [%exports @ @ ~]
      =/  project=@t  (slav %ux i.t.path)
      =/  owner=@p  (slav %p i.t.t.path)
      ?.  =(owner src.bowl)
        ~|([%multiplayer-runtime %watch-owner-refused src=src.bowl owner path] !!)
      ?.  (may-export:mcel state project src.bowl)
        ~|([%multiplayer-runtime %watch-export-refused src=src.bowl project path] !!)
      `this
  ==
++  on-leave  on-leave:def
++  on-fail   on-fail:def
++  on-peek
  |=  =path
  ^-  (unit (unit cage))
  ?+  path  [~ ~]
    [%x %state ~]  ``noun+!>(state)
    [%x %active ~]  ``noun+!>(active.state)
    [%x %ingress @ ~]
      =/  found  (~(get by ingress.state) (slav %p i.t.t.path))
      ``noun+!>(found)
    [%x %catalog @ ~]
      =/  found  (~(get by catalog.state) `@t`i.t.t.path)
      ``noun+!>(found)
    [%x %seats @ ~]
      =/  found  (~(get by seats.state) `@t`i.t.t.path)
      ``noun+!>(found)
    [%x %chain @ ~]
      =/  project=@t  i.t.t.path
      =/  found=(unit chain:mr)
        (~(get by chains.state) [project our.bowl])
      ``noun+!>(found)
    [%x %export @ @ ~]
      =/  project=@t  i.t.t.path
      =/  owner=@p  (slav %p i.t.t.t.path)
      =/  chain=(unit chain:mr)
        (~(get by chains.state) [project our.bowl])
      =/  bundle=(unit bundle:mrp)
        ?~(chain ~ (bundle-for:mrpl u.chain owner))
      ``noun+!>(bundle)
    [%x %transfer @ ~]
      =/  found  (~(get by transfers.state) (slav %ux i.t.t.path))
      ``noun+!>(found)
    [%x %landing @ ~]
      =/  found  (~(get by landings.state) (slav %ux i.t.t.path))
      ``noun+!>(found)
    [%x %ruling @ ~]
      =/  found  (~(get by rulings.state) (slav %ux i.t.t.path))
      ``noun+!>(found)
    [%x %review @ ~]
      =/  project=(unit project-state:mrt)
        (~(get by projects.state) `@t`i.t.t.path)
      =/  review=(unit snapshot:mcr)
        ?~(project ~ review.u.project)
      ``noun+!>(review)
  ==
++  on-poke
  |=  [=mark =vase]
  ^-  (quip card _this)
  ?:  =(%noun mark)
    ::  Versioned transport for hosted updates: the live desk's older custom
    ::  mark may not yet know a new action. Reuse the same typed admission path
    ::  and original authenticated bowl; the envelope grants no authority.
    =/  command=(unit [%multiplayer-runtime-command-v1 action=action:mrt])
      ((soft ,[%multiplayer-runtime-command-v1 action=action:mrt]) q.vase)
    ?^  command
      ?>  =(q.vase u.command)
      $(mark %multiplayer-runtime-action, vase !>(action.u.command))
    =/  request=(unit export-query)
      ((soft export-query) q.vase)
    ?~  request  (on-poke:def mark vase)
    =/  req=export-query  u.request
    =/  result=result:mce
      ?:  =(0 nonce.req)
        [%refused src.bowl %invalid-argument]
      (export:mcel state our.bowl src.bowl project.req)
    =/  project-segment=@ta  (scot %ux project.req)
    =/  owner-segment=@ta  (scot %p src.bowl)
    :_  this
    ~[[%give %fact ~[/exports/[project-segment]/[owner-segment]] %noun !>([%multiplayer-contributor-export-v2 project.req nonce.req result])]]
  ?.  =(%multiplayer-runtime-action mark)  (on-poke:def mark vase)
  =/  action=action:mrt  !<(action:mrt vase)
  =/  project=(unit @t)  (project-for:mrtl state action)
  =/  handled=handled:mrt
    (process:mrtl state our.bowl src.bowl now.bowl action)
  =/  result=result:mrt  result.handled
  =/  action-digest=digest:mrt  `@ux`(shax (jam action))
  =/  correlated=action-receipt:mrt
    ?-  -.result
      %|  [%refused action-digest p.result]
      %&  [%accepted action-digest code.p.result ruling.p.result]
    ==
  =/  scoped=(list card)
    ?~  project  ~
    =/  project-segment=@ta  (scot %ux u.project)
    =/  owner-segment=@ta  (scot %p src.bowl)
    :~  [%give %fact ~[/actions/[project-segment]/[owner-segment]] %noun !>(result)]
        [%give %fact ~[/action-receipts/[project-segment]/[owner-segment]] %noun !>(`receipt-event:mrt`[%receipt correlated])]
    ==
  ::  A join, a leave or a removal that was accepted, named for /membership.
  =/  membership=(list card)
    ?.  ?=(%& -.result)  ~
    =/  moved=(unit [kind=?(%joined %left) project=@t ship=@p])
      ?+  -.action  ~
        %join           `[%joined project.action src.bowl]
        %leave          `[%left project.action src.bowl]
        %remove-member  `[%left project.action target.action]
      ==
    ?~  moved  ~
    ~[[%give %fact ~[/membership] %noun !>([%multiplayer-membership-v1 u.moved])]]
  ?-  -.result
    %|
      =/  receipt=action-receipt:mrt
        [%refused action-digest p.result]
      :_  this(state state.handled)
      %+  weld
        :~  [%give %fact ~[/receipts] %noun !>(`receipt-event:mrt`[%receipt receipt])]
            [%give %fact ~[/refusals] %noun !>(p.result)]
        ==
      scoped
    %&
      =/  receipt=action-receipt:mrt
        [%accepted action-digest code.p.result ruling.p.result]
      :_  this(state state.handled)
      %+  weld
        :~  [%give %fact ~[/receipts] %noun !>(`receipt-event:mrt`[%receipt receipt])]
            [%give %fact ~[/outcomes] %noun !>([code.p.result ruling.p.result])]
        ==
      (weld membership scoped)
  ==
--
