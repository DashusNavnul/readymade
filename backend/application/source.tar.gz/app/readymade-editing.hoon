::  Advisory file activity over authenticated Ames. All room/client state is
::  transient; load clears it. This agent cannot edit source or grant permission.
/+  default-agent, server=readymade-editing-activity-owner,
    client=readymade-editing-activity-client,
    web=readymade-editing-activity-http, login=readymade-page-http-gate
=>
|%
+$  card  card:agent:gall
++  bind
  ^-  card
  [%pass /activity/bind %arvo %e %connect [~ /apps/readymade-editing] %readymade-editing]
++  answer
  |=  [id=@ta code=@ud data=json]
  ^-  (list card)
  =/  text=@t  (en:json:html data)
  =/  header  [code ~[['content-type' 'application/json; charset=utf-8'] ['cache-control' 'no-store'] ['x-content-type-options' 'nosniff']]]
  =/  body=(unit octs)  `[(met 3 text) text]
  =/  route=path  /http-response/[id]
  :~  [%give %fact ~[route] %http-response-header !>(header)]
      [%give %fact ~[route] %http-response-data !>(body)]
      [%give %kick ~[route] ~]
  ==
++  problem
  |=  reason=@t
  ^-  json
  (pairs:enjs:format ~[['status' s+'unavailable'] ['reason' s+reason] ['permissionGranted' b+%.n]])
++  pending
  |=  key=selector:web
  ^-  json
  %-  pairs:enjs:format
  :~  ['schema' s+'readymade-editing-activity-result-v1']
      ['status' s+'pending']  ['permissionGranted' b+%.n]
      ['owner' s+(scot %p owner.key)]  ['project' s+project.key]
      ['request' s+(scot %uv request.key)]
  ==
++  send
  |=  [peer=@p id=@uv value=*]
  ^-  card
  [%pass /activity/(scot %uv id) %agent [peer %readymade-editing] %poke %noun !>(value)]
--
=|  rooms=rooms:server
=|  journal=journal:client
=|  sequence=@ud
^-  agent:gall
|_  =bowl:gall
+*  this  .
    def  ~(. (default-agent this %.n) bowl)
++  on-init  [~[bind] this]
++  on-save  !>(%readymade-editing-activity-v1)
++  on-load
  |=  old=vase
  ?>  =(%readymade-editing-activity-v1 !<(@tas old))
  [~[bind] this(rooms ~, journal ~, sequence 0)]
++  on-poke
  |=  [=mark =vase]
  ^-  (quip card _this)
  ?:  =(%handle-http-request mark)
    ?.  =(our.bowl src.bowl)  `this
    =+  !<([id=@ta req=inbound-request:eyre] vase)
    ?.  authenticated.req
      [(answer id 403 (problem 'owner-login-required')) this]
    ?:  =('GET' method.request.req)
      ?.  =('/apps/readymade-editing/result' url.request.req)
        [(answer id 404 (problem 'unknown-route')) this]
      =/  key  (result-request:web req)
      ?~  key  [(answer id 400 (problem 'exact-request-required')) this]
      =/  entry  (~(get by journal) [owner.u.key project.u.key request.u.key])
      ?~  entry  [(answer id 404 (problem 'request-not-retained')) this]
      ?.  (fresh:client now.bowl u.entry)
        [(answer id 410 (problem 'request-expired-outcome-unknown')) this]
      =/  result  (result:client now.bowl owner.u.key project.u.key request.u.key journal)
      ?~  result  [(answer id 202 (pending u.key)) this]
      =/  body  (response:web u.key u.result)
      ?~  body  [(answer id 503 (problem 'invalid-retained-result')) this]
      [(answer id 200 u.body) this]
    ?.  &(=('POST' method.request.req) =('/apps/readymade-editing/action' url.request.req))
      [(answer id 404 (problem 'unknown-route')) this]
    =/  cmd  (post-request:web req)
    ?~  cmd  [(answer id 400 (problem 'same-origin-command-required')) this]
    =/  request=@uv  (shax (jam [our.bowl now.bowl eny.bowl sequence]))
    =/  message=request:server  [request project.u.cmd action.u.cmd]
    =/  started  (begin:client now.bowl owner.u.cmd message journal)
    ?:  ?=(%| -.started)
      [(answer id 409 (problem p.started)) this]
    :-  [(send owner.u.cmd request [%readymade-activity-request-v2 message]) (answer id 202 (pending [owner.u.cmd project.u.cmd request]))]
    this(journal p.started, sequence +(sequence))
  ?>  =(%noun mark)
  ?>  (lte (met 3 (jam q.vase)) 32.768)
  ?:  ?=([%readymade-activity-send-v2 *] q.vase)
    ?>  =(our.bowl src.bowl)
    =/  cmd  ((soft ,[%readymade-activity-send-v2 owner=@p project=@t action=action:server]) q.vase)
    ?>  ?=(^ cmd)
    =/  id=@uv  (shax (jam [our.bowl now.bowl eny.bowl sequence]))
    =/  req=request:server  [id project.u.cmd action.u.cmd]
    =/  started  (begin:client now.bowl owner.u.cmd req journal)
    ?>  ?=(%& -.started)
    :-  ~[(send owner.u.cmd id [%readymade-activity-request-v2 req])]
    this(journal p.started, sequence +(sequence))
  ?:  ?=([%readymade-activity-request-v2 *] q.vase)
    =/  parsed  ((soft ,[%readymade-activity-request-v2 request:server]) q.vase)
    ?>  ?=(^ parsed)
    =/  req=request:server  +.u.parsed
    ?>  &((gth id.req 0) (lte (met 0 id.req) 256))
    =/  observed  (mole |.((read:server bowl project.req)))
    =/  moved=change:server
      ?~  observed
        [rooms [id.req project.req [%| %activity-native-unavailable]]]
      ?:  ?=(%| -.u.observed)
        [rooms [id.req project.req [%| p.u.observed]]]
      (serve:server observation.p.u.observed window.p.u.observed rooms src.bowl req)
    :-  ~[(send src.bowl id.req [%readymade-activity-result-v2 response.moved])]
    this(rooms rooms.moved)
  =/  parsed  ((soft ,[%readymade-activity-result-v2 response:server]) q.vase)
  ?>  ?=(^ parsed)
  `this(journal (receive:client now.bowl src.bowl +.u.parsed journal))
++  on-peek
  |=  =path
  ^-  (unit (unit cage))
  ?.  =(our.bowl src.bowl)  ~
  ?:  =(/x/status path)
    ``noun+!>([%readymade-editing-status-v1 ~(wyt by rooms) ~(wyt by journal)])
  ?.  ?=([%x %result @ @ @ ~] path)  ~
  =/  owner  (slaw %p i.t.t.path)
  ?~  owner  ~
  ?.  =(i.t.t.path (scot %p u.owner))  ~
  =/  id  (slaw %uv i.t.t.t.t.path)
  ?~  id  ~
  ?.  &((gth u.id 0) (lte (met 0 u.id) 256) =(i.t.t.t.t.path (scot %uv u.id)))  ~
  ``noun+!>((result:client now.bowl u.owner i.t.t.t.path u.id journal))
++  on-agent
  |=  [=wire =sign:agent:gall]
  ::  A transport ACK is never a result. No automatic resend after either ACK.
  `this
++  on-watch
  |=  =path
  ^-  (quip card _this)
  =/  result  (watch:login our.bowl src.bowl path sup.bowl)
  ?>  ?=(^ result)
  [u.result this]
++  on-leave  on-leave:def
++  on-arvo
  |=  [=wire sign=sign-arvo]
  ^-  (quip card _this)
  ?.  &(=(/activity/bind wire) ?=([%eyre %bound *] sign))
    (on-arvo:def wire sign)
  ?>  =([~ /apps/readymade-editing] binding.sign)
  ~|  %readymade-editing-bind-refused
  ?>  accepted.sign
  `this
++  on-fail  on-fail:def
--
