::  /lib/hand-bind.hoon
::
::  BINDING %hand TO THE LAW (the thing we forgot). %hand is the ship's effector
::  limb over its host; its own `hand-gate` predates the honesty-typed law we just
::  finished. This binds a REAL host op through that law before the courier ever
::  moves -- the same propose/govern/execute we proved for the bound worker, now
::  for actual host effects. A host op is governed by three legs mapped onto the
::  %hand effect-class ladder (read < revoke < grave):
::
::    AUTHORITY  the op's class demands a regime act (read->articulate,
::               revoke->propose, grave->commit); that act must be admissible now.
::    HONESTY    an UNKNOWN recipe fails safe to %grave (sur/hand recipe-class) --
::               a capability the manifest cannot vouch for is treated as maximally
::               dangerous, never quietly run. The manifest declares; the law proves.
::    SAFETY     a quarantined fleet vetoes even a read (interlock); and a %grave
::               (destructive) op is NEVER auto-run -- it is held for principal
::               approval even when authority and safety are green.
::
::  Verdict: %execute (admitted) / %hold (refused) / %needs-approval (grave, gated).
::  Governance only -- this decides; it does not spit. COMPUTED -- exact.
::
/-  ca=cantrip-action, hand
/+  regime
|%
+$  verdict  [ruling=@tas why=@tas class=class:hand]
++  status   ^-(@tas %computed)
::  the regime act a host op's effect-class demands.
++  act-for
  |=  =class:hand
  ^-  act:regime
  ?-  class
    %read    %articulate
    %revoke  %propose
    %grave   %commit
  ==
::  govern one host op against the law.
++  govern
  |=  [reg=regime:regime quarantined=? =op:hand]
  ^-  verdict
  =/  cl=class:hand  (class-of:hand op)
  ?:  quarantined                             [%hold %safety-quarantine cl]
  ?.  (admissible:regime reg (act-for cl))    [%hold %authority-insufficient cl]
  ?:  =(%grave cl)                            [%needs-approval %grave-never-auto cl]
  [%execute %admitted cl]
::  Cantrip's resident host-effect judgment.  A degraded ship is inert; a safe
::  ship may only read; a full ship may perform reversible effects.  Destructive
::  effects additionally require the principal-only approval bit supplied by
::  Hand's authenticated Gall boundary.
++  host-admit
  |=  [ceiling=@tas effect=@tas principal-approved=?]
  ^-  host-verdict:ca
  ?.  ?|(=(%read effect) =(%revoke effect) =(%grave effect))
    [%.n %unknown-effect-class ceiling]
  ?-  ceiling
    %off   [%.n %health-ceiling-off ceiling]
    %safe
      ?:  =(%read effect)
        [%.y %admitted ceiling]
      [%.n %above-health-ceiling ceiling]
    %full
      ?:  =(%grave effect)
        ?:  principal-approved
          [%.y %principal-approved ceiling]
        [%.n %principal-approval-required ceiling]
      [%.y %admitted ceiling]
    *      [%.n %unknown-health-ceiling ceiling]
  ==
::  THE SPIT-GATE. What the live %hand agent runs on every op BEFORE it emits an
::  order over Lick. Regime-free -- the agent carries a ceiling, not a regime -- so
::  it composes with the agent's own floor check. A %grave op crosses this gate
::  only after the authenticated principal has explicitly approved the proposal.
++  gate-op-with
  |=  [ceiling=class:hand =op:hand principal-approved=?]
  ^-  [ok=? why=@tas]
  =/  cl=class:hand  (class-of:hand op)
  ?:  (gth (class-rank:hand cl) (class-rank:hand ceiling))  [%.n %above-ceiling]
  ?:  ?&  =(%grave cl)
          !principal-approved
      ==
    [%.n %grave-never-auto]
  [%.y %admitted]
++  gate-op
  |=  [ceiling=class:hand =op:hand]
  ^-  [ok=? why=@tas]
  (gate-op-with ceiling op %.n)
++  order-ok-with
  |=  [ceiling=class:hand =order:hand principal-approved=?]
  ^-  ?
  (levy ops.order |=(o=op:hand ok:(gate-op-with ceiling o principal-approved)))
::  Compatibility gate for every unapproved route. Destructive operations never
::  pass it; callers must deliberately use order-ok-with after principal approval.
++  order-ok
  |=  [ceiling=class:hand =order:hand]
  ^-  ?
  (order-ok-with ceiling order %.n)
--
