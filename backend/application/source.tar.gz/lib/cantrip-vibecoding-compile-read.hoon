::  Canonical compiler binding, write, intent and law joins for Cantrip.
/-  itn=intent
/+  compile=cantrip-vibecoding-compile, clw=cantrip-law-window,
    lr=vibecoding-local-result, lrr=vibecoding-local-result-read,
    protocol=vibecoding-compile-protocol, vcl=vibecoding-candidate,
    vsg=viki-scry-guard
|%
++  owned
  |=  [our=@p at=@da]
  ^-  (list *)
  =/  rows=(list [fact=* ships=(set @p)])
    .^((list [* (set @p)]) %gx /(scot %p our)/graf/(scot %da at)/attested/noun)
  %+  murn  rows
  |=  row=[fact=* ships=(set @p)]
  ?:((~(has in ships.row) our) `fact.row ~)
++  binding
  |=  [our=@p rows=(list *) key=@ux]
  ^-  (each binding:compile refusal:compile)
  =|  found=(unit binding:compile)
  |-  ^-  (each binding:compile refusal:compile)
  ?~  rows  ?~(found [%| %binding-missing] [%& u.found])
  =/  row  ((soft ,[%vibecoding-compiler-binding key=@t item=binding:compile]) i.rows)
  ?~  row  $(rows t.rows)
  ?.  =(key (digest:vcl item.u.row))  $(rows t.rows)
  ?.  &(=(key.u.row (scot %ux key)) =(our owner.item.u.row) (binding-valid:compile item.u.row))
    [%| %compiler-binding-invalid]
  ?^  found  [%| %binding-conflict]
  $(rows t.rows, found `item.u.row)
++  request
  |=  [rows=(list *) key=@ux]
  ^-  (unit snapshot:compile)
  =|  found=(unit snapshot:compile)
  |-  ^-  (unit snapshot:compile)
  ?~  rows  found
  =/  row  ((soft ,[%vibecoding-compile-request key=@t item=snapshot:compile]) i.rows)
  ?~  row  $(rows t.rows)
  ?.  =(key (digest:protocol order.item.u.row))  $(rows t.rows)
  ?.  &(=(key.u.row (scot %ux key)) (valid:compile item.u.row))  ~
  ?^  found  ~
  $(rows t.rows, found `item.u.row)
++  view
  |=  [our=@p at=@da write=@ux]
  ^-  (each view:lr refusal:compile)
  =/  result  (read:lrr our our at write)
  ?:  ?=(%| -.result)  [%| %result-unavailable]
  =/  context  (context-of:vcl packet.candidate.p.result)
  =/  path=path
    ~[(scot %p our) %viki (scot %da at) %intent id.intent.intent.context %noun]
  =/  intent=(unit record:itn)  .^((unit record:itn) %gx path)
  ?.  =(`intent.context intent)  [%| %intent-changed]
  [%& p.result]
++  read
  |=  [our=@p actor=@p at=@da write=@ux binding-key=@ux window=window:clw]
  ^-  (each snapshot:compile refusal:compile)
  ?.  =(our actor)  [%| %foreign-actor]
  ?.  &((agent-live:vsg our at %graf) (agent-live:vsg our at %viki))
    [%| %agent-unavailable]
  =/  selected  (binding our (owned our at) binding-key)
  ?:  ?=(%| -.selected)  [%| p.selected]
  =/  current  (view our at write)
  ?:  ?=(%| -.current)  [%| p.current]
  (freeze:compile our actor at p.selected p.current window)
++  admit
  |=  [our=@p actor=@p at=@da key=@ux window=window:clw]
  ^-  decision:compile
  ?.  =(our actor)  [%| %foreign-actor]
  ?.  &((agent-live:vsg our at %graf) (agent-live:vsg our at %viki))
    [%| %agent-unavailable]
  =/  rows  (owned our at)
  =/  held  (request rows key)
  ?~  held  [%| %request-invalid]
  =/  s=snapshot:compile  u.held
  =/  selected  (binding our rows (digest:vcl binding.s))
  ?:  ?=(%| -.selected)  [%| p.selected]
  ?.  =(p.selected binding.s)  [%| %compiler-binding-invalid]
  =/  current  (view our at write.order.s)
  ?:  ?=(%| -.current)  [%| p.current]
  (admit:compile our actor at s p.current window)
++  fact
  |=  s=snapshot:compile
  [%vibecoding-compile-request (scot %ux (digest:protocol order.s)) s]
++  compilation
  |=  [rows=(list *) key=@ux]
  ^-  (unit record:compile)
  =|  found=(unit record:compile)
  |-  ^-  (unit record:compile)
  ?~  rows  found
  =/  row  ((soft ,[%vibecoding-compilation key=@t item=record:compile]) i.rows)
  ?~  row  $(rows t.rows)
  ?.  =(key (digest:vcl item.u.row))  $(rows t.rows)
  ?.  &(=(key.u.row (scot %ux key)) (record-valid:compile item.u.row))  ~
  ?^  found  ~
  $(rows t.rows, found `item.u.row)
--
