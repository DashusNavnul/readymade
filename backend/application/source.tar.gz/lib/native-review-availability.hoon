::  Owner-only presentation of native subscription transport evidence.
::  Pairing and retained jobs never establish current login, quota or liveness.
/-  np=native-coding-provider, cli=cli-inference
/+  provider=native-coding-provider, catalog=native-review-provider-catalog
|%
+$  pairing  ?(%unobserved %missing %mismatch %active %revoked)
+$  job-phase
  ?(%none %unobserved %missing %mismatch %queued %claimed %completed %failed %cancelled %unknown)
+$  view
  $:  observed=@da  transport=?(%subscription %unsupported)
      pairing=pairing  job=job-phase
  ==
++  project
  ::  observed is the scry event's time, not a job start or adapter heartbeat.
  ::  Only the selected campaign's pending request may be supplied as expected.
  |=  $:  at=@da  key=@tas  chosen=selection:np  live=?
          paired=(unit binding:catalog)
          expected=(unit [id=@ux session=@ux])  found=(unit job:cli)
      ==
  ^-  view
  =/  out=view  [at %subscription %unobserved ?~(expected %none %unobserved)]
  =/  backend  (cli-backend:provider chosen)
  ?~  backend  out(transport %unsupported)
  ?.  live  out
  ?~  paired  out(pairing %missing)
  =/  public-selection  (selection:catalog key u.paired(active %.y))
  ?.  &(=(key key.u.paired) =(backend.u.paired u.backend) =(public-selection `chosen))
    out(pairing %mismatch)
  =.  out  out(pairing ?:(active.u.paired %active %revoked))
  ?~  expected  out
  ?~  found  out(job %missing)
  =/  j=job:cli  u.found
  ?.  ?&  =(id.u.expected id.request.j)  =(session.u.expected session.request.j)
          =(chosen selection.request.j)  =(key key.j)
          =(u.backend backend.j)  =(connector.u.paired connector.j)
      ==
    out(job %mismatch)
  out(job phase.j)
++  json
  |=  v=view
  ^-  ^json
  (pairs:enjs:format ~[['schema' s+'native-review-availability-v1'] ['observedAt' s+(scot %da observed.v)] ['transport' s+transport.v] ['pairing' s+pairing.v] ['job' s+job.v] ['liveness' s+'unobserved'] ['authentication' s+'unobserved'] ['quota' s+'unobserved']])
--
