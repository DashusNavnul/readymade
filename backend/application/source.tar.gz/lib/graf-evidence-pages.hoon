::  /lib/graf-evidence-pages.hoon
::
::  Shared law for complete reads over Graf's bounded by-kind endpoint.
::  The caller supplies the execution context: Gall reads synchronously;
::  Spider wraps the same pages in a strand.  Shape and continuity law stay
::  here so neither context can quietly accept a partial authority history.
::
/+  gew=graf-evidence-window
|%
++  max-page-items  max-page-items:gew
++  kind-page  kind-page:gew
++  page-path
  |=  [our=@p now=@da kind=@tas offset=@ud]
  ^-  path
  :~  (scot %p our)
      %graf
      (scot %da now)
      %by-kind-page
      (scot %tas kind)
      (scot %ud offset)
      (scot %ud max-page-items)
      %noun
  ==
++  page-valid
  |=  [p=kind-page expected-kind=@tas expected-offset=@ud]
  ^-  ?
  ?&  =(kind.p expected-kind)
      =(offset.p expected-offset)
      =(limit.p max-page-items)
      =(returned.p (lent items.p))
      (lte returned.p max-page-items)
      =(next-offset.p (add offset.p returned.p))
      ?:(more.p =(returned.p max-page-items) %.y)
  ==
::  Pure counterpart used by proofs: a missing continuation is failure, not
::  a shorter successful history.
++  collect-pages
  |=  [kind=@tas pages=(list kind-page)]
  ^-  (unit (list *))
  =/  offset=@ud  0
  =/  rev=(list *)  ~
  |-
  ?~  pages  ~
  =/  p=kind-page  i.pages
  ?.  (page-valid p kind offset)  ~
  =/  next-rev=(list *)  (weld (flop items.p) rev)
  ?:  more.p
    ?~  t.pages  ~
    $(pages t.pages, offset next-offset.p, rev next-rev)
  ?.  =(~ t.pages)  ~
  `(flop next-rev)
--
