::  /lib/fedwiki-store.hoon
::
::  The delay's cards, kept as graf facts.  A ship's wiki site is its set
::  of %fedwiki-page facts: each is one whole version of one page, as
::  fedwiki keeps one file per page, but append-only -- a change lights a
::  new version and nothing is overwritten (graf is immutable).
::
::  The current page of a slug is its newest version: highest rev, then
::  latest `at`, then mug order.  The answer never depends on the order
::  graf lists the facts in (by-kind answers in set order).
::
::  +write is the wiki-server's request routing (lib/server.js 848-962)
::  over the current pages: a create refuses a page that exists; an
::  explicit fork, or an implicit one (an action carrying `fork`), applies
::  to the page being forked (`forkPage`) and so replaces the page here;
::  any other action applies to the page here, or 'Page not found'.
::  One difference: the server makes a created page out of the create's
::  whole item, so extra item fields become top-level page fields; here
::  they stay on the create action, since a page keeps no other fields.
::
/-  fw=fedwiki
/+  fedwiki, fj=fedwiki-json
|%
+$  version  [%fedwiki-page %1 slug=@t rev=@ud =page:fw who=@p at=@da]
::  +pages: the current version of every slug among `facts`; facts that
::  are not well-formed versions are ignored
::
++  pages
  |=  facts=(list *)
  ^-  (map @t version)
  %+  roll  (murn facts (soft version))
  |=  [v=version acc=(map @t version)]
  =/  old  (~(get by acc) slug.v)
  ?:  &(?=(^ old) (outranks u.old v))  acc
  (~(put by acc) slug.v v)
::  +outranks: is version a newer than version b
::
++  outranks
  |=  [a=version b=version]
  ^-  ?
  ?.  =(rev.a rev.b)  (gth rev.a rev.b)
  ?.  =(at.a at.b)  (gth at.a at.b)
  ?:  =(a b)  %.y
  (gor b a)
::  +write: the version a request makes, or the server's refusal
::
++  write
  |=  $:  facts=(list *)
          slug=@t
          req=[=action:fw fork=(unit @t) fork-page=(unit page:fw)]
          who=@p
          now=@da
      ==
  ^-  (each version @t)
  =/  cur=(unit version)  (~(get by (pages facts)) slug)
  =*  act  action.req
  =/  res=(each page:fw @t)
    ?:  ?=(^ fork.req)
      ?~  fork-page.req  |+'an implicit fork needs its forkPage'
      (put:fedwiki u.fork-page.req act fork.req)
    ?:  ?=(%create -.act)
      ?^  cur  |+'Page already exists.'
      &+(start:fedwiki date.act title.act story.act more.act)
    ?:  ?=(%fork -.act)
      ?~  fork-page.req  |+'a fork needs its forkPage'
      (put:fedwiki u.fork-page.req act ~)
    ?~  cur  |+'Page not found'
    (put:fedwiki page.u.cur act ~)
  ?:  ?=(%| -.res)  |+p.res
  &+[%fedwiki-page %1 slug ?~(cur 1 +(rev.u.cur)) p.res who now]
::  +request: a client's PUT body (JSON text) for one slug, end to end
::
++  request
  |=  [facts=(list *) slug=@t body=@t who=@p now=@da]
  ^-  (each version @t)
  =/  jon  (de:json:html body)
  ?~  jon  |+'the request is not JSON'
  =/  req  (de-request:fj u.jon)
  ?:  ?=(%| -.req)  |+'the request is not a fedwiki action'
  (write facts slug p.req who now)
::
::  HOSTED SITES.  A host keeps a card store for each ship it speaks for --
::  flunky for the guest moons in its %bach (operator ruling 09-28: "flunky
::  speaks for them to dashus"; 10-01: flunky keeps their stores).  A hosted
::  version is a version that names its site; every rule above applies to
::  one site's versions alone, so two sites never see each other's cards.
::
+$  hosted  [%fedwiki-site-page %1 site=@p slug=@t rev=@ud =page:fw who=@p at=@da]
::  +site-facts: one hosted site's versions, as plain versions
::
++  site-facts
  |=  [facts=(list *) site=@p]
  ^-  (list version)
  %+  murn  facts
  |=  f=*
  ^-  (unit version)
  =/  h  ((soft hosted) f)
  ?~  h  ~
  ?.  =(site site.u.h)  ~
  `[%fedwiki-page %1 slug.u.h rev.u.h page.u.h who.u.h at.u.h]
::
++  site-pages
  |=  [facts=(list *) site=@p]
  ^-  (map @t version)
  (pages (site-facts facts site))
::  +host-write: +write for one hosted site
::
++  host-write
  |=  $:  facts=(list *)
          site=@p
          slug=@t
          req=[=action:fw fork=(unit @t) fork-page=(unit page:fw)]
          who=@p
          now=@da
      ==
  ^-  (each hosted @t)
  =/  res  (write (site-facts facts site) slug req who now)
  ?:  ?=(%| -.res)  |+p.res
  &+[%fedwiki-site-page %1 site slug.p.res rev.p.res page.p.res who.p.res at.p.res]
::  +host-request: a client's PUT body for one hosted site's slug
::
++  host-request
  |=  [facts=(list *) site=@p slug=@t body=@t who=@p now=@da]
  ^-  (each hosted @t)
  =/  jon  (de:json:html body)
  ?~  jon  |+'the request is not JSON'
  =/  req  (de-request:fj u.jon)
  ?:  ?=(%| -.req)  |+'the request is not a fedwiki action'
  (host-write facts site slug p.req who now)
--
