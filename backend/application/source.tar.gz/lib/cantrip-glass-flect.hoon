::  /lib/cantrip-glass-flect.hoon
::
::  The glass-generation judge as law geometry (phase 11, the glass lane).
::  The lane's act is [nonce evidence]: the owner's goal and plan, the
::  candidate context and its approval, the moon route and seat table, the
::  window, the seat write, the workspace claim, the desks, the lease and
::  its mirror.  The type-law says only that the act has the right shape;
::  this law adds one %run gate per predicate of
::  +admit:cantrip-glass-generation, at the axis of the field it reads, in
::  the judge's order, with the environment [our actor now].  The first
::  miss names the judge's own refusal.  Nothing here scries.
::
/-  gs=graf, mg=moon-grant
/+  flect, flect-law, generation=cantrip-glass-generation,
    planner=plan, route=viki-route, dispatch=cantrip-vibecoding-dispatch,
    candidate=vibecoding-candidate, checks=vibecoding-check-spec
|%
+$  act  [nonce=@ux e=evidence:generation]
+$  env  [our=@p actor=@p now=@da]
++  act-type  ^-  type  -:!>(*act)
::  Axes: nonce = 2; evidence = 3 and its fields goal 6, plan 14, context
::  30, approval 62, route 126, sessions 254, window 510, seat-write 1022,
::  claim 2046, desks 4094, grant 8190, mirror 8191.
++  owner-gate
  ^-  *
  |=  [a=* n=*]
  =/  v  ;;(env n)
  =(our.v actor.v)
++  nonce-gate
  ^-  *
  |=  [a=* n=*]
  =/  x  ;;(act a)
  &(!=(0 nonce.x) (lte (met 0 nonce.x) 128))
++  goal-plan-gate
  ^-  *
  |=  [a=* n=*]
  =/  x  ;;(act a)
  =/  v  ;;(env n)
  ?&  !=('' gid.goal.e.x)  =(%operator origin.goal.e.x)
      (lte at.goal.e.x now.v)
      =(plan.e.x (make:planner goal.e.x refs.plan.e.x))
  ==
++  context-gate
  ^-  *
  |=  [a=* n=*]
  =/  x  ;;(act a)
  =/  v  ;;(env n)
  ?&  (current-context-valid:candidate context.e.x)
      =(our.v by.intent.intent.context.e.x)
      =(text.goal.e.x said.intent.intent.context.e.x)
      (lte at.context.e.x now.v)
      =(law.context.e.x (digest:generation window.e.x))
  ==
++  approval-gate
  ^-  *
  |=  [a=* n=*]
  =/  x  ;;(act a)
  =/  v  ;;(env n)
  ?&  (approval-valid:checks approval.e.x)
      =(our.v owner.approval.e.x)
      =(context.approval.e.x (digest:generation context.e.x))
      (lte at.context.e.x at.approval.e.x)
      (lte at.approval.e.x now.v)
  ==
++  inspect-gate
  ^-  *
  |=  [a=* n=*]
  =/  x  ;;(act a)
  (inspect-allowed:generation window.e.x)
++  route-gate
  ^-  *
  |=  [a=* n=*]
  =/  x  ;;(act a)
  =/  v  ;;(env n)
  (allowed:route our.v now.v sessions.e.x route.e.x)
++  workspace-gate
  ^-  *
  |=  [a=* n=*]
  =/  x  ;;(act a)
  =/  s  seat-session.route.e.x
  ?&  =(workspace.s desk.work.context.e.x)
      =(workspace.s fork.claim.e.x)  =(moon.s holder.claim.e.x)
      (~(has in desks.e.x) workspace.s)
      =(seat.s seat-id.seat-write.e.x)
      =((scot %p moon.s) assigned-ship-id.seat-write.e.x)
      =(`@t`workspace.s session-id.seat-write.e.x)
      =(%claim write-kind.seat-write.e.x)
  ==
++  lease-gate
  ^-  *
  |=  [a=* n=*]
  =/  x  ;;(act a)
  =/  v  ;;(env n)
  =/  s  seat-session.route.e.x
  =/  reasons
    (grant-rejections:dispatch grant.e.x moon.s our.v seat.s seat-write.e.x mirror.e.x 'read-file' %safe now.v)
  ?=(~ reasons)
++  gates
  ^-  law:flect-law
  :~  [1 %run owner-gate]
      [2 %run nonce-gate]
      [14 %run goal-plan-gate]
      [30 %run context-gate]
      [62 %run approval-gate]
      [510 %run inspect-gate]
      [126 %run route-gate]
      [1.022 %run workspace-gate]
      [8.190 %run lease-gate]
  ==
++  glass-law
  ^-  law:flect-law
  (weld (law-of:flect-law act-type) gates)
++  glass-receipt
  |=  [a=act e=env]
  ^-  receipt:flect-law
  (judge-with:flect-law glass-law !>(`act`a) e)
::  +reason: the first miss, as the judge would have said it
++  reason
  |=  r=receipt:flect-law
  ^-  (unit @tas)
  ?~  misses.verdict.r  ~
  =/  d  demand.i.misses.verdict.r
  ?.  ?=(%run -.d)  `%act-ill-shaped
  ?:  =(gate.d owner-gate)  `%foreign-owner
  ?:  =(gate.d nonce-gate)  `%nonce-invalid
  ?:  =(gate.d goal-plan-gate)  `%goal-plan-invalid
  ?:  =(gate.d context-gate)  `%context-invalid
  ?:  =(gate.d approval-gate)  `%approval-invalid
  ?:  =(gate.d inspect-gate)  `%inspect-not-admitted
  ?:  =(gate.d route-gate)  `%route-not-current
  ?:  =(gate.d workspace-gate)  `%workspace-or-seat-write-mismatch
  ?:  =(gate.d lease-gate)  `%lease-not-admitted
  `%unknown-gate
--
