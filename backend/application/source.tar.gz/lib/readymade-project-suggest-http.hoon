::  Browser supplies edits and a selector, never a forged source observation.
/+  view-web=readymade-project-view-http, view=readymade-project-view-client,
    client=readymade-project-suggest-client, mg=readymade-app-management,
    model=pataphor-editor-model
|%
+$  command  [view=selector:view request=@ux pax=path source=@t]
+$  recovery-command  [command=command grant=@ux root=@ux snapshot-digest=@ux]
++  fields
  ::  Count separators outside JSON strings, including escaped quotes. All
  ::  eight admitted values are strings; duplicate/escaped-alias keys fail.
  |=  raw=@t
  ^-  @ud
  =/  chars=(list @t)  (trip raw)
  =/  quoted=?  %.n
  =/  escaped=?  %.n
  =/  count=@ud  0
  |-  ^-  @ud
  ?~  chars  count
  =/  c=@t  i.chars
  ?:  escaped  $(chars t.chars, escaped %.n)
  ?:  &(quoted =(c 92))  $(chars t.chars, escaped %.y)
  ?:  =(c 34)  $(chars t.chars, quoted !quoted)
  $(chars t.chars, count ?:(&(!quoted =(c ':')) +(count) count))
++  decode
  |=  raw=@t
  ^-  command
  ?>  &((lte (met 3 raw) 262.144) =(8 (fields raw)))
  =/  value=json  (need (de:json:html raw))
  ?>  ?=(%o -.value)
  =/  obj=(map @t json)  p.value
  ?>  =(8 ~(wyt by obj))
  ?>  =('readymade-project-suggest-v1' (text-field:mg obj 'schema' 64))
  =/  k=selector:view
    (select:view-web (text-field:mg obj 'owner' 128) (text-field:mg obj 'project' 128) (text-field:mg obj 'generation' 32) (text-field:mg obj 'viewRequest' 64))
  =/  request-text=@t  (text-field:mg obj 'request' 64)
  =/  request=@ux  (need (slaw %ux request-text))
  ?>  &((gth request 0) (lte (met 0 request) 128) =(request-text (scot %ux request)))
  =/  text=@t  (text-field:mg obj 'path' 1.024)
  =/  pax=path  (need (rush text stap))
  ?>  &(=(text (spat pax)) !=(~ pax))
  =/  source=@t  (text-field:mg obj 'source' 32.768)
  ?>  (text-valid:model source)
  [k request pax source]
++  parse
  |=  raw=@t
  ^-  (unit command)
  (mole |.((decode raw)))
++  post-body
  |=  [req=inbound-request:eyre url=@t]
  ^-  (unit @t)
  ?.  ?&  authenticated.req  =('POST' method.request.req)
          =(url url.request.req)
      ==  ~
  =/  host  (header:mg header-list.request.req 'host')
  =/  origin  (header:mg header-list.request.req 'origin')
  =/  mime  (header:mg header-list.request.req 'content-type')
  ?~  host  ~
  ?~  origin  ~
  ?~  mime  ~
  ?.  ?&  =(u.origin (cat 3 ?:(secure.req 'https://' 'http://') u.host))
          |(=(u.mime 'application/json') =(u.mime 'application/json; charset=utf-8'))
          =(`'v1' (header:mg header-list.request.req 'x-readymade-project-suggest'))
      ==  ~
  ?~  body.request.req  ~
  =/  body  u.body.request.req
  ?.  &((lte p.body 262.144) =(p.body (met 3 q.body)))  ~
  `q.body
++  post-request
  |=  req=inbound-request:eyre
  ^-  (unit command)
  =/  raw  (post-body req '/apps/readymade-collab/project-suggest')
  ?~  raw  ~
  (parse u.raw)
++  hash-field
  |=  [obj=(map @t json) key=@t]
  ^-  @ux
  =/  text=@t  (text-field:mg obj key 82)
  =/  value=@ux  (need (slaw %ux text))
  ?>  &((gth value 0) (lte (met 0 value) 256) =(text (scot %ux value)))
  value
++  decode-recovery
  |=  raw=@t
  ^-  recovery-command
  ?>  &((lte (met 3 raw) 262.144) =(11 (fields raw)))
  =/  value=json  (need (de:json:html raw))
  ?>  ?=(%o -.value)
  =/  obj=(map @t json)  p.value
  ?>  =(11 ~(wyt by obj))
  ?>  =('readymade-project-suggest-recover-v1' (text-field:mg obj 'schema' 64))
  =/  grant=@ux  (hash-field obj 'grant')
  =/  root=@ux  (hash-field obj 'root')
  =/  digest=@ux  (hash-field obj 'snapshotDigest')
  =/  base=(map @t json)
    (~(del by (~(del by (~(del by obj) 'grant')) 'root')) 'snapshotDigest')
  =.  base  (~(put by base) 'schema' s+'readymade-project-suggest-v1')
  [(decode (en:json:html [%o base])) grant root digest]
++  parse-recovery
  |=  raw=@t
  ^-  (unit recovery-command)
  (mole |.((decode-recovery raw)))
++  recover-request
  |=  req=inbound-request:eyre
  ^-  (unit recovery-command)
  =/  raw  (post-body req '/apps/readymade-collab/project-suggest-recover')
  ?~  raw  ~
  (parse-recovery u.raw)
++  recovery-result-request
  |=  req=inbound-request:eyre
  ^-  (unit selector:view)
  ?.  =('/apps/readymade-collab/project-suggest-recovery-result' url.request.req)  ~
  (result-request req(url.request '/apps/readymade-collab/project-suggest-result'))
++  result-request
  |=  req=inbound-request:eyre
  ^-  (unit selector:view)
  ?.  ?&  authenticated.req  =('GET' method.request.req)
          =('/apps/readymade-collab/project-suggest-result' url.request.req)
      ==  ~
  =/  owner  (header:mg header-list.request.req 'x-readymade-project-owner')
  =/  project  (header:mg header-list.request.req 'x-readymade-project')
  =/  gen  (header:mg header-list.request.req 'x-readymade-project-generation')
  =/  request  (header:mg header-list.request.req 'x-readymade-project-suggest-request')
  ?~  owner  ~
  ?~  project  ~
  ?~  gen  ~
  ?~  request  ~
  (mole |.((select:view-web u.owner u.project u.gen u.request)))
++  response
  |=  [our=@p e=entry:client]
  ^-  json
  =/  value=json
    %-  pairs:enjs:format
    :~  ['schema' s+?:(recovery.e 'readymade-project-suggest-recovery-result-v1' 'readymade-project-suggest-result-v1')]
        ['owner' s+(scot %p owner.key.e)]  ['peer' s+(scot %p our)]
        ['project' s+project.query.key.e]
        ['generation' s+(scot %ud generation.query.key.e)]
        ['request' s+(scot %ux nonce.query.key.e)]
        ['viewRequest' s+(scot %ux view-request.e)]
        ['grant' s+(scot %ux grant.e)]  ['root' s+(scot %ux root.e)]
        ['snapshotDigest' s+(scot %ux snapshot-digest.e)]
        ['status' s+phase.e]  ['reason' s+reason.e]
        ['path' s+(spat pax.request.e)]
        ['sourceHash' s+(scot %ux (shax source.request.e))]
        ['deadline' s+(scot %da deadline.e)]  ['retainedUntil' s+(scot %da retained.e)]
        ['permissionGranted' b+%.n]  ['committed' b+%.n]
        ['receiptHash' ?~(receipt.e ~ s+(scot %ux (shax (jam u.receipt.e))))]
    ==
  ?>  (lte (met 3 (en:json:html value)) 8.192)
  value
++  recovery-response
  |=  [our=@p e=entry:client]
  ^-  json
  ?>  recovery.e
  =/  value=json  (response our e)
  ?>  ?=(%o -.value)
  =/  body=json  [%o (~(put by p.value) 'recovery' b+%.y)]
  ?>  (lte (met 3 (en:json:html body)) 8.192)
  body
--
