::  Read-only projection of native admitted history. No observation admission,
::  recomputation, state mutation or conversion of missing evidence to zero.
/+  history=qpc-instrument-history, window=qpc-window, ct=qpc-ct-update,
    gate=qpc-session-gate, decision=qpc-decision
|%
++  decimal
  |=  n=@ud
  ^-  @t
  (crip (skim (trip (scot %ud n)) |=(c=@t !=(c '.'))))
++  signed
  |=  n=@s
  ^-  json
  [%s (cat 3 ?:((syn:si n) '' '-') (decimal (abs:si n)))]
++  ratio
  |=  r=ratio:ct
  ^-  json
  (pairs:enjs:format ~[['numerator' [%s (decimal num.r)]] ['denominator' [%s (decimal den.r)]]])
++  matrix
  |=  m=matrix:ct
  ^-  json
  [%a (turn m |=(row=(list @s) [%a (turn row signed)]))]
++  covariance
  |=  c=covariance:window
  ^-  json
  (pairs:enjs:format ~[['denominator' [%s (decimal denominator.c)]] ['entries' (matrix entries.c)]])
++  outcome
  |=  o=outcome:decision
  ^-  json
  (pairs:enjs:format ~[['verdict' [%s (scot %tas verdict.o)]] ['evidence' ?:(=(%unknown verdict.o) [%~] [%s (scot %ux evidence.o)])]])
++  point
  |=  p=point:window
  ^-  json
  %-  pairs:enjs:format
  :~  ['observation' [%s (scot %ux id.row.p)]]
      ['step' [%s (decimal step.row.p)]]
      ['work' [%s (scot %ux work.row.p)]]
      ['predictionSource' [%s (scot %ux prediction.p)]]
      ['resultingSource' [%s (scot %ux resulting-source.row.p)]]
      ['settlement' [%s (scot %ux settlement.p)]]
      ['task' [%s (scot %ux task.p)]]
      ['checks' [%s (scot %ux checks.p)]]
      ['segment' [%s (scot %ux segment.row.p)]]
      ['law' [%s (scot %ux law.row.p)]]
      ['confidence' [%a (turn confidence.row.p numb:enjs:format)]]
      ['outcomes' [%a (turn outcomes.row.p outcome)]]
  ==
++  comparison
  |=  c=comparison:window
  ^-  json
  %-  pairs:enjs:format
  :~  ['referenceKnown' (numb:enjs:format reference-known.c)]
      ['referencePass' (numb:enjs:format reference-pass.c)]
      ['liveKnown' (numb:enjs:format live-known.c)]
      ['livePass' (numb:enjs:format live-pass.c)]
      ['referenceVaries' [%b reference-varies.c]]
      ['liveVaries' [%b live-varies.c]]
      ['confidenceVaries' [%b confidence-varies.c]]
      ['modelBrier' ?~(model.c [%~] (ratio u.model.c))]
      ['baselineBrier' ?~(constant.c [%~] (ratio u.constant.c))]
      ['judgment' [%s (scot %tas judgment.c)]]
  ==
++  reading
  |=  r=reading:window
  ^-  json
  %-  pairs:enjs:format
  :~  ['id' [%s (scot %ux id.r)]]
      ['epoch' [%s (scot %ux epoch.r)]]
      ['tensor' (covariance [denominator.tensor.r entries.tensor.r])]
      ['attentionSquared' (ratio attention.tensor.r)]
      ['shape' ?~(shape.r [%~] (pairs:enjs:format ~[['denominator' [%s (decimal denominator.u.shape.r)]] ['state' (matrix state.u.shape.r)] ['update' (matrix update.u.shape.r)]]))]
      ['referenceMixedLaw' [%b reference-mixed-law.r]]
      ['liveMixedLaw' [%b live-mixed-law.r]]
      ['comparison' [%a (turn comparison.r comparison)]]
      ['live' [%a (turn live.r point)]]
  ==
++  event
  |=  e=event:window
  ^-  json
  =/  details=json
    ?:  ?=(%row -.body.e)  (point value.body.e)
    ?:  ?=(%gap -.body.e)
      (pairs:enjs:format ~[['evidence' [%s (scot %ux evidence.body.e)]] ['reason' [%s (scot %tas reason.body.e)]]])
    (pairs:enjs:format ~[['evidence' [%s (scot %ux evidence.body.e)]]])
  (pairs:enjs:format ~[['order' (numb:enjs:format order.e)] ['kind' [%s (scot %tas -.body.e)]] ['value' details]])
++  stream
  |=  [s=state:window pending=@ud]
  ^-  json
  =/  events=(list event:window)
    (sort ~(val by events.s) |=([a=event:window b=event:window] (lth order.a order.b)))
  =/  rc=@ud  ?~(reference.s (lent buffer.s) (lent reference.u.reference.s))
  =/  lc=@ud  ?~(measured.s ?~(reference.s 0 (lent buffer.s)) (lent live.u.measured.s))
  %-  pairs:enjs:format
  :~  ['instrument' [%s (scot %ux instrument.binding.s)]]
      ['stream' [%s (scot %ux stream.binding.s)]]
      ['manifest' [%s (scot %ux manifest.binding.s)]]
      ['status' [%s ?~(measured.s 'collecting' 'ready')]]
      ['referenceCount' (numb:enjs:format rc)]
      ['liveCount' (numb:enjs:format lc)]
      ['unconsumed' (numb:enjs:format pending)]
      ['gaps' (numb:enjs:format (lent (skim events |=(e=event:window ?=(%gap -.body.e)))))]
      ['outside' (numb:enjs:format (lent (skim events |=(e=event:window ?=(%outside -.body.e)))))]
      ['reference' ?~(reference.s [%~] (pairs:enjs:format ~[['id' [%s (scot %ux id.u.reference.s)]] ['covariance' (covariance covariance.u.reference.s)] ['members' [%a (turn reference.u.reference.s point)]]]))]
      ['reading' ?~(measured.s [%~] (reading u.measured.s))]
      ['buffer' [%a (turn buffer.s point)]]
      ['events' [%a (turn events event)]]
  ==
++  read
  |=  [inner=agent:gall b=bowl:gall]
  ^-  (unit state:history)
  ?.  =(our.b src.b)  ~
  =/  ag  ~(. inner b)
  =/  raw  (payload:gate (on-peek:ag /x/qpc/instrument/measurements))
  ?~  raw  ~
  =/  parsed  ((soft ,[%qpc-instrument-measurements-v1 held=state:history]) u.raw)
  ?~  parsed  ~
  `held.u.parsed
++  status
  |=  s=(unit state:history)
  ^-  @t
  ?~  s  'unavailable'
  ?^  fault.u.s  'fault'
  ?:  =(0 ~(wyt by windows.u.s))  'unavailable'
  ?:  (lien ~(val by windows.u.s) |=(w=state:window ?=(^ measured.w)))  'available'
  'collecting'
++  render
  ::  Exact integer strings avoid JavaScript's finite integer precision.
  ::  The native owner validates persisted history; this projection is inert.
  |=  s=(unit state:history)
  ^-  json
  =/  streams=(list json)
    ?~  s  ~
    =/  tail=(list item:history)  (slag cursor.u.s queue.u.s)
    %+  turn  ~(val by windows.u.s)
    |=  w=state:window
    (stream w (lent (skim tail |=(x=item:history =(stream.x stream.binding.w)))))
  %-  pairs:enjs:format
  :~  ['schema' [%s 'qpc-measurement-view-v1']]
      ['status' [%s (status s)]]
      ['width' (numb:enjs:format 16)]
      ['requiredPerBlock' (numb:enjs:format 17)]
      ['coordinates' [%a ~[[%s 'compatibility'] [%s 'intended-behavior']]]]
      ['confidenceScale' (numb:enjs:format 1.000.000)]
      ['policy' [%s 'first-17-reference-next-disjoint-17-live']]
      ['arithmetic' [%s 'qpc-ct-update-v1']]
      ['queueTotal' ?~(s [%~] (numb:enjs:format (lent queue.u.s)))]
      ['queueConsumed' ?~(s [%~] (numb:enjs:format cursor.u.s))]
      ['unconsumed' ?~(s [%~] (numb:enjs:format (sub (lent queue.u.s) cursor.u.s)))]
      ['fault' ?~(s [%~] ?~(fault.u.s [%~] [%s (scot %tas u.fault.u.s)]))]
      ['streams' [%a streams]]
  ==
--
