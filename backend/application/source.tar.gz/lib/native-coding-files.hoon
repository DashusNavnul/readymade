::  Bounded native text tools. No cards, writes, grants or model dispatch.
::  Caller passes registered config and authenticated actor. An undo parent
::  must come from the owning app's retained candidate ledger, never tool JSON.
/-  nc=native-coding
/+  project=native-coding-project, changes=multiplayer-changeset, dsr=desk-shell-read
|%
++  text-valid
  ::  Whole source has its own ceiling; read pages and tool inputs stay bounded.
  |=  [p=project:nc text=@t]
  ^-  ?
  ?.  (lte (met 3 text) (min max-file-bytes.policy.p file-byte-limit:project))  %.n
  (utf8 text)
++  utf8
  ::  One pass over the bytes: strict UTF-8 (RFC 3629) with no NUL byte.
  ::  Replaces the taft/tuft round trip, which grew faster than the text and
  ::  killed the reading thread on a 769 KB file (measured 2026-10-16).
  |=  text=@t
  ^-  ?
  =/  bytes=(list @)  (rip 3 text)
  |-  ^-  ?
  ?~  bytes  %.y
  =/  b=@  i.bytes
  ?:  =(0 b)  %.n
  ?:  (lth b 0x80)  $(bytes t.bytes)
  =/  want=[k=@ud lo=@ hi=@]
    ?:  &((gte b 0xc2) (lte b 0xdf))  [1 0x80 0xbf]
    ?:  =(b 0xe0)  [2 0xa0 0xbf]
    ?:  =(b 0xed)  [2 0x80 0x9f]
    ?:  &((gte b 0xe1) (lte b 0xef))  [2 0x80 0xbf]
    ?:  =(b 0xf0)  [3 0x90 0xbf]
    ?:  =(b 0xf4)  [3 0x80 0x8f]
    ?:  &((gte b 0xf1) (lte b 0xf3))  [3 0x80 0xbf]
    [0 0 0]
  ?:  =(0 k.want)  %.n
  =/  rest  (continued t.bytes want)
  ?~  rest  %.n
  $(bytes u.rest)
++  continued
  ::  The bytes after k continuation bytes, the first within lo..hi.
  |=  [rest=(list @) k=@ud lo=@ hi=@]
  ^-  (unit (list @))
  ?~  rest  ~
  ?.  &((gte i.rest lo) (lte i.rest hi))  ~
  ?:  =(1 k)  `t.rest
  $(rest t.rest, k (dec k), lo 0x80, hi 0xbf)
++  content-valid
  |=  [p=project:nc pax=path c=replacement:nc]
  ^-  ?
  ?.  &(?=(^ pax) (path-valid:project pax))  %.n
  &((text-valid p source.c) =(mark.c (rear pax)) =(`mark.c (~(get by file-types.p) mark.c)))
++  lines
  ::  Exact line pieces include their original LF; no newline normalization.
  |=  text=@t
  ^-  (list @t)
  =/  bytes=tape  (trip text)
  =/  line=tape  ~
  =/  out=(list @t)  ~
  |-  ^-  (list @t)
  ?~  bytes  (flop ?:(=(~ line) out [(rap 3 (flop line)) out]))
  =/  next=tape  [i.bytes line]
  ?:  =(10 i.bytes)  $(bytes t.bytes, line ~, out [(rap 3 (flop next)) out])
  $(bytes t.bytes, line next)
++  join
  |=  parts=(list @t)
  ^-  @t
  (rap 3 parts)
++  file
  |=  [p=project:nc t=tree:nc pax=path]
  ^-  (each replacement:nc @tas)
  ?.  &((tree-valid:project p t) (readable:project p pax) ?=(^ pax))
    [%| %path-refused]
  =/  expected  (~(get by files.body.snapshot.t) pax)
  ?~  expected  [%| %file-missing]
  =/  mark=@tas  (rear pax)
  ?.  =(`mark (~(get by file-types.p) mark))  [%| %file-type-unregistered]
  =/  r=revision:nc  revision.t
  =/  raw=*  .^(* %cx (beam-at:dsr owner.r desk.r (scot %ud number.r) pax))
  =/  text=(unit @t)  ((soft @t) raw)
  ?~  text  [%| %structured-file-unsupported]
  ?.  (text-valid p u.text)  [%| %text-or-size-refused]
  ?.  =(u.expected `@ux`(page-to-lobe:clay [mark u.text]))  [%| %source-lobe-mismatch]
  [%& [mark u.text]]
++  paths
  |=  [p=project:nc t=tree:nc directory=path]
  ^-  (list path)
  =/  selected=(list path)
    %+  skim  ~(tap in ~(key by files.body.snapshot.t))
    |=  pax=path
    &(?=(^ pax) (readable:project p pax) (under:project directory pax))
  %+  sort  selected
  |=  [a=path b=path]
  ^-  ?
  =/  left=tape  (trip (spat a))
  =/  right=tape  (trip (spat b))
  |-  ^-  ?
  ?~  left  ?=(^ right)
  ?~  right  %.n
  ?:  =(i.left i.right)  $(left t.left, right t.right)
  (lth i.left i.right)
++  listing
  ::  Recursive file listing. Cursor indexes the exact immutable source tree.
  |=  [p=project:nc t=tree:nc directory=path cursor=@ud limit=@ud]
  ^-  (each listing:nc @tas)
  ?.  &((path-valid:project directory) (gte limit 1) (lte limit 64))  [%| %page-invalid]
  =/  all=(list path)  (paths p t directory)
  ?.  (lte cursor (lent all))  [%| %cursor-invalid]
  =/  picked=(list path)  (scag limit (slag cursor all))
  =/  out=(list file-entry:nc)
    (turn picked |=(pax=path ^-(file-entry:nc [pax (rear pax) (~(got by files.body.snapshot.t) pax) ~])))
  =/  next=@ud  (add cursor (lent picked))
  [%& [out ?:(=(next (lent all)) ~ `next)]]
++  read
  |=  [p=project:nc t=tree:nc pax=path start=@ud count=@ud]
  ^-  (each file-read:nc @tas)
  ?.  &((gte start 1) (gte count 1) (lte count 200))  [%| %line-range-invalid]
  =/  body  (file p t pax)
  ?:  ?=(%| -.body)  [%| p.body]
  =/  all=(list @t)  (lines source.p.body)
  ?.  (lte start (add 1 (lent all)))  [%| %line-range-invalid]
  =/  picked=(list @t)  (scag count (slag (dec start) all))
  =/  text=@t  (join picked)
  ?.  (lte (met 3 text) 16.384)  [%| %read-page-too-large]
  =/  next=@ud  (add start (lent picked))
  [%& [pax (~(got by files.body.snapshot.t) pax) start (lent all) text ?:((gth next (lent all)) ~ `next)]]
++  contains
  |=  [query=@t text=@t]
  ^-  ?
  ?=(^ (find (trip query) (trip text)))
++  search
  ::  One first matching line per file, at most 32 scanned files per page.
  ::  next is a FILE cursor, including files with no match. A text file that
  ::  cannot be read within policy refuses the page instead of claiming no hit.
  |=  [p=project:nc t=tree:nc mode=?(%text %filename %path) query=@t directory=path cursor=@ud limit=@ud]
  ^-  (each search-results:nc @tas)
  ?.  &(!=(0 query) (lte (met 3 query) 256) (path-valid:project directory) (gte limit 1) (lte limit 32))
    [%| %search-page-invalid]
  =/  all=(list path)  (paths p t directory)
  ?.  (lte cursor (lent all))  [%| %cursor-invalid]
  =/  picked=(list path)  (scag limit (slag cursor all))
  =/  next=@ud  (add cursor (lent picked))
  =/  out=(list match:nc)  ~
  |-  ^-  (each search-results:nc @tas)
  ?~  picked  [%& [(flop out) ?:(=(next (lent all)) ~ `next)]]
  =/  pax=path  i.picked
  ?.  =(%text mode)
    =/  name=path  (slag 1 (flop pax))
    =/  text=@t  ?:(=(%path mode) (spat pax) (rap 3 ~[?~(name '' i.name) '.' (rear pax)]))
    =/  fold
      |=  value=@t
      ^-  @t
      (rap 3 (turn (trip value) |=(c=@t ?:(&((gte c 65) (lte c 90)) (add c 32) c))))
    =/  matched=?
      ?:  =(%filename mode)
        (contains (fold query) (fold text))
      (contains query text)
    $(picked t.picked, out ?:(matched [[pax ~ text] out] out))
  =/  body  (file p t pax)
  ?:  ?=(%| -.body)  [%| p.body]
  =/  hit=(unit match:nc)
    =/  rows=(list @t)  (lines source.p.body)
    =/  n=@ud  1
    |-  ^-  (unit match:nc)
    ?~  rows  ~
    ?:  (contains query i.rows)  `[pax `n i.rows]
    $(rows t.rows, n +(n))
  ?~  hit  $(picked t.picked)
  ?.  (lte (met 3 text.u.hit) 4.096)  [%| %matching-line-too-large]
  $(picked t.picked, out [u.hit out])
++  diff
  |=  [p=project:nc a=tree:nc w=tree:nc directory=path cursor=@ud limit=@ud]
  ^-  (each differences:nc @tas)
  ?.  &((path-valid:project directory) (gte limit 1) (lte limit 64))  [%| %page-invalid]
  =/  keys=(set path)  (~(uni in ~(key by files.body.snapshot.a)) ~(key by files.body.snapshot.w))
  =/  rows=(list difference:nc)
    %+  murn  ~(tap in keys)
    |=  pax=path
    ^-  (unit difference:nc)
    ?.  &((readable:project p pax) (under:project directory pax))  ~
    =/  before  (~(get by files.body.snapshot.a) pax)
    =/  after  (~(get by files.body.snapshot.w) pax)
    ?:(=(before after) ~ `[pax before after])
  ?.  (lte cursor (lent rows))  [%| %cursor-invalid]
  =/  picked=(list difference:nc)  (scag limit (slag cursor rows))
  =/  next=@ud  (add cursor (lent picked))
  [%& [picked ?:(=(next (lent rows)) ~ `next)]]
++  candidate-digest
  |=  c=candidate:nc
  ^-  @ux
  (shax (jam [%native-coding-candidate-v1 context.c basis.c accepted.c edits.c previous.c]))
++  candidate-valid
  |=  [p=project:nc c=candidate:nc]
  ^-  ?
  ?.  ?&  (valid:project p)  (tree-valid:project p basis.c)
          =(id.spec.p project.context.c)  =((configuration:project p) configuration.context.c)
          =(source.context.c revision.basis.c)  =(working.p desk.source.context.c)
          (revision-valid:project accepted.c)  =(authority.spec.p owner.accepted.c)
          =(base-desk.spec.p desk.accepted.c)  !=(0 session.context.c)  !=(0 request.context.c)
          (gte (lent edits.c) 1)  (lte (lent edits.c) 32)
          =((lent edits.c) ~(wyt in (silt (turn edits.c |=(e=edit:nc path.change.e)))))
          =((candidate-digest c) id.c)
      ==  %.n
  =/  bytes=@ud  0
  =/  rows=(list edit:nc)  edits.c
  |-  ^-  ?
  ?~  rows  (lte bytes max-candidate-bytes.policy.p)
  =/  e=edit:nc  i.rows
  ?.  &((writable:project p path.change.e) (change-valid:changes files.body.snapshot.basis.c change.e))  %.n
  ?:  =(%delete kind.change.e)  &(=(~ content.e) $(rows t.rows))
  ?~  content.e  %.n
  ?.  &((content-valid p path.change.e u.content.e) =(``@ux`(page-to-lobe:clay [mark.u.content.e source.u.content.e]) after.change.e))
    %.n
  $(rows t.rows, bytes (add bytes (met 3 source.u.content.e)))
++  candidate
  |=  [p=project:nc c=context:nc t=tree:nc accepted=revision:nc edits=(list edit:nc) previous=(unit @ux)]
  ^-  (each candidate:nc @tas)
  =/  out=candidate:nc  [%native-coding-candidate-v1 0x0 c t accepted edits previous]
  =.  id.out  (candidate-digest out)
  ?:((candidate-valid p out) [%& out] [%| %candidate-refused])
++  after-map
  ::  Pure full-namespace projection, never a Clay write.
  |=  c=candidate:nc
  ^-  (map path @ux)
  =/  files=(map path @ux)  files.body.snapshot.basis.c
  =/  rows=(list edit:nc)  edits.c
  |-  ^-  (map path @ux)
  ?~  rows  files
  =/  e=edit:nc  i.rows
  ?~  after.change.e  $(rows t.rows, files (~(del by files) path.change.e))
  $(rows t.rows, files (~(put by files) path.change.e u.after.change.e))
++  patch
  |=  [p=project:nc old=@t start=@ud remove=@ud expected=@t replacement=@t]
  ^-  (each @t @tas)
  =/  rows=(list @t)  (lines old)
  ?.  &((gte start 1) (lte start (add 1 (lent rows))) (lte remove (sub (lent rows) (dec start))))
    [%| %patch-range-invalid]
  =/  at=@ud  (dec start)
  ?.  =(expected (join (scag remove (slag at rows))))  [%| %patch-context-mismatch]
  =/  out=@t  (join ~[(join (scag at rows)) replacement (join (slag (add at remove) rows))])
  ?:((text-valid p out) [%& out] [%| %patch-text-refused])
++  mismatch
  ::  Why a patch context failed: line counts and the first differing line,
  ::  so a refused proposer can correct the count instead of guessing.
  |=  [old=@t start=@ud remove=@ud expected=@t]
  ^-  @t
  =/  want=(list @t)  (lines expected)
  =/  have=(list @t)  (scag remove (slag ?:(=(0 start) 0 (dec start)) (lines old)))
  =/  same=@ud
    =/  i=@ud  0
    |-  ^-  @ud
    ?~  want  i
    ?~  have  i
    ?.  =(i.want i.have)  i
    $(want t.want, have t.have, i +(i))
  %-  crip
  ;:  weld
    "expected has "  (scow %ud (lent want))  " lines; remove is "  (scow %ud remove)
    ". First difference at file line "  (scow %ud (add start same))
    ". Each line keeps its LF; remove must equal the lines in expected."
  ==
++  patches-mismatch
  ::  Which item of a multi-file proposal failed its context, and how, so a
  ::  refused proposer corrects that item instead of resubmitting blind.
  ::  Starts address the original text, so each item is judged against it.
  ::  Pure over a reader; the live caller reads blobs from Clay.
  |=  [p=project:nc items=(list patch-item:nc) read=$-(path (unit @t))]
  ^-  @t
  =/  rows=(list patch-item:nc)  items
  =/  n=@ud  1
  |-  ^-  @t
  ?~  rows
    'No item fails its context against the original files; re-read the current blobs before patching.'
  =/  i=patch-item:nc  i.rows
  =/  old=(unit @t)  (read pax.i)
  ?~  old  $(rows t.rows, n +(n))
  =/  tried  (patch p u.old start.i remove.i expected.i replacement.i)
  ?.  &(?=(%| -.tried) =(%patch-context-mismatch p.tried))  $(rows t.rows, n +(n))
  %-  crip
  ;:  weld
    "item "  (scow %ud n)  " "  (spud pax.i)  " line "  (scow %ud start.i)  ": "
    (trip (mismatch u.old start.i remove.i expected.i))
  ==
++  edit-one
  |=  [p=project:nc t=tree:nc pax=path body=(unit replacement:nc)]
  ^-  edit:nc
  =/  before=(unit @ux)  (~(get by files.body.snapshot.t) pax)
  ?~  body  [[%delete pax before ~] ~]
  [[?:(=(~ before) %add %modify) pax before ``@ux`(page-to-lobe:clay [mark.u.body source.u.body])] body]
++  edits
  |=  [p=project:nc t=tree:nc args=tool-args:nc]
  ^-  (each (list edit:nc) @tas)
  ?+  -.args  [%| %candidate-operation-required]
    %writes
      ::  Every precondition addresses the same original namespace. This
      ::  returns one complete edit list or a refusal; no partial write occurs.
      ?.  &((gth (lent items.args) 0) (lte (lent items.args) 16))  [%| %writes-invalid]
      ?.  =((lent items.args) ~(wyt in (silt (turn items.args |=(i=write-item:nc pax.i)))))
        [%| %writes-duplicate-path]
      =/  rows=(list write-item:nc)  items.args
      =|  out=(list edit:nc)
      |-  ^-  (each (list edit:nc) @tas)
      ?~  rows  [%& (flop out)]
      =/  i=write-item:nc  i.rows
      ?.  (content-valid p pax.i content.i)  [%| %write-content-invalid]
      =/  current=(unit @ux)  (~(get by files.body.snapshot.t) pax.i)
      ?.  =(before.i current)
        [%| ?~(before.i %destination-exists %prior-blob-mismatch)]
      $(rows t.rows, out [(edit-one p t pax.i `content.i) out])
    %batch
      ?.  ?&  (segment-valid:project repository.origin.args)
              (gth number.origin.args 0)  (lte number.origin.args 1.000.000)
              !=(0 base.origin.args)  (lte (met 0 base.origin.args) 160)
              !=(0 head.origin.args)  (lte (met 0 head.origin.args) 160)
              !=(0 receipt.origin.args)  (lte (met 0 receipt.origin.args) 256)
              (gth (lent edits.args) 0)  (lte (lent edits.args) 32)
          ==  [%| %batch-invalid]
      [%& edits.args]
    %patches
      ::  One candidate from several exact line patches, possibly across files.
      ::  Every item names the current blob of its file; starts address the
      ::  original text, so each file is patched bottom-up without overlap.
      ?.  &((gth (lent items.args) 0) (lte (lent items.args) 16))  [%| %patches-invalid]
      =/  paths=(list path)
        %-  flop
        %+  roll  items.args
        |=  [i=patch-item:nc acc=(list path)]
        ?:((lien acc |=(q=path =(q pax.i))) acc [pax.i acc])
      =|  out=(list edit:nc)
      |-  ^-  (each (list edit:nc) @tas)
      ?~  paths  [%& (flop out)]
      =/  pax=path  i.paths
      =/  mine=(list patch-item:nc)  (skim items.args |=(i=patch-item:nc =(pax pax.i)))
      ?.  (levy mine |=(i=patch-item:nc =(`before.i (~(get by files.body.snapshot.t) pax))))
        [%| %prior-blob-mismatch]
      =/  ordered=(list patch-item:nc)
        (sort mine |=([a=patch-item:nc b=patch-item:nc] (gth start.a start.b)))
      =/  apart=?
        =/  rows  ordered
        |-  ^-  ?
        ?~  rows  %.y
        ?~  t.rows  %.y
        ?.  &((gth start.i.rows start.i.t.rows) (gte start.i.rows (add start.i.t.rows remove.i.t.rows)))  %.n
        $(rows t.rows)
      ?.  apart  [%| %patches-overlap]
      =/  old  (file p t pax)
      ?:  ?=(%| -.old)  [%| p.old]
      =/  text=@t  source.p.old
      =/  rows=(list patch-item:nc)  ordered
      |-  ^-  (each (list edit:nc) @tas)
      ?~  rows  ^$(paths t.paths, out [(edit-one p t pax `[mark.p.old text]) out])
      =/  changed  (patch p text start.i.rows remove.i.rows expected.i.rows replacement.i.rows)
      ?:  ?=(%| -.changed)  [%| p.changed]
      $(rows t.rows, text p.changed)
    %create
      ?:  (~(has by files.body.snapshot.t) pax.args)  [%| %destination-exists]
      [%& ~[(edit-one p t pax.args `content.args)]]
    %replace
      ?.  =(`before.args (~(get by files.body.snapshot.t) pax.args))  [%| %prior-blob-mismatch]
      [%& ~[(edit-one p t pax.args `content.args)]]
    %delete
      ?.  =(`before.args (~(get by files.body.snapshot.t) pax.args))  [%| %prior-blob-mismatch]
      [%& ~[(edit-one p t pax.args ~)]]
    %patch
      ?.  =(`before.args (~(get by files.body.snapshot.t) pax.args))  [%| %prior-blob-mismatch]
      =/  old  (file p t pax.args)
      ?:  ?=(%| -.old)  [%| p.old]
      =/  changed  (patch p source.p.old start.args remove.args expected.args replacement.args)
      ?:  ?=(%| -.changed)  [%| p.changed]
      [%& ~[(edit-one p t pax.args `[mark.p.old p.changed])]]
    %move
      ?.  =(`before.args (~(get by files.body.snapshot.t) from.args))  [%| %prior-blob-mismatch]
      ?:  (~(has by files.body.snapshot.t) to.args)  [%| %destination-exists]
      =/  old  (file p t from.args)
      ?:  ?=(%| -.old)  [%| p.old]
      [%& ~[(edit-one p t from.args ~) (edit-one p t to.args `p.old)]]
  ==
++  undo
  ::  Inverse candidate at a NEW revision. Unrelated later edits survive;
  ::  an overlapping later edit refuses. No historical revision is reset.
  |=  [p=project:nc t=tree:nc prior=candidate:nc]
  ^-  (each (list edit:nc) @tas)
  ?.  &((candidate-valid p prior) =(desk.revision.t desk.source.context.prior) (gth number.revision.t number.source.context.prior))
    [%| %undo-parent-invalid]
  =/  rows=(list edit:nc)  edits.prior
  =/  out=(list edit:nc)  ~
  |-  ^-  (each (list edit:nc) @tas)
  ?~  rows  [%& (flop out)]
  =/  e=edit:nc  i.rows
  ?.  =(after.change.e (~(get by files.body.snapshot.t) path.change.e))  [%| %undo-overlap]
  ?~  before.change.e
    $(rows t.rows, out [(edit-one p t path.change.e ~) out])
  =/  old  (file p basis.prior path.change.e)
  ?:  ?=(%| -.old)  [%| p.old]
  $(rows t.rows, out [(edit-one p t path.change.e `p.old) out])
++  execute
  ::  Registered config + authenticated actor come from Gall. Only native
  ::  reads happen here. The app retains results and admits candidates later.
  |=  [our=@p actor=@p at=@da p=project:nc r=tool-request:nc prior=(unit candidate:nc)]
  ^-  tool-result:nc
  :-  %native-coding-tool-result-v1
  :-  context.r
  :-  call-id.r
  ^-  tool-output:nc
  ?.  &(=(actor actor.context.r) (gte (met 3 call-id.r) 1) (lte (met 3 call-id.r) 256))
    [%refused %request-identity 'The authenticated caller or tool call id does not match.']
  =/  catalog  (catalog:project our at p)
  ?:  ?=(%| -.catalog)  [%refused p.catalog 'Canonical project membership is unavailable.']
  =/  operations=(list operation:nc)  (operations:project arguments.r)
  ?~  operations  [%refused %candidate-operation-required 'The batch must contain one to 32 edits.']
  =/  denied=(list @tas)
    %+  murn  operations
    |=  op=operation:nc
    =/  admitted  (authorize:project p p.catalog context.r op)
    ?:(?=(%| -.admitted) `p.admitted ~)
  ?^  denied  [%refused i.denied 'Project policy refused an operation in this request.']
  =/  current  (current:project our at p)
  ?:  ?=(%| -.current)  [%refused p.current 'The private accepted and working desks are unavailable.']
  =/  source=revision:nc  source.context.r
  =/  selected  (tree-at:project our at p desk.source number.source)
  ?:  ?=(%| -.selected)  [%refused p.selected 'The selected source revision is unavailable.']
  ?.  =(source revision.p.selected)  [%refused %source-mismatch 'The source commitment changed.']
  =/  t=tree:nc  p.selected
  =/  args=tool-args:nc  arguments.r
  ?:  ?=(%list -.args)
    =/  found  (listing p t directory.args cursor.args limit.args)
    ?:(?=(%| -.found) [%refused p.found 'File listing refused.'] [%list p.found])
  ?:  ?=(%read -.args)
    =/  found  (read p t pax.args start.args count.args)
    ?:(?=(%| -.found) [%refused p.found 'File read refused.'] [%read p.found])
  ?:  ?=(%search -.args)
    =/  found  (search p t mode.args query.args directory.args cursor.args limit.args)
    ?:(?=(%| -.found) [%refused p.found 'Search page refused.'] [%search p.found])
  ?:  ?=(%diff -.args)
    ?.  =(accepted.args revision.accepted.p.current)  [%refused %accepted-revision-mismatch 'Choose the current accepted revision.']
    =/  found  (diff p accepted.p.current t directory.args cursor.args limit.args)
    ?:(?=(%| -.found) [%refused p.found 'Diff page refused.'] [%diff p.found])
  ?.  (mutating:project -.args)  [%refused %tool-executor-required 'This operation requires its native job executor.']
  ?.  =(source revision.working.p.current)  [%refused %working-revision-changed 'Read the current working revision before editing.']
  =/  prepared=(each (list edit:nc) @tas)
    ?.  ?=(%undo -.args)  (edits p t args)
    ?~  prior  [%| %retained-undo-parent-required]
    ?.  =(candidate.args id.u.prior)  [%| %undo-parent-mismatch]
    (undo p t u.prior)
  ?:  ?=(%| -.prepared)
    =/  plain=tool-output:nc  [%refused p.prepared 'Candidate preparation refused.']
    ?:  ?=(%patches -.args)
      ?.  =(%patch-context-mismatch p.prepared)  plain
      =/  read  |=(pax=path ^-((unit @t) =/(old (file p t pax) ?:(?=(%| -.old) ~ `source.p.old))))
      [%refused p.prepared (patches-mismatch p items.args read)]
    ?.  ?=(%patch -.args)  plain
    ?.  =(%patch-context-mismatch p.prepared)  plain
    =/  old  (file p t pax.args)
    ?:  ?=(%| -.old)  plain
    [%refused p.prepared (mismatch source.p.old start.args remove.args expected.args)]
  =/  parent=(unit @ux)  ?:(&(?=(%undo -.args) ?=(^ prior)) `id.u.prior ~)
  =/  made  (candidate p context.r t revision.accepted.p.current p.prepared parent)
  ?:(?=(%| -.made) [%refused p.made 'Candidate validation refused.'] [%candidate p.made])
--
