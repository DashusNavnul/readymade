::  Pure prospective owner journal. No cards, scries, selection or dispatch.
::  The Gall owner must supply private canonical snapshots and persist +open
::  before releasing its prepared provider card. This pure code cannot prove
::  the origin of caller-created nouns or that persistence preceded dispatch.
::  Task/scorer declarations are frozen but NOT admitted: the native producer
::  binding exact task, evaluator source/version and weights is still absent.
::  Candidate assessment and final Cantrip admission are also still required.
/-  nc=native-coding, np=native-coding-provider, ci=cli-inference
/+  decision=qpc-native-decision, sessions=native-coding-session,
    pool=qpc-native-pool, evidence=qpc-native-evidence, law=qpc-law-core,
    tools=cantrip-native-coding,
    project=native-coding-project, provider=native-coding-provider
|%
+$  declaration
  $:  task=@ux  objective=@ux  scorer=%qpc-energy-v1
      source=revision:nc  pax=path  hash=@ux
      weights=parameters:law  required=(list @tas)
  ==
+$  snapshot
  $:  input=input:pool  managed=(set @ux)  laws=state:law
      binding=binding:law  expected-law=@ux
      windows=(map @ux prefix:decision)  ledger=organ:tools
  ==
+$  collection
  $:  pool=pool:pool  generation=generation:decision  position=@ud
      extension=(list record:sessions)  provider=@ux  ledger=@ux
  ==
+$  record
  $:  decision=state:decision  declaration=declaration
      key=@tas  request=request:np  context=record:sessions
      scope=scope:tools  collection=(unit collection)
      closed=(unit [kind=?(%refused %cancelled) evidence=@ux])
  ==
+$  state  [%qpc-native-owner-v1 records=(map @ux record)]
++  empty  ^-(state [%qpc-native-owner-v1 ~])
++  digest  |=(v=* ^-(@ux (shax (jam [%qpc-native-owner-v1 v]))))
++  scope-valid
  ::  A current standing grant is a binding, not final effect admission.
  |=  [our=@p input=input:pool s=scope:tools]
  =/  e=entry:sessions  entry.input
  =/  g=grant:tools  grant.s
  ?&  (grant-valid:tools our g)  ?=(~ revoked.s)
      =(grant.input id.g)  =(id.session.e session.g)
      =(our actor.g)  =(our owner.session.e)  =(our worker.e)
      =(project.session.e id.spec.project.g)
      =(configuration.e (configuration:project project.g))
      =(desk.working.session.e working.project.g)
      (~(has in operations.g) %patch)
  ==
++  prepared
  |=  [our=@p input=input:pool]
  ^-  (each record:sessions @tas)
  =/  e=entry:sessions  entry.input
  ?.  &((chain:pool e) =(%inference phase.e) ?=(~ calls.e) ?=(~ results.e))
    [%| %qpc-owner-session-not-prepared]
  ?~  pending.e  [%| %qpc-owner-request-missing]
  =/  r=request:np  u.pending.e
  ?.  ?&  (request-valid:provider r)  (proposal-tools:pool tools.r)
          =(our owner.session.e)  =(our worker.e)
          =(selection.e selection.r)  =(id.session.e session.r)
          (gth turn.e 0)  !=(%$ key.input)
      ==  [%| %qpc-owner-request-mismatch]
  ?.  =(id.r (request-id:sessions id.session.e (dec turn.e)))
    [%| %qpc-owner-request-mismatch]
  ?.  (gte (lent records.e) 2)  [%| %qpc-owner-context-missing]
  =/  c=record:sessions  (rear records.e)
  ?.  ?=(%context -.body.c)  [%| %qpc-owner-context-missing]
  =/  dispatch=record:sessions  (snag (sub (lent records.e) 2) records.e)
  ?.  =([%status %inference %dispatch] body.dispatch)
    [%| %qpc-owner-dispatch-boundary]
  =/  b  value.body.c
  ?.  ?&  =(our owner.b)  =(our worker.b)  =(session.r session.b)
          =(id.r request.b)  =(working.session.e source.b)
          =(provider.selection.r provider.b)  =(model.selection.r model.b)
          =((shax (jam r)) request-digest.b)
          =((shax (jam history.r)) history-digest.b)
          =((shax (jam tools.r)) tools-digest.b)
          !=(0 prepared-digest.b)  !=(0 receipt-digest.b)
          !(lien records.e |=(v=record:sessions ?.(?=(%model -.body.v) %.n =(id.r id.result.body.v))))
      ==  [%| %qpc-owner-context-mismatch]
  [%& c]
++  open
  |=  [s=state our=@p actor=@p declared=declaration view=snapshot]
  ^-  (each state @tas)
  ?.  =(our actor)  [%| %qpc-owner-required]
  =/  input=input:pool  input.view
  =/  id=@ux  id.session.entry.input
  ?:  (~(has by records.s) id)  [%| %qpc-owner-already-open]
  ?.  (lth ~(wyt by records.s) 64)  [%| %qpc-owner-capacity]
  ?.  (~(has in managed.view) id)  [%| %qpc-owner-unmanaged-session]
  =/  context  (prepared our input)
  ?:  ?=(%| -.context)  [%| p.context]
  =/  scope  (~(get by grants.ledger.view) grant.input)
  ?~  scope  [%| %qpc-owner-grant-missing]
  ?.  (scope-valid our input u.scope)  [%| %qpc-owner-grant-mismatch]
  =/  history  (~(get by laws.view) instrument.binding.view)
  ?^  history
    ?.  (history-valid:law our instrument.binding.view u.history)
      [%| %qpc-owner-law-history-invalid]
    (open-law s our declared view p.context u.scope)
  (open-law s our declared view p.context u.scope)
++  open-law
  |=  [s=state our=@p declared=declaration view=snapshot context=record:sessions scope=scope:tools]
  ^-  (each state @tas)
  =/  frozen  (freeze:law laws.view binding.view our expected-law.view)
  ?:  ?=(%| -.frozen)  [%| p.frozen]
  =/  prefix  (~(get by windows.view) session.binding.view)
  ?~  prefix  [%| %qpc-owner-window-missing]
  ?.  ?&  (revision-valid:project source.declared)
          =(our owner.source.declared)  =(/lib/qpc-energy/hoon pax.declared)
          !=(0 hash.declared)  (lte (met 0 hash.declared) 256)
          =(weights.declared parameters.p.frozen)
      ==  [%| %qpc-owner-declaration-mismatch]
  =/  e=entry:sessions  entry.input.view
  =/  request=request:np  (need pending.e)
  =/  f=opening:decision
    :*  our  project.session.e  configuration.e  working.session.e
        id.session.e  id.request  (shax (jam request))
        grant.input.view  (digest scope)
        task.declared  objective.declared  scorer.declared
        (digest [scorer.declared source.declared pax.declared hash.declared])
        required.declared  sequence.context  p.frozen  u.prefix
    ==
  =/  opened  (open:decision f)
  ?:  ?=(%| -.opened)  [%| p.opened]
  =/  r=record  [p.opened declared key.input.view request context scope ~ ~]
  [%& s(records (~(put by records.s) id.session.e r))]
++  seal-ready
  |=  [s=state our=@p actor=@p input=input:pool ledger=organ:tools]
  ^-  (each record @tas)
  ?.  =(our actor)  [%| %qpc-owner-required]
  =/  e=entry:sessions  entry.input
  =/  held  (~(get by records.s) id.session.e)
  ?~  held  [%| %qpc-owner-not-open]
  =/  r=record  u.held
  ?:  ?=(^ closed.r)  [%| %qpc-owner-closed]
  ?:  ?=(^ collection.r)  [%| %qpc-owner-already-sealed]
  =/  f=opening:decision  frozen.decision.r
  =/  scope  (~(get by grants.ledger) grant.input)
  ?~  scope  [%| %qpc-owner-grant-missing]
  ?.  &((scope-valid our input u.scope) =(scope.r u.scope))
    [%| %qpc-owner-grant-changed]
  ?.  ?&  =(key.input key.r)  =(grant.input grant.f)
          =(configuration.e configuration.f)  =(project.session.e project.f)
          =(working.session.e source.f)  =(selection.e selection.request.r)
          (chain:pool e)  (gth (lent records.e) sequence.context.r)
      ==  [%| %qpc-owner-collection-mismatch]
  ?.  =(context.r (snag sequence.context.r records.e))
    [%| %qpc-owner-prefix-rewritten]
  [%& r]
++  seal-http
  ::  +assemble reparses the retained HTTP bytes; no asserted pool is accepted.
  |=  [s=state our=@p actor=@p input=input:pool kept=retained:evidence ledger=organ:tools]
  ^-  (each state @tas)
  =/  ready  (seal-ready s our actor input ledger)
  ?:  ?=(%| -.ready)  [%| p.ready]
  ?.  =(request.p.ready request.kept)  [%| %qpc-owner-provider-request-changed]
  =/  built  (assemble:pool our input kept ledger)
  ?:  ?=(%| -.built)  [%| p.built]
  (seal-checked s p.ready input p.built (digest kept) ledger)
++  seal-cli
  ::  +assemble-cli uses the retained native CLI claim/raw normalization.
  |=  [s=state our=@p actor=@p input=input:pool kept=job:ci ledger=organ:tools]
  ^-  (each state @tas)
  =/  ready  (seal-ready s our actor input ledger)
  ?:  ?=(%| -.ready)  [%| p.ready]
  ?.  =(request.p.ready request.kept)  [%| %qpc-owner-provider-request-changed]
  =/  built  (assemble-cli:pool our input kept ledger)
  ?:  ?=(%| -.built)  [%| p.built]
  (seal-checked s p.ready input p.built (digest kept) ledger)
++  seal-checked
  |=  [s=state r=record input=input:pool p=pool:pool provider=@ux ledger=organ:tools]
  ^-  (each state @tas)
  =/  found  (extract:pool entry.input)
  ?:  ?=(%| -.found)  [%| p.found]
  =/  model=record:sessions  model.p.found
  =/  last=record:sessions  (rear records.entry.input)
  ?.  ?&  =(context.r context.p.found)
          (lth sequence.context.r sequence.model)
          (lth sequence.model sequence.last)
          =(id.request.r request.p)  =(id.context.r context-record.p)
          =(id.model model-record.p)  =(id.last through.p)
      ==  [%| %qpc-owner-generation-order]
  =/  g=generation:decision
    [id.decision.r sequence.model id.request.r (shax (jam request.r)) provider]
  =/  kept=collection
    [p g sequence.last (slag +(sequence.context.r) records.entry.input) provider (digest ledger)]
  [%& s(records (~(put by records.s) session.p r(collection `kept)))]
++  stop
  |=  [s=state our=@p actor=@p id=@ux kind=?(%refused %cancelled) evidence=@ux]
  ^-  (each state @tas)
  ?.  =(our actor)  [%| %qpc-owner-required]
  =/  held  (~(get by records.s) id)
  ?~  held  [%| %qpc-owner-not-open]
  =/  r=record  u.held
  ?.  =(our owner.frozen.decision.r)  [%| %qpc-owner-required]
  =/  stopped  (stop:decision decision.r kind evidence)
  ?:  ?=(%| -.stopped)  [%| p.stopped]
  [%& s(records (~(put by records.s) id r(decision p.stopped, closed `[kind evidence])))]
++  release
  ::  There is deliberately no mapping/eligible/receipt argument to launder.
  ::  A later native producer must bind declarations, assess frozen candidates,
  ::  select once, and obtain fresh Cantrip admission for an exact new request.
  |=  [s=state id=@ux]
  ^-  (each mapping:decision @tas)
  ?.  (~(has by records.s) id)  [%| %qpc-owner-not-open]
  [%| %qpc-owner-admission-producer-required]
--
