::  Prospective managed collection only. Assessment, selection and ordinary
::  execution remain unavailable. No app is composed by importing this core.
/+  bind=qpc-native-owner-binding, read=qpc-native-owner-read,
    owner=qpc-native-owner, obs=qpc-observation, sensing=qpc-task-sensing
|%
++  wrap
  ::  Internal proof seams are native gates, never public payload fields.
  |=  [inner=agent:gall fetch=reader:read seal=sealer:read]
  =/  held=state:bind  empty:bind
  ^-  agent:gall
  |_  =bowl:gall
  +*  this  .
      ag  ~(. inner bowl)
      refuse
        |=  [id=@ux reason=@tas]
        ^-  (quip card:agent:gall _this)
        =.  held  (unavailable:bind held id reason)
        [~[[%give %fact ~[/native-coding] %noun !>([%qpc-owner-unavailable-v1 id reason])]] this]
      abandon
        ::  No prepared transition was committed. Preserve the pre-run inner;
        ::  disarm only the prior committed observation arm, retaining its record.
        |=  [id=@ux reason=@tas phase=?(%unavailable %unknown)]
        ^-  (quip card:agent:gall _this)
        =/  t=ticket:bind  (~(got by tickets.held) id)
        =.  held  held(tickets (~(put by tickets.held) id t(phase phase, reason `reason)))
        =^  cards  inner  (on-poke:~(. inner bowl(src our.bowl)) %noun !>([%qpc-observe-disarm-v1 id]))
        =/  refused  (refuse id reason)
        [(weld cards -.refused) +.refused]
      collect
        |=  id=@ux
        ^-  _this
        =/  found  (~(get by tickets.held) id)
        ?~  found  this
        =/  t=ticket:bind  u.found
        ?.  =(%opened phase.t)  this
        =.  t  ?~(seal.t t t(seal `u.seal.t(pending %.n)))
        =.  held  held(tickets (~(put by tickets.held) id t))
        =/  attempted  (mule |.((seal inner bowl(src our.bowl) journal.held id)))
        ?:  ?=(%| -.attempted)
          this(held (unavailable:bind held id %qpc-owner-seal-unconfirmed))
        =/  got  p.attempted
        ?:  ?=(%| -.got)
          this(held (unavailable:bind held id p.got))
        this(held held(journal p.got, tickets (~(put by tickets.held) id t(phase %sealed)), unavailable (~(del by unavailable.held) id)))
      schedule-seal
        ::  Commit callback DATA/cards before any native evidence scry. A native
        ::  %need cannot be caught by +mule, and must not roll back that callback.
        |=  id=@ux
        ^-  (quip card:agent:gall _this)
        =/  found  (~(get by tickets.held) id)
        ?~  found  [~ this]
        =/  t=ticket:bind  u.found
        ?.  &(=(%opened phase.t) ?=(~ seal.t))  [~ this]
        =/  queued=ticket:bind
          [registration.t work.t before.t due.t phase.t reason.t `[(add now.bowl ~s1) %.y]]
        =.  held  held(tickets (~(put by tickets.held) id queued))
        [~[[%pass (seal-wire:bind id queued) %arvo %b %wait due:(need seal.queued)]] this]
      finish
        ::  Every actual callback transition is already in inner. A seal refusal
        ::  cannot roll it back or discard its other cards. Unexpected managed
        ::  inference is stopped here; ordinary inference is passed unchanged.
        |=  [cards=(list card:agent:gall) settle=?]
        ^-  (quip card:agent:gall _this)
        =/  required  (managed:read inner bowl)
        =/  blocked=(set [session=@ux request=@ux])  ~
        =/  consumed=(set @ux)  ~
        =/  added=(list card:agent:gall)  ~
        =/  todo=(list card:agent:gall)  cards
        |-  ^-  (quip card:agent:gall _this)
        ?~  todo
          =/  kept=(list card:agent:gall)
            %+  skim  cards
            |=  c=card:agent:gall
            =/  legacy  (seal-card:bind our.bowl c)
            ?:  ?~(legacy %.n (~(has in consumed) u.legacy))  %.n
            =/  inference  (infer:bind c)
            ?^  inference
              !(~(has in blocked) [session.request.u.inference id.request.u.inference])
            =/  timer  ((soft ,[%pass [%native-coding %deadline session=@ta request=@ta ~] %arvo %b %wait at=@da]) c)
            ?~  timer  %.y
            =/  id  (slaw %ux session.u.timer)
            =/  request  (slaw %ux request.u.timer)
            ?~  id  %.y
            ?~  request  %.y
            !(~(has in blocked) [u.id u.request])
          [(weld kept added) this]
        =/  c=card:agent:gall  i.todo
        =/  inference  (infer:bind c)
        ?^  inference
          =/  id=@ux  session.request.u.inference
          ?:  ?~(required %.y (~(has in u.required) id))
            =.  held  (unavailable:bind held id %qpc-owner-unprepared-provider-card)
            $(todo t.todo, blocked (~(put in blocked) [id id.request.u.inference]))
          $(todo t.todo)
        =/  id  (seal-card:bind our.bowl c)
        ?~  id  $(todo t.todo)
        =/  ticket  (~(get by tickets.held) u.id)
        ?~  ticket  $(todo t.todo)
        ?.  =(%opened phase.u.ticket)  $(todo t.todo)
        ::  This owned control card would invoke the legacy synchronous sealer.
        ::  Replace it only for our opened session; ordinary cards remain exact.
        =.  consumed  (~(put in consumed) u.id)
        ?.  settle  $(todo t.todo)
        =/  next  (schedule-seal u.id)
        =.  held  held.+.next
        $(todo t.todo, added (weld added -.next))
  ++  on-init
    =^  cards  inner  on-init:ag
    (finish cards %.y)
  ++  on-save  !>([%qpc-prospective-owner-v1 held on-save:ag])
  ++  on-load
    |=  old=vase
    =/  saved=[held=state:bind inner=vase]
      ?.  ?=([%qpc-prospective-owner-v1 *] q.old)  [empty:bind old]
      =/  prior  !<([%qpc-prospective-owner-v1 held=state:bind inner=vase] old)
      +.prior
    ?>  (valid:bind our.bowl held.saved)
    =.  held  held.saved
    =^  cards  inner  (on-load:ag inner.saved)
    ::  Inspect the loaded inner locally, suppressing managed re-dispatch.
    ::  No new timer, native read, inference or automatic reseal on reload.
    (finish cards %.n)
  ++  on-poke
    |=  [=mark =vase]
    ::  Even owner-authenticated external pokes cannot supply a reservation.
    ::  Only the validated prospective path below constructs this protocol.
    ?>  !?=([%qpc-selected-reserve-v1 *] q.vase)
    ?:  &(=(%noun mark) ?=([%qpc-owner-seal-v1 @] q.vase))
      ?>  =(our.bowl src.bowl)
      [~ (collect `@ux`+.q.vase)]
    ?:  &(=(%noun mark) ?=([%native-coding-action-v1 %run @] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  command  ;;([%native-coding-action-v1 [%run id=@ux]] q.vase)
      =/  id=@ux  id.command
      =/  required  (managed:read inner bowl)
      ?~  required  (refuse id %qpc-owner-gate-unavailable)
      ?.  (~(has in u.required) id)
        =^  cards  inner  (on-poke:ag mark vase)
        (finish cards %.y)
      ::  There are no automatic retries or late enrollment of an old request.
      ?:  (~(has by tickets.held) id)  [~ this]
      ?:  (~(has by unavailable.held) id)  [~ this]
      ?.  (lth ~(wyt by tickets.held) 64)  (refuse id %qpc-owner-capacity)
      =/  got  (fetch inner bowl id)
      ?:  ?=(%| -.got)  (refuse id p.got)
      =/  v=view:bind  p.got
      =/  ready  (ready:bind our.bowl v)
      ?:  ?=(%| -.ready)  (refuse id p.ready)
      =/  t=ticket:bind
        [registration.v p.ready (digest:bind input.snapshot.v) (add now.bowl ~s1) %scheduled ~ ~]
      =^  reserved  inner
        ?:  =(`%first-17-reference-successive-disjoint-17-live (policy-of:sensing manifest.plan.value.registration.v))
          (on-poke:~(. inner bowl(src our.bowl)) %noun !>([%qpc-selected-reserve-v1 member.command.value.registration.v id.law.value.registration.v p.ready]))
        [~ inner]
      ?>  =(~ reserved)
      =^  cards  inner
        (on-poke:~(. inner bowl(src our.bowl)) %noun !>([%qpc-observe-arm-v1 manifest.plan.value.registration.v p.ready]))
      =.  held  held(tickets (~(put by tickets.held) id t))
      =/  wake=(list card:agent:gall)
        ~[[%pass (wire-for:bind id t) %arvo %b %wait due.t]]
      [(weld cards wake) this]
    =^  cards  inner  (on-poke:ag mark vase)
    (finish cards %.y)
  ++  on-arvo
    |=  [=wire =sign-arvo]
    ?:  ?=([%qpc-owner-seal *] wire)
      ?.  &(=(our.bowl src.bowl) ?=([%qpc-owner-seal @ @ ~] wire))  [~ this]
      =/  id  (slaw %ux i.t.wire)
      ?~  id  [~ this]
      =/  found  (~(get by tickets.held) u.id)
      ?~  found  [~ this]
      =/  t=ticket:bind  u.found
      ?~  seal.t  [~ this]
      ?.  &(=(%opened phase.t) pending.u.seal.t =(wire (seal-wire:bind u.id t)))  [~ this]
      ?.  &(?=([%behn %wake *] sign-arvo) (gte now.bowl due.u.seal.t))  [~ this]
      ?.  ?=([%behn %wake ~] sign-arvo)
        =.  held  held(tickets (~(put by tickets.held) u.id t(seal `u.seal.t(pending %.n))))
        (refuse u.id %qpc-owner-seal-wake-unconfirmed)
      [~ (collect u.id)]
    ?.  ?=([%qpc-owner-wake *] wire)
      =^  cards  inner  (on-arvo:ag wire sign-arvo)
      (finish cards %.y)
    ?.  &(=(our.bowl src.bowl) ?=([%qpc-owner-wake @ @ ~] wire))  [~ this]
    =/  id  (slaw %ux i.t.wire)
    ?~  id  [~ this]
    =/  found  (~(get by tickets.held) u.id)
    ?~  found  [~ this]
    =/  t=ticket:bind  u.found
    ?.  &(=(%scheduled phase.t) =(wire (wire-for:bind u.id t)))  [~ this]
    ?.  ?=([%behn %wake *] sign-arvo)  [~ this]
    ?.  (gte now.bowl due.t)  [~ this]
    ?.  ?=([%behn %wake ~] sign-arvo)  (abandon u.id %qpc-owner-wake-unconfirmed %unknown)
    =/  got  (fetch inner bowl u.id)
    ?:  ?=(%| -.got)  (abandon u.id p.got %unavailable)
    =/  v=view:bind  p.got
    =/  arm  (~(get by arms.observed.v) u.id)
    =/  unchanged=?
      ?~  arm  %.n
      ?&  =(registration.t registration.v)
          =(before.t (digest:bind input.snapshot.v))
          active.u.arm  =(work.t work.u.arm)
      ==
    ?.  unchanged  (abandon u.id %qpc-owner-ticket-stale %unavailable)
    ::  Keep this pre-prepare inner until every open/card check succeeds.
    =/  prepared  (on-poke:ag %noun !>([%native-coding-action-v1 [%run u.id]]))
    =/  after=agent:gall  +.prepared
    =/  snapshot  (fetch after bowl u.id)
    ?:  ?=(%| -.snapshot)  (abandon u.id p.snapshot %unavailable)
    ?.  =(registration.t registration.p.snapshot)
      (abandon u.id %qpc-owner-declaration-changed %unavailable)
    =/  opened  (open:owner journal.held our.bowl src.bowl (declared:bind registration.t) snapshot.p.snapshot)
    ?:  ?=(%| -.opened)  (abandon u.id p.opened %unavailable)
    =/  r=record:owner  (~(got by records.p.opened) u.id)
    =/  inferences=(list card:agent:gall)
      (skim -.prepared |=(c=card:agent:gall ?=(^ (infer:bind c))))
    ?.  =(inferences ~[(expected-card:bind our.bowl r)])
      (abandon u.id %qpc-owner-provider-card-mismatch %unavailable)
    ?.  (schema-valid:obs manifest.plan.value.registration.t work.t tools.request.r)
      (abandon u.id %qpc-owner-prediction-schema-mismatch %unavailable)
    =/  prompt=@t  (instructions:obs manifest.plan.value.registration.t work.t)
    ?.  =(prompt (cut 3 [0 (met 3 prompt)] instructions.request.r))
      (abandon u.id %qpc-owner-prediction-prompt-missing %unavailable)
    =.  held  held(journal p.opened, tickets (~(put by tickets.held) u.id t(phase %opened)))
    ::  Gall commits this journal and returned inner before releasing cards.
    [-.prepared this(inner after)]
  ++  on-peek
    |=  =path
    ?:  =(/x/qpc/owner path)
      ?.  =(our.bowl src.bowl)  ~
      ``noun+!>(held)
    (on-peek:ag path)
  ++  on-watch
    |=  =path
    =^  cards  inner  (on-watch:ag path)
    (finish cards %.y)
  ++  on-leave
    |=  =path
    =^  cards  inner  (on-leave:ag path)
    (finish cards %.y)
  ++  on-agent
    |=  [=wire =sign:agent:gall]
    =^  cards  inner  (on-agent:ag wire sign)
    (finish cards %.y)
  ++  on-fail
    |=  [=term =tang]
    =^  cards  inner  (on-fail:ag term tang)
    (finish cards %.y)
  --
++  agent  |=(inner=agent:gall (wrap inner read:read seal:read))
--
