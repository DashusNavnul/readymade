::  Exact saved-source joins and bounded, effect-free module evaluation.
/-  pc=pataphor-project-coding
/+  project=pataphor-project-coding, save=cantrip-project-save,
    editor=pataphor-editor-model
|%
+$  input  [manifest=manifest:pc saved=record:save]
+$  report
  $:  %pataphor-project-preview-v1  owner=@p  at=@da  manifest=@ux
      saved=record:save  work=revision:editor  sources=(map path @t)
      checks=(list check:pc)  preview=(unit preview:pc)
  ==
++  budget  `@dr`~s2
++  input-valid
  |=  i=input
  ^-  ?
  ?&  (manifest-valid:project manifest.i)
      (record-valid:save saved.i)  =(%applied status.saved.i)
      =(basis.manifest.i basis.request.admission.saved.i)
      (edits-valid:project manifest.i edits.request.admission.saved.i)
  ==
++  sources
  |=  i=input
  ^-  (map path @t)
  =/  out=(map path @t)  sources.manifest.i
  =/  edits=(list edit:save)  edits.request.admission.saved.i
  |-  ^-  (map path @t)
  ?~  edits  out
  $(edits t.edits, out (~(put by out) path.change.i.edits source.i.edits))
++  revision
  |=  saved=record:save
  ^-  revision:editor
  =/  work  working:(need history.saved)
  [base-desk.body.snapshot.work base-revision.body.snapshot.work root.work]
++  run
  ::  Compile only a fixed caller-supplied test expression, then evaluate
  ::  without scry hooks, cards, host tools, or unbounded native slam.
  |=  [built=vase expression=@t]
  ^-  (each @t @tas)
  =/  compiled  (mule |.((~(mint ut p.built) %noun (ream expression))))
  ?:  ?=(%| -.compiled)  [%| %interface-refused]
  ::  Native jets are required for ordinary Hoon atom/string operations.
  ::  No scry hook is supplied. Vere's nested %jinx work budget bounds the
  ::  evaluation; exhaustion fails the thread, leaving the save unchanged.
  =/  ran=tone
    ~>  %jinx.budget
    (mink [q.built q.p.compiled] ~)
  ?.  ?=(%0 -.ran)  [%| %evaluation-refused]
  =/  text  ((soft ,@t) product.ran)
  ?~  text  [%| %output-shape-refused]
  ?.  &(!=('' u.text) (lte (met 3 u.text) 4.096) (text-valid:editor u.text))
    [%| %output-bound-refused]
  [%& u.text]
++  escape
  |=  text=@t
  ^-  @t
  %+  rap  3
  %+  turn  (trip text)
  |=  c=@tD
  ^-  @t
  ?:  =(c 38)  '&amp;'
  ?:  =(c 60)  '&lt;'
  ?:  =(c 62)  '&gt;'
  ?:  =(c 34)  '&quot;'
  ?:  =(c 39)  '&#39;'
  (crip ~[c])
++  render
  |=  [welcome=@t reply=@t]
  ^-  preview:pc
  :-  %html
  %+  rap  3
  :~  '<section><h3>Native module preview</h3><p>Evaluated saved libraries; no browser or message action was run.</p><h4>Workspace welcome</h4><pre>'
      (escape welcome)
      '</pre><h4>Noltbook reply</h4><pre>'
      (escape reply)
      '</pre></section>'
  ==
++  checks-shape
  |=  checks=(list check:pc)
  ^-  ?
  =/  names=(list [path @tas])
    (turn checks |=(c=check:pc [pax.c name.c]))
  ?&  =(names ~[[/lib/pataphor-workspace-ui/hoon %compile] [/lib/pataphor-workspace-ui/hoon %welcome] [/lib/pataphor-noltbook/hoon %compile] [/lib/pataphor-noltbook/hoon %reply]])
      (levy checks |=(c=check:pc (lte (met 3 detail.c) 2.048)))
  ==
++  passed
  |=  r=report
  ^-  ?
  &((checks-shape checks.r) (levy checks.r |=(c=check:pc passed.c)) ?=(^ preview.r))
++  valid
  ::  Internal receipt integrity. Only the native Ted authenticates reads
  ::  and compilation; this predicate never proves supplied check claims.
  |=  [m=manifest:pc r=report]
  ^-  ?
  ?&  (input-valid [m saved.r])  =(owner.r owner.basis.m)
      =(manifest.r (manifest-id:project m))  !=(0 at.r)
      =(work.r (revision saved.r))  =(sources.r (sources [m saved.r]))
      (checks-shape checks.r)
      ?~  preview.r
        !(levy checks.r |=(c=check:pc passed.c))
      &((levy checks.r |=(c=check:pc passed.c)) =(%html -.u.preview.r) (lte (met 3 body.u.preview.r) 65.536))
  ==
--
