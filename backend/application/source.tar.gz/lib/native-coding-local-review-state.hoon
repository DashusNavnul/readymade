::  Durable local-review transitions. Read adapters authenticate input; these
::  pure transitions retain it once and never create a coding permission.
/-  np=native-coding-provider, pa=native-coding-provider-attestation
/+  local=native-coding-local-review, provider=native-coding-provider,
    att=native-coding-provider-attestation
|%
+$  campaign-v1
  $:  request=request:local  started=@da
      challenge=(unit attestation:pa)  resolution=(unit attestation:pa)
      pending=(unit @ux)  outcome=(unit judgment:local)  reason=(unit @tas)
      rejected=(unit attestation:pa)
  ==
+$  state-v1  [scopes=(map @t scope:local) campaigns=(map @ux campaign-v1)]
+$  campaign
  $:  request=request:local  started=@da
      challenge=(unit attestation:pa)  resolution=(unit attestation:pa)
      pending=(unit @ux)  outcome=(unit judgment:local)  reason=(unit @tas)
      rejected=(unit attestation:pa)
      attempt=@ud  failures=(list failure:np)
  ==
+$  state  [scopes=(map @t scope:local) campaigns=(map @ux campaign)]
+$  reading
  $%  [%pending ~]  [%unknown reason=@tas]  [%receipt value=attestation:pa]
      [%failed error=failure:np]
  ==
+$  change  [state=state dispatch=(unit [key=@tas request=request:np])]
++  migrate
  |=  old=state-v1
  ^-  state
  [scopes.old (malt (turn ~(tap by campaigns.old) |=([id=@ux c=campaign-v1] [id [request.c started.c challenge.c resolution.c pending.c outcome.c reason.c rejected.c 0 ~]])))]
++  transient
  |=  e=failure:np
  ^-  ?
  &(=(%http-error reason.e) ?|(=(502 status.e) =(503 status.e) =(504 status.e)))
++  retryable
  |=  [r=request:local e=failure:np]
  ^-  ?
  ?|  &(=(401 status.e) ?|(=(%login-required reason.e) =(%http-error reason.e)))
      &(=(%resolve mode.r) (transient e))
      &(=(200 status.e) (unusable reason.e))
  ==
++  unusable
  ::  An authentic reply with no reading in it. It holds no verdict, so calling
  ::  again cannot turn a refusal into an approval. Integrity failures stay out.
  |=  reason=@tas
  ^-  ?
  ?=  $?  %local-review-json-invalid  %local-review-schema-invalid
          %local-review-decision-missing  %local-review-decision-invalid
          %local-review-reason-missing  %local-review-reason-invalid
      ==
  reason
++  reply-failure
  ::  The failure row that spends the campaign's one retry on an unusable reply.
  ::  Its digest commits the rejected attestation, which Graf already retains.
  |=  c=campaign
  ^-  (unit failure:np)
  ?~  rejected.c  ~
  ?~  reason.c  ~
  ?.  &(=(0 attempt.c) ?=(~ failures.c) (unusable u.reason.c))  ~
  `[%native-coding-provider-error-v1 job.u.rejected.c provider.selection.scope.request.c 200 u.reason.c digest.u.rejected.c]
++  unread
  ::  Unusable again with the retry spent: the review ended with no verdict.
  ::  ++decide:native-coding-local-decision reads this as a refusal, so it fails
  ::  closed and the builder may submit again.
  |=  c=campaign
  ^-  ?
  &(?=(^ rejected.c) ?=(^ reason.c) (unusable (need reason.c)) ?=(~ (reply-failure c)))
++  dead
  ::  One member's reviews that carry a reason and no decision. Nothing else
  ::  moves these, and the candidate holds its work desk until one of them ends.
  |=  [held=state member=@ux]
  ^-  (list [candidate=@ux reason=@tas retry=(unit @ux) unread=?])
  %+  murn  ~(tap by campaigns.held)
  |=  [id=@ux c=campaign]
  ?.  =(member session.context.candidate.frozen.request.c)  ~
  ?^  outcome.c  ~
  ?~  reason.c  ~
  =/  spent  (reply-failure c)
  `[id u.reason.c ?~(spent ~ `id.u.spent) (unread c)]
++  challenge-attempt
  ::  The retained first failure identifies which stage consumed the one retry.
  |=  c=campaign
  ^-  @ud
  ?~  failures.c  0
  ?:  &(=(1 attempt.c) =((identity:local request.c) id.i.failures.c))  1
  0
++  failure-valid
  |=  [r=request:local attempt=@ud e=failure:np]
  ^-  ?
  ?&  =((identity-at:local r attempt) id.e)
      =(provider.selection.scope.r provider.e)
      (lte status.e 599)  (name-valid:provider reason.e)
      (stamp:att raw-digest.e)
  ==
++  history-valid
  |=  c=campaign
  ^-  ?
  =/  count=@ud  (lent failures.c)
  ?.  &((lte attempt.c 1) (gte count attempt.c) (lte count +(attempt.c)))  %.n
  ?.  ?:  =(count +(attempt.c))
        ?&  ?=(~ pending.c)  ?=(~ outcome.c)  ?=(~ resolution.c)
            ?=(~ rejected.c)  =(`%local-review-provider-failed reason.c)
        ==
      !=(`%local-review-provider-failed reason.c)
    %.n
  =/  index=@ud  0
  =/  rows=(list failure:np)  failures.c
  |-  ^-  ?
  ?~  rows  %.y
  =/  r=request:local
    ?:  &(=(0 index) =(1 (challenge-attempt c)))  request.c
    (expected c)
  ?&  (failure-valid r index i.rows)
      ?|(=(index attempt.c) (retryable r i.rows))
      $(index +(index), rows t.rows)
  ==
++  retry
  ::  Explicit bounded retry only after authenticated terminal failure or an
  ::  authentic reply with no reading in it.
  ::  Caller re-freezes current inputs; no unknown or semantic refusal retries.
  |=  [our=@p held=state id=@ux failed=@ux]
  ^-  (each change @tas)
  ?.  (valid our held)  [%| %local-review-state-invalid]
  =/  found  (~(get by campaigns.held) id)
  ?~  found  [%| %local-review-candidate-missing]
  =/  c=campaign  u.found
  ?.  (active held request.c)  [%| %local-review-scope-revoked]
  =/  spent  (reply-failure c)
  =.  c  ?~(spent c c(failures ~[u.spent], rejected ~, reason `%local-review-provider-failed))
  ?.  ?&  =(0 attempt.c)  =(~ pending.c)
          =(`%local-review-provider-failed reason.c)  =(1 (lent failures.c))
      ==  [%| %local-review-retry-unavailable]
  =/  e=failure:np  (snag 0 failures.c)
  ?.  &(=(failed id.e) (retryable (expected c) e))  [%| %local-review-retry-ineligible]
  =/  next  (inference-at:local our (expected c) 1)
  ?:  ?=(%| -.next)  [%| p.next]
  =.  c  c(attempt 1, pending `id.p.next, reason ~)
  [%& [held(campaigns (~(put by campaigns.held) id c)) `[provider-key.scope.request.c p.next]]]
++  scope-valid
  |=  [our=@p s=scope:local]
  ^-  ?
  ?&  =(our owner.s)  (bounded-text:att project.s 128)
      (gth generation.s 0)  (lte (met 0 generation.s) 64)
      (name-valid:provider provider-key.s)  (selection-valid:provider selection.s)
      !=('unknown' model.selection.s)  !=('model-unreported' model.selection.s)
  ==
++  configure
  |=  [our=@p held=state scope=scope:local]
  ^-  (each state @tas)
  ?.  (scope-valid our scope)  [%| %local-review-scope-invalid]
  =/  prior  (~(get by scopes.held) project.scope)
  ?:  =(`scope prior)  [%& held]
  ?.  ?~(prior (lth ~(wyt by scopes.held) 64) (gth generation.scope generation.u.prior))
    [%| %local-review-scope-generation]
  [%& held(scopes (~(put by scopes.held) project.scope scope))]
++  active
  |=  [held=state r=request:local]
  ^-  ?
  &(enabled.scope.r =(`scope.r (~(get by scopes.held) project.scope.r)))
++  expected
  |=  c=campaign
  ^-  request:local
  ?~  challenge.c  request.c
  request.c(mode %resolve, prior challenge.c)
++  begin
  |=  [our=@p at=@da held=state r=request:local]
  ^-  (each change @tas)
  =/  id=@ux  id.candidate.frozen.r
  =/  prior  (~(get by campaigns.held) id)
  ?^  prior
    ?:  =(r request.u.prior)  [%& [held ~]]
    [%| %local-review-candidate-already-bound]
  ?.  &(=(%challenge mode.r) ?=(~ prior.r) (active held r))
    [%| %local-review-scope-unavailable]
  ?.  (lth ~(wyt by campaigns.held) 64)  [%| %local-review-capacity]
  =/  req  (inference:local our r)
  ?:  ?=(%| -.req)  [%| p.req]
  =/  c=campaign  [r at ~ ~ `id.p.req ~ ~ ~ 0 ~]
  [%& [held(campaigns (~(put by campaigns.held) id c)) `[provider-key.scope.r p.req]]]
++  receive
  ::  The owner must read the provider canonically before supplying a reading.
  |=  [our=@p held=state id=@ux job=@ux got=reading]
  ^-  change
  =/  found  (~(get by campaigns.held) id)
  ?~  found  [held ~]
  =/  c=campaign  u.found
  ?.  &(?=(~ outcome.c) =(`job pending.c))  [held ~]
  ?.  (active held request.c)
    [held(campaigns (~(put by campaigns.held) id c(pending ~, reason `%local-review-scope-revoked))) ~]
  ?:  ?=(%pending -.got)  [held ~]
  ?:  ?=(%unknown -.got)
    [held(campaigns (~(put by campaigns.held) id c(reason `reason.got))) ~]
  ?:  ?=(%failed -.got)
    ?.  (failure-valid (expected c) attempt.c error.got)
      [held(campaigns (~(put by campaigns.held) id c(reason `%local-review-failure-invalid))) ~]
    =.  c  c(pending ~, reason `%local-review-provider-failed, failures (weld failures.c ~[error.got]))
    [held(campaigns (~(put by campaigns.held) id c)) ~]
  ?.  &((compact-valid:att our value.got) =(job job.value.got))
    [held(campaigns (~(put by campaigns.held) id c(reason `%local-review-receipt-invalid))) ~]
  =/  r=request:local  (expected c)
  =/  judged  (confirmed-at:local our r attempt.c value.got)
  ?:  ?=(%| -.judged)
    ::  Keep the actual authenticated reply even when it cannot be parsed as
    ::  a review. Only an explicit ++retry calls again, and only if ++unusable.
    [held(campaigns (~(put by campaigns.held) id c(pending ~, reason `p.judged, rejected `value.got))) ~]
  =.  c  c(pending ~, reason ~)
  ?:  =(%resolve mode.r)
    [held(campaigns (~(put by campaigns.held) id c(resolution `value.got, outcome `p.judged))) ~]
  =.  c  c(challenge `value.got)
  ?:  =(%refuse kind.p.judged)
    [held(campaigns (~(put by campaigns.held) id c(outcome `p.judged))) ~]
  =/  next  (inference-at:local our (expected c) attempt.c)
  ?:  ?=(%| -.next)
    [held(campaigns (~(put by campaigns.held) id c(reason `p.next))) ~]
  =.  c  c(pending `id.p.next)
  [held(campaigns (~(put by campaigns.held) id c)) `[provider-key.scope.r p.next]]
++  find-job
  |=  [held=state job=@ux session=@ux]
  ^-  (unit @ux)
  =/  rows  ~(tap by campaigns.held)
  |-  ^-  (unit @ux)
  ?~  rows  ~
  =/  [id=@ux c=campaign]  i.rows
  ?:  &(!=(0 job) =(session session.request.c) =(`job pending.c))  `id
  $(rows t.rows)
++  valid
  |=  [our=@p held=state]
  ^-  ?
  ?&  (lte ~(wyt by scopes.held) 64)  (lte ~(wyt by campaigns.held) 64)
      (levy ~(tap by scopes.held) |=([key=@t s=scope:local] &(=(key project.s) (scope-valid our s))))
      %+  levy  ~(tap by campaigns.held)
      |=  [id=@ux c=campaign]
      ?&  =(id id.candidate.frozen.request.c)  !=(0 started.c)
          =(%challenge mode.request.c)  ?=(~ prior.request.c)
          (valid:local our request.c)  (history-valid c)
          ?~  rejected.c  %.y
          ?&  ?=(~ pending.c)  ?=(~ outcome.c)  ?=(~ resolution.c)
              (compact-valid:att our u.rejected.c)
              =((identity-at:local (expected c) attempt.c) job.u.rejected.c)
              =/  refused  (confirmed-at:local our (expected c) attempt.c u.rejected.c)
              &(?=(%| -.refused) =(reason.c `p.refused))
          ==
          ?~  challenge.c
            &(?=(~ resolution.c) ?=(~ outcome.c) ?~(pending.c ?=(^ reason.c) =(u.pending.c (identity-at:local request.c attempt.c))))
          =/  first  (confirmed-at:local our request.c (challenge-attempt c) u.challenge.c)
          ?&  ?=(%& -.first)
              ?:  =(%refuse kind.p.first)
                &(=(outcome.c `p.first) ?=(~ pending.c) ?=(~ resolution.c))
              ?~  resolution.c
                &(?=(~ outcome.c) ?~(pending.c ?=(^ reason.c) =(u.pending.c (identity-at:local (expected c) attempt.c))))
              =/  second  (confirmed-at:local our (expected c) attempt.c u.resolution.c)
              &(?=(%& -.second) =(outcome.c `p.second) ?=(~ pending.c))
          ==
      ==
  ==
--
