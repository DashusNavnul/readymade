::  /lib/model-entropy.hoon
::
::  Pure Hoon reduction of Ollama selected-token natural log probabilities.
::  Ollama reports `logprob = ln(p_selected)` per generated token.  This module
::  parses those raw JSON numbers (including scientific notation), converts
::  `-ln(p_selected)` to the Pataphor 1.000.000 fixed scale, and computes the
::  population mean and variance.  No inference telemetry is interpreted
::  earthside.
::
|%
+$  entropy-stats
  $:  valid=?
      complete=?
      tokens=@ud
      mean=@ud
      variance=@ud
      surprisals=(list @ud)
  ==
+$  decimal
  $:  coefficient=@ud
      fractional-digits=@ud
      exponent-negative=?
      exponent=@ud
  ==
++  scale  1.000.000
++  surprisal-cap  64.000.000
++  max-decimal-digits  24
++  max-exponent  18
::
++  empty-entropy
  ^-  entropy-stats
  [%.n %.n 0 0 0 ~]
::
++  object-field
  |=  [jon=json key=@t]
  ^-  (unit json)
  ?.  ?=(%o -.jon)  ~
  (~(get by p.jon) key)
::
++  bool-field
  |=  [jon=json key=@t]
  ^-  (unit ?)
  =/  val=(unit json)  (object-field jon key)
  ?~  val  ~
  ?.  ?=(%b -.u.val)  ~
  `p.u.val
::
++  pow-ten
  |=  exponent=@ud
  ^-  @ud
  =/  product=@ud  1
  |-
  ?:  =(0 exponent)  product
  $(exponent (dec exponent), product (mul product 10))
::
::  JSON number -> abs(value) at 1e6.  Positive nonzero input is rejected:
::  a selected-token log probability must be <= 0.  Division rounds half-up.
++  parse-surprisal
  |=  raw=@t
  ^-  (unit @ud)
  =/  source=tape  (trip raw)
  ?~  source  ~
  =/  negative=?  =(45 i.source)
  =/  chars=tape  ?:(negative t.source source)
  =/  parsed=(unit decimal)
    =/  phase=@tas  %whole
    =/  coefficient=@ud  0
    =/  fractional-digits=@ud  0
    =/  digits=@ud  0
    =/  exponent-negative=?  %.n
    =/  exponent=@ud  0
    =/  exponent-digits=@ud  0
    |-
    ?~  chars
      ?.  ?&  (gth digits 0)
              ?:(=(%fraction phase) (gth fractional-digits 0) %.y)
              ?:(=(%exponent phase) (gth exponent-digits 0) %.y)
          ==
        ~
      `[coefficient fractional-digits exponent-negative exponent]
    =/  char=@tD  i.chars
    ?:  ?&((gte char 48) (lte char 57))
      =/  digit=@ud  `@ud`(sub char 48)
      ?:  =(%exponent phase)
        ?:  (gte exponent-digits 2)  ~
        =/  exponent-next=@ud  (add (mul exponent 10) digit)
        ?:  (gth exponent-next max-exponent)  ~
        $(chars t.chars, exponent exponent-next, exponent-digits +(exponent-digits))
      ?:  (gte digits max-decimal-digits)  ~
      %=  $
        chars  t.chars
        coefficient  (add (mul coefficient 10) digit)
        fractional-digits  ?:(=(%fraction phase) +(fractional-digits) fractional-digits)
        digits  +(digits)
      ==
    ?:  =(46 char)
      ?.  ?&(=(%whole phase) (gth digits 0))  ~
      $(chars t.chars, phase %fraction)
    ?:  ?|  =(101 char)
            =(69 char)
        ==
      ?.  ?&  ?|  =(%whole phase)
                  =(%fraction phase)
              ==
              (gth digits 0)
              ?:(=(%fraction phase) (gth fractional-digits 0) %.y)
          ==
        ~
      $(chars t.chars, phase %exponent)
    ?:  ?&  =(%exponent phase)
            =(0 exponent-digits)
            ?|  =(43 char)
                =(45 char)
            ==
        ==
      $(chars t.chars, exponent-negative =(45 char))
    ~
  ?~  parsed  ~
  ?.  ?|(negative =(0 coefficient.u.parsed))  ~
  =/  left-power=@ud
    (add 6 ?:(exponent-negative.u.parsed 0 exponent.u.parsed))
  =/  right-power=@ud
    (add fractional-digits.u.parsed ?:(exponent-negative.u.parsed exponent.u.parsed 0))
  =/  scaled=@ud
    ?:  (gte left-power right-power)
      (mul coefficient.u.parsed (pow-ten (sub left-power right-power)))
    =/  divisor=@ud  (pow-ten (sub right-power left-power))
    (div (add coefficient.u.parsed (div divisor 2)) divisor)
  `(min scaled surprisal-cap)
::
++  token-surprisal
  |=  item=json
  ^-  (unit @ud)
  ?.  ?=(%o -.item)  ~
  =/  raw=(unit json)  (~(get by p.item) 'logprob')
  ?~  raw  ~
  ?+  -.u.raw  ~
    %n  (parse-surprisal p.u.raw)
    %s  (parse-surprisal p.u.raw)
  ==
::
++  sum-values
  |=  values=(list @ud)
  ^-  @ud
  =/  total=@ud  0
  |-
  ?~  values  total
  $(values t.values, total (add total i.values))
::
++  squared-deviation-total
  |=  [values=(list @ud) average=@ud]
  ^-  @ud
  =/  total=@ud  0
  |-
  ?~  values  total
  =/  delta=@ud
    ?:((gte i.values average) (sub i.values average) (sub average i.values))
  $(values t.values, total (add total (div (mul delta delta) scale)))
::
++  summarize
  |=  [values=(list @ud) complete=?]
  ^-  entropy-stats
  =/  count=@ud  (lent values)
  ?:  =(0 count)  empty-entropy
  =/  total=@ud  (sum-values values)
  =/  average=@ud  (div total count)
  =/  squared-total=@ud  (squared-deviation-total values average)
  [%.y complete count average (div squared-total count) values]
::
++  entropy-from-logprobs
  |=  [items=(list json) complete=?]
  ^-  entropy-stats
  =/  values=(list @ud)  ~
  =/  remaining=(list json)  items
  |-
  ?~  remaining  (summarize (flop values) complete)
  =/  value=(unit @ud)  (token-surprisal i.remaining)
  ?~  value  empty-entropy
  $(remaining t.remaining, values [u.value values])
::
++  entropy-from-metadata
  |=  metadata=@t
  ^-  entropy-stats
  =/  parsed=(unit json)  (de:json:html metadata)
  ?~  parsed  empty-entropy
  =/  logprobs=(unit json)  (object-field u.parsed 'logprobs')
  ?~  logprobs  empty-entropy
  ?.  ?=(%a -.u.logprobs)  empty-entropy
  =/  truncated=(unit ?)  (bool-field u.parsed 'logprobs_truncated')
  =/  complete=?  ?~(truncated %.n =(%.n u.truncated))
  (entropy-from-logprobs p.u.logprobs complete)
--
