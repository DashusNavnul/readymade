::  Owner-only composer snapshots. No submission or execution authority here.
/-  pc=pataphor-chat
/+  c=readymade-compose
|%
+$  snapshot
  $%  $:  %readymade-compose-control-v1  nonce=@uv  epoch=@ta
          active=(unit @ud)  next=@ud  max-bytes=@ud  count=@ud  capacity=@ud
      ==
      [%readymade-submission-v1 id=@uv reply=(unit receipt:c)]
  ==
++  route
  |=  pax=path
  ^-  (unit @uv)
  ?.  ?=([%conversation %submission @ ~] pax)  ~
  ?.  (lte (met 3 i.t.t.pax) 64)  ~
  =/  parsed=(unit @uv)  (slaw %uv i.t.t.pax)
  ?~  parsed  ~
  ?.  ?&  (gth u.parsed 0)  (lte (met 0 u.parsed) 128)
          =(i.t.t.pax (scot %uv u.parsed))
      ==  ~
  parsed
++  project
  |=  [pax=path chat=state-0:pc receipts=ledger:c]
  ^-  (unit snapshot)
  ?:  =(/conversation/compose pax)
    `[%readymade-compose-control-v1 nonce.chat epoch.chat active.chat next.chat 4.096 ~(wyt by receipts) capacity:c]
  =/  id=(unit @uv)  (route pax)
  ?~  id  ~
  =/  record=(unit stored:c)  (~(get by receipts) u.id)
  `[%readymade-submission-v1 u.id ?~(record ~ `reply.u.record)]
++  facts
  |=  [b=bowl:gall chat=state-0:pc receipts=ledger:c]
  ^-  (list card:agent:gall)
  =/  paths=(list path)
    %+  murn  ~(val by sup.b)
    |=  [who=@p pax=path]
    ^-  (unit path)
    ?.  =(our.b who)  ~
    ?.  |(=(/conversation/compose pax) ?=(^ (route pax)))  ~
    `pax
  %+  turn  ~(tap in (silt paths))
  |=  pax=path
  =/  value=(unit snapshot)  (project pax chat receipts)
  ?>  ?=(^ value)
  [%give %fact ~[pax] %noun !>(u.value)]
++  spoke
  |=  [b=bowl:gall before=state-0:pc after=state-0:pc old=ledger:c next=ledger:c]
  ^-  (list card:agent:gall)
  =/  previous  [nonce.before epoch.before active.before next.before old]
  =/  current  [nonce.after epoch.after active.after next.after next]
  ?:  =(previous current)  ~
  (facts b after next)
--
