::  Pure prepared-context and approval plans. No fact here attests itself.
::  Plans require an owner-originated call and canonical attribution at use.
/-  vc=vibecoding-candidate, cs=vibecoding-check-spec, itn=intent
/+  vcl=vibecoding-candidate, checks=vibecoding-check-spec,
    project=vibecoding-project-read
|%
+$  command
  $%  [%prepare id=@tas]
      [%approve key=@ux specification=specification:cs]
  ==
+$  preparation  [context=context:vc retained=?]
+$  approval-plan  [approval=approval:cs retained=?]
++  fact
  |=  c=context:vc
  [%vibecoding-prepared-context (scot %ux (digest:vcl c)) c]
++  history-full
  ::  Graf holds many unrelated domains. Bound this owner's coding history,
  ::  while selection still inspects every row for late conflicts.
  |=  [our=@p rows=(list attested:cs)]
  ^-  ?
  =/  relevant
    %+  skim  rows
    |=  row=attested:cs
    ?.  (~(has in ships.row) our)  %.n
    ?=([?(%vibecoding-prepared-context %vibecoding-check-approval) *] fact.row)
  (gte (lent relevant) 256)
++  contexts
  |=  [our=@p at=@da rows=(list attested:cs)]
  ^-  (each (list context:vc) @tas)
  =/  found=(list context:vc)  ~
  |-  ^-  (each (list context:vc) @tas)
  ?~  rows  [%& (flop found)]
  =/  row=attested:cs  i.rows
  ?.  (~(has in ships.row) our)  $(rows t.rows)
  =/  tag  ((soft ,[@tas *]) fact.row)
  ?~  tag  $(rows t.rows)
  ?.  =(%vibecoding-prepared-context -.u.tag)  $(rows t.rows)
  =/  item  ((soft ,[%vibecoding-prepared-context key=@t context=context:vc]) fact.row)
  ?~  item  [%| %context-malformed]
  =/  c=context:vc  context.u.item
  ?.  &((current-context-valid:vcl c) =(fact.row (fact c)) =(our by.intent.intent.c) (lte at.c at))
    [%| %context-malformed]
  $(rows t.rows, found [c found])
++  for-intent
  |=  [our=@p at=@da id=@tas rows=(list attested:cs)]
  ^-  (each (unit context:vc) @tas)
  =/  all  (contexts our at rows)
  ?:  ?=(%| -.all)  [%| p.all]
  =/  found  (skim p.all |=(c=context:vc =(id id.intent.intent.c)))
  ?~  found  [%& ~]
  ?.  ?=([* ~] found)  [%| %context-conflict]
  [%& `i.found]
++  find
  |=  [our=@p actor=@p at=@da key=@ux rows=(list attested:cs)]
  ^-  (each context:vc @tas)
  ?.  =(our actor)  [%| %foreign-actor]
  ?.  (hash-valid:checks key)  [%| %context-key-invalid]
  =/  all  (contexts our at rows)
  ?:  ?=(%| -.all)  [%| p.all]
  =/  found  (skim p.all |=(c=context:vc =(key (digest:vcl c))))
  ?~  found  [%| %context-missing]
  ?.  ?=([* ~] found)  [%| %context-conflict]
  =/  c=context:vc  i.found
  =/  unique  (for-intent our at id.intent.intent.c rows)
  ?.  =([%& `c] unique)  [%| %context-conflict]
  [%& c]
++  fresh
  |=  [our=@p at=@da c=context:vc intent=(unit record:itn) baseline=(unit snapshot:project) law=@ux]
  ^-  ?
  ?&  (current-context-valid:vcl c)  =(our by.intent.intent.c)
      (lte at.c at)  =(`intent.c intent)
      (matches:project c baseline)  =(law.c law)
  ==
++  prepare
  |=  [our=@p actor=@p at=@da intent=record:itn baseline=snapshot:project law=@ux rows=(list attested:cs)]
  ^-  (each preparation @tas)
  ?.  =(our actor)  [%| %foreign-actor]
  =/  c=context:vc
    [%vibecoding-candidate-packet-v1 intent base.baseline work.baseline source.baseline preserved.baseline law at]
  ?.  (fresh our at c `intent `baseline law)  [%| %context-invalid]
  =/  prior  (for-intent our at id.intent.intent.c rows)
  ?:  ?=(%| -.prior)  [%| p.prior]
  ?~  p.prior
    ?:  (history-full our rows)  [%| %context-history-full]
    [%& [c %.n]]
  =/  old=context:vc  u.p.prior
  ?.  =(old c(at at.old))  [%| %context-changed]
  [%& [old %.y]]
++  approval-for
  |=  [our=@p at=@da key=@ux rows=(list attested:cs)]
  ^-  (each (unit approval:cs) @tas)
  =/  scan=(list attested:cs)  rows
  |-  ^-  (each (unit approval:cs) @tas)
  ?~  scan  [%& ~]
  =/  row=attested:cs  i.scan
  ?.  (~(has in ships.row) our)  $(scan t.scan)
  =/  tag  ((soft ,[@tas *]) fact.row)
  ?~  tag  $(scan t.scan)
  ?.  =(%vibecoding-check-approval -.u.tag)  $(scan t.scan)
  =/  item  ((soft ,[%vibecoding-check-approval key=@t approval=approval:cs]) fact.row)
  ?~  item  [%| %approval-malformed]
  =/  a=approval:cs  approval.u.item
  ?.  =(key context.a)  $(scan t.scan)
  =/  selected  (select:checks our at at key (digest:vcl a) rows)
  ?:  ?=(%| -.selected)  [%| p.selected]
  [%& `p.selected]
++  approve
  |=  [our=@p actor=@p at=@da c=context:vc spec=specification:cs rows=(list attested:cs)]
  ^-  (each approval-plan @tas)
  ?.  =(our actor)  [%| %foreign-actor]
  ?.  &((current-context-valid:vcl c) =(our by.intent.intent.c) (lte at.c at))
    [%| %context-invalid]
  ?.  (valid:checks spec)  [%| %specification-invalid]
  ?.  =([%& c] (find our actor at (digest:vcl c) rows))
    [%| %context-not-retained]
  =/  prior  (approval-for our at (digest:vcl c) rows)
  ?:  ?=(%| -.prior)  [%| p.prior]
  ?~  p.prior
    ?:  (history-full our rows)  [%| %context-history-full]
    [%& [[%vibecoding-check-approval-v1 our (digest:vcl c) spec at] %.n]]
  =/  old=approval:cs  u.p.prior
  ?.  =(spec specification.old)  [%| %approval-conflict]
  ?.  (lte at.c at.old)  [%| %approval-before-context]
  [%& [old %.y]]
--
