::  Pure metadata only. Callers supply canonical package/pact and authenticate
::  sender. No law, owner approval, functional-test or execution authority here.
/-  a=readymade-artifact-collab, p=readymade-pact, pkg=readymade-package,
    r=readymade-artifact-round
/+  pact=readymade-pact, round=readymade-artifact-round,
    package=readymade-package, build=readymade-package-build
|%
++  empty
  ^-  state:a
  [%readymade-artifact-collab-v1 ~ ~ ~]
++  fingerprint
  |=  [sender=@p payload=payload:a]
  ^-  @ux
  (shax (jam [%readymade-artifact-request-v2 sender payload]))
++  envelope
  ::  Canonical content-addressed IDs prevent arbitrary ID reuse even when
  ::  close/revoke must bypass a full replay cache. Owner counters still apply.
  |=  [sender=@p payload=payload:a]
  ^-  envelope:a
  [%readymade-collab-wire-v2 (scot %ux (fingerprint sender payload)) payload]
++  route
  ::  Runtime entry points require an exact pact route. Preserve the legacy
  ::  unqualified payload only for existing explicit-context pure callers.
  |=  e=envelope:a
  ^-  (unit @ux)
  =/  id=(unit @ux)
    ?-  -.payload.e
      %build-evidence  ~
      %build-evidence-for  `pact.payload.e
      %artifact  `pact.payload.e
      %revoke  `terms-digest.move.payload.e
    ==
  ?~  id  ~
  ?:((digest-valid:package u.id) id ~)
++  context-valid
  |=  [our=@p actor=@p current=state:p source=state:pkg]
  ^-  ?
  =/  terms=terms:p  terms.current
  =/  offer=offer:pkg  offer.source
  ?&  (valid-terms:pact terms)
      (valid:package offer)
      =(package.terms digest.offer)
      =(graf-root.terms graf-root.body.offer)
      |(=(our left.terms) =(our right.terms))
      |(=(actor left.terms) =(actor right.terms))
      ?|  &(=(sender.body.offer left.terms) =(recipient.body.offer right.terms))
          &(=(sender.body.offer right.terms) =(recipient.body.offer left.terms))
      ==
  ==
++  receipt-valid
  |=  [source=state:pkg builder=@p receipt=receipt:build]
  ^-  ?
  ?&  =(builder recipient.body.offer.source)
      (valid:build builder receipt)
      =(offer.source offer.plan.body.receipt)
      =(manifest.body.receipt (manifest:package files.body.offer.source))
  ==
++  local-valid
  ::  Source/result must be read from our canonical saved package, not wire.
  |=  [our=@p source=state:pkg receipt=receipt:build]
  ^-  ?
  ?.  &((receipt-valid source our receipt) =(%built stage.source))  %.n
  ?~  result.source  %.n
  =/  result=result:pkg  u.result.source
  =/  plan=plan:build  plan.body.receipt
  ?&  =(inspection.source `(inspection-digest:package offer.source))
      =(destination.source `destination.plan)
      =(consent.source `consent.plan)
      =(offer.result digest.offer.source)
      =(consent.result consent.plan)
      =(source.result source.body.offer.source)
      =(manifest.result manifest.body.receipt)
      success.result
      =(artifact.result `artifact.body.receipt)
      =(proof.result proof.receipt)
  ==
++  record-local
  ::  Explicit local-only API. Wire payload cannot select this provenance.
  |=  [s=state:a our=@p current=state:p source=state:pkg receipt=receipt:build]
  ^-  change:a
  ?.  &((context-valid our our current source) (local-valid our source receipt))
    [s current | | %local-receipt-refused]
  =/  entry=evidence:a  [our %local-canonical receipt]
  =/  prior=(unit evidence:a)  (~(get by evidence.s) proof.receipt)
  ?^  prior
    ?:  =(u.prior entry)  [s current & & %duplicate]
    [s current | | %evidence-conflict]
  ?:  (gte ~(wyt by evidence.s) 256)  [s current | | %evidence-capacity]
  [s(evidence (~(put by evidence.s) proof.receipt entry)) current & | %recorded]
++  proposal-bound
  |=  [s=state:a current=state:p source=state:pkg purpose=purpose:p candidate=proposal:r]
  ^-  ?
  ?.  (valid-proposal:round current purpose candidate)  %.n
  =/  held=(unit evidence:a)  (~(get by evidence.s) build-proof.candidate)
  ?~  held  %.n
  =/  receipt=receipt:build  receipt.u.held
  ?&  (receipt-valid source builder.u.held receipt)
      =(build-proof.candidate proof.receipt)
      =(artifact.candidate artifact.body.receipt)
      =(package.candidate digest.offer.source)
      =(scope.candidate scope.terms.current)
  ==
++  admitted
  |=  [s=state:a current=state:p sender=@p e=envelope:a]
  ^-  change:a
  ?:  (gte ~(wyt by requests.s) 4.096)  [s current & | %accepted]
  [s(requests (~(put by requests.s) [sender request.e] (fingerprint sender payload.e))) current & | %accepted]
++  receive-evidence
  ::  Shared tail after receive authenticates context, identity and capacity.
  |=  [s=state:a our=@p sender=@p current=state:p source=state:pkg e=envelope:a receipt=receipt:build]
  ^-  change:a
  ?.  &(!=(our sender) (receipt-valid source sender receipt))
    [s current | | %peer-receipt-refused]
  =/  entry=evidence:a  [sender %peer-assertion receipt]
  =/  held=(unit evidence:a)  (~(get by evidence.s) proof.receipt)
  ?^  held
    ?.  =(entry u.held)  [s current | | %evidence-conflict]
    (admitted s current sender e)
  ?:  (gte ~(wyt by evidence.s) 256)  [s current | | %evidence-capacity]
  (admitted s(evidence (~(put by evidence.s) proof.receipt entry)) current sender e)
++  receive
  ::  Pure reducer only. Local ack creation needs separate native current-law
  ::  and explicit-owner approval; peer ack evidence grants nothing locally.
  |=  [s=state:a our=@p sender=@p current=state:p source=state:pkg e=envelope:a]
  ^-  change:a
  ?.  (context-valid our sender current source)  [s current | | %context]
  =/  routed=(unit @ux)  (route e)
  ?.  ?~(routed %.y =(u.routed (digest:pact terms.current)))
    [s current | | %pact-binding]
  ?.  ?:(?=(%build-evidence-for -.payload.e) (active:pact current) %.y)
    [s current | | %inactive-pact]
  ?.  &((lte (met 3 (jam e)) 131.072) =(e (envelope sender payload.e)))
    [s current | | %request-identity]
  =/  prior=(unit @ux)  (~(get by requests.s) [sender request.e])
  ?^  prior
    ?:  =(u.prior (fingerprint sender payload.e))  [s current & & %duplicate]
    [s current | | %request-conflict]
  =/  closing=?
    ?+  -.payload.e  %.n
      %revoke  %.y
      %artifact  ?=(%close -.action.move.payload.e)
    ==
  ?:  &((gte ~(wyt by requests.s) 4.096) !closing)
    [s current | | %request-capacity]
  ?-  -.payload.e
    %build-evidence
      (receive-evidence s our sender current source e receipt.payload.e)
    %build-evidence-for
      ?.  =(pact.payload.e (digest:pact terms.current))  [s current | | %pact-binding]
      (receive-evidence s our sender current source e receipt.payload.e)
    %revoke
      ?.  ?=(%revoke -.action.move.payload.e)  [s current | | %revoke-required]
      =/  next=(unit state:p)  (step:pact current sender move.payload.e)
      ?~  next  [s current | | %revoke-refused]
      ::  Retain historical rounds/counters. Their generation now fails valid.
      (admitted s u.next sender e)
    %artifact
      ?.  =(pact.payload.e (digest:pact terms.current))  [s current | | %pact-binding]
      =/  key=key:a  [pact.payload.e generation.current purpose.payload.e]
      =/  old=(unit state:r)  (~(get by rounds.s) key)
      ?:  &(?=(~ old) (gte ~(wyt by rounds.s) 256))
        [s current | | %round-capacity]
      =/  initial=(unit state:r)
        ?~(old (init:round current purpose.payload.e) old)
      ?~  initial  [s current | | %inactive-pact]
      ?~  old
        ?.  ?=(%propose -.action.move.payload.e)  [s current | | %proposal-required]
        =/  candidate=proposal:r  proposal.action.move.payload.e
        ?.  (proposal-bound s current source purpose.payload.e candidate)
          [s current | | %build-binding]
        =/  next=(unit state:r)  (step:round u.initial current sender move.payload.e)
        ?~  next  [s current | | %round-refused]
        (admitted s(rounds (~(put by rounds.s) key u.next)) current sender e)
      =/  held=state:r  u.old
      ?:  ?=(%propose -.action.move.payload.e)
        ?.  (proposal-bound s current source purpose.payload.e proposal.action.move.payload.e)
          [s current | | %build-binding]
        =/  next=(unit state:r)  (step:round held current sender move.payload.e)
        ?~  next  [s current | | %round-refused]
        (admitted s(rounds (~(put by rounds.s) key u.next)) current sender e)
      =/  next=(unit state:r)  (step:round held current sender move.payload.e)
      ?~  next  [s current | | %round-refused]
      (admitted s(rounds (~(put by rounds.s) key u.next)) current sender e)
  ==
--
