::  /lib/escalate.hoon
::
::  WHAT TO DO WHEN AN ANSWER DOES NOT SETTLE IT.
::
::  satisfy returns three verdicts and the third is the interesting
::  one: %unclear is not a soft failure, it is the honest reading of a
::  turn that neither did the thing nor demonstrably failed.  A 135M
::  model will produce a lot of them.  This lib decides what happens
::  next, and it is pure so the decision can be replayed and argued
::  with rather than discovered in a log.
::
::  THE SHAPE OF THE ANSWER IS: TRY DIFFERENTLY, THEN STOP.
::
::  Retrying the SAME want is worthless -- greedy decode over pinned
::  weights is a pure function, so an identical ask returns an
::  identical answer, forever.  That is not a limitation; it is the
::  whole design.  So a retry must CHANGE something real (more
::  evidence, a narrower task) or it is not a retry, it is a loop.
::
::  HOW MANY ATTEMPTS IS NOT A LIBRARY DEFAULT.  The caller must supply
::  the explicit Viki/Bride policy that governs this goal.
::
/-  gol=goal
/+  satisfy
|%
::  what has happened to this step so far.
+$  history
  $:  attempts=@ud                    ::  wants already spent on it
      last=(unit verdict:satisfy)     ::  the most recent verdict
      refs-seen=@ud                   ::  evidence pinned last time
      refs-available=@ud              ::  evidence that existed
  ==
::
+$  policy  [max-attempts=@ud]
+$  policy-action  $%([%disable ~] [%set rule=policy])
+$  next-move
  $%  [%retry-with-more-evidence ~]   ::  same task, wider refs
      [%retry-narrower ~]             ::  same evidence, smaller task
      [%accept ~]                     ::  good enough; move on
      [%park why=reason:gol]          ::  stop, and tell the operator
  ==
::
::  A configured policy must authorize at least one total attempt.  Keeping
::  this check here gives every caller the same interpretation of zero:
::  disabled/invalid, never an accidental one-shot retry policy.
++  valid
  |=  p=policy
  ^-  ?
  (gth max-attempts.p 0)
::
::  THE DECISION.
++  next
  |=  [p=policy h=history]
  ^-  next-move
  ::  Zero is invalid policy, not permission to loop once.
  ?:  =(0 max-attempts.p)  [%park %budget]
  ::  a step that has never run is not escalating; it is starting.
  ?~  last.h  [%retry-with-more-evidence ~]
  ?-  -.u.last.h
    ::  it did the thing.
    %pass  [%accept ~]
    ::
    ::  A DEMONSTRABLE FAILURE IS NOT A PUZZLE.  The model was given
    ::  what it needed and produced the wrong thing; more evidence
    ::  will not fix a wrong answer, and pretending otherwise burns
    ::  the budget on hope.  Park it and say why.
    %fail  [%park %unsatisfied]
    ::
    %unclear
      ::  out of attempts: stop.  Parking is not failure -- it is the
      ::  familiar declining to spend more of the ship on a question it
      ::  cannot close, and handing it to the one principal who can.
      ?:  (gte attempts.h max-attempts.p)  [%park %unclear]
      ::  TRUNCATED is a failure of the LAW that bounded the turn, not
      ::  of the model.  Re-asking with the same ceiling would truncate
      ::  identically -- pure function -- so narrow the task instead.
      ?:  =(%truncated why.u.last.h)  [%retry-narrower ~]
      ::  there is evidence it has not seen: that is a real change, so
      ::  the retry is a different question rather than the same one.
      ?:  (gth refs-available.h refs-seen.h)  [%retry-with-more-evidence ~]
      ::  nothing new to show it and nothing left to narrow.  Asking
      ::  again would be asking the identical question.
      [%park %unclear]
  ==
::
::  does this move spend a want?  Parking and accepting do not --
::  which is what keeps a stuck goal from draining the familiar's
::  budget forever.
++  spends
  |=  m=next-move
  ^-  ?
  ?|  ?=(%retry-with-more-evidence -.m)
      ?=(%retry-narrower -.m)
  ==
--
