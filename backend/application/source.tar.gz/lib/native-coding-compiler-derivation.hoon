::  Owner derivation from an exact retained native compiler result.
::  Provenance records a data transformation, never source certification.
/-  nc=native-coding
/+  attachment=native-coding-compiler-attachment,
    runtime=native-coding-compiler-attachment-runtime,
    compiler=native-coding-compiler, exports=native-coding-compiler-exports,
    modules=native-coding-module-sources, decoder=native-coding-compiler-artifact,
    tools=cantrip-native-coding
|%
+$  reference  [job=@ux input=@ux receipt=@ux binding=@t child=@ux]
+$  organ
  [%native-coding-compiler-derivation-state-v1 records=(map @ux reference)]
+$  change  [state=organ attachments=organ:runtime]
+$  command  [%native-coding-compiler-derive-v1 job=@ux role=role:attachment]
++  capacity  8
++  empty  `organ`[%native-coding-compiler-derivation-state-v1 ~]
++  candidate
  ::  Sources are the producing JOB inputs, not its compiler's own manifest.
  |=  [r=retained:runtime role=role:attachment]
  ^-  (each attachment:attachment @tas)
  ?.  (retained-valid:runtime (key:tools request.input.r) r)
    [%| %compiler-derivation-producer-invalid]
  =/  out=result:attachment  output.r
  ?.  ?=(%& -.out)  [%| %compiler-derivation-producer-refused]
  =/  named  (inputs:exports input.r selection.r)
  ?:  ?=(%| -.named)  [%| p.named]
  =/  name=@t
    ?:(=(%checked-exports role) 'Runtime.NativeCodingCompiler.compile_checked_exports' 'Runtime.NativeCodingCompiler.compile_compiler_exports')
  =/  matches=(list binding:decoder)
    (skim bindings.p.out |=(b=binding:decoder =(name name.b)))
  ?.  =(1 (lent matches))  [%| %compiler-derivation-binding-missing]
  =/  selected=binding:decoder  (snag 0 matches)
  =/  entry=plan:decoder  artifact.selected
  ?.  (entry-valid:attachment entry)  [%| %compiler-derivation-entry-refused]
  =/  witnesses=(list witness:compiler)
    %+  turn  p.named
    |=  v=mapped:modules
    [module.v (rev 3 32 (shax text.source.v)) text.source.v]
  =/  child=attachment:attachment
    [%native-coding-compiler-attachment-v1 role witnesses (source-id:attachment witnesses) name entry (shax (jam entry)) 0x0]
  =.  child  child(digest (identity:attachment child))
  ?.  (valid:attachment child)  [%| %compiler-derivation-child-refused]
  [%& child]
++  reference-of
  |=  [job=@ux r=retained:runtime child=attachment:attachment]
  ^-  reference
  [job (identity:compiler input.r) (shax (jam r)) entry-name.child digest.child]
++  completed
  |=  [jobs=organ:tools id=@ux r=retained:runtime]
  ^-  ?
  ?.  (linked:runtime jobs id r)  %.n
  =/  job  (~(get by records.jobs) id)
  ?~  job  %.n
  ?.  =(%finished stage.u.job)  %.n
  =/  request=tool-request:nc  request.input.r
  =/  expected=tool-result:nc
    [%native-coding-tool-result-v1 context.request call-id.request (report:runtime r)]
  =(`expected result.u.job)
++  valid
  ::  All history remains meaningful after parent/child/grant revocation.
  ::  Caller also validates the complete attachment and native job organs.
  |=  [our=@p s=organ attachments=organ:runtime jobs=organ:tools]
  ^-  ?
  ?.  (lte ~(wyt by records.s) capacity)  %.n
  %+  levy  ~(tap by records.s)
  |=  [id=@ux ref=reference]
  ?.  =(id child.ref)  %.n
  =/  child  (~(get by attachments.attachments) id)
  =/  producer  (~(get by results.attachments) job.ref)
  ?~  child  %.n
  ?~  producer  %.n
  ?.  &(=(our authority.spec.project.input.u.producer) (completed jobs job.ref u.producer))  %.n
  =/  rebuilt  (candidate u.producer role.u.child)
  ?.  ?=(%& -.rebuilt)  %.n
  &(=(p.rebuilt u.child) =(ref (reference-of job.ref u.producer u.child)))
++  act
  |=  [b=bowl:gall s=organ attachments=organ:runtime jobs=organ:tools c=command]
  ^-  (each change @tas)
  ?.  =(our.b src.b)  [%| %compiler-derivation-owner-required]
  =/  producer  (~(get by results.attachments) job.c)
  ?~  producer  [%| %compiler-derivation-producer-missing]
  =/  r=retained:runtime  u.producer
  ?.  &(=(our.b authority.spec.project.input.r) (completed jobs job.c r))
    [%| %compiler-derivation-producer-unsettled]
  =/  built  (candidate r role.c)
  ?:  ?=(%| -.built)  [%| p.built]
  =/  child=attachment:attachment  p.built
  =/  ref=reference  (reference-of job.c r child)
  =/  prior  (~(get by records.s) digest.child)
  ?^  prior
    ?.  &(=(u.prior ref) =(`child (~(get by attachments.attachments) digest.child)))
      [%| %compiler-derivation-conflict]
    ::  Exact replay observes retained history; it cannot reactivate anything.
    [%& s attachments]
  ?:  (gte ~(wyt by records.s) capacity)  [%| %compiler-derivation-capacity]
  =/  chosen  (lookup:runtime attachments input.r)
  ?~  chosen  [%| %compiler-derivation-selection-missing]
  ?:  ?=(%| -.u.chosen)  [%| p.u.chosen]
  ?.  &(=(selection.r selection.p.u.chosen) =(attachment.r attachment.p.u.chosen))
    [%| %compiler-derivation-selection-mismatch]
  =/  parent  (~(get by attachments.attachments) attachment.r)
  ?~  parent  [%| %compiler-derivation-parent-missing]
  ?.  =(role.r role.u.parent)  [%| %compiler-derivation-parent-role-mismatch]
  =/  exact  (inputs:attachment u.parent input.r selection.r)
  ?:  ?=(%| -.exact)  [%| p.exact]
  =/  admitted
    (act:runtime b attachments jobs [%native-coding-compiler-attachment-admit-v1 child])
  ?:  ?=(%| -.admitted)  [%| p.admitted]
  [%& s(records (~(put by records.s) digest.child ref)) p.admitted]
--
