::  Viki-only review/fleet join. No model result can release a reservation.
::  Import from Viki, not the loop/runtime: those are dependencies of review.
/-  nc=native-coding, nf=native-coding-fleet, vr=glass-moon-route
/+  loop=native-coding-loop, fleet=native-coding-fleet-runtime,
    law=native-coding-fleet, read=native-coding-fleet-read,
    review=native-coding-review, session=native-coding-session,
    accept=native-coding-accept, project=native-coding-project,
    guard=viki-scry-guard, legacy=viki-glass-coding-loop,
    completion=native-coding-completion-runtime, unchanged=native-coding-completion,
    reviewed=native-coding-reviewed-completion
|%
+$  card  card:agent:gall
+$  intent  [session=@ux settlement=settlement:nf]
+$  state  (map @ux intent)
+$  change  [state=state coding=state:loop cards=(list card)]
+$  request  [%native-coding-fleet-progress-v1 session=@ux]
++  valid
  |=  [our=@p s=state]
  ^-  ?
  ?&  (lte ~(wyt by s) 256)
      (levy ~(tap by s) |=([id=@ux i=intent] &(!=(0 id) (lte (met 0 id) 256) =(id task.settlement.i) !=(0 session.i) (lte (met 0 session.i) 256) !=(0 assignment.settlement.i) =(%completed verdict.settlement.i) ?=(^ evidence.settlement.i) (lte (lent evidence.settlement.i) 64))))
  ==
++  progress
  |=  [our=@p id=@ux]
  ^-  card
  (poke:loop our %viki /native-fleet-progress [%native-coding-fleet-progress-v1 id])
++  canonical
  ::  Join the actual retained judgment to its exact current Cantrip record.
  ::  Missing evidence and unknown outcomes produce no transition.
  |=  [b=bowl:gall coding=state:loop reviews=state:review e=entry:session]
  ^-  (each [entry:review record:accept @ux] @tas)
  ?.  &((agent-live:guard our.b now.b %viki) (agent-live:guard our.b now.b %cantrip))
    [%| %fleet-review-unavailable]
  =/  actual=(unit public-session:loop)
    .^((unit public-session:loop) %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/session/(scot %ux id.session.e)/noun)
  ?.  =(actual `(public:loop e))  [%| %fleet-session-not-retained]
  =/  goal  (objective:review e)
  ?:  ?=(%| -.goal)  [%| p.goal]
  =/  judgments=(list record:session)
    (flop (skim records.e |=(r=record:session ?=(%judgment -.body.r))))
  ?~  judgments  [%| %fleet-judgment-missing]
  =/  j=record:session  i.judgments
  ?>  ?=(%judgment -.body.j)
  ?.  =(verdict.body.j ?:(=(%complete phase.e) %complete %continue))
    [%| %fleet-judgment-mismatch]
  =/  matches=(list entry:review)
    %+  skim  ~(val by reviews)
    |=  r=entry:review
    ?&  advanced.r  =(id.session.e session.context.candidate.r)
        =(p.goal objective.r)  ?=(^ observed.r)
        (~(has in (silt evidence.body.j)) ?:(=(%complete phase.e) (digest:accept r) (digest:accept u.observed.r)))
    ==
  ?~  matches  [%| %fleet-review-mismatch]
  ?^  t.matches  [%| %fleet-review-mismatch]
  =/  r=entry:review  i.matches
  =/  retained=(unit entry:review)
    .^((unit entry:review) %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/review/(scot %ux id.candidate.r)/noun)
  ?.  =(retained `r)  [%| %fleet-review-not-retained]
  =/  result=(unit record:accept)
    .^((unit record:accept) %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/candidate/(scot %ux id.candidate.r)/noun)
  ?~  result  [%| %fleet-candidate-missing]
  =/  c=record:accept  u.result
  ?.  &(=(observed.r `c) =(candidate.r candidate.c) =(configuration.e (configuration:project project.c)) (valid:accept (~(put by *ledger:accept) id.candidate.r c)))
    [%| %fleet-candidate-mismatch]
  =/  denied  (grant-error:review our.b now.b c)
  ?^  denied  [%| u.denied]
  =/  current  (current:project our.b now.b project.c)
  ?:  ?=(%| -.current)  [%| p.current]
  ?.  =(working.session.e revision.working.p.current)  [%| %fleet-source-changed]
  ?:  =(%applied stage.c)
    ?.  &(?=(^ decision.r) =(decision.r decision.c) ?=(^ landed.c) =(%approve verdict.u.decision.r) =(working.session.e revision.u.landed.c))
      [%| %fleet-approval-mismatch]
    [%& [r c id.j]]
  ?.  &(=(%ready phase.e) =(%refused stage.c) =(working.session.e source.context.candidate.c))
    [%| %fleet-revision-not-confirmed]
  ?~  decision.c  [%| %fleet-revision-decision-missing]
  ?.  &(=(decision.r decision.c) =(%revise verdict.u.decision.c))
    [%| %fleet-revision-decision-mismatch]
  =/  denied
    ?.  (passed:accept report.u.decision.c)  ~
    (scope-error:review our.b now.b candidate.c objective.r u.decision.c)
  ?^  denied  [%| u.denied]
  [%& [r c id.j]]
++  no-change
  ::  Only an owner completion receipt cited by the latest judgment selects
  ::  this path. A selected but invalid receipt never falls back to a candidate.
  |=  [b=bowl:gall coding=state:loop e=entry:session a=assignment:nf]
  ^-  (each (unit settlement:nf) @tas)
  ?.  =(%complete phase.e)  [%& ~]
  ?.  (agent-live:guard our.b now.b %viki)  [%| %fleet-completion-unavailable]
  =/  completions=state:completion
    .^(state:completion %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/completions/noun)
  =/  selected  (selected:completion completions e)
  ?~  selected  [%& ~]
  =/  checked  (inspect:completion b completions coding id.session.e)
  ?:  ?=(%| -.checked)  [%| p.checked]
  =/  assignment=@ux  (digest:unchanged a)
  ?.  &(=(u.selected key.p.checked) =(assignment.proposal.decision.receipt.p.checked `assignment) =(%complete verdict.decision.receipt.p.checked))
    [%| %fleet-completion-assignment-mismatch]
  =/  settlement=settlement:nf
    [task.a id.a %completed ~[key.p.checked judgment.receipt.p.checked assignment]]
  [%& `settlement]
++  reviewed-no-change
  ::  Selection is from the latest judgment. A selected invalid automated
  ::  receipt must refuse, never fall back to owner or candidate evidence.
  |=  [b=bowl:gall coding=state:loop e=entry:session a=assignment:nf]
  ^-  (each (unit [key=@ux receipt=receipt:reviewed]) @tas)
  ?.  (agent-live:guard our.b now.b %viki)  [%| %fleet-completion-unavailable]
  =/  held=state:reviewed
    .^(state:reviewed %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/reviewed-completions/noun)
  =/  chosen  (selected:reviewed held e)
  ?~  chosen  [%& ~]
  =/  checked  (inspect:reviewed b held coding id.session.e)
  ?:  ?=(%| -.checked)  [%| p.checked]
  ?.  &(=(u.chosen key.p.checked) =(assignment.proposal.packet.receipt.p.checked `(digest:unchanged a)))
    [%| %fleet-reviewed-completion-assignment-mismatch]
  [%& `p.checked]
++  observe
  |=  [b=bowl:gall s=state coding=state:loop reviews=state:review configured=(list moon-route:vr) old=organ:legacy id=@ux]
  ^-  change
  ?.  =(our.b src.b)  [s coding ~]
  =/  found  (~(get by sessions.coding) id)
  ?~  found  [s coding ~]
  =/  e=entry:session  u.found
  ?.  &(=(our.b owner.session.e) !=(our.b worker.e) ?=(?(%ready %complete) phase.e) ?=(~ pending.e) ?=(~ calls.e))
    [s coding ~]
  ?:  (lien ~(val by pending.coding) |=(r=tool-request:nc =(desk.working.session.e desk.source.context.r)))
    [s coding ~[(refused:loop id %fleet-tool-outcome-pending)]]
  =/  assigned  (assigned:fleet fleet.coding id)
  ?~  assigned  [s coding ~]
  =/  task=entry:nf  u.assigned
  ?.  =(%review phase.task)  [s coding ~]
  ?>  ?=(^ assignment.task)
  =/  a=assignment:nf  u.assignment.task
  ?.  &(=(worker.e worker.a) =(id session.context.a) =(configuration.e configuration.context.a) =(project.session.e project.context.a) =(desk.working.session.e desk.source.context.a))
    [s coding ~[(refused:loop id %fleet-assignment-mismatch)]]
  =/  automated  (reviewed-no-change b coding e a)
  ?:  ?=(%| -.automated)  [s coding ~[(refused:loop id p.automated)]]
  ?^  p.automated
    =/  r=receipt:reviewed  receipt.u.p.automated
    ?:  ?=(%negative -.outcome.r)
      =/  next  (continue-reviewed:law our.b src.b fleet.fleet.coding a judgment.r)
      ?:  ?=(%| -.next)  [s coding ~[(refused:loop id p.next)]]
      =/  out  (effects:fleet our.b fleet.coding sessions.coding p.next)
      [s coding(fleet +.out) (weld -.out ~[(run-card:loop our.b id)])]
    =/  settled=settlement:nf
      [task.a id.a %completed ~[key.u.p.automated judgment.r (digest:unchanged a)]]
    (retain b s coding configured old e settled)
  =/  completed  (no-change b coding e a)
  ?:  ?=(%| -.completed)  [s coding ~[(refused:loop id p.completed)]]
  ?^  p.completed  (retain b s coding configured old e u.p.completed)
  =/  checked  (canonical b coding reviews e)
  ?:  ?=(%| -.checked)  [s coding ~[(refused:loop id p.checked)]]
  =/  [r=entry:review c=record:accept evidence=@ux]  p.checked
  ?:  =(%ready phase.e)
    =/  next  (continue-reviewed:law our.b src.b fleet.fleet.coding a evidence)
    ?:  ?=(%| -.next)  [s coding ~[(refused:loop id p.next)]]
    =/  out  (effects:fleet our.b fleet.coding sessions.coding p.next)
    [s coding(fleet +.out) (weld -.out ~[(run-card:loop our.b id)])]
  =/  settlement=settlement:nf
    [task.a id.a %completed ~[evidence (digest:accept r) (digest:accept c)]]
  (retain b s coding configured old e settlement)
++  retain
  ::  Both judgment paths retain the same immutable intent and require Graf
  ::  readback. This gate does not create judgment or candidate evidence.
  |=  [b=bowl:gall s=state coding=state:loop configured=(list moon-route:vr) old=organ:legacy e=entry:session settlement=settlement:nf]
  ^-  change
  =/  id=@ux  id.session.e
  =/  prior  (~(get by s) task.settlement)
  ?^  prior
    ?.  =(u.prior [id settlement])  [s coding ~[(refused:loop id %fleet-settlement-conflict)]]
    ::  ACK alone is insufficient; the existing reader joins owner-attributed
    ::  canonical Graf evidence before settle can release any claim.
    =/  world  (read:read our.b src.b now.b configured old ~)
    ?:  ?=(%| -.world)  [s coding ~[(refused:loop id p.world)]]
    ?.  (lien owned.p.world |=(fact=* =(fact [%native-coding-fleet-settlement-v1 settlement])))
      [s coding ~]
    =/  next  (act:fleet b fleet.coding p.world sessions.coding projects.coding (blocked-desks:loop coding) [%settle settlement])
    ?:  ?=(%| -.next)  [s coding ~[(refused:loop id p.next)]]
    =/  out=(quip card state:fleet)  p.next
    [s coding(fleet +.out) (weld -.out ~[(changed:loop id sequence.e)])]
  ?:  (gte ~(wyt by s) 256)  [s coding ~[(refused:loop id %fleet-settlement-capacity)]]
  =.  s  (~(put by s) task.settlement [id settlement])
  [s coding ~[(poke:loop our.b %graf /native-fleet-settlement/(scot %ux task.settlement) [%attest [%native-coding-fleet-settlement-v1 settlement]])]]
++  on-agent
  |=  [b=bowl:gall s=state coding=state:loop reviews=state:review configured=(list moon-route:vr) old=organ:legacy wire=wire sign=sign:agent:gall]
  ^-  (unit change)
  ?.  ?=([%native-fleet-settlement @ ~] wire)  ~
  ?.  ?=(%poke-ack -.sign)  `[s coding ~]
  =/  key  (slaw %ux i.t.wire)
  ?~  key  `[s coding ~]
  =/  prior  (~(get by s) u.key)
  ?~  prior  `[s coding ~]
  ?^  p.sign
    `[s coding ~[(refused:loop session.u.prior %fleet-settlement-retain-unconfirmed)]]
  `(observe b(src our.b) s coding reviews configured old session.u.prior)
++  reload
  ::  Read retained intents once after reload; never replay Graf/inference.
  |=  [our=@p s=state]
  ^-  (list card)
  (turn ~(val by s) |=(i=intent (progress our session.i)))
--
