::  Bounded raw GLS Text bytes shared by native PLAN runners. These pure
::  operations perform no decoding, I/O, model calls or product authority.
|%
++  byte-limit  65.536
++  valid
  |=  [size=@ud bytes=@ud]
  ^-  ?
  &((lte size byte-limit) (lte (met 3 bytes) size))
++  combine
  |=  [op=?(%10 %12) left=[size=@ud bytes=@ud] right=[size=@ud bytes=@ud]]
  ^-  (each $?([%boolean value=?] [%text size=@ud bytes=@ud]) @tas)
  ?.  &((valid left) (valid right))  [%| %text-bound]
  ?:  =(%10 op)  [%& [%boolean =(left right)]]
  =/  size=@ud  (add size.left size.right)
  ?:  (gth size byte-limit)  [%| %text-bound]
  [%& [%text size (con bytes.left (lsh [3 size.left] bytes.right))]]
--
