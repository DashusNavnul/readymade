::  /lib/fedwiki-serve.hoon
::
::  A ship's cards over HTTP, as a fedwiki site answers: GET /<slug>.json
::  is the page, GET /system/sitemap.json the sitemap.  Sitemap entries
::  follow wiki-server lib/sitemap.js 42-100 and wiki-client
::  lib/synopsis.js: slug, title, date (the last edit that is not a
::  fork, omitted when none), synopsis, and links only when there are
::  some.  Two deliberate differences: a "text" that is not a string
::  never becomes a synopsis (the client would crash on it), and the
::  560-unit synopsis cut never splits a UTF-16 surrogate pair.
::
/-  fw=fedwiki
/+  fedwiki, fj=fedwiki-json, fs=fedwiki-store, gep=graf-evidence-pages
|%
+$  want  $@(%sitemap [%page slug=@t])
::  +wiki-path: is this request line one of the site's (query ignored)
::
++  wiki-path
  |=  url=@t
  ^-  (unit want)
  =/  t=tape  (trip url)
  =/  q  (find "?" t)
  =?  t  ?=(^ q)  (scag u.q t)
  ?:  =("/system/sitemap.json" t)  `%sitemap
  ::  wiki-server lib/server.js 478: ^\/([a-z0-9-]+)\.json$
  ?.  ?=([%'/' *] t)  ~
  =/  rest=tape  t.t
  =/  n  (lent rest)
  ?.  (gth n 5)  ~
  ?.  =(".json" (slag (sub n 5) rest))  ~
  =/  slug=tape  (scag (sub n 5) rest)
  ?.  (levy slug |=(c=@ |(&((gte c 'a') (lte c 'z')) &((gte c '0') (lte c '9')) =(c '-'))))
    ~
  `[%page (crip slug)]
::  +serve: [status content-type body] for a wanted path over the pages
::
++  serve
  |=  [=want pages=(map @t version:fs)]
  ^-  [status=@ud type=@t body=@t]
  ?@  want
    [200 'application/json' (en:json:html (sitemap pages))]
  =/  v  (~(get by pages) slug.want)
  ?~  v  [404 'text/plain' 'Page not found']
  [200 'application/json' (en:json:html (en-page:fj page.u.v))]
::  +read-facts: every %fedwiki-page fact in graf (call where a scry is
::  allowed, with graf running)
::
++  read-facts
  |=  [our=@p now=@da]
  ^-  (list *)
  =/  offset=@ud  0
  =/  rev=(list *)  ~
  |-
  =/  p  .^(kind-page:gep %gx (page-path:gep our now %fedwiki-page offset))
  ?.  (page-valid:gep p %fedwiki-page offset)
    ~|([%invalid-graf-kind-page %fedwiki-page offset] !!)
  =/  next=(list *)  (weld (flop items.p) rev)
  ?:  more.p  $(offset next-offset.p, rev next)
  (flop next)
::
++  sitemap
  |=  pages=(map @t version:fs)
  ^-  json
  :-  %a
  %+  turn  (sort ~(tap by pages) |=([a=[@t *] b=[@t *]] (aor -.a -.b)))
  |=([slug=@t v=version:fs] (entry slug page.v))
::
++  entry
  |=  [slug=@t =page:fw]
  ^-  json
  =/  m=(map @t json)
    (~(gas by *(map @t json)) ~[['slug' s+slug] ['title' s+title.page] ['synopsis' s+(synopsis page)]])
  =/  d  (edit-date:fedwiki journal.page)
  =?  m  ?=(^ d)  (~(put by m) 'date' (numb:enjs:format u.d))
  =/  ls  (links page)
  =?  m  !=(~ ls)  (~(put by m) 'links' o+(~(run by ls) |=(i=@t s+i)))
  o+m
::  +links: [[Title]] links in item text (asSlug'd) and reference items'
::  slugs, each to the id of the first item naming it
::
++  links
  |=  =page:fw
  ^-  (map @t @t)
  %+  roll  story.page
  |=  [i=item:fw acc=(map @t @t)]
  =/  found=(list @t)
    =/  r  (~(get by more.i) 'slug')
    %+  weld  ?~(text.i ~ (bracketed u.text.i))
    ?.  &(=('reference' kind.i) ?=([~ %s *] r))  ~
    ~[p.u.r]
  |-
  ?~  found  acc
  =?  acc  !(~(has by acc) i.found)  (~(put by acc) i.found id.i)
  $(found t.found)
::  +bracketed: what /\[\[([^\]]+)\]\]/g captures, asSlug'd
::
++  bracketed
  |=  text=@t
  ^-  (list @t)
  =/  b=(list @)  (rip 3 text)
  =|  out=(list @t)
  |-
  ?~  b  (flop out)
  =/  all=(list @)  b
  ?.  ?=([%'[' %'[' *] all)  $(b t.b)
  =/  start=(list @)  t.t.all
  =/  body=(list @)  start
  =/  n=@ud  0
  |-
  ?~  body  ^$(b t.b)
  ?.  =(']' i.body)  $(body t.body, n +(n))
  ?.  (gth n 0)  ^$(b t.b)
  ?.  ?=([%']' %']' *] body)  ^$(b t.b)
  =/  cap=@t  (rap 3 (scag n start))
  =/  after=(list @)  t.t.body
  ^$(b after, out [(as-slug:fedwiki cap) out])
::  +synopsis: wiki-client lib/synopsis.js
::
++  synopsis
  |=  =page:fw
  ^-  @t
  =/  st  story.page
  =/  p1=(unit item:fw)  ?~(st ~ `i.st)
  =/  p2=(unit item:fw)  ?~(st ~ ?~(t.st ~ `i.t.st))
  =/  txt  |=(i=(unit item:fw) ^-(@t ?~(i '' ?~(text.u.i '' u.text.u.i))))
  =/  para  |=(i=(unit item:fw) ^-(@t ?~(i '' ?.(=('paragraph' kind.u.i) '' (txt i)))))
  ::  a plain list: the wet +skip on a literal's exact-length type nest-fails
  =/  tries=(list @t)  ~[(para p1) (para p2) (txt p1) (txt p2)]
  =/  hits  (skip tries |=(t=@t =('' t)))
  =/  raw=@t
    ?^  hits  i.hits
    (rap 3 ~['A page with ' (crip ((d-co:co 1) (lent st))) ' items.'])
  =/  cs=(list @c)  (points raw)
  ::  trim, then keep the first line, then 560 UTF-16 units
  =.  cs  (flop (drop-space (flop (drop-space cs))))
  =/  line=(list @c)  (scag (fall (find ~[(@c 0xd)] cs) (lent cs)) cs)
  =.  line  (scag (fall (find ~[(@c 0xa)] line) (lent line)) line)
  =|  units=@ud
  =|  keep=(list @c)
  |-
  ?~  line  (rap 3 (turn (flop keep) tuft))
  =/  w=@ud  ?:((gth i.line 0xffff) 2 1)
  ?:  (gth (add units w) 560)  (rap 3 (turn (flop keep) tuft))
  $(line t.line, units (add units w), keep [i.line keep])
::
++  drop-space
  |=  cs=(list @c)
  ^-  (list @c)
  ?~  cs  ~
  ?.  (js-space:fedwiki i.cs)  cs
  $(cs t.cs)
::  +points: a cord's code points, decoded here (+tuba crashes on a tab)
::
++  points
  |=  t=@t
  ^-  (list @c)
  =/  bytes=(list @)  (rip 3 t)
  =|  out=(list @c)
  |-
  ?~  bytes  (flop out)
  =/  n=@ud
    ?:  (lth i.bytes 0xc0)  1
    ?:((lth i.bytes 0xe0) 2 ?:((lth i.bytes 0xf0) 3 4))
  =/  all=(list @)  bytes
  ?:  (gth n (lent all))  (flop out)
  $(bytes (slag n all), out [(utf8-point:fedwiki (scag n all)) out])
--
