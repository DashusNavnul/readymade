::  Owner-local recovery discovery. Reads never restart a retained command.
/+  inv=readymade-project-invitations, web=readymade-project-invitations-http,
    pages=readymade-session-catalog, mg=readymade-app-management
|%
++  read-request
  |=  req=inbound-request:eyre
  ^-  (unit query:pages)
  ?.  &(authenticated.req =('GET' method.request.req))  ~
  =/  offset  (header:mg header-list.request.req 'x-readymade-invitation-offset')
  ?~  offset  ~
  (parse-query:pages u.offset (header:mg header-list.request.req 'x-readymade-invitation-catalog'))
++  page
  |=  [our=@p request=query:pages journal=journal:inv]
  ^-  (each json @tas)
  ?.  (lte offset.request safe-int:pages)  [%| %invitation-catalog-cursor]
  =/  rows=(list [key=@t value=record:inv])
    (sort ~(tap by journal) |=([a=[key=@t value=record:inv] b=[key=@t value=record:inv]] (lth key.a key.b)))
  =/  total=@ud  (lent rows)
  ?.  (lte total 512)  [%| %invitation-catalog-capacity]
  ?.  ?|(&(=(0 total) =(0 offset.request)) (lth offset.request total))
    [%| %invitation-catalog-cursor]
  =/  digest=@ux  (shax (jam [%readymade-invitation-catalog-v1 our rows]))
  ?:  =(0 digest)  [%| %invitation-catalog-digest]
  ?:  ?&  ?=(^ expected.request)  !=(u.expected.request digest)  ==
    [%| %invitation-catalog-stale]
  ?:  &((gth offset.request 0) ?=(~ expected.request))
    [%| %invitation-catalog-cursor]
  =/  selected=(list [key=@t value=record:inv])
    (scag 64 (slag offset.request rows))
  =/  end=@ud  (add offset.request (lent selected))
  =/  body=json
    %-  pairs:enjs:format
    :~  ['schema' s+'readymade-project-invitation-catalog-v1']
        ['owner' s+(scot %p our)]
        ['permissionGranted' b+%.n]
        ['catalog' s+(scot %ux digest)]
        ['offset' (numb:enjs:format offset.request)]
        ['total' (numb:enjs:format total)]
        ['next' ?:(=(end total) ~ (numb:enjs:format end))]
        ['requests' a+(turn selected |=([key=@t value=record:inv] (view:web value)))]
    ==
  ?:  (gth (met 3 (en:json:html body)) 65.536)
    [%| %invitation-catalog-bytes]
  [%& body]
--
