::  Metadata agreement only. Caller authenticates actor; caller-supplied ship
::  and law digests are not runtime authority. Persist counters, never recreate
::  a retained round. Both native owners independently check current law and
::  explicit artifact authorization before producing their own ack evidence.
::  Remote evidence records that owner's observation; it grants nothing here.
/-  r=readymade-artifact-round, p=readymade-pact
/+  pact=readymade-pact, mc=multiplayer-collaboration, package=readymade-package
|%
++  digest
  |=  proposal=proposal:r
  ^-  @ux
  (shax (jam [%readymade-artifact-round-proposal-v1 proposal]))
++  valid-target
  |=  [purpose=purpose:p receiver=@p target=target:r]
  ^-  ?
  ?.  =(receiver ship.target)  %.n
  ?-  -.target
    %land
      ?&  =(%land purpose)
          !=(%base desk.target)
          !=(%$ desk.target)
          ((sane %tas) desk.target)
          (lte (met 3 desk.target) 64)
          (gth revision.target 0)
          (bounded-number:pact revision.target)
          (digest-valid:mc root.target)
          (path-valid:package file.target)
      ==
    %publish
      ?&  =(%publish purpose)
          (digest-valid:mc audience.target)
          (bounded-identifier:mc destination.target)
      ==
  ==
++  valid-proposal
  |=  [current=state:p purpose=purpose:p candidate=proposal:r]
  ^-  ?
  ?&  (valid-terms:pact terms.current)
      (active:pact current)
      (bounded-number:pact generation.current)
      =(1 version.candidate)
      =(pact.candidate (digest:pact terms.current))
      =(generation.candidate generation.current)
      =(purpose purpose.candidate)
      (gth round.candidate 0)
      (bounded-number:pact round.candidate)
      =(package.candidate package.terms.current)
      =(scope.candidate scope.terms.current)
      (digest-valid:mc artifact.candidate)
      (digest-valid:mc build-proof.candidate)
      |(=(receiver.candidate left.terms.current) =(receiver.candidate right.terms.current))
      (valid-target purpose receiver.candidate target.candidate)
  ==
++  init
  |=  [current=state:p purpose=purpose:p]
  ^-  (unit state:r)
  ?.  &((valid-terms:pact terms.current) (active:pact current) (bounded-number:pact generation.current))  ~
  `[%readymade-artifact-round-v1 (digest:pact terms.current) generation.current purpose 0 0 0 ~ ~ ~ %.n %.n]
++  valid
  |=  [held=state:r current=state:p]
  ^-  ?
  ?.  ?&  (valid-terms:pact terms.current)
          (active:pact current)
          =(pact.held (digest:pact terms.current))
          =(generation.held generation.current)
          (bounded-number:pact generation.held)
          (bounded-number:pact left-sequence.current)
          (bounded-number:pact right-sequence.current)
          (bounded-number:pact round.held)
          (bounded-number:pact left-sequence.held)
          (bounded-number:pact right-sequence.held)
      ==
    %.n
  ?~  proposal.held
    ?&  =(0 round.held)
        =(0 left-sequence.held)
        =(0 right-sequence.held)
        ?=(~ left-ack.held)
        ?=(~ right-ack.held)
        =(%.n left-close.held)
        =(%.n right-close.held)
    ==
  ?&  (valid-proposal current purpose.held u.proposal.held)
      =(round.held round.u.proposal.held)
      ?~(left-ack.held %.y &((digest-valid:mc law.u.left-ack.held) (digest-valid:mc authorization.u.left-ack.held)))
      ?~(right-ack.held %.y &((digest-valid:mc law.u.right-ack.held) (digest-valid:mc authorization.u.right-ack.held)))
  ==
++  local-ack-permitted
  ::  Pure preflight only. These booleans MUST be independently computed by
  ::  the authenticated native owner wrapper; never accept them from JSON/Ames.
  |=  [held=state:r current=state:p our=@p selected=@ux current-law-ok=? explicit-owner-ok=?]
  ^-  ?
  ?.  &(current-law-ok explicit-owner-ok (valid held current))  %.n
  ?~  proposal.held  %.n
  ?&  |(=(our left.terms.current) =(our right.terms.current))
      =(selected (digest u.proposal.held))
      =(%.n left-close.held)
      =(%.n right-close.held)
      ?:(=(our left.terms.current) ?=(~ left-ack.held) ?=(~ right-ack.held))
  ==
++  ready
  ::  Bilateral observation, NOT permission to land, publish, or execute.
  |=  [held=state:r current=state:p selected=@ux]
  ^-  ?
  ?.  (valid held current)  %.n
  ?~  proposal.held  %.n
  ?&  =(selected (digest u.proposal.held))
      ?=(^ left-ack.held)
      ?=(^ right-ack.held)
      =(%.n left-close.held)
      =(%.n right-close.held)
  ==
++  step
  |=  [held=state:r current=state:p actor=@p request=request:r]
  ^-  (unit state:r)
  ?.  (valid held current)  ~
  ?.  |(=(actor left.terms.current) =(actor right.terms.current))  ~
  ?.  =(generation.request generation.held)  ~
  ?.  (bounded-number:pact sequence.request)  ~
  =/  left=?  =(actor left.terms.current)
  =/  prior=@ud  ?:(left left-sequence.held right-sequence.held)
  ?.  =(+(prior) sequence.request)  ~
  =/  next=state:r
    ?:(left held(left-sequence sequence.request) held(right-sequence sequence.request))
  ?:  ?=(%propose -.action.request)
    ?.  left  ~
    ?.  ?~(proposal.held %.y &(left-close.held right-close.held))  ~
    =/  candidate=proposal:r  proposal.action.request
    ?.  (valid-proposal current purpose.held candidate)  ~
    ?.  =(+(round.held) round.candidate)  ~
    `next(round round.candidate, proposal `candidate, left-ack ~, right-ack ~, left-close %.n, right-close %.n)
  ?~  proposal.held  ~
  =/  selected=@ux
    ?-  -.action.request
      %ack    proposal.action.request
      %close  proposal.action.request
    ==
  ?.  =(selected (digest u.proposal.held))  ~
  ?-  -.action.request
    %ack
      ::  An opposite owner's close may cross an already-issued ack. Consume
      ::  that exact next ack to converge counters; ready stays false. Own
      ::  close prevents all subsequent own acks, by strict owner sequence.
      ?:  ?:(left left-close.held right-close.held)  ~
      ?.  ?:(left ?=(~ left-ack.held) ?=(~ right-ack.held))  ~
      =/  evidence=evidence:r  evidence.action.request
      ?.  &((digest-valid:mc law.evidence) (digest-valid:mc authorization.evidence))  ~
      `?:(left next(left-ack `evidence) next(right-ack `evidence))
    %close
      ?:  ?:(left left-close.held right-close.held)  ~
      `?:(left next(left-close %.y) next(right-close %.y))
  ==
--
