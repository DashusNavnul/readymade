::  Ordinary executor metadata only; no native reads, grants or source effects.
/-  r=readymade-artifact-round
/+  build=readymade-package-build, package=readymade-package,
    round=readymade-artifact-round, mg=readymade-app-management
|%
+$  command
  $:  %readymade-artifact-execute-v1
      owner=@p  peer=@p  request=@t  pact=@ux  selected=@ux
      guard=@ux  session=@ux
  ==
+$  selected  [proposal=proposal:r receipt=receipt:build]
+$  entry
  $:  command=command  at=@da  selection=selected
      phase=?(%pending %uncertain %refused %applied)
      candidate=(unit @ux)  reason=@tas
  ==
+$  journal  (map @ux entry)
++  key
  |=  cmd=command
  ^-  @ux
  (shax (jam cmd))
++  command-valid
  |=  cmd=command
  ^-  ?
  ?&  !=(owner.cmd peer.cmd)  (uuid:mg request.cmd)
      (lte (met 0 owner.cmd) 128)  (lte (met 0 peer.cmd) 128)
      (digest-valid:package pact.cmd)  (digest-valid:package selected.cmd)
      (digest-valid:package guard.cmd)  (digest-valid:package session.cmd)
  ==
++  entry-valid
  ::  Metadata consistency is not a current pact, grant or law judgment.
  |=  [our=@p value=entry]
  ^-  ?
  =/  cmd=command  command.value
  =/  proposal=proposal:r  proposal.selection.value
  =/  receipt=receipt:build  receipt.selection.value
  ?.  &((command-valid cmd) =(our owner.cmd))  %.n
  ?.  ?=(%land -.target.proposal)  %.n
  ?&  !=(0 at.value)  (lte (met 0 at.value) 128)
      (lte (met 3 reason.value) 128)  =(1 version.proposal)
      =(selected.cmd (digest:round proposal))
      =(pact.cmd pact.proposal)  =(%land purpose.proposal)
      =(our receiver.proposal)  =(our ship.target.proposal)
      (ordinary:mg desk.target.proposal)
      (path-valid:package file.target.proposal)
      (digest-valid:package root.target.proposal)
      &((gth revision.target.proposal 0) (lte (met 0 revision.target.proposal) 64))
      (lte (met 0 generation.proposal) 64)
      &((gth round.proposal 0) (lte (met 0 round.proposal) 64))
      (digest-valid:package scope.proposal)
      (valid:build our receipt)
      =(build-proof.proposal proof.receipt)
      =(artifact.proposal artifact.body.receipt)
      =(package.proposal digest.offer.plan.body.receipt)
      ?~  candidate.value  !=(%applied phase.value)
      (digest-valid:package u.candidate.value)
  ==
++  valid
  |=  [our=@p entries=journal]
  ^-  ?
  ?&  (lte ~(wyt by entries) 256)
      =((lent ~(val by entries)) ~(wyt in (silt (turn ~(val by entries) |=(value=entry request.command.value)))))
      %+  levy  ~(tap by entries)
      |=  row=[nonce=@ux value=entry]
      &(=(nonce.row (key command.value.row)) (entry-valid our value.row))
  ==
--
