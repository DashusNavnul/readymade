::  Owner-only coding catalog projection. No transcript, provider credential,
::  pending tool, authority grant or action is retained or returned here.
::  The caller authenticates the owner before reading the canonical session map.
/-  nc=native-coding, np=native-coding-provider
/+  sessions=native-coding-session, cursor=readymade-session-catalog
|%
+$  row
  $:  id=@ux  project=@t  objective=@t  phase=phase:sessions
      model=@t  worker=@p  source=revision:nc
  ==
+$  page
  $:  digest=@ux  offset=@ud  total=@ud  next=(unit @ud)
      ids=(list @ux)  rows=(list row)
  ==
++  page-limit  64
++  byte-limit  524.288
++  metadata
  |=  e=entry:sessions
  ^-  row
  [id.session.e project.session.e objective.session.e phase.e model.selection.e worker.e working.session.e]
++  valid-row
  |=  [our=@p r=row]
  ^-  ?
  ?&  !=(0 id.r)  (lte (met 0 id.r) 256)
      (gth (met 3 project.r) 0)  (lte (met 3 project.r) 128)
      (lte (met 3 objective.r) text-limit:np)
      (gth (met 3 model.r) 0)  (lte (met 3 model.r) identifier-limit:np)
      (lte (met 0 worker.r) 128)  =(our owner.source.r)
      (gth (met 3 desk.source.r) 0)  (lte (met 3 desk.source.r) 128)
      ((sane %tas) desk.source.r)  (lte number.source.r safe-int:cursor)
      (lte (met 0 root.source.r) 256)  (lte (met 0 commit.source.r) 256)
  ==
++  row-json
  ::  Same source identity and numeric representation as the legacy snapshot.
  |=  r=row
  ^-  json
  =/  source=revision:nc  source.r
  =/  revision=json
    (pairs:enjs:format ~[['id' s+(scot %ux (shax (jam source)))] ['owner' s+(scot %p owner.source)] ['desk' s+(scot %tas desk.source)] ['number' (numb:enjs:format number.source)] ['root' s+(scot %uv root.source)] ['commit' s+(scot %uv commit.source)]])
  (pairs:enjs:format ~[['id' s+(scot %ux id.r)] ['project' s+project.r] ['objective' s+objective.r] ['phase' s+(scot %tas phase.r)] ['model' s+model.r] ['worker' s+(scot %p worker.r)] ['source' revision]])
++  project
  ::  Traverse each entry once, extracting only metadata. Never jam the map:
  ::  its records, conversation and summary can be many orders larger.
  |=  [our=@p held=organ:sessions]
  ^-  (each (list row) @tas)
  ?.  (lte ~(wyt by held) session-limit:sessions)  [%| %coding-catalog-capacity]
  =/  remaining  ~(tap by held)
  =|  out=(list row)
  |-  ^-  (each (list row) @tas)
  ?~  remaining
    [%& (sort out |=([a=row b=row] (lth id.a id.b)))]
  =/  [key=@ux e=entry:sessions]  i.remaining
  =/  r=row  (metadata e)
  ?.  &(=(key id.r) =(our owner.session.e) (valid-row our r))
    [%| %coding-catalog-invalid]
  $(remaining t.remaining, out [r out])
++  select
  |=  [our=@p request=query:cursor held=organ:sessions]
  ^-  (each page @tas)
  ?.  (lte offset.request safe-int:cursor)  [%| %coding-catalog-cursor]
  =/  projected  (project our held)
  ?:  ?=(%| -.projected)  [%| p.projected]
  =/  ordered=(list row)  p.projected
  =/  total=@ud  (lent ordered)
  ?.  |(&(=(0 total) =(0 offset.request)) (lth offset.request total))
    [%| %coding-catalog-cursor]
  =/  digest=@ux  (shax (jam [%native-coding-session-catalog-v2 our ordered]))
  ?:  =(0 digest)  [%| %coding-catalog-digest]
  ?:  ?~(expected.request %.n !=(u.expected.request digest))
    [%| %coding-catalog-stale]
  ?:  &((gth offset.request 0) ?=(~ expected.request))
    [%| %coding-catalog-cursor]
  =/  remaining=(list row)  (slag offset.request ordered)
  =/  ids=(list @ux)  (turn ordered |=(r=row id.r))
  ::  Reserve more than the maximum 512 IDs plus the fixed JSON envelope.
  ::  Each row is encoded only once for sizing, not each growing page again.
  =/  bytes=@ud  65.536
  =|  count=@ud
  =|  out=(list row)
  |-  ^-  (each page @tas)
  =/  end=@ud  (add offset.request count)
  =/  done=page  [digest offset.request total ?:(=(end total) ~ `end) ids (flop out)]
  ?:  |(?=(~ remaining) =(page-limit count))  [%& done]
  =/  next-bytes=@ud  (add bytes +((met 3 (en:json:html (row-json i.remaining)))))
  ?:  (gth next-bytes byte-limit)
    ?:  =(0 count)  [%| %coding-catalog-row-too-large]
    [%& done]
  $(remaining t.remaining, bytes next-bytes, count +(count), out [i.remaining out])
++  page-json
  |=  p=page
  ^-  json
  =/  catalog=json
    (pairs:enjs:format ~[['digest' s+(scot %ux digest.p)] ['offset' (numb:enjs:format offset.p)] ['total' (numb:enjs:format total.p)] ['next' ?~(next.p ~ (numb:enjs:format u.next.p))]])
  (pairs:enjs:format ~[['schema' s+'native-coding-session-catalog-v2'] ['catalog' catalog] ['sessionIds' a+(turn ids.p |=(id=@ux s+(scot %ux id)))] ['sessions' a+(turn rows.p row-json)] ['permissionGranted' b+%.n]])
--
