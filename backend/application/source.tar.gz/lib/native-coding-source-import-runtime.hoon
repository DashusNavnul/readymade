::  Native delivery controller. Snapshots come only from these Clay reads.
::  Pure source-import owns byte/release/parent validation and write formation.
::  Exact accepted parts remain immutable; neither ACK nor reload resends one.
/+  source=native-coding-source-import, bootstrap=native-coding-bootstrap,
    private=pataphor-editor-read, dsr=desk-shell-read, guard=viki-scry-guard
|%
+$  entry  [record=record:source batches=(map @ud batch:source)]
+$  state  (map @ux entry)
+$  command
  $%  [%native-coding-source-import-begin-v1 request=request:source]
      [%native-coding-source-import-part-v1 id=@ux batch=batch:source]
      [%native-coding-source-import-observe-v1 id=@ux]
  ==
+$  summary
  [id=@ux desk=@tas release=@ux cursor=@ud total=@ud phase=@tas reason=@tas complete=?]
+$  change  [state=state cards=(list card:agent:gall)]
++  summarize
  |=  e=entry
  ^-  summary
  =/  r=record:source  record.e
  :*  id.request.r  desk.baseline.request.r  digest.release.request.r  cursor.r
      (lent files.release.request.r)  phase.r  reason.r  (complete:source r)
  ==
++  status
  |=  s=state
  ^-  (map @ux summary)
  (malt (turn ~(tap by s) |=([id=@ux e=entry] [id (summarize e)])))
++  reservations
  |=  s=state
  ^-  (set @tas)
  %-  silt
  %+  murn  ~(val by s)
  |=  e=entry
  ?:  (complete:source record.e)  ~
  `desk.baseline.request.record.e
++  entry-valid
  |=  [our=@p id=@ux e=entry]
  ^-  ?
  =/  r=record:source  record.e
  ?.  ?&  =(our owner.request.r)  =(id id.request.r)  (valid:source r)
          !=(%staged phase.r)  (lte ~(wyt by batches.e) 1.024)
          =(~(wyt by batches.e) (add (lent receipts.r) ?~(pending.r 0 1)))
      ==  %.n
  ?.  %+  levy  ~(tap by batches.e)
      |=  [cursor=@ud b=batch:source]
      &(=(cursor cursor.b) (batch-valid:source r(cursor cursor) b))
    %.n
  ?.  %+  levy  receipts.r
      |=  receipt=receipt:source
      =/  batch  (~(get by batches.e) cursor.receipt)
      ?~  batch  %.n
      ?&  =(count.receipt (lent files.u.batch))
          =(blobs.receipt (turn files.u.batch |=(u=upload:source [pax.file.u (blob:source u)])))
      ==
    %.n
  ?~  pending.r  %.y
  =(`batch.u.pending.r (~(get by batches.e) cursor.r))
++  valid
  |=  [our=@p s=state]
  ^-  ?
  ?&  (lte ~(wyt by s) 4)
      (levy ~(tap by s) |=([id=@ux e=entry] (entry-valid our id e)))
      =(~(wyt by s) ~(wyt in (silt (turn ~(val by s) |=(e=entry desk.baseline.request.record.e)))))
  ==
++  canonical
  ::  Direct Clay reads avoid the project reader's importer reservation fence.
  ::  An inactive existing desk with private root rules is mandatory.
  |=  [our=@p now=@da desk=@tas]
  ^-  (unit snapshot:source)
  ?.  &(!=(%base desk) !=(%$ desk))  ~
  =/  d  (dome:bootstrap our now desk)
  ?~  d  ~
  ?.  &((isolated:bootstrap u.d) (private-path:private our now desk /) (gth let.u.d 0))  ~
  =/  commit  (~(get by hit.u.d) let.u.d)
  ?~  commit  ~
  =/  y=yaki:clay
    .^(yaki:clay %cs (beam:dsr our now desk /yaki/(scot %uv u.commit)))
  =/  root=@uv  .^(@uv %cz (beam-at:dsr our desk (scot %ud let.u.d) /))
  =/  s=snapshot:source  [[our desk let.u.d root u.commit] q.y p.y]
  ?:((snapshot-valid:source s) `s ~)
++  available
  ::  Viki's projection excludes this importer to avoid a reservation cycle.
  ::  It includes global/scoped projects, bootstrap/opening/fleet reservations;
  ::  Cantrip adds candidate/runtime/cache and retained unknown tool desks.
  |=  [our=@p now=@da desk=@tas]
  ^-  (each snapshot:source @tas)
  ?.  (agent-live:guard our now %cantrip)  [%| %source-import-cantrip-unavailable]
  =/  tools=(set @tas)
    .^((set @tas) %gx /(scot %p our)/cantrip/(scot %da now)/native-coding/reserved-desks/noun)
  ?.  (agent-live:guard our now %viki)  [%| %source-import-viki-unavailable]
  =/  projects=(set @tas)
    .^((set @tas) %gx /(scot %p our)/viki/(scot %da now)/native-coding/reserved-desks/noun)
  ?:  |((~(has in tools) desk) (~(has in projects) desk))  [%| %source-import-desk-reserved]
  =/  current  (canonical our now desk)
  ?~  current  [%| %source-import-private-baseline-unavailable]
  [%& u.current]
++  notice
  |=  e=entry
  ^-  card:agent:gall
  [%give %fact ~[/status] %noun !>([%native-coding-source-import-status-v1 (summarize e)])]
++  retain
  |=  [s=state e=entry cards=(list card:agent:gall)]
  ^-  change
  [(~(put by s) id.request.record.e e) (weld cards ~[(notice e)])]
++  begin
  |=  [b=bowl:gall s=state r=request:source]
  ^-  (each change @tas)
  =/  old  (~(get by s) id.r)
  ?^  old
    ?.  =(r request.record.u.old)  [%| %source-import-id-conflict]
    [%& (retain s u.old ~)]
  ?:  (gte ~(wyt by s) 4)  [%| %source-import-capacity]
  ?.  &(=(our.b owner.r) (request-valid:source r))  [%| %source-import-request-invalid]
  ?:  (lien ~(val by s) |=(e=entry =(desk.baseline.r desk.baseline.request.record.e)))
    [%| %source-import-target-retained]
  =/  current  (available our.b now.b desk.baseline.r)
  ?:  ?=(%| -.current)  [%| p.current]
  =/  started  (begin:source our.b src.b r p.current)
  ?:  ?=(%| -.started)  [%| p.started]
  [%& (retain s [p.started ~] ~)]
++  part
  |=  [b=bowl:gall s=state e=entry batch=batch:source]
  ^-  (each change @tas)
  =/  old  (~(get by batches.e) cursor.batch)
  ?^  old
    ?.  =(batch u.old)  [%| %source-import-part-conflict]
    ::  A repeated part observes the exact retained submission, even unknown.
    [%& (retain s e ~)]
  =/  prepared  (stage:source our.b src.b record.e batch)
  ?:  ?=(%| -.prepared)  [%| p.prepared]
  =/  desk=@tas  desk.baseline.request.record.e
  =/  current  (available our.b now.b desk)
  ?:  ?=(%| -.current)  [%| p.current]
  ?.  (levy files.batch |=(u=upload:source (private-path:private our.b now.b desk pax.file.u)))
    [%| %source-import-path-not-private]
  =/  submitted  (submit:source our.b src.b p.prepared p.current)
  ?:  ?=(%| -.submitted)  [%| p.submitted]
  ::  Exact batch bytes and the submitted intent enter saved state in the same
  ::  Gall event as the one returned Clay card. Neither is reconstructed later.
  =/  next=entry  [record.p.submitted (~(put by batches.e) cursor.batch batch)]
  [%& (retain s next cards.p.submitted)]
++  observe
  |=  [b=bowl:gall s=state e=entry]
  ^-  (each change @tas)
  ?:  ?=(~ pending.record.e)  [%& (retain s e ~)]
  =/  current  (available our.b now.b desk.baseline.request.record.e)
  =/  moved  (observe:source our.b src.b record.e ?:(?=(%& -.current) `p.current ~))
  ?:  ?=(%| -.moved)  [%| p.moved]
  [%& (retain s e(record p.moved) ~)]
++  act
  |=  [b=bowl:gall s=state c=command]
  ^-  (each change @tas)
  ?.  =(our.b src.b)  [%| %source-import-owner-required]
  ?-  -.c
    %native-coding-source-import-begin-v1  (begin b s request.c)
    %native-coding-source-import-part-v1
      =/  e  (~(get by s) id.c)
      ?~  e  [%| %source-import-missing]
      (part b s u.e batch.c)
    %native-coding-source-import-observe-v1
      =/  e  (~(get by s) id.c)
      ?~  e  [%| %source-import-missing]
      (observe b s u.e)
  ==
--
