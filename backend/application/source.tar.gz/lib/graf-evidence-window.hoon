::  /lib/graf-evidence-window.hoon
::
::  Bounded, semantics-preserving pages over Graf's immutable fact set.
::
::  A Graf store is a set, not a log.  Its order is noun/tree order, so a
::  "last N" endpoint would lie about chronology and can drop the revocation
::  that keeps a guest out.  This library pages the SAME order as +tap:in.
::  Concatenating every page therefore reproduces legacy /by-kind exactly.
::
::  The traversal stops after limit+1 matching facts.  It does not first
::  materialize every fact or every match; the extra fact is only the honest
::  has-more witness.  Readers making authority decisions must page until
::  more=%.n and refuse if any page is unavailable.
::
/+  gs=graf-substrate, graf-search
|%
++  max-page-items  64
+$  kind-page
  $:  %graf-kind-page
      %1
      kind=@tas
      offset=@ud
      limit=@ud
      returned=@ud
      more=?
      next-offset=@ud
      items=(list fact:gs)
  ==
+$  scan
  $:  skip=@ud
      room=@ud
      rev=(list fact:gs)
  ==
++  valid-limit
  |=  limit=@ud
  &((gth limit 0) (lte limit max-page-items))
::  Walk in the same right-node-left order emitted by +tap:in.  State is
::  threaded through the tree so reaching room=0 stops the traversal early.
++  walk
  |=  [tree=(tree point:gs) pattern=pat:graf-search state=scan]
  ^-  scan
  ?:  =(0 room.state)  state
  ?~  tree  state
  =/  after-right=scan  (walk r.tree pattern state)
  ?:  =(0 room.after-right)  after-right
  =/  after-node=scan
    ?.  (match:graf-search pattern n.tree)  after-right
    ?:  (gth skip.after-right 0)
      after-right(skip (dec skip.after-right))
    after-right(room (dec room.after-right), rev [n.tree rev.after-right])
  ?:  =(0 room.after-node)  after-node
  (walk l.tree pattern after-node)
++  page
  |=  [s=store:gs kind=@tas offset=@ud limit=@ud]
  ^-  kind-page
  =/  pattern=pat:graf-search
    (tup:graf-search ~[(is:graf-search kind) any:graf-search any:graf-search])
  =/  scanned=scan
    (walk `(tree point:gs)`s pattern [offset +(limit) ~])
  =/  found=(list fact:gs)  (flop rev.scanned)
  =/  more=?  (gth (lent found) limit)
  =/  items=(list fact:gs)  (scag limit found)
  :*  %graf-kind-page
      %1
      kind
      offset
      limit
      (lent items)
      more
      (add offset (lent items))
      items
  ==
--
