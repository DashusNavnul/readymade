::  One fixed native task: disconnect an exact publisher sync, never an app.
::  All runtime authority comes from the authenticated Page bowl and own Hood.
|%
+$  binding  [local=@tas ship=@p desk=@tas]
+$  sync-state
  [nun=@ta kid=(unit @tas) let=@ud nit=(unit ?) hav=(unit @ud) yea=?]
+$  context  [apps=(set @tas) clay=@ux]
+$  snapshot
  [available=? owner=@p syncs=(map binding sync-state) installed=(map @tas context)]
+$  command
  [owner=@p request=@t target=binding guard=@ux]
+$  receipt
  $:  request=@t
      hash=@ux
      target=binding
      guard=@ux
      ack=?(%none %accepted %refused)
      status=?(%pending %uncertain %confirmed %refused)
      reason=@tas
      remaining=(unit @ud)
  ==
+$  journal  (map @t receipt)
+$  decision
  [journal=journal record=receipt dispatch=? code=@ud]
+$  response
  [journal=journal cards=(list card:agent:gall) code=@ud body=json]
+$  saved  [%pataphor-page-state-v3 previous=* management=journal]
++  capacity  4.096
++  base  '/apps/pataphor/app-tasks/management/'
++  protocol-pin
  ^-  @uv
  `@uv`0x9fca.5746.9d99.203c.ae5f.71c1.52c4.7fd7.5328.9cf2.ee0e.cec5.cc82.0353.2119.2bc5
++  uuid
  |=  value=@t
  ^-  ?
  ?.  =(36 (met 3 value))  %.n
  =/  chars=(list @t)  (trip value)
  =/  n=@ud  0
  |-  ^-  ?
  ?~  chars  %.y
  =/  c=@t  i.chars
  ?.  ?:  (lien `(list @ud)`~[8 13 18 23] |=(i=@ud =(i n)))
        =(c '-')
      ?&  |(&((gte c '0') (lte c '9')) &((gte c 'a') (lte c 'f')))
          ?:(=(n 14) =(c '4') %.y)
          ?:(=(n 19) (lien `(list @t)`~['8' '9' 'a' 'b'] |=(i=@t =(i c))) %.y)
      ==
    %.n
  $(chars t.chars, n +(n))
++  desk-valid
  |=  name=@t
  ^-  ?
  ?&  (gte (met 3 name) 1)  (lte (met 3 name) 64)
      %+  levy  (trip name)
      |=  c=@t
      |(&((gte c 'a') (lte c 'z')) &((gte c '0') (lte c '9')) =(c '-'))
  ==
++  ordinary
  |=  name=@tas
  ^-  ?
  ?&  (desk-valid name)
      !(lien `(list @tas)`~[%base %kids %pataphor %system %sys %webterm %terminal %glass-desktop-build %bach %viki %graf %cantrip %waterwheel %workspace %readymade] |=(v=@tas =(v name)))
      !=('host-' (end [3 5] name))
      !=('pataphor-' (end [3 9] name))
      !=('glass-' (end [3 6] name))
      !=('system-' (end [3 7] name))
      !=('build-' (end [3 6] name))
  ==
++  target-valid
  |=  target=binding
  ^-  ?
  &((ordinary local.target) (desk-valid desk.target))
++  text-field
  |=  [obj=(map @t json) key=@t limit=@ud]
  ^-  @t
  =/  got=json  (~(got by obj) key)
  ?>  ?=(%s -.got)
  ?>  (lte (met 3 p.got) limit)
  p.got
++  decode
  |=  raw=@t
  ^-  command
  ?>  =(8 (lent (skim (trip raw) |=(c=@t =(c ':')))))
  =/  data=json  (need (de:json:html raw))
  ?>  ?=(%o -.data)
  =/  obj=(map @t json)  p.data
  ?>  =(8 ~(wyt by obj))
  ?>  =('readymade-management-command-v1' (text-field obj 'schema' 64))
  ?>  =('disconnect-publisher' (text-field obj 'task' 32))
  =/  owner-text=@t  (text-field obj 'owner' 128)
  =/  owner=@p  (need (slaw %p owner-text))
  ?>  =(owner-text (scot %p owner))
  =/  request=@t  (text-field obj 'request' 36)
  ?>  (uuid request)
  =/  local=@t  (text-field obj 'local' 64)
  =/  ship-text=@t  (text-field obj 'sourceShip' 128)
  =/  ship=@p  (need (slaw %p ship-text))
  ?>  =(ship-text (scot %p ship))
  =/  desk=@t  (text-field obj 'sourceDesk' 64)
  =/  target=binding  [`@tas`local ship `@tas`desk]
  ?>  (target-valid target)
  =/  hex=@t  (text-field obj 'guard' 81)
  =/  guard=@ux  (need (slaw %ux hex))
  ?>  &(!=(0 guard) (lte (met 3 guard) 32) =(hex (scot %ux guard)))
  [owner request target guard]
++  parse
  |=  raw=@t
  ^-  (unit command)
  ?.  (lte (met 3 raw) 4.096)  ~
  (mole |.((decode raw)))
++  digest
  |=  cmd=command
  ^-  @ux
  (shax (rap 3 ~['disconnect-publisher' 0xa (scot %p owner.cmd) 0xa request.cmd 0xa local.target.cmd 0xa (scot %p ship.target.cmd) 0xa desk.target.cmd 0xa (scot %ux guard.cmd)]))
++  count-local
  |=  [local=@tas syncs=(map binding sync-state)]
  ^-  @ud
  %-  lent
  %+  skim  ~(tap by syncs)
  |=  row=[target=binding value=sync-state]
  =(local local.target.row)
++  guard
  |=  [our=@p target=binding value=sync-state ctx=context]
  ^-  @ux
  (shax (jam [%disconnect-publisher-v1 our protocol-pin target value ctx]))
++  blocked
  |=  [local=@tas entries=journal]
  ^-  ?
  %+  lien  ~(tap by entries)
  |=  row=[id=@t record=receipt]
  &(=(local local.target.record.row) |(=(%pending status.record.row) =(%uncertain status.record.row)))
++  admit
  |=  [our=@p src=@p cmd=command observed=snapshot entries=journal]
  ^-  decision
  =/  item=receipt
    [request.cmd (digest cmd) target.cmd guard.cmd %none %refused %invalid ~]
  ?.  ?&  =(our src)  =(our owner.cmd)  (uuid request.cmd)
          (target-valid target.cmd)  !=(0 guard.cmd)  (lte (met 3 guard.cmd) 32)
      ==
    [entries item(reason %owner-or-command) %.n 403]
  =/  known=(unit receipt)  (~(get by entries) request.cmd)
  ?^  known
    ?.  =(hash.u.known hash.item)
      [entries item(reason %request-conflict) %.n 409]
    [entries u.known %.n (status-code u.known)]
  ?:  (gte ~(wyt by entries) capacity)
    [entries item(reason %journal-full) %.n 503]
  =/  why=@tas
    ?.  &(available.observed =(our owner.observed))  %protocol-unavailable
    ?.  (~(has by installed.observed) local.target.cmd)  %not-installed
    ?:  (blocked local.target.cmd entries)  %target-pending
    ?.  =(1 (count-local local.target.cmd syncs.observed))  %ambiguous-source
    =/  found=(unit sync-state)  (~(get by syncs.observed) target.cmd)
    ?~  found  %source-missing
    ?.  =(guard.cmd (guard our target.cmd u.found (~(got by installed.observed) local.target.cmd)))  %stale-guard
    %ready
  =/  dispatch=?  =(%ready why)
  =.  item  item(status ?:(dispatch %pending %refused), reason ?:(dispatch %awaiting-readback why))
  [(~(put by entries) request.cmd item) item dispatch ?:(dispatch 202 409)]
++  settle
  |=  [our=@p entries=journal request=@t observed=snapshot]
  ^-  journal
  =/  known=(unit receipt)  (~(get by entries) request)
  ?~  known  entries
  =/  item=receipt  u.known
  ?.  &(=(%accepted ack.item) =(%uncertain status.item))  entries
  ?.  &(available.observed =(our owner.observed))
    (~(put by entries) request item(status %uncertain, reason %readback-unavailable))
  ?:  (~(has by syncs.observed) target.item)
    (~(put by entries) request item(status %uncertain, reason %source-still-observed))
  (~(put by entries) request item(status %confirmed, reason %exact-source-absent, remaining `(count-local local.target.item syncs.observed)))
++  acknowledge
  ::  Only the native wrapper may supply the authenticated matching Hood ACK.
  |=  [our=@p entries=journal request=@t accepted=? observed=snapshot]
  ^-  journal
  =/  found=(unit receipt)  (~(get by entries) request)
  ?~  found  entries
  =/  item=receipt  u.found
  ?.  &(=(%none ack.item) =(%pending status.item))  entries
  ?.  accepted
    (~(put by entries) request item(ack %refused, status %refused, reason %native-refused))
  =/  next=journal
    (~(put by entries) request item(ack %accepted, status %uncertain, reason %awaiting-readback))
  (settle our next request observed)
++  status-code
  |=  item=receipt
  ^-  @ud
  ?-  status.item
    %pending    202
    %uncertain  202
    %confirmed  200
    %refused    409
  ==
++  valid-journal
  |=  [our=@p entries=journal]
  ^-  ?
  ?.  (lte ~(wyt by entries) capacity)  %.n
  %+  levy  ~(tap by entries)
  |=  [key=@t item=receipt]
  ?&  =(key request.item)  (uuid key)  (target-valid target.item)
      =(hash.item (digest [our request.item target.item guard.item]))
      !=(0 hash.item)  (lte (met 3 hash.item) 32)
      !=(0 guard.item)  (lte (met 3 guard.item) 32)
      (lte (met 3 reason.item) 64)
      ?~(remaining.item %.y (lte u.remaining.item 512))
      =(?=(^ remaining.item) =(%confirmed status.item))
      ?:(=(%pending status.item) =(%none ack.item) %.y)
      ?:(|(=(%confirmed status.item) =(%uncertain status.item)) =(%accepted ack.item) %.y)
      ?:(=(%refused status.item) !=(%accepted ack.item) %.y)
  ==
++  unwrap
  ::  Preserve the old genuine vase on legacy load; unwrap DATA only for v3.
  |=  [our=@p old=vase]
  ^-  (unit [previous=vase management=journal])
  ?.  ?=([%pataphor-page-state-v3 *] q.old)  `[old ~]
  =/  parsed=(unit saved)  ((soft saved) q.old)
  ?~  parsed  ~
  ?.  ?=([%pataphor-page-state-v2 * *] previous.u.parsed)  ~
  ?.  (valid-journal our management.u.parsed)  ~
  `[!>(previous.u.parsed) management.u.parsed]
++  pinned
  |=  [b=bowl:gall app=@tas desk=@tas expected=@uv]
  ^-  ?
  =/  at=path  /(scot %p our.b)/[app]/(scot %da now.b)/$
  ?.  .^(? %gu at)  %.n
  ?.  =(desk .^(@tas %gd at))  %.n
  =/  raw=*  .^(* %gv at)
  =/  egg
    ((soft ,[version=@ tag=@ duct=* run=@ sub=@ stats=* sup=* wex=* boar=* code=* saved=* byk=* rest=*]) raw)
  ?~  egg  %.n
  ?.  &(=(20 version.u.egg) =(%live tag.u.egg) =(~ code.u.egg))  %.n
  =/  pin  ((soft ,[ship=@p desk=@tas point=[kind=@tas value=@da]]) byk.u.egg)
  ?~  pin  %.n
  ?.  &(=(our.b ship.u.pin) =(desk desk.u.pin) =(%da kind.point.u.pin))  %.n
  =(expected .^(@uv %cz /(scot %p our.b)/[desk]/(scot %da value.point.u.pin)))
++  native
  |=  b=bowl:gall
  ^-  snapshot
  =/  unavailable=snapshot  [%.n our.b ~ ~]
  ?.  =(our.b src.b)  unavailable
  ?.  (pinned b %hood %base protocol-pin)  unavailable
  =/  raw-syncs=*  .^(* %gx /(scot %p our.b)/hood/(scot %da now.b)/kiln/syncs/noun)
  =/  syncs  ((soft ,(map binding sync-state)) raw-syncs)
  ?~  syncs  unavailable
  ?.  (lte ~(wyt by u.syncs) 512)  unavailable
  =/  inventory=(map @tas @ud)
    .^((map @tas @ud) %gf /(scot %p our.b)/base/(scot %da now.b)/$)
  ?.  (lte ~(wyt by inventory) 512)  unavailable
  =/  owners=(map @tas (set @tas))  ~
  =/  todo  ~(tap by inventory)
  =.  owners
    |-  ^-  (map @tas (set @tas))
    ?~  todo  owners
    =/  app=@tas  p.i.todo
    =/  at=path  /(scot %p our.b)/[app]/(scot %da now.b)/$
    ?.  .^(? %gu at)  $(todo t.todo)
    =/  desk=@tas  .^(@tas %gd at)
    ?.  (ordinary desk)  $(todo t.todo)
    =/  known=(set @tas)  (~(gut by owners) desk ~)
    $(todo t.todo, owners (~(put by owners) desk (~(put in known) app)))
  =/  domes=cone:clay
    .^(cone:clay %cx /(scot %p our.b)//(scot %da now.b)/domes)
  =/  eligible=(map @tas context)
    %-  malt
    %+  murn  ~(tap by owners)
    |=  row=[desk=@tas apps=(set @tas)]
    =/  found=(unit dome:clay)  (~(get by domes) [our.b desk.row])
    ?~  found  ~
    =/  d=dome:clay  u.found
    ?.  &(=(%live liv.d) =(~ wic.d))  ~
    =/  root=@uv  .^(@uv %cz /(scot %p our.b)/[desk.row]/(scot %ud let.d))
    `[desk.row [apps.row (shax (jam [let.d liv.d ren.d wic.d root]))]]
  [%.y our.b u.syncs eligible]
++  receipt-json
  |=  [our=@p item=receipt]
  ^-  json
  %-  pairs:enjs:format
  :~  ['schema' s+'readymade-management-result-v1']
      ['owner' s+(scot %p our)]
      ['request' s+request.item]
      ['task' s+'disconnect-publisher']
      ['local' s+local.target.item]
      ['sourceShip' s+(scot %p ship.target.item)]
      ['sourceDesk' s+desk.target.item]
      ['guard' s+(scot %ux guard.item)]
      ['commandHash' s+(scot %ux hash.item)]
      ['ack' s+(scot %tas ack.item)]
      ['status' s+(scot %tas status.item)]
      ['reason' s+(scot %tas reason.item)]
      ['remainingSources' ?~(remaining.item ~ (numb:enjs:format u.remaining.item))]
      ['allUpdatesPaused' b+%.n]
  ==
++  pending-rows
  |=  [entries=journal cursor=@t]
  ^-  (list [id=@t item=receipt])
  =/  rows
    %+  skim  ~(tap by entries)
    |=  row=[id=@t item=receipt]
    &(|(=(%pending status.item.row) =(%uncertain status.item.row)) (gth id.row cursor))
  (sort rows |=([a=[id=@t item=receipt] b=[id=@t item=receipt]] (lth id.a id.b)))
++  pending-json
  |=  [our=@p entries=journal cursor=@t]
  ^-  json
  =/  all  (pending-rows entries cursor)
  =/  selected  (scag 32 all)
  =/  next=@t
    ?~  selected  ''
    =/  todo=(list [id=@t item=receipt])  selected
    =/  last=@t  ''
    |-  ^-  @t
    ?~  todo  last
    $(todo t.todo, last id.i.todo)
  %-  pairs:enjs:format
  :~  ['schema' s+'readymade-management-pending-v1']
      ['owner' s+(scot %p our)]
      ['cursor' s+cursor]
      ['next' s+next]
      ['more' b+(gth (lent all) 32)]
      ['receipts' a+(turn selected |=([id=@t item=receipt] (receipt-json our item)))]
  ==
++  state-json
  |=  [our=@p observed=snapshot entries=journal]
  ^-  json
  =/  rows=(list json)
    %+  murn  ~(tap by syncs.observed)
    |=  row=[target=binding value=sync-state]
    ?.  &((target-valid target.row) (~(has by installed.observed) local.target.row))  ~
    =/  available=?
      &(available.observed =(1 (count-local local.target.row syncs.observed)) !(blocked local.target.row entries) (lth ~(wyt by entries) capacity))
    `(pairs:enjs:format ~[['local' s+local.target.row] ['sourceShip' s+(scot %p ship.target.row)] ['sourceDesk' s+desk.target.row] ['guard' s+(scot %ux (guard our target.row value.row (~(got by installed.observed) local.target.row)))] ['available' b+available]])
  %-  pairs:enjs:format
  :~  ['schema' s+'readymade-management-state-v1']
      ['owner' s+(scot %p our)]
      ['protocolPin' s+(scot %ux `@ux`protocol-pin)]
      ['available' b+available.observed]
      ['sources' a+rows]
      ['receiptCount' (numb:enjs:format ~(wyt by entries))]
      ['receiptCapacity' (numb:enjs:format capacity)]
  ==
++  header
  |=  [headers=(list [@t @t]) name=@t]
  ^-  (unit @t)
  ?.  (lte (lent headers) 128)  ~
  =/  rows
    %+  skim  headers
    |=  row=[key=@t value=@t]
    =(name (crip (cass (trip key.row))))
  ?.  ?=([* ~] rows)  ~
  =/  row=[key=@t value=@t]  i.rows
  ?.  (lte (met 3 value.row) 1.024)  ~
  `value.row
++  post-ready
  |=  req=inbound-request:eyre
  ^-  ?
  =/  host  (header header-list.request.req 'host')
  =/  origin  (header header-list.request.req 'origin')
  =/  mime  (header header-list.request.req 'content-type')
  ?~  host  %.n
  ?~  origin  %.n
  ?~  mime  %.n
  ?&  =(u.origin (cat 3 ?:(secure.req 'https://' 'http://') u.host))
      |(=(u.mime 'application/json') =(u.mime 'application/json; charset=utf-8'))
      =(`'disconnect-v1' (header header-list.request.req 'x-readymade-management'))
  ==
++  error-json
  |=  reason=@tas
  ^-  json
  (pairs:enjs:format ~[['schema' s+'readymade-management-error-v1'] ['reason' s+(scot %tas reason)]])
++  handle
  |=  [b=bowl:gall req=inbound-request:eyre entries=journal]
  ^-  response
  ?.  &(authenticated.req =(our.b src.b))
    [entries ~ 403 (error-json %owner-required)]
  ?.  =(`'disconnect-v1' (header header-list.request.req 'x-readymade-management'))
    [entries ~ 403 (error-json %marker-required)]
  =/  url=@t  url.request.req
  ?:  =(url (cat 3 base 'state.json'))
    ?.  =('GET' method.request.req)  [entries ~ 405 (error-json %method)]
    [entries ~ 200 (state-json our.b (native b) entries)]
  =/  pending-prefix=@t  (cat 3 base 'pending/')
  ?:  =(pending-prefix (end [3 (met 3 pending-prefix)] url))
    ?.  =('GET' method.request.req)  [entries ~ 405 (error-json %method)]
    =/  cursor=@t  (rsh [3 (met 3 pending-prefix)] url)
    =?  cursor  =(cursor 'start')  ''
    ?.  |(=(cursor '') (uuid cursor))  [entries ~ 400 (error-json %request)]
    [entries ~ 200 (pending-json our.b entries cursor)]
  =/  prefix=@t  (cat 3 base 'result/')
  ?:  =(prefix (end [3 (met 3 prefix)] url))
    ?.  =('GET' method.request.req)  [entries ~ 405 (error-json %method)]
    =/  request=@t  (rsh [3 (met 3 prefix)] url)
    ?.  (uuid request)  [entries ~ 400 (error-json %request)]
    =/  prior=(unit receipt)  (~(get by entries) request)
    ?~  prior  [entries ~ 404 (error-json %not-found)]
    =/  next=journal
      ?.  &(=(%accepted ack.u.prior) =(%uncertain status.u.prior))  entries
      (settle our.b entries request (native b))
    =/  found=receipt  (~(got by next) request)
    [next ~ (status-code found) (receipt-json our.b found)]
  ?.  =(url (cat 3 base 'pause.json'))  [entries ~ 404 (error-json %route)]
  ?.  =('POST' method.request.req)  [entries ~ 405 (error-json %method)]
  ?.  (post-ready req)  [entries ~ 403 (error-json %origin-or-content-type)]
  =/  body=(unit octs)  body.request.req
  ?~  body  [entries ~ 400 (error-json %body)]
  ?.  &((lte p.u.body 4.096) =(p.u.body (met 3 q.u.body)))
    [entries ~ 413 (error-json %body-bound)]
  =/  cmd=(unit command)  (parse `@t`q.u.body)
  ?~  cmd  [entries ~ 400 (error-json %command)]
  =/  result=decision  (admit our.b src.b u.cmd (native b) entries)
  =/  cards=(list card:agent:gall)
    ?.  dispatch.result  ~
    ~[[%pass /management/[request.u.cmd] %agent [our.b %hood] %poke %kiln-unsync !>(target.u.cmd)]]
  [journal.result cards code.result (receipt-json our.b record.result)]
--
