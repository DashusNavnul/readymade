::  Public native opening projection and explicit delegation decoding.
::  All grant creation/admission remains in viki-native-opening and Cantrip.
/-  nc=native-coding, np=native-coding-provider
/+  opening=viki-native-opening, cr=codex-responses, guard=viki-scry-guard,
    terminal=native-coding-terminal, sessions=native-coding-session
|%
+$  row
  [id=@ux project=@t grant=@ux operations=(set operation:nc) phase=?(%granting %opened %refused %unknown) reason=(unit @tas)]
++  read
  |=  [our=@p now=@da]
  ^-  (unit (list row))
  ?.  (agent-live:guard our now %viki)  ~
  =/  raw=[%native-coding-openings-v1 rows=(list row)]
    .^([%native-coding-openings-v1 rows=(list row)] %gx /(scot %p our)/viki/(scot %da now)/native-coding/openings/noun)
  `rows.raw
++  project-json
  |=  p=project:nc
  ^-  json
  (pairs:enjs:format ~[['id' s+id.spec.p] ['title' s+title.spec.p] ['operations' a+(turn ~(tap in operations.policy.p) |=(op=operation:nc s+op))]])
++  rows-json
  |=  rows=(unit (list row))
  ^-  json
  =/  out=(list json)
    ?~  rows  ~
    %+  turn  u.rows
    |=  r=row
    (pairs:enjs:format ~[['id' s+(scot %ux id.r)] ['project' s+project.r] ['grant' s+(scot %ux grant.r)] ['phase' s+phase.r] ['reason' s+?~(reason.r '' u.reason.r)] ['operations' a+(turn ~(tap in operations.r) |=(op=operation:nc s+op))]])
  (pairs:enjs:format ~[['available' b+?=(^ rows)] ['rows' a+out]])
++  next
  ::  IDs come from native state. Linear probing is bounded and checks EVERY
  ::  retained opening, session and workspace reservation. Reservations prevent
  ::  collisions but do not consume the native session ledger's capacity.
  |=  [our=@p token=@uv ids=(list @ux) reserved=(list @ux) rows=(unit (list row))]
  ^-  @ux
  ?~  rows  0x0
  ?:  |((gte (lent ids) session-limit:sessions) (gte (lent u.rows) session-limit:sessions))  0x0
  =/  used=(set @ux)  (silt (weld ids (weld reserved (turn u.rows |=(r=row id.r)))))
  =/  id=@ux  (shax (jam [%native-coding-opening-http-id-v1 our token]))
  =/  left=@ud  256
  |-  ^-  @ux
  ?:  &(!=(0 id) !(~(has in used) id))  id
  ?:  =(0 left)  0x0
  $(left (dec left), id (end [0 256] +(id)))
++  request
  |=  [object=json id=@ux selection=selection:np worker=@p]
  ^-  request:opening
  =/  provided=json  (need (field:cr object 'operations'))
  ?>  ?=(%a -.provided)
  ?>  &((gte (lent p.provided) 1) (lte (lent p.provided) 32))
  =/  operations=(list operation:nc)
    %+  turn  p.provided
    |=  value=json
    ?>  ?=(%s -.value)
    ?>  ?=(operation:nc p.value)
    `operation:nc`p.value
  ?>  =((lent operations) ~(wyt in (silt operations)))
  =/  prior=request-v1:opening
    [%native-coding-session-open-v1 id (need (string:cr object 'project')) (need (string:cr object 'objective')) selection credential.selection worker (silt operations) (need (natural:cr (field:cr object 'maxEvalWork')))]
  =/  provided=(unit json)  (field:cr object 'inspections')
  =/  r=request:opening
    ?~  provided  prior
    ?>  ?=(%a -.u.provided)
    ?>  (lte (lent p.u.provided) 32)
    =/  scopes=(list inspection:opening)
      %+  turn  p.u.provided
      |=  value=json
      =/  app=@t  (need (string:cr value 'app'))
      =/  path=@t  (need (string:cr value 'path'))
      ?>  &((gte (met 3 path) 2) (lte (met 3 path) 2.064) =('/' (cut 3 [0 1] path)))
      =/  scope=inspection:opening  [app (path-of:terminal ~ path)]
      ?>  &((inspection-valid:opening scope) =(path (spat pax.scope)))
      scope
    ?>  =((lent scopes) ~(wyt in (silt scopes)))
    [%native-coding-session-open-v2 id.prior project.prior objective.prior selection.prior key.prior worker.prior operations.prior max-eval-work.prior (silt scopes)]
  ?>  (request-valid:opening r)
  r
--
