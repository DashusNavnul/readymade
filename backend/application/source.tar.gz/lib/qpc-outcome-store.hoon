::  Immutable independent outcomes. Selection and work settlement are separate.
/-  nc=native-coding, np=native-coding-provider
/+  q=qpc-native-outcome, obs=qpc-observation, report=qpc-report,
    sessions=native-coding-session, pool=qpc-native-pool,
    tools=cantrip-native-coding-contract, accept=native-coding-accept,
    codec=native-coding-tool-codec, guard=viki-scry-guard
|%
+$  key  [frame=@ux call=@t]
+$  state  [cases=(map @ux cases:q) outcomes=(map key linked:q)]
++  cases-valid
  |=  cs=cases:q
  ^-  ?
  ?&  (gte (lent rows.cs) 2)  (lte (lent rows.cs) 16)
      (lte (met 3 (jam cs)) 32.768)
      =((lent rows.cs) ~(wyt in (silt (turn rows.cs |=(r=case:q proposition.r)))))
      %+  levy  rows.cs
      |=  r=case:q
      ?&  (text-valid:obs `@t`proposition.r)  (text-valid:obs `@t`check.r)
          =(%hoon kind.target.r)  !=(%compile check.r)
          (gte (lent checks.target.r) 1)  (lte (lent checks.target.r) 32)
          =((lent checks.target.r) ~(wyt in (silt (turn checks.target.r |=([name=@tas expression=@t] name)))))
          (lien checks.target.r |=([name=@tas expression=@t] =(name check.r)))
          (levy checks.target.r |=([name=@tas expression=@t] &(!=(name %compile) (gth (met 3 expression) 0) (lte (met 3 expression) 8.192))))
      ==
  ==
++  register
  ::  The content hash was already frozen in the prospective work. Revealing
  ::  those exact definitions here cannot replace the committed checks.
  |=  [s=state cs=cases:q]
  ^-  (each state @tas)
  ?.  (cases-valid cs)  [%| %qpc-outcome-cases-invalid]
  =/  id=@ux  (digest:q cs)
  =/  prior  (~(get by cases.s) id)
  ?^  prior
    ?:(=(cs u.prior) [%& s] [%| %qpc-outcome-cases-conflict])
  ?.  (lth ~(wyt by cases.s) 64)  [%| %qpc-outcome-cases-capacity]
  [%& s(cases (~(put by cases.s) id cs))]
++  linked-valid
  |=  [observed=state:obs s=state value=linked:q]
  ^-  ?
  =/  frame  (~(get by frames.observed) frame.value)
  ?~  frame  %.n
  =/  f=frame:obs  u.frame
  ?.  ?=(%& -.result.f)  %.n
  =/  m  (~(get by manifests.observed) manifest.work.f)
  ?~  m  %.n
  =/  cs  (~(get by cases.s) case-set.work.f)
  ?~  cs  %.n
  =/  rows=(list row:report)
    (skim p.result.f |=(r=row:report =(call.r call.value)))
  ?.  =(1 (lent rows))  %.n
  =/  prediction=row:report  (snag 0 rows)
  ?&  =(values.prediction confidence.value)
      =((digest:obs work.f) work.result.value)
      =(source.work.f prediction.result.value)
      =((turn propositions.u.m |=(p=proposition:obs id.p)) (turn outcomes.result.value |=(o=assessment:q proposition.o)))
      =((turn rows.u.cs |=(r=case:q proposition.r)) (turn propositions.u.m |=(p=proposition:obs id.p)))
      (levy `(list @ux)`~[model-record.value tool-record.value candidate.result.value acceptance.result.value report.result.value] identifier:report)
      (levy outcomes.result.value |=(o=assessment:q &((identifier:report diagnostic.o) (text-valid:obs `@t`reason.o))))
      (lte (met 3 (jam value)) 16.384)
  ==
++  valid
  |=  [observed=state:obs s=state]
  ^-  ?
  ?&  (lte ~(wyt by cases.s) 64)  (lte ~(wyt by outcomes.s) 1.024)
      (levy ~(tap by cases.s) |=([id=@ux cs=cases:q] &(=(id (digest:q cs)) (cases-valid cs))))
      %+  levy  ~(tap by outcomes.s)
      |=  [k=key v=linked:q]
      &(=(k [frame.v call.v]) (linked-valid observed s v))
  ==
++  retain
  |=  [observed=state:obs s=state value=linked:q]
  ^-  (each state @tas)
  ?.  (linked-valid observed s value)  [%| %qpc-outcome-link-invalid]
  =/  k=key  [frame.value call.value]
  =/  prior  (~(get by outcomes.s) k)
  ?^  prior
    ?:(=(value u.prior) [%& s] [%| %qpc-outcome-already-resolved])
  ?.  (lth ~(wyt by outcomes.s) 1.024)  [%| %qpc-outcome-capacity]
  [%& s(outcomes (~(put by outcomes.s) k value))]
++  job
  ::  The canonical Cantrip record of one predicted call. Command supplies
  ::  frame/call IDs only; the call is decoded from the retained model reply.
  |=  [b=bowl:gall in=input:pool m=manifest:obs f=frame:obs call=@t]
  ^-  (each record:tools @tas)
  =/  e=entry:sessions  entry.in
  ?.  &(=(our.b src.b) =(our.b owner.f) =(session.work.f id.session.e))
    [%| %qpc-outcome-owner-mismatch]
  ?.  &((chain:pool e) ?=(%& -.result.f))  [%| %qpc-outcome-journal-invalid]
  =/  models=(list record:sessions)
    (skim records.e |=(r=record:sessions &(=(sequence.r journal.f) ?=(%model -.body.r))))
  ?.  =(1 (lent models))  [%| %qpc-outcome-model-missing]
  =/  model=record:sessions  (snag 0 models)
  ?>  ?=(%model -.body.model)
  ?.  =(reply.f (digest:obs result.body.model))  [%| %qpc-outcome-model-mismatch]
  =/  calls=(list call:np)
    (skim calls.result.body.model |=(c=call:np =(id.c call)))
  ?.  =(1 (lent calls))  [%| %qpc-outcome-call-missing]
  =/  w=work:obs  work.f
  =/  ctx=context:nc
    [project.m configuration.w session.w request.w owner.m source.w]
  =/  decoded  (decode:codec ctx source.w (snag 0 calls))
  ?:  ?=(%| -.decoded)  [%| %qpc-outcome-call-invalid]
  ?.  (agent-live:guard our.b now.b %cantrip)  [%| %qpc-cantrip-unavailable]
  =/  id=@ux  (key:tools p.decoded)
  =/  raw=*
    .^(* %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/job/(scot %ux id)/noun)
  =/  parsed  ((soft ,(unit record:tools)) raw)
  ?~  parsed  [%| %qpc-outcome-tool-invalid]
  ?~  u.parsed  [%| %qpc-outcome-tool-missing]
  [%& u.u.parsed]
++  read
  ::  All evidence comes from the owner stores and these existing private
  ::  Cantrip read paths; no tool is run.
  |=  [b=bowl:gall in=input:pool m=manifest:obs f=frame:obs cs=cases:q call=@t]
  ^-  (each linked:q @tas)
  =/  got  (job b in m f call)
  ?:  ?=(%| -.got)  [%| p.got]
  =/  tool=record:tools  p.got
  =/  result  result.tool
  ?~  result  [%| %qpc-outcome-tool-pending]
  ?.  &(=(grant.in grant.tool) ?=(%candidate -.output.u.result))
    [%| %qpc-outcome-tool-not-candidate]
  =/  candidate=@ux  id.value.output.u.result
  =/  raw=*
    .^(* %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/candidate/(scot %ux candidate)/noun)
  =/  parsed  ((soft ,(unit record:accept)) raw)
  ?~  parsed  [%| %qpc-outcome-acceptance-invalid]
  ?~  u.parsed  [%| %qpc-outcome-acceptance-missing]
  (link:q m f cs entry.in tool u.u.parsed)
++  refusal
  ::  Cantrip finished this predicted call under the session's grant and
  ::  refused it, so no candidate exists and no check can ever run. The
  ::  digest of that record is gap evidence, never an outcome. ~ means not
  ::  refused or not yet known; unknown completion stays unresolved.
  |=  [grant=@ux f=frame:obs call=@t tool=record:tools]
  ^-  (unit @ux)
  ?.  &(=(%finished stage.tool) =(grant grant.tool))  ~
  ?~  result.tool  ~
  ?.  ?=(%refused -.output.u.result.tool)  ~
  `(shax (jam [%qpc-outcome-refused-call-v1 id.f call tool]))
++  refused
  |=  [b=bowl:gall in=input:pool m=manifest:obs f=frame:obs call=@t]
  ^-  (unit @ux)
  =/  got  (job b in m f call)
  ?:  ?=(%| -.got)  ~
  (refusal grant.in f call p.got)
--
