::  /lib/multiplayer-cockpit
::
::  Pure, bounded cockpit projection over canonical multiplayer nouns.  It
::  owns no state and never turns an enabled control into authority.
::
/-  mc=multiplayer-changeset, mm=multiplayer-communication,
    mmb=multiplayer-model-binding, mmw=multiplayer-model-work,
    mn=multiplayer-concurrency, mpc=multiplayer-cockpit,
    mp=multiplayer-project, mr=multiplayer-receipt,
    ms=multiplayer-seat, mw=multiplayer-work
/+  mcl=multiplayer-changeset, mmcl=multiplayer-communication,
    mmbl=multiplayer-model-binding, mmwl=multiplayer-model-work,
    mncl=multiplayer-concurrency, mpl=multiplayer-project,
    mrl=multiplayer-receipt, msl=multiplayer-seat,
    mwl=multiplayer-work
|%
++  max-projects       `@ud`32
++  max-members        `@ud`64
++  max-leases         `@ud`128
++  max-models         `@ud`128
++  max-claims         `@ud`128
++  max-messages       `@ud`128
++  max-changesets     `@ud`128
++  max-conversations  `@ud`64
::
++  enabled
  |=  [action=action:mpc why=@t]
  ^-  control:mpc
  [action %enabled why]
++  disabled
  |=  [action=action:mpc why=@t]
  ^-  control:mpc
  [action %disabled why]
::
++  unique-digests
  |=  items=(list digest:mpc)
  ^-  ?
  =/  seen=(set digest:mpc)  ~
  =/  rest=(list digest:mpc)  items
  |-
  ?~  rest  %.y
  ?:  (~(has in seen) i.rest)  %.n
  $(rest t.rest, seen (~(put in seen) i.rest))
++  source-at
  |=  [sources=(list project-source:mpc) project=project-id:mp]
  ^-  (unit project-source:mpc)
  ?~  sources  ~
  ?:  =(project id.spec.project.i.sources)  `i.sources
  $(sources t.sources)
++  duplicate-project
  |=  sources=(list project-source:mpc)
  ^-  (unit project-id:mp)
  =/  seen=(set project-id:mp)  ~
  =/  rest=(list project-source:mpc)  sources
  |-
  ?~  rest  ~
  =/  project=project-id:mp  id.spec.project.i.rest
  ?:  (~(has in seen) project)  `project
  $(rest t.rest, seen (~(put in seen) project))
::
++  message-map-valid
  |=  [project=project-id:mp messages=(map digest:mpc message:mm)]
  ^-  ?
  %+  levy  ~(tap by messages)
  |=  row=[digest:mpc message:mm]
  ?&  =(-.row digest.+.row)
      (message-valid:mmcl +.row)
      =(project project.body.+.row)
  ==
++  mailbox-valid
  |=  [project=project-id:mp mailbox=mailbox:mm]
  ^-  ?
  ?&  =(project project.mailbox)
      (lte ~(wyt by inbox.mailbox) max-messages)
      (lte ~(wyt by outbox.mailbox) max-messages)
      (message-map-valid project inbox.mailbox)
      (message-map-valid project outbox.mailbox)
  ==
++  message-at
  |=  [mailbox=mailbox:mm digest=digest:mpc]
  ^-  (unit message:mm)
  =/  found=(unit message:mm)  (~(get by inbox.mailbox) digest)
  ?^(found found (~(get by outbox.mailbox) digest))
++  messages-known
  |=  [mailbox=mailbox:mm messages=(list digest:mpc)]
  ^-  ?
  ?~  messages  %.y
  ?~  (message-at mailbox i.messages)  %.n
  $(messages t.messages)
++  reviews-change
  |=  [mailbox=mailbox:mm messages=(list digest:mpc) changeset=digest:mpc]
  ^-  ?
  ?~  messages  %.n
  =/  item=(unit message:mm)  (message-at mailbox i.messages)
  ?~  item  $(messages t.messages)
  ?:  ?-  -.action.body.u.item
        %review  =(changeset changeset.action.body.u.item)
        %comment  %.n
        %mention  %.n
        %reply    %.n
      ==
    %.y
  $(messages t.messages)
++  receipt-at
  |=  [events=(list event:mr) digest=digest:mpc]
  ^-  (unit event:mr)
  ?~  events  ~
  ?:  =(digest digest.i.events)  `i.events
  $(events t.events)
::
++  claim-source-valid
  |=  [source=project-source:mpc claim=claim:mn]
  ^-  ?
  ?.  ?&  (claim-valid:mncl claim)
          =(id.spec.project.source project.body.claim)
      ==
    %.n
  ?~  plan.source  %.n
  =/  task=(unit task-state:mw)
    (~(get by tasks.u.plan.source) task.body.claim)
  ?~  task  %.n
  ?~  workspace.u.task  %.n
  =(workspace.body.claim workspace.u.workspace.u.task)
++  changesets-valid
  |=  source=project-source:mpc
  ^-  ?
  %+  levy  ~(tap by changesets.source)
  |=  row=[digest:mpc changeset-source:mpc]
  ?&  =(-.row digest.changeset.+.row)
      (changeset-valid:mcl sync.+.row changeset.+.row)
      =(id.spec.project.source project.body.changeset.+.row)
  ==
++  source-within-bounds
  |=  source=project-source:mpc
  ^-  ?
  ?&  (lte ~(wyt by members.project.source) max-members)
      (lte (lent claims.source) max-claims)
      (lte ~(wyt by changesets.source) max-changesets)
      (lte (lent conversations.source) max-conversations)
      ?~(registry.source %.y (lte ~(wyt by lease-history.u.registry.source) max-leases))
  ==
++  source-valid
  |=  source=project-source:mpc
  ^-  ?
  =/  project=project:mp  project.source
  ?.  (project-valid:mpl project)  %.n
  ?.  ?~  registry.source
        %.y
      ?&  (registry-valid:msl u.registry.source)
          =(id.spec.project project.u.registry.source)
          =(authority.spec.project authority.u.registry.source)
      ==
    %.n
  ?.  ?~  plan.source
        %.y
      ?&  (plan-valid:mwl u.plan.source)
          =(id.spec.project project.u.plan.source)
          =(authority.spec.project authority.u.plan.source)
      ==
    %.n
  ?.  ?~(mailbox.source %.y (mailbox-valid id.spec.project u.mailbox.source))
    %.n
  ?.  ?~  chain.source
        %.y
      ?&  (valid:mrl u.chain.source)
          =(id.spec.project project.u.chain.source)
          =(authority.spec.project authority-host.u.chain.source)
      ==
    %.n
  ?.  (levy claims.source |=(claim=claim:mn (claim-source-valid source claim)))
    %.n
  (changesets-valid source)
::
++  conversation-valid
  |=  [source=project-source:mpc link=conversation-link:mpc]
  ^-  ?
  ?.  ?&  ?=(^ messages.link)
          (unique-digests messages.link)
          (~(has by changesets.source) changeset.link)
          ?=(^ mailbox.source)
          ?=(^ chain.source)
      ==
    %.n
  =/  mailbox=mailbox:mm  u.mailbox.source
  =/  chain=chain:mr  u.chain.source
  ?.  (messages-known mailbox messages.link)  %.n
  ?.  (reviews-change mailbox messages.link changeset.link)  %.n
  =/  receipt=(unit event:mr)  (receipt-at events.chain receipt.link)
  ?~  receipt  %.n
  =/  exchange=(unit exchange:mc)
    ((soft exchange:mc) payload.body.u.receipt)
  ?~  exchange  %.n
  ?&  =(changeset.link digest.changeset.u.exchange)
      =(action.u.exchange kind.body.u.receipt)
  ==
++  invalid-conversation
  |=  source=project-source:mpc
  ^-  (unit digest:mpc)
  ?~  conversations.source  ~
  ?.  (conversation-valid source i.conversations.source)
    `changeset.i.conversations.source
  $(source source(conversations t.conversations.source))
++  source-refusal
  |=  source=project-source:mpc
  ^-  (unit refusal:mpc)
  =/  project=project-id:mp  id.spec.project.source
  ?.  (source-within-bounds source)  `[%source-overflow project]
  ?.  (source-valid source)  `[%invalid-project-source project]
  =/  invalid=(unit digest:mpc)  (invalid-conversation source)
  ?~(invalid ~ `[%invalid-conversation project u.invalid])
++  first-source-refusal
  |=  sources=(list project-source:mpc)
  ^-  (unit refusal:mpc)
  ?~  sources  ~
  =/  failure=(unit refusal:mpc)  (source-refusal i.sources)
  ?^(failure failure $(sources t.sources))
::
++  pending-for
  |=  [project=project:mp actor=@p]
  ^-  (unit digest:mpc)
  (~(get by pending.project) actor)
++  project-row-for
  |=  [source=project-source:mpc actor=@p active=(unit project-id:mp)]
  ^-  project-row:mpc
  =/  project=project:mp  project.source
  =/  member=(unit member:mp)  (~(get by members.project) actor)
  :*  id.spec.project
      title.spec.project
      authority.spec.project
      base-desk.spec.project
      ?~(member ~ `role.u.member)
      (pending-for project actor)
      ?~(active %.n =(id.spec.project u.active))
  ==
++  controls-for-source
  |=  [source=project-source:mpc actor=@p observed-at=@da active=(unit project-id:mp)]
  ^-  (list control:mpc)
  =/  project=project:mp  project.source
  =/  id=project-id:mp  id.spec.project
  =/  controls=(list control:mpc)  ~
  =/  invitation=(unit digest:mpc)  (pending-for project actor)
  =?  controls  ?=(^ invitation)
    =/  item=invitation:mp  (~(got by invitations.project) u.invitation)
    =/  open=?  (lth observed-at expires-at.body.item)
    [?:(open (enabled [%join id u.invitation] 'accept exact ship-targeted invitation') (disabled [%join id u.invitation] 'invitation expired')) controls]
  =/  member=(unit member:mp)  (~(get by members.project) actor)
  =?  controls  ?=(^ member)
    =/  may-leave=?  !=(actor authority.spec.project)
    =/  is-active=?  ?~(active %.n =(id u.active))
    %+  weld
      :~  ?:(may-leave (enabled [%leave id] 'record self-departure in project history') (disabled [%leave id] 'authority ship cannot abandon its project'))
          ?:(is-active (disabled [%switch id] 'project is already active') (enabled [%switch id] 'select this joined project'))
      ==
    controls
  controls
++  all-controls
  |=  [sources=(list project-source:mpc) actor=@p observed-at=@da active=(unit project-id:mp)]
  ^-  (list control:mpc)
  ?~  sources  ~
  (weld (controls-for-source i.sources actor observed-at active) $(sources t.sources))
::
++  registry-current
  |=  source=project-source:mpc
  ^-  ?
  ?~  registry.source  %.n
  ?~  head.project.source  %.n
  =(u.head.project.source project-head.u.registry.source)
++  lease-current-for-binding
  |=  [source=project-source:mpc binding=binding:mmb observed-at=@da]
  ^-  ?
  ?~  registry.source  %.n
  ?.  (registry-current source)  %.n
  =/  registry=registry:ms  u.registry.source
  =/  body=binding-body:mmb  body.binding
  =/  generation=(unit @ud)
    (~(get by current-seats.registry) seat.key.body)
  ?~  generation  %.n
  ?.  =(u.generation lease-generation.body)  %.n
  =/  lease=(unit lease:ms)
    (~(get by lease-history.registry) [seat.key.body u.generation])
  ?~  lease  %.n
  ?&  =(actor.body holder.u.lease)
      =(role-epoch.body role-epoch.u.lease)
      ?=(%active -.status.u.lease)
      (lth observed-at expires-at.u.lease)
  ==
++  model-state-bound
  |=  [routes=state:mmb work=state:mmw]
  ^-  ?
  %+  levy  ~(tap by assignments.work)
  |=  row=[route-key:mmb assignment:mmw]
  =/  route=(unit route-state:mmb)  (~(get by routes.routes) -.row)
  ?~  route  %.n
  ?&  =(current-binding.+.row digest.binding.u.route)
      =(current-identity.+.row identity.body.binding.u.route)
  ==
++  model-rows
  |=  [source=project-source:mpc input=input:mpc]
  ^-  (list model-row:mpc)
  =/  project=project-id:mp  id.spec.project.source
  =/  routes=(list [route-key:mmb route-state:mmb])
    %+  skim  ~(tap by routes.routes.input)
    |=  row=[route-key:mmb route-state:mmb]
    =(project project.-.row)
  %+  turn  routes
  |=  row=[route-key:mmb route-state:mmb]
  =/  binding=binding:mmb  binding.+.row
  =/  assignment=(unit assignment:mmw)
    (~(get by assignments.model-work.input) -.row)
  :*  task.-.row
      seat.-.row
      actor.body.binding
      digest.binding
      identity.body.binding
      (lease-current-for-binding source binding observed-at.input)
      ?~(assignment %.n =(digest.binding current-binding.u.assignment))
  ==
++  lease-rows
  |=  source=project-source:mpc
  ^-  (list lease-row:mpc)
  ?~  registry.source  ~
  =/  registry=registry:ms  u.registry.source
  %+  turn  ~(tap by lease-history.registry)
  |=  row=[[@tas @ud] lease:ms]
  =/  lease=lease:ms  +.row
  =/  current=(unit @ud)  (~(get by current-seats.registry) seat.lease)
  :*  seat.lease
      generation.lease
      holder.lease
      role.lease
      expires-at.lease
      status.lease
      ?~(current %.n =(generation.lease u.current))
  ==
++  member-rows
  |=  [source=project-source:mpc models=(list model-row:mpc) leases=(list lease-row:mpc)]
  ^-  (list member-row:mpc)
  %+  turn  ~(tap by members.project.source)
  |=  row=[@p member:mp]
  =/  ship=@p  -.row
  =/  presence=(unit presence:mm)  (~(get by presence.source) ship)
  :*  ship
      role.+.row
      joined-at.+.row
      ?~(presence %offline state.u.presence)
      (skim leases |=(lease=lease-row:mpc =(ship holder.lease)))
      (skim models |=(model=model-row:mpc =(ship ship.model)))
  ==
::
++  claim-contested
  |=  [claim=claim:mn claims=(list claim:mn) observed-at=@da]
  ^-  ?
  %+  lien  claims
  |=(other=claim:mn ?=(^ (overlap:mncl claim other observed-at)))
++  task-contested
  |=  [task=task-id:mw claims=(list claim:mn) observed-at=@da]
  ^-  ?
  %+  lien  claims
  |=  claim=claim:mn
  ?&  =(task task.body.claim)
      (claim-contested claim claims observed-at)
  ==
++  floor-status-for
  |=  [task=task-state:mw source=project-source:mpc observed-at=@da]
  ^-  floor-status:mpc
  ?:  (task-contested id.body.task.task claims.source observed-at)  %contested
  ?~  claim.task  %waiting
  =/  presence=(unit presence:mm)
    (~(get by presence.source) actor.u.claim.task)
  ?~  presence  %waiting
  ?-  state.u.presence
    %working  %working
    %blocked  %blocked
    %waiting  %waiting
    %offline  %waiting
  ==
++  task-rows
  |=  [source=project-source:mpc models=(list model-row:mpc) plan=plan:mw observed-at=@da]
  ^-  (list task-row:mpc)
  %+  turn  ~(tap by tasks.plan)
  |=  row=[task-id:mw task-state:mw]
  =/  state=task-state:mw  +.row
  :*  -.row
      summary.body.task.state
      dependencies.body.task.state
      completion.body.task.state
      ?=(^ dispatch.state)
      claim.state
      workspace.state
      (skim models |=(model=model-row:mpc =(-.row task.model)))
      (floor-status-for state source observed-at)
  ==
++  conversation-rows
  |=  source=project-source:mpc
  ^-  (list conversation-row:mpc)
  =/  chain=chain:mr  (need chain.source)
  %+  turn  conversations.source
  |=  link=conversation-link:mpc
  =/  changeset-source=changeset-source:mpc
    (~(got by changesets.source) changeset.link)
  =/  changeset=changeset:mc  changeset.changeset-source
  =/  receipt=event:mr  (need (receipt-at events.chain receipt.link))
  :*  messages.link
      changeset.link
      receipt.link
      actor.body.changeset
      (lent changes.body.changeset)
      occurred-at.body.receipt
  ==
++  active-view-for
  |=  [source=project-source:mpc input=input:mpc plan=plan:mw]
  ^-  active-view:mpc
  =/  models=(list model-row:mpc)  (model-rows source input)
  =/  leases=(list lease-row:mpc)  (lease-rows source)
  :*  (project-row-for source actor.input active.input)
      (registry-current source)
      (member-rows source models leases)
      models
      leases
      intent.plan
      (task-rows source models plan observed-at.input)
      (conversation-rows source)
  ==
::
++  project
  |=  input=input:mpc
  ^-  result:mpc
  ?.  ?&  (state-valid:mmbl routes.input)
          (lte ~(wyt by routes.routes.input) max-models)
      ==
    [%| [%invalid-routes ~]]
  ?.  ?&  (state-valid:mmwl model-work.input)
          (lte ~(wyt by assignments.model-work.input) max-models)
          (model-state-bound routes.input model-work.input)
      ==
    [%| [%invalid-model-work ~]]
  ?:  (gth (lent projects.input) max-projects)
    [%| [%source-overflow 'catalog']]
  =/  duplicate=(unit project-id:mp)  (duplicate-project projects.input)
  ?^  duplicate  [%| [%duplicate-project u.duplicate]]
  =/  source-failure=(unit refusal:mpc)
    (first-source-refusal projects.input)
  ?^  source-failure  [%| u.source-failure]
  =/  project-rows=(list project-row:mpc)
    (turn projects.input |=(source=project-source:mpc (project-row-for source actor.input active.input)))
  =/  controls=(list control:mpc)
    %+  weld
      ~[(enabled [%create ~] 'create an authority-bound project')]
    (all-controls projects.input actor.input observed-at.input active.input)
  ?~  active.input
    [%& [%multiplayer-cockpit-v1 actor.input observed-at.input project-rows controls ~ %.n]]
  =/  active-source=(unit project-source:mpc)
    (source-at projects.input u.active.input)
  ?~  active-source  [%| [%active-missing u.active.input]]
  ?.  (~(has by members.project.u.active-source) actor.input)
    [%| [%active-not-member u.active.input actor.input]]
  ?~  plan.u.active-source  [%| [%active-plan-missing u.active.input]]
  =/  view=active-view:mpc
    (active-view-for u.active-source input u.plan.u.active-source)
  [%& [%multiplayer-cockpit-v1 actor.input observed-at.input project-rows controls `view %.n]]
--
