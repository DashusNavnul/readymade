::  Private Viki app integration gate, not an action payload that starts a
::  model. The app must route the typed command below through this gate.
/-  nc=native-coding
/+  loop=native-coding-loop, sessions=native-coding-session,
    project=native-coding-project, resolve=native-coding-session-project
|%
+$  command
  [%qpc-native-note-v1 session=@ux head=@ux source=revision:nc reason=?(%qpc-admission-requested %qpc-selection-attempted)]
++  apply
  |=  [b=bowl:gall held=state:loop command=command]
  ^-  (quip card:agent:gall state:loop)
  ?.  =(our.b src.b)  [~ held]
  =/  found  (~(get by sessions.held) session.command)
  ?~  found  [~ held]
  =/  e=entry:sessions  u.found
  ?.  ?&  =(our.b owner.session.e)  =(our.b worker.e)
          =(%paused phase.e)  ?=(~ pending.e)  ?=(~ calls.e)
          =(head.e `head.command)  =(source.command working.session.e)
          (qpc-required:loop b session.command)
      ==  [~ held]
  =/  config  (resolve:resolve our.b now.b projects.held session.command project.session.e)
  ?:  ?=(%| -.config)  [~ held]
  =/  current  (current:project our.b now.b p.config)
  ?:  ?=(%| -.current)  [~ held]
  ?.  =(source.command revision.working.p.current)  [~ held]
  =/  appended  (append:sessions e now.b [%status %paused reason.command])
  ?:  ?=(%| -.appended)  [~ held]
  (apply:loop b held p.appended)
--
