::  Cantrip-owned inputs only; public commands carry judgment IDs, not state.
::  No Cantrip self-scry, Nock evaluation, write, watch or attestation here.
/+  land=cantrip-connected-land, judgment=viki-vibecoding-connected-judgment,
    checks=cantrip-connected-checks, preview=vibecoding-connected-preview,
    preview-read=vibecoding-connected-preview-read,
    compilation=cantrip-connected-compile-ledger, write=cantrip-connected-write,
    editor=cantrip-editor-save, editor-read=cantrip-editor-save-read,
    law=cantrip-law-window, legacy=cantrip-vibecoding-local-land,
    legacy-read=cantrip-vibecoding-local-land-read, demo=vibecoding-demo,
    dsr=desk-shell-read, vsg=viki-scry-guard, clflect=cantrip-connected-land-flect
|%
+$  owned
  $:  checks=ledger:checks  compilations=ledger-v2:compilation
      writes=ledger-v2:write  saves=ledger:editor
  ==
+$  live-egg
  ::  Opaque type carriers avoid traversing Gall/Shoe's recursive vase mold.
  $:  version=$?(%16 %20)  %live  control=*  run=*  sub=*  stats=*
      bitt=*  boat=*  boar=*  code=*
      old-state=[%| saved=[type=* noun=*]]  beak=beak  rest=*
  ==
++  judgments
  |=  [our=@p actor=@p at=@da]
  ^-  (each ledger:judgment @tas)
  ?.  =(our actor)  [%| %foreign-actor]
  ?.  (agent-live:vsg our at %viki)  [%| %viki-unavailable]
  =/  egg=live-egg
    .^(live-egg %gv /(scot %p our)/viki/(scot %da at)/$)
  =/  shoe
    ((soft ,[%shoe-app inner=[type=* noun=*] console=*]) noun.saved.old-state.egg)
  ?~  shoe  [%| %judgments-not-supported]
  ?.  ?=([%viki-familiar-state-v10 *] noun.inner.u.shoe)
    [%| %judgments-not-supported]
  ::  Full canonical owner ledger, not the externally supplied/Graf copy.
  =/  held=ledger:judgment
    .^(ledger:judgment %gx /(scot %p our)/viki/(scot %da at)/vibecoding/connected-judgments-v2/noun)
  =/  checked  (restore:judgment our at held)
  ?:  ?=(%| -.checked)  [%| p.checked]
  [%& held]
++  head
  |=  [our=@p at=@da desk=@tas]
  ^-  (unit [commit=commit:editor files=(map path lobe:clay)])
  =/  d=domo:clay  .^(domo:clay %cv (beam:dsr our at desk /))
  =/  key  (~(get by hit.d) let.d)
  ?~  key  ~
  =/  y=yaki:clay
    .^(yaki:clay %cs (beam:dsr our at desk /yaki/(scot %uv u.key)))
  ?.  =(r.y u.key)  ~
  `[[u.key p.y t.y] q.y]
++  basis
  |=  [our=@p actor=@p at=@da]
  ^-  (each basis:land @tas)
  ?.  =(our actor)  [%| %foreign-actor]
  =/  working  (read:editor-read our actor at)
  ?:  ?=(%| -.working)  [%| p.working]
  =/  accepted  (head our at base:demo)
  =/  current  (head our at work:demo)
  ?~  accepted  [%| %accepted-parent-missing]
  ?~  current  [%| %work-parent-missing]
  ?.  =(parent.p.working id.commit.u.current)  [%| %work-parent-changed]
  =/  b=basis:land
    [p.working id.commit.u.accepted files.u.accepted files.u.current]
  ?.  (basis-valid:land b)  [%| %project-support-changed]
  [%& b]
++  load
  |=  [our=@p actor=@p at=@da c=command:land own=owned window=window:law]
  ^-  (each admission:land @tas)
  -:(load-evidence our actor at c own window)
::  +load-evidence: the decision with the act the judge saw -- command,
::  Viki's ledger, the checks record and its observation, the stated intent,
::  the current basis -- so the caller can keep a receipt of the judgment
::  (lib/cantrip-connected-land-flect) without reading twice.  No act when
::  the read itself refused before the judge ran.
++  load-evidence
  |=  [our=@p actor=@p at=@da c=command:land own=owned window=window:law]
  ^-  [(each admission:land @tas) (unit act:clflect)]
  ?.  =(our actor)  [[%| %foreign-actor] ~]
  ?.  (command-valid:land c)  [[%| %command-invalid] ~]
  =/  held  (judgments our actor at)
  ?:  ?=(%| -.held)  [[%| p.held] ~]
  =/  selected  (select:land our at p.held c)
  ?:  ?=(%| -.selected)  [[%| p.selected] ~]
  =/  expected=record:checks  record.body.judgment.p.selected
  =/  request=command:checks  request.expected
  =/  found  (lookup:checks our actor at checks.own request)
  ?:  ?=(%| -.found)  [[%| p.found] ~]
  ?~  p.found  [[%| %checks-missing] ~]
  ?.  =(expected u.p.found)  [[%| %checks-mismatch] ~]
  =/  sources=owned-v2:preview-read
    :*  (~(get by compilations.own) write.request)
        [(~(get by writes.own) write.request) (~(get by saves.own) write.request)]
    ==
  =/  evidence  (context-v2:preview-read our actor at write.request sources)
  ?:  ?=(%| -.evidence)  [[%| p.evidence] ~]
  =/  e=evidence-v2:preview-read  p.evidence
  ?.  =(`compilation.expected record.attempt.e)  [[%| %compilation-changed] ~]
  =/  admitted
    (judge-v2:preview our actor at image.request attempt.e view.e rows.e stated.e window)
  =/  current  (observe:checks our actor at checks.own request admitted)
  ?:  ?=(%| -.current)  [[%| p.current] ~]
  =/  b  (basis our actor at)
  ?:  ?=(%| -.b)  [[%| p.b] ~]
  =/  a=act:clflect  [c p.held u.p.found p.current stated.e p.b]
  [(judge:land our actor at c p.held u.p.found p.current stated.e p.b window) `a]
++  admit
  |=  [our=@p actor=@p at=@da c=command:land own=owned window=window:law]
  ^-  (each admission:land @tas)
  -:(admit-evidence our actor at c own window)
++  admit-evidence
  |=  [our=@p actor=@p at=@da c=command:land own=owned window=window:law]
  ^-  [(each admission:land @tas) (unit act:clflect)]
  ?.  =(our actor)  [[%| %foreign-actor] ~]
  ?.  (command-valid:land c)  [[%| %command-invalid] ~]
  =/  found  (mule |.((load-evidence our actor at c own window)))
  ?:  ?=(%| -.found)  [[%| %landing-read-unavailable] ~]
  p.found
++  start
  ::  Future app supplies all journals, atomically saves next and emits cards.
  ::  Replay returns before any source/permission read; it never resubmits.
  |=  $:  our=@p  actor=@p  at=@da  held=ledger:land  old=ledger:legacy
          c=command:land  own=owned  window=window:law
      ==
  ^-  (each transition:land @tas)
  -:(start-evidence our actor at held old c own window)
::  +start-evidence: +start with the act the judge saw, when it ran
++  start-evidence
  |=  $:  our=@p  actor=@p  at=@da  held=ledger:land  old=ledger:legacy
          c=command:land  own=owned  window=window:law
      ==
  ^-  [(each transition:land @tas) (unit act:clflect)]
  =/  prior  (lookup:land our actor at held c)
  ?:  ?=(%| -.prior)  [[%| p.prior] ~]
  ?^  p.prior  [[%& [held u.p.prior %.y ~]] ~]
  ?:  (gte ~(wyt by held) 128)  [[%| %landing-capacity] ~]
  ?.  (legacy-ready:land our at held)  [[%| %landing-unresolved] ~]
  =/  [admitted=(each admission:land @tas) ev=(unit act:clflect)]
    (admit-evidence our actor at c own window)
  ?:  ?=(%| -.admitted)  [[%| p.admitted] ev]
  [(reserve:land our actor at held old p.admitted) ev]
++  reconcile-legacy
  ::  Bounded compatibility bridge: existing legacy observation semantics.
  ::  The app persists this returned ledger beside any new reservation. No
  ::  imported observation, historical relabeling, retry or effect is added.
  |=  [our=@p actor=@p at=@da held=ledger:legacy]
  ^-  (each ledger:legacy @tas)
  ?.  =(our actor)  [%| %foreign-actor]
  ?.  (ledger-valid:legacy held)  [%| %legacy-ledger-invalid]
  =/  remaining  ~(tap by held)
  |-  ^-  (each ledger:legacy @tas)
  ?~  remaining  [%& held]
  =/  r=record:legacy  q.i.remaining
  ?.  &(=(our actor.admission.r) (lte at.admission.r at))
    [%| %legacy-owner-or-time-invalid]
  ?.  ?~(observation.r %.y (lte at.u.observation.r at))
    [%| %legacy-owner-or-time-invalid]
  ?:  =(%applied status.r)  $(remaining t.remaining)
  =/  seen  (mule |.((observe:legacy-read our actor at r)))
  ?:  ?=(%| -.seen)  [%| %legacy-observation-unavailable]
  ?~  p.seen  [%| %legacy-observation-unavailable]
  =/  next=record:legacy  (observe:legacy r u.p.seen)
  $(remaining t.remaining, held (~(put by held) p.i.remaining next))
++  history
  ::  Pinned accepted revision, independent of today's work/accepted heads.
  |=  [our=@p at=@da a=admission:land]
  ^-  (unit history:land)
  =/  number=@ud  +(number.base.current.working.current.a)
  =/  d=domo:clay  .^(domo:clay %cv (beam:dsr our at base:demo /))
  =/  key  (~(get by hit.d) number)
  ?~  key  ~
  =/  y=yaki:clay
    .^(yaki:clay %cs (beam:dsr our at base:demo /yaki/(scot %uv u.key)))
  ?.  =(r.y u.key)  ~
  =/  root=@uv
    .^(@uv %cz ~[(scot %p our) base:demo (scot %ud number)])
  =/  h=history:land
    [%cantrip-connected-land-history-v2 our at [base:demo number root] [u.key p.y t.y] q.y]
  ?.  (historical-confirmed:land a h)  ~
  `h
++  recovery
  |=  [our=@p actor=@p at=@da r=record:land]
  ^-  (each recovery:land @tas)
  ?.  &(=(our actor) =(our owner.admission.r))  [%| %foreign-actor]
  ?.  (record-valid:land r)  [%| %landing-record-invalid]
  =/  b  (basis our actor at)
  ?:  ?=(%| -.b)  [%| p.b]
  ?.  (fence-valid:land admission.r p.b)  [%| %observation-not-later]
  [%& [p.b (history our at admission.r)]]
++  observe
  ::  No Viki/Graf freshness is needed to prove the historical Clay effect.
  |=  [our=@p actor=@p at=@da r=record:land]
  ^-  (each record:land @tas)
  ?.  &(=(our actor) =(our owner.admission.r))  [%| %foreign-actor]
  ?.  (record-valid:land r)  [%| %landing-record-invalid]
  ?:  =(%applied phase.r)  [%& r]
  =/  observed  (mule |.((recovery our actor at r)))
  ?:  ?=(%| -.observed)  [%| %landing-read-unavailable]
  ?:  ?=(%| -.p.observed)  [%| p.p.observed]
  [%& (observe:land r p.p.observed)]
--
