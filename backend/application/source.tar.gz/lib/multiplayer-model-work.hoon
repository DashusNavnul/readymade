::  /lib/multiplayer-model-work
::
::  Pure Steps 66-70 law.  Context is a bounded list of content-addressed Graf
::  references; tools are a strict subset of one task ceiling; every attempt
::  gets a resource receipt; failover appends both identities instead of
::  rewriting the failed model as its replacement.
::
/-  graf-sur=graf, ma=multiplayer-act, mmb=multiplayer-model-binding,
    mmw=multiplayer-model-work, mw=multiplayer-work
/+  mal=multiplayer-act, mmbl=multiplayer-model-binding, mwl=multiplayer-work
|%
++  max-context-handles  `@ud`16
++  max-context-bytes  `@ud`4.096
++  max-tool-calls  `@ud`64
++  initial-state
  ^-  state:mmw
  [1 ~ ~]
::
++  context-digest
  |=  body=context-body:mmw
  ^-  digest:mmw
  `@ux`(shax (jam [%multiplayer-model-context-v1 body]))
++  authority-digest
  |=  body=authority-body:mmw
  ^-  digest:mmw
  `@ux`(shax (jam [%multiplayer-model-authority-v1 body]))
++  receipt-digest
  |=  body=receipt-body:mmw
  ^-  digest:mmw
  `@ux`(shax (jam [%multiplayer-model-work-receipt-v1 body]))
++  reassignment-digest
  |=  body=reassignment-body:mmw
  ^-  digest:mmw
  `@ux`(shax (jam [%multiplayer-model-reassignment-v1 body]))
++  assignment-id
  |=  key=route-key:mmb
  ^-  digest:mmw
  `@ux`(shax (jam [%multiplayer-model-assignment-v1 key]))
::
++  handles-bytes
  |=  handles=(list context-handle:mmw)
  ^-  @ud
  (roll handles |=([handle=context-handle:mmw total=@ud] (add summary-bytes.handle total)))
++  handles-valid
  |=  handles=(list context-handle:mmw)
  ^-  ?
  ?~  handles  %.y
  ?&  !=(0 ref-id.i.handles)
      !=(%$ kind.i.handles)
      !=(0 summary-digest.i.handles)
      (gth summary-bytes.i.handles 0)
      (lte summary-bytes.i.handles 320)
      ?~(path.i.handles %.y (lte (met 3 u.path.i.handles) 256))
      $(handles t.handles)
  ==
++  unique-handles
  |=  handles=(list context-handle:mmw)
  ^-  ?
  =((lent handles) ~(wyt in (silt (turn handles |=(handle=context-handle:mmw ref-id.handle)))))
++  handle-for
  |=  ref=graf-viki-ref:graf-sur
  ^-  context-handle:mmw
  [ref-id.ref kind.ref `@ux`(shax summary.ref) (met 3 summary.ref) path.ref]
++  context-valid
  |=  context=context:mmw
  ^-  ?
  =/  body=context-body:mmw  body.context
  ?&  =(1 version.body)
      !=(0 project.key.body)
      !=(0 task.key.body)
      !=(0 seat.key.body)
      !=(0 binding-digest.body)
      !=(0 task-digest.body)
      !=(0 workspace-digest.body)
      (gth byte-budget.body 0)
      (lte byte-budget.body max-context-bytes)
      ?=(^ handles.body)
      (lte (lent handles.body) max-context-handles)
      (handles-valid handles.body)
      (unique-handles handles.body)
      (lte (handles-bytes handles.body) byte-budget.body)
      =((context-digest body) digest.context)
  ==
++  context-for
  |=  $:  binding=binding:mmb
          plan=plan:mw
          refs=(list graf-viki-ref:graf-sur)
          byte-budget=@ud
      ==
  ^-  context-result:mmw
  ?.  (binding-valid:mmbl binding)  [%| [%invalid-binding ~]]
  ?.  (plan-valid:mwl plan)  [%| [%invalid-context ~]]
  =/  bind-body=binding-body:mmb  body.binding
  ?.  =(project.plan project.key.bind-body)  [%| [%invalid-context ~]]
  =/  found=(unit task-state:mw)  (~(get by tasks.plan) task.key.bind-body)
  ?~  found  [%| [%task-missing task.key.bind-body]]
  =/  task-state=task-state:mw  u.found
  ?~  workspace.task-state  [%| [%task-not-ready task.key.bind-body]]
  =/  workspace=workspace-grant:mw  u.workspace.task-state
  ?.  =(digest.workspace workspace-digest.bind-body)
    [%| [%invalid-context ~]]
  =/  handles=(list context-handle:mmw)  (turn refs handle-for)
  =/  body=context-body:mmw
    :*  1
        key.bind-body
        digest.binding
        digest.task.task-state
        workspace-digest.bind-body
        byte-budget
        handles
    ==
  =/  context=context:mmw  [body (context-digest body)]
  ?.  (context-valid context)  [%| [%invalid-context ~]]
  [%& context]
::
++  action-for
  |=  tool=tool:mmw
  ^-  (unit action:ma)
  ?-  tool
    %graf-axis-read      ~
    %stage-changeset    `%stage-changeset
    %land-changeset     `%land-changeset
    %discard-changeset  `%discard-changeset
  ==
++  tools-fit
  |=  [tools=(list tool:mmw) ceiling=ceiling:ma]
  ^-  ?
  ?~  tools  %.y
  =/  action=(unit action:ma)  (action-for i.tools)
  ?&  ?~(action %.y (~(has in actions.ceiling) u.action))
      $(tools t.tools)
  ==
++  authority-valid
  |=  authority=authority:mmw
  ^-  ?
  =/  body=authority-body:mmw  body.authority
  ?&  =(1 version.body)
      !=(0 project.key.body)
      !=(0 task.key.body)
      !=(0 seat.key.body)
      !=(0 binding-digest.body)
      !=(0 task-digest.body)
      !=(0 workspace-digest.body)
      !=(0 ceiling-digest.body)
      (gth ~(wyt in tools.body) 0)
      (lte ~(wyt in tools.body) 4)
      (gth max-tool-calls.body 0)
      (lte max-tool-calls.body max-tool-calls)
      (gth expires-at.body issued-at.body)
      =((authority-digest body) digest.authority)
  ==
++  authority-bound
  |=  [plan=plan:mw binding=binding:mmb authority=authority:mmw]
  ^-  ?
  ?.  ?&  (plan-valid:mwl plan)
          (binding-valid:mmbl binding)
          (authority-valid authority)
      ==
    %.n
  =/  bind-body=binding-body:mmb  body.binding
  =/  auth-body=authority-body:mmw  body.authority
  =/  key=route-key:mmb  key.bind-body
  ?.  ?&  =(key key.auth-body)
          =(digest.binding binding-digest.auth-body)
          =(project.plan project.key)
      ==
    %.n
  =/  found=(unit task-state:mw)  (~(get by tasks.plan) task.key)
  ?~  found  %.n
  =/  task-state=task-state:mw  u.found
  ?~  dispatch.task-state  %.n
  ?~  workspace.task-state  %.n
  =/  dispatch=dispatch:mw  u.dispatch.task-state
  =/  workspace=workspace-grant:mw  u.workspace.task-state
  =/  ceiling=ceiling:ma  ceiling.dispatch
  ?&  =(digest.task.task-state task-digest.auth-body)
      =(digest.workspace workspace-digest.bind-body)
      =(digest.workspace workspace-digest.auth-body)
      =(workspace.workspace workspace.ceiling)
      =(`digest:mmw`ceiling-digest.dispatch ceiling-digest.auth-body)
      =(`digest:mmw`ceiling-digest.dispatch `digest:mmw`(ceiling-digest:mal ceiling))
      (~(has in actor-classes.ceiling) %model)
      (tools-fit ~(tap in tools.auth-body) ceiling)
      (gte issued-at.auth-body dispatched-at.dispatch)
      (lte expires-at.auth-body expires-at.ceiling)
      (lte expires-at.auth-body expires-at.bind-body)
  ==
++  authority-for
  |=  $:  plan=plan:mw
          binding=binding:mmb
          tools=(set tool:mmw)
          maximum=@ud
          issued-at=@da
          expires-at=@da
      ==
  ^-  authority-result:mmw
  ?.  (plan-valid:mwl plan)  [%| [%invalid-authority ~]]
  ?.  (binding-valid:mmbl binding)  [%| [%invalid-binding ~]]
  =/  bind-body=binding-body:mmb  body.binding
  =/  key=route-key:mmb  key.bind-body
  =/  found=(unit task-state:mw)  (~(get by tasks.plan) task.key)
  ?~  found  [%| [%task-missing task.key]]
  =/  task-state=task-state:mw  u.found
  ?~  dispatch.task-state  [%| [%task-not-ready task.key]]
  ?~  workspace.task-state  [%| [%task-not-ready task.key]]
  =/  dispatch=dispatch:mw  u.dispatch.task-state
  =/  workspace=workspace-grant:mw  u.workspace.task-state
  =/  ceiling=ceiling:ma  ceiling.dispatch
  ?.  ?&  =(project.plan project.key)
          =(digest.workspace workspace-digest.bind-body)
          =(workspace.workspace workspace.ceiling)
          =(ceiling-digest.dispatch ceiling-digest.workspace)
          =(`digest:mmw`ceiling-digest.dispatch `digest:mmw`(ceiling-digest:mal ceiling))
          (~(has in actor-classes.ceiling) %model)
          (tools-fit ~(tap in tools) ceiling)
          (gth maximum 0)
          (lte maximum max-tool-calls)
          (gte issued-at dispatched-at.dispatch)
          (gth expires-at issued-at)
          (lte expires-at expires-at.ceiling)
          (lte expires-at expires-at.bind-body)
      ==
    [%| [%authority-mismatch ~]]
  =/  body=authority-body:mmw
    :*  1  key  digest.binding  digest.task.task-state  digest.workspace
        `digest:mmw`ceiling-digest.dispatch  tools  maximum  issued-at  expires-at
    ==
  =/  authority=authority:mmw  [body (authority-digest body)]
  ?.  (authority-bound plan binding authority)  [%| [%invalid-authority ~]]
  [%& authority]
::
++  tool-use-valid
  |=  [use=tool-use:mmw authority=authority:mmw expected=@ud]
  ^-  ?
  ?&  =(expected ordinal.use)
      (~(has in tools.body.authority) tool.use)
      !=(0 argument-digest.use)
      (gte started-at.use issued-at.body.authority)
      (gte finished-at.use started-at.use)
      (lth started-at.use expires-at.body.authority)
  ==
++  tool-uses-valid
  |=  [uses=(list tool-use:mmw) authority=authority:mmw expected=@ud]
  ^-  ?
  ?~  uses  %.y
  ?&  (tool-use-valid i.uses authority expected)
      $(uses t.uses, expected +(expected))
  ==
++  usage-valid
  |=  [usage=usage:mmw authority=authority:mmw]
  ^-  ?
  ?&  (gte started-at.usage issued-at.body.authority)
      (gte finished-at.usage started-at.usage)
      (lte finished-at.usage expires-at.body.authority)
      !=(0 usage-json-digest.usage)
      (lte (lent tools.usage) max-tool-calls.body.authority)
      (tool-uses-valid tools.usage authority 1)
  ==
++  receipt-valid
  |=  receipt=receipt:mmw
  ^-  ?
  =/  body=receipt-body:mmw  body.receipt
  ?&  =(1 version.body)
      !=(0 assignment-id.body)
      !=(0 attempt.body)
      !=(0 binding-digest.body)
      !=(0 (identity-digest:mmbl identity.body))
      !=(0 request-key.body)
      !=(0 context-digest.body)
      !=(0 authority-digest.body)
      !=(0 usage-json-digest.usage.body)
      ?-  outcome.body
        %completed  ?=(^ result-digest.body)
        %failed     %.y
        %timed-out  %.y
        %cancelled  %.y
      ==
      =((receipt-digest body) digest.receipt)
  ==
++  assignment-valid
  |=  assignment=assignment:mmw
  ^-  ?
  ?&  !=(0 id.assignment)
      =(id.assignment (assignment-id key.assignment))
      !=(0 current-binding.assignment)
      !=(0 attempt.assignment)
      (levy receipts.assignment receipt-valid)
  ==
++  state-valid
  |=  state=state:mmw
  ^-  ?
  ?&  =(1 version.state)
      %+  levy  ~(tap by assignments.state)
      |=  row=[route-key:mmb assignment:mmw]
      ?&  =(-.row key.+.row)
          (assignment-valid +.row)
      ==
      %+  levy  ~(tap by receipts.state)
      |=  row=[digest:mmw receipt:mmw]
      ?&  =(-.row digest.+.row)
          (receipt-valid +.row)
      ==
  ==
::
++  open
  |=  $:  state=state:mmw
          routes=state:mmb
          plan=plan:mw
          key=route-key:mmb
          context=context:mmw
          authority=authority:mmw
      ==
  ^-  open-result:mmw
  ?.  (state-valid state)  [%| [%invalid-state ~]]
  ?.  (state-valid:mmbl routes)  [%| [%invalid-binding ~]]
  ?:  (~(has by assignments.state) key)  [%| [%assignment-exists key]]
  =/  route=(unit route-state:mmb)  (~(get by routes.routes) key)
  ?~  route  [%| [%invalid-binding ~]]
  =/  binding=binding:mmb  binding.u.route
  ?.  ?&  (context-valid context)
          (authority-bound plan binding authority)
          =(key key.body.context)
          =(key key.body.authority)
          =(digest.binding binding-digest.body.context)
          =(digest.binding binding-digest.body.authority)
          =(task-digest.body.context task-digest.body.authority)
          =(workspace-digest.body.context workspace-digest.body.authority)
      ==
    [%| [%authority-mismatch ~]]
  =/  id=digest:mmw  (assignment-id key)
  =/  assignment=assignment:mmw
    [id key digest.binding identity.body.binding 1 ~ ~]
  =/  next=state:mmw
    state(assignments (~(put by assignments.state) key assignment))
  [%& [next assignment]]
::
++  record
  |=  $:  state=state:mmw
          routes=state:mmb
          plan=plan:mw
          key=route-key:mmb
          context=context:mmw
          authority=authority:mmw
          request-key=@t
          usage=usage:mmw
          outcome=outcome:mmw
          result-digest=(unit digest:mmw)
      ==
  ^-  record-result:mmw
  ?.  (state-valid state)  [%| [%invalid-state ~]]
  ?.  (state-valid:mmbl routes)  [%| [%invalid-binding ~]]
  =/  found=(unit assignment:mmw)  (~(get by assignments.state) key)
  ?~  found  [%| [%assignment-missing key]]
  =/  assignment=assignment:mmw  u.found
  =/  route=(unit route-state:mmb)  (~(get by routes.routes) key)
  ?~  route  [%| [%invalid-binding ~]]
  =/  binding=binding:mmb  binding.u.route
  ?.  ?&  (context-valid context)
          (authority-bound plan binding authority)
          (usage-valid usage authority)
          =(current-binding.assignment digest.binding)
          =(current-identity.assignment identity.body.binding)
          =(current-binding.assignment binding-digest.body.context)
          =(current-binding.assignment binding-digest.body.authority)
          =(key key.body.context)
          =(key key.body.authority)
      ==
    [%| [%authority-mismatch ~]]
  =/  previous=(unit digest:mmw)
    ?~(receipts.assignment ~ `digest.i.receipts.assignment)
  =/  body=receipt-body:mmw
    :*  1  id.assignment  attempt.assignment  key
        current-binding.assignment  current-identity.assignment
        request-key  digest.context  digest.authority  usage  outcome
        result-digest  previous
    ==
  =/  receipt=receipt:mmw  [body (receipt-digest body)]
  ?.  (receipt-valid receipt)  [%| [%invalid-receipt ~]]
  ?:  (~(has by receipts.state) digest.receipt)
    [%| [%receipt-exists digest.receipt]]
  =/  next-assignment=assignment:mmw
    assignment(receipts [receipt receipts.assignment])
  =/  next=state:mmw
    %=  state
      assignments  (~(put by assignments.state) key next-assignment)
      receipts     (~(put by receipts.state) digest.receipt receipt)
    ==
  [%& [next receipt]]
::
++  reassign
  |=  $:  state=state:mmw
          routes=state:mmb
          key=route-key:mmb
          failed-receipt=digest:mmw
          reason=@tas
          reassigned-at=@da
      ==
  ^-  reassign-result:mmw
  ?.  (state-valid state)  [%| [%invalid-state ~]]
  ?.  (state-valid:mmbl routes)  [%| [%invalid-binding ~]]
  =/  found=(unit assignment:mmw)  (~(get by assignments.state) key)
  ?~  found  [%| [%assignment-missing key]]
  =/  assignment=assignment:mmw  u.found
  ?~  receipts.assignment  [%| [%invalid-reassignment ~]]
  =/  failed=receipt:mmw  i.receipts.assignment
  ?.  =(failed-receipt digest.failed)  [%| [%invalid-reassignment ~]]
  ?:  =(%completed outcome.body.failed)
    [%| [%failure-required outcome.body.failed]]
  =/  new-route=(unit route-state:mmb)  (~(get by routes.routes) key)
  ?~  new-route  [%| [%invalid-binding ~]]
  =/  binding=binding:mmb  binding.u.new-route
  ?.  =(key key.body.binding)
    [%| [%route-mismatch key key.body.binding]]
  ?:  =(current-binding.assignment digest.binding)
    [%| [%binding-mismatch current-binding.assignment digest.binding]]
  ?:  =(%$ reason)  [%| [%invalid-reassignment ~]]
  =/  body=reassignment-body:mmw
    :*  1  id.assignment  key
        current-binding.assignment  current-identity.assignment
        failed-receipt  digest.binding  identity.body.binding
        +(attempt.assignment)  reason  reassigned-at
    ==
  =/  reassignment=reassignment:mmw
    [body (reassignment-digest body)]
  =/  next-assignment=assignment:mmw
    %=  assignment
      current-binding  digest.binding
      current-identity  identity.body.binding
      attempt  +(attempt.assignment)
      reassignments  [reassignment reassignments.assignment]
    ==
  =/  next=state:mmw
    state(assignments (~(put by assignments.state) key next-assignment))
  [%& [next reassignment]]
--
