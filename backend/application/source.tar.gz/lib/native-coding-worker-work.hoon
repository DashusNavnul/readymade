::  Pure ordinary-tool binding law. Canonical readers must independently
::  require Cantrip allowed/pending and fresh prepare before every effect.
::  Boks delivery and these data checks never supply execution authority.
/-  x=native-coding-worker-work, w=native-coding-worker, nc=native-coding,
    b=boks, g=grav
/+  old=native-coding-worker, ct=cantrip-native-coding,
    archive=native-coding-hoon-artifact, project=native-coding-project,
    build=native-coding-tools, bl=boks, gl=grav
|%
++  hash
  |=(value=* ^-(@ux (shax (jam [%native-coding-worker-work-v2 value]))))
++  digest
  |=  o=order:x
  ^-  @ux
  ?:  ?=(%native-coding-worker-order-v1 -.o)  (digest:old o)
  (hash o)
++  input-digest
  |=(i=input:archive ^-(@ux (hash [%prepared-input i])))
++  authority
  |=  [grant=@ux p=tool-purpose:x]
  ^-  @ux
  (hash [%tool-authority grant request.p at.p scope.p input.p])
++  admission
  ::  A newly produced admission, not an invented candidate decision.
  |=  o=tool-order:x
  ^-  @ux
  (hash [%tool-admission ticket.o pairing.o grant.o authority.o source.o namespace.o issued.o deadline.o purpose.o])
++  tool-order-valid
  |=  o=tool-order:x
  ^-  ?
  =/  p=tool-purpose:x  purpose.o
  =/  r=tool-request:nc  request.p
  =/  c=context:nc  context.r
  ?.  ?&  (pairing-valid:old pairing.o)
          (levy `(list @ux)`~[ticket.o grant.o authority.o admission.o namespace.o scope.p input.p configuration.c session.c request.c] identifier:old)
          =(ticket.o (key:ct r))  =(authority.o (authority grant.o p))
          =(admission.o (admission o))
          =(owner.pairing.o actor.c)  =(owner.pairing.o owner.source.o)
          =(source.o source.c)  (revision-valid:project source.o)
          !=('' project.c)  (lte (met 3 project.c) 128)
          !=('' call-id.r)  (lte (met 3 call-id.r) 256)
          ?=(?(%compile %check %eval) -.arguments.r)
          (target-valid:old [%tool %hoon entry.p ~ checks.p])
          (gte (lent required.p) 1)  (lte (lent required.p) 128)
          =((lent required.p) ~(wyt in (silt required.p)))
          (levy required.p |=(pax=path &(?=(^ pax) (path-valid:project pax))))
          (gte maximum.p 1)  (lte maximum.p 2.000.000)
          (gth at.p 0)  (lte at.p issued.o)  (gth deadline.o issued.o)
          (lte deadline.o (add issued.o ~m30))
          (lte (met 3 (jam o)) 262.144)
      ==  %.n
  ?~  required.p  %.n
  ?.  =(entry.p i.required.p)  %.n
  ?:  ?=(%eval -.arguments.r)
    ?&  =(entry.p pax.arguments.r)  =(~ checks.p)
        (gte fuel.arguments.r 1)  (lte fuel.arguments.r maximum.p)
        (lte (met 3 expression.arguments.r) 8.192)
    ==
  ?>  ?=(?(%compile %check) -.arguments.r)
  &(!=(0 target.arguments.r) (lte (met 3 target.arguments.r) 128))
++  order-valid
  |=  o=order:x
  ^-  ?
  ?:  ?=(%native-coding-worker-order-v1 -.o)  (order-valid:old o)
  (tool-order-valid o)
++  make-tool
  ::  Supplies no canonical-read proof. The caller retains this exact order
  ::  only after allowed/pending and canonical prepare have all succeeded.
  |=  [pair=pairing:w row=record:ct scope=scope:ct i=input:archive issued=@da deadline=@da]
  ^-  (each tool-order:x @tas)
  =/  r=tool-request:nc  request.row
  ?.  ?&  (pairing-valid:old pair)  (input-valid:archive i)
          (grant-valid:ct owner.pair grant.scope)  =(~ revoked.scope)
          =(%running stage.row)  =(~ result.row)
          =(grant.row id.grant.scope)  =(r request.i)
          =(project.i project.grant.scope)
          =(owner.pair actor.context.r)  =(owner.pair actor.grant.scope)
          =(session.context.r session.grant.scope)
          (~(has in operations.grant.scope) -.arguments.r)
      ==  [%| %worker-tool-authority-refused]
  =/  selected  (select:build project.i r)
  ?:  ?=(%| -.selected)  [%| p.selected]
  ?.  =(%hoon backend.p.selected)  [%| %worker-tool-hoon-required]
  =/  purpose=tool-purpose:x
    [%tool r (scope-digest:archive scope) (input-digest i) entry.i (turn declared.i |=(d=[pax=path blob=@ux] pax.d)) checks.p.selected (ordinary-maximum:build max-eval-work.grant.scope) at.row]
  =/  o=tool-order:x
    [%native-coding-worker-order-v2 (key:ct r) pair grant.row (authority grant.row purpose) 0x0 revision.i (namespace-digest:old namespace.i) issued deadline purpose]
  =.  admission.o  (admission o)
  ?.  (tool-order-valid o)  [%| %worker-tool-order-invalid]
  [%& o]
++  tool-authorized
  ::  Exact re-derivation from current native authority; no timer on grants.
  |=  [o=tool-order:x pair=pairing:w row=record:ct scope=scope:ct i=input:archive]
  ^-  ?
  =/  current  (make-tool pair row scope i issued.o deadline.o)
  =([%& o] current)
++  describe
  |=  o=order:x
  ^-  descriptor:x
  ?:  ?=(%native-coding-worker-order-v2 -.o)
    [pairing.o source.o namespace.o issued.o deadline.o required.purpose.o]
  =/  required=(list path)
    (zing (turn targets.o |=(t=build-target:nc [entry.t dependencies.t])))
  [pairing.o source.o namespace.o issued.o deadline.o ~(tap in (silt required))]
++  source-ready
  |=  [o=order:x local=revision:nc files=(map path @ux)]
  ^-  ?
  ?:  ?=(%native-coding-worker-order-v1 -.o)  (source-ready:old o local files)
  ?&  (tool-order-valid o)  (revision-valid:project local)
      =(worker.pairing.o owner.local)
      (lte ~(wyt by files) max-files:project)
      =((namespace-digest:old files) namespace.o)
      (levy ~(tap by files) |=([pax=path blob=@ux] &(?=(^ pax) (path-valid:project pax) (lte (met 0 blob) 256))))
      (levy required.purpose.o |=(pax=path (~(has by files) pax)))
  ==
++  task-id
  |=  o=order:x
  ^-  @t
  ?:  ?=(%native-coding-worker-order-v1 -.o)  (task-id:old o)
  (cat 3 'native-hoon-tool-' (scot %ux (digest o)))
++  task
  |=  o=order:x
  ^-  task-request:b
  ?:  ?=(%native-coding-worker-order-v1 -.o)  (task:old o)
  :*  %boks-task-request-v1  (task-id o)
      (cat 3 'Run the exact native Hoon tool order ' (scot %ux (digest o)))
      [%boks-task-authority-v1 ~[(spat /(scot %p owner.source.o)/(scot %tas desk.source.o)/(scot %ud number.source.o))] ~ ~[-.arguments.request.purpose.o] %.n (sub deadline.o issued.o) 8.388.608]
      ~[%native-coding-worker-result-v2]
  ==
++  envelope
  |=  o=order:x
  ^-  envelope:b
  ?:  ?=(%native-coding-worker-order-v1 -.o)  (envelope:old o)
  (make-envelope:bl [%boks-envelope-v1 worker.pairing.o 'juggler-native-v1' 'juggler-native-v1' (task-id o) ~ [%task (task o)] issued.o deadline.o])
++  ingress-matches
  |=  [o=order:x ingress=admitted:b now=@da]
  ^-  ?
  ?:  ?=(%native-coding-worker-order-v1 -.o)  (ingress-matches:old o ingress now)
  ?&  (tool-order-valid o)  (envelope-valid:bl envelope.ingress)
      =(source.ingress owner.pairing.o)  =(envelope.ingress (envelope o))
      (lte issued.o received-at.ingress)  (lte received-at.ingress now)
      (lth now deadline.o)
  ==
++  grav-ready
  |=  [o=order:x r=record:g now=@da]
  ^-  ?
  ?:  ?=(%native-coding-worker-order-v1 -.o)  (grav-ready:old o r now)
  ?.  (tool-order-valid o)  %.n
  ?.  &(=(request.r (task o)) =(source.r owner.pairing.o))  %.n
  =/  wire=envelope:b  (envelope o)
  ?.  &(=(source-envelope.r digest.wire) (may-dispatch:gl r now))  %.n
  ?>  ?=(^ binding.r)
  ?.  =(u.binding.r [%grav-binding-v1 'juggler-native-v1' owner.pairing.o 'juggler-native-v1' project.context.request.purpose.o 'native-hoon' %native-coding-worker %native-coding-worker-v2])  %.n
  ?>  ?=(%admitted -.admission.r)
  ?&  =(admission.o decision.admission.r)
      =((digest o) ceiling.admission.r)
      =(deadline.o expires-at.admission.r)  =(deadline.o overall-deadline.r)
  ==
++  report-valid
  |=  [o=tool-order:x report=tool-result:nc built=(unit opaque:x)]
  ^-  ?
  =/  r=tool-request:nc  request.purpose.o
  ?.  &(=(context.r context.report) =(call-id.r call-id.report))  %.n
  =/  out=tool-output:nc  output.report
  ?:  ?=(%refused -.out)
    ?&  ?=(%check -.arguments.r)  =(~ checks.purpose.o)  ?=(^ built)
        =(%no-checks-configured reason.out)  (lte (met 3 detail.out) 2.048)
    ==
  ?.  ?=(%diagnostics -.out)  %.n
  ?~  values.out  %.n
  =/  first=diagnostic:nc  i.values.out
  ?.  &(=(%compile name.first) =(source.o source.first))  %.n
  ?.  (levy `(list diagnostic:nc)`values.out |=(d=diagnostic:nc &((lte (met 3 detail.d) 32.768) =(source.o source.d) (lte (lent artifacts.d) 2) (levy artifacts.d identifier:old))))  %.n
  ?~  built
    &(=(~ t.values.out) !passed.first =(~ artifacts.first))
  =/  product=@ux  (shax (jam q.u.built))
  ?.  &(passed.first =(~[product] artifacts.first))  %.n
  =/  names=(list @tas)
    ?:  ?=(%compile -.arguments.r)  ~[%compile]
    ?:  ?=(%eval -.arguments.r)  ~[%compile %eval]
    [%compile (turn checks.purpose.o |=([name=@tas expression=@t] name))]
  ?.  =(names (turn `(list diagnostic:nc)`values.out |=(d=diagnostic:nc name.d)))  %.n
  ?.  |(!?=(%check -.arguments.r) ?=(^ checks.purpose.o))  %.n
  %+  levy  t.values.out
  |=  d=diagnostic:nc
  ?~  artifacts.d  %.n
  =(product i.artifacts.d)
++  result-matches
  ::  Authenticated transport remains mandatory. This checks binding/shape,
  ::  including late terminal evidence, without executing archived DATA.
  |=  [o=order:x r=result:x]
  ^-  ?
  ?:  ?=(%native-coding-worker-order-v1 -.o)
    ?.  ?=(%native-coding-worker-result-v1 -.r)  %.n
    (result-matches:old o r)
  ?.  ?=(%native-coding-worker-result-v2 -.r)  %.n
  ?.  ?&  (tool-order-valid o)  =((digest o) request.r)
          =(worker.pairing.o worker.r)  =(generation.pairing.o generation.r)
          =(toolchain.pairing.o toolchain.r)
          =(source.o source.r)  =(namespace.o namespace.r)
          (lte issued.o started.r)  (lte started.r finished.r)
          (lte (met 3 (jam r)) 8.388.608)
      ==  %.n
  ?^  local.r
    ?.  &((revision-valid:project u.local.r) =(worker.r owner.u.local.r))  %.n
    ?:  ?=(%tool -.outcome.r)
      (report-valid o report.outcome.r built.outcome.r)
    &(!=(0 reason.outcome.r) (lte (met 3 reason.outcome.r) 128) (lte (met 3 detail.outcome.r) 2.048))
  ?.  ?=(%refused -.outcome.r)  %.n
  &(!=(0 reason.outcome.r) (lte (met 3 reason.outcome.r) 128) (lte (met 3 detail.outcome.r) 2.048))
--
