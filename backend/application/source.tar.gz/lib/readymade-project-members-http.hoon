::  Owner-authenticated read adapter; no commands, grants or outgoing messages.
/-  mp=multiplayer-project
/+  members=readymade-project-members, pages=readymade-session-catalog,
    guard=viki-scry-guard, mg=readymade-app-management
|%
+$  query  [project=@t kind=?(%members %invitations) page=query:pages]
++  read-request
  |=  req=inbound-request:eyre
  ^-  (unit query)
  ?.  &(authenticated.req =('GET' method.request.req))  ~
  =/  project  (header:mg header-list.request.req 'x-readymade-project')
  =/  kind  (header:mg header-list.request.req 'x-readymade-project-kind')
  =/  offset  (header:mg header-list.request.req 'x-readymade-project-offset')
  ?~  project  ~
  ?~  kind  ~
  ?~  offset  ~
  ?.  &((gte (met 3 u.project) 1) (lte (met 3 u.project) 128))  ~
  ?.  ?=(?(%members %invitations) u.kind)  ~
  =/  page  (parse-query:pages u.offset (header:mg header-list.request.req 'x-readymade-project-catalog'))
  ?~  page  ~
  `[u.project u.kind u.page]
++  read
  |=  [b=bowl:gall q=query]
  ^-  (each json @tas)
  ?.  &(=(our.b src.b) (agent-live:guard our.b now.b %multiplayer-runtime))
    [%| %project-members-unavailable]
  =/  id=@t  project.q
  =/  raw=*  .^(* %gx /(scot %p our.b)/multiplayer-runtime/(scot %da now.b)/catalog/[id]/noun)
  =/  parsed  ((soft ,(unit project:mp)) raw)
  ?~  parsed  [%| %project-members-unavailable]
  ?~  u.parsed  [%| %project-members-unavailable]
  ?.  =(id id.spec.u.u.parsed)  [%| %project-members-unavailable]
  (page:members our.b now.b u.u.parsed kind.q page.q)
--
