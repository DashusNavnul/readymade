::  Native inference boundary. No tool execution and no provider-owned loop.
/-  mb=model-bridge
/+  responses=codex-responses, provider=vibecoding-provider
|%
+$  mode  ?(%chatgpt %api)
+$  credentials  [mode=mode access=@t account=@t]
+$  failed-response
  [status=@ud bytes=@ud digest=@ux prefix=octs truncated=?]
+$  job
  $:  spec=model-bridge-spec:mb  request=model-bridge-request:mb
      body=@t  started=@da  event=model-bridge-event:mb
      receipt=(unit receipt:responses)  failed=(unit failed-response)
  ==
+$  state
  [%codex-inference-v1 credentials=(unit credentials) pending=(unit @ux) jobs=(map @ux job)]
++  key
  |=  [session=@t request=@t]
  ^-  @ux
  (shax (jam [%codex-inference session request]))
++  spec-valid
  |=  spec=model-bridge-spec:mb
  ^-  ?
  ?&  (model-bridge-spec-valid:mb spec)
      =([%gall-agent %codex-inference %model-bridge-action] target.spec)
      =('codex' provider-id.spec)
      (model-valid:provider model-id.spec)
      =('responses-v1' request-codec.spec)
      =('responses-v1' response-codec.spec)
      (model-auth-absent:mb auth.spec)
  ==
++  credential-valid
  |=  c=credentials
  ^-  ?
  ?&  (bounded-text:mb access.c 16.384)
      (levy (trip access.c) |=(ch=@t &((gte ch 33) (lte ch 126))))
      ?:  =(%api mode.c)  =('' account.c)
      ?&  (bounded-text:mb account.c 256)
          (levy (trip account.c) |=(ch=@t |((alphanumeric:provider ch) =(ch '-'))))
      ==
  ==
++  endpoint
  |=  selected=mode
  ^-  @t
  ?:  =(%chatgpt selected)  'https://chatgpt.com/backend-api/codex/responses'
  'https://api.openai.com/v1/responses'
++  prepare
  |=  [spec=model-bridge-spec:mb request=model-bridge-request:mb]
  ^-  (each @t @tas)
  ?.  &((spec-valid spec) (model-bridge-request-valid:mb request))
    [%| %request-invalid]
  ::  The request validator bounds full context at 16 KiB. The provider's
  ::  4 KiB metadata parser cannot accept an ordinary source-bearing request.
  =/  envelope=(unit json)  (de:json:html body-json.request)
  ?.  ?=([~ %o *] envelope)  [%| %policy-invalid]
  =/  policy  (~(get by p.u.envelope) 'policy')
  ?.  ?=([~ %o *] policy)  [%| %policy-invalid]
  ?.  ?&  =(`[%b %.n] (~(get by p.u.policy) 'allow-mutations'))
          =(`[%a ~] (~(get by p.u.policy) 'write-roots'))
          =(`session-id.request (string:provider p.u.policy 'workspace'))
      ==  [%| %policy-invalid]
  =/  prompt  (model-bridge-request-prompt:mb request)
  ?~  prompt  [%| %prompt-invalid]
  =/  input=json
    a+~[(pairs:enjs:format ~[['role' s+'user'] ['content' a+~[(pairs:enjs:format ~[['type' s+'input_text'] ['text' s+u.prompt]])]]])]
  %+  request:responses
    model-id.spec
  :*  'You propose source text only. Urbit owns context, continuation, permission, checks and writes. Follow the supplied task format. No tools are available. Never claim to execute commands or change files.'
      input  %.y
  ==
++  error
  |=  [request=model-bridge-request:mb code=model-bridge-error-code:mb reason=@t]
  ^-  model-bridge-event:mb
  [%error [%1 request-id.request session-id.request code reason %.n]]
++  result
  |=  [j=job receipt=receipt:responses]
  ^-  (each model-bridge-event:mb @tas)
  ::  Provider identity is reported, never proof of closed model weights.
  ?.  =(model-id.spec.j model.receipt)  [%| %model-mismatch]
  =/  metadata=@t
    %-  en:json:html
    %-  pairs:enjs:format
    :~  ['backend' s+'codex-inference']
        ['transport' s+'urbit-iris']
        ['completion' s+'response.completed']
        ['tools' s+'disabled']
        ['response_id' s+response-id.receipt]
        ['reported_model' s+model.receipt]
        ['raw_digest' s+(scot %ux raw-digest.receipt)]
        ['raw_bytes' (numb:enjs:format raw-bytes.receipt)]
    ==
  =/  out=model-bridge-result:mb
    :*  %1  %gallowglass-owned  %model-bridge-result  %ok
        bridge-id.spec.j  provider-id.spec.j  model-id.spec.j
        request-id.request.j  session-id.request.j
        parent-turn-handle.request.j  response-id.receipt
        text.receipt  '[]'  (en:json:html usage.receipt)  metadata  ''
        context-commitment.request.j  policy-hash.request.j
    ==
  ?.  (model-bridge-event-matches-request:mb spec.j request.j [%result out])
    [%| %result-invalid]
  [%& [%result out]]
++  event-card
  |=  [request=model-bridge-request:mb event=model-bridge-event:mb]
  ^-  card:agent:gall
  [%give %fact ~[/request/[session-id.request]/[request-id.request]] %model-bridge-event !>(event)]
++  failure
  ::  Failed bodies remain private evidence, including an explicitly marked
  ::  prefix when the provider exceeds the codec's complete-body bound.
  |=  [status=@ud data=octs]
  ^-  failed-response
  =/  bytes=@ud  (max p.data (met 3 q.data))
  =/  size=@ud  (min bytes body-limit:responses)
  [status bytes (shax q.data) [size (end [3 size] q.data)] (gth bytes size)]
++  failure-valid
  |=  f=failed-response
  ^-  ?
  ::  Older receipts retained only 256 KiB. A larger decoder limit cannot
  ::  recover their missing bytes or invalidate their unchanged evidence.
  ?&  ?|  =(p.prefix.f (min bytes.f body-limit:responses))
          &(truncated.f =(262.144 p.prefix.f) (gth bytes.f 262.144))
      ==
      (lte (met 3 q.prefix.f) p.prefix.f)
      =(truncated.f (gth bytes.f p.prefix.f))
      ?:(truncated.f %.y =(digest.f (shax q.prefix.f)))
  ==
++  evidence
  |=  j=job
  ^-  *
  [%codex-inference-receipt-v1 event.j receipt.j failed.j]
++  evidence-card
  |=  j=job
  ^-  card:agent:gall
  [%give %fact ~[/receipt/[session-id.request.j]/[request-id.request.j]] %noun !>((evidence j))]
++  job-valid
  |=  j=job
  ^-  ?
  ?.  =([%& body.j] (prepare spec.j request.j))  %.n
  ?.  (model-bridge-event-matches-request:mb spec.j request.j event.j)  %.n
  ?.  ?~(receipt.j %.y =([%& u.receipt.j] (decode:responses raw.u.receipt.j)))  %.n
  ?.  ?~(failed.j %.y (failure-valid u.failed.j))  %.n
  ?:  ?=(%accepted -.event.j)  &(=(~ receipt.j) =(~ failed.j))
  ?:  ?=(%result -.event.j)
    ?~  receipt.j  %.n
    &(=(~ failed.j) =([%& event.j] (result j u.receipt.j)))
  %.y
++  state-valid
  |=  s=state
  ^-  ?
  ?.  &((lte ~(wyt by jobs.s) 64) ?~(credentials.s %.y (credential-valid u.credentials.s)))  %.n
  ?.  ?~(pending.s %.y (~(has by jobs.s) u.pending.s))  %.n
  %+  levy  ~(tap by jobs.s)
  |=  [id=@ux j=job]
  ?&  =(id (key session-id.request.j request-id.request.j))
      (job-valid j)
      =(?=(%accepted -.event.j) =(`id pending.s))
  ==
++  cancel-card
  |=  id=@ux
  ^-  card:agent:gall
  [%pass /infer/(scot %ux id) %arvo %i %cancel-request ~]
--
