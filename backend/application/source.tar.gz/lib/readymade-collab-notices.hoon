::  Item 6: each collaborator's notifications, durable and deduplicated.
::
::  Kept in Clay on the private dead desk %collab-notices, never in Gall state:
::    /out/<id>/noun   a notice this ship sent (stored in the event that sends it)
::    /done/<id>/noun  the receiving ship's answer to it, stored once
::    /in/<id>/noun    a notice this ship received, stored once
::    /gone/<id>/noun  what is kept of a sent notice after it left the window
::
::  Each direction is a rolling window, not a lifetime allowance. When a
::  direction reaches `window` entries, enough of the oldest leave, in the
::  same commit that stores the new one, to end a batch below it. Sent
::  notices that are answered, or unanswered for `stale`, leave first, oldest
::  first; only when those are too few do younger unanswered ones leave. So
::  a peer that never answers can neither fill the store nor crowd the
::  answered notices out of it. Received notices leave from the
::  sender that holds the most, oldest first, so a sender that floods evicts
::  its own. A work notice leaves no trace: nothing announces it a second
::  time. A suggestion notice can be derived again by a later scan, so it
::  leaves a small /gone record, and an id with one is never sent again.
::  Before this the 513th notice in a direction was refused for good, and
::  one collaborator asking and withdrawing work could cause that.
::
::  One event (sender, receiver, project, kind, subject) has one id, so the
::  same outcome is never announced twice. A sent notice is pending while this
::  agent is still waiting for its acknowledgement, delivered or refused once
::  that answer is stored, and unknown otherwise (the wait was lost, e.g. to a
::  reload). Nothing is resent automatically: only an explicit owner retry of
::  an unknown notice sends it again. A late acknowledgement is still evidence
::  and settles an unknown notice.
|%
+$  kind
  $?  %suggestion-taken  %suggestion-declined  %suggestion-landed
      %work-queued  %work-started  %work-finished
  ==
+$  notice
  $:  %readymade-notice-v1
      id=@ux  from=@p  to=@p  project=@t
      =kind  subject=@ux                  ::  the sender's suggestion request id
      at=@da  detail=@t
  ==
+$  answer  [%readymade-notice-answer-v1 id=@ux ok=? at=@da]
+$  status  ?(%pending %delivered %refused %unknown)
+$  retry-action  [%readymade-notice-retry-v1 id=@ux]
++  desk  %collab-notices
++  capacity  512
::  The window is kept under nine tenths of the capacity a reader is told,
::  so a reader that warns near capacity never does so because of the window.
++  window  448
++  retire-batch  64
::  An unanswered notice this old leaves as readily as an answered one.
++  stale  ~d30
+$  gone  [%readymade-notice-gone-v1 id=@ux =kind at=@da done=(unit answer)]
++  work-kind  |=(k=kind ?=(?(%work-queued %work-started %work-finished) k))
++  id-for
  ::  Identity is the event, not the moment: one notice per outcome.
  |=  [from=@p to=@p project=@t =kind subject=@ux]
  ^-  @ux
  (shax (jam [%readymade-notice-v1 from to project kind subject]))
++  make
  |=  [from=@p to=@p project=@t =kind subject=@ux at=@da detail=@t]
  ^-  notice
  [%readymade-notice-v1 (id-for from to project kind subject) from to project kind subject at detail]
++  valid
  |=  n=notice
  ^-  ?
  ::  Every part another ship chooses is bounded. A subject wider than 256
  ::  bits was once accepted here and copied into state whose own load check
  ::  refuses it: one such notice left the receiving agent unable to reload.
  ?&  !=(from.n to.n)
      =(id.n (id-for from.n to.n project.n kind.n subject.n))
      !=(0 (met 3 project.n))  (lte (met 3 project.n) 128)
      (lte (met 3 subject.n) 32)
      (gth at.n 0)  (lte (met 3 at.n) 16)
      (lte (met 3 detail.n) 1.024)
  ==
++  same-event
  |=  [a=notice b=notice]
  ^-  ?
  =(a(at at.b, detail detail.b) b)
++  wire-for  |=(id=@ux `wire`/collab/notice/(scot %ux id))
++  card-for
  |=  n=notice
  ^-  card:agent:gall
  [%pass (wire-for id.n) %agent [to.n %readymade-collab] %poke %noun !>(n)]
::  ---  pure law
++  enqueue
  ::  held: what is already stored under this id; count: notices stored.
  ::  [%& %.y] = new, store and send once; [%& %.n] = already held, send nothing.
  |=  [held=(unit notice) count=@ud n=notice]
  ^-  (each ? @tas)
  ?.  (valid n)  [%| %notice-invalid]
  ?^  held  ?.((same-event u.held n) [%| %notice-conflict] [%& %.n])
  ?:  (gte count capacity)  [%| %notice-capacity]
  [%& %.y]
++  status-of
  |=  [done=(unit answer) sending=?]
  ^-  status
  ?^  done  ?:(ok.u.done %delivered %refused)
  ?:(sending %pending %unknown)
++  settle
  ::  The first acknowledgement of a held notice is kept; a later one changes nothing.
  |=  [held=(unit notice) done=(unit answer) id=@ux err=(unit tang) at=@da]
  ^-  (unit answer)
  ?~  held  ~
  ?^  done  ~
  `[%readymade-notice-answer-v1 id =(~ err) at]
++  excess
  ::  How many leave when `more` are about to be stored on top of `held`:
  ::  none below the window, else enough to end a batch below it, however far
  ::  past the window the store got (several sends in one event all read the
  ::  same count, so it can overshoot).
  |=  [held=@ud more=@ud]
  ^-  @ud
  =/  total=@ud  (add held more)
  ?:  (lth total window)  0
  (sub total (sub window retire-batch))
++  retire-sent
  ::  Which sent notices leave: first, oldest first, those answered or
  ::  unanswered for `stale`; then, only if those are too few, the oldest of
  ::  the younger unanswered ones.
  |=  [rows=(list [n=notice done=(unit answer)]) more=@ud now=@da]
  ^-  (list [n=notice done=(unit answer)])
  =/  need=@ud  (excess (lent rows) more)
  ?:  =(0 need)  ~
  =/  older
    |=  [a=[n=notice done=(unit answer)] b=[n=notice done=(unit answer)]]
    (lth at.n.a at.n.b)
  =/  free
    |=  [n=notice done=(unit answer)]
    |(?=(^ done) (gth now (add at.n stale)))
  (scag need (weld (sort (skim rows free) older) (sort (skip rows free) older)))
++  retire-received
  ::  Which received notices leave. Each sender's notices are ranked from its
  ::  newest (0) to its oldest; the highest ranks leave first, oldest first
  ::  among equals. So the sender holding the most gives up its oldest before
  ::  anyone else loses one, and the time a sender writes on its notices only
  ::  orders its own.
  |=  [rows=(list notice) more=@ud]
  ^-  (list notice)
  =/  need=@ud  (excess (lent rows) more)
  ?:  =(0 need)  ~
  =/  by-sender=(jar @p notice)
    (roll rows |=([n=notice acc=(jar @p notice)] (~(add ja acc) from.n n)))
  =/  ranked=(list [rank=@ud n=notice])
    %-  zing
    %+  turn  ~(val by by-sender)
    |=  ns=(list notice)
    =/  newest=(list notice)  (sort ns |=([a=notice b=notice] (gth at.a at.b)))
    =|  i=@ud
    |-  ^-  (list [rank=@ud n=notice])
    ?~  newest  ~
    [[i i.newest] $(i +(i), newest t.newest)]
  %+  turn
    %+  scag  need
    %+  sort  ranked
    |=  [a=[rank=@ud n=notice] b=[rank=@ud n=notice]]
    ?:  =(rank.a rank.b)  (lth at.n.a at.n.b)
    (gth rank.a rank.b)
  |=([rank=@ud n=notice] n)
++  leave-sent
  ::  The Clay changes that take one sent notice out of the window.
  |=  [n=notice done=(unit answer)]
  ^-  (list [path miso:clay])
  =/  answered=(list [path miso:clay])  ?~(done ~ ~[[(done-path id.n) %del ~]])
  =/  kept=(list [path miso:clay])
    ?:  (work-kind kind.n)  ~
    ~[[(gone-path id.n) %ins %noun !>(`gone`[%readymade-notice-gone-v1 id.n kind.n at.n done])]]
  [[(out-path id.n) %del ~] (weld answered kept)]
++  retry
  ::  Explicit owner action only, and only for an unknown notice.
  |=  [held=(unit notice) done=(unit answer) sending=?]
  ^-  (each notice @tas)
  ?~  held  [%| %notice-missing]
  ?.  =(%unknown (status-of done sending))  [%| %notice-not-unknown]
  [%& u.held]
++  receive
  ::  The sender is the authenticated src; the notice must name it and us.
  ::  A repeat of a held notice is accepted without a second entry.
  |=  [our=@p src=@p held=(unit notice) count=@ud n=notice]
  ^-  (each ? @tas)
  ?.  (valid n)  [%| %notice-invalid]
  ?.  &(=(src from.n) =(our to.n))  [%| %notice-foreign]
  ?^  held  ?:(=(u.held n) [%& %.n] [%| %notice-conflict])
  ?:  (gte count capacity)  [%| %notice-capacity]
  [%& %.y]
::  ---  Clay store
++  out-path  |=(id=@ux `path`/out/(scot %ux id)/noun)
++  done-path  |=(id=@ux `path`/done/(scot %ux id)/noun)
++  in-path  |=(id=@ux `path`/in/(scot %ux id)/noun)
++  gone-path  |=(id=@ux `path`/gone/(scot %ux id)/noun)
++  base  |=([our=@p at=@da] `path`/(scot %p our)/[desk]/(scot %da at))
++  store
  ::  The store exists and only this ship may read or write it.
  |=  [our=@p at=@da]
  ^-  ?
  ?.  .^(? %cu (weld (base our at) /sys/kelvin))  %.n
  =/  rules  .^([r=dict:clay w=dict:clay] %cp (base our at))
  &(=([%white ~ ~] rul.r.rules) =([%white ~ ~] rul.w.rules))
++  read-notice
  |=  [our=@p at=@da pax=path]
  ^-  (unit notice)
  =/  full=path  (weld (base our at) pax)
  ?.  .^(? %cu full)  ~
  `;;(notice .^(* %cx full))
++  read-answer
  |=  [our=@p at=@da id=@ux]
  ^-  (unit answer)
  =/  full=path  (weld (base our at) (done-path id))
  ?.  .^(? %cu full)  ~
  `;;(answer .^(* %cx full))
++  ids
  |=  [our=@p at=@da dir=@ta]
  ^-  (list @ux)
  =/  top=arch  .^(arch %cy (base our at))
  ?.  (~(has by dir.top) dir)  ~
  %+  murn  ~(tap in ~(key by dir:.^(arch %cy (weld (base our at) /[dir]))))
  |=(name=@ta (slaw %ux name))
++  read-gone
  |=  [our=@p at=@da id=@ux]
  ^-  (unit gone)
  =/  full=path  (weld (base our at) (gone-path id))
  ?.  .^(? %cu full)  ~
  `;;(gone .^(* %cx full))
++  insert
  |=  [pax=path value=vase]
  ^-  card:agent:gall
  [%pass /collab/notice-store %arvo %c %info desk %& ~[[pax %ins %noun value]]]
++  commit
  ::  One Clay commit: the new notice and whatever leaves the window with it.
  |=  changes=(list [path miso:clay])
  ^-  card:agent:gall
  [%pass /collab/notice-store %arvo %c %info desk %& changes]
++  sweep-sent
  ::  The sent notices that leave when one more is stored.
  |=  [our=@p at=@da]
  ^-  (list [n=notice done=(unit answer)])
  =/  rows=(list [n=notice done=(unit answer)])
    %+  murn  (ids our at %out)
    |=  id=@ux
    ^-  (unit [n=notice done=(unit answer)])
    =/  n  (read-notice our at (out-path id))
    ?~(n ~ `[u.n (read-answer our at id)])
  (retire-sent rows 1 at)
++  sweep-received
  |=  [our=@p at=@da]
  ^-  (list notice)
  =/  rows=(list notice)
    (murn (ids our at %in) |=(id=@ux (read-notice our at (in-path id))))
  (retire-received rows 1)
++  send
  ::  Store and send one notice once. Refuses as a whole: nothing is stored
  ::  or sent unless the store is private and the notice is new.
  |=  [our=@p at=@da n=notice]
  ^-  (each [new=? cards=(list card:agent:gall)] @tas)
  ?.  (store our at)  [%| %notice-store-unavailable]
  ?.  (valid n)  [%| %notice-invalid]
  ::  Told already, and since left the window: never a second time.
  ?:  .^(? %cu (weld (base our at) (gone-path id.n)))  [%& %.n ~]
  =/  held  (read-notice our at (out-path id.n))
  =/  count=@ud  (lent (ids our at %out))
  ::  What leaves is settled before the capacity is judged, so a full store
  ::  makes room instead of refusing for good.
  =/  leaving  ?:(|(?=(^ held) =(0 (excess count 1))) ~ (sweep-sent our at))
  =/  moved  (enqueue held (sub count (min count (lent leaving))) n)
  ?:  ?=(%| -.moved)  [%| p.moved]
  ?.  p.moved  [%& %.n ~]
  [%& %.y ~[(commit [[(out-path id.n) %ins %noun !>(n)] (zing (turn leaving leave-sent))]) (card-for n)]]
++  acknowledge
  |=  [our=@p at=@da id=@ux err=(unit tang)]
  ^-  (list card:agent:gall)
  ?.  (store our at)  ~
  =/  kept  (settle (read-notice our at (out-path id)) (read-answer our at id) id err at)
  ?^  kept  ~[(insert (done-path id) !>(u.kept))]
  ::  The notice left the window unanswered. A late answer is still
  ::  evidence: it is kept on what remains of the notice, once.
  =/  left  (read-gone our at id)
  ?~  left  ~
  ?^  done.u.left  ~
  =/  told=gone  u.left(done `[%readymade-notice-answer-v1 id =(~ err) at])
  ~[(commit ~[[(gone-path id) %mut %noun !>(told)]])]
++  resend
  |=  [our=@p at=@da id=@ux sending=?]
  ^-  (each card:agent:gall @tas)
  ?.  (store our at)  [%| %notice-store-unavailable]
  =/  moved  (retry (read-notice our at (out-path id)) (read-answer our at id) sending)
  ?:  ?=(%| -.moved)  [%| p.moved]
  [%& (card-for p.moved)]
++  accept
  |=  [our=@p src=@p at=@da n=notice]
  ^-  (each (list card:agent:gall) @tas)
  ?.  (store our at)  [%| %notice-store-unavailable]
  ::  Refused before the store is read: an invalid or foreign notice costs
  ::  nothing. A notice dated ahead of this ship's clock is not one either:
  ::  the date orders a sender's own notices, and a far date would keep one
  ::  here for good.
  ?.  (valid n)  [%| %notice-invalid]
  ?.  &(=(src from.n) =(our to.n))  [%| %notice-foreign]
  ?:  (gth at.n (add at ~h1))  [%| %notice-invalid]
  =/  held  (read-notice our at (in-path id.n))
  =/  count=@ud  (lent (ids our at %in))
  =/  leaving  ?:(|(?=(^ held) =(0 (excess count 1))) ~ (sweep-received our at))
  =/  moved  (receive our src held (sub count (min count (lent leaving))) n)
  ?:  ?=(%| -.moved)  [%| p.moved]
  ?.  p.moved  [%& ~]
  [%& ~[(commit [[(in-path id.n) %ins %noun !>(n)] (turn leaving |=(old=notice [(in-path id.old) %del ~]))])]]
::  ---  owner HTTP
++  retry-request
  ::  The owner's explicit retry of one notice, as exact same-origin JSON.
  |=  req=inbound-request:eyre
  ^-  (unit @ux)
  ?.  &(authenticated.req =('POST' method.request.req))  ~
  =/  host  (get-header:http 'host' header-list.request.req)
  =/  origin  (get-header:http 'origin' header-list.request.req)
  ?~  host  ~
  ?~  origin  ~
  ?.  =(u.origin (cat 3 ?:(secure.req 'https://' 'http://') u.host))  ~
  ?~  body.request.req  ~
  ?.  (lte p.u.body.request.req 512)  ~
  %-  mole
  |.
  =/  v=json  (need (de:json:html q.u.body.request.req))
  ?>  ?=(%o -.v)
  ?>  =(2 ~(wyt by p.v))
  =/  get  |=(k=@t =/(x (~(got by p.v) k) ?>(?=(%s -.x) p.x)))
  ?>  =('readymade-notice-retry-v1' (get 'schema'))
  (need (slaw %ux (get 'id')))
++  notice-pairs
  |=  n=notice
  ^-  (list [@t json])
  :~  ['id' s+(scot %ux id.n)]  ['from' s+(scot %p from.n)]  ['to' s+(scot %p to.n)]
      ['project' s+project.n]  ['kind' s+(scot %tas kind.n)]
      ['subject' s+(scot %ux subject.n)]  ['at' s+(scot %da at.n)]  ['detail' s+detail.n]
  ==
++  page
  |=  [our=@p at=@da sending=(set @ux)]
  ^-  json
  ?.  (store our at)
    (pairs:enjs:format ~[['schema' s+'readymade-collab-notices-v1'] ['available' b+%.n] ['error' s+'notice-store-unavailable']])
  ::  Never more than the capacity this page reports, newest first: several
  ::  sends in one event can leave a direction past its window for a moment.
  =/  newest
    |=  rows=(list [at=@da j=json])
    ^-  (list json)
    (turn (scag capacity (sort rows |=([a=[at=@da j=json] b=[at=@da j=json]] (gth at.a at.b)))) |=([at=@da j=json] j))
  =/  out=(list [at=@da j=json])
    %+  murn  (ids our at %out)
    |=  id=@ux
    =/  n  (read-notice our at (out-path id))
    ?~  n  ~
    =/  done  (read-answer our at id)
    =/  st=status  (status-of done (~(has in sending) id))
    :-  ~
    :-  at.u.n
    %-  pairs:enjs:format
    %+  weld  (notice-pairs u.n)
    ^-  (list [@t json])
    :~  ['status' s+st]
        ['answeredAt' ?~(done ~ s+(scot %da at.u.done))]
        ['retryable' b+=(%unknown st)]
    ==
  =/  in=(list [at=@da j=json])
    %+  murn  (ids our at %in)
    |=  id=@ux
    =/  n  (read-notice our at (in-path id))
    ?~(n ~ `[at.u.n (pairs:enjs:format (notice-pairs u.n))])
  %-  pairs:enjs:format
  :~  ['schema' s+'readymade-collab-notices-v1']  ['available' b+%.y]
      ['ship' s+(scot %p our)]  ['observedAt' s+(scot %da at)]
      ['capacity' (numb:enjs:format capacity)]
      ['outbox' a+(newest out)]  ['inbox' a+(newest in)]
  ==
--
