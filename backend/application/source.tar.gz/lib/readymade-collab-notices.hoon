::  Item 6: each collaborator's notifications, durable and deduplicated.
::
::  Kept in Clay on the private dead desk %collab-notices, never in Gall state,
::  and only ever inserted:
::    /out/<id>/noun   a notice this ship sent (stored in the event that sends it)
::    /done/<id>/noun  the receiving ship's answer to it, stored once
::    /in/<id>/noun    a notice this ship received, stored once
::
::  One event (sender, receiver, project, kind, subject) has one id, so the
::  same outcome is never announced twice. A sent notice is pending while this
::  agent is still waiting for its acknowledgement, delivered or refused once
::  that answer is stored, and unknown otherwise (the wait was lost, e.g. to a
::  reload). Nothing is resent automatically: only an explicit owner retry of
::  an unknown notice sends it again. A late acknowledgement is still evidence
::  and settles an unknown notice.
|%
+$  kind
  $?  %suggestion-taken  %suggestion-declined  %suggestion-landed
      %work-queued  %work-started  %work-finished
  ==
+$  notice
  $:  %readymade-notice-v1
      id=@ux  from=@p  to=@p  project=@t
      =kind  subject=@ux                  ::  the sender's suggestion request id
      at=@da  detail=@t
  ==
+$  answer  [%readymade-notice-answer-v1 id=@ux ok=? at=@da]
+$  status  ?(%pending %delivered %refused %unknown)
+$  retry-action  [%readymade-notice-retry-v1 id=@ux]
++  desk  %collab-notices
++  capacity  512
++  id-for
  ::  Identity is the event, not the moment: one notice per outcome.
  |=  [from=@p to=@p project=@t =kind subject=@ux]
  ^-  @ux
  (shax (jam [%readymade-notice-v1 from to project kind subject]))
++  make
  |=  [from=@p to=@p project=@t =kind subject=@ux at=@da detail=@t]
  ^-  notice
  [%readymade-notice-v1 (id-for from to project kind subject) from to project kind subject at detail]
++  valid
  |=  n=notice
  ^-  ?
  ?&  !=(from.n to.n)
      =(id.n (id-for from.n to.n project.n kind.n subject.n))
      !=(0 (met 3 project.n))  (lte (met 3 project.n) 128)
      (lte (met 3 detail.n) 1.024)
  ==
++  same-event
  |=  [a=notice b=notice]
  ^-  ?
  =(a(at at.b, detail detail.b) b)
++  wire-for  |=(id=@ux `wire`/collab/notice/(scot %ux id))
++  card-for
  |=  n=notice
  ^-  card:agent:gall
  [%pass (wire-for id.n) %agent [to.n %readymade-collab] %poke %noun !>(n)]
::  ---  pure law
++  enqueue
  ::  held: what is already stored under this id; count: notices stored.
  ::  [%& %.y] = new, store and send once; [%& %.n] = already held, send nothing.
  |=  [held=(unit notice) count=@ud n=notice]
  ^-  (each ? @tas)
  ?.  (valid n)  [%| %notice-invalid]
  ?^  held  ?.((same-event u.held n) [%| %notice-conflict] [%& %.n])
  ?:  (gte count capacity)  [%| %notice-capacity]
  [%& %.y]
++  status-of
  |=  [done=(unit answer) sending=?]
  ^-  status
  ?^  done  ?:(ok.u.done %delivered %refused)
  ?:(sending %pending %unknown)
++  settle
  ::  The first acknowledgement of a held notice is kept; a later one changes nothing.
  |=  [held=(unit notice) done=(unit answer) id=@ux err=(unit tang) at=@da]
  ^-  (unit answer)
  ?~  held  ~
  ?^  done  ~
  `[%readymade-notice-answer-v1 id =(~ err) at]
++  retry
  ::  Explicit owner action only, and only for an unknown notice.
  |=  [held=(unit notice) done=(unit answer) sending=?]
  ^-  (each notice @tas)
  ?~  held  [%| %notice-missing]
  ?.  =(%unknown (status-of done sending))  [%| %notice-not-unknown]
  [%& u.held]
++  receive
  ::  The sender is the authenticated src; the notice must name it and us.
  ::  A repeat of a held notice is accepted without a second entry.
  |=  [our=@p src=@p held=(unit notice) count=@ud n=notice]
  ^-  (each ? @tas)
  ?.  (valid n)  [%| %notice-invalid]
  ?.  &(=(src from.n) =(our to.n))  [%| %notice-foreign]
  ?^  held  ?:(=(u.held n) [%& %.n] [%| %notice-conflict])
  ?:  (gte count capacity)  [%| %notice-capacity]
  [%& %.y]
::  ---  Clay store
++  out-path  |=(id=@ux `path`/out/(scot %ux id)/noun)
++  done-path  |=(id=@ux `path`/done/(scot %ux id)/noun)
++  in-path  |=(id=@ux `path`/in/(scot %ux id)/noun)
++  base  |=([our=@p at=@da] `path`/(scot %p our)/[desk]/(scot %da at))
++  store
  ::  The store exists and only this ship may read or write it.
  |=  [our=@p at=@da]
  ^-  ?
  ?.  .^(? %cu (weld (base our at) /sys/kelvin))  %.n
  =/  rules  .^([r=dict:clay w=dict:clay] %cp (base our at))
  &(=([%white ~ ~] rul.r.rules) =([%white ~ ~] rul.w.rules))
++  read-notice
  |=  [our=@p at=@da pax=path]
  ^-  (unit notice)
  =/  full=path  (weld (base our at) pax)
  ?.  .^(? %cu full)  ~
  `;;(notice .^(* %cx full))
++  read-answer
  |=  [our=@p at=@da id=@ux]
  ^-  (unit answer)
  =/  full=path  (weld (base our at) (done-path id))
  ?.  .^(? %cu full)  ~
  `;;(answer .^(* %cx full))
++  ids
  |=  [our=@p at=@da dir=@ta]
  ^-  (list @ux)
  =/  top=arch  .^(arch %cy (base our at))
  ?.  (~(has by dir.top) dir)  ~
  %+  murn  ~(tap in ~(key by dir:.^(arch %cy (weld (base our at) /[dir]))))
  |=(name=@ta (slaw %ux name))
++  insert
  |=  [pax=path value=vase]
  ^-  card:agent:gall
  [%pass /collab/notice-store %arvo %c %info desk %& ~[[pax %ins %noun value]]]
++  send
  ::  Store and send one notice once. Refuses as a whole: nothing is stored
  ::  or sent unless the store is private and the notice is new.
  |=  [our=@p at=@da n=notice]
  ^-  (each [new=? cards=(list card:agent:gall)] @tas)
  ?.  (store our at)  [%| %notice-store-unavailable]
  =/  moved  (enqueue (read-notice our at (out-path id.n)) (lent (ids our at %out)) n)
  ?:  ?=(%| -.moved)  [%| p.moved]
  ?.  p.moved  [%& %.n ~]
  [%& %.y ~[(insert (out-path id.n) !>(n)) (card-for n)]]
++  acknowledge
  |=  [our=@p at=@da id=@ux err=(unit tang)]
  ^-  (list card:agent:gall)
  ?.  (store our at)  ~
  =/  kept  (settle (read-notice our at (out-path id)) (read-answer our at id) id err at)
  ?~  kept  ~
  ~[(insert (done-path id) !>(u.kept))]
++  resend
  |=  [our=@p at=@da id=@ux sending=?]
  ^-  (each card:agent:gall @tas)
  ?.  (store our at)  [%| %notice-store-unavailable]
  =/  moved  (retry (read-notice our at (out-path id)) (read-answer our at id) sending)
  ?:  ?=(%| -.moved)  [%| p.moved]
  [%& (card-for p.moved)]
++  accept
  |=  [our=@p src=@p at=@da n=notice]
  ^-  (each (list card:agent:gall) @tas)
  ?.  (store our at)  [%| %notice-store-unavailable]
  =/  moved  (receive our src (read-notice our at (in-path id.n)) (lent (ids our at %in)) n)
  ?:  ?=(%| -.moved)  [%| p.moved]
  [%& ?.(p.moved ~ ~[(insert (in-path id.n) !>(n))])]
::  ---  owner HTTP
++  retry-request
  ::  The owner's explicit retry of one notice, as exact same-origin JSON.
  |=  req=inbound-request:eyre
  ^-  (unit @ux)
  ?.  &(authenticated.req =('POST' method.request.req))  ~
  =/  host  (get-header:http 'host' header-list.request.req)
  =/  origin  (get-header:http 'origin' header-list.request.req)
  ?~  host  ~
  ?~  origin  ~
  ?.  =(u.origin (cat 3 ?:(secure.req 'https://' 'http://') u.host))  ~
  ?~  body.request.req  ~
  ?.  (lte p.u.body.request.req 512)  ~
  %-  mole
  |.
  =/  v=json  (need (de:json:html q.u.body.request.req))
  ?>  ?=(%o -.v)
  ?>  =(2 ~(wyt by p.v))
  =/  get  |=(k=@t =/(x (~(got by p.v) k) ?>(?=(%s -.x) p.x)))
  ?>  =('readymade-notice-retry-v1' (get 'schema'))
  (need (slaw %ux (get 'id')))
++  notice-pairs
  |=  n=notice
  ^-  (list [@t json])
  :~  ['id' s+(scot %ux id.n)]  ['from' s+(scot %p from.n)]  ['to' s+(scot %p to.n)]
      ['project' s+project.n]  ['kind' s+(scot %tas kind.n)]
      ['subject' s+(scot %ux subject.n)]  ['at' s+(scot %da at.n)]  ['detail' s+detail.n]
  ==
++  page
  |=  [our=@p at=@da sending=(set @ux)]
  ^-  json
  ?.  (store our at)
    (pairs:enjs:format ~[['schema' s+'readymade-collab-notices-v1'] ['available' b+%.n] ['error' s+'notice-store-unavailable']])
  =/  out=(list json)
    %+  murn  (ids our at %out)
    |=  id=@ux
    =/  n  (read-notice our at (out-path id))
    ?~  n  ~
    =/  done  (read-answer our at id)
    =/  st=status  (status-of done (~(has in sending) id))
    :-  ~
    %-  pairs:enjs:format
    %+  weld  (notice-pairs u.n)
    ^-  (list [@t json])
    :~  ['status' s+st]
        ['answeredAt' ?~(done ~ s+(scot %da at.u.done))]
        ['retryable' b+=(%unknown st)]
    ==
  =/  in=(list json)
    %+  murn  (ids our at %in)
    |=  id=@ux
    =/  n  (read-notice our at (in-path id))
    ?~(n ~ `(pairs:enjs:format (notice-pairs u.n)))
  %-  pairs:enjs:format
  :~  ['schema' s+'readymade-collab-notices-v1']  ['available' b+%.y]
      ['ship' s+(scot %p our)]  ['observedAt' s+(scot %da at)]
      ['capacity' (numb:enjs:format capacity)]
      ['outbox' a+out]  ['inbox' a+in]
  ==
--
