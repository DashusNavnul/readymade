::  The sole successor policy identity/text; no imports or admission authority.
::  Observation sensing and window arithmetic may both depend on this core.
|%
+$  policy  %first-17-reference-successive-disjoint-17-live
++  text
  ^-  @t
  'W16 successor-v1: freeze the first eligible uninterrupted 17-report reference block; then seal each successive disjoint eligible uninterrupted 17-report live block in chronological order. Ordinary work contributes its sole prediction; managed alternatives contribute only the actually selected branch authenticated by its release and settlement. Unselected alternatives never count as successive reports. Missing reports and explicit pauses break the unfinished block. Unknown execution remains unresolved. Preserve prediction and settled source identities separately. The next block clears the usable reading; no old reading after source change. No historical v1 import, relabelling, filler or implicit zero baseline.'
--
