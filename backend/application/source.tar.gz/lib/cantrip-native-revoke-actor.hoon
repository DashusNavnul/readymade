::  Owner sweep selection: every live grant one ship holds in one project.
::  Used after removing a member, so a later rejoin finds nothing still live.
::  Pure; revocation itself goes through the ordinary single-revoke path.
/+  tools=cantrip-native-coding
|%
++  targets
  |=  [s=organ:tools project=@t actor=@p]
  ^-  (list @ux)
  %+  sort
    %+  murn  ~(tap by grants.s)
    |=  [id=@ux held=scope:tools]
    ^-  (unit @ux)
    ?.  ?&  ?=(~ revoked.held)  =(actor actor.grant.held)
            =(project id.spec.project.grant.held)
        ==
      ~
    `id
  lth
--
