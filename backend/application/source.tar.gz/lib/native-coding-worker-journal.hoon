::  Planet-side effect journal, for Cantrip to persist before interpreting
::  dispatch. Reload, timeout and observation NEVER produce another dispatch.
::  This pure organ neither reads permission nor sends cards by itself.
/-  w=native-coding-worker
/+  law=native-coding-worker
|%
::  A lifetime store, never evicted; see capacity:native-coding-worker-runtime.
++  capacity  1.024
++  put
  |=  [s=journal:w r=record:w effects=(list effect:w)]
  ^-  change:w
  [(~(put by s) (digest:law order.r) r) effects]
++  reserve
  |=  [our=@p src=@p now=@da s=journal:w scope=scope:w o=order:w]
  ^-  (each change:w @tas)
  ?.  &(=(our src) =(our owner.pairing.o) (order-valid:law o))
    [%| %worker-order-refused]
  =/  key=@ux  (digest:law o)
  =/  previous  (~(get by s) key)
  ?^  previous
    ?.  =(o order.u.previous)  [%| %worker-order-conflict]
    [%& [s ~]]
  ?:  (lien ~(val by s) |=(r=record:w =(ticket.o ticket.order.r)))
    [%| %worker-ticket-reused]
  ?.  (authorized:law scope o)  [%| %worker-authority-refused]
  ?.  &((lte issued.o now) (lth now deadline.o))  [%| %worker-order-window]
  ?:  (gte ~(wyt by s) capacity)  [%| %worker-journal-capacity]
  [%& (put s [o %reserved %.n ~ ~] ~)]
++  busy
  ::  Revocation does not prove a sent job stopped. Only a retained terminal
  ::  receipt releases the slot; an unknown outcome cannot start another job.
  |=  [s=journal:w worker=@p]
  ^-  ?
  (lien ~(val by s) |=(r=record:w &(=(worker worker.pairing.order.r) sent.r ?=(~ result.r))))
++  dispatch
  |=  [our=@p src=@p now=@da s=journal:w scope=scope:w key=@ux]
  ^-  (each change:w @tas)
  ?.  =(our src)  [%| %worker-owner-required]
  =/  found  (~(get by s) key)
  ?~  found  [%| %worker-order-missing]
  =/  r=record:w  u.found
  ?.  =(our owner.pairing.order.r)  [%| %worker-owner-required]
  ?.  =(%reserved phase.r)  [%& [s ~]]
  ?.  (authorized:law scope order.r)
    [%& (put s r(phase %revoked, reason `%worker-authority-changed) ~)]
  ?.  &((lte issued.order.r now) (lth now deadline.order.r))
    [%& (put s r(phase %refused, reason `%worker-order-window) ~)]
  ?:  (busy s worker.pairing.order.r)  [%| %worker-unresolved]
  [%& (put s r(phase %dispatched, sent %.y) ~[[%dispatch order.r]])]
++  revoke
  ::  Current native authority is re-read by the owner before this call.
  ::  Keep complete evidence and never interpret cancellation as rollback.
  |=  [our=@p src=@p s=journal:w scope=scope:w key=@ux]
  ^-  (each change:w @tas)
  ?.  =(our src)  [%| %worker-owner-required]
  =/  found  (~(get by s) key)
  ?~  found  [%| %worker-order-missing]
  =/  r=record:w  u.found
  ?.  =(our owner.pairing.order.r)  [%| %worker-owner-required]
  ?:  (authorized:law scope order.r)  [%& [s ~]]
  ::  An earlier lawful terminal result stays historical evidence. Fresh
  ::  authority must still be checked before the planet accepts any result.
  ?:  ?=(?(%checked %refused %revoked) phase.r)  [%& [s ~]]
  [%& (put s r(phase %revoked, reason `%worker-authority-changed) ~)]
++  observe
  |=  [our=@p src=@p now=@da s=journal:w key=@ux]
  ^-  (each change:w @tas)
  ?.  =(our src)  [%| %worker-owner-required]
  =/  found  (~(get by s) key)
  ?~  found  [%| %worker-order-missing]
  =/  r=record:w  u.found
  ?.  =(our owner.pairing.order.r)  [%| %worker-owner-required]
  ?.  &((gte now deadline.order.r) ?=(?(%reserved %dispatched) phase.r))
    [%& [s ~]]
  [%& (put s r(phase ?:(sent.r %unknown %refused), reason `%worker-deadline) ~)]
++  disconnect
  |=  [our=@p s=journal:w key=@ux]
  ^-  change:w
  =/  found  (~(get by s) key)
  ?~  found  [s ~]
  =/  r=record:w  u.found
  ?.  &(=(our owner.pairing.order.r) =(%dispatched phase.r))  [s ~]
  (put s r(phase %unknown, reason `%worker-disconnected) ~)
++  receive
  ::  src/app are Gall's authenticated peer, never fields from the payload.
  ::  Runtime must also bind the exact acknowledged subscription and wire.
  |=  [our=@p src=@p app=@tas now=@da s=journal:w scope=scope:w value=result:w]
  ^-  (each change:w @tas)
  =/  found  (~(get by s) request.value)
  ?~  found  [%| %worker-order-missing]
  =/  r=record:w  u.found
  ?.  ?&  =(our owner.pairing.order.r)  =(src worker.pairing.order.r)
          =(%native-coding-worker app)  sent.r
          (result-matches:law order.r value)  (lte finished.value now)
      ==  [%| %worker-result-refused]
  ?^  result.r
    ?.  =(`value result.r)  [%| %worker-result-conflict]
    [%& [s ~]]
  =/  terminal=phase:w  ?:(?=(%checked -.outcome.value) %checked %refused)
  ?:  |(=(%revoked phase.r) !(authorized:law scope order.r))
    [%& (put s r(result `value, phase %revoked, reason `%worker-authority-changed) ~)]
  ?:  (gte now deadline.order.r)
    [%& (put s r(result `value, phase %unknown, reason `%worker-late-result) ~)]
  [%& (put s r(result `value, phase terminal, reason ~) ~)]
++  recover
  ::  Restore the complete journal. Never resend, even when no ack arrived.
  |=  s=journal:w
  ^-  change:w
  :-  (~(run by s) |=(r=record:w ?:(=(%dispatched phase.r) r(phase %unknown, reason `%worker-reload-unconfirmed) r)))
  ~
++  valid
  |=  [our=@p s=journal:w]
  ^-  ?
  ?&  (lte ~(wyt by s) capacity)
      =((lent ~(val by s)) ~(wyt in (silt (turn ~(val by s) |=(r=record:w ticket.order.r)))))
      %+  levy  ~(tap by s)
      |=  [key=@ux r=record:w]
      ?&  =((digest:law order.r) key)  (order-valid:law order.r)
          =(our owner.pairing.order.r)
          ?.  &(sent.r ?=(~ result.r))  %.y
          (lte (lent (skim ~(val by s) |=(other=record:w &(sent.other ?=(~ result.other) =(worker.pairing.order.r worker.pairing.order.other))))) 1)
          ?~(reason.r %.y &(!=(0 u.reason.r) (lte (met 3 u.reason.r) 128)))
          ?~(result.r %.y &(sent.r (result-matches:law order.r u.result.r)))
          ?:  =(%reserved phase.r)  &(!sent.r ?=(~ result.r))
          ?:  =(%dispatched phase.r)  &(sent.r ?=(~ result.r))
          ?:  =(%checked phase.r)
            ?~(result.r %.n &(?=(%checked -.outcome.u.result.r) sent.r))
          ?:  =(%unknown phase.r)  sent.r
          ?:  =(%refused phase.r)
            ?~(result.r !sent.r ?=(%refused -.outcome.u.result.r))
          %.y
      ==
  ==
--
