::  Pure necessary gate, never a substitute for Cantrip law or owner auth.
::  actor MUST come from authenticated bowl/Ames plus owner authorization.
::  Persist state atomically; never recreate it to clear a revocation/replay.
/-  rp=readymade-pact
/+  mc=multiplayer-collaboration
|%
++  digest
  |=  terms=terms:rp
  ^-  digest:rp
  `@ux`(shax (jam [%readymade-pact-v1 terms]))
++  bounded-number
  |=  value=@ud
  ^-  ?
  (lte value 18.446.744.073.709.551.615)
++  valid-terms
  |=  terms=terms:rp
  ^-  ?
  ?&  =(1 version.terms)
      !=(left.terms right.terms)
      (lte (met 3 left.terms) 16)
      (lte (met 3 right.terms) 16)
      (bounded-identifier:mc project.terms)
      (digest-valid:mc package.terms)
      (digest-valid:mc graf-root.terms)
      (digest-valid:mc scope.terms)
      (digest-valid:mc policy.terms)
      (digest-valid:mc nonce.terms)
  ==
++  init
  |=  terms=terms:rp
  ^-  (unit state:rp)
  ?.  (valid-terms terms)  ~
  `[terms 0 0 0 %.n %.n ~ ~]
++  active
  |=  state=state:rp
  ^-  ?
  &(left-consent.state right-consent.state)
++  approve
  |=  [old=(unit approval:rp) artifact=digest:rp left=?]
  ^-  approval:rp
  =/  prior=approval:rp
    ?~(old [artifact %.n %.n] u.old)
  =/  next=approval:rp
    ?:(=(artifact artifact.prior) prior [artifact %.n %.n])
  ?:  left
    next(left %.y)
  next(right %.y)
++  step
  |=  [state=state:rp actor=@p request=request:rp]
  ^-  (unit state:rp)
  ?.  (valid-terms terms.state)  ~
  ?.  |(=(actor left.terms.state) =(actor right.terms.state))  ~
  ?.  &((bounded-number generation.state) (bounded-number generation.request))  ~
  ?.  ?:  ?=(%revoke -.action.request)
        (lte generation.request generation.state)
      =(generation.state generation.request)
    ~
  ?.  =(terms-digest.request (digest terms.state))  ~
  ?.  (bounded-number sequence.request)  ~
  =/  left=?  =(actor left.terms.state)
  =/  prior=@ud  ?:(left left-sequence.state right-sequence.state)
  ?.  =(+(prior) sequence.request)  ~
  =/  next=state:rp
    ?:  left
      state(left-sequence sequence.request)
    state(right-sequence sequence.request)
  ?-  -.action.request
    %accept
      `?:(left next(left-consent %.y) next(right-consent %.y))
    %revoke
      =/  generation=@ud  (max generation.state +(generation.request))
      ?.  (bounded-number generation)  ~
      `next(generation generation, left-consent %.n, right-consent %.n, landing ~, publication ~)
    %approve
      ?.  (active state)  ~
      ?.  (digest-valid:mc artifact.action.request)  ~
      ?:  =(%land purpose.action.request)
        `next(landing `(approve landing.state artifact.action.request left))
      `next(publication `(approve publication.state artifact.action.request left))
  ==
++  allowed
  ::  cantrip-ok is receiver-owned current law/approval judgment, not wire data.
  |=  [state=state:rp purpose=purpose:rp artifact=digest:rp cantrip-ok=?]
  ^-  ?
  ?.  &(cantrip-ok (valid-terms terms.state) (active state))  %.n
  =/  approval=(unit approval:rp)
    ?:(=(%land purpose) landing.state publication.state)
  ?~  approval  %.n
  ?&  =(artifact artifact.u.approval)
      left.u.approval
      right.u.approval
  ==
--
