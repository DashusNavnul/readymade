::  Native build/evaluation mechanics. This library cannot admit a job.
::  The Cantrip journal and the Ted's canonical checks supply authority.
/-  nc=native-coding
/+  project=native-coding-project, accept=native-coding-accept,
    budget=native-coding-hoon-check-budget
|%
+$  selection  [backend=?(%hoon %gallowglass) entry=path checks=(list [name=@tas expression=@t])]
++  ordinary-maximum
  ::  Candidate aggregate authority does not enlarge ordinary tool work.
  |=(maximum=@ud ^-(@ud (min expression-limit:budget maximum)))
++  ordinary-per-check
  |=  [maximum=@ud count=@ud]
  ^-  @ud
  (max 1 (div (ordinary-maximum maximum) (max 1 count)))
++  select
  |=  [p=project:nc r=tool-request:nc]
  ^-  (each selection @tas)
  =/  args=tool-args:nc  arguments.r
  ?:  ?=(%eval -.args)
    ?:  !(readable:project p pax.args)  [%| %evaluation-path-refused]
    [%& [%hoon pax.args ~]]
  ?.  ?=(?(%compile %check) -.args)  [%| %not-a-build-operation]
  =/  found=(list build-target:nc)
    (skim targets.p |=(v=build-target:nc =(target.args name.v)))
  ?~  found  [%| %build-target-missing]
  [%& [kind.i.found entry.i.found checks.i.found]]
++  evaluate
  ::  Preserve the original public result and refusal symbols.
  |=  [built=vase expression=@t fuel=@ud]
  ^-  (each [value=* packed=@ux] @tas)
  =/  result  (evaluate-detail built expression fuel)
  ?:(?=(%& -.result) [%& p.result] [%| reason.p.result])
++  trace-append
  |=  [out=@t text=@t]
  ^-  @t
  ?:  (gth (add 1 (add (met 3 out) (met 3 text))) 2.048)  out
  (cat 3 out (cat 3 '\0a' text))
++  trace-detail
  ::  Excerpt actual tang leaves without rendering an unbounded type tree.
  ::  Both pending work and visited nodes are bounded; oversized leaves skip.
  |=  trace=tang
  ^-  @t
  =/  pending=(list tank)  (scag 128 trace)
  =/  left=@ud  128
  =/  out=@t  'Native expression tang excerpt (formatting omitted; may be incomplete):'
  |-  ^-  @t
  ?:  |(=(0 left) =(~ pending))  out
  =/  node=tank  (snag 0 pending)
  =.  pending  (slag 1 pending)
  =.  left  (dec left)
  ?@  node  $(out (trace-append out node))
  ?:  ?=(%leaf -.node)
    $(out (trace-append out (crip (scag 2.049 p.node))))
  $(pending (scag 128 (weld (scag 128 q.node) pending)))
++  bounded-runtime
  ::  An old runtime ignores the new hint and returns 1. Refuse there before
  ::  evaluating any user expression; the finite probe never loops.
  ^-  ?
  =/  probe=tone
    (mink [0 [11 [%jinx [1 [%soft 1]]] [4 [1 0]]]] ~)
  ?.  ?=(%2 -.probe)  %.n
  ?~  trace.probe  %.n
  =([%mean 'evaluation-budget-exceeded'] i.trace.probe)
++  evaluate-detail
  ::  fuel is a native work budget in microseconds, not an instruction count
  ::  or authority deadline. No scry handler or effect interpreter is supplied.
  |=  [built=vase expression=@t fuel=@ud]
  ^-  (each [value=* packed=@ux] [reason=@tas detail=@t])
  ?.  &((gte fuel 1) (lte fuel 2.000.000) (lte (met 3 expression) 8.192))
    [%| %evaluation-budget-refused 'evaluation-budget-refused']
  ?.  bounded-runtime
    [%| %evaluation-runtime-unavailable 'The runtime cannot return a bounded evaluation timeout.']
  =/  budget=@dr  `@dr`(div (mul fuel ~s1) 1.000.000)
  =/  checked
    %-  mule
    |.  ^-  (each [value=* packed=@ux] [reason=@tas detail=@t])
    ::  One allowance covers compilation, evaluation and output packing.
    ~>  %jinx.[%soft budget]
    =/  compiled  (mule |.((~(mint ut p.built) %noun (ream expression))))
    ?:  ?=(%| -.compiled)  [%| %expression-compile-failed (trace-detail p.compiled)]
    =/  evaluated=tone  (mink [q.built q.p.compiled] ~)
    ?.  ?=(%0 -.evaluated)  [%| %evaluation-failed 'evaluation-failed']
    =/  packed=@ux  (jam product.evaluated)
    ?.  (lte (met 3 packed) 8.192)  [%| %evaluation-output-too-large 'evaluation-output-too-large']
    [%& [product.evaluated packed]]
  ?:  ?=(%| -.checked)  [%| %evaluation-failed (trace-detail p.checked)]
  p.checked
++  diagnostic
  |=  [name=@tas passed=? detail=@t source=revision:nc artifacts=(list @ux)]
  ^-  diagnostic:nc
  [name passed detail source artifacts]
++  report
  |=  [r=tool-request:nc built=(unit vase) checks=(list [name=@tas expression=@t]) maximum=@ud]
  ^-  tool-output:nc
  =/  source=revision:nc  source.context.r
  ?~  built
    =/  selected=@t
      ?:  ?=(%eval -.arguments.r)  (spat pax.arguments.r)
      ?>  ?=(?(%compile %check) -.arguments.r)
      target.arguments.r
    =/  message=@t
      (cat 3 (cat 3 'Selected target/path: ' selected) '. Clay returned no compiler value; compiler trace unavailable through this API.')
    [%diagnostics ~[(diagnostic %compile %.n message source ~)]]
  =/  artifact=@ux  (shax (jam q.u.built))
  =/  compiled=diagnostic:nc
    (diagnostic %compile %.y 'Native Ford built the selected immutable source revision.' source ~[artifact])
  =/  args=tool-args:nc  arguments.r
  ?:  ?=(%compile -.args)  [%diagnostics ~[compiled]]
  ?:  ?=(%eval -.args)
    =/  ran  (evaluate-detail u.built expression.args fuel.args)
    ?:  ?=(%| -.ran)
      [%diagnostics ~[compiled (diagnostic %eval %.n detail.p.ran source ~[artifact])]]
    [%diagnostics ~[compiled (diagnostic %eval %.y (cat 3 'Result as jam hex: ' (scot %ux packed.p.ran)) source ~[artifact (shax packed.p.ran)])]]
  ?.  ?=(%check -.args)  [%refused %unexpected-operation 'This request is not a compile, check or evaluation.']
  ?~  checks  [%refused %no-checks-configured 'The owner has not configured checks for this target.']
  =/  per-check=@ud  (ordinary-per-check maximum (lent checks))
  =/  out=(list diagnostic:nc)
    %+  turn  `(list [name=@tas expression=@t])`checks
    |=  [name=@tas expression=@t]
    ^-  diagnostic:nc
    =/  ran  (evaluate-detail u.built expression per-check)
    ?:  ?=(%| -.ran)  (diagnostic name %.n detail.p.ran source ~[artifact])
    (diagnostic name =(0 value.p.ran) (verdict value.p.ran (scot %ux packed.p.ran)) source ~[artifact (shax packed.p.ran)])
  [%diagnostics [compiled out]]
++  report-detailed
  ::  The caller binds this bounded compiler detail to its one native build.
  ::  Detail never changes the verdict, source, artifacts or tool authority.
  |=  [r=tool-request:nc built=(unit vase) detail=(unit @t) checks=(list [name=@tas expression=@t]) maximum=@ud]
  ^-  tool-output:nc
  =/  out=tool-output:nc  (report r built checks maximum)
  ?^  built  out
  ?~  detail  out
  ?.  &((gth (met 3 u.detail) 0) (lte (met 3 u.detail) 6.144))  out
  ?.  ?=(%diagnostics -.out)  out
  ?~  values.out  out
  =/  first=diagnostic:nc  i.values.out
  ?.  &(=(%compile name.first) !passed.first =(source.context.r source.first))  out
  out(values [first(detail u.detail) t.values.out])
++  verdict
  ::  A check passes only on Hoon true (%.y, the atom 0). Say which outcome
  ::  it was in words; jam hex alone (jam of 0 is 0x2) reads as a mismatch.
  |=  [value=* jammed=@t]
  ^-  @t
  ?:  =(0 value)  'Passed: the check returned true (%.y).'
  =/  got=@t  ?:(=(1 value) 'false (%.n)' 'a non-boolean noun')
  (rap 3 ~['Failed: expected true (%.y); the check returned ' got ', jam hex ' jammed '.'])
++  candidate-target
  ::  Complete ordered rows even when a target could not compile. No skipped
  ::  check becomes a pass; results are bound to the proposed source desk.
  |=  [t=build-target:nc source=revision:nc built=(unit vase) maximum=@ud]
  ^-  target-result:accept
  =/  artifact=(list @ux)  ?~(built ~ ~[(shax (jam q.u.built))])
  =/  detail=@t
    ?~  built
      (rap 3 ~['Target ' name.t ' at ' (spat entry.t) ': Ford returned no compiled value.'])
    'The proposed file was built by native Ford.'
  =/  compiled=diagnostic:nc
    (diagnostic %compile ?=(^ built) detail source artifact)
  =/  each-budget=@ud  (max 1 (div maximum (max 1 (lent checks.t))))
  =/  rows=(list diagnostic:nc)
    %+  turn  checks.t
    |=  [name=@tas expression=@t]
    ^-  diagnostic:nc
    ?~  built  (diagnostic name %.n 'Check not run because no compiled value was returned.' source ~)
    =/  ran  (evaluate-detail u.built expression each-budget)
    ?:  ?=(%| -.ran)  (diagnostic name %.n detail.p.ran source artifact)
    =/  actual=@t
      ?:  (lte (met 3 packed.p.ran) 128)  (scot %ux packed.p.ran)
      (cat 3 'large noun, digest ' (scot %ux (shax packed.p.ran)))
    (diagnostic name =(0 value.p.ran) (verdict value.p.ran actual) source (weld artifact ~[(shax packed.p.ran)]))
  [t [compiled rows]]
--
