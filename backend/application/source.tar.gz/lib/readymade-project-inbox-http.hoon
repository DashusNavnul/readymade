::  Local owner inbox: historical suggestion receipts, never permission or
::  acceptance. No cards, state changes, peer scries, or inferred sessions.
/-  pa=cantrip-project-access
/+  runtime=cantrip-project-access-runtime, read=cantrip-project-access-read,
    view=readymade-project-view-http, mg=readymade-app-management,
    guard=viki-scry-guard
|%
+$  selector  [project=@t receipt=(unit @ux)]
++  select
  |=  [project=@t receipt=(unit @t)]
  ^-  selector
  ?>  (project-valid:view project)
  ?~  receipt  [project ~]
  ?>  (lte (met 3 u.receipt) 82)
  =/  hash=@ux  (need (slaw %ux u.receipt))
  ?>  &((gth hash 0) (lte (met 0 hash) 256) =(u.receipt (scot %ux hash)))
  [project `hash]
++  request
  |=  req=inbound-request:eyre
  ^-  (unit selector)
  ?.  ?&  authenticated.req  =('GET' method.request.req)
          =('/apps/readymade-collab/project-inbox' url.request.req)
      ==  ~
  =/  project  (header:mg header-list.request.req 'x-readymade-project')
  ?~  project  ~
  =/  receipt  (header:mg header-list.request.req 'x-readymade-project-receipt')
  (mole |.((select u.project receipt)))
++  rows
  |=  [our=@p actor=@p q=selector saved=records:pa]
  ^-  (list receipt:pa)
  ?>  =(our actor)
  ?>  (project-valid:view project.q)
  ?>  (lte ~(wyt by saved) 64)
  =/  remaining  ~(tap by saved)
  =|  found=(list receipt:pa)
  |-  ^-  (list receipt:pa)
  ?~  remaining  (flop found)
  =/  key  p.i.remaining
  =/  r=receipt:pa  q.i.remaining
  ?>  ?&  (receipt-valid:runtime r)  =(our owner.r)
          =(key [project.request.r peer.r generation.request.r nonce.request.r])
      ==
  ?.  &(=(project.q project.request.r) ?=(%suggest -.payload.r))
    $(remaining t.remaining)
  =/  hash=@ux  (shax (jam r))
  ?.  ?~(receipt.q %.y =(u.receipt.q hash))  $(remaining t.remaining)
  $(remaining t.remaining, found [r found])
++  row
  |=  [r=receipt:pa detail=?]
  ^-  json
  ?>  &((receipt-valid:runtime r) ?=(%suggest -.payload.r))
  =/  parent=parent:pa  parent.payload.r
  =/  change  change.payload.r
  ?>  ?=(^ before.change)
  =/  fields=(list [@t json])
    :~  ['receiptHash' s+(scot %ux (shax (jam r)))]
        ['peer' s+(scot %p peer.r)]  ['receivedAt' s+(scot %da at.r)]
        ['generation' s+(scot %ud generation.request.r)]
        ['request' s+(scot %ux nonce.request.r)]
        ['path' s+(spat pax.request.r)]
        ['sourceHash' s+(scot %ux (shax source.payload.r))]
        ['parentRoot' s+(scot %ux root.parent)]
        ['snapshotDigest' s+(scot %ux digest.snapshot.parent)]
        ['desk' s+base-desk.body.snapshot.parent]
        ['revision' s+(scot %ud base-revision.body.snapshot.parent)]
        ['originalHash' s+(scot %ux u.before.change)]
    ==
  (pairs:enjs:format ?:(detail [['source' s+source.payload.r] fields] fields))
++  encode
  |=  [our=@p actor=@p q=selector saved=records:pa]
  ^-  json
  =/  receipts  (rows our actor q saved)
  ?>  ?~(receipt.q %.y =(1 (lent receipts)))
  =/  value=json
    %-  pairs:enjs:format
    :~  ['schema' s+'readymade-project-inbox-v1']
        ['owner' s+(scot %p our)]  ['project' s+project.q]
        ['permissionGranted' b+%.n]  ['committed' b+%.n]
        ['receipts' a+(turn receipts |=(r=receipt:pa (row r ?=(^ receipt.q))))]
    ==
  ?>  (lte (met 3 (en:json:html value)) 524.288)
  value
++  decode-answer
  ::  Exactly five keys: the owner's own word about one retained suggestion.
  |=  [our=@p raw=@t]
  ^-  [project=@t receipt=@ux taken=?]
  ?>  (lte (met 3 raw) 1.024)
  =/  value=json  (need (de:json:html raw))
  ?>  ?=(%o -.value)
  =/  obj=(map @t json)  p.value
  ?>  =(5 ~(wyt by obj))
  ?>  =('readymade-suggestion-answer-v1' (text-field:mg obj 'schema' 64))
  ?>  =((scot %p our) (text-field:mg obj 'owner' 128))
  =/  q=selector  (select (text-field:mg obj 'project' 128) `(text-field:mg obj 'receipt' 82))
  =/  answer=@t  (text-field:mg obj 'answer' 16)
  ?>  |(=('taken' answer) =('declined' answer))
  [project.q (need receipt.q) =('taken' answer)]
++  answer-request
  |=  [our=@p req=inbound-request:eyre]
  ^-  (unit [project=@t receipt=@ux taken=?])
  ?.  ?&  authenticated.req  =('POST' method.request.req)
          =('/apps/readymade-collab/suggestion-answer' url.request.req)
      ==
    ~
  =/  host  (header:mg header-list.request.req 'host')
  =/  origin  (header:mg header-list.request.req 'origin')
  =/  mime  (header:mg header-list.request.req 'content-type')
  ?~  host  ~
  ?~  origin  ~
  ?~  mime  ~
  ?.  ?&  =(u.origin (cat 3 ?:(secure.req 'https://' 'http://') u.host))
          |(=(u.mime 'application/json') =(u.mime 'application/json; charset=utf-8'))
          =(`'v1' (header:mg header-list.request.req 'x-readymade-suggestion-answer'))
      ==
    ~
  ?~  body.request.req  ~
  =/  body  u.body.request.req
  ?.  &((lte p.body 1.024) =(p.body (met 3 q.body)))  ~
  (mole |.((decode-answer our q.body)))
++  find
  ::  The one retained suggestion receipt of this project with this hash.
  |=  [our=@p actor=@p at=@da project=@t hash=@ux]
  ^-  (each receipt:pa @tas)
  ?.  =(our actor)  [%| %foreign-owner]
  ?.  (agent-live:guard our at %cantrip)  [%| %cantrip-not-live]
  =/  catalog  (catalog:read our actor at project)
  ?:  ?=(%| -.catalog)  [%| p.catalog]
  =/  saved=records:pa
    .^(records:pa %gx /(scot %p our)/cantrip/(scot %da at)/project-access/records/noun)
  =/  selected  (mole |.((rows our actor [project `hash] saved)))
  ?~  selected  [%| %receipt-state-invalid]
  ?~  u.selected  [%| %receipt-missing]
  [%& i.u.selected]
++  answer-receipt
  ::  What was sent, never whether the peer's ship took it.
  |=  taken=?
  ^-  json
  %-  pairs:enjs:format
  ^-  (list [@t json])
  :~  ['schema' s+'readymade-suggestion-answer-receipt-v1']
      ['status' s+'sent']
      ['answer' s+?:(taken 'taken' 'declined')]
      ['confirmed' b+%.n]
  ==
++  observe
  ::  Authenticated Eyre owner must be supplied by the caller. Historical
  ::  receipts remain visible after grant revocation, without renewing it.
  |=  [our=@p actor=@p at=@da q=selector]
  ^-  (each json @tas)
  ?.  =(our actor)  [%| %foreign-owner]
  ?.  (agent-live:guard our at %cantrip)  [%| %cantrip-not-live]
  =/  catalog  (catalog:read our actor at project.q)
  ?:  ?=(%| -.catalog)  [%| p.catalog]
  =/  saved=records:pa
    .^(records:pa %gx /(scot %p our)/cantrip/(scot %da at)/project-access/records/noun)
  =/  selected  (mole |.((rows our actor q saved)))
  ?~  selected  [%| %receipt-state-invalid]
  ?:  &(?=(^ receipt.q) ?=(~ u.selected))  [%| %receipt-missing]
  =/  result  (mole |.((encode our actor q saved)))
  ?~  result  [%| %receipt-state-invalid]
  [%& u.result]
--
