::  Items 61 and 68: claim tasks natively without duplicate ownership, and
::  keep consequential questions for the owner while independent work goes on.
::
::  Stored insert-only in Clay on the private dead desk %owner-tasks:
::    /claim/<task>/<n>/noun     claim n on a task: who, until when (or a release)
::    /question/<id>/noun        a question for the owner, on one task
::    /answer/<id>/noun          the owner's answer
::    /withdrawn/<id>/noun       the asker took its own question back
::  A task has at most one owner: a claim is refused while another claimant
::  holds a live (unexpired, unreleased) claim; the holder may renew. Leases
::  last at most one hour, so a vanished agent never owns a task for good.
::  A question blocks only its own task: while it is open nobody may claim
::  that task, and every other task stays claimable. Nothing is erased.
::    /proposal/<id>/noun        a task an agent proposes (items 56, 57)
::    /proposal-closed/<id>/noun the proposer withdrew it, or the owner dismissed it
::  A proposal states its evidence, expected outcome, dependencies and the
::  paths it would touch. It is admitted only through the owner's standing
::  policy: the policy must be in force for that project and every path must
::  be one the policy names; otherwise it is refused with the reason and
::  nothing is stored. Admission is not a claim and starts no work.
/+  standing=cantrip-standing-policy
|%
++  desk  %owner-tasks
++  lease-max  ~h1
++  history-max  256
+$  claim  [%owner-task-claim-v1 task=@t n=@ud who=@t at=@da until=@da release=?]
+$  question  [%owner-question-v1 id=@ux task=@t who=@t text=@t consequence=@t at=@da]
+$  answer  [%owner-answer-v1 id=@ux text=@t by=@p at=@da]
::  The asker withdraws its own open question; that closes it like an answer
::  does, and is shown as withdrawn, never as answered.
+$  retraction  [%owner-question-withdrawn-v1 id=@ux who=@t at=@da]
+$  proposal
  $:  %owner-task-proposal-v1  id=@ux  task=@t  who=@t  project=@t
      evidence=@t  outcome=@t  depends=(list @t)  paths=(set path)
      policy=@ud  at=@da
  ==
::  A proposal ends without becoming work: its proposer takes it back, or the
::  owner dismisses it. Either is recorded once; the proposal stays readable.
+$  closure  [%owner-proposal-closed-v1 id=@ux by=?(%withdrawn %dismissed) who=@t at=@da]
+$  command
  $%  [%propose task=@t who=@t project=@t evidence=@t outcome=@t depends=(list @t) paths=(set path)]
      [%claim task=@t who=@t seconds=@ud]
      [%release task=@t who=@t]
      [%ask task=@t who=@t text=@t consequence=@t]
      [%answer id=@ux text=@t]
      [%retract id=@ux who=@t]
      [%withdraw-proposal id=@ux who=@t]
      [%dismiss-proposal id=@ux]
  ==
++  text-ok  |=([t=@t max=@ud] &(!=(0 (met 3 t)) (lte (met 3 t) max) ((sane %t) t)))
++  task-ok  |=(t=@t &((text-ok t 128) ((sane %ta) t)))
++  question-id
  |=  [task=@t who=@t text=@t]
  ^-  @ux
  (shax (jam [%owner-question-v1 task who text]))
::  ---  pure law
++  holder
  ::  The live claim on a task now, if any (the newest decides).
  |=  [cs=(list claim) now=@da]
  ^-  (unit claim)
  ?:  =(~ cs)  ~
  =/  last=claim
    (roll cs |=([c=claim acc=claim] ?:((gth n.c n.acc) c acc)))
  ?:  |(release.last (lte until.last now))  ~
  `last
++  open
  ::  Questions on a task with no answer yet.
  |=  [qs=(list question) answered=(set @ux) task=@t]
  ^-  (list question)
  (skim qs |=(q=question &(=(task task.q) !(~(has in answered) id.q))))
++  admit
  ::  Policy first: the policy in force (its version and body), then bounds.
  |=  [held=(list proposal) policy=(unit [version=@ud =body:standing]) now=@da c=command]
  ^-  (each proposal @tas)
  ?>  ?=(%propose -.c)
  ?~  policy  [%| %proposal-policy-not-in-force]
  ?.  =(project.c project.body.u.policy)  [%| %proposal-policy-other-project]
  ?.  ?&  (task-ok task.c)  (text-ok who.c 64)  (text-ok evidence.c 2.048)
          (text-ok outcome.c 1.024)  (lte (lent depends.c) 16)  (levy depends.c task-ok)
          !=(~ paths.c)  (lte ~(wyt in paths.c) 64)
      ==
    [%| %proposal-invalid]
  ?.  (levy ~(tap in paths.c) |=(p=path (~(has in paths.body.u.policy) p)))
    [%| %proposal-path-outside-policy]
  =/  id  (shax (jam [%owner-task-proposal-v1 task.c who.c project.c]))
  ?:  (lien held |=(p=proposal =(id id.p)))  [%| %proposal-duplicate]
  ?:  (gte (lent held) history-max)  [%| %proposal-history-full]
  [%& [%owner-task-proposal-v1 id task.c who.c project.c evidence.c outcome.c depends.c paths.c version.u.policy now]]
++  close
  ::  held: the proposals; shut: ids already closed. Only its proposer withdraws.
  |=  [held=(list proposal) shut=(set @ux) now=@da c=command]
  ^-  (each closure @tas)
  ?>  ?=(?(%withdraw-proposal %dismiss-proposal) -.c)
  =/  id=@ux  ?-(-.c %withdraw-proposal id.c, %dismiss-proposal id.c)
  =/  found  (skim held |=(p=proposal =(id id.p)))
  ?~  found  [%| %proposal-missing]
  ?:  (~(has in shut) id)  [%| %proposal-closed]
  ?:  ?=(%dismiss-proposal -.c)  [%& [%owner-proposal-closed-v1 id %dismissed 'owner' now]]
  ?.  =(who.c who.i.found)  [%| %proposal-not-yours]
  [%& [%owner-proposal-closed-v1 id %withdrawn who.c now]]
++  decide
  ::  The one new record a command writes, or the reason it is refused.
  |=  [cs=(list claim) qs=(list question) answered=(set @ux) now=@da our=@p c=command]
  ^-  (each * @tas)
  ?-  -.c
      ?(%propose %withdraw-proposal %dismiss-proposal)  [%| %proposal-needs-policy]
  ::
      %claim
    ?.  &((task-ok task.c) (text-ok who.c 64))  [%| %claim-invalid]
    ?.  &((gth seconds.c 0) (lte (mul seconds.c ~s1) lease-max))  [%| %claim-lease-invalid]
    ?^  (open qs answered task.c)  [%| %claim-blocked-by-question]
    =/  h  (holder cs now)
    ?:  &(?=(^ h) !=(who.u.h who.c))  [%| %claim-held]
    ?:  (gte (lent cs) history-max)  [%| %claim-history-full]
    [%& `claim`[%owner-task-claim-v1 task.c +((lent cs)) who.c now (add now (mul seconds.c ~s1)) %.n]]
  ::
      %release
    =/  h  (holder cs now)
    ?~  h  [%| %claim-not-held]
    ?.  =(who.u.h who.c)  [%| %claim-held]
    [%& `claim`[%owner-task-claim-v1 task.c +((lent cs)) who.c now now %.y]]
  ::
      %ask
    ?.  &((task-ok task.c) (text-ok who.c 64) (text-ok text.c 2.048) (text-ok consequence.c 1.024))
      [%| %question-invalid]
    =/  id  (question-id task.c who.c text.c)
    ?:  (lien qs |=(q=question =(id id.q)))  [%| %question-duplicate]
    [%& `question`[%owner-question-v1 id task.c who.c text.c consequence.c now]]
  ::
      %answer
    ?.  (text-ok text.c 2.048)  [%| %answer-invalid]
    ?.  (lien qs |=(q=question =(id.c id.q)))  [%| %question-missing]
    ?:  (~(has in answered) id.c)  [%| %question-answered]
    [%& `answer`[%owner-answer-v1 id.c text.c our now]]
  ::
      %retract
    =/  found  (skim qs |=(q=question =(id.c id.q)))
    ?~  found  [%| %question-missing]
    ?.  =(who.c who.i.found)  [%| %question-not-yours]
    ?:  (~(has in answered) id.c)  [%| %question-answered]
    [%& `retraction`[%owner-question-withdrawn-v1 id.c who.c now]]
  ==
::  ---  Clay store
++  base  |=([our=@p at=@da] `path`/(scot %p our)/[desk]/(scot %da at))
++  store
  |=  [our=@p at=@da]
  ^-  ?
  ?.  .^(? %cu (weld (base our at) /sys/kelvin))  %.n
  =/  rules  .^([r=dict:clay w=dict:clay] %cp (base our at))
  &(=([%white ~ ~] rul.r.rules) =([%white ~ ~] rul.w.rules))
++  dir-has
  |=  [our=@p at=@da pax=path name=@ta]
  ^-  ?
  =/  top=arch  .^(arch %cy (weld (base our at) pax))
  (~(has by dir.top) name)
++  claims-of
  |=  [our=@p at=@da task=@t]
  ^-  (list claim)
  ?.  (dir-has our at / %claim)  ~
  ?.  (dir-has our at /claim task)  ~
  %+  turn  ~(tap in ~(key by dir:.^(arch %cy (weld (base our at) /claim/[task]))))
  |=(n=@ta ;;(claim .^(* %cx (weld (base our at) /claim/[task]/[n]/noun))))
++  tasks
  |=  [our=@p at=@da]
  ^-  (list @t)
  ?.  (dir-has our at / %claim)  ~
  ~(tap in ~(key by dir:.^(arch %cy (weld (base our at) /claim))))
++  questions
  |=  [our=@p at=@da]
  ^-  (list question)
  ?.  (dir-has our at / %question)  ~
  %+  turn  ~(tap in ~(key by dir:.^(arch %cy (weld (base our at) /question))))
  |=(n=@ta ;;(question .^(* %cx (weld (base our at) /question/[n]/noun))))
++  answers
  |=  [our=@p at=@da]
  ^-  (list answer)
  ?.  (dir-has our at / %answer)  ~
  %+  turn  ~(tap in ~(key by dir:.^(arch %cy (weld (base our at) /answer))))
  |=(n=@ta ;;(answer .^(* %cx (weld (base our at) /answer/[n]/noun))))
++  proposals
  |=  [our=@p at=@da]
  ^-  (list proposal)
  ?.  (dir-has our at / %proposal)  ~
  %+  turn  ~(tap in ~(key by dir:.^(arch %cy (weld (base our at) /proposal))))
  |=(n=@ta ;;(proposal .^(* %cx (weld (base our at) /proposal/[n]/noun))))
++  closures
  |=  [our=@p at=@da]
  ^-  (list closure)
  ?.  (dir-has our at / %proposal-closed)  ~
  %+  turn  ~(tap in ~(key by dir:.^(arch %cy (weld (base our at) /proposal-closed))))
  |=(n=@ta ;;(closure .^(* %cx (weld (base our at) /proposal-closed/[n]/noun))))
++  policy-now
  |=  [our=@p at=@da]
  ^-  (unit [version=@ud =body:standing])
  =/  held  (current:standing our at)
  ?:  ?=(%| -.held)  ~
  ?~  p.held  ~
  ?~  body.u.p.held  ~
  `[version.u.p.held u.body.u.p.held]
++  retractions
  |=  [our=@p at=@da]
  ^-  (list retraction)
  ?.  (dir-has our at / %withdrawn)  ~
  %+  turn  ~(tap in ~(key by dir:.^(arch %cy (weld (base our at) /withdrawn))))
  |=(n=@ta ;;(retraction .^(* %cx (weld (base our at) /withdrawn/[n]/noun))))
++  closed
  ::  Every question that is no longer open: answered by the owner, or withdrawn by its asker.
  |=  [our=@p at=@da]
  ^-  (set @ux)
  %-  ~(gas in (silt (turn (answers our at) |=(a=answer id.a))))
  (turn (retractions our at) |=(r=retraction id.r))
++  write
  |=  [our=@p at=@da c=command]
  ^-  (each card:agent:gall @tas)
  ?.  (store our at)  [%| %owner-tasks-store-unavailable]
  ?:  ?=(%propose -.c)
    =/  made  (admit (proposals our at) (policy-now our at) at c)
    ?:  ?=(%| -.made)  [%| p.made]
    [%& [%pass /owner-tasks %arvo %c %info desk %& ~[[/proposal/(scot %ux id.p.made)/noun %ins %noun !>(p.made)]]]]
  ?:  ?=(?(%withdraw-proposal %dismiss-proposal) -.c)
    =/  made  (close (proposals our at) (silt (turn (closures our at) |=(x=closure id.x))) at c)
    ?:  ?=(%| -.made)  [%| p.made]
    [%& [%pass /owner-tasks %arvo %c %info desk %& ~[[/proposal-closed/(scot %ux id.p.made)/noun %ins %noun !>(p.made)]]]]
  =/  task=@t
    ?-  -.c
      ?(%claim %release %ask)  task.c
      ?(%answer %retract)  ''
    ==
  =/  cs  ?:(=('' task) ~ (claims-of our at task))
  =/  qs  (questions our at)
  =/  answered=(set @ux)  (closed our at)
  =/  made  (decide cs qs answered at our c)
  ?:  ?=(%| -.made)  [%| p.made]
  =/  pax=path
    ?-  -.c
      ?(%claim %release)  /claim/[task]/(scot %ud n:;;(claim p.made))/noun
      %ask  /question/(scot %ux id:;;(question p.made))/noun
      %answer  /answer/(scot %ux id.c)/noun
      %retract  /withdrawn/(scot %ux id.c)/noun
    ==
  [%& [%pass /owner-tasks %arvo %c %info desk %& ~[[pax %ins %noun !>(p.made)]]]]
::  ---  HTTP (console, owner only)
++  prefix  '/apps/pataphor-native/coding/tasks'
++  decode
  |=  raw=@t
  ^-  (unit command)
  %-  mole
  |.
  =/  v=json  (need (de:json:html raw))
  ?>  ?=(%o -.v)
  =/  get  |=(k=@t =/(x (~(got by p.v) k) ?>(?=(%s -.x) p.x)))
  =/  a  (get 'action')
  ?:  =('propose' a)
    =/  texts  |=(k=@t =/(x (~(got by p.v) k) ?>(?=(%a -.x) (turn p.x |=(j=json ?>(?=(%s -.j) p.j))))))
    :*  %propose  (get 'task')  (get 'who')  (get 'project')  (get 'evidence')  (get 'outcome')
        (texts 'depends')
        (silt (turn (texts 'paths') |=(t=@t (need (rush t ;~(pfix fas (more fas urs:ab)))))))
    ==
  ?:  =('claim' a)  [%claim (get 'task') (get 'who') (rash (get 'seconds') dem)]
  ?:  =('release' a)  [%release (get 'task') (get 'who')]
  ?:  =('ask' a)  [%ask (get 'task') (get 'who') (get 'text') (get 'consequence')]
  ?:  =('retract' a)  [%retract (need (slaw %ux (get 'id'))) (get 'who')]
  ?:  =('withdraw-proposal' a)  [%withdraw-proposal (need (slaw %ux (get 'id'))) (get 'who')]
  ?:  =('dismiss-proposal' a)  [%dismiss-proposal (need (slaw %ux (get 'id')))]
  ?>  =('answer' a)
  [%answer (need (slaw %ux (get 'id'))) (get 'text')]
++  view
  |=  [our=@p at=@da]
  ^-  json
  ?.  (store our at)  (pairs:enjs:format ~[['schema' s+'owner-tasks-v1'] ['available' b+%.n]])
  =/  qs  (questions our at)
  =/  as  (answers our at)
  =/  gone=(set @ux)  (silt (turn (retractions our at) |=(r=retraction id.r)))
  =/  answered=(set @ux)  (closed our at)
  =/  task-rows=(list json)
    %+  turn  (tasks our at)
    |=  t=@t
    =/  cs  (claims-of our at t)
    =/  h  (holder cs at)
    =/  blocking  (open qs answered t)
    %-  pairs:enjs:format
    :~  ['task' s+t]  ['claims' (numb:enjs:format (lent cs))]
        ['holder' ?~(h ~ s+who.u.h)]  ['until' ?~(h ~ s+(scot %da until.u.h))]
        ['blockedBy' a+(turn blocking |=(q=question s+(scot %ux id.q)))]
    ==
  =/  q-rows=(list json)
    %+  turn  (sort qs |=([a=question b=question] (gth at.a at.b)))
    |=  q=question
    =/  ans  (skim as |=(a=answer =(id.a id.q)))
    %-  pairs:enjs:format
    :~  ['id' s+(scot %ux id.q)]  ['task' s+task.q]  ['who' s+who.q]
        ['text' s+text.q]  ['consequence' s+consequence.q]  ['at' s+(scot %da at.q)]
        ['open' b+!(~(has in answered) id.q)]
        ['answer' ?~(ans ~ s+text.i.ans)]
        ['withdrawn' b+(~(has in gone) id.q)]
    ==
  %-  pairs:enjs:format
  :~  ['schema' s+'owner-tasks-v1']  ['available' b+%.y]  ['observedAt' s+(scot %da at)]
      ['openQuestions' (numb:enjs:format (lent (skip qs |=(q=question (~(has in answered) id.q)))))]
      ['tasks' a+task-rows]  ['questions' a+q-rows]
      :-  'proposals'
      :-  %a
      %+  turn  (sort (proposals our at) |=([a=proposal b=proposal] (gth at.a at.b)))
      |=  p=proposal
      %-  pairs:enjs:format
      :~  ['id' s+(scot %ux id.p)]  ['task' s+task.p]  ['who' s+who.p]  ['project' s+project.p]
          ['evidence' s+evidence.p]  ['outcome' s+outcome.p]
          ['depends' a+(turn depends.p |=(t=@t s+t))]
          ['paths' a+(turn (sort ~(tap in paths.p) aor) |=(x=path s+(spat x)))]
          ['policyVersion' (numb:enjs:format policy.p)]  ['at' s+(scot %da at.p)]
          :-  'closed'
          =/  shut  (skim (closures our at) |=(x=closure =(id.x id.p)))
          ?~(shut ~ s+by.i.shut)
      ==
  ==
--
