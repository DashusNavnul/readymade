::  /lib/multiplayer-concurrency
::
::  Claims are advisory only. Comparison is pure and does not invoke %merg.
::
/-  mc=multiplayer-changeset, mn=multiplayer-concurrency
/+  mcl=multiplayer-changeset
|%
++  claim-digest
  |=  body=claim-body:mn
  ^-  digest:mn
  `@ux`(shax (jam [%multiplayer-path-claim-v1 body]))
++  make-claim
  |=  body=claim-body:mn
  ^-  claim:mn
  [body (claim-digest body)]
++  claim-valid
  |=  item=claim:mn
  ^-  ?
  ?&  =(1 version.body.item)
      !=(0 project.body.item)
      !=(0 task.body.item)
      !=(0 workspace.body.item)
      ?=(^ ~(tap in paths.body.item))
      (gth expires-at.body.item claimed-at.body.item)
      =((claim-digest body.item) digest.item)
  ==
++  overlap
  |=  [left=claim:mn right=claim:mn observed-at=@da]
  ^-  (unit overlap:mn)
  ?.  ?&  (claim-valid left)
          (claim-valid right)
          =(project.body.left project.body.right)
          !=(digest.left digest.right)
          (lth observed-at expires-at.body.left)
          (lth observed-at expires-at.body.right)
      ==
    ~
  =/  shared=(set path)  (~(int in paths.body.left) paths.body.right)
  =/  paths=(list path)  ~(tap in shared)
  ?~  paths  ~
  `[digest.left digest.right paths]
++  classify
  |=  $:  original=(unit digest:mn)
          recognized=(unit digest:mn)
          current=(unit digest:mn)
          proposed=(unit digest:mn)
      ==
  ^-  classification:mn
  ?:  !=(original recognized)  %stale
  ?:  =(current proposed)  %duplicate
  ?:  =(current original)  %clean
  %conflicting
++  compare-one
  |=  $:  base-files=(map path digest:mn)
          current-files=(map path digest:mn)
          change=change:mc
      ==
  ^-  comparison:mn
  =/  recognized=(unit digest:mn)  (~(get by base-files) path.change)
  =/  current=(unit digest:mn)  (~(get by current-files) path.change)
  =/  verdict=classification:mn
    (classify before.change recognized current after.change)
  [path.change before.change current after.change verdict]
++  count-verdict
  |=  [wanted=classification:mn comparisons=(list comparison:mn)]
  ^-  @ud
  (lent (skim comparisons |=(item=comparison:mn =(wanted verdict.item))))
++  compare
  |=  $:  changeset=changeset:mc
          base-files=(map path digest:mn)
          current-files=(map path digest:mn)
      ==
  ^-  (unit report:mn)
  ?.  =((changeset-digest:mcl body.changeset) digest.changeset)  ~
  =/  comparisons=(list comparison:mn)
    (turn changes.body.changeset |=(change=change:mc (compare-one base-files current-files change)))
  `[digest.changeset comparisons (count-verdict %clean comparisons) (count-verdict %stale comparisons) (count-verdict %duplicate comparisons) (count-verdict %conflicting comparisons)]
--
