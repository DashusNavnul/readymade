::  Wire adapter for NativeCodingTerminal.gls. No editing decisions here.
::  Owner-installed artifacts are executable code, never model or browser data.
::  This optional boundary permits the legacy console to load without a bundle.
/+  vm=native-coding-terminal-plan, scalar=terminal-plan
|%
+$  bundle
  [%native-coding-terminal-artifact-v1 source=@ux digest=@ux initial=plan:vm valid=plan:vm reduce=plan:vm contents=plan:vm]
+$  state
  [%native-coding-terminal-state-v1 artifact=(unit bundle) editors=(map @ux plan:vm)]
+$  effect  $%([%none ~] [%command text=@t] [%interrupt ~] [%pause ~])
++  source-digest
  0x755a.6c4e.d314.a73d.41f2.3321.5cd7.b3cc.cae8.541a.88b6.5fb3.7e1d.17f8.3d23.68e6
++  fuel  2.000.000
++  error  %native-editor-artifact-unavailable
++  empty  `state`[%native-coding-terminal-state-v1 ~ ~]
++  constructor
  |=  [tag=@ud fields=(list plan:vm)]
  ^-  plan:vm
  =/  result=plan:vm  [%nat tag]
  =/  todo=(list plan:vm)  fields
  |-  ^-  plan:vm
  ?~  todo  result
  $(result [%app result i.todo], todo t.todo)
++  row
  |=  [value=plan:vm tag=@ud count=@ud]
  ^-  (list plan:vm)
  =/  fields=(list plan:vm)  ~
  |-  ^-  (list plan:vm)
  ?:  =(count 0)  ?>(=([%nat tag] value) fields)
  ?>  ?=(%app -.value)
  $(value fun.value, fields [arg.value fields], count (dec count))
++  natural
  |=  value=plan:vm
  ^-  @ud
  ?>  ?=(%nat -.value)
  value.value
++  encode-list
  |=  items=(list plan:vm)
  ^-  plan:vm
  =/  rest=(list plan:vm)  items
  ?~  rest  [%nat 0]
  (constructor 1 ~[i.rest $(items t.rest)])
++  decode-list
  |=  [value=plan:vm limit=@ud]
  ^-  (list plan:vm)
  =/  items=(list plan:vm)  ~
  |-  ^-  (list plan:vm)
  ?:  =([%nat 0] value)  (flop items)
  ?>  !=(0 limit)
  =/  fields  (row value 1 2)
  $(value (snag 1 fields), items [(snag 0 fields) items], limit (dec limit))
++  scalars
  |=  raw=@t
  ^-  (list @c)
  ?>  (lte (met 3 raw) 32.768)
  =/  left=@ud  8.192
  =/  out=(list @c)  ~
  |-  ^-  (list @c)
  ?:  =(0 raw)  (flop out)
  ?>  !=(0 left)
  ?:  =(9 (end [3 1] raw))
    $(raw (rsh [3 1] raw), left (dec left), out [`@c`9 out])
  =/  size=@ud  (teff raw)
  =/  value=@c  (taft (end [3 size] raw))
  ?>  &((lte value 0x10.ffff) |((lth value 0xd800) (gth value 0xdfff)))
  $(raw (rsh [3 size] raw), left (dec left), out [value out])
++  line
  |=  raw=@t
  (encode-list (turn (scalars raw) |=(n=@c ^-(plan:vm [%nat `@ud`n]))))
++  text
  |=  value=plan:vm
  ^-  @t
  =/  values=(list plan:vm)  (decode-list value 8.192)
  `@t`(rap 3 (turn values |=(v=plan:vm (tuft `@c`(natural v)))))
++  event
  |=  [kind=@t raw=@t]
  ^-  plan:vm
  ?:  =('insert' kind)  (constructor 0 ~[(line raw)])
  ?:  =('complete' kind)
    ::  Syntax hints only. The compiled reducer chooses the common prefix;
    ::  the eventual command still requires native project/tool admission.
    =/  hints=(list @t)
      ~['/help' '/list ' '/read ' '/search ' '/create ' '/replace ' '/patch ' '/move ' '/delete ' '/diff ' '/undo ' '/compile ' '/check ' '/eval ' '/inspect ' '/jobs' '/observe ' '/cancel ' '/pause' '/interrupt' '/reattach ']
    (constructor 10 ~[(encode-list (turn hints line))])
  =/  names=(list @t)
    ~['insert' 'left' 'right' 'home' 'end' 'backspace' 'delete' 'newline' 'older' 'newer' 'complete' 'submit' 'clear' 'interrupt' 'pause']
  =/  index=@ud  0
  |-  ^-  plan:vm
  =/  rest=(list @t)  names
  ?~  rest  !!
  ?:  =(kind i.rest)  [%nat index]
  $(names t.rest, index +(index))
++  bundle-valid
  |=  b=bundle
  ^-  ?
  ?&  =(source.b source-digest)
      ::  Entry roles are part of this retained profile, not just arities.
      =(digest.b 0x4573.9df9.fa6d.3d59.2b82.c7a7.cf61.bdfe.0747.e4dd.4bd1.42d0.33b3.3f42.2497.780d)
      =(digest.b (shax (jam [source.b initial.b valid.b reduce.b contents.b])))
      (levy `(list plan:vm)`~[initial.b valid.b reduce.b contents.b] artifact-valid:scalar)
      (editor-entry-valid:vm initial.b 0)
      (editor-entry-valid:vm valid.b 1)
      (editor-entry-valid:vm reduce.b 2)
      (editor-entry-valid:vm contents.b 1)
  ==
++  install
  |=  [held=state incoming=bundle]
  ^-  (each state @tas)
  ?.  (bundle-valid incoming)  [%| %editor-artifact-invalid]
  ?^  artifact.held
    ?.  =(incoming u.artifact.held)  [%| %editor-artifact-already-installed]
    [%& held]
  =/  started  (run-editor:vm fuel initial.incoming ~)
  ?:  ?=(%| -.started)  [%| p.started]
  =/  checked  (run-editor:vm remaining.p.started valid.incoming ~[output.p.started])
  ?:  ?=(%| -.checked)  [%| p.checked]
  ?.  =([%nat 1] output.p.checked)  [%| %editor-initial-invalid]
  [%& held(artifact `incoming)]
++  step
  |=  [held=state session=@ux kind=@t raw=@t]
  ^-  (each [state=state effect=effect] @tas)
  ?~  artifact.held  [%| error]
  ?:  =(session 0x0)  [%| %editor-session-invalid]
  =/  previous  (~(get by editors.held) session)
  ?:  &(=(~ previous) (gte ~(wyt by editors.held) 64))  [%| %editor-capacity]
  =/  original=(each [remaining=@ud output=plan:vm] @tas)
    ?^  previous  [%& fuel u.previous]
    (run-editor:vm fuel initial.u.artifact.held ~)
  ?:  ?=(%| -.original)  [%| p.original]
  =/  encoded  (mole |.((event kind raw)))
  ?~  encoded  [%| %editor-input-invalid]
  =/  result  (run-editor:vm remaining.p.original reduce.u.artifact.held ~[output.p.original u.encoded])
  ?:  ?=(%| -.result)  [%| p.result]
  =/  decoded
    %-  mole
    |.
    =/  fields  (row output.p.result 0 5)
    =/  accepted=@ud  (natural (snag 3 fields))
    ?>  =(accepted 1)
    =/  next=plan:vm  (snag 0 fields)
    ?>  =(6 (lent (row next 0 6)))
    =/  action=plan:vm  (snag 1 fields)
    =/  effect=effect
      ?:  =([%nat 0] action)  [%none ~]
      ?:  =([%nat 2] action)  [%interrupt ~]
      ?:  =([%nat 3] action)  [%pause ~]
      =/  command  (row action 1 1)
      [%command (text (snag 0 command))]
    [held(editors (~(put by editors.held) session next)) effect]
  ?~  decoded  [%| %editor-change-refused]
  [%& u.decoded]
++  view
  |=  [held=state session=@ux]
  ^-  json
  =/  ready=?  ?=(^ artifact.held)
  =/  found  (~(get by editors.held) session)
  =/  display=(unit [text=@t position=@ud])
    ?~  found  `['' 0]
    %-  mole
    |.
    =/  fields  (row u.found 0 6)
    =/  left  (decode-list (snag 0 fields) 8.192)
    =/  right  (decode-list (snag 1 fields) 8.192)
    [`@t`(rap 3 (turn (weld (flop left) right) |=(p=plan:vm (tuft `@c`(natural p))))) (lent left)]
  (pairs:enjs:format ~[['ready' b+&(ready ?=(^ display))] ['reason' s+?:(ready '' (scot %tas error))] ['text' s+?~(display '' text.u.display)] ['position' (numb:enjs:format ?~(display 0 position.u.display))]])
++  state-valid
  |=  held=state
  ^-  ?
  ?&  (lte ~(wyt by editors.held) 64)
      ?~(artifact.held =(~ editors.held) (bundle-valid u.artifact.held))
      (levy ~(val by editors.held) data-valid:vm)
  ==
--
