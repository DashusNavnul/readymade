::  lib/hosted-app.hoon
::
::  WHERE AN APP'S SOURCE REALLY IS. Since 2026-09-22 every live
::  /app/<name>/hoon on ~dashus-navnul is a brain-shell host shell: three
::  lines naming the dead desk %host-<name> that holds the real agent. A
::  proof that instantiates an agent from source must build THAT file, not
::  the shell -- a shell built alone has no agent inside
::  (%brain-shell-no-agent; on-save gives %host-0).
::
::  real-app reads the app file at the beak it is given. If the file is a
::  host shell, the beam it returns points at the host desk; otherwise the
::  beam is the one asked for. Proofs call
::    (build-file-hard:strandio (real-app:hosted-app beak %name))
::  and are unchanged on a ship whose apps are real.
::
|%
++  hosting-desk
  |=  src=@t
  ^-  (unit @tas)
  =/  marker=tape  "host:brain-shell %"
  =/  t=tape  (trip src)
  =/  i  (find marker t)
  ?~  i  ~
  =/  rest=tape  (slag (add u.i (lent marker)) t)
  =/  name=tape  (scag (fall (find " " rest) (lent rest)) rest)
  ?~  name  ~
  ((soft @tas) (crip name))
::
++  real-app
  |=  [bek=beak name=@tas]
  ^-  beam
  =/  pax=path  /app/[name]/hoon
  =/  src=@t  .^(@t %cx (en-beam bek pax))
  =/  d  (hosting-desk src)
  ?~  d  [bek pax]
  [bek(q u.d) pax]
--
