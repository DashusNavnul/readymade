::  Decode Runtime.NativeCodingCompiler.CheckedArtifactEmission DATA only.
::  A caller must independently bind the exact checked entry, source witnesses,
::  canonical job and evaluation. The old compile_exports seed is not that entry.
::  Neither this result nor its remaining work is a Cantrip check/installation.
::
::  tag0(bindings,remaining-typework)
::  tag1(stage,Pair(reason,Pair(module-bytes,symbol-bytes)))
::  Stages: 0 source/link, 1 types, 2 encoding. Malformed data has NO stage;
::  it must never masquerade as a compiler's retained source/type refusal.
/+  artifacts=native-coding-compiler-artifact
|%
+$  plan  plan:artifacts
+$  output  [bindings=(list binding:artifacts) remaining-typework=@ud]
+$  refusal  [reason=@tas stage=(unit @ud) code=@ud module=@t symbol=@t]
+$  result  (each output refusal)
++  type-work-cap  2.000.000
++  parse
  |=  [raw=plan wanted=(list @t)]
  ^-  result
  ?>  &((gte (lent wanted) 1) (lte (lent wanted) 8) (levy wanted name-valid:artifacts) =((lent wanted) ~(wyt in (silt wanted))))
  =/  envelope  (row:artifacts raw)
  ?>  =(2 (lent fields.envelope))
  ?:  =(1 tag.envelope)
    =/  stage=plan  (snag 0 fields.envelope)
    ?>  ?=(%nat -.stage)
    ?>  (lte value.stage 2)
    =/  detail  (fields:artifacts (snag 1 fields.envelope) 0 2)
    =/  code=plan  (snag 0 detail)
    ?>  ?=(%nat -.code)
    ?>  &((gte value.code 1) (lte value.code 65.535))
    =/  names  (fields:artifacts (snag 1 detail) 0 2)
    ::  Symbols can be numeric type/binder IDs, not only source identifiers.
    ::  Preserve exact bounded bytes (including interior zero); no rendering.
    =/  module=@t  `@t`(atom:artifacts (snag 0 names) 128)
    =/  symbol=@t  `@t`(atom:artifacts (snag 1 names) 128)
    [%| %compiler-checked-emission-refused [~ value.stage] value.code module symbol]
  ?>  =(0 tag.envelope)
  =/  work=plan  (snag 1 fields.envelope)
  ?>  ?=(%nat -.work)
  ?>  (lte value.work type-work-cap)
  ::  Reuse the one canonical binding decoder: exact selected order, 1..8
  ::  unique names <=128B, shared 262144 PLAN nodes, depth512, atoms<=512B,
  ::  law arity1..32, finite numeric pins0..4/10..12 and scalar validation.
  ::  No evaluator, duplicated binding policy or terminal-only names here.
  =/  emission=plan  [%app [%nat 0] (snag 0 fields.envelope)]
  =/  decoded  (decode:artifacts emission wanted)
  ?:  ?=(%| -.decoded)
    [%| %compiler-checked-artifact-wire-refused ~ 0 '' '']
  [%& p.decoded value.work]
++  decode
  |=  [raw=plan wanted=(list @t)]
  ^-  result
  =/  parsed  (mole |.((parse raw wanted)))
  ?~  parsed  [%| %compiler-checked-wire-refused ~ 0 '' '']
  u.parsed
--
