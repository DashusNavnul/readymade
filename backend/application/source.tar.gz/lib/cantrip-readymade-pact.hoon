::  Pure necessary binding checks. A workflow consent never creates a grant.
/-  cp=cantrip-readymade-pact, c=readymade-collab, rp=readymade-pact,
    a=readymade-artifact-collab, r=readymade-artifact-round
/+  pact=readymade-pact, package=readymade-package, law=cantrip-law-window,
    reader=readymade-collab-state, round=readymade-artifact-round,
    artifact=readymade-artifact-collab
|%
++  binding
  |=  [our=@p actor=@p id=@ux state=state:c]
  ^-  (each binding:cp @tas)
  ?.  =(our actor)  [%| %foreign-owner]
  ?.  (digest-valid:package id)  [%| %pact-id-invalid]
  ?.  ?&  (lte ~(wyt by pacts.state) 256)
          (lte ~(wyt by packages.state) 256)
          (lte ~(wyt by requests.state) 4.096)
          (lte (lent receipts.state) 128)
      ==
    [%| %workflow-state-unbounded]
  =/  held=(unit agreement:c)  (~(get by pacts.state) id)
  ?~  held  [%| %pact-missing]
  =/  item=agreement:c  u.held
  =/  value=state:rp  value.item
  =/  terms=terms:rp  terms.value
  ?.  &((valid-terms:pact terms) =(id (digest:pact terms)))
    [%| %pact-binding-invalid]
  ?.  |(=(our left.terms) =(our right.terms))  [%| %not-party]
  ?.  ?&  (bounded-number:pact generation.value)
          (bounded-number:pact left-sequence.value)
          (bounded-number:pact right-sequence.value)
          (lte (met 3 text.item) 16.384)
          !=(0 text.item)
          =(scope.terms (shax text.item))
          =(reference.item (scot %ux package.terms))
      ==
    [%| %pact-binding-invalid]
  =/  source=(unit package:c)  (~(get by packages.state) package.terms)
  ?~  source  [%| %package-missing]
  =/  offered  offer.value.u.source
  ?.  ?&  (valid:package offered)
          =(package.terms digest.offered)
          =(graf-root.terms graf-root.body.offered)
          =(project.terms title.u.source)
          ?|  &(=(sender.body.offered left.terms) =(recipient.body.offered right.terms))
              &(=(sender.body.offered right.terms) =(recipient.body.offered left.terms))
          ==
      ==
    [%| %package-binding-invalid]
  =/  left=?  =(our left.terms)
  [%& [id our ?:(left right.terms left.terms) project.terms package.terms graf-root.terms scope.terms policy.terms generation.value ?:(left left-sequence.value right-sequence.value) ?:(left right-sequence.value left-sequence.value) ?:(left left-consent.value right-consent.value) ?:(left right-consent.value left-consent.value) (active:pact value) %until-revoked]]
++  observe
  ::  Cantrip supplies its current ship-window; historical policy stays distinct.
  |=  [our=@p actor=@p id=@ux state=state:c window=window:law]
  ^-  (each observation:cp @tas)
  =/  found  (binding our actor id state)
  ?:  ?=(%| -.found)  [%| p.found]
  [%& [%cantrip-readymade-pact-observation-v1 p.found (shax (jam window)) %.n %coordinated-artifact-round-required]]
++  judge
  ::  No shared executor is connected. Even artifact flags cannot admit a move.
  |=  [our=@p actor=@p id=@ux purpose=purpose:cp artifact=@ux state=state:c window=window:law]
  ^-  (each judgment:cp @tas)
  ?.  (digest-valid:package artifact)  [%| %artifact-invalid]
  =/  observed  (observe our actor id state window)
  ?:  ?=(%| -.observed)  [%| p.observed]
  =/  act=act:law  ?:(=(purpose %land) %implement %promote)
  =/  current=?  &((~(has in admissible.window) act) !(~(has in blocked.window) act))
  =/  item=agreement:c  (~(got by pacts.state) id)
  =/  bilateral=?  (allowed:pact value.item purpose artifact %.y)
  [%& [%cantrip-readymade-pact-judgment-v1 p.observed purpose artifact current (~(has in never-auto.window) act) bilateral %.n %coordinated-artifact-round-required]]
++  observe-artifact
  ::  The caller supplies the current native law window and canonical snapshot.
  ::  Ack evidence describes independent past observations, not current grants.
  |=  $:  our=@p
          actor=@p
          id=@ux
          generation=@ud
          purpose=purpose:cp
          selected=@ux
          state=state:c
          artifacts=state:a
          window=window:law
      ==
  ^-  (each artifact-observation:cp @tas)
  =/  observed  (observe our actor id state window)
  ?:  ?=(%| -.observed)  [%| p.observed]
  ?.  =(generation generation.binding.p.observed)  [%| %generation-mismatch]
  ?.  active.binding.p.observed  [%| %pact-inactive]
  ?.  (digest-valid:package selected)  [%| %proposal-id-invalid]
  =/  checked  (checked:reader our [state `artifacts])
  ?:  ?=(%| -.checked)  [%| p.checked]
  =/  held=(unit state:r)  (~(get by rounds.artifacts) [id generation purpose])
  ?~  held  [%| %artifact-round-missing]
  =/  agreement=agreement:c  (~(got by pacts.state) id)
  =/  current=state:rp  value.agreement
  ?.  (valid:round u.held current)  [%| %artifact-round-invalid]
  ?~  proposal.u.held  [%| %artifact-proposal-missing]
  =/  candidate=proposal:r  u.proposal.u.held
  ?.  =(selected (digest:round candidate))  [%| %proposal-mismatch]
  =/  source=package:c  (~(got by packages.state) package.terms.current)
  ?.  (proposal-bound:artifact artifacts current value.source purpose candidate)
    [%| %artifact-binding-invalid]
  =/  evidence=evidence:a  (~(got by evidence.artifacts) build-proof.candidate)
  =/  left=?  =(our left.terms.current)
  =/  act=act:law  ?:(=(purpose %land) %implement %promote)
  =/  admissible=?  &((~(has in admissible.window) act) !(~(has in blocked.window) act))
  [%& [%cantrip-readymade-artifact-observation-v1 p.observed selected candidate builder.evidence provenance.evidence ?:(left left-ack.u.held right-ack.u.held) ?:(left right-ack.u.held left-ack.u.held) ?:(left left-close.u.held right-close.u.held) ?:(left right-close.u.held left-close.u.held) (ready:round u.held current selected) admissible (~(has in never-auto.window) act) %.n %.n %shared-executor-unavailable]]
--
