::  Viki's local review owner. Commands name canonical candidates; provider
::  events only trigger reads. Saved review evidence never grants a write.
/-  nc=native-coding, np=native-coding-provider, pa=native-coding-provider-attestation
/+  local=native-coding-local-review, store=native-coding-local-review-state,
    gate=qpc-session-gate, observer=qpc-observer, review=native-coding-review,
    accept=native-coding-accept, project=native-coding-project,
    scoped=native-coding-session-project, files=native-coding-files,
    guard=viki-scry-guard, inference=native-coding-inference,
    evidence=qpc-native-evidence, outbound=native-coding-provider-request,
    provider=native-coding-provider, att=native-coding-provider-attestation,
    origin=native-coding-local-review-artifact, context=native-coding-review-context
|%
+$  command
  $%  [%native-local-review-scope-v1 scope=scope:local]
      [%native-local-review-start-v1 candidate=@ux]
      [%native-local-review-start-bound-v1 candidate=@ux binding=@ux]
      [%native-local-review-observe-v1 candidate=@ux]
      [%native-local-review-retry-v1 candidate=@ux failed=@ux]
  ==
++  begin-bound
  ::  Check the confirmed complete scope in the same event as begin/dispatch.
  |=  [our=@p at=@da held=state:store r=request:local binding=@ux]
  ^-  (each change:store @tas)
  ?.  =(binding (digest:local scope.r))  [%| %local-review-scope-changed]
  (begin:store our at held r)
++  freeze
  |=  [inner=agent:gall b=bowl:gall held=state:store id=@ux]
  ^-  (each request:local @tas)
  ?.  &(=(our.b src.b) (agent-live:guard our.b now.b %cantrip))
    [%| %local-review-agents-unavailable]
  =/  raw=*
    .^(* %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/candidate/(scot %ux id)/noun)
  =/  parsed  ((soft ,(unit record:accept)) raw)
  ?.  &(?=(^ parsed) ?=(^ u.parsed))  [%| %local-review-candidate-missing]
  =/  row=record:accept  u.u.parsed
  =/  c=candidate:nc  candidate.row
  ?.  ?&  =(id id.c)  =(%review stage.row)  ?=(^ report.row)
          ?=(~ decision.row)  ?=(~ landed.row)
      ==  [%| %local-review-candidate-not-ready]
  =/  input  (input:observer inner b session.context.c)
  ?~  input  [%| %local-review-session-missing]
  =/  e  entry.u.input
  ?.  ?&  =(our.b owner.session.e)  =(our.b worker.e)
          =(working.session.e source.context.c)  ?=(~ pending.e)
          ?=(~ calls.e)  =(configuration.e configuration.context.c)
      ==  [%| %local-review-session-changed]
  =/  ag  ~(. inner b)
  =/  raw  (payload:gate (on-peek:ag /x/native-coding/projects))
  ?~  raw  [%| %local-review-projects-unavailable]
  =/  all  ((soft ,(map @t project:nc)) u.raw)
  ?~  all  [%| %local-review-projects-invalid]
  =/  current  (resolve:scoped our.b now.b u.all session.context.c project.context.c)
  ?.  &(?=(%& -.current) =(p.current project.row))  [%| %local-review-project-changed]
  =/  objective  (objective:review e)
  ?:  ?=(%| -.objective)  [%| p.objective]
  =/  scope  (~(get by scopes.held) project.context.c)
  ?~  scope  [%| %local-review-scope-missing]
  =/  unavailable=(unit @tas)
    ?:  ?=(^ (cli-backend:provider selection.u.scope))
      =/  paired  (current-cli:att our.b now.b provider-key.u.scope selection.u.scope)
      ?:(?=(%| -.paired) `p.paired ~)
    ?.  (agent-live:guard our.b now.b %codex-inference)  `%local-review-provider-unavailable
    =/  status=*
      .^(* %gx /(scot %p our.b)/codex-inference/(scot %da now.b)/native-coding/status/noun)
    ?.  ?=([%native-coding-inference-status-v1 %viki @ @ @ @] status)
      `%local-review-controller-mismatch
    =/  selected=*
      .^(* %gx /(scot %p our.b)/codex-inference/(scot %da now.b)/native-coding/selection/(scot %tas provider-key.u.scope)/noun)
    ?.(=(`selection.u.scope selected) `%local-review-selection-changed ~)
  ?^  unavailable  [%| u.unavailable]
  =/  trees  (current:project our.b now.b project.row)
  ?:  ?=(%| -.trees)  [%| p.trees]
  ?.  &(=(basis.c working.p.trees) =(accepted.c revision.accepted.p.trees))
    [%| %local-review-source-changed]
  =/  todo  edits.c
  =|  before=(map path replacement:nc)
  =/  old=(each (map path replacement:nc) @tas)
    |-  ^-  (each (map path replacement:nc) @tas)
    ?~  todo  [%& before]
    ?~  before.change.i.todo  $(todo t.todo)
    =/  file  (file:files project.row basis.c path.change.i.todo)
    ?:  ?=(%| -.file)  [%| p.file]
    $(todo t.todo, before (~(put by before) path.change.i.todo p.file))
  ?:  ?=(%| -.old)  [%| p.old]
  =/  provenance  (capture:origin our.b now.b project.row c e)
  ?:  ?=(%| -.provenance)  [%| p.provenance]
  =/  read-context  (capture:context project.row c records.e)
  ?:  ?=(%| -.read-context)  [%| p.read-context]
  =/  checks=(list [name=@tas expression=@t])
    (zing (turn targets.u.report.row |=(t=target-result:accept checks.target.t)))
  =/  protected  (protect:context project.row c checks)
  ?:  ?=(%| -.protected)  [%| p.protected]
  =/  session=@ux  (digest:local [%local-review-session-v1 id u.scope])
  =/  r=request:local
    [%native-coding-local-review-request-v8 u.scope [project.row c u.report.row p.objective [%native-review-context-v2 p.old p.read-context p.protected p.provenance]] session %challenge ~]
  =/  req  (inference:local our.b r)
  ?:  ?=(%| -.req)  [%| p.req]
  [%& r]
++  read-cli
  |=  [b=bowl:gall c=campaign:store]
  ^-  reading:store
  =/  req  (inference-at:local our.b (expected:store c) attempt.c)
  ?:  ?=(%| -.req)  [%unknown p.req]
  =/  kept  (lookup-cli:evidence our.b now.b id.p.req session.p.req provider-key.scope.request.c)
  ?:  ?=(%| -.kept)  [%unknown p.kept]
  =/  j  p.kept
  ?.  =(p.req request.j)  [%unknown %local-review-cli-request-mismatch]
  ?:  ?=(?(%queued %claimed) phase.j)  [%pending ~]
  ?:  ?=(?(%failed %cancelled) phase.j)
    ::  Actual canonical terminal failures clear pending without enabling retry.
    ::  Zero is explicitly non-HTTP; the digest commits the retained native job.
    =/  reason=@tas
      ?:(=(%cancelled phase.j) %cli-cancelled (fall reason.j %cli-failed))
    [%failed [%native-coding-provider-error-v1 id.p.req provider.selection.p.req 0 reason (value-digest:att j)]]
  ?.  =(%completed phase.j)  [%unknown phase.j]
  =/  made  (attest-cli:att our.b id.p.req j)
  ?:  ?=(%| -.made)  [%unknown p.made]
  =/  checked  (confirm-cli:att our.b now.b p.req provider-key.scope.request.c p.made)
  ?^  checked  [%unknown u.checked]
  [%receipt p.made]
++  read-receipt
  |=  [b=bowl:gall c=campaign:store]
  ^-  reading:store
  ?~  pending.c  [%unknown %local-review-not-pending]
  ?:  ?=(^ (cli-backend:provider selection.scope.request.c))  (read-cli b c)
  ?.  (agent-live:guard our.b now.b %codex-inference)
    [%unknown %local-review-provider-unavailable]
  =/  id=@ux  u.pending.c
  =/  raw=*
    .^(* %gx /(scot %p our.b)/codex-inference/(scot %da now.b)/native-coding/jobs/noun)
  =/  rows  ((soft ,(list index-row:evidence)) raw)
  ?~  rows  [%unknown %local-review-provider-index-invalid]
  =/  found  (skim u.rows |=(r=index-row:evidence =(id id.r)))
  ?~  found  [%unknown %local-review-provider-not-retained]
  ?.  &(?=(~ t.found) =(session.request.c session.i.found) =(provider-key.scope.request.c selection.i.found))
    [%unknown %local-review-provider-binding-mismatch]
  ?:  =(%pending outcome.i.found)  [%pending ~]
  ?:  =(%failed outcome.i.found)
    =/  raw=*
      .^(* %gx /(scot %p our.b)/codex-inference/(scot %da now.b)/native-coding/evidence/(scot %ux id)/noun)
    =/  saved  ((soft ,[request=request:np body=@t outcome=outcome:inference evidence=(unit evidence:inference)]) raw)
    ?~  saved  [%unknown %local-review-failure-unavailable]
    ?.  ?=(%failed -.outcome.u.saved)  [%unknown %local-review-failure-unconfirmed]
    =/  req  (inference-at:local our.b (expected:store c) attempt.c)
    ?:  ?=(%| -.req)  [%unknown p.req]
    =/  encoded  (encode:outbound p.req)
    ?:  ?=(%| -.encoded)  [%unknown p.encoded]
    ?.  &(=(p.req request.u.saved) =(p.encoded body.u.saved))
      [%unknown %local-review-failure-binding-mismatch]
    [%failed error.outcome.u.saved]
  ?.  =(%result outcome.i.found)  [%unknown outcome.i.found]
  ::  This route returns an each even when a job is absent. The provider
  ::  reparses its retained raw response before producing the attestation.
  =/  raw=*
    .^(* %gx /(scot %p our.b)/codex-inference/(scot %da now.b)/native-coding/inspection-receipt/(scot %ux id)/noun)
  =/  receipt  ((soft ,(each attestation:pa @tas)) raw)
  ?~  receipt  [%unknown %local-review-provider-receipt-invalid]
  ?:  ?=(%| -.u.receipt)  [%unknown p.u.receipt]
  [%receipt p.u.receipt]
++  cards
  |=  [our=@p before=state:store next=change:store]
  ^-  (list card:agent:gall)
  =/  out=(list card:agent:gall)
    ?~  dispatch.next  ~
    =/  d  u.dispatch.next
    =/  target=@tas  (transport:provider selection.request.d)
    ~[[%pass /native-local-review/infer/(scot %ux id.request.d) %agent [our target] %poke %noun !>([%native-coding-infer key.d request.d])]]
  ::  Retain only changed campaigns, including unknown outcomes. Graf is
  ::  evidence storage; its acknowledgement is not a decision or write grant.
  =/  retained=(list card:agent:gall)
    %+  roll  ~(tap by campaigns.state.next)
    |=  [[id=@ux c=campaign:store] acc=(list card:agent:gall)]
    ?:  =(`c (~(get by campaigns.before) id))  acc
    [[%pass /native-local-review/retain/(scot %ux id) %agent [our %graf] %poke %graf-action !>([%attest [%native-coding-local-review-v2 id c]])] acc]
  =/  decisions=(list card:agent:gall)
    %+  murn  ~(tap by campaigns.state.next)
    |=  [id=@ux c=campaign:store]
    ^-  (unit card:agent:gall)
    ?~  outcome.c  ~
    =/  prior  (~(get by campaigns.before) id)
    ?:  ?~(prior %.n ?=(^ outcome.u.prior))  ~
    `[%pass /native-local-review/decision/(scot %ux id) %agent [our %viki] %poke %noun !>([%native-coding-review-action-v1 [%observe id]])]
  (weld retained (weld out decisions))
++  agent
  |=  inner=agent:gall
  =|  held=state:store
  ^-  agent:gall
  |_  =bowl:gall
  +*  this  .
      ag  ~(. inner bowl)
  ++  on-init
    =^  effects  inner  on-init:ag
    [effects this]
  ++  on-save  !>([%native-local-review-owner-v3 held on-save:ag])
  ++  on-load
    |=  old=vase
    =/  saved=[held=state:store inner=vase]
      ::  V3 admits the wider V6 request contract. Existing V2 campaign DATA
      ::  stays exact; the envelope marks the saved-type migration explicitly.
      ?:  ?=([?(%native-local-review-owner-v2 %native-local-review-owner-v3) *] q.old)
        =/  prior  !<([?(%native-local-review-owner-v2 %native-local-review-owner-v3) held=state:store inner=vase] old)
        +.prior
      ?.  ?=([%native-local-review-owner-v1 *] q.old)  [*state:store old]
      =/  prior  !<([%native-local-review-owner-v1 held=state-v1:store inner=vase] old)
      [(migrate:store held.prior) inner.prior]
    ?>  (valid:store our.bowl held.saved)
    =.  held  held.saved
    =^  effects  inner  (on-load:ag inner.saved)
    ::  Reload never redispatches a model request.
    [effects this]
  ++  on-poke
    |=  [=mark =vase]
    =/  observe
      |=  id=@ux
      ^-  (quip card:agent:gall agent:gall)
      =/  found  (~(get by campaigns.held) id)
      ?~  found  [~ this]
      ?~  pending.u.found  [~ this]
      =/  next  (receive:store our.bowl held id u.pending.u.found (read-receipt bowl u.found))
      [(cards our.bowl held next) this(held state.next)]
    =/  cmd  ?.(=(%noun mark) ~ ((soft command) q.vase))
    ?^  cmd
      ?>  =(our.bowl src.bowl)
      ?:  ?=(%native-local-review-scope-v1 -.u.cmd)
        =/  next  (configure:store our.bowl held scope.u.cmd)
        ?:  ?=(%| -.next)  ~|(p.next !!)
        [~ this(held p.next)]
      ?:  ?=(%native-local-review-retry-v1 -.u.cmd)
        =/  id=@ux  candidate.u.cmd
        =/  found  (~(get by campaigns.held) id)
        ?~  found  ~|(%local-review-candidate-missing !!)
        =/  frozen  (freeze inner bowl held id)
        ?:  ?=(%| -.frozen)  ~|(p.frozen !!)
        ?>  =(p.frozen request.u.found)
        =/  next  (retry:store our.bowl held id failed.u.cmd)
        ?:  ?=(%| -.next)  ~|(p.next !!)
        [(cards our.bowl held p.next) this(held state.p.next)]
      =/  id=@ux
        ?:  ?=(%native-local-review-start-bound-v1 -.u.cmd)  candidate.u.cmd
        candidate.u.cmd
      ?:  ?=(%native-local-review-observe-v1 -.u.cmd)  (observe id)
      ::  A repeated start is a no-op even if a request is unknown.
      ?:  (~(has by campaigns.held) id)  [~ this]
      =/  frozen  (freeze inner bowl held id)
      ?:  ?=(%| -.frozen)  ~|(p.frozen !!)
      =/  next
        ?:  ?=(%native-local-review-start-bound-v1 -.u.cmd)
          (begin-bound our.bowl now.bowl held p.frozen binding.u.cmd)
        (begin:store our.bowl now.bowl held p.frozen)
      ?:  ?=(%| -.next)  ~|(p.next !!)
      [(cards our.bowl held p.next) this(held state.p.next)]
    =/  event  ?.(=(%noun mark) ~ ((soft event:inference) q.vase))
    =/  found=(unit @ux)
      ?~  event  ~
      (find-job:store held id.u.event session.u.event)
    ?^  found
      ?>  =(our.bowl src.bowl)
      (observe u.found)
    =^  effects  inner  (on-poke:ag mark vase)
    [effects this]
  ++  on-peek
    |=  =path
    ?.  ?=([%x %native-coding %local-review *] path)  (on-peek:ag path)
    ?.  =(our.bowl src.bowl)  ~
    ?:  =(/x/native-coding/local-review/scopes path)  ``noun+!>(scopes.held)
    ?:  =(/x/native-coding/local-review/campaigns path)  ``noun+!>(campaigns.held)
    ?:  ?=([%x %native-coding %local-review %dead @ ~] path)
      =/  member  (slaw %ux i.t.t.t.t.path)
      ?~  member  [~ ~]
      ::  Only a candidate still at review holds the desk.
      =/  at-review
        |=  id=@ux
        ^-  ?
        =/  raw=*  .^(* %gx /(scot %p our.bowl)/cantrip/(scot %da now.bowl)/native-coding/candidate/(scot %ux id)/noun)
        =/  parsed  ((soft ,(unit record:accept)) raw)
        &(?=([~ ~ *] parsed) =(%review stage.u.u.parsed))
      ``noun+!>((skim (dead:store held u.member) |=(row=[candidate=@ux *] (at-review candidate.row))))
    ?.  ?=([%x %native-coding %local-review %candidate @ ~] path)  [~ ~]
    =/  id  (slaw %ux i.t.t.t.t.path)
    ?~  id  [~ ~]
    ``noun+!>((~(get by campaigns.held) u.id))
  ++  on-watch
    |=  =path
    =^  effects  inner  (on-watch:ag path)
    [effects this]
  ++  on-leave
    |=  =path
    =^  effects  inner  (on-leave:ag path)
    [effects this]
  ++  on-agent
    |=  [=wire =sign:agent:gall]
    ?:  ?=([%native-local-review *] wire)  [~ this]
    =^  effects  inner  (on-agent:ag wire sign)
    [effects this]
  ++  on-arvo
    |=  [=wire =sign-arvo]
    =^  effects  inner  (on-arvo:ag wire sign-arvo)
    [effects this]
  ++  on-fail
    |=  [=term =tang]
    =^  effects  inner  (on-fail:ag term tang)
    [effects this]
  --
--
