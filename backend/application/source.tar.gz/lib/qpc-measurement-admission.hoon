::  Pure joins over owner-held evidence, never an authority or a window.
::  A native owner must persist registration BEFORE dispatch and supply all
::  stores/positions itself. Hashes and a completed journal cannot prove this.
/-  nc=native-coding, np=native-coding-provider
/+  sensing=qpc-task-sensing, obs=qpc-observation, q=qpc-native-outcome,
    outcomes=qpc-outcome-store, settlement=qpc-work-settlement,
    decision=qpc-decision, sessions=native-coding-session, pool=qpc-native-pool,
    measurement=qpc-measurement-contract
|%
+$  position  [instrument=@ux stream=@ux segment=@ux step=@ud]
+$  prospect
  $:  session=session:nc  configuration=@ux  selection=selection:np
      worker=@p  phase=phase:sessions  resume=phase:sessions  turn=@ud
      sequence=@ud  head=(unit @ux)
  ==
+$  enrollment
  $:  %qpc-measurement-enrollment-v1  id=@ux  owner=@p  at=@da
      position=position  contract=contract:sensing  task=task:sensing
      work=work:obs  project=@ux  before=prospect
  ==
+$  measurement-row  measurement-row:measurement
+$  sample
  $:  %qpc-measurement-sample-v1  id=@ux  enrollment=enrollment
      frame=frame:obs  outcome=linked:q  settlement=receipt:settlement
      through=(unit @ux)  row=measurement-row
  ==
+$  state  [enrollments=(map @ux enrollment) samples=(map @ux sample)]
++  digest  digest:measurement
::  Every managed turn enrolls once and is never evicted, so these bound a
::  growing history across all plans, not one campaign.
++  enrollment-limit  4.096
++  sample-limit  4.096
++  snapshot
  |=  e=entry:sessions
  ^-  prospect
  [session.e configuration.e selection.e worker.e phase.e resume.e turn.e sequence.e head.e]
++  restore
  ::  Reconstruct only fields used by sensing; no invented history is read.
  |=  [p=prospect records=(list record:sessions)]
  ^-  entry:sessions
  =/  e=entry:sessions  *entry:sessions
  e(session session.p, configuration configuration.p, selection selection.p, worker worker.p, phase phase.p, resume resume.p, turn turn.p, sequence sequence.p, head head.p, records records)
++  position-valid
  |=  p=position
  &((levy `(list @ux)`~[instrument.p stream.p segment.p] identifier:sensing) (lte (met 0 step.p) 64))
++  row-valid  row-valid:measurement
++  for-epoch
  ::  Projection only. The future owner must first establish a canonical
  ::  measurement epoch and its reference/live membership. A collection
  ::  stream is never a measurement epoch, and this gate creates neither.
  |=  [s=sample epoch=@ux]
  ^-  (each observation:decision @tas)
  ?.  &(=(id.s (digest s(id 0x0))) (row-valid row.s) (identifier:sensing epoch))
    [%| %qpc-measurement-epoch-projection-invalid]
  =/  r=measurement-row  row.s
  [%& [id.r step.r work.r resulting-source.r epoch segment.r law.r confidence.r outcomes.r]]
++  enrollment-valid
  |=  r=enrollment
  ?&  =(id.r (digest r(id 0x0)))  (position-valid position.r)
      =(instrument.position.r instrument.contract.r)
      =(owner.r owner.session.before.r)  =(owner.r owner.source.work.r)
      =(session.work.r id.session.before.r)
      =(request.work.r (request-id:sessions session.work.r turn.before.r))
      (lte sequence.before.r journal-limit:sessions)
      (lte (met 3 (jam r)) 65.536)
  ==
++  mentioned
  |=  [request=@ux r=record:sessions]
  ?-  -.body.r
    %context  =(request request.value.body.r)
    %model  =(request id.result.body.r)
    *  %.n
  ==
++  register
  ::  The caller must be the native owner with its actual pre-dispatch entry.
  ::  There is intentionally no command accepting an enrollment noun.
  |=  $:  s=state  our=@p  at=@da  position=position
          c=contract:sensing  t=task:sensing  m=manifest:obs  w=work:obs
          p=project:nc  cs=cases:q  e=entry:sessions
      ==
  ^-  (each state @tas)
  ?.  ?&  =(our owner.m)  (position-valid position)
          =(instrument.position instrument.c)  (chain:pool e)
          (validate:sensing c t m w p cs e)
          !(lien records.e |=(r=record:sessions (mentioned request.w r)))
          =(turn.e (lent (skim records.e |=(r=record:sessions =([%status %inference %dispatch] body.r)))))
          (levy records.e |=(r=record:sessions (lte at.r at)))
      ==  [%| %qpc-measurement-enrollment-invalid]
  =/  r=enrollment
    [%qpc-measurement-enrollment-v1 0x0 our at position c t w (digest p) (snapshot e)]
  =.  r  r(id (digest r))
  ?.  (enrollment-valid r)  [%| %qpc-measurement-enrollment-invalid]
  =/  old  (~(get by enrollments.s) id.r)
  ?^  old  ?:(=(r u.old) [%& s] [%| %qpc-measurement-enrollment-conflict])
  ?:  (lien ~(val by enrollments.s) |=(v=enrollment |(=(work.r work.v) &(=(session.work.r session.work.v) =(request.work.r request.work.v)))))
    [%| %qpc-measurement-request-reused]
  ?.  (lth ~(wyt by enrollments.s) enrollment-limit)  [%| %qpc-measurement-capacity]
  [%& s(enrollments (~(put by enrollments.s) id.r r))]
++  prefix
  ::  Prefix continuity is structural evidence, not proof that a caller
  ::  really registered at that time. The owner's retained map supplies that.
  |=  [r=enrollment e=entry:sessions]
  ^-  (each entry:sessions @tas)
  ?.  &((chain:pool e) =(session.work.r id.session.e) (lte sequence.before.r sequence.e))
    [%| %qpc-measurement-journal-invalid]
  =/  pre=entry:sessions  (restore before.r (scag sequence.before.r records.e))
  ?.  (chain:pool pre)  [%| %qpc-measurement-prefix-changed]
  [%& pre]
++  chronology
  |=  [r=enrollment m=manifest:obs f=frame:obs v=linked:q e=entry:sessions]
  ^-  ?
  =/  contexts=(list record:sessions)
    (skim records.e |=(x=record:sessions &(?=(%context -.body.x) (mentioned request.work.r x))))
  ?.  =(1 (lent contexts))  %.n
  =/  c=record:sessions  (snag 0 contexts)
  ?>  ?=(%context -.body.c)
  =/  models=(list record:sessions)
    (skim records.e |=(x=record:sessions &(?=(%model -.body.x) (mentioned request.work.r x))))
  ?.  =(1 (lent models))  %.n
  =/  model=record:sessions  (snag 0 models)
  ?>  ?=(%model -.body.model)
  =/  between=(list record:sessions)
    (scag (sub sequence.c (min sequence.c sequence.before.r)) (slag sequence.before.r records.e))
  ?:  =(0 (lent between))  %.n
  =/  dispatched=record:sessions  (rear between)
  ?.  ?&  =(id.c context.f)
          (gte sequence.c sequence.before.r)  (lth sequence.c sequence.model)
          =(sequence.model journal.f)  =(id.model model-record.v)
          =(reply.f (digest:obs result.body.model))  =(at.model at.f)
          (lte at.r at.c)  (lte at.c at.model)
          =(owner.r owner.value.body.c)  =(owner.r worker.value.body.c)
          =(session.work.r session.value.body.c)  =(source.work.r source.value.body.c)
          =(provider.selection.m provider.value.body.c)  =(model.selection.m model.value.body.c)
          =([%status %inference %dispatch] body.dispatched)
          (levy between |=(x=record:sessions &((lte at.r at.x) (lte at.x at.c))))
          (levy (scag (dec (lent between)) between) |=(x=record:sessions =([%status %ready %operator-resume] body.x)))
      ==  %.n
  =/  predicted  (call-predictions:obs m work.f calls.result.body.model text.result.body.model)
  ?.  =(predicted result.f)  %.n
  =/  tool-records=(list record:sessions)
    (skim records.e |=(x=record:sessions &(=(id.x tool-record.v) ?=(%tool -.body.x))))
  ?.  =(1 (lent tool-records))  %.n
  =/  tool=record:sessions  (snag 0 tool-records)
  ?>  ?=(%tool -.body.tool)
  =/  result=tool-result:nc  result.body.tool
  ?.  ?=(%candidate -.output.result)  %.n
  =/  expected=context:nc
    [project.m configuration.work.r session.work.r request.work.r owner.r source.work.r]
  ?&  (gth sequence.tool sequence.model)  (gte at.tool at.model)
      =(call.v call-id.result)  =(expected context.result)
      =(candidate.result.v id.value.output.result)
      =(expected context.value.output.result)
  ==
++  inspect
  ::  Legacy/gap inspection remains possible, without changing admissibility.
  |=  [observed=state:obs frame=@ux]
  (~(get by frames.observed) frame)
++  admit
  ::  Only the native owner may supply these stores, project snapshot,
  ::  completed journal and managed-session set. GUI input is IDs only.
  |=  $:  s=state  our=@p  enrollment-id=@ux  frame-id=@ux
          observed=state:obs  checked=state:outcomes  settled=state:settlement
          p=project:nc  e=entry:sessions  required=(set @ux)
      ==
  ^-  (each [state sample] @tas)
  =/  found  (~(get by enrollments.s) enrollment-id)
  ?~  found  [%| %qpc-measurement-enrollment-missing]
  =/  r=enrollment  u.found
  ?.  &(=(enrollment-id id.r) =(our owner.r) (enrollment-valid r))
    [%| %qpc-measurement-enrollment-invalid]
  ?:  (~(has in required) session.work.r)  [%| %qpc-measurement-selection-required]
  ?.  ?&  (valid:obs our observed)  (valid:outcomes observed checked)
          (valid:settlement observed checked settled)
      ==  [%| %qpc-measurement-stores-invalid]
  =/  got  (inspect observed frame-id)
  ?~  got  [%| %qpc-measurement-frame-missing]
  =/  f=frame:obs  u.got
  ?.  &(?=(%& -.result.f) =(work.r work.f))
    [%| %qpc-measurement-frame-ineligible]
  ?.  =(1 (lent p.result.f))  [%| %qpc-measurement-selection-required]
  =/  m=manifest:obs  (~(got by manifests.observed) manifest.work.f)
  =/  cases  (~(get by cases.checked) case-set.work.f)
  ?~  cases  [%| %qpc-measurement-cases-missing]
  =/  pre  (prefix r e)
  ?:  ?=(%| -.pre)  [%| p.pre]
  ?.  &(=(project.r (digest p)) (validate:sensing contract.r task.r m work.r p u.cases p.pre))
    [%| %qpc-measurement-sensing-mismatch]
  =/  row  (snag 0 p.result.f)
  =/  linked  (~(get by outcomes.checked) [frame-id call.row])
  ?~  linked  [%| %qpc-measurement-outcome-missing]
  =/  v=linked:q  u.linked
  =/  terminal  (~(get by settled) frame-id)
  ?~  terminal  [%| %qpc-measurement-settlement-missing]
  =/  terminal=receipt:settlement  u.terminal
  ?.  ?&  (linked-valid:outcomes observed checked v)
          (linked-valid:settlement observed checked terminal)
          (chronology r m f v e)
      ==  [%| %qpc-measurement-provenance-mismatch]
  =/  measured=measurement-row
    :*  id.f  step.position.r  (digest:obs work.f)  (digest resulting.terminal)
        segment.position.r  law.contract.r  confidence.v
        (turn outcomes.result.v |=(x=assessment:q [verdict.x ?:(=(%unknown verdict.x) 0x0 diagnostic.x)]))
    ==
  ?.  (row-valid measured)
    [%| %qpc-measurement-observation-invalid]
  =/  value=sample
    [%qpc-measurement-sample-v1 0x0 r f v terminal `tool-record.v measured]
  =.  value  value(id (digest value))
  =/  old  (~(get by samples.s) frame-id)
  ?^  old  ?:(=(value u.old) [%& [s value]] [%| %qpc-measurement-already-admitted])
  ?:  %+  lien  ~(val by samples.s)
      |=  x=sample
      ?|  =(id.r id.enrollment.x)  =(work.measured work.row.x)
          &(=(instrument.position.r instrument.position.enrollment.x) =(stream.position.r stream.position.enrollment.x) =(step.measured step.row.x))
      ==
    [%| %qpc-measurement-position-reused]
  ?.  (lth ~(wyt by samples.s) sample-limit)  [%| %qpc-measurement-capacity]
  [%& [s(samples (~(put by samples.s) frame-id value)) value]]
--
