::  Compact frozen collection, not eligibility, a score, or an execution grant.
::  Exact source/candidate bytes remain in the native journals committed here.
/-  nc=native-coding, np=native-coding-provider, frozen=native-coding-context,
    ci=cli-inference
/+  sessions=native-coding-session, evidence=qpc-native-evidence,
    provider=native-coding-provider, collection=qpc-native-collection,
    codec=native-coding-tool-codec, tools=cantrip-native-coding-contract,
    files=native-coding-files, guard=viki-scry-guard,
    patch-report=qpc-patch-report, cli=cli-inference
|%
+$  input  [entry=entry:sessions key=@tas grant=@ux]
+$  row
  $:  call=@t  tool=@ux  journal=@ux  result=@ux
      origin=?(%cantrip %journal-refusal)
      candidate=(unit @ux)  effect=(unit @ux)
  ==
+$  pool
  $:  %qpc-native-pool-v1  id=@ux  owner=@p  session=@ux
      project=@t  configuration=@ux  source=revision:nc  grant=@ux
      provider-key=@tas  request=@ux  model-record=@ux  context-record=@ux
      context=binding:frozen  reply=@ux  through=@ux  rows=(list row)
  ==
++  digest  |=(value=* ^-(@ux (shax (jam [%qpc-pool-commitment-v1 value]))))
++  valid
  |=  p=pool
  ^-  ?
  ?&  =(id.p (digest p(id 0x0)))
      !=(0 session.p)  !=(0 configuration.p)  !=(0 grant.p)
      &(=(owner.p owner.context.p) =(session.p session.context.p))
      &(=(source.p source.context.p) =(request.p request.context.p))
      (gte (lent rows.p) 2)  (lte (lent rows.p) 4)
      =((lent rows.p) ~(wyt in (silt (turn rows.p |=(r=row call.r)))))
      (levy rows.p |=(r=row &(!=(0 tool.r) !=(0 journal.r) !=(0 result.r) =(?=(^ candidate.r) ?=(^ effect.r)) ?:(=(%journal-refusal origin.r) ?=(~ candidate.r) %.y))))
      (lte (met 3 (jam p)) 8.192)
  ==
++  chain
  |=  e=entry:sessions
  ^-  ?
  ?.  (lte (lent records.e) journal-limit:sessions)  %.n
  =/  todo=(list record:sessions)  records.e
  =/  sequence=@ud  0
  =/  previous=(unit @ux)  ~
  |-  ^-  ?
  ?~  todo  &(=(sequence sequence.e) =(previous head.e))
  =/  r=record:sessions  i.todo
  ?.  &(=(sequence sequence.r) =(previous previous.r) =(id.r (event-id:sessions id.session.e sequence previous at.r body.r)))  %.n
  $(todo t.todo, sequence +(sequence), previous `id.r)
++  extract
  |=  e=entry:sessions
  ^-  (each [model=record:sessions context=record:sessions] @tas)
  ?.  &((chain e) =(%paused phase.e) ?=(~ pending.e) ?=(~ calls.e))
    [%| %qpc-pool-session-not-quiescent]
  ?~  records.e  [%| %qpc-pool-journal-empty]
  =/  last=record:sessions  (rear records.e)
  ?.  =([%status %paused %qpc-pool-collected] body.last)
    [%| %qpc-pool-not-collected]
  =/  models=(list record:sessions)
    (skim `(list record:sessions)`records.e |=(r=record:sessions ?=(%model -.body.r)))
  ?~  models  [%| %qpc-pool-model-missing]
  =/  model=record:sessions  (rear models)
  ?>  ?=(%model -.body.model)
  =/  contexts=(list record:sessions)
    %+  skim  `(list record:sessions)`records.e
    |=  r=record:sessions
    ?.  ?=(%context -.body.r)  %.n
    &(=(id.result.body.model request.value.body.r) (lth sequence.r sequence.model))
  ?~  contexts  [%| %qpc-pool-context-missing]
  ?^  t.contexts  [%| %qpc-pool-context-ambiguous]
  [%& [model i.contexts]]
++  proposal-tools
  |=  offered=(list tool:np)
  ^-  ?
  ?:  =(tools:collection offered)  %.y
  ?.  ?=([* ~] offered)  %.n
  =/  v3=tool:np  i.offered
  =/  args=json  parameters.v3
  ?.  ?=([%o *] args)  %.n
  =/  props  (~(get by p.args) 'properties')
  ?~  props  %.n
  ?.  ?=([%o *] u.props)  %.n
  =/  prediction  (~(get by p.u.props) prediction-key:patch-report)
  ?~  prediction  %.n
  ?.  ?=([%o *] u.prediction)  %.n
  =/  fields  (~(get by p.u.prediction) 'properties')
  ?~  fields  %.n
  ?.  ?=([%o *] u.fields)  %.n
  =/  man-j  (~(get by p.u.fields) 'manifest')
  =/  wok-j  (~(get by p.u.fields) 'work')
  =/  con-j  (~(get by p.u.fields) 'confidence')
  ?~  man-j  %.n
  ?~  wok-j  %.n
  ?~  con-j  %.n
  =/  enum-id
    |=  value=json
    ^-  (unit @ux)
    ?.  ?=([%o *] value)  ~
    =/  enum  (~(get by p.value) 'enum')
    ?~  enum  ~
    ?.  ?=([%a *] u.enum)  ~
    =/  xs=(list json)  p.u.enum
    ?.  ?=([* ~] xs)  ~
    ?.  ?=([%s *] i.xs)  ~
    (slaw %ux p.i.xs)
  =/  man  (enum-id u.man-j)
  =/  wok  (enum-id u.wok-j)
  =/  dim
    ?.  ?=([%o *] u.con-j)  ~
    =/  min  (~(get by p.u.con-j) 'minItems')
    ?~  min  ~
    ?.  ?=([%n *] u.min)  ~
    (slaw %ud p.u.min)
  ?~  man  %.n
  ?~  wok  %.n
  ?~  dim  %.n
  ?.  ?&  (gth u.man 0)  (lte (met 0 u.man) 256)
          (gth u.wok 0)  (lte (met 0 u.wok) 256)
          (gte u.dim 2)  (lte u.dim 16)
      ==  %.n
  =/  built  (mole |.((decorate:patch-report u.man u.wok u.dim (snag 0 tools:collection))))
  ?~  built  %.n
  =(u.built v3)
++  assemble
  ::  HTTP evidence remains on its existing validator and public signature.
  |=  [our=@p in=input retained=retained:evidence ledger=organ:tools]
  ^-  (each pool @tas)
  ?.  ?=(%result -.outcome.retained)  [%| %qpc-provider-result-unavailable]
  =/  reply=reply:np  value.outcome.retained
  =/  issue  (validate:evidence request.retained reply retained)
  ?^  issue  [%| u.issue]
  (assemble-checked our in request.retained reply ledger)
++  assemble-cli
  ::  The owner reader authenticates this job; pure consistency is not a grant.
  |=  [our=@p in=input retained=job:ci ledger=organ:tools]
  ^-  (each pool @tas)
  ?.  =(key.in key.retained)  [%| %qpc-cli-pairing-mismatch]
  ?~  reply.retained  [%| %qpc-cli-result-not-retained]
  =/  issue  (validate-evidence:cli request.retained u.reply.retained retained)
  ?^  issue  [%| u.issue]
  (assemble-checked our in request.retained u.reply.retained ledger)
++  assemble-checked
  ::  Shared context/tool proof after either transport-specific evidence check.
  ::  Pure assembly alone does not authenticate caller-supplied request/reply.
  |=  [our=@p in=input wanted=request:np reply=reply:np ledger=organ:tools]
  ^-  (each pool @tas)
  =/  e=entry:sessions  entry.in
  =/  found  (extract e)
  ?:  ?=(%| -.found)  [%| p.found]
  =/  m=record:sessions  model.p.found
  =/  c=record:sessions  context.p.found
  ?>  &(?=(%model -.body.m) ?=(%context -.body.c))
  =/  b=binding:frozen  value.body.c
  ?.  ?&  =(our owner.session.e)  =(our worker.e)
          =(selection.e selection.wanted)  (proposal-tools tools.wanted)
          =(id.session.e session.wanted)  =(id.wanted request.b)
          =(our owner.b)  =(our worker.b)  =(session.wanted session.b)
          =(working.session.e source.b)
          =(provider.selection.wanted provider.b)  =(model.selection.wanted model.b)
          =(request-digest.b (shax (jam wanted)))
          =(history-digest.b (shax (jam history.wanted)))
          =(tools-digest.b (shax (jam tools.wanted)))
          =(result.body.m (publish:provider reply))
          (patches:collection e reply)
      ==  [%| %qpc-pool-context-mismatch]
  =/  ctx=context:nc
    [project.session.e configuration.e id.session.e id.wanted our working.session.e]
  =/  records=(list record:sessions)
    %+  skim  records.e
    |=  r=record:sessions
    ?.  ?=(%tool -.body.r)  %.n
    &(=(id.wanted request.context.result.body.r) (gth sequence.r sequence.m))
  ?.  =((lent calls.reply) (lent records))  [%| %qpc-pool-result-count]
  =/  todo=(list call:np)  calls.reply
  =/  rows=(list row)  ~
  =/  collected=(each (list row) @tas)
    |-  ^-  (each (list row) @tas)
    ?~  todo  [%& (flop rows)]
    =/  call=call:np  i.todo
    =/  matches=(list record:sessions)
      %+  skim  records
      |=  r=record:sessions
      ?.  ?=(%tool -.body.r)  %.n
      =(id.call call-id.result.body.r)
    ?~  matches  [%| %qpc-pool-result-missing]
    ?^  t.matches  [%| %qpc-pool-result-duplicate]
    =/  recorded=record:sessions  i.matches
    ?>  ?=(%tool -.body.recorded)
    =/  result=tool-result:nc  result.body.recorded
    ?.  &(=(ctx context.result) =(`result (~(get by results.e) id.call)))
      [%| %qpc-pool-result-mismatch]
    =/  decoded  (decode:codec ctx working.session.e call)
    ?:  ?=(%| -.decoded)  [%| %qpc-pool-call-invalid]
    =/  request=tool-request:nc  p.decoded
    =/  key=@ux  (key:tools request)
    =/  tool  (~(get by records.ledger) key)
    =/  row=row  [id.call key id.recorded (digest result) %cantrip ~ ~]
    ?~  tool
      ?.  ?=(%refused -.output.result)  [%| %qpc-pool-tool-unconfirmed]
      $(todo t.todo, rows [row(origin %journal-refusal) rows])
    ?.  &(=(grant.in grant.u.tool) =(request request.u.tool) =(%finished stage.u.tool) =(`result result.u.tool))
      [%| %qpc-pool-tool-mismatch]
    ?:  ?=(%refused -.output.result)  $(todo t.todo, rows [row rows])
    ?.  ?=(%candidate -.output.result)  [%| %qpc-pool-tool-not-settled]
    =/  candidate=candidate:nc  value.output.result
    ?.  &(=(ctx context.candidate) =(working.session.e revision.basis.candidate) =(1 (lent edits.candidate)) =(~ previous.candidate) =(id.candidate (candidate-digest:files candidate)))
      [%| %qpc-pool-candidate-mismatch]
    =/  effect=@ux  (digest [%effect-v1 revision.basis.candidate accepted.candidate edits.candidate])
    $(todo t.todo, rows [row(candidate `id.candidate, effect `effect) rows])
  ?:  ?=(%| -.collected)  [%| p.collected]
  =/  p=pool
    :*  %qpc-native-pool-v1  0x0  our  id.session.e  project.session.e
        configuration.e  working.session.e  grant.in  key.in  id.wanted
        id.m  id.c  b  (digest reply)  (need head.e)  p.collected
    ==
  =.  p  p(id (digest p))
  ?:((valid p) [%& p] [%| %qpc-pool-invalid])
++  payload
  |=  value=(unit (unit cage))
  ^-  (unit *)
  ?~  value  ~
  ?~  u.value  ~
  ?.  =(%noun p.u.u.value)  ~
  `q.q.u.u.value
++  read
  |=  [inner=agent:gall b=bowl:gall id=@ux]
  ^-  (each pool @tas)
  =/  ag  ~(. inner b(src our.b))
  =/  raw  (payload (on-peek:ag /x/native-coding/qpc-input/(scot %ux id)))
  ?~  raw  [%| %qpc-pool-input-unavailable]
  =/  parsed  ((soft ,(unit input)) u.raw)
  ?~  parsed  [%| %qpc-pool-input-invalid]
  ?~  u.parsed  [%| %qpc-pool-input-missing]
  =/  in=input  u.u.parsed
  ?.  =(id id.session.entry.in)  [%| %qpc-pool-session-mismatch]
  =/  found  (extract entry.in)
  ?:  ?=(%| -.found)  [%| p.found]
  =/  model=record:sessions  model.p.found
  ?>  ?=(%model -.body.model)
  ?.  (agent-live:guard our.b now.b %cantrip)  [%| %qpc-cantrip-unavailable]
  =/  raw=*
    .^(* %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/tool-state/noun)
  =/  ledger  ((soft organ:tools) raw)
  ?~  ledger  [%| %qpc-pool-ledger-invalid]
  ?:  ?=(^ (cli-backend:provider selection.entry.in))
    =/  kept  (lookup-cli:evidence our.b now.b id.result.body.model id key.in)
    ?:  ?=(%| -.kept)  [%| p.kept]
    (assemble-cli our.b in p.kept u.ledger)
  =/  kept  (lookup:evidence our.b now.b id.result.body.model id key.in)
  ?:  ?=(%| -.kept)  [%| p.kept]
  (assemble our.b in p.kept u.ledger)
--
