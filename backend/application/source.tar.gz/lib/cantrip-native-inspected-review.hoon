::  Cantrip proof companion for inspected AI review admission. Context and
::  inspection are read from Viki's authenticated retained worker capture.
/-  protocol=native-coding-review, ri=native-coding-review-inspection
/+  legacy=cantrip-native-review, review=native-coding-review-request,
    inspected=native-coding-inspected-review, accept=native-coding-accept,
    tools=cantrip-native-coding, guard=viki-scry-guard
|%
+$  proofs  (map @ux entry:ri)
+$  change
  [next=ledger:legacy proofs=proofs cards=(list card:agent:gall)]
++  config
  |=  ctx=admission-context:protocol
  ^-  config:review
  ?:(=(worker.ctx ship.left.scope.ctx) config.left.scope.ctx config.right.scope.ctx)
++  proof-key
  ::  Stable across Boxy rounds, but never shared across different moon actors.
  |=  ctx=admission-context:protocol
  ^-  @ux
  (digest:review [%native-coding-inspected-admission-proof-v1 worker.ctx (config ctx) candidate.request.ctx report.request.ctx objective.request.ctx])
++  row-valid
  |=  [our=@p r=retained:legacy proofs=proofs]
  ^-  ?
  ?:  =(law.admission.verdict.r 'native-ai-review-standing-scope-v1')  %.y
  ?.  =(law.admission.verdict.r 'native-ai-review-standing-scope-v2')  %.n
  =/  ctx=admission-context:protocol  context.r
  =/  c=config:review  (config ctx)
  ?.  =(our parent.c)  %.n
  =/  e  (~(get by proofs) (proof-key ctx))
  ?~  e  %.n
  =/  prepared  (inference:inspected worker.ctx c request.ctx u.e)
  ?=(%& -.prepared)
++  valid
  ::  The owning Cantrip app MUST use this in addition to its legacy ledgers.
  |=  [our=@p s=ledger:legacy proofs=proofs]
  ^-  ?
  ?&  (valid:legacy s)  (lte ~(wyt by proofs) 256)
      (levy ~(val by s) |=(r=retained:legacy (row-valid our r proofs)))
      %+  levy  ~(tap by proofs)
      |=  [key=@ux e=entry:ri]
      %+  lien  ~(val by s)
      |=  r=retained:legacy
      &(=(law.admission.verdict.r 'native-ai-review-standing-scope-v2') =(key (proof-key context.r)))
  ==
++  act
  |=  [b=bowl:gall s=ledger:legacy proofs=proofs candidates=ledger:accept grants=(map @ux scope:tools) command=command:protocol]
  ^-  change
  ?>  =(our.b src.b)
  =/  k=key:legacy  [campaign.command request.command]
  =/  old  (~(get by s) k)
  ?^  old
    ?>  (row-valid our.b u.old proofs)
    [s proofs ~[(publish:legacy verdict.u.old)]]
  ?>  (agent-live:guard our.b now.b %viki)
  =/  found=(unit admission-context:protocol)
    .^((unit admission-context:protocol) %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/review-admission/(scot %ux campaign.k)/(scot %ux request.k)/noun)
  ?>  ?=(^ found)
  =/  ctx=admission-context:protocol  u.found
  ?>  &(=(campaign.k campaign.ctx) =(request.k id.request.ctx))
  =/  captured=(unit entry:ri)
    .^((unit entry:ri) %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/review-inspection/(scot %ux campaign.k)/(scot %ux request.k)/noun)
  ?>  ?=(^ captured)
  =/  prepared  (inference:inspected worker.ctx (config ctx) request.ctx u.captured)
  ?>  ?=(%& -.prepared)
  =/  key=@ux  (proof-key ctx)
  =/  existing  (~(get by proofs) key)
  ?>  ?~(existing (lth ~(wyt by proofs) 256) =(u.existing u.captured))
  =/  changed
    (act-checked:legacy b s candidates grants command `(digest:review ctx))
  =/  retained=retained:legacy  (~(got by next.changed) k)
  ?>  =(law.admission.verdict.retained 'native-ai-review-standing-scope-v2')
  [next.changed (~(put by proofs) key u.captured) cards.changed]
--
