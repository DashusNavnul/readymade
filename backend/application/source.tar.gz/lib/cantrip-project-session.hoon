::  Pure intersection of existing source-view and exact inspection authority.
::  No grants are created, widened or renewed; no private session body escapes.
/-  ps=cantrip-project-session, pa=cantrip-project-access,
    nc=native-coding, mp=multiplayer-project
/+  access=cantrip-project-access, transport=cantrip-project-access-runtime,
    tools=cantrip-native-coding, project=native-coding-project,
    rows=readymade-session-catalog, law=cantrip-law-window
|%
+$  scopes  (map @ux scope:tools)
+$  session-view
  [session=session:nc phase=@tas selection=* worker=@p records=* summary=@t sequence=@ud]
++  view-request
  |=  q=query:ps
  ^-  request:pa
  [project.q generation.q nonce.q %view ~ ~ `@t`0]
++  query-valid
  |=  q=query:ps
  ^-  ?
  ?&  (request-valid:transport (view-request q))
      (identifier:tools inspection.q)  (identifier:tools session.q)
  ==
++  inspection-path
  |=  session=@ux
  ^-  path
  /native-coding/session/(scot %ux session)/noun
++  route
  |=  [peer=@p q=query:ps]
  ^-  path
  /project-session/(scot %ux project.q)/(scot %p peer)/(scot %ud generation.q)/(scot %ux inspection.q)/(scot %ux session.q)/(scot %ux nonce.q)
++  parse
  |=  pax=path
  ^-  (unit [peer=@p query=query:ps])
  ?.  &(?=([%project-session @ @ @ @ @ @ ~] pax) (lte (met 3 (jam pax)) 4.096))  ~
  =/  project  (slaw %ux i.t.pax)
  =/  peer  (slaw %p i.t.t.pax)
  =/  generation  (slaw %ud i.t.t.t.pax)
  =/  inspection  (slaw %ux i.t.t.t.t.pax)
  =/  session  (slaw %ux i.t.t.t.t.t.pax)
  =/  nonce  (slaw %ux i.t.t.t.t.t.t.pax)
  ?~  project  ~
  ?~  peer  ~
  ?~  generation  ~
  ?~  inspection  ~
  ?~  session  ~
  ?~  nonce  ~
  =/  q=query:ps  [`@t`u.project u.generation u.inspection u.session u.nonce]
  ?.  &((lte (met 0 u.peer) 128) (query-valid q) =(pax (route u.peer q)))  ~
  `[u.peer q]
++  preflight
  ::  Reject before native reads. Both actor and id come from the retained grant.
  |=  [our=@p peer=@p q=query:ps held=scopes w=window:law]
  ^-  (each grant:tools @tas)
  ?.  (query-valid q)  [%| %session-query-invalid]
  =/  found  (~(get by held) inspection.q)
  ?~  found  [%| %inspection-grant-missing]
  =/  g=grant:tools  grant.u.found
  ?.  &((grant-valid:tools our g) =(id.g inspection.q))  [%| %inspection-grant-invalid]
  ?^  revoked.u.found  [%| %inspection-grant-revoked]
  ?.  &(=(actor.g peer) =(session.g session.q) =(id.spec.project.g project.q))
    [%| %inspection-grant-mismatch]
  ?.  ?&  (~(has in operations.g) %inspect)
          (~(has in inspections.g) [%viki (inspection-path session.q)])
      ==  [%| %inspection-outside-scope]
  ?.  &((~(has in admissible.w) %inspect) !(~(has in blocked.w) %inspect))
    [%| %inspection-law-refused]
  [%& g]
++  response-valid
  |=  r=response:ps
  ^-  ?
  ?&  (lte (met 0 owner.r) 128)  (lte (met 0 peer.r) 128)
      (query-valid query.r)  (gth at.r 0)  (lte (met 0 at.r) 128)
      (identifier:tools source-grant.r)  (identifier:tools inspection-grant.r)
      (revision-valid:project source.r)
      (valid-row:rows owner.r [session.query.r project.query.r owner.r phase.r source.r])
  ==
++  observe
  ::  The live adapter supplies all four current native observations. This arm
  ::  never trusts peer-supplied membership, configuration, grants or session.
  |=  $:  our=@p  peer=@p  now=@da  q=query:ps
          grants=grants:pa  held=scopes  w=window:law
          catalog=project:mp  current=project:nc  raw=*
      ==
  ^-  (each response:ps @tas)
  =/  inspected  (preflight our peer q held w)
  ?:  ?=(%| -.inspected)  [%| p.inspected]
  =/  allowed
    (authorize-scoped:access our peer now catalog grants (view-request q) w `current)
  ?:  ?=(%| -.allowed)  [%| p.allowed]
  =/  g=grant:tools  p.inspected
  ?.  =(current project.g)  [%| %session-project-changed]
  ?.  (member:project current catalog peer %inspect)  [%| %session-member-refused]
  =/  decoded  ((soft ,(unit session-view)) raw)
  ?~  decoded  [%| %session-invalid]
  ?~  u.decoded  [%| %session-missing]
  =/  s=session-view  u.u.decoded
  ?.  ?&  =(our owner.session.s)  =(session.q id.session.s)
          =(project.q project.session.s)  =(our owner.working.session.s)
          =(working.current desk.working.session.s)
          =(desk.p.allowed desk.working.session.s)
      ==  [%| %session-context-mismatch]
  =/  response=response:ps
    [our peer q now (digest:access p.allowed) (digest:tools g) phase.s working.session.s]
  ?.  (response-valid response)  [%| %session-invalid]
  [%& response]
++  cards
  |=  [pax=path r=response:ps]
  ^-  (list card:agent:gall)
  ?>  &((response-valid r) =(pax (route peer.r query.r)))
  :~  [%give %fact ~[pax] %noun !>(`event:ps`[%cantrip-project-session-v1 r])]
      [%give %kick ~[pax] ~]
  ==
--
