::  /lib/cantrip-multiplayer-law
::
::  Pure Hoon realization of Cantrip/Multiplayer.gls. Gall agents pass
::  src.bowl into this core; no claimed ship field is accepted as identity.
::
/-  ct=cantrip, cm=cantrip-multiplayer
|%
++  allow
  ^-  verdict:cm
  [%& ~]
::
++  refuse
  |=  why=refusal:cm
  ^-  verdict:cm
  [%| why]
::
++  receive
  |=  context=receive-context:cm
  ^-  verdict:cm
  ?.  ?|  =(source.context host.context)
          source-allowed.context
      ==
    (refuse %source-not-allowed)
  ?.  =(kind.move.context -.payload.move.context)
    (refuse %payload-kind-mismatch)
  ?:  duplicate-move-id.context
    (refuse %duplicate-move-id)
  ?:  move-too-large.context
    (refuse %move-too-large)
  ?:  source-inbox-full.context
    (refuse %source-inbox-full)
  ?:  inbox-full.context
    (refuse %inbox-full)
  allow
::
++  legal-transition
  |=  [from=mp-inbox-status:ct to=mp-inbox-status:ct]
  ^-  ?
  ?:  =(%pending from)
    ?|(?=(%accepted to) ?=(%refused to) ?=(%held to) ?=(%abandoned to))
  ?:  =(%held from)
    ?|(?=(%accepted to) ?=(%refused to) ?=(%completed to) ?=(%abandoned to))
  ?:  =(%accepted from)
    ?|(?=(%completed to) ?=(%abandoned to))
  %.n
::
++  transition
  |=  request=transition-request:cm
  ^-  verdict:cm
  ?.  =(source.request host.request)
    (refuse %local-judgment-only)
  ?.  (legal-transition from.request to.request)
    (refuse %illegal-status-transition)
  allow
::
++  legal-receipt
  |=  [from=mp-outbox-status:ct to=mp-inbox-status:ct]
  ^-  ?
  ?:  =(from to)  %.y
  ?:  =(%sent from)
    %.y
  ?:  =(%pending from)
    ?|(?=(%accepted to) ?=(%refused to) ?=(%held to) ?=(%completed to) ?=(%abandoned to))
  ?:  =(%held from)
    ?|(?=(%accepted to) ?=(%refused to) ?=(%completed to) ?=(%abandoned to))
  ?:  =(%accepted from)
    ?|(?=(%completed to) ?=(%abandoned to))
  %.n
::
++  receipt
  |=  context=receipt-context:cm
  ^-  verdict:cm
  ?~  entry.context
    (refuse %unknown-outbox-move)
  ?.  =(source.context target-ship.u.entry.context)
    (refuse %receipt-source-mismatch)
  ?.  =(receiver.receipt.context source.context)
    (refuse %receipt-receiver-mismatch)
  ?.  =(move-id.receipt.context move-id.move.u.entry.context)
    (refuse %receipt-move-id-mismatch)
  ?.  (legal-receipt status.u.entry.context status.receipt.context)
    (refuse %illegal-receipt-transition)
  allow
::
++  terminal-outbox
  |=  status=mp-outbox-status:ct
  ^-  ?
  ?=(?(%refused %completed %abandoned) status)
::
++  retry
  |=  [host=@p source=@p entry=(unit mp-outbox-entry:ct)]
  ^-  verdict:cm
  ?.  =(host source)
    (refuse %local-send-only)
  ?~  entry
    (refuse %unknown-outbox-move)
  ?:  (terminal-outbox status.u.entry)
    (refuse %retry-terminal-outbox)
  allow
::
++  retire
  |=  [host=@p source=@p entry=(unit mp-outbox-entry:ct)]
  ^-  verdict:cm
  ?.  =(host source)
    (refuse %local-send-only)
  ?~  entry
    (refuse %unknown-outbox-move)
  ?.  (terminal-outbox status.u.entry)
    (refuse %retire-active-outbox)
  allow
::
++  administer-allowlist
  |=  [host=@p source=@p]
  ^-  verdict:cm
  ?:(=(host source) allow (refuse %local-judgment-only))
::
++  send
  |=  [host=@p source=@p]
  ^-  verdict:cm
  ?:(=(host source) allow (refuse %local-send-only))
--
