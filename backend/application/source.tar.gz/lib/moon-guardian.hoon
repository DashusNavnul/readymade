::  /lib/moon-guardian.hoon
::
::  The moon-authority clamp and the pure lifecycle transitions the %moon-warden
::  agent runs.  This is the security core: the DECISION the sovereign ship runs
::  when a moon asks to exercise delegated authority.
::
::  The clamp is the intersection of two independent gates:
::    1. the parent's OWN guardian law (/lib/viki-guardian.hoon) -- is the tool an
::       attested guardian tool at all, and is it read-only or mutating?
::    2. the LEASE -- is the tool in the moon's allowed subset, within its tier
::       ceiling, and is the lease active (not pending / expired / revoked)?
::  Closed Graf seat capabilities may also be carried as identity metadata in a
::  lease, but +clamp never executes them: the Guardian gate still refuses them.
::  A moon can never hold authority its parent could not grant: the verdict is the
::  parent's own gate, further narrowed by the lease.  Everything fails closed.
::
::  Keeping the clamp AND the lifecycle transitions pure (Nock-only) is deliberate:
::  ted/ph/moon-authority-clamp-proof.hoon exercises the exact same code the agent
::  enforces, so the proof proves the enforcement, not a reimplementation of it.
::
/-  mg=moon-grant
/+  viki-guardian, moon-graf-effect, gsc=graf-seat-claim
|%
::  ingress bounds.  These are deliberately small enough to keep one hostile
::  poke from turning validation into an unbounded allocation or scan.
++  max-lease-id-bytes  64
++  max-tool-count      32
++  max-tool-bytes      64
++  max-arg-bytes       4.096
++  max-lease-seconds   2.678.400
::  atom byte length is the canonical bound for all externally supplied text.
++  text-within
  |=  [txt=@t max=@ud]
  ^-  ?
  (lte (met 3 txt) max)
::  tier ordering for the ceiling clamp.  0 = none/unknown (most restrictive).
++  tier-rank
  |=  t=@tas
  ^-  @ud
  ?+  t  0
    %safe        1
    %reversible  2
    %data        3
  ==
::  the asked tool's tier must not exceed the lease ceiling.
++  tier-within-ceiling
  |=  [tool=@t ceiling=@tas]
  ^-  ?
  (lte (tier-rank (tool-tier:viki-guardian tool)) (tier-rank ceiling))
::  is `who` a moon of `parent`?  a moon is clan %earl whose sponsor is the parent
::  and is not the parent itself.  `sponsor` is supplied by the agent as
::  (^sein:title now who) so this predicate stays pure and provable.
++  is-moon-of
  |=  [parent=@p who=@p sponsor=@p]
  ^-  ?
  ?&  =(parent sponsor)
      =(%earl (clan:title who))
      !=(parent who)
  ==
::  THE CLAMP.  parent guardian law INTERSECT lease -> verdict.  fail-closed.
++  clamp
  |=  [ask=moon-ask:mg grant=(unit moon-grant:mg) now=@da]
  ^-  clamp-result:mg
  ?.  (valid-lease-id lease-id.ask)
    [%refused 'lease-id is invalid or exceeds 64 bytes' %safe]
  ?.  (text-within tool.ask max-tool-bytes)
    [%refused 'tool name exceeds 64 bytes' %safe]
  ?.  (text-within arg.ask max-arg-bytes)
    [%refused 'tool argument exceeds 4096 bytes' %safe]
  ?.  (text-within arg2.ask max-arg-bytes)
    [%refused 'second tool argument exceeds 4096 bytes' %safe]
  =/  asked-tier  (tool-tier:viki-guardian tool.ask)
  ::  1. no lease for this moon+lease-id -> refuse (unknown grant)
  ?~  grant  [%refused 'no active lease for this lease-id' asked-tier]
  =/  g  u.grant
  ?.  =(lease-id.ask lease-id.g)  [%refused 'lease-id mismatch' asked-tier]
  ::  2. status gates (fail-closed): only %active authorizes
  ?:  =(%revoked status.g)  [%refused 'lease revoked' asked-tier]
  ?:  =(%pending status.g)  [%refused 'lease not yet approved by principal' asked-tier]
  ?:  =(%activating status.g)  [%refused 'lease activation is not complete' asked-tier]
  ?:  =(%mirror-failed status.g)  [%refused 'lease authority mirror failed' asked-tier]
  ?:  =(%expired status.g)  [%refused 'lease expired' asked-tier]
  ?.  =(%active status.g)   [%refused 'lease not active' asked-tier]
  ::  3. A present zero expiry means until revoked; missing remains invalid.
  ?~  expires-at.g
    [%refused 'active lease has no expiry' asked-tier]
  ?:  ?&(!=(0 u.expires-at.g) (gte now u.expires-at.g))
    [%refused 'lease expired' asked-tier]
  ::  4. parent's OWN guardian gate: is the tool an attested guardian tool?
  ::     an unattested / unknown tool name fails safe to %refused.
  =/  parent-gate  (name-gate:viki-guardian tool.ask)
  ?:  =(%refused parent-gate)  [%refused 'tool not attested by parent guardian law' asked-tier]
  ::  5. lease subset clamp: the tool must be inside the moon's allowed subset
  ?.  (~(has in allowed-tools.g) tool.ask)
    [%refused 'tool outside lease grant' asked-tier]
  ::  6. lease tier-ceiling clamp
  ?.  (tier-within-ceiling tool.ask tier-ceiling.g)
    [%refused 'tool tier exceeds lease ceiling' asked-tier]
  ::  passed every gate -> the verdict is the PARENT's gate (%execute for a
  ::  read-only tool, %needs-approval for a mutating tool).  The moon is clamped
  ::  to at most what the parent's own law would allow for that same tool.
  [parent-gate 'within lease and parent guardian law' asked-tier]
::
::  -------------------------------------------------------------------------
::  pure lifecycle transitions over warden-state.  each returns a `transition`
::  (new state + receipt-intents + effect-intents + ok?).  the agent supplies
::  `now`; sender authentication (principal vs moon) is done by the agent from
::  src.bowl before calling these.
::  -------------------------------------------------------------------------
::
++  migrate-grant
  |=  g=legacy-moon-grant:mg
  ^-  moon-grant:mg
  =/  status=grant-status:mg
    ?-  status.g
      %pending  %pending
      ::  A legacy active lease predates canonical Cantrip mirroring.  It must
      ::  prove that mirror on load before it can authorize again.
      %active   %activating
      %revoked  %revoked
      %expired  %expired
    ==
  :*  lease-id.g  grantee.g  parent.g  allowed-tools.g  tier-ceiling.g
      lease-seconds.g  granted-by.g  requested-at.g  granted-at.g  expires-at.g
      status  approval-id.g  revoked-at.g  revoke-reason.g
  ==
::  A %1 grant already has the current record shape, but %active meant only
::  principal approval.  Demote exactly that status so canonical mirroring must
::  be proved; every other status and every immutable field is preserved.
++  remirror-grant
  |=  g=moon-grant:mg
  ^-  moon-grant:mg
  ?:  =(%active status.g)  g(status %activating)
  g
++  migrate-act
  |=  p=legacy-moon-act-proposal:mg
  ^-  moon-act-proposal:mg
  =/  status=act-status:mg
    ?-  status.p
      %pending   %pending
      %rejected  %rejected
      ::  Legacy %approved meant only "dispatch requested"; no execution ack
      ::  existed.  Preserve it as a closed, explicitly unverified failure.
      %approved  %failed
    ==
  :*  proposal-id.p  lease-id.p  grantee.p  tool.p  arg.p  arg2.p
      status  created-at.p  decided-at.p
  ==
++  migrate-grants
  |=  xs=(list [@t legacy-moon-grant:mg])
  ^-  (map @t moon-grant:mg)
  =|  out=(map @t moon-grant:mg)
  |-
  ?~  xs  out
  =/  entry  i.xs
  $(xs t.xs, out (~(put by out) -.entry (migrate-grant +.entry)))
++  remirror-grants
  |=  xs=(list [@t moon-grant:mg])
  ^-  (map @t moon-grant:mg)
  =|  out=(map @t moon-grant:mg)
  |-
  ?~  xs  out
  =/  entry  i.xs
  $(xs t.xs, out (~(put by out) -.entry (remirror-grant +.entry)))
++  migrate-acts
  |=  xs=(list legacy-moon-act-proposal:mg)
  ^-  (list moon-act-proposal:mg)
  (turn xs migrate-act)
++  migrate-state
  |=  old=legacy-warden-state:mg
  ^-  warden-state:mg
  :*  %2
      (migrate-grants ~(tap by grants.old))
      (migrate-acts act-queue.old)
      (migrate-acts act-history.old)
      ~
      seq.old
  ==
++  migrate-state-1
  |=  old=legacy-warden-state-1:mg
  ^-  warden-state:mg
  :*  %2
      (remirror-grants ~(tap by grants.old))
      act-queue.old
      act-history.old
      in-flight.old
      seq.old
  ==
++  bump  |=(st=warden-state:mg st(seq +(seq.st)))
::  build a receipt-intent
++  rcpt
  |=  $:  stage=receipt-stage:mg
          actor=receipt-actor:mg
          lease-id=@t
          grantee=@p
          tool=@t
          summary=@t
      ==
  ^-  receipt-intent:mg
  [stage actor lease-id grantee tool summary]
::  a valid lease-id must be a real @tas term (so it is safe as a graf impulse-id
::  and cannot smuggle punctuation into receipt keys).  fail-closed if not.
++  valid-lease-id
  |=  id=@t
  ^-  ?
  ?&  (text-within id max-lease-id-bytes)
      ?=(^ (slaw %tas id))
  ==
::  Stable holder identity shared with Cantrip's lease record.
++  grant-holder
  |=  g=moon-grant:mg
  ^-  @t
  (scot %p grantee.g)
::  Gall continuation wire for the Cantrip mirror poke.  The absolute deadline
::  is part of the identity, so an acknowledgement from an older generation is
::  stale by construction.
++  mirror-wire
  |=  [lease-id=@t expires=@da]
  ^-  wire
  [%moon-lease %mirror lease-id (scot %da expires) ~]
++  parse-mirror-wire
  |=  w=wire
  ^-  (unit mirror-spec:mg)
  ?.  ?=([%moon-lease %mirror @ @ ~] w)  ~
  =/  exp=(unit @da)  (slaw %da i.t.t.t.w)
  ?~  exp  ~
  `[i.t.t.w u.exp]
::  Warden's own Behn wheel.  Cantrip owns its separate timer; this wire only
::  makes Warden's local grant state truthful at the same exact deadline.
++  expiry-wire
  |=  [lease-id=@t expires=@da]
  ^-  wire
  [%moon-lease %expire lease-id (scot %da expires) ~]
++  parse-expiry-wake
  |=  [w=wire s=sign-arvo]
  ^-  (unit wake-spec:mg)
  ?.  ?=([%moon-lease %expire @ @ ~] w)  ~
  ?.  ?=([%behn %wake *] s)  ~
  =/  exp=(unit @da)  (slaw %da i.t.t.t.w)
  ?~  exp  ~
  `[i.t.t.w u.exp]
::  every requested tool must fit the ingress text bound.
++  oversized-tools
  |=  tools=(list @t)
  ^-  (list @t)
  (skip tools |=(t=@t (text-within t max-tool-bytes)))
::  Lease metadata includes closed seats and Cantrip's exact read-file peer
::  capability. Neither is a Guardian executable: +clamp still requires its
::  unchanged +name-gate. The moon must separately hold its local peer grant.
++  unattested-tools
  |=  tools=(list @t)
  ^-  (list @t)
  (skip tools |=(t=@t ?|((is-attested:viki-guardian t) (seat-cap-valid:gsc t) =('read-file' t))))
::
::  principal requests a grant.  a grant IS a mutating act: this only creates a
::  %pending lease; it authorizes nothing until %approve-grant.  fail-closed on a
::  bad lease-id, an unattested tool, or a bad tier.
++  apply-grant-request
  |=  $:  st=warden-state:mg
          grantee=@p
          parent=@p
          grantee-sponsor=@p
          lease-id=@t
          tools=(list @t)
          ceiling=@tas
          secs=@ud
          granted-by=@t
          now=@da
      ==
  ^-  transition:mg
  =/  who  (scot %p grantee)
  ?.  (is-moon-of parent grantee grantee-sponsor)
    :*  st
        ~[(rcpt %grant-refused %principal lease-id grantee '' 'grantee is not a moon sponsored by this parent')]
        ~  %.n
    ==
  ?.  (valid-lease-id lease-id)
    :*  st
        ~[(rcpt %grant-refused %principal lease-id grantee '' 'lease-id is not a valid term')]
        ~  %.n
    ==
  ?:  (~(has by grants.st) lease-id)
    :*  st
        ~[(rcpt %grant-refused %principal lease-id grantee '' 'lease-id already in use')]
        ~  %.n
    ==
  =/  tool-count=@ud  (lent tools)
  ?:  =(0 tool-count)
    :*  st
        ~[(rcpt %grant-refused %principal lease-id grantee '' 'grant must name at least one tool')]
        ~  %.n
    ==
  ?:  (gth tool-count max-tool-count)
    :*  st
        ~[(rcpt %grant-refused %principal lease-id grantee '' 'grant exceeds 32-tool limit')]
        ~  %.n
    ==
  ?:  (gth secs max-lease-seconds)
    :*  st
        ~[(rcpt %grant-refused %principal lease-id grantee '' 'lease lifetime exceeds 31-day limit')]
        ~  %.n
    ==
  ?.  ?=(?(%safe %reversible %data) ceiling)
    :*  st
        ~[(rcpt %grant-refused %principal lease-id grantee '' 'invalid tier ceiling')]
        ~  %.n
    ==
  =/  huge  (oversized-tools tools)
  ?^  huge
    :*  st
        ~[(rcpt %grant-refused %principal lease-id grantee i.huge 'tool name exceeds 64-byte limit')]
        ~  %.n
    ==
  =/  bad  (unattested-tools tools)
  ?^  bad
    :*  st
        ~[(rcpt %grant-refused %principal lease-id grantee i.bad 'entry is neither an attested Guardian tool nor a closed seat capability')]
        ~  %.n
    ==
  =/  g=moon-grant:mg
    :*  lease-id  grantee  parent  (sy tools)  ceiling  secs
        granted-by  now  ~  ~  %pending  ~  ~  ~
    ==
  =/  st2  (bump st(grants (~(put by grants.st) lease-id g)))
  =/  sum=@t
    (rap 3 'grant requested for ' who ' lease ' lease-id ' (pending principal approval)' ~)
  :*  st2
      ~[(rcpt %grant-requested %principal lease-id grantee '' sum)]
      ~  %.y
  ==
::  Principal approval fixes an expiry (zero means until revoked) and begins
::  activation. It authorizes nothing until an exact Cantrip readback matches.
++  apply-approve-grant
  |=  [st=warden-state:mg lease-id=@t now=@da]
  ^-  lease-transition:mg
  ?.  (valid-lease-id lease-id)
    :*  st  ~[(rcpt %grant-rejected %principal lease-id ~zod '' 'invalid lease-id')]  ~  ~  %.n
    ==
  =/  mg-unit  (~(get by grants.st) lease-id)
  ?~  mg-unit
    :*  st  ~[(rcpt %grant-rejected %principal lease-id ~zod '' 'no such lease to approve')]  ~  ~  %.n
    ==
  =/  g  u.mg-unit
  ?.  =(%pending status.g)
    :*  st  ~[(rcpt %grant-rejected %principal lease-id grantee.g '' 'lease is not pending')]  ~  ~  %.n
    ==
  =/  exp=@da
    ?:  =(0 lease-seconds.g)  `@da`0
    (add now (mul lease-seconds.g ~s1))
  =/  g2=moon-grant:mg
    g(status %activating, granted-at `now, expires-at `exp, approval-id `(scot %da now))
  =/  st2  (bump st(grants (~(put by grants.st) lease-id g2)))
  =/  sum=@t
    (rap 3 'grant APPROVED for ' (scot %p grantee.g) ' lease ' lease-id ' (activation awaits canonical Cantrip mirror)' ~)
  :*  st2
      ~[(rcpt %grant-approved %principal lease-id grantee.g '' sum)]
      ~
      ~[[%mirror lease-id (grant-holder g2) exp]]
      %.y
  ==
::  A nack, missing readback, or mismatched readback closes activation fail-
::  closed.  The callback must name the exact persisted deadline.
++  apply-mirror-failure
  |=  [st=warden-state:mg lease-id=@t expected=@da reason=@t now=@da]
  ^-  lease-transition:mg
  =/  found  (~(get by grants.st) lease-id)
  ?~  found  [st ~ ~ ~ %.n]
  =/  g  u.found
  ?.  =(%activating status.g)  [st ~ ~ ~ %.n]
  ?.  ?&(?=(^ expires-at.g) =(expected u.expires-at.g))
    [st ~ ~ ~ %.n]
  =/  failed=moon-grant:mg  g(status %mirror-failed)
  =/  st2  (bump st(grants (~(put by grants.st) lease-id failed)))
  =/  sum=@t
    (rap 3 'lease activation FAILED for ' (scot %p grantee.g) ' lease ' lease-id ': ' reason ~)
  :*  st2
      ~[(rcpt %grant-mirror-failed %warden lease-id grantee.g '' sum)]
      ~  ~  %.y
  ==
::  A successful poke acknowledgement is only permission to read.  Activation
::  completes iff Cantrip's canonical noun matches holder, status and the exact
::  expiry, either zero (until revoked) or a deadline still in the future.
++  apply-mirror-readback
  |=  $:  st=warden-state:mg
          lease-id=@t
          expected=@da
          observed=(unit mirrored-lease:mg)
          now=@da
      ==
  ^-  lease-transition:mg
  =/  found  (~(get by grants.st) lease-id)
  ?~  found  [st ~ ~ ~ %.n]
  =/  g  u.found
  ?.  =(%activating status.g)  [st ~ ~ ~ %.n]
  ?.  ?&(?=(^ expires-at.g) =(expected u.expires-at.g))
    [st ~ ~ ~ %.n]
  ?~  observed
    (apply-mirror-failure st lease-id expected 'canonical Cantrip mirror is missing' now)
  =/  seen  u.observed
  ?.  ?&  =((grant-holder g) holder.seen)
          =(expected expires.seen)
          =(%active status.seen)
          ?|(=(0 expected) (lth now expected))
      ==
    (apply-mirror-failure st lease-id expected 'canonical Cantrip mirror does not match the grant' now)
  =/  active=moon-grant:mg  g(status %active)
  =/  st2  (bump st(grants (~(put by grants.st) lease-id active)))
  =/  sum=@t
    (rap 3 'lease ACTIVE for ' (scot %p grantee.g) ' lease ' lease-id ' after exact canonical Cantrip readback' ~)
  :*  st2
      ~[(rcpt %grant-active %warden lease-id grantee.g '' sum)]
      ~
      ?:(=(0 expected) ~ ~[[%wait lease-id expected]])
      %.y
  ==
::  principal rejects a pending grant -> dropped.
++  apply-reject-grant
  |=  [st=warden-state:mg lease-id=@t reason=@t]
  ^-  transition:mg
  ?.  (valid-lease-id lease-id)
    :*  st  ~[(rcpt %grant-rejected %principal lease-id ~zod '' 'invalid lease-id')]  ~  %.n
    ==
  =/  mg-unit  (~(get by grants.st) lease-id)
  ?~  mg-unit
    :*  st  ~[(rcpt %grant-rejected %principal lease-id ~zod '' 'no such lease')]  ~  %.n
    ==
  =/  g  u.mg-unit
  =/  st2  (bump st(grants (~(del by grants.st) lease-id)))
  :*  st2  ~[(rcpt %grant-rejected %principal lease-id grantee.g '' reason)]  ~  %.y
  ==
::  principal revokes a lease.  IMMEDIATE, no model in the loop, no moon contact.
::  works whether the lease is %pending or %active, and even if the moon is
::  unreachable -- it is a pure state change on the parent.
++  apply-revoke
  |=  [st=warden-state:mg lease-id=@t reason=@t now=@da]
  ^-  lease-transition:mg
  ?.  (valid-lease-id lease-id)
    :*  st  ~[(rcpt %revoked %principal lease-id ~zod '' 'invalid lease-id')]  ~  ~  %.n
    ==
  =/  mg-unit  (~(get by grants.st) lease-id)
  ?~  mg-unit
    :*  st  ~[(rcpt %revoked %principal lease-id ~zod '' 'no such lease to revoke')]  ~  ~  %.n
    ==
  =/  g  u.mg-unit
  =/  g2=moon-grant:mg  g(status %revoked, revoked-at `now, revoke-reason `reason)
  =/  st2  (bump st(grants (~(put by grants.st) lease-id g2)))
  =/  sum=@t
    (rap 3 'lease REVOKED for ' (scot %p grantee.g) ' lease ' lease-id ' -- ' reason ~)
  =/  release=(list lease-effect:mg)
    ?:  =(%active status.g)  ~[[%release lease-id]]
    ~
  :*  st2
      ~[(rcpt %revoked %principal lease-id grantee.g '' sum)]
      ~
      release
      %.y
  ==
::  behn-driven auto-expiry: makes the lease STATE truthful at expires-at (the
::  ask-time clamp already refuses past expiry; this flips the stored status so
::  state and verdict agree).  fail-closed on misfire: an early wake, a missing
::  lease, or a non-%active lease (e.g. already %revoked) changes NOTHING -- in
::  every such case the clamp remains the enforcement backstop.
++  apply-expire
  |=  [st=warden-state:mg lease-id=@t now=@da]
  ^-  transition:mg
  =/  mg-unit  (~(get by grants.st) lease-id)
  ?~  mg-unit  [st ~ ~ %.n]
  =/  g  u.mg-unit
  ?.  =(%active status.g)  [st ~ ~ %.n]
  ?.  ?&(?=(^ expires-at.g) !=(0 u.expires-at.g) (gte now u.expires-at.g))
    [st ~ ~ %.n]
  =/  g2=moon-grant:mg  g(status %expired)
  =/  st2  (bump st(grants (~(put by grants.st) lease-id g2)))
  =/  sum=@t
    (rap 3 'lease EXPIRED for ' (scot %p grantee.g) ' lease ' lease-id ' (behn auto-expiry at lease end)' ~)
  [st2 ~[(rcpt %lease-expired %warden lease-id grantee.g '' sum)] ~ %.y]
::  Exact Warden wake semantics.  A matching early wake rearms the same
::  persisted deadline; an exact or late wake expires local authority.  Stale
::  deadlines, missing grants and terminal states are no-ops.
++  apply-expiry-wake
  |=  [st=warden-state:mg lease-id=@t wire-expires=@da now=@da]
  ^-  lease-transition:mg
  =/  found  (~(get by grants.st) lease-id)
  ?~  found  [st ~ ~ ~ %.n]
  =/  g  u.found
  ?.  =(%active status.g)  [st ~ ~ ~ %.n]
  ?~  expires-at.g  [st ~ ~ ~ %.n]
  ?:  =(0 u.expires-at.g)  [st ~ ~ ~ %.n]
  ?.  =(wire-expires u.expires-at.g)  [st ~ ~ ~ %.n]
  ?:  (lth now u.expires-at.g)
    [st ~ ~ ~[[%wait lease-id u.expires-at.g]] %.n]
  =/  expired  (apply-expire st lease-id now)
  [state.expired receipts.expired effects.expired ~ ok.expired]
::  Restart recovery is pure and deterministic.  Persisted dispatching acts
::  reconstruct the exact same native Graf intent; corrupt/unsupported legacy
::  in-flight entries close failed instead of remaining stuck forever.
::  Activating grants reissue the idempotent Cantrip mirror; future active grants
::  rearm Warden's wheel; overdue active grants close locally.
++  restore-warden
  |=  [st=warden-state:mg now=@da]
  ^-  lease-transition:mg
  =/  recover
    |=  $:  items=(list [@t moon-act-proposal:mg])
            cur=warden-state:mg
            rs=(list receipt-intent:mg)
            es=(list effect-intent:mg)
            changed=?
        ==
    ^-  [state=warden-state:mg receipts=(list receipt-intent:mg) effects=(list effect-intent:mg) changed=?]
    ?~  items  [cur rs es changed]
    =/  pid=@t  -.i.items
    =/  p=moon-act-proposal:mg  +.i.items
    =/  eff  (effect-of-proposal:moon-graf-effect p)
    ?^  eff
      $(items t.items, es (snoc es u.eff))
    =/  failed=moon-act-proposal:mg  p(status %failed, decided-at `now)
    =/  cur2
      %-  bump
      %=  cur
        in-flight    (~(del by in-flight.cur) pid)
        act-history  [failed act-history.cur]
      ==
    =/  sum=@t
      (rap 3 'persisted dispatch ' pid ' cannot be reconstructed by a native Warden adapter' ~)
    =/  r
      (rcpt %act-failed %warden lease-id.p grantee.p tool.p sum)
    $(items t.items, cur cur2, rs (snoc rs r), changed %.y)
  =/  recovered  (recover ~(tap by in-flight.st) st ~ ~ %.n)
  =/  walk
    |=  $:  items=(list [@t moon-grant:mg])
            cur=warden-state:mg
            rs=(list receipt-intent:mg)
            es=(list effect-intent:mg)
            les=(list lease-effect:mg)
            changed=?
        ==
    ^-  lease-transition:mg
    ?~  items  [cur rs es les changed]
    =/  lease-id=@t  -.i.items
    =/  g=moon-grant:mg  +.i.items
    ?-  status.g
      %activating
        ?~  expires-at.g
          $(items t.items)
        $(items t.items, les (snoc les [%mirror lease-id (grant-holder g) u.expires-at.g]))
      %active
        ?~  expires-at.g
          $(items t.items)
        ?:  =(0 u.expires-at.g)
          $(items t.items)
        ?:  (lth now u.expires-at.g)
          $(items t.items, les (snoc les [%wait lease-id u.expires-at.g]))
        =/  closed  (apply-expire cur lease-id now)
        $(items t.items, cur state.closed, rs (weld rs receipts.closed), changed ?|(changed ok.closed))
      %pending       $(items t.items)
      %mirror-failed  $(items t.items)
      %revoked       $(items t.items)
      %expired       $(items t.items)
    ==
  (walk ~(tap by grants.state.recovered) state.recovered receipts.recovered effects.recovered ~ changed.recovered)
::  a moon exercises a tool under its lease.  `asker` is src.bowl; the agent has
::  already confirmed (is-moon-of parent asker sponsor).  runs the clamp.
++  apply-moon-ask
  |=  [st=warden-state:mg ask=moon-ask:mg asker=@p now=@da]
  ^-  transition:mg
  =/  who  (scot %p asker)
  ::  Reject oversized/ill-shaped asks before touching the grants map.
  ?.  ?&  (valid-lease-id lease-id.ask)
          (text-within tool.ask max-tool-bytes)
          (text-within arg.ask max-arg-bytes)
          (text-within arg2.ask max-arg-bytes)
      ==
    =/  cr  (clamp ask ~ now)
    =/  sum=@t  (rap 3 who ' asked ' tool.ask ' -> REFUSED: ' reason.cr ~)
    :*  st  ~[(rcpt %act-refused %moon lease-id.ask asker tool.ask sum)]  ~  %.n
    ==
  =/  mg-unit  (~(get by grants.st) lease-id.ask)
  ::  the asking moon must be the named grantee of the lease it cites.
  ?:  ?&(?=(^ mg-unit) !=(asker grantee.u.mg-unit))
    =/  sum=@t  (rap 3 who ' is not the grantee of lease ' lease-id.ask ~)
    :*  st  ~[(rcpt %act-refused %moon lease-id.ask asker tool.ask sum)]  ~  %.n
    ==
  =/  cr  (clamp ask mg-unit now)
  ?-  verdict.cr
      %refused
    =/  sum=@t  (rap 3 who ' asked ' tool.ask ' -> REFUSED: ' reason.cr ~)
    :*  st  ~[(rcpt %act-refused %moon lease-id.ask asker tool.ask sum)]  ~  %.n
    ==
  ::
      %execute
    ::  A read-only tool passed the clamp.  This transition only authorizes the
    ::  read; it does not dispatch an effect and must not claim execution.
    =/  st2  (bump st)
    =/  sum=@t  (rap 3 who ' requested read-only ' tool.ask ' under lease ' lease-id.ask ' -> authorized' ~)
    :*  st2  ~[(rcpt %act-authorized %moon lease-id.ask asker tool.ask sum)]  ~  %.y
    ==
  ::
      %needs-approval
    ::  mutating tool, within lease -> lands in the PARENT's approval queue.
    =/  pid=@t  (rap 3 'act-' lease-id.ask '-' (scot %ud seq.st) ~)
    =/  prop=moon-act-proposal:mg
      [pid lease-id.ask asker tool.ask arg.ask arg2.ask %pending now ~]
    =/  st2  (bump st(act-queue [prop act-queue.st]))
    =/  sum=@t
      (rap 3 who ' asked mutating ' tool.ask ' under lease ' lease-id.ask ' -> QUEUED for principal approval (proposal ' pid ')' ~)
    :*  st2  ~[(rcpt %act-queued %moon lease-id.ask asker tool.ask sum)]  ~  %.y
    ==
  ==
::  Principal approval authorizes dispatch; it does NOT prove execution.  The
::  proposal remains in-flight until a matching acknowledgement closes it.
++  apply-approve-moon-act
  |=  [st=warden-state:mg proposal-id=@t now=@da]
  ^-  transition:mg
  =/  found  (find-act proposal-id act-queue.st)
  ?~  found
    :*  st  ~[(rcpt %act-rejected %principal '' ~zod '' 'no such queued act')]  ~  %.n
    ==
  =/  p  u.found
  ::  fail-closed: re-run the clamp at approval time.  a lease that was revoked
  ::  or expired between queue and approval no longer authorizes the queued act,
  ::  so the effect must NOT fire -- revocation is total, even for acts already
  ::  in the queue.  A still-live mutating act re-clamps to %needs-approval.
  =/  recheck  (clamp [lease-id.p tool.p arg.p arg2.p] (~(get by grants.st) lease-id.p) now)
  ?.  ?=(%needs-approval verdict.recheck)
    =/  st2
      %-  bump
      %=  st
        act-queue    (skim-act proposal-id act-queue.st)
        act-history  [p(status %rejected, decided-at `now) act-history.st]
      ==
    =/  sum=@t
      (rap 3 'queued act ' tool.p ' for ' (scot %p grantee.p) ' REFUSED at approval: lease no longer authorizes (' reason.recheck ')' ~)
    :*  st2  ~[(rcpt %act-refused %principal lease-id.p grantee.p tool.p sum)]  ~  %.n
    ==
  =/  dispatching=moon-act-proposal:mg  p(status %dispatching, decided-at `now)
  =/  eff-unit  (effect-of-proposal:moon-graf-effect dispatching)
  ?~  eff-unit
    =/  failed=moon-act-proposal:mg  p(status %failed, decided-at `now)
    =/  st2
      %-  bump
      %=  st
        act-queue    (skim-act proposal-id act-queue.st)
        act-history  [failed act-history.st]
      ==
    =/  sum=@t
      (rap 3 'queued act ' tool.p ' has no valid Urbit-native Moon-Warden effect adapter' ~)
    :*  st2  ~[(rcpt %act-failed %warden lease-id.p grantee.p tool.p sum)]  ~  %.n
    ==
  =/  st2
    %-  bump
    %=  st
      act-queue    (skim-act proposal-id act-queue.st)
      in-flight    (~(put by in-flight.st) proposal-id dispatching)
    ==
  =/  eff=effect-intent:mg  u.eff-unit
  =/  sum=@t
    (rap 3 (scot %p grantee.p) ' mutating act ' tool.p ' APPROVED by principal; dispatch in flight under lease ' lease-id.p ~)
  :*  st2  ~[(rcpt %act-dispatching %principal lease-id.p grantee.p tool.p sum)]  ~[eff]  %.y
  ==
::  principal rejects a queued moon act -> dropped, no effect.
++  apply-reject-moon-act
  |=  [st=warden-state:mg proposal-id=@t reason=@t now=@da]
  ^-  transition:mg
  =/  found  (find-act proposal-id act-queue.st)
  ?~  found
    :*  st  ~[(rcpt %act-rejected %principal '' ~zod '' 'no such queued act')]  ~  %.n
    ==
  =/  p  u.found
  =/  decided=moon-act-proposal:mg  p(status %rejected, decided-at `now)
  =/  st2
    %-  bump
    %=  st
      act-queue    (skim-act proposal-id act-queue.st)
      act-history  [decided act-history.st]
    ==
  :*  st2  ~[(rcpt %act-rejected %principal lease-id.p grantee.p tool.p reason)]  ~  %.y
  ==
::  A completion signal must match all immutable routing identity carried by
::  the in-flight proposal.  Duplicate, unknown, and mismatched signals are
::  fail-closed no-ops and never manufacture an execution receipt.
++  completion-match
  |=  [p=moon-act-proposal:mg lease-id=@t tool=@t]
  ^-  ?
  ?&  =(%dispatching status.p)
      =(lease-id lease-id.p)
      =(tool tool.p)
  ==
++  apply-moon-act-ack
  |=  [st=warden-state:mg proposal-id=@t lease-id=@t tool=@t now=@da]
  ^-  transition:mg
  =/  found  (~(get by in-flight.st) proposal-id)
  ?~  found
    :*  st  ~[(rcpt %act-ack-refused %warden lease-id ~zod tool 'unknown or duplicate success acknowledgement')]  ~  %.n
    ==
  =/  p  u.found
  ?.  (completion-match p lease-id tool)
    :*  st  ~[(rcpt %act-ack-refused %warden lease-id grantee.p tool 'mismatched success acknowledgement')]  ~  %.n
    ==
  =/  done=moon-act-proposal:mg  p(status %executed, decided-at `now)
  =/  st2
    %-  bump
    %=  st
      in-flight    (~(del by in-flight.st) proposal-id)
      act-history  [done act-history.st]
    ==
  =/  sum=@t
    (rap 3 'dispatch ' proposal-id ' for ' tool.p ' acknowledged successful' ~)
  :*  st2  ~[(rcpt %act-executed %warden lease-id.p grantee.p tool.p sum)]  ~  %.y
  ==
++  apply-moon-act-nack
  |=  [st=warden-state:mg proposal-id=@t lease-id=@t tool=@t reason=@t now=@da]
  ^-  transition:mg
  =/  found  (~(get by in-flight.st) proposal-id)
  ?~  found
    :*  st  ~[(rcpt %act-ack-refused %warden lease-id ~zod tool 'unknown or duplicate failure acknowledgement')]  ~  %.n
    ==
  =/  p  u.found
  ?.  (completion-match p lease-id tool)
    :*  st  ~[(rcpt %act-ack-refused %warden lease-id grantee.p tool 'mismatched failure acknowledgement')]  ~  %.n
    ==
  =/  done=moon-act-proposal:mg  p(status %failed, decided-at `now)
  =/  st2
    %-  bump
    %=  st
      in-flight    (~(del by in-flight.st) proposal-id)
      act-history  [done act-history.st]
    ==
  =/  sum=@t
    (rap 3 'dispatch ' proposal-id ' for ' tool.p ' failed: ' reason ~)
  :*  st2  ~[(rcpt %act-failed %warden lease-id.p grantee.p tool.p sum)]  ~  %.y
  ==
++  find-act
  |=  [pid=@t q=(list moon-act-proposal:mg)]
  ^-  (unit moon-act-proposal:mg)
  ?~  q  ~
  ?:  =(pid proposal-id.i.q)  `i.q
  $(q t.q)
++  skim-act
  |=  [pid=@t q=(list moon-act-proposal:mg)]
  ^-  (list moon-act-proposal:mg)
  (skip q |=(p=moon-act-proposal:mg =(pid proposal-id.p)))
--
