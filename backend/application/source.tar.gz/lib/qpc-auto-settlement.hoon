::  Resolve ordinary work atomically before later work can change its source.
::  Reader gates are native canonical reads in production, fixtures in proofs.
/+  obs=qpc-observation, q=qpc-native-outcome, outcomes=qpc-outcome-store,
    settlement=qpc-work-settlement, pool=qpc-native-pool,
    accept=native-coding-accept
|%
+$  check-reader
  $-([b=bowl:gall in=input:pool m=manifest:obs f=frame:obs cs=cases:q call=@t] (each linked:q @tas))
+$  work-reader
  $-([b=bowl:gall required=(set @ux) m=manifest:obs f=frame:obs cs=cases:q v=linked:q] (each receipt:settlement @tas))
+$  change
  [checked=state:outcomes settled=state:settlement facts=(list *) reason=(unit @tas)]
++  trigger
  ::  Callback contents choose a session to inspect; they never supply truth.
  |=  [our=@p src=@p =mark =vase]
  ^-  (unit @ux)
  ?.  &(=(our src) =(%noun mark))  ~
  ?:  ?=([%native-coding-action-v1 %run @] q.vase)  `+.+.q.vase
  =/  parsed  ((soft ,[%native-coding-candidate-status-v1 candidate=@ux record=record:accept]) q.vase)
  ?~  parsed  ~
  ?.  ?=(?(%applied %refused) stage.record.u.parsed)  ~
  `session.context.candidate.record.u.parsed
++  latest
  |=  [held=state:obs session=@ux]
  ^-  (unit frame:obs)
  =/  rows  ~(val by frames.held)
  =|  found=(unit frame:obs)
  |-  ^-  (unit frame:obs)
  ?~  rows  found
  =/  f=frame:obs  i.rows
  ?.  =(session session.work.f)  $(rows t.rows)
  ::  V2 read-only provenance has no proposal ordinal of its own. Never
  ::  confuse it with a sample or let an ordinal tie hide a genuine gap.
  ?:  ?=(%outside -.result.f)  $(rows t.rows)
  ?:  ?~(found %.y (gth ordinal.f ordinal.u.found))
    $(rows t.rows, found `f)
  $(rows t.rows)
++  finish
  |=  $:  b=bowl:gall  snapshot=input:pool  observed=state:obs
          checked=state:outcomes  settled=state:settlement  required=(set @ux)
          check-read=check-reader  work-read=work-reader
      ==
  ^-  change
  =/  unchanged=change  [checked settled ~ ~]
  =/  found  (latest observed id.session.entry.snapshot)
  ?~  found  unchanged
  =/  f=frame:obs  u.found
  ?:  (~(has by settled) id.f)  unchanged
  ?.  &(=(our.b src.b) =(our.b owner.f))
    unchanged(reason `%qpc-auto-owner-mismatch)
  ?:  (~(has in required) session.work.f)
    unchanged(reason `%qpc-settlement-selection-required)
  ?.  ?=(%& -.result.f)  unchanged
  ?.  =(1 (lent p.result.f))
    unchanged(reason `%qpc-settlement-selection-required)
  =/  row  (snag 0 p.result.f)
  =/  manifest  (~(get by manifests.observed) manifest.work.f)
  =/  cases  (~(get by cases.checked) case-set.work.f)
  ?.  &(?=(^ manifest) ?=(^ cases))
    unchanged(reason `%qpc-auto-definition-missing)
  =/  prior  (~(get by outcomes.checked) [id.f call.row])
  =/  linked=(each linked:q @tas)
    ?~  prior  (check-read b snapshot u.manifest f u.cases call.row)
    [%& u.prior]
  ?:  ?=(%| -.linked)  unchanged(reason `p.linked)
  =/  completed  (work-read b required u.manifest f u.cases p.linked)
  ?:  ?=(%| -.completed)  unchanged(reason `p.completed)
  ::  Neither store changes unless both canonical joins and both retention
  ::  checks succeed. An early unknown check cannot become a frozen outcome.
  =/  checked-next  (retain:outcomes observed checked p.linked)
  ?:  ?=(%| -.checked-next)  unchanged(reason `p.checked-next)
  =/  settled-next  (retain:settlement observed p.checked-next settled p.completed)
  ?:  ?=(%| -.settled-next)  unchanged(reason `p.settled-next)
  =/  facts=(list *)  ?~(prior ~[p.linked p.completed] ~[p.completed])
  [p.checked-next p.settled-next facts ~]
--
