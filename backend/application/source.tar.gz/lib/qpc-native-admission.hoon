::  Candidate eligibility from exact assessment diagnostics. No effect cards.
::  The native reader supplies canonical assessment, law/source/grant and a
::  committed Viki request marker; consistency alone authenticates none of them.
/-  nc=native-coding
/+  a=qpc-native-assessment, d=qpc-native-decision,
    outcomes=qpc-native-outcome, accept=native-coding-accept,
    sessions=native-coding-session, pool=qpc-native-pool,
    ct=cantrip-native-coding-contract
|%
+$  marker
  [%qpc-admission-request-v1 opening=@ux session=@ux event=record:sessions]
+$  receipt
  $:  %qpc-native-admission-v1  request=marker  assessment=@ux
      at=@da  offered=(list offered:d)
  ==
++  required
  |=  cs=cases:outcomes
  ^-  (list @tas)
  =/  names=(list @tas)  [%compile (turn rows.cs |=(c=case:outcomes proposition.c))]
  =/  constraints=(list @tas)  ~[%project-constraints]
  (weld names constraints)
++  outcome
  |=  [verdict=?(%pass %fail %unknown) evidence=@ux]
  ^-  [verdict=?(%pass %fail %unknown) evidence=@ux]
  [verdict ?:(=(%unknown verdict) 0x0 evidence)]
++  combine
  |=  verdicts=(list ?(%pass %fail %unknown))
  ^-  ?(%pass %fail %unknown)
  ?:  (lien verdicts |=(v=?(%pass %fail %unknown) =(%fail v)))  %fail
  ?:  (lien verdicts |=(v=?(%pass %fail %unknown) =(%unknown v)))  %unknown
  %pass
++  checks
  ::  %compile means all compilation diagnostics. %project-constraints means
  ::  all actual project checks, including targets absent from the objectives
  ::  and additional changed Hoon files. Neither can hide an extra failure.
  |=  [p=project:nc c=candidate:nc cs=cases:outcomes r=report:accept]
  ^-  (each (list check:d) @tas)
  ?.  (report-valid:accept p c r)  [%| %qpc-admission-report-invalid]
  =/  names=(list @tas)  (required cs)
  ?.  &((lte (lent names) 16) =((lent names) ~(wyt in (silt names))))
    [%| %qpc-admission-requirements-invalid]
  =/  targets=(list target-result:accept)  targets.r
  =/  compiles=(list ?(%pass %fail %unknown))  ~
  =/  constraints=(list ?(%pass %fail %unknown))  ~
  =/  aggregated=(each [compiles=(list ?(%pass %fail %unknown)) constraints=(list ?(%pass %fail %unknown))] @tas)
    |-  ^-  (each [compiles=(list ?(%pass %fail %unknown)) constraints=(list ?(%pass %fail %unknown))] @tas)
    ?~  targets  [%& [compiles constraints]]
    =/  t=target-result:accept  i.targets
    ?~  diagnostics.t  [%| %qpc-admission-compile-missing]
    =/  compiled=diagnostic:nc  i.diagnostics.t
    ?.  &(=(%compile name.compiled) =(?:(passed.compiled 1 0) (lent artifacts.compiled)))
      [%| %qpc-admission-compile-artifacts]
    =/  verdict=?(%pass %fail %unknown)  ?:(passed.compiled %pass %fail)
    =/  rest=(list [name=@tas expression=@t])  checks.target.t
    =/  more=(each (list ?(%pass %fail %unknown)) @tas)
      |-  ^-  (each (list ?(%pass %fail %unknown)) @tas)
      ?~  rest  [%& constraints]
      =/  got  (assess:outcomes [name.i.rest target.t name.i.rest] revision.staging.r t)
      ?:  ?=(%| -.got)  [%| p.got]
      $(rest t.rest, constraints [verdict.p.got constraints])
    ?:  ?=(%| -.more)  [%| p.more]
    $(targets t.targets, compiles [verdict compiles], constraints [verdict p.more])
  ?:  ?=(%| -.aggregated)  [%| p.aggregated]
  =/  todo=(list case:outcomes)  rows.cs
  =/  named=(list check:d)  ~
  |-  ^-  (each (list check:d) @tas)
  ?~  todo
    =/  evidence=@ux  (digest:accept r)
    =/  compiled=check:d  [%compile (outcome (combine compiles.p.aggregated) evidence)]
    =/  complete=check:d  [%project-constraints (outcome (combine constraints.p.aggregated) evidence)]
    [%& [compiled (weld (flop named) ~[complete])]]
  =/  found=(list target-result:accept)
    (skim targets.r |=(t=target-result:accept =(target.i.todo target.t)))
  ?.  =(1 (lent found))  [%| %qpc-admission-objective-target-missing]
  =/  got  (assess:outcomes i.todo revision.staging.r (snag 0 found))
  ?:  ?=(%| -.got)  [%| p.got]
  $(todo t.todo, named [[proposition.i.todo (outcome verdict.p.got diagnostic.p.got)] named])
++  marker-valid
  |=  [m=marker r=record:a e=entry:sessions]
  ^-  ?
  =/  f=opening:d  opening.binding.r
  =/  v=record:sessions  event.m
  ?&  (chain:pool e)  =(session.f session.m)  =(session.m id.session.e)
      =(owner.f owner.session.e)  =(source.f working.session.e)
      =(configuration.f configuration.e)  =(%paused phase.e)
      ?=(~ pending.e)  =(opening.m (digest:d f))
      =(body.v [%status %paused %qpc-admission-requested])
      (gth sequence.v sealed.binding.r)
      (lte (met 0 sequence.v) 64)
      (lien records.e |=(item=record:sessions =(item v)))
      %+  lien  records.e
      |=  item=record:sessions
      &(=(id.item through.pool.binding.r) =(sequence.item sealed.binding.r))
  ==
++  prepare
  ::  Every candidate is represented. Unfinished assessments defer the whole
  ::  pool; terminal refusal/unknown is retained as ineligible, never omitted.
  |=  [our=@p at=@da m=marker v=view:a r=record:a cs=cases:outcomes e=entry:sessions]
  ^-  (each receipt @tas)
  ?.  (valid:a our [%qpc-native-assessments-v1 (malt ~[[session.m r]]) ~])
    [%| %qpc-admission-assessment-invalid]
  ?.  =(binding.r binding.v)  [%| %qpc-admission-binding-changed]
  ?.  =(required.opening.binding.r (required cs))
    [%| %qpc-admission-project-constraints-required]
  ?.  (marker-valid m r e)  [%| %qpc-admission-marker-invalid]
  =/  current  (begin:a empty:a our our at v)
  ?:  ?=(%| -.current)  [%| p.current]
  =/  rows=(list row:a)  ~(val by rows.r)
  =/  offered=(list offered:d)  ~
  |-  ^-  (each receipt @tas)
  ?~  rows
    [%& [%qpc-native-admission-v1 m (digest:a r) at (flop offered)]]
  =/  row=row:a  i.rows
  ?.  =(`tool.row (~(get by records.tools.v) (key:ct request.tool.row)))
    [%| %qpc-admission-tool-changed]
  ?.  ?=(?(%checked %refused %unknown) phase.row)
    [%| %qpc-admission-assessment-unfinished]
  =/  judged=(each (list check:d) @tas)
    ?:  !=(%checked phase.row)
      [%& (turn (required cs) |=(name=@tas ^-(check:d [name [%unknown 0x0]])))]
    ?~  report.row  [%| %qpc-admission-report-missing]
    (checks project.grant.scope.binding.r candidate.row cs u.report.row)
  ?:  ?=(%| -.judged)  [%| p.judged]
  =/  receipt=admission-receipt:d
    [0x0 opening.m id.candidate.row (effect:d candidate.row) source.opening.binding.r authority.opening.binding.r sequence.event.m p.judged]
  =.  receipt  receipt(id (digest:d receipt))
  $(rows t.rows, offered [[tool.row receipt] offered])
--
