::  Items 43, 45, 46, 49 and 50: durable project memory that a returning or
::  incoming model can use without being misled.
::
::  The operator's memory (lib/memory-tier: one Graf fact per version, canon
::  only by the operator's ruling) gains two owner-written facts:
::    [%operator-memory-standing %1 name hash standing by at]
::        what this exact version claims to be: %fact, %hypothesis or
::        %question. Editing the memory makes it unlabelled again.
::    [%operator-memory-supersedes %1 new old reason by at]
::        a later decision replaces an earlier one; both stay readable.
::    [%operator-memory-supersedes-retracted %1 new old by at]
::        that link was a mistake: it stops counting from then on. The link
::        and its retraction both stay in the record; linking again later works.
::  Retrieval states each memory's standing (45): %ruling (canon), %fact,
::  %hypothesis, %question, or %unlabelled; refused memories are never served.
::  A superseded memory names its successor and leaves current packets (43).
::  A context packet (46) and a handoff (50) are bounded in bytes and say what
::  they left out; the account since last work (49) lists what changed after
::  a given moment or after that agent's last recorded turn.
/+  mt=memory-tier
|%
+$  standing  ?(%ruling %fact %hypothesis %question %unlabelled)
+$  label  [name=@t hash=@t standing=?(%fact %hypothesis %question) by=@p at=@da]
+$  link  [new=@t old=@t reason=@t by=@p at=@da]
+$  retraction  [new=@t old=@t by=@p at=@da]
+$  item  [m=mem:mt hash=@t tier=tier:mt =standing superseded=(unit @t)]
++  packet-max  16.000
++  labels
  |=  [our=@p now=@da]
  ^-  (list label)
  %+  murn  (facts-of:mt our now %operator-memory-standing)
  |=(f=* ?.(?=([%operator-memory-standing %1 *] f) ~ ((soft label) +>.f)))
++  links
  ::  The links that stand now: every link not retracted after it was made.
  |=  [our=@p now=@da]
  ^-  (list link)
  %+  effective
    %+  murn  (facts-of:mt our now %operator-memory-supersedes)
    |=(f=* ?.(?=([%operator-memory-supersedes %1 *] f) ~ ((soft link) +>.f)))
  %+  murn  (facts-of:mt our now %operator-memory-supersedes-retracted)
  |=(f=* ?.(?=([%operator-memory-supersedes-retracted %1 *] f) ~ ((soft retraction) +>.f)))
++  effective
  ::  A link stands unless a later retraction names the same pair.
  |=  [lk=(list link) rs=(list retraction)]
  ^-  (list link)
  %+  skip  lk
  |=  l=link
  (lien rs |=(r=retraction &(=(new.l new.r) =(old.l old.r) (gth at.r at.l))))
::  ---  pure law
++  standing-of
  ::  A ruling only by canon; otherwise the newest label on exactly this version.
  |=  [ls=(list label) name=@t hash=@t =tier:mt]
  ^-  standing
  ?:  =(%canon tier)  %ruling
  =/  best=(unit label)
    %+  roll  ls
    |=  [l=label acc=(unit label)]
    ?.  &(=(name name.l) =(hash hash.l))  acc
    ?:  &(?=(^ acc) (gte at.u.acc at.l))  acc
    `l
  ?~(best %unlabelled standing.u.best)
++  successor
  ::  The newest live memory that supersedes this one, if any.
  |=  [lk=(list link) live=(set @t) name=@t]
  ^-  (unit @t)
  =/  best=(unit link)
    %+  roll  lk
    |=  [l=link acc=(unit link)]
    ?.  &(=(name old.l) (~(has in live) new.l) !=(new.l old.l))  acc
    ?:  &(?=(^ acc) (gte at.u.acc at.l))  acc
    `l
  (bind best |=(l=link new.l))
++  items
  ::  Every served memory with its standing; refused memories are dropped.
  |=  [tiered=(list [m=mem:mt hash=@t =tier:mt]) ls=(list label) lk=(list link)]
  ^-  (list item)
  =/  live=(set @t)  (silt (turn tiered |=([m=mem:mt h=@t t=tier:mt] name.m)))
  %+  murn  tiered
  |=  [m=mem:mt h=@t t=tier:mt]
  ?:  =(%refused t)  ~
  `[m h t (standing-of ls name.m h t) (successor lk live name.m)]
++  rank
  |=  s=standing
  ^-  @ud
  ?-(s %ruling 0, %fact 1, %question 2, %hypothesis 3, %unlabelled 4)
++  words
  |=  topic=@t
  ^-  (list @t)
  (skip (turn (rash topic (more ace (star ;~(less ace prn)))) crip) |=(w=@t =(0 (met 3 w))))
++  about
  ::  Rulings always; otherwise any topic word in the name or description.
  |=  [ws=(list @t) i=item]
  ^-  ?
  ?:  =(%ruling standing.i)  %.y
  ?:  =(~ ws)  %.y
  =/  hay=tape  (cass (trip (rap 3 ~[name.m.i ' ' description.m.i])))
  (lien ws |=(w=@t ?=(^ (find (cass (trip w)) hay))))
++  packet
  ::  Current memories on a topic, rulings first, within a byte budget.
  |=  [is=(list item) topic=@t budget=@ud]
  ^-  [kept=(list item) left=@ud bytes=@ud]
  =/  ws  (words topic)
  =/  current
    %+  sort  (skim is |=(i=item &(?=(~ superseded.i) (about ws i))))
    |=([a=item b=item] ?:(=(standing.a standing.b) (gth at.m.a at.m.b) (lth (rank standing.a) (rank standing.b))))
  =|  kept=(list item)
  =/  used=@ud  0
  =/  left=@ud  0
  |-  ^-  [kept=(list item) left=@ud bytes=@ud]
  ?~  current  [(flop kept) left used]
  =/  size=@ud  (add 64 (met 3 (rap 3 ~[name.m.i.current description.m.i.current body.m.i.current])))
  ?:  (gth (add used size) budget)  $(current t.current, left +(left))
  $(current t.current, kept [i.current kept], used (add used size))
++  since
  ::  What changed after a moment: memory versions, rulings, labels, links.
  |=  [is=(list item) ls=(list label) lk=(list link) rs=(list ruling:mt) at=@da]
  ^-  [memories=(list item) rulings=(list ruling:mt) labels=(list label) links=(list link)]
  :^    (skim is |=(i=item (gth at.m.i at)))
      (skim rs |=(r=ruling:mt (gth at.r at)))
    (skim ls |=(l=label (gth at.l at)))
  (skim lk |=(l=link (gth at.l at)))
++  agents
  ::  Every recorded author of a turn, with its turn count and newest turn.
  ::  Turns are recorded under the model's own name (claude-opus-5-5, ...).
  |=  [our=@p now=@da]
  ^-  (map @t [turns=@ud newest=@da])
  %+  roll  (facts-of:mt our now %operator-turn)
  |=  [f=* acc=(map @t [turns=@ud newest=@da])]
  =/  t  ((soft ,[%operator-turn %1 session=* who=@t prompt=* reply=* at=@da]) f)
  ?~  t  acc
  =/  old=[turns=@ud newest=@da]  (~(gut by acc) who.u.t [0 *@da])
  (~(put by acc) who.u.t [+(turns.old) (max newest.old at.u.t)])
++  matches
  ::  An exact name, or a family: who=claude matches claude-opus-5-5.
  |=  [who=@t name=@t]
  ^-  ?
  =(who (end [3 (met 3 who)] name))
++  last-turn
  ::  The newest recorded turn of one agent or agent family, if any.
  |=  [as=(map @t [turns=@ud newest=@da]) who=@t]
  ^-  (unit @da)
  %+  roll  ~(tap by as)
  |=  [[name=@t turns=@ud newest=@da] acc=(unit @da)]
  ?.  (matches who name)  acc
  ?:  &(?=(^ acc) (gte u.acc newest))  acc
  `newest
::  ---  JSON
++  item-json
  |=  [i=item body=?]
  ^-  json
  %-  pairs:enjs:format
  %+  weld
    ^-  (list [@t json])
    :~  ['name' s+name.m.i]  ['hash' s+hash.i]  ['standing' s+standing.i]
        ['tier' s+tier.i]  ['type' s+type.m.i]  ['description' s+description.m.i]
        ['at' s+(scot %da at.m.i)]  ['supersededBy' ?~(superseded.i ~ s+u.superseded.i)]
        ['cite' s+(rap 3 ~['cite:mem/' name.m.i '/' hash.i])]
    ==
  ^-  (list [@t json])
  ?.(body ~ ~[['body' s+body.m.i]])
++  view
  ::  GET /apps/pataphor-native/coding/memory?view=...&topic=...&bytes=...&who=...&since=...
  |=  [our=@p src=@p now=@da url=@t]
  ^-  (unit json)
  =/  prefix=@t  '/apps/pataphor-native/coding/memory'
  =/  n=@ud  (met 3 prefix)
  ?.  =(prefix (end [3 n] url))  ~
  =/  rest=@t  (rsh [3 n] url)
  ?.  |(=('' rest) =('?' (end [3 1] rest)))  ~
  ?.  =(our src)  `(pairs:enjs:format ~[['schema' s+'operator-memory-view-v1'] ['error' s+'owner-required']])
  =/  q=(map @t @t)
    ?:  =('' rest)  ~
    %-  malt
    %+  fall
      %+  rush  (rsh [3 1] rest)
      (more pam ;~(plug (cook crip (star ;~(less tis pam prn))) ;~(pfix tis (cook crip (star ;~(less pam prn))))))
    ~
  =/  get  |=(k=@t (~(gut by q) k ''))
  =/  ls  (labels our now)
  =/  lk  (links our now)
  =/  is  (items (tiered:mt our now) ls lk)
  =/  topic=@t  (crip (turn (trip (get 'topic')) |=(c=@t ?:(=('+' c) ' ' c))))
  ::  Plain digits (6000), as a browser or script writes them.
  =/  budget=@ud  (min packet-max (fall (rush (get 'bytes') dem) packet-max))
  =/  who=@t  (get 'who')
  =/  as  (agents our now)
  =/  from=(unit @da)
    ?^  (slaw %da (get 'since'))  (slaw %da (get 'since'))
    ?:  =('' who)  ~
    (last-turn as who)
  =/  kind=@t  ?:(=('' (get 'view')) 'memories' (get 'view'))
  =/  count  |=(s=standing (numb:enjs:format (lent (skim is |=(i=item =(s standing.i))))))
  =/  head=(list [@t json])
    :~  ['schema' s+'operator-memory-view-v1']  ['view' s+kind]  ['observedAt' s+(scot %da now)]
        :-  'standings'
        %-  pairs:enjs:format
        :~  ['ruling' (count %ruling)]  ['fact' (count %fact)]  ['hypothesis' (count %hypothesis)]
            ['question' (count %question)]  ['unlabelled' (count %unlabelled)]
        ==
        :-  'agents'
        :-  %a
        %+  turn  (scag 32 (sort ~(tap by as) |=([a=[@t @ud newest=@da] b=[@t @ud newest=@da]] (gth newest.a newest.b))))
        |=  [name=@t turns=@ud newest=@da]
        (pairs:enjs:format ~[['who' s+name] ['turns' (numb:enjs:format turns)] ['newest' s+(scot %da newest)]])
    ==
  =/  the-packet
    |=  b=@ud
    =/  p  (packet is topic b)
    %-  pairs:enjs:format
    :~  ['topic' s+topic]  ['budget' (numb:enjs:format b)]  ['bytes' (numb:enjs:format bytes.p)]
        ['leftOut' (numb:enjs:format left.p)]  ['items' a+(turn kept.p |=(i=item (item-json i %.y)))]
    ==
  =/  the-since
    ?~  from  ~
    =/  s  (since is ls lk (rulings:mt our now) u.from)
    %-  pairs:enjs:format
    :~  ['since' s+(scot %da u.from)]  ['who' s+who]
        ['memories' a+(turn (scag 64 memories.s) |=(i=item (item-json i %.n)))]
        ['moreMemories' (numb:enjs:format (sub (lent memories.s) (min 64 (lent memories.s))))]
        ['rulings' a+(turn rulings.s |=(r=ruling:mt (pairs:enjs:format ~[['name' s+name.r] ['verdict' s+verdict.r] ['at' s+(scot %da at.r)]])))]
        ['labels' a+(turn labels.s |=(l=label (pairs:enjs:format ~[['name' s+name.l] ['standing' s+standing.l] ['at' s+(scot %da at.l)]])))]
        ['supersessions' a+(turn links.s |=(l=link (pairs:enjs:format ~[['new' s+new.l] ['old' s+old.l] ['reason' s+reason.l] ['at' s+(scot %da at.l)]])))]
    ==
  :-  ~
  %-  pairs:enjs:format
  %+  weld  head
  ^-  (list [@t json])
  ?:  =('packet' kind)  ~[['packet' (the-packet budget)]]
  ?:  =('since' kind)  ~[['account' the-since]]
  ?:  =('handoff' kind)
    ::  The account first (small), then the packet within what is left.
    =/  account  the-since
    =/  used=@ud  (met 3 (en:json:html account))
    =/  questions  (skim is |=(i=item &(=(%question standing.i) ?=(~ superseded.i))))
    :~  ['account' account]  ['packet' (the-packet (sub budget (min budget used)))]
        ['openQuestions' a+(turn (scag 16 questions) |=(i=item (item-json i %.n)))]
    ==
  :~  :-  'memories'
      a+(turn is |=(i=item (item-json i %.n)))
  ==
::  ---  owner writes (POST /apps/pataphor-native/coding/memory)
++  write
  ::  A label on a live memory's current version, or a supersession between
  ::  two live memories. Refuses as a whole; returns the one Graf fact.
  |=  [our=@p now=@da raw=@t]
  ^-  (each * @tas)
  =/  v  (de:json:html raw)
  ?~  v  [%| %memory-write-invalid]
  ?.  ?=(%o -.u.v)  [%| %memory-write-invalid]
  =/  get  |=(k=@t =/(x (~(get by p.u.v) k) ?~(x '' ?.(?=(%s -.u.x) '' p.u.x))))
  =/  live=(map @t mem:mt)  (malt (turn (live:mt our now) |=(m=mem:mt [name.m m])))
  =/  kind  (get 'kind')
  ?:  =('label' kind)
    =/  m  (~(get by live) (get 'name'))
    ?~  m  [%| %memory-missing]
    ?.  =((get 'hash') (hash-of:mt body.u.m))  [%| %memory-version-changed]
    =/  s=@t  (get 'standing')
    ?.  ?=(?(%fact %hypothesis %question) s)  [%| %memory-standing-invalid]
    [%& [%operator-memory-standing %1 name.u.m (get 'hash') s our now]]
  ?:  =('supersede' kind)
    =/  new  (get 'new')
    =/  old  (get 'old')
    ?.  &((~(has by live) new) (~(has by live) old) !=(new old))  [%| %memory-missing]
    =/  why  (get 'reason')
    ?.  &(!=(0 (met 3 why)) (lte (met 3 why) 1.024))  [%| %memory-reason-required]
    [%& [%operator-memory-supersedes %1 new old why our now]]
  ?:  =('unsupersede' kind)
    =/  new  (get 'new')
    =/  old  (get 'old')
    ?.  (lien (links our now) |=(l=link &(=(new new.l) =(old old.l))))  [%| %memory-not-superseded]
    [%& [%operator-memory-supersedes-retracted %1 new old our now]]
  [%| %memory-write-invalid]
--
