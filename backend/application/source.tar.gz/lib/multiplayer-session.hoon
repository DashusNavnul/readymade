::  /lib/multiplayer-session
::
::  Pure validation and identity law for the Urbit session mailbox.
::
/-  ms=multiplayer-session
|%
++  max-inbox  `@ud`512
++  max-outbox  `@ud`512
++  max-text-bytes  `@ud`16.384
++  max-provider-envelope-bytes  `@ud`65.536
++  max-label-bytes  `@ud`256
++  text-limit
  ::  This transports an opaque encoded receipt, not model text authority.
  ::  The executor still validates correlation, task opt-in and content caps.
  |=  body=message-body:ms
  ^-  @ud
  ?.  &(=(%response kind.body) ?=(^ reply-to.body) =('0w' (end [3 2] text.body)))
    max-text-bytes
  max-provider-envelope-bytes
++  message-digest
  |=  body=message-body:ms
  ^-  digest:ms
  `@ux`(shax (jam [%multiplayer-session-message-v1 body]))
++  make-message
  |=  body=message-body:ms
  ^-  message:ms
  [body (message-digest body)]
++  inbox-query-matches
  |=  [query=inbox-query:ms candidate=message:ms]
  ^-  ?
  ?&  =(session.query recipient-session.body.candidate)
      ?~(sender.query %.y =(u.sender.query sender.body.candidate))
      ?~(thread.query %.y =(u.thread.query thread.body.candidate))
      ?~(reply-to.query %.y =(u.reply-to.query reply-to.body.candidate))
  ==
++  latest-inbox-match
  |=  [box=(map digest:ms message:ms) query=inbox-query:ms]
  ^-  (unit message:ms)
  =/  matches=(list message:ms)
    %+  skim  ~(val by box)
    |=(candidate=message:ms (inbox-query-matches query candidate))
  %+  roll  matches
  |=  [candidate=message:ms current=(unit message:ms)]
  ?~  current  `candidate
  ?:  (gth sent-at.body.candidate sent-at.body.u.current)  `candidate
  ?:  ?&  =(sent-at.body.candidate sent-at.body.u.current)
          (gth digest.candidate digest.u.current)
      ==
    `candidate
  current
++  message-valid
  |=  item=message:ms
  ^-  ?
  ?&  =(%multiplayer-session-message-v1 -.body.item)
      !=(0 thread.body.item)
      !=(sender.body.item recipient.body.item)
      !=(0 sender-session.body.item)
      !=(0 recipient-session.body.item)
      !=(0 text.body.item)
      !=(0 sent-at.body.item)
      (lte (met 3 thread.body.item) max-label-bytes)
      (lte (met 3 sender-session.body.item) max-label-bytes)
      (lte (met 3 recipient-session.body.item) max-label-bytes)
      (lte (met 3 text.body.item) (text-limit body.item))
      =((message-digest body.item) digest.item)
  ==
++  accepted-result
  |=  [id=digest:ms at=@da]
  ^-  delivery-result:ms
  [%accepted id at]
++  refused-result
  |=  [id=digest:ms reason=refusal:ms at=@da]
  ^-  delivery-result:ms
  [%refused id reason at]
++  result-id
  |=  result=delivery-result:ms
  ^-  digest:ms
  ?-(-.result %accepted id.result, %refused id.result)
::  IS THERE ROOM -- a question, separate from making room.
::
::  multiplayer-session-relay answers exactly this with +inbound-room and lets
::  its agent decide, and when the answer is no the sender is told %inbox-full.
::  That refusal is declared in the shared union here too and, until this arm
::  existed, nothing in this lane could emit it: +make-inbox-room evicts and
::  cannot refuse, so the agent had no way to ask before committing.
::
::  Added rather than changing +make-inbox-room's return type, which is what
::  made this look like a shared-law change for three cycles. It is not one:
::  the existing arm is untouched and any other consumer keeps its behaviour.
++  inbox-room
  |=  box=(map digest:ms message:ms)
  ^-  ?
  (lth ~(wyt by box) max-inbox)
++  make-inbox-room
  |=  box=(map digest:ms message:ms)
  ^-  (map digest:ms message:ms)
  ?:  (lth ~(wyt by box) max-inbox)  box
  =/  oldest=(unit message:ms)
    %+  roll  ~(val by box)
    |=  [candidate=message:ms current=(unit message:ms)]
    ?~  current  `candidate
    ?:  (lth sent-at.body.candidate sent-at.body.u.current)  `candidate
    current
  ?~  oldest  box
  (~(del by box) digest.u.oldest)
++  make-outbox-room
  |=  box=(map digest:ms outbound:ms)
  ^-  (unit (map digest:ms outbound:ms))
  ?:  (lth ~(wyt by box) max-outbox)  `box
  =/  settled=(list outbound:ms)
    %+  skim  ~(val by box)
    |=(candidate=outbound:ms ?=(^ result.candidate))
  =/  oldest=(unit outbound:ms)
    %+  roll  settled
    |=  [candidate=outbound:ms current=(unit outbound:ms)]
    ?~  current  `candidate
    ?:  (lth sent-at.body.item.candidate sent-at.body.item.u.current)  `candidate
    current
  ?~  oldest  ~
  `(~(del by box) digest.item.u.oldest)
--
