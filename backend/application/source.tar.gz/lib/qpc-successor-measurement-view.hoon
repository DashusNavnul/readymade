::  Read-only successor history. Retained readings do not grant admission;
::  the campaign's current-source reader remains the sole availability gate.
/+  history=qpc-successor-history, window=qpc-successor-window,
    view=qpc-measurement-view, gate=qpc-session-gate
|%
+$  snapshot  [held=state:history refresh=(unit @da)]
++  read
  |=  [inner=agent:gall b=bowl:gall]
  ^-  (unit snapshot)
  ?.  =(our.b src.b)  ~
  =/  ag  ~(. inner b)
  =/  raw  (payload:gate (on-peek:ag /x/qpc/instrument/successors))
  ?~  raw  ~
  =/  parsed
    ((soft ,[%qpc-instrument-successors-v1 held=state:history refresh=(unit @da)]) u.raw)
  ?~  parsed  ~
  `[held.u.parsed refresh.u.parsed]
++  reading
  |=  r=reading:window
  ^-  json
  %-  pairs:enjs:format
  :~  ['id' [%s (scot %ux id.r)]]
      ['epoch' [%s (scot %ux epoch.r)]]
      ['generation' (numb:enjs:format generation.r)]
      ['previous' ?~(previous.r [%~] [%s (scot %ux u.previous.r)])]
      ['source' [%s (scot %ux source.r)]]
      ['tensor' (covariance:view [denominator.tensor.r entries.tensor.r])]
      ['attentionSquared' (ratio:view attention.tensor.r)]
      ['shape' ?~(shape.r [%~] (pairs:enjs:format ~[['denominator' [%s (decimal:view denominator.u.shape.r)]] ['state' (matrix:view state.u.shape.r)] ['update' (matrix:view update.u.shape.r)]]))]
      ['referenceMixedLaw' [%b reference-mixed-law.r]]
      ['liveMixedLaw' [%b live-mixed-law.r]]
      ['comparison' [%a (turn comparison.r comparison:view)]]
      ['live' [%a (turn live.r point:view)]]
  ==
++  stream
  |=  [s=state:window pending=@ud refresh=(unit @da)]
  ^-  json
  =/  events=(list event:window)
    (sort ~(val by events.s) |=([a=event:window b=event:window] (lth order.a order.b)))
  =/  archive=(list [generation=@ud value=reading:window])
    (sort ~(tap by readings.s) |=([a=[generation=@ud value=reading:window] b=[generation=@ud value=reading:window]] (lth generation.a generation.b)))
  %-  pairs:enjs:format
  :~  ['instrument' [%s (scot %ux instrument.binding.s)]]
      ['stream' [%s (scot %ux stream.binding.s)]]
      ['manifest' [%s (scot %ux manifest.binding.s)]]
      ['policy' [%s (scot %tas policy.binding.s)]]
      ['status' [%s ?^(refresh 'refresh-pending' ?:((gth pending 0) 'unresolved' ?~(measured.s 'collecting' 'retained')))]]
      ['referenceCount' (numb:enjs:format ?~(reference.s (lent buffer.s) (lent reference.u.reference.s)))]
      ['liveCount' (numb:enjs:format ?~(reference.s 0 ?~(measured.s (lent buffer.s) (lent live.u.measured.s))))]
      ['unconsumed' (numb:enjs:format pending)]
      ['gaps' (numb:enjs:format (lent (skim events |=(e=event:window ?=(%gap -.body.e)))))]
      ['outside' (numb:enjs:format (lent (skim events |=(e=event:window ?=(%outside -.body.e)))))]
      ['reference' ?~(reference.s [%~] (pairs:enjs:format ~[['id' [%s (scot %ux id.u.reference.s)]] ['covariance' (covariance:view covariance.u.reference.s)] ['members' [%a (turn reference.u.reference.s point:view)]]]))]
      ['reading' ?~(measured.s [%~] (reading u.measured.s))]
      ['readings' [%a (turn archive |=([generation=@ud value=reading:window] (reading value)))]]
      ['buffer' [%a (turn buffer.s point:view)]]
      ['events' [%a (turn events event:view)]]
  ==
++  render
  |=  s=(unit snapshot)
  ^-  json
  =/  streams=(list json)
    ?~  s  ~
    %+  turn  ~(val by windows.held.u.s)
    |=  w=state:window
    (stream w (pending-count:history held.u.s stream.binding.w) refresh.u.s)
  %-  pairs:enjs:format
  :~  ['schema' [%s 'qpc-successor-measurement-view-v1']]
      ['status' [%s ?~(s 'unavailable' ?^(fault.held.u.s 'fault' 'available'))]]
      ['width' (numb:enjs:format 16)]
      ['requiredPerBlock' (numb:enjs:format 17)]
      ['coordinates' [%a ~[[%s 'compatibility'] [%s 'intended-behavior']]]]
      ['confidenceScale' (numb:enjs:format 1.000.000)]
      ['policy' [%s 'first-17-reference-successive-disjoint-17-live']]
      ['arithmetic' [%s 'qpc-ct-update-v1']]
      ['availability' [%s 'Retained history only; current source and native campaign gates determine admission.']]
      ['queueTotal' ?~(s [%~] (numb:enjs:format (lent queue.held.u.s)))]
      ['queueConsumed' ?~(s [%~] (numb:enjs:format (consumed-count:history held.u.s)))]
      ['queueContiguousPrefix' ?~(s [%~] (numb:enjs:format cursor.held.u.s))]
      ['unconsumed' ?~(s [%~] (numb:enjs:format (sub (lent queue.held.u.s) (consumed-count:history held.u.s))))]
      ['fault' ?~(s [%~] ?~(fault.held.u.s [%~] [%s (scot %tas u.fault.held.u.s)]))]
      ['refresh' ?~(s [%~] ?~(refresh.u.s [%~] [%s (scot %da u.refresh.u.s)]))]
      ['streams' [%a streams]]
  ==
--
