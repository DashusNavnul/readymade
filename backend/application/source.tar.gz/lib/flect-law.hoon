::  /lib/flect-law.hoon
::
::  Law that fits an act by geometry (the first radical use).
::
::  A law is a list of demands at axes; an act is a grown shape
::  (/lib/flect).  The act fits when every demand is met at its axis.
::  A Hoon TYPE is a law: +law-of walks a type the way +grow walks a
::  noun, so a constant becomes an exact flect, a @p slot demands a
::  ship, a fork of constants demands one of them, and a wildcard
::  demands nothing.  Admission is then a pure function of two shapes,
::  the same on every ship; the verdict names every miss by axis, and
::  the receipt (law tag, act tag, verdict) is recomputable by anyone
::  holding the two nouns.
::
/+  flect
|%
+$  demand
  $%  [%any ~]                            ::  anything may stand here
      [%kind =kind:flect]                 ::  a word, a tag or a ship
      [%same fs=(list flect:flect)]       ::  exactly these flects (a constant)
      [%one fs=(list (list flect:flect))] ::  one of these constants
      [%run gate=*]                       ::  a law that computes: a gate
  ==                                      ::  called with [act-noun env]; 0 fits
+$  rule     [axis=@ud =demand]
+$  law      (list rule)
+$  miss     [axis=@ud =demand have=(unit grown:flect) got=(unit *)]
+$  verdict  [fit=? misses=(list miss)]
+$  receipt  [law=flect:flect act=flect:flect =verdict]
::  +leaf: the flects a constant atom is, by aura (a long constant spans several)
++  leaf
  |=  [aura=@tas a=@]
  ^-  (list flect:flect)
  ?:(=(%p aura) ~[(ship:flect a)] (letters:flect a))
::  +law-of: a type is a law
++  law-of
  |=  t=type
  ^-  law
  =/  axis=@ud  1
  |-  ^-  law
  =/  n  (norm:flect t)
  ?:  ?=([%cell *] n)
    %+  weld
      $(t p.n, axis (mul 2 axis))
    $(t q.n, axis (add 1 (mul 2 axis)))
  ?:  ?=([%atom *] n)
    ?^  q.n
      [axis %same (leaf p.n u.q.n)]~
    ?:  =(%p p.n)
      [axis %kind %ship]~
    [axis %kind %word]~
  ?:  ?=([%fork *] n)
    =/  alts=(list type)  ~(tap in p.n)
    =/  fs=(list (list flect:flect))
      |-  ^-  (list (list flect:flect))
      ?~  alts  ~
      =/  a  (norm:flect i.alts)
      ?.  ?=([%atom * ^] a)  ~
      [(leaf p.a u.q.a) $(alts t.alts)]
    ?:  =((lent fs) (lent alts))          ::  every branch a constant
      [axis %one fs]~
    [axis %any ~]~
  [axis %any ~]~
::  +at: the act's grown flect at an axis, if it has one there
++  at
  |=  [axis=@ud act=shape:flect]
  ^-  (unit grown:flect)
  |-
  ?~  act  ~
  ?:  =(axis axis.i.act)  `i.act
  $(act t.act)
::  +fits: the verdict of a shape alone, with every miss named by axis; a
::  %run demand has no noun to run on here and misses with nothing got
++  fits
  |=  [=law act=shape:flect]
  ^-  verdict
  (fits-with law act ~ ~)
::  +fits-with: the verdict with the act's noun and an environment, so a
::  %run demand can compute: its gate is called with [noun env] in mock
::  (the slam formula [9 2 10 [6 1 sample] 0 1]), with no scries; a product
::  of 0 fits, anything else or a crash is a miss that keeps what came back
++  fits-with
  |=  [=law act=shape:flect noun=(unit *) env=*]
  ^-  verdict
  =/  misses=(list miss)
    |-  ^-  (list miss)
    ?~  law  ~
    =/  have  (at axis.i.law act)
    =/  [ok=? got=(unit *)]
      ?:  ?=(%run -.demand.i.law)
        ?~  noun  [| ~]
        =/  ran  (mock [gate.demand.i.law [9 2 10 [6 1 [u.noun env]] 0 1]] |=(^ ~))
        ?:  ?=(%0 -.ran)  [=(0 p.ran) `p.ran]
        [| ~]
      :_  ~
      ?~  have  ?=(%any -.demand.i.law)      ::  absent: only nothing is met
      ?-  -.demand.i.law                     ::  %run was taken above
        %any   &
        %kind  =(kind.demand.i.law kind.u.have)
        %same  =(fs.demand.i.law flects.u.have)
        %one   (lien fs.demand.i.law |=(f=(list flect:flect) =(f flects.u.have)))
      ==
    ?:  ok  $(law t.law)
    [[axis.i.law demand.i.law have got] $(law t.law)]
  [=(~ misses) misses]
::  +judge: the receipt any ship can recompute from the two nouns
++  judge
  |=  [=law act=vase]
  ^-  receipt
  (judge-with law act ~)
::  +judge-with: the receipt with an environment for the laws that compute
++  judge-with
  |=  [=law act=vase env=*]
  ^-  receipt
  [(tag:flect law) (tag:flect q.act) (fits-vase law act env)]
::  +grown-at: the act's flect at one axis, grown from the vase on demand --
::  the law looks only where it demands, so an act of megabytes costs a
::  walk to each demanded axis, never a shape of the whole.  What stands at
::  an axis is exactly what +grow would have put there: a typed atom is a
::  word or a ship, an atom in an untyped place is a word, a cell is nothing.
++  grown-at
  |=  [axis=@ud act=vase]
  ^-  (unit grown:flect)
  =/  got  (mule |.((slot axis act)))
  ?:  ?=(%| -.got)  ~
  =/  s=vase  p.got
  =/  t=type  (norm:flect p.s)
  ?:  ?=([%atom *] t)
    ?>  ?=(@ q.s)
    ?:  =(%p p.t)  `[axis %ship ~[(ship:flect q.s)]]
    `[axis %word (letters:flect q.s)]
  ?:  ?=([%cell *] t)  ~
  ?@  q.s  `[axis %word (letters:flect q.s)]
  ~
::  +fits-vase: +fits-with without growing the act: every demand is met or
::  missed at its own axis, the laws that compute run on the noun
++  fits-vase
  |=  [=law act=vase env=*]
  ^-  verdict
  =/  misses=(list miss)
    |-  ^-  (list miss)
    ?~  law  ~
    =/  have  (grown-at axis.i.law act)
    =/  [ok=? got=(unit *)]
      ?:  ?=(%run -.demand.i.law)
        =/  ran  (mock [gate.demand.i.law [9 2 10 [6 1 [q.act env]] 0 1]] |=(^ ~))
        ?:  ?=(%0 -.ran)  [=(0 p.ran) `p.ran]
        [| ~]
      :_  ~
      ?~  have  ?=(%any -.demand.i.law)
      ?-  -.demand.i.law
        %any   &
        %kind  =(kind.demand.i.law kind.u.have)
        %same  =(fs.demand.i.law flects.u.have)
        %one   (lien fs.demand.i.law |=(f=(list flect:flect) =(f flects.u.have)))
      ==
    ?:  ok  $(law t.law)
    [[axis.i.law demand.i.law have got] $(law t.law)]
  [=(~ misses) misses]
::
::  Laws as governed facts.  A law lives in graf as an append-only fact,
::  promoted or retired by the operator, the way bench governs lessons:
::  later facts win, a retirement removes, a promotion (re)adds.  The
::  fact's id and a receipt's law tag are the same sham, so a receipt
::  cites the law by the identity the canon keeps.
::
+$  law-fact
  $:  %flect-law
      %1
      verb=?(%promote %retire)
      id=@t
      =law
      who=@p
      at=@da
  ==
++  law-id
  |=  =law
  ^-  @t
  (scot %uv (sham law))
++  fact-of
  |=  [verb=?(%promote %retire) =law who=@p at=@da]
  ^-  law-fact
  [%flect-law %1 verb (law-id law) law who at]
::  +verify: cross-ship verification as a pure function.  A peer sends the
::  law, the act (a typed noun: the type travels as a vase) and the receipt
::  it claims; any ship recomputes the receipt from the two nouns and says
::  whether it is the same.  Nothing is trusted but Nock.
++  verify
  |=  [=law act=vase env=* claimed=receipt]
  ^-  ?
  =((judge-with law act env) claimed)
::  +canon-laws: the laws in force after these facts, in promotion order --
::  folded by the time RECORDED (graf answers a kind in set order, and a
::  retire folded before its promote would re-promote); later wins
::  A fact whose id differs from its law's id is ignored.
++  canon-laws
  |=  facts=(list *)
  ^-  (list [id=@t =law])
  =/  good=(list law-fact)
    %+  murn  facts
    |=  f=*
    ^-  (unit law-fact)
    =/  p  ((soft law-fact) f)
    ?~  p  ~
    ?.(=(id.u.p (law-id law.u.p)) ~ p)
  =.  good  (sort good |=([a=law-fact b=law-fact] (lth at.a at.b)))
  =|  canon=(list [id=@t =law])
  |-  ^-  (list [id=@t =law])
  ?~  good  canon
  =/  without  (skip canon |=(c=[id=@t =law] =(id.c id.i.good)))
  ?-  verb.i.good
    %retire   $(good t.good, canon without)
    %promote  $(good t.good, canon (snoc without [id.i.good law.i.good]))
  ==
--
