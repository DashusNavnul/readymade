::  /lib/model-admission-registry
::
::  Pure edited-model registry law.  Registration re-verifies the portable
::  admission from the canonical base leaves.  Activation is single-current;
::  retirement cannot silently remove the model Viki is currently running.
::
/-  mr=model-admission-registry, we=weight-edit
/+  wed=weight-edit
|%
++  find-entry
  |=  [oracle=@ux rows=(list entry:mr)]
  ^-  (unit entry:mr)
  ?~  rows  ~
  ?:  =(oracle oracle.admission.i.rows)  `i.rows
  $(rows t.rows)
::
++  insert
  |=  [row=entry:mr rows=(list entry:mr)]
  ^-  (list entry:mr)
  ?~  rows  ~[row]
  ?:  (lth oracle.admission.row oracle.admission.i.rows)
    [row rows]
  [i.rows $(row row, rows t.rows)]
::
++  valid
  |=  current=registry:mr
  ^-  ?
  ?.  =(schema:mr schema.current)  |
  =/  names=(list @ux)
    (turn entries.current |=(row=entry:mr oracle.admission.row))
  ?.  =((lent names) (lent ~(tap in (silt names))))  |
  =/  active=(list entry:mr)
    (skim entries.current |=(row=entry:mr =(%active status.row)))
  ?~  current.current  =(~ active)
  ?~  active  |
  ?&  =(1 (lent active))
      =(u.current.current oracle.admission.i.active)
  ==
::
++  activate-rows
  |=  [oracle=@ux now=@da rows=(list entry:mr)]
  ^-  (list entry:mr)
  %+  turn  rows
  |=  row=entry:mr
  ?:  =(oracle oracle.admission.row)
    row(status %active, changed-at now)
  ?:  =(%active status.row)
    row(status %admitted, changed-at now)
  row
::
++  retire-rows
  |=  [oracle=@ux now=@da rows=(list entry:mr)]
  ^-  (list entry:mr)
  %+  turn  rows
  |=  row=entry:mr
  ?:  =(oracle oracle.admission.row)
    row(status %retired, changed-at now)
  row
::
++  apply
  |=  $:  current=registry:mr
          action=action:mr
          leaves=(list @uvI)
          now=@da
      ==
  ^-  (each registry:mr @tas)
  ?.  (valid current)  [%| %invalid-registry]
  ?-  -.action
    %register
      ?.  (verify:wed admission.action leaves)
        [%| %invalid-admission]
      ?^  (find-entry oracle.admission.action entries.current)
        [%| %duplicate-oracle]
      =/  row=entry:mr  [admission.action %admitted now now]
      [%& current(entries (insert row entries.current), sequence +(sequence.current))]
    %activate
      =/  found=(unit entry:mr)
        (find-entry oracle.action entries.current)
      ?~  found  [%| %unknown-oracle]
      ?:  =(%retired status.u.found)  [%| %retired-oracle]
      ?:  =(current.current `oracle.action)  [%| %already-current]
      :-  %&
      %=  current
        current   `oracle.action
        entries   (activate-rows oracle.action now entries.current)
        sequence  +(sequence.current)
      ==
    %retire
      =/  found=(unit entry:mr)
        (find-entry oracle.action entries.current)
      ?~  found  [%| %unknown-oracle]
      ?:  =(current.current `oracle.action)  [%| %current-oracle]
      ?:  =(%retired status.u.found)  [%| %already-retired]
      :-  %&
      %=  current
        entries   (retire-rows oracle.action now entries.current)
        sequence  +(sequence.current)
      ==
  ==
--
