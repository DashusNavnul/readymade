::  Pure provider configuration and proposal validation. No network effects.
/-  p=native-coding-provider
/+  cr=codex-responses
|%
++  text-valid
  |=  [text=@t maximum=@ud]
  ^-  ?
  &((gth (met 3 text) 0) (lte (met 3 text) maximum))
++  name-valid
  |=  name=@t
  ^-  ?
  ?&  (text-valid name 64)
      (levy (trip name) |=(c=@t ?|(&((gte c 'a') (lte c 'z')) &((gte c 'A') (lte c 'Z')) &((gte c '0') (lte c '9')) =(c '_') =(c '-'))))
  ==
++  https
  |=  endpoint=@t
  ^-  ?
  ?&  (text-valid endpoint endpoint-limit:p)
      =('https://' (cut 3 [0 8] endpoint))
      (gth (met 3 endpoint) 8)
      (levy (trip endpoint) |=(c=@t ?&((gte c 33) (lte c 126) !=(c '@') !=(c '#') !=(c '?') !=(c '\\'))))
  ==
++  endpoint-valid
  |=  [provider=provider:p endpoint=@t format=wire-format:p]
  ^-  ?
  ?-  provider
    %openai  &(=(format %responses) =(endpoint openai-endpoint:p))
    %codex  &(=(format %responses) =(endpoint codex-endpoint:p))
    %anthropic  &(=(format %messages) =(endpoint anthropic-endpoint:p))
    %xai  &(=(format %chat) |(=(endpoint xai-endpoint:p) =(endpoint xai-session-endpoint:p)))
    %compatible  &(=(format %chat) (https endpoint))
  ==
++  cli-backend
  ::  Explicit transport selection; credentials is a nonsecret pairing key.
  |=  s=selection:p
  ^-  (unit ?(%codex %claude))
  ?:  ?&  =(%codex provider.s)  =(codex-cli-endpoint:p endpoint.s)
          =(%responses format.s)  =('codex-cli' model.s)
      ==  `%codex
  ?:  ?&  =(%anthropic provider.s)  =(claude-cli-endpoint:p endpoint.s)
          =(%messages format.s)  =('claude-cli' model.s)
      ==  `%claude
  ~
++  transport
  |=  s=selection:p
  ^-  @tas
  ?:(?=(^ (cli-backend s)) %cli-inference %codex-inference)
++  selection-valid
  |=  s=selection:p
  ^-  ?
  ?&  (text-valid model.s identifier-limit:p)
      (text-valid credential.s identifier-limit:p)
      |(?=(^ (cli-backend s)) (endpoint-valid provider.s endpoint.s format.s))
      ?:(&(=(%codex provider.s) ?=(~ (cli-backend s))) streaming.capabilities.s %.y)
      ?:  &(=(%xai provider.s) =(endpoint.s xai-session-endpoint:p))
        ::  The selected model is also a fixed proxy routing header.
        &(streaming.capabilities.s (levy (trip model.s) |=(c=@t &((gte c 33) (lte c 126)))))
      %.y
  ==
++  model-identity
  ::  Response-label compatibility, not proof of fixed model weights.
  ::  Keep both labels: never rewrite a reply or widen this to prefix matching.
  |=  [s=selection:p reported-provider=provider:p reported=@t]
  ^-  (unit [rule=@tas requested=@t reported=@t])
  ?.  &((selection-valid s) =(provider.s reported-provider) (text-valid reported identifier-limit:p))  ~
  ?:  =(model.s reported)  `[%exact model.s reported]
  ?.  ?&  =(%xai provider.s)
          =(xai-session-endpoint:p endpoint.s)
          =('grok-4.6' model.s)  =('grok-4.6-build' reported)
      ==  ~
  `[%grok-cli-4-6-build-v1 model.s reported]
++  model-matches
  |=  [s=selection:p reported-provider=provider:p reported=@t]
  ^-  ?
  ?=(^ (model-identity s reported-provider reported))
++  credentials-valid
  |=  c=credentials:p
  ^-  ?
  ?&  (https endpoint.c)
      (text-valid secret.c credential-limit:p)
      (levy (trip secret.c) |=(ch=@t &((gte ch 33) (lte ch 126))))
      ?:  !=(%codex provider.c)  =('' account.c)
      ?&  (text-valid account.c identifier-limit:p)
          (levy (trip account.c) |=(ch=@t &((gte ch 33) (lte ch 126))))
      ==
  ==
++  configure
  |=  [our=@p src=@p key=@tas value=credentials:p held=vault:p]
  ^-  (each vault:p @tas)
  ?.  =(our src)  [%| %owner-required]
  ?.  &((text-valid key identifier-limit:p) (credentials-valid value))  [%| %credential-invalid]
  ?.  |((~(has by held) key) (lth ~(wyt by held) vault-limit:p))  [%| %credential-capacity]
  [%& (~(put by held) key value)]
++  disconnect
  |=  [our=@p src=@p key=@tas held=vault:p]
  ^-  (each vault:p @tas)
  ?.  =(our src)  [%| %owner-required]
  [%& (~(del by held) key)]
++  select
  |=  [our=@p src=@p key=@tas value=selection:p held=selections:p]
  ^-  (each selections:p @tas)
  ?.  =(our src)  [%| %owner-required]
  ?.  &((name-valid key) (selection-valid value))  [%| %selection-invalid]
  ?.  |((~(has by held) key) (lth ~(wyt by held) selection-limit:p))  [%| %selection-capacity]
  [%& (~(put by held) key value)]
++  tool-valid
  |=  t=tool:p
  ^-  ?
  ?&  (name-valid name.t)
      (lte (met 3 description.t) 4.096)
      ?=([%o *] parameters.t)
      =(`'object' (string:cr parameters.t 'type'))
      (lte (met 3 (en:json:html parameters.t)) schema-limit:p)
  ==
++  call-valid
  |=  c=call:p
  ^-  ?
  ?&  (text-valid id.c identifier-limit:p)
      (name-valid name.c)
      ?=([%o *] arguments.c)
      (lte (met 3 (en:json:html arguments.c)) argument-limit:p)
  ==
++  opaque-valid
  |=  [provider=provider:p model=@t value=json]
  ^-  ?
  ?.  &((text-valid model identifier-limit:p) (lte (met 3 (en:json:html value)) response-limit:p))  %.n
  ?:  |(=(%openai provider) =(%codex provider))
    &(?=([%o *] value) =(`'reasoning' (string:cr value 'type')))
  ?.  =(%anthropic provider)  %.n
  ?:  =(`'redacted_thinking' (string:cr value 'type'))  ?=(^ (string:cr value 'data'))
  &(=(`'thinking' (string:cr value 'type')) ?=(^ (string:cr value 'thinking')) ?=(^ (string:cr value 'signature')))
++  block-valid
  |=  [role=?(%user %assistant) value=block:p]
  ^-  ?
  ?-  -.value
    %text  (text-valid text.value text-limit:p)
    %call  &(=(%assistant role) (call-valid call.value))
    %result  &(=(%user role) (text-valid id.value identifier-limit:p) (lte (met 3 text.value) text-limit:p))
    %opaque  &(=(%assistant role) (opaque-valid provider.value model.value value.value))
  ==
++  history-valid
  |=  history=(list message:p)
  ^-  ?
  ?.  &((gth (lent history) 0) (lte (lent history) history-limit:p))  %.n
  =/  open=(set @t)  ~
  |-  ^-  ?
  ?~  history  =(~ open)
  =/  message=message:p  i.history
  ?.  &((gth (lent content.message) 0) (lte (lent content.message) block-limit:p))  %.n
  ?.  (levy content.message |=(value=block:p (block-valid role.message value)))  %.n
  =/  processed=(unit (set @t))
    =/  blocks=(list block:p)  content.message
    |-  ^-  (unit (set @t))
    ?~  blocks  `open
    =/  value=block:p  i.blocks
    ?:  ?=(%call -.value)
      ?:  (~(has in open) id.call.value)  ~
      $(blocks t.blocks, open (~(put in open) id.call.value))
    ?:  ?=(%result -.value)
      ?.  (~(has in open) id.value)  ~
      $(blocks t.blocks, open (~(del in open) id.value))
    $(blocks t.blocks)
  ?~  processed  %.n
  $(history t.history, open u.processed)
++  call-ids-unique
  ::  Hosted provider APIs refuse a repeated tool call id across a transcript.
  ::  A CLI builder names its own calls and reused one on 2026-11-01 (`read-current`
  ::  after a revise), so this binds only requests that reach such an API.
  |=  history=(list message:p)
  ^-  ?
  =/  ids=(list @t)
    %-  zing
    %+  turn  history
    |=  message=message:p
    %+  murn  content.message
    |=(value=block:p ?.(?=(%call -.value) ~ `id.call.value))
  =((lent ids) ~(wyt in (silt ids)))
++  block-bytes
  |=  b=block:p
  ^-  @ud
  ?-  -.b
    %text  (met 3 text.b)
    %result  (add (met 3 id.b) (met 3 text.b))
    %call  (add (add (met 3 id.call.b) (met 3 name.call.b)) (met 3 (en:json:html arguments.call.b)))
    %opaque  (met 3 (en:json:html value.b))
  ==
++  context-bytes
  |=  r=request:p
  ^-  @ud
  =/  messages=@ud
    %+  roll  history.r
    |=  [message=message:p total=@ud]
    %+  add  total
    %+  roll  content.message
    |=  [b=block:p bytes=@ud]
    (add bytes (block-bytes b))
  =/  schemas=@ud
    %+  roll  tools.r
    |=  [tool=tool:p bytes=@ud]
    (add bytes (add (met 3 description.tool) (met 3 (en:json:html parameters.tool))))
  (add (met 3 instructions.r) (add messages schemas))
++  request-valid
  |=  r=request:p
  ^-  ?
  ?&  !=(0 id.r)  !=(0 session.r)
      (selection-valid selection.r)
      (text-valid instructions.r instruction-limit:p)
      (history-valid history.r)
      |(?=(^ (cli-backend selection.r)) (call-ids-unique history.r))
      (lte (context-bytes r) request-limit:p)
      (lte (lent tools.r) call-limit:p)
      (levy tools.r tool-valid)
      =((lent tools.r) ~(wyt in (silt (turn tools.r |=(t=tool:p name.t)))))
      |(=(~ tools.r) tools.capabilities.selection.r)
      |(!streaming.r streaming.capabilities.selection.r)
      ?:(&(=(%codex provider.selection.r) ?=(~ (cli-backend selection.r))) streaming.r %.y)
      ?:  &(=(%xai provider.selection.r) =(endpoint.selection.r xai-session-endpoint:p))
        streaming.r
      %.y
      &((gth max-output.r 0) (lte max-output.r token-limit:p))
  ==
++  calls-valid
  |=  [calls=(list call:p) tools=(list tool:p)]
  ^-  ?
  ?&  (lte (lent calls) call-limit:p)
      (levy calls call-valid)
      =((lent calls) ~(wyt in (silt (turn calls |=(c=call:p id.c)))))
      %+  levy  calls
      |=  c=call:p
      (lien tools |=(t=tool:p =(name.c name.t)))
  ==
++  publish
  |=  r=reply:p
  ^-  public-reply:p
  [%native-coding-result-v1 id.r provider.r model.r response-id.r stop.r text.r calls.r usage.r raw-digest.r]
--
