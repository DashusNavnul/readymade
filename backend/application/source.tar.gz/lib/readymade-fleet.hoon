::  Bounded read-only Viki fleet projection. No inference or dispatch authority.
/-  nf=native-coding-fleet, ss=seat-session, vr=glass-moon-route,
    mse=glass-moon-executor, np=native-coding-provider, nc=native-coding
/+  h=readymade-history
|%
+$  config
  [binding=binding:mse generation=@ud session=@ux provider-key=@tas selection=selection:np]
+$  placement  [route=moon-route:vr config=config]
+$  placements  (map @ux placement)
+$  selection  [provider=provider:np model=text:h]
+$  allocation
  [id=@ux seat=seat:ss worker=@p generation=@ud request=@ux inspection=@ux held=?]
+$  handoff
  [task=@ux request=(unit @ux) role=(unit role:nf) phase=(unit phase:nf) assignment=(unit allocation) ready=? handed=?]
+$  session-phase
  ?(%idle %ready %inference %tools %judgment %paused %unknown %complete %refused)
+$  journal-body
  $%  [%operator text=@t]
      [%model result=public-reply:np]
      [%tool result=tool-result:nc]
      [%selection value=selection:np]
      [%status value=session-phase reason=@tas]
      [%terminal input=@t output=@t]
      [%judgment verdict=?(%complete %continue %refuse) evidence=(list @ux) reason=@t]
  ==
+$  journal-record
  [sequence=@ud previous=(unit @ux) at=@da body=journal-body id=@ux]
::  Exact existing Viki public-session noun; never retained in component state.
+$  public-session
  [session=session:nc phase=session-phase selection=selection:np worker=@p records=(list journal-record) summary=@t sequence=@ud]
+$  native-status
  [phase=session-phase reason=text:h sequence=@ud at=@da]
+$  reply
  [request=@ux record=@ux sequence=@ud at=@da selected=selection stop=stop:np text=text:h]
+$  row
  $:  id=@ux  ordinal=@ud  session=@ux  request=@ux  project=text:h
      objective=text:h  role=role:nf  phase=phase:nf  dependencies=(list @ux)
      assignment=(unit allocation)  selected=(unit selection)  model-reason=@tas
      handoffs=(list handoff)  handoffs-total=@ud  waiting=(list @ux)
      candidate=(unit @ux)  evidence=(list @ux)  evidence-total=@ud
      status=(unit native-status)  reply=(unit reply)  observation=@tas
  ==
+$  seat-row
  $:  seat=seat:ss  worker=(unit @p)  roles=(list role:nf)
      inspection=(unit @ux)  observed=?(%unbound %unknown %idle %busy %not-ready)
      held=(unit @ux)
  ==
+$  snapshot
  $:  %readymade-fleet-v2  revision=@ud  source=@ux  start=@ud  total=@ud
      seats=(list seat-row)  rows=(list row)  next=(unit @ud)
  ==
::  Ephemeral projection work, shared only within one observation callback.
+$  prepared
  [fleet=organ:nf placements=placements ordered=(list entry:nf) base=snapshot]
++  seats
  ^-  (list seat:ss)
  ~[%flunky %busboy %policeman %gendarme %undertaker %priest %delivery-boy %cuirassier %stationmaster]
++  held
  |=  e=entry:nf
  ^-  ?
  &(?=(^ assignment.e) !released.e)
++  coherent
  |=  [our=@p o=organ:nf ps=placements]
  ^-  ?
  ?&  (lte ~(wyt by workers.o) 9)  (lte ~(wyt by tasks.o) 256)
      (lte ~(wyt by ps) 64)
      =(~(wyt in (silt (turn ~(val by tasks.o) |=(e=entry:nf ordinal.e)))) ~(wyt by tasks.o))
      %+  levy  ~(tap by workers.o)
      |=  [s=seat:ss w=worker:nf]
      =(s seat.seat-session.route.w)
      %+  levy  ~(tap by tasks.o)
      |=  [id=@ux e=entry:nf]
      ?&  =(id id.task.e)  !=(0 id)  (lth ordinal.e next.o)
          =(our actor.context.task.e)  =(our owner.source.context.task.e)
          =(our owner.accepted.task.e)  (lte ~(wyt in dependencies.task.e) 32)
          (lte (lent evidence.e) 64)
          ?~  assignment.e
            |(&(=(%queued phase.e) !released.e) &(=(%cancelled phase.e) released.e))
          =/  a=assignment:nf  u.assignment.e
          ?&  =(id task.a)  =(context.task.e context.a)
              =(request.context.task.e request.a)
              =(seat.a seat.seat-session.route-value.a)
              =(worker.a moon.seat-session.route-value.a)
          ==
      ==
  ==
++  selected-for
  |=  [e=entry:nf ps=placements]
  ^-  [(unit selection) @tas]
  ?~  assignment.e  [~ %not-assigned]
  =/  a=assignment:nf  u.assignment.e
  =/  p=(unit placement)  (~(get by ps) session.context.task.e)
  ?~  p  [~ %placement-missing]
  =/  c=config  config.u.p
  ?.  ?=([%multiplayer-session-executor-binding-v2 *] -.binding.c)
    [~ %placement-mismatch]
  ?.  ?&  =(session.c session.context.task.e)
          =(generation.c generation.a)  =(route.u.p route-value.a)
          =(worker.a moon.seat-session.route.u.p)
          =(route.a (shax (jam route-value.a)))
          =(route.binding.c route.a)
          =(selected.binding.c spec.provider.route-value.a)
          =(provider-id.selected.binding.c `@t`provider.selection.c)
          =(model-id.selected.binding.c model.selection.c)
      ==  [~ %placement-mismatch]
  ?:  |(=('model-unreported' model.selection.c) =('unreported' model.selection.c) =('unknown' model.selection.c) =('' model.selection.c))
    [~ %model-unreported]
  [`[provider.selection.c (bounded:h model.selection.c 256)] %selected]
++  task-row
  |=  [e=entry:nf ps=placements]
  ^-  row
  =/  model  (selected-for e ps)
  =/  a=(unit allocation)
    ?~  assignment.e  ~
    =/  v=assignment:nf  u.assignment.e
    `[id.v seat.v worker.v generation.v request.v inspection.v (held e)]
  :*  id.task.e  ordinal.e  session.context.task.e  request.context.task.e
      (bounded:h project.context.task.e 128)  (bounded:h objective.task.e 1.024)
      role.task.e  phase.e  ~(tap in dependencies.task.e)  a  -.model  +.model
      ~  ~(wyt in dependencies.task.e)  ~
      candidate.e  (scag 8 evidence.e)  (lent evidence.e)  ~  ~  %not-observed
  ==
++  dependency
  |=  [o=organ:nf target=entry:nf id=@ux]
  ^-  handoff
  =/  found=(unit entry:nf)  (~(get by tasks.o) id)
  ?~  found  [id ~ ~ ~ ~ %.n %.n]
  =/  e=entry:nf  u.found
  =/  ready=?  &(=(%completed phase.e) released.e)
  =/  a=(unit allocation)
    ?~  assignment.e  ~
    =/  v=assignment:nf  u.assignment.e
    `[id.v seat.v worker.v generation.v request.v inspection.v (held e)]
  =/  handed=?
    ?~  a  %.n
    ?~  assignment.target  %.n
    ?&  ready
        |(!=(seat.u.a seat.u.assignment.target) !=(role.task.e role.task.target))
    ==
  [id `request.context.task.e `role.task.e `phase.e a ready handed]
++  dependencies-for
  |=  [o=organ:nf e=entry:nf r=row]
  ^-  row
  =/  ids=(list @ux)  ~(tap in dependencies.task.e)
  =/  waiting=(list @ux)
    %+  skim  ids
    |=  id=@ux
    =/  d=handoff  (dependency o e id)
    !ready.d
  r(handoffs (turn (scag 8 ids) |=(id=@ux (dependency o e id))), waiting waiting)
++  observe
  |=  [our=@p e=entry:nf r=row session=(unit public-session)]
  ^-  row
  ?~  session  r(observation %session-unavailable)
  ?~  assignment.e  r(observation %not-assigned)
  =/  s=public-session  u.session
  =/  a=assignment:nf  u.assignment.e
  ?.  ?&  =(our owner.session.s)  =(session.r id.session.s)
          =(project.context.task.e project.session.s)
          |(!(held e) =(worker.a worker.s))
          =(our owner.working.session.s)
          =(desk.source.context.task.e desk.working.session.s)
          (lte (lent records.s) 4.096)
      ==  r(observation %session-mismatch)
  =/  items=(list journal-record)  records.s
  =/  result=(unit reply)  ~
  =/  status=(unit native-status)  ~
  |-  ^-  row
  ?~  items  r(reply result, status status, observation %observed)
  =/  item=journal-record  i.items
  =?  status
    ?&  (held e)  ?=([%status *] body.item)
        =(phase.s value.body.item)  (lth sequence.item sequence.s)
    ==
    `[value.body.item (bounded:h `@t`reason.body.item 128) sequence.item at.item]
  =?  status
    ?&  (held e)  ?=([%judgment *] body.item)
        =(phase.s ?-(verdict.body.item %complete %complete, %continue %ready, %refuse %refused))
        (lth sequence.item sequence.s)
    ==
    `[phase.s (bounded:h reason.body.item 128) sequence.item at.item]
  =?  result
    ?&  ?=([%model *] body.item)  (lth sequence.item sequence.s)
        =(request.r id.result.body.item)
        =(provider-id.spec.provider.route-value.a `@t`provider.result.body.item)
        =(model-id.spec.provider.route-value.a model.result.body.item)
    ==
    =/  v=public-reply:np  result.body.item
    `[id.v id.item sequence.item at.item [provider.v (bounded:h model.v 256)] stop.v (bounded:h text.v 4.096)]
  $(items t.items)
++  enrich
  |=  [our=@p o=organ:nf s=snapshot sessions=(map @ux (unit public-session))]
  ^-  snapshot
  =/  rows=(list row)
    %+  turn  rows.s
    |=  r=row
    =/  e=entry:nf  (~(got by tasks.o) id.r)
    (observe our e r (fall (~(get by sessions) session.r) ~))
  ?:  =(rows rows.s)  s
  s(rows rows, source (shax (jam [source.s rows])))
++  seat-view
  |=  [o=organ:nf s=seat:ss]
  ^-  seat-row
  =/  w=(unit worker:nf)  (~(get by workers.o) s)
  =/  active=(list entry:nf)
    (skim ~(val by tasks.o) |=(e=entry:nf ?~(assignment.e %.n &((held e) =(s seat.u.assignment.e)))))
  ?>  (lte (lent active) 1)
  =/  task=(unit @ux)  ?~(active ~ `id.task.i.active)
  ?~  w  [s ~ ~ ~ %unbound task]
  =/  v=worker:nf  u.w
  =/  observed=?(%unknown %idle %busy %not-ready)
    ?~  observed.v  %unknown
    =/  event=event:mse  u.observed.v
    ?.  &(!=(0 inspection.v) =(inspection.v request.event) =(`binding.v binding.event))  %unknown
    ?.  enabled.event  %not-ready
    ?:  |((gth jobs.event 0) !=(1 capacity.v))  %busy
    %idle
  [s `moon.seat-session.route.v ~(tap in roles.v) `inspection.v observed task]
++  prepare
  |=  [our=@p o=organ:nf ps=placements]
  ^-  prepared
  ?>  (coherent our o ps)
  =/  ordered=(list entry:nf)
    (sort ~(val by tasks.o) |=([a=entry:nf b=entry:nf] (lth ordinal.a ordinal.b)))
  [o ps ordered [%readymade-fleet-v2 next.o (shax (jam [o ps])) 0 ~(wyt by tasks.o) (turn seats |=(s=seat:ss (seat-view o s))) ~ ~]]
++  project-prepared
  |=  [ready=prepared start=@ud]
  ^-  snapshot
  ?>  (lte start 256)
  =/  remaining=(list entry:nf)  (slag start ordered.ready)
  =/  chosen=(list entry:nf)  (scag 16 remaining)
  =/  next=(unit @ud)  ?:((gth (lent remaining) 16) `(add start 16) ~)
  =/  rows=(list row)
    (turn chosen |=(e=entry:nf (dependencies-for fleet.ready e (task-row e placements.ready))))
  base.ready(start start, rows rows, next next)
++  project
  |=  [our=@p o=organ:nf ps=placements start=@ud]
  ^-  snapshot
  (project-prepared (prepare our o ps) start)
--
