::  A distinct admitted compiler/checkpoint protocol. Old attachment roles,
::  seeds and outputs cannot supply a checkpoint. Pure joins do not establish
::  canonical origin: Cantrip must own admission, prior lookup and retention.
/-  nc=native-coding
/+  compiler=native-coding-compiler, exports=native-coding-compiler-exports,
    attachment=native-coding-compiler-attachment,
    decoder=native-coding-compiler-artifact, checked=native-coding-compiler-checked,
    modules=native-coding-module-sources, vm=native-coding-terminal-plan,
    tools=cantrip-native-coding, scalar=terminal-plan,
    arithmetic=native-coding-compiler-arithmetic
|%
+$  role  ?(%compiler-prefix-exports %checked-prefix-exports)
+$  program
  $:  %native-coding-compiler-prefix-program-v1
      role=role
      sources=(list witness:compiler)
      source-digest=@ux
      entry-name=@t
      entry=plan:vm
      entry-digest=@ux
      digest=@ux
  ==
+$  previous  [receipt=@ux checkpoint=@ux prefix=(list mapped:modules)]
+$  request
  $:  %native-coding-compiler-prefix-request-v1
      job=job:compiler
      selection=selection:exports
      program=program
      profile=@ux
      scope=@ux
      fuel=@ud
      previous=(unit previous)
  ==
+$  output
  $:  bindings=(list binding:decoder)
      checkpoint=plan:vm
      prefix=(list mapped:modules)
      reused=@ud
      remaining=@ud
      type-work=(unit @ud)
  ==
+$  result  (each output refusal:checked)
+$  retained  [%native-coding-compiler-prefix-retained-v1 request=request output=result]
++  byte-limit  33.554.432
++  profile-id
  ^-  @ux
  %-  shax
  %-  jam
  :*  %native-coding-compiler-prefix-protocol-v1  prefix-mode:vm
      byte-limit  32  524.288  1.048.576  512  32  262.144  type-work-cap:checked
  ==
++  digest
  |=  value=*
  ^-  @ux
  (shax (jam [%native-coding-compiler-prefix-v1 value]))
++  program-id
  |=  p=program
  ^-  @ux
  (digest p(digest 0x0))
++  program-valid
  |=  p=program
  ^-  ?
  ?.  ?&  (gte (lent sources.p) 1)
          (lte (lent sources.p) 32)
          (lte (met 3 (jam p)) 4.194.304)
      ==
    %.n
  =/  names=(list @t)  (turn sources.p |=(w=witness:compiler module.w))
  ?&  =((lent names) ~(wyt in (silt names)))
      (levy names name-valid:decoder)
      (~(has in (silt names)) 'Runtime.NativeCodingCompiler')
      (~(has in (silt names)) 'ModuleReuse')
      (~(has in (silt names)) 'ModuleReuseWire')
      %+  levy  sources.p
      |=  w=witness:compiler
      ?&  (gte (met 3 bytes.w) 1)
          (lte (met 3 bytes.w) 524.288)
          =(digest.w (rev 3 32 (shax bytes.w)))
      ==
      (lte (roll sources.p |=([w=witness:compiler n=@ud] (add n (met 3 bytes.w)))) 1.048.576)
      =(source-digest.p (source-id:attachment sources.p))
      =(entry-name.p ?:(=(%compiler-prefix-exports role.p) 'Runtime.NativeCodingCompiler.compile_reuse_compiler_exports' 'Runtime.NativeCodingCompiler.compile_reuse_checked_exports'))
      =(entry-digest.p (shax (jam entry.p)))
      =(digest.p (program-id p))  (entry-valid:attachment entry.p)
  ==
++  wire-valid
  ::  Wide numbers are opaque represented compiler state, never executable
  ::  laws/pins. Preserve the separate returned-node and aggregate byte caps.
  |=  raw=plan:vm
  ^-  ?
  ?.  (lte (met 3 (jam raw)) byte-limit)  %.n
  =/  todo=(list plan:vm)  ~[raw]
  =/  left=@ud  prefix-output-nodes:vm
  =/  bytes=@ud  prefix-atom-bytes:vm
  |-  ^-  ?
  ?~  todo  %.y
  ?:  =(0 left)  %.n
  =/  value=plan:vm  i.todo
  ?:  ?=(%nat -.value)
    ?.  ?&  (lte (met 0 value.value) attachment-bits:arithmetic)
            (lte (met 3 value.value) bytes)
        ==
      %.n
    $(todo t.todo, left (dec left), bytes (sub bytes (met 3 value.value)))
  ?.  ?=(%app -.value)  %.n
  $(todo [fun.value arg.value t.todo], left (dec left))
++  pair
  |=  [left=plan:vm right=plan:vm]
  ^-  plan:vm
  [%app [%app [%nat 0] left] right]
++  bytes
  ::  Exact byte list, bounded by the source protocol; never strip NULs.
  |=  [raw=plan:vm limit=@ud]
  ^-  @t
  =/  kept=(list @)  ~
  =/  count=@ud  0
  |-  ^-  @t
  ?:  =([%nat 0] raw)
    =/  text=@t  (rap 3 (flop kept))
    ?>  =(count (met 3 text))
    text
  ?>  (lth count limit)
  =/  fields  (fields:decoder raw 1 2)
  =/  byte=plan:vm  (snag 0 fields)
  ?>  ?=(%nat -.byte)
  ?>  (lte value.byte 255)
  $(raw (snag 1 fields), count +(count), kept [value.byte kept])
++  prefix
  ::  Extract root and source witnesses only. Linked/Metadata stay opaque;
  ::  the separately admitted GLS entry validates their deterministic order.
  |=  [j=job:compiler raw=plan:vm]
  ^-  (list mapped:modules)
  =/  envelope  (fields:decoder raw 0 2)
  ?>  =([%nat 1] (snag 0 envelope))
  =/  checkpoint  (fields:decoder (snag 1 envelope) 0 2)
  ?>  =([%nat module.j] (snag 0 checkpoint))
  =/  payload  (fields:decoder (snag 1 checkpoint) 0 2)
  ?>  =(2 (lent (fields:decoder (snag 1 payload) 0 2)))
  =/  named  (named-sources:compiler j)
  ?>  ?=(%& -.named)
  =/  raw=plan:vm  (snag 0 payload)
  =/  kept=(list mapped:modules)  ~
  =/  seen=(set @t)  ~
  =/  total=@ud  0
  |-  ^-  (list mapped:modules)
  ?:  =([%nat 0] raw)  (flop kept)
  ?>  (lth (lent kept) 32)
  =/  link  (fields:decoder raw 1 2)
  =/  source  (fields:decoder (snag 0 link) 0 2)
  =/  name=@t  (bytes (snag 0 source) 128)
  ?>  &((name-valid:decoder name) !=(name module.j) !(~(has in seen) name))
  =/  text=@t  (bytes (snag 1 source) 524.288)
  ?>  (lte (add total (met 3 text)) 1.048.576)
  =/  matches=(list mapped:modules)
    (skim p.named |=(s=mapped:modules &(=(name module.s) =(text text.source.s))))
  ?>  =(1 (lent matches))
  %=  $
    raw    (snag 1 link)
    kept   [(snag 0 matches) kept]
    seen   (~(put in seen) name)
    total  (add total (met 3 text))
  ==
++  request-valid
  |=  r=request
  ^-  ?
  ?.  ?&  (program-valid program.r)
          =(profile.r profile-id)
          (identifier:tools scope.r)
          (gte fuel.r 1)
          (lte fuel.r compiler-fuel-v2:vm)
          (lte (met 3 (jam r)) byte-limit)
      ==
    %.n
  =/  input  (inputs:exports job.r selection.r)
  ?.  ?=(%& -.input)  %.n
  =/  sources-check=?
    ?:  =(%checked-prefix-exports role.program.r)
      ?&  (lte (lent (job-sources:compiler job.r)) 8)
          (levy (job-sources:compiler job.r) |=(s=source:compiler (lte (met 3 text.s) 32.768)))
          (lte (roll (job-sources:compiler job.r) |=([s=source:compiler n=@ud] (add n (met 3 text.s)))) 131.072)
      ==
    %.y
  ?.  sources-check  %.n
  ?~  previous.r  %.y
  ?&  (identifier:tools receipt.u.previous.r)
      (identifier:tools checkpoint.u.previous.r)
      (lte (lent prefix.u.previous.r) 31)
      =((lent prefix.u.previous.r) ~(wyt in (silt (turn prefix.u.previous.r |=(s=mapped:modules module.s)))))
      (levy prefix.u.previous.r |=(s=mapped:modules &(!=(module.s (job-module:compiler job.r)) (lien p.input |=(v=mapped:modules =(s v))))))
  ==
++  parse
  |=  [r=request raw=plan:vm remaining=@ud]
  ^-  result
  ?>  &((request-valid r) (lte remaining fuel.r) (wire-valid raw))
  =/  envelope  (row:decoder raw)
  ?>  =(2 (lent fields.envelope))
  ?:  =(1 tag.envelope)
    =/  stage=plan:vm  (snag 0 fields.envelope)
    ?>  ?=(%nat -.stage)
    ?>  (lte value.stage 3)
    =/  detail  (fields:decoder (snag 1 fields.envelope) 0 2)
    =/  code=plan:vm  (snag 0 detail)
    ?>  ?=(%nat -.code)
    ?>  &((gte value.code 1) (lte value.code 65.535))
    =/  names  (fields:decoder (snag 1 detail) 0 2)
    :*  %|  %compiler-prefix-emission-refused
        `value.stage  value.code
        (bytes (snag 0 names) 128)  (bytes (snag 1 names) 128)
    ==
  ?>  =(0 tag.envelope)
  =/  decoded  (decode:decoder [%app [%nat 0] (snag 0 fields.envelope)] names.selection.r)
  ?>  ?=(%& -.decoded)
  =/  payload  (fields:decoder (snag 1 fields.envelope) 0 2)
  =/  checkpoint=plan:vm  (snag 0 payload)
  =/  metadata  (fields:decoder (snag 1 payload) 0 2)
  =/  reused=plan:vm  (snag 0 metadata)
  ?>  ?=(%nat -.reused)
  =/  work=plan:vm  (snag 1 metadata)
  =/  type-work=(unit @ud)
    ?:  =([%nat 0] work)  ~
    =/  value=plan:vm  (snag 0 (fields:decoder work 1 1))
    ?>  ?=(%nat -.value)
    `value.value
  =/  output=output
    [p.decoded checkpoint (prefix job.r checkpoint) value.reused remaining type-work]
  ?>  (output-valid r [%& output])
  [%& output]
++  output-valid
  |=  [r=request out=result]
  ^-  ?
  ?.  ?&  (request-valid r)
          (lte (met 3 (jam out)) byte-limit)
      ==
    %.n
  ?:  ?=(%| -.out)
    ?&  !=(0 reason.p.out)
        (lte (met 3 reason.p.out) 128)
        (lte code.p.out 65.535)
        (lte (met 3 module.p.out) 128)
        (lte (met 3 symbol.p.out) 128)
        ?~(stage.p.out %.y &((lte u.stage.p.out 3) (gte code.p.out 1)))
    ==
  =/  o=output  p.out
  ?.  ?&  (wire-valid checkpoint.o)
          (lte remaining.o fuel.r)
          =(names.selection.r (turn bindings.o |=(b=binding:decoder name.b)))
          (supported:exports bindings.o)
          (levy bindings.o |=(b=binding:decoder (artifact-valid:scalar artifact.b)))
      ==
    %.n
  =/  decoded  (mole |.((prefix job.r checkpoint.o)))
  ?.  =(`prefix.o decoded)  %.n
  =/  reuse-ok=?
    ?~  previous.r
      =(0 reused.o)
    &(=(prefix.o prefix.u.previous.r) =(reused.o (lent prefix.u.previous.r)))
  ?.  reuse-ok  %.n
  ?:  =(%checked-prefix-exports role.program.r)
    ?~(type-work.o %.n (lte u.type-work.o type-work-cap:checked))
  ?=(~ type-work.o)
++  retained-valid
  |=  [id=@ux r=retained]
  ^-  ?
  ?&  (identifier:tools id)
      =(id (key:tools request.job.request.r))
      (lte (met 3 (jam r)) byte-limit)
      (output-valid request.r output.r)
  ==
++  report
  |=  r=retained
  ^-  tool-output:nc
  ?.  (retained-valid (key:tools request.job.request.r) r)
    [%refused %compiler-prefix-retained-invalid 'Compiler checkpoint evidence is invalid.']
  =/  text=@t
    ?:  ?=(%| -.output.r)
      (cat 3 'Native prefix compilation refused: ' (cat 3 reason.p.output.r (cat 3 '; code ' (cat 3 (scot %ud code.p.output.r) (cat 3 '; module ' (cat 3 module.p.output.r (cat 3 '; symbol ' symbol.p.output.r)))))))
    (cat 3 'Unchecked native compiler output retained; dependency modules reused: ' (cat 3 (scot %ud reused.p.output.r) '. No passing check or installation authority.'))
  [%diagnostics ~[[%gallowglass %.n text source.context.request.job.request.r ~[(digest r) (identity:compiler job.request.r) digest.program.request.r profile.request.r ?~(previous.request.r 0x0 receipt.u.previous.request.r) ?:(?=(%& -.output.r) (digest checkpoint.p.output.r) 0x0)]]]]
++  linked
  ::  Canonical caller supplies jobs and retained receipt, not model metadata.
  |=  [jobs=organ:tools id=@ux r=retained finished=?]
  ^-  ?
  ?.  (retained-valid id r)  %.n
  =/  found  (~(get by records.jobs) id)
  ?~  found  %.n
  ?.  =(request.u.found request.job.request.r)  %.n
  =/  grant  (~(get by grants.jobs) grant.u.found)
  ?~  grant  %.n
  ?.  ?&  =(project.job.request.r project.grant.u.grant)
          =(scope.request.r (shax (jam u.grant(revoked ~))))
      ==
    %.n
  ?.  finished  %.y
  =/  expected=tool-result:nc
    [%native-coding-tool-result-v1 context.request.u.found call-id.request.u.found (report r)]
  &(=(%finished stage.u.found) =(`expected result.u.found))
++  prepare
  ::  Called after current allowed/pending/compiler.prepare. Prior is supplied
  ::  only by canonical native lookup; receipt identity alone is not provenance.
  |=  [p=program j=job:compiler selection=selection:exports scope=@ux fuel=@ud prior=(unit retained) jobs=organ:tools]
  ^-  (each request @tas)
  =/  parsed
    %-  mole
    |.
    =/  previous=(unit previous)
      ?~  prior  ~
      ?>  (linked jobs (key:tools request.job.request.u.prior) u.prior %.y)
      ?>  ?=(%& -.output.u.prior)
      ?>  ?&  =(p program.request.u.prior)
              =(selection selection.request.u.prior)
              =(module.j module.job.request.u.prior)
              !=((key:tools request.j) (key:tools request.job.request.u.prior))
          ==
      `[(digest u.prior) (digest checkpoint.p.output.u.prior) prefix.p.output.u.prior]
    =/  r=request
      [%native-coding-compiler-prefix-request-v1 j selection p profile-id scope fuel previous]
    ?>  (request-valid r)
    r
  ?~  parsed  [%| %compiler-prefix-request-invalid]
  [%& u.parsed]
++  arguments
  |=  [r=request prior=(unit retained)]
  ^-  (list plan:vm)
  ?>  (request-valid r)
  =/  checkpoint=plan:vm
    ?~  previous.r
      ?>  ?=(~ prior)
      [%nat 0]
    ?>  ?=(^ prior)
    ?>  ?&  (retained-valid (key:tools request.job.request.u.prior) u.prior)
          ?=(%& -.output.u.prior)
          =(receipt.u.previous.r (digest u.prior))
          =(checkpoint.u.previous.r (digest checkpoint.p.output.u.prior))
          =(prefix.u.previous.r prefix.p.output.u.prior)
      ==
    [%app [%nat 1] checkpoint.p.output.u.prior]
  =/  named  (named-sources:compiler job.r)
  ?>  ?=(%& -.named)
  ~[(encode:compiler (job-module:compiler job.r)) (wanted:exports names.selection.r) (pair [%nat 1] (pair (encode-sources:compiler p.named) checkpoint))]
++  invoke
  |=  [r=request prior=(unit retained)]
  ^-  result
  =/  tried
    %-  mole
    |.
    =/  args  (arguments r prior)
    ?>  (lte (met 3 (jam [r args])) byte-limit)
    =/  ran  (run-prefix:vm fuel.r entry-digest.program.r entry.program.r args)
    ?:  ?=(%| -.ran)  [%| p.ran ~ 0 '' '']
    (parse r output.p.ran remaining.p.ran)
  ?~  tried  [%| %compiler-prefix-unconfirmed ~ 0 '' '']
  u.tried
--
