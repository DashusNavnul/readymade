::  Receiver-owned bridge into the EXISTING Viki/Cantrip candidate pipeline.
::  No grant provisioning, source effects, executable casts or authority timers.
/-  nc=native-coding, r=readymade-artifact-round, pkg=readymade-package
/+  saved=readymade-collab-saved, action=readymade-artifact-actions,
    artifact=readymade-artifact-collab, round=readymade-artifact-round,
    package=readymade-package, build=readymade-package-build,
    project=native-coding-project, law=cantrip-law-window,
    guard=viki-scry-guard, mg=readymade-app-management,
    accept=native-coding-accept, types=readymade-artifact-executor-types,
    reader=readymade-collab-state, legacy-status=readymade-git-proposal,
    sessions=native-coding-session
|%
+$  command  command:types
+$  selected  selected:types
+$  entry  entry:types
+$  journal  journal:types
+$  packet  [%readymade-collab-app-v5 previous=saved:saved executions=journal]
+$  context  [entry=entry previous=saved:saved]
+$  status
  $:  %readymade-artifact-pipeline-status-v1
      session=@ux  nonce=@ux
      phase=?(%missing %pending %candidate %refused %unknown)
      candidate=(unit @ux)  reason=(unit @t)
  ==
+$  session-view
  [session=session:nc phase=* selection=* worker=@p records=(list record:sessions) summary=@t sequence=@ud]
+$  admission-view
  [session=session:nc phase=phase:sessions selection=* worker=@p records=* summary=@t sequence=@ud]
++  session-admission
  ::  Submission terminal + correlated tool result + review judgment each
  ::  append one record. This is admission headroom, not a slot reservation:
  ::  unrelated later appends can still leave the request conservatively unknown.
  |=  [our=@p id=@ux raw=*]
  ^-  (each session:nc @tas)
  =/  parsed  ((soft (unit admission-view)) raw)
  ?~  parsed  [%| %native-session-invalid]
  ?~  u.parsed  [%| %existing-session-required]
  =/  view=admission-view  u.u.parsed
  ?.  &(=(id id.session.view) =(our owner.session.view))
    [%| %native-session-target-mismatch]
  =/  required=@ud  3
  ?.  (lte sequence.view (sub journal-limit:sessions required))
    [%| %native-session-journal-headroom]
  =/  rows=*  records.view
  =|  index=@ud
  |-  ^-  (each session:nc @tas)
  ?:  =(~ rows)
    ?:  =(index sequence.view)  [%& session.view]
    [%| %native-session-journal-incomplete]
  ?.  &(?=(^ rows) (lth index sequence.view))
    [%| %native-session-journal-incomplete]
  =/  row  ((soft record:sessions) -.rows)
  ?~  row  [%| %native-session-journal-invalid]
  ?.  =(index sequence.u.row)  [%| %native-session-journal-incomplete]
  $(rows +.rows, index +(index))
++  key  key:types
++  call-id
  |=  nonce=@ux
  ^-  @t
  (cat 3 'readymade-artifact:' (scot %ux nonce))
++  call-key
  |=  text=@t
  ^-  (unit @ux)
  =/  prefix=@t  'readymade-artifact:'
  ?.  =(prefix (end [3 (met 3 prefix)] text))  ~
  =/  parsed  (slaw %ux (rsh [3 (met 3 prefix)] text))
  ?~  parsed  ~
  ?:(&(=(text (call-id u.parsed)) (digest-valid:package u.parsed)) parsed ~)
++  marked
  |=  text=@t
  ^-  ?
  =/  prefix=@t  'readymade-artifact:'
  =(prefix (end [3 (met 3 prefix)] text))
++  command-valid  command-valid:types
++  valid  valid:types
++  restore
  ::  Only ordinary known DATA is parsed. Legacy migration stays in saved-kit.
  |=  [our=@p raw=*]
  ^-  (unit packet)
  =/  five=(unit packet)  ((soft packet) raw)
  ?^  five
    ?:(&((valid:saved our previous.u.five) (valid our executions.u.five)) five ~)
  =/  old  (restore:saved our raw)
  ?~  old  ~
  `[%readymade-collab-app-v5 u.old ~]
++  select
  |=  [our=@p cmd=command value=saved:saved]
  ^-  (each selected @tas)
  ?.  &((command-valid cmd) =(our owner.cmd) (valid:saved our value))
    [%| %owner-or-state]
  =/  agreement  (~(get by pacts.state.value) pact.cmd)
  ?~  agreement  [%| %pact-missing]
  =/  current  value.u.agreement
  ?.  ?|  &(=(our left.terms.current) =(peer.cmd right.terms.current))
          &(=(our right.terms.current) =(peer.cmd left.terms.current))
      ==
    [%| %peer-mismatch]
  =/  held  (~(get by rounds.artifacts.value) [pact.cmd generation.current %land])
  ?~  held  [%| %round-missing]
  ?.  (ready:round u.held current selected.cmd)  [%| %both-current-owner-approvals-required]
  ?~  proposal.u.held  [%| %proposal-missing]
  =/  proposal=proposal:r  u.proposal.u.held
  ?.  &(?=(%land -.target.proposal) =(our receiver.proposal) =(our ship.target.proposal))
    [%| %receiver-only]
  =/  item  (~(get by packages.state.value) package.proposal)
  ?~  item  [%| %package-missing]
  ?.  (proposal-bound:artifact artifacts.value current value.u.item %land proposal)
    [%| %proposal-binding]
  =/  evidence  (~(get by evidence.artifacts.value) build-proof.proposal)
  ?~  evidence  [%| %proof-missing]
  ?.  ?&  =(%local-canonical provenance.u.evidence)
          =(our builder.u.evidence)
          (local-valid:artifact our value.u.item receipt.u.evidence)
      ==
    [%| %canonical-receiver-build-required]
  =/  receipt=receipt:build  receipt.u.evidence
  ?.  ?=([* ~] files.body.offer.plan.body.receipt)
    [%| %one-exact-hoon-file-required]
  =/  file=file:pkg  i.files.body.offer.plan.body.receipt
  ?.  &((source-supported:build file) =(%hoon (rear file.target.proposal)))
    [%| %hoon-only]
  [%& [proposal receipt]]
++  admit
  |=  [our=@p actor=@p now=@da cmd=command value=saved:saved entries=journal]
  ^-  (each [journal=journal duplicate=?] @tas)
  ?.  &(=(our actor) (valid our entries) !=(0 now))  [%| %owner-required]
  =/  prior  (~(get by entries) (key cmd))
  ?^  prior  [%& [entries %.y]]
  ?:  (lien ~(val by entries) |=(old=entry =(request.command.old request.cmd)))
    [%| %request-conflict]
  ?.  =(guard.cmd (guard:action our peer.cmd pact.cmd value))  [%| %stale-guard]
  =/  chosen  (select our cmd value)
  ?:  ?=(%| -.chosen)  [%| p.chosen]
  ?:  (gte ~(wyt by entries) 256)  [%| %executor-capacity]
  =/  destination=target:r  target.proposal.p.chosen
  ?>  ?=(%land -.destination)
  =/  busy=?
    %+  lien  ~(val by entries)
    |=  old=entry
    ?.  ?=(?(%pending %uncertain) phase.old)  %.n
    ::  Retained immutable target keeps this desk locked even after revocation.
    ::  Unrelated private desks are not blocked by a stale request elsewhere.
    =/  target=target:r  target.proposal.selection.old
    ?>  ?=(%land -.target)
    =(desk.destination desk.target)
  ?:  busy  [%| %receiver-execution-unresolved]
  =/  next=entry  [cmd now p.chosen %pending ~ %native-pipeline-pending]
  [%& [(~(put by entries) (key cmd) next) %.n]]
++  native-start
  ::  A source-bound EXISTING receiver session is necessary before journalled
  ::  handoff. Its standing grant and review permissions remain Cantrip's job.
  |=  [b=bowl:gall cmd=command value=saved:saved entries=journal]
  ^-  (each [journal=journal duplicate=?] @tas)
  ?.  &(=(our.b src.b) =(our.b owner.cmd))  [%| %receiver-owner-required]
  ?:  (~(has by entries) (key cmd))  (admit our.b src.b now.b cmd value entries)
  ?.  &((agent-live:guard our.b now.b %viki) (agent-live:guard our.b now.b %cantrip))
    [%| %native-authority-unavailable]
  =/  chosen  (select our.b cmd value)
  ?:  ?=(%| -.chosen)  [%| p.chosen]
  =/  target=target:r  target.proposal.p.chosen
  ?>  ?=(%land -.target)
  ?.  (target-private:action b target)  [%| %private-target-drift]
  =/  problem  (verify-workspace:build our.b now.b plan.body.receipt.p.chosen)
  ?^  problem  [%| u.problem]
  ::  Complete bounded canonical journal is required before durable handoff.
  =/  raw=*
    .^(* %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/session/(scot %ux session.cmd)/noun)
  =/  parsed  (session-admission our.b session.cmd raw)
  ?:  ?=(%| -.parsed)  [%| p.parsed]
  =/  session=session:nc  p.parsed
  ?.  ?&  =(session.cmd id.session)  =(our.b owner.session)
          =(our.b owner.working.session)  =(desk.target desk.working.session)
          =(revision.target number.working.session)  =(root.target root.working.session)
      ==
    [%| %native-session-target-mismatch]
  (admit our.b src.b now.b cmd value entries)
++  command-header
  |=  req=inbound-request:eyre
  ^-  (unit @t)
  (header:mg header-list.request.req 'x-readymade-executor-command')
++  ready-request
  |=  req=inbound-request:eyre
  ^-  ?
  &((ready-request:action req) =(`'execute-v1' (header:mg header-list.request.req 'x-readymade-artifact-executor')))
++  parse
  |=  raw=@t
  ^-  (unit command)
  ?.  (lte (met 3 raw) 4.096)  ~
  (mole |.((decode raw)))
++  decode
  |=  raw=@t
  ^-  command
  =/  json  (need (de:json:html raw))
  ?>  ?=(%o -.json)
  =/  obj  p.json
  ?>  =((silt `(list @t)`~['schema' 'owner' 'peer' 'request' 'pact' 'selected' 'guard' 'session']) ~(key by obj))
  ?>  =('readymade-artifact-execute-v1' (text-field:action obj 'schema' 64))
  =/  owner=@t  (text-field:action obj 'owner' 128)
  =/  peer=@t  (text-field:action obj 'peer' 128)
  =/  ship=@p  (need (slaw %p owner))
  =/  other=@p  (need (slaw %p peer))
  ?>  &(=(owner (scot %p ship)) =(peer (scot %p other)))
  =/  cmd=command
    :*  %readymade-artifact-execute-v1
        ship
        other
        (text-field:action obj 'request' 36)
        (ux:action (text-field:action obj 'pact' 256))
        (ux:action (text-field:action obj 'selected' 256))
        (ux:action (text-field:action obj 'guard' 256))
        (ux:action (text-field:action obj 'session' 256))
    ==
  ?>  (command-valid cmd)
  cmd
++  read-context
  ::  Only the always-supported route is read. Old/unknown packets refuse
  ::  before per-nonce lookup; no new GX route is probed.
  |=  [our=@p now=@da nonce=@ux]
  ^-  (each context @tas)
  ?.  (agent-live:guard our now %readymade-collab)  [%| %collaboration-unavailable]
  =/  raw=*
    .^(* %gx /(scot %p our)/readymade-collab/(scot %da now)/state/noun)
  =/  decoded  (read-executor:reader our raw)
  ?:  ?=(%| -.decoded)  [%| p.decoded]
  =/  held  (~(get by executions.p.decoded) nonce)
  ?~  held  [%| %executor-request-missing]
  =/  prior=packet:reader  previous.p.decoded
  =/  value=saved:saved
    [%readymade-collab-app-v4 state.prior ~ ~ ~ artifacts.prior]
  [%& [u.held value]]
++  tool-arguments
  ::  Existing project scopes, namespace/delta rules and fleet reservations
  ::  are still checked by Viki and Cantrip. This arm never writes source.
  |=  [our=@p now=@da held=context p=project:nc current=tree:nc]
  ^-  (each tool-args:nc @tas)
  =/  cmd=command  command.entry.held
  ?.  ?=(?(%pending %uncertain) phase.entry.held)  [%| %executor-not-pending]
  =/  chosen  (select our cmd previous.held)
  ?:  ?=(%| -.chosen)  [%| p.chosen]
  ?.  =(selection.entry.held p.chosen)  [%| %artifact-selection-changed]
  =/  selected=selected  p.chosen
  =/  target=target:r  target.proposal.selected
  ?>  ?=(%land -.target)
  ?.  ?&  =(our authority.spec.p)  =(working.p desk.target)
          =(our owner.revision.current)  =(desk.target desk.revision.current)
          =(revision.target number.revision.current)  =(root.target root.revision.current)
          (writable:project p file.target)
      ==
    [%| %managed-session-target-mismatch]
  =/  b=bowl:gall  *bowl:gall
  =.  b  b(our our, src our, now now)
  ?.  (target-private:action b target)  [%| %target-no-longer-private]
  =/  problem  (verify-workspace:build our now plan.body.receipt.selected)
  ?^  problem  [%| u.problem]
  =/  sources=(list file:pkg)  files.body.offer.plan.body.receipt.selected
  ?>  ?=([* ~] sources)
  =/  source=file:pkg  i.sources
  =/  plan=plan:build  plan.body.receipt.selected
  =/  raw=*
    .^(* %cq (weld ~[(scot %p our) destination.plan (scot %ud revision.plan)] path.source))
  =/  parsed=(unit @t)  ((soft @t) raw)
  ?~  parsed  [%| %canonical-build-source-drift]
  =/  bytes=@t  u.parsed
  ?.  =(source (source-file:package path.source bytes))  [%| %canonical-build-source-drift]
  =/  before=(unit @ux)  (~(get by files.body.snapshot.current) file.target)
  ?~  before  [%& [%create file.target [%hoon bytes]]]
  [%& [%replace file.target u.before [%hoon bytes]]]
++  permission
  ::  Necessary ADDITIONAL Cantrip gate. Existing grant+scope+Viki pending,
  ::  project catalog, candidate checks and local-review law remain necessary.
  |=  [our=@p now=@da p=project:nc request=tool-request:nc]
  ^-  (each ~ @tas)
  ?.  (marked call-id.request)  [%& ~]
  =/  nonce  (call-key call-id.request)
  ?~  nonce  [%| %artifact-call-id-invalid]
  =/  captured  (read-context our now u.nonce)
  ?:  ?=(%| -.captured)  [%| p.captured]
  =/  held=context  p.captured
  =/  cmd=command  command.entry.held
  ?.  &(=(session.cmd session.context.request) =(u.nonce request.context.request) =(our actor.context.request))
    [%| %artifact-request-context-mismatch]
  =/  current  (current:project our now p)
  ?:  ?=(%| -.current)  [%| p.current]
  =/  expected  (tool-arguments our now held p working.p.current)
  ?:  ?=(%| -.expected)  [%| p.expected]
  ?.  &(=(arguments.request p.expected) =(source.context.request revision.working.p.current))
    [%| %artifact-request-body-mismatch]
  ?.  (agent-live:guard our now %cantrip)  [%| %current-law-unavailable]
  =/  raw=*  .^(* %gx /(scot %p our)/cantrip/(scot %da now)/law/window/current/noun)
  =/  window  ((soft window:law) raw)
  ?~  window  [%| %current-law-invalid]
  ?.  &((~(has in admissible.u.window) %implement) !(~(has in blocked.u.window) %implement))
    [%| %current-implement-law-refused]
  [%& ~]
++  settle
  ::  Native wrapper supplies canonical Viki status + Cantrip acceptance row.
  ::  Neither Gall ACK nor missing status proves a refusal or a completed write.
  |=  [our=@p held=entry observed=status accepted=(unit record:accept) evidence=(unit tool-result:nc)]
  ^-  entry
  ?.  ?=(?(%pending %uncertain) phase.held)  held
  =/  cmd=command  command.held
  ?.  &(=(our owner.cmd) =(session.cmd session.observed) =((key cmd) nonce.observed))  held
  ::  Viki may retain a candidate while a later row projects refusal. Only
  ::  its exact Cantrip acceptance record can terminate that candidate.
  ?:  &(?=(^ candidate.held) ?=(^ candidate.observed) !=(candidate.held candidate.observed))  held
  =.  observed
    observed(candidate ?~(candidate.observed candidate.held candidate.observed))
  ?~  candidate.observed  held
  ?~  accepted  held
  =/  record=record:accept  u.accepted
  ?.  (valid:accept (~(put by *ledger:accept) u.candidate.observed record))  held
  =/  candidate=candidate:nc  candidate.record
  ?~  evidence  held
  ?.  (candidate-result-matches held candidate u.evidence)  held
  =/  target=target:r  target.proposal.selection.held
  ?>  ?=(%land -.target)
  ?.  ?&  =(u.candidate.observed id.candidate)
          =(session.cmd session.context.candidate)
          =((key cmd) request.context.candidate)
          =(our actor.context.candidate)
          =(our owner.source.context.candidate)
          =(desk.target desk.source.context.candidate)
          =(revision.target number.source.context.candidate)
          =(root.target root.source.context.candidate)
          ?=([* ~] edits.candidate)
      ==
    held
  =/  edit=edit:nc  i.edits.candidate
  ?.  &(=(file.target path.change.edit) ?=(^ content.edit))  held
  =/  content=replacement:nc  u.content.edit
  =/  sources=(list file:pkg)  files.body.offer.plan.body.receipt.selection.held
  ?.  ?=([* ~] sources)  held
  =/  source=file:pkg  i.sources
  ?.  &(=(%hoon mark.content) =(source (source-file:package path.source source.content)))  held
  ?:  =(%applied stage.record)
    held(phase %applied, candidate candidate.observed, reason %cantrip-landing-readback-confirmed)
  ?:  =(%refused stage.record)
    held(phase %refused, candidate candidate.observed, reason %native-cantrip-refused)
  held(candidate candidate.observed)
++  candidate-result-matches
  |=  [held=entry candidate=candidate:nc result=tool-result:nc]
  ^-  ?
  =/  cmd=command  command.held
  ?.  ?=(%candidate -.output.result)  %.n
  ?&  =((call-id (key cmd)) call-id.result)
      =(session.cmd session.context.result)
      =((key cmd) request.context.result)
      =(owner.cmd actor.context.result)
      =(context.candidate context.result)
      =(candidate value.output.result)
  ==
++  candidate-evidence
  ::  The existing public session supplies the call-id omitted by git-status.
  ::  Require a complete bounded journal and exactly one candidate result.
  |=  $:  held=entry  candidate=candidate:nc
          session=@ux  owner=@p  sequence=@ud
          rows=(list record:sessions)
      ==
  ^-  (unit tool-result:nc)
  =/  cmd=command  command.held
  ?.  &(=(session.cmd session) =(owner.cmd owner) (gte sequence 1) (lte sequence 4.096) =(sequence (lent rows)))  ~
  =|  index=@ud
  =|  found=(unit tool-result:nc)
  |-  ^-  (unit tool-result:nc)
  ?~  rows  found
  =/  row=record:sessions  i.rows
  ?.  =(index sequence.row)  ~
  ?.  ?=(%tool -.body.row)  $(rows t.rows, index +(index))
  =/  result=tool-result:nc  result.body.row
  ?.  |(=((call-id (key cmd)) call-id.result) &(=(session.cmd session.context.result) =((key cmd) request.context.result)))
    $(rows t.rows, index +(index))
  ?.  &(=(call-id.result (call-id (key cmd))) =(session.cmd session.context.result) =((key cmd) request.context.result) =(owner.cmd actor.context.result))  ~
  ?:  ?=(%unknown -.output.result)
    ?^(found ~ $(rows t.rows, index +(index)))
  ?.  (candidate-result-matches held candidate result)  ~
  ?^  found  ~
  $(rows t.rows, index +(index), found `result)
++  predispatch-refused
  ::  Join the retained nonce status with the existing full public session.
  ::  append:sessions never evicts; only artifact-command's reject arm emits
  ::  this exact prefix, stores inputs[nonce], and returns without a tool card.
  |=  $:  our=@p  held=entry  observed=status
          session=@ux  owner=@p  sequence=@ud
          rows=(list record:sessions)
      ==
  ^-  ?
  =/  cmd=command  command.held
  ?.  ?&  =(our owner.cmd)  =(our owner)
          =(session.cmd session)  =(session.cmd session.observed)
          =((key cmd) nonce.observed)  =(%refused phase.observed)
          =(~ candidate.held)  =(~ candidate.observed)
          (gte sequence 1)  (lte sequence 4.096)
          =(sequence (lent rows))
      ==
    %.n
  =/  input=@t  (call-id (key cmd))
  =/  prefix=@t  'Artifact proposal refused: '
  =|  index=@ud
  =|  matches=@ud
  |-  ^-  ?
  ?~  rows  =(1 matches)
  =/  row=record:sessions  i.rows
  ?.  =(index sequence.row)  %.n
  ?:  ?=(%terminal -.body.row)
    ?.  =(input input.body.row)  $(rows t.rows, index +(index))
    ?.  &((gth (met 3 output.body.row) (met 3 prefix)) (lte (met 3 output.body.row) 256) =(prefix (end [3 (met 3 prefix)] output.body.row)))  %.n
    $(rows t.rows, index +(index), matches +(matches))
  ?:  ?=(%tool -.body.row)
    =/  result=tool-result:nc  result.body.row
    ?:  |(=(input call-id.result) &(=(session.cmd session.context.result) =((key cmd) request.context.result)))  %.n
    $(rows t.rows, index +(index))
  $(rows t.rows, index +(index))
++  observe
  |=  [our=@p now=@da held=entry]
  ^-  entry
  ?.  ?=(?(%pending %uncertain) phase.held)  held
  ?.  &((agent-live:guard our now %viki) (agent-live:guard our now %cantrip))  held
  =/  cmd=command  command.held
  ::  Historical route name, generic implementation: git-status correlates
  ::  ANY retained owner input + tool result by exact session/request. Never
  ::  use git-lookup, which is origin-specific. No Git authority is inferred.
  =/  raw=*
    .^(* %gx /(scot %p our)/viki/(scot %da now)/native-coding/git-proposal/(scot %ux session.cmd)/(scot %ux (key cmd))/noun)
  =/  legacy  ((soft candidate-status:legacy-status) raw)
  ?~  legacy  held
  =/  observed=status
    [%readymade-artifact-pipeline-status-v1 session.u.legacy request.u.legacy state.u.legacy candidate.u.legacy reason.u.legacy]
  ?:  &(?=(%refused phase.observed) =(~ candidate.held) =(~ candidate.observed))
    =/  raw=*
      .^(* %gx /(scot %p our)/viki/(scot %da now)/native-coding/session/(scot %ux session.cmd)/noun)
    =/  view
      ((soft (unit session-view)) raw)
    ?~  view  held
    ?~  u.view  held
    ?.  (predispatch-refused our held observed id.session.u.u.view owner.session.u.u.view sequence.u.u.view records.u.u.view)  held
    held(phase %refused, reason %native-viki-predispatch-refused)
  ?:  &(?=(^ candidate.held) ?=(^ candidate.observed) !=(candidate.held candidate.observed))  held
  =.  observed
    observed(candidate ?~(candidate.observed candidate.held candidate.observed))
  =/  accepted=(unit record:accept)
    ?~  candidate.observed  ~
    =/  raw=*
      .^(* %gx /(scot %p our)/cantrip/(scot %da now)/native-coding/candidate/(scot %ux u.candidate.observed)/noun)
    (need ((soft (unit record:accept)) raw))
  ?~  accepted  held
  =/  raw=*
    .^(* %gx /(scot %p our)/viki/(scot %da now)/native-coding/session/(scot %ux session.cmd)/noun)
  =/  view
    ((soft (unit session-view)) raw)
  ?~  view  held
  ?~  u.view  held
  =/  evidence=(unit tool-result:nc)
    (candidate-evidence held candidate.u.accepted id.session.u.u.view owner.session.u.u.view sequence.u.u.view records.u.u.view)
  =/  settled=entry  (settle our held observed accepted evidence)
  ?.  =(%applied phase.settled)  settled
  ?~  landed.u.accepted  held
  =/  landed=tree:nc  u.landed.u.accepted
  =/  current  (current:project our now project.u.accepted)
  ?:  ?=(%| -.current)  held(phase %uncertain, reason %landing-readback-unavailable)
  ?.  =(landed working.p.current)  held(phase %uncertain, reason %landing-current-tree-drift)
  =/  target=target:r  target.proposal.selection.held
  ?>  ?=(%land -.target)
  =.  target
    target(revision number.revision.landed, root `@ux`root.revision.landed)
  =/  b=bowl:gall  *bowl:gall
  =.  b  b(our our, src our, now now)
  ?.  (target-private:action b target)  held(phase %uncertain, reason %landing-private-target-drift)
  =/  edits=(list edit:nc)  edits.candidate.u.accepted
  ?.  ?=([* ~] edits)  held
  ?~  content.i.edits  held
  =/  raw=*
    .^(* %cq (weld ~[(scot %p our) desk.target (scot %ud revision.target)] file.target))
  =/  parsed=(unit @t)  ((soft @t) raw)
  ?~  parsed  held(phase %uncertain, reason %landing-current-source-drift)
  =/  bytes=@t  u.parsed
  ?.  =(bytes source.u.content.i.edits)  held(phase %uncertain, reason %landing-current-source-drift)
  settled
++  session-json
  |=  [session=session:nc phase=phase:sessions]
  ^-  json
  %-  pairs:enjs:format
  ^-  (list [@t json])
  :~  ['id' s+(scot %ux id.session)]
      ['project' s+project.session]
      ['owner' s+(scot %p owner.session)]
      ['phase' s+(scot %tas phase)]
      ['working' (pairs:enjs:format `(list [@t json])`~[['ship' s+(scot %p owner.working.session)] ['desk' s+(scot %tas desk.working.session)] ['revision' s+(scot %ud number.working.session)] ['root' s+(scot %ux `@ux`root.working.session)] ['commit' s+(scot %ux `@ux`commit.working.session)]])]
      ['permissionGranted' b+%.n]
      ['sharedExecutorAdmitted' b+%.y]
  ==
++  native-sessions
  ::  Existing public session DTO; selection/records/summary stay private.
  ::  This list is choice metadata, never admission or permission evidence.
  |=  b=bowl:gall
  ^-  (each json @tas)
  ?.  &(=(our.b src.b) (agent-live:guard our.b now.b %viki))  [%| %viki-unavailable]
  =/  raw=*
    .^(* %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/sessions/noun)
  =|  count=@ud
  =|  out=(list json)
  |-  ^-  (each json @tas)
  ?~  raw
    =/  body=json
      (pairs:enjs:format `(list [@t json])`~[['schema' s+'readymade-artifact-executor-sessions-v1'] ['owner' s+(scot %p our.b)] ['sessions' a+(flop out)] ['permissionGranted' b+%.n] ['sharedExecutorAdmitted' b+%.y]])
    ?.  (lte (met 3 (en:json:html body)) 65.536)  [%| %session-catalog-bytes]
    [%& body]
  ?.  &(?=(^ raw) (lth count 64))  [%| %session-catalog-capacity]
  =/  row
    ((soft ,[session=session:nc phase=phase:sessions selection=* worker=@p records=* summary=@t sequence=@ud]) -.raw)
  ?~  row  [%| %session-catalog-invalid]
  =/  value=session:nc  session.u.row
  ?.  ?&  =(our.b owner.value)  (digest-valid:package id.value)
          (gte (met 3 project.value) 1)  (lte (met 3 project.value) 128)
          =(our.b owner.working.value)
          &((gth (met 3 desk.working.value) 0) (lte (met 3 desk.working.value) 128) ((sane %tas) desk.working.value))
          (lte (met 0 number.working.value) 64)
          (lte (met 0 root.working.value) 256)
          (lte (met 0 commit.working.value) 256)
      ==
    [%| %session-catalog-invalid]
  $(raw +.raw, count +(count), out [(session-json value phase.u.row) out])
++  json-result
  |=  [our=@p held=entry]
  ^-  json
  (command-json our command.held phase.held candidate.held reason.held)
++  refusal-json
  |=  [our=@p cmd=command reason=@tas]
  ^-  json
  (command-json our cmd %refused ~ reason)
++  command-json
  |=  [our=@p cmd=command phase=@tas candidate=(unit @ux) reason=@tas]
  ^-  json
  %-  pairs:enjs:format
  ^-  (list [@t json])
  :~  ['schema' s+'readymade-artifact-executor-result-v1']
      ['owner' s+(scot %p our)]
      ['peer' s+(scot %p peer.cmd)]
      ['request' s+request.cmd]
      ['session' s+(scot %ux session.cmd)]
      ['pact' s+(scot %ux pact.cmd)]
      ['selected' s+(scot %ux selected.cmd)]
      ['guard' s+(scot %ux guard.cmd)]
      ['nonce' s+(scot %ux (key cmd))]
      ['status' s+(scot %tas phase)]
      ['candidate' ?~(candidate ~ s+(scot %ux u.candidate))]
      ['reason' s+(scot %tas reason)]
      ['sharedExecutorAdmitted' b+%.y]
  ==
--
