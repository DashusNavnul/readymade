::  Authenticate proposals before Viki journals or materializes them. Private
::  provider reads only; this neither calls a model nor grants an action.
/-  np=native-coding-provider, ci=cli-inference
/+  inference=native-coding-inference, provider=native-coding-provider,
    outbound=native-coding-provider-request, inbound=native-coding-provider-response,
    guard=viki-scry-guard, cli=cli-inference
|%
+$  retained
  [request=request:np body=@t outcome=outcome:inference evidence=(unit evidence:inference)]
+$  index-row  [id=@ux session=@ux selection=@tas outcome=@tas bytes=@ud]
++  validate
  ::  Pure consistency is not issuer authentication. +confirm supplies the
  ::  canonical record; accepting a caller-created retained noun would bypass it.
  |=  [wanted=request:np delivered=reply:np kept=retained]
  ^-  (unit @tas)
  ?.  &((request-valid:provider wanted) =(wanted request.kept))
    `%qpc-provider-request-mismatch
  ?.  ?=(%result -.outcome.kept)  `%qpc-provider-result-unavailable
  ?.  =(delivered value.outcome.kept)  `%qpc-provider-event-mismatch
  ?~  evidence.kept  `%qpc-provider-evidence-missing
  =/  e=evidence:inference  u.evidence.kept
  =/  r=reply:np  value.outcome.kept
  ?.  ?&  =(200 status.e)  !truncated.e
          (gth bytes.e 0)  (lte bytes.e response-limit:np)
          =(bytes.e p.prefix.e)  =(bytes.e (met 3 q.prefix.e))
          =(raw.r q.prefix.e)  =(digest.e raw-digest.r)
          =(digest.e (shax raw.r))
          =(id.wanted id.r)
          (model-matches:provider selection.wanted provider.r model.r)
      ==  `%qpc-provider-evidence-invalid
  =/  encoded  (encode:outbound wanted)
  ?.  ?=(%& -.encoded)  `%qpc-provider-request-encoding
  ?.  =(p.encoded body.kept)  `%qpc-provider-body-mismatch
  =/  decoded  (decode:inbound wanted status.e prefix.e)
  ?.  ?=(%& -.decoded)  `%qpc-provider-decode-refused
  ?.  =(p.decoded r)  `%qpc-provider-normalization-mismatch
  ~
++  indexed
  |=  [wanted=request:np key=@tas rows=(list index-row)]
  ^-  ?
  =/  matches=(list index-row)  (skim rows |=(r=index-row =(id.wanted id.r)))
  ?~  matches  %.n
  ?^  t.matches  %.n
  &(=(session.wanted session.i.matches) =(key selection.i.matches) =(%result outcome.i.matches))
++  lookup
  |=  [our=@p at=@da id=@ux session=@ux key=@tas]
  ^-  (each retained @tas)
  ?.  (agent-live:guard our at %codex-inference)  [%| %qpc-provider-unavailable]
  ::  Missing /evidence paths block an event rather than returning a unit.
  ::  Preflight its hot index in the same event, before reading that path.
  =/  raw=*
    .^(* %gx /(scot %p our)/codex-inference/(scot %da at)/native-coding/jobs/noun)
  =/  rows  ((soft ,(list index-row)) raw)
  ?~  rows  [%| %qpc-provider-index-invalid]
  =/  wanted=request:np  *request:np
  ?.  (indexed wanted(id id, session session) key u.rows)  [%| %qpc-provider-result-not-retained]
  =/  raw=*
    .^(* %gx /(scot %p our)/codex-inference/(scot %da at)/native-coding/evidence/(scot %ux id)/noun)
  =/  kept  ((soft retained) raw)
  ?~  kept  [%| %qpc-provider-record-invalid]
  ?.  &(=(id id.request.u.kept) =(session session.request.u.kept))
    [%| %qpc-provider-request-mismatch]
  [%& u.kept]
++  lookup-cli
  ::  Canonical native job; no HTTP evidence is synthesized for this transport.
  |=  [our=@p at=@da id=@ux session=@ux key=@tas]
  ^-  (each job:ci @tas)
  ?.  (agent-live:guard our at %cli-inference)  [%| %qpc-cli-unavailable]
  =/  raw=*
    .^(* %gx /(scot %p our)/cli-inference/(scot %da at)/job/(scot %ux id)/noun)
  =/  parsed  ((soft ,(unit job:ci)) raw)
  ?~  parsed  [%| %qpc-cli-record-invalid]
  =/  kept=(unit job:ci)  u.parsed
  ?~  kept  [%| %qpc-cli-result-not-retained]
  ?.  &(=(id id.request.u.kept) =(session session.request.u.kept) =(key key.u.kept))
    [%| %qpc-cli-pairing-mismatch]
  [%& u.kept]
++  confirm-cli
  ::  CLI evidence is a native retained claim/result, never an HTTP receipt.
  |=  [our=@p at=@da wanted=request:np key=@tas delivered=reply:np]
  ^-  (unit @tas)
  =/  kept  (lookup-cli our at id.wanted session.wanted key)
  ?:  ?=(%| -.kept)  `p.kept
  (validate-evidence:cli wanted delivered p.kept)
++  confirm
  |=  [our=@p at=@da wanted=request:np key=@tas delivered=reply:np]
  ^-  (unit @tas)
  ?:  ?=(^ (cli-backend:provider selection.wanted))
    (confirm-cli our at wanted key delivered)
  =/  kept  (lookup our at id.wanted session.wanted key)
  ?:  ?=(%| -.kept)  `p.kept
  (validate wanted delivered p.kept)
--
