::  Declared soft-criterion energy for the first task binding (contract 5.1):
::  E = (wf*lf + wi*li) / (wf + wi). Footprint lf = min(1, changed/8), with
::  changed = removed plus added logical lines of the exact %patch diff.
::  Indirection has no evaluator: its loss is 1 and stays visibly unknown.
::  Authored engineering preference, not a measure of truth. No authority.
/-  nc=native-coding
/+  select=qpc-select
|%
+$  loss  [value=ratio:select known=?]
+$  energy
  $:  %qpc-energy-v1
      footprint=loss  changed=(unit @ud)  indirection=loss
      weights=[footprint=@ud indirection=@ud]  value=ratio:select
  ==
++  span  8
++  window  64
++  lines
  ::  LF-delimited logical lines; a trailing LF ends a line, it adds none.
  |=  text=@t
  ^-  (list @t)
  ?:  =(0 (met 3 text))  ~
  (to-wain:format text)
++  common
  |=  [a=(list @t) b=(list @t)]
  ^-  @ud
  =/  n=@ud  0
  |-  ^-  @ud
  ?~  a  n
  ?~  b  n
  ?.  =(i.a i.b)  n
  $(a t.a, b t.b, n +(n))
++  lcs
  ::  Exact longest common subsequence length, one DP row at a time.
  |=  [a=(list @t) b=(list @t)]
  ^-  @ud
  =/  row=(list @ud)  (reap +((lent b)) 0)
  |-  ^-  @ud
  ?~  a  (rear row)
  =/  next=(list @ud)  ~[0]
  =/  left=@ud  0
  =/  diagonal=(list @ud)  row
  =/  above=(list @ud)  (slag 1 row)
  =/  todo=(list @t)  b
  |-  ^-  @ud
  ?~  todo
    ^$(a t.a, row (flop next))
  ?>  &(?=(^ diagonal) ?=(^ above))
  =/  cell=@ud
    ?:  =(i.a i.todo)  +(i.diagonal)
    (max left i.above)
  $(todo t.todo, next [cell next], left cell, diagonal t.diagonal, above t.above)
++  changed
  ::  ~ when the trimmed remainder is too large to diff exactly here.
  |=  [before=@t after=@t]
  ^-  (unit @ud)
  =/  a=(list @t)  (lines before)
  =/  b=(list @t)  (lines after)
  =/  head=@ud  (common a b)
  =.  a  (slag head a)
  =.  b  (slag head b)
  =/  tail=@ud  (common (flop a) (flop b))
  =.  a  (flop (slag tail (flop a)))
  =.  b  (flop (slag tail (flop b)))
  ?:  |(=(~ a) =(~ b))  `(add (lent a) (lent b))
  ?:  |((gth (lent a) window) (gth (lent b) window))  ~
  =/  same=@ud  (lcs a b)
  `(sub (add (lent a) (lent b)) (mul 2 same))
++  footprint
  |=  args=tool-args:nc
  ^-  [loss (unit @ud)]
  ?.  ?=(%patch -.args)  [[[1 1] %.n] ~]
  =/  count  (changed expected.args replacement.args)
  ?~  count  [[[1 1] %.n] ~]
  [[[(min u.count span) span] %.y] count]
++  measure
  ::  Weights are the law's admitted criterion weights; both zero is refused.
  |=  [args=(unit tool-args:nc) weights=[footprint=@ud indirection=@ud]]
  ^-  (each energy @tas)
  ?:  =(0 (add footprint.weights indirection.weights))  [%| %energy-weights-empty]
  =/  [fp=loss count=(unit @ud)]
    ?~  args  [[[1 1] %.n] ~]
    (footprint u.args)
  =/  ind=loss  [[1 1] %.n]
  =/  total=@ud  (add footprint.weights indirection.weights)
  =/  num=@ud
    %+  add  (mul footprint.weights (mul num.value.fp den.value.ind))
    (mul indirection.weights (mul num.value.ind den.value.fp))
  =/  den=@ud  (mul total (mul den.value.fp den.value.ind))
  [%& [%qpc-energy-v1 fp count ind weights [num den]]]
--
