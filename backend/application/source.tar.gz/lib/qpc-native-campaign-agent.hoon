::  Bounded native recurrence for an explicit useful task. Existing owners
::  retain every observation, candidate, draw, admission and project effect.
/-  nc=native-coding
/+  campaign=qpc-native-campaign, read=qpc-native-campaign-read,
    instrument=qpc-instrument-contract, observer=qpc-observer,
    sessions=native-coding-session, loop=native-coding-loop,
    declaration=qpc-native-declaration, successor=qpc-successor-window,
    bind=qpc-native-owner-binding, obs=qpc-observation,
    admission=qpc-measurement-admission, appstate=qpc-native-app-state,
    project=native-coding-project, reviews=native-coding-local-review-state,
    native-review=native-coding-review, local=native-coding-local-decision,
    accept=native-coding-accept, completion=native-coding-completion,
    task-completion=qpc-native-task-completion-runtime,
    handoff=qpc-native-task-handoff-runtime
|%
+$  reading
  $-([inner=agent:gall b=bowl:gall r=record:campaign] (each (unit reading:successor) @tas))
+$  ending
  $-([inner=agent:gall b=bowl:gall r=record:campaign] (each terminal:read @tas))
+$  gating  $-([inner=agent:gall b=bowl:gall child=child:campaign] (unit @tas))
+$  dispatch-ticket  [enrollment=@ux snapshot=@ux due=@da]
+$  dispatch-plan
  [plan=* active=? step=@ud segment=@ux ticket=(unit dispatch-ticket) awaiting=(unit @ux) reason=(unit @tas)]
+$  dispatch-witness
  [id=@ux member=@ux request=@ux turn=@ud identity=@ux entry=@ux plan=dispatch-plan]
++  unreviewed
  ::  Preserve only the ordinary checkpoint before its independent review
  ::  starts. A pending or finished local review remains under normal recovery.
  |=  [member=@ux parts=(list part:appstate)]
  ^-  ?
  =/  rows=(list part:appstate)
    (skim parts |=(p=part:appstate =(%native-local-review-owner-v3 tag.p)))
  ?.  =(1 (lent rows))  %.n
  =/  value=part:appstate  (snag 0 rows)
  =/  parsed  ((soft ,state:reviews) data.value)
  ?~  parsed  %.n
  !(lien ~(val by campaigns.u.parsed) |=(r=campaign:reviews =(member session.context.candidate.frozen.request.r)))
++  quiet-review
  ::  An unchanged idle checkpoint is history, not renewed execution authority.
  ::  Native load checks the entire inner DATA before applying this predicate.
  |=  [our=@p r=record:campaign e=entry:sessions key=@tas grant=@ux p=dispatch-plan]
  ^-  ?
  =/  c=command:campaign  command.task.r
  =/  plan=plan:instrument  plan.snapshot.task.r
  ?&  =(our owner.task.r)  =(%collecting phase.r)
      ?=(~ due.r)  ?=(~ request.r)  ?=(~ child.r)
      =(%judgment phase.e)  =(%judgment resume.e)
      ?=(~ pending.e)  ?=(~ calls.e)
      =(member.c id.session.e)  =(our owner.session.e)  =(our worker.e)
      =(objective.c objective.session.e)
      =(project.manifest.plan project.session.e)
      =((configuration:project project.snapshot.task.r) configuration.e)
      =(expected.c working.session.e)
      =(selection.manifest.plan selection.e)
      =(key.c key)  =(grant.c grant)
      =(plan plan.p)  active.p  ?=(~ ticket.p)
  ==
++  quiet-landed
  ::  Retain only the history of an already consumed one-step landing. This
  ::  pure saved-DATA join renews no authority and emits no continuation card.
  |=  $:  our=@p  r=record:campaign  e=entry:sessions  key=@tas  grant=@ux
          p=dispatch-plan  parts=(list part:appstate)  known=state:native-review
      ==
  ^-  ?
  =/  c=command:campaign  command.task.r
  =/  plan=plan:instrument  plan.snapshot.task.r
  ?.  ?&  =(our owner.task.r)  =(%collecting phase.r)
          ?=(~ due.r)  ?=(~ request.r)  ?=(~ child.r)
          =(%paused phase.e)  =(%ready resume.e)
          ?=(~ pending.e)  ?=(~ calls.e)
          =(member.c id.session.e)  =(our owner.session.e)  =(our worker.e)
          =(objective.c objective.session.e)
          =(project.manifest.plan project.session.e)
          =((configuration:project project.snapshot.task.r) configuration.e)
          =(selection.manifest.plan selection.e)
          =(key.c key)  =(grant.c grant)
          =(plan plan.p)  active.p  ?=(~ ticket.p)  ?=(~ awaiting.p)
          =(owner.expected.c owner.working.session.e)
          =(desk.expected.c desk.working.session.e)
          =(+(number.expected.c) number.working.session.e)
          (journal-valid:completion e)
      ==  %.n
  =/  rows=(list part:appstate)
    (skim parts |=(p=part:appstate =(%native-local-review-owner-v3 tag.p)))
  ?.  =(1 (lent rows))  %.n
  =/  state  ((soft ,state:reviews) data:(snag 0 rows))
  ?~  state  %.n
  =/  local-rows=(list campaign:reviews)
    (skim ~(val by campaigns.u.state) |=(h=campaign:reviews =(member.c session.context.candidate.frozen.request.h)))
  ?.  (levy local-rows |=(h=campaign:reviews &(?=(~ pending.h) ?=(~ reason.h) ?=(^ outcome.h))))
    %.n
  =/  owned=(list entry:native-review)
    (skim ~(val by known) |=(h=entry:native-review =(member.c session.context.candidate.h)))
  ?.  (levy owned |=(h=entry:native-review ?~(observed.h %.n ?=(?(%applied %refused) stage.u.observed.h))))
    %.n
  =/  landed=(list entry:native-review)
    (skim owned |=(h=entry:native-review ?~(observed.h %.n &(advanced.h =(%applied stage.u.observed.h) ?~(landed.u.observed.h %.n =(working.session.e revision.u.landed.u.observed.h))))))
  ?.  =(1 (lent landed))  %.n
  =/  h=entry:native-review  (snag 0 landed)
  =/  actual=record:accept  (need observed.h)
  =/  candidate  candidate.actual
  ?.  ?&  =(candidate.h candidate)
          =(project.snapshot.task.r project.actual)
          =(grant.c grant.actual)  =(expected.c source.context.candidate)
          =(member.c session.context.candidate)  =(our actor.context.candidate)
          =(project.session.e project.context.candidate)
          =(configuration.e configuration.context.candidate)
          (~(has in attempts.r) [member.c request.context.candidate])
          ?=(^ report.actual)  ?=(^ decision.actual)
          =(decision.h decision.actual)
          (valid:accept (~(put by *ledger:accept) id.candidate actual))
          (passed:accept (need report.actual))
          =(1 (lent edits.candidate))
          (levy edits.candidate |=(edit=edit:nc =(artifact.plan path.change.edit)))
      ==  %.n
  =/  goal  (objective:native-review e)
  ?:  ?=(%| -.goal)  %.n
  ?.  =(objective.h p.goal)  %.n
  =/  review  (~(get by campaigns.u.state) id.candidate)
  ?~  review  %.n
  ?.  ?&  ?=(^ challenge.u.review)  ?=(^ resolution.u.review)
          ?=(^ outcome.u.review)  =(%accept kind:(need outcome.u.review))
          =(scope.request.u.review reviewer.snapshot.task.r)
          =(`reviewer.snapshot.task.r (~(get by scopes.u.state) project.session.e))
      ==  %.n
  =/  decision  (decide:local our at:(need decision.actual) [`reviewer.snapshot.task.r u.review] project.actual candidate (need report.actual) p.goal)
  ?:  ?=(%| -.decision)  %.n
  ?.  &(=(p.decision (need decision.actual)) =(%approve verdict.p.decision))  %.n
  =/  results=(list record:sessions)
    (skim records.e |=(j=record:sessions ?.(?=(%tool -.body.j) %.n &(?=(%candidate -.output.result.body.j) =(context.candidate context.result.body.j) =(candidate value.output.result.body.j)))))
  =/  judgments=(list record:sessions)
    (skim records.e |=(j=record:sessions ?.(?=(%judgment -.body.j) %.n &(=(%continue verdict.body.j) (~(has in (silt evidence.body.j)) (digest:accept actual))))))
  ?.  &(=(1 (lent results)) =(1 (lent judgments)))  %.n
  =/  result=record:sessions  (snag 0 results)
  =/  judgment=record:sessions  (snag 0 judgments)
  &((lth sequence.result sequence.judgment) (gte at.judgment at:(need decision.actual)))
++  quiet-landed-read
  |=  [inner=agent:gall b=bowl:gall r=record:campaign e=entry:sessions key=@tas grant=@ux p=dispatch-plan parts=(list part:appstate)]
  ^-  ?
  =/  raw  (raw:instrument inner b /x/native-coding/reviews)
  ?~  raw  %.n
  =/  known  ((soft ,state:native-review) u.raw)
  ?~  known  %.n
  (quiet-landed our.b r e key grant p parts u.known)
++  dispatch-plan-read
  |=  [inner=agent:gall b=bowl:gall member=@ux]
  ^-  (unit dispatch-plan)
  =/  raw  (raw:instrument inner b /x/qpc/instrument/state)
  ?~  raw  ~
  =/  decoded  ((soft ,[plans=(map @ux dispatch-plan) rest=*]) u.raw)
  ?~  decoded  ~
  (~(get by plans.u.decoded) member)
++  dispatch-wake
  ::  The refusal fact has no request ID. Bind it to this callback's exact
  ::  retained ticket before delegating, never to an arbitrary later fact.
  |=  [s=state:campaign inner=agent:gall b=bowl:gall wire=wire sign=sign-arvo]
  ^-  (unit dispatch-witness)
  ?.  &(=(our.b src.b) ?=([%behn %wake ~] sign))  ~
  ?.  ?=([%qpc-instrument-wake @ @ @ @ ~] wire)  ~
  =/  parsed  (slaw %ux i.t.wire)
  ?~  parsed  ~
  =/  member=@ux  u.parsed
  =/  owners=(list [@ux record:campaign])
    (skim ~(tap by records.s) |=([id=@ux r=record:campaign] =(member member.command.task.r)))
  ?~  owners  ~
  ?.  =(1 (lent owners))  ~
  =/  [id=@ux r=record:campaign]  i.owners
  ?.  &(=(%collecting phase.r) ?=(~ due.r) ?=(~ request.r))  ~
  =/  found  (dispatch-plan-read inner b member)
  ?~  found  ~
  =/  p=dispatch-plan  u.found
  ?.  &(active.p ?=(^ ticket.p))  ~
  =/  t=dispatch-ticket  (need ticket.p)
  ?.  &((gte now.b due.t) =(`enrollment.t awaiting.p))  ~
  ?.  =(plan.p plan.snapshot.task.r)  ~
  ?.  =(wire /qpc-instrument-wake/(scot %ux member)/(scot %ux enrollment.t)/(scot %ux snapshot.t)/(scot %da due.t))  ~
  =/  input  (input:observer inner b member)
  ?~  input  ~
  =/  e=entry:sessions  entry.u.input
  ?.  &(=(%ready phase.e) ?=(~ pending.e) ?=(~ calls.e))  ~
  =/  request=@ux  (request-id:sessions member turn.e)
  ?.  (~(has in attempts.r) [member request])  ~
  =/  entry=@ux  (digest:obs e)
  ::  A journal note may stale this ticket without changing its request.
  ::  Join the owner's retained enrollment before attributing that refusal;
  ::  membership in the campaign's charged-attempt set alone is insufficient.
  =/  bound=?
    ?:  =(snapshot.t entry)  %.y
    =/  raw  (raw:instrument inner b /x/qpc/instrument/state)
    ?~  raw  %.n
    =/  saved  ((soft ,[plans=* admitted=state:admission rest=*]) u.raw)
    ?~  saved  %.n
    =/  enrollment  (~(get by enrollments.admitted.u.saved) enrollment.t)
    ?~  enrollment  %.n
    =/  original=enrollment:admission  u.enrollment
    ?&  =(enrollment.t id.original)  =(our.b owner.original)
        (enrollment-valid:admission original)
        =(member session.work.original)  =(request request.work.original)
        =(turn.e turn.before.original)
        =([session.e configuration.e selection.e worker.e] [session.before.original configuration.before.original selection.before.original worker.before.original])
        =(key.u.input key.command.task.r)  =(grant.u.input grant.command.task.r)
    ==
  ?.  bound  ~
  `[id member request turn.e (digest:obs [session.e configuration.e selection.e worker.e key.u.input grant.u.input]) entry p]
++  dispatch-refusal
  ::  This is a truthful dispatch failure, not a report or a settlement.
  |=  [w=dispatch-witness inner=agent:gall b=bowl:gall cards=(list card:agent:gall)]
  ^-  (unit @tas)
  =/  found  (dispatch-plan-read inner b member.w)
  ?~  found  ~
  =/  stale=?
    =(u.found plan.w(active %.n, ticket ~, awaiting ~, reason `%instrument-ticket-stale))
  ?.  |(stale =(u.found plan.w(ticket ~)))  ~
  =/  input  (input:observer inner b member.w)
  ?~  input  ~
  =/  e=entry:sessions  entry.u.input
  ?.  &(=(%ready phase.e) =(turn.w turn.e) ?=(~ pending.e) ?=(~ calls.e))  ~
  ?.  =(request.w (request-id:sessions member.w turn.e))  ~
  ?.  =(identity.w (digest:obs [session.e configuration.e selection.e worker.e key.u.input grant.u.input]))  ~
  ?:  (lien cards |=(card=card:agent:gall ?=(^ (infer:bind card))))  ~
  ::  The instrument cancels this exact enrollment without a refusal fact.
  ::  Retain its failure only if delegation preserved the actual entry too.
  ?:  stale  ?:(=(entry.w (digest:obs e)) `%instrument-ticket-stale ~)
  ?.  =(entry.w snapshot:(need ticket.plan.w))  ~
  =/  reasons=(set @tas)  ~
  |-  ^-  (unit @tas)
  ?~  cards
    ?.  =(1 ~(wyt in reasons))  ~
    `(snag 0 ~(tap in reasons))
  =/  fact  ((soft ,[%give %fact paths=(list path) mark=mark value=vase]) i.cards)
  ?~  fact  $(cards t.cards)
  ?.  =([paths.u.fact mark.u.fact] [~[/native-coding] %noun])  $(cards t.cards)
  =/  body  ((soft ,[%native-coding-refused-v1 member=@ux reason=@tas]) q.value.u.fact)
  ?~  body  $(cards t.cards)
  ?.  =(member.w member.u.body)  $(cards t.cards)
  $(cards t.cards, reasons (~(put in reasons) reason.u.body))
++  wrap
  ::  Internal native proof seams only, never fields of a public command.
  |=  [inner=agent:gall fetch=reader:read reading=reading ending=ending gating=gating]
  =/  held=state:campaign  empty:campaign
  ^-  agent:gall
  |_  =bowl:gall
  +*  this  .
      ag  ~(. inner bowl)
      filter
        |=  cards=(list card:agent:gall)
        ^-  (list card:agent:gall)
        %+  skim  cards
        |=  card=card:agent:gall
        =/  inferred  (infer:bind card)
        ?^  inferred  (dispatch:campaign held session.request.u.inferred id.request.u.inferred)
        =/  timer  ((soft ,[%pass [%native-coding %deadline session=@ta request=@ta ~] %arvo %b %wait at=@da]) card)
        ?~  timer  %.y
        =/  sid  (slaw %ux session.u.timer)
        =/  rid  (slaw %ux request.u.timer)
        ?~  sid  %.y
        ?~  rid  %.y
        (dispatch:campaign held u.sid u.rid)
      fail
        |=  [id=@ux reason=@tas]
        ^-  (quip card:agent:gall _this)
        =/  r=record:campaign  (~(got by records.held) id)
        =.  held  held(records (~(put by records.held) id (unavailable:campaign r %unknown reason)))
        [~[[%give %fact ~[/native-coding] %noun !>([%qpc-campaign-unavailable-v1 id reason])]] this]
      undispatched
        ::  A charged turn must reach the loop or a retained instrument
        ::  deferral; else name the instrument's recorded refusal.
        |=  member=@ux
        ^-  (unit @tas)
        =/  actual  (input:observer inner bowl member)
        ?~  actual  `%qpc-campaign-session-missing
        ?^  pending.entry.u.actual  ~
        =/  raw  (raw:instrument inner bowl /x/qpc/instrument/state)
        =/  plans  ?~(raw ~ ((soft ,[plans=(map @ux [plan=* active=? step=@ud segment=@ux ticket=(unit *) awaiting=(unit @ux) reason=(unit @tas)]) *]) u.raw))
        =/  r  ?~(plans ~ (~(get by plans.u.plans) member))
        ?:  &(?=(^ r) ?=(^ ticket.u.r))  ~
        `(fall ?~(r ~ reason.u.r) %qpc-campaign-dispatch-unconfirmed)
      schedule
        |=  [id=@ux r=record:campaign]
        ^-  (quip card:agent:gall _this)
        =/  due=@da  (add now.bowl ~s1)
        =.  r  r(due `due)
        =.  held  held(records (~(put by records.held) id r))
        [~[[%pass (wire-for:campaign id r) %arvo %b %wait due]] this]
      finish
        ::  No native namespace access here: ordinary callback DATA and cards
        ::  commit before a separately retained settlement/profile read.
        |=  cards=(list card:agent:gall)
        ^-  (quip card:agent:gall _this)
        =/  rows=(list [@ux record:campaign])  ~(tap by records.held)
        =/  added=(list card:agent:gall)  ~
        |-  ^-  (quip card:agent:gall _this)
        ?~  rows  [(weld (filter cards) added) this]
        =/  [id=@ux r=record:campaign]  i.rows
        ?.  &(=(~ due.r) (ready:read inner bowl r))  $(rows t.rows)
        =/  queued  (schedule id r)
        =.  held  held.+.queued
        $(rows t.rows, added (weld added -.queued))
      open-session
        |=  [id=@ux r=record:campaign session=@ux grant=@ux]
        ^-  (quip card:agent:gall _this)
        =/  c=command:campaign  command.task.r
        =/  p=plan:instrument  plan.snapshot.task.r
        =/  prepared
          (on-poke:~(. inner bowl(src our.bowl)) %noun !>([%native-coding-action-v1 [%open session project.manifest.p objective.c selection.manifest.p key.c grant our.bowl]]))
        =/  actual  (input:observer +.prepared bowl session)
        ?~  actual  (fail id %qpc-campaign-open-unconfirmed)
        ?.  ?&  =(expected.c working.session.entry.u.actual)
                =(objective.c objective.session.entry.u.actual)
                =(session id.session.entry.u.actual)
                =(key.c key.u.actual)  =(grant grant.u.actual)
                =(%ready phase.entry.u.actual)  =(0 turn.entry.u.actual)
                !(lien -.prepared |=(card=card:agent:gall ?=(^ (infer:bind card))))
            ==  (fail id %qpc-campaign-open-mismatch)
        [-.prepared this(inner +.prepared, held held(records (~(put by records.held) id r)))]
      wake
        |=  id=@ux
        ^-  (quip card:agent:gall _this)
        =/  r=record:campaign  (~(got by records.held) id)
        =/  c=command:campaign  command.task.r
        =.  r  r(due ~)
        =.  held  held(records (~(put by records.held) id r))
        ?:  =(%pool phase.r)
          =/  result  (ending inner bowl r)
          ?:  ?=(%| -.result)  (fail id p.result)
          =/  end=terminal:read  p.result
          ?~  decision.acceptance.end  (fail id %qpc-campaign-decision-missing)
          =/  moved  (settled:campaign r receipt.end verdict.u.decision.acceptance.end)
          ?:  ?=(%| -.moved)  (fail id p.moved)
          =/  next=record:campaign  next.p.moved
          ?:  handover.p.moved
            =^  cards  inner
              (on-poke:~(. inner bowl(src our.bowl)) %noun !>([%qpc-campaign-handover-v1 member.c enrollment.end id.receipt.end]))
            ?>  =(~ cards)
            [~ this(held held(records (~(put by records.held) id next)))]
          ?.  resume.p.moved  [~ this(held held(records (~(put by records.held) id next)))]
          =/  fresh  (fetch inner bowl c %.n)
          ?:  ?=(%| -.fresh)  (fail id p.fresh)
          ?.  =(snapshot.task.r p.fresh)  (fail id %qpc-campaign-task-changed)
          [~[(run-card:loop our.bowl member.c)] this(held held(records (~(put by records.held) id next)))]
        ::  All new work rechecks native source, standing scope and law.
        =^  reconciled  inner
          ?:  =(%deciding phase.r)
            (on-poke:~(. inner bowl(src our.bowl)) %noun !>([%qpc-instrument-reobserve-v1 member.c]))
          [~ inner]
        ?>  =(~ reconciled)
        =/  fresh  (fetch inner bowl c =(%opening phase.r))
        ?:  ?=(%| -.fresh)  (fail id p.fresh)
        ?.  =(snapshot.task.r p.fresh)  (fail id %qpc-campaign-task-changed)
        ?:  =(%opening phase.r)
          (open-session id r(phase %collecting) member.c grant.c)
        =/  available  (reading inner bowl r)
        ?:  ?=(%| -.available)  (fail id p.available)
        ?:  =(%deciding phase.r)
          ?~  request.r  (fail id %qpc-campaign-request-missing)
          ?~  p.available
            =/  charged  (request:campaign r member.c u.request.r)
            ?:  ?=(%| -.charged)  (fail id p.charged)
            =.  held  held(records (~(put by records.held) id p.charged(phase %collecting, request ~)))
            =^  cards  inner  (on-poke:~(. inner bowl(src our.bowl)) %noun !>([%native-coding-action-v1 [%run member.c]]))
            ::  A silent refusal would strand the charged attempt forever.
            =/  missed  (undispatched member.c)
            ?~  missed  [cards this]
            =^  failed  this  (fail id u.missed)
            [(weld cards failed) this]
          =/  made  (make-child:campaign r id.u.p.available)
          ?:  ?=(%| -.made)  (fail id p.made)
          =/  child=child:campaign  p.made
          =/  charged  (request:campaign r session.child (request-id:sessions session.child 0))
          ?:  ?=(%| -.charged)  (fail id p.charged)
          =^  cards  inner
            (on-poke:~(. inner bowl(src our.bowl)) %noun !>([%qpc-session-require-v1 session.child]))
          ?>  =(~ cards)
          =.  held  held(records (~(put by records.held) id p.charged(phase %gating, child `child)))
          :_  this
          :~  (poke:loop our.bowl %cantrip /qpc-campaign-ack/(scot %ux id)/(scot %ux session.child)/gate [%qpc-session-require-v1 session.child])
              (poke:loop our.bowl %cantrip /qpc-campaign-ack/(scot %ux id)/(scot %ux session.child)/grant [%native-coding-grant-v1 grant.child])
          ==
        ?~  child.r  (fail id %qpc-campaign-collection-missing)
        =/  child=child:campaign  u.child.r
        ?~  p.available  (fail id %qpc-campaign-reading-lost)
        ?.  =(reading.child id.u.p.available)  (fail id %qpc-campaign-reading-changed)
        =/  issue  (gating inner bowl child)
        ?^  issue  (fail id u.issue)
        ?:  =(%gating phase.r)
          ?.  =(acknowledgments.child (silt `(list ?(%gate %grant))`~[%gate %grant]))  (fail id %qpc-campaign-gate-unconfirmed)
          =/  command=command:declaration
            [%qpc-profile-register-v1 session.child member.c expected-law.c profile.c rationale.c]
          =^  cards  inner  (on-poke:~(. inner bowl(src our.bowl)) %noun !>(command))
          [cards this(held held(records (~(put by records.held) id r(phase %profile))))]
        ?.  =(%profile phase.r)  (fail id %qpc-campaign-phase-mismatch)
        =/  registered  (registry:read inner bowl session.child)
        ?~  registered  (fail id %qpc-campaign-profile-missing)
        ?.  ?&  (usable:declaration u.registered)
                =(source.source.snapshot.task.r source.source.value.u.registered)
                =(profile.c profile.command.value.u.registered)
                =(member.c member.command.value.u.registered)
                =(expected-law.c expected-law.command.value.u.registered)
            ==  (fail id %qpc-campaign-profile-unconfirmed)
        (open-session id r(phase %pool, child `child(declaration `id.u.registered)) session.child id.grant.child)
  ++  on-init
    =^  cards  inner  on-init:ag
    (finish cards)
  ++  on-save  !>([%qpc-campaign-owner-v1 held on-save:ag])
  ++  on-load
    |=  old=vase
    =/  saved=[held=state:campaign inner=vase]
      ?.  ?=([%qpc-campaign-owner-v1 *] q.old)  [empty:campaign old]
      =/  prior  !<([%qpc-campaign-owner-v1 held=state:campaign inner=vase] old)
      +.prior
    ?>  (valid:campaign our.bowl held.saved)
    =.  held  (recover:campaign held.saved)
    =^  cards  inner  (on-load:ag inner.saved)
    ::  Filter while every loaded owner is still recovered. Restoring idle
    ::  history afterward cannot release an inference or deadline load card.
    =.  cards  (filter cards)
    =/  before  (mule |.((viki:appstate inner.saved)))
    =/  after  (mule |.((viki:appstate on-save:ag)))
    ?.  &(?=(%& -.before) ?=(%& -.after))  [cards this]
    ::  The strict extractor fixes order and accepted versioned tags; all
    ::  thirteen current inner parts must exist, including the inner journal.
    ?.  &(=(13 (lent p.before)) =(p.before p.after))  [cards this]
    =/  rows=(list [@ux record:campaign])  ~(tap by records.held.saved)
    |-  ^-  (quip card:agent:gall _this)
    ?~  rows  [cards this]
    =/  [id=@ux r=record:campaign]  i.rows
    ?.  &(=(%collecting phase.r) ?=(~ due.r) ?=(~ request.r) ?=(~ child.r))
      $(rows t.rows)
    =/  input  (input:observer inner bowl member.command.task.r)
    ?~  input  $(rows t.rows)
    =/  plan  (dispatch-plan-read inner bowl member.command.task.r)
    ?~  plan  $(rows t.rows)
    =/  keep=?
      ?:  &((unreviewed member.command.task.r p.before) (quiet-review our.bowl r entry.u.input key.u.input grant.u.input u.plan))  %.y
      (quiet-landed-read inner bowl r entry.u.input key.u.input grant.u.input u.plan p.before)
    ?.  keep
      $(rows t.rows)
    $(rows t.rows, held held(records (~(put by records.held) id r)))
  ++  on-poke
    |=  [=mark =vase]
    ?>  !?=([%qpc-campaign-handover-v1 *] q.vase)
    :: These owner operations return their exact bounded effects. Running
    :: finish here could add work outside the explicit completion/handoff.
    ?:  &(=(%noun mark) ?=([%qpc-native-task-complete-v1 *] q.vase))
      =/  command  ((soft ,command:task-completion) q.vase)
      ?~  command
        [~[(refused:loop 0x0 %task-completion-command-invalid)] this]
      =/  changed  (complete:handoff inner bowl held u.command)
      [cards.changed this(inner inner.changed, held held.changed)]
    ?:  &(=(%noun mark) ?=([?(%qpc-native-task-handoff-prepare-v1 %qpc-native-campaign-activate-v1) *] q.vase))
      =/  command  ((soft ,command:handoff) q.vase)
      ?~  command
        [~[(refused:loop 0x0 %task-handoff-command-invalid)] this]
      =/  changed  (act:handoff inner bowl held fetch u.command)
      [cards.changed this(inner inner.changed, held held.changed)]
    ?:  &(=(%noun mark) ?=([%qpc-campaign-start-v1 *] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  command=command:campaign  !<(command:campaign vase)
      =/  view  (fetch inner bowl command %.y)
      ?>  ?=(%& -.view)
      =/  next  (begin:campaign held our.bowl src.bowl now.bowl command p.view)
      ?>  ?=(%& -.next)
      =.  held  p.next
      =/  r=record:campaign  (~(got by records.held) id.command)
      [~[[%pass (wire-for:campaign id.command r) %arvo %b %wait (need due.r)]] this]
    ?:  &(=(%noun mark) ?=([%native-coding-action-v1 %run @] q.vase))
      ::  The loop's own run card carries a noun-typed vase; clam its DATA.
      =/  command  ;;([%native-coding-action-v1 [%run id=@ux]] q.vase)
      =/  owned=(list [@ux record:campaign])
        (skim ~(tap by records.held) |=([id=@ux r=record:campaign] =(id.command member.command.task.r)))
      ?~  owned
        =^  cards  inner  (on-poke:ag mark vase)
        (finish cards)
      ?>  =(our.bowl src.bowl)
      =/  [id=@ux r=record:campaign]  i.owned
      ?.  =(%collecting phase.r)  [~ this]
      =/  input  (input:observer inner bowl id.command)
      ?~  input  (fail id %qpc-campaign-session-missing)
      =/  e=entry:sessions  entry.u.input
      ::  A repeated run card while this owner's charged request is in flight.
      ?:  ?&(?=(^ pending.e) (~(has in attempts.r) [id.command id.u.pending.e]))  [~ this]
      ?.  &(=(%ready phase.e) ?=(~ pending.e) ?=(~ calls.e))
        (fail id %qpc-campaign-session-not-ready)
      =/  request=@ux  (request-id:sessions id.command turn.e)
      ?:  (~(has in attempts.r) [id.command request])  [~ this]
      (schedule id r(phase %deciding, request `request))
    =^  cards  inner  (on-poke:ag mark vase)
    (finish cards)
  ++  on-arvo
    |=  [=wire =sign-arvo]
    ?:  ?=([%qpc-campaign *] wire)
      ?.  &(=(our.bowl src.bowl) ?=([%qpc-campaign @ @ ~] wire))  [~ this]
      =/  id  (slaw %ux i.t.wire)
      ?~  id  [~ this]
      =/  found  (~(get by records.held) u.id)
      ?~  found  [~ this]
      =/  r=record:campaign  u.found
      ?.  &(=(wire (wire-for:campaign u.id r)) ?=(^ due.r))  [~ this]
      ?:  ?=([%behn %wake ^] sign-arvo)  (fail u.id %qpc-campaign-timer-unconfirmed)
      ?.  &(?=([%behn %wake ~] sign-arvo) (gte now.bowl (need due.r)))  [~ this]
      (wake u.id)
    =/  witness  (dispatch-wake held inner bowl wire sign-arvo)
    =^  cards  inner  (on-arvo:ag wire sign-arvo)
    ?~  witness  (finish cards)
    =/  reason  (dispatch-refusal u.witness inner bowl cards)
    ?~  reason  (finish cards)
    =^  unavailable  this  (fail id.u.witness u.reason)
    (finish (weld cards unavailable))
  ++  on-agent
    |=  [=wire =sign:agent:gall]
    ?:  ?=([%qpc-campaign-ack *] wire)
      ?.  &(=(our.bowl src.bowl) ?=([%qpc-campaign-ack @ @ ?(%gate %grant) ~] wire))  [~ this]
      =/  id  (slaw %ux i.t.wire)
      =/  session  (slaw %ux i.t.t.wire)
      ?~  id  [~ this]
      ?~  session  [~ this]
      =/  found  (~(get by records.held) u.id)
      ?~  found  [~ this]
      =/  r=record:campaign  u.found
      ?.  =(%gating phase.r)  [~ this]
      ?~  child.r  [~ this]
      ?.  =(session.u.child.r u.session)  [~ this]
      ?.  ?=([%poke-ack ~] sign)  (fail u.id %qpc-campaign-gate-delivery-unconfirmed)
      =/  kind=?(%gate %grant)  i.t.t.t.wire
      =/  child=child:campaign  u.child.r
      ?:  (~(has in acknowledgments.child) kind)  [~ this]
      =.  child  child(acknowledgments (~(put in acknowledgments.child) kind))
      =.  r  r(child `child)
      =.  held  held(records (~(put by records.held) u.id r))
      ?.  =(acknowledgments.child (silt `(list ?(%gate %grant))`~[%gate %grant]))  [~ this]
      (schedule u.id r)
    =^  cards  inner  (on-agent:ag wire sign)
    (finish cards)
  ++  on-peek
    |=  =path
    ?:  =(/x/qpc/campaigns path)
      ?.  =(our.bowl src.bowl)  ~
      ``noun+!>(held)
    (on-peek:ag path)
  ++  on-watch
    |=  =path
    =^  cards  inner  (on-watch:ag path)
    (finish cards)
  ++  on-leave
    |=  =path
    =^  cards  inner  (on-leave:ag path)
    (finish cards)
  ++  on-fail
    |=  [=term =tang]
    =^  cards  inner  (on-fail:ag term tang)
    (finish cards)
  --
++  agent
  |=(inner=agent:gall (wrap inner read:read current:read settlement:read gates:read))
--
