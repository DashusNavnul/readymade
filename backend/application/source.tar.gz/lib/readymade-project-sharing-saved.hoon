::  Preserve all workspace state and validated sharing requests, never replay.
/+  previous=readymade-workspace-saved, sharing=readymade-project-sharing
|%
+$  saved
  [%readymade-collab-app-v8 previous=saved:previous sharing=journal:sharing]
++  restore
  |=  [our=@p raw=*]
  ^-  (unit saved)
  =/  eight  ((soft ,saved) raw)
  ?^  eight
    =/  old  (restore:previous our previous.u.eight)
    ?~  old  ~
    =/  journal  (restore:sharing sharing.u.eight)
    ?~  journal  ~
    ?.  &(=(raw u.eight) =(previous.u.eight u.old) =(sharing.u.eight u.journal))  ~
    ?.  (levy ~(val by u.journal) |=(r=record:sharing =(our owner.command.r)))  ~
    eight
  =/  old  (restore:previous our raw)
  ?~  old  ~
  `[%readymade-collab-app-v8 u.old ~]
--
