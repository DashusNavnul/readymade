::  Read-only presentation of canonical native owner projections. This core
::  grants no authority and accepts no commands. Pure supplied nouns do not
::  authenticate records; only +read's local private peeks establish origin.
::  Keep +project's two status strings and expose separate read-only receipt
::  identities in +view. A chosen candidate or sent mapping is not application.
/+  bind=qpc-native-owner-binding, controller=qpc-native-controller,
    selected=qpc-native-selected, history=qpc-selected-history,
    measured=qpc-selected-measurement, obs=qpc-observation,
    decision=qpc-native-decision, gate=qpc-session-gate,
    receipts=qpc-native-evidence-view, distributions=qpc-native-distribution-view
|%
+$  snapshot
  $:  owner=state:bind  choices=state:controller
      executions=state:selected  feedback=state:history  observed=state:obs
  ==
+$  counts  (map @tas @ud)
++  raw
  ::  No remote/self scry: use the actual current inner core, including a
  ::  just-completed law edit. An absent legacy peek may bail; retain absence.
  |=  [inner=agent:gall b=bowl:gall path=path]
  ^-  (unit *)
  %-  mole
  |.  (need (payload:gate (on-peek:~(. inner b(src our.b)) path)))
++  read
  |=  [inner=agent:gall b=bowl:gall]
  ^-  (unit snapshot)
  ?.  =(our.b src.b)  ~
  %-  mole
  |.
  =/  o=*  (need (raw inner b /x/qpc/owner))
  =/  c=*  (need (raw inner b /x/qpc/controller))
  =/  e=*  (need (raw inner b /x/qpc/selected))
  =/  f=*  (need (raw inner b /x/qpc/instrument/selected))
  =/  a=*  (need (raw inner b /x/qpc/observations))
  =/  oo=state:bind  (need ((soft state:bind) o))
  =/  cc=state:controller  (need ((soft state:controller) c))
  =/  ee=state:selected  (need ((soft state:selected) e))
  =/  ff=[%qpc-instrument-selected-v1 state:history]
    (need ((soft ,[%qpc-instrument-selected-v1 state:history]) f))
  =/  aa=state:obs  (need ((soft state:obs) a))
  ?>  &(=(o oo) =(c cc) =(e ee) =(f ff) =(a aa))
  [oo cc ee +.ff aa]
++  receipt-linked
  ::  Native instrument receipts were assembled from real acceptance. Here
  ::  rejoin their exact retained identities; do not infer landing from the
  ::  current selection phase, an acceptance-shaped noun, or an HTTP result.
  |=  [s=snapshot id=@ux r=receipt:measured]
  ^-  ?
  =/  reserved  (~(get by reservations.feedback.s) id)
  =/  frame  (~(get by frames.observed.s) frame.r)
  ?~  reserved  %.n
  ?~  frame  %.n
  =/  reservation=reservation:measured  reservation.u.reserved
  ?.  =(id id.enrollment.reservation)  %.n
  ?.  (linked-valid:measured reservation u.frame r)  %.n
  =/  session=@ux  session.work.enrollment.reservation
  =/  choice  (~(get by records.choices.s) session)
  ?~  choice  %.n
  =/  execution  (~(get by records.executions.s) id.decision.u.choice)
  ?~  execution  %.n
  =/  original  (~(get by records.journal.owner.s) session)
  ?~  original  %.n
  ?~  mapping.u.execution  %.n
  =/  mapping=mapping:decision  u.mapping.u.execution
  ?&  =(origin.u.choice u.original)
      =(%chosen phase.u.choice)  =(%sent phase.u.execution)
      =(controller.r (digest:selected u.choice))
      =(selected.r (digest:selected u.execution))
      =(selection.plan.u.execution controller.r)
      =(mapping.r id.mapping)  =(id.mapping (digest:decision mapping(id 0x0)))
      =(id.decision.u.choice decision.mapping)
      =(session collection-session.mapping)
      =(candidate.plan.u.execution candidate.mapping)
      =(request.plan.u.execution request.mapping)
  ==
++  count
  |=  [s=counts key=@tas]
  ^-  @ud
  (fall (~(get by s) key) 0)
++  bump
  |=  [s=counts key=@tas amount=@ud]
  ^-  counts
  (~(put by s) key (add (count s key) amount))
++  totals
  ::  Bounds and consistency only, not a replay of every compiler/assessment
  ::  proof on each page read. Authenticity belongs to +read's native owners.
  |=  s=snapshot
  ^-  (unit counts)
  ?.  ?&  (lte ~(wyt by tickets.owner.s) 64)
          (lte ~(wyt by records.journal.owner.s) 64)
          (lte ~(wyt by records.choices.s) 64)
          (lte ~(wyt by records.executions.s) 64)
          (lte ~(wyt by reservations.feedback.s) 128)
          (lte ~(wyt by receipts.feedback.s) 128)
          (lte ~(wyt by reads.feedback.s) 128)
          (lte ~(wyt by unavailable.owner.s) 128)
          (lte ~(wyt by unavailable.choices.s) 128)
          (lte ~(wyt by unavailable.executions.s) 128)
      ==  ~
  ?.  %+  levy  ~(tap by records.choices.s)
      |=  [id=@ux c=record:controller]
      =/  original  (~(get by records.journal.owner.s) id)
      ?~  original  %.n
      &(=(id session.marker.c) =(origin.c u.original))
    ~
  ?.  %+  levy  ~(tap by records.executions.s)
      |=  [id=@ux e=record:selected]
      =/  c  (~(get by records.choices.s) collection.plan.e)
      ?~  c  %.n
      ?&  =(id id.plan.e)  =(id id.decision.u.c)
          =(%chosen phase.u.c)  =(selection.plan.e (digest:selected u.c))
          ?~(mapping.e !=(%sent phase.e) =(%sent phase.e))
      ==
    ~
  ?.  (levy ~(tap by receipts.feedback.s) |=([id=@ux r=receipt:measured] (receipt-linked s id r)))  ~
  =/  out=counts  *counts
  =.  out
    %+  roll  ~(val by tickets.owner.s)
    |=  [t=ticket:bind =_out]
    (bump out `@tas`(cat 3 'owner-' phase.t) 1)
  =.  out
    %+  roll  ~(val by records.choices.s)
    |=  [c=record:controller =_out]
    (bump out `@tas`(cat 3 'choice-' phase.c) 1)
  =.  out
    %+  roll  ~(val by records.executions.s)
    |=  [e=record:selected =_out]
    (bump out `@tas`(cat 3 'execution-' phase.e) 1)
  =.  out
    %+  roll  ~(val by receipts.feedback.s)
    |=  [r=receipt:measured =_out]
    (bump out `@tas`(cat 3 'outcome-' status.r) 1)
  =.  out
    %+  roll  ~(val by reads.feedback.s)
    |=  [r=ticket:history =_out]
    (bump out `@tas`(cat 3 'feedback-' phase.r) 1)
  =.  out  (bump out %unavailable :(add ~(wyt by unavailable.owner.s) ~(wyt by unavailable.choices.s) ~(wyt by unavailable.executions.s)))
  `out
++  project
  |=  [base=json state=(unit snapshot)]
  ^-  (unit json)
  ?.  ?=(%o -.base)  ~
  ?.  =(`[%s 'qpc-ark-law-v1'] (~(get by p.base) 'schema'))  ~
  ?.  &((~(has by p.base) 'selection') (~(has by p.base) 'application'))  ~
  =/  counted=(unit counts)
    ?~  state  ~
    %-  mole
    |.  (need (totals u.state))
  =/  selection=@t
    ?~  counted  'unavailable'
    =/  c=counts  u.counted
    %-  crip
    "Controller installed; collecting {<(add (count c %owner-scheduled) (count c %owner-opened))>}, sealed {<(count c %owner-sealed)>}, waiting {<(count c %choice-waiting)>}, chosen {<(count c %choice-chosen)>}; refused {<(count c %choice-refused)>}, unknown {<(add (count c %owner-unknown) (count c %choice-unknown))>}, unavailable {<(add (count c %owner-unavailable) (count c %unavailable))>}."
  =/  application=@t
    ?~  counted  'Native QPC state unavailable; no application is confirmed by this view.'
    =/  c=counts  u.counted
    %-  crip
    "Execution: opening {<(count c %execution-opening)>}, admitting {<(count c %execution-admitting)>}, sent {<(count c %execution-sent)>}, refused {<(count c %execution-refused)>}. Canonical outcomes: applied {<(count c %outcome-applied)>}, refused {<(count c %outcome-refused)>}. Unknown execution {<(count c %execution-unknown)>}; feedback pending {<(count c %feedback-scheduled)>}, unknown {<(count c %feedback-unknown)>}."
  `[%o (~(put by (~(put by p.base) 'selection' [%s selection])) 'application' [%s application])]
++  evidence
  |=  s=(unit snapshot)
  ^-  json
  =/  checked=(unit snapshot:receipts)
    %-  mole
    |.
    =/  value=snapshot  (need s)
    ?>  ?=(^ (totals value))
    [choices.value executions.value feedback.value]
  (render:receipts checked)
++  view
  |=  [inner=agent:gall b=bowl:gall]
  ^-  (unit json)
  ?.  =(our.b src.b)  ~
  =/  raw-base  (raw inner b /x/qpc/ark/view)
  ?~  raw-base  ~
  =/  base  ((soft ,json) u.raw-base)
  ?~  base  ~
  ?.  =(u.raw-base u.base)  ~
  =/  snapshot  (read inner b)
  =/  shown  (project u.base snapshot)
  ?~  shown  ~
  ?>  ?=(%o -.u.shown)
  =/  fields=(map @t json)  p.u.shown
  =/  prior  (~(get by fields) 'distributions')
  =/  with-distributions=(map @t json)
    ?~  prior  fields
    =/  managed=(unit snapshot:distributions)
      ?~  snapshot  ~
      ?~  (totals u.snapshot)  ~
      `(read:distributions inner b owner.u.snapshot choices.u.snapshot)
    (~(put by fields) 'distributions' (project:distributions u.prior managed))
  `[%o (~(put by with-distributions) 'executionEvidence' (evidence snapshot))]
--
