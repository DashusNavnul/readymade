:: Pure prospective handoff only. The native reader authenticates completion,
:: Graf retention, source, fresh-session facts and the next useful task.
:: No command, judgment, model, report, gap, timer or source write here.
/-  nc=native-coding
/+  campaign=qpc-native-campaign, completed=qpc-native-task-completion,
    instrument=qpc-instrument, history=qpc-successor-history,
    session=native-coding-session,
    project=native-coding-project, sensing=qpc-task-sensing
|%
+$  snapshot
  $:  prior=record:campaign  task=task:completed
      receipt=receipt:completed  retained=?
      command=command:campaign  view=snapshot:campaign
      held=state:instrument  ordered=state:history  refresh=(unit @da)
      current=revision:nc  next-entry=(unit entry:session)
      next-observed=?  next-managed=?
      interrupted=(list record:campaign)
  ==
+$  proposal
  $:  %qpc-native-task-handoff-v1
      prior=@ux  member=@ux  completion=@ux  next=@ux  task=@ux
      source=revision:nc  before=@ux  after=@ux  history=@ux
  ==
+$  change
  [proposal=proposal prior=record:campaign held=state:instrument ordered=state:history]
++  digest
  |=(value=* ^-(@ux (shax (jam [%qpc-native-task-handoff-v1 value]))))
++  completion-bound
  :: Consistency with the immutable original task, not proof of native origin.
  |=  s=snapshot
  ^-  ?
  =/  c=command:campaign  command.task.prior.s
  =/  v=snapshot:campaign  snapshot.task.prior.s
  =/  t=task:completed  task.s
  =/  p=proposal:completed  proposal.receipt.s
  =/  row=record:session  record.receipt.s
  ?&  retained.s  ?=(^ graf.t)
      =(member.c member.t)  =(member.c member.p)
      =(project.manifest.plan.v project.t)
      =((configuration:project project.v) configuration.t)
      =(objective.c objective.t)  =(expected.c source.t)
      =(artifact.plan.v artifact.t)  =(cases.v cases.t)
      =((digest:completed t) task.p)
      =(current.s source.p)  =(expected.command.s current.s)
      =(owner.source.t owner.current.s)
      =(desk.source.t desk.current.s)
      =(+(number.source.t) number.current.s)
      =(body.row (judgment-body:completed p))
      =(id.row (event-id:session member.c sequence.row previous.row at.row body.row))
      (levy `(list @ux)`~[entry.p acceptance.p review.p graf.p id.row] identifier:sensing)
  ==
++  interrupted-predecessor
  :: A successor of the completed prior that ended %stopped/%unknown has no
  :: completion of its own; the operator stop that retired its plan already
  :: recorded the gap. The next task then hands over from the completed prior
  :: again, and the stopped record is the explicit predecessor: no maximum-step
  :: tie is inferred. Measured 2026-10-31: ptf-14f4 v2 ended %unknown with its
  :: plan active while afb3's plan was already retired, so nothing could hand
  :: over; an interrupted campaign stays %unknown here, only its plan stopped.
  |=  s=snapshot
  ^-  (each record:instrument @tas)
  =/  our=@p  owner.task.prior.s
  =/  old=command:campaign  command.task.prior.s
  =/  old-plan=plan:instrument  plan.snapshot.task.prior.s
  ?~  interrupted.s  [%| %task-handoff-active-member-unconfirmed]
  =/  handed=(unit record:instrument)  (~(get by plans.held.s) member.old)
  ?~  handed  [%| %task-handoff-prior-member-missing]
  ?.  &(!active.u.handed =(old-plan plan.u.handed) =(`%pool-handover reason.u.handed))
    [%| %task-handoff-prior-not-handed-over]
  ?.  =((lent interrupted.s) ~(wyt in (silt (turn interrupted.s |=(r=record:campaign id.command.task.r)))))
    [%| %task-handoff-interrupted-successor-ambiguous]
  =/  stopped-at
    |=  r=record:campaign
    ^-  (unit record:instrument)
    =/  c=command:campaign  command.task.r
    =/  p=plan:instrument  plan.snapshot.task.r
    =/  stopped  (~(get by plans.held.s) member.c)
    ?.  ?&  =(our owner.task.r)  ?=(?(%stopped %unknown) phase.r)
            ?=(~ request.r)  ?=(~ due.r)  ?=(~ child.r)  ?=(^ reason.r)
            !=(id.old id.c)  !=(id.command.s id.c)
            !=(member.old member.c)  !=(member.command.s member.c)
            (gth at.task.r at.task.prior.s)
            =(stream.old-plan stream.p)  =(member.c session.p)
            (valid:campaign our [%qpc-native-campaigns-v1 (~(put by *(map @ux record:campaign)) id.c r)])
            ?=(^ stopped)  !active.u.stopped  =(p plan.u.stopped)
            =(`%operator-stopped reason.u.stopped)
            ?=(~ ticket.u.stopped)  ?=(~ awaiting.u.stopped)
        ==
      ~
    stopped
  =/  rows=(list record:campaign)  interrupted.s
  =|  latest=(unit record:campaign)
  |-  ^-  (each record:instrument @tas)
  ?^  rows
    ?~  (stopped-at i.rows)  [%| %task-handoff-interrupted-successor-invalid]
    ?~  latest  $(rows t.rows, latest `i.rows)
    ?:  =(at.task.u.latest at.task.i.rows)
      [%| %task-handoff-interrupted-successor-ambiguous]
    $(rows t.rows, latest ?:((gth at.task.i.rows at.task.u.latest) `i.rows latest))
  ?~  latest  [%| %task-handoff-active-member-unconfirmed]
  =/  stopped  (stopped-at u.latest)
  ?~  stopped  [%| %task-handoff-interrupted-successor-invalid]
  [%& u.stopped]
++  prepare
  |=  [our=@p actor=@p s=snapshot]
  ^-  (each change @tas)
  ?.  =(our actor)  [%| %task-handoff-owner-required]
  =/  prior=record:campaign  prior.s
  =/  old=command:campaign  command.task.prior
  =/  next=command:campaign  command.s
  =/  old-plan=plan:instrument  plan.snapshot.task.prior
  =/  plan=plan:instrument  plan.view.s
  ?.  (valid:campaign our [%qpc-native-campaigns-v1 (~(put by *(map @ux record:campaign)) id.old prior)])
    [%| %task-handoff-original-task-invalid]
  ?.  ?&  =(our owner.task.prior)
          ?=(?(%collecting %awaiting-next-task) phase.prior)
          ?=(~ request.prior)  ?=(~ due.prior)  ?=(~ child.prior)
      ==  [%| %task-handoff-prior-unsettled]
  ?.  (completion-bound s)  [%| %task-handoff-completion-unconfirmed]
  ::  Name the clause (2026-11-01); the family tag sent the operator to the source.
  =/  why  (incompatible:campaign our next view.s)
  ?^  why  [%| u.why]
  ?.  ?&  !=(id.old id.next)  !=(member.old member.next)
          !=(task.old-plan task.plan)  !=(objective.old objective.next)
          =(instrument.old-plan instrument.plan)
          =(law.old-plan law.plan)  =(stream.old-plan stream.plan)
          =(manifest.old-plan manifest.plan)
      ==  [%| %task-handoff-declaration-mismatch]
  ?.  ?&  ?=(~ next-entry.s)  !next-observed.s  !next-managed.s
          !(~(has by plans.held.s) member.next)
          (lth ~(wyt by plans.held.s) plan-limit:instrument)
      ==  [%| %task-handoff-next-member-not-fresh]
  ?.  (valid:instrument our held.s)  [%| %task-handoff-instrument-invalid]
  ?.  &(?=(~ refresh.s) ?=(~ fault.ordered.s))
    [%| %task-handoff-history-unsettled]
  =/  mates=(list record:instrument)
    (skim ~(val by plans.held.s) |=(r=record:instrument =(stream.plan stream.plan.r)))
  =/  active=(list record:instrument)
    (skim mates |=(r=record:instrument active.r))
  :: Do not infer the active owner from an arbitrary maximum-step tie.
  ?:  (gth (lent active) 1)  [%| %task-handoff-active-member-unconfirmed]
  =/  predecessor=(each record:instrument @tas)
    ?~  active  (interrupted-predecessor s)
    ?.  ?=(~ interrupted.s)  [%| %task-handoff-interrupted-successor-unconfirmed]
    ?.  =(old-plan plan.i.active)  [%| %task-handoff-active-member-changed]
    [%& i.active]
  ?:  ?=(%| -.predecessor)  [%| p.predecessor]
  =/  before=record:instrument  p.predecessor
  ?:  (lien mates |=(r=record:instrument |(?=(^ ticket.r) ?=(^ awaiting.r))))
    [%| %task-handoff-member-busy]
  ?:  (pending:history ordered.s stream.plan)
    [%| %task-handoff-work-unresolved]
  ?.  (successor-continuity:instrument ordered.s stream.plan current.s)
    [%| %task-handoff-source-changed]
  =/  joined  (join-successor:instrument held.s ordered.s plan %.y)
  ?:  ?=(%| -.joined)  [%| p.joined]
  =/  next-held=state:instrument  held.s(plans plans.p.joined)
  ?.  (valid:instrument our next-held)  [%| %task-handoff-result-invalid]
  =/  after=record:instrument  r.p.joined
  =/  proposed=proposal
    :*  %qpc-native-task-handoff-v1  id.old  member.old
        (digest:completed receipt.s)  id.next
        (digest:campaign [next view.s])  current.s
        (digest before)  (digest after)  (digest ordered.s)
    ==
  :: The ordinary task retires, not a selected-settlement protocol or gap.
  =/  retired=record:campaign
    (unavailable:campaign prior %awaiting-next-task %qpc-task-completed)
  [%& [proposed retired next-held ordered.s]]
--
