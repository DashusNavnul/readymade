::  Prospective collection contracts. These frames are raw predictions, not
::  settled work, measurement epochs, adjudications or executable permissions.
/-  nc=native-coding, np=native-coding-provider, frozen=native-coding-context
/+  report=qpc-report, provider=native-coding-provider, bound=qpc-patch-report,
    sessions=native-coding-session, codec=native-coding-tool-codec
|%
+$  proposition  [id=@tas wording=@t evidence=@t adjudication=@t horizon=@t]
+$  manifest
  $:  version=?(%qpc-observation-manifest-v1 %qpc-observation-manifest-v2 %qpc-observation-manifest-v3 %qpc-observation-manifest-v4)  owner=@p  project=@t
      selection=selection:np  prompt=@tas  context-policy=@t
      scope=(list path)  propositions=(list proposition)
      width=@ud  baseline-policy=@t
  ==
+$  work
  $:  %qpc-observation-work-v1  manifest=@ux  nonce=@ux
      session=@ux  request=@ux  configuration=@ux  source=revision:nc
      artifact=path  case-set=@ux  substitutions=@t  available-evidence=@t
  ==
+$  armed
  [work=work ordinal=@ud segment=@ux active=? after=@ud]
+$  result
  $%  [%& p=(list row:report)]
      [%| p=@tas]
      [%outside p=%read-only]
  ==
+$  frame
  $:  %qpc-observation-frame-v1  id=@ux  owner=@p  work=work
      ordinal=@ud  segment=@ux  at=@da  journal=@ud
      context=@ux  reply=@ux  result=result
  ==
+$  state
  $:  manifests=(map @ux manifest)
      arms=(map @ux armed)  frames=(map @ux frame)
  ==
++  digest
  |=  value=*
  ^-  @ux
  (shax (jam [%qpc-observation-commitment-v1 value]))
++  text-valid
  |=  value=@t
  (text-valid:provider value 1.024)
++  evidence-byte-limit  8.192
++  work-byte-limit  16.384
++  evidence-valid
  |=  value=@t
  (text-valid:provider value evidence-byte-limit)
++  tool-bound
  ::  v3 and v4 share the tool-bound prediction; only v4 widens the boundary.
  |=  m=manifest
  ^-  ?
  |(=(%qpc-observation-manifest-v3 version.m) =(%qpc-observation-manifest-v4 version.m))
++  manifest-valid
  |=  m=manifest
  ^-  ?
  ?&  (selection-valid:provider selection.m)
      ?:(=(%qpc-observation-manifest-v3 version.m) =(%tool-bound-v3 prompt.m) ?:(=(%qpc-observation-manifest-v4 version.m) =(%tool-bound-v4 prompt.m) %.y))
      (text-valid project.m)  (text-valid `@t`prompt.m)
      (text-valid context-policy.m)  (text-valid baseline-policy.m)
      |(=(16 width.m) =(32 width.m) =(64 width.m))
      (gte (lent scope.m) 1)  (lte (lent scope.m) 16)
      (levy scope.m |=(p=path &(?=(^ p) (lte (met 3 (jam p)) 256))))
      (gte (lent propositions.m) 2)  (lte (lent propositions.m) 16)
      =((lent propositions.m) ~(wyt in (silt (turn propositions.m |=(p=proposition id.p)))))
      %+  levy  propositions.m
      |=  p=proposition
      &((text-valid `@t`id.p) (text-valid wording.p) (text-valid evidence.p) (text-valid adjudication.p) (text-valid horizon.p))
      (lte (met 3 (jam m)) 16.384)
  ==
++  work-valid
  |=  [m=manifest w=work]
  ^-  ?
  ?&  (manifest-valid m)  =((digest m) manifest.w)
      (work-fields-valid m w)
  ==
++  work-fields-valid
  ::  Only the work-local conditions. +work-valid checks the manifest first;
  ::  +valid checks every manifest and map key before reaching any work.
  |=  [m=manifest w=work]
  ^-  ?
  ?&  (levy `(list @ux)`~[nonce.w session.w request.w configuration.w case-set.w] identifier:report)
      =(owner.m owner.source.w)  (~(has in (silt scope.m)) artifact.w)
      (text-valid substitutions.w)  (evidence-valid available-evidence.w)
      (lte (met 3 (jam w)) work-byte-limit)
  ==
++  matches
  |=  [m=manifest w=work e=entry:sessions]
  ^-  ?
  ?&  (work-valid m w)  =(session.w id.session.e)
      =(configuration.w configuration.e)  =(source.w working.session.e)
      =(project.m project.session.e)  =(owner.m owner.session.e)
      =(owner.m worker.e)  =(selection.m selection.e)
  ==
++  instructions
  |=  [m=manifest w=work]
  ^-  @t
  =/  props=(list json)
    %+  turn  propositions.m
    |=  p=proposition
    [%a ~[[%s `@t`id.p] [%s wording.p] [%s evidence.p] [%s adjudication.p] [%s horizon.p]]]
  =/  details=json
    [%a ~[[%s (scot %ux (digest m))] [%s (scot %ux (digest w))] [%s substitutions.w] [%s available-evidence.w] [%s (scot %ux case-set.w)] [%a props]]]
  ?:  (tool-bound m)
    %+  rap  3
    :~  ?:(=(%qpc-observation-manifest-v4 version.m) 'Prospective QPC tool-bound observation v4' 'Prospective QPC tool-bound observation v3')
        ', fixed before this request. Propose patches using qpc_patch_v3. Include the required qpc_prediction object in each same patch call, before checks: exact manifest and work hashes from its schema, and confidence as integer millionths from 0 to 1000000 in the proposition order below. Reply text is not a prediction report. Do not invent patches or extra work to supply samples. '
        ?:(=(%qpc-observation-manifest-v4 version.m) 'Inspection-only replies (list, read, search, diff, jobs, observe) are outside the sampling boundary; ' 'List/read/search/diff-only replies are outside the sampling boundary; ')
        'mixed or unsupported calls and missing or invalid predictions are gaps. Manifest, work, substitutions, available-evidence declaration, case-set, ordered propositions [id, wording, evidence, adjudication, horizon]: '
        (en:json:html details)  '\0a'
    ==
  ?:  =(%qpc-observation-manifest-v2 version.m)
    %+  rap  3
    :~  'Prospective QPC proposal-event observation, fixed before this request. If proposing patches, put only this JSON array in your reply text: ["qpc-prospective-report-v2","'
        (scot %ux (digest m))
        '",[[integer_confidences_in_proposition_order]]]. Supply one vector per patch in actual call order; omit call IDs, which the authenticated receiver binds. Use integer millionths from 0 to 1000000, no fractions, prose or fences. Predictions precede checks. Only strictly decoded list/read/search/diff-only replies are outside this sampling boundary; mixed calls, missing required reports and unsupported actions are gaps. Proposal boundaries, not every inference request, advance the observation clock. Do not invent patches or extra work to supply samples. Manifest, work, substitutions, available-evidence declaration, case-set, ordered propositions [id, wording, evidence, adjudication, horizon]: '
        (en:json:html details)  '\0a'
    ==
  %+  rap  3
  :~  'Prospective QPC observation, fixed before this request. If proposing a patch, put only this JSON array in your reply text: ["qpc-prospective-report-v1","'
      (scot %ux (digest m))
      '",[["exact_patch_call_id",[integer_confidences_in_proposition_order]]]]. Cover each patch call in reply order. Use integer millionths from 0 to 1000000, no fractions, prose or fences. These are predictions before checks, never check results. Do not fabricate patches or evidence to produce a report. Manifest, work, substitutions, available-evidence declaration, case-set, ordered propositions [id, wording, evidence, adjudication, horizon]: '
      (en:json:html details)  '\0a'
  ==
++  interrupted
  |=  [after=@ud e=entry:sessions]
  ^-  ?
  %+  lien  records.e
  |=  r=record:sessions
  &((gte sequence.r after) ?.(?=(%status -.body.r) %.n ?=(?(%operator-pause %interrupt %cancelled) reason.body.r)))
::  Retained evidence is never evicted, so these bound a growing history.
++  manifest-limit  128
++  arm-limit  256
++  frame-limit  4.096
++  enroll
  |=  [our=@p held=state m=manifest w=work e=entry:sessions]
  ^-  (each state @tas)
  ?.  &((matches m w e) =(our owner.m))  [%| %qpc-observation-binding-invalid]
  ?.  &(?=(~ pending.e) ?=(~ calls.e) ?|(=(%ready phase.e) &(=(%paused phase.e) =(%ready resume.e))))
    [%| %qpc-observation-session-busy]
  ?.  =(request.w (request-id:sessions session.w turn.e))  [%| %qpc-observation-request-stale]
  =/  prior  (~(get by arms.held) session.w)
  ?:  ?~(prior %.n active.u.prior)  [%| %qpc-observation-already-armed]
  ?:  (lien ~(val by frames.held) |=(f=frame =(request.w request.work.f)))
    [%| %qpc-observation-request-used]
  ?:  (lien ~(val by frames.held) |=(f=frame =(nonce.w nonce.work.f)))
    [%| %qpc-observation-work-used]
  =/  active=@ud  (lent (skim ~(val by arms.held) |=(a=armed active.a)))
  ?.  ?&  (lth (add active ~(wyt by frames.held)) frame-limit)
          ?|((~(has by arms.held) session.w) (lth ~(wyt by arms.held) arm-limit))
          ?|((~(has by manifests.held) manifest.w) (lth ~(wyt by manifests.held) manifest-limit))
      ==  [%| %qpc-observation-capacity]
  =/  ordinal=@ud
    ?~  prior  0
    =/  outside=?
      ?&  !=(%qpc-observation-manifest-v1 version.m)
          =(manifest.w manifest.work.u.prior)
          %+  lien  ~(val by frames.held)
          |=  f=frame
          &(=(work.u.prior work.f) ?=(%outside -.result.f))
      ==
    ?:(outside ordinal.u.prior +(ordinal.u.prior))
  =/  missed=?
    ?~  prior  %.n
    %+  lien  records.e
    |=  r=record:sessions
    &((gth sequence.r after.u.prior) ?=(%model -.body.r))
  =/  segment=@ux
    ?:  ?~(prior %.n &(=(manifest.w manifest.work.u.prior) !missed !(interrupted after.u.prior e)))
      ?>  ?=(^ prior)
      segment.u.prior
    (digest [%segment our w ordinal])
  =/  a=armed  [w ordinal segment %.y sequence.e]
  [%& held(manifests (~(put by manifests.held) manifest.w m), arms (~(put by arms.held) session.w a))]
++  prefix
  ::  No enrollment means ordinary instructions. A stale enrollment grants no
  ::  report label; capture will retain a gap if its expected request arrives.
  |=  [held=state e=entry:sessions base=@t]
  ^-  @t
  =/  found  (~(get by arms.held) id.session.e)
  ?~  found  base
  =/  a=armed  u.found
  ?.  &(active.a =(request.work.a (request-id:sessions id.session.e turn.e)))  base
  =/  m=manifest  (~(got by manifests.held) manifest.work.a)
  ?.  (matches m work.a e)  base
  (cat 3 (instructions m work.a) base)
++  request-tools
  ::  Only a current tool-bound (v3/v4) enrollment changes the advertised patch schema.
  ::  The request and its context receipt freeze these exact tools together.
  |=  [held=state e=entry:sessions base=(list tool:np)]
  ^-  (list tool:np)
  =/  found  (~(get by arms.held) id.session.e)
  ?~  found  base
  =/  a=armed  u.found
  ?.  &(active.a =(request.work.a (request-id:sessions id.session.e turn.e)))  base
  =/  m=manifest  (~(got by manifests.held) manifest.work.a)
  ?.  &((matches m work.a e) (tool-bound m))  base
  %+  turn  base
  |=  t=tool:np
  ?.  (lien bases:bound |=(b=@t =(b name.t)))  t
  (decorate:bound (digest m) (digest work.a) (lent propositions.m) t)
++  schema-valid
  ::  No plain candidate tool may be advertised to a tool-bound enrollment;
  ::  every advertised alias must be exactly its base decorated for this
  ::  manifest/work, at least the one-file alias is present, and no alias
  ::  repeats. Older requests that advertised only qpc_patch_v3 stay valid.
  |=  [m=manifest w=work advertised=(list tool:np)]
  ^-  ?
  ?.  (tool-bound m)  %.y
  ?:  (lien advertised |=(t=tool:np (lien bases:bound |=(b=@t =(b name.t)))))  %.n
  =/  aliases=(list tool:np)
    (skim advertised |=(t=tool:np ?=(^ (base-of:bound name.t))))
  ?.  &((gte (lent aliases) 1) =((lent aliases) ~(wyt in (silt (turn aliases |=(t=tool:np name.t))))))  %.n
  ?.  (lien aliases |=(t=tool:np =(tool-name:bound name.t)))  %.n
  %+  levy  aliases
  |=  t=tool:np
  =/  base-name=@t  (need (base-of:bound name.t))
  =/  base=(list tool:np)  (skim tools:codec |=(c=tool:np =(base-name name.c)))
  ?.  =(1 (lent base))  %.n
  =(t (decorate:bound (digest m) (digest w) (lent propositions.m) (snag 0 base)))
++  predictions
  ::  Shared capture/adjudication codec choice; historical v1 stays exact.
  |=  [m=manifest calls=(list @t) text=@t]
  ^-  (each (list row:report) @tas)
  ?:  (tool-bound m)
    [%| %qpc-report-tool-required]
  ?:  =(%qpc-observation-manifest-v2 version.m)
    (decode-ordered:report (digest m) (lent propositions.m) calls text)
  (decode:report (digest m) (lent propositions.m) calls text)
++  call-predictions
  ::  Capture and independent outcome matching read the original call bytes.
  |=  [m=manifest w=work calls=(list call:np) text=@t]
  ^-  (each (list row:report) @tas)
  ?:  (tool-bound m)
    (predictions:bound (digest m) (digest w) (lent propositions.m) calls)
  (predictions m (turn calls |=(c=call:np id.c)) text)
++  read-only
  |=  [ctx=context:nc source=revision:nc r=reply:np]
  ^-  ?
  ?.  &(=(%tools stop.r) (gte (lent calls.r) 1) (lte (lent calls.r) call-limit:np))  %.n
  %+  levy  calls.r
  |=  c=call:np
  =/  decoded  (decode:codec ctx source c)
  ?.(?=(%& -.decoded) %.n ?=(?(%list %read %search %diff) -.arguments.p.decoded))
++  inspection-only
  ::  v4 boundary: job status reads change nothing, so they are outside too.
  |=  [ctx=context:nc source=revision:nc r=reply:np]
  ^-  ?
  ?.  &(=(%tools stop.r) (gte (lent calls.r) 1) (lte (lent calls.r) call-limit:np))  %.n
  %+  levy  calls.r
  |=  c=call:np
  =/  decoded  (decode:codec ctx source c)
  ?.(?=(%& -.decoded) %.n ?=(?(%list %read %search %diff %jobs %observe) -.arguments.p.decoded))
++  closing
  ::  v4 boundary: a completed reply with no calls is the session's closing
  ::  statement (measured 2026-10-16, pool task 4). It changes nothing and
  ::  attempts no patch. Length and refusal stops stay gaps.
  |=  r=reply:np
  ^-  ?
  &(=(%complete stop.r) =(~ calls.r))
++  reading
  ::  Canonical provider authentication is required by the caller, separately.
  |=  [m=manifest a=armed e=entry:sessions r=reply:np]
  ^-  $%([%& p=[context=@ux rows=(list row:report)]] [%| p=@tas] [%outside p=[context=@ux kind=%read-only]])
  ?.  (matches m work.a e)  [%| %qpc-observation-context-changed]
  ?:  (interrupted after.a e)  [%| %qpc-observation-paused]
  =/  pending  pending.e
  ?~  pending  [%| %qpc-observation-request-missing]
  =/  wanted=request:np  u.pending
  ?.  &(=(request.work.a id.wanted) =(id.wanted id.r))  [%| %qpc-observation-request-mismatch]
  =/  prompt=@t  (instructions m work.a)
  ?.  =(prompt (cut 3 [0 (met 3 prompt)] instructions.wanted))  [%| %qpc-observation-prompt-missing]
  ?.  (schema-valid m work.a tools.wanted)  [%| %qpc-observation-schema-mismatch]
  =/  contexts=(list record:sessions)
    (skim records.e |=(v=record:sessions ?.(?=(%context -.body.v) %.n =(id.wanted request.value.body.v))))
  ?.  =(1 (lent contexts))  [%| %qpc-observation-context-missing]
  =/  context=record:sessions  (snag 0 contexts)
  ?>  ?=(%context -.body.context)
  =/  b=binding:frozen  value.body.context
  ?.  ?&  =(owner.m owner.b)  =(session.work.a session.b)  =(owner.m worker.b)
          =(source.work.a source.b)  =(provider.selection.m provider.b)  =(model.selection.m model.b)
          =((shax (jam wanted)) request-digest.b)
          =((shax (jam history.wanted)) history-digest.b)
          =((shax (jam tools.wanted)) tools-digest.b)
      ==  [%| %qpc-observation-context-invalid]
  =/  ctx=context:nc  [project.m configuration.e id.session.e id.r owner.m source.work.a]
  ?:  ?&  !=(%qpc-observation-manifest-v1 version.m)
          ?:  =(%qpc-observation-manifest-v4 version.m)
            |((closing r) (inspection-only ctx source.work.a r))
          (read-only ctx source.work.a r)
      ==
    [%outside [id.context %read-only]]
  ?.  &(=(%tools stop.r) (gte (lent calls.r) 1) (lte (lent calls.r) 4))
    [%| %qpc-observation-not-patch-work]
  ?.  %+  levy  calls.r
      |=  c=call:np
      =/  decoded  (decode:codec ctx source.work.a c)
      ?.  ?=(%& -.decoded)  %.n
      ?.  ?=(%patch -.arguments.p.decoded)  %.n
      =(artifact.work.a pax.arguments.p.decoded)
    [%| %qpc-observation-patch-scope]
  =/  parsed  (call-predictions m work.a calls.r text.r)
  ?:  ?=(%| -.parsed)  [%| p.parsed]
  [%& [id.context p.parsed]]
++  capture
  |=  [our=@p at=@da held=state a=armed e=entry:sessions r=reply:np]
  ^-  [state frame]
  =/  m=manifest  (~(got by manifests.held) manifest.work.a)
  =/  got  (reading m a e r)
  =/  result=result
    ?:  ?=(%| -.got)  [%| p.got]
    ?:  ?=(%outside -.got)  [%outside kind.p.got]
    [%& rows.p.got]
  =/  context=@ux  ?:(?=(%| -.got) 0x0 context.p.got)
  ::  Bind the durable public model record, not private transport bytes which
  ::  may retire from the provider's hot evidence cache after authentication.
  (retain our at held a sequence.e context (digest (publish:provider r)) result)
++  retain
  |=  [our=@p at=@da held=state a=armed journal=@ud context=@ux reply=@ux result=result]
  ^-  [state frame]
  ?:  ?=(%outside -.result)
    =/  m=manifest  (~(got by manifests.held) manifest.work.a)
    ?>  &(!=(%qpc-observation-manifest-v1 version.m) (identifier:report context) (identifier:report reply))
    (retain-outside our at held a journal context reply)
  =/  f=frame
    [%qpc-observation-frame-v1 0x0 our work.a ordinal.a segment.a at journal context reply result]
  =.  f  f(id (digest f))
  =.  a  a(active %.n, after journal)
  =.  a  ?:(?=(%| -.result) a(segment (digest [%gap id.f])) a)
  [held(arms (~(put by arms.held) session.work.a a), frames (~(put by frames.held) id.f f)) f]
++  retain-outside
  ::  These are provenance events, never measurements. No segment mutation.
  |=  [our=@p at=@da held=state a=armed journal=@ud context=@ux reply=@ux]
  ^-  [state frame]
  =/  f=frame
    [%qpc-observation-frame-v1 0x0 our work.a ordinal.a segment.a at journal context reply [%outside %read-only]]
  =.  f  f(id (digest f))
  =.  a  a(active %.n, after journal)
  [held(arms (~(put by arms.held) session.work.a a), frames (~(put by frames.held) id.f f)) f]
++  valid
  |=  [our=@p held=state]
  ^-  ?
  ?&  (lte ~(wyt by manifests.held) manifest-limit)  (lte ~(wyt by arms.held) arm-limit)
      (lte ~(wyt by frames.held) frame-limit)
      (lte (add ~(wyt by frames.held) (lent (skim ~(val by arms.held) |=(a=armed active.a)))) frame-limit)
      (levy ~(tap by manifests.held) |=([id=@ux m=manifest] &((manifest-valid m) =(id (digest m)) =(our owner.m))))
      %+  levy  ~(tap by arms.held)
      |=  [id=@ux a=armed]
      =/  m  (~(get by manifests.held) manifest.work.a)
      ?~  m  %.n
      &((work-fields-valid u.m work.a) =(id session.work.a) (identifier:report segment.a) (lte (met 0 ordinal.a) 64))
      %+  levy  ~(tap by frames.held)
      |=  [id=@ux f=frame]
      =/  m  (~(get by manifests.held) manifest.work.f)
      ?~  m  %.n
      ?&  (work-fields-valid u.m work.f)  =(our owner.f)  =(id id.f)  =(id (digest f(id 0x0)))
          ?:  ?=(%outside -.result.f)
            &(!=(%qpc-observation-manifest-v1 version.u.m) (identifier:report context.f) (identifier:report reply.f))
          %.y
      ==
  ==
--
