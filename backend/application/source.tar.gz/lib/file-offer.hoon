::  /lib/file-offer.hoon
::
::  A FILE OFFERED ACROSS SHIPS, as evidence.
::
::  Born 2026-08-20, the night clay sync between the live pair proved
::  broken at two independent layers (maroon-vere HEAD hangs all cross-ship
::  clay reads; dashus cannot serve reads at its own recent %pataphor
::  revisions, and clay's answer to an unservable sing is ETERNAL SILENCE).
::  Gall pokes were flawless the whole time.  So the offering rides the
::  channel that works: a collaborator pokes the file in as speech, the
::  ship stamps WHO from src.bowl, graf holds it as %light evidence, and
::  ted/offer-pull commits it into a claimed fork only when the stamp
::  matches the claim's holder.  Landing stays the law's job.
::
::  TWO SHAPES, deliberately:
::
::  +$offer-in is the WIRE shape -- what a foreign ship sends.  The actor
::  is NEVER in the payload (same rule as %bench-say, +can-connect, and
::  seat-warden).  hash binds the content: an offer that does not mug to
::  its own hash is refused at the door.
::
::  +$offer is the STORED fact -- offer-in plus who, stamped by the
::  RECEIVING agent from src.bowl.  Per the consistency-is-not-
::  authentication scar: a provenance field a writer fills in about itself
::  is a claim; a field the membrane stamps from the packet source is an
::  attestation.  Only stamped offers exist in graf.
::
|%
+$  offer-in
  $:  ::  the fork this offer wants to enter (must be CLAIMED by the sender)
      fork=@tas
      ::  the desk it was authored in, on the SENDER's ship -- provenance,
      ::  re-checkable there by anyone the sender permits
      dek=@tas
      pax=path
      content=@t
      hash=@
  ==
+$  offer
  [%file-offer %2 who=@p fork=@tas dek=@tas pax=path content=@t hash=@]
+$  pull
  [%federated-pull %1 who=@p dek=@tas pax=path at=@da hash=@]
::  the wire shape is self-consistent: content mugs to hash
++  good-in
  |=  in=offer-in
  ^-  ?
  =(hash.in (mug content.in))
::  stamp: the only constructor of the stored shape.  who comes from the
::  caller's src.bowl, never from the wire.
++  stamp
  |=  [who=@p in=offer-in]
  ^-  offer
  [%file-offer %2 who fork.in dek.in pax.in content.in hash.in]
++  pull-for
  |=  [item=offer at=@da]
  ^-  pull
  [%federated-pull %1 who.item dek.item pax.item at hash.item]
::  read a stored fact back, REFUSING tampered content even if the shape
::  softs.  %1 offers (the pre-stamp era, no who) do not soft and are
::  correctly invisible to this lane.
++  offer-of
  |=  f=*
  ^-  (unit offer)
  =/  s  ((soft offer) f)
  ?~  s  ~
  ?.  =(hash.u.s (mug content.u.s))  ~
  s
::  every stored offer for a fork whose stamp matches the fork's claim
::  holder.  The claim is the authorization; the stamp is the identity;
::  an offer from anyone else is not an error, just not YOURS to apply.
++  for-fork
  |=  [facts=(list *) fork=@tas holder=@p]
  ^-  (list offer)
  %+  skim  (murn facts offer-of)
  |=  o=offer
  &(=(fork.o fork) =(who.o holder))
::  THE INVITATION LAW over facts: a ship is a guest iff its latest
::  invitation is STRICTLY newer than its latest revocation.  A tie goes
::  to the revocation -- when the record cannot order the two rulings,
::  the door stays shut.  Re-inviting after a revocation works by the
::  same comparison; nothing is ever deleted.
::
::  Fact shapes (both written by bench, who/by from src.bowl):
::    [%bench-guest         %1 g=@p by=@p at=@da]
::    [%bench-guest-revoked %1 g=@p by=@p at=@da]
++  guest-law
  |=  [invites=(list *) revokes=(list *) who=@p]
  ^-  ?
  =/  best
    |=  [tag=@tas facts=(list *)]
    ^-  (unit @da)
    %+  roll  facts
    |=  [f=* acc=(unit @da)]
    ^-  (unit @da)
    =/  s  ((soft ,[t=@tas %1 g=@p by=@p at=@da]) f)
    ?~  s  acc
    ?.  =(tag t.u.s)  acc
    ?.  =(who g.u.s)  acc
    ?~  acc  `at.u.s
    `(max u.acc at.u.s)
  =/  inv=(unit @da)  (best %bench-guest invites)
  =/  rev=(unit @da)  (best %bench-guest-revoked revokes)
  ?~  inv  %.n
  ?~  rev  %.y
  (gth u.inv u.rev)
::  A holder with invitation history is a guest forever after for courier
::  purposes: revocation must therefore be checked at PULL time, not only
::  when bench first accepts the offer.  Holders with no invitation record
::  are admitted by another membrane (self or parentage) and pass unchanged.
++  courier-holder
  |=  [invites=(list *) revokes=(list *) who=@p]
  ^-  ?
  =/  invited=?
    %+  lien  invites
    |=  f=*
    =/  s  ((soft ,[t=@tas %1 g=@p by=@p at=@da]) f)
    ?~  s  %.n
    &(=(%bench-guest t.u.s) =(who g.u.s))
  ?.  invited  %.y
  (guest-law invites revokes who)
::  The courier's complete selection law.  Stored offers remain immutable
::  evidence, but a revoked guest's old offers are no longer executable.
++  courier-for-fork
  |=  [facts=(list *) invites=(list *) revokes=(list *) fork=@tas holder=@p]
  ^-  (list offer)
  ?.  (courier-holder invites revokes holder)  ~
  (for-fork facts fork holder)
--
