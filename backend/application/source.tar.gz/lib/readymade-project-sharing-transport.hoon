::  Owner-only canonical reads and single dispatch; no retry or ACK authority.
/-  pa=cantrip-project-access, mp=multiplayer-project, nc=native-coding
/+  sharing=readymade-project-sharing, guard=viki-scry-guard
|%
+$  change
  [journal=journal:sharing record=record:sharing cards=(list card:agent:gall)]
++  read
  |=  [b=bowl:gall id=@t]
  ^-  (each observation:sharing @tas)
  ?.  &(=(our.b src.b) !=('' id) (lte (met 3 id) 128))
    [%| %sharing-owner-required]
  ?.  ?&  (agent-live:guard our.b now.b %multiplayer-runtime)
          (agent-live:guard our.b now.b %cantrip)
          (agent-live:guard our.b now.b %viki)
      ==  [%| %sharing-native-unavailable]
  =/  p=(unit project:mp)
    .^((unit project:mp) %gx /(scot %p our.b)/multiplayer-runtime/(scot %da now.b)/catalog/[id]/noun)
  ?~  p  [%| %sharing-project-missing]
  ?.  &(=(our.b authority.spec.u.p) =(id id.spec.u.p))
    [%| %sharing-foreign-project]
  =/  configs=(map @t project:nc)
    .^((map @t project:nc) %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/projects/noun)
  =/  grants=grants:pa
    .^(grants:pa %gx /(scot %p our.b)/cantrip/(scot %da now.b)/project-access/grants/noun)
  [%& [our.b now.b u.p (~(get by configs) id) grants]]
++  plan
  ::  Caller installs returned journal and cards in the SAME Gall transition.
  |=  [our=@p actor=@p o=observation:sharing j=journal:sharing c=command:sharing]
  ^-  (each change @tas)
  =/  prepared  (prepare:sharing our actor o j c)
  ?:  ?=(%| -.prepared)  [%| p.prepared]
  =/  d=decision:sharing  p.prepared
  =/  r=record:sharing  record.d
  =/  cards=(list card:agent:gall)
    ?.  dispatch.d  ~
    ~[[%pass /collab/sharing/[request.command.r] %agent [our %cantrip] %poke %noun !>(action.r)]]
  [%& [journal.d r cards]]
++  begin
  |=  [b=bowl:gall j=journal:sharing c=command:sharing]
  ^-  (each change @tas)
  ?.  &(=(our.b src.b) =(our.b owner.c))  [%| %sharing-owner-required]
  =/  observed  (read b project.c)
  ?:  ?=(%| -.observed)  [%| p.observed]
  (plan our.b src.b p.observed j c)
--
