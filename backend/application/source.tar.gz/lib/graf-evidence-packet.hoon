::  /lib/graf-evidence-packet.hoon
::
::  A SMALL, REPRODUCIBLE READ from Graf for one Viki goal.  This library
::  ranks and bounds material already present in Graf; it never invents a
::  semantic or causal label.  Relation kinds are returned exactly as stored.
::
/-  graf-sur=graf
/+  ask-build, graf-relations, wh=weight-hypothesis
|%
+$  evidence-ref
  $:  handle=@t
      text=@t
  ==
+$  visible-relation
  [rel=rel:graf-relations tier=@tas]
+$  relation-ref
  $:  tier=@tas
      kind=@tas
      src=@t
      dst=@t
  ==
+$  contradiction-ref  [handle=@t ship=@p]
+$  provenance-ref
  $:  handle=@t
      action=@tas
      source=@p
      legacy-handle=(unit @t)
  ==
+$  gap
  $:  kind=@tas
      handle=(unit @t)
      detail=@ud
  ==
+$  packet
  $:  version=@t
      query=@t
      exact=?
      index-n=@ud
      behind=@ud
      index-at=@da
      requested=@ud
      available=@ud
      refs=(list ref:ask-build)
      relations=(list relation-ref)
      contradictions=(list contradiction-ref)
      provenance=(list provenance-ref)
      gaps=(list gap)
  ==
+$  packet-input
  $:  query=@t
      exact=?
      index-n=@ud
      behind=@ud
      index-at=@da
      requested=@ud
      facts=(list *)
      relations=(list visible-relation)
      contradictions=(list contradiction-ref)
      provenance=(list provenance-ref)
  ==
+$  entry  [fact=* ref=evidence-ref]
::
++  max-refs  16
++  max-relations  16
++  max-contradictions  16
++  max-provenance  16
::
++  handle-of
  |=  fact=*
  ^-  (unit @t)
  =/  hypothesis=(unit fact:wh)  (decode:wh fact)
  ?^  hypothesis  `handle.u.hypothesis
  =/  projected
    ((soft graf-core-projection-fact:graf-sur) fact)
  ?^  projected
    `(scot %ux core-fact-id.u.projected)
  ?.  ?=([@ @ *] fact)  ~
  ``@t`+<.fact
::
++  entry-for
  |=  fact=*
  ^-  (unit entry)
  =/  handle  (handle-of fact)
  ?~  handle  ~
  =/  hypothesis=(unit fact:wh)  (decode:wh fact)
  =/  body=*  ?:(?=([@ @ *] fact) +>.fact fact)
  =/  text=@t
    ?~  hypothesis
      ?@(body `@t`body u.handle)
    (render:wh u.hypothesis)
  `[fact [u.handle text]]
::
++  rank-entry
  |=  [a=entry b=entry]
  ^-  ?
  =/  la=@ud  (met 3 text.ref.a)
  =/  lb=@ud  (met 3 text.ref.b)
  ?:  !=(la lb)  (lth la lb)
  ?:  !=(handle.ref.a handle.ref.b)
    (aor handle.ref.a handle.ref.b)
  (lth (jam fact.a) (jam fact.b))
::
++  relation-for
  |=  [row=visible-relation handles=(set @t)]
  ^-  (unit relation-ref)
  =/  source  (handle-of src.rel.row)
  =/  target  (handle-of dst.rel.row)
  ?~  source  ~
  ?~  target  ~
  ?.  ?|  (~(has in handles) u.source)
          (~(has in handles) u.target)
      ==
    ~
  `[tier.row kind.rel.row u.source u.target]
::
++  rank-noun
  |=  [a=* b=*]
  ^-  ?
  (lth (jam a) (jam b))
::
++  build
  |=  args=packet-input
  ^-  packet
  =/  requested=@ud  (min requested.args max-refs)
  =/  entries=(list entry)
    (sort (murn facts.args entry-for) rank-entry)
  =/  available=@ud  (lent entries)
  =/  kept=(list entry)  (scag requested entries)
  =/  handles=(set @t)
    %-  ~(gas in *(set @t))
    (turn kept |=(item=entry handle.ref.item))
  =/  all-relations=(list relation-ref)
    (sort (murn relations.args |=(row=visible-relation (relation-for row handles))) rank-noun)
  =/  all-contradictions=(list contradiction-ref)
    %+  sort
      (skim contradictions.args |=(row=contradiction-ref (~(has in handles) handle.row)))
    rank-noun
  =/  all-provenance=(list provenance-ref)
    %+  sort
      (skim provenance.args |=(row=provenance-ref (~(has in handles) handle.row)))
    rank-noun
  =/  relations=(list relation-ref)  (scag max-relations all-relations)
  =/  contradictions=(list contradiction-ref)
    (scag max-contradictions all-contradictions)
  =/  provenance=(list provenance-ref)  (scag max-provenance all-provenance)
  =/  gaps=(list gap)  ~
  =?  gaps  !exact.args
    [[?:(=(0 index-n.args) %recall-index-missing %recall-index-stale) ~ behind.args] gaps]
  =?  gaps  &(exact.args =(0 available))
    [[%no-match ~ 0] gaps]
  =?  gaps  (gth available requested)
    [[%fact-bound ~ (sub available requested)] gaps]
  =?  gaps  (gth (lent all-relations) max-relations)
    [[%relation-bound ~ (sub (lent all-relations) max-relations)] gaps]
  =?  gaps  (gth (lent all-contradictions) max-contradictions)
    [[%contradiction-bound ~ (sub (lent all-contradictions) max-contradictions)] gaps]
  =?  gaps  (gth (lent all-provenance) max-provenance)
    [[%provenance-bound ~ (sub (lent all-provenance) max-provenance)] gaps]
  =/  sourced=(set @t)
    %-  ~(gas in *(set @t))
    (turn all-provenance |=(row=provenance-ref handle.row))
  =/  missing=(list gap)
    %+  murn  kept
    |=  item=entry
    ^-  (unit gap)
    ?:  (~(has in sourced) handle.ref.item)  ~
    `[%provenance-missing `handle.ref.item 0]
  :*  'graf-evidence-packet-v1'
      query.args
      exact.args
      index-n.args
      behind.args
      index-at.args
      requested
      available
      (turn kept |=(item=entry [handle.ref.item text.ref.item]))
      relations
      contradictions
      provenance
      (flop (weld missing gaps))
  ==
--
