::  /lib/graf-core-engine.hoon
::
::  The open fact/territory substrate owned by canonical %graf.  This library
::  contains state transitions and read routing; it is not an agent and has no
::  independent authority surface.
::
/-  graf-sur=graf, graf-event, snap=graf-snapshot, f=frag,
    wis=weight-interpretation, wi=weight-inquiry
/+  graf-substrate, graf-relations, graf-search, graf-recall, graf-traverse,
    gew=graf-evidence-window, gts=graf-territory-state,
    gal=graf-axis-layout, bok,
    we=weight-evidence, wei=weight-evidence-index,
    gep=graf-evidence-packet, fsa=frag-scalar-axis,
    wh=weight-hypothesis, wib=weight-interpretation,
    crc=cantrip-record-cache
|%
+$  card  card:agent:gall
+$  territory  [axis=@ud writable=? active=?]
+$  plot  [app=@t axis=@ud fact=*]
+$  subject-summary
  $:  plot-count=@ud
      axis-count=@ud
      coherent-count=@ud
      conflict-count=@ud
  ==
+$  territory-event  territory-event:graf-event
+$  writer-link
  $:  generation=@ud
      connected=?
      accepted=@ud
      refused=@ud
      replayed=@ud
      retries=@ud
  ==
+$  writer-source
  $:  version=@t
      logical-writer=@tas
      physical-agent=@tas
      watch-path=@t
  ==
+$  placement  [status=@tas facts=store:graf-substrate plots=(list plot)]
+$  allocation-fact  [%territory-allocation app=@t axis=@ud writable=?]
+$  bok-chunk-fact
  $:  %bok-chunk
      id=@t
      doc=@t
      idx=@ud
      total=@ud
      pos=?(%opening %closing %body)
      sid=?(%qpc %rudolph)
      text=@t
  ==
+$  ascii-corpus-payload
  $:  %graf-ascii-corpus
      schema=@ud
      chunks=(list [source=@t text=@t])
  ==
+$  overlap-repair-payload
  $:  %graf-overlap-repair
      schema=@ud
      targets=(list [app=@t axis=@ud])
  ==
+$  overlap-repair-receipt
  $:  %graf-overlap-repair-receipt
      schema=@ud
      target-count=@ud
      removed-plot-count=@ud
      before-conflict-count=@ud
      after-conflict-count=@ud
  ==
+$  territory-conflict
  $:  left-app=@t
      left-axis=@ud
      right-app=@t
      right-axis=@ud
  ==
+$  overlap-repair-result
  $:  territories=(map @t territory)
      plots=(list plot)
      receipt=overlap-repair-receipt
  ==
+$  ascii-corpus-source
  $:  %graf-corpus-source
      source=@t
      text-digest=@ux
      axes=(list @ud)
  ==
+$  ascii-corpus-receipt
  $:  %graf-ascii-corpus-receipt
      schema=@ud
      chunk-count=@ud
      fragment-count=@ud
      occurrence-count=@ud
      corpus-digest=@ux
  ==
+$  fragment-fact
  $:  %graf-fragment
      kind=fragment-kind:gal
      text=@t
      ascii-atom=@ud
      ascii-axes=(list @ud)
      occurrences=(list fragment-occurrence:gal)
  ==
+$  corpus-materialization
  $:  facts=store:graf-substrate
      plots=(list plot)
      receipt=ascii-corpus-receipt
  ==
+$  corpus-state-summary
  $:  source-count=@ud
      fragment-count=@ud
      occurrence-count=@ud
      receipts=(list ascii-corpus-receipt)
  ==
::  THE RECALL INDEX, cached.
::
::  lib/graf-recall already splits the work correctly: +build is the
::  BAKE (expensive, linear in total key BYTES) and +recall is the SCAN
::  (cheap).  The peek called +fire, which does both -- so every query
::  re-baked the whole automaton.
::
::  MEASURED on the live ship before this change: 29.872 facts carrying
::  2.891.779 bytes of key material (avg ~97 bytes, max 98).  A query
::  matching NOTHING cost 38.3s; a matching one exceeded 120s.  The
::  bake was the entire floor and it was paid on every call.
::
::  So the bake is stored.  `n` is the fact count it was baked from.
::  The cache is usable only when `n` exactly equals the current count.
::  A stale cache still knows old facts, but using it would silently miss
::  appended facts; the correct slow path is mandatory until rebaked.
+$  recall-cache
  $:  ix=index:graf-recall
      n=@ud                             ::  fact count at bake time
      at=@da                            ::  when baked
  ==
+$  component-jam-index  (map @ @)
+$  component-cache
  $:  ix=component-jam-index
      n=@ud                             ::  distinct attested facts at bake
      at=@da
  ==
::  the PREVIOUS core shape, exported so app/graf can still soft the
::  state the running agent wrote.  Deleting this type is what turns an
::  upgrade into a crash.
+$  state-v4
  $:  %4
      governor=(unit @tas)
      attached=(set @p)
      facts=store:graf-substrate
      tiers=tiers:graf-relations
      attests=(jug * @p)
      contras=(jug * @p)
      grounding=(unit bok:bok)
      territories=(map @t territory)
      plots=(list plot)
      writer-links=(map @tas writer-link)
  ==
+$  state-v5
  $:  %5
      recall-index=(unit recall-cache)
      governor=(unit @tas)
      attached=(set @p)
      facts=store:graf-substrate
      tiers=tiers:graf-relations
      attests=(jug * @p)
      contras=(jug * @p)
      grounding=(unit bok:bok)
      territories=(map @t territory)
      plots=(list plot)
      writer-links=(map @tas writer-link)
  ==
+$  state
  $:  %6
      component-index=(unit component-cache)
      recall-index=(unit recall-cache)
      governor=(unit @tas)
      attached=(set @p)
      facts=store:graf-substrate
      tiers=tiers:graf-relations
      attests=(jug * @p)
      contras=(jug * @p)
      grounding=(unit bok:bok)
      territories=(map @t territory)
      plots=(list plot)
      writer-links=(map @tas writer-link)
  ==
+$  context  [our=@p src=@p now=@da canon-approved=?]
+$  authorization  [accepted=? reason=@tas]
+$  effect  [state=state cards=(list card)]
+$  snapshot-control  snapshot-control:snap
+$  snapshot-action  snapshot-action:snap
+$  core-snapshot  core-snapshot:snap
+$  unified-snapshot  unified-snapshot:snap
+$  snapshot-effect
  [control=snapshot-control state=state cards=(list card)]
::
++  bok-chunks
  |=  facts=store:graf-substrate
  ^-  (list [chunk-in:bok text=@t])
  =/  all=(list *)  (facts:graf-substrate facts)
  =|  out=(list [chunk-in:bok text=@t])
  =/  index=@ud  0
  |-  ^-  (list [chunk-in:bok text=@t])
  ?~  all  (flop out)
  =/  chunk  ((soft bok-chunk-fact) i.all)
  ?~  chunk  $(all t.all)
  =/  node=node:bok
    [pos.u.chunk doc.u.chunk sid.u.chunk (tok:bok text.u.chunk)]
  $(all t.all, index +(index), out [[[index node] text.u.chunk] out])
::
++  organ-seed
  ^-  (list [@t territory])
  :~  ['graf-board' [4 %.y %.y]]
      ['cantrip' [6 %.y %.y]]
      ['viki' [40 %.y %.y]]
      ['cortex' [41 %.y %.y]]
      ['waterwheel' [42 %.y %.y]]
      ['hand' [43 %.y %.y]]
      ['mcp' [47 %.y %.y]]
      ['scribe' [57 %.y %.y]]
      ['rlm' [59 %.y %.y]]
  ==
::
++  retired-organs
  ^-  (list @t)
  ~['juggler' 'juggler-review' 'moon-warden']
::
++  structural-writers
  ^-  (list @tas)
  ~[%cortex %cantrip %graf-board %viki %waterwheel %hand %mcp %scribe %rlm]
::
::  THE TERRITORY FEEDS (2026-10-20): the structural writers whose physical
::  agent actually serves its writer path, so graf watches only these.  The
::  rest stay structural for write admission and keep their link records
::  (+valid-state), but get no watch: %cantrip and %viki serve no
::  /graf/territory (they write by poke), %cortex and %scribe are not
::  installed, and %graf-board's physical %siev holds no board.
++  territory-feeds
  ^-  (list @tas)
  ~[%waterwheel %hand %mcp %rlm]
::
++  territory-feed
  |=  app=@tas
  ^-  ?
  (lien territory-feeds |=(candidate=@tas =(candidate app)))
::
++  structural-writer
  |=  app=@t
  ^-  ?
  (lien structural-writers |=(candidate=@tas =(candidate app)))
::
::  EDGE graf-dynamic-writer-agent-identity: namespace-labeled writes are
::  admitted by EXACT app identity -- a structural writer, a known organ
::  namespace, or the holder of an ACTIVE territory (the operator-managed
::  dynamic set: %grant-auto / %grant-territory admit, %revoke-territory
::  revokes). Gall cannot prove which same-ship agent sent a poke (the
::  permanent law); this admits the DECLARED identity against an explicit
::  registry instead of accepting any label under ship authority alone.
++  namespace-writers
  ^-  (set @tas)
  ::  %proof / %proof-app are the ph proof-thread namespaces.
  (silt `(list @tas)`~[%viki %sensor %waterwheel %nets %proof %proof-app])
::
++  writer-admitted
  |=  [st=state app=@tas]
  ^-  ?
  ?:  (structural-writer app)  %.y
  ?:  (~(has in namespace-writers) app)  %.y
  =/  held  (~(get by territories.st) `@t`app)
  ?~  held  %.n
  active.u.held
::
++  legacy-authorized
  |=  [our=@p src=@p]
  ^-  ?
  ?|(=(our src) =(our (^sein:title src)))
::
++  snapshot-authorized
  |=  [our=@p src=@p]
  ^-  ?
  =(our src)
::
++  core-source-authorized
  |=  [st=state our=@p src=@p]
  ^-  ?
  ?|  =(our src)
      =(our (^sein:title src))
      (~(has in attached.st) src)
  ==
::
::  Is this bare fact noun one of Cantrip's law records?  A fact is
::  [kind id body]; anything that is not a cell with an atom head cannot be a
::  law record and is left to the ordinary write law.
++  law-record-fact
  |=  fact=*
  ^-  ?
  ?@  fact  %.n
  ?.  ?=(@ -.fact)  %.n
  (~(has in record-kinds:crc) `@tas`-.fact)
::
++  authorize
  |=  [st=state act=graf-core-action:graf-sur ctx=context]
  ^-  authorization
  ?.  (core-source-authorized st our.ctx src.ctx)
    [%.n %core-source-law]
  ::  engraving and RETRACTING are the same authority question, but
  ::  they need separate ?= branches: `?|(?=(a) ?=(b))` does not refine
  ::  the type, so app.act would be unresolvable inside a merged test.
  ?:  ?=(%propose-canon -.act)
    ?.  (writer-admitted st app.act)  [%.n %core-writer-identity-law]
    ?:(canon-approved.ctx [%.y %accepted] [%.n %core-governor-law])
  ?:  ?=(%decanonize -.act)
    ?.  (writer-admitted st app.act)  [%.n %core-writer-identity-law]
    ?:(canon-approved.ctx [%.y %accepted] [%.n %core-governor-law])
  ?:  ?|  ?=(%allow-ship -.act)
          ?=(%disallow-ship -.act)
          ?=(%rebake-recall -.act)
          ?=(%rebake-weight-evidence -.act)
          ?=(%set-governor -.act)
          ?=(%bok-bake -.act)
          ?=(%grant-auto -.act)
          ?=(%grant-territory -.act)
          ?=(%revoke-territory -.act)
      ==
    ?:(=(our.ctx src.ctx) [%.y %accepted] [%.n %core-operator-law])
  ::  THE LAW-RECORD GATE (operator ruling, 2026-08-14: moons do not move law).
  ::  Cantrip rebuilds its window from Graf's facts BY KIND, and a stored fact
  ::  carries no author -- so once a moon's law record lands it is
  ::  indistinguishable from the principal's, and no downstream filter can tell
  ::  them apart.  The write is the last place the distinction exists, so the
  ::  gate lives here.  Graf keeps admitting our moons for ordinary facts; the
  ::  eight law-record kinds are operator-only.  The kind set is imported from
  ::  cantrip-record-cache rather than copied, so the two can never drift.
  ?:  ?&(?=(%light -.act) (law-record-fact fact.act))
    ?:  =(our.ctx src.ctx)  [%.y %accepted]
    [%.n %core-law-record-operator-law]
  ::  Attestation also lights the bare fact into the same substrate. Keep a
  ::  separate tag refinement so fact.act is typed in both write routes.
  ?:  ?&(?=(%attest -.act) (law-record-fact fact.act))
    ?:  =(our.ctx src.ctx)  [%.y %accepted]
    [%.n %core-law-record-operator-law]
  ?:  ?=(%plant -.act)
    =/  self=?  =(our.ctx src.ctx)
    ?:  &(self (structural-writer app.act))
      [%.n %core-structural-writer-law]
    =/  who=@t  ?:(self app.act (scot %p src.ctx))
    =/  held  (~(get by territories.st) who)
    ?~  held  [%.n %core-territory-law]
    ?.  active.u.held  [%.n %core-territory-inactive-law]
    ?.  writable.u.held  [%.n %core-territory-read-only-law]
    ?.  (in-subtree axis.u.held axis.act)
      [%.n %core-territory-axis-law]
    [%.y %accepted]
  ::  namespace-labeled writes admit by exact app identity, never by
  ::  ship authority alone.
  ?:  ?=(?(%note %unnote %publish %unpublish) -.act)
    ?:  (writer-admitted st app.act)  [%.y %accepted]
    [%.n %core-writer-identity-law]
  [%.y %accepted]
::
++  writer-links-seed
  ^-  (map @tas writer-link)
  %-  malt
  %+  turn  structural-writers
  |=(app=@tas [app *writer-link])
::
++  physical-writer
  |=  logical=@tas
  ^-  @tas
  ::  graf records its own Board's events (app/graf); %graf-board is no feed
  ?:  =(%graf-board logical)  %graf
  ?:  =(%mcp logical)  %vesp                      ::  the agent was renamed 2026-10-02; the writer keeps its name
  ?:(=(%rlm logical) %waterwheel logical)
::
++  writer-path
  |=  logical=@tas
  ^-  path
  ?:(=(%rlm logical) /graf/territory/rlm /graf/territory)
::
++  writer-source-for
  |=  logical=@tas
  ^-  writer-source
  ['graf-writer-source-v1' logical (physical-writer logical) (spat (writer-path logical))]
::
++  watch-wire
  |=  [app=@tas generation=@ud]
  ^-  wire
  [%territory app (scot %ud generation) ~]
::
++  watch-card
  |=  [our=@p app=@tas generation=@ud]
  ^-  card
  [%pass (watch-wire app generation) %agent [our (physical-writer app)] %watch (writer-path app)]
::
++  http-bind-card
  ^-  card
  [%pass /bind %arvo %e %connect [~ /graf] %graf]
::
++  retry-card
  |=  [app=@tas generation=@ud now=@da]
  ^-  card
  [%pass [%territory-retry app (scot %ud generation) ~] %arvo %b %wait (add now ~s5)]
::
++  start-links
  |=  [our=@p links=(map @tas writer-link)]
  ^-  [links=(map @tas writer-link) cards=(list card)]
  =/  apps=(list @tas)  structural-writers
  =/  out=(map @tas writer-link)  links
  =/  cards=(list card)  ~
  |-
  ?~  apps  [out (flop cards)]
  =/  app=@tas  i.apps
  =/  old=writer-link  (~(gut by out) app *writer-link)
  ::  every reload re-arms a fresh retry budget (on-arvo's twelve watches)
  =/  next=writer-link  old(generation +(generation.old), connected %.n, retries 0)
  =/  more=(list card)  ?.((territory-feed app) cards [(watch-card our app generation.next) cards])
  $(apps t.apps, out (~(put by out) app next), cards more)
::
++  set-connected
  |=  [links=(map @tas writer-link) app=@tas connected=?]
  ^-  (map @tas writer-link)
  =/  old=writer-link  (~(gut by links) app *writer-link)
  (~(put by links) app old(connected connected))
::
++  bump-link
  |=  [links=(map @tas writer-link) app=@tas status=@tas]
  ^-  (map @tas writer-link)
  =/  old=writer-link  (~(gut by links) app *writer-link)
  =/  next=writer-link  old
  =?  next  =(%accepted status)  old(accepted +(accepted.old))
  =?  next  =(%refused status)   old(refused +(refused.old))
  =?  next  =(%replayed status)  old(replayed +(replayed.old))
  (~(put by links) app next)
::
++  disconnect-links
  |=  links=(map @tas writer-link)
  ^-  (map @tas writer-link)
  %-  malt
  %+  turn  ~(tap by links)
  |=  [app=@tas link=writer-link]
  [app link(connected %.n)]
::
++  retain-structural-links
  |=  links=(map @tas writer-link)
  ^-  (map @tas writer-link)
  %-  malt
  %+  murn  ~(tap by links)
  |=  [app=@tas link=writer-link]
  ?:  (structural-writer app)
    `[[app link]]
  ~
::
::  %4 -> %6 core: both indexes are additive and start empty.  Every existing
::  field crosses by name, so no migration can silently scramble the fact floor.
++  upgrade-v4
  |=  old=state-v4
  ^-  state
  :*  %6
      component-index=~
      recall-index=~
      governor=governor.old
      attached=attached.old
      facts=facts.old
      tiers=tiers.old
      attests=attests.old
      contras=contras.old
      grounding=grounding.old
      territories=territories.old
      plots=plots.old
      writer-links=writer-links.old
  ==
++  upgrade-v5
  |=  old=state-v5
  ^-  state
  :*  %6
      component-index=~
      recall-index=recall-index.old
      governor=governor.old
      attached=attached.old
      facts=facts.old
      tiers=tiers.old
      attests=attests.old
      contras=contras.old
      grounding=grounding.old
      territories=territories.old
      plots=plots.old
      writer-links=writer-links.old
  ==
::
::  Exactness law: append-only facts make equal counts sufficient.  Any
::  mismatch is stale or corrupt and must use the correct slow path.
++  recall-cache-exact
  |=  [cache-n=@ud fact-n=@ud]
  ^-  ?
  =(cache-n fact-n)
++  recall-cache-valid
  |=  st=state
  ^-  ?
  ?~  recall-index.st  %.n
  (recall-cache-exact n.u.recall-index.st (count:graf-substrate facts.st))
++  attested-rows
  |=  st=state
  ^-  (list [* *])
  %+  turn  ~(tap by attests.st)
  |=  [fact=* ships=(set @p)]
  ^-  [* *]
  [fact ships]
++  component-cache-exact
  |=  [cache-n=@ud attested-n=@ud]
  ^-  ?
  =(cache-n attested-n)
++  component-cache-valid
  |=  st=state
  ^-  ?
  ?~  component-index.st  %.n
  (component-cache-exact n.u.component-index.st ~(wyt by attests.st))
++  close-component-index
  |=  raw=index:wei
  ^-  component-jam-index
  %-  malt
  %+  turn  ~(tap by raw)
  |=  [target=evidence-target:we facts=(list *)]
  [(jam target) (jam facts)]
++  component-evidence-read
  |=  [st=state target=evidence-target:we]
  ^-  *
  =/  now-n=@ud  ~(wyt by attests.st)
  =/  cache=(unit component-cache)  component-index.st
  =/  baked=?  (component-cache-valid st)
  =/  found-jam=@
    ?:  baked
      ?~  cache  2
      (~(gut by ix.u.cache) (jam target) 2)
    (jam (select:we target (attested-rows st)))
  =/  cache-n=@ud  ?~(component-index.st 0 n.u.component-index.st)
  :*  %weight-evidence-index
      status=?:(=(2 found-jam) %unmapped %inherited)
      retrieval=?:(baked %component-index %linear-attested-scan)
      baked=baked
      n=cache-n
      behind=?:((gth now-n cache-n) (sub now-n cache-n) 0)
      at=?~(component-index.st *@da at.u.component-index.st)
      evidence-jam=found-jam
  ==
::
++  recall-index-view
  |=  st=state
  ^-  index-view:wis
  =/  current=@ud  (count:graf-substrate facts.st)
  =/  indexed=@ud  ?~(recall-index.st 0 n.u.recall-index.st)
  =/  exact=?  (recall-cache-valid st)
  :*  present=?=(^ recall-index.st)
      exact=exact
      indexed=indexed
      current=current
      behind=?:((gth current indexed) (sub current indexed) 0)
      at=?~(recall-index.st *@da at.u.recall-index.st)
      retrieval=?:(exact %recall-index %linear-fact-scan)
  ==
++  component-index-view
  |=  st=state
  ^-  index-view:wis
  =/  current=@ud  ~(wyt by attests.st)
  =/  indexed=@ud  ?~(component-index.st 0 n.u.component-index.st)
  =/  exact=?  (component-cache-valid st)
  :*  present=?=(^ component-index.st)
      exact=exact
      indexed=indexed
      current=current
      behind=?:((gth current indexed) (sub current indexed) 0)
      at=?~(component-index.st *@da at.u.component-index.st)
      retrieval=?:(exact %component-index %linear-attested-scan)
  ==
++  evidence-target-for
  |=  component=fine-component:f
  ^-  evidence-target:we
  ?-  -.component
    %attn-head   [%attn-head layer.component head.component]
    %kv-group    [%kv-group layer.component group.component]
    %mlp-neuron  [%mlp-neuron layer.component neuron.component]
  ==
++  weight-interpretation-for-index
  |=  [st=state index=@ud]
  ^-  (unit packet:wis)
  =/  found=(unit scalar-address:fsa)  (address-for-index:fsa index)
  ?~  found  ~
  =/  address=scalar-address:fsa  u.found
  =/  hypothesis-index=index-view:wis  (recall-index-view st)
  =/  hypothesis-rows=(list *)
    ?~  recall-index.st
      (facts:graf-substrate facts.st)
    ?:  (recall-cache-valid st)
      ~(tap in (recall:graf-recall ix.u.recall-index.st (target-key:wh owner.address)))
    (facts:graf-substrate facts.st)
  =/  hypotheses=(list fact:wh)
    (select:wh owner.address hypothesis-rows)
  ?:  ?=(%shared -.owner.address)
    =/  no-component-index=index-view:wis
      [%.y %.y 0 0 0 *@da %not-applicable]
    =/  packet=packet:wis
      %-  build:wib
        :*  address
            %shared-structure
            no-component-index
            ~
            hypothesis-index
            hypotheses
        ==
    [~ packet]
  =/  target=evidence-target:we
    (evidence-target-for component.owner.address)
  =/  raw=evidence-read:wis
    ;;(evidence-read:wis (component-evidence-read st target))
  =/  evidence=(list *)
    ;;((list *) (cue evidence-jam.raw))
  =/  packet=packet:wis
    %-  build:wib
      :*  address
          %component-inherited
          (component-index-view st)
          evidence
          hypothesis-index
          hypotheses
      ==
  [~ packet]
::
++  weight-inquiry-history-for-index
  |=  [st=state index=@ud]
  ^-  history:wi
  (history-for:wi index (facts:graf-substrate facts.st))
::
++  evidence-packet
  |=  [st=state query=@t requested=@ud]
  ^-  packet:gep
  =/  fact-n=@ud  (count:graf-substrate facts.st)
  =/  cache-n=@ud  ?~(recall-index.st 0 n.u.recall-index.st)
  =/  exact=?
    ?~  recall-index.st  %.n
    (recall-cache-exact cache-n fact-n)
  =/  behind=@ud  ?:((gth fact-n cache-n) (sub fact-n cache-n) 0)
  =/  index-at=@da  ?~(recall-index.st *@da at.u.recall-index.st)
  =/  hits=(list *)
    ?~  recall-index.st  ~
    ?:  exact
      ~(tap in (recall:graf-recall ix.u.recall-index.st query))
    ~
  ::  With no fact handles, build discards every relation and provenance row.
  ::  Preserve its exact gap/limit semantics without scanning the whole graph.
  ?~  hits
    (build:gep [query exact cache-n behind index-at requested ~ ~ ~ ~])
  =/  visible=(set rel:graf-relations)
    (~(uni in canon.tiers.st) (all-published:graf-relations tiers.st))
  =/  relations=(list visible-relation:gep)
    %+  turn  ~(tap in visible)
    |=  relation=rel:graf-relations
    =/  in-canon=?  (~(has in canon.tiers.st) relation)
    =/  tier=@tas  ?:(in-canon %canon %published)
    [relation tier]
  =/  contradictions=(list contradiction-ref:gep)
    %-  zing
    %+  turn  hits
    |=  fact=*
    =/  handle  (handle-of:gep fact)
    ?~  handle  ~
    %+  turn  ~(tap in (~(get ju contras.st) fact))
    |=(ship=@p [u.handle ship])
  =/  provenance=(list provenance-ref:gep)
    %-  zing
    %+  turn  hits
    |=  fact=*
    =/  handle  (handle-of:gep fact)
    ?~  handle  ~
    =/  rows=(list provenance-ref:gep)
      %+  turn  ~(tap in (~(get ju attests.st) fact))
      |=(ship=@p [u.handle %attest ship ~])
    =/  projected
      ((soft graf-core-projection-fact:graf-sur) fact)
    ?~  projected  rows
    =/  legacy=(unit graf-handle:graf-sur)  legacy-handle.u.projected
    =/  legacy-id=(unit @t)  ?~(legacy ~ `id.u.legacy)
    [[u.handle action.u.projected source-ship.u.projected legacy-id] rows]
  %-  build:gep
  [query exact cache-n behind index-at requested hits relations contradictions provenance]
::
::
++  normalize-state
  |=  st=state
  ^-  state
  st(territories (retire:gts territories.st retired-organs), writer-links (disconnect-links (retain-structural-links writer-links.st)))
::
++  valid-state
  |=  st=state
  ^-  ?
  ?&  ?~((territory-conflicts territories.st) %.y %.n)
      %+  levy  retired-organs
      |=(app=@t !(~(has by territories.st) app))
      %+  levy  ~(val by territories.st)
      |=(held=territory (gth axis.held 0))
      %+  levy  structural-writers
      |=(app=@tas (~(has by writer-links.st) app))
      %+  levy  ~(val by writer-links.st)
      |=(link=writer-link !connected.link)
      %+  levy  plots.st
      |=  item=plot
      =/  held  (~(get by territories.st) app.item)
      ?~  held  %.n
      ?&  (in-subtree axis.u.held axis.item)
          (lit:graf-substrate facts.st fact.item)
      ==
  ==
::
++  init-control
  ^-  snapshot-control
  [%live 0 ~ ~ ~ ~ ~]
::
++  upgrade-control
  ^-  snapshot-control
  =/  control=snapshot-control  init-control
  control(mode %frozen, last-result `[%upgrade %.y %maintenance-required %frozen 0 ~])
::
++  restart-control
  |=  control=snapshot-control
  ^-  snapshot-control
  ?.  =(%live mode.control)  control
  control(mode %frozen, last-result `[%restart %.y %maintenance-required %frozen revision.control ~])
::
++  writes-open
  |=  control=snapshot-control
  ^-  ?
  =(%live mode.control)
::
++  snapshot-digest
  |=  item=core-snapshot
  ^-  @ux
  %-  shax
  %-  jam
  :*  schema.item
      source-ship.item
      source-agent.item
      exported-at.item
      revision.item
      state.item
  ==
::
++  make-snapshot
  |=  [st=state our=@p agent=@tas now=@da revision=@ud]
  ^-  core-snapshot
  =/  normalized  (normalize-state st)
  =/  item=core-snapshot
    [%core-snapshot 1 our agent now revision normalized 0x0]
  item(digest (snapshot-digest item))
::
++  noun-digest
  |=  value=*
  ^-  @ux
  (shax (jam value))
::
++  state-digest
  |=  st=state
  ^-  @ux
  (noun-digest (normalize-state st))
::
++  unified-data-digest
  |=  [st=state constitutional=*]
  ^-  @ux
  (noun-digest [(normalize-state st) constitutional])
::
++  unified-snapshot-digest
  |=  item=unified-snapshot
  ^-  @ux
  (noun-digest [schema.item core.item constitutional.item data-digest.item])
::
++  make-unified-snapshot
  |=  [core=core-snapshot st=state constitutional=*]
  ^-  unified-snapshot
  ?>  =(state.core st)
  ?>  =(digest.core (snapshot-digest core))
  ?>  (valid-state st)
  =/  data  (unified-data-digest st constitutional)
  =/  item=unified-snapshot
    [%unified-snapshot 1 core constitutional data 0x0]
  item(digest (unified-snapshot-digest item))
::
++  valid-unified-snapshot
  |=  item=unified-snapshot
  ^-  ?
  ?.  =(1 schema.item)  %.n
  ?.  =(digest.core.item (snapshot-digest core.item))  %.n
  =/  candidate  ((soft state) state.core.item)
  ?~  candidate  %.n
  ?.  (valid-state u.candidate)  %.n
  ?.  =(data-digest.item (unified-data-digest u.candidate constitutional.item))
    %.n
  =(digest.item (unified-snapshot-digest item))
::
++  snapshot-action-name
  |=  act=snapshot-action
  ^-  @tas
  ?-  -.act
    %freeze         %freeze
    %begin-import   %begin-import
    %commit-import  %commit-import
    %abort-import   %abort-import
    %rollback       %rollback
    %thaw           %thaw
  ==
::
++  note-result
  |=  $:  control=snapshot-control
          action=@tas
          accepted=?
          reason=@tas
          digest=(unit @ux)
      ==
  ^-  snapshot-control
  control(last-result `[action accepted reason mode.control revision.control digest])
::
++  block-write
  |=  control=snapshot-control
  ^-  snapshot-control
  (note-result control %core-write %.n %mode-blocked ~)
::
++  record-write
  |=  [control=snapshot-control changed=?]
  ^-  snapshot-control
  ?:  changed
    =/  next  control(revision +(revision.control))
    (note-result next %core-write %.y %accepted ~)
  (note-result control %core-write %.y %no-change ~)
::
++  apply-snapshot
  |=  $:  control=snapshot-control
          st=state
          act=snapshot-action
          our=@p
          agent=@tas
          now=@da
          expected-source-agent=@tas
      ==
  ^-  snapshot-effect
  =/  action  (snapshot-action-name act)
  ?-  -.act
    %freeze
      ?.  (writes-open control)
        [(note-result control action %.n %wrong-mode ~) st ~]
      ?.  =(expected-revision.act revision.control)
        [(note-result control action %.n %stale-target ~) st ~]
      =/  normalized  (normalize-state st)
      ?.  (valid-state normalized)
        [(note-result control action %.n %invalid-state ~) st ~]
      =/  item  (make-snapshot normalized our agent now revision.control)
      =/  next
        control(mode %frozen, export `item, pending ~, rollback ~)
      [(note-result next action %.y %accepted `digest.item) normalized ~]
    %begin-import
      ?.  =(%frozen mode.control)
        [(note-result control action %.n %wrong-mode ~) st ~]
      ?.  =(expected-revision.act revision.control)
        [(note-result control action %.n %stale-target ~) st ~]
      =/  item  snapshot.act
      ?.  =(1 schema.item)
        [(note-result control action %.n %wrong-schema `digest.item) st ~]
      ?.  =(our source-ship.item)
        [(note-result control action %.n %foreign-ship `digest.item) st ~]
      ?.  =(expected-source-agent source-agent.item)
        [(note-result control action %.n %wrong-agent `digest.item) st ~]
      ?.  =(digest.item (snapshot-digest item))
        [(note-result control action %.n %bad-digest `digest.item) st ~]
      =/  candidate  ((soft state) state.item)
      ?~  candidate
        [(note-result control action %.n %bad-state `digest.item) st ~]
      =/  normalized  (normalize-state u.candidate)
      ?.  (valid-state normalized)
        [(note-result control action %.n %invalid-state `digest.item) st ~]
      =/  previous  last-source.control
      ?.  ?~(previous %.y (gth revision.item revision.u.previous))
        [(note-result control action %.n %stale-source `digest.item) st ~]
      =/  saved=(unit *)  `st
      =/  next
        control(mode %importing, pending `item, rollback saved)
      [(note-result next action %.y %accepted `digest.item) st ~]
    %commit-import
      ?.  =(%importing mode.control)
        [(note-result control action %.n %wrong-mode `digest.act) st ~]
      =/  pending  pending.control
      ?~  pending
        [(note-result control action %.n %missing-pending `digest.act) st ~]
      ?.  =(digest.act digest.u.pending)
        [(note-result control action %.n %digest-mismatch `digest.act) st ~]
      =/  candidate  ((soft state) state.u.pending)
      ?~  candidate
        [(note-result control action %.n %bad-state `digest.act) st ~]
      =/  imported  (normalize-state u.candidate)
      ?.  (valid-state imported)
        [(note-result control action %.n %invalid-state `digest.act) st ~]
      =/  source=snapshot-source:snap
        [source-ship.u.pending source-agent.u.pending revision.u.pending digest.u.pending]
      =/  next-revision=@ud
        (add 1 (max revision.control revision.u.pending))
      =/  next
        control(mode %frozen, revision next-revision, export pending, pending ~, last-source `source)
      [(note-result next action %.y %accepted `digest.act) imported ~]
    %abort-import
      ?.  =(%importing mode.control)
        [(note-result control action %.n %wrong-mode `digest.act) st ~]
      =/  pending  pending.control
      ?~  pending
        [(note-result control action %.n %missing-pending `digest.act) st ~]
      ?.  =(digest.act digest.u.pending)
        [(note-result control action %.n %digest-mismatch `digest.act) st ~]
      =/  next  control(mode %frozen, pending ~, rollback ~)
      [(note-result next action %.y %accepted `digest.act) st ~]
    %rollback
      ?.  =(%frozen mode.control)
        [(note-result control action %.n %wrong-mode `digest.act) st ~]
      =/  source  last-source.control
      ?~  source
        [(note-result control action %.n %missing-import `digest.act) st ~]
      ?.  =(digest.act digest.u.source)
        [(note-result control action %.n %digest-mismatch `digest.act) st ~]
      =/  rollback  rollback.control
      ?~  rollback
        [(note-result control action %.n %missing-rollback `digest.act) st ~]
      =/  restored  ((soft state) u.rollback)
      ?~  restored
        [(note-result control action %.n %bad-rollback `digest.act) st ~]
      =/  normalized  (normalize-state u.restored)
      ?.  (valid-state normalized)
        [(note-result control action %.n %invalid-rollback `digest.act) st ~]
      =/  next
        control(revision +(revision.control), export ~, pending ~, rollback ~)
      [(note-result next action %.y %accepted `digest.act) normalized ~]
    %thaw
      ?.  =(%frozen mode.control)
        [(note-result control action %.n %wrong-mode ~) st ~]
      ?.  =(expected-revision.act revision.control)
        [(note-result control action %.n %stale-target ~) st ~]
      =/  prepared  (prepare our st)
      =/  next  control(mode %live, pending ~, rollback ~)
      [(note-result next action %.y %accepted ~) state.prepared cards.prepared]
  ==
::
++  peek-snapshot
  |=  [control=snapshot-control pax=path]
  ^-  (unit (unit cage))
  =/  export-digest=(unit @ux)
    ?~(export.control ~ `digest.u.export.control)
  =/  pending-digest=(unit @ux)
    ?~(pending.control ~ `digest.u.pending.control)
  ?+  pax  ~
    [%x %snapshot %noun ~]
      ``noun+!>(export.control)
    [%x %snapshot %hash ~]
      ``noun+!>(export-digest)
    [%x %snapshot %mode ~]
      ``noun+!>(mode.control)
    ::  THE UNFREEZE PRECONDITION (rehearsal finding R2).  Every restart
    ::  freezes writes by law, and %thaw demands the CURRENT revision -- but
    ::  the only surface carrying it was /x/snapshot/noun, which ships whole
    ::  core snapshots, crashes spider, and wedges the newt decoder.  A gate
    ::  that cannot state its own precondition turns a diagnosable step into a
    ::  guessable one, so the operator gets it as a bounded atom.
    [%x %snapshot %revision ~]
      ``noun+!>(revision.control)
    ::  ...and the reason the last snapshot action was accepted or refused,
    ::  likewise bounded: verdict, code, and the acting revision only.
    [%x %snapshot %last-result ~]
      =/  last  last-result.control
      ?~  last
        ``noun+!>([%graf-snapshot-last-result %none %.n %none revision.control])
      :^  ~  ~  %noun
      !>  :*  %graf-snapshot-last-result
              action.u.last
              accepted.u.last
              reason.u.last
              revision.control
          ==
    [%x %snapshot %donor %validation ~]
      =/  donor  last-source.control
      =/  donor-present=?  ?=(^ donor)
      =/  donor-agent=@tas  ?~(donor %none agent.u.donor)
      =/  donor-digest=@ux  ?~(donor 0x0 digest.u.donor)
      =/  current  export.control
      ?~  current
        ``noun+!>([%graf-donor-validation donor-present donor-agent donor-digest %.n %none 0x0 %.n])
      =/  item=core-snapshot  u.current
      ``noun+!>([%graf-donor-validation donor-present donor-agent donor-digest %.y source-agent.item digest.item =(digest.item (snapshot-digest item))])
    [%x %snapshot %summary ~]
      ``noun+!>([%graf-snapshot-summary mode.control revision.control export-digest pending-digest rollback=?=(^ rollback.control) last-source.control last-result.control])
  ==
::
++  peek-unified-snapshot
  |=  [control=snapshot-control st=state constitutional=* pax=path]
  ^-  (unit (unit cage))
  ?.  ?|  =([%x %snapshot %unified %noun ~] pax)
          =([%x %snapshot %unified %hash ~] pax)
          =([%x %snapshot %unified %data-hash ~] pax)
          =([%x %snapshot %unified %summary ~] pax)
      ==
    ~
  =/  current-data=@ux  (unified-data-digest st constitutional)
  =/  core-data=@ux  (state-digest st)
  =/  constitutional-data=@ux  (noun-digest constitutional)
  =/  checkpoint=(unit unified-snapshot)
    ?.  =(%frozen mode.control)  ~
    =/  exported  export.control
    ?~  exported  ~
    ?.  =(state.u.exported st)  ~
    `(make-unified-snapshot u.exported st constitutional)
  =/  checkpoint-digest=(unit @ux)
    ?~(checkpoint ~ `digest.u.checkpoint)
  =/  checkpoint-data=(unit @ux)
    ?~(checkpoint ~ `data-digest.u.checkpoint)
  ?+  pax  ~
    [%x %snapshot %unified %noun ~]
      ``noun+!>(checkpoint)
    [%x %snapshot %unified %hash ~]
      ``noun+!>(checkpoint-digest)
    [%x %snapshot %unified %data-hash ~]
      ``noun+!>(current-data)
    [%x %snapshot %unified %summary ~]
      ``noun+!>([%graf-unified-snapshot-summary mode.control revision.control checkpoint-digest checkpoint-data current-data core-data constitutional-data])
  ==
::
++  place-structural
  |=  $:  territories=(map @t territory)
          facts=store:graf-substrate
          plots=(list plot)
          app=@tas
          fact=*
      ==
  ^-  placement
  =/  found  (~(get by territories) `@t`app)
  ?~  found  [%refused facts plots]
  ?.  active.u.found  [%refused facts plots]
  ?.  writable.u.found  [%refused facts plots]
  =/  axis=@ud  axis.u.found
  ?:  (lien plots |=(existing=plot ?&(=(app.existing app) =(axis.existing axis) =(fact.existing fact))))
    [%replayed facts plots]
  [%accepted (light:graf-substrate facts fact) [[app axis fact] plots]]
::
++  in-subtree
  |=  [root=@ud axis=@ud]
  ^-  ?
  ?:  =(0 root)  %.n
  ?:  =(0 axis)  %.n
  |-
  ?:  =(root axis)  %.y
  ?:  (lte axis 1)  %.n
  ?:  (lth axis root)  %.n
  $(axis (div axis 2))
::
++  frag
  |=  [axis=@ud subject=*]
  ^-  (unit *)
  ?:  =(axis 0)  ~
  |-
  ?:  =(axis 1)  `subject
  ?@  subject  ~
  =/  branch  (cap axis)
  %=  $
    axis     (mas axis)
    subject  ?-(branch %2 -.subject, %3 +.subject)
  ==
::
++  sparse-subject-set
  |=  [subject=* axis=@ud value=*]
  ^-  *
  ?>  (gth axis 0)
  ?:  =(axis 1)
    value
  =/  head=*
    ?^(subject -.subject 0)
  =/  tail=*
    ?^(subject +.subject 0)
  =/  branch=@ud  (cap axis)
  =/  rest=@ud  (mas axis)
  ?:  =(branch 2)
    [(sparse-subject-set head rest value) tail]
  [head (sparse-subject-set tail rest value)]
::
++  build-subject
  |=  items=(list plot)
  ^-  *
  =/  queue=(list plot)  (flop items)
  =|  subject=*
  |-
  ?~  queue  subject
  $(queue t.queue, subject (sparse-subject-set subject axis.i.queue fact.i.queue))
::
++  latest-plots
  |=  items=(list plot)
  ^-  (list plot)
  =|  seen=(set @ud)
  =|  out=(list plot)
  |-
  ?~  items  (flop out)
  ?:  (~(has in seen) axis.i.items)
    $(items t.items)
  $(items t.items, seen (~(put in seen) axis.i.items), out [i.items out])
::
++  find-plot-at-axis
  |=  [items=(list plot) axis=@ud]
  ^-  (unit plot)
  ?~  items  ~
  ?:  =(axis.i.items axis)
    `i.items
  $(items t.items)
::
++  newer-axis-overlap
  |=  [items=(list plot) axis=@ud]
  ^-  ?
  ?~  items  %.n
  ?:  =(axis.i.items axis)  %.n
  ?:  ?|  (in-subtree axis axis.i.items)
          (in-subtree axis.i.items axis)
      ==
    %.y
  $(items t.items)
::
++  read-axis
  |=  [items=(list plot) axis=@ud]
  ^-  (unit *)
  ?:  =(axis 0)  ~
  =/  found  (find-plot-at-axis items axis)
  ?~  found  ~
  ?.  (newer-axis-overlap items axis)
    `fact.u.found
  =/  subject=*  (build-subject items)
  =/  read=(unit *)  (frag axis subject)
  ?~  read  ~
  ?.  =(u.read fact.u.found)  ~
  read
::
++  summarize-subject
  |=  items=(list plot)
  ^-  subject-summary
  =/  subject=*  (build-subject items)
  =/  latest=(list plot)  (latest-plots items)
  =/  coherent=(list plot)
    %+  skim  latest
    |=  item=plot
    =/  read=(unit *)  (frag axis.item subject)
    ?~(read %.n =(u.read fact.item))
  =/  coherent-count=@ud  (lent coherent)
  =/  axis-count=@ud  (lent latest)
  [plot-count=(lent items) axis-count=axis-count coherent-count=coherent-count conflict-count=(sub axis-count coherent-count)]
::
++  subject-conflicts
  |=  items=(list plot)
  ^-  (list plot)
  =/  subject=*  (build-subject items)
  %+  skim  (latest-plots items)
  |=  item=plot
  =/  read=(unit *)  (frag axis.item subject)
  ?~(read %.y !=(u.read fact.item))
::
++  territory-conflicts
  |=  territories=(map @t territory)
  ^-  (list territory-conflict)
  =/  items=(list [@t territory])  ~(tap by territories)
  =|  out=(list territory-conflict)
  |-
  ?~  items  (flop out)
  =/  left-app=@t  -.i.items
  =/  left=territory  +.i.items
  =/  clashes=(list territory-conflict)
    %+  murn  t.items
    |=  [right-app=@t right=territory]
    ?:  (overlaps axis.left axis.right)
      `[left-app axis.left right-app axis.right]
    ~
  $(items t.items, out (weld clashes out))
::
++  repair-targets-distinct
  |=  targets=(list [app=@t axis=@ud])
  ^-  ?
  =|  seen=(set @t)
  |-
  ?~  targets  %.y
  ?:  (~(has in seen) app.i.targets)  %.n
  $(targets t.targets, seen (~(put in seen) app.i.targets))
::
++  repair-targets-match
  |=  $:  territories=(map @t territory)
          targets=(list [app=@t axis=@ud])
      ==
  ^-  ?
  %+  levy  targets
  |=  target=[app=@t axis=@ud]
  =/  held=(unit territory)  (~(get by territories) app.target)
  ?~  held  %.n
  ?&  =(axis.target axis.u.held)
      !(structural-writer app.target)
      ?|(!active.u.held !writable.u.held)
  ==
::
++  repair-target-set
  |=  targets=(list [app=@t axis=@ud])
  ^-  (set @t)
  (~(gas in *(set @t)) (turn targets |=(target=[app=@t axis=@ud] app.target)))
::
++  remove-target-territories
  |=  $:  territories=(map @t territory)
          targets=(list [app=@t axis=@ud])
      ==
  ^-  (map @t territory)
  ?~  targets  territories
  $(territories (~(del by territories) app.i.targets), targets t.targets)
::
++  repair-overlaps
  |=  $:  territories=(map @t territory)
          plots=(list plot)
          targets=(list [app=@t axis=@ud])
      ==
  ^-  (unit overlap-repair-result)
  ?~  targets  ~
  ?.  (repair-targets-distinct targets)  ~
  ?.  (repair-targets-match territories targets)  ~
  =/  before=subject-summary  (summarize-subject plots)
  ?:  =(0 conflict-count.before)  ~
  =/  target-apps=(set @t)  (repair-target-set targets)
  =/  kept-plots=(list plot)
    (skim plots |=(item=plot !(~(has in target-apps) app.item)))
  =/  next-territories=(map @t territory)
    (remove-target-territories territories targets)
  ?:  !=(~ (territory-conflicts next-territories))  ~
  =/  after=subject-summary  (summarize-subject kept-plots)
  ?:  !=(0 conflict-count.after)  ~
  =/  removed=@ud  (sub (lent plots) (lent kept-plots))
  ?:  =(0 removed)  ~
  =/  receipt=overlap-repair-receipt
    :*  %graf-overlap-repair-receipt
        1
        (lent targets)
        removed
        conflict-count.before
        conflict-count.after
    ==
  `[next-territories kept-plots receipt]
::
++  fragment-fact-from-node
  |=  node=fragment-node:gal
  ^-  fragment-fact
  :*  %graf-fragment
      kind.node
      text.node
      ascii-atom.address.node
      ascii-axes.address.node
      occurrences.node
  ==
::
++  corpus-source-from-chunk
  |=  chunk=[source=@t text=@t]
  ^-  ascii-corpus-source
  =/  items=(list [kind=fragment-kind:gal address=memory-address:gal])
    (addressed-tokens:gal text.chunk)
  =/  axes=(list @ud)
    (turn items |=(item=[kind=fragment-kind:gal address=memory-address:gal] absolute-axis.address.item))
  [%graf-corpus-source source.chunk (shax (jam text.chunk)) axes]
::
++  occurrence-count
  |=  nodes=(list fragment-node:gal)
  ^-  @ud
  =|  total=@ud
  |-
  ?~  nodes  total
  $(nodes t.nodes, total (add total (lent occurrences.i.nodes)))
::
++  light-all
  |=  [facts=store:graf-substrate items=(list *)]
  ^-  store:graf-substrate
  ?~  items  facts
  $(items t.items, facts (light:graf-substrate facts i.items))
::
::  Replace the physical Hand territory with the canonical ASCII graph.  Old
::  Hand plots remain lit as append-only facts, but no ancestor plot is allowed
::  to mask the fragment paths below axis 43.
++  materialize-corpus
  |=  $:  facts=store:graf-substrate
          plots=(list plot)
          chunks=(list [source=@t text=@t])
      ==
  ^-  corpus-materialization
  =/  index=fragment-index:gal  (index-corpus:gal chunks)
  =/  nodes=(list fragment-node:gal)  ~(val by index)
  =/  fragment-facts=(list fragment-fact)
    (turn nodes fragment-fact-from-node)
  =/  fragment-plots=(list plot)
    %+  turn  nodes
    |=  node=fragment-node:gal
    ['hand' absolute-axis.address.node (fragment-fact-from-node node)]
  =/  source-facts=(list ascii-corpus-source)
    (turn chunks corpus-source-from-chunk)
  =/  receipt=ascii-corpus-receipt
    :*  %graf-ascii-corpus-receipt
        1
        (lent chunks)
        (lent nodes)
        (occurrence-count nodes)
        (shax (jam chunks))
    ==
  =/  preserved=(list plot)
    %+  skim  plots
    |=  item=plot
    !(in-subtree:gal memory-owner-axis:gal axis.item)
  =/  next-facts=store:graf-substrate
    (light-all facts `(list *)`source-facts)
  =.  next-facts  (light:graf-substrate next-facts receipt)
  =.  next-facts  (light-all next-facts `(list *)`fragment-facts)
  [next-facts (weld fragment-plots preserved) receipt]
::
++  corpus-sources
  |=  facts=store:graf-substrate
  ^-  (list ascii-corpus-source)
  %+  murn  (facts:graf-substrate facts)
  |=  fact=*
  ((soft ascii-corpus-source) fact)
::
++  corpus-receipts
  |=  facts=store:graf-substrate
  ^-  (list ascii-corpus-receipt)
  %+  murn  (facts:graf-substrate facts)
  |=  fact=*
  ((soft ascii-corpus-receipt) fact)
::
++  corpus-fragments
  |=  plots=(list plot)
  ^-  (list fragment-fact)
  %+  murn  plots
  |=  item=plot
  ((soft fragment-fact) fact.item)
::
++  corpus-state
  |=  [facts=store:graf-substrate plots=(list plot)]
  ^-  corpus-state-summary
  =/  sources=(list ascii-corpus-source)  (corpus-sources facts)
  =/  fragments=(list fragment-fact)  (corpus-fragments plots)
  =/  occurrences=@ud
    =|  total=@ud
    |-
    ?~  fragments  total
    $(fragments t.fragments, total (add total (lent occurrences.i.fragments)))
  [(lent sources) (lent fragments) occurrences (corpus-receipts facts)]
::
++  find-corpus-source
  |=  [facts=store:graf-substrate source=@t]
  ^-  (unit ascii-corpus-source)
  =/  sources=(list ascii-corpus-source)  (corpus-sources facts)
  |-
  ?~  sources  ~
  ?:  =(source.i.sources source)  `i.sources
  $(sources t.sources)
::
++  overlaps
  |=  [a=@ud b=@ud]
  ^-  ?
  |((in-subtree a b) (in-subtree b a))
::
++  axis-free
  |=  [axis=@ud territories=(map @t territory)]
  ^-  ?
  !(lien ~(val by territories) |=(held=territory (overlaps axis axis.held)))
::
++  allocate-axis
  |=  territories=(map @t territory)
  ^-  (unit @ud)
  =/  frontier=@ud  58
  =/  tries=@ud  0
  |-
  ?:  =(tries 512)  ~
  =/  candidate=@ud  (mul 2 frontier)
  ?:  (axis-free candidate territories)  `candidate
  $(frontier +(candidate), tries +(tries))
::
::  A RETRACTION IS A FACT.  Un-engraving moves a tier cursor, which the
::  immutability ruling allows -- but the floor must remember it happened,
::  or "what was canon at time T" is unrecoverable (measured 2026-09-13:
::  %decanonize left only revision+1 and an overwritable last-result).
::  `now` is part of the point, so each retraction is its own fact and a
::  replay of the same act at the same instant stays idempotent.
++  retraction-fact
  |=  [tier=tier:graf-relations who=app:graf-relations r=rel:graf-relations ctx=context]
  ^-  *
  [%graf-retraction-v1 tier who r src.ctx now.ctx]
::
++  init
  ^-  state
  =/  st  *state
  st(territories (malt organ-seed), writer-links writer-links-seed)
::
++  prepare
  |=  [our=@p st=state]
  ^-  effect
  =/  normalized  (normalize-state st)
  =/  backfilled  (backfill:gts territories.normalized organ-seed)
  =/  started  (start-links our writer-links.normalized)
  [normalized(territories backfilled, writer-links links.started) cards.started]
::
++  apply
  |=  [st=state act=graf-core-action:graf-sur ctx=context]
  ^-  effect
  ?.  ?|  =(our.ctx src.ctx)
          =(our.ctx (^sein:title src.ctx))
          (~(has in attached.st) src.ctx)
      ==
    [st ~]
  ?:  ?=(%allow-ship -.act)
    ?.  =(our.ctx src.ctx)  [st ~]
    [st(attached (~(put in attached.st) who.act)) ~]
  ?:  ?=(%disallow-ship -.act)
    ?.  =(our.ctx src.ctx)  [st ~]
    [st(attached (~(del in attached.st) who.act)) ~]
  =/  foreign-app=@tas  (scot %p src.ctx)
  ?-  -.act
    %light
      =/  repair=(unit overlap-repair-payload)
        ((soft overlap-repair-payload) fact.act)
      ?^  repair
        ?.  =(our.ctx src.ctx)  [st ~]
        ?.  =(1 schema.u.repair)  [st ~]
        =/  fixed=(unit overlap-repair-result)
          (repair-overlaps territories.st plots.st targets.u.repair)
        ?~  fixed  [st ~]
        =/  next-facts=store:graf-substrate
          (light:graf-substrate facts.st receipt.u.fixed)
        :*  st(facts next-facts, territories territories.u.fixed, plots plots.u.fixed)
            ~[[%give %fact ~[/updates] %noun !>(receipt.u.fixed)]]
        ==
      =/  corpus=(unit ascii-corpus-payload)
        ((soft ascii-corpus-payload) fact.act)
      ?~  corpus
        [st(facts (light:graf-substrate facts.st fact.act)) ~[[%give %fact ~[/updates] %noun !>(fact.act)]]]
      ?.  =(our.ctx src.ctx)  [st ~]
      ?.  =(1 schema.u.corpus)  [st ~]
      =/  built=corpus-materialization
        (materialize-corpus facts.st plots.st chunks.u.corpus)
      :*  st(facts facts.built, plots plots.built)
          ~[[%give %fact ~[/updates] %noun !>(receipt.built)]]
      ==
    %note
      [st(tiers (note:graf-relations tiers.st ?:(=(our.ctx src.ctx) app.act foreign-app) r.act)) ~]
    %unnote
      =/  who=app:graf-relations  ?:(=(our.ctx src.ctx) app.act foreign-app)
      =/  fact=*  (retraction-fact %private who r.act ctx)
      :*  st(facts (light:graf-substrate facts.st fact), tiers (unnote:graf-relations tiers.st who r.act))
          ~[[%give %fact ~[/updates] %noun !>(fact)]]
      ==
    %publish
      [st(tiers (publish:graf-relations tiers.st ?:(=(our.ctx src.ctx) app.act foreign-app) r.act)) ~]
    %unpublish
      =/  who=app:graf-relations  ?:(=(our.ctx src.ctx) app.act foreign-app)
      =/  fact=*  (retraction-fact %published who r.act ctx)
      :*  st(facts (light:graf-substrate facts.st fact), tiers (unpublish:graf-relations tiers.st who r.act))
          ~[[%give %fact ~[/updates] %noun !>(fact)]]
      ==
    ::  the retraction.  Same gate, same governor -- and now the same
    ::  RECORD: the retraction is lit on the floor before the engraving
    ::  is undone, so what was canon at any moment stays reconstructible.
    ::  The guard mirrors %propose-canon; +authorize already refuses an
    ::  unapproved retraction, this keeps +apply honest on its own.
    %decanonize
      ?.  canon-approved.ctx  [st ~]
      =/  gate=gate:graf-relations  |=(rel:graf-relations %.y)
      =/  fact=*  (retraction-fact %canon app.act r.act ctx)
      :*  st(facts (light:graf-substrate facts.st fact), tiers (decanonize:graf-relations tiers.st gate r.act))
          ~[[%give %fact ~[/updates] %noun !>(fact)]]
      ==
    ::  THE BAKE.  Operator/agent-triggered, never automatic: it is
    ::  ~38s at 2.9 MB of key material, and a write path that silently
    ::  paid that would be a trap for frag and warp.
    %rebake-recall
      =/  fs=(set *)  (~(gas in *(set *)) (facts:graf-substrate facts.st))
      =/  ix  (build:graf-recall fs)
      [st(recall-index `[ix (count:graf-substrate facts.st) now.ctx]) ~]
    ::  Separate component bake: only the six recognized attested evidence
    ::  shapes enter it, and no scalar fact is ever materialized.
    %rebake-weight-evidence
      =/  raw=index:wei  (build:wei (attested-rows st))
      =/  ix=component-jam-index  (close-component-index raw)
      [st(component-index `[ix ~(wyt by attests.st) now.ctx]) ~]
    %propose-canon
      ?.  canon-approved.ctx  [st ~]
      =/  gate=gate:graf-relations  |=(rel:graf-relations %.y)
      [st(tiers (canonize:graf-relations tiers.st gate r.act)) ~]
    %set-governor
      ?.  =(our.ctx src.ctx)  [st ~]
      [st(governor `app.act) ~]
    %attest
      =.  attests.st  (~(put ju attests.st) fact.act src.ctx)
      =.  facts.st  (light:graf-substrate facts.st fact.act)
      [st(tiers (publish:graf-relations tiers.st foreign-app [fact.act %attested-by (scot %p src.ctx)])) ~]
    %contradict
      =.  contras.st  (~(put ju contras.st) fact.act src.ctx)
      [st(tiers (publish:graf-relations tiers.st foreign-app [fact.act %contradicted-by (scot %p src.ctx)])) ~]
    %bok-bake
      ?.  =(our.ctx src.ctx)  [st ~]
      =/  chunks=(list [chunk-in:bok @t])  (bok-chunks facts.st)
      =/  inputs=(list chunk-in:bok)
        (turn chunks |=([chunk=chunk-in:bok @t] chunk))
      =/  index=bok:bok  (build:bok inputs (malt anchors.act))
      [st(grounding `index) ~]
    %grant-territory
      ?.  =(our.ctx src.ctx)  [st ~]
      =/  current  (~(get by territories.st) app.act)
      ?~  current
        ((slog leaf+"graf: manual territory grant refused (allocator owns new roots) {<app.act>}" ~) [st ~])
      ?.  =(axis.act axis.u.current)
        ((slog leaf+"graf: manual territory move refused {<app.act>}" ~) [st ~])
      [st(territories (~(put by territories.st) app.act u.current(writable writable.act, active %.y))) ~]
    %grant-auto
      ?.  =(our.ctx src.ctx)  [st ~]
      =/  current  (~(get by territories.st) app.act)
      ?^  current
        ((slog leaf+"graf: auto grant refused (app already reserved) {<app.act>}" ~) [st ~])
      =/  axis  (allocate-axis territories.st)
      ?~  axis  ((slog leaf+"graf: auto allocator exhausted" ~) [st ~])
      =/  fact=allocation-fact
        [%territory-allocation app.act u.axis writable.act]
      :*  st(territories (~(put by territories.st) app.act [u.axis writable.act %.y]), facts (light:graf-substrate facts.st fact))
          ~[[%give %fact ~[/updates] %noun !>(fact)]]
      ==
    %revoke-territory
      ?.  =(our.ctx src.ctx)  [st ~]
      =/  current  (~(get by territories.st) app.act)
      ?~  current  [st ~]
      [st(territories (~(put by territories.st) app.act u.current(active %.n))) ~]
    %plant
      ?:  &(=(our.ctx src.ctx) (structural-writer app.act))
        ((slog leaf+"graf: plant refused (claimed structural identity) {<app.act>}" ~) [st ~])
      =/  who=@t  ?:(=(our.ctx src.ctx) app.act foreign-app)
      =/  current  (~(get by territories.st) who)
      ?~  current  ((slog leaf+"graf: plant refused (no grant) {<who>}" ~) [st ~])
      ?.  active.u.current  ((slog leaf+"graf: plant refused (revoked) {<who>}" ~) [st ~])
      ?.  writable.u.current  ((slog leaf+"graf: plant refused (read-only) {<who>}" ~) [st ~])
      ?.  (in-subtree axis.u.current axis.act)
        ((slog leaf+"graf: plant refused (out-of-territory) {<who>} {<axis.act>}" ~) [st ~])
      ?:  %+  lien  plots.st
          |=  existing=plot
          ?&  =(app.existing who)
              =(axis.existing axis.act)
              =(fact.existing fact.act)
          ==
        [st ~]
      =.  facts.st  (light:graf-substrate facts.st fact.act)
      [st(plots [[who axis.act fact.act] plots.st]) ~]
  ==
::
++  peek
  |=  [st=state pax=path our=@p]
  ^-  (unit (unit cage))
  ?+  pax  ~
    [%x %facts ~]      ``noun+!>((facts:graf-substrate facts.st))
    [%x %attested ~]   ``noun+!>(~(tap by attests.st))
    [%x %contested ~]  ``noun+!>(~(tap by contras.st))
    [%x %advisory ~]
      =/  advisory=(list *)
        %+  murn  ~(tap by attests.st)
        |=  [fact=* ships=(set @p)]
        ^-  (unit *)
        ?:  =(~ ships)  ~
        ?.  =(~ (~(get ju contras.st) fact))  ~
        `fact
      ``noun+!>(advisory)
    [%x %canon ~]      ``noun+!>(canon.tiers.st)
    [%x %published ~]  ``noun+!>((all-published:graf-relations tiers.st))
    [%x %governor ~]   ``noun+!>(governor.st)
    [%x %attached ~]   ``noun+!>(attached.st)
    [%x %health ~]
      ``noun+!>([%graf-health up=%.y facts=(count:graf-substrate facts.st) canon=`@ud`~(wyt in canon.tiers.st) territories=`@ud`~(wyt by territories.st) plots=`@ud`(lent plots.st)])
    ::  WHAT ARE THESE FACTS?  A census by head tag, read-only.
    ::
    ::  /x/health reports a COUNT and nothing about composition, and
    ::  by-kind cannot answer it either: it matches [kind any any], so it
    ::  only ever sees facts whose head is an ATOM.  A graf-seat-write is
    ::  headed by its HANDLE -- a cell -- so whole families are invisible
    ::  to it, and a by-kind census would look complete while missing
    ::  them silently.
    ::
    ::  So this buckets on the shape actually present:
    ::    atom head          -> that tag        (e.g. %goal)
    ::    cell head, atom in it -> that tag     (handle-headed: %seat-write)
    ::    anything else      -> %opaque
    ::
    ::  The counts SUM to /x/health's facts, which is the checksum: if
    ::  they do not, this arm is missing a shape and says so by arithmetic
    ::  rather than by looking right.
    [%x %fact-census ~]
      =/  all=(list *)  (facts:graf-substrate facts.st)
      =/  tally=(map @tas @ud)
        %+  roll  all
        |=  [f=* acc=(map @tas @ud)]
        =/  tag=@tas
          ?@  f  %atom-fact
          ?@  -.f  `@tas`-.f
          ?@  -.-.f  `@tas`-.-.f
          %opaque
        (~(put by acc) tag +((~(gut by acc) tag 0)))
      ``noun+!>([%graf-fact-census total=(lent all) kinds=~(tap by tally)])
    [%x %nock %subject ~]
      ``noun+!>((build-subject plots.st))
    [%x %nock %summary ~]
      ``noun+!>((summarize-subject plots.st))
    [%x %nock %conflicts ~]
      ``noun+!>((subject-conflicts plots.st))
    [%x %nock %territory-conflicts ~]
      ``noun+!>((territory-conflicts territories.st))
    [%x %nock %layout ~]
      ``noun+!>(layout-summary:gal)
    [%x %nock %address @ ~]
      =/  text=@t  ;;(@t (cue (slav %uw i.t.t.t.pax)))
      ``noun+!>((address-for-text:gal text))
    [%x %nock %fragments @ @ ~]
      =/  source=@t  ;;(@t (cue (slav %uw i.t.t.t.pax)))
      =/  text=@t  ;;(@t (cue (slav %uw i.t.t.t.t.pax)))
      =/  index=fragment-index:gal
        (index-text:gal *fragment-index:gal source text)
      ``noun+!>(~(tap by index))
    [%x %nock %corpus %summary ~]
      ``noun+!>((corpus-state facts.st plots.st))
    [%x %nock %corpus %receipts ~]
      ``noun+!>((corpus-receipts facts.st))
    [%x %nock %corpus %source @ ~]
      =/  source=@t  ;;(@t (cue (slav %uw i.t.t.t.t.pax)))
      ``noun+!>((find-corpus-source facts.st source))
    [%x %nock %axis @ ~]
      =/  axis=(unit @ud)  (slaw %ud i.t.t.t.pax)
      ?~  axis  [~ ~]
      ``noun+!>((read-axis plots.st u.axis))
    [%x %count @ ~]
      =/  kind=@tas  i.t.t.pax
      =/  all=(list *)  (facts:graf-substrate facts.st)
      =/  pattern=pat:graf-search
        (tup:graf-search ~[(is:graf-search kind) any:graf-search any:graf-search])
      ``noun+!>(`@ud`(lent (skim all |=(fact=* (match:graf-search pattern fact)))))
    [%x %admits @ ~]
      =/  who=@p  (slav %p i.t.t.pax)
      ``noun+!>(?|(=(our who) =(our (^sein:title who)) (~(has in attached.st) who)))
    ::  the app-identity oracle: is this exact writer name admitted?
    [%x %writer @ ~]
      =/  app=@tas  i.t.t.pax
      ``noun+!>((writer-admitted st app))
    [%x %slot @ ~]     ``noun+!>((slot-of:graf-relations tiers.st i.t.t.pax))
    [%x %view @ ~]     ``noun+!>((view:graf-relations tiers.st i.t.t.pax))
    [%x %ground @ ~]
      ?~  grounding.st  ``noun+!>(~)
      =/  task=@t  i.t.t.pax
      =/  vocab=(list @tas)  ~(tap in ~(key by aidx.u.grounding.st))
      ``noun+!>(`(ground:bok u.grounding.st task vocab))
    [%x %bok-stats ~]
      =/  chunks=@ud  (lent (bok-chunks facts.st))
      =/  ops=@ud  ?~(grounding.st 0 ~(wyt by aidx.u.grounding.st))
      ``noun+!>([baked=?=(^ grounding.st) chunks=chunks ops=ops])
    [%x %bok-text @ ~]
      =/  index=@ud  (slav %ud i.t.t.pax)
      =/  chunks=(list [chunk-in:bok text=@t])  (bok-chunks facts.st)
      ?:  (gte index (lent chunks))  ``noun+!>(~)
      ``noun+!>(`text:(snag index chunks))
    [%x %by-kind @ ~]
      =/  kind=@tas  i.t.t.pax
      =/  all=(list *)  (facts:graf-substrate facts.st)
      =/  pattern=pat:graf-search
        (tup:graf-search ~[(is:graf-search kind) any:graf-search any:graf-search])
      ``noun+!>((skim all |=(fact=* (match:graf-search pattern fact))))
    [%x %by-kinds @ ~]
      =/  kinds=(list @tas)
        =/  chars=tape  (weld (trip i.t.t.pax) ",")
        =|  piece=tape
        =|  out=(list @tas)
        |-  ^-  (list @tas)
        ?~  chars  (flop out)
        ?.  ?|(=('_' i.chars) =(',' i.chars))
          $(chars t.chars, piece [i.chars piece])
        ?~  piece  $(chars t.chars)
        =/  kind=(unit @tas)  (slaw %tas (crip (flop piece)))
        ?~  kind  $(chars t.chars, piece ~)
        $(chars t.chars, piece ~, out [u.kind out])
      ?~  kinds  ``noun+!>(~)
      =/  wanted=(set @tas)  (~(gas in *(set @tas)) kinds)
      =/  grouped=(map @tas (list *))
        %+  roll  (facts:graf-substrate facts.st)
        |=  [fact=* acc=(map @tas (list *))]
        ^-  (map @tas (list *))
        ?@  fact  acc
        ?^  -.fact  acc
        ::  Match the same [kind any any] shape as by-kind.
        ?@  +.fact  acc
        =/  kind=@tas  `@tas`-.fact
        ?.  (~(has in wanted) kind)  acc
        (~(put by acc) kind [fact (~(gut by acc) kind ~)])
      =/  rows=(list [kind=@tas facts=(list *)])
        %+  turn  kinds
        |=  kind=@tas
        [kind (flop (~(gut by grouped) kind ~))]
      ``noun+!>(rows)
    ::  Deterministic bounded page in the exact legacy set order.  Invalid
    ::  limits fail closed; authority readers must consume through more=%.n.
    [%x %by-kind-page @ @ @ ~]
      =/  kind=@tas  i.t.t.pax
      =/  offset=(unit @ud)  (slaw %ud i.t.t.t.pax)
      ?~  offset  [~ ~]
      =/  limit=(unit @ud)  (slaw %ud i.t.t.t.t.pax)
      ?~  limit  [~ ~]
      ?.  (valid-limit:gew u.limit)  [~ ~]
      ``noun+!>((page:gew facts.st kind u.offset u.limit))
    ::  Exact membership avoids materializing and filtering the full fact set.
    [%x %contains @ ~]
      =/  fact=*  (cue (slav %uw i.t.t.pax))
      ``noun+!>((lit:graf-substrate facts.st fact))
    [%x %by-id @ @ ~]
      =/  kind=@tas  i.t.t.pax
      =/  id=@t  i.t.t.t.pax
      =/  all=(list *)  (facts:graf-substrate facts.st)
      =/  pattern=pat:graf-search
        (tup:graf-search ~[(is:graf-search kind) (is:graf-search id) any:graf-search])
      ``noun+!>((skim all |=(fact=* (match:graf-search pattern fact))))
    ::  cached: scan only when the bake covers the exact current fact floor.
    ::  Missing or stale caches use the old correct bake-per-call path.
    [%x %recall @ ~]
      =/  query=@t  i.t.t.pax
      ?^  recall-index.st
        ?:  (recall-cache-valid st)
          ``noun+!>(~(tap in (recall:graf-recall ix.u.recall-index.st query)))
        =/  facts=(set *)  (~(gas in *(set *)) (facts:graf-substrate facts.st))
        ``noun+!>(~(tap in (fire:graf-recall facts query)))
      =/  facts=(set *)  (~(gas in *(set *)) (facts:graf-substrate facts.st))
      ``noun+!>(~(tap in (fire:graf-recall facts query)))
    ::  the index explains itself: a stale index that cannot be seen to
    ::  be stale is worse than none.
    [%x %recall-status ~]
      ?~  recall-index.st
        ``noun+!>([%recall-index baked=%.n n=0 behind=(count:graf-substrate facts.st) at=`@da`*@da])
      =/  now-n=@ud  (count:graf-substrate facts.st)
      :^  ~  ~  %noun
      !>  :*  %recall-index
              baked==(now-n n.u.recall-index.st)
              n=n.u.recall-index.st
              behind=?:((gth now-n n.u.recall-index.st) (sub now-n n.u.recall-index.st) 0)
              at=at.u.recall-index.st
          ==
    ::  Viki's bounded read.  Unlike /x/recall this never pays the slow
    ::  rebuild path: stale or missing indexes return an explicit gap.
    [%x %evidence @ @ ~]
      =/  requested=(unit @ud)  (slaw %ud i.t.t.pax)
      ?~  requested  [~ ~]
      =/  query=@t  i.t.t.t.pax
      ``noun+!>((evidence-packet st query u.requested))
    [%x %weight-evidence @ @ @ ~]
      =/  kind=@tas  i.t.t.pax
      =/  layer=(unit @ud)  (slaw %ud i.t.t.t.pax)
      =/  index=(unit @ud)  (slaw %ud i.t.t.t.t.pax)
      ?~  layer  [~ ~]
      ?~  index  [~ ~]
      ``noun+!>((component-evidence-read st [kind u.layer u.index]))
    [%x %weight-evidence-status ~]
      =/  now-n=@ud  ~(wyt by attests.st)
      ?~  component-index.st
        ``noun+!>([%weight-evidence-index baked=%.n n=0 behind=now-n at=`@da`*@da])
      ``noun+!>([%weight-evidence-index baked=(component-cache-valid st) n=n.u.component-index.st behind=?:((gth now-n n.u.component-index.st) (sub now-n n.u.component-index.st) 0) at=at.u.component-index.st])
    [%x %weight %index @ ~]
      =/  index=(unit @ud)  (slaw %ud i.t.t.t.pax)
      ?~  index  [~ ~]
      =/  packet=(unit packet:wis)
        (weight-interpretation-for-index st u.index)
      ?~  packet  [~ ~]
      ``noun+!>(u.packet)
    [%x %weight %inquiries %index @ ~]
      =/  index=(unit @ud)  (slaw %ud i.t.t.t.t.pax)
      ?~  index  [~ ~]
      ``noun+!>((weight-inquiry-history-for-index st u.index))
    [%x %reach @ @ @ ~]
      =/  kind=@tas     i.t.t.pax
      =/  start=@t      i.t.t.t.pax
      =/  depth=@ud     (slav %ud i.t.t.t.t.pax)
      =/  relations=(set rel:graf-relations)
        (~(uni in canon.tiers.st) (all-published:graf-relations tiers.st))
      =/  indexed=jugs:graf-traverse  (index:graf-traverse relations)
      ``noun+!>(~(tap in (reach:graf-traverse indexed start kind depth)))
    [%x %territories ~]  ``noun+!>(~(tap by territories.st))
    [%x %writer-links ~]  ``noun+!>(~(tap by writer-links.st))
    [%x %writer-source @ ~]  ``noun+!>((writer-source-for i.t.t.pax))
    [%x %territory @ ~]  ``noun+!>((~(get by territories.st) `@t`i.t.t.pax))
    [%x %plots @ ~]
      =/  app=@t  `@t`i.t.t.pax
      ``noun+!>((skim plots.st |=(item=plot =(app.item app))))
    ::  Exact territory membership returns one loobean, never the plot list.
    [%x %planted @ @ @ ~]
      =/  app=@tas  i.t.t.pax
      =/  axis=@ud  (slav %ud i.t.t.t.pax)
      =/  fact=*  (cue (slav %uw i.t.t.t.t.pax))
      =/  present=?
        %+  lien  plots.st
        |=  item=plot
        ?&  =(app.item app)
            =(axis.item axis)
            =(fact.item fact)
        ==
      ``noun+!>(present)
    [%x %at-axis @ ~]
      =/  axis=@ud  (slav %ud i.t.t.pax)
      ``noun+!>((skim plots.st |=(item=plot (in-subtree axis axis.item))))
  ==
--
