::  A provider supplies text only. Exact sources and native checks stay owned.
/-  pc=pataphor-project-coding, msc=glass-moon-coordinator,
    mse=glass-moon-executor, mb=model-bridge
/+  authority=pataphor-project-authority, coding=pataphor-project-coding,
    save=cantrip-project-save, executor=glass-moon-executor,
    coordinator=glass-moon-coordinator, route=viki-route,
    codex=codex-provider-receipt, correction=pataphor-project-correction,
    native=codex-inference
|%
+$  proposal
  [record=record:msc provider=provider-result:mse edits=(list edit:save)]
+$  failure
  [record=record:msc provider=provider-result:mse reason=@tas]
+$  dispatch-failure
  [record=record:msc reason=%model-dispatch-refused]
++  prompt
  |=  a=admission:authority
  ^-  @t
  %+  rap  3
  :~  text.request.a
      ?~  prior.a  ''
      ?:((failed:correction u.prior.a) (guidance:correction u.prior.a) '')
      '\0aReturn ONLY JSON [["/lib/pataphor-workspace-ui/hoon","full source"],["/lib/pataphor-noltbook/hoon","full source"]]. Preserve welcome as @t and reply [eid=@uv status=@t body=@t] -> @t. No tools or writes. Sources:\0a'
      %+  rap  3
      %+  turn  ~(tap by sources.manifest.a)
      |=  [pax=path source=@t]
      (rap 3 ~[(crip (spud pax)) '\0a' source '\0a'])
  ==
++  input
  |=  a=admission:authority
  ^-  (each input:msc @tas)
  =/  text=@t  (prompt a)
  ?.  (lte (met 3 text) 8.192)  [%| %prompt-over-limit]
  =/  selected  route.evidence.a
  =/  task=task-request-v1:mse
    [%multiplayer-task-request-v1 (scot %ux nonce.request.a) text [%multiplayer-task-authority-v1 ~['.'] ~ ~[%read %inspect] %.n ~m5 16.384] ~[%candidate-source %moon-provider-result-v2 %provider-envelope-64k-v1]]
  =/  task=task-request:mse
    (select-task:executor task (spec-for:route selected) (commitment:route selected))
  =/  i=input:msc
    [moon.seat-session.selected `@t`workspace.seat-session.selected session-id.selected task ~m5]
  ?:((input-valid:coordinator i) [%& i] [%| %task-invalid])
++  edits
  |=  [m=manifest:pc text=@t]
  ^-  (unit (list edit:save))
  ?:  (gth (met 3 text) 16.384)  ~
  =/  parsed  (de:json:html text)
  ?~  parsed  ~
  ?.  ?=([%a *] u.parsed)  ~
  =/  rows=(list json)  p.u.parsed
  ?.  =(2 (lent rows))  ~
  =/  remaining=(list path)  targets:coding
  =/  out=(list edit:save)  ~
  |-  ^-  (unit (list edit:save))
  ?~  rows
    =/  ordered=(list edit:save)  (flop out)
    ?:((edits-valid:coding m ordered) `ordered ~)
  ?~  remaining  ~
  ?.  ?=([%a [[%s *] [%s *] ~]] i.rows)  ~
  =/  pax=path  i.remaining
  ?.  =((crip (spud pax)) p.i.p.i.rows)  ~
  =/  source=@t  p.i.t.p.i.rows
  =/  prior  (~(get by files.body.snapshot.working.basis.m) pax)
  ?~  prior  ~
  =/  e=edit:save  [[%modify pax prior ``@ux`(page-to-lobe:clay [%hoon source])] source]
  $(rows t.rows, remaining t.remaining, out [e out])
++  linked
  ::  Caller must authenticate the coordinator watch. Mutable delivery ACKs
  ::  may settle later; original input/request and terminal remain exact.
  |=  [our=@p at=@da a=admission:authority i=input:msc r=record:msc]
  ^-  (each ~ @tas)
  ?.  (valid:authority our a)  [%| %admission-invalid]
  ?.  =([%& i] (input a))  [%| %input-mismatch]
  ?.  =(i input.r)  [%| %coordinator-input-mismatch]
  =/  original=record:msc  (make-record:coordinator our i sent-at.body.request.r)
  ?.  ?&  =(key.r key.original)  =(payload-digest.r payload-digest.original)
          =(request.r request.original)  =(deadline.r deadline.original)
          (lte at.a sent-at.body.request.r)  (lte sent-at.body.request.r at)
      ==  [%| %coordinator-request-mismatch]
  ?~  terminal.r  [%| %provider-pending]
  ?.  ?=(%completed -.u.terminal.r)  [%| %provider-outcome-uncertain]
  =/  response  response.u.terminal.r
  ?.  ?&  (lte sent-at.body.request.r sent-at.body.response)
          (lte sent-at.body.response at)  (lth sent-at.body.response deadline.r)
      ==  [%| %provider-time-invalid]
  [%& ~]
++  returned
  |=  [our=@p at=@da a=admission:authority i=input:msc r=record:msc]
  ^-  (each provider-result:mse @tas)
  =/  checked  (linked our at a i r)
  ?:  ?=(%| -.checked)  [%| p.checked]
  ?>  ?=(^ terminal.r)
  ?>  ?=(%completed -.u.terminal.r)
  =/  response  response.u.terminal.r
  =/  returned  (decode-provider-result:executor request.r response)
  ?~  returned  [%| %provider-record-invalid]
  [%& u.returned]
++  dispatch-refusal
  ::  This is the executor's failed initial Gall poke, not model output.
  ::  A caller must authenticate the coordinator watch before retaining it.
  |=  [our=@p at=@da a=admission:authority i=input:msc r=record:msc]
  ^-  (each dispatch-failure @tas)
  =/  checked  (linked our at a i r)
  ?:  ?=(%| -.checked)  [%| p.checked]
  ?>  ?=(^ terminal.r)
  ?>  ?=(%completed -.u.terminal.r)
  =/  response  response.u.terminal.r
  ?.  &((response-matches:coordinator our r response) =(response (make-response:executor recipient.i request.r 'REMOTE-COMMAND-ERROR: local model poke refused' sent-at.body.response)))
    [%| %dispatch-refusal-unconfirmed]
  [%& [r %model-dispatch-refused]]
++  dispatch-failure-valid
  |=  [our=@p a=admission:authority i=input:msc f=dispatch-failure]
  ^-  ?
  ?~  terminal.record.f  %.n
  ?.  ?=(%completed -.u.terminal.record.f)  %.n
  =/  at=@da  sent-at.body.response.u.terminal.record.f
  =([%& f] (dispatch-refusal our at a i record.f))
++  capture
  |=  [our=@p at=@da a=admission:authority i=input:msc r=record:msc]
  ^-  (each proposal @tas)
  =/  checked  (returned our at a i r)
  ?:  ?=(%| -.checked)  [%| p.checked]
  =/  p=provider-result:mse  p.checked
  ?.  ?=(%result -.terminal.p)  [%| %provider-not-successful]
  =/  checked  (inspect:codex spec.p request.p result.terminal.p)
  ?:  ?=(%| -.checked)  [%| p.checked]
  =/  sources  (edits manifest.a content.result.terminal.p)
  ?~  sources  [%| %two-file-source-invalid]
  [%& [r p u.sources]]
++  refusal
  ::  A known failed terminal releases only after its complete evidence is
  ::  owner-retained. Timeouts, cancellation and malformed receipts do not.
  |=  [our=@p at=@da a=admission:authority i=input:msc r=record:msc]
  ^-  (each failure @tas)
  =/  checked  (returned our at a i r)
  ?:  ?=(%| -.checked)  [%| p.checked]
  =/  p=provider-result:mse  p.checked
  ?:  ?=(%error -.terminal.p)
    ?.  ?|  =(%process code.error.terminal.p)
            =(%not-ready code.error.terminal.p)
            =(%invalid-request code.error.terminal.p)
            ::  Only this native transport emits protocol after HTTP has
            ::  finished. CLI protocol errors do not establish completion.
            &((spec-valid:native spec.p) =(%protocol code.error.terminal.p) !retryable.error.terminal.p)
        ==  [%| %provider-outcome-uncertain]
    [%& [r p code.error.terminal.p]]
  ?.  ?=(%result -.terminal.p)  [%| %provider-outcome-uncertain]
  =/  receipt  (inspect:codex spec.p request.p result.terminal.p)
  ?:  ?=(%| -.receipt)  [%| p.receipt]
  ?^  (edits manifest.a content.result.terminal.p)  [%| %valid-proposal-not-refused]
  [%& [r p %two-file-source-invalid]]
++  failure-valid
  |=  [our=@p a=admission:authority i=input:msc f=failure]
  ^-  ?
  ?~  terminal.record.f  %.n
  ?.  ?=(%completed -.u.terminal.record.f)  %.n
  =/  at=@da  sent-at.body.response.u.terminal.record.f
  =([%& f] (refusal our at a i record.f))
++  key
  |=  [a=admission:authority i=input:msc p=proposal]
  ^-  @ux
  (hash:coding [%pataphor-project-proposal-v1 a i request.record.p provider.p edits.p])
++  valid
  |=  [our=@p a=admission:authority i=input:msc p=proposal]
  ^-  ?
  ?~  terminal.record.p  %.n
  ?.  ?=(%completed -.u.terminal.record.p)  %.n
  =/  at=@da  sent-at.body.response.u.terminal.record.p
  =([%& p] (capture our at a i record.p))
--
