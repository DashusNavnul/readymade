::  /lib/multiplayer-changeset
::
::  Pure snapshot, changeset, and receipt-chain exchange law.
::
/-  mc=multiplayer-changeset, mr=multiplayer-receipt, mw=multiplayer-work
/+  mrl=multiplayer-receipt, mwl=multiplayer-work
|%
++  snapshot-digest
  |=  body=snapshot-body:mc
  ^-  digest:mc
  `@ux`(shax (jam [%multiplayer-snapshot-v1 body]))
++  make-snapshot
  |=  body=snapshot-body:mc
  ^-  snapshot:mc
  [body (snapshot-digest body)]
++  snapshot-valid
  |=  item=snapshot:mc
  ^-  ?
  ?&  =(1 version.body.item)
      !=(0 project.body.item)
      !=(0 base-desk.body.item)
      !=(0 base-revision.body.item)
      =((snapshot-digest body.item) digest.item)
  ==
++  changeset-digest
  |=  body=changeset-body:mc
  ^-  digest:mc
  `@ux`(shax (jam [%multiplayer-changeset-v1 body]))
++  change-valid
  |=  [files=(map path digest:mc) item=change:mc]
  ^-  ?
  ?.  ?=(^ path.item)  %.n
  =/  base=(unit digest:mc)  (~(get by files) path.item)
  ?-  kind.item
    %add
      ?&  ?=(~ before.item)
          ?=(^ after.item)
          ?=(~ base)
      ==
    %modify
      ?&  ?=(^ before.item)
          ?=(^ after.item)
          ?=(^ base)
          =(u.base u.before.item)
          !=(u.before.item u.after.item)
      ==
    %delete
      ?&  ?=(^ before.item)
          ?=(~ after.item)
          ?=(^ base)
          =(u.base u.before.item)
      ==
  ==
++  changes-valid
  |=  [files=(map path digest:mc) changes=(list change:mc)]
  ^-  ?
  ?~  changes  &
  ?&  (change-valid files i.changes)
      $(changes t.changes)
  ==
++  changeset-valid
  |=  [sync=synchronized:mc item=changeset:mc]
  ^-  ?
  =/  grant=workspace-grant:mw  grant.sync
  =/  snapshot=snapshot:mc  snapshot.sync
  ?&  =(1 version.body.item)
      =(project.grant project.body.item)
      =(task.grant task.body.item)
      =(workspace.grant workspace.body.item)
      =(ship.grant actor.body.item)
      =(base-revision.grant base-revision.body.item)
      =(digest.snapshot snapshot-digest.body.item)
      ?=(^ changes.body.item)
      =((lent changes.body.item) (lent ~(tap in (silt `(list path)`(turn changes.body.item |=(change=change:mc path.change))))))
      (changes-valid files.body.snapshot changes.body.item)
      =((changeset-digest body.item) digest.item)
  ==
++  reject-sync
  |=  refusal=refusal:mc
  ^-  sync-result:mc
  [%| refusal]
++  synchronize
  |=  $:  grant=workspace-grant:mw
          snapshot=snapshot:mc
          recognized=(map @ud digest:mc)
          synchronized-at=@da
      ==
  ^-  sync-result:mc
  ?.  =((workspace-digest:mwl grant) digest.grant)
    (reject-sync [%grant-mismatch ~])
  ?.  (snapshot-valid snapshot)  (reject-sync [%invalid-snapshot ~])
  ?.  ?&  =(project.grant project.body.snapshot)
          =(base-revision.grant base-revision.body.snapshot)
      ==
    (reject-sync [%grant-mismatch ~])
  =/  known=(unit digest:mc)  (~(get by recognized) base-revision.body.snapshot)
  ?~  known  (reject-sync [%unknown-base base-revision.body.snapshot])
  ?.  =(u.known digest.snapshot)
    (reject-sync [%base-digest-mismatch u.known digest.snapshot])
  [%& [grant snapshot synchronized-at]]
++  stage
  |=  [sync=synchronized:mc changes=(list change:mc)]
  ^-  changeset-result:mc
  =/  grant=workspace-grant:mw  grant.sync
  =/  snapshot=snapshot:mc  snapshot.sync
  =/  body=changeset-body:mc
    :*  1  project.grant  task.grant  workspace.grant  ship.grant
        base-revision.grant  digest.snapshot  changes
    ==
  =/  item=changeset:mc  [body (changeset-digest body)]
  ?.  (changeset-valid sync item)  [%| [%invalid-changeset ~]]
  [%& item]
++  record
  |=  $:  chain=chain:mr
          sync=synchronized:mc
          changeset=changeset:mc
          action=exchange-action:mc
          actor=@p
          host-sequence=@ud
          source-sequence=@ud
          occurred-at=@da
      ==
  ^-  receipt-result:mc
  ?.  (changeset-valid sync changeset)  [%| [%invalid-changeset ~]]
  ?.  =(project.chain project.body.changeset)
    [%| [%wrong-project project.chain project.body.changeset]]
  =/  expected=@p
    ?-  action
      %offer  ship.grant.sync
      %pull   authority-host.chain
    ==
  ?.  =(expected actor)  [%| [%foreign-actor expected actor]]
  =/  kind=@tas  ?:(=(%offer action) %file-offer %file-pull)
  =/  source-actor=actor:mr  [actor ~ ~]
  =/  payload=exchange:mc  [1 action changeset occurred-at]
  =/  item=event:mr
    (make-live:mrl project.chain authority-host.chain host-sequence head.chain actor source-sequence kind source-actor payload occurred-at ~)
  =/  appended=result:mr  (append:mrl chain item occurred-at)
  ?-  -.appended
    %|  [%| [%receipt-refused p.appended]]
    %&  [%& p.appended]
  ==
--
