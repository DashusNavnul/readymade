::  Bounded native transport. No timers, automatic replay or permission grants.
/+  inv=readymade-project-invitations, executor=readymade-artifact-executor
|%
+$  card  card:agent:gall
+$  change  [journal=journal:inv cards=(list card) reason=@tas]
+$  saved  [%readymade-collab-app-v6 previous=packet:executor invitations=journal:inv]
++  route
  |=  [our=@p cmd=command:inv]
  ^-  path
  /action-receipts/(scot %ux project.action.cmd)/(scot %p our)
++  begin
  |=  [our=@p j=journal:inv cmd=command:inv]
  ^-  change
  =/  reserved  (reserve:inv j cmd)
  ?.  dispatch.reserved  [journal.reserved ~ reason.reserved]
  =/  wire=path  /collab/invitation/[request.cmd]
  [journal.reserved ~[[%pass wire %agent [authority.cmd %multiplayer-runtime] %watch (route our cmd)]] %watch-once]
++  receive
  |=  [b=bowl:gall j=journal:inv wire=wire sign=sign:agent:gall]
  ^-  change
  ?.  ?=([%collab ?(%invitation %invitation-send) @ ~] wire)  [j ~ %unrelated]
  =/  request=@t  i.t.t.wire
  =/  old  (~(get by j) request)
  ?~  old  [j ~ %missing]
  =/  cmd=command:inv  command.u.old
  ?.  =(authority.cmd src.b)  [j ~ %wrong-authority]
  ?:  =(%invitation-send i.t.wire)
    ?.  ?=([%poke-ack ^] sign)  [j ~ %ack-not-outcome]
    [(uncertain:inv j request) ~ %send-unconfirmed]
  ::  Gall's outgoing subscription binds this wire to the exact agent/path.
  =/  sub=(unit [acked=? path=path])  (~(get by wex.b) [wire authority.cmd %multiplayer-runtime])
  ?~  sub  [j ~ %unbound]
  ?.  =(path.u.sub (route our.b cmd))  [j ~ %wrong-route]
  ?:  ?|(?=([%watch-ack ^] sign) ?=([%kick *] sign))
    [(uncertain:inv j request) ~ %subscription-unconfirmed]
  ?.  ?=([%fact %noun *] sign)  [j ~ %not-receipt]
  =/  event  ((soft ,receipt-event:inv) q.q.cage.sign)
  ?~  event  [j ~ %invalid-receipt]
  ?.  =(q.q.cage.sign u.event)  [j ~ %invalid-receipt]
  ?:  ?=(%ready -.u.event)
    =/  started  (start:inv j request src.b)
    ?.  dispatch.started  [journal.started ~ reason.started]
    =/  send-wire=path  /collab/invitation-send/[request]
    [journal.started ~[[%pass send-wire %agent [authority.cmd %multiplayer-runtime] %poke %noun !>([%multiplayer-runtime-command-v1 action.cmd])]] %submit-once]
  =/  next  (settle:inv j request src.b value.u.event)
  ?:  =(next j)  [j ~ %retained]
  [next ~[[%pass wire %agent [authority.cmd %multiplayer-runtime] %leave ~]] %settled]
++  restore
  |=  [our=@p raw=*]
  ^-  (unit saved)
  =/  six  ((soft ,saved) raw)
  ?^  six
    =/  previous  (restore:executor our previous.u.six)
    =/  invitations  (restore:inv invitations.u.six)
    ?~  previous  ~
    ?~  invitations  ~
    ?.  &(=(raw u.six) =(previous.u.six u.previous) =(invitations.u.six u.invitations))  ~
    six
  =/  previous  (restore:executor our raw)
  ?~  previous  ~
  `[%readymade-collab-app-v6 u.previous ~]
--
