::  /lib/model-bridge-state.hoon
::
::  Pure state machine for the provider-neutral local-session bridge.
::  Gall owns persistence and Lick cards; this core owns admission, correlation,
::  deduplication, and fail-closed state transitions.
::
/-  mb=model-bridge
|%
+$  bridge-state-v0
  $:  %0
      port-open=?
      peer-protocol=(unit @tas)
      pending=(unit model-bridge-dispatch:mb)
      latest=(unit model-bridge-event:mb)
      settled=(list @t)
  ==
+$  bridge-state
  $:  %1
      port-open=?
      peer-protocol=(unit @tas)
      pending=(unit model-bridge-dispatch:mb)
      latest=(unit model-bridge-event:mb)
      latest-result=(unit model-bridge-result:mb)
      settled=(list @t)
  ==
::  ONE PORT PER SEAT.  The bridge used to hold one port, one peer protocol
::  and one pending dispatch, and the literal %pataphor-codex in every card.
::  A second seat waited behind the first for the whole of a turn -- measured
::  7s to 82s -- which is tolerable for two seats and disqualifying for nine.
::
::  Now each port is its own record, keyed by name.  Everything that was
::  per-bridge is per-port: open, protocol, pending.  The transition law is
::  UNCHANGED in what it checks; it is applied to the port the dispatch names
::  rather than to the bridge.  The spec already carried `port=@tas` in
::  %local-session; it was simply never read.
::
::  `latest`, `latest-result` and `settled` stay per-bridge.  They are the
::  audit and the dedup, and neither cares which port a turn went through.
+$  port
  $:  open=?
      protocol=(unit @tas)
      pending=(unit model-bridge-dispatch:mb)
  ==
+$  bridge-state-v2
  $:  %2
      ports=(map @tas port)
      latest=(unit model-bridge-event:mb)
      latest-result=(unit model-bridge-result:mb)
      settled=(list @t)
  ==
::  PUBLIC OBSERVABILITY MUST NOT BE A SECOND MODEL-OUTPUT CHANNEL.  Gall
::  peeks have no caller identity, so their nouns are safe for any reader by
::  construction: correlation and readiness survive; prompt, content, tool
::  JSON, provider metadata, errors and cancellation reasons do not.
+$  public-port
  [name=@tas open=? ready=? busy=?]
+$  public-event
  $%  [%ready protocol=@tas]
      [%accepted request-id=@t session-id=@t]
      [%result status=@tas request-id=@t session-id=@t]
      [%error request-id=@t session-id=@t code=model-bridge-error-code:mb retryable=?]
      [%cancelled request-id=@t session-id=@t]
  ==
+$  public-state
  $:  %model-bridge-public-state-v1
      ports=(list public-port)
      latest=(unit public-event)
      settled-count=@ud
  ==
::  the port every caller that predates seats dispatches to
++  default-port  `@tas`%pataphor-codex
++  empty-port  ^-(port [%.n ~ ~])
::
+$  transition-status
  $?  %accepted
      %acknowledged
      %settled
      %ready
      %not-ready
      %not-local
      %wrong-port
      %busy
      %duplicate
      %orphan
      %mismatch
      %invalid
  ==
+$  transition
  $:  status=transition-status
      state=bridge-state-v2
  ==
++  max-settled-keys  64
++  initial-state
  ^-  bridge-state-v2
  [%2 (~(put by *(map @tas port)) default-port empty-port) ~ ~ ~]
::
::  v0 -> v1 -> v2.  The one port a v1 bridge held becomes the default port's
::  record; nothing about it is lost.
++  upgrade-v0
  |=  old=bridge-state-v0
  ^-  bridge-state
  =/  latest-result=(unit model-bridge-result:mb)
    ?~  latest.old  ~
    ?.  ?=(%result -.u.latest.old)  ~
    `result.u.latest.old
  [%1 port-open.old peer-protocol.old pending.old latest.old latest-result settled.old]
++  upgrade-state
  |=  old=bridge-state
  ^-  bridge-state-v2
  :*  %2
      (~(put by *(map @tas port)) default-port [port-open.old peer-protocol.old pending.old])
      latest.old
      latest-result.old
      settled.old
  ==
::
++  ids-key
  |=  [request-id=@t session-id=@t]
  ^-  @t
  (cat 3 'model-bridge-request:' (cat 3 session-id (cat 3 ':' request-id)))
::
++  event-ids
  |=  event=model-bridge-event:mb
  ^-  (unit [request-id=@t session-id=@t])
  ?-  -.event
    %ready      ~
    %accepted   `[request-id.event session-id.event]
    %result     `[request-id.result.event session-id.result.event]
    %error      `[request-id.error.event session-id.error.event]
    %cancelled  `[request-id.cancel.event session-id.cancel.event]
  ==
::
++  settled
  |=  [key=@t state=bridge-state-v2]
  ^-  ?
  %+  lien  settled.state
  |=(known=@t =(key known))
::
++  remember
  |=  [key=@t state=bridge-state-v2]
  ^-  bridge-state-v2
  =/  keys=(list @t)  [key settled.state]
  state(settled (scag max-settled-keys keys))
::
::  +at: the named port, or an empty one.  A port nobody has touched is
::  closed with no peer and nothing pending -- which is the truth.
++  at
  |=  [state=bridge-state-v2 name=@tas]
  ^-  port
  (~(gut by ports.state) name empty-port)
::
++  busy
  |=  [state=bridge-state-v2 name=@tas]
  ^-  ?
  =/  p=port  (at state name)
  ?=(^ pending.p)
::
++  redact-event
  |=  event=model-bridge-event:mb
  ^-  public-event
  ?-  -.event
    %ready      [%ready protocol.event]
    %accepted   [%accepted request-id.event session-id.event]
    %result
      [%result status.result.event request-id.result.event session-id.result.event]
    %error
      [%error request-id.error.event session-id.error.event code.error.event retryable.error.event]
    %cancelled
      [%cancelled request-id.cancel.event session-id.cancel.event]
  ==
::
++  redact-latest
  |=  state=bridge-state-v2
  ^-  (unit public-event)
  ?~(latest.state ~ `(redact-event u.latest.state))
::
++  redact-latest-result
  |=  state=bridge-state-v2
  ^-  (unit public-event)
  ?~(latest-result.state ~ `(redact-event [%result u.latest-result.state]))
::
++  redact-state
  |=  state=bridge-state-v2
  ^-  public-state
  =/  safe-ports=(list public-port)
    %+  turn  ~(tap by ports.state)
    |=  [name=@tas p=port]
    [name open.p (ready state name) ?=(^ pending.p)]
  [%model-bridge-public-state-v1 safe-ports (redact-latest state) (lent settled.state)]
::
++  put-port
  |=  [state=bridge-state-v2 name=@tas p=port]
  ^-  bridge-state-v2
  state(ports (~(put by ports.state) name p))
::
++  spin
  |=  [state=bridge-state-v2 name=@tas]
  ^-  bridge-state-v2
  =/  p=port  (at state name)
  (put-port state name p(open %.y))
::
++  shut
  |=  [state=bridge-state-v2 name=@tas]
  ^-  bridge-state-v2
  =/  p=port  (at state name)
  (put-port state name p(open %.n, protocol ~))
::
::  +shut-all: every port, on reload.  The reconnect law (%shut then %spin so
::  the peer's socket really closes) applies to each.
++  shut-all
  |=  state=bridge-state-v2
  ^-  bridge-state-v2
  state(ports (~(run by ports.state) |=(p=port p(open %.n, protocol ~))))
::
++  ready
  |=  [state=bridge-state-v2 name=@tas]
  ^-  ?
  =/  p=port  (at state name)
  ?&  open.p
      ?=(^ protocol.p)
  ==
::
::  +any-pending: is ANY port mid-turn?  For the reload path, which must
::  fail every in-flight request on every port, not just one.
++  pending-ports
  |=  state=bridge-state-v2
  ^-  (list [name=@tas dispatch=model-bridge-dispatch:mb])
  %+  murn  ~(tap by ports.state)
  |=  [name=@tas p=port]
  ?~(pending.p ~ `[name u.pending.p])
::
++  submit
  |=  [state=bridge-state-v2 dispatch=model-bridge-dispatch:mb]
  ^-  transition
  =/  prompt=(unit @t)  (model-bridge-request-prompt:mb request.dispatch)
  ?~  prompt
    [%invalid state]
  ::  validate the command with the SAME policy the wire will carry, derived
  ::  from the request rather than supplied here -- otherwise the check passes
  ::  on a shape the dispatcher never sends.
  =/  policy=@t  (model-bridge-request-policy:mb request.dispatch)
  ?.  (model-bridge-command-valid:mb [%dispatch dispatch u.prompt policy])
    [%invalid state]
  ?.  ?=(%local-session -.target.spec.dispatch)
    [%not-local state]
  ::  THE PORT IS THE SPEC'S, not a literal.  %wrong-port now means "no such
  ::  port has ever been spun", which is the only sense left for it.
  =/  name=@tas  port.target.spec.dispatch
  ?.  (~(has by ports.state) name)
    [%wrong-port state]
  =/  p=port  (at state name)
  ?.  open.p
    [%not-ready state]
  ?~  protocol.p
    [%not-ready state]
  ?.  =(protocol.target.spec.dispatch u.protocol.p)
    [%not-ready state]
  ::  BUSY IS PER PORT.  Seat A mid-turn does not block seat B; only a second
  ::  dispatch to A does.
  ?^  pending.p
    [%busy state]
  =/  key=@t  (model-bridge-request-key:mb request.dispatch)
  ?:  (settled key state)
    [%duplicate state]
  [%accepted (put-port state name p(pending `dispatch))]
::
::  +port-of: which port holds the dispatch for this session+request.  The
::  session id IS the seat, so this is the seat's port -- but found by lookup,
::  not assumed, so a cancel for a turn that went elsewhere is a %mismatch.
++  port-of
  |=  [state=bridge-state-v2 request-id=@t session-id=@t]
  ^-  (unit @tas)
  =/  hits
    %+  skim  (pending-ports state)
    |=  [name=@tas d=model-bridge-dispatch:mb]
    ?&  =(request-id request-id.request.d)
        =(session-id session-id.request.d)
    ==
  ?~(hits ~ `name.i.hits)
::
++  cancel
  |=  [state=bridge-state-v2 request=model-bridge-cancel:mb]
  ^-  transition
  ?.  (model-bridge-cancel-valid:mb request)
    [%invalid state]
  =/  key=@t  (ids-key request-id.request session-id.request)
  ?:  (settled key state)
    [%duplicate state]
  ?~  (pending-ports state)
    [%orphan state]
  ?~  (port-of state request-id.request session-id.request)
    [%mismatch state]
  [%accepted state]
::
::  `from` is the port the soak arrived on -- the Lick name in the sign.  A
::  %ready carries no ids and is credited to that port; every other event is
::  matched to the dispatch pending ON THAT PORT, so a result arriving on the
::  wrong port is a %mismatch, not a settle.
++  receive
  |=  [state=bridge-state-v2 from=@tas event=model-bridge-event:mb]
  ^-  transition
  ?.  (model-bridge-event-valid:mb event)
    [%invalid state]
  ?:  ?=(%ready -.event)
    =/  p=port  (at state from)
    =/  with-latest=bridge-state-v2  state(latest `event)
    [%ready (put-port with-latest from p(protocol `protocol.event))]
  =/  ids=(unit [request-id=@t session-id=@t])  (event-ids event)
  ?~  ids
    [%invalid state]
  =/  key=@t  (ids-key request-id.u.ids session-id.u.ids)
  ?:  (settled key state)
    [%duplicate state]
  =/  p=port  (at state from)
  ?~  pending.p
    [%orphan state]
  ?.  (model-bridge-event-matches-request:mb spec.u.pending.p request.u.pending.p event)
    [%mismatch state]
  ?:  ?=(%accepted -.event)
    [%acknowledged state(latest `event)]
  =/  latest-result=(unit model-bridge-result:mb)
    ?:(?=(%result -.event) `result.event latest-result.state)
  =/  with-latest=bridge-state-v2  state(latest `event, latest-result latest-result)
  =/  next=bridge-state-v2  (put-port with-latest from p(pending ~))
  [%settled (remember key next)]
--
