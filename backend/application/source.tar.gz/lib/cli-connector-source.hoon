::  Inert connector source delivery. Validation never executes source/builds.
/+  cr=codex-responses
|%
+$  file  [path=@t bytes=@ud sha256=@ux text=@t]
++  carrier-valid
  ::  Exact reviewed release bytes; avoid reparsing Rust source on HTTP reads.
  |=  text=@t
  ^-  ?
  &(=(156.459 (met 3 text)) =(0x4049.31e8.c704.bb80.e7a8.f1b2.bd5b.5cd4.956c.bdd8.c5b9.3aaf.9c51.de4d.78cc.78ec (shax text)))
++  safe-path
  |=  value=@t
  ^-  ?
  ?:  |(=('Cargo.toml' value) =('Cargo.lock' value))  %.y
  =/  size=@ud  (met 3 value)
  ?.  &((gte size 8) (lte size 512) =('src/' (cut 3 [0 4] value)) =('.rs' (cut 3 [(sub size 3) 3] value)))  %.n
  =/  chars=tape  (trip (cut 3 [4 (sub size 7)] value))
  =/  slash=?  %.y
  =/  depth=@ud  0
  |-  ^-  ?
  ?~  chars  !slash
  ?:  =('/' i.chars)
    ?.  &(!slash (lth depth 15))  %.n
    $(chars t.chars, slash %.y, depth +(depth))
  ?.  |(&((gte i.chars 'a') (lte i.chars 'z')) &((gte i.chars 'A') (lte i.chars 'Z')) &((gte i.chars '0') (lte i.chars '9')) =(i.chars '_') =(i.chars '-'))  %.n
  $(chars t.chars, slash %.n)
++  file-valid
  |=  f=file
  ^-  ?
  &((safe-path path.f) (gth bytes.f 0) (lte bytes.f 1.048.576) =(bytes.f (met 3 text.f)) =(sha256.f (shax text.f)))
++  manifest
  |=  files=(list file)
  ^-  @ux
  =/  rows=(list (list @t))
    %+  turn  files
    |=  f=file
    ^-  (list @t)
    ~[path.f '\0a' (scot %ud bytes.f) '\0a' (scot %ux sha256.f) '\0a']
  (shax (rap 3 (zing rows)))
++  files-valid
  |=  files=(list file)
  ^-  ?
  =/  paths=(set @t)  (silt (turn files |=(f=file path.f)))
  ?&  (gte (lent files) 6)  (lte (lent files) 64)
      =((lent files) ~(wyt in paths))  (levy files file-valid)
      (lte (roll files |=([f=file size=@ud] (add size bytes.f))) 4.194.304)
      (levy `(list @t)`~['Cargo.toml' 'Cargo.lock' 'src/main.rs' 'src/connect.rs' 'src/connect_cli.rs' 'src/connect_state.rs'] |=(p=@t (~(has in paths) p)))
  ==
++  decode
  |=  object=json
  ^-  (unit (list file))
  %-  mole
  |.
  ?>  &(?=(%o -.object) =(6 ~(wyt by p.object)))
  ?>  =(`'pataphor-connector-source-v1' (string:cr object 'protocol'))
  ?>  =(`'rust-cargo-locked-v1' (string:cr object 'sourceContract'))
  ?>  =(`'little-endian-urbit-hex' (string:cr object 'digestEncoding'))
  =/  instructions=@t  (need (string:cr object 'instructions'))
  ?>  (lte (met 3 instructions) 8.192)
  =/  raw=json  (need (field:cr object 'files'))
  ?>  &(?=(%a -.raw) (lte (lent p.raw) 64))
  =/  files=(list file)
    %+  turn  p.raw
    |=  item=json
    ?>  &(?=(%o -.item) =(4 ~(wyt by p.item)))
    =/  sha=@t  (need (string:cr item 'sha256'))
    =/  value=@ux  (need (slaw %ux sha))
    ?>  &((lte (met 0 value) 256) =(sha (scot %ux value)))
    [(need (string:cr item 'path')) (need (natural:cr (field:cr item 'bytes'))) value (need (string:cr item 'text'))]
  ?>  (files-valid files)
  ?>  =(`(scot %ux (manifest files)) (string:cr object 'manifest'))
  files
++  download
  ::  Owner session only: a connector capability is not a general source grant.
  |=  [owner=? object=json]
  ^-  (unit json)
  ?.  owner  ~
  ?~  (decode object)  ~
  `object
--
