::  Bounded owner publication and exact native commands. No new authority.
/-  nc=native-coding
/+  law=cantrip-law-window, tools=cantrip-native-coding,
    accept=native-coding-accept, files=native-coding-files, h=readymade-history,
    budget=native-coding-hoon-check-budget
|%
+$  grant-row
  $:  id=@ux  session=@ux  actor=@p  authority=@p  project=text:h
      base=@tas  working=@tas  operations=(list operation:nc)
      inspections=(list [app=@tas pax=path])  max-eval-work=@ud
      readable=(list path)  writable=(list path)  protected=(list path)
      paths-overflow=?  revoked=(unit @da)  scope=@ux
  ==
+$  approval-row
  $:  id=@ux  grant=@ux  project=text:h  actor=@p  session=@ux
      source=revision:nc  accepted=revision:nc  basis=revision:nc
      stage=?(%proposed %cloning %staging %checking %review %landing %applied %refused %unknown)
      requested=@da  reason=(unit @tas)
      decision=(unit [verdict=?(%approve %revise %refuse) at=@da digest=@ux])
      report=(unit @ux)  candidate=@ux
  ==
+$  snapshot
  $:  %readymade-permissions-v2  owner=@p  source=@ux
      window=window:law  forbidden=(set act:law)
      grants=(list grant-row)  approvals=(list approval-row)  requests-overflow=?
  ==
+$  action
  $%  [%revoke id=@ux]
      [%grant-copy template=@ux id=@ux]
      [%review id=@ux]
      [%decide id=@ux]
      [%observe id=@ux]
  ==
+$  command  [%readymade-permissions-action-v1 source=@ux action=action]
+$  native-command
  $%  [%native-coding-grant-v1 value=grant:tools]
      [%native-coding-revoke-v1 id=@ux]
      [%native-coding-review-v1 candidate=@ux]
      [%native-coding-decide-v1 candidate=@ux]
      [%native-coding-candidate-observe-v1 candidate=@ux]
  ==
++  grant-view
  |=  s=scope:tools
  ^-  grant-row
  =/  g=grant:tools  grant.s
  =/  p=project:nc  project.g
  :*  id.g  session.g  actor.g  authority.spec.p  (bounded:h id.spec.p 256)
      base-desk.spec.p  working.p  ~(tap in operations.g)
      ~(tap in inspections.g)  max-eval-work.g
      (scag 32 ~(tap in readable.policy.p))
      (scag 32 ~(tap in writable.policy.p))
      (scag 32 ~(tap in protected.policy.p))
      |((gth ~(wyt in readable.policy.p) 32) (gth ~(wyt in writable.policy.p) 32) (gth ~(wyt in protected.policy.p) 32))
      revoked.s  (digest:tools s)
  ==
++  approval-view
  |=  r=record:accept
  ^-  approval-row
  =/  c=candidate:nc  candidate.r
  :*  id.c  grant.r  (bounded:h id.spec.project.r 256)
      actor.context.c  session.context.c  source.context.c
      accepted.c  revision.basis.c  stage.r  requested-at.r  reason.r
      ?~(decision.r ~ `[verdict.u.decision.r at.u.decision.r (digest:accept u.decision.r)])
      ?~(report.r ~ `(digest:accept u.report.r))  (digest:accept c)
  ==
++  stamp
  |=  s=snapshot
  ^-  @ux
  (shax (jam s(source 0x0)))
++  proposals
  ::  Only finished retained tool candidates; an acceptance row takes priority.
  |=  [t=organ:tools a=ledger:accept]
  ^-  (list approval-row)
  =/  pending=(map @ux approval-row)  *(map @ux approval-row)
  =/  rows=(list record:tools)  ~(val by records.t)
  |-  ^-  (list approval-row)
  ?~  rows  ~(val by pending)
  =/  r=record:tools  i.rows
  ?~  result.r  $(rows t.rows)
  ?.  &(=(%finished stage.r) ?=(%candidate -.output.u.result.r))
    $(rows t.rows)
  =/  c=candidate:nc  value.output.u.result.r
  ?:  |((~(has by a) id.c) (~(has by pending) id.c))  $(rows t.rows)
  =/  scope=(unit scope:tools)  (~(get by grants.t) grant.r)
  ?~  scope  $(rows t.rows)
  =/  row=approval-row
    :*  id.c  grant.r  (bounded:h id.spec.project.grant.u.scope 256)
        actor.context.c  session.context.c  source.context.c
        accepted.c  revision.basis.c  %proposed  at.r  ~  ~  ~
        (digest:accept c)
    ==
  $(rows t.rows, pending (~(put by pending) id.c row))
++  project
  |=  [our=@p w=window:law gone=(set act:law) t=organ:tools a=ledger:accept]
  ^-  snapshot
  ::  Native journals already enforce these bounds. A corrupted or
  ::  future larger journal must refuse, rather than silently omit authority.
  ?>  &((lte ~(wyt by grants.t) grant-capacity:tools) (lte ~(wyt by a) capacity:accept) (lte ~(wyt by records.t) capacity:tools))
  =/  retained=(list approval-row)  (turn ~(val by a) approval-view)
  =/  pending=(list approval-row)  (proposals t a)
  =/  room=@ud  (sub 128 (lent retained))
  =/  s=snapshot
    :*  %readymade-permissions-v2  our  0x0  (restrict:law w gone)  gone
        (turn ~(val by grants.t) grant-view)
        (weld retained (scag room pending))  (gth (lent pending) room)
    ==
  s(source (stamp s))
++  valid
  |=  [our=@p s=snapshot]
  ^-  ?
  ?&  =(our owner.s)  =(source.s (stamp s))
      (lte (lent grants.s) 128)  (lte (lent approvals.s) 128)
      =((lent grants.s) ~(wyt in (silt (turn grants.s |=(r=grant-row id.r)))))
      =((lent approvals.s) ~(wyt in (silt (turn approvals.s |=(r=approval-row id.r)))))
      (levy grants.s |=(r=grant-row ?&((identifier:tools id.r) (identifier:tools session.r) =(our authority.r) (lte (lent operations.r) 32) (lte (lent inspections.r) 32) (gte max-eval-work.r 1) (lte max-eval-work.r candidate-total-limit:budget) (lte (lent readable.r) 32) (lte (lent writable.r) 32) (lte (lent protected.r) 32) (lte (met 3 body.project.r) 256))))
      (levy approvals.s |=(r=approval-row &((identifier:tools id.r) (identifier:tools grant.r) (lte (met 3 body.project.r) 256))))
      =((~(uni in admissible.window.s) blocked.window.s) (silt all-acts:law))
      =(0 ~(wyt in (~(int in admissible.window.s) blocked.window.s)))
      =(never-auto.window.s never-auto-acts:law)
      =(0 ~(wyt in (~(dif in forbidden.s) blocked.window.s)))
  ==
++  facts
  |=  [b=bowl:gall w=window:law gone=(set act:law) t=organ:tools a=ledger:accept]
  ^-  (list card:agent:gall)
  ?.  (lien ~(val by sup.b) |=([who=@p pax=path] &(=(our.b who) =(/readymade/permissions pax))))  ~
  ~[[%give %fact ~[/readymade/permissions] %noun !>((project our.b w gone t a))]]
++  resolve
  ::  Re-read the CURRENT owner journals at dispatch, not the viewer's noun.
  ::  A grant-copy changes only the identifier; it cannot widen a scope.
  |=  [our=@p src=@p w=window:law gone=(set act:law) t=organ:tools a=ledger:accept c=command]
  ^-  (each native-command @t)
  ?.  =(our src)  [%| 'Only the owner ship may change permissions.']
  =/  current=snapshot  (project our w gone t a)
  ?.  =(source.c source.current)  [%| 'Permissions changed. Review the new native snapshot before acting.']
  =/  op=action  action.c
  ?:  ?=(%grant-copy -.op)
    ?.  &((identifier:tools template.op) (identifier:tools id.op))
      [%| 'Use canonical nonzero 256-bit native identifiers.']
    =/  template=(unit scope:tools)  (~(get by grants.t) template.op)
    ?~  template  [%| 'The native scope template no longer exists.']
    ?:  (~(has by grants.t) id.op)  [%| 'That grant identifier already exists; historical grants cannot be replaced.']
    =/  g=grant:tools  grant.u.template(id id.op)
    ?.  (grant-valid:tools our g)  [%| 'The native grant validator refused this scope.']
    [%& [%native-coding-grant-v1 g]]
  ?.  (identifier:tools id.op)  [%| 'Use a canonical nonzero 256-bit native identifier.']
  ?:  ?=(%revoke -.op)
    =/  found=(unit scope:tools)  (~(get by grants.t) id.op)
    ?~  found  [%| 'The standing grant does not exist.']
    [%& [%native-coding-revoke-v1 id.op]]
  ?:  ?=(%review -.op)
    ?:  (~(has by a) id.op)  [%| 'Native review has already been requested; observe its retained record.']
    =/  original=(unit record:tools)  (candidate-source:tools t id.op)
    ?~  original  [%| 'No finished retained candidate matches this request.']
    =/  scope=(unit scope:tools)  (~(get by grants.t) grant.u.original)
    ?~  scope  [%| 'The candidate standing grant no longer exists.']
    ?^  revoked.u.scope  [%| 'The candidate standing grant was revoked.']
    ?>  ?=(^ result.u.original)
    ?>  ?=(%candidate -.output.u.result.u.original)
    =/  candidate=candidate:nc  value.output.u.result.u.original
    ?.  (candidate-valid:files project.grant.u.scope candidate)
      [%| 'The retained candidate failed native validation.']
    [%& [%native-coding-review-v1 id.op]]
  =/  found=(unit record:accept)  (~(get by a) id.op)
  ?~  found  [%| 'The canonical candidate record does not exist.']
  ?:  ?=(%observe -.op)  [%& [%native-coding-candidate-observe-v1 id.op]]
  ?.  =(%review stage.u.found)  [%| 'The candidate is not awaiting a native decision.']
  ::  The existing decide action reads Viki's exact decision itself. A browser
  ::  supplies neither verdict nor source revisions nor decision evidence.
  [%& [%native-coding-decide-v1 id.op]]
++  prove
  ::  Pure authority boundaries; never dispatch, scry or mutate a journal.
  =/  w=window:law  (window-of:law [%high %low %high %low %low] [1 0 0 0])
  =/  gone=(set act:law)  (silt ~[%implement])
  =/  tools=organ:tools  *organ:tools
  =/  held=ledger:accept  *ledger:accept
  =/  s=snapshot  (project ~zod w gone tools held)
  ?>  (valid ~zod s)
  ?>  !(valid ~nec s)
  ?>  !(~(has in admissible.window.s) %implement)
  ?>  (~(has in blocked.window.s) %implement)
  ?>  =(0 ~(wyt in (~(dif in admissible.window.s) admissible.w)))
  =/  changed=@ux  `@ux`(mix 1 source.s)
  ?>  !(valid ~zod s(source changed))
  =/  exact=command  [%readymade-permissions-action-v1 source.s [%revoke 0x1]]
  =/  foreign  (resolve ~zod ~nec w gone tools held exact)
  ?>  ?=(%| -.foreign)
  =/  stale  (resolve ~zod ~zod w gone tools held exact(source changed))
  ?>  ?=(%| -.stale)
  =/  missing  (resolve ~zod ~zod w gone tools held exact)
  ?>  ?=(%| -.missing)
  =/  zero  (resolve ~zod ~zod w gone tools held exact(action [%grant-copy 0x0 0x2]))
  ?>  ?=(%| -.zero)
  =/  decide  (resolve ~zod ~zod w gone tools held exact(action [%decide 0x1]))
  ?>  ?=(%| -.decide)
  =/  observe  (resolve ~zod ~zod w gone tools held exact(action [%observe 0x1]))
  ?>  ?=(%| -.observe)
  ?>  ?=(~ ((soft command) [%readymade-permissions-action-v1 source.s [%revoke 0x1 %widened]]))
  ?>  ?=(~ ((soft command) [%readymade-permissions-action-v1 source.s [%grant-copy 0x1 0x2 %widened]]))
  %readymade-permissions-proof-v1
--
