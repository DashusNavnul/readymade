::  /lib/cantrip-land-flect.hoon
::
::  The local-land judge as law geometry (phase 11 of cantrip x flect).
::  The lane's act is everything +judge:cantrip-vibecoding-local-land reads
::  from the record: the owned graf rows, the judgment's key, the local
::  result view, the image, the preview run, the stated intent and the
::  parent commit.  The type-law says only that the act has the right
::  shape; this law adds one %run gate per predicate of the judge, at the
::  axis of the field it reads, in the judge's order, with the environment
::  [our actor at window].  The first miss names the judge's own refusal.
::  Nothing here scries: the gates run in mock.
::
/-  itn=intent
/+  flect, flect-law, land=cantrip-vibecoding-local-land,
    lr=vibecoding-local-result, image=vibecoding-local-image,
    preview=vibecoding-local-preview, vlj=viki-vibecoding-local-judgment,
    clw=cantrip-law-window
|%
+$  act
  $:  rows=(list *)  key=@ux  view=view:lr  img=image:image
      run=record:preview  intent=(unit record:itn)  parent=@uv
  ==
+$  env  [our=@p actor=@p at=@da w=window:clw]
++  act-type  ^-  type  -:!>(*act)
::  Axes: rows = 2, key = 6, view = 14, img = 30, run = 62, intent = 126,
::  parent = 127; the whole act = 1.
++  actor-gate
  ^-  *
  |=  [a=* e=*]
  =/  n  ;;(env e)
  =(our.n actor.n)
++  select-gate
  ^-  *
  |=  [a=* e=*]
  =/  x  ;;(act a)
  =/  n  ;;(env e)
  =/  picked  (select:land our.n at.n rows.x key.x)
  ?=(%& -.picked)
++  binding-gate
  ^-  *
  |=  [a=* e=*]
  =/  x  ;;(act a)
  =/  n  ;;(env e)
  =/  picked  (select:land our.n at.n rows.x key.x)
  ?.  ?=(%& -.picked)  %.n
  =/  j=judgment:vlj  p.picked
  &(=(key.x digest.j) (gte judged-at.j at.run.x) !=(0 parent.x))
::  Viki's exact approval body, recomputed from the evidence
++  recheck
  |=  [x=act n=env j=judgment:vlj]
  ^-  (each judgment:vlj @tas)
  =/  item=action:vlj
    [%viki-vibecoding-local-judge nonce.body.j write.subject.body.j run.subject.body.j decision.body.j note.body.j]
  (judge:vlj our.n actor.n at.n item view.x img.x run.x intent.x `w.n)
++  judgment-gate
  ^-  *
  |=  [a=* e=*]
  =/  x  ;;(act a)
  =/  n  ;;(env e)
  =/  picked  (select:land our.n at.n rows.x key.x)
  ?.  ?=(%& -.picked)  %.n
  =/  checked  (recheck x n p.picked)
  ?.  ?=(%& -.checked)  %.n
  =(body.p.picked body.p.checked)
++  window-gate
  ^-  *
  |=  [a=* e=*]
  =/  n  ;;(env e)
  &((~(has in admissible.w.n) %implement) !(~(has in blocked.w.n) %implement))
++  admission-gate
  ^-  *
  |=  [a=* e=*]
  =/  x  ;;(act a)
  =/  n  ;;(env e)
  =/  picked  (select:land our.n at.n rows.x key.x)
  ?.  ?=(%& -.picked)  %.n
  %-  admission-valid:land
  [%vibecoding-local-land-admission-v1 our.n at.n p.picked source.candidate.view.x parent.x]
++  gates
  ^-  law:flect-law
  :~  [1 %run actor-gate]
      [2 %run select-gate]
      [6 %run binding-gate]
      [14 %run judgment-gate]
      [1 %run window-gate]
      [127 %run admission-gate]
  ==
++  land-law
  ^-  law:flect-law
  (weld (law-of:flect-law act-type) gates)
++  land-receipt
  |=  [a=act e=env]
  ^-  receipt:flect-law
  (judge-with:flect-law land-law !>(`act`a) e)
::  +reason: the first miss, as the judge would have said it
++  reason
  |=  [r=receipt:flect-law a=act e=env]
  ^-  (unit refusal:land)
  ?~  misses.verdict.r  ~
  =/  d  demand.i.misses.verdict.r
  ?.  ?=(%run -.d)  `%binding-invalid
  ?:  =(gate.d actor-gate)  `%foreign-actor
  ?:  =(gate.d select-gate)
    =/  picked  (select:land our.e at.e rows.a key.a)
    ?:(?=(%| -.picked) `p.picked `%judgment-missing)
  ?:  =(gate.d binding-gate)  `%binding-invalid
  ?:  =(gate.d judgment-gate)
    =/  picked  (select:land our.e at.e rows.a key.a)
    ?.  ?=(%& -.picked)  `%binding-invalid
    =/  checked  (recheck a e p.picked)
    ?:  ?=(%& -.checked)  `%binding-invalid
    ?+  p.checked  `%binding-invalid
      %foreign-actor   `%foreign-actor
      %stale-source    `%stale-source
      %intent-changed  `%intent-changed
      %law-changed     `%law-changed
      %checks-failed   `%checks-failed
    ==
  ?:  =(gate.d window-gate)  `%landing-not-admitted
  ?:  =(gate.d admission-gate)  `%binding-invalid
  `%binding-invalid
--
