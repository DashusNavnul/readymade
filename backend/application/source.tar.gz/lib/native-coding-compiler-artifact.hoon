::  Decode the compiler's named PlanVal DATA, never execute it here.
::  The caller must separately bind the compiler entry and exact source job.
::  No source witnesses, positive checks, or installation rights are inferred.
/+  scalar=terminal-plan
|%
+$  plan  plan:scalar
+$  binding  [name=@t artifact=plan]
+$  refusal  [reason=@tas code=@ud module=@t symbol=@t]
+$  result  (each (list binding) refusal)
+$  terminal-artifacts  [initial=plan valid=plan reduce=plan contents=plan]
+$  task
  $%  [%visit raw=plan depth=@ud]
      [%application ~]
      [%pin ~]
      [%law arity=@ud name=@ud]
  ==
++  node-cap  262.144
++  depth-cap  512
++  row
  ::  At most two fields, exact constructor spine; no laws/pins/delays as data.
  |=  raw=plan
  ^-  [tag=@ud fields=(list plan)]
  =/  out=(list plan)  ~
  =/  count=@ud  0
  |-  ^-  [tag=@ud fields=(list plan)]
  ?:  ?=(%nat -.raw)  [value.raw out]
  ?>  &(?=(%app -.raw) (lth count 2))
  $(raw fun.raw, out [arg.raw out], count +(count))
++  fields
  |=  [raw=plan tag=@ud count=@ud]
  ^-  (list plan)
  =/  decoded  (row raw)
  ?>  &(=(tag tag.decoded) =(count (lent fields.decoded)))
  fields.decoded
++  atom
  ::  Minimal little-endian representation: zero is Nil, not Cons(0,Nil).
  ::  Interior zero bytes are retained, including in compiler law names.
  |=  [raw=plan limit=@ud]
  ^-  @ud
  ?>  (lte limit 512)
  =/  bytes=(list @)  ~
  =/  count=@ud  0
  =/  last=@ud  0
  |-  ^-  @ud
  ?:  =([%nat 0] raw)
    ?>  |(=(0 count) !=(0 last))
    (rap 3 (flop bytes))
  ?>  (lth count limit)
  =/  parts  (fields raw 1 2)
  =/  byte=plan  (snag 0 parts)
  ?>  ?=(%nat -.byte)
  ?>  (lte value.byte 255)
  $(raw (snag 1 parts), count +(count), last value.byte, bytes [value.byte bytes])
++  name-valid
  |=  name=@t
  ^-  ?
  ?.  &(!=('' name) (lte (met 3 name) 128))  %.n
  =/  bytes=(list @t)  (trip name)
  =/  first=?  %.y
  |-  ^-  ?
  ?~  bytes  !first
  =/  c=@t  i.bytes
  ?:  =('.' c)  ?:(first %.n $(bytes t.bytes, first %.y))
  =/  alpha=?  |(&((gte c 'a') (lte c 'z')) &((gte c 'A') (lte c 'Z')))
  ?.  ?:(first alpha |(alpha &((gte c '0') (lte c '9')) =('_' c)))  %.n
  $(bytes t.bytes, first %.n)
++  decode-node
  |=  [raw=plan remaining=@ud]
  ^-  [remaining=@ud artifact=plan]
  =/  todo=(list task)  ~[[%visit raw 1]]
  =/  stack=(list plan)  ~
  |-  ^-  [remaining=@ud artifact=plan]
  ?:  =(~ todo)
    ?>  =(1 (lent stack))
    [remaining (snag 0 stack)]
  =/  work=task  (snag 0 todo)
  =/  rest=(list task)  (slag 1 todo)
  ?-  -.work
    %visit
      ?>  &(!=(0 remaining) (lte depth.work depth-cap))
      =/  next=@ud  (dec remaining)
      =/  decoded  (row raw.work)
      =/  values=(list plan)  fields.decoded
      ?+  tag.decoded  !!
        %0
          ?>  =(1 (lent values))
          $(todo rest, remaining next, stack [[%nat (atom (snag 0 values) 512)] stack])
        %1
          ?>  =(2 (lent values))
          $(todo [[%visit (snag 0 values) +(depth.work)] [%visit (snag 1 values) +(depth.work)] [%application ~] rest], remaining next)
        %2
          ?>  &(=(2 (lent values)) !=(0 next))
          =/  name=@ud  (atom (snag 0 values) 512)
          =/  pair  (fields (snag 1 values) 0 2)
          =/  arity=plan  (snag 0 pair)
          ?>  ?=(%nat -.arity)
          ?>  &((gte value.arity 1) (lte value.arity 32))
          $(todo [[%visit (snag 1 pair) +(depth.work)] [%law value.arity name] rest], remaining (dec next))
        %3
          ?>  =(1 (lent values))
          $(todo [[%visit (snag 0 values) +(depth.work)] [%pin ~] rest], remaining next)
      ==
    %application
      =/  argument=plan  (snag 0 stack)
      =/  function=plan  (snag 1 stack)
      $(todo rest, stack [[%app function argument] (slag 2 stack)])
    %pin
      =/  pinned=plan  (snag 0 stack)
      ::  This attachment supports the native VM's finite primitive set.
      ::  Arbitrary opaque Nat pins are deliberately outside this ABI subset.
      ?>  ?:(?=(%nat -.pinned) |((lte value.pinned 4) ?=(?(%10 %11 %12) value.pinned)) %.y)
      $(todo rest, stack [[%pin pinned] (slag 1 stack)])
    %law
      $(todo rest, stack [[%law arity.work [%nat name.work] (snag 0 stack)] (slag 1 stack)])
  ==
++  names
  ^-  (list @t)
  ~['Runtime.NativeCodingTerminal.initial' 'Runtime.NativeCodingTerminal.valid' 'Runtime.NativeCodingTerminal.reduce' 'Runtime.NativeCodingTerminal.contents']
++  parse
  |=  [raw=plan wanted=(list @t)]
  ^-  result
  ?>  &((gte (lent wanted) 1) (lte (lent wanted) 8) (levy wanted name-valid) =((lent wanted) ~(wyt in (silt wanted))))
  =/  envelope  (row raw)
  ?:  =(1 tag.envelope)
    ?>  =(2 (lent fields.envelope))
    =/  code=plan  (snag 0 fields.envelope)
    ?>  ?=(%nat -.code)
    ?>  &((gte value.code 1) (lte value.code 65.535))
    =/  detail  (fields (snag 1 fields.envelope) 0 2)
    =/  module=@t  `@t`(atom (snag 0 detail) 128)
    =/  symbol=@t  `@t`(atom (snag 1 detail) 128)
    ?>  &(|(=('' module) (name-valid module)) |(=('' symbol) (name-valid symbol)))
    [%| %compiler-artifact-emission-refused value.code module symbol]
  ?>  &(=(0 tag.envelope) =(1 (lent fields.envelope)))
  =/  pending=plan  (snag 0 fields.envelope)
  =/  output=(list binding)  ~
  =/  remaining=@ud  node-cap
  |-  ^-  result
  ?:  =(~ wanted)
    ?>  =([%nat 0] pending)
    [%& (flop output)]
  =/  pair  (fields pending 1 2)
  =/  item  (fields (snag 0 pair) 0 2)
  =/  name=@t  `@t`(atom (snag 0 item) 128)
  ?>  =((snag 0 wanted) name)
  =/  decoded  (decode-node (snag 1 item) remaining)
  ?>  (artifact-valid:scalar artifact.decoded)
  $(pending (snag 1 pair), wanted (slag 1 wanted), remaining remaining.decoded, output [[name artifact.decoded] output])
++  decode
  |=  [raw=plan wanted=(list @t)]
  ^-  result
  =/  decoded  (mole |.((parse raw wanted)))
  ?~  decoded  [%| %compiler-artifact-wire-refused 0 '' '']
  u.decoded
++  terminal
  |=  raw=plan
  ^-  (each terminal-artifacts refusal)
  =/  decoded  (decode raw names)
  ?:  ?=(%| -.decoded)  [%| p.decoded]
  =/  first=binding  (snag 0 p.decoded)
  =/  second=binding  (snag 1 p.decoded)
  =/  third=binding  (snag 2 p.decoded)
  =/  fourth=binding  (snag 3 p.decoded)
  =/  values=terminal-artifacts
    [artifact.first artifact.second artifact.third artifact.fourth]
  ?.  &(=(`0 (arity:scalar initial.values)) =(`1 (arity:scalar valid.values)) =(`2 (arity:scalar reduce.values)) =(`1 (arity:scalar contents.values)))
    [%| %compiler-terminal-export-arity 0 '' '']
  [%& values]
--
