::  Pure plans for Cantrip's future active Viki watch. Caller-provided nouns
::  and Graf rows do not authenticate this state machine. The owning agent
::  must persist both ledgers and emit returned cards in the SAME event.
/-  ci=vibecoding-connected-intake, cr=vibecoding-connected-review
/+  intake=vibecoding-intake-core, review=cantrip-vibecoding-connected-review,
    editor=cantrip-editor-save, model=pataphor-editor-model,
    vcl=vibecoding-candidate
|%
+$  request  [%cantrip-connected-write-v1 candidate=@ux nonce=@ux]
+$  state
  $%  [%watching ~]  [%reviewing ~]
      [%submitted intake=record:ci admission=@ux]
      [%refused reason=@tas]  [%unknown reason=@tas]
  ==
+$  entry  [owner=@p request=request at=@da expires=@da state=state]
+$  ledger  (map @ux entry)
+$  view  [review=record:cr basis=basis:editor]
+$  transition  [next=ledger saves=ledger:editor cards=(list card:agent:gall)]
+$  result  (each transition @tas)
++  request-valid
  |=  r=request
  ^-  ?
  &(!=(0 candidate.r) (lte (met 0 candidate.r) 256) !=(0 nonce.r) (lte (met 0 nonce.r) 128))
++  pending
  |=  e=entry
  |(?=(%watching -.state.e) ?=(%reviewing -.state.e))
++  route
  |=  nonce=@ux
  /connected-write/(scot %ux nonce)
++  key-for
  |=  w=wire
  ^-  (unit @ux)
  ?.  ?=([%connected-write @ ~] w)  ~
  =/  key  (slaw %ux i.t.w)
  ?~  key  ~
  ?.  &(!=(0 u.key) (lte (met 0 u.key) 128) =(w (route u.key)))  ~
  key
++  close
  |=  [our=@p e=entry]
  ^-  (list card:agent:gall)
  :~  [%pass (route nonce.request.e) %agent [our %viki] %leave ~]
      [%pass (route nonce.request.e) %arvo %b %rest expires.e]
  ==
++  entry-valid
  |=  [e=entry saves=ledger:editor]
  ^-  ?
  ?.  &((request-valid request.e) !=(0 at.e) =(expires.e (add at.e ~s15)))  %.n
  ?.  ?=(%submitted -.state.e)  %.y
  =/  r=record:ci  intake.state.e
  =/  found  (~(get by saves) nonce.request.e)
  ?~  found  %.n
  =/  a=admission:editor  admission.u.found
  =/  checked  (build:review owner.e at.a candidate.body.review.body.r window.a)
  ?.  ?=(%& -.checked)  %.n
  ?&  (valid:intake r)  (record-valid:editor u.found)
      =(owner.e owner.body.review.body.r)
      =(candidate.request.e candidate.ticket.body.r)
      =(nonce.request.e nonce.ticket.body.r)
      (lte at.e started.ticket.body.r)
      (lth at.body.review.body.r expires.e)
      =(admission.state.e (digest:editor a))
      =(owner.e owner.change.a)  =(nonce.request.e nonce.change.a)
      =(source.candidate.body.review.body.r replacement.change.a)
      (lte at.body.review.body.r at.a)  (lth at.a expires.e)
      (lth at.a (until:intake ticket.body.r))
      =([%& a] (admission owner.e at.a e r [p.checked basis.a]))
  ==
++  valid
  |=  [held=ledger saves=ledger:editor]
  ^-  ?
  ?&  (lte ~(wyt by held) 128)  (ledger-valid:editor saves)
      %+  levy  ~(tap by held)
      |=  [key=@ux e=entry]
      &(=(key nonce.request.e) (entry-valid e saves))
  ==
++  start
  ::  The owner requests this exact candidate's WORKING-source replacement.
  ::  Tests approved before inference are not ratification of arbitrary bytes.
  |=  [our=@p actor=@p now=@da held=ledger saves=ledger:editor r=request]
  ^-  result
  ?.  =(our actor)  [%| %foreign-actor]
  ?.  !=(0 now)  [%| %time-invalid]
  ?.  &((request-valid r) (valid held saves))  [%| %request-invalid]
  =/  old  (~(get by held) nonce.r)
  ?^  old
    ?.  &(=(our owner.u.old) =(r request.u.old))  [%| %nonce-conflict]
    [%& [held saves ~]]
  ?:  (~(has by saves) nonce.r)  [%| %save-nonce-used]
  ?:  (gte ~(wyt by held) 128)  [%| %capacity]
  ?:  (lien ~(val by held) pending)  [%| %review-in-progress]
  =/  e=entry  [our r now (add now ~s15) [%watching ~]]
  =/  cards=(list card:agent:gall)
    :~  [%pass (route nonce.r) %agent [our %viki] %watch /vibecoding-connected-reviews]
        [%pass (route nonce.r) %arvo %b %wait expires.e]
    ==
  [%& [(~(put by held) nonce.r e) saves cards]]
++  lookup
  |=  [our=@p now=@da held=ledger saves=ledger:editor source=[ship=@p agent=@tas] w=wire]
  ^-  (each entry @tas)
  ?.  =(source [our %viki])  [%| %wrong-endpoint]
  ?.  (valid held saves)  [%| %journal-invalid]
  =/  key  (key-for w)
  ?~  key  [%| %wrong-wire]
  =/  held-entry  (~(get by held) u.key)
  ?~  held-entry  [%| %not-pending]
  =/  e=entry  u.held-entry
  ?.  &(=(our owner.e) (pending e))  [%| %not-pending]
  ?.  &((lte at.e now) (lth now expires.e))  [%| %expired]
  [%& e]
++  ack
  ::  Only a positive Gall acknowledgment of our Viki watch requests replay.
  |=  [our=@p now=@da held=ledger saves=ledger:editor source=[ship=@p agent=@tas] w=wire sign=sign:agent:gall]
  ^-  result
  =/  found  (lookup our now held saves source w)
  ?:  ?=(%| -.found)  [%| p.found]
  =/  e=entry  p.found
  ?.  &(?=(%watching -.state.e) ?=(%watch-ack -.sign))  [%| %unexpected-ack]
  ?^  p.sign
    [%& [(~(put by held) nonce.request.e e(state [%refused %watch-rejected])) saves (close our e)]]
  =/  cards=(list card:agent:gall)
    ~[[%pass /connected-write-request/(scot %ux nonce.request.e) %agent [our %viki] %poke %noun !>([%viki-connected-review candidate.request.e `@uv`nonce.request.e])]]
  [%& [(~(put by held) nonce.request.e e(state [%reviewing ~])) saves cards]]
++  event-for
  |=  [e=entry now=@da sign=sign:agent:gall]
  ^-  (each record:ci @tas)
  ?.  ?=(%reviewing -.state.e)  [%| %watch-not-acknowledged]
  ?.  ?=(%fact -.sign)  [%| %not-viki-fact]
  ?.  =(%noun p.cage.sign)  [%| %wrong-mark]
  =/  parsed  ((soft ,record:ci) q.q.cage.sign)
  ?~  parsed  [%| %malformed-intake]
  =/  r=record:ci  u.parsed
  ?.  ?&  (valid:intake r)  =(owner.e owner.body.review.body.r)
          =(candidate.request.e candidate.ticket.body.r)
          =(nonce.request.e nonce.ticket.body.r)
          (lte at.e started.ticket.body.r)
          (lte at.body.review.body.r now)
          (lth now (until:intake ticket.body.r))
      ==  [%| %intake-mismatch]
  [%& r]
++  admission
  ::  This joins fresh source and law to an ACTIVE event, not Graf provenance.
  |=  [our=@p now=@da e=entry r=record:ci current=view]
  ^-  (each admission:editor @tas)
  =/  original=record:cr  review.body.r
  ?.  =([%& review.current] (build:review our now candidate.body.original window.body.original))
    [%| %review-changed]
  =/  context  (context-of:vcl packet.candidate.body.original)
  =/  b=basis:editor  basis.current
  ?.  (basis-valid:editor b)  [%| %basis-invalid]
  =/  s=snapshot:model  current.b
  ?.  ?=(%text -.body.s)  [%| %basis-invalid]
  ?.  ?&  =(our owner.s)  =(now at.s)
          =(base.context base.s)  =(work.context work.s)
          =(before.context source.body.s)
          =(before.body.original blob.s)
      ==  [%| %source-changed]
  =/  change=change:model
    [%pataphor-editor-change-v1 our nonce.request.e s source.candidate.body.original]
  (judge:editor our our now change b window.body.review.current)
++  receive
  ::  The future Cantrip on-agent handler alone supplies endpoint and sign.
  ::  No historical-receipt lookup or raw-intake poke can call this as authority.
  |=  [our=@p now=@da held=ledger saves=ledger:editor source=[ship=@p agent=@tas] w=wire sign=sign:agent:gall current=view]
  ^-  result
  =/  found  (lookup our now held saves source w)
  ?:  ?=(%| -.found)  [%| p.found]
  =/  e=entry  p.found
  =/  got  (event-for e now sign)
  ?:  ?=(%| -.got)  [%| p.got]
  =/  admitted  (admission our now e p.got current)
  ?:  ?=(%| -.admitted)  [%| p.admitted]
  ::  Use the SAME editor ledger and reserve arm as manual saves. This is
  ::  the only producer of the Clay card and commit-recovery admission.
  =/  reserved  (reserve:editor saves p.admitted our now)
  ?:  ?=(%| -.reserved)  [%| p.reserved]
  =/  next=entry
    e(state [%submitted p.got (digest:editor p.admitted)])
  =/  cards=(list card:agent:gall)  ~[card.p.reserved]
  [%& [(~(put by held) nonce.request.e next) next.p.reserved (weld (close our e) cards)]]
++  stop
  ::  Failure/timeout closes the watch; it never resubmits or writes source.
  |=  [our=@p now=@da held=ledger saves=ledger:editor nonce=@ux reason=@tas]
  ^-  result
  ?.  (valid held saves)  [%| %journal-invalid]
  =/  found  (~(get by held) nonce)
  ?~  found  [%| %not-pending]
  =/  e=entry  u.found
  ?.  &(=(our owner.e) (pending e))  [%| %not-pending]
  ?.  (gte now at.e)  [%| %time-invalid]
  =/  next=entry  e(state [%unknown reason])
  [%& [(~(put by held) nonce next) saves (close our e)]]
::  V2 is an additive contract. No existing command, ledger or Gall hook
::  selects it. Activation must supply BOTH journals to the shared guards.
+$  request-v2  [%cantrip-connected-write-v2 candidate=@ux nonce=@ux]
++  state-for-v2
  |$  [intake-mold]
  $%  [%watching ~]  [%reviewing ~]
      [%submitted intake=intake-mold admission=@ux]
      [%refused reason=@tas]  [%unknown reason=@tas]
  ==
++  entry-for-v2
  |$  [intake-mold]
  [owner=@p request=request-v2 at=@da expires=@da state=(state-for-v2 intake-mold)]
::  Existing journals and gates still select only the strict v6 intake.
+$  state-v2  (state-for-v2 record-v2:ci)
+$  entry-v2  (entry-for-v2 record-v2:ci)
+$  ledger-v2  (map @ux entry-v2)
+$  view-v2  [review=record-v2:cr basis=basis:editor]
+$  transition-v2  [next=ledger-v2 saves=ledger:editor cards=(list card:agent:gall)]
+$  result-v2  (each transition-v2 @tas)
++  request-valid-v2
  |=  r=request-v2
  (request-valid [%cantrip-connected-write-v1 candidate.r nonce.r])
++  pending-v2
  |=  e=entry-v2
  |(?=(%watching -.state.e) ?=(%reviewing -.state.e))
++  route-v2
  |=  nonce=@ux
  /connected-write-v2/(scot %ux nonce)
++  key-for-v2
  |=  w=wire
  ^-  (unit @ux)
  ?.  ?=([%connected-write-v2 @ ~] w)  ~
  ::  Reuse the exact bounded, canonical nonce parser, not its authority tag.
  (key-for [%connected-write t.w])
++  close-v2
  |=  [our=@p e=entry-v2]
  ^-  (list card:agent:gall)
  :~  [%pass (route-v2 nonce.request.e) %agent [our %viki] %leave ~]
      [%pass (route-v2 nonce.request.e) %arvo %b %rest expires.e]
  ==
++  admission-v2
  |=  [our=@p now=@da e=entry-v2 r=record-v2:ci current=view-v2]
  ^-  (each admission:editor @tas)
  =/  original=record-v2:cr  review.body.r
  ?.  =([%& review.current] (build-v2:review our now candidate.body.original window.body.original))
    [%| %review-changed]
  =/  context  context.packet.candidate.body.original
  =/  b=basis:editor  basis.current
  ?.  (basis-valid:editor b)  [%| %basis-invalid]
  =/  s=snapshot:model  current.b
  ?.  ?=(%text -.body.s)  [%| %basis-invalid]
  ?.  ?&  =(our owner.s)  =(now at.s)
          =(base.context base.s)  =(work.context work.s)
          =(before.context source.body.s)  =(before.body.original blob.s)
      ==  [%| %source-changed]
  =/  change=change:model
    [%pataphor-editor-change-v1 our nonce.request.e s source.candidate.body.original]
  (judge:editor our our now change b window.body.review.current)
++  entry-valid-v2
  |=  [e=entry-v2 saves=ledger:editor]
  ^-  ?
  ?.  &((request-valid-v2 request.e) !=(0 at.e) =(expires.e (add at.e ~s15)))  %.n
  ?.  ?=(%submitted -.state.e)  %.y
  =/  r=record-v2:ci  intake.state.e
  =/  found  (~(get by saves) nonce.request.e)
  ?~  found  %.n
  =/  a=admission:editor  admission.u.found
  =/  checked  (build-v2:review owner.e at.a candidate.body.review.body.r window.a)
  ?.  ?=(%& -.checked)  %.n
  ?&  (valid-v2:intake r)  (record-valid:editor u.found)
      =(owner.e owner.body.review.body.r)
      =(candidate.request.e candidate.ticket.body.r)
      =(nonce.request.e nonce.ticket.body.r)
      (lte at.e started.ticket.body.r)
      (lth at.body.review.body.r expires.e)
      =(admission.state.e (digest:editor a))
      =(owner.e owner.change.a)  =(nonce.request.e nonce.change.a)
      =(source.candidate.body.review.body.r replacement.change.a)
      (lte at.body.review.body.r at.a)  (lth at.a expires.e)
      (lth at.a (until:intake ticket.body.r))
      =([%& a] (admission-v2 owner.e at.a e r [p.checked basis.a]))
  ==
++  valid-v2
  |=  [held=ledger-v2 saves=ledger:editor]
  ^-  ?
  ?&  (lte ~(wyt by held) 128)  (ledger-valid:editor saves)
      %+  levy  ~(tap by held)
      |=  [key=@ux e=entry-v2]
      &(=(key nonce.request.e) (entry-valid-v2 e saves))
  ==
++  compatible
  |=  [legacy=ledger modern=ledger-v2 saves=ledger:editor]
  ^-  ?
  ?&  (valid legacy saves)  (valid-v2 modern saves)
      %+  levy  ~(tap by modern)
      |=  [key=@ux e=entry-v2]
      !(~(has by legacy) key)
  ==
++  start-v1-shared
  ::  Required by the future owner hook; old start itself stays unchanged.
  |=  [our=@p actor=@p now=@da legacy=ledger modern=ledger-v2 saves=ledger:editor r=request]
  ^-  result
  ?.  =(our actor)  [%| %foreign-actor]
  ?.  (compatible legacy modern saves)  [%| %journal-conflict]
  ?:  (~(has by modern) nonce.r)  [%| %version-nonce-used]
  ?:  (~(has by legacy) nonce.r)  (start our actor now legacy saves r)
  ?:  (lien ~(val by modern) pending-v2)  [%| %review-in-progress]
  (start our actor now legacy saves r)
++  start-v2
  |=  [our=@p actor=@p now=@da legacy=ledger held=ledger-v2 saves=ledger:editor r=request-v2]
  ^-  result-v2
  ?.  =(our actor)  [%| %foreign-actor]
  ?.  &(!=(0 now) (request-valid-v2 r))  [%| %request-invalid]
  ?.  (compatible legacy held saves)  [%| %journal-conflict]
  ?:  (~(has by legacy) nonce.r)  [%| %version-nonce-used]
  =/  old  (~(get by held) nonce.r)
  ?^  old
    ?.  &(=(our owner.u.old) =(r request.u.old))  [%| %nonce-conflict]
    [%& [held saves ~]]
  ?:  (~(has by saves) nonce.r)  [%| %save-nonce-used]
  ?:  (gte ~(wyt by held) 128)  [%| %capacity]
  ?:  |((lien ~(val by legacy) pending) (lien ~(val by held) pending-v2))  [%| %review-in-progress]
  =/  e=entry-v2  [our r now (add now ~s15) [%watching ~]]
  =/  cards=(list card:agent:gall)
    :~  [%pass (route-v2 nonce.r) %agent [our %viki] %watch /vibecoding-connected-reviews]
        [%pass (route-v2 nonce.r) %arvo %b %wait expires.e]
    ==
  [%& [(~(put by held) nonce.r e) saves cards]]
++  lookup-v2
  |=  [our=@p now=@da legacy=ledger held=ledger-v2 saves=ledger:editor source=[ship=@p agent=@tas] w=wire]
  ^-  (each entry-v2 @tas)
  ?.  =(source [our %viki])  [%| %wrong-endpoint]
  ?.  (compatible legacy held saves)  [%| %journal-conflict]
  =/  key  (key-for-v2 w)
  ?~  key  [%| %wrong-wire]
  =/  found  (~(get by held) u.key)
  ?~  found  [%| %not-pending]
  =/  e=entry-v2  u.found
  ?.  &(=(our owner.e) (pending-v2 e))  [%| %not-pending]
  ?.  &((lte at.e now) (lth now expires.e))  [%| %expired]
  [%& e]
++  ack-v2
  |=  [our=@p now=@da legacy=ledger held=ledger-v2 saves=ledger:editor source=[ship=@p agent=@tas] w=wire sign=sign:agent:gall]
  ^-  result-v2
  =/  found  (lookup-v2 our now legacy held saves source w)
  ?:  ?=(%| -.found)  [%| p.found]
  =/  e=entry-v2  p.found
  ?.  &(?=(%watching -.state.e) ?=(%watch-ack -.sign))  [%| %unexpected-ack]
  ?^  p.sign
    [%& [(~(put by held) nonce.request.e e(state [%refused %watch-rejected])) saves (close-v2 our e)]]
  =/  cards=(list card:agent:gall)
    ~[[%pass /connected-write-request-v2/(scot %ux nonce.request.e) %agent [our %viki] %poke %noun !>([%viki-connected-review-v2 candidate.request.e `@uv`nonce.request.e])]]
  [%& [(~(put by held) nonce.request.e e(state [%reviewing ~])) saves cards]]
++  event-for-v2
  |=  [e=entry-v2 now=@da sign=sign:agent:gall]
  ^-  (each record-v2:ci @tas)
  ?.  ?=(%reviewing -.state.e)  [%| %watch-not-acknowledged]
  ?.  ?=(%fact -.sign)  [%| %not-viki-fact]
  ?.  =(%noun p.cage.sign)  [%| %wrong-mark]
  =/  parsed  ((soft ,record-v2:ci) q.q.cage.sign)
  ?~  parsed  [%| %malformed-intake]
  =/  r=record-v2:ci  u.parsed
  ?.  ?&  (valid-v2:intake r)  =(owner.e owner.body.review.body.r)
          =(candidate.request.e candidate.ticket.body.r)
          =(nonce.request.e nonce.ticket.body.r)
          (lte at.e started.ticket.body.r)
          (lte at.body.review.body.r now)
          (lth now (until:intake ticket.body.r))
      ==  [%| %intake-mismatch]
  [%& r]
++  receive-v2
  |=  [our=@p now=@da legacy=ledger held=ledger-v2 saves=ledger:editor source=[ship=@p agent=@tas] w=wire sign=sign:agent:gall current=view-v2]
  ^-  result-v2
  =/  found  (lookup-v2 our now legacy held saves source w)
  ?:  ?=(%| -.found)  [%| p.found]
  =/  got  (event-for-v2 p.found now sign)
  ?:  ?=(%| -.got)  [%| p.got]
  =/  admitted  (admission-v2 our now p.found p.got current)
  ?:  ?=(%| -.admitted)  [%| p.admitted]
  ::  Full v2 intake remains intact. Only the existing editor reserve arm
  ::  admits the sole Clay card; no provider identity becomes write authority.
  =/  reserved  (reserve:editor saves p.admitted our now)
  ?:  ?=(%| -.reserved)  [%| p.reserved]
  =/  e=entry-v2  p.found(state [%submitted p.got (digest:editor p.admitted)])
  [%& [(~(put by held) nonce.request.e e) next.p.reserved (weld (close-v2 our e) ~[card.p.reserved])]]
++  stop-v2
  |=  [our=@p now=@da legacy=ledger held=ledger-v2 saves=ledger:editor nonce=@ux reason=@tas]
  ^-  result-v2
  ?.  (compatible legacy held saves)  [%| %journal-conflict]
  =/  found  (~(get by held) nonce)
  ?~  found  [%| %not-pending]
  =/  e=entry-v2  u.found
  ?.  &(=(our owner.e) (pending-v2 e))  [%| %not-pending]
  ?.  (gte now at.e)  [%| %time-invalid]
  [%& [(~(put by held) nonce e(state [%unknown reason])) saves (close-v2 our e)]]
--
