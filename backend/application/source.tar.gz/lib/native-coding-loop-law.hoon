::  Loop law: runtime policy for the native coding loop, read from the host
::  law desk at each provider outcome, never compiled in. Changing a value is
::  a Clay commit of /law/native-coding-loop/hoon: no Viki rebuild. Absent or
::  out-of-range law falls back to the defaults below; the digest of whatever
::  text was read is kept either way.
/-  np=native-coding-provider
|%
+$  policy
  $:  version=@t
      retry-statuses=(list @ud)
      retry-limit=@ud
      request-timeout=@dr    ::  cancel a provider call still pending this long; ~s0 = off
      unclaimed-waits=@ud    ::  how many timeouts a CLI-routed request may sit unclaimed before cancelling
  ==
::  The law file written before unclaimed-waits existed (loop-v2); it still parses.
+$  legacy-policy
  [version=@t retry-statuses=(list @ud) retry-limit=@ud request-timeout=@dr]
+$  law-state  [pol=policy digest=@ux present=?]
++  law-path  /law/native-coding-loop/hoon
++  default-unclaimed-waits  6
++  default-policy
  ^-  policy
  ['loop-v3' ~[502 503 504] 2 ~m10 default-unclaimed-waits]
++  policy-valid
  |=  pol=policy
  ^-  ?
  ?&  (gte (met 3 version.pol) 1)  (lte (met 3 version.pol) 64)
      (lte (lent retry-statuses.pol) 8)  (lte retry-limit.pol 8)
      (levy retry-statuses.pol |=(s=@ud &((gte s 400) (lte s 599))))
      |(=(~s0 request-timeout.pol) &((gte request-timeout.pol ~m1) (lte request-timeout.pol ~h1)))
      (lte unclaimed-waits.pol 24)
  ==
++  parse-law
  ::  The law file is one Hoon expression evaluated against an empty subject.
  ::  A legacy four-field policy keeps the default unclaimed-waits.
  |=  text=@t
  ^-  (unit policy)
  =/  value  (mule |.(q:(slap !>(~) (ream text))))
  ?:  ?=(%| -.value)  ~
  =/  current  ((soft policy) p.value)
  =/  parsed=(unit policy)
    ?^  current  current
    =/  old  ((soft legacy-policy) p.value)
    ?~  old  ~
    `[version.u.old retry-statuses.u.old retry-limit.u.old request-timeout.u.old default-unclaimed-waits]
  ?~  parsed  ~
  ?.  (policy-valid u.parsed)  ~
  parsed
++  law
  |=  [our=@p at=@da desk=@tas]
  ^-  law-state
  =/  pax=path  (weld /(scot %p our)/[desk]/(scot %da at) law-path)
  ?.  .^(? %cu pax)  [default-policy 0x0 %.n]
  =/  text=@t  .^(@t %cx pax)
  =/  parsed=(unit policy)  (parse-law text)
  ?~  parsed  [default-policy (shax text) %.n]
  [u.parsed (shax text) %.y]
++  retry
  ::  A provider failure is transient when it is an HTTP error whose status
  ::  the law lists and fewer than retry-limit retries happened since the
  ::  last model reply (counted by the caller from the session journal).
  |=  [pol=policy error=failure:np retries=@ud]
  ^-  ?
  ?&  =(%http-error reason.error)
      ?=(^ (find ~[status.error] retry-statuses.pol))
      (lth retries retry-limit.pol)
  ==
--
