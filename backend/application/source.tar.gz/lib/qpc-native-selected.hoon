::  One execution intent/mapping for the controller's one canonical choice.
::  This journal never chooses, reselects or owns a second decision state.
::  A patch result materializes a candidate; only ordinary Cantrip acceptance
::  and an independent selected-settlement adapter may establish application.
/-  nc=native-coding
/+  controller=qpc-native-controller, d=qpc-native-decision,
    admit=qpc-native-admission, pool=qpc-native-pool,
    ct=cantrip-native-coding, sessions=native-coding-session,
    project=native-coding-project
|%
+$  plan
  $:  %qpc-selected-plan-v1  id=@ux  selection=@ux  at=@da  nonce=@ux
      collection=@ux  candidate=@ux  effect=@ux
      original=record:ct  grant=grant:ct  request=tool-request:nc
      entry=entry:sessions  key=@tas
  ==
+$  record
  $:  plan=plan  phase=?(%opening %admitting %sent %refused %unknown)
      marker=(unit marker:admit)  mapping=(unit mapping:d)
      reason=(unit @tas)
  ==
+$  state
  [%qpc-native-selected-v1 records=(map @ux record) unavailable=(map @ux @tas)]
++  empty  ^-(state [%qpc-native-selected-v1 ~ ~])
++  digest  |=(v=* ^-(@ux (shax (jam [%qpc-native-selected-v1 v]))))
++  objective
  ::  Preserve all retained operator instructions, in ordinary review order.
  ::  This pure projection imports no review owner or inference machinery.
  |=  e=entry:sessions
  ^-  (each @t @tas)
  =/  text=@t
    (rap 3 (murn records.e |=(r=record:sessions ?:(?=(%operator -.body.r) `(cat 3 text.body.r '\0a') ~))))
  ?:  |(=(0 text) (gth (met 3 text) 65.536))
    [%| %qpc-selected-objective-capacity]
  [%& text]
++  make
  |=  [choice=record:controller input=input:pool at=@da nonce=@ux]
  ^-  (each plan @tas)
  ?.  &(=(%chosen phase.choice) (identifier:ct nonce))
    [%| %qpc-selected-choice-required]
  =/  decision=state:d  decision.choice
  ?~  selection.core.decision  [%| %qpc-selected-choice-required]
  ?.  &(=(%selected phase.core.decision) ?=(~ released.decision) ?=(~ result.decision))
    [%| %qpc-selected-choice-closed]
  =/  f=opening:d  frozen.decision
  =/  e=entry:sessions  entry.input
  ?.  ?&  =(session.f id.session.e)  =(owner.f owner.session.e)
          =(source.f working.session.e)  =(configuration.f configuration.e)
          =(%paused phase.e)  ?=(~ pending.e)  ?=(~ calls.e)
          =(grant.f grant.input)  =(key.origin.choice key.input)
      ==  [%| %qpc-selected-session-changed]
  =/  candidate=@ux  `@ux`selected.u.selection.core.decision
  =/  found=(list scored:d)
    (skim candidates.decision |=(v=scored:d =(candidate candidate.admission.evidence.v)))
  ?.  =(1 (lent found))  [%| %qpc-selected-evidence-missing]
  =/  v=scored:d  (snag 0 found)
  ?.  (passed:d admission.evidence.v)  [%| %qpc-selected-ineligible]
  =/  source=grant:ct  grant.scope.origin.choice
  =/  session=@ux  (digest [%session id.decision at nonce])
  =/  request=@ux  (digest [%request id.decision session])
  =/  grant=grant:ct
    [(digest [%grant id.decision session]) session owner.f project.source (silt `(list operation:nc)`~[%patch %compile %check]) ~ max-eval-work.source]
  ?.  ?&  !=(session session.f)  !=(request request.f)  !=(id.grant grant.f)
          (grant-valid:ct owner.f grant)
          (levy ~(tap in operations.grant) |=(op=operation:nc (~(has in operations.source) op)))
      ==  [%| %qpc-selected-grant-refused]
  =/  goal  (objective e)
  ?:  ?=(%| -.goal)  [%| p.goal]
  =/  new=session:nc
    [%native-coding-session-v1 session project.f owner.f source.f directory.session.e p.goal ~]
  =/  begun  (begin:sessions owner.f owner.f at new configuration.f selection.e owner.f source-context.e)
  ?:  ?=(%| -.begun)  [%| p.begun]
  =/  paused  (append:sessions entry.p.begun(phase %paused) at [%status %paused %qpc-selected-execution])
  ?:  ?=(%| -.paused)  [%| p.paused]
  =/  original=record:ct  tool.evidence.v
  =/  tool=tool-request:nc
    [%native-coding-tool-request-v1 [project.f configuration.f session request owner.f source.f] call-id.request.original arguments.request.original]
  [%& [%qpc-selected-plan-v1 id.decision (digest choice) at nonce session.f candidate effect.admission.evidence.v original grant tool entry.p.paused key.input]]
++  plan-valid
  ::  Structural saved-data checks; native readers must rejoin +make to the
  ::  canonical controller and original session before any new effect card.
  |=  p=plan
  ^-  ?
  =/  e=entry:sessions  entry.p
  =/  r=tool-request:nc  request.p
  ?~  result.original.p  %.n
  =/  result=tool-result:nc  u.result.original.p
  ?.  ?=(%candidate -.output.result)  %.n
  =/  candidate=candidate:nc  value.output.result
  ?&  (levy `(list @ux)`~[id.p selection.p nonce.p collection.p candidate.p effect.p] identifier:ct)
      =(%finished stage.original.p)  =(candidate.p id.candidate)
      =(effect.p (effect:d candidate))  =(collection.p session.context.candidate)
      =(context.request.original.p context.candidate)
      =(source.context.candidate working.session.e)
      !=(id.grant.p grant.original.p)
      =(id.session.e (digest [%session id.p at.p nonce.p]))
      =(request.context.r (digest [%request id.p id.session.e]))
      =(id.grant.p (digest [%grant id.p id.session.e]))
      =(session.grant.p id.session.e)  !=(collection.p id.session.e)
      (grant-valid:ct owner.session.e grant.p)
      =(operations.grant.p (silt `(list operation:nc)`~[%patch %compile %check]))
      =(~ inspections.grant.p)  (chain:pool e)  =(%paused phase.e)
      ?=(~ pending.e)  ?=(~ calls.e)  =(0 turn.e)
      =(context.r [project.session.e configuration.e id.session.e request.context.r owner.session.e working.session.e])
      =(arguments.r arguments.request.original.p)  ?=(%patch -.arguments.r)
      !=(%$ key.p)  !=(%$ call-id.r)
      =(2 (lent records.e))
      =([%status %paused %qpc-selected-execution] body:(rear records.e))
  ==
++  begin
  |=  [s=state p=plan]
  ^-  (each state @tas)
  ?:  (~(has by records.s) id.p)  [%| %qpc-selected-already-consumed]
  ?:  (~(has by unavailable.s) id.p)  [%| %qpc-selected-already-refused]
  ?.  (lth ~(wyt by records.s) 64)  [%| %qpc-selected-capacity]
  ?.  (plan-valid p)  [%| %qpc-selected-plan-invalid]
  [%& s(records (~(put by records.s) id.p [p %opening ~ ~ ~]))]
++  admitted
  |=  [r=record m=marker:admit]
  ^-  (each record @tas)
  ?.  =(%opening phase.r)  [%| %qpc-selected-not-opening]
  ?.  &(=(opening.m id.plan.r) =(session.m collection.plan.r))
    [%| %qpc-selected-marker-mismatch]
  [%& r(phase %admitting, marker `m)]
++  consume
  ::  Owner commits this mapping and exact pending/direct registration in
  ::  one Gall event before returning the one Cantrip execute card.
  |=  [r=record choice=record:controller receipt=receipt:admit current=current:d]
  ^-  (each record @tas)
  ?.  =(%admitting phase.r)  [%| %qpc-selected-already-consumed]
  ?.  &(=(selection.plan.r (digest choice)) =(marker.r `request.receipt))
    [%| %qpc-selected-selection-changed]
  =/  found=(list offered:d)
    (skim offered.receipt |=(v=offered:d =(candidate.plan.r candidate.admission.v)))
  ?.  =(1 (lent found))  [%| %qpc-selected-admission-missing]
  =/  released
    (release:d decision.choice candidate.plan.r id.grant.plan.r request.plan.r admission:(snag 0 found) current)
  ?:  ?=(%| -.released)  [%| p.released]
  =/  mapping=mapping:d  +.p.released
  [%& r(phase %sent, mapping `mapping)]
++  unavailable
  |=  [s=state id=@ux reason=@tas]
  ^-  state
  ?.  |((~(has by unavailable.s) id) (lth ~(wyt by unavailable.s) 128))  s
  s(unavailable (~(put by unavailable.s) id reason))
++  recover
  |=  s=state
  ^-  state
  s(records (~(run by records.s) |=(r=record ?:(?=(?(%opening %admitting) phase.r) r(phase %unknown, reason `%qpc-selected-reload-unconfirmed) r))))
++  valid
  |=  s=state
  ^-  ?
  ?&  (lte ~(wyt by records.s) 64)  (lte ~(wyt by unavailable.s) 128)
      (levy ~(tap by unavailable.s) |=([id=@ux reason=@tas] &((identifier:ct id) !=(%$ reason))))
      %+  levy  ~(tap by records.s)
      |=  [id=@ux r=record]
      ?&  =(id id.plan.r)  (plan-valid plan.r)
          ?~  marker.r  ?=(?(%opening %refused %unknown) phase.r)
          &(=(id opening.u.marker.r) =(collection.plan.r session.u.marker.r))
          ?~  mapping.r  !=(%sent phase.r)
          ?&  =(%sent phase.r)  =(id decision.u.mapping.r)
              =(id.u.mapping.r (digest:d u.mapping.r(id 0x0)))
              =(request.plan.r request.u.mapping.r)  =(id.grant.plan.r grant.u.mapping.r)
              =(candidate.plan.r candidate.u.mapping.r)  =(effect.plan.r effect.u.mapping.r)
              =(collection.plan.r collection-session.u.mapping.r)
              =(tool.u.mapping.r (key:ct request.plan.r))
          ==
          ?:  =(%opening phase.r)  &(?=(~ marker.r) ?=(~ mapping.r))
          %.y
          ?:  ?=(?(%opening %admitting %sent) phase.r)  ?=(~ reason.r)
          ?~(reason.r %.n !=(%$ u.reason.r))
      ==
  ==
--
