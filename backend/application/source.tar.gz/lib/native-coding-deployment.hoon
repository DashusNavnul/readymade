::  Owner-governed deployment preparation. Only the Cantrip journal may call
::  lifecycle arms; native Clay builds the complete Gall loadout, never %load.
::  Installation and updates use a fresh private desk for each accepted source.
/-  nc=native-coding
/+  accept=native-coding-accept, project=native-coding-project,
    loadout=gall-loadout-update, private=pataphor-editor-read, guard=viki-scry-guard
|%
+$  grant
  [id=@ux project=project:nc actor=@p apps=(set @tas) updates=?]
+$  scope  [grant=grant revoked=(unit @da)]
+$  request
  [%native-coding-deploy-v1 id=@ux candidate=@ux grant=@ux previous=(unit @ux)]
+$  identity  (map @tas [beak *])
+$  predecessor  [id=@ux source=tree:nc apps=(set @tas)]
+$  app-evidence
  $:  name=@tas  factory=*
      previous=(unit [source=beak factory=* saved=* normalized=*])
      expected=*  effects=(list card:agent:gall)
  ==
+$  rehearsal
  $:  %native-coding-deployment-rehearsal-v1  id=@ux  runtime=tree:nc
      identity=identity  apps=(list app-evidence)
  ==
+$  record
  $:  %native-coding-deployment-record-v1  request=request  grant=grant
      accepted=record:accept  previous=(unit predecessor)
      before=identity  runtime=(unit tree:nc)  rehearsal=(unit rehearsal)
      phase=?(%cloning %overrides %checking %ready %activating %applied %refused %unknown)
      reason=(unit @tas)
  ==
+$  organ  [grants=(map @ux scope) records=(map @ux record)]
+$  change  [next=organ cards=(list card:agent:gall)]
++  digest
  |=  value=*
  ^-  @ux
  (shax (jam [%native-coding-deployment-v1 value]))
++  desk-for
  |=  id=@ux
  ^-  @tas
  `@tas`(cat 3 'nd-' (crip (skip (slag 2 (trip (scot %ux id))) |=(c=@t =(c '.')))))
++  wire-for
  |=  [id=@ux phase=@tas]
  ^-  wire
  /native-deployment/(scot %ux id)/[phase]
++  grant-valid
  |=  [our=@p g=grant]
  ^-  ?
  ?&  !=(0 id.g)  (lte (met 0 id.g) 256)
      (valid:project project.g)  =(our authority.spec.project.g)
      =(our actor.g)  (gte ~(wyt in apps.g) 1)  (lte ~(wyt in apps.g) 8)
      (levy ~(tap in apps.g) |=(app=@tas &((segment-valid:project app) (readable:project project.g /app/[app]/hoon))))
  ==
++  ready
  |=  s=organ
  ^-  ?
  !(lien ~(val by records.s) |=(r=record !?=(?(%applied %refused) phase.r)))
++  valid
  |=  [our=@p s=organ]
  ^-  ?
  ?&  (lte ~(wyt by grants.s) 128)  (lte ~(wyt by records.s) 128)
      (levy ~(tap by grants.s) |=([id=@ux g=scope] &(=(id id.grant.g) (grant-valid our grant.g))))
      %+  levy  ~(tap by records.s)
      |=  [id=@ux r=record]
      ?&  =(id id.request.r)  =(candidate.request.r id.candidate.accepted.r)
          =(grant.request.r id.grant.r)  (grant-valid our grant.r)
          =(project.grant.r project.accepted.r)  =(%applied stage.accepted.r)
          (valid:accept (~(put by *ledger:accept) candidate.request.r accepted.r))
          ?~(rehearsal.r %.y (rehearsal-valid r u.rehearsal.r))
          ?:(?=(?(%ready %activating %applied) phase.r) ?=(^ rehearsal.r) %.y)
      ==
  ==
++  publish
  |=  [our=@p r=record]
  ^-  (list card:agent:gall)
  :~  [%pass /native-deployment-evidence %agent [our %graf] %poke %graf-action !>([%attest [%native-coding-deployment-v1 (digest r) r]])]
      [%pass /native-deployment-status %agent [our %viki] %poke %noun !>([%native-coding-deployment-status-v1 id.request.r r])]
  ==
++  put
  |=  [our=@p s=organ r=record cards=(list card:agent:gall)]
  ^-  change
  [s(records (~(put by records.s) id.request.r r)) (weld (publish our r) cards)]
++  allowed
  |=  [our=@p s=organ r=record]
  ^-  ?
  =/  g  (~(get by grants.s) id.grant.r)
  ?~  g  %.n
  &((grant-valid our grant.r) =(grant.r grant.u.g) =(~ revoked.u.g))
++  domes
  |=  [our=@p at=@da]
  ^-  cone:clay
  .^(cone:clay %cx /(scot %p our)//(scot %da at)/domes)
++  runtime
  |=  [our=@p at=@da r=record]
  ^-  (unit tree:nc)
  =/  desk=@tas  (desk-for id.request.r)
  =/  d  (~(get by (domes our at)) [our desk])
  ?~  d  ~
  ?.  &(=(1 let.u.d) =(~ wic.u.d) (private-path:private our at desk /))  ~
  =/  p=project:nc  project.grant.r(working desk)
  =/  t  (tree-at:project our at p desk 1)
  ?:  ?=(%| -.t)  ~
  =/  landed  landed.accepted.r
  ?~  landed  ~
  ?.  &(=(commit.revision.u.landed commit.revision.p.t) =(root.revision.u.landed root.revision.p.t) =(files.body.snapshot.u.landed files.body.snapshot.p.t))  ~
  `p.t
++  saved
  |=  [our=@p at=@da app=@tas]
  ^-  [source=beak payload=*]
  ?>  (agent-live:guard our at app)
  =/  exported
    .^([version=$?(%16 %20) %live control=* run=* sub=* stats=* incoming=* outgoing=* boar=* code=* saved=[%| value=[type=* noun=*]] source=beak rest=*] %gv /(scot %p our)/[app]/(scot %da at)/$)
  [source.exported noun.value.saved.exported]
++  bill
  |=  [our=@p r=record]
  ^-  (list @tas)
  .^((list @tas) %cx /(scot %p our)/(desk-for id.request.r)/(scot %ud 1)/desk/bill)
++  overrides
  ::  Include the actual bill as well as source app names, so an unselected
  ::  bill entry cannot silently start. The caller reads the bill canonically.
  |=  [r=record bill=(list @tas)]
  ^-  rein:clay
  ?>  ?=(^ landed.accepted.r)
  =/  paths=(list path)  ~(tap in ~(key by files.body.snapshot.u.landed.accepted.r))
  =/  names=(set @tas)
    %-  silt
    %+  murn  paths
    |=  p=path
    ^-  (unit @tas)
    ?:(?=([%app @ %hoon ~] p) `i.t.p ~)
  =.  names  (~(uni in names) (silt bill))
  =.  names  (~(uni in names) apps.grant.r)
  (~(gas by *(map @tas ?)) (turn ~(tap in names) |=(name=@tas [name (~(has in apps.grant.r) name)])))
++  begin
  ::  accepted is a canonical Cantrip acceptance row, never a request payload.
  |=  [b=bowl:gall s=organ q=request accepted=record:accept]
  ^-  change
  ?>  =(our.b src.b)
  ?:  (~(has by records.s) id.q)  [s ~]
  ?>  &((ready s) (lth ~(wyt by records.s) 128) !=(0 id.q) (lte (met 0 id.q) 256))
  =/  found  (~(get by grants.s) grant.q)
  ?>  ?=(^ found)
  =/  g=grant  grant.u.found
  ?>  &((grant-valid our.b g) =(~ revoked.u.found))
  ?>  &(=(candidate.q id.candidate.accepted) =(project.g project.accepted) =(%applied stage.accepted) ?=(^ landed.accepted) (valid:accept (~(put by *ledger:accept) candidate.q accepted)))
  =/  current  (current:project our.b now.b project.g)
  ?>  ?=(%& -.current)
  ?>  =(u.landed.accepted working.p.current)
  =/  rows=inventory:loadout  (capture:loadout our.b src.b now.b)
  =/  previous=(unit predecessor)
    ?~  previous.q  ~
    ?>  updates.g
    =/  old  (~(get by records.s) u.previous.q)
    ?>  ?=(^ old)
    ?>  &(?=(^ runtime.u.old) =(%applied phase.u.old) =(apps.g apps.grant.u.old) =(project.g project.grant.u.old))
    `[u.previous.q u.runtime.u.old apps.g]
  ?>  %+  levy  ~(tap in apps.g)
      |=  app=@tas
      =/  old  (~(get by rows) app)
      ?~  previous  ?=(~ old)
      ?~  old  %.n
      =(desk.revision.source.u.previous q.source.u.old)
  ?>  ?~  previous  %.y
      =/  occupants=(list @tas)
        %+  murn  ~(tap by rows)
        |=  [name=@tas y=yoke:loadout]
        ?:(=(desk.revision.source.u.previous q.source.y) `name ~)
      =((silt occupants) apps.g)
  =/  all  (domes our.b now.b)
  ?>  !(~(has by all) [our.b (desk-for id.q)])
  =/  r=record
    [%native-coding-deployment-record-v1 q g accepted previous (identity:loadout rows) ~ ~ %cloning ~]
  %-  put
  :*  our.b  s  r
      :~  [%pass (wire-for id.q %clone) %arvo %c %merg (desk-for id.q) our.b desk.revision.u.landed.accepted [%ud number.revision.u.landed.accepted] %init]
          [%pass (wire-for id.q %observe) %arvo %c %warp our.b (desk-for id.q) ~ %sing %z [%ud 1] /]
      ==
  ==
++  rehearsal-valid
  |=  [r=record p=rehearsal]
  ^-  ?
  ?&  =(id.request.r id.p)  =(before.r identity.p)  =(runtime.r `runtime.p)
      =((silt (turn apps.p |=(a=app-evidence name.a))) apps.grant.r)
      =((lent apps.p) ~(wyt in apps.grant.r))
      %+  levy  apps.p
      |=  a=app-evidence
      ?~  previous.r  ?=(~ previous.a)
      ?~  previous.a  %.n
      &(=(normalized.u.previous.a expected.a) =((~(get by before.r) name.a) `[source.u.previous.a factory.u.previous.a]))
  ==
++  prepared
  ::  Only an authenticated native thread result reaches this gate.
  |=  [our=@p s=organ id=@ux p=rehearsal]
  ^-  change
  =/  found  (~(get by records.s) id)
  ?~  found  [s ~]
  =/  r=record  u.found
  ?.  =(%checking phase.r)  [s ~]
  ?.  (rehearsal-valid r p)
    (put our s r(phase %unknown, reason `%deployment-rehearsal-mismatch) ~)
  (put our s r(phase %ready, rehearsal `p) ~)
++  observe
  |=  [b=bowl:gall s=organ id=@ux]
  ^-  change
  =/  found  (~(get by records.s) id)
  ?~  found  [s ~]
  =/  r=record  u.found
  ?.  ?=(?(%cloning %overrides) phase.r)  [s (publish our.b r)]
  ?.  (allowed our.b s r)
    (put our.b s r(phase %refused, reason `%deployment-grant-revoked) ~)
  =/  t  (runtime our.b now.b r)
  ?~  t  [s (publish our.b r)]
  =/  d  (~(got by (domes our.b now.b)) [our.b (desk-for id)])
  ?.  =(%dead liv.d)
    (put our.b s r(phase %unknown, reason `%deployment-desk-not-isolated) ~)
  =/  ren=rein:clay  (overrides r (bill our.b r))
  ?:  =(%cloning phase.r)
    ?>  =(~ ren.d)
    %-  put
    :*  our.b  s  r(phase %overrides, runtime t)
        :~  [%pass (wire-for id %overrides) %arvo %c %rein (desk-for id) ren]
            [%pass (wire-for id %observe) %arvo %c %warp our.b (desk-for id) ~ %sing %z [%ud 1] /]
        ==
    ==
  ?.  =(ren ren.d)  [s (publish our.b r)]
  (put our.b s r(phase %checking) ~[[%pass (wire-for id %prepare) %arvo %k %fard q.byk.b %ph-native-coding-deployment %noun !>(`id)]])
++  activate
  ::  Cantrip additionally checks its current law window and other journals.
  ::  This is one normal Clay batch, with no intermediate Gall app removal.
  |=  [b=bowl:gall s=organ id=@ux]
  ^-  change
  ?>  =(our.b src.b)
  =/  r=record  (~(got by records.s) id)
  ?.  =(%ready phase.r)  [s (publish our.b r)]
  ?>  &((allowed our.b s r) ?=(^ rehearsal.r) (rehearsal-valid r u.rehearsal.r))
  ?>  =(before.r (identity:loadout (capture:loadout our.b src.b now.b)))
  ?>  =(runtime.r (runtime our.b now.b r))
  =/  current  (current:project our.b now.b project.grant.r)
  ?>  ?=(%& -.current)
  ?>  =(landed.accepted.r `working.p.current)
  =/  next-dome  (~(got by (domes our.b now.b)) [our.b (desk-for id)])
  ?>  &(=(%dead liv.next-dome) =((overrides r (bill our.b r)) ren.next-dome))
  ?>  %+  levy  apps.u.rehearsal.r
      |=  a=app-evidence
      ?~  previous.a  %.y
      =([source.u.previous.a saved.u.previous.a] (saved our.b now.b name.a))
  =/  changes=(list [desk zest:clay])  ~[[(desk-for id) %live]]
  ?^  previous.r
    =/  old  (~(got by (domes our.b now.b)) [our.b desk.revision.source.u.previous.r])
    ?>  &(=(%live liv.old) =(number.revision.source.u.previous.r let.old))
    =.  changes  [[desk.revision.source.u.previous.r %dead] changes]
    (put our.b s r(phase %activating) ~[[%pass (wire-for id %activate) %arvo %c %zeal changes]])
  (put our.b s r(phase %activating) ~[[%pass (wire-for id %activate) %arvo %c %zeal changes]])
++  verify
  ::  Observation is separate from activation and never sends another zeal.
  ::  Match the complete factory inventory, then actual selected saved data.
  |=  [b=bowl:gall s=organ id=@ux]
  ^-  change
  =/  found  (~(get by records.s) id)
  ?~  found  [s ~]
  =/  r=record  u.found
  ?.  &(=(%activating phase.r) ?=(^ rehearsal.r))  [s (publish our.b r)]
  =/  active-dome  (~(got by (domes our.b now.b)) [our.b (desk-for id)])
  ?.  &(=(%live liv.active-dome) =((overrides r (bill our.b r)) ren.active-dome))
    [s (publish our.b r)]
  =/  rows  (capture:loadout our.b src.b now.b)
  =/  actual=identity  (identity:loadout rows)
  ?:  =(before.r actual)  [s (publish our.b r)]
  =/  expected=(set @tas)  (~(uni in ~(key by before.r)) apps.grant.r)
  ?.  =(expected ~(key by actual))
    (put our.b s r(phase %unknown, reason `%deployment-inventory-mismatch) ~)
  ?.  %+  levy  ~(tap by before.r)
      |=  [name=@tas identity=[beak *]]
      |((~(has in apps.grant.r) name) =(`identity (~(get by actual) name)))
    (put our.b s r(phase %unknown, reason `%unrelated-factory-changed) ~)
  ?.  =(runtime.r (runtime our.b now.b r))
    (put our.b s r(phase %unknown, reason `%runtime-source-changed) ~)
  ?.  %+  levy  apps.u.rehearsal.r
      |=  a=app-evidence
      =/  y  (~(got by rows) name.a)
      =/  retained  (saved our.b now.b name.a)
      ?&  =(our.b p.source.y)  =((desk-for id) q.source.y)
          =(factory.a code.y)  =(expected.a payload.retained)
      ==
    (put our.b s r(phase %unknown, reason `%deployment-state-unconfirmed) ~)
  (put our.b s r(phase %applied, reason ~) ~)
++  cancellation
  ::  Khan fard/lard expose no cancellation handle in this integration.
  |=  r=record
  ^-  [available=? reason=@tas]
  [%.n ?:(?=(?(%applied %refused) phase.r) %already-terminal %native-cancellation-unavailable)]
--
