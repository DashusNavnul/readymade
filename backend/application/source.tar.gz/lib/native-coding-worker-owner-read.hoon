::  Fresh parent authority. No cached permission or model payload grants work.
/-  w=native-coding-worker, nc=native-coding
/+  owner=native-coding-worker-owner, law=native-coding-worker,
    ct=cantrip-native-coding, accept=native-coding-accept,
    allowance=native-coding-check-authorization, project=native-coding-project,
    window=cantrip-law-window, assessment=qpc-native-assessment,
    assessment-read=qpc-native-assessment-read
|%
+$  facts  [candidate=record:accept grant=scope:ct allowance=allowance:allowance]
+$  assessed  [record=record:assessment row=row:assessment]
+$  reader  $-([inner=agent:gall b=bowl:gall id=@ux canonical=?] (each facts @tas))
++  key
  |=  text=@t
  ^-  (unit @ux)
  =/  parsed  (slaw %ux text)
  ?~  parsed  ~
  ?:(&((identifier:law u.parsed) =(text (scot %ux u.parsed))) parsed ~)
++  ordinary
  |=  [inner=agent:gall b=bowl:gall id=@ux]
  ^-  (unit record:accept)
  =/  ag  ~(. inner b(src our.b))
  =/  raw  (payload:allowance (on-peek:ag /x/native-coding/candidate/(scot %ux id)))
  ?~  raw  ~
  =/  parsed  ((soft (unit record:accept)) u.raw)
  ?~  parsed  ~
  ?:(=(u.raw u.parsed) u.parsed ~)
++  assessment-entry
  |=  [inner=agent:gall b=bowl:gall id=@ux]
  ^-  (unit assessed)
  =/  ag  ~(. inner b(src our.b))
  ::  Older inner agents may reject an unknown private path. Their ordinary
  ::  worker records remain usable without installing the optional QPC owner.
  =/  attempt  (mule |.((payload:allowance (on-peek:ag /x/qpc/assessment-candidate/(scot %ux id)))))
  ?:  ?=(%| -.attempt)  ~
  =/  raw  p.attempt
  ?~  raw  ~
  =/  parsed  ((soft (unit assessed)) u.raw)
  ?~  parsed  ~
  ?.  =(u.raw u.parsed)  ~
  ?~  u.parsed  ~
  =/  v=assessed  u.u.parsed
  ?.  =(id id.candidate.row.v)  ~
  ?.  =(`row.v (~(get by rows.record.v) id))  ~
  `v
++  candidate
  ::  A QPC row is private to this worker reader. Ordinary app peeks and its
  ::  acceptance ledger remain unchanged; overlap fails closed.
  |=  [inner=agent:gall b=bowl:gall id=@ux]
  ^-  (unit record:accept)
  =/  normal  (ordinary inner b id)
  =/  managed  (assessment-entry inner b id)
  ?~  managed  normal
  ?^  normal  ~
  `(bridge:assessment record.u.managed row.u.managed)
++  assessment-current
  |=  [inner=agent:gall b=bowl:gall held=assessed]
  ^-  (each facts @tas)
  =/  r=record:assessment  record.held
  =/  v=row:assessment  row.held
  ?.  ?=(?(%staged %sent) phase.v)  [%| %qpc-assessment-not-dispatchable]
  =/  fresh  (read:assessment-read inner b(src our.b) session.pool.binding.r)
  ?:  ?=(%| -.fresh)  [%| p.fresh]
  ?.  =(binding.r binding.p.fresh)  [%| %qpc-assessment-binding-changed]
  =/  ag  ~(. inner b(src our.b))
  =/  raw  (payload:allowance (on-peek:ag /x/native-coding/candidate-ledger))
  ?~  raw  [%| %worker-ledger-unavailable]
  =/  normal  ((soft ledger:accept) u.raw)
  ?~  normal  [%| %worker-ledger-incompatible]
  ?.  (ready-at:accept our.b now.b u.normal)  [%| %worker-unresolved]
  =/  bridge=record:accept  (bridge:assessment r v)
  =/  source  (current:project our.b now.b project.bridge)
  ?:  ?=(%| -.source)  [%| p.source]
  =/  staged  (staged:accept our.b now.b bridge)
  ?:  ?=(%| -.staged)  [%| p.staged]
  ?.  (check-source-ready:accept bridge (malt ~[[id.candidate.v bridge]]) accepted.p.source working.p.source p.staged)
    [%| %worker-source-changed]
  [%& [bridge scope.binding.r [maximum.v ~]]]
++  tool-slot
  |=  raw=*
  ^-  (each ~ @tas)
  ?:  =(%.y raw)  [%| %worker-unresolved]
  ?:  =(%.n raw)  [%& ~]
  [%| %worker-busy-state-incompatible]
++  current
  ::  New work and result acceptance require canonical allowance. Reconcile
  ::  may inspect the just-updated inner wrapper solely to revoke authority.
  |=  [inner=agent:gall b=bowl:gall id=@ux canonical=?]
  ^-  (each facts @tas)
  =/  slot=(each ~ @tas)
    ?.  canonical  [%& ~]
    (tool-slot .^(* %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/worker/tool-busy/noun))
  ?:  ?=(%| -.slot)  [%| p.slot]
  =/  managed  (assessment-entry inner b id)
  ?^  managed
    ?^  (ordinary inner b id)  [%| %worker-candidate-ambiguous]
    (assessment-current inner b u.managed)
  =/  ag  ~(. inner b(src our.b))
  =/  r  (candidate inner b id)
  ?~  r  [%| %worker-candidate-missing]
  ?.  &((check-dispatched:accept u.r) =(id id.candidate.u.r))
    [%| %worker-candidate-not-dispatched]
  =/  raw  (payload:allowance (on-peek:ag /x/native-coding/tool-state))
  ?~  raw  [%| %worker-tools-unavailable]
  =/  jobs  ((soft organ:ct) u.raw)
  ?~  jobs  [%| %worker-tools-incompatible]
  ?.  =(u.raw u.jobs)  [%| %worker-tools-incompatible]
  =/  permission  (candidate-permission:ct our.b now.b u.jobs u.r)
  ?:  ?=(%| -.permission)  [%| p.permission]
  =/  grant  (~(get by grants.u.jobs) grant.u.r)
  ?~  grant  [%| %worker-grant-missing]
  =/  catalog  (catalog:project our.b now.b project.u.r)
  ?:  ?=(%| -.catalog)  [%| p.catalog]
  ?.  &((member:project project.u.r p.catalog our.b %compile) (member:project project.u.r p.catalog our.b %check))
    [%| %worker-membership-refused]
  =/  raw  (payload:allowance (on-peek:ag /x/law/window/current))
  ?~  raw  [%| %worker-law-unavailable]
  =/  law-window  ((soft window:window) u.raw)
  ?~  law-window  [%| %worker-law-incompatible]
  ?.  &((~(has in admissible.u.law-window) %probe) !(~(has in blocked.u.law-window) %probe))
    [%| %worker-law-blocked]
  =/  raw  (payload:allowance (on-peek:ag /x/native-coding/candidate-ledger))
  ?~  raw  [%| %worker-ledger-unavailable]
  =/  ledger  ((soft ledger:accept) u.raw)
  ?~  ledger  [%| %worker-ledger-incompatible]
  ?.  &(=(u.raw u.ledger) =(`u.r (~(get by u.ledger) id)))
    [%| %worker-candidate-changed]
  =/  source  (current:project our.b now.b project.u.r)
  ?:  ?=(%| -.source)  [%| p.source]
  =/  staged  (staged:accept our.b now.b u.r)
  ?:  ?=(%| -.staged)  [%| p.staged]
  ?.  (check-source-ready-with:accept u.r u.ledger accepted.p.source working.p.source p.staged (released-at:accept our.b now.b u.ledger))
    [%| %worker-source-changed]
  =/  allowed=(each allowance:allowance @tas)
    ?:  canonical  (effective:allowance our.b now.b u.r u.grant)
    =/  raw  (payload:allowance (on-peek:ag /x/native-coding/check-authorization/(scot %ux id)))
    ?~  raw  [%| %worker-allowance-unavailable]
    =/  parsed  ((soft (unit (each authorization:allowance @tas))) u.raw)
    ?~  parsed  [%| %worker-allowance-incompatible]
    ?.  =(u.raw u.parsed)  [%| %worker-allowance-incompatible]
    (choose:allowance our.b u.r u.grant u.parsed)
  ?:  ?=(%| -.allowed)  [%| p.allowed]
  [%& [u.r u.grant p.allowed]]
++  scope
  |=  [p=pairing:w f=facts]
  (scope:owner p candidate.f grant.f allowance.f)
--
