::  /lib/cantrip-schema.hoon
::
::  The entity schema -- DATA, not code. In the generic substrate an entity kind
::  is just a tag; recording and search are kind-agnostic. So "the schema" is a
::  registry of the valid fact kinds + relation kinds the fleet uses, with
::  membership predicates. cantrip validates a %record's kind against it (reject
::  unknown kinds) without any per-entity handler. Adding a new entity = one line
::  here, never new dispatch/projection code.
::
|%
++  kinds
  ^-  (set @tas)
  %-  silt
  ^-  (list @tas)
  :~  %cast  %trace  %loom-turn  %fork-record  %fold-marker  %reward-update
      %fold-threshold  %trim-manifest  %retry-record  %continuity-session
      %secret-field-policy  %streaming-event  %usage-reconciliation  %child-circle
      %child-call-result  %governed-step  %runtime-decision  %execution-status
      %self-audit  %proof-bundle  %promotion  %rollback  %continuation  %task-open
      %task-result  %dispatch  %verdict  %crossing  %authority  %soul  %law-state
      %pataphor-goal  %task-graph  %agent-graph  %familiar  %controlled-agency-verdict
      %mp-move  %governance-event  %native-result  %pataphor-user-goal  %intake-verdict
      %planning-request  %goal-agent-graph-link  %goal-replay  %goal-lifecycle-event
      %goal-lifecycle-readback  %identity  %cantrip-definition  %circle-definition
      %viki-verdict  %model-proposal  %ca-policy  %ca-evidence
      %moon-link-proof  %moon-link-verdict
      %goal  %node  %controlled-agency-run
      ::  law-loop residue kinds: verify outcomes feed the sensor bands; rivals/
      ::  blockers gate promotion; ratification is the recorded principal act.
      %verify-pass  %verify-failure  %rival  %rival-resolved
      %blocker  %blocker-cleared  %ratification  %health-sample
      ::  every host-effect admission %hand consumes is recorded back (inert:
      ::  the receipt never moves the law that produced it).
      %host-admission
      ::  canon prescriptions bind a %purpose node to an engraved %law
      ::  (sur/canon-law +prescribe).
      %purpose  %law
      ::  synthesized Jock programs and the verdicts that admitted them.
      ::  A %jock-program is recorded WITH its judgments, never alone:
      ::  the program is not the claim, the passing verdicts are
      ::  (lib/jock-judge +proven, program-2 steps 52/53).
      %jock-program  %jock-judgment
  ==
++  relation-kinds
  ^-  (set @tas)
  %-  silt
  ^-  (list @tas)
  :~  %has-node  %precedes  %of  %proven  %status  %repaired  %turn  %summoned
      %ran-by  %follows  %verifies  %repairs  %approves  %contradicts  %parent
      %fork-origin  %entity  %session  %seat  %proof-handle  %canon  %rival
      %moon  %controlled-agency-run  %recall  %continuation  %promotion  %needs-user
      %next  %attested-by  %contradicted-by  %world  %calls  %deleg  %sent
      %loop-step  %spawned  %spawn  %bound-by
  ==
++  valid-kind      |=(k=@tas (~(has in kinds) k))
++  valid-relation  |=(k=@tas (~(has in relation-kinds) k))
++  kind-count      `@ud`~(wyt in kinds)
--
