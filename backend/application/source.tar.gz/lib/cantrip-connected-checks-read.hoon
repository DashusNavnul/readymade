::  App-owned checks/compilation/write/editor journals are explicit inputs.
::  They are NOT authenticated merely by decoding this library's molds.
::  No checks endpoint exists until a future Cantrip hook installs the ledger.
/+  core=cantrip-connected-checks, read=vibecoding-connected-preview-read,
    preview=vibecoding-local-preview, law=cantrip-law-window,
    vsg=viki-scry-guard
|%
++  from-owned
  ::  Called inside Cantrip: no recursive Cantrip journal/law scry.
  ::  A repeated exact nonce returns the retained run before any fresh read.
  |=  [our=@p actor=@p at=@da held=ledger:core c=command:core own=owned-v2:read window=window:law]
  ^-  (each transition:core @tas)
  =/  prior  (lookup:core our actor at held c)
  ?:  ?=(%| -.prior)  [%| p.prior]
  ?^  p.prior  [%& [held u.p.prior %.y]]
  ?:  (gte ~(wyt by held) 128)  [%| %capacity]
  =/  found  (mule |.((context-v2:read our actor at write.c own)))
  ?:  ?=(%| -.found)  [%| %current-read-unavailable]
  ?:  ?=(%| -.p.found)  [%| p.p.found]
  =/  e=evidence-v2:read  p.p.found
  (start:core our actor at held c attempt.e view.e rows.e stated.e window)
++  current
  ::  External callers may load existing canonical compiler/write journals.
  ::  This returns only a current admission, never execution or saved checks.
  |=  [our=@p actor=@p at=@da c=command:core]
  ^-  decision:preview
  ?.  =(our actor)  [%| %foreign-actor]
  ?.  (command-valid:core c)  [%| %binding-invalid]
  ?.  (agent-live:vsg our at %cantrip)  [%| %agent-unavailable]
  =/  window=window:law
    .^(window:law %gx /(scot %p our)/cantrip/(scot %da at)/law/window/current/noun)
  (read-v2:read our actor at write.c image.c window)
++  observe-owned
  ::  Own ledger authenticates the original result; read failures only make
  ::  that immutable result stale. Neither this arm nor reload runs Nock.
  |=  [our=@p actor=@p at=@da held=ledger:core c=command:core own=owned-v2:read window=window:law]
  ^-  (each observation:core @tas)
  =/  prior  (lookup:core our actor at held c)
  ?:  ?=(%| -.prior)  [%| p.prior]
  ?~  p.prior  [%| %checks-missing]
  =/  r=record:core  u.p.prior
  =/  attempt  attempt.own
  =/  same=?
    ?~  attempt  %.n
    ?~  record.u.attempt  %.n
    =(compilation.r u.record.u.attempt)
  =/  decision=decision:preview
    ?.  same  [%| %binding-invalid]
    (from-owned-v2:read our actor at write.c image.c own window)
  (observe:core our actor at held c decision)
--
