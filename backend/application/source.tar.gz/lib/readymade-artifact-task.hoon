::  Exact retained task/check/review projection. No state or effects.
/-  nc=native-coding, c=readymade-collab, pkg=readymade-package,
    r=readymade-artifact-round
/+  execution=readymade-artifact-executor-types,
    history=readymade-artifact-history, package=readymade-package,
    build=readymade-package-build, accept=native-coding-accept,
    files=native-coding-files, utf8=native-coding-source-text, guard=viki-scry-guard,
    mg=readymade-app-management
|%
+$  command  [owner=@p peer=@p nonce=@ux]
+$  excerpt  [body=@t bytes=@ud shown=@ud truncated=?]
::  Structural copy of native-coding-review.entry avoids importing the entire
::  Viki/Cantrip execution orchestration into a read-only metadata helper.
+$  review-entry
  $:  candidate=candidate:nc  objective=@t  model=@t
      workspace=(unit @tas)  observed=(unit record:accept)
      decision=(unit decision:accept)  advanced=?
  ==
+$  context  [command=command held=entry:execution item=package:c]
++  object  object:history
++  put  put:history
++  bounded
  ::  Byte cap on a UTF-8 boundary; ordinary detail is presentation only.
  |=  [body=@t cap=@ud]
  ^-  excerpt
  =/  n=@ud  (min cap (met 3 body))
  |-  ^-  excerpt
  ?:  |(=(0 n) =(n (met 3 body)))
    [(end [3 n] body) (met 3 body) n (lth n (met 3 body))]
  =/  byte=@  (cut 3 [n 1] body)
  ?:  &((gte byte 128) (lte byte 191))  $(n (dec n))
  [(end [3 n] body) (met 3 body) n (lth n (met 3 body))]
++  decode
  |=  raw=@t
  ^-  command
  =/  value=json  (need (de:json:html raw))
  ?>  ?=(%o -.value)
  =/  obj=(map @t json)  p.value
  ?>  =((silt `(list @t)`~['schema' 'owner' 'peer' 'nonce']) ~(key by obj))
  ?>  =('readymade-artifact-task-command-v1' (text-field:mg obj 'schema' 64))
  =/  own=@t  (text-field:mg obj 'owner' 128)
  =/  other=@t  (text-field:mg obj 'peer' 128)
  =/  owner=@p  (need (slaw %p own))
  =/  peer=@p  (need (slaw %p other))
  ?>  &(=(own (scot %p owner)) =(other (scot %p peer)) !=(owner peer))
  ?>  &((lte (met 0 owner) 128) (lte (met 0 peer) 128))
  =/  raw-nonce=@t  (text-field:mg obj 'nonce' 82)
  =/  nonce=@ux  (need (slaw %ux raw-nonce))
  ?>  &((digest-valid:package nonce) =(raw-nonce (scot %ux nonce)))
  [owner peer nonce]
++  parse
  |=  raw=@t
  ^-  (unit command)
  ?.  (lte (met 3 raw) 1.024)  ~
  (mole |.((decode raw)))
++  read-request
  |=  req=inbound-request:eyre
  ^-  (unit command)
  =/  raw  (header:mg header-list.request.req 'x-readymade-task-command')
  ?~  raw  ~
  (parse u.raw)
++  prepare
  |=  [our=@p actor=@p cmd=command entries=journal:execution packages=(map @ux package:c)]
  ^-  (each context @tas)
  ?.  &(=(our actor) =(our owner.cmd) !=(our peer.cmd))  [%| %owner-required]
  =/  got  (~(get by entries) nonce.cmd)
  ?~  got  [%| %task-execution-missing]
  =/  held=entry:execution  u.got
  ?.  &((entry-valid:execution our held) =(nonce.cmd (key:execution command.held)) =(peer.cmd peer.command.held))
    [%| %task-execution-binding]
  =/  receipt=receipt:build  receipt.selection.held
  =/  offer=offer:pkg  offer.plan.body.receipt
  =/  item  (~(get by packages) digest.offer)
  ?~  item  [%| %task-package-missing]
  ?.  &(=(offer offer.value.u.item) (valid:package offer))  [%| %task-package-binding]
  ?.  &((utf8:files instructions.body.offer) (lte (met 3 instructions.body.offer) 4.096))
    [%| %task-instructions-invalid]
  [%& [cmd held u.item]]
++  revision-json
  |=  rev=revision:nc
  ^-  json
  (object ~[['owner' s+(scot %p owner.rev)] ['desk' s+(scot %tas desk.rev)] ['revision' s+(decimal:history number.rev)] ['root' s+(scot %ux `@ux`root.rev)] ['commit' s+(scot %ux `@ux`commit.rev)]])
++  candidate-bound
  |=  [ctx=context record=record:accept]
  ^-  ?
  =/  held=entry:execution  held.ctx
  =/  cmd=command:execution  command.held
  =/  proposal=proposal:r  proposal.selection.held
  =/  target=target:r  target.proposal
  ?.  ?=(%land -.target)  %.n
  =/  candidate=candidate:nc  candidate.record
  ?.  ?&  ?=(^ candidate.held)  =(u.candidate.held id.candidate)
          (valid:accept (malt ~[[id.candidate record]]))
          =((candidate-digest:files candidate) id.candidate)
          =(owner.cmd actor.context.candidate)
          =(session.cmd session.context.candidate)
          =((key:execution cmd) request.context.candidate)
          =(owner.cmd owner.source.context.candidate)
          =(desk.target desk.source.context.candidate)
          =(revision.target number.source.context.candidate)
          =(root.target root.source.context.candidate)
          ?=([* ~] edits.candidate)
      ==  %.n
  =/  edit=edit:nc  i.edits.candidate
  ?.  &(=(file.target path.change.edit) ?=(^ content.edit))  %.n
  =/  content=replacement:nc  u.content.edit
  =/  offered=(list file:pkg)  files.body.offer.plan.body.receipt.selection.held
  ?.  ?=([* ~] offered)  %.n
  &(=(%hoon mark.content) =(i.offered (source-file:package path.i.offered source.content)))
++  check-json
  |=  [target=build-target:nc diag=diagnostic:nc spec=(unit [name=@tas expression=@t]) compiled=?]
  ^-  json
  =/  excerpt=excerpt  (bounded detail.diag 512)
  =/  outcome=@t  ?~(spec ?:(passed.diag 'passed' 'failed') ?:(!compiled 'not-run' ?:(passed.diag 'passed' 'failed')))
  (object ~[['target' s+name.target] ['entry' s+(spat entry.target)] ['name' s+name.diag] ['kind' s+?~(spec 'compile' 'configured-check')] ['outcome' s+outcome] ['expressionDigest' ?~(spec ~ s+(scot %ux (shax expression.u.spec)))] ['source' (revision-json source.diag)] ['detail' s+body.excerpt] ['detailBytes' (numb:enjs:format bytes.excerpt)] ['detailTruncated' b+truncated.excerpt] ['artifacts' a+(turn artifacts.diag |=(v=@ux s+(scot %ux v)))]])
++  target-checks
  ::  Classification is by position, not by name: a configured check can be
  ::  named 'compile' and configured names need not be unique.
  |=  result=target-result:accept
  ^-  (list json)
  ?>  ?=(^ diagnostics.result)
  =/  compiled=diagnostic:nc  i.diagnostics.result
  :-  (check-json target.result compiled ~ passed.compiled)
  =/  specs=(list [name=@tas expression=@t])  checks.target.result
  =/  diagnostics=(list diagnostic:nc)  t.diagnostics.result
  |-  ^-  (list json)
  ?~  specs  ~
  ?>  ?=(^ diagnostics)
  [(check-json target.result i.diagnostics `i.specs passed.compiled) $(specs t.specs, diagnostics t.diagnostics)]
++  review-json
  |=  [record=record:accept observed=(unit review-entry)]
  ^-  json
  ?~  observed  (object ~[['status' s+'unavailable'] ['reason' s+'native-review-missing']])
  =/  review=review-entry  u.observed
  ?.  &(=(candidate.review candidate.record) =(observed.review `record))
    (object ~[['status' s+'unavailable'] ['reason' s+'native-review-observation-mismatch']])
  ?.  &(=(decision.review decision.record) (lte (met 3 objective.review) 65.536))
    (object ~[['status' s+'unavailable'] ['reason' s+'native-review-decision-mismatch']])
  ?.  (valid:utf8 objective.review)
    (object ~[['status' s+'unavailable'] ['reason' s+'native-review-objective-invalid']])
  =/  objective=excerpt  (bounded objective.review 2.048)
  (object ~[['status' s+'verified'] ['objectiveDigest' s+(scot %ux (shax objective.review))] ['objective' s+body.objective] ['objectiveBytes' (numb:enjs:format bytes.objective)] ['objectiveTruncated' b+truncated.objective] ['decision' ?~(decision.review ~ s+(scot %tas verdict.u.decision.review))] ['decisionDigest' ?~(decision.review ~ s+(scot %ux (digest:accept u.decision.review)))] ['reason' ?~(decision.review ~ s+body:(bounded reason.challenge.u.decision.review 512))] ['recordDigest' s+(scot %ux (shax (jam review)))]])
++  evidence-json
  |=  [ctx=context accepted=(unit record:accept) review=(unit review-entry)]
  ^-  json
  ?~  candidate.held.ctx  (object ~[['status' s+'unavailable'] ['reason' s+'task-candidate-not-retained']])
  ?~  accepted  (object ~[['status' s+'unavailable'] ['reason' s+'native-candidate-missing']])
  =/  record=record:accept  u.accepted
  ?.  (candidate-bound ctx record)  (object ~[['status' s+'unavailable'] ['reason' s+'task-candidate-binding']])
  =/  result=json
    (object ~[['status' s+'verified'] ['candidate' s+(scot %ux id.candidate.record)] ['source' (revision-json source.context.candidate.record)] ['stage' s+(scot %tas stage.record)] ['reason' ?~(reason.record ~ s+(scot %tas u.reason.record))] ['checkedSource' ~] ['reportDigest' ~] ['checks' a+~] ['configuredCheckCount' (numb:enjs:format 0)] ['configuredChecksOutcome' s+'not-run'] ['review' (review-json record review)] ['landed' ?~(landed.record ~ (revision-json revision.u.landed.record))] ['recordDigest' s+(scot %ux (digest:accept record))]])
  =/  cmd=command:execution  command.held.ctx
  =/  proposal=proposal:r  proposal.selection.held.ctx
  =.  result  (put result 'nonce' s+(scot %ux (key:execution cmd)))
  =.  result  (put result 'session' s+(scot %ux session.cmd))
  =.  result  (put result 'selected' s+(scot %ux selected.cmd))
  =.  result  (put result 'package' s+(scot %ux package.proposal))
  =.  result  (put result 'artifact' s+(scot %ux artifact.proposal))
  =.  result  (put result 'buildProof' s+(scot %ux build-proof.proposal))
  ?~  report.record  result
  =/  report=report:accept  u.report.record
  =/  total=@ud  (roll targets.report |=([r=target-result:accept n=@ud] (add n (lent diagnostics.r))))
  ?.  (lte total 64)  (object ~[['status' s+'unavailable'] ['reason' s+'task-check-count-limit']])
  ?.  %+  levy  targets.report
      |=  r=target-result:accept
      ?&  (lte (met 3 name.target.r) 128)  (valid:utf8 name.target.r)
          (lte (lent diagnostics.r) 33)
          %+  levy  diagnostics.r
          |=  d=diagnostic:nc
          &((lte (met 3 name.d) 128) (valid:utf8 name.d) (valid:utf8 detail.d))
      ==
    (object ~[['status' s+'unavailable'] ['reason' s+'task-check-text-invalid']])
  =/  configured=@ud  (roll targets.report |=([r=target-result:accept n=@ud] (add n (lent checks.target.r))))
  =/  compiled=?
    %+  levy  targets.report
    |=  r=target-result:accept
    ?~  diagnostics.r  %.n
    passed.i.diagnostics.r
  =/  outcome=@t
    ?:  =(0 configured)  'not-configured'
    ?:  !compiled  'not-run-or-incomplete'
    ?:((passed:accept report) 'passed' 'failed')
  =.  result  (put result 'checkedSource' (revision-json revision.staging.report))
  =.  result  (put result 'reportDigest' s+(scot %ux (digest:accept report)))
  =.  result  (put result 'checks' a+(zing (turn targets.report target-checks)))
  =.  result  (put result 'configuredCheckCount' (numb:enjs:format configured))
  (put result 'configuredChecksOutcome' s+outcome)
++  project
  |=  [ctx=context accepted=(unit record:accept) review=(unit review-entry)]
  ^-  (each json @tas)
  =/  held=entry:execution  held.ctx
  =/  offer=offer:pkg  offer.plan.body.receipt.selection.held
  =/  row=json  (execution-row:history owner.command.ctx held)
  =.  row  (put row 'schema' s+'readymade-artifact-task-v1')
  =.  row  (put row 'instructions' s+instructions.body.offer)
  =.  row  (put row 'instructionsDigest' s+(scot %ux (shax instructions.body.offer)))
  =.  row  (put row 'instructionFormat' s+'original-text')
  =.  row  (put row 'grafRoot' s+(scot %ux graf-root.body.offer))
  =.  row  (put row 'manifest' s+(scot %ux (manifest:package files.body.offer)))
  =.  row  (put row 'title' s+title.item.ctx)
  =.  row  (put row 'evidence' (evidence-json ctx accepted review))
  =/  encoded=@t  (en:json:html row)
  ?.  (lte (met 3 encoded) 65.536)  [%| %task-response-limit]
  [%& row]
++  wrapper-data
  ::  Every step follows a known production save wrapper. Its nested VASE is
  ::  a cell [TYPE DATA]; TYPE is opaque and never recursively validated.
  |=  [raw=* tags=(list @tas)]
  ^-  (unit *)
  ?~  tags  `raw
  =/  inner=(unit *)
    ?:  =(%shoe-app i.tags)
      =/  p  ((soft ,[tag=@tas inner=* held=*]) raw)
      ?~  p  ~
      ?.  =(tag.u.p i.tags)  ~
      `inner.u.p
    ?:  |(=(%native-coding-worker-tool-save-v2 i.tags) =(%native-coding-worker-parent-save-v2 i.tags))
      =/  p  ((soft ,[tag=@tas one=* two=* inner=*]) raw)
      ?~  p  ~
      ?.  =(tag.u.p i.tags)  ~
      `inner.u.p
    ?:  =(%qpc-instrument-v5 i.tags)
      =/  p  ((soft ,[tag=@tas held=* ordered=* laws=* successors=* refresh=(unit @da) selected=* inner=*]) raw)
      ?~  p  ~
      ?.  =(tag.u.p i.tags)  ~
      `inner.u.p
    ?:  =(%qpc-instrument-v4 i.tags)
      =/  p  ((soft ,[tag=@tas held=* ordered=* laws=* successors=* refresh=(unit @da) inner=*]) raw)
      ?~  p  ~
      ?.  =(tag.u.p i.tags)  ~
      `inner.u.p
    ?:  |(=(%qpc-instrument-v3 i.tags) =(%qpc-observer-v3 i.tags) =(%qpc-session-gate-v2 i.tags))
      =/  p  ((soft ,[tag=@tas one=* two=* three=* inner=*]) raw)
      ?~  p  ~
      ?.  =(tag.u.p i.tags)  ~
      `inner.u.p
    =/  p  ((soft ,[tag=@tas held=* inner=*]) raw)
    ?~  p  ~
    ?.  =(tag.u.p i.tags)  ~
    `inner.u.p
  ?~  inner  ~
  ?@  u.inner  ~
  $(raw +.u.inner, tags t.tags)
++  optional-wrappers
  ::  Only known leading wrappers may be absent on older installed builds.
  ::  Never walk nested TYPEs or skip an unknown wrapper to find a registry.
  |=  [raw=* tags=(list @tas)]
  ^-  (unit *)
  ?~  tags  `raw
  ?@  raw  ~
  ?.  =(i.tags -.raw)  $(tags t.tags)
  =/  inner  (wrapper-data raw ~[i.tags])
  ?~  inner  ~
  $(raw u.inner, tags t.tags)
++  saved-registry
  ::  Known direct-DATA versions keep the previous state in field two.
  ::  Other held fields remain opaque. Only the final registry is decoded.
  |=  [raw=* tags=(list @tas)]
  ^-  (unit *)
  ?~  tags  ~
  =/  p  ((soft ,[tag=@tas previous=* held=*]) raw)
  ?~  p  ~
  ?.  =(tag.u.p i.tags)  ~
  ?~  t.tags  `held.u.p
  $(raw previous.u.p, tags t.tags)
++  flow-data
  ::  After the optional campaign, flow must match the app reader role.
  |=  [raw=* who=?(%viki %cantrip)]
  ^-  (unit *)
  ?.  ?=([%qpc-flow-owner-v1 *] raw)  `raw
  =/  parsed  ((soft ,[%qpc-flow-owner-v1 role=?(%viki %cantrip) held=* inner=[type=* noun=*]]) raw)
  ?~  parsed  ~
  ?.  =(who role.u.parsed)  ~
  `noun.inner.u.parsed
++  cantrip-registry
  |=  raw=*
  ^-  (unit *)
  =/  flowed  (flow-data raw %cantrip)
  ?~  flowed  ~
  =/  raw=*  u.flowed
  =/  outer
    (optional-wrappers raw ~[%native-coding-worker-tool-save-v2 %native-coding-worker-parent-save-v2 %qpc-admission-owner-v1 %qpc-assessment-owner-v1])
  ?~  outer  ~
  =/  inner  (wrapper-data u.outer ~[%native-coding-check-authorizations-v1])
  ?~  inner  ~
  =/  peeled=(unit *)
    ?.  ?=([%qpc-session-gate-v2 *] u.inner)  inner
    (wrapper-data u.inner ~[%qpc-session-gate-v2])
  ?~  peeled  ~
  (saved-registry u.peeled ~[%cantrip-judge-state-v40 %cantrip-judge-state-v39 %cantrip-judge-state-v38 %cantrip-judge-state-v37 %cantrip-judge-state-v36 %cantrip-judge-state-v35 %cantrip-judge-state-v34 %cantrip-judge-state-v33 %cantrip-judge-state-v32 %cantrip-judge-state-v31 %cantrip-judge-state-v30 %cantrip-judge-state-v29 %cantrip-judge-state-v28 %cantrip-judge-state-v27 %cantrip-judge-state-v26 %cantrip-judge-state-v25 %cantrip-judge-state-v24 %cantrip-judge-state-v23 %cantrip-judge-state-v22 %cantrip-judge-state-v21])
++  viki-registry
  |=  raw=*
  ^-  (unit *)
  =/  campaign  (optional-wrappers raw ~[%qpc-readiness-owner-v1 %qpc-task-onboard-owner-v3 %qpc-campaign-owner-v1])
  ?~  campaign  ~
  =/  flowed  (flow-data u.campaign %viki)
  ?~  flowed  ~
  =/  raw=*  u.flowed
  =/  owners
    (optional-wrappers raw ~[%qpc-selected-owner-v1 %qpc-controller-owner-v1 %qpc-prospective-owner-v1 %qpc-native-declaration-owner-v1])
  ?~  owners  ~
  =/  law  (wrapper-data u.owners ~[%qpc-law-owner-v2])
  ?~  law  ~
  =/  outer
    ?:  ?=([%qpc-instrument-v5 *] u.law)
      (wrapper-data u.law ~[%qpc-instrument-v5])
    ?:  ?=([%qpc-instrument-v4 *] u.law)
      (wrapper-data u.law ~[%qpc-instrument-v4])
    (wrapper-data u.law ~[%qpc-instrument-v3])
  ?~  outer  ~
  =/  review
    ((soft ,[tag=?(%native-local-review-owner-v2 %native-local-review-owner-v3) held=* inner=*]) u.outer)
  ?~  review  ~
  ?@  inner.u.review  ~
  =/  inner  (wrapper-data +.inner.u.review ~[%qpc-stream-v1 %qpc-observer-v3 %qpc-session-gate-v2 %shoe-app])
  ?~  inner  ~
  (saved-registry u.inner ~[%viki-familiar-state-v30 %viki-familiar-state-v29 %viki-familiar-state-v28 %viki-familiar-state-v27 %viki-familiar-state-v26 %viki-familiar-state-v25 %viki-familiar-state-v24 %viki-familiar-state-v23 %viki-familiar-state-v22 %viki-familiar-state-v21 %viki-familiar-state-v20 %viki-familiar-state-v19])
++  saved-data
  ::  %gv /$ is Gall's own always-defined metadata surface for a live app.
  ::  This extracts original saved DATA, never an executable core or TYPE.
  |=  [b=bowl:gall app=@tas]
  ^-  (unit *)
  ?.  &(=(our.b src.b) (agent-live:guard our.b now.b app))  ~
  =/  raw=egg-any:gall
    .^(egg-any:gall %gv /(scot %p our.b)/[app]/(scot %da now.b)/$)
  ?.  ?=(%20 -.raw)  ~
  =/  current=egg:gall  +.raw
  ?.  ?=(%live -.current)  ~
  =/  original=vase  +.old-state.current
  `q.original
++  registry-row
  ::  Visit at most 128 nodes before decoding a selected record. Unknown DATA
  ::  cannot cause an unbounded recursive map mold traversal.
  |=  [raw=(unit *) id=@ux]
  ^-  (unit *)
  ?~  raw  ~
  =/  todo=(list *)  ~[u.raw]
  =|  seen=(set @ux)
  =|  count=@ud
  =|  found=(unit *)
  |-  ^-  (unit *)
  ?~  todo  found
  ?:  =(0 i.todo)  $(todo t.todo)
  ?:  (gte count 128)  ~
  =/  node  ((soft ,[n=[p=@ux q=*] l=* r=*]) i.todo)
  ?~  node  ~
  ?.  &((digest-valid:package p.n.u.node) !(~(has in seen) p.n.u.node))  ~
  $(todo [l.u.node r.u.node t.todo], seen (~(put in seen) p.n.u.node), count +(count), found ?:(=(id p.n.u.node) `q.n.u.node found))
++  bounded-record
  ::  Bound cells and aggregate atom bytes before any recursive row mold.
  |=  raw=*
  ^-  ?
  =/  todo=(list *)  ~[raw]
  =|  cells=@ud
  =|  bytes=@ud
  |-  ^-  ?
  ?:  |((gth cells 131.072) (gth bytes 4.194.304))  %.n
  ?~  todo  %.y
  ?@  i.todo
    $(todo t.todo, bytes (add bytes (met 3 i.todo)))
  $(todo [-.i.todo +.i.todo t.todo], cells +(cells))
++  read
  |=  [b=bowl:gall ctx=context]
  ^-  (each json @tas)
  ?~  candidate.held.ctx  (project ctx ~ ~)
  =/  id=@ux  u.candidate.held.ctx
  =/  raw  (saved-data b %cantrip)
  =/  accepted=(unit record:accept)
    ?~  raw  ~
    =/  row  (registry-row (cantrip-registry u.raw) id)
    ?~  row  ~
    ?.  (bounded-record u.row)  ~
    ((soft record:accept) u.row)
  =/  raw  (saved-data b %viki)
  =/  reviewed=(unit review-entry)
    ?~  raw  ~
    =/  row  (registry-row (viki-registry u.raw) id)
    ?~  row  ~
    ?.  (bounded-record u.row)  ~
    ((soft review-entry) u.row)
  (project ctx accepted reviewed)
--
