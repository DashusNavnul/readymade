::  Finite native Spider waiter. No local Ford fallback after worker selection.
::  Compiled fields remain opaque data through the existing archive command.
/-  spider, nc=native-coding, x=native-coding-worker-work, v3=native-coding-worker-work-v3
/+  strandio, owner=native-coding-worker-tool-owner,
    parent=native-coding-worker-owner-runtime, work=native-coding-worker-work,
    source=native-coding-worker-tool-source, archive=native-coding-hoon-artifact,
    ct=cantrip-native-coding, work-v3=native-coding-worker-work-v3,
    source-v3=native-coding-worker-tool-source-v3
=,  strand=strand:spider
|%
++  engaged
  |=  [our=@p now=@da]
  ^-  ?
  =/  chosen=state:parent
    .^(state:parent %gx /(scot %p our)/cantrip/(scot %da now)/native-coding/worker/state/noun)
  engaged.chosen
++  selected
  |=  [our=@p now=@da o=tool-order:x]
  ^-  ?
  =/  chosen=state:parent
    .^(state:parent %gx /(scot %p our)/cantrip/(scot %da now)/native-coding/worker/state/noun)
  &(engaged.chosen =(`pairing.o pairing.owner.chosen))
++  run
  |=  [id=@ux i=input:archive scope=scope:ct]
  =/  m  (strand ,vase)
  ^-  form:m
  =/  r=tool-request:nc  request.i
  =/  refused
    |=  reason=@tas
    (pure:m !>((refusal:ct r reason 'The selected native worker could not provide an authorized result.')))
  ;<  initial=bowl:spider  bind:m  get-bowl:strandio
  =/  chosen=state:parent
    .^(state:parent %gx /(scot %p our.initial)/cantrip/(scot %da now.initial)/native-coding/worker/state/noun)
  ?~  pairing.owner.chosen  (refused %worker-not-selected)
  ?.  .^(? %gx /(scot %p our.initial)/cantrip/(scot %da now.initial)/native-coding/worker/tool-room/(scot %ux id)/noun)
    (refused %worker-tool-capacity)
  ;<  ~  bind:m
    (poke-our:strandio %cantrip %noun !>([%native-coding-worker-tool-start-v1 id]))
  ;<  ~  bind:m
    (watch-our:strandio /native-worker-tool-result %cantrip (result-path:owner id))
  ;<  v=row:owner  bind:m
    =/  m  (strand ,row:owner)
    |-  ^-  form:m
    ;<  c=cage  bind:m  (take-fact:strandio /native-worker-tool-result)
    ?>  =(%noun p.c)
    ?>  (lte (met 3 (jam q.q.c)) 8.650.752)
    =/  parsed  ((soft ,(unit row:owner)) q.q.c)
    ?>  &(?=(^ parsed) =(u.parsed q.q.c))
    ?~  u.parsed  $
    =/  v=row:owner  u.u.parsed
    ?>  =(r request.v)
    ?.  (terminal:owner v)  $
    (pure:m v)
  ?^  failure.v
    ?:  unknown.u.failure.v
      (pure:m !>(`tool-result:nc`[%native-coding-tool-result-v1 context.r call-id.r [%unknown reason.u.failure.v 'Remote work is unconfirmed; no build was repeated.']]))
    (refused reason.u.failure.v)
  ?>  &(?=(^ order.v) ?=(^ result.v))
  ?>  ?=(%native-coding-worker-order-v2 -.u.order.v)
  ?>  ?=(%native-coding-worker-result-v2 -.u.result.v)
  =/  o=tool-order:x  u.order.v
  =/  result=tool-result:x  u.result.v
  ?.  &((result-matches:work o result) =(request.purpose.o r) =(input.purpose.o (input-digest:work i)) =(scope.purpose.o (scope-digest:archive scope)))
    (refused %worker-tool-retained-result-mismatch)
  ?:  ?=(%refused -.outcome.result)  (refused reason.outcome.result)
  ?>  ?=(%tool -.outcome.result)
  ;<  b=bowl:spider  bind:m  get-bowl:strandio
  ?.  (selected our.b now.b o)  (refused %worker-tool-selection-changed)
  =/  fresh  (current:source our.b now.b o)
  ?.  =([%& i] fresh)  (refused %worker-tool-authority-changed)
  ?~  built.outcome.result  (pure:m !>(report.outcome.result))
  =/  made  (make-data:archive i (scope-digest:archive scope) u.built.outcome.result)
  ?:  ?=(%| -.made)  (refused p.made)
  ;<  ~  bind:m
    (poke-our:strandio %cantrip %noun !>(`command:archive`[%native-coding-hoon-artifact-retain-v1 id p.made]))
  ;<  after=bowl:spider  bind:m  get-bowl:strandio
  =/  saved=(unit artifact:archive)
    .^((unit artifact:archive) %gx /(scot %p our.after)/cantrip/(scot %da now.after)/native-coding/hoon-artifact/(scot %ux id)/noun)
  ?.  =(`p.made saved)  (refused %hoon-artifact-retention-mismatch)
  ?.  (selected our.after now.after o)  (refused %worker-tool-selection-changed)
  =/  fresh  (current:source our.after now.after o)
  ?.  =([%& i] fresh)  (refused %worker-tool-authority-changed)
  (pure:m !>(report.outcome.result))
++  selected-v3
  |=  [our=@p now=@da o=tool-order:v3]
  ^-  ?
  =/  chosen=state:parent
    .^(state:parent %gx /(scot %p our)/cantrip/(scot %da now)/native-coding/worker/state/noun)
  &(engaged.chosen =(`pairing.o pairing.owner.chosen))
++  route-v3
  |=  [our=@p now=@da]
  ^-  ?
  =/  choice=capability-state:owner
    .^(capability-state:owner %gx /(scot %p our)/cantrip/(scot %da now)/native-coding/worker/tool-v3-selection/noun)
  selected.choice
++  run-v3
  |=  [id=@ux i=input:archive scope=scope:ct]
  =/  m  (strand ,vase)
  ^-  form:m
  =/  r=tool-request:nc  request.i
  =/  refused
    |=  reason=@tas
    (pure:m !>((refusal:ct r reason 'The selected native worker could not provide an authorized result.')))
  ;<  initial=bowl:spider  bind:m  get-bowl:strandio
  =/  chosen=state:parent
    .^(state:parent %gx /(scot %p our.initial)/cantrip/(scot %da now.initial)/native-coding/worker/state/noun)
  ?~  pairing.owner.chosen  (refused %worker-not-selected)
  ?.  .^(? %gx /(scot %p our.initial)/cantrip/(scot %da now.initial)/native-coding/worker/tool-v3-ready/noun)
    (refused %worker-v3-not-ready)
  ?.  .^(? %gx /(scot %p our.initial)/cantrip/(scot %da now.initial)/native-coding/worker/tool-room/(scot %ux id)/noun)
    (refused %worker-tool-capacity)
  ;<  ~  bind:m
    (poke-our:strandio %cantrip %noun !>([%native-coding-worker-tool-start-v3 id]))
  ;<  ~  bind:m
    (watch-our:strandio /native-worker-tool-result %cantrip (result-path:owner id))
  ;<  v=row:owner  bind:m
    =/  m  (strand ,row:owner)
    |-  ^-  form:m
    ;<  c=cage  bind:m  (take-fact:strandio /native-worker-tool-result)
    ?>  =(%noun p.c)
    ?>  (lte (met 3 (jam q.q.c)) 786.432)
    =/  parsed  ((soft ,(unit row:owner)) q.q.c)
    ?>  &(?=(^ parsed) =(u.parsed q.q.c))
    ?~  u.parsed  $
    =/  v=row:owner  u.u.parsed
    ?>  =(r request.v)
    ?.  (terminal:owner v)  $
    (pure:m v)
  ?^  failure.v
    ?:  unknown.u.failure.v
      (pure:m !>(`tool-result:nc`[%native-coding-tool-result-v1 context.r call-id.r [%unknown reason.u.failure.v 'Remote work is unconfirmed; no build was repeated.']]))
    (refused reason.u.failure.v)
  ?>  &(?=(^ order.v) ?=(^ result.v))
  ?>  ?=(%native-coding-worker-order-v3 -.u.order.v)
  ?>  ?=(%native-coding-worker-result-v3 -.u.result.v)
  =/  o=tool-order:v3  u.order.v
  =/  result=tool-result:v3  u.result.v
  ?.  &((result-matches:work-v3 o result) =(request.purpose.o r) =(input.purpose.o (input-digest:work-v3 i)) =(scope.purpose.o (scope-digest:archive scope)))
    (refused %worker-tool-retained-result-mismatch)
  ?:  ?=(%refused -.outcome.result)  (refused reason.outcome.result)
  ?>  ?=(%tool -.outcome.result)
  ;<  b=bowl:spider  bind:m  get-bowl:strandio
  ?.  (selected-v3 our.b now.b o)  (refused %worker-tool-selection-changed)
  =/  fresh  (current:source-v3 our.b now.b o)
  ?.  =([%& i] fresh)  (refused %worker-tool-authority-changed)
  ?.  .^(? %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/worker/tool-v3-ready/noun)
    (refused %worker-v3-not-ready)
  :: The bounded reference is already retained once in the owner result row.
  :: It is not a full artifact and never supplies execution authority.
  (pure:m !>(report.outcome.result))
--
