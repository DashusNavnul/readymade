::  Selected-source release planning. No cards, source reads or activation.
/-  pkg=readymade-package
/+  package=readymade-package, utf8=native-coding-source-text,
    fnd=readymade-package-foundations
|%
+$  selection  [desk=@tas revision=@ud path=path]
+$  result
  $%  [%readymade-package-released request=@t original=pin:pkg release=pin:pkg files=(list file:pkg)]
      [%readymade-package-release-refused request=@t reason=@tas]
      [%readymade-package-release-uncertain request=@t desk=@tas reason=@tas]
  ==
++  select
  |=  reference=@t
  ^-  (unit selection)
  ?:  (gth (met 3 reference) 512)  ~
  =/  parsed=(unit path)  (rush reference stap)
  ?~  parsed  ~
  ?.  ?=([@ @ @ @ @ *] u.parsed)  ~
  ?.  &((gte (lent u.parsed) 5) (lte (lent u.parsed) 18))  ~
  =/  desk=(unit @tas)  (slaw %tas i.u.parsed)
  =/  revision=(unit @ud)  (slaw %ud i.t.u.parsed)
  ?~  desk  ~
  ?~  revision  ~
  =/  pax=path  t.t.u.parsed
  ?.  ?&  (segment-valid:package u.desk)
          (gth u.revision 0)
          (lte u.revision 18.446.744.073.709.551.615)
          (path-valid:package pax)
          (lien `(list @tas)`~[%hoon %js %css %html] |=(m=@tas =(m (rear pax))))
          =(reference (spat [(scot %tas u.desk) (scot %ud u.revision) pax]))
      ==
    ~
  `[u.desk u.revision pax]
++  source-valid
  |=  [pax=path source=@t]
  ^-  ?
  ?&  (path-valid:package pax)
      (lien `(list @tas)`~[%hoon %js %css %html] |=(m=@tas =(m (rear pax))))
      !(~(has in foundation-paths) pax)
      (gth (met 3 source) 0)
      (lte (met 3 source) 262.144)
      (valid:utf8 source)
  ==
++  raw
  |=  value=*
  ^-  (unit @t)
  ?@  value  `value
  =/  lines=(unit wain)  ((soft wain) value)
  ?~  lines  ~
  `(of-wain:format u.lines)
++  name
  |=  [our=@p peer=@p request=@t original=pin:pkg file=file:pkg]
  ^-  @tas
  =/  hash=@ux
    (end [0 64] (shax (jam [%readymade-release-v1 our peer request original file])))
  =/  digits=@t
    (crip (skip (trip (scot %ux hash)) |=(c=@t =(c '.'))))
  `@tas`(cat 3 'share-' digits)
++  foundation-marks
  ^-  (set @tas)
  marks:fnd
++  foundation-paths
  ^-  (set path)
  paths:fnd
++  foundations-valid
  |=  sources=(map @tas @t)
  ^-  ?
  (valid:fnd sources)
++  pages
  |=  [pax=path source=@t foundations=(map @tas @t) kelvin=*]
  ^-  (map path page:clay)
  ?>  &((source-valid pax source) (foundations-valid foundations))
  =/  files=(map path page:clay)  (pages:fnd foundations)
  =.  files  (~(put by files) pax [`@tas`(rear pax) source])
  =.  files  (~(put by files) /desk/bill [%bill ~])
  (~(put by files) /sys/kelvin [%kelvin kelvin])
++  edits
  |=  files=(map path page:clay)
  ^-  soba:clay
  %+  turn  ~(tap by files)
  |=  [pax=path page=page:clay]
  [pax %ins p.page !>(q.page)]
++  permitted
  |=  [peer=@p rules=[r=dict:clay w=dict:clay]]
  ^-  ?
  ?&  =([%white (silt `(list @p)`~[peer]) ~] rul.r.rules)
      =([%white ~ ~] rul.w.rules)
  ==
--
