::  Pure law data, validation and transitions. No instrument or agent imports.
::  The facade keeps all existing saved nouns, hashes and public arms.
/+  input=qpc-law-command, decision=qpc-decision
|%
+$  parameters  [gain=@ud footprint=@ud indirection=@ud]
+$  edit  edit:input
+$  command  command:input
+$  binding
  [instrument=@ux session=@ux initial-law=@ux objective=@ux project=@t artifact=path]
+$  revision
  $:  id=@ux  previous=(unit @ux)  binding=binding  parameters=parameters
      at=(unit @da)  actor=@p  reason=@t
  ==
+$  state  (map @ux (list revision))
++  digest  |=(v=* ^-(@ux (shax (jam [%qpc-law-revision-v1 v]))))
++  defaults  ^-(parameters [1.000.000 1 1])
++  parameters-valid
  |=  p=parameters
  ?&  (gth gain.p 0)  (lte gain.p 32.000.000)
      (lte footprint.p 1.000.000)  (lte indirection.p 1.000.000)
      (gth (add footprint.p indirection.p) 0)
  ==
++  reason-valid  reason-valid:input
++  initial
  |=  [b=binding our=@p]
  ^-  revision
  =/  r=revision  [0x0 ~ b defaults ~ our 'Declared initial QPC profile; not yet saved.']
  r(id (digest r))
++  valid
  |=  r=revision
  &((parameters-valid parameters.r) (reason-valid reason.r) =(id.r (digest r(id 0x0))))
++  history-valid
  |=  [our=@p id=@ux rows=(list revision)]
  ^-  ?
  ?.  &((gth (lent rows) 0) (lte (lent rows) 128))  %.n
  |-  ^-  ?
  ?~  rows  %.n
  =/  r=revision  i.rows
  ?.  &((valid r) =(our actor.r) =(id instrument.binding.r))  %.n
  ?~  t.rows  =(r (initial binding.r our))
  =/  older=revision  i.t.rows
  ?.  &(=(previous.r `id.older) =(binding.r binding.older) ?=(^ at.r))  %.n
  ?^  at.older
    ?.  (gte u.at.r u.at.older)  %.n
    $(rows t.rows)
  $(rows t.rows)
++  current
  |=  [held=state b=binding our=@p]
  ^-  revision
  =/  prior  (~(get by held) instrument.b)
  ?~  prior  (initial b our)
  ?>  ?=(^ u.prior)
  i.u.prior
++  preview
  |=  [p=parameters change=edit]
  ^-  (each parameters @tas)
  =/  next=parameters
    ?:  ?=(%gain -.change)  p(gain value.change)
    p(footprint footprint.change, indirection indirection.change)
  ?:((parameters-valid next) [%& next] [%| %invalid-law-parameters])
++  apply
  ::  Caller authenticates canonical binding. This pure gate grants no rights.
  |=  [held=state b=binding our=@p actor=@p at=@da cmd=command]
  ^-  (each state @tas)
  ?.  =(our actor)  [%| %owner-control-required]
  ?.  =(instrument.b instrument.cmd)  [%| %instrument-mismatch]
  ::  No native scorer/source commitment is admitted yet. A project name or
  ::  writable artifact is not evidence that a scoring profile applies.
  ?:  ?=(%weights -.change.cmd)
    [%| %objective-profile-unavailable]
  =/  previous=revision  (current held b our)
  ?.  =(b binding.previous)  [%| %instrument-binding-changed]
  ?.  =(expected.cmd id.previous)  [%| %law-revision-changed]
  ?.  (reason-valid reason.cmd)  [%| %law-rationale-required]
  =/  next  (preview parameters.previous change.cmd)
  ?:  ?=(%| -.next)  [%| p.next]
  ?:  =(p.next parameters.previous)  [%| %law-unchanged]
  =/  history=(list revision)  (fall (~(get by held) instrument.b) ~[previous])
  ?.  (lth (lent history) 128)  [%| %law-history-full]
  ?.  |((~(has by held) instrument.b) (lth ~(wyt by held) 64))
    [%| %law-instruments-full]
  =/  next=revision  [0x0 `id.previous b p.next `at actor reason.cmd]
  =.  next  next(id (digest next))
  [%& (~(put by held) instrument.b [next history])]
++  freeze
  ::  A future decision owner MUST retain this whole revision, use id as
  ::  decision.binding.law, and use its values. No independent gain argument.
  |=  [held=state b=binding our=@p expected=@ux]
  ^-  (each revision @tas)
  =/  r=revision  (current held b our)
  ?.  &(=(expected id.r) =(b binding.r) (valid r))
    [%| %law-revision-changed]
  [%& r]
++  retained
  :: An opened decision keeps its exact recorded revision. This lookup does
  :: not admit new work or replace current source, grant or permission checks.
  |=  [held=state b=binding our=@p expected=@ux]
  ^-  (each revision @tas)
  =/  prior  (~(get by held) instrument.b)
  ?~  prior
    =/  r=revision  (initial b our)
    ?:(=(expected id.r) [%& r] [%| %law-revision-unavailable])
  ?.  (history-valid our instrument.b u.prior)
    [%| %law-history-invalid]
  =/  matched=(list revision)
    (skim u.prior |=(r=revision &(=(expected id.r) =(b binding.r))))
  ?.  =(1 (lent matched))  [%| %law-revision-unavailable]
  [%& (snag 0 matched)]
++  open-decision
  ::  Consumer seam: same retained revision supplies identity AND gain.
  ::  Caller still authenticates observation admission, objective and authority.
  |=  $:  held=state  b=binding  our=@p  expected=@ux
          context=binding:decision  dimensions=@ud  width=@ud
          live=(list observation:decision)  reference=(list observation:decision)
      ==
  ^-  (each state:decision @tas)
  =/  frozen  (freeze held b our expected)
  ?:  ?=(%| -.frozen)  [%| p.frozen]
  ?.  =(session.b session.context)  [%| %law-session-mismatch]
  (open:decision context(law id.p.frozen) dimensions width gain.parameters.p.frozen live reference)
--
