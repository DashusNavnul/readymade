::  Distinct compilation contract for selected, owner-approved source data.
::  Pure values authenticate no caller or app. The owner must supply native
::  journals and current law through the read helper before dispatching.
/-  vc=vibecoding-candidate, cs=vibecoding-check-spec, itn=intent
/+  legacy=cantrip-vibecoding-compile, protocol=vibecoding-compile-protocol,
    result=vibecoding-connected-result, vcl=vibecoding-candidate,
    clw=cantrip-law-window
|%
+$  commitment
  $:  %vibecoding-connected-compile-commitment-v1
      result=@ux  nonce=@ux  accepted=revision:vc  working=revision:vc
      binding=binding:legacy  approval=approval:cs
      intent=record:itn  window=window:clw
  ==
+$  snapshot
  [%vibecoding-connected-compile-snapshot-v1 commitment=commitment receipt=receipt:result order=order:protocol]
+$  admission  [snapshot=snapshot at=@da]
+$  record
  [%vibecoding-connected-compilation-v1 snapshot=snapshot artifact=artifact:protocol received=@da]
+$  decision  (each admission @tas)
++  valid
  |=  s=snapshot
  ^-  ?
  =/  c=commitment  commitment.s
  =/  o=order:protocol  order.s
  ?.  ?&  (binding-valid:legacy binding.c)  (valid:protocol o)
          =(owner.binding.c owner.o)  =(worker.binding.c worker.o)
          =(expires.o (add at.o ~m5))
          =(write.o (digest:protocol c))
          =(result.c (digest:vcl receipt.s))
          (linked:result owner.o at.o receipt.s)
          (permission:legacy window.c)
      ==  %.n
  =/  e  entry.receipt.s
  =/  saved  saved.receipt.s
  ?.  ?=(%submitted -.state.e)  %.n
  ?~  historical.saved  %.n
  =/  candidate=candidate:vc  candidate.body.review.body.intake.state.e
  =/  packet=packet:vc  packet.candidate
  ?.  ?=([%vibecoding-candidate-packet-v5 *] -.packet)  %.n
  ?&  =(nonce.c nonce.request.e)
      =(accepted.c base.current.basis.admission.saved)
      =(working.c work.u.historical.saved)
      =(approval.c approval.version.packet)
      =(intent.c intent.context.packet)
      =(source.o source.candidate)
  ==
++  view-valid
  |=  [our=@p at=@da view=view:result]
  ^-  ?
  ?&  =(our owner.view)  =(at at.view)
      historical.view  fresh.view
      =(key.view (digest:vcl receipt.view))
      (linked:result our at receipt.view)
      (fresh:result at receipt.view current.view)
  ==
++  freeze
  |=  [our=@p actor=@p at=@da binding=binding:legacy view=view:result stated=(unit record:itn) window=window:clw]
  ^-  (each snapshot @tas)
  ?.  =(our actor)  [%| %foreign-actor]
  ?.  &((binding-valid:legacy binding) =(our owner.binding))  [%| %compiler-binding-invalid]
  ?.  (view-valid our at view)  [%| %result-not-current]
  =/  e  entry.receipt.view
  =/  saved  saved.receipt.view
  ?.  ?=(%submitted -.state.e)  [%| %result-invalid]
  ?~  historical.saved  [%| %history-missing]
  =/  candidate=candidate:vc  candidate.body.review.body.intake.state.e
  =/  packet=packet:vc  packet.candidate
  ?.  ?=([%vibecoding-candidate-packet-v5 *] -.packet)  [%| %selected-packet-required]
  ?.  =(`intent.context.packet stated)  [%| %intent-changed]
  ?.  (permission:legacy window)  [%| %probe-not-admitted]
  ::  A NEW freeze may use a newly current permitted window. The historical
  ::  write window is not silently relabeled as current compiler permission.
  =/  c=commitment
    :*  %vibecoding-connected-compile-commitment-v1
        key.view  nonce.request.e
        base.current.basis.admission.saved  work.u.historical.saved
        binding  approval.version.packet  intent.context.packet  window
    ==
  =/  o=order:protocol
    [%vibecoding-compile-order-v1 our worker.binding (digest:protocol c) source.candidate (shax source.candidate) at (add at ~m5)]
  =/  s=snapshot  [%vibecoding-connected-compile-snapshot-v1 c receipt.view o]
  ?.  (valid s)  [%| %snapshot-invalid]
  [%& s]
++  admit
  |=  [our=@p actor=@p at=@da s=snapshot view=view:result stated=(unit record:itn) window=window:clw]
  ^-  decision
  ?.  =(our actor)  [%| %foreign-actor]
  ?.  &((valid s) =(our owner.order.s))  [%| %snapshot-invalid]
  ?.  &((lte at.order.s at) (lth at expires.order.s))  [%| %expired-request]
  =/  current  (freeze our actor at binding.commitment.s view stated window)
  ?:  ?=(%| -.current)  [%| p.current]
  ::  Refresh current reads without moving the frozen deadline or identity.
  =/  expected=order:protocol  order.p.current(at at.order.s, expires expires.order.s)
  ?.  =(s p.current(order expected))  [%| %frozen-context-changed]
  [%& [s at]]
++  dispatch
  ::  Not installed. A future owner must journal before emitting this card.
  |=  [our=@p now=@da a=admission]
  ^-  (unit card:agent:gall)
  =/  s=snapshot  snapshot.a
  ?.  &((valid s) =(our owner.order.s) =(now at.a) (lte at.order.s now) (lth now expires.order.s))  ~
  `[%pass /connected-compiler-order/(scot %ux (digest:protocol order.s)) %agent [worker.order.s %vibecoding-compiler] %poke %noun !>([%compile order.s])]
++  receive
  ::  The future owning callback supplies the authenticated worker endpoint.
  |=  [our=@p src=@p now=@da s=snapshot a=artifact:protocol]
  ^-  (each record @tas)
  ?.  &((valid s) =(our owner.order.s) =(src worker.order.s))  [%| %foreign-or-invalid-snapshot]
  ?.  &((lte at.order.s now) (lth now expires.order.s))  [%| %expired-request]
  =/  binding=binding:legacy  binding.commitment.s
  ::  The worker freezes Clay at reservation, then compiles in a later event.
  ?.  ?=(%da -.r.beak.compiler.a)  [%| %artifact-mismatch]
  ?.  ?&  (matches:protocol order.s a)
          =(desk.binding q.beak.compiler.a)
          =(root.binding root.compiler.a)
          =(hoon.binding hoon.compiler.a)  =(zuse.binding zuse.compiler.a)
          (lte at.order.s p.r.beak.compiler.a)
          (lte p.r.beak.compiler.a at.compiler.a)
          (lte at.compiler.a now)
      ==  [%| %artifact-mismatch]
  [%& [%vibecoding-connected-compilation-v1 s a now]]
++  record-valid
  |=  r=record
  ^-  ?
  =/  s=snapshot  snapshot.r
  =([%& r] (receive owner.order.s worker.order.s received.r s artifact.r))
::  The v2 domain binds the digest of the COMPLETE v2 receipt, retained in
::  the snapshot. Neither the provider envelope nor the ordered approval is
::  projected into an older mold. Worker orders and artifacts stay unchanged.
+$  commitment-v2
  $:  %vibecoding-connected-compile-commitment-v2
      result=@ux  nonce=@ux  accepted=revision:vc  working=revision:vc
      binding=binding:legacy  approval=approval:cs
      intent=record:itn  window=window:clw
  ==
+$  snapshot-v2
  [%vibecoding-connected-compile-snapshot-v2 commitment=commitment-v2 receipt=receipt-v2:result order=order:protocol]
+$  admission-v2  [snapshot=snapshot-v2 at=@da]
+$  record-v2
  [%vibecoding-connected-compilation-v2 snapshot=snapshot-v2 artifact=artifact:protocol received=@da]
+$  decision-v2  (each admission-v2 @tas)
++  valid-v2
  |=  s=snapshot-v2
  ^-  ?
  =/  c=commitment-v2  commitment.s
  =/  o=order:protocol  order.s
  ?.  ?&  (binding-valid:legacy binding.c)  (valid:protocol o)
          =(owner.binding.c owner.o)  =(worker.binding.c worker.o)
          =(expires.o (add at.o ~m5))
          =(write.o (digest:protocol c))
          =(result.c (digest:vcl receipt.s))
          (linked-v2:result owner.o at.o receipt.s)
          (permission:legacy window.c)
      ==  %.n
  =/  e  entry.receipt.s
  =/  saved  saved.receipt.s
  ?.  ?=(%submitted -.state.e)  %.n
  ?~  historical.saved  %.n
  =/  candidate=candidate-v4:vc  candidate.body.review.body.intake.state.e
  =/  packet=selected-v2:vc  packet.candidate
  ?&  =(nonce.c nonce.request.e)
      =(accepted.c base.current.basis.admission.saved)
      =(working.c work.u.historical.saved)
      =(approval.c approval.version.packet)
      =(intent.c intent.context.packet)
      =(source.o source.candidate)
  ==
++  view-valid-v2
  |=  [our=@p at=@da view=view-v2:result]
  ^-  ?
  ?&  =(our owner.view)  =(at at.view)
      historical.view  fresh.view
      =(key.view (digest:vcl receipt.view))
      (linked-v2:result our at receipt.view)
      (fresh-v2:result at receipt.view current.view)
  ==
++  freeze-v2
  |=  [our=@p actor=@p at=@da binding=binding:legacy view=view-v2:result stated=(unit record:itn) window=window:clw]
  ^-  (each snapshot-v2 @tas)
  ?.  =(our actor)  [%| %foreign-actor]
  ?.  &((binding-valid:legacy binding) =(our owner.binding))  [%| %compiler-binding-invalid]
  ?.  (view-valid-v2 our at view)  [%| %result-not-current]
  =/  e  entry.receipt.view
  =/  saved  saved.receipt.view
  ?.  ?=(%submitted -.state.e)  [%| %result-invalid]
  ?~  historical.saved  [%| %history-missing]
  =/  candidate=candidate-v4:vc  candidate.body.review.body.intake.state.e
  =/  packet=selected-v2:vc  packet.candidate
  ?.  =(`intent.context.packet stated)  [%| %intent-changed]
  ?.  (permission:legacy window)  [%| %probe-not-admitted]
  =/  c=commitment-v2
    :*  %vibecoding-connected-compile-commitment-v2
        key.view  nonce.request.e
        base.current.basis.admission.saved  work.u.historical.saved
        binding  approval.version.packet  intent.context.packet  window
    ==
  =/  o=order:protocol
    [%vibecoding-compile-order-v1 our worker.binding (digest:protocol c) source.candidate (shax source.candidate) at (add at ~m5)]
  =/  s=snapshot-v2  [%vibecoding-connected-compile-snapshot-v2 c receipt.view o]
  ?.  (valid-v2 s)  [%| %snapshot-invalid]
  [%& s]
++  admit-v2
  |=  [our=@p actor=@p at=@da s=snapshot-v2 view=view-v2:result stated=(unit record:itn) window=window:clw]
  ^-  decision-v2
  ?.  =(our actor)  [%| %foreign-actor]
  ?.  &((valid-v2 s) =(our owner.order.s))  [%| %snapshot-invalid]
  ?.  &((lte at.order.s at) (lth at expires.order.s))  [%| %expired-request]
  =/  current  (freeze-v2 our actor at binding.commitment.s view stated window)
  ?:  ?=(%| -.current)  [%| p.current]
  =/  expected=order:protocol  order.p.current(at at.order.s, expires expires.order.s)
  ?.  =(s p.current(order expected))  [%| %frozen-context-changed]
  [%& [s at]]
++  dispatch-v2
  ::  Inspection only until an owning app reserves before emitting the card.
  |=  [our=@p now=@da a=admission-v2]
  ^-  (unit card:agent:gall)
  =/  s=snapshot-v2  snapshot.a
  ?.  &((valid-v2 s) =(our owner.order.s) =(now at.a) (lte at.order.s now) (lth now expires.order.s))  ~
  `[%pass /connected-compiler-order-v2/(scot %ux (digest:protocol order.s)) %agent [worker.order.s %vibecoding-compiler] %poke %noun !>([%compile order.s])]
++  receive-v2
  |=  [our=@p src=@p now=@da s=snapshot-v2 a=artifact:protocol]
  ^-  (each record-v2 @tas)
  ?.  &((valid-v2 s) =(our owner.order.s) =(src worker.order.s))  [%| %foreign-or-invalid-snapshot]
  ?.  &((lte at.order.s now) (lth now expires.order.s))  [%| %expired-request]
  =/  binding=binding:legacy  binding.commitment.s
  ?.  ?=(%da -.r.beak.compiler.a)  [%| %artifact-mismatch]
  ?.  ?&  (matches:protocol order.s a)
          =(desk.binding q.beak.compiler.a)
          =(root.binding root.compiler.a)
          =(hoon.binding hoon.compiler.a)  =(zuse.binding zuse.compiler.a)
          (lte at.order.s p.r.beak.compiler.a)
          (lte p.r.beak.compiler.a at.compiler.a)
          (lte at.compiler.a now)
      ==  [%| %artifact-mismatch]
  [%& [%vibecoding-connected-compilation-v2 s a now]]
++  record-valid-v2
  |=  r=record-v2
  ^-  ?
  =/  s=snapshot-v2  snapshot.r
  =([%& r] (receive-v2 owner.order.s worker.order.s received.r s artifact.r))
--
