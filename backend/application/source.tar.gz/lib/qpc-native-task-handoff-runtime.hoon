:: Native completion/handoff boundary. Prepared tasks are inert; activation is
:: a separate explicit owner operation. No new saved wrapper or model loop.
/-  nc=native-coding, audit=verb
/+  campaign=qpc-native-campaign, kernel=qpc-native-task-handoff,
    completed=qpc-native-task-completion,
    completion=qpc-native-task-completion-runtime,
    read=qpc-native-campaign-read, instrument=qpc-instrument,
    history=qpc-successor-history, obs=qpc-observation,
    observer=qpc-observer, appstate=qpc-native-app-state,
    session=native-coding-session, loop=native-coding-loop,
    guard=viki-scry-guard, rf=readymade-fleet-agent, law=qpc-law
|%
+$  command
  $%  [%qpc-native-task-handoff-prepare-v1 prior=@ux next=command:campaign plan=plan:instrument expected=@ux]
      [%qpc-native-campaign-activate-v1 id=@ux task=@ux handoff=@ux]
  ==
+$  change  [inner=agent:gall held=state:campaign cards=(list card:agent:gall)]
+$  world  [held=state:instrument ordered=state:history refresh=(unit @da)]
+$  inspector
  $-([inner=agent:gall b=bowl:gall member=@ux] (each inspected:completion @tas))
+$  keeper  $-([b=bowl:gall next=@ux] (each proposal:kernel @tas))
+$  retained-page
  [%graf-kind-page %1 kind=@tas offset=@ud limit=@ud returned=@ud more=? next=@ud items=(list *)]
+$  sent
  [%pass route=wire %agent target=[owner=@p app=@tas] %poke mark=mark payload=[p=* q=*]]
+$  notice  [%give %fact routes=(list path) mark=mark payload=[p=* q=*]]
+$  ui-fact  [route=path value=*]
+$  audit-fact  [routes=(list path) mark=mark value=*]
+$  audit-context  [b=bowl:gall c=command:completion]
+$  refreshed  [%pass route=wire %arvo %b %wait due=@da]
++  refuse
  |=  [inner=agent:gall held=state:campaign member=@ux reason=@tas]
  ^-  change
  [inner held ~[(refused:loop member reason)]]
++  state-read
  |=  [inner=agent:gall b=bowl:gall]
  ^-  (each world @tas)
  =/  raw  (raw:instrument inner b /x/qpc/instrument/state)
  ?~  raw  [%| %task-handoff-instrument-unavailable]
  =/  held  ((soft ,state:instrument) u.raw)
  ?~  held  [%| %task-handoff-instrument-invalid]
  =/  raw  (raw:instrument inner b /x/qpc/instrument/successors)
  ?~  raw  [%| %task-handoff-history-unavailable]
  =/  parsed  ((soft ,[%qpc-instrument-successors-v1 ordered=state:history refresh=(unit @da)]) u.raw)
  ?~  parsed  [%| %task-handoff-history-invalid]
  [%& [u.held ordered.u.parsed refresh.u.parsed]]
++  parts
  |=  [inner=agent:gall b=bowl:gall]
  ^-  (unit (list part:appstate))
  =/  got  (mule |.((viki:appstate on-save:~(. inner b(src our.b)))))
  ?:  ?=(%| -.got)  ~
  ?.  =(13 (lent p.got))  ~
  `p.got
++  instrument-part
  :: Compare DATA fields explicitly; v4 and v5 have different final axes.
  |=  p=part:appstate
  ^-  (unit [held=state:instrument ordered=* laws=laws:instrument successors=* refresh=(unit @da) selected=(unit *)])
  ?:  =(%qpc-instrument-v4 tag.p)
    =/  got  ((soft ,[held=state:instrument ordered=* laws=laws:instrument successors=* refresh=(unit @da)]) data.p)
    ?~  got  ~
    `[held.u.got ordered.u.got laws.u.got successors.u.got refresh.u.got ~]
  ?.  =(%qpc-instrument-v5 tag.p)  ~
  =/  got  ((soft ,[held=state:instrument ordered=* laws=laws:instrument successors=* refresh=(unit @da) selected=*]) data.p)
  ?~  got  ~
  `[held.u.got ordered.u.got laws.u.got successors.u.got refresh.u.got `selected.u.got]
++  cleared-refresh-parts
  :: A synchronous observation may clear its ticket, not normalize evidence.
  |=  [before=(list part:appstate) after=(list part:appstate)]
  ^-  ?
  ?.  &(=(13 (lent before)) =(13 (lent after)))  %.n
  =/  selected
    |=(p=part:appstate ?=(?(%qpc-instrument-v4 %qpc-instrument-v5) tag.p))
  =/  left=(list part:appstate)  (skim before selected)
  =/  right=(list part:appstate)  (skim after selected)
  ?.  &(=(1 (lent left)) =(1 (lent right)))  %.n
  ?.  =((skip before selected) (skip after selected))  %.n
  ?~  left  %.n
  ?~  right  %.n
  ?.  =(tag.i.left tag.i.right)  %.n
  =/  l  (instrument-part i.left)
  =/  r  (instrument-part i.right)
  ?.  &(?=(^ l) ?=(^ r))  %.n
  =/  pending=(unit @da)  refresh.u.l
  ?~  pending  %.n
  =(u.r u.l(refresh ~))
++  refresh-current
  :: Trial the existing native reader in this owner event. No returned card or
  :: DATA change besides the completed read ticket can reach the transition.
  |=  [inner=agent:gall b=bowl:gall member=@ux]
  ^-  (each agent:gall @tas)
  ?.  =(our.b src.b)  [%| %task-handoff-owner-required]
  =/  observed  (state-read inner b)
  ?:  ?=(%| -.observed)  [%| p.observed]
  ?~  refresh.p.observed  [%& inner]
  =/  stores  (stores-read:instrument inner b)
  ?~  stores  [%| %task-handoff-refresh-stores-unavailable]
  =/  before  (parts inner b)
  ?~  before  [%| %task-handoff-owned-data-unavailable]
  =/  trial
    (mule |.((on-poke:~(. inner b(src our.b)) %noun !>([%qpc-instrument-reobserve-v1 member]))))
  ?:  ?=(%| -.trial)  [%| %task-handoff-refresh-refused]
  ?.  =(~ -.p.trial)  [%| %task-handoff-refresh-produced-cards]
  =/  confirmed  (stores-read:instrument +.p.trial b)
  ?~  confirmed  [%| %task-handoff-refresh-stores-unavailable]
  ?.  =(u.stores u.confirmed)  [%| %task-handoff-refresh-changed-data]
  =/  after  (parts +.p.trial b)
  ?~  after  [%| %task-handoff-returned-data-unavailable]
  ?.  (cleared-refresh-parts u.before u.after)
    [%| %task-handoff-refresh-changed-data]
  [%& +.p.trial]
++  joined-parts
  :: Only the predicted plan join and its canonical law projection may change.
  :: Retained law and every other complete DATA part stay exact.
  |=  [our=@p before=(list part:appstate) after=(list part:appstate) old=world next=world expected=state:instrument]
  ^-  ?
  =/  selected
    |=  p=part:appstate
    ^-  ?
    ?=(?(%qpc-instrument-v4 %qpc-instrument-v5) tag.p)
  =/  left=(list part:appstate)  (skim before selected)
  =/  right=(list part:appstate)  (skim after selected)
  ?.  &(=(1 (lent left)) =(1 (lent right)))  %.n
  ?.  =((skim before |=(p=part:appstate !(selected p))) (skim after |=(p=part:appstate !(selected p))))  %.n
  ?~  left  %.n
  ?~  right  %.n
  =/  l=part:appstate  i.left
  =/  r=part:appstate  i.right
  ?.  =(tag.l tag.r)  %.n
  =/  l  (instrument-part l)
  =/  r  (instrument-part r)
  ?.  &(?=(^ l) ?=(^ r))  %.n
  =/  laws=(list part:appstate)
    (skim before |=(p=part:appstate =(%qpc-law-owner-v2 tag.p)))
  ?.  =(1 (lent laws))  %.n
  ?~  laws  %.n
  =/  retained  ((soft ,state:law) data.i.laws)
  ?~  retained  %.n
  =/  members-before=(list [session=@ux bound=binding:law])
    (turn ~(val by plans.held.old) |=(p=record:instrument [session.plan.p (binding-of:law plan.p)]))
  =/  members-after=(list [session=@ux bound=binding:law])
    (turn ~(val by plans.expected) |=(p=record:instrument [session.plan.p (binding-of:law plan.p)]))
  ?&  =(held.u.l held.old)  =(held.u.r held.next)
      =(held.next expected)
      =(laws.u.l (project-context:law our u.retained members-before))
      =(laws.u.r (project-context:law our u.retained members-after))
      =(ordered.u.l ordered.u.r)  =(successors.u.l successors.u.r)
      =(refresh.u.l refresh.u.r)  =(selected.u.l selected.u.r)
      =(ordered.old ordered.next)  =(refresh.old refresh.next)
  ==
++  completion-history
  :: This private returned-inner surface authenticates actual Graf retention
  :: and the complete historical native task/review/landing/journal joins.
  |=  [inner=agent:gall b=bowl:gall member=@ux]
  ^-  (each inspected:completion @tas)
  =/  raw  (raw:instrument inner b /x/native-coding/task-completion-history/(scot %ux member))
  ?~  raw  [%| %task-handoff-completion-unavailable]
  =/  got  ((soft ,(each inspected:completion @tas)) u.raw)
  ?~  got  [%| %task-handoff-completion-incompatible]
  u.got
++  completion-proposal
  |=  [inner=agent:gall b=bowl:gall member=@ux]
  ^-  (each proposal:completed @tas)
  =/  raw  (raw:instrument inner b /x/native-coding/task-completion-proposal/(scot %ux member))
  ?~  raw  [%| %task-completion-proposal-unavailable]
  =/  got  ((soft ,(each proposal:completed @tas)) u.raw)
  ?~  got  [%| %task-completion-proposal-incompatible]
  u.got
++  page-valid
  |=  [p=retained-page offset=@ud]
  ^-  ?
  ?&  =(%qpc-native-task-handoff-v1 kind.p)
      =(offset offset.p)  =(64 limit.p)
      =(returned.p (lent items.p))  (lte returned.p 64)
      =(next.p (add offset returned.p))
      ?:(more.p =(64 returned.p) %.y)
  ==
++  retained
  :: Consume bounded actual Graf pages through more=false. Partial history,
  :: malformed facts and two proposals for one next identity fail closed.
  |=  [b=bowl:gall next=@ux]
  ^-  (each proposal:kernel @tas)
  ?.  (agent-live:guard our.b now.b %graf)  [%| %task-handoff-graf-unavailable]
  =/  offset=@ud  0
  =|  found=(unit proposal:kernel)
  |-  ^-  (each proposal:kernel @tas)
  ?:  (gte offset 256)  [%| %task-handoff-history-capacity]
  =/  raw=*
    .^(* %gx /(scot %p our.b)/graf/(scot %da now.b)/by-kind-page/qpc-native-task-handoff-v1/(scot %ud offset)/64/noun)
  =/  parsed  ((soft ,retained-page) raw)
  ?~  parsed  [%| %task-handoff-history-page-invalid]
  =/  page=retained-page  u.parsed
  ?.  (page-valid page offset)  [%| %task-handoff-history-page-invalid]
  =/  rows=(list *)  items.page
  =/  selected=(each (unit proposal:kernel) @tas)
    |-  ^-  (each (unit proposal:kernel) @tas)
    ?~  rows  [%& found]
    =/  value  ((soft ,proposal:kernel) i.rows)
    ?~  value  [%| %task-handoff-history-fact-invalid]
    ?.  =(next next.u.value)  $(rows t.rows)
    ?^  found  [%| %task-handoff-history-ambiguous]
    $(rows t.rows, found `u.value)
  ?:  ?=(%| -.selected)  [%| p.selected]
  =.  found  p.selected
  ?:  more.page  $(offset next.page)
  ?~  found  [%| %task-handoff-retention-unconfirmed]
  [%& u.found]
++  bound
  :: Historical link plus current prepared member identity. The whole-history
  :: hash records preservation then; unrelated streams need not freeze later.
  |=  [our=@p held=state:campaign next=record:campaign p=proposal:kernel inspected=inspected:completion now=world]
  ^-  ?
  =/  prior  (~(get by records.held) prior.p)
  ?~  prior  %.n
  =/  old=record:campaign  u.prior
  =/  original=command:campaign  command.task.old
  =/  command=command:campaign  command.task.next
  =/  plan=plan:instrument  plan.snapshot.task.next
  =/  member  (~(get by plans.held.now) member.command)
  ?~  member  %.n
  =/  before  (~(get by plans.held.now) member.original)
  ?~  before  %.n
  ?&  =(our owner.task.old)  =(our owner.task.next)
      =(%awaiting-next-task phase.old)  =(`%qpc-task-completed reason.old)
      ?=(~ due.old)  ?=(~ request.old)  ?=(~ child.old)
      =(id.command next.p)  =(member.original member.p)
      =((task-digest:campaign next) task.p)
      =((digest:completed receipt.inspected) completion.p)
      =(source.proposal.receipt.inspected source.p)
      =(expected.command source.p)
      =(member.original member.task.inspected)
      =(plan plan.u.member)
      =((digest:kernel u.member) after.p)
      !active.u.before  =(plan.snapshot.task.old plan.u.before)
      ?=(~ ticket.u.before)  ?=(~ awaiting.u.before)
  ==
++  ui-facts
  :: These are derived projections, never caller-authorized extra effects.
  :: Inspect payload DATA without traversing a producer's VASE TYPE.
  |=  expected=(list card:agent:gall)
  ^-  (unit (list ui-fact))
  ?.  (lte (lent expected) 32)  ~
  =|  paths=(set path)
  =|  values=(list ui-fact)
  |-  ^-  (unit (list ui-fact))
  ?~  expected  `(flop values)
  =/  item  ((soft ,notice) i.expected)
  ?~  item  ~
  ?.  &(=(%noun mark.u.item) ?=([* ~] routes.u.item))  ~
  =/  pax=path  i.routes.u.item
  ?~  (route:rf pax)  ~
  ?:  (~(has in paths) pax)  ~
  =/  value  ((soft ,observation:rf) q.payload.u.item)
  ?~  value  ~
  $(expected t.expected, paths (~(put in paths) pax), values [[pax u.value] values])
++  completion-audits
  :: verb.on-poke fingerprints only the three inner completion cards. Fleet
  :: notifications and the successor refresh are added outside that wrapper.
  |=  [b=bowl:gall c=command:completion e=entry:session receipt=receipt:completed]
  ^-  (list audit-fact)
  =/  effects=(list effect:audit)
    :~  [%fact ~[/native-coding] %noun (mug [%native-coding-changed-v1 member.c sequence.e])]
        [%poke /native-coding/retain [our.b %graf] %graf-action (mug [%attest [%native-coding-session-record-v1 member.c record.receipt]])]
        [%poke /qpc/native-task-completion-retain [our.b %graf] %graf-action (mug [%attest (retained-fact:completion member.c receipt)])]
    ==
  =/  plus=event-plus:audit
    [act.b now.b src.b sap.b [%on-poke %noun (mug c)] effects]
  =/  event=event:audit  [%on-poke %noun]
  :~  [~[/verb/events-plus] %verb-event-plus plus]
      [~[/verb/events] %verb-event event]
  ==
++  completion-cards
  |=  [our=@p at=@da member=@ux e=entry:session receipt=receipt:completed before=world after=world cards=(list card:agent:gall)]
  ^-  ?
  (completion-cards-with our at member e receipt before after ~ cards)
++  completion-cards-with
  |=  [our=@p at=@da member=@ux e=entry:session receipt=receipt:completed before=world after=world expected=(list card:agent:gall) cards=(list card:agent:gall)]
  ^-  ?
  (completion-cards-all our at member e receipt before after expected ~ cards)
++  completion-cards-all
  :: Production completion also requires verb's two exact audit facts. Their
  :: metadata and ordered effect fingerprints come from the actual invocation.
  :: No other non-noun notification or new effect class is authorized.
  |=  [our=@p at=@da member=@ux e=entry:session receipt=receipt:completed before=world after=world expected=(list card:agent:gall) context=(unit audit-context) cards=(list card:agent:gall)]
  ^-  ?
  =/  audits=(list audit-fact)
    ?~  context  ~
    (completion-audits b.u.context c.u.context e receipt)
  =/  bound=?
    ?~  context  %.y
    ?&  =(our our.b.u.context)  =(our src.b.u.context)
        =(at now.b.u.context)  =(member member.c.u.context)
        =((digest:completed proposal.receipt) expected.c.u.context)
    ==
  ?.  bound  %.n
  =/  projected  (ui-facts expected)
  ?~  projected  %.n
  =/  remaining=(list ui-fact)  u.projected
  ?.  &(=(held.before held.after) =(ordered.before ordered.after))  %.n
  =/  changed=@ud  0
  =/  journal=@ud  0
  =/  semantic=@ud  0
  =/  refresh=@ud  0
  |-  ^-  ?
  ?~  cards
    ?.  &(=(~ remaining) =(~ audits))  %.n
    ?.  &(=(1 changed) =(1 journal) =(1 semantic))  %.n
    ?:  =(refresh.before refresh.after)  =(0 refresh)
    ?.  &(?=(~ refresh.before) ?=(^ refresh.after) =(1 refresh))  %.n
    =((add at ~s1) (need refresh.after))
  =/  n  ((soft ,notice) i.cards)
  ?^  n
    ?:  &(=(%noun mark.u.n) =(~[/native-coding] routes.u.n) =([%native-coding-changed-v1 member sequence.e] q.payload.u.n))
      $(cards t.cards, changed +(changed))
    =/  matches-audit=?
      ?~  audits  %.n
      =([routes.u.n mark.u.n q.payload.u.n] i.audits)
    ?:  matches-audit
      $(cards t.cards, audits (slag 1 audits))
    ?.  &(=(%noun mark.u.n) ?=([* ~] routes.u.n))  %.n
    =/  pax=path  i.routes.u.n
    =/  matches=(list ui-fact)
      (skim remaining |=(f=ui-fact &(=(pax route.f) =(q.payload.u.n value.f))))
    ?.  =(1 (lent matches))  %.n
    =/  matched=ui-fact  (snag 0 matches)
    $(cards t.cards, remaining (skip remaining |=(f=ui-fact =(f matched))))
  =/  p  ((soft ,sent) i.cards)
  ?^  p
    ?.  &(=([our %graf] target.u.p) =(%graf-action mark.u.p))  %.n
    ?:  =(/native-coding/retain route.u.p)
      ?.  =([%attest [%native-coding-session-record-v1 member record.receipt]] q.payload.u.p)  %.n
      $(cards t.cards, journal +(journal))
    ?.  =(/qpc/native-task-completion-retain route.u.p)  %.n
    ?.  =([%attest (retained-fact:completion member receipt)] q.payload.u.p)  %.n
    $(cards t.cards, semantic +(semantic))
  =/  r  ((soft ,refreshed) i.cards)
  ?~  r  %.n
  ?.  &(=(/qpc-successor-refresh/(scot %da due.u.r) route.u.r) =(`due.u.r refresh.after))  %.n
  $(cards t.cards, refresh +(refresh))
++  completion-entry
  |=  [before=entry:session after=entry:session p=proposal:completed at=@da]
  ^-  ?
  ?.  ?&  =(%paused phase.before)  =(%ready resume.before)
          ?=(~ pending.before)  ?=(~ calls.before)
          ?=(^ records.after)  =(member.p id.session.before)
      ==  %.n
  =/  last=record:session  (rear records.after)
  ?&  =(at.last at)  =(body.last (judgment-body:completed p))
      =(sequence.last sequence.before)  =(previous.last head.before)
      =(id.last (event-id:session id.session.before sequence.last previous.last at.last body.last))
      =(after before(phase %complete, resume %complete, records (snoc records.before last), head `id.last, sequence +(sequence.before)))
  ==
++  complete
  :: The trusted inner owner proves completion. Retire its original campaign
  :: in this same event only after verifying the returned exact single append.
  :: Failed trials are discarded with all their cards; no partial work commits.
  |=  [inner=agent:gall b=bowl:gall held=state:campaign c=command:completion]
  ^-  change
  =/  fail  |=(reason=@tas (refuse inner held member.c reason))
  ?.  =(our.b src.b)  (fail %task-completion-owner-required)
  ?.  (valid:campaign our.b held)  (fail %task-completion-campaign-state-invalid)
  =/  rows=(list record:campaign)
    (skim ~(val by records.held) |=(r=record:campaign =(member.c member.command.task.r)))
  ?.  =(1 (lent rows))  (fail %task-completion-declaration-missing)
  =/  prior=record:campaign  (snag 0 rows)
  ?.  ?&  =(our.b owner.task.prior)
          ?=(?(%collecting %awaiting-next-task) phase.prior)
          ?=(~ due.prior)  ?=(~ request.prior)  ?=(~ child.prior)
      ==  (fail %task-completion-declaration-unsettled)
  =/  before  (input:observer inner b member.c)
  ?~  before  (fail %task-completion-session-missing)
  =/  proposed  (completion-proposal inner b member.c)
  ?:  ?=(%| -.proposed)  (fail p.proposed)
  ?.  =(expected.c (digest:completed p.proposed))  (fail %task-completion-proposal-changed)
  ?:  =(%complete phase.entry.u.before)
    ?.  =(%awaiting-next-task phase.prior)
      (fail %task-completion-owner-not-retired)
    ?.  =(`%qpc-task-completed reason.prior)  (fail %task-completion-owner-not-retired)
    [inner held ~]
  =/  old  (state-read inner b)
  ?:  ?=(%| -.old)  (fail p.old)
  =/  trial  (on-poke:~(. inner b(src our.b)) %noun !>(c))
  =/  after  (input:observer +.trial b member.c)
  ?~  after  (fail %task-completion-returned-session-missing)
  ?:  =(u.before u.after)  (fail %task-completion-not-applied)
  ?.  =(key.u.before key.u.after)
    (fail %task-completion-returned-binding-changed)
  ?.  =(grant.u.before grant.u.after)  (fail %task-completion-returned-binding-changed)
  =/  confirmed  (completion-proposal +.trial b member.c)
  ?:  ?=(%| -.confirmed)  (fail p.confirmed)
  ?.  =(p.proposed p.confirmed)  (fail %task-completion-returned-proposal-changed)
  ?.  (completion-entry entry.u.before entry.u.after p.confirmed now.b)
    (fail %task-completion-returned-journal-mismatch)
  =/  next  (state-read +.trial b)
  ?:  ?=(%| -.next)  (fail p.next)
  =/  receipt=receipt:completed  [p.confirmed (rear records.entry.u.after)]
  =/  expected-ui=(list card:agent:gall)
    (updates:rf (capture:rf inner b) (capture:rf +.trial b) %.n)
  ?.  (completion-cards-all our.b now.b member.c entry.u.after receipt p.old p.next expected-ui `[b c] -.trial)
    (fail %task-completion-returned-effects-invalid)
  =/  retired=record:campaign
    (unavailable:campaign prior %awaiting-next-task %qpc-task-completed)
  [+.trial held(records (~(put by records.held) id.command.task.prior retired)) -.trial]
++  fresh-flags
  |=  [inner=agent:gall b=bowl:gall member=@ux]
  ^-  (each [observed=? managed=?] @tas)
  =/  raw  (raw:instrument inner b /x/qpc/observations)
  ?~  raw  [%| %task-handoff-observer-unavailable]
  =/  observed  ((soft ,state:obs) u.raw)
  ?~  observed  [%| %task-handoff-observer-invalid]
  =/  raw  (raw:instrument inner b /x/qpc/required-sessions)
  ?~  raw  [%| %task-handoff-gate-unavailable]
  =/  required  ((soft ,[%qpc-session-gate-v1 %viki ids=(set @ux)]) u.raw)
  ?~  required  [%| %task-handoff-gate-invalid]
  [%& [(lien ~(val by frames.u.observed) |=(f=frame:obs =(member session.work.f))) (~(has in ids.u.required) member)]]
++  ready
  |=  [w=world plan=plan:instrument source=revision:nc]
  ^-  ?
  ?&  ?=(~ refresh.w)  ?=(~ fault.ordered.w)
      !(pending:history ordered.w stream.plan)
      (successor-continuity:instrument ordered.w stream.plan source)
  ==
++  prepare-with
  :: The two injected readers are private proof seams. Public act fixes them
  :: to native completion inspection and complete bounded Graf pagination.
  |=  $:  inner=agent:gall  b=bowl:gall  held=state:campaign
          fetch=reader:read  inspect=inspector  keep=keeper
          c=[prior=@ux next=command:campaign plan=plan:instrument expected=@ux]
      ==
  ^-  change
  =/  fail  |=(reason=@tas (refuse inner held member.next.c reason))
  ?.  =(our.b src.b)  (fail %task-handoff-owner-required)
  ?.  (valid:campaign our.b held)  (fail %task-handoff-campaign-state-invalid)
  =/  found  (~(get by records.held) prior.c)
  ?~  found  (fail %task-handoff-prior-missing)
  =/  prior=record:campaign  u.found
  ?.  ?&  =(%awaiting-next-task phase.prior)
          =(`%qpc-task-completed reason.prior)
          ?=(~ request.prior)  ?=(~ due.prior)  ?=(~ child.prior)
      ==  (fail %task-handoff-prior-unsettled)
  =/  inspected  (inspect inner b member.command.task.prior)
  ?:  ?=(%| -.inspected)  (fail p.inspected)
  ?.  =(expected.c (digest:completed receipt.p.inspected))
    (fail %task-handoff-completion-changed)
  ?.  =(member.next.c session.plan.c)  (fail %task-handoff-next-plan-mismatch)
  =/  refreshed-inner  (refresh-current inner b member.command.task.prior)
  ?:  ?=(%| -.refreshed-inner)  (fail p.refreshed-inner)
  =.  inner  p.refreshed-inner
  =/  now  (state-read inner b)
  ?:  ?=(%| -.now)  (fail p.now)
  :: Every later campaign on the prior's stream goes to the kernel, which
  :: accepts only settled interrupted ones whose plans the operator stopped.
  =/  interrupted=(list record:campaign)
    %+  skim  ~(val by records.held)
    |=  r=record:campaign
    ?&  !=(prior.c id.command.task.r)
        =(stream.plan.c stream.plan.snapshot.task.r)
        (gth at.task.r at.task.prior)
    ==
  =/  existing  (~(get by records.held) id.next.c)
  ?^  existing
    ?.  ?&  (prepared:campaign u.existing)
            =(next.c command.task.u.existing)
            =(plan.c plan.snapshot.task.u.existing)
        ==  (fail %task-handoff-prepared-task-conflict)
    =/  retained  (keep b id.next.c)
    ?:  ?=(%| -.retained)  (fail p.retained)
    ?.  (bound our.b held u.existing p.retained p.inspected p.now)
      (fail %task-handoff-prepared-link-changed)
    =/  fresh  (fetch inner b next.c %.y)
    ?:  ?=(%| -.fresh)  (fail p.fresh)
    ?.  =(p.fresh snapshot.task.u.existing)
      (fail %task-handoff-prepared-task-changed)
    ?.  (ready p.now plan.c expected.next.c)
      (fail %task-handoff-prepared-source-unsettled)
    [inner held ~]
  ?.  (lth ~(wyt by records.held) record-limit:campaign)
    (fail %qpc-campaign-capacity)
  ?.  (lth ~(wyt by plans.held.p.now) plan-limit:instrument)  (fail %task-handoff-plan-capacity)
  ?.  (ready p.now plan.c source.proposal.receipt.p.inspected)
    (fail %task-handoff-source-unsettled)
  =/  flags  (fresh-flags inner b member.next.c)
  ?:  ?=(%| -.flags)  (fail p.flags)
  =/  entry  (input:observer inner b member.next.c)
  ?.  &(?=(~ entry) !observed.p.flags !managed.p.flags)
    (fail %task-handoff-next-member-not-fresh)
  =/  before  (parts inner b)
  ?~  before  (fail %task-handoff-owned-data-unavailable)
  =/  trial
    (on-poke:~(. inner b(src our.b)) %noun !>([%qpc-instrument-successor-plan-v1 plan.c]))
  ?.  =(~ -.trial)  (fail %task-handoff-plan-produced-cards)
  =/  view  (fetch +.trial b next.c %.y)
  ?:  ?=(%| -.view)  (fail p.view)
  ?.  =(plan.c plan.p.view)  (fail %task-handoff-next-plan-changed)
  =/  snapshot=snapshot:kernel
    [prior task.p.inspected receipt.p.inspected %.y next.c p.view held.p.now ordered.p.now refresh.p.now expected.next.c ~ observed.p.flags managed.p.flags interrupted]
  =/  proposed  (prepare:kernel our.b src.b snapshot)
  ?:  ?=(%| -.proposed)  (fail p.proposed)
  =/  next  (state-read +.trial b)
  ?:  ?=(%| -.next)  (fail p.next)
  =/  after  (parts +.trial b)
  ?~  after  (fail %task-handoff-returned-data-unavailable)
  ?.  (joined-parts our.b u.before u.after p.now p.next held.p.proposed)
    (fail %task-handoff-plan-delta-unconfirmed)
  =/  staged  (prepare:campaign held our.b src.b now.b next.c p.view)
  ?:  ?=(%| -.staged)  (fail p.staged)
  =/  saved=state:campaign
    p.staged(records (~(put by records.p.staged) prior.c prior.p.proposed))
  ?.  (valid:campaign our.b saved)  (fail %task-handoff-result-invalid)
  =/  card=card:agent:gall
    (poke:loop our.b %graf /qpc/native-task-handoff-retain [%attest proposal.p.proposed])
  [+.trial saved ~[card]]
++  activate-with
  |=  $:  inner=agent:gall  b=bowl:gall  held=state:campaign
          fetch=reader:read  inspect=inspector  keep=keeper
          c=[id=@ux task=@ux handoff=@ux]
      ==
  ^-  change
  =/  fail  |=(reason=@tas (refuse inner held 0x0 reason))
  ?.  =(our.b src.b)  (fail %task-handoff-owner-required)
  ?.  (valid:campaign our.b held)  (fail %task-handoff-campaign-state-invalid)
  =/  found  (~(get by records.held) id.c)
  ?~  found  (fail %qpc-campaign-prepared-missing)
  =/  r=record:campaign  u.found
  ?.  =(task.c (task-digest:campaign r))  (fail %qpc-campaign-prepared-task-changed)
  =/  retained  (keep b id.c)
  ?:  ?=(%| -.retained)  (fail p.retained)
  ?.  ?&  =(handoff.c (digest:kernel p.retained))
          =(id.c next.p.retained)  =(task.c task.p.retained)
      ==  (fail %task-handoff-retained-proposal-changed)
  :: A previous activation, including an unknown later outcome, never creates
  :: another opening timer. The retained task/fact pins still must match.
  ?.  (prepared:campaign r)  [inner held ~]
  =/  inspected  (inspect inner b member.p.retained)
  ?:  ?=(%| -.inspected)  (fail p.inspected)
  =/  refreshed-inner  (refresh-current inner b member.command.task.r)
  ?:  ?=(%| -.refreshed-inner)  (fail p.refreshed-inner)
  =.  inner  p.refreshed-inner
  =/  now  (state-read inner b)
  ?:  ?=(%| -.now)  (fail p.now)
  ?.  (bound our.b held r p.retained p.inspected p.now)
    (fail %task-handoff-prepared-link-changed)
  =/  plan=plan:instrument  plan.snapshot.task.r
  ?.  (ready p.now plan expected.command.task.r)
    (fail %task-handoff-prepared-source-unsettled)
  =/  fresh  (fetch inner b command.task.r %.y)
  ?:  ?=(%| -.fresh)  (fail p.fresh)
  =/  started
    (activate:campaign held our.b src.b now.b id.c task.c p.fresh)
  ?:  ?=(%| -.started)  (fail p.started)
  =/  opening=record:campaign  (~(got by records.p.started) id.c)
  [inner p.started ~[[%pass (wire-for:campaign id.c opening) %arvo %b %wait (need due.opening)]]]
++  act-with
  :: Internal native proof seam; public commands cannot choose these readers.
  |=  [inner=agent:gall b=bowl:gall held=state:campaign fetch=reader:read inspect=inspector keep=keeper c=command]
  ^-  change
  ?-  -.c
    %qpc-native-task-handoff-prepare-v1
      (prepare-with inner b held fetch inspect keep +.c)
    %qpc-native-campaign-activate-v1
      (activate-with inner b held fetch inspect keep +.c)
  ==
++  act
  |=  [inner=agent:gall b=bowl:gall held=state:campaign fetch=reader:read c=command]
  ^-  change
  (act-with inner b held fetch completion-history retained c)
--
