::  One explicit suggestion, never a commit or replay. Saved authority is Cantrip's.
/-  pa=cantrip-project-access
/+  view=readymade-project-view-client, runtime=cantrip-project-access-runtime,
    model=pataphor-editor-model, recovery=cantrip-project-receipt
|%
+$  phase  ?(%watching %sent %recorded %refused %uncertain)
+$  entry
  $:  key=selector:view  view-request=@ux  request=request:pa  grant=@ux
      recovery=?  root=@ux  snapshot-digest=@ux
      deadline=@da  retained=@da  phase=phase  reason=@tas
      receipt=(unit receipt:pa)
  ==
+$  journal  (map selector:view entry)
+$  change  [journal=journal cards=(list card:agent:gall)]
+$  start  [journal=journal cards=(list card:agent:gall) result=(each entry @tas)]
++  active
  |=  e=entry
  |(=(%watching phase.e) =(%sent phase.e))
++  wire-for
  |=  [k=selector:view deadline=@da]
  ^-  wire
  /collab/project-suggest/(scot %p owner.k)/(scot %ux project.query.k)/(scot %ud generation.query.k)/(scot %ux nonce.query.k)/(scot %da deadline)
++  parse-wire
  |=  wir=wire
  ^-  (unit [key=selector:view deadline=@da])
  ?.  ?=([%collab %project-suggest *] wir)  ~
  (parse-wire:view wir(i.t %project-view))
++  operation-wire
  |=  [k=selector:view deadline=@da recovery=?]
  ^-  wire
  =/  prefix=@tas  ?:(recovery %project-suggest-recover %project-suggest)
  /collab/[prefix]/(scot %p owner.k)/(scot %ux project.query.k)/(scot %ud generation.query.k)/(scot %ux nonce.query.k)/(scot %da deadline)
++  parse-operation
  |=  wir=wire
  ^-  (unit [key=selector:view deadline=@da recovery=?])
  ?.  ?=([%collab ?(%project-suggest %project-suggest-recover) *] wir)  ~
  =/  parsed  (parse-wire wir(i.t %project-suggest))
  ?~  parsed  ~
  `[key.u.parsed deadline.u.parsed =(%project-suggest-recover i.t.wir)]
++  operation-cleanup
  |=  [k=selector:view deadline=@da recovery=?]
  ^-  (list card:agent:gall)
  =/  wir=wire  (operation-wire k deadline recovery)
  :~  [%pass wir %agent [owner.k %cantrip] %leave ~]
      [%pass wir %arvo %b %rest deadline]
  ==
++  cleanup
  |=  [k=selector:view deadline=@da]
  ^-  (list card:agent:gall)
  =/  wir=wire  (wire-for k deadline)
  :~  [%pass wir %agent [owner.k %cantrip] %leave ~]
      [%pass wir %arvo %b %rest deadline]
  ==
++  reload
  |=  [our=@p outgoing=boat:gall]
  ^-  (list card:agent:gall)
  %-  zing
  %+  turn  ~(tap by outgoing)
  |=  item=[[wir=wire ship=@p app=@tas] [acked=? pax=path]]
  =/  parsed  (parse-operation wir.item)
  ?~  parsed  ~
  =/  k=selector:view  key.u.parsed
  =/  r=request:pa  [project.query.k generation.query.k nonce.query.k %suggest ~ ~ `@t`0]
  ?.  ?&  =(owner.k ship.item)  =(%cantrip app.item)
          =(pax.item ?:(recovery.u.parsed (route:recovery our query.k) (route:runtime our r)))
      ==  ~
  (operation-cleanup k deadline.u.parsed recovery.u.parsed)
++  begin
  |=  [our=@p now=@da nonce=@ux observed=entry:view pax=path source=@t held=journal]
  ^-  start
  =.  held
    %-  malt
    %+  skim  ~(tap by held)
    |=  row=[key=selector:view value=entry]
    |((active value.row) (lth now retained.value.row))
  ?.  &(=(%ready phase.observed) ?=(^ response.observed))
    [held ~ [%| %ready-view-required]]
  =/  v  u.response.observed
  ?.  ?&  (view-valid:runtime v)  =(our peer.v)  !=(our owner.v)
          =(key.observed [owner.v query.v])  (lth now retained.observed)
          (gth now 0)  (text-valid:model source)
          (lte (met 3 source) 32.768)  (~(has by files.basis.v) pax)
      ==  [held ~ [%| %view-or-source-invalid]]
  =/  k=selector:view  [owner.v query.v(nonce nonce)]
  ?.  (valid-key:view k)  [held ~ [%| %selector-invalid]]
  =/  r=request:pa
    [project.query.k generation.query.k nonce %suggest `[root.basis.v snapshot.basis.v] pax source]
  =/  prior  (~(get by held) k)
  ?^  prior
    ?.  &(=(request.u.prior r) =(grant.u.prior grant.v) =(view-request.u.prior nonce.query.v))
      [held ~ [%| %request-conflict]]
    [held ~ [%& u.prior]]
  ?:  |((gte ~(wyt by held) 32) (gte (lent (skim ~(val by held) active)) 8))
    [held ~ [%| %suggest-capacity]]
  =/  deadline=@da  (add now ~s30)
  =/  e=entry  [k nonce.query.v r grant.v %.n root.basis.v digest.snapshot.basis.v deadline (add deadline ~m5) %watching %awaiting-owner ~]
  =/  wir=wire  (wire-for k deadline)
  :*  (~(put by held) k e)
      :~  [%pass wir %arvo %b %wait deadline]
          [%pass wir %agent [owner.k %cantrip] %watch (route:runtime our r)]
      ==
      [%& e]
  ==
++  recover
  ::  Immutable browser intent is comparison data only, never permission.
  |=  [our=@p now=@da k=selector:view view-request=@ux grant=@ux root=@ux snapshot-digest=@ux pax=path source=@t held=journal]
  ^-  start
  ?.  ?&  (valid-key:view k)  !=(our owner.k)  (gth now 0)
          (gth view-request 0)  (lte (met 0 view-request) 128)
          (gth grant 0)  (lte (met 0 grant) 256)
          (gth root 0)  (lte (met 0 root) 256)
          (gth snapshot-digest 0)  (lte (met 0 snapshot-digest) 256)
          (path-valid:model pax)  (text-valid:model source)  (lte (met 3 source) 32.768)
      ==  [held ~ [%| %recovery-intent-invalid]]
  =/  r=request:pa  [project.query.k generation.query.k nonce.query.k %suggest ~ pax source]
  =/  prior  (~(get by held) k)
  ?^  prior
    ?.  ?&  recovery.u.prior  =(request.u.prior r)  =(grant.u.prior grant)
            =(view-request.u.prior view-request)  =(root.u.prior root)
            =(snapshot-digest.u.prior snapshot-digest)
        ==  [held ~ [%| %recovery-intent-conflict]]
    ::  Even an expired retained attempt never creates another watch implicitly.
    [held ~ [%& u.prior]]
  =.  held
    %-  malt
    %+  skim  ~(tap by held)
    |=  row=[key=selector:view value=entry]
    |((active value.row) (lth now retained.value.row))
  ?:  |((gte ~(wyt by held) 32) (gte (lent (skim ~(val by held) active)) 8))
    [held ~ [%| %recovery-capacity]]
  =/  deadline=@da  (add now ~s30)
  =/  e=entry  [k view-request r grant %.y root snapshot-digest deadline (add deadline ~m5) %watching %recovering-receipt ~]
  =/  wir=wire  (operation-wire k deadline %.y)
  :*  (~(put by held) k e)
      :~  [%pass wir %arvo %b %wait deadline]
          [%pass wir %agent [owner.k %cantrip] %watch (route:recovery our query.k)]
      ==
      [%& e]
  ==
++  receipt-matches
  |=  [our=@p e=entry r=receipt:pa]
  ^-  ?
  ?.  ?&  (receipt-valid:runtime r)  =(owner.key.e owner.r)  =(our peer.r)
          =(grant.e grant.r)  =(%suggest action.request.r)
      ==  %.n
  ?.  recovery.e  =(request.e request.r)
  ?~  parent.request.r  %.n
  ?&  =(query.key.e [project.request.r generation.request.r nonce.request.r])
      =(pax.request.e pax.request.r)  =(source.request.e source.request.r)
      =(root.e root.u.parent.request.r)
      =(snapshot-digest.e digest.snapshot.u.parent.request.r)
  ==
++  finish
  |=  [held=journal e=entry phase=phase reason=@tas receipt=(unit receipt:pa)]
  ^-  change
  [(~(put by held) key.e e(phase phase, reason reason, receipt receipt)) (operation-cleanup key.e deadline.e recovery.e)]
++  receive
  |=  [our=@p src=@p now=@da held=journal wir=wire sign=sign:agent:gall]
  ^-  change
  =/  parsed  (parse-operation wir)
  ?~  parsed  [held ~]
  ?.  =(src owner.key.u.parsed)  [held ~]
  =/  found  (~(get by held) key.u.parsed)
  ?~  found  [held (operation-cleanup key.u.parsed deadline.u.parsed recovery.u.parsed)]
  =/  e=entry  u.found
  ?.  &(=(deadline.e deadline.u.parsed) =(recovery.e recovery.u.parsed))  [held (operation-cleanup key.u.parsed deadline.u.parsed recovery.u.parsed)]
  ?.  (active e)  [held ~]
  ?:  (gte now deadline.e)  (finish held e %uncertain %suggest-timeout ~)
  ?-  -.sign
    %watch-ack
      ?~  p.sign  [held ~]
      (finish held e ?:(&(!recovery.e =(%watching phase.e)) %refused %uncertain) %watch-refused ~)
    %poke-ack
      ?~  p.sign  [held ~]
      (finish held e %uncertain %poke-refused ~)
    %kick  (finish held e %uncertain %closed-without-receipt ~)
    %fact
      ?.  &(=(%noun p.cage.sign) (lte (met 3 (jam q.q.cage.sign)) 131.072))
        (finish held e %uncertain %invalid-reply ~)
      =/  event  ((soft ,event:pa) q.q.cage.sign)
      ?~  event  (finish held e %uncertain %invalid-reply ~)
      =/  value=event:pa  u.event
      ?-  -.value
        %cantrip-project-ready-v1
          ?:  recovery.e  (finish held e %uncertain %unexpected-recovery-ready ~)
          ?.  ?&  =(owner.key.e owner.value)  =(our peer.value)
                  =(grant.e grant.value)
              ==  (finish held e %uncertain %grant-mismatch ~)
          ?.  =(%watching phase.e)  [held ~]
          ::  Commit sent phase with this one card; duplicate ready cannot resend.
          :-  (~(put by held) key.e e(phase %sent, reason %awaiting-receipt))
          ~[[%pass wir %agent [owner.key.e %cantrip] %poke %noun !>(`action:pa`[%cantrip-project-request-v1 request.e])]]
        %cantrip-project-receipt-v1
          =/  r=receipt:pa  receipt.value
          ?.  ?&  |(recovery.e =(%sent phase.e))  (receipt-matches our e r)
              ==  (finish held e %uncertain %receipt-mismatch ~)
          (finish held e %recorded %suggestion-recorded `r)
      ==
  ==
++  wake
  |=  [now=@da held=journal wir=wire]
  ^-  change
  =/  parsed  (parse-operation wir)
  ?~  parsed  [held ~]
  =/  found  (~(get by held) key.u.parsed)
  ?~  found  [held (operation-cleanup key.u.parsed deadline.u.parsed recovery.u.parsed)]
  =/  e=entry  u.found
  ?.  &((active e) =(recovery.e recovery.u.parsed) =(deadline.e deadline.u.parsed) (gte now deadline.e))  [held ~]
  (finish held e %uncertain %suggest-timeout ~)
++  result
  |=  [now=@da k=selector:view held=journal]
  ^-  (unit entry)
  =/  found  (~(get by held) k)
  ?~  found  ~
  ?:  (gte now retained.u.found)  ~
  ?:  &((active u.found) (gte now deadline.u.found))
    `u.found(phase %uncertain, reason %suggest-timeout)
  found
--
