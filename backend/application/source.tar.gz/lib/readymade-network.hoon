::  Private planet connections. A reply proves this peer answered this request;
::  it grants no call, room, file, terminal or model permission.
|%
+$  peer  [name=@t ticket=@uv requested=@da heard=@da phase=?(%waiting %connected %refused) application=?(%unknown %ready %unavailable) fleet=?]
+$  state  [serial=@ud peers=(map @p peer)]
+$  move
  $%  [%connect ship=@t name=@t]
      [%remove ship=@t]
      [%fleet ship=@t member=?]
      [%hello ticket=@uv]
      [%reply ticket=@uv]
  ==
++  named
  |=  text=@t
  ^-  @p
  ?>  (lte (met 3 text) 128)
  =/  who  (slaw %p text)
  ?>  ?=(^ who)
  ?>  &(=(text (scot %p u.who)) (lte (met 0 u.who) 128))
  u.who
++  step
  |=  [b=bowl:gall s=state m=move]
  ^-  (quip card:agent:gall state)
  ?-  -.m
    %connect
      ?>  =(our.b src.b)
      =/  who=@p  (named ship.m)
      ?>  !=(who our.b)
      ?>  (lte (met 3 name.m) 96)
      ?>  |((~(has by peers.s) who) (lth ~(wyt by peers.s) 64))
      =/  serial=@ud  +(serial.s)
      =/  ticket=@uv  (end [0 128] (sham [our.b who serial now.b]))
      =/  old=(unit peer)  (~(get by peers.s) who)
      =/  row=peer  [name.m ticket now.b ?~(old *@da heard.u.old) %waiting %unknown ?~(old %.n fleet.u.old)]
      :_  s(serial serial, peers (~(put by peers.s) who row))
      ~[[%pass /network/(scot %p who)/(scot %uv ticket) %agent [who %call] %poke %noun !>([%network `move`[%hello ticket]])]]
    %remove
      ?>  =(our.b src.b)
      [~ s(peers (~(del by peers.s) (named ship.m)))]
    %fleet
      ?>  =(our.b src.b)
      =/  who=@p  (named ship.m)
      =/  row=peer  (~(got by peers.s) who)
      [~ s(peers (~(put by peers.s) who row(fleet member.m)))]
    %hello
      ?>  (lte (met 0 ticket.m) 128)
      :_  s
      ~[[%pass /network-reply %agent [src.b %call] %poke %noun !>([%network `move`[%reply ticket.m]])]]
    %reply
      =/  old=(unit peer)  (~(get by peers.s) src.b)
      ?~  old  [~ s]
      ?.  =(ticket.m ticket.u.old)  [~ s]
      ?:  ?=(%ready application.u.old)  [~ s]
      [~ s(peers (~(put by peers.s) src.b u.old(heard now.b, phase %connected, application %ready)))]
  ==
++  acknowledged
  |=  [s=state who=@p ticket=@uv now=@da accepted=?]
  ^-  state
  =/  old=(unit peer)  (~(get by peers.s) who)
  ?~  old  s
  ?.  &(?=(%waiting phase.u.old) =(ticket ticket.u.old))  s
  ::  A remote Gall nack still proves this planet answered. It means its
  ::  Readymade endpoint is unavailable, not that the planet is unreachable.
  s(peers (~(put by peers.s) who u.old(phase %connected, heard now, application ?:(accepted %unknown %unavailable))))
++  contact
  |=  [b=bowl:gall who=@p known=(unit [kind=?(%peer %chum) status=?(%alien %known)])]
  ^-  [phase=@tas at=@da]
  ?~  known  [%unknown *@da]
  ?.  =(%known status.u.known)  [%unknown *@da]
  ?:  =(%chum kind.u.known)
    =/  p  .^(chum-state:ames %ax /(scot %p our.b)//(scot %da now.b)/chums/(scot %p who))
    ?.  ?=(%known -.p)  [%unknown *@da]
    [-.qos.+.p last-contact.qos.+.p]
  =/  p  .^(ship-state:ames %ax /(scot %p our.b)//(scot %da now.b)/peers/(scot %p who))
  ?.  ?=(%known -.p)  [%unknown *@da]
  [-.qos.+.p last-contact.qos.+.p]
::  Read the local Ames census, never probe or publish someone else's contacts.
::  Bound detailed reads to explicit peers, fleet members and 64 known ships.
::  Saved fleet is local organization, never an override of native membership.
++  membership
  |=  [s=state who=@p fleet=(set @p)]
  ^-  [native=? organized=? member=?]
  =/  row=(unit peer)  (~(get by peers.s) who)
  =/  native=?  (~(has in fleet) who)
  =/  organized=?  ?~(row %.n fleet.u.row)
  [native organized |(native organized)]
++  view
  |=  [b=bowl:gall s=state fleet=(set @p)]
  ^-  json
  =/  all=(map ship [kind=?(%peer %chum) status=?(%alien %known)])
    .^((map ship [kind=?(%peer %chum) status=?(%alien %known)]) %ax /(scot %p our.b)//(scot %da now.b)/chums/all)
  =/  visible=(list @p)
    (scag 64 (sort (murn ~(tap by all) |=([who=@p * status=?(%alien %known)] ?:(&(?=(%known status) (gte (met 0 who) 17) (lte (met 0 who) 32)) `who ~))) lth))
  =/  local=(list @p)
    %+  murn  ~(tap by all)
    |=  [who=@p meta=[kind=?(%peer %chum) status=?(%alien %known)]]
    ?.  &(=(our.b `@p`(mod who (bex 32))) !=(our.b who))  ~
    =/  qos  (contact b who `meta)
    ?.  &(?=(%live phase.qos) (gte at.qos (sub now.b ~m20)))  ~
    `who
  =.  fleet  (~(gas in fleet) local)
  =/  ships=(set @p)
    (~(del in (silt (weld visible (weld (scag 128 (sort ~(tap in fleet) lth)) ~(tap in ~(key by peers.s)))))) our.b)
  =/  rows=(list json)
    %+  turn  (sort ~(tap in ships) lth)
    |=  who=@p
    =/  row=(unit peer)  (~(get by peers.s) who)
    =/  qos  (contact b who (~(get by all) who))
    =/  affiliation  (membership s who fleet)
    %-  pairs:enjs:format
    :~  ['ship' s+(scot %p who)]
        ['name' s+?~(row '' name.u.row)]
        ['fleet' b+member.affiliation]
        ['nativeFleet' b+native.affiliation]
        ['localFleet' b+organized.affiliation]
        ['saved' b+?=(^ row)]
        ['connection' s+?~(row 'visible' phase.u.row)]
        ['application' s+?~(row 'unknown' application.u.row)]
        ['requested' ?~(row ~ (sect:enjs:format requested.u.row))]
        ['verified' ?~(row ~ ?:(=(heard.u.row *@da) ~ (sect:enjs:format heard.u.row)))]
        ['transport' s+phase.qos]
        ['lastHeard' ?:(?|(=(%unknown phase.qos) =(%unborn phase.qos)) ~ (sect:enjs:format at.qos))]
    ==
  %-  pairs:enjs:format
  :~  ['schema' s+'readymade-network-v1']
      ['owner' s+(scot %p our.b)]
      ['at' (sect:enjs:format now.b)]
      ['tracked' (numb:enjs:format ~(wyt by all))]
      ['discoveryLimit' (numb:enjs:format 64)]
      ['peers' a+rows]
  ==
--
