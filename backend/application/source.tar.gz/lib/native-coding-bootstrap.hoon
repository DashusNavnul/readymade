::  Owner-directed, once-recorded project provisioning. The Gall owner must
::  persist transition.held and emit transition.cards in the SAME event.
::  No automatic retry, activation, mount, catalog creation, or history rewrite.
::  Existing projects enter through %adopt; their sources and claim are retained.
/-  nc=native-coding, ws=workspace
/+  project=native-coding-project, private=pataphor-editor-read,
    seats=seat-session, dsr=desk-shell-read
|%
+$  existing  [working=revision:nc claim=claim:ws]
+$  request
  $:  %native-coding-bootstrap-request-v1
      nonce=@ux  project=project:nc  baseline=revision:nc
      holder=@p  purpose=@t  task=(unit @ux)
      mode=?(%clone %adopt)  existing=(unit existing)
  ==
+$  observation
  $:  accepted=tree:nc  working=tree:nc  origin=tree:nc
      parents=(list tako:clay)  claim=claim:ws
  ==
+$  record
  $:  %native-coding-bootstrap-record-v1
      request=request  at=@da  basis=tree:nc  parents=(list tako:clay)
      status=?(%isolating %submitted %ready)
      observed=(unit observation)
  ==
+$  ledger  (map @ux record)
+$  transition  [held=ledger record=record cards=(list card:agent:gall)]
++  request-valid
  |=  [our=@p r=request]
  ^-  ?
  ?&  (valid:project project.r)
      =(our authority.spec.project.r)
      !=(0 nonce.r)  (lte (met 0 nonce.r) 256)
      |(=(our holder.r) (ours:seats our holder.r))
      !=(0 purpose.r)  (lte (met 3 purpose.r) 4.096)
      ?~(task.r %.y &(!=(0 u.task.r) (lte (met 0 u.task.r) 256)))
      (revision-valid:project baseline.r)
      =(our owner.baseline.r)  =(base-desk.spec.project.r desk.baseline.r)
      ?:  =(%clone mode.r)  ?=(~ existing.r)
      ?~  existing.r  %.n
      =/  e=existing  u.existing.r
      ?&  (revision-valid:project working.e)
          =(our owner.working.e)  =(working.project.r desk.working.e)
          =(working.project.r fork.claim.e)
          =(base-desk.spec.project.r base.claim.e)
          =(holder.r holder.claim.e)  =(purpose.r purpose.claim.e)
      ==
  ==
++  dome
  |=  [our=@p at=@da desk=@tas]
  ^-  (unit dome:clay)
  =/  domes=cone:clay
    .^(cone:clay %cx /(scot %p our)//(scot %da at)/domes)
  (~(get by domes) [our desk])
++  isolated
  |=  d=dome:clay
  ^-  ?
  &(=(%dead liv.d) =(~ ren.d) =(~ wic.d))
++  parents-at
  |=  [our=@p at=@da r=revision:nc]
  ^-  (list tako:clay)
  =/  commit=yaki:clay
    .^(yaki:clay %cs (beam:dsr our at desk.r /yaki/(scot %uv commit.r)))
  p.commit
++  retain
  |=  [held=ledger r=record cards=(list card:agent:gall)]
  ^-  transition
  [(~(put by held) nonce.request.r r) r cards]
++  valid
  ::  Saved-state validation is pure. Existing enclosing agent state must be
  ::  carried unchanged when adding an empty ledger; source adoption is explicit.
  |=  [our=@p held=ledger]
  ^-  ?
  ?&  (lte ~(wyt by held) 128)
      %+  levy  ~(tap by held)
      |=  [key=@ux r=record]
      ?&  =(key nonce.request.r)  (request-valid our request.r)
          (tree-valid:project project.request.r basis.r)
          =(baseline.request.r revision.basis.r)
          (lte (lent parents.r) 4.096)
          |(!=(%adopt mode.request.r) =(%ready status.r))
          ?:  !=(%ready status.r)  ?=(~ observed.r)
          ?~  observed.r  %.n
          =/  o=observation  u.observed.r
          ?&  (tree-valid:project project.request.r accepted.o)
              (tree-valid:project project.request.r working.o)
              (tree-valid:project project.request.r origin.o)
              =(working.project.request.r desk.revision.working.o)
              =(base-desk.spec.project.request.r desk.revision.accepted.o)
              =(working.project.request.r fork.claim.o)
              =(base-desk.spec.project.request.r base.claim.o)
              =(holder.request.r holder.claim.o)
              =(purpose.request.r purpose.claim.o)
              =(working.project.request.r desk.revision.origin.o)
              (lte (lent parents.o) 4.096)
          ==
      ==
  ==
++  submit
  ::  Caller supplies authenticated Gall src as actor, never JSON/model actor.
  ::  The approved baseline is a full numbered revision, not an ambient HEAD.
  |=  [our=@p at=@da actor=@p held=ledger r=request]
  ^-  (each transition @tas)
  ?.  &(=(our actor) (request-valid our r))  [%| %bootstrap-request-refused]
  =/  previous  (~(get by held) nonce.r)
  ?^  previous
    ?.  =(r request.u.previous)  [%| %bootstrap-nonce-conflict]
    [%& [held u.previous ~]]
  ?:  (gte ~(wyt by held) 128)  [%| %bootstrap-capacity]
  ::  A second nonce cannot reuse a desk, including an unresolved preparation.
  ?:  %+  lien  ~(tap by held)
      |=  [key=@ux value=record]
      =(working.project.r working.project.request.value)
    [%| %bootstrap-desk-reserved]
  =/  registered  (catalog:project our at project.r)
  ?:  ?=(%| -.registered)  [%| p.registered]
  =/  basis  (tree-at:project our at project.r desk.baseline.r number.baseline.r)
  ?:  ?=(%| -.basis)  [%| p.basis]
  ?.  =(baseline.r revision.p.basis)  [%| %bootstrap-baseline-mismatch]
  ?.  (private-path:private our at desk.baseline.r /)  [%| %bootstrap-baseline-not-private]
  =/  parents=(list tako:clay)  (parents-at our at baseline.r)
  ?:  (gth (lent parents) 4.096)  [%| %bootstrap-parent-limit]
  =/  retained=record  [%native-coding-bootstrap-record-v1 r at p.basis parents %isolating ~]
  ?:  =(%adopt mode.r)
    ?>  ?=(^ existing.r)
    ?.  (lte at.claim.u.existing.r at)  [%| %bootstrap-claim-from-future]
    =/  now  (current:project our at project.r)
    ?:  ?=(%| -.now)  [%| p.now]
    ?.  =(working.u.existing.r revision.working.p.now)  [%| %bootstrap-existing-mismatch]
    =/  observed=observation
      [accepted.p.now working.p.now working.p.now (parents-at our at working.u.existing.r) claim.u.existing.r]
    [%& (retain held retained(status %ready, observed `observed) ~)]
  =/  target  (dome our at working.project.r)
  ?^  target  [%| %bootstrap-existing-desk]
  ::  Permission preparation creates only an empty dead desk. Clone is a
  ::  separate, recorded transition after observing these rules and isolation.
  =/  permission=card:agent:gall
    :*  %pass  /native-coding-bootstrap/isolate/(scot %ux nonce.r)
        %arvo  %c  %perm  working.project.r  /
        %rw  `[%white ~]  `[%white ~]
    ==
  [%& (retain held retained ~[permission])]
++  advance
  ::  Owner/controller observation only. A missed reply never resends an
  ::  earlier permission or clone effect. Returned errors leave ledger intact.
  |=  [our=@p at=@da held=ledger nonce=@ux]
  ^-  (each transition @tas)
  =/  found  (~(get by held) nonce)
  ?~  found  [%| %bootstrap-missing]
  =/  r=record  u.found
  ?.  (request-valid our request.r)  [%| %bootstrap-record-invalid]
  ?:  =(%ready status.r)  [%& [held r ~]]
  =/  p=project:nc  project.request.r
  =/  registered  (catalog:project our at p)
  ?:  ?=(%| -.registered)  [%| p.registered]
  =/  target  (dome our at working.p)
  ?~  target  [%| %bootstrap-preparation-unobserved]
  ?.  (isolated u.target)  [%| %bootstrap-work-not-isolated]
  ?.  (private-path:private our at working.p /)  [%| %bootstrap-work-not-private]
  ?:  =(%isolating status.r)
    ?.  &(=(0 let.u.target) =(~ hit.u.target))  [%| %bootstrap-target-changed]
    =/  basis  (tree-at:project our at p desk.baseline.request.r number.baseline.request.r)
    ?:  ?=(%| -.basis)  [%| p.basis]
    ?.  =(basis.r p.basis)  [%| %bootstrap-baseline-changed]
    ?.  (private-path:private our at desk.baseline.request.r /)  [%| %bootstrap-baseline-not-private]
    =/  clone=card:agent:gall
      :*  %pass  /native-coding-bootstrap/clone/(scot %ux nonce)
          %arvo  %c  %merg  working.p  our  desk.baseline.request.r
          [%ud number.baseline.request.r]  %init
      ==
    [%& (retain held r(status %submitted) ~[clone])]
  ?.  (gth let.u.target 0)  [%| %bootstrap-clone-unobserved]
  ::  The first numbered commit must be the exact cloned commit. Later working
  ::  changes are observed separately; they cannot erase proof of the origin.
  =/  origin  (tree-at:project our at p working.p 1)
  ?:  ?=(%| -.origin)  [%| p.origin]
  ?.  ?&  =(root.baseline.request.r root.revision.p.origin)
          =(commit.baseline.request.r commit.revision.p.origin)
          =(files.body.snapshot.basis.r files.body.snapshot.p.origin)
      ==  [%| %bootstrap-origin-mismatch]
  =/  parents=(list tako:clay)  (parents-at our at revision.p.origin)
  ?.  =(parents.r parents)  [%| %bootstrap-parents-mismatch]
  =/  now  (current:project our at p)
  ?:  ?=(%| -.now)  [%| p.now]
  =/  claim=claim:ws
    [%1 working.p base-desk.spec.p holder.request.r purpose.request.r at.r]
  =/  observed=observation
    [accepted.p.now working.p.now p.origin parents claim]
  [%& (retain held r(status %ready, observed `observed) ~)]
++  key-for
  ::  Matching wire only invites a canonical read; it never certifies success.
  |=  w=wire
  ^-  (unit @ux)
  ?.  ?=([%native-coding-bootstrap @ @ ~] w)  ~
  ?.  ?=(?(%isolate %clone %ready) i.t.w)  ~
  =/  key  (slaw %ux i.t.t.w)
  ?~  key  ~
  ?.  &(!=(0 u.key) (lte (met 0 u.key) 256) =((scot %ux u.key) i.t.t.w))  ~
  key
++  completion
  ::  Optional native wake-up, not a timer. %perm's %done and %merg's %mere
  ::  may prompt advance; neither ACK is proof. An exact revision subscription
  ::  also wakes submitted clones once content exists, even after ACK loss.
  |=  [our=@p r=record]
  ^-  (list card:agent:gall)
  ?.  =(%submitted status.r)  ~
  :~  :*  %pass  /native-coding-bootstrap/ready/(scot %ux nonce.request.r)
          %arvo  %c  %warp  our  working.project.request.r
          ~  %sing  %z  [%ud 1]  /
      ==
  ==
--
