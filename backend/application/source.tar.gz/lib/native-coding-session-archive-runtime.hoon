::  Internal owner archive coordinator. The app must bind the trusted native
::  eligibility gates; neither gate nor its result is accepted from a poke.
::  Pending writes are persisted before cards are returned and never retried.
/+  law=native-coding-session-archive-retirement,
    history=native-coding-session-archive-history,
    io=native-coding-session-archive-history-io,
    listing=native-coding-session-archive-list,
    loop=native-coding-loop, opening=viki-native-opening,
    carried=native-coding-session-archive-carried
|%
+$  state  state:history
+$  head  head:history
+$  page-request  [offset=@ud revision=@ud commit=@uv]
+$  submitted  [state=state cards=(list card:agent:gall)]
::  organs are the completion, campaign and reviewed receipts that leave with
::  the session; the app writes back the stripped organs with coding/openings.
+$  settled  [state=state coding=state:loop openings=ledger:opening organs=organs:carried]
+$  qualify
  $-  [b=bowl:gall id=@ux expected=@ux coding=state:loop openings=ledger:opening organs=organs:carried]
  (each receipt:law @tas)
+$  requalify
  $-  [b=bowl:gall expected=receipt:law coding=state:loop openings=ledger:opening organs=organs:carried stored=receipt:law]
  (each retirement:law @tas)
++  empty  ^-  state  [~ ~]
++  parse-page
  |=  path=path
  ^-  (each page-request @tas)
  ?.  ?=([%x %native-coding %session-archive %page @ @ @ ~] path)
    [%| %archive-page-path-invalid]
  =/  offset  (slaw %ud i.t.t.t.t.path)
  ?~  offset  [%| %archive-page-offset-invalid]
  =/  revision  (slaw %ud i.t.t.t.t.t.path)
  ?~  revision  [%| %archive-page-head-invalid]
  =/  commit  (slaw %uv i.t.t.t.t.t.t.path)
  ?~  commit  [%| %archive-page-head-invalid]
  ?.  &(=((scot %ud u.offset) i.t.t.t.t.path) =((scot %ud u.revision) i.t.t.t.t.t.path) =((scot %uv u.commit) i.t.t.t.t.t.t.path))
    [%| %archive-page-head-invalid]
  ?.  =(=(0 u.revision) =(0 u.commit))  [%| %archive-page-head-invalid]
  ?:  &(=(0 u.revision) !=(0 u.offset))  [%| %archive-page-head-required]
  [%& [u.offset u.revision u.commit]]
++  valid
  ::  Restore validates the saved shape without attempting or repeating IO.
  |=  [our=@p s=state]
  ^-  ?
  ?~  head.s  ?=(~ writing.s)
  ?.  (valid-head:history u.head.s)  %.n
  ?~  writing.s  %.y
  (valid-receipt:law our u.writing.s)
++  reserve
  ::  Exclusion omits only this archive's addition; any other claim stays.
  |=  [s=state held=(set @tas) exclude=(unit @tas)]
  ^-  (set @tas)
  ?~  head.s  held
  ?^  exclude
    ?:  =(u.exclude desk.u.head.s)  held
    (~(put in held) desk.u.head.s)
  (~(put in held) desk.u.head.s)
++  configure
  |=  [b=bowl:gall s=state desk=@tas]
  ^-  (each state @tas)
  (configure:io b s desk)
++  read-history
  |=  [b=bowl:gall s=state id=@ux]
  ^-  found:io
  ?.  =(our.b src.b)  [%| %archive-owner-required]
  ?~  head.s  [%| %archive-history-unconfigured]
  (lookup:io our.b now.b u.head.s id)
++  page-history
  |=  [b=bowl:gall s=state expected=(unit head) offset=@ud limit=@ud]
  ^-  (each page:listing @tas)
  (history-page:io b s expected offset limit)
++  start
  |=  [b=bowl:gall s=state id=@ux expected=@ux coding=state:loop openings=ledger:opening organs=organs:carried check=qualify]
  ^-  (each submitted @tas)
  ?.  =(our.b src.b)  [%| %archive-owner-required]
  ?^  writing.s  [%| %archive-write-pending]
  =/  cold  (check b id expected coding openings organs)
  ?:  ?=(%| -.cold)  [%| p.cold]
  ?.  &(=(id session.p.cold) =(expected evidence.p.cold))  [%| %archive-observation-changed]
  =/  next  (append:io b s p.cold)
  ?:  ?=(%| -.next)  [%| p.next]
  [%& [state.p.next cards.p.next]]
++  settle
  |=  [b=bowl:gall s=state written=confirmed:history coding=state:loop openings=ledger:opening organs=organs:carried check=requalify]
  ^-  (each settled @tas)
  ?.  =(our.b src.b)  [%| %archive-owner-required]
  ?~  writing.s  [%| %archive-write-not-pending]
  ?.  =(u.writing.s receipt.written)  [%| %archive-readback-mismatch]
  =/  retired  (check b u.writing.s coding openings organs receipt.written)
  ?:  ?=(%| -.retired)  [%| p.retired]
  =/  exact  (retire:law our.b src.b u.writing.s coding openings organs `receipt.written)
  ?.  =(retired exact)  [%| %archive-retirement-mismatch]
  [%& [state.written coding.p.retired openings.p.retired organs.p.retired]]
++  finish
  |=  [b=bowl:gall s=state w=wire sign=sign-arvo coding=state:loop openings=ledger:opening organs=organs:carried check=requalify]
  ^-  (each settled @tas)
  =/  written  (callback:io b s w sign)
  ?:  ?=(%| -.written)  [%| p.written]
  (settle b s p.written coding openings organs check)
++  recover
  ::  Observe the existing write after a missed callback, without resubmission.
  |=  [b=bowl:gall s=state coding=state:loop openings=ledger:opening organs=organs:carried check=requalify]
  ^-  (each settled @tas)
  =/  written  (observe:io b s)
  ?:  ?=(%| -.written)  [%| p.written]
  (settle b s p.written coding openings organs check)
--
