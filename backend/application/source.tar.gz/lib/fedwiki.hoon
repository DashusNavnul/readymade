::  /lib/fedwiki.hoon
::
::  Federated wiki's page rules, so a ship can hold, serve and fork the
::  delay's cards.  Fedwiki has two rule sets and so does this core:
::
::    +put     the SERVER's write (wiki-server lib/server.js 848-908):
::             what a site stores when an action arrives
::    +replay  the CLIENT's history view (wiki-client lib/revision.js):
::             the page as it stood at one journal entry
::
::  They disagree on purpose-built edges: an edit naming a missing item
::  changes nothing on the server but appends in the history view, and
::  a move naming a missing item is refused by the server.  An add with
::  no `after`, or an `after` that is not on the page, goes to the TOP.
::
/-  fw=fedwiki
|%
::  +as-slug: a title's page name (wiki-server lib/sitemap.js asSlug).
::  JavaScript whitespace becomes '-', anything else outside
::  [A-Za-z0-9-] is dropped, and letters go to lower case.  The bytes
::  are decoded here, not by +tuba: the stdlib's +teff asserts every
::  byte is a newline or at least 32, so a tab in a title would crash.
::
++  as-slug
  |=  title=@t
  ^-  @t
  =/  bytes=(list @)  (rip 3 title)
  =|  out=tape
  |-
  ?~  bytes  (crip (flop out))
  =/  n=@ud
    ?:  (lth i.bytes 0xc0)  1                ::  ascii, or a stray tail
    ?:((lth i.bytes 0xe0) 2 ?:((lth i.bytes 0xf0) 3 4))
  ::  the wet +scag and +slag must see a plain list, not the
  ::  non-empty one ?~ refined, or their recursion nest-fails
  =/  all=(list @)  bytes
  ?:  (gth n (lent all))  (crip (flop out))
  =/  c=@c  (utf8-point (scag n all))
  =?  out  (js-space c)  ['-' out]
  =?  out  &((gte c 'A') (lte c 'Z'))  [(@tD (add c 32)) out]
  =?  out  ?|  &((gte c 'a') (lte c 'z'))
               &((gte c '0') (lte c '9'))
               =(c '-')
           ==
    [(@tD c) out]
  $(bytes (slag n all))
::  +utf8-point: the code point one UTF-8 sequence spells
::
++  utf8-point
  |=  seq=(list @)
  ^-  @c
  ?~  seq  (@c 0)
  ?~  t.seq  (@c i.seq)
  =/  acc=@
    ?:  (lth i.seq 0xe0)  (dis i.seq 0x1f)
    ?:((lth i.seq 0xf0) (dis i.seq 0xf) (dis i.seq 0x7))
  =/  rest=(list @)  t.seq
  |-
  ?~  rest  (@c acc)
  $(acc (add (lsh [0 6] acc) (dis i.rest 0x3f)), rest t.rest)
::  +js-space: the code points JavaScript's \s matches
::
++  js-space
  |=  c=@c
  ^-  ?
  ?|  &((gte c 0x9) (lte c 0xd))
      =(c 0x20)  =(c 0xa0)  =(c 0x1680)
      &((gte c 0x2000) (lte c 0x200a))
      =(c 0x2028)  =(c 0x2029)  =(c 0x202f)  =(c 0x205f)
      =(c 0x3000)  =(c 0xfeff)
  ==
::
++  ids
  |=  story=(list item:fw)
  ^-  (list @t)
  (turn story |=(i=item:fw id.i))
::  +slot-after: where an add lands, indexOf(after) + 1, so a missing
::  or unknown `after` lands at 0
::
++  slot-after
  |=  [story=(list item:fw) after=(unit @t)]
  ^-  @ud
  ?~  after  0
  =/  at  (find ~[u.after] (ids story))
  ?~(at 0 +(u.at))
::
++  find-item
  |=  [story=(list item:fw) id=@t]
  ^-  (unit item:fw)
  ?~  story  ~
  ?:(=(id id.i.story) `i.story $(story t.story))
::  +start: the page a create action makes (the server's 404 path);
::  a page that already exists is refused by the caller, as fedwiki
::  answers 409
::
++  start
  |=  $:  date=(unit @ud)
          title=(unit @t)
          story=(unit (list item:fw))
          more=(map @t json)
      ==
  ^-  page:fw
  [(fall title '') (fall story ~) ~[[%create date title story more]]]
::  +put: the server's write.  `fork` is the implicit fork of an action
::  made on another site's page: fedwiki journals [%fork site] dated
::  one millisecond earlier, then the action itself.  The server's two
::  refusals come back as its own words.
::
++  put
  |=  [=page:fw =action:fw fork=(unit @t)]
  ^-  (each page:fw @t)
  =/  story=(each (list item:fw) @t)
    ?-    -.action
      %add     &+(into story.page (slot-after story.page after.action) item.action)
      %remove  &+(skip story.page |=(i=item:fw =(id.i id.action)))
      %edit    &+(turn story.page |=(i=item:fw ?:(=(id.i id.action) item.action i)))
      %create  &+story.page
      %fork    &+story.page
      %other   |+'Unfamiliar action ignored'
        %move
      =/  found=(list (unit item:fw))
        (turn order.action |=(o=@t (find-item story.page o)))
      ?:  (lien found |=(f=(unit item:fw) ?=(~ f)))
        |+'Ignoring move. Try reload.'
      &+(murn found |=(f=(unit item:fw) f))
    ==
  ?:  ?=(%| -.story)  |+p.story
  =/  marks=(list action:fw)
    ?~  fork  ~[action]
    :~  [%fork (bind date.action |=(d=@ud ?:(=(0 d) 0 (dec d)))) fork ~]
        action
    ==
  &+page(story p.story, journal (weld journal.page marks))
::  +fork-in: a page forked here from `site` (the server's push path):
::  the source page whole, its journal, then [%fork site]
::
++  fork-in
  |=  [src=page:fw site=@t date=(unit @ud)]
  ^-  page:fw
  src(journal (snoc journal.src [%fork date `site ~]))
::  +replay: the page as it stood after journal entry `rev`, by the
::  client's rules.  One deliberate difference: a move naming an item
::  not on the page is skipped, where the client would splice in
::  `undefined`.
::
++  replay
  |=  [=page:fw rev=@ud]
  ^-  [title=@t story=(list item:fw)]
  =/  out=[title=@t story=(list item:fw)]  [title.page ~]
  =/  todo  (scag +(rev) journal.page)
  |-
  ?~  todo  out
  =*  a  i.todo
  =.  out
    ?-    -.a
      %fork    out
      %other   out
      %add     out(story (into story.out (slot-after story.out after.a) item.a))
        %create
      :-  ?:(|(?=(~ title.a) =('' u.title.a)) title.out u.title.a)
      ?~(story.a story.out u.story.a)
    ::
        %edit
      =/  at  (find ~[id.a] (ids story.out))
      ?~  at  out(story (snoc story.out item.a))
      out(story (snap story.out u.at item.a))
    ::
        %remove
      =/  at  (find ~[id.a] (ids story.out))
      ?~(at out out(story (oust [u.at 1] story.out)))
    ::
        %move
      =/  here  (find ~[id.a] (ids story.out))
      ?~  here  out
      =/  at  (find ~[id.a] order.a)
      =/  after=(unit @t)
        ?~  at  ~
        ?:(=(0 u.at) ~ `(snag (dec u.at) order.a))
      =/  rest  (oust [u.here 1] story.out)
      out(story (into rest (slot-after rest after) (snag u.here story.out)))
    ==
  $(todo t.todo)
::  +edit-date: the last dated entry that is not a fork
::  (wiki-client lib/refresh.js editDate, wiki-server sitemap lastEdit);
::  a fork does not count as an edit
::
++  edit-date
  |=  journal=(list action:fw)
  ^-  (unit @ud)
  =/  back  (flop journal)
  |-
  ?~  back  ~
  ?:  &(?=(^ date.i.back) !=(0 u.date.i.back) !?=(%fork -.i.back))
    date.i.back
  $(back t.back)
::  +twin: how another site's copy of this page compares to the one
::  being viewed (wiki-client lib/refresh.js): no edit date here, no
::  twins; a remote copy with no edit date compares as the same
::
++  twin
  |=  [viewing=page:fw remote=page:fw]
  ^-  (unit ?(%newer %older %same))
  =/  mine  (edit-date journal.viewing)
  ?~  mine  ~
  =/  theirs  (edit-date journal.remote)
  ?~  theirs  `%same
  ?:  (gth u.theirs u.mine)  `%newer
  ?:  (lth u.theirs u.mine)  `%older
  `%same
--
