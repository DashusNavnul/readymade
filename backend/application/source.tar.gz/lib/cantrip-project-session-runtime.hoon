::  One authenticated Ames watch, one native observation, then close.
::  Every watch rechecks authority; no cache, journal, timer or retry exists.
/-  pa=cantrip-project-access, ps=cantrip-project-session, nc=native-coding
/+  core=cantrip-project-session, access=cantrip-project-access-runtime,
    read=cantrip-project-access-read, scoped=native-coding-session-project,
    guard=viki-scry-guard, law=cantrip-law-window
|%
++  observe
  |=  [b=bowl:gall grants=grants:pa held=scopes:core q=query:ps w=window:law]
  ^-  (each response:ps @tas)
  ::  Existing source-view admission still owns current membership, generation,
  ::  revocation and registered-source scope. Session clones are not inferred.
  =/  admitted  (admit-watch:access b grants (view-request:core q) w)
  ?:  ?=(%| -.admitted)  [%| p.admitted]
  ?.  (agent-live:guard our.b now.b %viki)  [%| %viki-unavailable]
  =/  catalog  (catalog:read our.b our.b now.b project.q)
  ?:  ?=(%| -.catalog)  [%| p.catalog]
  =/  registered=(map @t project:nc)
    .^((map @t project:nc) %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/projects/noun)
  =/  current  (resolve:scoped our.b now.b registered session.q project.q)
  ?:  ?=(%| -.current)  [%| p.current]
  =/  raw=*
    .^(* %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/session/(scot %ux session.q)/noun)
  (observe:core our.b src.b now.b q grants held w p.catalog p.current raw)
++  watch
  |=  [b=bowl:gall grants=grants:pa held=scopes:core pax=path w=window:law]
  ^-  (each (list card:agent:gall) @tas)
  =/  parsed  (parse:core pax)
  ?~  parsed  [%| %path-invalid]
  ?.  =(src.b peer.u.parsed)  [%| %foreign-peer]
  =/  checked  (preflight:core our.b src.b query.u.parsed held w)
  ?:  ?=(%| -.checked)  [%| p.checked]
  ::  An absent or incompatible native route refuses; it never falls back to
  ::  cached session data or an unprotected HTTP/Dojo read.
  =/  observed  (mole |.((observe b grants held query.u.parsed w)))
  ?~  observed  [%| %session-observation-unavailable]
  =/  result  u.observed
  ?:  ?=(%| -.result)  [%| p.result]
  [%& (cards:core pax p.result)]
--
