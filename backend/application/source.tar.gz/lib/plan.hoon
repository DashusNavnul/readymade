::  /lib/plan.hoon
::
::  A PLAN IS A PUBLIC DECISION, NOT AGENT STATE.
::
::  V1 deliberately does one small, named thing: it turns one goal into one
::  actionable step.  The selected Graf handles are part of the decision, so
::  the exact context Viki chose is visible before any want is planted.
::
/-  gol=goal
|%
+$  plan
  $:  %viki-plan-v1
      strategy=%single-step
      goal=gid:gol
      step=step:gol
      refs=(list @t)
  ==
::
::  Pure decomposition.  Model-proposed fan-out is a later strategy; it must
::  not be smuggled into this deterministic first version.
++  make
  |=  [g=goal:gol refs=(list @t)]
  ^-  plan
  :*  %viki-plan-v1
      %single-step
      gid.g
      (step-for:gol g)
      refs
  ==
::
::  The Bachelor sees the same criterion Viki will apply.  Length framing keeps
::  the prompt injective; the criterion remains data, never model-authored law.
++  request-task
  |=  p=plan
  ^-  @t
  ?~  criterion.step.p  task.step.p
  ?-  -.u.criterion.step.p
    %contains
      %+  rap  3
      :~  task.step.p
          '\0aPATAPHOR-ACCEPTANCE-V1 CONTAINS '
          (scot %ud (met 3 needle.u.criterion.step.p))
          '\0a'
          needle.u.criterion.step.p
          '\0a'
      ==
  ==
::
::  The decision is content-addressed.  Identical goal and context produce
::  the identical fact and therefore cannot manufacture duplicate history.
++  pid
  |=  p=plan
  ^-  @ux
  `@ux`(shax (jam p))
::
++  fact
  |=  p=plan
  ^-  *
  [%viki-plan (scot %ux (pid p)) p]
::
::  Plans live as Graf relations over the goal.  The fact above explains the
::  strategy and inputs; these relations are the executable shape.
++  relations
  |=  p=plan
  ^-  (list rel:gol)
  ~[ (needs-rel:gol goal.p step-id.step.p)
     (status-rel:gol goal.p %working)
   ]
--
