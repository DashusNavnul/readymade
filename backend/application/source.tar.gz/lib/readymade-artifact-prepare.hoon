::  Explicit canonical local-build import only. No proposal, ACK or message.
::  saved/ledger MUST come from owner-native state, never supplied JSON/Ames.
::  Future local proposal/ACK requires same-turn actual Cantrip judgment plus
::  explicit owner ratification. This metadata import creates neither.
::  Existing left-only proposal arbitration is unchanged: a right-side builder
::  still needs a later peer-evidence workflow at the left owner.
/-  c=readymade-collab, j=readymade-collab-jobs, p=readymade-pact
/+  kit=readymade-collab-saved, pact=readymade-pact,
    package=readymade-package, build=readymade-package-build,
    artifact=readymade-artifact-collab, flow=readymade-collab
|%
+$  metadata
  $:  %readymade-artifact-local-build-import-v1
      pact=@ux
      tid=@ta
      package=@ux
      builder=@p
      build-proof=@ux
      artifact=@ux
      provenance=%local-canonical
      wire-ready=%|
      admitted=%|
  ==
+$  imported  [saved=saved:kit metadata=metadata]
++  import-build
  ::  Exact owner-selected IDs only. Never infer pact from a matching package.
  |=  [our=@p actor=@p id=@ux tid=@ta value=saved:kit]
  ^-  (each imported @tas)
  ?.  =(our actor)  [%| %foreign-owner]
  ?.  (valid:kit our value)  [%| %invalid-saved]
  ?.  (digest-valid:package id)  [%| %pact-id-invalid]
  ?.  &((gth (met 3 tid) 0) (lte (met 3 tid) 128))
    [%| %build-tid-invalid]
  =/  agreement=(unit agreement:c)  (~(get by pacts.state.value) id)
  ?~  agreement  [%| %unknown-pact]
  =/  terms=terms:p  terms.value.u.agreement
  ?.  &((valid-terms:pact terms) =(id (digest:pact terms)))
    [%| %pact-binding]
  =/  source=(unit package:c)  (~(get by packages.state.value) package.terms)
  ?~  source  [%| %unknown-package]
  =/  job=(unit job:j)  (~(get by ledger.value) tid)
  ?~  job  [%| %unknown-build-job]
  =/  held=job:j  u.job
  ?.  &(=(%build kind.held) =(%confirmed phase.held))
    [%| %confirmed-build-required]
  =/  cmd=command:c  command.held
  =/  offer  offer.value.u.source
  ?.  ?&  =('build' op.cmd)
          =(owner.cmd (scot %p our))
          =(our recipient.body.offer)
          =(peer.cmd (scot %p sender.body.offer))
          (identifier:flow request.cmd)
          =(offer.held `package.terms)
          =(id.cmd (scot %ux package.terms))
          =(digest.cmd id.cmd)
          (digest-valid:package nonce.held)
          =(tid `@ta`(cat 3 'collab-' (scot %ux nonce.held)))
      ==
    [%| %build-job-binding]
  ?~  result.held  [%| %build-result-missing]
  ?.  (lte (met 3 (jam u.result.held)) 131.072)
    [%| %build-result-limit]
  =/  parsed
    ((soft ,[%readymade-package-build-v1 offer=@ux nonce=@ux answer=result:build]) u.result.held)
  ?~  parsed  [%| %build-result-invalid]
  =/  callback  u.parsed
  ?.  &(=(offer.callback package.terms) =(nonce.callback nonce.held))
    [%| %build-callback-binding]
  ?.  ?=(%confirmed -.answer.callback)  [%| %successful-build-required]
  =/  receipt=receipt:build  receipt.answer.callback
  ?.  =(nonce.held nonce.plan.body.receipt)  [%| %build-plan-binding]
  ?.  (local-valid:artifact our value.u.source receipt)
    [%| %canonical-local-build-required]
  =/  moved  (record-local:kit value our id receipt)
  ?:  ?=(%| -.moved)  [%| p.moved]
  [%& [p.moved [%readymade-artifact-local-build-import-v1 id tid package.terms our proof.receipt artifact.body.receipt %local-canonical %.n %.n]]]
--
