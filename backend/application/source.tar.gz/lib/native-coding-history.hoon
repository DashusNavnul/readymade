::  Owner-only, read-only historical pages anchored to retained native tools.
::  Browser source descriptors never supply authority or choose a Clay desk.
/-  nc=native-coding
/+  journal=native-coding-session, files=native-coding-files,
    wire=native-coding-files-http, scoped=native-coding-session-project,
    project=native-coding-project
|%
++  evidence
  |=  [e=entry:journal source=@ux]
  ^-  (unit record:journal)
  =/  records  records.e
  |-  ^-  (unit record:journal)
  ?~  records  ~
  =/  r=record:journal  i.records
  ?.  ?=(%tool -.body.r)  $(records t.records)
  =/  c=context:nc  context.result.body.r
  ?.  ?&  =(source (shax (jam source.c)))
          =(id.session.e session.c)  =(owner.session.e actor.c)
          =(project.session.e project.c)  =(configuration.e configuration.c)
      ==  $(records t.records)
  `r
++  refused
  |=  reason=@tas
  ^-  json
  (pairs:enjs:format ~[['schema' s+'native-coding-history-v1'] ['reason' s+reason] ['result' ~]])
++  current-request
  :: Current read authority is separate from the retained checked context.
  |=  [actor=@p p=project:nc retained=context:nc pax=path start=@ud count=@ud]
  ^-  tool-request:nc
  [%native-coding-tool-request-v1 retained(configuration (configuration:project p), actor actor) 'historical-read' [%read pax start count]]
++  historical-result
  |=  [retained=context:nc request=tool-request:nc answer=tool-result:nc]
  ^-  (each tool-result:nc @tas)
  ?.  ?=(%read -.arguments.request)  [%| %historical-read-result-mismatch]
  ?.  =(context.request retained(configuration configuration.context.request))
    [%| %historical-read-result-mismatch]
  :: Full context equality binds the exact source, IDs and authenticated actor.
  ?.  &(=(context.request context.answer) =(call-id.request call-id.answer))
    [%| %historical-read-result-mismatch]
  ?:  ?=(%refused -.output.answer)  [%| reason.output.answer]
  ?.  ?=(%read -.output.answer)  [%| %historical-read-unavailable]
  ?.  &(=(pax.arguments.request pax.value.output.answer) =(start.arguments.request start.value.output.answer))
    [%| %historical-read-result-mismatch]
  :: A read-only view preserves provenance; no journal or ledger is appended.
  [%& answer(context retained)]
++  read
  |=  [b=bowl:gall projects=(map @t project:nc) sessions=organ:journal id=@ux source=@ux pax=path start=@ud count=@ud]
  ^-  json
  ?.  =(our.b src.b)  (refused %owner-required)
  ?.  &((gte start 1) (lte start 1.000.000.000) (gte count 1) (lte count 200) (lte (lent pax) 64))
    (refused %read-range-invalid)
  =/  found  (~(get by sessions) id)
  ?~  found  (refused %session-unavailable)
  =/  e=entry:journal  u.found
  ?.  =(our.b owner.session.e)  (refused %owner-required)
  =/  retained  (evidence e source)
  ?~  retained  (refused %source-evidence-unavailable)
  =/  r=record:journal  u.retained
  ?>  ?=(%tool -.body.r)
  =/  p  (resolve:scoped our.b now.b projects id project.session.e)
  ?:  ?=(%| -.p)  (refused p.p)
  =/  request=tool-request:nc
    (current-request src.b p.p context.result.body.r pax start count)
  =/  answer=tool-result:nc  (execute:files our.b src.b now.b p.p request ~)
  =/  historical  (historical-result context.result.body.r request answer)
  ?:  ?=(%| -.historical)  (refused p.historical)
  (pairs:enjs:format ~[['schema' s+'native-coding-history-v1'] ['reason' ~] ['result' (record:wire r(body [%tool p.historical]))]])
++  peek
  |=  [b=bowl:gall projects=(map @t project:nc) sessions=organ:journal path=path]
  ^-  (unit (unit cage))
  ?.  ?=([%x %native-coding %historical @ @ @ @ *] path)  ~
  ?.  =(our.b src.b)  ~
  =/  [sid=@tas digest=@tas first=@tas size=@tas pax=(list @ta)]  t.t.t.path
  =/  id  (slaw %ux sid)
  =/  source  (slaw %ux digest)
  =/  start  (slaw %ud first)
  =/  count  (slaw %ud size)
  ?~  id  [~ ~]
  ?~  source  [~ ~]
  ?~  start  [~ ~]
  ?~  count  [~ ~]
  ?.  ?&  =((scot %ux u.id) sid)  =((scot %ux u.source) digest)
          =((scot %ud u.start) first)  =((scot %ud u.count) size)
          (lte (met 0 u.id) 256)  (lte (met 0 u.source) 256)
      ==  [~ ~]
  ``json+!>((read b projects sessions u.id u.source pax u.start u.count))
--
