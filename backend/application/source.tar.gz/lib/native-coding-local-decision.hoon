::  Explicit same-model review policy. Canonical Viki reads authenticate the
::  retained chain; final Cantrip still owns grant, law and landing checks.
/-  nc=native-coding, pa=native-coding-provider-attestation
/+  local=native-coding-local-review, store=native-coding-local-review-state,
    accept=native-coding-accept, sessions=native-coding-session,
    project=native-coding-project, scoped=native-coding-session-project,
    guard=viki-scry-guard, provider=native-coding-provider,
    att=native-coding-provider-attestation
|%
+$  captured  [scope=(unit scope:local) campaign=campaign:store]
++  marker  (digest:local %native-coding-local-review-decision-v1)
++  marked
  |=  d=decision:accept
  ^-  ?
  (~(has in (silt evidence.challenge.d)) marker)
++  enabled-for
  ::  The owner has an enabled local-review scope for this project.
  |=  [scopes=(map @t scope:local) project=@t]
  ^-  ?
  =/  s  (~(get by scopes) project)
  &(?=(^ s) enabled.u.s)
++  has-scope
  |=  [our=@p at=@da project=@t]
  ^-  ?
  ?.  (agent-live:guard our at %viki)  %.n
  =/  raw=*
    .^(* %gx /(scot %p our)/viki/(scot %da at)/native-coding/local-review/scopes/noun)
  =/  scopes  ((soft ,(map @t scope:local)) raw)
  ?~  scopes  %.n
  (enabled-for u.scopes project)
++  decide
  ::  Pure consistency only. +offer/+admit supply canonically owned inputs.
  |=  $:  our=@p  at=@da  held=captured  p=project:nc
          c=candidate:nc  r=report:accept  objective=@t
      ==
  ^-  (each decision:accept @tas)
  =/  h=campaign:store  campaign.held
  =/  f=frozen:local  frozen.request.h
  ?~  scope.held  [%| %local-review-scope-missing]
  ?.  &(enabled.u.scope.held =(u.scope.held scope.request.h))
    [%| %local-review-scope-revoked]
  =/  s=state:store
    [(~(put by *(map @t scope:local)) project.u.scope.held u.scope.held) (~(put by *(map @ux campaign:store)) id.c h)]
  ?.  (valid:store our s)  [%| %local-review-evidence-invalid]
  ?.  &(!=(0 at) (gte at started.h))  [%| %local-review-decision-time]
  ?.  =([p c r objective] [project.f candidate.f report.f objective.f])
    [%| %local-review-frozen-input-changed]
  =/  no-verdict=?  (unread:store h)
  ?:  &(?=(^ reason.h) !no-verdict)  [%| (need reason.h)]
  ?^  pending.h  [%| %local-review-pending]
  =/  judged=(unit judgment:local)
    ?.  no-verdict  outcome.h
    `[%refuse (cat 3 'The review ended with no readable verdict: ' (need reason.h))]
  ?~  judged  [%| %local-review-outcome-missing]
  ?.  ?=(?(%accept %refuse) kind.u.judged)  [%| %local-review-outcome-invalid]
  =/  accepted=?  =(%accept kind.u.judged)
  =/  evidence=(list @ux)
    :~  marker  (digest:local [%native-coding-local-review-decision-v1 h])
        (artifact:local request.h)
    ==
  =/  challenge=challenge:accept
    :*  %native-coding-challenge-v1  id.c  (digest:accept r)
        ?:(accepted %passed %failed)  evidence
        (cat 3 'Local same-model review (separate requests, not independent reviewers): ' reason.u.judged)
    ==
  =/  d=decision:accept
    [%native-coding-decision-v1 id.c context.c basis.c r challenge ?:(accepted %approve %revise) source.context.c at]
  ?.  (decision-valid:accept p c d)  [%| %local-review-decision-invalid]
  [%& d]
++  lookup
  |=  [our=@p at=@da id=@ux]
  ^-  (each (unit captured) @tas)
  ?.  (agent-live:guard our at %viki)  [%| %local-review-owner-unavailable]
  =/  raw=*
    .^(* %gx /(scot %p our)/viki/(scot %da at)/native-coding/local-review/candidate/(scot %ux id)/noun)
  =/  found  ((soft ,(unit campaign:store)) raw)
  ?~  found  [%| %local-review-owner-incompatible]
  ?~  u.found  [%& ~]
  =/  h=campaign:store  u.u.found
  =/  raw=*
    .^(* %gx /(scot %p our)/viki/(scot %da at)/native-coding/local-review/scopes/noun)
  =/  scopes  ((soft ,(map @t scope:local)) raw)
  ?~  scopes  [%| %local-review-scopes-incompatible]
  [%& `[(~(get by u.scopes) project.scope.request.h) h]]
++  current
  ::  Reconstruct current instructions from the retained operator journal.
  ::  A changed provider, project, session or source invalidates old approval.
  |=  [our=@p at=@da h=campaign:store]
  ^-  (unit @tas)
  =/  f=frozen:local  frozen.request.h
  =/  c=candidate:nc  candidate.f
  =/  raw=*
    .^(* %gx /(scot %p our)/viki/(scot %da at)/native-coding/qpc-input/(scot %ux session.context.c)/noun)
  =/  input  ((soft ,(unit [entry=entry:sessions key=@tas grant=@ux])) raw)
  ?.  &(?=(^ input) ?=(^ u.input))  `%local-review-session-unavailable
  =/  e=entry:sessions  entry.u.u.input
  ?.  ?&  =(our owner.session.e)  =(our worker.e)
          =(working.session.e source.context.c)  ?=(~ pending.e)  ?=(~ calls.e)
          =(configuration.e configuration.context.c)
      ==  `%local-review-session-changed
  =/  objective=@t
    (rap 3 (murn records.e |=(r=record:sessions ?:(?=(%operator -.body.r) `(cat 3 text.body.r '\0a') ~))))
  ?.  =(objective objective.f)  `%local-review-instructions-changed
  =/  provider-denied=(unit @tas)
    ?:  ?=(^ (cli-backend:provider selection.scope.request.h))
      (current-cli our at h)
    ?.  (agent-live:guard our at %codex-inference)  `%local-review-provider-unavailable
    =/  selected=*
      .^(* %gx /(scot %p our)/codex-inference/(scot %da at)/native-coding/selection/(scot %tas provider-key.scope.request.h)/noun)
    ?.(=(`selection.scope.request.h selected) `%local-review-selection-changed ~)
  ?^  provider-denied  provider-denied
  =/  raw=*
    .^(* %gx /(scot %p our)/viki/(scot %da at)/native-coding/projects/noun)
  =/  all  ((soft ,(map @t project:nc)) raw)
  ?~  all  `%local-review-projects-incompatible
  =/  config  (resolve:scoped our at u.all session.context.c project.context.c)
  ?.  &(?=(%& -.config) =(p.config project.f))  `%local-review-project-changed
  =/  trees  (current:project our at project.f)
  ?:  ?=(%| -.trees)  `p.trees
  ?.  &(=(basis.c working.p.trees) =(accepted.c revision.accepted.p.trees))
    `%local-review-source-changed
  ~
++  current-cli
  ::  Admission reauthenticates both distinct native jobs and current pairing.
  |=  [our=@p at=@da h=campaign:store]
  ^-  (unit @tas)
  =/  paired  (current-cli:att our at provider-key.scope.request.h selection.scope.request.h)
  ?:  ?=(%| -.paired)  `p.paired
  =/  receipts=(list [request:local @ud attestation:pa])
    (weld ?~(challenge.h ~ ~[[request.h (challenge-attempt:store h) u.challenge.h]]) ?~(resolution.h ~ ~[[(expected:store h) attempt.h u.resolution.h]]))
  |-  ^-  (unit @tas)
  ?~  receipts  ~
  =/  [r=request:local attempt=@ud a=attestation:pa]  i.receipts
  =/  req  (inference-at:local our r attempt)
  ?:  ?=(%| -.req)  `p.req
  =/  checked  (confirm-cli:att our at p.req provider-key.scope.request.h a)
  ?^  checked  checked
  $(receipts t.receipts)
++  offer
  |=  [our=@p at=@da p=project:nc c=candidate:nc r=report:accept objective=@t]
  ^-  (each (unit decision:accept) @tas)
  =/  got  (lookup our at id.c)
  ?:  ?=(%| -.got)  [%| p.got]
  ?~  p.got  [%& ~]
  =/  denied  (current our at campaign.u.p.got)
  ?^  denied  [%| u.denied]
  =/  made  (decide our at u.p.got p c r objective)
  ?:  ?=(%| -.made)  [%| p.made]
  [%& `p.made]
++  admit
  ::  A tagged decision must exactly reproduce from current canonical review
  ::  ownership. Unmarked decisions continue through their existing policy.
  |=  [our=@p at=@da c=candidate:nc d=decision:accept]
  ^-  (unit @tas)
  ?.  (marked d)  ~
  =/  got  (lookup our at id.c)
  ?:  ?=(%| -.got)  `p.got
  ?~  p.got  `%local-review-evidence-missing
  =/  h=campaign:store  campaign.u.p.got
  =/  denied  (current our at h)
  ?^  denied  denied
  ?.  (lte at.d at)  `%local-review-decision-time
  =/  f=frozen:local  frozen.request.h
  =/  made  (decide our at.d u.p.got project.f c report.d objective.f)
  ?:  ?=(%| -.made)  `p.made
  ?.  =(d p.made)  `%local-review-decision-mismatch
  ~
--
