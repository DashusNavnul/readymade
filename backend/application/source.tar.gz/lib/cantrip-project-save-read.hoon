::  Owner-only canonical project reads. The caller is Cantrip itself and
::  supplies its current law; never recurse through a Cantrip scry.
/-  mp=multiplayer-project
/+  save=cantrip-project-save, project=multiplayer-project,
    changes=multiplayer-changeset, editor=pataphor-editor-read,
    dsr=desk-shell-read, guard=viki-scry-guard, law=cantrip-law-window
|%
++  tree-at
  |=  [our=@p at=@da id=@t desk=@tas number=@ud]
  ^-  (unit tree:save)
  ::  The current dome already contains the revision index. %cv walks desk
  ::  ancestry and can stall the ship before an otherwise bounded read.
  =/  domes=cone:clay
    .^(cone:clay %cx /(scot %p our)//(scot %da at)/domes)
  =/  found=(unit dome:clay)  (~(get by domes) [our desk])
  ?~  found  ~
  =/  commit=(unit tako:clay)  (~(get by hit.u.found) number)
  ?~  commit  ~
  =/  y=yaki:clay
    .^(yaki:clay %cs (beam:dsr our at desk /yaki/(scot %uv u.commit)))
  ?.  (lte ~(wyt by q.y) 512)  ~
  =/  files=(map path @ux)
    (~(run by q.y) |=(hash=lobe:clay `@ux`hash))
  =/  snapshot  (make-snapshot:changes [1 id desk number files])
  =/  root=@uv  .^(@uv %cz (beam-at:dsr our desk (scot %ud number) /))
  `[snapshot root [u.commit p.y t.y]]
++  read
  |=  [our=@p actor=@p at=@da id=@t work=@tas]
  ^-  (each basis:save @tas)
  ?.  =(our actor)  [%| %foreign-owner]
  ?.  &(!=(0 id) (lte (met 3 id) 128) !=(0 work))  [%| %invalid-project]
  ?.  (agent-live:guard our at %multiplayer-runtime)  [%| %catalog-unavailable]
  =/  catalog=(unit project:mp)
    .^((unit project:mp) %gx /(scot %p our)/multiplayer-runtime/(scot %da at)/catalog/[id]/noun)
  ?~  catalog  [%| %project-missing]
  ?.  &((project-valid:project u.catalog) =(id id.spec.u.catalog) =(our authority.spec.u.catalog))
    [%| %foreign-project]
  =/  base=@tas  base-desk.spec.u.catalog
  ?.  !=(base work)  [%| %work-is-accepted]
  =/  domes=cone:clay  .^(cone:clay %cx /(scot %p our)//(scot %da at)/domes)
  =/  accepted=(unit dome:clay)  (~(get by domes) [our base])
  =/  working=(unit dome:clay)  (~(get by domes) [our work])
  ?~  accepted  [%| %accepted-missing]
  ?~  working  [%| %work-missing]
  ?.  &(=(%dead liv.u.working) =(~ ren.u.working) =(~ wic.u.working))
    [%| %work-not-isolated]
  ?.  &((private-path:editor our at base /) (private-path:editor our at work /))
    [%| %project-not-private]
  =/  a  (tree-at our at id base let.u.accepted)
  =/  w  (tree-at our at id work let.u.working)
  ?~  a  [%| %accepted-over-limit]
  ?~  w  [%| %work-over-limit]
  ?:  (~(has by files.body.snapshot.u.w) /desk/bill)  [%| %work-has-bill]
  =/  b=basis:save  [our at spec.u.catalog u.a u.w]
  ?.  (basis-valid:save b)  [%| %basis-invalid]
  [%& b]
++  admit
  |=  [our=@p actor=@p at=@da r=request:save w=window:law]
  ^-  (each admission:save @tas)
  ?.  =(our actor)  [%| %foreign-owner]
  ?.  (request-valid:save r)  [%| %request-invalid]
  =/  desk=@tas  base-desk.body.snapshot.working.basis.r
  =/  b  (read our actor at id.project.basis.r desk)
  ?:  ?=(%| -.b)  [%| p.b]
  ?.  %+  levy  edits.r
      |=  e=edit:save
      (private-path:editor our at desk path.change.e)
    [%| %path-not-private]
  (judge:save our actor at r p.b w)
++  observe
  ::  The current read establishes a fence. The immutable next revision
  ::  independently proves all changed and unchanged files in one commit.
  |=  [our=@p actor=@p at=@da r=record:save]
  ^-  (each record:save @tas)
  ?.  =(our actor)  [%| %foreign-owner]
  ?.  &((record-valid:save r) =(our owner.basis.request.admission.r))
    [%| %record-invalid]
  =/  original=basis:save  basis.request.admission.r
  =/  work=@tas  base-desk.body.snapshot.working.original
  =/  b  (read our actor at id.project.original work)
  ?:  ?=(%| -.b)  [%| p.b]
  =/  historical
    (tree-at our at id.project.original work +(base-revision.body.snapshot.working.original))
  =/  h=(unit history:save)
    ?~  historical  ~
    `[our at accepted.p.b u.historical]
  [%& (observe:save r p.b h)]
--
