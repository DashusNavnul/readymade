::  Commit prospective enrollment before dispatch, without pausing the session.
::  The outer wrapper owns plans/tickets; the observer still owns all evidence.
/+  obs=qpc-observation, observer=qpc-observer, sessions=native-coding-session,
    gate=qpc-session-gate, q=qpc-native-outcome, outcomes=qpc-outcome-store
|%
+$  plan  [%qpc-stream-plan-v1 manifest=manifest:obs template=work:obs objective=@ux]
+$  ticket  [request=@ux work=@ux snapshot=@ux]
+$  record  [plan=plan active=? reason=(unit @tas) ticket=(unit ticket)]
+$  state  (map @ux record)
++  valid-plan
  |=  [our=@p p=plan]
  &((work-valid:obs manifest.p template.p) =(our owner.manifest.p) !=(0 objective.p) (lte (met 0 objective.p) 256))
++  next-work
  |=  [p=plan e=entry:sessions]
  ^-  (each work:obs @tas)
  ?.  &(?=(~ pending.e) ?=(~ calls.e) =(%ready phase.e))
    [%| %qpc-stream-not-ready]
  =/  w=work:obs  template.p
  ?.  ?&  =(objective.p (digest:obs objective.session.e))
          =(owner.source.w owner.working.session.e)
          =(desk.source.w desk.working.session.e)
          (gte number.working.session.e number.source.w)
      ==  [%| %qpc-stream-task-changed]
  =/  request=@ux  (request-id:sessions id.session.e turn.e)
  =.  w  w(request request, source working.session.e, nonce (digest:obs [%stream-work p request]))
  ?.  (matches:obs manifest.p w e)  [%| %qpc-stream-binding-changed]
  [%& w]
++  dispatch-card
  |=  [our=@p id=@ux t=ticket]
  ^-  card:agent:gall
  [%pass /qpc/stream/dispatch %agent [our %viki] %poke %noun !>([%qpc-stream-dispatch-v1 id t])]
++  notice
  |=  [id=@ux reason=@tas]
  ^-  card:agent:gall
  [%give %fact ~[/native-coding] %noun !>([%qpc-stream-status-v1 id reason])]
++  agent
  |=  inner=agent:gall
  =|  streams=state
  ^-  agent:gall
  |_  =bowl:gall
  +*  this  .
      ag  ~(. inner bowl)
  ++  on-init
    =^  cards  inner  on-init:ag
    [cards this]
  ++  on-save  !>([%qpc-stream-v1 streams on-save:ag])
  ++  on-load
    |=  old=vase
    =/  saved=[streams=state inner=vase]
      ?.  ?=([%qpc-stream-v1 *] q.old)  [*state old]
      =/  prior  !<([%qpc-stream-v1 streams=state inner=vase] old)
      +.prior
    ?>  (lte ~(wyt by streams.saved) 64)
    ?>  %+  levy  ~(tap by streams.saved)
        |=  [id=@ux r=record]
        &((valid-plan our.bowl plan.r) =(id session.template.plan.r) ?~(ticket.r %.y active.r))
    =.  streams  streams.saved
    =^  cards  inner  (on-load:ag inner.saved)
    [cards this]
  ++  on-poke
    |=  [=mark =vase]
    ?:  &(=(%noun mark) ?=([%qpc-stream-plan-v1 *] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  p=plan  !<(plan vase)
      ?>  (valid-plan our.bowl p)
      =/  id=@ux  session.template.p
      =/  prior  (~(get by streams) id)
      ?>  ?~(prior (lth ~(wyt by streams) 64) =(p plan.u.prior))
      ?:  ?~(prior %.n active.u.prior)  [~ this]
      ::  Plans may precede session creation, since opening queues its first
      ::  run immediately. Exact session/source binding is checked at every run.
      =/  raw  (payload:gate (on-peek:ag /x/qpc/cases/(scot %ux case-set.template.p)))
      ?>  ?=(^ raw)
      =/  parsed  ((soft ,(unit cases:q)) u.raw)
      ?>  &(?=(^ parsed) ?=(^ u.parsed))
      =/  cs=cases:q  u.u.parsed
      ?>  &((cases-valid:outcomes cs) =(case-set.template.p (digest:q cs)))
      ?>  =((turn rows.cs |=(c=case:q proposition.c)) (turn propositions.manifest.p |=(v=proposition:obs id.v)))
      [~ this(streams (~(put by streams) id [p %.y ~ ~]))]
    ?:  &(=(%noun mark) ?=([%qpc-stream-retry-v1 @] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  id=@ux  `@ux`+.q.vase
      =/  found  (~(get by streams) id)
      ?~  found  [~ this]
      =/  pending  ticket.u.found
      ?~  pending  [~ this]
      [~[(dispatch-card our.bowl id u.pending)] this]
    ?:  &(=(%noun mark) ?=([%qpc-observe-disarm-v1 @] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  id=@ux  `@ux`+.q.vase
      =/  found  (~(get by streams) id)
      =.  streams
        ?~  found  streams
        (~(put by streams) id u.found(active %.n, ticket ~, reason `%operator-stopped))
      =^  cards  inner  (on-poke:ag mark vase)
      [cards this]
    ?:  &(=(%noun mark) ?=([%qpc-observe-arm-v1 *] q.vase))
      =/  command  !<([%qpc-observe-arm-v1 manifest=manifest:obs work=work:obs] vase)
      =/  found  (~(get by streams) session.work.command)
      ~|  %qpc-stream-stop-before-manual-enrollment
      ?>  ?~(found %.y !active.u.found)
      =^  cards  inner  (on-poke:ag mark vase)
      [cards this]
    ?:  &(=(%noun mark) ?=([%qpc-stream-dispatch-v1 *] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  command  !<([%qpc-stream-dispatch-v1 id=@ux ticket=ticket] vase)
      =/  found  (~(get by streams) id.command)
      ?~  found  [~ this]
      =/  r=record  u.found
      ?.  &(active.r =(`ticket.command ticket.r))  [~ this]
      =/  snapshot  (input:observer inner bowl id.command)
      =/  ready=?
        ?~  snapshot  %.n
        =/  next  (next-work plan.r entry.u.snapshot)
        ?&  ?=(%& -.next)  =(snapshot.ticket.command (digest:obs entry.u.snapshot))
            =(request.ticket.command request.p.next)  =(work.ticket.command (digest:obs p.next))
        ==
      =.  streams  (~(put by streams) id.command r(ticket ~, reason ?:(ready ~ `%handoff-stale)))
      ?.  ready
        =^  cards  inner  (on-poke:ag %noun !>([%qpc-observe-disarm-v1 id.command]))
        [(weld cards ~[(notice id.command %handoff-stale)]) this]
      ::  Consume the ticket before returning any inference cards. A replay
      ::  after persistence sees no ticket and cannot dispatch another request.
      =^  cards  inner  (on-poke:ag %noun !>([%native-coding-action-v1 [%run id.command]]))
      [cards this]
    ?:  &(=(%noun mark) ?=([%native-coding-action-v1 %run @] q.vase))
      ?>  =(our.bowl src.bowl)
      ::  Native loop self-pokes carry a generic noun vase. Validate the
      ::  value, not the sender's optional type detail, after authenticating.
      =/  command  ;;([%native-coding-action-v1 [%run id=@ux]] q.vase)
      =/  id=@ux  id.command
      =/  found  (~(get by streams) id)
      ?:  ?~(found %.y !active.u.found)
        =^  cards  inner  (on-poke:ag mark vase)
        [cards this]
      ?>  ?=(^ found)
      =/  r=record  u.found
      ?^  ticket.r  [~ this]
      =/  snapshot  (input:observer inner bowl id)
      ?~  snapshot
        =^  cards  inner  (on-poke:ag mark vase)
        [cards this]
      =/  e=entry:sessions  entry.u.snapshot
      =/  next  (next-work plan.r e)
      ?:  ?=(%| -.next)
        ?:  =(%qpc-stream-not-ready p.next)
          =^  cards  inner  (on-poke:ag mark vase)
          [cards this]
        ::  No new execution prohibition: expose and disable failed sensing,
        ::  then leave the ordinary session's existing admission rules intact.
        =.  streams  (~(put by streams) id r(active %.n, reason `p.next))
        =^  cards  inner  (on-poke:ag mark vase)
        [(weld cards ~[(notice id p.next)]) this]
      =/  raw  (payload:gate (on-peek:ag /x/qpc/observations))
      ?>  ?=(^ raw)
      =/  held=state:obs  (need ((soft state:obs) u.raw))
      =/  prior  (~(get by arms.held) id)
      ?:  ?~(prior %.n &(active.u.prior =(work.u.prior p.next)))
        =/  t=ticket  [request.p.next (digest:obs p.next) (digest:obs e)]
        :_  this(streams (~(put by streams) id r(ticket `t, reason ~)))
        ~[(dispatch-card our.bowl id t)]
      =/  possible  (enroll:obs our.bowl held manifest.plan.r p.next e)
      ?:  ?=(%| -.possible)
        =.  streams  (~(put by streams) id r(active %.n, reason `p.possible))
        =^  cards  inner  (on-poke:ag mark vase)
        [(weld cards ~[(notice id p.possible)]) this]
      =^  cards  inner  (on-poke:ag %noun !>([%qpc-observe-arm-v1 manifest.plan.r p.next]))
      =/  t=ticket  [request.p.next (digest:obs p.next) (digest:obs e)]
      :_  this(streams (~(put by streams) id r(ticket `t, reason ~)))
      (weld cards ~[(dispatch-card our.bowl id t)])
    =^  cards  inner  (on-poke:ag mark vase)
    [cards this]
  ++  on-watch
    |=  =path
    =^  cards  inner  (on-watch:ag path)
    [cards this]
  ++  on-leave
    |=  =path
    =^  cards  inner  (on-leave:ag path)
    [cards this]
  ++  on-peek
    |=  =path
    ?:  =(/x/qpc/streams path)
      ?.  =(our.bowl src.bowl)  ~
      ``noun+!>(streams)
    (on-peek:ag path)
  ++  on-agent
    |=  [=wire =sign:agent:gall]
    =^  cards  inner  (on-agent:ag wire sign)
    [cards this]
  ++  on-arvo
    |=  [=wire =sign-arvo]
    =^  cards  inner  (on-arvo:ag wire sign-arvo)
    [cards this]
  ++  on-fail
    |=  [=term =tang]
    =^  cards  inner  (on-fail:ag term tang)
    [cards this]
  --
--
