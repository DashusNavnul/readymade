::  Terminal presentation of canonical Viki state. No execution decisions.
/-  pc=pataphor-project-coding
/+  con=pataphor-project-console, coding=pataphor-project-coding
|%
+$  connection  ?(%pending %live %failed)
+$  delivery  [nonce=@ux phase=?(%submitted %accepted %refused) reason=@tas]
++  cursor
  ::  Observation time is not a new view. Exact results retain their own
  ::  source/receipt identities; only the manifest read timestamp is omitted.
  |=  current=(each view:pc @tas)
  ^-  @ux
  ?:  ?=(%| -.current)  (shax (jam [%unavailable p.current]))
  =/  manifest=(unit @ux)
    ?~  manifest.p.current  ~
    `(manifest-id:coding u.manifest.p.current)
  (shax (jam [owner.p.current project.p.current manifest results.p.current]))
++  view-cursor
  |=  [current=(each view:pc @tas) connection=connection last=(unit delivery)]
  ^-  @ux
  (shax (jam [(cursor current) connection last]))
++  delivery-text
  |=  last=delivery
  ^-  @t
  =/  reason=@t  (scot %tas reason.last)
  =/  safe=@t
    (crip (turn (scag 80 (trip reason)) |=(c=@tD ^-(@tD ?:(|((lth c 32) (gth c 126)) '?' c)))))
  (rap 3 ~[(scot %ux nonce.last) ' delivery ' (scot %tas phase.last) ?:(=(0 reason.last) '' (cat 3 ': ' safe))])
++  snapshot
  |=  [token=@uv current=(each view:pc @tas) connection=connection last=(unit delivery)]
  ^-  json
  =/  ready=?  ?=(%& -.current)
  =/  rows=(list result:pc)  ?:(?=(%& -.current) results.p.current ~)
  =/  manifest=@t
    ?.  ?=(%& -.current)  ''
    ?~  manifest.p.current  ''
    (scot %ux (manifest-id:coding u.manifest.p.current))
  %-  pairs:enjs:format
  :~  ['nonce' s+(scot %uv token)]
      ['cursor' s+(scot %ux (view-cursor current connection last))]
      ['manifest' s+manifest]
      ['ready' b+&(ready =(%live connection))]
      ['connection' s+(scot %tas connection)]
      ['error' s+?:(?=(%& -.current) '' (scot %tas p.current))]
      ['delivery' ?~(last ~ (pairs:enjs:format ~[['id' s+(scot %ux nonce.u.last)] ['phase' s+(scot %tas phase.u.last)] ['text' s+(delivery-text u.last)]]))]
      :-  'results'
      a+(turn rows |=(r=result:pc (pairs:enjs:format ~[['id' s+(scot %ux nonce.request.r)] ['phase' s+(scot %tas phase.r)] ['text' s+(summary:con r)]])))
  ==
++  command
  |=  [raw=@t token=@uv]
  ^-  (unit [manifest=@ux line=@t])
  ?.  (lte (met 3 raw) 8.192)  ~
  =/  parsed  (de:json:html raw)
  ?~  parsed  ~
  ?.  ?=(%o -.u.parsed)  ~
  ?.  =(3 ~(wyt by p.u.parsed))  ~
  =/  nonce  (~(get by p.u.parsed) 'nonce')
  =/  line  (~(get by p.u.parsed) 'line')
  =/  manifest  (~(get by p.u.parsed) 'manifest')
  ?.  &(?=([~ %s *] nonce) ?=([~ %s *] line) ?=([~ %s *] manifest))  ~
  ?.  =(p.u.nonce (scot %uv token))  ~
  =/  expected  (slaw %ux p.u.manifest)
  ?~  expected  ~
  ?.  &(=(p.u.manifest (scot %ux u.expected)) (lte (met 0 u.expected) 256))  ~
  `[u.expected p.u.line]
++  page
  ^-  @t
  %+  rap  3
  :~  '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Viki terminal</title>'
      '<link rel="stylesheet" href="/apps/pataphor-terminal/xterm.css"><style>html,body{height:100%;margin:0;background:#181818;color:#ddd;font:13px monospace}body{display:flex;flex-direction:column}header{padding:10px;display:flex;gap:16px;border-bottom:1px solid #444}a,button{color:#ffaa00;background:#222;font:inherit}#terminal{flex:1;min-height:240px;padding:6px}#status{flex:1}</style>'
      '<script defer src="/apps/pataphor-terminal/xterm.js"></script><script defer src="/apps/pataphor-native/native-console.js"></script></head><body><header><span>Viki · Urbit</span><span id="status">Connecting</span><button id="refresh">Reconnect</button><a href="/apps/pataphor-terminal">Host shell</a></header><main id="terminal"></main></body></html>'
  ==
--
