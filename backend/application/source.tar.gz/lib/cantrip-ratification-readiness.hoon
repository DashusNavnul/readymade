::  /lib/cantrip-ratification-readiness
::
::  Pure readiness projection.  The live Cantrip window remains the decision;
::  this only explains its evidence gap and preserves the never-auto boundary.
::
/-  crr=cantrip-ratification-readiness
/+  clw=cantrip-law-window, cvp=cantrip-vibecoding-proposal
|%
++  law-version  1
++  required-turns  1
++  required-streak  2
++  missing-turns
  |=  turns=@ud
  ^-  @ud
  ?:  (gte turns required-turns)
    0
  (sub required-turns turns)
++  missing-passes
  |=  streak=@ud
  ^-  @ud
  ?:  (gte streak required-streak)
    0
  (sub required-streak streak)
++  has-requirement
  |=  [requirements=(list requirement:crr) tag=@tas]
  ^-  ?
  %+  lien  requirements
  |=  item=requirement:crr
  =(tag -.item)
++  build
  |=  [window=window:clw residue=residue:clw streak=@ud]
  ^-  readiness:crr
  =/  implement=?  (~(has in admissible.window) %implement)
  =/  missing-turn=@ud  (missing-turns turn.residue)
  =/  missing=@ud  (missing-passes streak)
  =/  requirements=(list requirement:crr)
    ~[[%operator-approval-required ~]]
  =?  requirements  (gth blockers.residue 0)
    [[%blockers-observed blockers.residue] requirements]
  =?  requirements  (gth rivals.residue 0)
    [[%resolve-rivals rivals.residue] requirements]
  =?  requirements  (gth contraindications.residue 0)
    [[%clear-contraindications contraindications.residue] requirements]
  =?  requirements  (gth missing 0)
    [[%verified-passes missing required-streak streak] requirements]
  =?  requirements  (gth missing-turn 0)
    [[%loom-turns missing-turn required-turns turn.residue] requirements]
  =/  stage=stage:crr
    ?:  implement  %ready-for-operator
    ?:  ?|((gth contraindications.residue 0) (gth rivals.residue 0))
      %needs-clearance
    %needs-verification
  =/  law-digest=@ux  (law-digest:cvp law-version window)
  =/  preimage=*
    [%cantrip-ratification-readiness-v1 stage regime.window implement law-version law-digest streak residue requirements]
  :*  %cantrip-ratification-readiness-v1
      stage
      regime.window
      implement
      law-version
      law-digest
      streak
      residue
      requirements
      `@ux`(shax (jam preimage))
  ==
++  valid
  |=  [item=readiness:crr window=window:clw]
  ^-  ?
  =(item (build window residue.item streak.item))
--
