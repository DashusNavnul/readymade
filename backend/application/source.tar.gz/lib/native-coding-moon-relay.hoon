::  Native inference relay. The moon owner fixes the parent and provider;
::  the parent supplies bounded inference requests, never local credentials.
/-  mse=glass-moon-executor, p=native-coding-provider
/+  general=native-coding-inference, law=native-coding-provider,
    route=native-coding-route, guard=viki-scry-guard
|%
++  limit  256
++  empty  ^-  state  [%native-coding-moon-relay-v1 ~ 0 ~]
++  digest  |=(value=* ^-(@ux `@`(sham value)))
++  number-valid  |=(value=@ &(!=(0 value) (lte (met 0 value) 256)))
++  terminal
  |=  o=outcome:general
  ^-  ?
  ?|(?=(%result -.o) ?=(%failed -.o) ?=(%cancelled -.o) ?=(%refused -.o))
++  busy
  |=  s=state
  ^-  ?
  (lien ~(val by jobs.s) |=(j=job !(terminal outcome.j)))
++  authorized-config
  |=  [our=@p c=config]
  ^-  ?
  =/  b=binding:mse  binding.c
  ?.  ?=([%multiplayer-session-executor-binding-v2 *] -.b)  %.n
  ?&  (binding-valid:route b)
      =(%earl (clan:title our))  =(peer.b (^sein:title our))
      (number-valid generation.c)  (number-valid session.c)
      (name-valid:law provider-key.c)
      (selection-matches:route selected.b selection.c)
  ==
++  state-valid
  |=  [our=@p s=state]
  ^-  ?
  ?&  (lte ~(wyt by jobs.s) limit)
      ?~  config.s  %.y
      &((authorized-config our u.config.s) =(generation.s generation.u.config.s))
      %+  levy  ~(tap by jobs.s)
      |=(entry=[id=@ux j=job] &((lte generation.config.j.entry generation.s) (job-valid our id.entry j.entry)))
  ==
++  job-valid
  |=  [our=@p id=@ux j=job]
  ^-  ?
  ?&  (number-valid id)  (number-valid request.j)
      (authorized-config our config.j)
      ?:  ?=(%result -.outcome.j)
        &(=(id id.value.outcome.j) =(provider.selection.config.j provider.value.outcome.j) (lte (met 3 raw.value.outcome.j) response-limit:p) =(raw-digest.value.outcome.j (shax raw.value.outcome.j)))
      ?:  ?=(%failed -.outcome.j)
        &(=(id id.error.outcome.j) =(provider.selection.config.j provider.error.outcome.j))
      ?|(?=(%pending -.outcome.j) ?=(%unknown -.outcome.j) ?=(%cancelled -.outcome.j) ?=(%refused -.outcome.j))
  ==
++  notice
  |=  [j=job id=@ux]
  ^-  card:agent:gall
  =/  result=event
    [%native-coding-moon-event (digest config.j) generation.config.j request.j [%native-coding-event id session.config.j outcome.j]]
  [%pass /native-moon/reply/(scot %ux id) %agent [peer.binding.config.j %viki] %poke %noun !>(result)]
++  local
  |=  [our=@p id=@ux command=command:general]
  ^-  card:agent:gall
  [%pass /native-moon/local/(scot %tas -.command)/(scot %ux id) %agent [our %codex-inference] %poke %noun !>(command)]
++  controller-ready
  |=  [our=@p at=@da]
  ^-  ?
  ?.  (agent-live:guard our at %codex-inference)  %.n
  =/  path=path  /(scot %p our)/codex-inference/(scot %da at)/native-coding/status/noun
  =/  observed=*
    .^(* %gx path)
  =/  decoded  ((soft ,[%native-coding-inference-status-v1 controller=@tas credentials=@ud selections=@ud pending=@ud jobs=@ud]) observed)
  ?~  decoded  %.n
  =(%multiplayer-session-executor controller.u.decoded)
++  handle
  |=  [our=@p src=@p at=@da s=state action=command]
  ^-  (each transition @tas)
  ?:  ?=(%native-coding-moon-controller -.action)
    ?.  =(our src)  [%| %owner-required]
    [%& [s ~[(local our 0x0 [%native-coding-controller %multiplayer-session-executor])]]]
  ?:  ?=(%native-coding-moon-bind -.action)
    ?.  &(=(our src) (authorized-config our config.action))  [%| %moon-binding-invalid]
    ?:  =(`config.action config.s)  [%& [s ~]]
    ?:  (busy s)  [%| %moon-inference-busy]
    ?.  (gth generation.config.action generation.s)  [%| %moon-generation-reused]
    [%& [s(config `config.action, generation generation.config.action) ~]]
  ?:  ?=(%native-coding-moon-disable -.action)
    ?.  =(our src)  [%| %owner-required]
    ?:  (busy s)  [%| %moon-inference-busy]
    [%& [s(config ~) ~]]
  ?:  ?=(%native-coding-moon-inspect -.action)
    ?~  config.s  [%| %moon-unbound]
    =/  c=config  u.config.s
    ?.  &(=(src peer.binding.c) =(binding.action (digest c)) =(generation.action generation.c))
      [%| %moon-binding-mismatch]
    =/  report=inspection
      [%native-coding-moon-inspection binding.action generation.action request.action (controller-ready our at) (busy s)]
    [%& [s ~[[%pass /native-moon/inspection/(scot %ux request.action) %agent [src %viki] %poke %noun !>(report)]]]]
  ?:  ?=(%native-coding-moon-infer -.action)
    ?~  config.s  [%| %moon-unbound]
    =/  c=config  u.config.s
    ?.  &(=(src peer.binding.c) =(binding.action (digest c)) =(generation.action generation.c))
      [%| %moon-binding-mismatch]
    =/  r=request:p  request.action
    ?.  &((request-valid:law r) =(session.r session.c) =(selection.r selection.c))
      [%| %moon-request-invalid]
    =/  old=(unit job)  (~(get by jobs.s) id.r)
    ?^  old
      ?.  &(=(config.u.old c) =(request.u.old (digest r)))  [%| %moon-request-reused]
      [%& [s ~[(notice u.old id.r)]]]
    ?:  (gte ~(wyt by jobs.s) limit)  [%| %moon-receipt-capacity]
    =/  j=job  [c (digest r) [%pending ~]]
    ?:  (busy s)  [%| %moon-inference-busy]
    ?.  (controller-ready our at)
      =.  outcome.j  [%refused %moon-controller-unavailable]
      [%& [s(jobs (~(put by jobs.s) id.r j)) ~[(notice j id.r)]]]
    [%& [s(jobs (~(put by jobs.s) id.r j)) ~[(local our id.r [%native-coding-infer provider-key.c r])]]]
  =/  id=@ux  id.action
  =/  found=(unit job)  (~(get by jobs.s) id)
  ?~  found  [%| %moon-request-missing]
  =/  j=job  u.found
  ?.  ?&  =(src peer.binding.config.j)  =(binding.action (digest config.j))
          =(generation.action generation.config.j)  =(session.action session.config.j)
          =(request.action request.j)
      ==
    [%| %moon-correlation-mismatch]
  ?:  (terminal outcome.j)  [%& [s ~[(notice j id)]]]
  =/  op=command:general
    ?:  ?=(%native-coding-moon-cancel -.action)  [%native-coding-cancel id]
    [%native-coding-observe id]
  [%& [s ~[(local our id op)]]]
++  receive
  |=  [our=@p src=@p s=state received=event:general]
  ^-  transition
  ?.  =(our src)  [s ~]
  =/  found=(unit job)  (~(get by jobs.s) id.received)
  ?~  found  [s ~]
  =/  j=job  u.found
  ?:  (terminal outcome.j)  [s ~]
  ?.  |(=(session.received session.config.j) &(=(0 session.received) ?=(%missing -.outcome.received)))  [s ~]
  =/  result=outcome:general
    ?:  |(?=(%missing -.outcome.received) ?=(%conflict -.outcome.received))  [%unknown ~]
    outcome.received
  ::  No stale pending notification can make an unknown delivery look new.
  ?:  &(?=(%unknown -.outcome.j) ?=(%pending -.result))  [s ~]
  =.  outcome.j  result
  =/  next=state  s(jobs (~(put by jobs.s) id.received j))
  ?.  (job-valid our id.received j)  [s ~]
  [next ~[(notice j id.received)]]
++  rejected
  ::  A definite local poke rejection is retained, never automatically sent again.
  |=  [s=state id=@ux operation=@tas]
  ^-  transition
  =/  found=(unit job)  (~(get by jobs.s) id)
  ?~  found  [s ~]
  =/  j=job  u.found
  ?.  ?=(%pending -.outcome.j)  [s ~]
  =/  wide=job  j
  =/  j=job
    wide(outcome ?:(=(%native-coding-infer operation) [%refused %moon-local-dispatch-refused] [%unknown ~]))
  [s(jobs (~(put by jobs.s) id j)) ~[(notice j id)]]
++  reload
  ::  The local transport owns its own recovery. Observation cannot start HTTP.
  |=  [our=@p s=state]
  ^-  transition
  =/  cards=(list card:agent:gall)  ~
  =/  todo=(list [@ux job])  ~(tap by jobs.s)
  |-  ^-  transition
  ?~  todo  [s cards]
  =/  id=@ux  -.i.todo
  =/  j=job  +.i.todo
  ?:  (terminal outcome.j)  $(todo t.todo)
  =.  outcome.j  [%unknown ~]
  $(todo t.todo, s s(jobs (~(put by jobs.s) id j)), cards (weld cards ~[(notice j id) (local our id [%native-coding-observe id])]))
++  status
  |=  s=state
  ^-  *
  [%native-coding-moon-status-v1 ?~(config.s ~ `(digest u.config.s)) generation.s (busy s) ~(wyt by jobs.s)]
++  command-tag
  |=  noun=*
  ^-  ?
  ?~  noun  %.n
  ?.  ?=(^ noun)  %.n
  ?|  =(%native-coding-moon-bind -.noun)  =(%native-coding-moon-controller -.noun)
      =(%native-coding-moon-disable -.noun)  =(%native-coding-moon-infer -.noun)
      =(%native-coding-moon-inspect -.noun)
      =(%native-coding-moon-observe -.noun)  =(%native-coding-moon-cancel -.noun)
  ==
++  event-tag
  |=  noun=*
  ^-  ?
  &(?=(^ noun) ?=([%native-coding-event *] noun))
++  enabled  |=(s=state ?=(^ config.s))
+$  config
  [binding=binding:mse generation=@ud session=@ux provider-key=@tas selection=selection:p]
+$  job  [config=config request=@ux outcome=outcome:general]
+$  state  [%native-coding-moon-relay-v1 config=(unit config) generation=@ud jobs=(map @ux job)]
+$  transition  [state=state cards=(list card:agent:gall)]
+$  event  [%native-coding-moon-event binding=@ux generation=@ud request=@ux event=event:general]
+$  inspection
  [%native-coding-moon-inspection binding=@ux generation=@ud request=@ux ready=? busy=?]
+$  command
  $%  [%native-coding-moon-bind config=config]
      [%native-coding-moon-controller ~]
      [%native-coding-moon-disable ~]
      [%native-coding-moon-inspect binding=@ux generation=@ud request=@ux]
      [%native-coding-moon-infer binding=@ux generation=@ud request=request:p]
      [%native-coding-moon-observe binding=@ux generation=@ud id=@ux session=@ux request=@ux]
      [%native-coding-moon-cancel binding=@ux generation=@ud id=@ux session=@ux request=@ux]
  ==
--
