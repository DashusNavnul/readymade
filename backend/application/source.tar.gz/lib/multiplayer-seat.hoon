::  /lib/multiplayer-seat
::
::  Pure project-seat law.  Role grants are append-only epochs; leases bind
::  the exact role epoch that existed when authority granted the seat.
::
/-  mp=multiplayer-project, ms=multiplayer-seat
/+  mpl=multiplayer-project
|%
++  max-lease-span  `@dr`~d1
::
++  role-grant-digest
  |=  body=role-grant-body:ms
  ^-  digest:mp
  `@ux`(shax (jam [%multiplayer-seat-role-grant-v1 body]))
++  role-grant-for
  |=  $:  project=project-id:mp
          member=@p
          epoch=@ud
          role=role:mp
          previous=(unit digest:mp)
          effective-at=@da
      ==
  ^-  role-grant:ms
  =/  body=role-grant-body:ms
    [1 project member epoch role previous effective-at]
  [body (role-grant-digest body)]
++  role-grant-valid
  |=  grant=role-grant:ms
  ^-  ?
  ?&  =(1 version.body.grant)
      !=(0 project.body.grant)
      !=(0 epoch.body.grant)
      !=(0 effective-at.body.grant)
      =((role-grant-digest body.grant) digest.grant)
  ==
::
++  grant-chain-valid
  |=  $:  project=project-id:mp
          member=@p
          state=member-state:ms
          expected=@ud
          previous=(unit digest:mp)
      ==
  ^-  ?
  ?:  (gth expected active-epoch.state)  %.y
  =/  found=(unit role-grant:ms)  (~(get by grants.state) expected)
  ?~  found  %.n
  =/  grant=role-grant:ms  u.found
  ?.  ?&  (role-grant-valid grant)
          =(project project.body.grant)
          =(member member.body.grant)
          =(expected epoch.body.grant)
          =(previous previous.body.grant)
      ==
    %.n
  $(expected +(expected), previous `digest.grant)
++  member-state-valid
  |=  [project=project-id:mp member=@p state=member-state:ms]
  ^-  ?
  ?&  !=(0 active-epoch.state)
      =(active-epoch.state ~(wyt by grants.state))
      (grant-chain-valid project member state 1 ~)
  ==
++  members-valid
  |=  [project=project-id:mp members=(map @p member-state:ms)]
  ^-  ?
  %+  levy  ~(tap by members)
  |=  row=[@p member-state:ms]
  (member-state-valid project -.row +.row)
::
++  grant-at
  |=  [registry=registry:ms member=@p epoch=@ud]
  ^-  (unit role-grant:ms)
  =/  state=(unit member-state:ms)  (~(get by members.registry) member)
  ?~(state ~ (~(get by grants.u.state) epoch))
++  active-grant
  |=  [registry=registry:ms member=@p]
  ^-  (unit role-grant:ms)
  =/  state=(unit member-state:ms)  (~(get by members.registry) member)
  ?~(state ~ (~(get by grants.u.state) active-epoch.u.state))
::
++  lease-valid
  |=  [registry=registry:ms lease=lease:ms]
  ^-  ?
  =/  grant=(unit role-grant:ms)
    (grant-at registry holder.lease role-epoch.lease)
  ?~  grant  %.n
  ?&  =(1 version.lease)
      =(project.registry project.lease)
      !=(0 seat.lease)
      !=(0 generation.lease)
      =(role.lease role.body.u.grant)
      (gte issued-at.lease effective-at.body.u.grant)
      (gth expires-at.lease issued-at.lease)
      ?-  -.status.lease
        %active   %.y
        %expired  (gte at.status.lease expires-at.lease)
        %revoked  (gte at.status.lease issued-at.lease)
      ==
  ==
++  history-valid
  |=  registry=registry:ms
  ^-  ?
  %+  levy  ~(tap by lease-history.registry)
  |=  row=[[seat=@tas generation=@ud] lease:ms]
  ?&  =(seat.-.row seat.+.row)
      =(generation.-.row generation.+.row)
      (lease-valid registry +.row)
  ==
++  current-index-valid
  |=  registry=registry:ms
  ^-  ?
  %+  levy  ~(tap by current-seats.registry)
  |=  row=[@tas @ud]
  =/  found=(unit lease:ms)
    (~(get by lease-history.registry) [-.row +.row])
  ?~  found  %.n
  ?&  =(-.row seat.u.found)
      =(+.row generation.u.found)
  ==
++  registry-valid
  |=  registry=registry:ms
  ^-  ?
  ?&  =(1 version.registry)
      !=(0 project.registry)
      !=(0 project-head.registry)
      (~(has by members.registry) authority.registry)
      (members-valid project.registry members.registry)
      (history-valid registry)
      (current-index-valid registry)
  ==
::
++  state-for
  |=  [project=project-id:mp member=@p role=role:mp joined-at=@da]
  ^-  member-state:ms
  =/  grant=role-grant:ms
    (role-grant-for project member 1 role ~ joined-at)
  [1 (~(put by *(map @ud role-grant:ms)) 1 grant)]
++  init
  |=  project=project:mp
  ^-  (unit registry:ms)
  ?.  (project-valid:mpl project)  ~
  ?~  head.project  ~
  =/  members=(map @p member-state:ms)
    %-  ~(urn by members.project)
    |=  [ship=@p member=member:mp]
    (state-for id.spec.project ship role.member joined-at.member)
  `[1 id.spec.project authority.spec.project u.head.project members ~ ~]
::
++  reject
  |=  refusal=refusal:ms
  ^-  result:ms
  [%| refusal]
++  current-lease
  |=  [registry=registry:ms seat=@tas]
  ^-  (unit lease:ms)
  =/  generation=(unit @ud)  (~(get by current-seats.registry) seat)
  ?~(generation ~ (~(get by lease-history.registry) [seat u.generation]))
++  span-valid
  |=  [observed-at=@da expires-at=@da]
  ^-  ?
  ?&  (gth expires-at observed-at)
      (lte expires-at (add observed-at max-lease-span))
  ==
++  seat-role
  |=  role=role:mp
  ^-  ?
  ?|  =(%operator role)
      =(%maintainer role)
      =(%contributor role)
      =(%model role)
  ==
++  closed-at
  |=  status=lease-status:ms
  ^-  (unit @da)
  ?-  -.status
    %active   ~
    %expired  `at.status
    %revoked  `at.status
  ==
::
++  binding-for
  |=  [registry=registry:ms member=@p]
  ^-  (unit role-binding:ms)
  =/  grant=(unit role-grant:ms)  (active-grant registry member)
  ?~  grant  ~
  `[ project.registry
     member
     epoch.body.u.grant
     role.body.u.grant
     digest.u.grant
   ]
++  binding-known
  |=  [registry=registry:ms binding=role-binding:ms]
  ^-  ?
  ?.  =(project.registry project.binding)  %.n
  =/  grant=(unit role-grant:ms)
    (grant-at registry member.binding epoch.binding)
  ?~  grant  %.n
  ?&  =(role.binding role.body.u.grant)
      =(grant-digest.binding digest.u.grant)
  ==
++  binding-current
  |=  [registry=registry:ms binding=role-binding:ms]
  ^-  ?
  ?.  (binding-known registry binding)  %.n
  =/  state=(unit member-state:ms)
    (~(get by members.registry) member.binding)
  ?~(state %.n =(epoch.binding active-epoch.u.state))
::
++  change-role
  |=  [registry=registry:ms actor=@p member=@p role=role:mp observed-at=@da]
  ^-  result:ms
  ?.  (registry-valid registry)  (reject [%invalid-registry ~])
  ?.  =(authority.registry actor)
    (reject [%foreign-authority authority.registry actor])
  ?:  |(=(member authority.registry) =(%operator role))
    (reject [%role-forbidden member role])
  =/  found=(unit member-state:ms)  (~(get by members.registry) member)
  ?~  found  (reject [%member-missing member])
  =/  state=member-state:ms  u.found
  =/  current=role-grant:ms  (~(got by grants.state) active-epoch.state)
  ?:  (lth observed-at effective-at.body.current)
    (reject [%invalid-registry ~])
  =/  epoch=@ud  +(active-epoch.state)
  =/  grant=role-grant:ms
    (role-grant-for project.registry member epoch role `digest.current observed-at)
  =/  next-state=member-state:ms
    [epoch (~(put by grants.state) epoch grant)]
  [%& registry(members (~(put by members.registry) member next-state))]
::
++  grant-seat
  |=  $:  registry=registry:ms
          actor=@p
          seat=@tas
          holder=@p
          observed-at=@da
          expires-at=@da
      ==
  ^-  result:ms
  ?.  (registry-valid registry)  (reject [%invalid-registry ~])
  ?.  =(authority.registry actor)
    (reject [%foreign-authority authority.registry actor])
  ?:  =(0 seat)  (reject [%seat-invalid ~])
  =/  old=(unit lease:ms)  (current-lease registry seat)
  ?^  old  (reject [%seat-held seat holder.u.old generation.u.old])
  =/  grant=(unit role-grant:ms)  (active-grant registry holder)
  ?~  grant  (reject [%member-missing holder])
  ?.  (seat-role role.body.u.grant)
    (reject [%role-forbidden holder role.body.u.grant])
  ?:  (lth observed-at effective-at.body.u.grant)
    (reject [%event-before-bound effective-at.body.u.grant observed-at])
  ?.  (span-valid observed-at expires-at)
    (reject [%renewal-invalid observed-at expires-at])
  =/  lease=lease:ms
    :*  1  project.registry  seat  1  holder
        epoch.body.u.grant  role.body.u.grant
        observed-at  expires-at  [%active ~]
    ==
  =/  next=registry:ms
    %=  registry
      current-seats  (~(put by current-seats.registry) seat 1)
      lease-history  (~(put by lease-history.registry) [seat 1] lease)
    ==
  [%& next]
::
++  renew
  |=  [registry=registry:ms actor=@p seat=@tas observed-at=@da expires-at=@da]
  ^-  result:ms
  ?.  (registry-valid registry)  (reject [%invalid-registry ~])
  =/  found=(unit lease:ms)  (current-lease registry seat)
  ?~  found  (reject [%seat-missing seat])
  =/  lease=lease:ms  u.found
  ?.  ?=(%active -.status.lease)  (reject [%seat-closed seat status.lease])
  ?.  =(holder.lease actor)  (reject [%foreign-holder holder.lease actor])
  ?:  (lth observed-at issued-at.lease)
    (reject [%event-before-bound issued-at.lease observed-at])
  ?:  (gte observed-at expires-at.lease)
    (reject [%lease-expired expires-at.lease observed-at])
  ?.  ?&  (gth expires-at expires-at.lease)
          (span-valid observed-at expires-at)
      ==
    (reject [%renewal-invalid expires-at.lease expires-at])
  =/  renewed=lease:ms  lease(expires-at expires-at)
  [%& registry(lease-history (~(put by lease-history.registry) [seat generation.lease] renewed))]
::
++  close-seat
  |=  [registry=registry:ms actor=@p seat=@tas observed-at=@da kind=?(%expire %revoke)]
  ^-  result:ms
  ?.  (registry-valid registry)  (reject [%invalid-registry ~])
  ?.  =(authority.registry actor)
    (reject [%foreign-authority authority.registry actor])
  =/  found=(unit lease:ms)  (current-lease registry seat)
  ?~  found  (reject [%seat-missing seat])
  =/  lease=lease:ms  u.found
  ?.  ?=(%active -.status.lease)  (reject [%seat-closed seat status.lease])
  ?:  (lth observed-at issued-at.lease)
    (reject [%event-before-bound issued-at.lease observed-at])
  ?:  =(%expire kind)
    ?.  (gte observed-at expires-at.lease)
      (reject [%lease-not-expired expires-at.lease observed-at])
    =/  closed=lease:ms  lease(status [%expired observed-at])
    [%& registry(lease-history (~(put by lease-history.registry) [seat generation.lease] closed))]
  =/  closed=lease:ms  lease(status [%revoked observed-at])
  [%& registry(lease-history (~(put by lease-history.registry) [seat generation.lease] closed))]
++  expire
  |=  [registry=registry:ms actor=@p seat=@tas observed-at=@da]
  ^-  result:ms
  (close-seat registry actor seat observed-at %expire)
++  revoke
  |=  [registry=registry:ms actor=@p seat=@tas observed-at=@da]
  ^-  result:ms
  (close-seat registry actor seat observed-at %revoke)
::
++  takeover
  |=  $:  registry=registry:ms
          actor=@p
          seat=@tas
          holder=@p
          observed-at=@da
          expires-at=@da
      ==
  ^-  result:ms
  ?.  (registry-valid registry)  (reject [%invalid-registry ~])
  ?.  =(authority.registry actor)
    (reject [%foreign-authority authority.registry actor])
  =/  found=(unit lease:ms)  (current-lease registry seat)
  ?~  found  (reject [%seat-missing seat])
  =/  old=lease:ms  u.found
  ?:  ?=(%active -.status.old)
    (reject [%seat-held seat holder.old generation.old])
  =/  closed=(unit @da)  (closed-at status.old)
  ?~  closed  (reject [%invalid-registry ~])
  ?:  (lth observed-at u.closed)
    (reject [%event-before-bound u.closed observed-at])
  =/  grant=(unit role-grant:ms)  (active-grant registry holder)
  ?~  grant  (reject [%member-missing holder])
  ?.  (seat-role role.body.u.grant)
    (reject [%role-forbidden holder role.body.u.grant])
  ?:  (lth observed-at effective-at.body.u.grant)
    (reject [%event-before-bound effective-at.body.u.grant observed-at])
  ?.  (span-valid observed-at expires-at)
    (reject [%renewal-invalid observed-at expires-at])
  =/  generation=@ud  +(generation.old)
  =/  lease=lease:ms
    :*  1  project.registry  seat  generation  holder
        epoch.body.u.grant  role.body.u.grant
        observed-at  expires-at  [%active ~]
    ==
  =/  next=registry:ms
    %=  registry
      current-seats  (~(put by current-seats.registry) seat generation)
      lease-history  (~(put by lease-history.registry) [seat generation] lease)
    ==
  [%& next]
::
++  authorize
  |=  $:  registry=registry:ms
          actor=@p
          seat=@tas
          binding=role-binding:ms
          observed-at=@da
      ==
  ^-  lease-result:ms
  ?.  (registry-valid registry)  [%| [%invalid-registry ~]]
  =/  found=(unit lease:ms)  (current-lease registry seat)
  ?~  found  [%| [%seat-missing seat]]
  =/  lease=lease:ms  u.found
  ?.  ?=(%active -.status.lease)  [%| [%seat-closed seat status.lease]]
  ?.  =(holder.lease actor)  [%| [%foreign-holder holder.lease actor]]
  ?:  (gte observed-at expires-at.lease)
    [%| [%lease-expired expires-at.lease observed-at]]
  ?.  ?&  (binding-current registry binding)
          =(actor member.binding)
          =(role-epoch.lease epoch.binding)
          =(role.lease role.binding)
      ==
    =/  state=(unit member-state:ms)  (~(get by members.registry) actor)
    [%| [%role-stale ?~(state 0 active-epoch.u.state) epoch.binding]]
  [%& lease]
::
++  roles-view
  |=  members=(map @p member-state:ms)
  ^-  (map @p [role=role:mp epoch=@ud])
  %-  ~(urn by members)
  |=  [member=@p state=member-state:ms]
  =/  grant=role-grant:ms  (~(got by grants.state) active-epoch.state)
  [role.body.grant active-epoch.state]
++  seats-view
  |=  registry=registry:ms
  ^-  (map @tas lease:ms)
  %-  ~(urn by current-seats.registry)
  |=  [seat=@tas generation=@ud]
  (~(got by lease-history.registry) [seat generation])
++  view-for
  |=  registry=registry:ms
  ^-  view:ms
  =/  roles=(map @p [role=role:mp epoch=@ud])  (roles-view members.registry)
  =/  seats=(map @tas lease:ms)  (seats-view registry)
  =/  digest=digest:mp
    `@ux`(shax (jam [%multiplayer-seat-view-v1 project.registry authority.registry project-head.registry roles seats]))
  [project.registry authority.registry project-head.registry roles seats digest]
++  read
  |=  [registry=registry:ms actor=@p]
  ^-  view-result:ms
  ?.  (registry-valid registry)  [%| [%invalid-registry ~]]
  ?.  (~(has by members.registry) actor)  [%| [%member-missing actor]]
  [%& (view-for registry)]
--
