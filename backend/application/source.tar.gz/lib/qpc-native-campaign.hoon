::  One explicitly requested useful task. This owner chooses when to use the
::  existing collection path; it neither chooses candidates nor stores reports.
/-  nc=native-coding
/+  instrument=qpc-instrument-read-contract, sensing=qpc-task-sensing,
    source=qpc-instrument-source, obs=qpc-observation,
    q=qpc-native-outcome, ct=cantrip-native-coding,
    local=native-coding-local-review, law=qpc-law-core,
    project=native-coding-project, sessions=native-coding-session,
    provider=native-coding-provider, measured=qpc-selected-measurement
|%
+$  command
  $:  %qpc-campaign-start-v1  id=@ux  member=@ux  key=@tas  grant=@ux
      baseline=@ux  expected=revision:nc  profile=revision:nc
      expected-law=@ux  requests=@ud  collections=@ud
      objective=@t  rationale=@t
  ==
+$  snapshot
  $:  plan=plan:instrument  project=project:nc  cases=cases:q
      source=receipt:source  law=revision:law  scope=scope:ct
      reviewer=scope:local  baseline=record:ct
  ==
+$  task  [owner=@p at=@da command=command snapshot=snapshot]
+$  child
  $:  session=@ux  grant=grant:ct  reading=@ux
      acknowledgments=(set ?(%gate %grant))
      declaration=(unit @ux)  receipt=(unit @ux)
  ==
+$  phase
  ?(%opening %collecting %deciding %gating %profile %pool %awaiting-next-task %stopped %unknown)
+$  record
  $:  task=task  phase=phase  request=(unit @ux)  due=(unit @da)
      attempts=(set [session=@ux request=@ux])
      child=(unit child)  previous=(list child)  reason=(unit @tas)
  ==
+$  state  [%qpc-native-campaigns-v1 records=(map @ux record)]
++  record-limit  256
++  empty  ^-(state [%qpc-native-campaigns-v1 ~])
++  digest  |=(value=* ^-(@ux (shax (jam [%qpc-native-campaign-v1 value]))))
++  unfinished
  ::  An authenticated native check, not a model claim, establishes the
  ::  starting defect. It is never enrolled as an observation or prediction.
  |=  [c=command v=snapshot]
  ^-  ?
  ?=(~ (unfinished-why c v))
++  unfinished-why
  ::  The same law, naming the first clause that fails. Every gate explains
  ::  its failures (2026-11-01): a bare refusal sent the operator to the source.
  |=  [c=command v=snapshot]
  ^-  (unit @tas)
  =/  r=record:ct  baseline.v
  =/  cases=(list case:q)
    (skim rows.cases.v |=(x=case:q =(%intended-behavior proposition.x)))
  ?.  =(1 (lent cases))  `%qpc-campaign-unfinished-single-intended-case
  =/  test=case:q  (snag 0 cases)
  ?.  =(baseline.c (key:ct request.r))  `%qpc-campaign-unfinished-baseline-request
  ?.  =(%finished stage.r)  `%qpc-campaign-unfinished-baseline-stage
  ?.  =(arguments.request.r [%check name.target.test])  `%qpc-campaign-unfinished-check-arguments
  ?.  =(expected.c source.context.request.r)  `%qpc-campaign-unfinished-baseline-source
  ?.  =((configuration:project project.v) configuration.context.request.r)  `%qpc-campaign-unfinished-baseline-configuration
  ?.  =(id.spec.project.v project.context.request.r)  `%qpc-campaign-unfinished-baseline-project
  ?.  =(authority.spec.project.v actor.context.request.r)  `%qpc-campaign-unfinished-baseline-actor
  ?~  result.r  `%qpc-campaign-unfinished-no-result
  =/  returned=tool-result:nc  u.result.r
  ?.  &(=(context.request.r context.returned) =(call-id.request.r call-id.returned))  `%qpc-campaign-unfinished-result-context
  ?.  ?=(%diagnostics -.output.returned)  `%qpc-campaign-unfinished-no-diagnostics
  =/  diagnostics=(list diagnostic:nc)  values.output.returned
  ?~  diagnostics  `%qpc-campaign-unfinished-empty-diagnostics
  =/  assessed
    (assess:q test source.i.diagnostics [target.test diagnostics])
  ?:  ?=(%| -.assessed)  `%qpc-campaign-unfinished-assessment-invalid
  ?.  =(%fail verdict.p.assessed)  `%qpc-campaign-unfinished-intended-not-failing
  ~
++  compatible
  ::  Native readers authenticate these inputs. Pure validation grants no
  ::  authority to caller-supplied scopes, checks, or source receipts.
  |=  [our=@p c=command v=snapshot]
  ^-  ?
  ?=(~ (incompatible our c v))
++  incompatible
  ::  The same law as +compatible, clause by clause in the same order,
  ::  naming the first clause that fails so a refusal says what to fix.
  |=  [our=@p c=command v=snapshot]
  ^-  (unit @tas)
  =/  p=plan:instrument  plan.v
  =/  g=grant:ct  grant.scope.v
  ?.  (levy `(list @ux)`~[id.c member.c grant.c baseline.c expected-law.c] identifier:sensing)  `%qpc-campaign-binding-identifiers
  ?.  (plan-valid:instrument our p)  `%qpc-campaign-binding-plan-invalid
  ?.  (successor-plan:instrument p)  `%qpc-campaign-binding-plan-not-successor
  ?.  =(member.c session.p)  `%qpc-campaign-binding-member-session
  ?.  =(objective.p (digest:obs objective.c))  `%qpc-campaign-binding-objective-digest
  ?.  (text-valid:sessions objective.c)  `%qpc-campaign-binding-objective-text
  ?.  (reason-valid:law rationale.c)  `%qpc-campaign-binding-rationale
  ?.  &((gth requests.c 0) (lte requests.c 64))  `%qpc-campaign-binding-requests-range
  ?.  &((gth collections.c 0) (lte collections.c 16))  `%qpc-campaign-binding-collections-range
  ?.  (lte collections.c requests.c)  `%qpc-campaign-binding-collections-over-requests
  ?.  !=(%$ key.c)  `%qpc-campaign-binding-key-empty
  ?.  (revision-valid:project expected.c)  `%qpc-campaign-binding-expected-revision
  ?.  (revision-valid:project profile.c)  `%qpc-campaign-binding-profile-revision
  ?.  =(our owner.expected.c)  `%qpc-campaign-binding-expected-owner
  ?.  =(our owner.profile.c)  `%qpc-campaign-binding-profile-owner
  ?.  =(expected.c source.source.v)  `%qpc-campaign-binding-expected-source
  ?.  =(working.project.v desk.expected.c)  `%qpc-campaign-binding-working-desk
  ?.  =(project.manifest.p id.spec.project.v)  `%qpc-campaign-binding-manifest-project
  ?.  =(cases.p (digest:q cases.v))  `%qpc-campaign-binding-cases-digest
  ?.  (checks-protected:sensing project.v artifact.p cases.v)  `%qpc-campaign-binding-checks-protected
  ?.  (valid:law law.v)  `%qpc-campaign-binding-law-invalid
  ?.  =(expected-law.c id.law.v)  `%qpc-campaign-binding-law-id
  ?.  =(binding.law.v [instrument.p stream.p law.p (digest:obs manifest.p) project.manifest.p /pool])  `%qpc-campaign-binding-law-binding
  ?.  (grant-valid:ct our g)  `%qpc-campaign-binding-grant-invalid
  ?.  ?=(~ revoked.scope.v)  `%qpc-campaign-binding-scope-revoked
  ?.  =(grant.c id.g)  `%qpc-campaign-binding-grant-id
  ?.  =(member.c session.g)  `%qpc-campaign-binding-grant-session
  ?.  =(our actor.g)  `%qpc-campaign-binding-grant-actor
  ?.  =(project.v project.g)  `%qpc-campaign-binding-grant-project
  ?.  (levy `(list operation:nc)`~[%read %patch %compile %check] |=(op=operation:nc (~(has in operations.g) op)))  `%qpc-campaign-binding-grant-operations
  ?.  =(our owner.reviewer.v)  `%qpc-campaign-binding-reviewer-owner
  ?.  enabled.reviewer.v  `%qpc-campaign-binding-reviewer-disabled
  ?.  =(id.spec.project.v project.reviewer.v)  `%qpc-campaign-binding-reviewer-project
  ?.  (gth generation.reviewer.v 0)  `%qpc-campaign-binding-reviewer-generation
  ?.  (lte (met 0 generation.reviewer.v) 64)  `%qpc-campaign-binding-reviewer-generation-length
  ?.  (name-valid:provider provider-key.reviewer.v)  `%qpc-campaign-binding-provider-name
  ?.  (selection-valid:provider selection.reviewer.v)  `%qpc-campaign-binding-provider-selection
  ?.  !=('unknown' model.selection.reviewer.v)  `%qpc-campaign-binding-model-unknown
  ?.  !=('model-unreported' model.selection.reviewer.v)  `%qpc-campaign-binding-model-unreported
  (unfinished-why c v)
++  task-digest
  |=  r=record
  ^-  @ux
  (digest [command.task.r snapshot.task.r])
++  prepared
  |=  r=record
  ^-  ?
  ?&  =(%awaiting-next-task phase.r)  =(`%qpc-task-prepared reason.r)
      ?=(~ request.r)  ?=(~ due.r)
      =(~ attempts.r)  ?=(~ child.r)  ?=(~ previous.r)
  ==
++  insert
  :: Preparation and activation share one identity/capacity/binding gate.
  :: Only the opening variant describes a timer; this pure gate sends none.
  |=  [s=state our=@p actor=@p at=@da c=command v=snapshot opening=?]
  ^-  (each state @tas)
  ?.  =(our actor)  [%| %qpc-campaign-owner-required]
  ?:  (~(has by records.s) id.c)  [%| %qpc-campaign-already-registered]
  ?.  (lth ~(wyt by records.s) record-limit)  [%| %qpc-campaign-capacity]
  ?:  (lien ~(val by records.s) |=(r=record =(member.c member.command.task.r)))
    [%| %qpc-campaign-member-already-owned]
  ?.  (compatible our c v)  [%| %qpc-campaign-task-refused]
  =/  r=record
    [[our at c v] ?:(opening %opening %awaiting-next-task) ~ ?:(opening `(add at ~s1) ~) ~ ~ ~ ?:(opening ~ `%qpc-task-prepared)]
  [%& s(records (~(put by records.s) id.c r))]
++  begin
  |=  [s=state our=@p actor=@p at=@da c=command v=snapshot]
  ^-  (each state @tas)
  (insert s our actor at c v %.y)
++  prepare
  |=  [s=state our=@p actor=@p at=@da c=command v=snapshot]
  ^-  (each state @tas)
  (insert s our actor at c v %.n)
++  activate
  :: The native owner separately authenticates the retained handoff and fresh
  :: unused-member reads. This gate compares their frozen task bytes exactly.
  |=  [s=state our=@p actor=@p at=@da id=@ux expected=@ux fresh=snapshot]
  ^-  (each state @tas)
  ?.  =(our actor)  [%| %qpc-campaign-owner-required]
  =/  found  (~(get by records.s) id)
  ?~  found  [%| %qpc-campaign-prepared-missing]
  =/  r=record  u.found
  ?.  (prepared r)  [%| %qpc-campaign-not-prepared]
  ?.  &(=(expected (task-digest r)) =(fresh snapshot.task.r))
    [%| %qpc-campaign-prepared-task-changed]
  ?.  (compatible our command.task.r fresh)
    [%| %qpc-campaign-task-refused]
  [%& s(records (~(put by records.s) id r(phase %opening, due `(add at ~s1), reason ~)))]
++  request
  |=  [r=record session=@ux request=@ux]
  ^-  (each record @tas)
  ?:  (prepared r)  [%| %qpc-campaign-not-activated]
  ?:  (~(has in attempts.r) [session request])  [%| %qpc-campaign-request-already-consumed]
  ?.  (lth ~(wyt in attempts.r) requests.command.task.r)
    [%| %qpc-campaign-request-budget]
  [%& r(attempts (~(put in attempts.r) [session request]))]
++  make-child
  |=  [r=record reading=@ux]
  ^-  (each child @tas)
  ?.  (lth (lent previous.r) collections.command.task.r)
    [%| %qpc-campaign-collection-budget]
  ?^  child.r  [%| %qpc-campaign-collection-pending]
  =/  c=command  command.task.r
  =/  session=@ux  (digest [%collection id.c (lent previous.r)])
  =/  original=grant:ct  grant.scope.snapshot.task.r
  =/  g=grant:ct
    original(id (digest [%grant id.c session]), session session)
  [%& [session g reading ~ ~ ~]]
++  unavailable
  |=  [r=record phase=?(%stopped %unknown %awaiting-next-task) reason=@tas]
  ^-  record
  r(phase phase, due ~, request ~, reason `reason)
++  settled
  ::  Only the native reader supplies this already joined terminal receipt.
  ::  This transition neither authenticates a receipt nor creates a report.
  |=  [r=record receipt=receipt:measured verdict=@tas]
  ^-  (each [next=record resume=? handover=?] @tas)
  ?.  =(%pool phase.r)  [%| %qpc-campaign-phase-mismatch]
  ?~  child.r  [%| %qpc-campaign-collection-missing]
  =/  child=child  u.child.r(receipt `id.receipt)
  =/  next=record  r(child ~, previous (weld previous.r ~[child]), request ~, due ~)
  ?:  =(%applied status.receipt)
    ?.  =(%accept verdict)  [%| %qpc-campaign-terminal-mismatch]
    [%& [(unavailable next %awaiting-next-task %qpc-campaign-effect-applied) %.n %.y]]
  ?:  &(=(%revise verdict) =(expected.command.task.r resulting.receipt))
    [%& [next(phase %collecting) %.y %.n]]
  [%& [(unavailable next %stopped %qpc-campaign-task-refused) %.n %.n]]
++  recover
  ::  A reload cannot trust work in flight. An idle collecting campaign (no
  ::  request, due timer or child) carries none, so it survives a code-only
  ::  deploy and its landed task can still be completed (2026-11-01).
  |=  s=state
  ^-  state
  %=  s
    records
      %-  ~(run by records.s)
      |=  r=record
      ?:  ?=(?(%stopped %unknown %awaiting-next-task) phase.r)  r
      ?:  &(=(%collecting phase.r) ?=(~ request.r) ?=(~ due.r) ?=(~ child.r))  r
      (unavailable r %unknown %qpc-campaign-reload-unconfirmed)
  ==
++  wire-for
  |=  [id=@ux r=record]
  ^-  wire
  /qpc-campaign/(scot %ux id)/(scot %ux (digest [phase.r due.r request.r child.r]))
++  dispatch
  ::  Loaded/unknown owners cannot release a late inner inference or timer.
  |=  [s=state session=@ux request=@ux]
  ^-  ?
  =/  owners=(list record)
    %+  skim  ~(val by records.s)
    |=  r=record
    |(=(session member.command.task.r) ?~(child.r %.n =(session session.u.child.r)) (lien previous.r |=(x=child =(session session.x))))
  ?~  owners  %.y
  =/  r=record  i.owners
  &((~(has in attempts.r) [session request]) |(&(=(session member.command.task.r) =(%collecting phase.r)) &(!=(session member.command.task.r) =(%pool phase.r) ?~(child.r %.n =(session session.u.child.r)))))
++  child-valid
  |=  [t=task index=@ud x=child]
  ^-  ?
  =/  c=command  command.t
  =/  session=@ux  (digest [%collection id.c index])
  =/  original=grant:ct  grant.scope.snapshot.t
  ?&  =(session session.x)  !=(member.c session.x)
      =(grant.x original(id (digest [%grant id.c session]), session session))
      (identifier:sensing reading.x)
      ?~(declaration.x %.y (identifier:sensing u.declaration.x))
      ?~(receipt.x %.y (identifier:sensing u.receipt.x))
  ==
++  valid
  |=  [our=@p s=state]
  ^-  ?
  ?&  (lte ~(wyt by records.s) record-limit)
      =((lent ~(val by records.s)) ~(wyt in (silt (turn ~(val by records.s) |=(r=record member.command.task.r)))))
      %+  levy  ~(tap by records.s)
      |=  [id=@ux r=record]
      =/  c=command  command.task.r
      ?&  =(id id.c)  =(our owner.task.r)  (compatible our c snapshot.task.r)
          (lte ~(wyt in attempts.r) requests.c)
          (lte (lent previous.r) collections.c)
          =/  prior=(list child)  previous.r
          =/  index=@ud  0
          |-  ^-  ?
          ?~  prior  %.y
          &((child-valid task.r index i.prior) ?=(^ declaration.i.prior) ?=(^ receipt.i.prior) $(prior t.prior, index +(index)))
          (levy ~(tap in attempts.r) |=([session=@ux request=@ux] &((identifier:sensing session) (identifier:sensing request))))
          ?~(due.r %.y (gth u.due.r 0))
          ?:(=(`%qpc-task-prepared reason.r) (prepared r) %.y)
          ?:  ?=(?(%stopped %unknown %awaiting-next-task) phase.r)
            &(?=(~ due.r) ?=(~ request.r) ?~(reason.r %.n !=(%$ u.reason.r)))
          ?=(~ reason.r)
          ?~  child.r  !?=(?(%gating %profile %pool) phase.r)
          &((lth (lent previous.r) collections.c) (child-valid task.r (lent previous.r) u.child.r))
      ==
  ==
--
