::  /lib/multiplayer-dispute
::
::  Pure Cantrip-shaped dispute law: verdicts are derived from recorded facts.
::
/-  md=multiplayer-dispute
|%
++  contradiction-digest
  |=  body=contradiction-body:md
  ^-  digest:md
  `@ux`(shax (jam [%multiplayer-contradiction-v1 body]))
++  make-contradiction
  |=  body=contradiction-body:md
  ^-  contradiction:md
  [body (contradiction-digest body)]
++  contradiction-valid
  |=  item=contradiction:md
  ^-  ?
  ?&  =(1 version.body.item)
      !=(0 project.body.item)
      !=(left.body.item right.body.item)
      ?=(^ ~(tap in paths.body.item))
      !=(0 raised-at.body.item)
      =((contradiction-digest body.item) digest.item)
  ==
++  contest-digest
  |=  body=contest-body:md
  ^-  digest:md
  `@ux`(shax (jam [%multiplayer-contest-v1 body]))
++  make-contest
  |=  body=contest-body:md
  ^-  contest:md
  [body (contest-digest body)]
++  contest-valid
  |=  item=contest:md
  ^-  ?
  ?&  =(1 version.body.item)
      !=(0 project.body.item)
      !=(0 changeset.body.item)
      !=(0 reason.body.item)
      !=(0 contested-at.body.item)
      =((lent evidence.body.item) (lent ~(tap in (silt `(list digest:md)`(turn evidence.body.item |=(item=evidence:md handle.item))))))
      =((contest-digest body.item) digest.item)
  ==
++  count-stance
  |=  [wanted=stance:md evidence=(list evidence:md)]
  ^-  @ud
  (lent (skim evidence |=(item=evidence:md =(wanted stance.item))))
++  derive-verdict
  |=  [contradiction=contradiction:md contest=contest:md]
  ^-  verdict:md
  ?.  ?&  (contradiction-valid contradiction)
          (contest-valid contest)
          =(project.body.contradiction project.body.contest)
      ==
    %hold
  =/  supports=@ud  (count-stance %supports evidence.body.contest)
  =/  opposes=@ud  (count-stance %opposes evidence.body.contest)
  ?:  ?&  =(0 supports)  =(0 opposes)  ==  %hold
  ?:  =(0 opposes)  %accept
  ?:  =(0 supports)  %refuse
  ?:  =(1 ~(wyt in paths.body.contradiction))  %revise
  %split
++  ruling-digest
  |=  body=ruling-body:md
  ^-  digest:md
  `@ux`(shax (jam [%multiplayer-ruling-v1 body]))
++  decide
  |=  [contradiction=contradiction:md contest=contest:md law=digest:md ruled-at=@da]
  ^-  ruling:md
  =/  body=ruling-body:md
    [1 digest.contradiction digest.contest (derive-verdict contradiction contest) law ruled-at]
  [body (ruling-digest body)]
++  replay
  |=  [contradiction=contradiction:md contests=(list contest:md) law=digest:md ruled-at=@da]
  ^-  (list ruling:md)
  (turn contests |=(contest=contest:md (decide contradiction contest law ruled-at)))
--
