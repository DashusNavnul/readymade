::  Called only by Cantrip's own Gall arms. A noun poke cannot supply bowl,
::  an outgoing subscription, or an on-agent event. No Graf-origin shortcut.
/-  ci=vibecoding-connected-intake
/+  core=cantrip-connected-write, read=cantrip-connected-write-read,
    editor=cantrip-editor-save,
    law=cantrip-law-window
|%
++  reload
  ::  Preserve submitted receipts exactly. An interrupted watch is closed,
  ::  never reopened or replayed by loading saved state.
  |=  [our=@p now=@da held=ledger:core saves=ledger:editor]
  ^-  transition:core
  ?>  (valid:core held saves)
  ?>  (levy ~(val by held) |=(e=entry:core =(our owner.e)))
  =/  remaining  ~(tap by held)
  =|  cards=(list card:agent:gall)
  |-  ^-  transition:core
  ?~  remaining  [held saves cards]
  =/  e=entry:core  q.i.remaining
  ?.  (pending:core e)  $(remaining t.remaining)
  ?>  (lte at.e now)
  %=  $
    remaining  t.remaining
    held  (~(put by held) p.i.remaining e(state [%unknown %reload]))
    cards  (weld cards (close:core our e))
  ==
++  event
  |=  [b=bowl:gall held=ledger:core saves=ledger:editor w=wire sign=sign:agent:gall window=window:law]
  ^-  transition:core
  =/  unchanged=transition:core  [held saves ~]
  ?.  =(our.b src.b)  unchanged
  =/  key  (key-for:core w)
  ?~  key  unchanged
  =/  found  (~(get by held) u.key)
  ?~  found  unchanged
  =/  e=entry:core  u.found
  ?.  &((valid:core held saves) =(our.b owner.e) (pending:core e))  unchanged
  ?.  (lte at.e now.b)  unchanged
  =/  stop
    |=  reason=@tas
    =/  stopped  (stop:core our.b now.b held saves u.key reason)
    ?:(?=(%& -.stopped) p.stopped unchanged)
  ::  Gall removes wex BEFORE delivering a kick or negative watch ack.
  ::  These signs may only close the exact pending wire; neither admits data.
  ?:  ?=(%kick -.sign)  (stop %watch-kicked)
  ?:  &(?=(%watch-ack -.sign) ?=(^ p.sign))
    =/  denied  (ack:core our.b now.b held saves [src.b %viki] w sign)
    ?:(?=(%& -.denied) p.denied (stop %watch-rejected))
  ::  Positive acknowledgments and facts must have the exact acknowledged
  ::  outgoing subscription supplied by Gall, including its destination path.
  =/  subscribed  (~(get by wex.b) [w our.b %viki])
  ?.  =(subscribed `[%.y /vibecoding-connected-reviews])  unchanged
  ?:  (gte now.b expires.e)  (stop %timeout)
  ?:  ?=(%watch-ack -.sign)
    =/  acked  (ack:core our.b now.b held saves [src.b %viki] w sign)
    ?:(?=(%& -.acked) p.acked unchanged)
  ?.  ?=(%fact -.sign)  unchanged
  ?.  ?=(%reviewing -.state.e)  unchanged
  ?.  =(%noun p.cage.sign)  (stop %wrong-mark)
  =/  parsed  ((soft ,record:ci) q.q.cage.sign)
  ?~  parsed  (stop %malformed-intake)
  ::  The feed is shared. A different request's genuine event is irrelevant.
  ?.  &(=(candidate.request.e candidate.ticket.body.u.parsed) =(nonce.request.e nonce.ticket.body.u.parsed))
    unchanged
  =/  checked
    (mule |.((receive:read our.b src.b now.b held saves [src.b %viki] w sign window)))
  ?:  ?=(%| -.checked)  (stop %read-unavailable)
  ?:  ?=(%| -.p.checked)  (stop p.p.checked)
  p.p.checked
++  wake
  |=  [b=bowl:gall held=ledger:core saves=ledger:editor w=wire sign=sign-arvo]
  ^-  transition:core
  =/  unchanged=transition:core  [held saves ~]
  ?.  ?=([%behn %wake *] sign)  unchanged
  =/  key  (key-for:core w)
  ?~  key  unchanged
  =/  found  (~(get by held) u.key)
  ?~  found  unchanged
  ?.  (gte now.b expires.u.found)  unchanged
  =/  stopped  (stop:core our.b now.b held saves u.key %timeout)
  ?:(?=(%& -.stopped) p.stopped unchanged)
++  reload-v2
  |=  [our=@p now=@da legacy=ledger:core held=ledger-v2:core saves=ledger:editor]
  ^-  transition-v2:core
  ?>  (compatible:core legacy held saves)
  ?>  (levy ~(val by held) |=(e=entry-v2:core =(our owner.e)))
  =/  remaining  ~(tap by held)
  =|  cards=(list card:agent:gall)
  |-  ^-  transition-v2:core
  ?~  remaining  [held saves cards]
  =/  e=entry-v2:core  q.i.remaining
  ?.  (pending-v2:core e)  $(remaining t.remaining)
  ?>  (lte at.e now)
  %=  $
    remaining  t.remaining
    held  (~(put by held) p.i.remaining e(state [%unknown %reload]))
    cards  (weld cards (close-v2:core our e))
  ==
++  event-v2
  |=  [b=bowl:gall legacy=ledger:core held=ledger-v2:core saves=ledger:editor w=wire sign=sign:agent:gall window=window:law]
  ^-  transition-v2:core
  =/  unchanged=transition-v2:core  [held saves ~]
  ?.  =(our.b src.b)  unchanged
  =/  key  (key-for-v2:core w)
  ?~  key  unchanged
  =/  found  (~(get by held) u.key)
  ?~  found  unchanged
  =/  e=entry-v2:core  u.found
  ?.  &((compatible:core legacy held saves) =(our.b owner.e) (pending-v2:core e))  unchanged
  ?.  (lte at.e now.b)  unchanged
  =/  stop
    |=  reason=@tas
    =/  stopped  (stop-v2:core our.b now.b legacy held saves u.key reason)
    ?:(?=(%& -.stopped) p.stopped unchanged)
  ::  A negative ack or kick has already removed wex; it can only close.
  ?:  ?=(%kick -.sign)  (stop %watch-kicked)
  ?:  &(?=(%watch-ack -.sign) ?=(^ p.sign))
    =/  denied  (ack-v2:core our.b now.b legacy held saves [src.b %viki] w sign)
    ?:(?=(%& -.denied) p.denied (stop %watch-rejected))
  =/  subscribed  (~(get by wex.b) [w our.b %viki])
  ?.  =(subscribed `[%.y /vibecoding-connected-reviews])  unchanged
  ?:  (gte now.b expires.e)  (stop %timeout)
  ?:  ?=(%watch-ack -.sign)
    =/  acked  (ack-v2:core our.b now.b legacy held saves [src.b %viki] w sign)
    ?:(?=(%& -.acked) p.acked unchanged)
  ?.  ?=(%fact -.sign)  unchanged
  ?.  ?=(%reviewing -.state.e)  unchanged
  ?.  =(%noun p.cage.sign)  (stop %wrong-mark)
  =/  parsed  ((soft ,record-v2:ci) q.q.cage.sign)
  ?~  parsed
    ::  Viki publishes both versions on this feed. An old, well-shaped
    ::  intake is unrelated, not a v2 receipt or an authority downgrade.
    ?^  ((soft ,record:ci) q.q.cage.sign)  unchanged
    (stop %malformed-intake)
  ?.  &(=(candidate.request.e candidate.ticket.body.u.parsed) =(nonce.request.e nonce.ticket.body.u.parsed))
    unchanged
  =/  checked
    (mule |.((receive-v2:read our.b src.b now.b legacy held saves [src.b %viki] w sign window)))
  ?:  ?=(%| -.checked)  (stop %read-unavailable)
  ?:  ?=(%| -.p.checked)  (stop p.p.checked)
  p.p.checked
++  wake-v2
  |=  [b=bowl:gall legacy=ledger:core held=ledger-v2:core saves=ledger:editor w=wire sign=sign-arvo]
  ^-  transition-v2:core
  =/  unchanged=transition-v2:core  [held saves ~]
  ?.  ?=([%behn %wake *] sign)  unchanged
  =/  key  (key-for-v2:core w)
  ?~  key  unchanged
  =/  found  (~(get by held) u.key)
  ?~  found  unchanged
  ?.  (gte now.b expires.u.found)  unchanged
  =/  stopped  (stop-v2:core our.b now.b legacy held saves u.key %timeout)
  ?:(?=(%& -.stopped) p.stopped unchanged)
--
