::  Explicit owner consent for an already reviewed candidate. This adapter
::  supplies no verdict; Cantrip rechecks its current grant and Viki decision.
/-  nc=native-coding
/+  loop=native-coding-loop, accept=native-coding-accept,
    project=native-coding-project, solo=native-coding-solo-review-http,
    guard=viki-scry-guard, cr=codex-responses
|%
+$  selector  [owner=@p session=@ux project=@t candidate=@ux basis=@ux]
++  select
  |=  object=json
  ^-  selector
  ?>  ?=(%o -.object)
  ?>  =((silt ~['nonce' 'kind' 'owner' 'session' 'project' 'candidate' 'basis' 'consent']) ~(key by p.object))
  ?>  =(`'candidate-decide' (string:cr object 'kind'))
  ?>  (boolean:solo object 'consent')
  =/  text=@t  (need (string:cr object 'owner'))
  =/  owner=@p  (need (slaw %p text))
  ?>  =(text (scot %p owner))
  =/  name=@t  (need (string:cr object 'project'))
  ?>  &(!=('' name) (lte (met 3 name) 128))
  [owner (hex:solo object 'session') name (hex:solo object 'candidate') (hex:solo object 'basis')]
++  ready
  ::  Pure correlation gate, using full native reports rather than UI summaries.
  |=  [our=@p now=@da q=selector e=public-session:loop r=record:accept d=decision:accept accepted=tree:nc working=tree:nc]
  ^-  ?
  =/  c=candidate:nc  candidate.r
  ?~  report.r  %.n
  ?&  =(our owner.q)  =(our owner.session.e)  =(our worker.e)
      =(our authority.spec.project.r)  =(our owner.source.context.c)
      =(session.q id.session.e)  =(session.q session.context.c)
      =(project.q project.session.e)  =(project.q project.context.c)
      =(project.q id.spec.project.r)  =(candidate.q id.c)
      =(basis.q (shax (jam source.context.c)))
      =(working.session.e source.context.c)
      =(%review stage.r)  ?=(~ landed.r)  ?=(~ reason.r)
      =(%approve verdict.d)  (lte at.d now)
      (decision-valid:accept project.r c d)  =(u.report.r report.d)
      =(basis.c working)  =(accepted.c revision.accepted)
  ==
++  decode
  |=  [our=@p now=@da object=json]
  ^-  command:accept
  =/  q=selector  (select object)
  ?>  =(our owner.q)
  =/  e  (session:solo our now session.q)
  ?>  (agent-live:guard our now %cantrip)
  =/  raw=*  .^(* %gx /(scot %p our)/cantrip/(scot %da now)/native-coding/candidate/(scot %ux candidate.q)/noun)
  =/  r  (need (need ((soft ,(unit record:accept)) raw)))
  =/  raw=*  .^(* %gx /(scot %p our)/viki/(scot %da now)/native-coding/decision/(scot %ux candidate.q)/noun)
  =/  d  (need (need ((soft ,(unit decision:accept)) raw)))
  =/  current  (current:project our now project.r)
  ?>  ?=(%& -.current)
  ?>  (ready our now q e r d accepted.p.current working.p.current)
  [%native-coding-decide-v1 candidate.q]
--
