::  /lib/cantrip-vibecoding-dispatch-read
::
::  The one live join for Cantrip's vibecoding dispatch decision.  The caller
::  names only a proposal digest, seat and sequence; Ames supplies the actor.
::  Every other input is read from its canonical owner before the pure gate
::  runs.  Missing prerequisite evidence is not a law verdict.
::
/-  cls=cantrip-lease, graf-sur=graf, mg=moon-grant, ss=seat-session,
    vd=vibecoding-dispatch, vp=vibecoding-proposal, vw=viki-worker,
    ws=workspace
/+  cvd=cantrip-vibecoding-dispatch, cvp=cantrip-vibecoding-proposal,
    cle=cantrip-lease, sl=seat-session, vsg=viki-scry-guard, wl=workspace
|%
++  not-decided
  |=  $:  digest=@ux
          actor=@p
          seat=seat:ss
          sequence=@ud
          reasons=(list evidence-refusal:vd)
      ==
  ^-  decision:vd
  [%vibecoding-dispatch-decision-v1 %.n digest actor seat sequence ~ reasons]
::
++  claim-for
  |=  [rows=(list *) actor=@p workspace=@tas]
  ^-  (unit claim:ws)
  =/  claims=(list claim:ws)  (murn rows claim-of:wl)
  =/  matching=(list claim:ws)
    (skim claims |=(claim=claim:ws ?&(=(holder.claim actor) =(fork.claim workspace))))
  ?~(matching ~ `i.matching)
::
++  read
  |=  $:  our=@p
          now=@da
          actor=@p
          digest=@ux
          seat=seat:ss
          sequence=@ud
          mirrors=table:cls
          law=law-binding:vp
      ==
  ^-  decision:vd
  ?.  (agent-live:vsg our now %graf)
    (not-decided digest actor seat sequence ~[[%source-unavailable %graf]])
  =/  graf-base=path  /(scot %p our)/graf/(scot %da now)
  =/  proposal-rows=(list *)
    .^((list *) %gx (weld graf-base /by-kind/vibecoding-proposal-record/noun))
  =/  record=(unit record:vp)
    (find-proposal-record:cvp proposal-rows digest)
  ?~  record
    (not-decided digest actor seat sequence ~[[%proposal-missing ~]])
  ?.  (agent-live:vsg our now %seat-warden)
    (not-decided digest actor seat sequence ~[[%source-unavailable %seat-warden]])
  ?.  (agent-live:vsg our now %viki)
    (not-decided digest actor seat sequence ~[[%source-unavailable %viki]])
  =/  sessions=table:sl
    .^(table:sl %gx /(scot %p our)/seat-warden/(scot %da now)/table/noun)
  =/  seat-base=path  (weld graf-base /seat)
  =/  seat-path=path
    (weld seat-base ~[`@t`seat %holder %noun])
  =/  write=(unit graf-seat-write:graf-sur)
    .^((unit graf-seat-write:graf-sur) %gx seat-path)
  ?~  write
    (not-decided digest actor seat sequence ~[[%seat-write-missing ~]])
  =/  workspace=(unit @tas)  (slaw %tas session-id.u.write)
  ?~  workspace
    (not-decided digest actor seat sequence ~[[%seat-write-malformed ~]])
  =/  claim-rows=(list *)
    .^((list *) %gx (weld graf-base /by-kind/workspace-claim/noun))
  =/  claim=(unit claim:ws)  (claim-for claim-rows actor u.workspace)
  ?~  claim
    (not-decided digest actor seat sequence ~[[%workspace-claim-missing ~]])
  =/  desks=(set @tas)
    .^((set @tas) %cd ~[(scot %p our) '' (scot %da now)])
  =/  workers=worker-organ:vw
    .^(worker-organ:vw %gx /(scot %p our)/viki/(scot %da now)/workers/noun)
  ?.  authoritative.workers
    (not-decided digest actor seat sequence ~[[%viki-workers-not-authoritative ~]])
  =/  grant=(unit moon-grant:mg)
    (~(get by grants.core.workers) lease-id.u.write)
  =/  mirror=(unit mirrored-lease:mg)
    (lookup:cle mirrors lease-id.u.write now)
  =/  proposal=proposal:vp  proposal.body.u.record
  =/  proposal-verdict=verdict:vp  verdict.body.u.record
  =/  verdict=verdict:vd
    %-  gate:cvd
    :*  proposal  proposal-verdict  law  our  actor  seat  sessions
        u.write  u.claim  desks  grant  mirror  sequence  now
    ==
  [%vibecoding-dispatch-decision-v1 %.y digest actor seat sequence `verdict ~]
--
