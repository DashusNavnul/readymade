::  Canonical selection/current-law/source/grant join for one fresh ordinary
::  session. Only a decision ID crosses the public owner command boundary.
/+  selected=qpc-native-selected, c=qpc-native-controller,
    controller=qpc-native-controller-read, d=qpc-native-decision,
    instrument=qpc-instrument-contract, observer=qpc-observer,
    pool=qpc-native-pool, ct=cantrip-native-coding,
    guard=viki-scry-guard, admit=qpc-native-admission
|%
+$  view  [choice=record:c input=input:pool current=current:d]
+$  reader  $-([inner=agent:gall b=bowl:gall id=@ux] (each view @tas))
+$  fresh-reader  $-([inner=agent:gall b=bowl:gall p=plan:selected] (each view @tas))
++  choices
  |=  [inner=agent:gall b=bowl:gall]
  ^-  (unit state:c)
  =/  raw  (raw:instrument inner b /x/qpc/controller)
  ?~  raw  ~
  =/  parsed  ((soft state:c) u.raw)
  ?~  parsed  ~
  ?.  &(=(u.raw u.parsed) (valid:c u.parsed))  ~
  parsed
++  read
  |=  [inner=agent:gall b=bowl:gall id=@ux]
  ^-  (each view @tas)
  ?.  =(our.b src.b)  [%| %qpc-selected-owner-required]
  =/  held  (choices inner b)
  ?~  held  [%| %qpc-selected-controller-unavailable]
  =/  rows=(list record:c)
    (skim ~(val by records.u.held) |=(r=record:c =(id id.decision.r)))
  ?.  =(1 (lent rows))  [%| %qpc-selected-choice-missing]
  =/  r=record:c  (snag 0 rows)
  ?.  =(%chosen phase.r)  [%| %qpc-selected-choice-not-final]
  =/  now  (read:controller inner b session.frozen.decision.r)
  ?:  ?=(%| -.now)  [%| p.now]
  ?.  =(origin.r origin.p.now)  [%| %qpc-selected-origin-changed]
  [%& [r input.p.now current.p.now]]
++  ordinary
  |=  [inner=agent:gall b=bowl:gall id=@ux]
  ^-  ?
  =/  raw  (raw:instrument inner b /x/qpc/required-sessions)
  ?~  raw  %.n
  =/  parsed  ((soft ,[%qpc-session-gate-v1 %viki ids=(set @ux)]) u.raw)
  ?~  parsed  %.n
  ?:  (~(has in ids.u.parsed) id)  %.n
  ?.  (agent-live:guard our.b now.b %cantrip)  %.n
  =/  managed=[%qpc-session-gate-v1 %cantrip ids=(set @ux)]
    .^([%qpc-session-gate-v1 %cantrip ids=(set @ux)] %gx /(scot %p our.b)/cantrip/(scot %da now.b)/qpc/required-sessions/noun)
  !(~(has in ids.managed) id)
++  fresh
  |=  [inner=agent:gall b=bowl:gall p=plan:selected]
  ^-  (each view @tas)
  =/  got  (read inner b id.p)
  ?:  ?=(%| -.got)  [%| p.got]
  =/  rebuilt  (make:selected choice.p.got input.p.got at.p nonce.p)
  ?.  &(?=(%& -.rebuilt) =(p p.rebuilt))  [%| %qpc-selected-plan-changed]
  =/  session=@ux  id.session.entry.p
  ?.  (ordinary inner b session)  [%| %qpc-selected-session-not-ordinary]
  =/  current  (input:observer inner b session)
  ?~  current  [%| %qpc-selected-fresh-session-missing]
  ?.  =(u.current [entry.p key.p id.grant.p])  [%| %qpc-selected-fresh-session-changed]
  =/  scope=(unit scope:ct)
    .^((unit scope:ct) %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/grant/(scot %ux id.grant.p)/noun)
  ?~  scope  [%| %qpc-selected-fresh-grant-unconfirmed]
  ?.  &(=(grant.p grant.u.scope) ?=(~ revoked.u.scope))
    [%| %qpc-selected-fresh-grant-changed]
  =/  allowed  (allowed:ct our.b now.b u.scope request.p)
  ?:  ?=(%| -.allowed)  [%| p.allowed]
  got
++  receipt
  |=  [b=bowl:gall marker=@ux]
  ^-  (each receipt:admit @tas)
  (receipt:controller b marker)
--
