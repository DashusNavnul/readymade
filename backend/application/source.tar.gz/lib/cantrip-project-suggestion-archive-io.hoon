::  Native receipt IO; not an app or a migration. Both indices are one
::  append. Only numbered full readback can retire a hot receipt.
/-  pa=cantrip-project-access, j=cantrip-project-suggestion-journal
/+  law=cantrip-project-receipt-archive,
    journal=cantrip-project-suggestion-journal, read=cantrip-project-bundle-read
|%
+$  change  [history=shared-state:law records=journal:j cards=(list card:agent:gall)]
+$  page
  [%cantrip-project-receipt-page-v1 project=@t head=head:law examined=@ud receipts=(list receipt:pa) next=(unit @ta) more=?]
+$  page-v2
  [%cantrip-project-receipt-page-v2 project=@t head=head:law examined=@ud receipts=(list entry:j) next=(unit @ta) more=?]
++  slice
  ::  Walk at most limit entries after an immutable directory cursor. Map
  ::  split/tree traversal avoids materializing the whole permanent index.
  |=  [rows=(map @ta ~) after=(unit @ta) limit=@ud]
  ^-  [names=(list @ta) next=(unit @ta) more=?]
  ?>  &((gth limit 0) (lte limit 8))
  =/  todo=(map @ta ~)  ?~(after rows r:(~(bif by rows) u.after))
  =/  stack=(list (map @ta ~))  ~
  =/  names=(list @ta)  ~
  =/  count=@ud  0
  |-  ^-  [names=(list @ta) next=(unit @ta) more=?]
  ?^  todo  $(stack [todo stack], todo l.todo)
  ?~  stack  [(flop names) ~ %.n]
  =/  node=(map @ta ~)  i.stack
  ?>  ?=(^ node)
  =/  name=@ta  p.n.node
  =/  next-names=(list @ta)  [name names]
  =/  more=?  |(?=(^ r.node) ?=(^ t.stack))
  ?:  =(+(count) limit)  [(flop next-names) ?:(more `name ~) more]
  $(todo r.node, stack t.stack, count +(count), names next-names)
++  page-rows
  ::  Owner inbox rows only; a view still advances the examination cursor.
  |=  [project=@t rows=(list entry:j)]
  ^-  (list receipt:pa)
  %+  murn  rows
  |=  e=entry:j
  ^-  (unit receipt:pa)
  ?.  ?=(%legacy -.e)  ~
  ?.  &(=(project project.request.value.e) ?=(%suggest -.payload.value.e))  ~
  `value.e
++  page-rows-v2
  ::  Version two retains the complete tagged receipt for either submission
  ::  format. Views advance the cursor but are not owner suggestions.
  |=  [project=@t rows=(list entry:j)]
  ^-  (list entry:j)
  %+  skim  rows
  |=  e=entry:j
  =/  key=key:j  (key-for:journal e)
  ?.  =(project project.key)  %.n
  ?-  -.e
    %legacy  ?=(%suggest -.payload.value.e)
    %bundle  %.y
  ==
++  current
  |=  [our=@p at=@da desk=@tas]
  ^-  (unit head:law)
  =/  domes=cone:clay  .^(cone:clay %cx /(scot %p our)//(scot %da at)/domes)
  =/  found  (~(get by domes) [our desk])
  ?~  found  ~
  =/  commit  (~(get by hit.u.found) let.u.found)
  ?~  commit  ~
  =/  h=head:law  [desk let.u.found u.commit]
  ?.  (current-head:read our at h)  ~
  `h
++  configure
  ::  Caller must already possess qualified known history. This arm cannot
  ::  turn a missing legacy history observation into known absence.
  |=  [b=bowl:gall s=shared-state:law desk=@tas]
  ^-  (each shared-state:law @tas)
  ?.  =(our.b src.b)  [%| %receipt-archive-owner-required]
  ?^  head.s
    ?.  =(desk desk.u.head.s)  [%| %receipt-archive-already-configured]
    [%& s]
  ?^  writing.s  [%| %receipt-archive-pending]
  =/  h  (current our.b now.b desk)
  ?~  h  [%| %receipt-archive-head-unavailable]
  =/  prefix=arch  .^(arch %cy (beam:read our.b u.h /project-access-history))
  ?.  &(=(~ fil.prefix) =(~ dir.prefix))  [%| %receipt-archive-prefix-not-empty]
  [%& [h ~]]
++  read-noun
  |=  [our=@p at=@da s=shared-state:law pax=path]
  ^-  raw:law
  ?~  head.s  [%& ~]
  ?.  (current-head:read our at u.head.s)  [%| %receipt-archive-head-unavailable]
  ?.  (private:read our at desk.u.head.s pax)  [%| %receipt-archive-not-private]
  (noun-at:read our u.head.s pax)
++  lookup
  ::  Owner history observation. Peer recovery/admission must ALSO apply the
  ::  existing current-authority law; this lookup does not grant permission.
  |=  [b=bowl:gall s=shared-state:law grants=grants:pa records=journal:j k=key:j]
  ^-  observed:j
  ?.  =(our.b src.b)  [%| %receipt-archive-owner-required]
  (cold:read our.b our.b now.b `s grants records k)
++  lookup-hash
  ::  Owner inbox detail can retrieve exact old bytes by their old hash, but
  ::  a body without its permanent nonce index is an error, never an entry.
  |=  [b=bowl:gall s=shared-state:law grants=grants:pa records=journal:j digest=@ux]
  ^-  observed:j
  ?.  =(our.b src.b)  [%| %receipt-archive-owner-required]
  ?.  (shared-valid:law our.b s grants records)  [%| %receipt-archive-state-invalid]
  ?^  writing.s  [%| %receipt-archive-pending]
  =/  body  (shared-decode:law our.b our.b digest (read-noun our.b now.b s (path-for:law digest)))
  ?:  ?=(%| -.body)  body
  ?~  p.body  body
  =/  joined  (lookup b s grants records (key-for:journal u.p.body))
  ?:  ?=(%| -.joined)  joined
  ?.  =(joined body)  [%| %receipt-archive-index-mismatch]
  body
++  one-with
  ::  Pure boundary for an owner-selected key/hash. Derive the receipt from
  ::  the current hot journal; callers never supply a replacement receipt.
  |=  [b=bowl:gall s=shared-state:law grants=grants:pa records=journal:j k=key:j expected=@ux delivery=delivery:law index=indexed:law body=observed:j]
  ^-  (each change @tas)
  ?.  =(our.b src.b)  [%| %receipt-archive-owner-required]
  =/  held  (lookup:journal records k)
  ?~  held  [%| %receipt-archive-record-missing]
  =/  e=entry:j  u.held
  ::  A view or suggestion is immutable history; archival is not acceptance.
  ?.  =(expected (hash:journal e))  [%| %receipt-archive-record-mismatch]
  =/  started  (shared-begin:law our.b src.b s grants records e delivery index body)
  ?:  ?=(%| -.started)  [%| p.started]
  ?>  ?=(^ head.s)
  =/  h=head:law  u.head.s
  [%& p.started records (write-cards b h e /project-suggestion-archive)]
++  auto-wire
  |=  [h=head:law e=entry:j]
  ^-  wire
  /project-suggestion-archive-auto/(scot %ud +(number.h))/(scot %ux (hash:journal e))
++  write-cards
  |=  [b=bowl:gall h=head:law e=entry:j wire=wire]
  ^-  (list card:agent:gall)
  =/  digest=@ux  (hash:journal e)
  :~  [%pass wire %arvo %c %info desk.h [%& [[(path-for:law digest) %ins %noun !>((raw:journal e))] [(nonce-path:law (key-for:journal e)) %ins %noun !>((shared-pointer:law e))] ~]]]
      [%pass wire %arvo %c %warp our.b desk.h ~ %sing %z [%ud +(number.h)] /]
  ==
++  automatic-cards
  ::  Identical one-write law, distinct revision-fenced callback channel.
  |=  [b=bowl:gall before=shared-state:law moved=change]
  ^-  change
  ?>  ?=(^ head.before)
  ?>  ?=(^ writing.history.moved)
  moved(cards (write-cards b u.head.before u.writing.history.moved (auto-wire u.head.before u.writing.history.moved)))
++  automatic-one-with
  |=  [b=bowl:gall s=shared-state:law grants=grants:pa records=journal:j k=key:j expected=@ux delivery=delivery:law index=indexed:law body=observed:j]
  ^-  (each change @tas)
  =/  got  (one-with b s grants records k expected delivery index body)
  ?:  ?=(%| -.got)  got
  [%& (automatic-cards b s p.got)]
++  automatic-one
  |=  [b=bowl:gall s=shared-state:law grants=grants:pa records=journal:j k=key:j expected=@ux]
  ^-  (each change @tas)
  =/  got  (one b s grants records k expected)
  ?:  ?=(%| -.got)  got
  [%& (automatic-cards b s p.got)]
++  one
  |=  [b=bowl:gall s=shared-state:law grants=grants:pa records=journal:j k=key:j expected=@ux]
  ^-  (each change @tas)
  ?.  =(our.b src.b)  [%| %receipt-archive-owner-required]
  ?.  (shared-valid:law our.b s grants records)  [%| %receipt-archive-state-invalid]
  ?~  head.s  [%| %receipt-archive-unconfigured]
  ?^  writing.s  [%| %receipt-archive-pending]
  =/  index  (decode-pointer:law our.b our.b k (read-noun our.b now.b s (nonce-path:law k)))
  =/  body  (shared-decode:law our.b our.b expected (read-noun our.b now.b s (path-for:law expected)))
  (one-with b s grants records k expected `(shared-delivery-keys:law b) index body)
++  choose
  ::  Shared pressure and ordering cover scalar and bundle receipts together.
  |=  [our=@p src=@p grants=grants:pa records=journal:j delivery=delivery:law]
  ^-  observed:j
  (shared-choose:law our src grants records delivery)
++  advance
  ::  Existing combined48 pressure/hard64 law, at most one append per call.
  |=  [b=bowl:gall s=shared-state:law grants=grants:pa records=journal:j]
  ^-  (each change @tas)
  ?^  writing.s  [%| %receipt-archive-pending]
  =/  chosen  (choose our.b src.b grants records `(shared-delivery-keys:law b))
  ?:  ?=(%| -.chosen)  [%| p.chosen]
  ?~  p.chosen  [%& s records ~]
  (one b s grants records (key-for:journal u.p.chosen) (hash:journal u.p.chosen))
++  confirm
  ::  Current grants and delivery observations are required again. No ACK,
  ::  incomplete index, changed journal, or extra Clay edit can retire a row.
  |=  [b=bowl:gall s=shared-state:law grants=grants:pa records=journal:j after=head:law old=yaki:clay new=yaki:clay got=observed:j delivery=delivery:law]
  ^-  (each change @tas)
  =/  done  (shared-confirm:law our.b src.b s grants records after old new got delivery)
  ?:  ?=(%| -.done)  [%| p.done]
  [%& state.p.done records.p.done ~]
++  observe
  ::  Observation only, including after reload or an unknown write outcome.
  ::  Never append here and never chain from a manual Clay callback.
  |=  [b=bowl:gall s=shared-state:law grants=grants:pa records=journal:j]
  ^-  (each change @tas)
  ?.  =(our.b src.b)  [%| %receipt-archive-owner-required]
  ?.  (shared-valid:law our.b s grants records)  [%| %receipt-archive-state-invalid]
  ?~  writing.s  [%& s records ~]
  ?>  ?=(^ head.s)
  =/  before=head:law  u.head.s
  =/  after  (current our.b now.b desk.before)
  ?~  after  [%| %receipt-archive-head-unavailable]
  =/  got  (lookup b [after ~] grants records (key-for:journal u.writing.s))
  ?:  ?=(%| -.got)  [%| p.got]
  =/  domes=cone:clay  .^(cone:clay %cx /(scot %p our.b)//(scot %da now.b)/domes)
  =/  held  (~(get by domes) [our.b desk.before])
  ?~  held  [%| %receipt-archive-head-unavailable]
  ?.  =(`commit.before (~(get by hit.u.held) number.before))
    [%| %receipt-archive-head-unavailable]
  =/  old=yaki:clay
    .^(yaki:clay %cs /(scot %p our.b)/[desk.before]/(scot %da now.b)/yaki/(scot %uv commit.before))
  =/  new=yaki:clay
    .^(yaki:clay %cs /(scot %p our.b)/[desk.before]/(scot %da now.b)/yaki/(scot %uv commit.u.after))
  (confirm b s grants records u.after old new got `(shared-delivery-keys:law b))
++  page-read
  ::  First revision0/start chooses the owned current head. Every next page
  ::  binds that same revision; a changed head refuses rather than skip rows.
  |=  [b=bowl:gall s=shared-state:law grants=grants:pa records=journal:j project=@t revision=@ud after=@ta limit=@ud]
  ^-  (each page @tas)
  ?.  =(our.b src.b)  [%| %receipt-archive-owner-required]
  ?.  &((gth limit 0) (lte limit 8) (lte (met 3 after) 82))  [%| %receipt-page-invalid]
  ?.  (shared-valid:law our.b s grants records)  [%| %receipt-archive-state-invalid]
  ?^  writing.s  [%| %receipt-archive-pending]
  ?~  head.s  [%| %receipt-archive-unconfigured]
  =/  h=head:law  u.head.s
  ?.  (current-head:read our.b now.b h)  [%| %receipt-archive-head-unavailable]
  ?.  |(&(=(revision 0) =(%start after)) =(revision number.h))
    [%| %receipt-page-head-changed]
  =/  directory=arch  .^(arch %cy (beam:read our.b h /project-access-history/nonces))
  ?:  &(!=(%start after) !(~(has by dir.directory) after))  [%| %receipt-page-cursor-invalid]
  =/  selected  (slice dir.directory ?:(=(%start after) ~ `after) limit)
  =/  todo=(list @ta)  names.selected
  =/  rows=(list entry:j)  ~
  |-  ^-  (each page @tas)
  ?~  todo
    [%& %cantrip-project-receipt-page-v1 project h (lent names.selected) (page-rows project (flop rows)) next.selected more.selected]
  =/  pax=path  /project-access-history/nonces/[i.todo]/noun
  =/  raw  (read-noun our.b now.b s pax)
  ?:  ?=(%| -.raw)  [%| p.raw]
  ?~  p.raw  [%| %receipt-archive-index-missing]
  =/  pointer  ((soft pointer:law) u.p.raw)
  ?~  pointer  [%| %receipt-archive-index-invalid]
  ?.  &(=(u.p.raw u.pointer) =(pax (nonce-path:law key.u.pointer)))
    [%| %receipt-archive-index-invalid]
  =/  got  (lookup b s grants records key.u.pointer)
  ?:  ?=(%| -.got)  [%| p.got]
  ?~  p.got  [%| %receipt-archive-body-unavailable]
  $(todo t.todo, rows [u.p.got rows])
++  page-read-v2
  ::  Same pinned-head and exact index/body checks as v1, with tagged rows.
  |=  [b=bowl:gall s=shared-state:law grants=grants:pa records=journal:j project=@t revision=@ud after=@ta limit=@ud]
  ^-  (each page-v2 @tas)
  ?.  =(our.b src.b)  [%| %receipt-archive-owner-required]
  ?.  &((gth limit 0) (lte limit 8) (lte (met 3 after) 82))  [%| %receipt-page-invalid]
  ?.  (shared-valid:law our.b s grants records)  [%| %receipt-archive-state-invalid]
  ?^  writing.s  [%| %receipt-archive-pending]
  ?~  head.s  [%| %receipt-archive-unconfigured]
  =/  h=head:law  u.head.s
  ?.  (current-head:read our.b now.b h)  [%| %receipt-archive-head-unavailable]
  ?.  |(&(=(revision 0) =(%start after)) =(revision number.h))
    [%| %receipt-page-head-changed]
  =/  directory=arch  .^(arch %cy (beam:read our.b h /project-access-history/nonces))
  ?:  &(!=(%start after) !(~(has by dir.directory) after))  [%| %receipt-page-cursor-invalid]
  =/  selected  (slice dir.directory ?:(=(%start after) ~ `after) limit)
  =/  todo=(list @ta)  names.selected
  =/  rows=(list entry:j)  ~
  |-  ^-  (each page-v2 @tas)
  ?~  todo
    [%& %cantrip-project-receipt-page-v2 project h (lent names.selected) (page-rows-v2 project (flop rows)) next.selected more.selected]
  =/  pax=path  /project-access-history/nonces/[i.todo]/noun
  =/  raw  (read-noun our.b now.b s pax)
  ?:  ?=(%| -.raw)  [%| p.raw]
  ?~  p.raw  [%| %receipt-archive-index-missing]
  =/  pointer  ((soft pointer:law) u.p.raw)
  ?~  pointer  [%| %receipt-archive-index-invalid]
  ?.  &(=(u.p.raw u.pointer) =(pax (nonce-path:law key.u.pointer)))
    [%| %receipt-archive-index-invalid]
  =/  got  (lookup b s grants records key.u.pointer)
  ?:  ?=(%| -.got)  [%| p.got]
  ?~  p.got  [%| %receipt-archive-body-unavailable]
  $(todo t.todo, rows [u.p.got rows])
--
