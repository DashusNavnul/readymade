::  Viki-only prospective observation owner. The complete prior agent, including
::  its independent QPC execution gate, is retained as an opaque saved vase.
/+  obs=qpc-observation, gate=qpc-session-gate, pool=qpc-native-pool,
    evidence=qpc-native-evidence, inference=native-coding-inference,
    sessions=native-coding-session, outcomes=qpc-outcome-store,
    adjudication=qpc-native-outcome, settlement=qpc-work-settlement,
    automatic=qpc-auto-settlement
|%
++  input
  |=  [inner=agent:gall b=bowl:gall id=@ux]
  ^-  (unit input:pool)
  =/  ag  ~(. inner b(src our.b))
  =/  raw  (payload:gate (on-peek:ag /x/native-coding/qpc-input/(scot %ux id)))
  ?~  raw  ~
  =/  parsed  ((soft ,(unit input:pool)) u.raw)
  ?~(parsed ~ u.parsed)
++  agent
  |=  inner=agent:gall
  =|  held=state:obs
  =|  results=state:outcomes
  =|  settled=state:settlement
  ^-  agent:gall
  |_  =bowl:gall
  +*  this  .
      ag  ~(. inner bowl)
  ++  on-init
    =^  cards  inner  on-init:ag
    [cards this]
  ++  on-save  !>([%qpc-observer-v3 held results settled on-save:ag])
  ++  on-load
    |=  old=vase
    =/  saved=[held=state:obs results=state:outcomes settled=state:settlement inner=vase]
      ?:  ?=([%qpc-observer-v3 *] q.old)
        =/  prior  !<([%qpc-observer-v3 held=state:obs results=state:outcomes settled=state:settlement inner=vase] old)
        +.prior
      ?:  ?=([%qpc-observer-v2 *] q.old)
        =/  prior  !<([%qpc-observer-v2 held=state:obs results=state:outcomes inner=vase] old)
        [held.prior results.prior *state:settlement inner.prior]
      ?.  ?=([%qpc-observer-v1 *] q.old)  [*state:obs *state:outcomes *state:settlement old]
      =/  prior  !<([%qpc-observer-v1 held=state:obs inner=vase] old)
      [held.prior *state:outcomes *state:settlement inner.prior]
    ?>  (valid:obs our.bowl held.saved)
    ?>  (valid:outcomes held.saved results.saved)
    ?>  (valid:settlement held.saved results.saved settled.saved)
    =.  held  held.saved
    =.  results  results.saved
    =.  settled  settled.saved
    =^  cards  inner  (on-load:ag inner.saved)
    [cards this]
  ++  on-poke
    |=  [=mark =vase]
    ?:  &(=(%noun mark) ?=([%qpc-observe-settle-v1 @] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  id=@ux  `@ux`+.q.vase
      ?:  (~(has by settled) id)  [~ this]
      =/  f=frame:obs  (~(got by frames.held) id)
      ~|  %qpc-settlement-selection-required
      ?>  ?=(%& -.result.f)
      ?>  =(1 (lent p.result.f))
      =/  row  (snag 0 p.result.f)
      =/  v=linked:adjudication  (~(got by outcomes.results) [id call.row])
      =/  m=manifest:obs  (~(got by manifests.held) manifest.work.f)
      =/  cs=cases:adjudication  (~(got by cases.results) case-set.work.f)
      ::  A missing/unreadable execution gate cannot mean ordinary authority.
      =/  raw  (payload:gate (on-peek:ag /x/qpc/required-sessions))
      ?>  ?=(^ raw)
      =/  required  ((soft ,[%qpc-session-gate-v1 %viki ids=(set @ux)]) u.raw)
      ?>  ?=(^ required)
      =/  got  (read:settlement bowl ids.u.required m f cs v)
      ?:  ?=(%| -.got)
        ~|  p.got
        !!
      =/  next  (retain:settlement held results settled p.got)
      ?:  ?=(%| -.next)
        ~|  p.next
        !!
      :_  this(settled p.next)
      ~[[%pass /qpc/settlement/(scot %ux id) %agent [our.bowl %graf] %poke %graf-action !>([%attest p.got])]]
    ?:  &(=(%noun mark) ?=([%qpc-observe-cases-v1 *] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  command  !<([%qpc-observe-cases-v1 cases=cases:adjudication] vase)
      =/  next  (register:outcomes results cases.command)
      ?:  ?=(%| -.next)
        ~|  p.next
        !!
      [~ this(results p.next)]
    ?:  &(=(%noun mark) ?=([%qpc-observe-adjudicate-v1 *] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  command  !<([%qpc-observe-adjudicate-v1 frame=@ux call=@t] vase)
      ::  First check outcome is immutable; retries do not replace evidence
      ::  with a later acceptance stage or issue another Graf attestation.
      ?:  (~(has by outcomes.results) [frame.command call.command])  [~ this]
      =/  f=frame:obs  (~(got by frames.held) frame.command)
      =/  m=manifest:obs  (~(got by manifests.held) manifest.work.f)
      =/  cs=cases:adjudication  (~(got by cases.results) case-set.work.f)
      =/  snapshot  (input inner bowl session.work.f)
      ~|  %qpc-observation-session-unavailable
      ?>  ?=(^ snapshot)
      =/  linked  (read:outcomes bowl u.snapshot m f cs call.command)
      ?:  ?=(%| -.linked)
        ~|  p.linked
        !!
      =/  next  (retain:outcomes held results p.linked)
      ?:  ?=(%| -.next)
        ~|  p.next
        !!
      =/  id=@ux  (digest:adjudication p.linked)
      :_  this(results p.next)
      ~[[%pass /qpc/outcome/(scot %ux id) %agent [our.bowl %graf] %poke %graf-action !>([%attest p.linked])]]
    ?:  &(=(%noun mark) ?=([%qpc-observe-arm-v1 *] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  command  !<([%qpc-observe-arm-v1 manifest=manifest:obs work=work:obs] vase)
      =/  snapshot  (input inner bowl session.work.command)
      ~|  %qpc-observation-session-unavailable
      ?>  ?=(^ snapshot)
      =/  next  (enroll:obs our.bowl held manifest.command work.command entry.u.snapshot)
      ?:  ?=(%| -.next)
        ~|  p.next
        !!
      [~ this(held p.next)]
    ?:  &(=(%noun mark) ?=([%qpc-observe-disarm-v1 @] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  id=@ux  `@ux`+.q.vase
      =/  found  (~(get by arms.held) id)
      ?~  found  [~ this]
      =/  a=armed:obs  u.found
      =.  a  a(active %.n, segment (digest:obs [%disarmed a now.bowl]))
      [~ this(arms.held (~(put by arms.held) id a))]
    =/  event=(unit event:inference)
      ?.(=(%noun mark) ~ ((soft event:inference) q.vase))
    =/  observed=state:obs
      ?~  event  held
      ?.  =(our.bowl src.bowl)  held
      =/  found  (~(get by arms.held) session.u.event)
      ?~  found  held
      =/  a=armed:obs  u.found
      ?.  &(active.a =(request.work.a id.u.event))  held
      =/  snapshot  (input inner bowl session.u.event)
      ?~  snapshot  held
      =/  e=entry:sessions  entry.u.snapshot
      =/  pending  pending.e
      ?~  pending  held
      ?.  =(id.u.event id.u.pending)  held
      ?.  ?=(%result -.outcome.u.event)
        ?.  ?=(?(%failed %cancelled %refused) -.outcome.u.event)  held
        ::  Terminal owner events retain a gap, never an authenticated reading.
        =/  gap  (retain:obs our.bowl now.bowl held a sequence.e 0x0 0x0 [%| %qpc-observation-no-provider-report])
        -.gap
      =/  issue  (confirm:evidence our.bowl now.bowl u.pending key.u.snapshot value.outcome.u.event)
      ::  An unauthenticated reply cannot become an observation or run tools.
      ~|  [%qpc-observation-provider-unconfirmed issue]
      ?>  ?=(~ issue)
      =/  checked  (model:sessions now.bowl e(phase %paused) value.outcome.u.event)
      ?:  ?=(%| -.checked)  held
      =/  captured  (capture:obs our.bowl now.bowl held a e value.outcome.u.event)
      -.captured
    ::  Capture is part of this atomic saved transition, before any returned
    ::  inner tool cards can run. No self-poke pretends to establish ordering.
    =/  fresh=(list frame:obs)
      (skim ~(val by frames.observed) |=(f=frame:obs !(~(has by frames.held) id.f)))
    =/  retained=(list card:agent:gall)
      %+  turn  fresh
      |=  f=frame:obs
      [%pass /qpc/observation/(scot %ux id.f) %agent [our.bowl %graf] %poke %graf-action !>([%attest [%qpc-observation-frame-v1 f]])]
    =.  held  observed
    =^  cards  inner  (on-poke:ag mark vase)
    =/  target  (trigger:automatic our.bowl src.bowl mark vase)
    ?~  target  [(weld retained cards) this]
    =/  snapshot  (input inner bowl u.target)
    ?~  snapshot  [(weld retained cards) this]
    =/  current  ~(. inner bowl)
    =/  raw  (payload:gate (on-peek:current /x/qpc/required-sessions))
    =/  required
      ?~  raw  ~
      ((soft ,[%qpc-session-gate-v1 %viki ids=(set @ux)]) u.raw)
    ?~  required  [(weld retained cards) this]
    =/  completed
      (finish:automatic bowl u.snapshot held results settled ids.u.required read:outcomes read:settlement)
    =.  results  checked.completed
    =.  settled  settled.completed
    =/  attestations=(list card:agent:gall)
      %+  turn  facts.completed
      |=  fact=*
      [%pass /qpc/automatic/(scot %ux (shax (jam fact))) %agent [our.bowl %graf] %poke %graf-action !>([%attest fact])]
    =/  notices=(list card:agent:gall)
      ?~  reason.completed  ~
      ~[[%give %fact ~[/native-coding] %noun !>([%qpc-auto-settlement-status-v1 u.target u.reason.completed])]]
    [(weld attestations (weld notices (weld retained cards))) this]
  ++  on-watch
    |=  =path
    =^  cards  inner  (on-watch:ag path)
    [cards this]
  ++  on-leave
    |=  =path
    =^  cards  inner  (on-leave:ag path)
    [cards this]
  ++  on-peek
    |=  =path
    ?:  =(/x/qpc/settlements path)
      ?.  =(our.bowl src.bowl)  ~
      ``noun+!>(settled)
    ?:  =(/x/qpc/outcome-state path)
      ?.  =(our.bowl src.bowl)  ~
      ``noun+!>(results)
    ?:  ?=([%x %qpc %outcomes @ ~] path)
      ?.  =(our.bowl src.bowl)  ~
      =/  id  (slaw %ux i.t.t.t.path)
      ?~  id  [~ ~]
      ``noun+!>((skim ~(val by outcomes.results) |=(v=linked:adjudication =(u.id frame.v))))
    ?:  ?=([%x %qpc %cases @ ~] path)
      ?.  =(our.bowl src.bowl)  ~
      =/  id  (slaw %ux i.t.t.t.path)
      ?~  id  [~ ~]
      ``noun+!>((~(get by cases.results) u.id))
    ?:  =(/x/qpc/observations path)
      ?.  =(our.bowl src.bowl)  ~
      ``noun+!>(held)
    ?:  ?=([%x %qpc %observation-plan @ ~] path)
      ?.  =(our.bowl src.bowl)  ~
      =/  id  (slaw %ux i.t.t.t.path)
      =/  plan=(unit [manifest=manifest:obs armed=armed:obs])
        ?~  id  ~
        =/  a  (~(get by arms.held) u.id)
        ?~  a  ~
        ?.  active.u.a  ~
        `[(~(got by manifests.held) manifest.work.u.a) u.a]
      ``noun+!>(plan)
    (on-peek:ag path)
  ++  on-agent
    |=  [=wire =sign:agent:gall]
    =^  cards  inner  (on-agent:ag wire sign)
    [cards this]
  ++  on-arvo
    |=  [=wire =sign-arvo]
    =^  cards  inner  (on-arvo:ag wire sign-arvo)
    [cards this]
  ++  on-fail
    |=  [=term =tang]
    =^  cards  inner  (on-fail:ag term tang)
    [cards this]
  --
--
