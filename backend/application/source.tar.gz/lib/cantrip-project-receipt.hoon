::  Read-only recovery of an existing suggestion. A missing record is unknown,
::  never a command to replay. Current grant/member/law admission still applies.
/-  pa=cantrip-project-access, view=cantrip-project-view
/+  runtime=cantrip-project-access-runtime, core=cantrip-project-access,
    law=cantrip-law-window
|%
++  route
  |=  [peer=@p q=query:view]
  ^-  path
  /project-receipt/(scot %ux project.q)/(scot %p peer)/(scot %ud generation.q)/(scot %ux nonce.q)
++  parse
  |=  pax=path
  ^-  (unit [peer=@p query=query:view])
  ?.  ?=([%project-receipt *] pax)  ~
  (view-parse:runtime pax(i %project-view))
++  lookup
  ::  Only an already admitted caller supplies current grant digest here.
  |=  [our=@p peer=@p q=query:view grant=@ux records=records:pa]
  ^-  (unit receipt:pa)
  =/  found  (~(get by records) [project.q peer generation.q nonce.q])
  ?~  found  ~
  =/  r=receipt:pa  u.found
  ?.  ?&  (receipt-valid:runtime r)  =(our owner.r)  =(peer peer.r)
          =(grant grant.r)  =(%suggest action.request.r)
          =(q [project.request.r generation.request.r nonce.request.r])
      ==  ~
  found
++  cards
  |=  [pax=path found=(unit receipt:pa)]
  ^-  (list card:agent:gall)
  =/  close=card:agent:gall  [%give %kick ~[pax] ~]
  ?~  found  ~[close]
  :~  [%give %fact ~[pax] %noun !>(`event:pa`[%cantrip-project-receipt-v1 u.found])]
      close
  ==
++  watch
  |=  [b=bowl:gall grants=grants:pa records=records:pa pax=path w=window:law]
  ^-  (each (list card:agent:gall) @tas)
  =/  parsed  (parse pax)
  ?~  parsed  [%| %path-invalid]
  ?.  =(src.b peer.u.parsed)  [%| %foreign-peer]
  =/  q=query:view  query.u.parsed
  =/  request=request:pa  [project.q generation.q nonce.q %suggest ~ ~ `@t`0]
  =/  admitted  (admit-watch:runtime b grants request w)
  ?:  ?=(%| -.admitted)  [%| p.admitted]
  [%& (cards pax (lookup our.b src.b q (digest:core p.admitted) records))]
--
