::  Browser command journal. Runtime receipts, never poke ACKs, settle outcomes.
/+  mg=readymade-app-management
|%
+$  action
  $%  [%invite-member project=@t target=@p role=?(%maintainer %contributor %observer %model) expires-at=@da nonce=@ux]
      [%join project=@t invitation=@ux]
      [%decline-invitation project=@t invitation=@ux]
      [%revoke-invitation project=@t invitation=@ux]
      [%expire-invitation project=@t invitation=@ux]
  ==
+$  code  ?(%project-invited %project-joined %invitation-declined %invitation-revoked %invitation-expired)
+$  receipt
  $%  [%accepted action-digest=@ux code=code ruling=~]
      [%refused action-digest=@ux reason=*]
  ==
+$  receipt-event  $%([%ready ~] [%receipt value=receipt])
+$  command  [request=@t authority=@p action=action]
+$  record
  [command=command digest=@ux status=?(%prepared %submitted %unknown %accepted %refused) outcome=(unit receipt)]
+$  journal  (map @t record)
+$  decision  [journal=journal dispatch=? reason=@tas]
++  valid
  |=  c=command
  ^-  ?
  ?&  (uuid:mg request.c)
      (gte (met 3 project.action.c) 1)
      (lte (met 3 project.action.c) 128)
      ?:  ?=(%invite-member -.action.c)
        &((gth nonce.action.c 0) (lte (met 0 nonce.action.c) 256))
      &((gth invitation.action.c 0) (lte (met 0 invitation.action.c) 256))
  ==
++  reserve
  |=  [j=journal c=command]
  ^-  decision
  ?.  (valid c)  [j %.n %invalid-command]
  =/  old  (~(get by j) request.c)
  ?^  old
    [j %.n ?:(=(c command.u.old) %retained %request-conflict)]
  =/  digest=@ux  (shax (jam action.c))
  ::  Changing the browser request ID must not resend an identical command.
  ?:  %+  lien  ~(tap by j)
      |=  item=[key=@t value=record]
      &(=(authority.c authority.command.value.item) =(digest digest.value.item))
    [j %.n %action-retained]
  ?:  (gte ~(wyt by j) 512)  [j %.n %journal-full]
  ::  Reserve before subscribing. A later authenticated ready event may send.
  [(~(put by j) request.c [c digest %prepared ~]) %.y %watch-once]
++  start
  |=  [j=journal request=@t source=@p]
  ^-  decision
  =/  old  (~(get by j) request)
  ?~  old  [j %.n %missing]
  ?.  =(source authority.command.u.old)  [j %.n %wrong-authority]
  ?.  =(%prepared status.u.old)  [j %.n %retained]
  [(~(put by j) request u.old(status %submitted)) %.y %submit-once]
++  uncertain
  |=  [j=journal request=@t]
  ^-  journal
  =/  old  (~(get by j) request)
  ?~  old  j
  ?.  ?=(?(%prepared %submitted) status.u.old)  j
  (~(put by j) request u.old(status %unknown))
++  settle
  |=  [j=journal request=@t source=@p receipt=receipt]
  ^-  journal
  =/  old  (~(get by j) request)
  ?~  old  j
  ?.  =(source authority.command.u.old)  j
  ?.  =(digest.u.old action-digest.receipt)  j
  ?^  outcome.u.old  j
  ?:  ?=(%accepted -.receipt)
    =/  expected=code
      ?-  -.action.command.u.old
        %invite-member       %project-invited
        %join                %project-joined
        %decline-invitation  %invitation-declined
        %revoke-invitation   %invitation-revoked
        %expire-invitation   %invitation-expired
      ==
    ?.  =(expected code.receipt)  j
    (~(put by j) request u.old(status %accepted, outcome `receipt))
  (~(put by j) request u.old(status %refused, outcome `receipt))
++  restore
  ::  Preserve valid saved journals exactly; never repair by dropping requests.
  |=  raw=*
  ^-  (unit journal)
  =/  parsed  ((soft ,journal) raw)
  ?~  parsed  ~
  =/  j=journal  u.parsed
  ?.  &(=(raw j) (lte ~(wyt by j) 512))  ~
  =/  rows=(list [key=@t value=record])  ~(tap by j)
  ?.  =(j (~(gas by *journal) rows))  ~
  =|  seen=(set [@p @ux])
  |-  ^-  (unit journal)
  ?~  rows  `j
  =/  r=record  value.i.rows
  ?.  &((valid command.r) =(key.i.rows request.command.r))  ~
  ?.  =(digest.r (shax (jam action.command.r)))  ~
  =/  identity=[@p @ux]  [authority.command.r digest.r]
  ?:  (~(has in seen) identity)  ~
  =/  consistent=?
    ?~  outcome.r
      ?=(?(%prepared %submitted %unknown) status.r)
    =/  base=journal  (~(put by *journal) key.i.rows r(status %unknown, outcome ~))
    =/  settled  (settle base key.i.rows authority.command.r u.outcome.r)
    =(r (~(got by settled) key.i.rows))
  ?.  consistent  ~
  $(rows t.rows, seen (~(put in seen) identity))
--
