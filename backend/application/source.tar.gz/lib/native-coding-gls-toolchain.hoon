::  Explicit owner trust for an exact compiler used in candidate checks.
::  Byte/source association alone never activates this policy. Compiler trust
::  is an operational assumption, not a proof of source equivalence.
/-  nc=native-coding
/+  check=native-coding-gls-check, attachment=native-coding-compiler-attachment,
    attachments=native-coding-compiler-attachment-runtime,
    accept=native-coding-accept, tools=cantrip-native-coding,
    project=native-coding-project, law=cantrip-law-window, guard=viki-scry-guard
|%
+$  key  [configuration=@ux target=@tas]
+$  choice  [value=trust:check revoked=?]
+$  authorization  [trust=trust:check compiler=attachment:attachment]
+$  organ
  [%native-coding-gls-toolchain-state-v1 trusts=(map key choice) receipts=(map [candidate=@ux target=@tas] receipt:check)]
+$  command
  $%  [%native-coding-gls-toolchain-trust-v1 value=trust:check]
      [%native-coding-gls-toolchain-revoke-v1 configuration=@ux target=@tas]
  ==
+$  envelope
  [%native-coding-gls-candidate-report-v1 report=report:accept receipts=(list receipt:check)]
+$  change  [state=organ candidates=ledger:accept cards=(list card:agent:gall)]
++  empty  `organ`[%native-coding-gls-toolchain-state-v1 ~ ~]
++  byte-limit  134.217.728
++  bounded
  |=  s=organ
  ^-  ?
  &((lte ~(wyt by trusts.s) 32) (lte ~(wyt by receipts.s) 128) (lte (met 3 (jam s)) byte-limit))
++  key-for
  |=  t=trust:check
  ^-  key
  [(configuration:project project.selection.t) name.target.selection.t]
++  associated
  ::  Historical association survives revocation; lookup checks current use.
  |=  [our=@p a=organ:attachments t=trust:check]
  ^-  (each authorization @tas)
  =/  compiler  (~(get by attachments.a) attachment.t)
  ?~  compiler  [%| %gls-toolchain-compiler-missing]
  ?.  (trust-valid:check our t u.compiler)  [%| %gls-toolchain-trust-invalid]
  =/  selected  (~(get by choices.a) (key-for t))
  ?~  selected  [%| %gls-toolchain-selection-missing]
  ?.  &(=(selection.t selection.u.selected) =(attachment.t attachment.u.selected))
    [%| %gls-toolchain-selection-mismatch]
  [%& [t u.compiler]]
++  lookup
  |=  [our=@p s=organ a=organ:attachments k=key]
  ^-  (each authorization @tas)
  =/  selected  (~(get by trusts.s) k)
  ?~  selected  [%| %gls-toolchain-trust-required]
  ?:  revoked.u.selected  [%| %gls-toolchain-trust-revoked]
  =/  auth  (associated our a value.u.selected)
  ?:  ?=(%| -.auth)  auth
  =/  chosen  (~(get by choices.a) k)
  ?~  chosen  [%| %gls-toolchain-selection-missing]
  ?.  enabled.u.chosen  [%| %gls-toolchain-selection-revoked]
  ?:  (~(has in revoked.a) attachment.value.u.selected)
    [%| %gls-toolchain-compiler-revoked]
  auth
++  act
  |=  [b=bowl:gall s=organ a=organ:attachments c=command]
  ^-  (each organ @tas)
  ?.  =(our.b src.b)  [%| %gls-toolchain-owner-required]
  ?:  ?=(%native-coding-gls-toolchain-revoke-v1 -.c)
    =/  k=key  [configuration.c target.c]
    =/  prior  (~(get by trusts.s) k)
    ?~  prior  [%| %gls-toolchain-trust-missing]
    [%& s(trusts (~(put by trusts.s) k u.prior(revoked %.y)))]
  =/  auth  (associated our.b a value.c)
  ?:  ?=(%| -.auth)  [%| p.auth]
  =/  k=key  (key-for value.c)
  =/  prior  (~(get by trusts.s) k)
  ?^  prior
    ?:  &(=(value.u.prior value.c) !revoked.u.prior)  [%& s]
    [%| %gls-toolchain-trust-immutable]
  =/  next=organ  s(trusts (~(put by trusts.s) k [value.c %.n]))
  ?.  (bounded next)  [%| %gls-toolchain-capacity]
  =/  enabled  (lookup our.b next a k)
  ?:  ?=(%| -.enabled)  [%| p.enabled]
  [%& next]
++  target-receipt
  |=  [s=organ id=@ux t=target-result:accept]
  ^-  (unit receipt:check)
  =/  found  (~(get by receipts.s) [id name.target.t])
  ?~  found  ~
  ?.  &(=(id id.candidate.input.u.found) (receipt-valid:check u.found) =(t (target-result:check u.found)))  ~
  found
++  report-current
  |=  [our=@p now=@da s=organ a=organ:attachments jobs=organ:tools r=record:accept]
  ^-  ?
  ?~  report.r  %.n
  =/  permission  (candidate-permission:tools our now jobs r)
  ?.  ?=(%& -.permission)  %.n
  =/  grant  (~(get by grants.jobs) grant.r)
  ?~  grant  %.n
  =/  per-target=@ud
    (max 1 (div max-eval-work.grant.u.grant (max 1 (lent (required:accept project.r candidate.r)))))
  %+  levy  targets.u.report.r
  |=  t=target-result:accept
  ?:  =(%hoon kind.target.t)  %.y
  =/  found  (target-receipt s id.candidate.r t)
  ?~  found  %.n
  =/  auth  (lookup our s a (key-for trust.input.u.found))
  ?.  ?=(%& -.auth)  %.n
  =/  prepared
    (prepare:check our now r trust.p.auth compiler.p.auth u.grant per-target)
  &(?=(%& -.prepared) =(input.u.found p.prepared))
++  candidate-act
  |=  [b=bowl:gall s=organ a=organ:attachments jobs=organ:tools held=ledger:accept c=command:accept window=window:law]
  ^-  change:accept
  ?:  ?=(%native-coding-decide-v1 -.c)
    =/  found  (~(get by held) candidate.c)
    ?~  found  (candidate-act:tools b jobs held c window)
    =/  r=record:accept  u.found
    ?.  &(=(%review stage.r) ?=(^ report.r) (lien targets.u.report.r |=(t=target-result:accept =(%gallowglass kind.target.t))))
      (candidate-act:tools b jobs held c window)
    ?.  &(=(our.b src.b) (agent-live:guard our.b now.b %viki))
      (candidate-act:tools b jobs held c window)
    =/  decision=(unit decision:accept)
      .^((unit decision:accept) %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/decision/(scot %ux candidate.c)/noun)
    ?^  decision
      ?:  &(=(%approve verdict.u.decision) !(report-current our.b now.b s a jobs r))
        (put:accept our.b held r(stage %refused, reason `%gls-toolchain-current-proof-required) ~)
      (candidate-act:tools b jobs held c window)
    (candidate-act:tools b jobs held c window)
  (candidate-act:tools b jobs held c window)
++  row-valid
  ::  Restore retained facts, never run a compiler or check on reload.
  |=  [our=@p s=organ a=organ:attachments held=ledger:accept jobs=organ:tools k=[candidate=@ux target=@tas] value=receipt:check]
  ^-  ?
  ?.  &((receipt-valid:check value) =(candidate.k id.candidate.input.value) =(target.k name.target.job.input.value))  %.n
  =/  found  (~(get by held) candidate.k)
  ?~  found  %.n
  =/  r=record:accept  u.found
  ?.  &(=(candidate.r candidate.input.value) =(`staging.input.value staging.r) =(project.r project.selection.trust.input.value))  %.n
  =/  grant  (~(get by grants.jobs) grant.r)
  ?~  grant  %.n
  ?.  =(scope.input.value u.grant(revoked ~))  %.n
  =/  chosen  (~(get by trusts.s) (key-for trust.input.value))
  ?~  chosen  %.n
  ?.  =(value.u.chosen trust.input.value)  %.n
  =/  auth  (associated our a trust.input.value)
  ?.  &(?=(%& -.auth) =(compiler.p.auth compiler.input.value))  %.n
  ?~  report.r  %.n
  =/  matching=(list target-result:accept)
    (skim targets.u.report.r |=(t=target-result:accept =(target.k name.target.t)))
  =([(target-result:check value) ~] matching)
++  valid
  |=  [our=@p s=organ a=organ:attachments held=ledger:accept jobs=organ:tools]
  ^-  ?
  ?.  (bounded s)  %.n
  ?.  (levy ~(tap by trusts.s) |=([k=key c=choice] &(=(k (key-for value.c)) =(%& -:(associated our a value.c)))))  %.n
  ?.  (levy ~(tap by receipts.s) |=([k=[candidate=@ux target=@tas] r=receipt:check] (row-valid our s a held jobs k r)))  %.n
  ::  Historical false GLS reports predate this protocol. Positive reports
  ::  require an exact retained native receipt, regardless of later revocation.
  %+  levy  ~(tap by held)
  |=  [id=@ux r=record:accept]
  ?~  report.r  %.y
  %+  levy  targets.u.report.r
  |=  t=target-result:accept
  ?:  |(=(%hoon kind.target.t) !(lien diagnostics.t |=(d=diagnostic:nc passed.d)))  %.y
  ?=(^ (target-receipt s id t))
++  accept-envelope
  |=  [b=bowl:gall s=organ a=organ:attachments held=ledger:accept jobs=organ:tools id=@ux r=record:accept incoming=envelope]
  ^-  (each organ @tas)
  =/  permission  (candidate-permission:tools our.b now.b jobs r)
  ?:  ?=(%| -.permission)  [%| p.permission]
  ?.  &((report-valid:accept project.r candidate.r report.incoming) =(`staging.report.incoming staging.r))  [%| %gls-candidate-report-mismatch]
  ?.  (levy receipts.incoming receipt-valid:check)
    [%| %gls-candidate-receipt-invalid]
  =/  expected=(list target-result:accept)
    (skim targets.report.incoming |=(t=target-result:accept =(%gallowglass kind.target.t)))
  ?.  &((gte (lent expected) 1) =(expected (turn receipts.incoming target-result:check)))
    [%| %gls-candidate-receipt-targets-mismatch]
  =/  grant  (~(get by grants.jobs) grant.r)
  ?~  grant  [%| %gls-candidate-grant-missing]
  =/  per-target=@ud
    (max 1 (div max-eval-work.grant.u.grant (max 1 (lent (required:accept project.r candidate.r)))))
  =/  todo=(list receipt:check)  receipts.incoming
  |-  ^-  (each organ @tas)
  ?~  todo  [%& s]
  =/  receipt=receipt:check  i.todo
  ?.  (receipt-valid:check receipt)  [%| %gls-candidate-receipt-invalid]
  =/  auth  (lookup our.b s a (key-for trust.input.receipt))
  ?:  ?=(%| -.auth)  [%| p.auth]
  =/  prepared
    (prepare:check our.b now.b r trust.p.auth compiler.p.auth u.grant per-target)
  ?.  &(?=(%& -.prepared) =(input.receipt p.prepared))
    [%| %gls-candidate-input-changed]
  =/  k=[candidate=@ux target=@tas]  [id name.target.job.input.receipt]
  =/  previous  (~(get by receipts.s) k)
  ?:  &(?=(^ previous) !=(u.previous receipt))  [%| %gls-candidate-receipt-conflict]
  =/  next=organ  s(receipts (~(put by receipts.s) k receipt))
  ?.  (bounded next)  [%| %gls-toolchain-capacity]
  $(s next, todo t.todo)
++  arvo
  ::  Only the exact outstanding native candidate Khan callback may retain
  ::  execution receipts. No owner/model command accepts a receipt payload.
  |=  [b=bowl:gall s=organ a=organ:attachments jobs=organ:tools held=ledger:accept w=wire sign=sign-arvo window=window:law]
  ^-  change
  =/  fallback
    |.
    =/  next  (candidate-arvo:tools b jobs held w sign window)
    [s next.next cards.next]
  ?.  &(=(our.b src.b) ?=([%native-candidate @ %checks ~] w) ?=([%khan %arow *] sign))  $:fallback
  =/  parsed  (slaw %ux i.t.w)
  ?~  parsed  $:fallback
  =/  id=@ux  u.parsed
  ?.  =(w (wire-for:accept id %checks))  $:fallback
  =/  found  (~(get by held) id)
  ?~  found  $:fallback
  =/  r=record:accept  u.found
  ?.  &(=(%checking stage.r) =(~ reason.r) ?=(%& -.p.sign))  $:fallback
  =/  refuse
    |=  reason=@tas
    ^-  change
    =/  next  (put:accept our.b held r(stage %unknown, reason `reason) ~)
    [s next.next cards.next]
  =/  raw=*  q.q.p.p.sign
  ?.  (lte (met 3 (jam raw)) byte-limit)  (refuse %gls-candidate-envelope-too-large)
  =/  incoming  ((soft (each envelope @tas)) raw)
  ?~  incoming
    ::  Preserve old refusal/Hoon results; do not admit a positive GLS report
    ::  through the older report-only wire format.
    =/  old  ((soft (each report:accept @tas)) raw)
    ?~  old  $:fallback
    ?.  &(?=(%& -.u.old) =(u.old raw))  $:fallback
    ?:  (lien targets.p.u.old |=(t=target-result:accept &(=(%gallowglass kind.target.t) (lien diagnostics.t |=(d=diagnostic:nc passed.d)))))
      (refuse %gls-candidate-receipt-required)
    $:fallback
  ?.  &(=(u.incoming raw) ?=(%& -.u.incoming))  $:fallback
  =/  retained  (accept-envelope b s a held jobs id r p.u.incoming)
  ?:  ?=(%| -.retained)  (refuse p.retained)
  =/  next  (checked:accept our.b held id report.p.u.incoming)
  [p.retained next.next cards.next]
--
