::  Durable compilation selection for the workspace's native job coordinator.
::  A missing result never authorizes another submission.
/+  cc=cantrip-vibecoding-compile, read=cantrip-vibecoding-compile-read,
    protocol=vibecoding-compile-protocol
|%
+$  command  $%([%run candidate=@ux] [%observe candidate=@ux])
+$  outcome
  $%  [%compiled candidate=@ux review=@ux write=@ux request=@ux compilation=@ux]
      [%absent candidate=@ux]
      [%unknown candidate=@ux reason=@tas]
      [%refused candidate=@ux reason=@tas]
  ==
++  binding
  |=  [our=@p rows=(list *)]
  ^-  (each binding:cc @tas)
  =/  all=(list *)  rows
  =|  found=(unit binding:cc)
  |-  ^-  (each binding:cc @tas)
  ?~  rows  ?~(found [%| %binding-missing] [%& u.found])
  ?.  ?=([%vibecoding-compiler-binding *] i.rows)  $(rows t.rows)
  =/  row  ((soft ,[%vibecoding-compiler-binding key=@t item=binding:cc]) i.rows)
  ?~  row  [%| %binding-invalid]
  =/  checked  (binding:read our all (digest:protocol item.u.row))
  ?:  ?=(%| -.checked)  [%| p.checked]
  ?^  found  [%| %binding-conflict]
  $(rows t.rows, found `p.checked)
++  request
  ::  Select by candidate, so changing compiler bindings cannot hide a run.
  |=  [our=@p candidate=@ux rows=(list *)]
  ^-  (each (unit snapshot:cc) @tas)
  =/  all=(list *)  rows
  =|  found=(unit snapshot:cc)
  |-  ^-  (each (unit snapshot:cc) @tas)
  ?~  rows  [%& found]
  ?.  ?=([%vibecoding-compile-request *] i.rows)  $(rows t.rows)
  =/  row  ((soft ,[%vibecoding-compile-request key=@t item=snapshot:cc]) i.rows)
  ?~  row  [%| %request-invalid]
  =/  s=snapshot:cc  item.u.row
  ?.  =(candidate candidate.s)  $(rows t.rows)
  ?.  =(our owner.order.s)  [%| %request-owner-mismatch]
  =/  checked  (request:read all (digest:protocol order.s))
  ?.  =(`s checked)  [%| %request-invalid]
  ?^  found  [%| %request-conflict]
  $(rows t.rows, found `s)
++  record
  |=  [s=snapshot:cc rows=(list *)]
  ^-  (each (unit record:cc) @tas)
  ?.  (valid:cc s)  [%| %request-invalid]
  =/  all=(list *)  rows
  =|  found=(unit record:cc)
  |-  ^-  (each (unit record:cc) @tas)
  ?~  rows  [%& found]
  ?.  ?=([%vibecoding-compilation *] i.rows)  $(rows t.rows)
  =/  row  ((soft ,[%vibecoding-compilation key=@t item=record:cc]) i.rows)
  ?~  row  [%| %compilation-invalid]
  =/  r=record:cc  item.u.row
  ?.  =((digest:protocol order.s) (digest:protocol order.snapshot.r))
    $(rows t.rows)
  ?.  =(s snapshot.r)  [%| %compilation-snapshot-mismatch]
  =/  checked  (compilation:read all (digest:protocol r))
  ?.  =(`r checked)  [%| %compilation-invalid]
  ?^  found
    ?.  =(artifact.u.found artifact.r)  [%| %compilation-conflict]
    ::  Concurrent observers may attest the identical artifact at different
    ::  parent times. Keep the first valid receipt without changing its data.
    $(rows t.rows, found `?:((lte received.u.found received.r) u.found r))
  $(rows t.rows, found `r)
++  observed
  |=  [our=@p at=@da candidate=@ux rows=(list *)]
  ^-  outcome
  =/  held  (request our candidate rows)
  ?:  ?=(%| -.held)  [%unknown candidate p.held]
  ?~  p.held  [%absent candidate]
  =/  s=snapshot:cc  u.p.held
  =/  retained  (record s rows)
  ?:  ?=(%| -.retained)  [%unknown candidate p.retained]
  ?~  p.retained
    [%unknown candidate ?:((gte at expires.order.s) %compiler-deadline %compilation-unconfirmed)]
  =/  r=record:cc  u.p.retained
  ?.  (lte received.r at)  [%unknown candidate %future-compilation]
  [%compiled candidate review.s write.order.s (digest:protocol order.s) (digest:protocol r)]
--
