::  Pure assembly from an explicitly selected compile_exports seed.
::  A v2 compiler bundle's old text entry is NEVER called with this ABI.
::  Caller must obtain the job via compiler.prepare under current native
::  admission. Internal consistency and pinned bytes do not prove a live read.
/-  nc=native-coding
/+  compiler=native-coding-compiler, artifact=native-coding-compiler-artifact,
    editor=native-coding-terminal-state, vm=native-coding-terminal-plan,
    scalar=terminal-plan, project=native-coding-project,
    files=native-coding-files, modules=native-coding-module-sources,
    profile=native-coding-compiler-profile
|%
+$  seed
  [%native-coding-terminal-assembly-seed-v1 source=bundle-v2:compiler digest=@ux entry=plan:vm]
+$  evidence
  ::  Old evidence ends in %unchecked. The new tail is disjoint and retains
  ::  its exact arithmetic profile and remaining native work; neither passes
  ::  a type check. Earlier saved nouns still fit without normalization.
  [bundle=bundle:editor seed=@ux job=@ux unchecked=$?(%unchecked [%native-coding-compiler-profile-v1 identity=@ux remaining=@ud])]
+$  result
  $%  [%& p=evidence]
      [%| p=refusal:artifact]
      [%native-coding-compiler-refusal-v1 profile=@ux failure=refusal:artifact]
  ==
++  failure
  |=  out=result
  ^-  (unit refusal:artifact)
  ?-  -.out
    %&  ~
    %|  `p.out
    %native-coding-compiler-refusal-v1  `failure.out
  ==
++  result-profile-valid
  |=  out=result
  ^-  ?
  ?.  ?=(%native-coding-compiler-refusal-v1 -.out)  %.y
  =(profile.out identity:profile)
++  execution-valid
  |=  [value=evidence fuel=@ud]
  ^-  ?
  ?:  ?=(%unchecked unchecked.value)  %.y
  ?>  ?=(^ unchecked.value)
  &((lte remaining.unchecked.value fuel) =(identity.unchecked.value identity:profile))
++  profiled-seed
  |=  input=seed
  ^-  ?
  !=(~ (prepare:profile entry.input))
++  execution-seed-valid
  |=  [input=seed out=result]
  ^-  ?
  ?.  ?=(%& -.out)  (result-profile-valid out)
  ?:  ?=(%unchecked unchecked.p.out)  %.y
  (profiled-seed input)
++  seed-digest
  |=  input=seed
  ^-  @ux
  (shax (jam [%native-coding-terminal-assembly-seed-v1 source.input entry.input]))
++  seed-valid
  |=  input=seed
  ^-  ?
  ?&  ?=(~ entry.source.input)
      (bundle-valid:compiler source.input)
      ::  Thirteen is the named-export producer generation. Older retained
      ::  manifests remain readable by compiler but cannot enter this lane.
      =(13 (lent sources.source.input))
      =(linker-sources:compiler (turn sources.source.input |=(w=witness:compiler [module.w digest.w])))
      =(digest.input (seed-digest input))
      (artifact-valid:scalar entry.input)
      =(`3 (arity:scalar entry.input))
  ==
++  source-pins
  ::  Conventional hexadecimal SHA-256, independently read from exact sources.
  ::  Law/entry identities and Urbit release hashes use native atom order.
  ^-  (map @t @ux)
  %-  malt
  :~  ['Runtime.NativeCodingTerminal' 0x755a.6c4e.d314.a73d.41f2.3321.5cd7.b3cc.cae8.541a.88b6.5fb3.7e1d.17f8.3d23.68e6]
      ['Core.Nat' 0x57bf.04b7.673f.a1fd.728e.0f19.95fb.aae6.57e1.0e53.c8e7.c42a.2289.e31a.4536.3d0f]
      ['Core.Text' 0xda3e.39a5.fc26.0d20.abe1.cc86.248f.e3a2.2e60.81bd.12c0.a346.c543.97aa.0a20.b5b6]
      ['Core.List' 0x298d.b091.bf33.3192.d23b.10f9.4d69.de55.843a.e0d5.487c.1dc2.92df.6ae4.9998.d81a]
  ==
++  inputs
  |=  j=job:compiler
  ^-  (each (list mapped:modules) @tas)
  =/  p=project:nc  (job-project:compiler j)
  =/  r=tool-request:nc  (job-request:compiler j)
  =/  tgt=build-target:nc  (job-target:compiler j)
  =/  mod=@t  (job-module:compiler j)
  =/  srcs=(list source:compiler)  (job-sources:compiler j)
  =/  c=context:nc  context.r
  ?.  &((valid:project p) ?=(?(%compile %check) -.arguments.r) =(4 (lent srcs)) =('Runtime.NativeCodingTerminal' mod))
    [%| %terminal-assembly-job-refused]
  ?.  ?&  =(id.spec.p project.c)  =(configuration.c (configuration:project p))
          =(actor.c authority.spec.p)  =(owner.source.c authority.spec.p)
          (revision-valid:project source.c)
          |(=(working.p desk.source.c) =(base-desk.spec.p desk.source.c))
          !=(0 session.c)  !=(0 request.c)
          (lte (met 0 session.c) 256)  (lte (met 0 request.c) 256)
          !=(0 call-id.r)  (lte (met 3 call-id.r) 128)
          =(%gallowglass kind.tgt)
          =(~[tgt] (skim targets.p |=(t=build-target:nc =(name.t name.tgt))))
      ==
    [%| %terminal-assembly-context-refused]
  ::  Refine the argument variant before reading its shared target face.
  ?>  ?=(?(%compile %check) -.arguments.r)
  =/  requested=@tas
    ?-  -.arguments.r
      %compile  target.arguments.r
      %check  target.arguments.r
    ==
  ?.  =(requested name.tgt)  [%| %terminal-assembly-target-refused]
  =/  closure  (dependencies:compiler p tgt)
  ?:  ?=(%| -.closure)  [%| p.closure]
  ?.  =(p.closure (turn srcs |=(s=source:compiler pax.s)))
    [%| %terminal-assembly-closure-refused]
  ?.  (levy srcs |=(s=source:compiler &((lte (met 3 text.s) 32.768) (text-valid:files p text.s) (readable:project p pax.s) ?=(^ pax.s) =(%gls (rear pax.s)) =(blob.s `@ux`(page-to-lobe:clay [%gls text.s])))))
    [%| %terminal-assembly-source-refused]
  ?.  (linked-input-valid:compiler j)  [%| %terminal-assembly-linked-input-refused]
  =/  named  (named-sources:compiler j)
  ?:  ?=(%| -.named)  [%| p.named]
  =/  root=mapped:modules  (snag 0 p.named)
  ?.  &(=(4 (lent p.named)) =('Runtime.NativeCodingTerminal' module.root))
    [%| %terminal-assembly-root-refused]
  ?.  %+  levy  p.named
      |=  s=mapped:modules
      =/  pin  (~(get by source-pins) module.s)
      ?~  pin  %.n
      =(u.pin (rev 3 32 (shax text.source.s)))
    [%| %terminal-assembly-source-pin-refused]
  named
++  wanted
  ::  Compiler.List of Compiler.List byte names, not a Text value.
  ^-  plan:vm
  =/  todo=(list @t)  (flop names:artifact)
  =/  out=plan:vm  [%nat 0]
  |-  ^-  plan:vm
  ?:  =(~ todo)  out
  $(todo (slag 1 todo), out [%app [%app [%nat 1] (encode:compiler (snag 0 todo))] out])
++  attempt
  |=  [input=seed j=job:compiler fuel=@ud]
  ^-  result
  ?.  (seed-valid input)  [%| %terminal-assembly-seed-refused 0 '' '']
  ?.  &((gte fuel 1) (lte fuel 2.000.000))  [%| %fuel-bound 0 '' '']
  =/  source  (inputs j)
  ?:  ?=(%| -.source)  [%| p.source 0 '' '']
  =/  ran
    (run-profile:vm fuel entry.input ~[(encode:compiler (job-module:compiler j)) wanted (encode-sources:compiler p.source)])
  ?:  ?=(%| -.ran)  [%| p.ran 0 '' '']
  =/  decoded  (terminal:artifact output.p.ran)
  ?:  ?=(%| -.decoded)  [%| p.decoded]
  =/  source=@ux  (~(got by source-pins) 'Runtime.NativeCodingTerminal')
  ?.  =(source source-digest:editor)  [%| %terminal-assembly-editor-source-mismatch 0 '' '']
  =/  bundle=bundle:editor
    [%native-coding-terminal-artifact-v1 source 0x0 initial.p.decoded valid.p.decoded reduce.p.decoded contents.p.decoded]
  =.  digest.bundle
    (shax (jam [source.bundle initial.bundle valid.bundle reduce.bundle contents.bundle]))
  ?.  (bundle-valid:editor bundle)  [%| %terminal-assembly-bundle-refused 0 '' '']
  [%& bundle digest.input (identity:compiler j) [%native-coding-compiler-profile-v1 identity:profile remaining.p.ran]]
++  assemble
  |=  [input=seed j=job:compiler fuel=@ud]
  ^-  result
  =/  tried  (mole |.((attempt input j fuel)))
  ?~  tried
    [%native-coding-compiler-refusal-v1 identity:profile [%terminal-assembly-input-invalid 0 '' '']]
  ?:  ?=(%| -.u.tried)
    [%native-coding-compiler-refusal-v1 identity:profile p.u.tried]
  u.tried
--
