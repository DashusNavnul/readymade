::  Typed saved-VASE DATA projection shared by production +owned and the
::  inert deployment rehearsal. Never cast a saved noun to executable code.
/+  guard=load-guard, owner=qpc-native-owner-binding,
    declaration=qpc-native-declaration, assessment=qpc-native-assessment,
    controller=qpc-native-controller, selected=qpc-native-selected,
    admission=qpc-native-admission-store, flow=qpc-native-flow,
    campaign=qpc-native-campaign
|%
+$  app  ?(%viki %cantrip)
+$  part  part:guard
++  peel
  |=  [who=app tag=@tas v=vase]
  ^-  [data=* inner=vase]
  ?:  =(%qpc-campaign-owner-v1 tag)
    ?>  =(%viki who)
    =/  p  !<([%qpc-campaign-owner-v1 held=state:campaign inner=vase] v)
    [held.p inner.p]
  ?:  =(%qpc-flow-owner-v1 tag)
    =/  p  !<([actual=@tas role=app held=* inner=vase] v)
    ?>  &(=(tag actual.p) =(who role.p))
    [[role.p held.p] inner.p]
  ?:  ?=(?(%native-coding-worker-tool-save-v2 %native-coding-worker-parent-save-v2) tag)
    =/  p  !<([actual=@tas one=* two=* inner=vase] v)
    ?>  =(tag actual.p)
    [[one.p two.p] inner.p]
  ?:  =(%qpc-instrument-v3 tag)
    =/  p  !<([actual=@tas held=* ordered=* laws=* inner=vase] v)
    ?>  =(tag actual.p)
    [[held.p ordered.p laws.p] inner.p]
  ?:  =(%qpc-instrument-v4 tag)
    =/  p  !<([actual=@tas held=* ordered=* laws=* successors=* refresh=(unit @da) inner=vase] v)
    ?>  =(tag actual.p)
    [[held.p ordered.p laws.p successors.p refresh.p] inner.p]
  ?:  =(%qpc-instrument-v5 tag)
    =/  p  !<([actual=@tas held=* ordered=* laws=* successors=* refresh=(unit @da) selected=* inner=vase] v)
    ?>  =(tag actual.p)
    [[held.p ordered.p laws.p successors.p refresh.p selected.p] inner.p]
  ?:  =(%shoe-app tag)
    =/  p  !<([actual=@tas inner=vase held=*] v)
    ?>  =(tag actual.p)
    [held.p inner.p]
  ?:  =(%qpc-session-gate-v2 tag)
    =/  p  !<([%qpc-session-gate-v2 role=app required=* pools=* inner=vase] v)
    ?>  =(who role.p)
    [[role.p required.p pools.p] inner.p]
  ?:  =(%qpc-observer-v3 tag)
    =/  p  !<([actual=@tas one=* two=* three=* inner=vase] v)
    ?>  =(tag actual.p)
    [[one.p two.p three.p] inner.p]
  =/  p  !<([actual=@tas held=* inner=vase] v)
  ?>  =(tag actual.p)
  [held.p inner.p]
++  extract
  |=  [who=app v=vase tags=(list @tas) optional=(set @tas)]
  ^-  (list part)
  ?~  tags  ~[[%inner q.v]]
  =/  actual=@tas
    ?:  &(=(%qpc-instrument-v3 i.tags) ?=([%qpc-instrument-v5 *] q.v))
      %qpc-instrument-v5
    ?:  &(=(%qpc-instrument-v3 i.tags) ?=([%qpc-instrument-v4 *] q.v))
      %qpc-instrument-v4
    ?:  &(=(%native-local-review-owner-v3 i.tags) ?=([%native-local-review-owner-v2 *] q.v))
      %native-local-review-owner-v2
    i.tags
  ?:  &((~(has in optional) i.tags) ?@(q.v %.y !=(actual -.q.v)))
    $(tags t.tags)
  =/  parts  (peel who actual v)
  [[actual data.parts] $(v inner.parts, tags t.tags)]
++  viki
  |=  v=vase
  ^-  (list part)
  %:  extract  %viki  v
    ~[%qpc-readiness-owner-v1 %qpc-task-onboard-owner-v3 %qpc-campaign-owner-v1 %qpc-flow-owner-v1 %qpc-selected-owner-v1 %qpc-controller-owner-v1 %qpc-prospective-owner-v1 %qpc-native-declaration-owner-v1 %qpc-law-owner-v2 %qpc-instrument-v3 %native-local-review-owner-v3 %qpc-stream-v1 %qpc-observer-v3 %qpc-session-gate-v2 %shoe-app]
  (silt `(list @tas)`~[%qpc-readiness-owner-v1 %qpc-task-onboard-owner-v3 %qpc-campaign-owner-v1 %qpc-flow-owner-v1 %qpc-selected-owner-v1 %qpc-controller-owner-v1 %qpc-prospective-owner-v1 %qpc-native-declaration-owner-v1])
  ==
++  cantrip
  |=  v=vase
  ^-  (list part)
  %:  extract  %cantrip  v
    ~[%qpc-flow-owner-v1 %native-coding-worker-tool-save-v2 %native-coding-worker-parent-save-v2 %qpc-admission-owner-v1 %qpc-assessment-owner-v1 %native-coding-check-authorizations-v1 %qpc-session-gate-v2]
  (silt `(list @tas)`~[%qpc-flow-owner-v1 %native-coding-worker-tool-save-v2 %native-coding-worker-parent-save-v2 %qpc-admission-owner-v1 %qpc-assessment-owner-v1 %qpc-session-gate-v2])
  ==
++  owned
  |=  [who=app v=vase]
  ?:(=(%viki who) (viki v) (cantrip v))
++  new-empty
  |=  [who=app p=part]
  ^-  ?
  ?:  &(=(%cantrip who) =(%qpc-session-gate-v2 tag.p))
    =(data.p [%cantrip ~ ~])
  ?:  &(=(%viki who) =(%qpc-campaign-owner-v1 tag.p))
    =(data.p empty:campaign)
  ::  Literal, not an import: Cantrip compiles this file too.
  ?:  &(=(%viki who) =(%qpc-readiness-owner-v1 tag.p))
    =(data.p [%qpc-readiness-owner-state-v1 [%qpc-native-readiness-v1 ~ ~ ~ ~] ~ ~ ~ ~])
  ?:  =(%qpc-flow-owner-v1 tag.p)  =(data.p [who empty:flow])
  ::  Literal, not an import: the onboarding owner's empty state (2026-11-01).
  ?:  &(=(%viki who) =(%qpc-task-onboard-owner-v3 tag.p))
    =(data.p [%qpc-task-onboard-v3 ~ ~ ~ ~])
  ?:  &(=(%viki who) =(%qpc-selected-owner-v1 tag.p))
    =(data.p empty:selected)
  ?:  &(=(%viki who) =(%qpc-controller-owner-v1 tag.p))
    =(data.p empty:controller)
  ?:  &(=(%cantrip who) =(%qpc-admission-owner-v1 tag.p))
    =(data.p empty:admission)
  ?:  &(=(%viki who) =(%qpc-prospective-owner-v1 tag.p))
    =(data.p empty:owner)
  ?:  &(=(%viki who) =(%qpc-native-declaration-owner-v1 tag.p))
    =(data.p empty:declaration)
  &(=(%cantrip who) =(%qpc-assessment-owner-v1 tag.p) =(data.p empty:assessment))
++  preserved
  ::  Only the new, exactly empty owner layers may appear. An existing layer
  ::  cannot be dropped, reset, reordered, or replaced by a new empty layer.
  |=  [who=app before=(list part) after=(list part)]
  ^-  ?
  =/  added=(set @tas)  ~
  |-
  ?~  after  ?=(~ before)
  ?~  before  %.n
  ?:  =(tag.i.before tag.i.after)
    &(=(data.i.before data.i.after) $(before t.before, after t.after))
  ?&  !(~(has in added) tag.i.after)
      (new-empty who i.after)
      $(after t.after, added (~(put in added) tag.i.after))
  ==
++  rehearse
  ::  Both are actual native compiler products. The caller supplies the
  ::  original Gall saved VASE and bowl; every returned card stays inert.
  |=  [who=app old=agent:gall candidate=agent:gall original=vase b=bowl:gall]
  ^-  [before=@ux after=@ux again=@ux parts=@ud cards=@ud]
  =/  baseline  (on-load:~(. old b) original)
  =/  normalized=vase  on-save:~(. +.baseline b)
  ?>  =((owned who original) (owned who normalized))
  =/  changed  (on-load:~(. candidate b) original)
  =/  saved=vase  on-save:~(. +.changed b)
  ?>  (preserved who (owned who normalized) (owned who saved))
  ?>  =(-.baseline -.changed)
  =/  repeat  (on-load:~(. +.changed b) saved)
  =/  reloaded=vase  on-save:~(. +.repeat b)
  ?>  =((owned who saved) (owned who reloaded))
  ?>  =(-.changed -.repeat)
  ?>  &((~(nest ut p.saved) | p.reloaded) (~(nest ut p.reloaded) | p.saved))
  [(shax (jam (owned who original))) (shax (jam (owned who saved))) (shax (jam (owned who reloaded))) (lent (owned who saved)) (lent -.changed)]
--
