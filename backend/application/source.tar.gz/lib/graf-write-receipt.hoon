::  /lib/graf-write-receipt
::
::  Pure construction and bounded lookup for Graf write receipts.  Ames
::  supplies source-ship outside the request noun; callers cannot forge it by
::  copying identity fields into a Graf action.
::
/-  gwr=graf-write-receipt
|%
++  max-receipts  256
::
++  request-id-for
  |=  key=@t
  ^-  @ux
  (shax key)
::
++  request-digest-for
  |=  [source-ship=@p request=*]
  ^-  @ux
  (shax (jam [source-ship request]))
::
++  receipt-id-for
  |=  [request-id=@ux request-digest=@ux]
  ^-  @ux
  (shax (jam [request-id request-digest]))
::
++  make
  |=  $:  request-key=@t
          action=@tas
          source-ship=@p
          request=*
          accepted=?
          duplicate=?
          reason=@tas
          revision=@ud
          recorded-at=@da
      ==
  ^-  receipt:gwr
  =/  request-id=@ux  (request-id-for request-key)
  =/  request-digest=@ux  (request-digest-for source-ship request)
  :*  version=1
      receipt-id=(receipt-id-for request-id request-digest)
      request-id=request-id
      request-digest=request-digest
      request-key=request-key
      action=action
      source-ship=source-ship
      accepted=accepted
      duplicate=duplicate
      reason=reason
      revision=revision
      recorded-at=recorded-at
  ==
::
++  same-correlation
  |=  [item=receipt:gwr request-id=@ux request-digest=@ux]
  ^-  ?
  ?&  =(request-id.item request-id)
      =(request-digest.item request-digest)
  ==
::
++  find
  |=  [receipts=(list receipt:gwr) request-id=@ux request-digest=@ux]
  ^-  (unit receipt:gwr)
  ?~  receipts  ~
  ?:  (same-correlation i.receipts request-id request-digest)
    `i.receipts
  $(receipts t.receipts)
::
::  One correlation has one current receipt.  A replay replaces its earlier
::  outcome, while a reused key with changed source or payload has a different
::  digest and remains separately readable.
::
++  put
  |=  [receipts=(list receipt:gwr) item=receipt:gwr]
  ^-  (list receipt:gwr)
  =/  rest=(list receipt:gwr)
    %+  skim  receipts
    |=(old=receipt:gwr !=(receipt-id.old receipt-id.item))
  (scag max-receipts (weld ~[item] rest))
--
