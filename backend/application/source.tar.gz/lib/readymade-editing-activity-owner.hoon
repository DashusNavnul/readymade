::  Owner-side activity service. Caller passes Gall src unchanged and stores rooms
::  only transiently. No raw room state is returned to a remote recipient.
/-  pa=cantrip-project-access, mp=multiplayer-project, nc=native-coding
/+  activity=readymade-editing-activity, sharing=readymade-project-sharing,
    law=cantrip-law-window, coding=native-coding-project,
    projects=multiplayer-project, guard=viki-scry-guard
|%
+$  rooms  (map @t room:activity)
+$  action  $%([%query ~] [%update message:activity])
+$  request  [id=@uv project=@t action=action]
+$  snapshot  [address=address:activity at=@da rows=(list [ship=@p file=file:activity]) self-sequence=(unit @ud)]
+$  response  [id=@uv project=@t result=(each snapshot @tas)]
+$  change  [rooms=rooms response=response]
++  admitted
  |=  [o=observation:sharing w=window:law src=@p]
  ^-  ?
  ?.  ?&  (project-valid:projects catalog.o)
          (time-valid:projects catalog.o at.o)
          =(owner.o authority.spec.catalog.o)
          (~(has in admissible.w) %read)
          !(~(has in blocked.w) %read)
      ==  %.n
  ?:  =(owner.o src)
    ?~  scope.o  %.n
    &((valid:coding u.scope.o) =(spec.catalog.o spec.u.scope.o))
  =/  held  (~(get by held.o) [id.spec.catalog.o src])
  ?~  held  %.n
  %+  lien  ~(tap in paths.grant.u.held)
  |=  pax=path
  ?=(^ (permission:activity o w src [desk.grant.u.held pax] %.n))
++  serve
  |=  [o=observation:sharing w=window:law held=rooms src=@p req=request]
  ^-  change
  =/  refused  |=(why=@tas [held [id.req project.req [%| why]]])
  ?.  ?&  (gth id.req 0)  (lte (met 0 id.req) 256)
          !=('' project.req)  (lte (met 3 project.req) 128)
          =(project.req id.spec.catalog.o)
      ==  (refused %activity-request-invalid)
  =/  old  (~(get by held) project.req)
  =/  current=(each room:activity @tas)
    ?:  ?=(%query -.action.req)
      ?.  (admitted o w src)  [%| %activity-permission-refused]
      ?^  old  [%& u.old]
      ?:  (gte ~(wyt by held) 32)  [%| %activity-project-capacity]
      (open-room:activity o)
    ?~  old  [%| %activity-room-missing]
    (receive:activity o w u.old src +.action.req)
  ?:  ?=(%| -.current)  (refused p.current)
  =/  room=room:activity  p.current
  ?.  (room-current:activity o room address.room)
    (refused %activity-scope-mismatch)
  =/  rows=(list [ship=@p file=file:activity])
    (read-room:activity o w room src address.room)
  ::  Only the authenticated caller's cursor, including expired/stop tombstones.
  ::  This does not disclose old paths or prove an unknown request succeeded.
  =/  own  (~(get by entries.room) src)
  =/  cursor=(unit @ud)  ?~(own ~ `sequence.update.u.own)
  [(~(put by held) project.req room) [id.req project.req [%& [address.room at.o rows cursor]]]]
++  read
  ::  Reads the local owner's canonical state, without rewriting b.src to our.
  ::  This read alone grants nothing: serve rechecks the authenticated actor.
  |=  [b=bowl:gall id=@t]
  ^-  (each [observation=observation:sharing window=window:law] @tas)
  ?.  &(!=('' id) (lte (met 3 id) 128))  [%| %activity-request-invalid]
  ?.  ?&  (agent-live:guard our.b now.b %multiplayer-runtime)
          (agent-live:guard our.b now.b %cantrip)
          (agent-live:guard our.b now.b %viki)
      ==  [%| %activity-native-unavailable]
  =/  p=(unit project:mp)
    .^((unit project:mp) %gx /(scot %p our.b)/multiplayer-runtime/(scot %da now.b)/catalog/[id]/noun)
  ?~  p  [%| %activity-project-missing]
  ?.  &(=(our.b authority.spec.u.p) =(id id.spec.u.p))
    [%| %activity-foreign-project]
  =/  configs=(map @t project:nc)
    .^((map @t project:nc) %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/projects/noun)
  =/  grants=grants:pa
    .^(grants:pa %gx /(scot %p our.b)/cantrip/(scot %da now.b)/project-access/grants/noun)
  =/  window=window:law
    .^(window:law %gx /(scot %p our.b)/cantrip/(scot %da now.b)/law/window/current/noun)
  [%& [[our.b now.b u.p (~(get by configs) id) grants] window]]
--
