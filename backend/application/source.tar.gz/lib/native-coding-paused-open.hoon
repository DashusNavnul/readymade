::  Owner-only paused opening. No model run, timer, tool, or new authority.
/-  nc=native-coding, np=native-coding-provider
/+  sessions=native-coding-session, tools=cantrip-native-coding,
    reservation=qpc-session-reservation, guard=viki-scry-guard
|%
++  permit
  |=  $:  our=@p  id=@ux  grant=@ux  project=project:nc
          expected=revision:nc  actual=revision:nc
          ledger=organ:tools  local=(set @ux)
      ==
  ^-  (unit @tas)
  ?.  =(expected actual)  `%source-changed
  =/  scope  (~(get by grants.ledger) grant)
  ?~  scope  `%standing-grant-missing
  ?.  =(``grant (spare:reservation ledger local id))  `%session-id-already-used
  =/  g=grant:tools  grant.u.scope
  ?.  ?&  =(~ revoked.u.scope)  (grant-valid:tools our g)
          =(our actor.g)  =(id session.g)  =(project project.g)
          (~(has in operations.g) %read)
      ==  `%standing-scope-mismatch
  ~
++  read
  ::  The caller resolves membership and today's project/source first.
  |=  [b=bowl:gall id=@ux grant=@ux project=project:nc expected=revision:nc actual=revision:nc]
  ^-  (unit @tas)
  ?.  =(our.b src.b)  `%owner-required
  ?.  &((agent-live:guard our.b now.b %cantrip) (agent-live:guard our.b now.b %viki))
    `%paused-open-owner-unavailable
  =/  raw=*
    .^(* %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/tool-state/noun)
  =/  ledger  ((soft organ:tools) raw)
  ?~  ledger  `%paused-open-ledger-invalid
  =/  raw=*
    .^(* %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/local-used-sessions/noun)
  =/  local  ((soft (set @ux)) raw)
  ?~  local  `%paused-open-sessions-invalid
  (permit our.b id grant project expected actual u.ledger u.local)
++  begin
  |=  [our=@p actor=@p at=@da s=session:nc configuration=@ux selected=selection:np context=@t]
  ^-  (each transition:sessions @tas)
  =/  opened  (begin:sessions our actor at s configuration selected our context)
  ?:  ?=(%| -.opened)  opened
  =/  paused  (pause:sessions our actor at entry.p.opened %.n)
  ?:  ?=(%| -.paused)  paused
  [%& [entry.p.paused (weld effects.p.opened effects.p.paused)]]
--
