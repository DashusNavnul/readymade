::  Pure discovery law: which retained sessions one current member may see.
::  Authority is current membership, project policy, the law window and each
::  exact live inspection grant. Nothing is created, widened or renewed, and
::  no file view grant is required or implied. The peer supplies no ids.
/-  ps=cantrip-project-sessions, nc=native-coding, mp=multiplayer-project
/+  tools=cantrip-native-coding, project=native-coding-project,
    rows=readymade-session-catalog, law=cantrip-law-window
|%
+$  scopes  (map @ux scope:tools)
+$  session-view
  [session=session:nc phase=@tas selection=* worker=@p records=* summary=@t sequence=@ud]
+$  resolved  (map @ux (each project:nc @tas))
++  limit  64
++  query-valid
  |=  q=query:ps
  ^-  ?
  ?&  !=(0 project.q)  (lte (met 3 project.q) 128)
      !=(0 nonce.q)  (lte (met 0 nonce.q) 128)
  ==
++  inspection-path
  |=  session=@ux
  ^-  path
  /native-coding/session/(scot %ux session)/noun
++  route
  |=  [peer=@p q=query:ps]
  ^-  path
  /project-sessions/(scot %ux project.q)/(scot %p peer)/(scot %ux nonce.q)
++  parse
  |=  pax=path
  ^-  (unit [peer=@p query=query:ps])
  ?.  &(?=([%project-sessions @ @ @ ~] pax) (lte (met 3 (jam pax)) 4.096))  ~
  =/  project  (slaw %ux i.t.pax)
  =/  peer  (slaw %p i.t.t.pax)
  =/  nonce  (slaw %ux i.t.t.t.pax)
  ?~  project  ~
  ?~  peer  ~
  ?~  nonce  ~
  =/  q=query:ps  [`@t`u.project u.nonce]
  ?.  &((lte (met 0 u.peer) 128) (query-valid q) =(pax (route u.peer q)))  ~
  `[u.peer q]
++  admitted
  ::  Reject before any native read.
  |=  [q=query:ps w=window:law]
  ^-  (each ~ @tas)
  ?.  (query-valid q)  [%| %sessions-query-invalid]
  ?.  &((~(has in admissible.w) %inspect) !(~(has in blocked.w) %inspect))
    [%| %sessions-law-refused]
  [%& ~]
++  eligible
  ::  One live, exact inspection grant held for this peer in this project.
  |=  [our=@p peer=@p q=query:ps s=scope:tools]
  ^-  ?
  =/  g=grant:tools  grant.s
  ?&  ?=(~ revoked.s)  (grant-valid:tools our g)
      =(actor.g peer)  =(id.spec.project.g project.q)
      (~(has in operations.g) %inspect)
      (~(has in inspections.g) [%viki (inspection-path session.g)])
  ==
++  candidates
  ::  Deterministic and bounded: ascending grant id, at most `limit`.
  |=  [our=@p peer=@p q=query:ps held=scopes]
  ^-  [grants=(list grant:tools) truncated=?]
  =/  kept=(list grant:tools)
    %+  murn  ~(val by held)
    |=  s=scope:tools
    ^-  (unit grant:tools)
    ?.((eligible our peer q s) ~ `grant.s)
  =/  all=(list grant:tools)
    (sort kept |=([a=grant:tools b=grant:tools] (lth id.a id.b)))
  [(scag limit all) (gth (lent all) limit)]
++  row-valid
  |=  [our=@p q=query:ps r=row:ps]
  ^-  ?
  ?&  (identifier:tools inspection.r)
      (revision-valid:project source.r)
      (valid-row:rows our [session.r project.q our phase.r source.r])
  ==
++  response-valid
  |=  r=response:ps
  ^-  ?
  ?&  (lte (met 0 owner.r) 128)  (lte (met 0 peer.r) 128)
      (query-valid query.r)  (gth at.r 0)  (lte (met 0 at.r) 128)
      (lte (lent rows.r) limit)
      (levy rows.r |=(x=row:ps (row-valid owner.r query.r x)))
  ==
++  observe
  ::  The live adapter supplies every current native observation. A row whose
  ::  own grant, project or session no longer agrees is omitted, never guessed.
  ::  A peer who is not a current member with inspect standing gets no list.
  |=  $:  our=@p  peer=@p  now=@da  q=query:ps  held=scopes  w=window:law
          catalog=project:mp  base=project:nc  solved=resolved  raw=*
      ==
  ^-  (each response:ps @tas)
  =/  ok  (admitted q w)
  ?:  ?=(%| -.ok)  [%| p.ok]
  ?.  &(=(project.q id.spec.catalog) =(our authority.spec.catalog))
    [%| %sessions-member-refused]
  ?.  (member:project base catalog peer %inspect)  [%| %sessions-member-refused]
  =/  decoded  ((soft (list session-view)) raw)
  ?~  decoded  [%| %sessions-invalid]
  =/  views=(map @ux session-view)
    %-  malt
    ^-  (list [@ux session-view])
    (turn u.decoded |=(v=session-view [id.session.v v]))
  =/  picked  (candidates our peer q held)
  =/  out=(list row:ps)
    %+  murn  grants.picked
    |=  g=grant:tools
    ^-  (unit row:ps)
    =/  current  (~(get by solved) session.g)
    ?~  current  ~
    =/  answer=(each project:nc @tas)  u.current
    ?:  ?=(%| -.answer)  ~
    =/  p=project:nc  p.answer
    ?.  &(=(p project.g) (member:project p catalog peer %inspect))  ~
    =/  v  (~(get by views) session.g)
    ?~  v  ~
    =/  s=session:nc  session.u.v
    ?.  ?&  =(our owner.s)  =(session.g id.s)  =(project.q project.s)
            =(our owner.working.s)  =(working.p desk.working.s)
        ==
      ~
    =/  r=row:ps  [id.s id.g phase.u.v working.s]
    ?.  (row-valid our q r)  ~
    `r
  =/  response=response:ps  [our peer q now out truncated.picked]
  ?.  (response-valid response)  [%| %sessions-invalid]
  [%& response]
++  cards
  |=  [pax=path r=response:ps]
  ^-  (list card:agent:gall)
  ?>  &((response-valid r) =(pax (route peer.r query.r)))
  :~  [%give %fact ~[pax] %noun !>(`event:ps`[%cantrip-project-sessions-v1 r])]
      [%give %kick ~[pax] ~]
  ==
--
