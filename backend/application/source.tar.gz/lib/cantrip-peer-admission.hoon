::  /lib/cantrip-peer-admission
::
::  The join Cantrip was missing.  Transport law already ruled on the MOVE
::  (/lib/cantrip-multiplayer-law) and the vibecoding law already ruled on the
::  local ACT (/lib/cantrip-vibecoding-dispatch).  Nothing ruled on the hop
::  between them, so a peer task reached the model under a ceiling hardcoded
::  in the executor rather than under a verdict -- a real gate, but a constant,
::  with no path by which a peer could ever be granted more.
::
::  Three rules, in order of how much they matter:
::
::  1. THE REQUEST IS NEVER THE AUTHORITY.  Identity is src.bowl, which Ames
::     authenticated; the ceiling is the grant this ship issued.  Effective
::     authority is the MEET of asked and granted -- never a max, never the
::     peer's value.
::
::  2. CAPABILITY IS DERIVED FROM THE ACT.  The local dispatch law already
::     refuses to let a caller name a cheaper tool for a more powerful
::     operation.  That property must survive the Ames hop, because the hop
::     is exactly where lying becomes possible.
::
::  3. RULE ON SHAPE, NEVER ON CONTENT.  Releases are digest-only by law, so
::     this gate sees a target and an act and never a payload.  It must not
::     become a classifier: an opaque judgment surface is a thing to
::     reverse-engineer, and a peer should be able to read this file and know
::     exactly what is admissible.
::
/-  cpg=cantrip-peer-grant, vp=vibecoding-proposal
/+  clw=cantrip-law-window
|%
++  allow
  |=  [capability=@t tier=peer-tier:cpg digest=@ux]
  ^-  peer-verdict:cpg
  [%& capability tier digest]
++  refuse
  |=  why=peer-refusal:cpg
  ^-  peer-verdict:cpg
  [%| why]
::
::  The act-to-tier mapping, narrowed for peers.  The four %data acts return
::  ~ rather than a tier: across Ames they are not expensive, they are absent.
++  peer-tier-of
  |=  kind=act:clw
  ^-  (unit peer-tier:cpg)
  ?-  kind
    ?(%read %inspect %compare %hypothesize %probe %summarize %done)  `%safe
    %branch  `%reversible
    ?(%inscribe %implement %promote %reduce)  ~
  ==
++  tier-rank
  |=  tier=peer-tier:cpg
  ^-  @ud
  ?-(tier %safe 0, %reversible 1)
::
::  Derived from the exact target and act.  The caller does not get to name it.
++  capability-for
  |=  act=proposed-act:vp
  ^-  @t
  =/  tier  (peer-tier-of kind.act)
  ?-  -.target.act
    %clay    ?:(=(`%safe tier) 'read-file' 'branch-fork')
    %thread  `@t`name.target.act
    %graf    ?:(=(`%safe tier) 'graf-recall' 'graf-inscribe')
    %gall    'poke-agent'
  ==
::
::  Containment.  A read may look outside the fork; anything that leaves a
::  mark may not exist outside it.
::
::  %graf and %gall returned %.y here, which meant a %reversible grant whose
::  capability set held graf-inscribe or poke-agent was admitted with NO
::  containment at all -- a fork cannot contain a graf handle or a gall poke,
::  so there was nothing to check and the arm said yes anyway.  Unreachable
::  through the executor today, which only ever builds %clay targets, but this
::  law is what BOTH ships run and a direct peer-request may name any surface.
::  Refuse what cannot be contained: only %safe acts reach graf and gall, and
::  %safe never consults this arm.
++  inside-fork
  |=  [target=surface:vp fork=@tas]
  ^-  ?
  ?-  -.target
    %clay    =(fork desk.target)
    %thread  =(fork desk.target)
    %graf    %.n
    %gall    %.n
  ==
::
::  The verdict digest covers the grant, the act and the derived capability,
::  so a crossing record can carry proof of the authority it ran under.
++  verdict-digest
  |=  [grant=peer-grant:cpg act=proposed-act:vp capability=@t]
  ^-  @ux
  `@ux`(shax (jam [%cantrip-peer-verdict-v1 grant act capability]))
::
++  admit
  |=  $:  source=@p
          grant=(unit peer-grant:cpg)
          request=peer-request:cpg
          now=@da
      ==
  ^-  peer-verdict:cpg
  ?~  grant  (refuse %no-grant)
  =/  g=peer-grant:cpg  u.grant
  ::  identity is what Ames authenticated, never a field in the request
  ?.  =(source peer.g)  (refuse %source-not-allowed)
  ?.  =(peer-session.request peer-session.g)  (refuse %session-mismatch)
  ::  the lease is checked at the ACT, not once when the binding was made:
  ::  a grant that cannot be pulled mid-flight is not one to extend
  ::  A zero deadline remains authorized until the owner removes the grant.
  ?:  &(!=(0 expires.g) (gth now expires.g))  (refuse %lease-expired)
  =/  asked  (peer-tier-of kind.act.request)
  ?~  asked  (refuse %act-not-admissible)
  ?:  (gth (tier-rank u.asked) (tier-rank tier-ceiling.g))
    (refuse %tier-ceiling-exceeded)
  =/  cap=@t  (capability-for act.request)
  ?.  (~(has in capabilities.g) cap)  (refuse %capability-not-granted)
  ?:  ?&  =(%reversible u.asked)
          !(inside-fork target.act.request fork.g)
      ==
    (refuse %outside-fork)
  (allow cap u.asked (verdict-digest g act.request cap))
--
