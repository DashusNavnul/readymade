::  /lib/desk-diff
::
::  WHAT CHANGED, READ FROM THE COMMITS.  lib/desk-shell-read's +changed walks
::  two trees with %cy and %cz per node, and Clay recomputes a subtree hash on
::  every %cz, so even the pruned walk costs seconds -- measured 2026-09-28 on
::  dashus: fork vs %repo 4.8 s, fork vs live %pataphor 13.4 s, two revisions
::  of one fork 7.1 s.  Bench paid all three on every turn.
::
::  A commit (yaki) already holds its whole namespace as (map path lobe), and
::  a lobe is a content hash.  One cone read gives every desk's commit table,
::  one %cs read gives a commit; the diff is then a map walk in memory:
::  0.0 s measured, and the SAME answer as the walk on both pairs above,
::  proven as sets before this file existed.
::
::  %cw IS NOT CHEAP: 2.3 s per read, measured, at any case shape.  So aeons
::  come from the dome's `let`, and a date becomes an aeon by reading commit
::  dates, never through %cw.
::
::  The change shape is desk-shell-read's, so callers cast the same.
|%
+$  status  ?(%only-in-fork %only-in-base %differs)
+$  change  [pax=path what=status]
::
++  domes
  |=  [our=@p now=@da]
  ^-  cone:clay
  .^(cone:clay %cx /(scot %p our)/(scot %tas %$)/(scot %da now)/domes)
::
++  dome-of
  |=  [our=@p now=@da dek=@tas]
  ^-  dome:clay
  (~(got by (domes our now)) [our dek])
::
::  the desk's current revision number, without %cw
++  let-of
  |=  [our=@p now=@da dek=@tas]
  ^-  @ud
  let:(dome-of our now dek)
::
++  yaki-of
  |=  [our=@p now=@da dek=@tas tak=tako:clay]
  ^-  yaki:clay
  .^(yaki:clay %cs /(scot %p our)/[dek]/(scot %da now)/yaki/(scot %uv tak))
::
::  the namespace of a desk's newest revision, from a cone already in hand:
::  one cone read serves every desk compared in one event (bench compares
::  every host desk against %repo after a landing).
++  path-map-with
  |=  [our=@p now=@da cone=cone:clay dek=@tas]
  ^-  (map path lobe:clay)
  =/  dom=(unit dome:clay)  (~(get by cone) [our dek])
  ?~  dom  ~
  =/  tak=(unit tako:clay)  (~(get by hit.u.dom) let.u.dom)
  ?~  tak  ~
  q:(yaki-of our now dek u.tak)
::
::  the namespace of one revision
++  path-map
  |=  [our=@p now=@da dek=@tas aeon=@ud]
  ^-  (map path lobe:clay)
  =/  dom=dome:clay  (dome-of our now dek)
  =/  tak=(unit tako:clay)  (~(get by hit.dom) aeon)
  ?~  tak  ~
  q:(yaki-of our now dek u.tak)
::
::  the newest revision committed at or before a date (0 = none yet)
++  aeon-at
  |=  [our=@p now=@da dek=@tas when=@da]
  ^-  @ud
  =/  dom=dome:clay  (dome-of our now dek)
  =/  best=@ud  0
  =/  rest=(list [a=@ud t=tako:clay])  ~(tap by hit.dom)
  |-  ^-  @ud
  ?~  rest  best
  =/  yak=yaki:clay  (yaki-of our now dek t.i.rest)
  ?:  ?&((lte t.yak when) (gth a.i.rest best))
    $(rest t.rest, best a.i.rest)
  $(rest t.rest)
::
++  diff-maps
  |=  [b=(map path lobe:clay) f=(map path lobe:clay)]
  ^-  (list change)
  %+  weld
    %+  murn  ~(tap by f)
    |=  [p=path l=lobe:clay]
    ^-  (unit change)
    =/  bl=(unit lobe:clay)  (~(get by b) p)
    ?~  bl  `[p %only-in-fork]
    ?:  =(u.bl l)  ~
    `[p %differs]
  %+  murn  ~(tap by b)
  |=  [p=path l=lobe:clay]
  ^-  (unit change)
  ?:  (~(has by f) p)  ~
  `[p %only-in-base]
::
::  how base and fork differ now
++  changed
  |=  [our=@p now=@da base=@tas fork=@tas]
  ^-  (list change)
  %+  diff-maps
    (path-map our now base (let-of our now base))
  (path-map our now fork (let-of our now fork))
::
::  how two revisions differ, each named by a date
++  changed-since
  |=  [our=@p now=@da base=@tas base-at=@da fork=@tas fork-at=@da]
  ^-  (list change)
  %+  diff-maps
    (path-map our now base (aeon-at our now base base-at))
  (path-map our now fork (aeon-at our now fork fork-at))
::
::  how two revisions differ, each named by a revision number
++  changed-between
  |=  [our=@p now=@da base=@tas base-aeon=@ud fork=@tas fork-aeon=@ud]
  ^-  (list change)
  %+  diff-maps
    (path-map our now base base-aeon)
  (path-map our now fork fork-aeon)
::
::  IMPORTS AND CLOSURES.  What a file pulls in through /- and /+, each as a
::  desk path, read from the header alone: rune lines, their indented
::  continuations, comments and blanks; the first line that is none of those
::  ends the header.  /= and /* are not walked (one lib imports vane sources
::  with /=; no host desk carries those).  These are the rules of
::  pataphor-ops hostcheck.py's +imports, which converged 678 of 681 host
::  files, now on the ship so bench can judge a host desk by what its agent
::  BUILDS: a host keeps files from agents it used to run, and Clay rebuilds
::  nothing for those; a lib a landing newly imports is not on the host at
::  all, and the build fails without it (both seen 2026-09-28).
++  imports
  |=  txt=@t
  ^-  (list path)
  =/  lines=wain  (to-wain:format txt)
  =/  kind=@tas  %none
  =|  acc=(list path)
  |-  ^-  (list path)
  ?~  lines  (flop acc)
  =/  l=tape  (trip i.lines)
  =/  c1=@tD  ?~(l *@tD i.l)
  =/  c2=@tD  ?~(l *@tD ?~(t.l *@tD i.t.l))
  ?:  |(=(0 c1) &(=(':' c1) =(':' c2)))  $(lines t.lines)
  ?:  &(=('/' c1) =('+' c2))
    $(lines t.lines, kind %lib, acc (weld (names (slag 2 l) %lib) acc))
  ?:  &(=('/' c1) =('-' c2))
    $(lines t.lines, kind %sur, acc (weld (names (slag 2 l) %sur) acc))
  ?:  =('/' c1)  $(lines t.lines, kind %none)
  ?.  =(' ' c1)  (flop acc)
  ?:  =(%none kind)  $(lines t.lines)
  $(lines t.lines, acc (weld (names l kind) acc))
::
::  the names one import line carries: `a, b=c, *d  ::  e` -> a c d, each
::  as /<dir>/<name>/hoon
++  names
  |=  [l=tape dir=@tas]
  ^-  (list path)
  =|  [cur=tape acc=(list path)]
  |-  ^-  (list path)
  =/  done=(list path)
    ?~  cur  acc
    =/  tok=tape  (flop `tape`cur)
    =/  eq=(unit @ud)  (find "=" tok)
    =.  tok  ?~(eq tok (slag +(u.eq) tok))
    =.  tok  ?:(&(?=(^ tok) =('*' i.tok)) t.tok tok)
    ::  (no ?=(^ tok) before levy: a wet gate takes the refined type, and
    ::  its own loop then cannot recurse on the plain tail -- nest-fail %~)
    =/  ok=?
      ?&  !=(~ tok)
          %+  levy  tok
          |=  c=@tD
          ?|  &((gte c 'a') (lte c 'z'))
              &((gte c '0') (lte c '9'))
              =('-' c)
          ==
      ==
    ?.  ok  acc
    =/  name=@ta  `@ta`(crip tok)
    [/[dir]/[name]/hoon acc]
  ?~  l  (flop done)
  ?:  &(=(':' i.l) ?=(^ t.l) =(':' i.t.l))  (flop done)
  ?:  |(=(' ' i.l) =(',' i.l))  $(l t.l, cur ~, acc done)
  $(l t.l, cur [i.l cur])
::
::  every path an app's build reaches, walking imports over one desk from the
::  seeds (its app file).  A memo of imports per path carries across calls:
::  one base serves every host desk compared after a landing.  Paths the
::  desk lacks are not walked -- nothing is here to carry for them.
::  The memo comes back with the set so the next call can reuse it.
++  closure
  |=  $:  our=@p  now=@da  dek=@tas  have=(map path lobe:clay)
          seeds=(list path)  memo=(map path (list path))
      ==
  ^-  [(set path) (map path (list path))]
  =/  bek=path  /(scot %p our)/[dek]/(scot %da now)
  =|  seen=(set path)
  |-  ^-  [(set path) (map path (list path))]
  ?~  seeds  [seen memo]
  ?:  (~(has in seen) i.seeds)  $(seeds t.seeds)
  ?.  (~(has by have) i.seeds)  $(seeds t.seeds)
  =/  deps=(list path)
    =/  m=(unit (list path))  (~(get by memo) i.seeds)
    ?^  m  u.m
    (imports .^(@t %cx (weld bek i.seeds)))
  %=  $
    seeds  (weld deps t.seeds)
    seen   (~(put in seen) i.seeds)
    memo   (~(put by memo) i.seeds deps)
  ==
::
::  every path an agent's build reaches on the desk's newest revision
++  closure-of
  |=  [our=@p now=@da dek=@tas agent=@tas]
  ^-  (set path)
  -:(closure our now dek (path-map-with our now (domes our now) dek) ~[/app/[agent]/hoon] ~)
--
