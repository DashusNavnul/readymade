::  /lib/entity-subject.hoon -- PER-ENTITY SUBJECTS (#3). Authority-by-
::  construction across delegation.
::
::  moon-guardian's clamp judges each ASK: parent law INTERSECT lease ->
::  verdict. This lib moves that intersection UPSTREAM into the medium itself:
::  a delegated entity's subject is BUILT from (parent's granted gates ∩ the
::  lease's allowed tools), sealed on the empty base (nick-medium). So a worker
::  granted {recall} does not get `write` refused -- `write` is -find,
::  unnameable, absent from the very subject its code compiles against. And a
::  lease naming a tool the parent never granted adds NOTHING: the intersection
::  is bounded by the parent's own gates, so a moon can never hold authority
::  its parent could not grant -- by construction, not by check.
::
::  Fail-closed lease discipline (mirrors moon-guardian's clamp): a missing
::  lease, a lease held by someone else, a %pending / %revoked / %expired
::  lease, or an %active lease past its expiry instant all yield the EMPTY gate
::  set -- a subject with no arms at all.
::
::  The expressibility seal is necessary but NOT sufficient (nick-medium's own
::  caveat): a request is data, and [%cap %write ...] can be forged literally.
::  The executor's grant gate (cortex) remains the second lock; what this lib
::  adds is that for a delegated entity the EXECUTOR gate set and the SUBJECT
::  gate set are the same computed intersection -- one truth, two locks.
::
::  COMPUTED -- exact; proven by ph/entity-subject-proof.
::
/-  mg=moon-grant
/+  nick-medium
|%
++  status  ^-(@tas %computed)
::  lease tool names (@t) parsed to medium gates (@tas). A guardian tool name is
::  translated to the medium capability it authorizes (graf-recall -> recall,
::  write-hoon -> write); a name that is already a medium gate passes through; a
::  name that is neither drops (fail-closed -- an unknown lease tool grants no
::  medium capability). This bridges moon-warden's attested-tool namespace to
::  the nick-medium gate namespace so a REAL lease clamps the medium subject.
++  tool-to-gate
  |=  t=@t
  ^-  (unit @tas)
  ?+  t  (slaw %tas t)                          ::  already a medium gate name
    %graf-recall    `%recall
    %write-hoon     `%write
    %graf-inscribe  `%write
  ==
++  tool-gates
  |=  tools=(set @t)
  ^-  (set gate:nick-medium)
  (silt (murn ~(tap in tools) tool-to-gate))
::  is the lease live for this asker at this instant? fail-closed everywhere.
++  lease-live
  |=  [grant=(unit moon-grant:mg) asker=@p now=@da]
  ^-  ?
  ?~  grant  %.n
  ?.  =(asker grantee.u.grant)  %.n
  ?.  =(%active status.u.grant)  %.n
  ::  An explicit zero deadline remains active until the grant is revoked.
  ?:  ?&  ?=(^ expires-at.u.grant)
          !=(0 u.expires-at.u.grant)
          (gte now u.expires-at.u.grant)
      ==
    %.n
  %.y
::  THE INTERSECTION: the delegated gate set. Parent gates ∩ lease tools under
::  a live lease; the empty set otherwise. This IS the moon's action space.
++  moon-gates
  |=  [parent=(set gate:nick-medium) grant=(unit moon-grant:mg) asker=@p now=@da]
  ^-  (set gate:nick-medium)
  ?.  (lease-live grant asker now)  ~
  (~(int in parent) (tool-gates allowed-tools:(need grant)))
::  the delegated subject: sealed (empty base), built from ONLY the
::  intersection. An out-of-lease or out-of-parent capability is not refused
::  here -- it does not exist here.
++  subject-for-moon
  |=  [parent=(set gate:nick-medium) grant=(unit moon-grant:mg) asker=@p now=@da]
  ^-  vase
  (subject-for:nick-medium (moon-gates parent grant asker now))
::  run delegated source in the delegated circle (loop/length guard included).
++  run-as-moon
  |=  $:  parent=(set gate:nick-medium)
          grant=(unit moon-grant:mg)
          asker=@p
          now=@da
          src=@t
      ==
  (run-in-circle:nick-medium (moon-gates parent grant asker now) src)
--
