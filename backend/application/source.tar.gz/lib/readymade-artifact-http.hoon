::  Owner HTTP metadata only. No source work, wire events or execution grants.
/-  c=readymade-collab, j=readymade-collab-jobs, a=readymade-artifact-collab,
    r=readymade-artifact-round, p=readymade-pact
/+  prep=readymade-artifact-prepare, kit=readymade-collab-saved,
    artifact=readymade-artifact-collab, build=readymade-package-build,
    package=readymade-package, round=readymade-artifact-round,
    flow=readymade-collab, owner-actions=readymade-artifact-actions
|%
++  put
  |=  [value=json key=@t entry=json]
  ^-  json
  ?>  ?=(%o -.value)
  [%o (~(put by p.value) key entry)]
++  parties
  |=  [our=@p peer=@p terms=terms:p]
  ^-  ?
  |(&(=(our left.terms) =(peer right.terms)) &(=(peer left.terms) =(our right.terms)))
++  package-peer
  |=  [our=@p peer=@p item=package:c]
  ^-  ?
  =/  offer  offer.value.item
  &((valid:package offer) |(&(=(our sender.body.offer) =(peer recipient.body.offer)) &(=(peer sender.body.offer) =(our recipient.body.offer))))
++  prepare-import
  |=  [our=@p peer=@p cmd=command:c value=saved:kit]
  ^-  (each imported:prep @tas)
  ?.  &(!=(our peer) =('artifact-import' op.cmd) =(owner.cmd (scot %p our)) =(peer.cmd (scot %p peer)))
    [%| %owner-or-peer]
  =/  id=(unit @ux)  (slaw %ux id.cmd)
  =/  proof=(unit @ux)  (slaw %ux digest.cmd)
  ?.  &(?=(^ id) ?=(^ proof))  [%| %explicit-pact-and-proof-required]
  ?.  &((digest-valid:package u.id) (digest-valid:package u.proof) =(id.cmd (scot %ux u.id)) =(digest.cmd (scot %ux u.proof)))
    [%| %noncanonical-pact-or-proof]
  =/  held=(unit agreement:c)  (~(get by pacts.state.value) u.id)
  ?~  held  [%| %unknown-pact]
  ?.  (parties our peer terms.value.u.held)  [%| %pact-peer]
  =/  moved  (import-build:prep our our u.id `@ta`reference.cmd value)
  ?:  ?=(%| -.moved)  [%| p.moved]
  ?.  =(u.proof build-proof.metadata.p.moved)  [%| %build-proof-mismatch]
  moved
++  local-build
  |=  [our=@p peer=@p state=state:c tid=@ta work=job:j index=state:a]
  ^-  (unit json)
  ?.  &(=(%build kind.work) =(%confirmed phase.work))  ~
  ?~  offer.work  ~
  =/  item=(unit package:c)  (~(get by packages.state) u.offer.work)
  ?~  item  ~
  ?.  (package-peer our peer u.item)  ~
  =/  offer  offer.value.u.item
  =/  cmd=command:c  command.work
  ?.  ?&  =(our recipient.body.offer)
          =('build' op.cmd)
          =(owner.cmd (scot %p our))
          =(peer.cmd (scot %p peer))
          (identifier:flow request.cmd)
          =(u.offer.work digest.offer)
          =(id.cmd (scot %ux digest.offer))
          =(digest.cmd id.cmd)
          (digest-valid:package nonce.work)
          =(tid `@ta`(cat 3 'collab-' (scot %ux nonce.work)))
      ==
    ~
  ?~  result.work  ~
  ?.  (lte (met 3 (jam u.result.work)) 131.072)  ~
  =/  parsed
    ((soft ,[%readymade-package-build-v1 offer=@ux nonce=@ux answer=result:build]) u.result.work)
  ?~  parsed  ~
  =/  callback  u.parsed
  ?.  &(=(offer.callback digest.offer) =(nonce.callback nonce.work))  ~
  ?.  ?=(%confirmed -.answer.callback)  ~
  =/  receipt=receipt:build  receipt.answer.callback
  ?.  &(=(nonce.work nonce.plan.body.receipt) (local-valid:artifact our value.u.item receipt))  ~
  =/  evidence=(unit evidence:a)  (~(get by evidence.index) proof.receipt)
  =/  imported=?
    ?~(evidence %.n &(=(builder.u.evidence our) =(%local-canonical provenance.u.evidence) =(receipt receipt.u.evidence)))
  =/  encoded=json
    %-  pairs:enjs:format
    :~  ['tid' s+`@t`tid]
        ['package' s+(scot %ux digest.offer)]
        ['buildProof' s+(scot %ux proof.receipt)]
        ['artifact' s+(scot %ux artifact.body.receipt)]
        ['builder' s+(scot %p our)]
        ['mode' s+'ford-hoon-compile']
        ['imported' b+imported]
        ['metadataOnly' b+%.y]
        ['sharedExecution' b+%.n]
    ==
  `encoded
++  evidence-json
  |=  [proof=@ux entry=evidence:a]
  ^-  json
  %-  pairs:enjs:format
  :~  ['buildProof' s+(scot %ux proof)]
      ['package' s+(scot %ux digest.offer.plan.body.receipt.entry)]
      ['artifact' s+(scot %ux artifact.body.receipt.entry)]
      ['builder' s+(scot %p builder.entry)]
      ['provenance' s+(scot %tas provenance.entry)]
      ['metadataOnly' b+%.y]
      ['sharedExecution' b+%.n]
  ==
++  target-json
  |=  target=target:r
  ^-  json
  ?-  -.target
    %land
      %-  pairs:enjs:format
      :~  ['kind' s+'land']
          ['ship' s+(scot %p ship.target)]
          ['desk' s+(scot %tas desk.target)]
          ['revision' s+(scot %ud revision.target)]
          ['root' s+(scot %ux root.target)]
          ['file' s+(spat file.target)]
      ==
    %publish
      %-  pairs:enjs:format
      :~  ['kind' s+'publish']
          ['ship' s+(scot %p ship.target)]
          ['audience' s+(scot %ux audience.target)]
          ['destination' s+destination.target]
      ==
  ==
++  round-json
  |=  [our=@p current=state:p held=state:r]
  ^-  json
  =/  left=?  =(our left.terms.current)
  =/  candidate=json
    ?~  proposal.held  ~
    =/  value=proposal:r  u.proposal.held
    %-  pairs:enjs:format
    :~  ['digest' s+(scot %ux (digest:round value))]
        ['package' s+(scot %ux package.value)]
        ['artifact' s+(scot %ux artifact.value)]
        ['buildProof' s+(scot %ux build-proof.value)]
        ['receiver' s+(scot %p receiver.value)]
        ['target' (target-json target.value)]
    ==
  %-  pairs:enjs:format
  :~  ['pact' s+(scot %ux pact.held)]
      ['generation' s+(scot %ud generation.held)]
      ['purpose' s+(scot %tas purpose.held)]
      ['round' s+(scot %ud round.held)]
      ['proposal' candidate]
      ['historical' b+!=(generation.held generation.current)]
      ['localAckPresent' b+?:(left ?=(^ left-ack.held) ?=(^ right-ack.held))]
      ['peerAckPresent' b+?:(left ?=(^ right-ack.held) ?=(^ left-ack.held))]
      ['localClosed' b+?:(left left-close.held right-close.held)]
      ['peerClosed' b+?:(left right-close.held left-close.held)]
      ['metadataOnly' b+%.y]
      ['sharedExecution' b+%.n]
  ==
++  snapshot
  |=  [our=@p peer=@p state=state:c ledger=ledger:j index=state:a value=json]
  ^-  json
  ?>  ?=(%o -.value)
  =/  saved=saved:kit  [%readymade-collab-app-v4 state ~ ledger ~ index]
  =/  valid=?  (valid:kit our saved)
  =/  builds=(list json)
    ?.  valid  ~
    %+  murn  ~(tap by ledger)
    |=  row=[tid=@ta work=job:j]
    (local-build our peer state tid.row work.row index)
  =/  evidence=(list json)
    ?.  valid  ~
    %+  murn  ~(tap by evidence.index)
    |=  row=[proof=@ux entry=evidence:a]
    =/  item=(unit package:c)  (~(get by packages.state) digest.offer.plan.body.receipt.entry.row)
    ?~  item  ~
    ?.  (package-peer our peer u.item)  ~
    `(evidence-json proof.row entry.row)
  =/  rounds=(list json)
    ?.  valid  ~
    %+  murn  ~(tap by rounds.index)
    |=  row=[key=key:a held=state:r]
    =/  agreement=(unit agreement:c)  (~(get by pacts.state) pact.key.row)
    ?~  agreement  ~
    ?.  (parties our peer terms.value.u.agreement)  ~
    `(round-json our value.u.agreement held.row)
  =/  metadata=json
    %-  pairs:enjs:format
    :~  ['metadataOnly' b+%.y]
        ['sharedExecution' b+%.n]
        ['available' b+valid]
        ['notice' s+'Build proofs and terms approval do not authorize execution. Execution requires both exact approvals, your current coding grant and Cantrip review. Deployment needs separate permission.']
        ['localBuilds' a+(scag 64 builds)]
        ['evidence' a+(scag 256 evidence)]
        ['rounds' a+(scag 256 rounds)]
        ['limited' b+(gth (lent builds) 64)]
    ==
  =/  caps=json  (need (~(get by p.value) 'capabilities'))
  =/  capability=json
    %-  pairs:enjs:format
    :~  ['available' b+valid]
        ['metadataOnly' b+%.y]
        ['sharedExecution' b+%.n]
        ['reason' s+'Owner-selected canonical local-build metadata import only; grants no approval or execution.']
    ==
  =/  guards=(list json)
    ?.  valid  ~
    %+  murn  ~(tap by pacts.state)
    |=  row=[id=@ux item=agreement:c]
    ?.  (parties our peer terms.value.item.row)  ~
    =/  encoded=json
      %-  pairs:enjs:format
      ^-  (list [@t json])
      :~  ['pact' s+(scot %ux id.row)]
          ['guard' s+(scot %ux (guard:owner-actions our peer id.row saved))]
          ['proposer' s+(scot %p left.terms.value.item.row)]
          ['active' b+&(left-consent.value.item.row right-consent.value.item.row)]
          ['generation' s+(scot %ud generation.value.item.row)]
      ==
    `encoded
  =/  actions=json
    %-  pairs:enjs:format
    ^-  (list [@t json])
    :~  ['schema' s+'readymade-artifact-owner-actions-v1']
        ['owner' s+(scot %p our)]
        ['peer' s+(scot %p peer)]
        ['guards' a+guards]
        ['sharedExecution' b+%.n]
    ==
  =/  caps  (put caps 'artifact-import' capability)
  =.  caps  (put caps 'artifact-negotiation' (put capability 'reason' s+'Proof sharing and artifact approval are separate from a request to execute. Deployment needs separate permission.'))
  (put (put value 'capabilities' caps) 'artifacts' (put metadata 'ownerActions' actions))
--
