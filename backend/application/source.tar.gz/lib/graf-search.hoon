::  /lib/graf-search.hoon
::
::  Graf search (Model A): a query is a PATTERN -- a fact with holes. You fire a
::  BATCH of patterns and get back every lit fact matching ANY of them.
::
::  A pattern mirrors a fact's noun shape:
::    [%any ~]        a hole -- matches anything at this position
::    [%is p=*]       matches exactly this noun
::    [%cell l r]     matches a cell whose head matches l and tail matches r
::  `tup` builds a right-nested tuple pattern, so [%loom-turn _ _] is
::  (tup ~[(is %loom-turn) any any]).
::
::  CONTRACT: `search s pats` = { f in s | some p in pats, (match p f) }.
::  This first cut is the correct REFERENCE (scan the lit facts, test the batch).
::  The Aho-Corasick engine that fires all patterns in ONE simultaneous pass --
::  "infinitely free to run at the same time" -- slots in behind this exact
::  contract next, changing the mechanism, not the meaning.
::
/+  graf-substrate
=,  graf-substrate
|%
+$  pat
  $~  [%any ~]
  $%  [%any ~]
      [%is p=*]
      [%cell l=pat r=pat]
  ==
::
++  any  `pat`[%any ~]                         ::  a hole
++  is   |=(p=* `pat`[%is p])                  ::  an exact leaf
++  tup                                        ::  right-nested tuple pattern
  |=  l=(list pat)
  ^-  pat
  ?~  l  any
  ?~  t.l  i.l
  [%cell i.l $(l t.l)]
::
++  match                                      ::  does one fact match one pattern?
  |=  [=pat =fact]
  ^-  ?
  ?-  -.pat
    %any   &
    %is    =(p.pat fact)
    %cell  ?@  fact  |
           ?&  $(pat l.pat, fact -.fact)
               $(pat r.pat, fact +.fact)
           ==
  ==
::
++  hits                                       ::  does any pattern in the batch match?
  |=  [pats=(list pat) =fact]
  ^-  ?
  (lien pats |=(=pat (match pat fact)))
::
++  search                                      ::  fire a batch -> all lit facts matching ANY
  |=  [s=store pats=(list pat)]
  ^-  (set fact)
  %-  ~(gas in *(set fact))
  (skim (facts s) |=(=fact (hits pats fact)))
--
