::  Mechanical Nat operations for the exact compiler profile. No parsing,
::  linking, type judgments or source authority. Work uses 64-bit word units.
::  Compiler.gls semantics: saturating sub; div/mod by zero both return zero.
::  Historical execution is limited to 32768 packed bytes. Attachment v2
::  admits up to 1 MiB intermediates; both paths charge before allocation.
|%
++  bits  262.144
++  attachment-bits  8.388.608
++  first
  |=  op=@tas
  ^-  @ud
  ?:  ?=(?(%lt %add %sub %mul %div %mod %shr %shl) op)  1
  0
++  unary
  |=  op=@tas
  ^-  ?
  ?=(?(%pow %bytes %inc) op)
++  short
  ::  These results do not demand the other operand in the original law.
  |=  [op=@tas n=@ud]
  ^-  ?
  &(=(0 n) ?=(?(%lt %lte %mul %div %mod %and) op))
++  run
  |=  [op=@tas a=@ud b=@ud fuel=@ud]
  ^-  (each [remaining=@ud value=@ud] @tas)
  (run-bounded op a b fuel bits)
++  run-bounded
  |=  [op=@tas a=@ud b=@ud fuel=@ud limit=@ud]
  ^-  (each [remaining=@ud value=@ud] @tas)
  ?.  |(=(limit bits) =(limit attachment-bits))
    [%| %compiler-arithmetic-limit]
  ?.  ?=(?(%eq %lt %lte %add %sub %mul %div %mod %and %or %shr %shl %pow %bytes %inc) op)
    [%| %compiler-arithmetic-operation]
  ?.  &((lte (met 0 a) limit) (lte (met 0 b) limit))
    [%| %compiler-arithmetic-bound]
  =/  wa=@ud  (max 1 (met 6 a))
  =/  wb=@ud  (max 1 (met 6 b))
  =/  cost=@ud  +((add wa wb))
  ?:  ?=(?(%shl %shr) op)
    ?.  (lte b limit)  [%| %compiler-shift-bound]
    ?:  &(?=(%shl op) !=(0 a) (gth (add (met 0 a) b) limit))
      [%| %compiler-arithmetic-bound]
    =.  cost  (add cost (div +(b) 64))
    ?:  (lth fuel cost)  [%| %fuel-exhausted]
    [%& (sub fuel cost) ?:(=(%shl op) (lsh [0 b] a) (rsh [0 b] a))]
  ?:  =(%pow op)
    ?.  (lth a limit)  [%| %compiler-shift-bound]
    =.  cost  (add cost +((div a 64)))
    ?:  (lth fuel cost)  [%| %fuel-exhausted]
    [%& (sub fuel cost) (lsh [0 a] 1)]
  =.  cost  ?:(?=(?(%mul %div %mod) op) (add cost (mul wa wb)) cost)
  ::  Check a product's possible size before allocating it. One extra bit
  ::  is allowed through this preflight and checked exactly after evaluation.
  ?:  &(?=(%mul op) !=(0 a) !=(0 b) (gth (add (met 0 a) (met 0 b)) +(limit)))
    [%| %compiler-arithmetic-bound]
  ?:  (lth fuel cost)  [%| %fuel-exhausted]
  =/  value=@ud
    ?+  op  !!
      %eq  ?:(=(a b) 1 0)
      %lt  ?:((lth a b) 1 0)
      %lte  ?:((lte a b) 1 0)
      %add  (add a b)
      %sub  (sub a (min a b))
      %mul  (mul a b)
      %div  ?:(=(0 b) 0 (div a b))
      %mod  ?:(=(0 b) 0 (mod a b))
      %and  (dis a b)
      %or  (con a b)
      %bytes  (met 3 a)
      %inc  +(a)
    ==
  ?.  (lte (met 0 value) limit)  [%| %compiler-arithmetic-bound]
  [%& (sub fuel cost) value]
--
