::  Canonical reads AFTER the owning Cantrip agent receives its Viki event.
::  This helper never accepts a Graf intake digest as historical Viki authority
::  and never sends cards. The future handler supplies its current law window.
/-  ci=vibecoding-connected-intake
/+  core=cantrip-connected-write, intake=viki-connected-intake,
    review=cantrip-vibecoding-connected-review,
    history=vibecoding-check-context-read, project=vibecoding-project-read,
    editor=cantrip-editor-save, read=cantrip-editor-save-read,
    law=cantrip-law-window, vcl=vibecoding-candidate
|%
++  recheck
  |=  [our=@p actor=@p now=@da r=record:ci window=window:law]
  ^-  (each view:core @tas)
  ?.  =(our actor)  [%| %foreign-actor]
  ?.  &((valid:intake r) =(our owner.body.review.body.r))  [%| %intake-invalid]
  =/  rows  (history:history our actor now)
  ?:  ?=(%| -.rows)  [%| p.rows]
  =/  candidate  candidate.body.review.body.r
  ?.  .^(? %gx /(scot %p our)/graf/(scot %da now)/contains/(scot %uw (jam (packet-fact:vcl packet.candidate)))/noun)
    [%| %packet-not-retained]
  =/  context  (context-of:vcl packet.candidate)
  =/  checked
    (judge:review our actor now candidate p.rows (intent:history our now id.intent.intent.context) (read:project our actor now) window)
  ?:  ?=(%| -.checked)  [%| p.checked]
  =/  basis  (read:read our actor now)
  ?:  ?=(%| -.basis)  [%| p.basis]
  [%& [p.checked p.basis]]
++  receive
  ::  Validate pending wire, endpoint, phase and event before canonical reads.
  ::  The endpoint argument is supplied from Cantrip's own watch, never a poke.
  |=  [our=@p actor=@p now=@da held=ledger:core saves=ledger:editor source=[ship=@p agent=@tas] w=wire sign=sign:agent:gall window=window:law]
  ^-  result:core
  ?.  =(our actor)  [%| %foreign-actor]
  =/  pending  (lookup:core our now held saves source w)
  ?:  ?=(%| -.pending)  [%| p.pending]
  =/  received  (event-for:core p.pending now sign)
  ?:  ?=(%| -.received)  [%| p.received]
  =/  current  (recheck our actor now p.received window)
  ?:  ?=(%| -.current)  [%| p.current]
  (receive:core our now held saves source w sign p.current)
++  recheck-v2
  ::  Complete provider-v2 receipt, current approved packet and native basis.
  ::  No self-scry: the future Cantrip owner hook supplies its current window.
  |=  [our=@p actor=@p now=@da r=record-v2:ci window=window:law]
  ^-  (each view-v2:core @tas)
  ?.  =(our actor)  [%| %foreign-actor]
  ?.  &((valid-v2:intake r) =(our owner.body.review.body.r))  [%| %intake-invalid]
  =/  rows  (history:history our actor now)
  ?:  ?=(%| -.rows)  [%| p.rows]
  =/  candidate  candidate.body.review.body.r
  =/  packet  packet.candidate
  =/  fact=*  [%vibecoding-candidate-packet (scot %ux (digest:vcl packet)) packet]
  ?.  .^(? %gx /(scot %p our)/graf/(scot %da now)/contains/(scot %uw (jam fact))/noun)
    [%| %packet-not-retained]
  =/  context  context.packet
  =/  checked
    (judge-v2:review our actor now candidate p.rows (intent:history our now id.intent.intent.context) (read:project our actor now) window)
  ?:  ?=(%| -.checked)  [%| p.checked]
  =/  basis  (read:read our actor now)
  ?:  ?=(%| -.basis)  [%| p.basis]
  [%& [p.checked p.basis]]
++  receive-v2
  |=  [our=@p actor=@p now=@da legacy=ledger:core held=ledger-v2:core saves=ledger:editor source=[ship=@p agent=@tas] w=wire sign=sign:agent:gall window=window:law]
  ^-  result-v2:core
  ?.  =(our actor)  [%| %foreign-actor]
  =/  pending  (lookup-v2:core our now legacy held saves source w)
  ?:  ?=(%| -.pending)  [%| p.pending]
  =/  received  (event-for-v2:core p.pending now sign)
  ?:  ?=(%| -.received)  [%| p.received]
  =/  current  (recheck-v2 our actor now p.received window)
  ?:  ?=(%| -.current)  [%| p.current]
  (receive-v2:core our now legacy held saves source w sign p.current)
--
