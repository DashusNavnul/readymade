:: Pure reservation-release contract extracted from canonical Cantrip87.
:: Native readers authenticate the parent journal, pending ticket and failure.
:: Pure evidence consistency grants no authority; the outcome stays unknown.
/-  worker=native-coding-worker
/+  accept=native-coding-accept, worker-law=native-coding-worker
|%
++  check
  ::  Preserve the legacy two-reason API for existing callers and receipts.
  |=  [our=@p at=@da r=record:accept key=@ux job=record:worker]
  ^-  ?
  &(|(=(`%worker-deadline reason.r) =(`%worker-source-changed reason.r)) (evidence our at r key job))
++  evidence
  ::  The native runtime must also correlate the actual parent's retained
  ::  failure. Deadline refusal does not prove computation stopped or never ran.
  |=  [our=@p at=@da r=record:accept key=@ux job=record:worker]
  ^-  ?
  ?.  ?&  =(%unknown stage.r)  (released-worker-reason:accept reason.r)
          ?=(^ staging.r)  ?=(~ report.r)  ?=(~ decision.r)  ?=(~ landed.r)
          sent.job  ?=(^ result.job)
      ==  %.n
  =/  o=order:worker  order.job
  =/  result=result:worker  u.result.job
  =/  normal=@ux
    (digest:accept [%native-coding-check-ticket-v1 r(stage %checking, reason ~)])
  =/  retry=@ux
    (digest:accept [%native-coding-check-ticket-v1 r(stage %checking, reason `%candidate-recheck)])
  ?&  =(our owner.pairing.o)  =(our owner.source.context.candidate.r)
      =((digest:worker-law o) key)  (result-matches:worker-law o result)
      ?=(%refused -.outcome.result)
      =(%worker-deadline-unconfirmed reason.outcome.result)
      (lte deadline.o finished.result)  (lte finished.result at)
      =(id.candidate.r candidate.o)  =(grant.r grant.o)
      =(context.candidate.r context.o)
      =(revision.u.staging.r source.o)
      =((namespace-digest:worker-law files.body.snapshot.u.staging.r) namespace.o)
      =((required:accept project.r candidate.r) targets.o)
      |(=(normal ticket.o) =(retry ticket.o))
  ==
--
