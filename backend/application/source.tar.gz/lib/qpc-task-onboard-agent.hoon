::  Owner wrapper for one-event task onboarding. The registration and the
::  adjudication cases are applied in the command event by trial of the
::  inner agent; the two standing grants go to Cantrip; on both
::  acknowledgments the ledger is re-read and the paused baseline session is
::  opened. Every refusal names its cause and leaves a %failed record.
::  Sits above the campaign owner, so its thirteen inner parts stay as they are.
/-  nc=native-coding
/+  onboard=qpc-task-onboard, contract=cantrip-native-coding-contract,
    project=native-coding-project, instrument=qpc-instrument-contract,
    observer=qpc-observer, loop=native-coding-loop, q=qpc-native-outcome,
    guard=viki-scry-guard, sessions=native-coding-session,
    campaign=qpc-native-campaign, handoff=qpc-native-task-handoff-runtime,
    kernel=qpc-native-task-handoff, completed=qpc-native-task-completion
|%
+$  command  [%qpc-task-onboard-v1 d=description:onboard]
+$  arming
  $%  [%qpc-task-arm-v1 seed=@ux prior=@ux]
      [%qpc-task-activate-v1 seed=@ux]
      [%qpc-task-enqueue-v1 d=description:onboard]
      [%qpc-task-resume-v1 ~]
  ==
+$  trial  (each (quip card:agent:gall agent:gall) tang)
++  wrap
  |=  inner=agent:gall
  =/  held=state:onboard  empty:onboard
  ^-  agent:gall
  |_  =bowl:gall
  +*  this  .
      ag  ~(. inner bowl)
      refuse
        |=  [id=@ux reason=@tas]
        ^-  (quip card:agent:gall _this)
        =.  held  (fail:onboard held id reason)
        [~[(refused:loop id reason)] this]
      ledger
        ^-  (unit organ:contract)
        ?.  (agent-live:guard our.bowl now.bowl %cantrip)  ~
        %-  (soft organ:contract)
        .^(* %gx /(scot %p our.bowl)/cantrip/(scot %da now.bowl)/native-coding/tool-state/noun)
      projects-of
        |=  agent=agent:gall
        ^-  (unit (map @t project:nc))
        =/  raw  (raw:instrument agent bowl /x/native-coding/projects)
        ?~  raw  ~
        ((soft (map @t project:nc)) u.raw)
      used
        ^-  (unit (set @ux))
        =/  raw  (raw:instrument inner bowl /x/native-coding/local-used-sessions)
        ?~  raw  ~
        ((soft (set @ux)) u.raw)
      session-ids
        ^-  (unit (set @ux))
        =/  raw  (raw:instrument inner bowl /x/native-coding/sessions)
        ?~  raw  ~
        =/  rows  ((soft ,(list [session=session:nc rest=*])) u.raw)
        ?~  rows  ~
        `(silt (turn u.rows |=(r=[session=session:nc rest=*] id.session.r)))
      refusal-in
        ::  The inner loop reports its refusals as facts, never as crashes.
        |=  cards=(list card:agent:gall)
        ^-  (unit @tas)
        |-
        ?~  cards  ~
        =/  got  ((soft ,[%give %fact (list path) %noun p=* q=*]) i.cards)
        ?~  got  $(cards t.cards)
        =/  fact  ((soft ,[%native-coding-refused-v1 id=@ux reason=@tas]) q.u.got)
        ?~  fact  $(cards t.cards)
        `reason.u.fact
      try
        ::  Typed vases: the observer extracts its command with !<, so a
        ::  noun-typed vase is refused there (measured 2026-11-01, smoke test).
        |=  [agent=agent:gall payload=vase]
        ^-  trial
        (mule |.((on-poke:~(. agent bowl(src our.bowl)) %noun payload)))
      begin
        |=  d=description:onboard
        ^-  (quip card:agent:gall _this)
        =/  live  (projects-of inner)
        ?~  live  (refuse 0x0 %onboard-projects-unavailable)
        =/  old  (~(get by u.live) project.d)
        ?~  old  (refuse 0x0 %onboard-project-unregistered)
        =/  source  (current:project our.bowl now.bowl u.old)
        ?:  ?=(%| -.source)  (refuse 0x0 p.source)
        =/  built  (build:onboard our.bowl u.old revision.working.p.source d)
        ?:  ?=(%| -.built)  (refuse 0x0 p.built)
        =/  p=plan:onboard  p.built
        =/  id=@ux  seed.identities.p
        ::  From here a refusal is readable: the plan is recorded %failed under
        ::  its seed with the reason (the nonce is spent; retry with a new one).
        =/  bail
          |=  reason=@tas
          ^-  (quip card:agent:gall _this)
          =.  held  ?:((~(has by records.held) id) held (start:onboard held p now.bowl task.d artifact.d))
          (refuse id reason)
        =/  grants  ledger
        ?~  grants  (bail %onboard-ledger-unavailable)
        =/  local  used
        ?~  local  (bail %onboard-used-sessions-unavailable)
        =/  open-ids  session-ids
        ?~  open-ids  (bail %onboard-sessions-unavailable)
        =/  admitted  (admit:onboard p u.grants u.local u.open-ids u.live held)
        ?^  admitted  (refuse id u.admitted)
        ::  registration, by trial of the inner agent in this event
        =/  first=trial  (try inner !>([%native-coding-action-v1 [%register project.p]]))
        ?:  ?=(%| -.first)  (bail %onboard-register-crashed)
        =/  why  (refusal-in -.p.first)
        ?^  why  (bail u.why)
        =/  registered  (projects-of +.p.first)
        ?~  registered  (bail %onboard-register-unconfirmed)
        ?.  =(`project.p (~(get by u.registered) project.d))
          (bail %onboard-register-unconfirmed)
        ::  cases, by trial of the registered inner agent
        =/  second=trial  (try +.p.first !>([%qpc-observe-cases-v1 cases.p]))
        ?:  ?=(%| -.second)  (bail %onboard-cases-refused)
        =/  stored  (raw:instrument +.p.second bowl /x/qpc/cases/(scot %ux (digest:q cases.p)))
        ?~  stored  (bail %onboard-cases-unconfirmed)
        ::  the observer answers (unit cases); the soft cast wraps it once more
        ?.  =(``cases.p ((soft ,(unit cases:q)) u.stored))  (bail %onboard-cases-unconfirmed)
        ::  Gall commits both applied changes and this record before the two
        ::  grant pokes leave; their acknowledgments continue in +on-agent.
        =.  held  (start:onboard held p now.bowl task.d artifact.d)
        =.  inner  +.p.second
        =/  route=path  /qpc-onboard/(scot %ux id)
        =/  requested=(list card:agent:gall)
          :~  (poke:loop our.bowl %cantrip (weld route /baseline) [%native-coding-grant-v1 baseline.p])
              (poke:loop our.bowl %cantrip (weld route /member) [%native-coding-grant-v1 member.p])
              [%give %fact ~[/native-coding] %noun !>([%qpc-task-onboard-started-v1 id identities.p])]
          ==
        :_  this
        :(weld -.p.first -.p.second requested)
      open
        |=  id=@ux
        ^-  (quip card:agent:gall _this)
        =/  found  (~(get by records.held) id)
        ?~  found  (refuse id %onboard-record-missing)
        =/  p=plan:onboard  plan.u.found
        =/  grants  ledger
        ?~  grants  (refuse id %onboard-ledger-unavailable)
        ?.  (granted:onboard p u.grants)  (refuse id %onboard-grants-unconfirmed)
        =/  o=opening:onboard  opening.p
        =/  third=trial
          %+  try  inner
          !>([%native-coding-action-v1 [%open-paused id.o project.o objective.o selection.o key.o grant.o worker.o expected.o]])
        ?:  ?=(%| -.third)  (refuse id %onboard-open-crashed)
        =/  why  (refusal-in -.p.third)
        ?^  why  (refuse id u.why)
        =/  actual  (input:observer +.p.third bowl id.o)
        ?~  actual  (refuse id %onboard-open-unconfirmed)
        =/  e=entry:sessions  entry.u.actual
        ?.  ?&  =(key.o key.u.actual)  =(grant.o grant.u.actual)
                =(%paused phase.e)  =(0 turn.e)  =(id.o id.session.e)
            ==
          (refuse id %onboard-open-unconfirmed)
        =/  done  (opened:onboard held id)
        ?:  ?=(%| -.done)  (refuse id p.done)
        =.  held  p.done
        =.  inner  +.p.third
        :_  this
        %+  weld  -.p.third
        ^-  (list card:agent:gall)
        ~[[%give %fact ~[/native-coding] %noun !>([%qpc-task-onboard-opened-v1 id identities.p])]]
      campaigns
        ^-  (unit state:campaign)
        =/  raw  (raw:instrument inner bowl /x/qpc/campaigns)
        ?~  raw  ~
        ((soft state:campaign) u.raw)
      tool-record
        |=  key=@ux
        ^-  (unit record:contract)
        =/  grants  ledger
        ?~  grants  ~
        (~(get by records.u.grants) key)
      execute-key
        ::  the loop's terminal command leaves one execute poke on /native-coding/tool/<key>
        |=  cards=(list card:agent:gall)
        ^-  (unit @ux)
        |-
        ?~  cards  ~
        ?:  ?=([%pass [%native-coding %tool @ ~] %agent * %poke *] i.cards)
          (slaw %ux i.t.t.p.i.cards)
        $(cards t.cards)
      arm
        ::  Start the authenticated baseline check on the opened baseline session.
        |=  [id=@ux prior=@ux]
        ^-  (quip card:agent:gall _this)
        =/  found  (~(get by records.held) id)
        ?~  found  (refuse id %onboard-record-missing)
        ?.  =(%opened phase.u.found)  (refuse id %onboard-not-opened)
        =/  p=plan:onboard  plan.u.found
        =/  held-campaigns  campaigns
        ?~  held-campaigns  (refuse id %onboard-campaigns-unavailable)
        =/  old  (~(get by records.u.held-campaigns) prior)
        ?~  old  (refuse id %onboard-prior-missing)
        ?.  &(=(%awaiting-next-task phase.u.old) =(`%qpc-task-completed reason.u.old))  (refuse id %onboard-prior-unsettled)
        ::  The law and manifest bind one stream to one project (2026-11-01).
        ?.  =(id.spec.project.p project.manifest.plan.snapshot.task.u.old)  (refuse id %onboard-prior-other-project)
        ?:  =(~ artifact.u.found)  (refuse id %onboard-artifact-unknown)
        =/  source  (current:project our.bowl now.bowl project.p)
        ?:  ?=(%| -.source)  (refuse id p.source)
        ?.  =(expected.opening.p revision.working.p.source)  (refuse id %onboard-source-changed)
        =/  trial  (try inner !>((check-command:onboard p revision.working.p.source)))
        ?:  ?=(%| -.trial)  (refuse id %onboard-check-crashed)
        =/  why  (refusal-in -.p.trial)
        ?^  why  (refuse id u.why)
        =/  key  (execute-key -.p.trial)
        ?~  key  (refuse id %onboard-check-not-dispatched)
        =/  next  (check-started:onboard held id u.key)
        ?:  ?=(%| -.next)  (refuse id p.next)
        =.  held  p.next
        =.  inner  +.p.trial
        :_  this
        %+  weld  -.p.trial
        ^-  (list card:agent:gall)
        :~  [%give %fact ~[/native-coding] %noun !>([%qpc-task-check-started-v1 id u.key prior])]
            [%pass /qpc-onboard/check-watch/(scot %ux id) %arvo %b %wait (add now.bowl ~m5)]
        ==
      settle
        ::  After Cantrip's result for the check: derive the next campaign from the
        ::  prior and hand off through the campaign owner's own command.
        |=  [id=@ux prior=@ux]
        ^-  (quip card:agent:gall _this)
        =/  found  (~(get by records.held) id)
        ?~  found  (refuse id %onboard-record-missing)
        ?.  &(=(%checking phase.u.found) ?=(^ check.u.found))  (refuse id %onboard-not-checking)
        =/  p=plan:onboard  plan.u.found
        =/  rec  (tool-record u.check.u.found)
        ?~  rec  [~ this]
        ?:  ?=(?(%running %unknown) stage.u.rec)  [~ this]
        ?.  &(=(%finished stage.u.rec) ?=(^ result.u.rec))  (refuse id %onboard-check-not-finished)
        =/  held-campaigns  campaigns
        ?~  held-campaigns  (refuse id %onboard-campaigns-unavailable)
        =/  old  (~(get by records.u.held-campaigns) prior)
        ?~  old  (refuse id %onboard-prior-missing)
        =/  source  (current:project our.bowl now.bowl project.p)
        ?:  ?=(%| -.source)  (refuse id p.source)
        =/  working=revision:nc  revision.working.p.source
        =/  next=command:campaign  (next-command:onboard command.task.u.old p u.check.u.found working objective.opening.p)
        =/  plan=plan:instrument  (next-plan:onboard plan.snapshot.task.u.old p label.u.found objective.opening.p artifact.u.found)
        =/  retained  (raw:instrument inner bowl /x/native-coding/task-completion/(scot %ux member.command.task.u.old))
        ?~  retained  (refuse id %onboard-prior-completion-unavailable)
        =/  receipt  ((soft ,(each * @tas)) u.retained)
        ?~  receipt  (refuse id %onboard-prior-completion-invalid)
        ?:  ?=(%| -.u.receipt)  (refuse id p.u.receipt)
        =/  expected=@ux  (digest:completed p.u.receipt)
        =/  ran  (checked:onboard held id)
        ?:  ?=(%| -.ran)  (refuse id p.ran)
        =.  held  p.ran
        =/  trial  (try inner !>([%qpc-native-task-handoff-prepare-v1 prior next plan expected]))
        ?:  ?=(%| -.trial)  (refuse id %onboard-handoff-crashed)
        =/  why  (refusal-in -.p.trial)
        ?^  why  (refuse id u.why)
        =/  after-campaigns
          =/  raw  (raw:instrument +.p.trial bowl /x/qpc/campaigns)
          ?~  raw  ~
          ((soft state:campaign) u.raw)
        ?~  after-campaigns  (refuse id %onboard-campaigns-unavailable)
        =/  made  (~(get by records.u.after-campaigns) id.next)
        ?~  made  (refuse id %onboard-handoff-unconfirmed)
        ?.  (prepared:campaign u.made)  (refuse id %onboard-handoff-unconfirmed)
        =/  done  (handing:onboard held id)
        ?:  ?=(%| -.done)  (refuse id p.done)
        =.  held  p.done
        =.  inner  +.p.trial
        :_  this
        %+  weld  -.p.trial
        ^-  (list card:agent:gall)
        ~[[%give %fact ~[/native-coding] %noun !>([%qpc-task-handing-v1 id id.next])]]
      confirm
        ::  Graf has retained the handoff proposal: record the task and handoff
        ::  digests the activation command will carry.
        |=  id=@ux
        ^-  (quip card:agent:gall _this)
        =/  found  (~(get by records.held) id)
        ?~  found  [~ this]
        ?.  =(%handing phase.u.found)  [~ this]
        =/  next=@ux  campaign.identities.plan.u.found
        =/  held-campaigns  campaigns
        ?~  held-campaigns  [~ this]
        =/  made  (~(get by records.u.held-campaigns) next)
        ?~  made  [~ this]
        =/  retained  (retained:handoff bowl next)
        ?:  ?=(%| -.retained)  [~ this]
        =/  task=@ux  (task-digest:campaign u.made)
        =/  handoff-hash=@ux  (digest:kernel p.retained)
        =/  done  (prepared:onboard held id task handoff-hash)
        ?:  ?=(%| -.done)  (refuse id p.done)
        =.  held  p.done
        [~[[%give %fact ~[/native-coding] %noun !>([%qpc-task-prepared-v1 id next task handoff-hash])]] this]
      prior-of
        ::  The latest completed campaign is the prior the handover law accepts.
        |=  p=plan:onboard
        ^-  (unit @ux)
        =/  held-campaigns  campaigns
        ?~  held-campaigns  ~
        =/  settled=(list [id=@ux r=record:campaign])
          %+  skim  ~(tap by records.u.held-campaigns)
          |=  [id=@ux r=record:campaign]
          ?&  =(%awaiting-next-task phase.r)  =(`%qpc-task-completed reason.r)
              =(id.spec.project.p project.manifest.plan.snapshot.task.r)
          ==
        =/  best=(unit [id=@ux at=@da])  ~
        |-  ^-  (unit @ux)
        ?~  settled  ?~(best ~ `id.u.best)
        =/  row  i.settled
        =.  best
          ?~  best  `[id.row at.task.r.row]
          ?:((gth at.task.r.row at.u.best) `[id.row at.task.r.row] best)
        $(settled t.settled)
      activate
        |=  id=@ux
        ^-  (quip card:agent:gall _this)
        =/  found  (~(get by records.held) id)
        ?~  found  (refuse id %onboard-record-missing)
        ?.  &(=(%prepared phase.u.found) ?=(^ handoff.u.found))  (refuse id %onboard-not-prepared)
        =/  p=plan:onboard  plan.u.found
        =/  trial  (try inner !>([%qpc-native-campaign-activate-v1 campaign.identities.p task.u.handoff.u.found handoff.u.handoff.u.found]))
        ?:  ?=(%| -.trial)  (refuse id %onboard-activate-crashed)
        =/  why  (refusal-in -.p.trial)
        ?^  why  (refuse id u.why)
        =/  done  (activated:onboard held id)
        ?:  ?=(%| -.done)  (refuse id p.done)
        =.  held  p.done
        =.  inner  +.p.trial
        :_  this
        %+  weld  -.p.trial
        ^-  (list card:agent:gall)
        ~[[%give %fact ~[/native-coding] %noun !>([%qpc-task-activated-v1 id campaign.identities.p])]]
      campaign-busy
        ::  Unreadable campaigns count as busy: never start on a guess.
        ^-  ?
        =/  held-campaigns  campaigns
        ?~  held-campaigns  %.y
        %+  lien  ~(val by records.u.held-campaigns)
        |=(r=record:campaign ?=(?(%opening %collecting %deciding %gating %profile %pool) phase.r))
      tend-card
        |=  id=@ux
        ^-  card:agent:gall
        [%pass /qpc-onboard/tend/(scot %ux id) %arvo %b %wait (add now.bowl ~m1)]
      session-ready
        ::  The cheap read that keeps the proposal's full snapshot read off this
        ::  tick until the member has actually finished.
        |=  member=@ux
        ^-  ?
        =/  raw  (raw:instrument inner bowl /x/native-coding/qpc-input/(scot %ux member))
        ?~  raw  %.n
        =/  input  ((soft ,(unit [entry=entry:sessions key=@tas grant=@ux])) u.raw)
        ?.  ?=([~ ~ *] input)  %.n
        &(=(%paused phase.entry.u.u.input) =(%ready resume.entry.u.u.input))
      dead-review
        ::  A review with a reason and no decision never moves by itself.
        |=  member=@ux
        ^-  (unit [candidate=@ux reason=@tas retry=(unit @ux) unread=?])
        =/  raw  (raw:instrument inner bowl /x/native-coding/local-review/dead/(scot %ux member))
        ?~  raw  ~
        =/  rows  ((soft ,(list [candidate=@ux reason=@tas retry=(unit @ux) unread=?])) u.raw)
        ?~  rows  ~
        ?~  u.rows  ~
        `i.u.rows
      halt
        |=  [id=@ux why=@tas]
        ^-  (quip card:agent:gall _this)
        =.  held  held(halted `[id why], queued (~(del in queued.held) id))
        [~[[%give %fact ~[/native-coding] %noun !>([%qpc-task-queue-halted-v1 id why])]] this]
      check-lost
        ::  Cantrip records a tool request in the event that receives it, so a
        ::  %checking record whose check it does not hold will never settle
        ::  (2026-11-02: `line-column` waited 27 minutes in silence). Failing it by
        ::  name lets the queue halt and be resumed; nothing is resent.
        |=  id=@ux
        ^-  ?
        =/  r  (~(get by records.held) id)
        ?~  r  %.n
        ?.  =(%checking phase.u.r)  %.n
        ?~  check.u.r  %.n
        =(~ (tool-record u.check.u.r))
      advance
        ::  One step per event; free when the queue is idle. Grants and sessions
        ::  are lifetime stores, so a failure halts rather than spends the next.
        ^-  (quip card:agent:gall _this)
        ?:  &(=(~ queue.held) =(~ queued.held))  [~ this]
        ?.  =(~ halted.held)  [~ this]
        =/  mine=(list [id=@ux r=record:onboard])
          (turn ~(tap in queued.held) |=(id=@ux [id (~(got by records.held) id)]))
        =/  at-phase
          |=  want=phase:onboard
          ^-  (list [id=@ux r=record:onboard])
          (skim mine |=([id=@ux r=record:onboard] =(want phase.r)))
        =/  failed  (at-phase %failed)
        ?^  failed  (halt id.i.failed (fall reason.r.i.failed %onboard-queue-failed))
        =/  opened  (at-phase %opened)
        ?^  opened
          =/  id=@ux  id.i.opened
          =/  prior  (prior-of plan.r.i.opened)
          ?~  prior  (halt id %onboard-queue-no-prior)
          =^  cards  this  (arm id u.prior)
          =/  after  (~(get by records.held) id)
          ?.  &(?=(^ after) =(%opened phase.u.after))  [cards this]
          =^  more  this  (halt id %onboard-queue-arm-refused)
          [(weld cards more) this]
        =/  prepared  (at-phase %prepared)
        ?^  prepared
          =/  id=@ux  id.i.prepared
          =^  cards  this  (activate id)
          =/  after  (~(get by records.held) id)
          ?.  &(?=(^ after) =(%prepared phase.u.after))  [[(tend-card id) cards] this]
          =^  more  this  (halt id %onboard-queue-activate-refused)
          [(weld cards more) this]
        ?.  =(~ queued.held)  [~ this]
        ?:  campaign-busy  [~ this]
        =/  [next=(unit description:onboard) after=state:onboard]  (dequeue:onboard held)
        ?~  next  [~ this]
        =.  held  after
        =/  before  ~(key by records.held)
        =^  cards  this  (begin u.next)
        =/  new  ~(tap in (~(dif in ~(key by records.held)) before))
        ?~  new
          =^  more  this  (halt 0x0 %onboard-queue-begin-refused)
          [(weld cards more) this]
        =.  held  held(queued (~(put in queued.held) i.new))
        [cards this]
      tend
        ::  One minute's watch over the queue's running task, ending when its
        ::  campaign settles. Enqueueing authorized the whole task, and the
        ::  proposal exists only after independent approval, a landing and passed
        ::  protected checks, so the owner completes it on that exact proposal.
        |=  id=@ux
        ^-  (quip card:agent:gall _this)
        ?.  (~(has in queued.held) id)  [~ this]
        =/  found  (~(get by records.held) id)
        ?~  found  [~ this]
        ?.  =(%activated phase.u.found)  [~ this]
        =/  ids=identities:onboard  identities.plan.u.found
        =/  held-campaigns  campaigns
        ?~  held-campaigns  [~[(tend-card id)] this]
        =/  c  (~(get by records.u.held-campaigns) campaign.ids)
        ?~  c  (halt id %onboard-queue-campaign-missing)
        ?:  ?=(?(%stopped %unknown) phase.u.c)
          (halt id (fall reason.u.c %onboard-queue-campaign-failed))
        ?:  =(%awaiting-next-task phase.u.c)
          =.  held  held(queued (~(del in queued.held) id))
          advance
        =/  dead  ?.(=(%collecting phase.u.c) ~ (dead-review member.ids))
        ?^  dead
          ?:  &(?=(~ retry.u.dead) !unread.u.dead)  (halt id reason.u.dead)
          :_  this
          :~  (tend-card id)
              :*  %pass  /qpc-onboard/review-exit/(scot %ux id)  %agent  [our.bowl dap.bowl]  %poke  %noun
                  ?~  retry.u.dead  !>([%native-coding-review-action-v1 [%observe candidate.u.dead]])
                  !>([%native-local-review-retry-v1 candidate.u.dead u.retry.u.dead])
              ==
          ==
        ?.  &(=(%collecting phase.u.c) (session-ready member.ids))  [~[(tend-card id)] this]
        =/  raw  (raw:instrument inner bowl /x/native-coding/task-completion-proposal/(scot %ux member.ids))
        =/  ready  ?~(raw ~ ((soft ,(each * @tas)) u.raw))
        ?.  ?=([~ %& *] ready)  [~[(tend-card id)] this]
        =/  expected=@ux  (digest:completed p.u.ready)
        :_  this
        :~  (tend-card id)
            [%pass /qpc-onboard/complete/(scot %ux id) %agent [our.bowl dap.bowl] %poke %noun !>([%qpc-native-task-complete-v1 member.ids expected])]
        ==
  ++  on-init
    =^  cards  inner  on-init:ag
    [cards this]
  ++  on-save  !>([%qpc-task-onboard-owner-v3 held on-save:ag])
  ++  on-load
    |=  old=vase
    =/  saved=[held=state:onboard inner=vase]
      ?:  ?=([%qpc-task-onboard-owner-v1 *] q.old)
        =/  prior  !<([%qpc-task-onboard-owner-v1 held=state-v1:onboard inner=vase] old)
        [(migrate:onboard held.prior) inner.prior]
      ?:  ?=([%qpc-task-onboard-owner-v2 *] q.old)
        =/  prior  !<([%qpc-task-onboard-owner-v2 held=state-v2:onboard inner=vase] old)
        [(migrate-v2:onboard held.prior) inner.prior]
      ?.  ?=([%qpc-task-onboard-owner-v3 *] q.old)  [empty:onboard old]
      =/  prior  !<([%qpc-task-onboard-owner-v3 held=state:onboard inner=vase] old)
      +.prior
    ?>  (valid:onboard our.bowl held.saved)
    =.  held  held.saved
    =^  cards  inner  (on-load:ag inner.saved)
    [cards this]
  ++  on-poke
    |=  [=mark =vase]
    ?:  &(=(%noun mark) ?=([%qpc-task-onboard-v1 *] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  parsed  ((soft command) q.vase)
      ?~  parsed  (refuse 0x0 %onboard-command-invalid)
      (begin d.u.parsed)
    ?:  &(=(%noun mark) ?=([?(%qpc-task-arm-v1 %qpc-task-activate-v1 %qpc-task-enqueue-v1 %qpc-task-resume-v1) *] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  parsed  ((soft arming) q.vase)
      ?~  parsed  (refuse 0x0 %onboard-command-invalid)
      ?-  -.u.parsed
        %qpc-task-arm-v1       (arm seed.u.parsed prior.u.parsed)
        %qpc-task-activate-v1  (activate seed.u.parsed)
        %qpc-task-resume-v1
          ::  A halted task whose campaign still runs goes back under the minute's
          ::  watch. One that ended stays over, or resuming would only halt on it
          ::  again; the queue moves on, and the operator can enqueue it afresh.
          =/  was  halted.held
          =.  held
            %+  roll  (skim ~(tap in queued.held) check-lost)
            |=  [id=@ux acc=_held]
            (fail:onboard acc id %onboard-check-lost)
          =.  held  held(halted ~)
          =/  back=(unit @ux)
            ?~  was  ~
            =/  r  (~(get by records.held) id.u.was)
            ?~  r  ~
            ?.  =(%activated phase.u.r)  ~
            =/  held-campaigns  campaigns
            ?~  held-campaigns  ~
            =/  c  (~(get by records.u.held-campaigns) campaign.identities.plan.u.r)
            ?~  c  ~
            ?:  ?=(?(%stopped %unknown) phase.u.c)  ~
            `id.u.was
          ?~  back  advance
          =.  held  held(queued (~(put in queued.held) u.back))
          =^  cards  this  advance
          [[(tend-card u.back) cards] this]
        %qpc-task-enqueue-v1
          =/  next  (enqueue:onboard held d.u.parsed)
          ?:  ?=(%| -.next)  (refuse 0x0 p.next)
          =.  held  p.next
          advance
      ==
    =^  cards  inner  (on-poke:ag mark vase)
    ::  Cantrip's result for a baseline check passes through here; a %checking
    ::  record whose check is now finished settles into its handoff.
    =^  more  this
      ?.  &(=(%noun mark) ?=([%native-coding-tool-result-v1 *] q.vase))  [~ this]
      =/  waiting=(list [id=@ux r=record:onboard])
        (skim ~(tap by records.held) |=([id=@ux r=record:onboard] =(%checking phase.r)))
      ?~  waiting  [~ this]
      =/  prior  (prior-of plan.r.i.waiting)
      ?~  prior  [~ this]
      (settle id.i.waiting u.prior)
    =^  rest  this  advance
    [:(weld cards more rest) this]
  ++  on-agent
    |=  [=wire =sign:agent:gall]
    ?:  ?=([%qpc-onboard %complete @ ~] wire)
      ?.  &(=(our.bowl src.bowl) ?=([%poke-ack ^] sign))  [~ this]
      =/  id  (slaw %ux i.t.t.wire)
      ?~  id  [~ this]
      (halt u.id %onboard-queue-complete-nacked)
    ?:  ?=([%qpc-onboard %review-exit @ ~] wire)
      ?.  &(=(our.bowl src.bowl) ?=([%poke-ack ^] sign))  [~ this]
      =/  id  (slaw %ux i.t.t.wire)
      ?~  id  [~ this]
      (halt u.id %onboard-queue-review-exit-nacked)
    ?:  ?=([%qpc-onboard @ ?(%baseline %member) ~] wire)
      ?.  =(our.bowl src.bowl)  [~ this]
      =/  id  (slaw %ux i.t.wire)
      ?~  id  [~ this]
      =/  found  (~(get by records.held) u.id)
      ?~  found  [~ this]
      ?.  =(%granting phase.u.found)  [~ this]
      ?.  ?=([%poke-ack ~] sign)  (refuse u.id %onboard-grant-nacked)
      =/  which=?(%baseline %member)  ?:(=(%baseline i.t.t.wire) %baseline %member)
      =/  next  (acknowledge:onboard held u.id which)
      ?:  ?=(%| -.next)  (refuse u.id p.next)
      =.  held  state.p.next
      ?.  complete.p.next  [~ this]
      (open u.id)
    =^  cards  inner  (on-agent:ag wire sign)
    =/  handing=(list [id=@ux r=record:onboard])
      (skim ~(tap by records.held) |=([id=@ux r=record:onboard] =(%handing phase.r)))
    =^  more  this
      ?~  handing  [~ this]
      (confirm id.i.handing)
    =^  rest  this  advance
    [:(weld cards more rest) this]
  ++  on-peek
    |=  =path
    ?:  =(/x/qpc/onboard path)
      ?.  =(our.bowl src.bowl)  ~
      ``noun+!>(held)
    ?:  ?=([%x %qpc %onboard @ ~] path)
      ?.  =(our.bowl src.bowl)  ~
      =/  id  (slaw %ux i.t.t.t.path)
      ?~  id  [~ ~]
      ``noun+!>((~(get by records.held) u.id))
    ::  Why a record stands where it stands (2026-11-01, GOAL 30): its phase,
    ::  the clause-named reason, and the verdicts of the check it was judged on.
    ?:  =(/x/qpc/queue path)
      ?.  =(our.bowl src.bowl)  ~
      ``noun+!>([%qpc-onboard-queue-v1 (turn queue.held |=(d=description:onboard task.d)) ~(tap in queued.held) halted.held campaign-busy])
    ?:  ?=([%x %qpc %explain @ ~] path)
      ?.  =(our.bowl src.bowl)  ~
      =/  id  (slaw %ux i.t.t.t.path)
      ?~  id  [~ ~]
      =/  rec  (~(get by records.held) u.id)
      ?~  rec  ``noun+!>(~)
      =/  r=record:onboard  u.rec
      =/  found=(unit record:contract)
        ?~  check.r  ~
        =/  l  ledger
        ?~  l  ~
        (~(get by records.u.l) u.check.r)
      =/  stage=@tas  ?~(check.r %no-check ?~(found %check-missing stage.u.found))
      =/  verdicts=(list [name=@tas passed=? detail=@t])
        ?~  found  ~
        ?~  result.u.found  ~
        =/  out  output.u.result.u.found
        ?:  ?=(%diagnostics -.out)
          (turn values.out |=(d=diagnostic:nc [name.d passed.d detail.d]))
        ::  A check that never ran says why rather than reading as no diagnostics.
        ?+  -.out  ~
          %refused  ~[[reason.out %.n detail.out]]
          %unknown  ~[[reason.out %.n detail.out]]
        ==
      ``noun+!>([%qpc-onboard-explain-v1 u.id phase.r reason.r label.r stage verdicts])
    (on-peek:ag path)
  ++  on-watch
    |=  =path
    =^  cards  inner  (on-watch:ag path)
    [cards this]
  ++  on-leave
    |=  =path
    =^  cards  inner  (on-leave:ag path)
    [cards this]
  ++  on-arvo
    |=  [=wire =sign-arvo]
    ?:  ?=([%qpc-onboard %check-watch @ ~] wire)
      ?.  ?=([%behn %wake *] sign-arvo)  [~ this]
      =/  id  (slaw %ux i.t.t.wire)
      ?~  id  [~ this]
      ?.  (check-lost u.id)  [~ this]
      =^  said  this  (refuse u.id %onboard-check-lost)
      =^  rest  this  advance
      [(weld said rest) this]
    ?:  ?=([%qpc-onboard %tend @ ~] wire)
      ?.  ?=([%behn %wake *] sign-arvo)  [~ this]
      =/  id  (slaw %ux i.t.t.wire)
      ?~  id  [~ this]
      (tend u.id)
    =^  cards  inner  (on-arvo:ag wire sign-arvo)
    =^  more  this  advance
    [(weld cards more) this]
  ++  on-fail
    |=  [=term =tang]
    =^  cards  inner  (on-fail:ag term tang)
    [cards this]
  --
++  agent  |=(inner=agent:gall (wrap inner))
--
