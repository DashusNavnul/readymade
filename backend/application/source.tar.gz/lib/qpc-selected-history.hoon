::  A private selected-work overlay on the unchanged chronological queue.
::  Ordinary slots retain their old rules. Selected slots are reserved before
::  generation and remain unresolved until the native selected producer joins
::  the real original frame, sole choice, execution and terminal acceptance.
/-  nc=native-coding
/+  prior=qpc-successor-history, ordinary=qpc-instrument-history,
    measured=qpc-selected-measurement, admission=qpc-measurement-admission,
    obs=qpc-observation, window=qpc-successor-window
|%
+$  registration  [member=@ux reservation=reservation:measured]
+$  ticket
  $:  id=@ux  session=@ux  decision=@ux  acceptance=@ux  due=@da
      phase=?(%scheduled %settled %unknown)  reason=(unit @tas)
  ==
+$  state
  $:  reservations=(map @ux registration)
      receipts=(map @ux receipt:measured)  reads=(map @ux ticket)
  ==
++  read-id
  |=  [candidate=@ux session=@ux decision=@ux acceptance=@ux]
  ^-  @ux
  (shax (jam [%qpc-selected-read-v1 candidate session decision acceptance]))
++  reserve
  |=  [h=state:prior s=state member=@ux r=reservation:measured]
  ^-  (each [history=state:prior selected=state] @tas)
  =/  e=enrollment:admission  enrollment.r
  ?.  &(=(~ fault.h) (reservation-valid:measured r) (gth member 0))
    [%| %qpc-selected-reservation-invalid]
  ?:  |((~(has by reservations.s) id.e) (pending:prior h stream.position.e))
    [%| %qpc-selected-stream-pending]
  ?:  (lien queue.h |=(x=item:prior &(?=(%work -.body.x) =(id.e enrollment.body.x))))
    [%| %qpc-selected-slot-already-recorded]
  ?.  &((lth ~(wyt by reservations.s) 128) (lth (lent queue.h) 512))
    [%| %qpc-selected-reservation-capacity]
  ?.  =(`prefix.r (~(get by windows.h) stream.position.e))
    [%| %qpc-selected-prefix-changed]
  [%& [(reserve:prior h e) s(reservations (~(put by reservations.s) id.e [member r]))]]
++  pending
  |=  [h=state:prior s=state stream=@ux]
  ^-  ?
  %+  lien  (pending-items:prior h stream)
  |=  x=item:prior
  &(?=(%work -.body.x) =(stream stream.x) (~(has by reservations.s) enrollment.body.x))
++  reopen
  ::  Sole exception to the general pending guard: this exact already-held
  ::  work may reopen its unchanged pre-generation prefix. Nothing else may
  ::  open, and no later reading or caller-supplied source replaces the pin.
  |=  [h=state:prior s=state member=@ux work=work:obs current=revision:nc]
  ^-  (each state:window @tas)
  ?^  fault.h  [%| u.fault.h]
  =/  found=(list registration)
    (skim ~(val by reservations.s) |=(r=registration =(work work.enrollment.reservation.r)))
  ?.  =(1 (lent found))  [%| %qpc-selected-reservation-missing]
  =/  r=registration  (snag 0 found)
  =/  e=enrollment:admission  enrollment.reservation.r
  ?.  ?&  =(member member.r)  (reservation-valid:measured reservation.r)
          =(current source.work)  !(~(has by receipts.s) id.e)
          =(`prefix.reservation.r (~(get by windows.h) stream.position.e))
      ==  [%| %qpc-selected-reopen-mismatch]
  =/  pending=(list item:prior)
    (pending-items:prior h stream.position.e)
  ?.  =(pending ~[[stream.position.e [%work id.e]]])
    [%| %qpc-selected-reopen-not-exclusive]
  [%& prefix.reservation.r]
++  collect
  ::  Native reader only; there is no command accepting rows or receipts.
  |=  [s=state v=evidence:measured]
  ^-  (each state @tas)
  =/  id=@ux  id.enrollment.reservation.v
  =/  prior  (~(get by reservations.s) id)
  ?~  prior  [%| %qpc-selected-reservation-missing]
  ?.  =(reservation.u.prior reservation.v)  [%| %qpc-selected-reservation-changed]
  =/  made  (assemble:measured v)
  ?:  ?=(%| -.made)  [%| p.made]
  =/  old  (~(get by receipts.s) id)
  ?^  old  ?:(=(u.old p.made) [%& s] [%| %qpc-selected-settlement-conflict])
  [%& s(receipts (~(put by receipts.s) id p.made))]
++  body
  |=  [h=state:prior s=state x=item:prior admitted=state:admission observed=state:obs]
  ^-  (unit body:window)
  ?.  ?=(%work -.body.x)  (body:prior h x admitted observed)
  =/  found  (~(get by reservations.s) enrollment.body.x)
  ?~  found  (body:prior h x admitted observed)
  ::  An ordinary cancellation/alternatives rule cannot consume selected work.
  =/  receipt  (~(get by receipts.s) enrollment.body.x)
  ?~  receipt  ~
  =/  frame  (~(get by frames.observed) frame.u.receipt)
  ?~  frame  ~
  ?.  (linked-valid:measured reservation.u.found u.frame u.receipt)  ~
  =/  p=point:window
    [row.u.receipt (digest:admission prediction.u.receipt) enrollment.body.x assessment.u.receipt id.u.receipt]
  `[%row p]
++  process
  |=  [h=state:prior s=state admitted=state:admission observed=state:obs]
  ^-  step:prior
  |=  [held=state:window value=item:prior]
  ^-  (unit (each state:window @tas))
  =/  reserved=(unit registration)
    ?.  ?=(%work -.body.value)  ~
    (~(get by reservations.s) enrollment.body.value)
  ?.  ?~(reserved %.y =(held prefix.reservation.u.reserved))
    [~ [%| %qpc-selected-prefix-changed]]
  =/  ready  (body h s value admitted observed)
  ?~  ready  ~
  [~ (append:window held [next.held u.ready])]
++  advance
  |=  [h=state:prior s=state admitted=state:admission observed=state:obs limit=@ud]
  ^-  state:prior
  (advance-with:prior h limit (process h s admitted observed))
++  valid
  |=  [h=state:prior s=state admitted=state:admission observed=state:obs]
  ^-  ?
  ?:  =(s *state)  (valid:prior h admitted observed)
  ?.  &((lte ~(wyt by reservations.s) 128) (lte ~(wyt by receipts.s) 128) (lte ~(wyt by reads.s) 128) (lte (lent queue.h) 512) (lte cursor.h (lent queue.h)) (lte ~(wyt by windows.h) 64))  %.n
  ?.  %+  levy  ~(tap by reads.s)
      |=  [candidate=@ux ticket=ticket]
      ?&  =(id.ticket (read-id candidate session.ticket decision.ticket acceptance.ticket))
          (levy `(list @ux)`~[candidate session.ticket decision.ticket acceptance.ticket] |=(n=@ux &((gth n 0) (lte (met 0 n) 256))))
          (gth due.ticket 0)
          ?:  !=(%settled phase.ticket)  %.y
          =/  matched=(list receipt:measured)
            (skim ~(val by receipts.s) |=(r=receipt:measured &(=(acceptance.ticket acceptance.r) =(decision.ticket decision.r))))
          =(1 (lent matched))
          ?:  =(%unknown phase.ticket)
            ?~(reason.ticket %.n !=(%$ u.reason.ticket))
          ?=(~ reason.ticket)
      ==
    %.n
  =/  works=(list @ux)
    (murn queue.h |=(x=item:prior ?:(?=(%work -.body.x) `enrollment.body.x ~)))
  ?.  =((lent works) ~(wyt in (silt works)))  %.n
  ?.  (levy ~(tap by canceled.h) |=([id=@ux value=interruption:prior] &((~(has in (silt works)) id) (interruption-valid:ordinary value) !(~(has by reservations.s) id))))  %.n
  ?.  %+  levy  ~(tap by reservations.s)
      |=  [id=@ux r=registration]
      =/  e=enrollment:admission  enrollment.reservation.r
      ?&  =(id id.e)  (gth member.r 0)  (reservation-valid:measured reservation.r)
          =(`e (~(get by enrollments.admitted) id))  (~(has in (silt works)) id)
          ?:  (pending:prior h stream.position.e)
            =/  remaining=(list item:prior)
              (skim (pending-items:prior h stream.position.e) |=(x=item:prior &(?=(%work -.body.x) =(id enrollment.body.x))))
            ?~  remaining  %.y
            =(`prefix.reservation.r (~(get by windows.h) stream.position.e))
          %.y
      ==
    %.n
  ?.  %+  levy  ~(tap by receipts.s)
      |=  [id=@ux value=receipt:measured]
      =/  r  (~(get by reservations.s) id)
      =/  f  (~(get by frames.observed) frame.value)
      ?~  r  %.n
      ?~  f  %.n
      (linked-valid:measured reservation.u.r u.f value)
    %.n
  ?.  %+  levy  ~(tap by windows.h)
      |=  [id=@ux value=state:window]
      =/  begun  (start:window binding.value manifest.value)
      &(=(id stream.binding.value) ?=(%& -.begun))
    %.n
  ?.  %+  levy  queue.h
      |=  x=item:prior
      =/  win  (~(get by windows.h) stream.x)
      ?~  win  %.n
      ?:  ?=(%gap -.body.x)  (interruption-valid:ordinary +.body.x)
      =/  enrolled  (~(get by enrollments.admitted) enrollment.body.x)
      ?~  enrolled  %.n
      =/  r=enrollment:admission  u.enrolled
      ?&  (enrollment-valid:admission r)  =(stream.x stream.position.r)
          =(instrument.binding.u.win instrument.position.r)
          =(manifest.binding.u.win manifest.contract.r)
          =(policy.binding.u.win policy.contract.r)
      ==
    %.n
  (valid-progress:prior h (process h s admitted observed))
--
