::  Parent-owned review campaigns. Each external mutation has a retained
::  intent; progress follows canonical Boxy/Cantrip observations, never ACKs.
/-  nc=native-coding, bx=boxy, jm=juggler-match, protocol=native-coding-review,
    ri=native-coding-review-inspection
/+  worker=native-coding-review-worker, request=native-coding-review-request,
    accept=native-coding-accept, files=native-coding-files,
    judgment=native-coding-judgment, boxy=boxy-law, match=boxy-match,
    juggler=juggler-match, guard=viki-scry-guard, grants=cantrip-native-coding,
    inspections=native-coding-review-inspection-orchestration,
    inspected=native-coding-inspected-review
|%
+$  card  card:agent:gall
+$  job
  [worker=@p config=config:request request=request:request event=(unit event:worker)]
+$  campaign
  $:  scope=scope:protocol
      record=record:accept
      objective=@t
      workspace=@tas
      before=(map path replacement:nc)
      sent=(set @ux)
      jobs=(map @ux job)
      reason=@tas
      done=?
  ==
+$  state-v1
  [%native-coding-review-campaigns-v1 scopes=(map @t scope:protocol) campaigns=(map @ux campaign)]
+$  state
  [%native-coding-review-campaigns-v2 scopes=(map @t scope:protocol) campaigns=(map @ux campaign) inspections=state:inspections]
+$  change  [state=state cards=(list card)]
+$  action
  $%  [%scope scope=scope:protocol]
      [%scope-if expected=(unit @ux) scope=scope:protocol]
      [%start candidate=@ux objective=@t]
      [%observe campaign=@ux]
  ==
++  empty  ^-  state  [%native-coding-review-campaigns-v2 ~ ~ ~]
++  legacy
  |=  s=state
  ^-  state-v1
  [%native-coding-review-campaigns-v1 scopes.s campaigns.s]
++  migrate
  |=  s=state-v1
  ^-  state
  [%native-coding-review-campaigns-v2 scopes.s campaigns.s ~]
++  scope-valid
  |=  [our=@p scope=scope:protocol]
  ^-  ?
  ::  The current owner must parent both independently configured reviewers.
  ?&  !=(0 project.scope)  (lte (met 3 project.scope) 128)
      !=(ship.left.scope ship.right.scope)
      (config-valid:request ship.left.scope config.left.scope)
      (config-valid:request ship.right.scope config.right.scope)
      =(our parent.config.left.scope)  =(our parent.config.right.scope)
  ==
++  enabled
  |=  [s=state e=campaign]
  ^-  ?
  &(enabled.scope.e =(`scope.e (~(get by scopes.s) project.scope.e)))
++  wire-for
  |=  [id=@ux kind=@tas]
  ^-  path
  /native-review-campaign/(scot %ux id)/[kind]
++  remote
  |=  [id=@ux moon=@p command=command:worker]
  ^-  card
  [%pass (wire-for id %worker) %agent [moon %native-coding-reviewer] %poke %noun !>(command)]
++  retained
  |=  [our=@p id=@ux e=campaign]
  ^-  card
  [%pass (wire-for id %retain) %agent [our %graf] %poke %graf-action !>([%attest [%native-coding-review-campaign-v1 id (digest:request e) reason.e done.e]])]
++  put
  |=  [our=@p s=state id=@ux e=campaign cards=(list card)]
  ^-  change
  ?:  &(=(`e (~(get by campaigns.s) id)) =(~ cards))  [s ~]
  [s(campaigns (~(put by campaigns.s) id e)) [(retained our id e) cards]]
++  once
  |=  [our=@p s=state id=@ux e=campaign key=* cards=(list card)]
  ^-  change
  =/  digest=@ux  (digest:request key)
  ?:  (~(has in sent.e) digest)  [s ~]
  (put our s id e(sent (~(put in sent.e) digest)) cards)
++  emit
  |=  [our=@p s=state id=@ux e=campaign w=workspace-state:bx key=* command=command:bx]
  ^-  change
  =/  envelope=command-envelope:bx
    [id.w membership-epoch.w law-digest.w ?~(head.w ~ ~[u.head.w]) (payload-digest-for:boxy command) (scot %ux (digest:request [id key])) command]
  (once our s id e key ~[[%pass (wire-for id %boxy) %agent [our %boxy] %poke %boxy-action !>(`action:bx`[%command envelope])]])
++  act
  |=  [b=bowl:gall s=state action=action]
  ^-  (each change @tas)
  ?.  =(our.b src.b)  [%| %review-owner-required]
  ?:  ?=(%scope-if -.action)
    ::  The comparison and scope mutation share this Viki event. HTTP's
    ::  earlier observation cannot authorize replacing an intervening scope.
    =/  current=(unit scope:protocol)
      (~(get by scopes.s) project.scope.action)
    =/  observed=(unit @ux)
      ?~(current ~ `(digest:request u.current))
    ?.  =(expected.action observed)  [%| %review-scope-changed]
    (act b s [%scope scope.action])
  ?:  ?=(%scope -.action)
    ?.  (scope-valid our.b scope.action)  [%| %review-scope-invalid]
    ?.  |((~(has by scopes.s) project.scope.action) (lth ~(wyt by scopes.s) 32))
      [%| %review-scope-capacity]
    ::  Explicit disabling is immediate. An old campaign cannot use a new
    ::  scope, generation or provider selection to finish an old decision.
    =.  s  s(scopes (~(put by scopes.s) project.scope.action scope.action))
    =/  rows=(list [@ux campaign])  ~(tap by campaigns.s)
    =/  cards=(list card)  ~
    |-  ^-  (each change @tas)
    ?~  rows  [%& [s cards]]
    =/  id=@ux  -.i.rows
    =/  e=campaign  +.i.rows
    ?:  |(done.e (enabled s e))  $(rows t.rows)
    =/  held  (feedback our.b s id e 0x0 %review-scope-revoked)
    $(rows t.rows, s state.held, cards (weld cards cards.held))
  ?:  ?=(%observe -.action)  [%& (observe b s campaign.action)]
  (begin b s candidate.action objective.action)
++  begin
  |=  [b=bowl:gall s=state candidate=@ux objective=@t]
  ^-  (each change @tas)
  ?.  &(!=(0 objective) (lte (met 3 objective) 65.536) (agent-live:guard our.b now.b %cantrip))
    [%| %review-not-ready]
  =/  canonical=(unit record:accept)
    .^((unit record:accept) %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/candidate/(scot %ux candidate)/noun)
  ?~  canonical  [%| %review-candidate-missing]
  =/  r=record:accept  u.canonical
  ?.  =(candidate id.candidate.r)  [%| %review-candidate-mismatch]
  ?.  &(=(%review stage.r) ?=(^ report.r))  [%| %review-checks-pending]
  =/  selected  (~(get by scopes.s) id.spec.project.r)
  ?~  selected  [%| %review-standing-scope-required]
  ?.  &(enabled.u.selected (scope-valid our.b u.selected))  [%| %review-standing-scope-revoked]
  ?.  &((report-valid:accept project.r candidate.r u.report.r) (passed:accept u.report.r))
    [%| %review-checks-failed]
  =/  id=@ux  (digest:request [candidate objective u.selected])
  ?:  (~(has by campaigns.s) id)  [%& (observe b s id)]
  ?:  (gte ~(wyt by campaigns.s) 32)  [%| %review-campaign-capacity]
  =/  source  (sources r)
  ?:  ?=(%| -.source)  [%| p.source]
  =/  workspace=@tas  (staging-desk:accept id)
  =/  e=campaign  [u.selected r objective workspace p.source ~ ~ %opening %.n]
  =.  s  s(campaigns (~(put by campaigns.s) id e))
  [%& (observe b s id)]
++  sources
  ::  Full changed-file witnesses are read from exact numbered Clay trees.
  |=  r=record:accept
  ^-  (each (map path replacement:nc) @tas)
  ?~  report.r  [%| %review-report-missing]
  ?.  (lte (lent edits.candidate.r) 8)  [%| %review-file-capacity]
  =/  before=(map path replacement:nc)  ~
  =/  rows=(list edit:nc)  edits.candidate.r
  |-  ^-  (each (map path replacement:nc) @tas)
  ?~  rows  [%& before]
  =/  e=edit:nc  i.rows
  =/  old=(each (map path replacement:nc) @tas)
    ?~  before.change.e  [%& before]
    =/  read  (file:files project.r basis.candidate.r path.change.e)
    ?:  ?=(%| -.read)  [%| p.read]
    [%& (~(put by before) path.change.e p.read)]
  ?:  ?=(%| -.old)  [%| p.old]
  ?^  content.e
    =/  read  (file:files project.r staging.u.report.r path.change.e)
    ?:  ?=(%| -.read)  [%| p.read]
    ?.  =(p.read u.content.e)  [%| %review-staging-source-mismatch]
    $(rows t.rows, before p.old)
  $(rows t.rows, before p.old)
++  watch
  |=  [our=@p id=@ux e=campaign]
  ^-  card
  [%pass (wire-for id %boxy-watch) %agent [our %boxy] %watch /boxy/workspace/(scot %tas workspace.e)]
++  observe
  |=  [b=bowl:gall s=state id=@ux]
  ^-  change
  =/  found  (~(get by campaigns.s) id)
  ?~  found  [s ~]
  =/  e=campaign  u.found
  ?:  done.e  [s ~]
  ?.  (enabled s e)  (feedback our.b s id e 0x0 %review-scope-revoked)
  ?.  &((agent-live:guard our.b now.b %cantrip) (agent-live:guard our.b now.b %boxy))  [s ~]
  =/  canonical=(unit record:accept)
    .^((unit record:accept) %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/candidate/(scot %ux id.candidate.record.e)/noun)
  ?~  canonical  (put our.b s id e(reason %review-candidate-missing) ~)
  ?.  &(=(%review stage.u.canonical) =(candidate.record.e candidate.u.canonical) =(report.record.e report.u.canonical))
    (put our.b s id e(reason %review-candidate-changed) ~)
  =/  grant=(unit scope:grants)
    .^((unit scope:grants) %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/grant/(scot %ux grant.u.canonical)/noun)
  ?~  grant  (feedback our.b s id e 0x0 %review-grant-unavailable)
  ?^  revoked.u.grant  (feedback our.b s id e 0x0 %review-grant-revoked)
  =/  all=state:bx  .^(state:bx %gx /(scot %p our.b)/boxy/(scot %da now.b)/state/noun)
  =/  found  (~(get by workspaces.all) workspace.e)
  ?~  found
    =/  config=workspace-config:bx
      [workspace.e (artifact:judgment candidate.record.e (need report.record.e) objective.e) [%unanimity ~] %review-host (silt `(list ?(%invite %revoke %publish))`~[%invite %revoke %publish])]
    (once our.b s id e %open ~[[%pass (wire-for id %boxy) %agent [our.b %boxy] %poke %boxy-action !>(`action:bx`[%open config])]])
  =/  w=workspace-state:bx  u.found
  ?.  &((event-chain-valid:boxy w) =(event-seq.w (lent events.w)) =(title.w (artifact:judgment candidate.record.e (need report.record.e) objective.e)))
    (put our.b s id e(reason %review-workspace-conflict) ~)
  ?.  (~(has in sent.e) (digest:request %watch))
    (once our.b s id e %watch ~[(watch our.b id e)])
  ?.  (~(has by members.w) ship.left.scope.e)  (member b s id e w left.scope.e %left)
  ?.  (~(has by members.w) ship.right.scope.e)  (member b s id e w right.scope.e %right)
  =/  projected  (project-workspace:match w)
  =/  m=match-state:jm  match.projected
  =/  config=match-config:jm
    [workspace.e objective.e our.b [ship.left.scope.e (label:request ship.left.scope.e model.selection.config.left.scope.e)] [ship.right.scope.e (label:request ship.right.scope.e model.selection.config.right.scope.e)]]
  ?~  config.m
    (emit our.b s id e w %match (command-for:match [%open config]))
  ?.  &(=(u.config.m config) =(0 refused.projected))
    (put our.b s id e(reason %review-match-conflict) ~)
  ?^  pending.m  (settle b s id e w m)
  =/  negative=(list settlement:jm)
    (skim settlements.m |=(v=settlement:jm |(!accepted.admission.v =(%refuse kind.contribution.v))))
  ?^  negative
    =/  jobs=(list job)
      (skim ~(val by jobs.e) |=(j=job ?~(event.j %.n &(=(worker.j actor.i.negative) =(contribution.u.event.j `contribution.i.negative)))))
    ?~  jobs  (put our.b s id e(reason %review-unattributed-refusal) ~)
    ?^  t.jobs  (put our.b s id e(reason %review-unattributed-refusal) ~)
    (feedback our.b s id e id.request.i.jobs %review-refused)
  ?^  closure.m
    ?.  &(=(%closed status.m) =(artifact.u.closure.m title.w))
      (put our.b s id e(reason %review-closure-conflict) ~)
    =/  action  [%native-coding-review-action-v1 [%bind id.candidate.record.e workspace.e]]
    (put our.b s id e(done %.y, reason %review-match-closed) ~[[%pass (wire-for id %bind) %agent [our.b %viki] %poke %noun !>(action)]])
  =/  targets=(list move:jm)  (skim moves.m |=(v=move:jm =(%propose kind.contribution.v)))
  ?~  targets  (dispatch b s id e w left.scope.e %propose %propose ~)
  ?^  t.targets  (put our.b s id e(reason %review-target-conflict) ~)
  =/  target=move:jm  i.targets
  ?.  =(body.contribution.target title.w)  (put our.b s id e(reason %review-artifact-conflict) ~)
  ?.  (challenged:judgment m target)
    (dispatch b s id e w right.scope.e %challenge %challenge `id.target)
  ?.  (accepted-by:juggler moves.m ship.left.scope.e id.target)
    (dispatch b s id e w left.scope.e %vote-left %vote `id.target)
  ?.  (accepted-by:juggler moves.m ship.right.scope.e id.target)
    (dispatch b s id e w right.scope.e %vote-right %vote `id.target)
  (dispatch b s id e w left.scope.e %close %close `id.target)
++  member
  |=  [b=bowl:gall s=state id=@ux e=campaign w=workspace-state:bx peer=reviewer:protocol side=@tas]
  ^-  change
  ?.  (~(has by invitations.w) ship.peer)
    (emit our.b s id e w [%invite side] [%invite ship.peer %ai-reviewer (silt ~[%publish])])
  (once our.b s id e [%join side] ~[(remote id ship.peer [%native-coding-review-join-v1 (digest:request config.peer) generation.config.peer w])])
++  feedback
  ::  Zero only requests an authority-hold observation. A nonzero request
  ::  identifies a real settled negative; Viki independently rereads it.
  |=  [our=@p s=state id=@ux e=campaign request=@ux reason=@tas]
  ^-  change
  (once our s id e(reason reason) [%feedback request reason] ~[[%pass (wire-for id %feedback) %agent [our %viki] %poke %noun !>([%native-coding-review-negative-v1 id request])]])
++  dispatch
  |=  [b=bowl:gall s=state id=@ux e=campaign w=workspace-state:bx peer=reviewer:protocol key=@tas mode=?(%propose %challenge %vote %close) target=(unit @ud)]
  ^-  change
  =/  nonce=@ux  (digest:request [id key])
  =/  held  (~(get by jobs.e) nonce)
  ?^  held
    ?~  event.u.held  [s ~]
    (put our.b s id e(reason reason.u.event.u.held) ~)
  =/  r=request:request
    [%native-coding-review-request-v1 nonce project.record.e candidate.record.e (need report.record.e) objective.e w mode target before.e]
  =/  checked  (inference:request ship.peer config.peer r)
  ?:  ?=(%| -.checked)
    ?.  &((context-valid:request ship.peer config.peer r) |(=(%review-context-too-large p.checked) (gth (met 3 (jam r)) 262.144)))
      (put our.b s id e(reason p.checked) ~)
    =/  captured  (lookup:inspections inspections.s [id ship.peer])
    ?~  captured
      =/  pending  (~(get by inspections.s) [id ship.peer])
      ?^  pending
        =/  next  (observe:inspections b inspections.s [id ship.peer])
        (put our.b s(inspections state.next) id e(reason reason.u.pending) cards.next)
      =/  started  (begin:inspections b inspections.s id record.e before.e objective.e peer)
      ?:  ?=(%| -.started)  (put our.b s id e(reason p.started) ~)
      (put our.b s(inspections state.p.started) id e(reason %awaiting-source-inspection) cards.p.started)
    =/  prepared  (inference:inspected ship.peer config.peer r u.captured)
    ?:  ?=(%| -.prepared)  (put our.b s id e(reason p.prepared) ~)
    =/  j=job  [ship.peer config.peer r ~]
    =.  e  e(jobs (~(put by jobs.e) nonce j), reason %awaiting-inspected-review)
    (put our.b s id e ~[[%pass (wire-for id %worker) %agent [ship.peer %native-coding-reviewer] %poke %noun !>([%native-coding-inspected-review-v1 (digest:request config.peer) generation.config.peer (key:ri manifest.u.captured) r])]])
  =/  j=job  [ship.peer config.peer r ~]
  =.  e  e(jobs (~(put by jobs.e) nonce j), reason %awaiting-moon-review)
  (put our.b s id e ~[(remote id ship.peer [%native-coding-review-request-v1 (digest:request config.peer) generation.config.peer r])])
++  context
  |=  [s=state id=@ux request-id=@ux]
  ^-  (unit admission-context:protocol)
  =/  e  (~(get by campaigns.s) id)
  ?~  e  ~
  ?.  (enabled s u.e)  ~
  =/  j  (~(get by jobs.u.e) request-id)
  ?~  j  ~
  ?~  event.u.j  ~
  ?.  =(%submitted phase.u.event.u.j)  ~
  `[id scope.u.e worker.u.j request.u.j u.event.u.j]
++  inspection-for
  ::  The current Boxy request selects its own captured moon/config/source.
  |=  [s=state campaign=@ux request-id=@ux]
  ^-  (unit entry:ri)
  =/  found  (~(get by campaigns.s) campaign)
  ?~  found  ~
  ?.  (enabled s u.found)  ~
  =/  job  (~(get by jobs.u.found) request-id)
  ?~  job  ~
  =/  captured  (lookup:inspections inspections.s [campaign worker.u.job])
  ?~  captured  ~
  =/  prepared  (inference:inspected worker.u.job config.u.job request.u.job u.captured)
  ?:  ?=(%| -.prepared)  ~
  captured
++  adopt-inspection
  |=  [b=bowl:gall s=state next=change:inspections]
  ^-  change
  =/  changed=(list [key:inspections ?])
    %+  murn  ~(tap by state.next)
    |=  [k=key:inspections e=entry:inspections]
    =/  captured=?  &(?=(^ inspected.e) ?=(~ (lookup:inspections inspections.s k)))
    =/  old  (~(get by inspections.s) k)
    ?:  ?~(old %.n &(=(phase.e phase.u.old) =(reason.e reason.u.old) !captured))  ~
    `[k captured]
  =.  s  s(inspections state.next)
  =/  cards=(list card)  cards.next
  |-  ^-  change
  ?~  changed  [s cards]
  =/  row=[k=key:inspections captured=?]  i.changed
  =/  campaign  (~(get by campaigns.s) campaign.k.row)
  ?~  campaign  $(changed t.changed)
  ?:  done.u.campaign  $(changed t.changed)
  =/  inspection  (~(got by inspections.s) k.row)
  =/  resumed=change
    ?:  captured.row  (observe b s campaign.k.row)
    (put our.b s campaign.k.row u.campaign(reason reason.inspection) ~)
  $(changed t.changed, s state.resumed, cards (weld cards cards.resumed))
++  inspection-event
  |=  [b=bowl:gall s=state event=event:ri]
  ^-  change
  (adopt-inspection b s (receive:inspections b inspections.s event))
++  settle
  |=  [b=bowl:gall s=state id=@ux e=campaign w=workspace-state:bx m=match-state:jm]
  ^-  change
  ?~  pending.m  (put our.b s id e(reason %review-pending-conflict) ~)
  ?^  t.pending.m  (put our.b s id e(reason %review-pending-conflict) ~)
  =/  pending=pending-contribution:jm  i.pending.m
  =/  jobs=(list job)
    (skim ~(val by jobs.e) |=(j=job ?~(event.j %.n =(contribution.u.event.j `contribution.pending))))
  ?~  jobs  [s ~]
  ?^  t.jobs  [s ~]
  =/  j=job  i.jobs
  ?.  =(worker.j actor.pending)  (put our.b s id e(reason %review-source-mismatch) ~)
  =/  ctx  (context s id id.request.j)
  ?~  ctx  [s ~]
  =/  verdict=(unit verdict:protocol)
    .^((unit verdict:protocol) %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/review-admission/(scot %ux id)/(scot %ux id.request.j)/noun)
  ?~  verdict
    (once our.b s id e [%admit id.request.j] ~[[%pass (wire-for id %cantrip-watch) %agent [our.b %cantrip] %watch /native-coding/review-admission/(scot %ux id)/(scot %ux id.request.j)] [%pass (wire-for id %cantrip) %agent [our.b %cantrip] %poke %noun !>([%native-coding-review-admit-v1 id id.request.j])]])
  ?.  &(=(id campaign.u.verdict) =(id.request.j request.u.verdict) =((digest:request u.ctx) context.u.verdict) =(proposal-id.contribution.pending proposal-id.admission.u.verdict))
    (put our.b s id e(reason %review-admission-mismatch) ~)
  =/  applied  (apply:juggler m [%settle proposal-id.contribution.pending admission.u.verdict] [%cantrip our.b])
  ?.  ok.applied  (put our.b s id e(reason code.applied) ~)
  (emit our.b s id e w [%settle id.request.j] (command-for:match [%settle proposal-id.contribution.pending admission.u.verdict]))
++  receive
  |=  [b=bowl:gall s=state event=event:worker]
  ^-  change
  =/  ids=(list @ux)
    (murn ~(tap by campaigns.s) |=([id=@ux e=campaign] ?:((~(has by jobs.e) id.event) `id ~)))
  ?~  ids  [s ~]
  ?^  t.ids  [s ~]
  =/  id=@ux  i.ids
  =/  e=campaign  (~(got by campaigns.s) id)
  =/  j=job  (~(got by jobs.e) id.event)
  ?.  ?&  (enabled s e)  =(src.b worker.j)
          =(binding.event (digest:request config.j))  =(generation.event generation.config.j)
          =(request.event (digest:request request.j))
      ==  [s ~]
  ?^  event.j
    ?:  ?=(?(%submitted %refused %cancelled) phase.u.event.j)  [s ~]
    ?:  &(=(%unknown phase.u.event.j) =(%pending phase.event))  [s ~]
    =.  e  e(jobs (~(put by jobs.e) id.event j(event `event)))
    (observe b s(campaigns (~(put by campaigns.s) id e)) id)
  =.  e  e(jobs (~(put by jobs.e) id.event j(event `event)))
  (observe b s(campaigns (~(put by campaigns.s) id e)) id)
++  peek
  |=  [s=state path=path]
  ^-  (unit (unit cage))
  ::  These are local canonical Gall scries. Gall supplies no caller identity
  ::  here; any browser or remote projection must enforce owner access there.
  ?:  =(/x/native-coding/review-campaigns path)  ``noun+!>(campaigns.s)
  ?:  =(/x/native-coding/review-scopes path)  ``noun+!>(scopes.s)
  ?.  ?=([%x %native-coding ?(%review-admission %review-inspection) @ @ ~] path)  ~
  =/  id  (slaw %ux i.t.t.t.path)
  =/  request-id  (slaw %ux i.t.t.t.t.path)
  ?~  id  [~ ~]
  ?~  request-id  [~ ~]
  ?:  =(%review-inspection i.t.t.path)
    ``noun+!>((inspection-for s u.id u.request-id))
  ``noun+!>((context s u.id u.request-id))
++  reload
  ::  Watches and observations only. Stored mutations are never repeated.
  |=  [b=bowl:gall s=state]
  ^-  change
  =/  next  (reload:inspections b inspections.s)
  =/  cards=(list card)
    %-  zing
    %+  turn  ~(tap by campaigns.s)
    |=  [id=@ux e=campaign]
    ^-  (list card)
    ?:  |(done.e !(enabled s e))  ~
    :-  (watch our.b id e)
    %-  zing
    %+  turn  ~(val by jobs.e)
    |=  j=job
    ^-  (list card)
    ?:  ?~(event.j %.n =(%submitted phase.u.event.j))
      ~[[%pass (wire-for id %cantrip-watch) %agent [our.b %cantrip] %watch /native-coding/review-admission/(scot %ux id)/(scot %ux id.request.j)]]
    ?:  ?~(event.j %.n ?=(?(%refused %cancelled) phase.u.event.j))  ~
    ~[(remote id worker.j [%native-coding-review-observe-v1 (digest:request config.j) generation.config.j id.request.j (digest:request request.j)])]
  [s(inspections state.next) (weld cards cards.next)]
++  on-agent
  ::  Only facts/acks on retained local ducts trigger canonical observations.
  ::  Graf evidence acknowledgements must never become scheduling events.
  |=  [b=bowl:gall s=state path=wire sign=sign:agent:gall]
  ^-  (unit change)
  =/  inspection  (on-agent:inspections b inspections.s path sign)
  ?^  inspection  `(adopt-inspection b s u.inspection)
  ?.  ?=([%native-review-campaign @ @ ~] path)  ~
  =/  id  (slaw %ux i.t.path)
  ?~  id  ~
  =/  found  (~(get by campaigns.s) u.id)
  ?~  found  ~
  ?:  =(%retain i.t.t.path)  `[s ~]
  ?:  ?=(%kick -.sign)
    `(put our.b s u.id u.found(reason %review-watch-ended) ~)
  ?:  ?=(%poke-ack -.sign)
    ?^  p.sign  `(put our.b s u.id u.found(reason %review-delivery-refused) ~)
    `(observe b s u.id)
  ?:  ?=(%watch-ack -.sign)
    ?^  p.sign  `(put our.b s u.id u.found(reason %review-watch-refused) ~)
    `(observe b s u.id)
  `(observe b s u.id)
++  valid
  |=  [our=@p s=state]
  ^-  ?
  ?&  (lte ~(wyt by scopes.s) 32)  (lte ~(wyt by campaigns.s) 32)
      (valid:inspections our inspections.s)
      %+  levy  ~(tap by inspections.s)
      |=  [k=key:inspections inspection=entry:inspections]
      =/  c  (~(get by campaigns.s) campaign.k)
      ?~  c  %.n
      &(=(record.inspection record.u.c) =(before.inspection before.u.c) =(objective.inspection objective.u.c) |(=(peer.inspection left.scope.u.c) =(peer.inspection right.scope.u.c)))
      (levy ~(tap by scopes.s) |=([name=@t value=scope:protocol] &(=(name project.value) (scope-valid our value))))
      %+  levy  ~(tap by campaigns.s)
      |=  [id=@ux e=campaign]
      ?&  (scope-valid our scope.e)  !=(0 objective.e)  (lte (met 3 objective.e) 65.536)
          =(id (digest:request [id.candidate.record.e objective.e scope.e]))
          =(workspace.e (staging-desk:accept id))
          =(project.scope.e id.spec.project.record.e)
          ?=(^ report.record.e)
          (report-valid:accept project.record.e candidate.record.e (need report.record.e))
          (lte ~(wyt in sent.e) 32)  (lte ~(wyt by jobs.e) 5)
          %+  levy  ~(tap by jobs.e)
          |=  [nonce=@ux j=job]
          =/  old  (inference:request worker.j config.j request.j)
          =/  prepared=?
            ?:  ?=(%& -.old)  %.y
            =/  captured  (lookup:inspections inspections.s [id worker.j])
            ?~  captured  %.n
            =/  next  (inference:inspected worker.j config.j request.j u.captured)
            ?=(%& -.next)
          ?&  =(nonce id.request.j)  prepared
              |(=([worker.j config.j] left.scope.e) =([worker.j config.j] right.scope.e))
              =(candidate.request.j candidate.record.e)  =(objective.request.j objective.e)
              ?~  event.j  %.y
              ?&  =(nonce id.u.event.j)  =(binding.u.event.j (digest:request config.j))
                  =(generation.u.event.j generation.config.j)
                  =(request.u.event.j (digest:request request.j))
              ==
          ==
      ==
  ==
--
