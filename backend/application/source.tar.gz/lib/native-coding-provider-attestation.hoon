::  Read-only validation against the provider's existing private journal.
::  No credential reads, HTTP cards, receipt fabrication, or journal mutation.
/-  pa=native-coding-provider-attestation, np=native-coding-provider, ci=cli-inference
/+  inference=native-coding-inference, provider=native-coding-provider,
    outbound=native-coding-provider-request, inbound=native-coding-provider-response,
    cli=cli-inference, evidence=qpc-native-evidence, guard=viki-scry-guard
|%
++  value-digest  value-digest:pa
++  stamp
  |=  value=@ux
  ^-  ?
  &(!=(0 value) (lte (met 0 value) 256))
++  bounded-text
  |=  [text=@t maximum=@ud]
  ^-  ?
  ?.  (text-valid:provider text maximum)  %.n
  =/  decoded=(unit @t)  (mole |.(`@t`(tuft (taft text))))
  &(=(decoded `text) !(lien (trip text) |=(c=@t =(0 c))))
++  compact-valid
  ::  Pure shape and self-commitment checks do NOT authenticate an issuer.
  |=  [our=@p a=attestation:pa]
  ^-  ?
  =/  r=public-reply:np  result.a
  ?&  =(our ship.a)
      ?|  &(=(%codex-inference agent.a) =(200 status.a))
          ?&  =(%cli-inference agent.a)  =(0 status.a)
              =([0 0 0] usage.r)
              |(=([%codex 'codex-cli'] [provider.r model.r]) =([%anthropic 'claude-cli'] [provider.r model.r]))
          ==
      ==
      (stamp job.a)  =(job.a id.r)  (name-valid:provider selection.a)
      (stamp request.a)  (stamp body.a)  (stamp full-reply.a)
      (stamp digest.a)  (stamp raw-digest.r)
      (gth bytes.a 0)  (lte bytes.a response-limit:np)
      =(%complete stop.r)  ?=(~ calls.r)
      (bounded-text model.r identifier-limit:np)
      (bounded-text response-id.r identifier-limit:np)
      (bounded-text text.r text-limit:pa)
      (lte input.usage.r 4.294.967.295)
      (lte output.usage.r 4.294.967.295)
      (lte total.usage.r 4.294.967.295)
      ::  Chat-format total may legitimately exceed input+output (xAI folds
      ::  reasoning tokens into total_tokens without adding them to
      ::  completion_tokens). Never less than the parts we did count.
      (gte total.usage.r (add input.usage.r output.usage.r))
      =(digest.a (attestation-digest:pa a))
      (lte (met 3 (jam a)) byte-limit:pa)
  ==
++  attest
  ::  Caller must supply the canonical job from this ship's codex-inference.
  ::  Reparse the retained raw response before projecting away raw/continuation.
  |=  [our=@p id=@ux j=job:inference]
  ^-  (each attestation:pa @tas)
  ?.  &((stamp id) =(id id.request.j) (request-valid:provider request.j) (name-valid:provider selection.j))  [%| %attestation-request-invalid]
  ?.  ?=(%result -.outcome.j)  [%| %attestation-result-unavailable]
  ?~  evidence.j  [%| %attestation-evidence-missing]
  =/  e=evidence:inference  u.evidence.j
  =/  r=reply:np  value.outcome.j
  ?.  ?&  =(200 status.e)  !truncated.e
          (gth bytes.e 0)  (lte bytes.e response-limit:np)
          =(bytes.e p.prefix.e)  =(bytes.e (met 3 q.prefix.e))
          =(raw.r q.prefix.e)  =(digest.e raw-digest.r)
          =(digest.e (shax raw.r))
          =(id id.r)
          (model-matches:provider selection.request.j provider.r model.r)
          =(%complete stop.r)  ?=(~ calls.r)
          (bounded-text text.r text-limit:pa)
      ==  [%| %attestation-evidence-invalid]
  =/  encoded  (encode:outbound request.j)
  ?.  ?=(%& -.encoded)  [%| %attestation-request-encoding]
  ?.  =(p.encoded body.j)  [%| %attestation-body-mismatch]
  =/  decoded  (decode:inbound request.j status.e prefix.e)
  ?.  ?=(%& -.decoded)  [%| %attestation-decode-refused]
  ?.  =(p.decoded r)  [%| %attestation-normalization-mismatch]
  =/  a=attestation:pa
    [%native-coding-provider-attestation-v1 our %codex-inference id selection.j (value-digest request.j) (value-digest body.j) (value-digest r) status.e bytes.e (publish:provider r) 0x0]
  =.  digest.a  (attestation-digest:pa a)
  ?:((compact-valid our a) [%& a] [%| %attestation-compact-invalid])
++  attest-cli
  ::  Status zero labels native CLI evidence; it is never an HTTP response.
  ::  Pure consistency only. +confirm-cli authenticates the retained job.
  |=  [our=@p id=@ux j=job:ci]
  ^-  (each attestation:pa @tas)
  ?~  reply.j  [%| %attestation-cli-result-unavailable]
  =/  r=reply:np  u.reply.j
  ?.  &((stamp id) =(id id.request.j) (request-valid:provider request.j))  [%| %attestation-cli-request-invalid]
  ?^  (validate-evidence:cli request.j r j)  [%| %attestation-cli-evidence-invalid]
  ?.  &(!=(0 connector.j) (bounded-text connector.j 64))  [%| %attestation-cli-connector-invalid]
  =/  prepared  (prompt:cli request.j)
  ?~  prepared  [%| %attestation-cli-prompt-invalid]
  =/  a=attestation:pa
    [%native-coding-provider-attestation-v1 our %cli-inference id key.j (value-digest request.j) (value-digest u.prepared) (value-digest r) 0 (met 3 raw.r) (publish:provider r) 0x0]
  =.  digest.a  (attestation-digest:pa a)
  ?:((compact-valid our a) [%& a] [%| %attestation-cli-compact-invalid])
++  current-cli
  |=  [our=@p at=@da key=@tas selected=selection:np]
  ^-  (each public-binding:ci @tas)
  ?.  (agent-live:guard our at %cli-inference)  [%| %attestation-cli-unavailable]
  =/  backend  (cli-backend:provider selected)
  ?~  backend  [%| %attestation-cli-selection-invalid]
  =/  raw=*
    .^(* %gx /(scot %p our)/cli-inference/(scot %da at)/binding/(scot %tas key)/noun)
  =/  parsed  ((soft ,(unit public-binding:ci)) raw)
  ?.  &(?=(^ parsed) ?=(^ u.parsed))  [%| %attestation-cli-binding-unavailable]
  =/  b=public-binding:ci  u.u.parsed
  ?.  ?&  active.b  =(key key.b)  =(key credential.selected)
          =(u.backend backend.b)  (label:cli connector.b)
      ==  [%| %attestation-cli-binding-changed]
  [%& b]
++  confirm-cli
  ::  Re-read canonical evidence and active pairing at every final admission.
  |=  [our=@p at=@da wanted=request:np key=@tas a=attestation:pa]
  ^-  (unit @tas)
  =/  kept  (lookup-cli:evidence our at id.wanted session.wanted key)
  ?:  ?=(%| -.kept)  `p.kept
  =/  j=job:ci  p.kept
  ?~  reply.j  `%attestation-cli-result-unavailable
  ::  A new capability under the same connector label cannot revive old jobs.
  =/  current=*
    .^(* %gx /(scot %p our)/cli-inference/(scot %da at)/job-current/(scot %ux id.wanted)/noun)
  =/  live  ((soft ?) current)
  ?.  &(?=(^ live) u.live)  `%attestation-cli-job-not-current
  =/  checked  (confirm:evidence our at wanted key u.reply.j)
  ?^  checked  checked
  =/  paired  (current-cli our at key selection.wanted)
  ?:  ?=(%| -.paired)  `p.paired
  ?.  =(connector.j connector.p.paired)  `%attestation-cli-connector-changed
  =/  made  (attest-cli our id.wanted j)
  ?:  ?=(%| -.made)  `p.made
  ?.  =(a p.made)  `%attestation-cli-receipt-changed
  ~
--
