::  Complete JSON and bounded SSE normalization. No provider call is executed.
::  Raw response and opaque continuation are private evidence. Public results
::  come from +publish in native-coding-provider. Legacy codecs are unchanged.
::  https://developers.openai.com/api/reference/responses
::  https://platform.claude.com/docs/en/build-with-claude/streaming
::  https://docs.x.ai/developers/model-capabilities/text/streaming
/-  p=native-coding-provider
/+  cr=codex-responses, law=native-coding-provider
|%
+$  content  [text=@t calls=(list call:p) opaque=(list json) refused=?]
++  put
  |=  [value=json key=@t item=json]
  ^-  json
  ?>  ?=([%o *] value)
  [%o (~(put by p.value) key item)]
++  string
  |=  [value=json key=@t]
  ^-  @t
  (need (string:cr value key))
++  array
  |=  [value=json key=@t]
  ^-  (list json)
  =/  found  (need (field:cr value key))
  ?>  ?=([%a *] found)
  p.found
++  number
  |=  [value=json key=@t]
  ^-  @ud
  (need (natural:cr (field:cr value key)))
++  optional-number
  |=  [value=json key=@t]
  ^-  @ud
  =/  found  (field:cr value key)
  ?~  found  0
  (need (natural:cr found))
++  append
  |=  [value=json key=@t fragment=@t limit=@ud]
  ^-  json
  =/  before=(unit @t)  (string:cr value key)
  =/  text=@t  (cat 3 ?~(before '' u.before) fragment)
  ?>  (lte (met 3 text) limit)
  (put value key [%s text])
++  arguments
  |=  text=@t
  ^-  json
  ?>  (lte (met 3 text) argument-limit:p)
  =/  value=json  (need (de:json:html text))
  ?>  ?=([%o *] value)
  value
++  call
  |=  [format=wire-format:p value=json]
  ^-  call:p
  ?:  =(%messages format)
    [(string value 'id') (string value 'name') (need (field:cr value 'input'))]
  ?:  =(%responses format)
    [(string value 'call_id') (string value 'name') (arguments (string value 'arguments'))]
  ?>  =('function' (string value 'type'))
  =/  fn=json  (need (field:cr value 'function'))
  [(string value 'id') (string fn 'name') (arguments (string fn 'arguments'))]
++  blocks
  |=  [format=wire-format:p items=(list json) provider=provider:p model=@t]
  ^-  content
  =/  text=@t  ''
  =/  calls=(list call:p)  ~
  =/  opaque=(list json)  ~
  =/  refused=?  %.n
  |-  ^-  content
  ?~  items  [text (flop calls) (flop opaque) refused]
  =/  item=json  i.items
  =/  kind=@t  (string item 'type')
  ?:  |(=('text' kind) =('output_text' kind))
    =/  next=@t  (cat 3 text (string item 'text'))
    ?>  (lte (met 3 next) text-limit:p)
    $(items t.items, text next)
  ?:  =('refusal' kind)  $(items t.items, refused %.y)
  ?:  |(=('tool_use' kind) =('function_call' kind))
    ?>  (lth (lent calls) call-limit:p)
    ?>  ?:(=(%responses format) =('function_call' kind) =('tool_use' kind))
    =/  status=(unit @t)  (string:cr item 'status')
    ?>  ?~(status %.y =('completed' u.status))
    $(items t.items, calls [(call format item) calls])
  ?:  =('message' kind)
    ?>  &(=(%responses format) =('assistant' (string item 'role')) =('completed' (string item 'status')))
    $(items (weld (array item 'content') t.items))
  ?>  (opaque-valid:law provider model item)
  $(items t.items, opaque [item opaque])
++  usage
  |=  [format=wire-format:p value=json]
  ^-  usage:p
  =/  input=@ud
    ?:  =(%chat format)  (number value 'prompt_tokens')
    ?:  !=(%messages format)  (number value 'input_tokens')
    (add (number value 'input_tokens') (add (optional-number value 'cache_creation_input_tokens') (optional-number value 'cache_read_input_tokens')))
  =/  output=@ud  (number value ?:(=(%chat format) 'completion_tokens' 'output_tokens'))
  =/  total=@ud
    ::  xAI's total_tokens folds in reasoning tokens that completion_tokens
    ::  itself excludes, so input+output legitimately undercounts it.
    ::  Measured 2026-09-14 on five real Grok replies: total_tokens ==
    ::  prompt_tokens + completion_tokens + reasoning_tokens every time,
    ::  never plain prompt+completion. Trust the provider's own total
    ::  rather than asserting a sum it never promised.
    ?:  =(%chat format)  (number value 'total_tokens')
    (add input output)
  ?>  ?:  |(=(%messages format) =(%chat format))  %.y
      =(total (number value 'total_tokens'))
  [input output total]
++  normalize
  |=  [r=request:p raw=@t value=json]
  ^-  reply:p
  =/  format=wire-format:p  format.selection.r
  ?>  (nullable:cr (field:cr value 'error'))
  =/  id=@t  (string value 'id')
  =/  model=@t  (string value 'model')
  ?>  &((text-valid:law id identifier-limit:p) (text-valid:law model identifier-limit:p))
  =/  result=[stop=stop:p content=content]
    ?:  =(%responses format)
      ?>  =('response' (string value 'object'))
      =/  status=@t  (string value 'status')
      ?>  |(=('completed' status) =('incomplete' status))
      ?:  =('incomplete' status)
        =/  details=json  (need (field:cr value 'incomplete_details'))
        =/  reason=@t  (string details 'reason')
        ?>  |(=('max_output_tokens' reason) =('content_filter' reason))
        [?:(=('content_filter' reason) %refusal %length) ['' ~ ~ %.n]]
      ?>  (nullable:cr (field:cr value 'incomplete_details'))
      =/  content=content  (blocks format (array value 'output') provider.selection.r model.selection.r)
      [?:(refused.content %refusal ?~(calls.content %complete %tools)) content]
    ?:  =(%messages format)
      ?>  &(=('message' (string value 'type')) =('assistant' (string value 'role')))
      =/  reason=@t  (string value 'stop_reason')
      ?:  =('max_tokens' reason)  [%length ['' ~ ~ %.n]]
      ?:  =('refusal' reason)  [%refusal ['' ~ ~ %.y]]
      ?>  |(=('end_turn' reason) =('stop_sequence' reason) =('tool_use' reason))
      =/  content=content  (blocks format (array value 'content') provider.selection.r model.selection.r)
      ?>  =(=('tool_use' reason) ?=(^ calls.content))
      [?:(refused.content %refusal ?~(calls.content %complete %tools)) content]
    =/  choices=(list json)  (array value 'choices')
    ?>  ?=(^ choices)
    ?>  =(~ t.choices)
    ?>  =(0 (number i.choices 'index'))
    =/  reason=@t  (string i.choices 'finish_reason')
    ?:  =('length' reason)  [%length ['' ~ ~ %.n]]
    ?:  =('content_filter' reason)  [%refusal ['' ~ ~ %.y]]
    ?>  |(=('stop' reason) =('tool_calls' reason))
    =/  message=json  (need (field:cr i.choices 'message'))
    ?>  =('assistant' (string message 'role'))
    =/  text=(unit @t)  (string:cr message 'content')
    =/  calls=(list call:p)
      ?~  (field:cr message 'tool_calls')  ~
      (turn (array message 'tool_calls') |=(item=json (call %chat item)))
    ?>  =(=('tool_calls' reason) ?=(^ calls))
    =/  refused=?  !(nullable:cr (field:cr message 'refusal'))
    [?:(refused %refusal ?~(calls %complete %tools)) [?~(text '' u.text) calls ~ refused]]
  ?>  (lte (met 3 text.content.result) text-limit:p)
  ?>  (calls-valid:law calls.content.result tools.r)
  =/  calls=(list call:p)  ?:(=(%tools stop.result) calls.content.result ~)
  [%native-coding-reply-v1 id.r provider.selection.r model id stop.result text.content.result calls (usage format (need (field:cr value 'usage'))) opaque.content.result raw (shax raw)]
++  sse-json
  ::  Parse complete events only; arbitrary HTTP chunk boundaries disappear
  ::  when the Gall owner supplies the finished octs. No partial call escapes.
  |=  raw=@t
  ^-  (list json)
  =/  lines=(list @t)  (lines:cr raw)
  =/  data=@t  ''
  =/  name=@t  ''
  =/  events=(list json)  ~
  =/  count=@ud  0
  |-  ^-  (list json)
  ?~  lines
    ?>  &(=('' data) =('' name))
    (flop events)
  =/  line=@t  i.lines
  ?:  =('' line)
    ?:  =('' data)
      ?>  =('' name)
      $(lines t.lines)
    ?>  (lth count event-limit:p)
    =/  event=json
      ?:  =('[DONE]' data)  [%s '[DONE]']
      (need (de:json:html data))
    ?>  |(=('' name) =(`name (string:cr event 'type')))
    $(lines t.lines, data '', name '', count +(count), events [event events])
  ?:  =(':' (cut 3 [0 1] line))  $(lines t.lines)
  =/  data-line=?  =('data:' (cut 3 [0 5] line))
  ?>  |(data-line =('event:' (cut 3 [0 6] line)))
  =/  value=@t  (rsh [3 ?:(data-line 5 6)] line)
  =.  value  ?:(=(' ' (cut 3 [0 1] value)) (rsh [3 1] value) value)
  ?:  !data-line
    ?>  =('' name)
    $(lines t.lines, name value)
  $(lines t.lines, data ?:(=('' data) value (rap 3 ~[data '\0a' value])))
++  ordered
  |=  values=(map @ud json)
  ^-  (list json)
  =/  count=@ud  ~(wyt by values)
  =/  index=@ud  0
  =/  out=(list json)  ~
  |-  ^-  (list json)
  ?:  =(index count)  (flop out)
  $(index +(index), out [(~(got by values) index) out])
++  response-events
  |=  events=(list json)
  ^-  json
  =/  identity=(unit [@t @t])  ~
  =/  previous=(unit @ud)  ~
  =/  items=(map @ud json)  ~
  =/  pending=(map @ud @t)  ~
  |-  ^-  json
  ?>  ?=(^ events)
  =/  event=json  i.events
  =/  kind=@t  (string event 'type')
  =/  sequence=@ud  (number event 'sequence_number')
  ?>  ?~(previous %.y (gth sequence u.previous))
  =/  response=(unit json)  (field:cr event 'response')
  =.  identity
    ?~  response  identity
    =/  pair=[@t @t]  [(string u.response 'id') (string u.response 'model')]
    ?>  ?~(identity %.y =(pair u.identity))
    `pair
  =/  reference=(unit @t)  (string:cr event 'response_id')
  ?>  ?~(reference %.y ?&(?=(^ identity) =(u.reference -.u.identity)))
  ?:  =('response.completed' kind)
    ?>  ?=(^ response)
    ?>  |(=(~ t.events) =(~[[%s '[DONE]']] t.events))
    ?>  =(~ pending)
    =/  final=(list json)  (array u.response 'output')
    ?:  =(~ items)  u.response
    =/  collected=(list json)  (ordered items)
    ?>  ?~(final %.y =(final collected))
    (put u.response 'output' [%a collected])
  ?:  |(=('response.output_item.added' kind) =('response.output_item.done' kind))
    ?>  ?=(^ identity)
    =/  index=@ud  (number event 'output_index')
    ?>  (lth index block-limit:p)
    =/  item=json  (need (field:cr event 'item'))
    =/  id=@t  (string item 'id')
    =/  type=@t  (string item 'type')
    ?>  |(=('message' type) =('reasoning' type) =('function_call' type))
    ?>  !(~(has by items) index)
    ?:  =('response.output_item.added' kind)
      ?>  !(~(has by pending) index)
      $(events t.events, previous `sequence, pending (~(put by pending) index id))
    =/  prior=(unit @t)  (~(get by pending) index)
    ?>  ?~(prior %.y =(id u.prior))
    ?>  (levy ~(tap by items) |=([slot=@ud value=json] !=(id (string value 'id'))))
    $(events t.events, previous `sequence, pending (~(del by pending) index), items (~(put by items) index item))
  ?>  (~(has in (silt ~['response.created' 'response.in_progress' 'response.output_text.delta' 'response.output_text.done' 'response.function_call_arguments.delta' 'response.function_call_arguments.done' 'response.content_part.added' 'response.content_part.done' 'response.reasoning_summary_part.added' 'response.reasoning_summary_part.done' 'response.reasoning_summary_text.delta' 'response.reasoning_summary_text.done' 'response.reasoning_text.delta' 'response.reasoning_text.done'])) kind)
  $(events t.events, previous `sequence)
++  anthropic-events
  |=  events=(list json)
  ^-  json
  =/  message=(unit json)  ~
  =/  items=(map @ud json)  ~
  =/  opened=(set @ud)  ~
  =/  fragments=(map @ud @t)  ~
  =/  finished=?  %.n
  |-  ^-  json
  ?>  ?=(^ events)
  =/  event=json  i.events
  =/  kind=@t  (string event 'type')
  ?:  =('ping' kind)  $(events t.events)
  ?:  =('message_start' kind)
    ?>  ?=(~ message)
    =/  initial=json  (need (field:cr event 'message'))
    ?>  =(~ (array initial 'content'))
    $(events t.events, message `initial)
  ?>  ?=(^ message)
  ?:  =('message_stop' kind)
    ?>  &(finished =(~ opened) =(~ t.events))
    (put u.message 'content' [%a (ordered items)])
  ?>  !finished
  ?:  =('message_delta' kind)
    ?>  =(~ opened)
    =/  delta=json  (need (field:cr event 'delta'))
    =/  next=json  (put u.message 'stop_reason' [%s (string delta 'stop_reason')])
    =/  usage=json  (need (field:cr next 'usage'))
    =/  update=json  (need (field:cr event 'usage'))
    ?>  &(?=([%o *] usage) ?=([%o *] update))
    =.  next  (put next 'usage' [%o (~(gas by p.usage) ~(tap by p.update))])
    $(events t.events, message `next, finished %.y)
  =/  index=@ud  (number event 'index')
  ?>  (lth index block-limit:p)
  ?:  =('content_block_start' kind)
    ?>  &(=(~ opened) =(index ~(wyt by items)))
    =/  item=json  (need (field:cr event 'content_block'))
    =/  type=@t  (string item 'type')
    ?>  (~(has in (silt ~['text' 'tool_use' 'thinking' 'redacted_thinking'])) type)
    $(events t.events, items (~(put by items) index item), opened (~(put in opened) index))
  ?>  (~(has in opened) index)
  =/  item=json  (~(got by items) index)
  ?:  =('content_block_stop' kind)
    =/  fragment=(unit @t)  (~(get by fragments) index)
    =/  item=json
      ?~  fragment  item
      ?>  =('tool_use' (string item 'type'))
      (put item 'input' (arguments u.fragment))
    $(events t.events, items (~(put by items) index item), opened (~(del in opened) index), fragments (~(del by fragments) index))
  ?>  =('content_block_delta' kind)
  =/  delta=json  (need (field:cr event 'delta'))
  =/  type=@t  (string delta 'type')
  ?:  =('input_json_delta' type)
    ?>  =('tool_use' (string item 'type'))
    =/  prior=(unit @t)  (~(get by fragments) index)
    =/  next=@t  (cat 3 ?~(prior '' u.prior) (string delta 'partial_json'))
    ?>  (lte (met 3 next) argument-limit:p)
    $(events t.events, fragments (~(put by fragments) index next))
  =/  item=json
    ?:  =('text_delta' type)
      ?>  =('text' (string item 'type'))
      (append item 'text' (string delta 'text') text-limit:p)
    ?:  =('thinking_delta' type)
      ?>  =('thinking' (string item 'type'))
      (append item 'thinking' (string delta 'thinking') response-limit:p)
    ?>  &(=('signature_delta' type) =('thinking' (string item 'type')))
    (append item 'signature' (string delta 'signature') response-limit:p)
  $(events t.events, items (~(put by items) index item))
++  chat-calls
  |=  [parts=(list json) held=(map @ud json)]
  ^-  (map @ud json)
  ?~  parts  held
  =/  part=json  i.parts
  =/  index=@ud  (number part 'index')
  ?>  (lth index call-limit:p)
  =/  previous=(unit json)  (~(get by held) index)
  =/  item=json
    ?^  previous  u.previous
    (pairs:enjs:format ~[['id' s+''] ['type' s+'function'] ['function' (pairs:enjs:format ~[['name' s+''] ['arguments' s+'']])]])
  =/  type=(unit @t)  (string:cr part 'type')
  ?>  ?~(type %.y =('function' u.type))
  =/  id=(unit @t)  (string:cr part 'id')
  =.  item
    ?~  id  item
    ?>  |(=('' (string item 'id')) =(u.id (string item 'id')))
    (put item 'id' [%s u.id])
  =/  fn=json  (need (field:cr item 'function'))
  =/  changes=(unit json)  (field:cr part 'function')
  =/  fn=json
    ?~  changes  fn
    =/  name=(unit @t)  (string:cr u.changes 'name')
    =/  args=(unit @t)  (string:cr u.changes 'arguments')
    =/  fn=json  ?~(name fn (append fn 'name' u.name 64))
    ?~(args fn (append fn 'arguments' u.args argument-limit:p))
  $(parts t.parts, held (~(put by held) index (put item 'function' fn)))
++  chat-events
  |=  events=(list json)
  ^-  json
  =/  base=(unit json)  ~
  =/  usage=(unit json)  ~
  =/  reason=(unit @t)  ~
  =/  text=@t  ''
  =/  refusal=@t  ''
  =/  calls=(map @ud json)  ~
  |-  ^-  json
  =/  rest=(list json)  events
  ?>  ?=(^ rest)
  =/  event=json  i.rest
  ?:  =([%s '[DONE]'] event)
    ?>  &(=(~ t.rest) ?=(^ base) ?=(^ reason))
    ::  The Grok CLI session proxy streams no usage block. Report zeros rather
    ::  than refusing the reply; never invent counts the provider did not send.
    =/  counted=json
      ?^  usage  u.usage
      (pairs:enjs:format ~[['prompt_tokens' n+'0'] ['completion_tokens' n+'0'] ['total_tokens' n+'0']])
    =/  fields=(list [@t json])  ~[['role' s+'assistant'] ['content' s+text]]
    =.  fields  ?~(calls fields [['tool_calls' [%a (ordered calls)]] fields])
    =.  fields  ?:(=('' refusal) fields [['refusal' s+refusal] fields])
    =/  choice=json
      (pairs:enjs:format ~[['index' n+'0'] ['finish_reason' s+u.reason] ['message' (pairs:enjs:format fields)]])
    (put (put u.base 'choices' [%a ~[choice]]) 'usage' counted)
  ?>  (nullable:cr (field:cr event 'error'))
  =.  base
    ?~  base  `event
    ?>  &(=((string u.base 'id') (string event 'id')) =((string u.base 'model') (string event 'model')))
    base
  =.  usage
    =/  found=(unit json)  (field:cr event 'usage')
    ?:((nullable:cr found) usage found)
  =/  choices=(list json)  (array event 'choices')
  ?~  choices
    ?>  ?=(^ reason)
    $(events t.rest)
  =/  current=(unit @t)  reason
  ?>  &(=(~ t.choices) ?=(~ current) =(0 (number i.choices 'index')))
  =/  delta=json  (need (field:cr i.choices 'delta'))
  =/  role=(unit @t)  (string:cr delta 'role')
  ?>  ?~(role %.y =('assistant' u.role))
  ?>  (nullable:cr (field:cr delta 'function_call'))
  =/  content=(unit @t)  (string:cr delta 'content')
  =.  text  ?~(content text (cat 3 text u.content))
  ?>  (lte (met 3 text) text-limit:p)
  =/  refused=(unit @t)  (string:cr delta 'refusal')
  =.  refusal  ?~(refused refusal (cat 3 refusal u.refused))
  ?>  (lte (met 3 refusal) text-limit:p)
  =.  calls
    ?~  (field:cr delta 'tool_calls')  calls
    (chat-calls (array delta 'tool_calls') calls)
  =.  reason  (string:cr i.choices 'finish_reason')
  $(events t.rest)
++  decode
  ::  Caller retains HTTP uncertainty separately. Non-200 and malformed data
  ::  yield fixed error codes; no provider error text or credential is exposed.
  |=  [r=request:p status=@ud data=octs]
  ^-  (each reply:p failure:p)
  =/  digest=@ux  (shax q.data)
  =/  fail
    |=  reason=@tas
    ^-  (each reply:p failure:p)
    [%| [%native-coding-provider-error-v1 id.r provider.selection.r status reason digest]]
  ?.  (request-valid:law r)  (fail %request-invalid)
  ?.  =(200 status)
    (fail ?:(=(401 status) %login-required ?:(=(429 status) %rate-limited %http-error)))
  ?.  &((gth p.data 0) (lte p.data response-limit:p) =(p.data (met 3 q.data)))
    (fail %body-size-invalid)
  =/  attempt
    %-  mole
    |.
    =/  parsed=(unit json)  (de:json:html q.data)
    =/  value=json
      ?^  parsed  u.parsed
      ?>  streaming.r
      =/  events=(list json)  (sse-json q.data)
      ?-  format.selection.r
        %responses  (response-events events)
        %messages  (anthropic-events events)
        %chat  (chat-events events)
      ==
    (normalize r q.data value)
  ?~  attempt  (fail %protocol-invalid)
  [%& u.attempt]
--
