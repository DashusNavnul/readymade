::  Reconnect a retained, confirmed publisher pause. Fresh sync may merge;
::  no restoration of old Kiln nonce, settings, or queued updates is claimed.
::  Source absence is an admission snapshot, not an atomic Hood reservation;
::  another authorized tool can change syncs before Hood processes this card.
/+  mg=readymade-app-management
|%
+$  command
  [owner=@p request=@t pause-request=@t target=binding:mg guard=@ux]
+$  receipt
  $:  request=@t
      hash=@ux
      pause-request=@t
      pause-hash=@ux
      target=binding:mg
      guard=@ux
      attempted=?
      ack=?(%none %accepted %refused)
      status=?(%pending %uncertain %confirmed %refused)
      reason=@tas
  ==
+$  journal  (map @t receipt)
+$  decision  [journal=journal record=receipt dispatch=? code=@ud]
+$  response
  [journal=journal cards=(list card:agent:gall) code=@ud body=json]
+$  saved
  [%pataphor-page-state-v4 previous=* management=journal:mg resume=journal]
++  capacity  4.096
++  base  '/apps/pataphor/app-tasks/reconnect/'
++  digest
  |=  cmd=command
  ^-  @ux
  %-  shax
  %+  rap  3
  :~  'reconnect-publisher'  0xa  (scot %p owner.cmd)  0xa
      request.cmd  0xa  pause-request.cmd  0xa  local.target.cmd  0xa
      (scot %p ship.target.cmd)  0xa  desk.target.cmd  0xa
      (scot %ux guard.cmd)
  ==
++  origin
  |=  [our=@p pauses=journal:mg id=@t]
  ^-  (unit receipt:mg)
  =/  found  (~(get by pauses) id)
  ?~  found  ~
  ?.  ?&  (uuid:mg id)  =(id request.u.found)
          (valid-journal:mg our (~(put by *journal:mg) id u.found))
          =(%accepted ack.u.found)  =(%confirmed status.u.found)
          =(%exact-source-absent reason.u.found)
      ==
    ~
  found
++  consumed
  |=  [id=@t entries=journal]
  ^-  ?
  %+  lien  ~(tap by entries)
  |=  row=[key=@t item=receipt]
  &(attempted.item.row =(id pause-request.item.row) !=(%refused status.item.row))
++  blocked
  |=  [local=@tas entries=journal]
  ^-  ?
  %+  lien  ~(tap by entries)
  |=  row=[key=@t item=receipt]
  ?&  attempted.item.row  =(local local.target.item.row)
      |(=(%pending status.item.row) =(%uncertain status.item.row))
  ==
++  attempt-history
  ::  Canonical map of this origin's admitted attempts; unrelated work is excluded.
  |=  [id=@t entries=journal]
  ^-  journal
  %-  malt
  %+  skim  ~(tap by entries)
  |=  row=[key=@t item=receipt]
  &(attempted.item.row =(id pause-request.item.row))
++  guard
  |=  [our=@p pause=receipt:mg ctx=context:mg entries=journal]
  ^-  @ux
  (shax (jam [%reconnect-publisher-v1 our protocol-pin:mg pause ctx %local-syncs-absent (attempt-history request.pause entries)]))
++  eligibility
  |=  [our=@p pauses=journal:mg entries=journal id=@t observed=snapshot:mg]
  ^-  @tas
  =/  pause  (origin our pauses id)
  ?~  pause  %invalid-pause
  ?:  (consumed id entries)  %origin-used
  ?.  &(available.observed =(our owner.observed))  %protocol-unavailable
  ?.  (~(has by installed.observed) local.target.u.pause)  %not-installed
  ?:  |((blocked:mg local.target.u.pause pauses) (blocked local.target.u.pause entries))
    %target-pending
  ?.  =(0 (count-local:mg local.target.u.pause syncs.observed))  %source-present
  ?:  (gte ~(wyt by entries) capacity)  %journal-full
  %ready
++  status-code
  |=  item=receipt
  ^-  @ud
  ?-  status.item
    %pending    202
    %uncertain  202
    %confirmed  200
    %refused    409
  ==
++  admit
  |=  [our=@p src=@p cmd=command pauses=journal:mg entries=journal observed=snapshot:mg]
  ^-  decision
  =/  pause  (origin our pauses pause-request.cmd)
  =/  item=receipt
    [request.cmd (digest cmd) pause-request.cmd ?~(pause 0x0 (shax (jam u.pause))) target.cmd guard.cmd %.n %none %refused %invalid-pause]
  ?.  ?&  =(our src)  =(our owner.cmd)
          (uuid:mg request.cmd)  (uuid:mg pause-request.cmd)
          (target-valid:mg target.cmd)  !=(0 guard.cmd)
          (lte (met 3 guard.cmd) 32)
      ==
    [entries item(reason %owner-or-command) %.n 403]
  =/  known  (~(get by entries) request.cmd)
  ?^  known
    ?.  =(hash.u.known hash.item)
      [entries item(reason %request-conflict) %.n 409]
    [entries u.known %.n (status-code u.known)]
  ?:  (gte ~(wyt by entries) capacity)
    [entries item(reason %journal-full) %.n 503]
  =/  why=@tas
    ?~  pause  %invalid-pause
    ?.  =(target.cmd target.u.pause)  %target-mismatch
    =/  ready  (eligibility our pauses entries pause-request.cmd observed)
    ?.  =(%ready ready)  ready
    ?.  =(guard.cmd (guard our u.pause (~(got by installed.observed) local.target.cmd) entries))
      %stale-guard
    %ready
  =/  dispatch=?  =(%ready why)
  =.  item
    item(attempted dispatch, status ?:(dispatch %pending %refused), reason ?:(dispatch %awaiting-native-ack why))
  [(~(put by entries) request.cmd item) item dispatch ?:(dispatch 202 409)]
++  settle
  |=  [our=@p pauses=journal:mg entries=journal request=@t observed=snapshot:mg]
  ^-  journal
  =/  known  (~(get by entries) request)
  ?~  known  entries
  =/  item=receipt  u.known
  ?.  &(attempted.item =(%accepted ack.item) =(%uncertain status.item))  entries
  =/  pause  (origin our pauses pause-request.item)
  =/  why=@tas
    ?~  pause  %pause-changed
    ?.  &(=(pause-hash.item (shax (jam u.pause))) =(target.item target.u.pause))
      %pause-changed
    ?.  &(available.observed =(our owner.observed))  %readback-unavailable
    ?.  (~(has by installed.observed) local.target.item)  %readback-unavailable
    ?.  =(1 (count-local:mg local.target.item syncs.observed))
      ?:(=(0 (count-local:mg local.target.item syncs.observed)) %source-not-observed %source-ambiguous)
    ?.  (~(has by syncs.observed) target.item)  %source-not-observed
    %exact-source-present
  (~(put by entries) request item(status ?:(=(why %exact-source-present) %confirmed %uncertain), reason why))
++  needs-observation
  |=  [entries=journal request=@t accepted=?]
  ^-  ?
  ?.  accepted  %.n
  =/  found  (~(get by entries) request)
  ?~  found  %.n
  &(attempted.u.found =(%none ack.u.found) =(%pending status.u.found))
++  acknowledge
  ::  Caller supplies only its authenticated matching native Hood ACK.
  |=  [our=@p pauses=journal:mg entries=journal request=@t accepted=? observed=snapshot:mg]
  ^-  journal
  =/  found  (~(get by entries) request)
  ?~  found  entries
  =/  item=receipt  u.found
  ?.  &(attempted.item =(%none ack.item) =(%pending status.item))  entries
  ?.  accepted
    (~(put by entries) request item(ack %refused, status %refused, reason %native-refused))
  (settle our pauses (~(put by entries) request item(ack %accepted, status %uncertain, reason %awaiting-readback)) request observed)
++  valid-journal
  |=  [our=@p pauses=journal:mg entries=journal]
  ^-  ?
  ?.  (lte ~(wyt by entries) capacity)  %.n
  =/  rows=(list [key=@t item=receipt])  ~(tap by entries)
  =/  seen=(set @t)  ~
  =/  pending-locals=(set @tas)  ~
  |-  ^-  ?
  ?~  rows  %.y
  =/  key=@t  key.i.rows
  =/  item=receipt  item.i.rows
  ?.  ?&  =(key request.item)  (uuid:mg key)  (uuid:mg pause-request.item)
          (target-valid:mg target.item)  !=(0 guard.item)
          (lte (met 3 guard.item) 32)  (lte (met 3 pause-hash.item) 32)
          =(hash.item (digest [our key pause-request.item target.item guard.item]))
          (lte (met 3 reason.item) 64)
      ==
    %.n
  ?.  attempted.item
    ?.  &(=(%none ack.item) =(%refused status.item))  %.n
    $(rows t.rows)
  =/  consuming=?  !=(%refused status.item)
  ?:  &(consuming (~(has in seen) pause-request.item))  %.n
  =/  inflight=?  |(=(%pending status.item) =(%uncertain status.item))
  ?:  &(inflight (~(has in pending-locals) local.target.item))  %.n
  ?:  &(|(=(%pending status.item) =(%uncertain status.item)) (blocked:mg local.target.item pauses))
    %.n
  =/  pause  (origin our pauses pause-request.item)
  ?~  pause  %.n
  ?.  &(=(pause-hash.item (shax (jam u.pause))) =(target.item target.u.pause))  %.n
  ?.  ?-  ack.item
        %none      &(=(%pending status.item) =(%awaiting-native-ack reason.item))
        %accepted  ?:(=(%confirmed status.item) =(%exact-source-present reason.item) =(%uncertain status.item))
        %refused   &(=(%refused status.item) =(%native-refused reason.item))
      ==
    %.n
  $(rows t.rows, seen ?:(consuming (~(put in seen) pause-request.item) seen), pending-locals ?:(inflight (~(put in pending-locals) local.target.item) pending-locals))
++  unwrap
  ::  Only ordinary saved DATA is parsed. The original legacy vase stays opaque.
  |=  [our=@p old=vase]
  ^-  (unit [previous=vase resume=journal])
  ?.  ?=([%pataphor-page-state-v4 *] q.old)  `[old ~]
  =/  parsed  ((soft saved) q.old)
  ?~  parsed  ~
  ?.  ?=([%pataphor-page-state-v2 * *] previous.u.parsed)  ~
  ?.  (valid-journal:mg our management.u.parsed)  ~
  ?.  (valid-journal our management.u.parsed resume.u.parsed)  ~
  `[!>([%pataphor-page-state-v3 previous.u.parsed management.u.parsed]) resume.u.parsed]
++  gate-pause
  ::  A no-card GET/replay is byte exact. Only the fresh proposed dispatch changes.
  |=  [our=@p entries=journal prepared=response:mg]
  ^-  response:mg
  ?~  cards.prepared  prepared
  ?>  ?=([* ~] cards.prepared)
  =/  card=card:agent:gall  i.cards.prepared
  ?>  ?=([%pass * %agent * %poke %kiln-unsync *] card)
  =/  [tag=* wire=wire act=* dock=[@p @tas] poke=* mark=* payload=vase]  card
  ?>  =(dock [our %hood])
  ?>  ?=([%management @ ~] wire)
  =/  request=@t  i.t.wire
  =/  item=receipt:mg  (~(got by journal.prepared) request)
  ?>  &(=(request request.item) =(%none ack.item) =(%pending status.item))
  ?>  =(q.payload target.item)
  ?>  (valid-journal:mg our (~(put by *journal:mg) request item))
  ?.  (blocked local.target.item entries)  prepared
  =.  item  item(status %refused, reason %resume-pending, remaining ~)
  [(~(put by journal.prepared) request item) ~ 409 (receipt-json:mg our item)]
++  decode
  |=  raw=@t
  ^-  command
  ?>  =(9 (lent (skim (trip raw) |=(c=@t =(c ':')))))
  =/  data=json  (need (de:json:html raw))
  ?>  ?=(%o -.data)
  =/  obj=(map @t json)  p.data
  ?>  =(9 ~(wyt by obj))
  ?>  =('readymade-reconnect-command-v1' (text-field:mg obj 'schema' 64))
  ?>  =('reconnect-publisher' (text-field:mg obj 'task' 32))
  =/  owner-text  (text-field:mg obj 'owner' 128)
  =/  owner=@p  (need (slaw %p owner-text))
  ?>  =(owner-text (scot %p owner))
  =/  request  (text-field:mg obj 'request' 36)
  =/  pause-request  (text-field:mg obj 'pauseRequest' 36)
  ?>  &((uuid:mg request) (uuid:mg pause-request))
  =/  local  (text-field:mg obj 'local' 64)
  =/  ship-text  (text-field:mg obj 'sourceShip' 128)
  =/  ship=@p  (need (slaw %p ship-text))
  ?>  =(ship-text (scot %p ship))
  =/  desk  (text-field:mg obj 'sourceDesk' 64)
  =/  target=binding:mg  [`@tas`local ship `@tas`desk]
  ?>  (target-valid:mg target)
  =/  hex  (text-field:mg obj 'guard' 81)
  =/  guard=@ux  (need (slaw %ux hex))
  ?>  &(!=(0 guard) (lte (met 3 guard) 32) =(hex (scot %ux guard)))
  [owner request pause-request target guard]
++  parse
  |=  raw=@t
  ^-  (unit command)
  ?.  (lte (met 3 raw) 4.096)  ~
  (mole |.((decode raw)))
++  receipt-json
  |=  [our=@p item=receipt]
  ^-  json
  %-  pairs:enjs:format
  ^-  (list [@t json])
  :~  ['schema' s+'readymade-reconnect-result-v1']
      ['owner' s+(scot %p our)]
      ['task' s+'reconnect-publisher']
      ['request' s+request.item]
      ['pauseRequest' s+pause-request.item]
      ['local' s+local.target.item]
      ['sourceShip' s+(scot %p ship.target.item)]
      ['sourceDesk' s+desk.target.item]
      ['guard' s+(scot %ux guard.item)]
      ['commandHash' s+(scot %ux hash.item)]
      ['pauseHash' s+(scot %ux pause-hash.item)]
      ['attempted' b+attempted.item]
      ['ack' s+(scot %tas ack.item)]
      ['status' s+(scot %tas status.item)]
      ['reason' s+(scot %tas reason.item)]
      ['observedSources' ?:(=(%confirmed status.item) s+'1' ~)]
      ['freshSync' b+%.y]
      ['mayMerge' b+%.y]
      ['restoresPriorSettings' b+%.n]
  ==
++  pending-rows
  |=  [entries=journal cursor=@t]
  ^-  (list [id=@t item=receipt])
  (sort (skim ~(tap by entries) |=([id=@t item=receipt] &(attempted.item |(=(%pending status.item) =(%uncertain status.item)) (gth id cursor)))) |=([a=[id=@t item=receipt] b=[id=@t item=receipt]] (lth id.a id.b)))
++  last-id
  |=  rows=(list [id=@t item=receipt])
  ^-  @t
  =/  last=@t  ''
  |-  ^-  @t
  ?~  rows  last
  $(rows t.rows, last id.i.rows)
++  pending-json
  |=  [our=@p entries=journal cursor=@t]
  ^-  json
  =/  all  (pending-rows entries cursor)
  =/  selected  (scag 32 all)
  %-  pairs:enjs:format
  ^-  (list [@t json])
  :~  ['schema' s+'readymade-reconnect-pending-v1']
      ['owner' s+(scot %p our)]
      ['cursor' s+cursor]
      ['next' s+(last-id selected)]
      ['more' b+(gth (lent all) 32)]
      ['receipts' a+(turn selected |=([id=@t item=receipt] (receipt-json our item)))]
  ==
++  state-json
  |=  [our=@p pauses=journal:mg entries=journal observed=snapshot:mg cursor=@t]
  ^-  json
  =/  all=(list [id=@t item=receipt:mg])
    (sort (skim ~(tap by pauses) |=([id=@t item=receipt:mg] &((gth id cursor) ?=(^ (origin our pauses id))))) |=([a=[id=@t item=receipt:mg] b=[id=@t item=receipt:mg]] (lth id.a id.b)))
  =/  selected  (scag 32 all)
  =/  next=@t
    =/  todo=(list [id=@t item=receipt:mg])  selected
    =/  last=@t  ''
    |-  ^-  @t
    ?~  todo  last
    $(todo t.todo, last id.i.todo)
  =/  rows=(list json)
    %+  turn  selected
    |=  [id=@t item=receipt:mg]
    =/  why  (eligibility our pauses entries id observed)
    =/  ctx  (~(get by installed.observed) local.target.item)
    %-  pairs:enjs:format
    ^-  (list [@t json])
    :~  ['pauseRequest' s+id]
        ['local' s+local.target.item]
        ['sourceShip' s+(scot %p ship.target.item)]
        ['sourceDesk' s+desk.target.item]
        ['pauseHash' s+(scot %ux (shax (jam item)))]
        ['guard' s+(scot %ux ?~(ctx 0 (guard our item u.ctx entries)))]
        ['available' b+=(why %ready)]
        ['reason' s+(scot %tas why)]
        ['used' b+(consumed id entries)]
    ==
  %-  pairs:enjs:format
  ^-  (list [@t json])
  :~  ['schema' s+'readymade-reconnect-state-v1']
      ['owner' s+(scot %p our)]
      ['protocolPin' s+(scot %ux `@ux`protocol-pin:mg)]
      ['available' b+&(available.observed =(our owner.observed))]
      ['cursor' s+cursor]
      ['next' s+next]
      ['more' b+(gth (lent all) 32)]
      ['origins' a+rows]
      ['freshSync' b+%.y]
      ['mayMerge' b+%.y]
      ['restoresPriorSettings' b+%.n]
  ==
++  error-json
  |=  reason=@tas
  ^-  json
  (pairs:enjs:format `(list [@t json])`~[['schema' s+'readymade-reconnect-error-v1'] ['reason' s+(scot %tas reason)]])
++  post-ready
  |=  req=inbound-request:eyre
  ^-  ?
  =/  host  (header:mg header-list.request.req 'host')
  =/  origin  (header:mg header-list.request.req 'origin')
  =/  mime  (header:mg header-list.request.req 'content-type')
  ?~  host  %.n
  ?~  origin  %.n
  ?~  mime  %.n
  ?&  =(u.origin (cat 3 ?:(secure.req 'https://' 'http://') u.host))
      |(=(u.mime 'application/json') =(u.mime 'application/json; charset=utf-8'))
      =(`'reconnect-v1' (header:mg header-list.request.req 'x-readymade-reconnect'))
  ==
++  handle
  |=  [b=bowl:gall req=inbound-request:eyre pauses=journal:mg entries=journal]
  ^-  response
  ?.  &(authenticated.req =(our.b src.b))
    [entries ~ 403 (error-json %owner-required)]
  ?.  =(`'reconnect-v1' (header:mg header-list.request.req 'x-readymade-reconnect'))
    [entries ~ 403 (error-json %marker-required)]
  =/  url=@t  url.request.req
  =/  state-prefix  (cat 3 base 'state/')
  ?:  =(state-prefix (end [3 (met 3 state-prefix)] url))
    ?.  =('GET' method.request.req)  [entries ~ 405 (error-json %method)]
    =/  cursor=@t  (rsh [3 (met 3 state-prefix)] url)
    =?  cursor  =(cursor 'start')  ''
    ?.  |(=(cursor '') (uuid:mg cursor))  [entries ~ 400 (error-json %request)]
    [entries ~ 200 (state-json our.b pauses entries (native:mg b) cursor)]
  =/  pending-prefix  (cat 3 base 'pending/')
  ?:  =(pending-prefix (end [3 (met 3 pending-prefix)] url))
    ?.  =('GET' method.request.req)  [entries ~ 405 (error-json %method)]
    =/  cursor=@t  (rsh [3 (met 3 pending-prefix)] url)
    =?  cursor  =(cursor 'start')  ''
    ?.  |(=(cursor '') (uuid:mg cursor))  [entries ~ 400 (error-json %request)]
    [entries ~ 200 (pending-json our.b entries cursor)]
  =/  result-prefix  (cat 3 base 'result/')
  ?:  =(result-prefix (end [3 (met 3 result-prefix)] url))
    ?.  =('GET' method.request.req)  [entries ~ 405 (error-json %method)]
    =/  request=@t  (rsh [3 (met 3 result-prefix)] url)
    ?.  (uuid:mg request)  [entries ~ 400 (error-json %request)]
    =/  prior  (~(get by entries) request)
    ?~  prior  [entries ~ 404 (error-json %not-found)]
    =/  next=journal
      ?.  &(attempted.u.prior =(%accepted ack.u.prior) =(%uncertain status.u.prior))  entries
      (settle our.b pauses entries request (native:mg b))
    =/  item=receipt  (~(got by next) request)
    [next ~ (status-code item) (receipt-json our.b item)]
  ?.  =(url (cat 3 base 'reconnect.json'))  [entries ~ 404 (error-json %route)]
  ?.  =('POST' method.request.req)  [entries ~ 405 (error-json %method)]
  ?.  (post-ready req)  [entries ~ 403 (error-json %origin-or-content-type)]
  =/  body=(unit octs)  body.request.req
  ?~  body  [entries ~ 400 (error-json %body)]
  ?.  &((lte p.u.body 4.096) =(p.u.body (met 3 q.u.body)))
    [entries ~ 413 (error-json %body-bound)]
  =/  cmd  (parse `@t`q.u.body)
  ?~  cmd  [entries ~ 400 (error-json %command)]
  ::  Known UUIDs never trigger a fresh native observation or repeat a dispatch.
  =/  observed=snapshot:mg
    ?:  (~(has by entries) request.u.cmd)  *snapshot:mg
    (native:mg b)
  =/  result  (admit our.b src.b u.cmd pauses entries observed)
  =/  cards=(list card:agent:gall)
    ?.  dispatch.result  ~
    ~[[%pass /reconnect/[request.u.cmd] %agent [our.b %hood] %poke %kiln-sync !>(target.u.cmd)]]
  [journal.result cards code.result (receipt-json our.b record.result)]
--
