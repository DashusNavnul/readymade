::  Native pinned Clay reads. Parent page owns owner checks and watch lifecycle.
/+  r=readymade-changes, p=readymade-projects, cv=clay-view, dd=desk-diff
|%
++  token
  |=  value=@t
  ^-  (unit @uv)
  ?.  (lte (met 3 value) 64)  ~
  =/  parsed=(unit @uv)  (slaw %uv value)
  ?~  parsed  ~
  ?.  &(=(value (scot %uv u.parsed)) (lte (met 0 u.parsed) 128))  ~
  parsed
++  route
  |=  pax=path
  ^-  (unit selection:r)
  ?.  ?=([%changes @ @ @ @ @ @ @ *] pax)  ~
  =/  source  (token i.t.pax)
  =/  seat=@tas  i.t.t.pax
  =/  base=@tas  i.t.t.t.pax
  =/  br  (cursor:p i.t.t.t.t.pax)
  =/  fr  (cursor:p i.t.t.t.t.t.pax)
  =/  start  (cursor:p i.t.t.t.t.t.t.pax)
  =/  line  (cursor:p i.t.t.t.t.t.t.t.pax)
  ?~  source  ~
  ?~  br  ~
  ?~  fr  ~
  ?~  start  ~
  ?~  line  ~
  =/  file=(unit path)
    ?~  t.t.t.t.t.t.t.t.pax  ~
    `t.t.t.t.t.t.t.t.pax
  =/  selected=selection:r  [u.source seat base u.br u.fr u.start file u.line]
  ?.  (selection-valid:r selected)  ~
  `selected
++  path-for
  |=  selected=selection:r
  ^-  path
  =/  head=path
    /changes/(scot %uv source.selected)/[seat.selected]/[base.selected]/(scot %ud base-revision.selected)/(scot %ud fork-revision.selected)/(scot %ud start.selected)/(scot %ud line.selected)
  ?~  file.selected  head
  (weld head u.file.selected)
++  read-tree
  |=  [our=@p now=@da desk=@tas revision=@ud]
  ^-  (unit [revision=@ud files=(map path @uv)])
  =/  at=@ud  ?:(=(0 revision) (rev:cv our desk) revision)
  =/  dome=dome:clay  (dome-of:dd our now desk)
  ?.  (~(has by hit.dome) at)  ~
  `[at (path-map:dd our now desk at)]
++  read-blob
  |=  [our=@p desk=@tas revision=@ud pax=path lobe=(unit @uv)]
  ^-  blob:r
  ?~  lobe  [~ 0 (shax '') `'']
  =/  at=path  (weld /(scot %p our)/[desk]/(scot %ud revision) pax)
  ?.  .^(? %cu at)  [lobe 0 0x0 ~]
  =/  raw=*  .^(* %cq at)
  =/  source=(unit @t)
    ?@  raw  `raw
    (bind ((soft wain) raw) of-wain:format)
  ?~  source  [lobe 0 0x0 ~]
  =/  size=@ud  (met 3 u.source)
  [lobe size (shax u.source) ?:((lte size 65.536) source ~)]
++  empty
  |=  [our=@p selected=selection:r why=@t]
  ^-  snapshot:r
  [%readymade-changes-v1 our [source.selected seat.selected base.selected base-revision.selected fork-revision.selected 0x0] start.selected 0 ~ ~ ~ `why]
++  project
  |=  [b=bowl:gall selected=selection:r]
  ^-  snapshot:r
  ?.  =(our.b src.b)  (empty our.b selected 'Only the owner may read reviewed changes.')
  ?.  (selection-valid:r selected)  (empty our.b selected 'Invalid review selection.')
  =/  names=(set @tas)  .^((set @tas) %cd ~[(scot %p our.b) '' (scot %da now.b)])
  ?.  &((~(has in names) base.selected) (~(has in names) seat.selected))
    (empty our.b selected 'The native base or Bachelor fork is absent.')
  =/  before  (read-tree our.b now.b base.selected base-revision.selected)
  =/  after  (read-tree our.b now.b seat.selected fork-revision.selected)
  ?~  before  (empty our.b selected 'The exact base revision is unavailable.')
  ?~  after  (empty our.b selected 'The exact fork revision is unavailable.')
  ?:  |((gth ~(wyt by files.u.before) 20.000) (gth ~(wyt by files.u.after) 20.000))
    (empty our.b selected 'Review exceeds 20000 paths per desk; no incomplete manifest was substituted.')
  =/  out=snapshot:r
    (page:r our.b source.selected seat.selected base.selected revision.u.before revision.u.after files.u.before files.u.after start.selected)
  ?.  (levy rows.out |=(row=change:r (path-valid:p pax.row)))
    out(rows ~, next ~, problem `'This page contains unsupported pathnames; no partial change list was substituted.')
  ?~  file.selected  out
  =/  pax=path  u.file.selected
  =/  a=blob:r  (read-blob our.b base.selected revision.u.before pax (~(get by files.u.before) pax))
  =/  z=blob:r  (read-blob our.b seat.selected revision.u.after pax (~(get by files.u.after) pax))
  ?:  =(lobe.a lobe.z)
    out(problem `'The selected path is unchanged at these exact versions.')
  out(file `(file-page:r pax a z line.selected))
++  paths
  |=  [our=@p sup=bitt:gall]
  ^-  (list path)
  =/  found=(list path)
    %+  murn  ~(val by sup)
    |=  [who=@p pax=path]
    ^-  (unit path)
    ?.  =(our who)  ~
    ?~  (route pax)  ~
    `pax
  ~(tap in (silt found))
++  admit
  |=  [pax=path wanted=(list path)]
  ^-  ?
  &(?=(^ (route pax)) (lte (lent wanted) 32))
++  desks
  |=  [our=@p sup=bitt:gall]
  ^-  (set @tas)
  =/  all=(list @tas)
    %-  zing
    %+  turn  (paths our sup)
    |=  pax=path
    =/  selected=selection:r  (need (route pax))
    ~[base.selected seat.selected]
  (silt all)
++  facts
  |=  [b=bowl:gall changed=(unit @tas)]
  ^-  (list card:agent:gall)
  =/  wanted=(list path)
    %+  skim  (paths our.b sup.b)
    |=  pax=path
    ?~  changed  %.y
    =/  selected=selection:r  (need (route pax))
    |(=(u.changed base.selected) =(u.changed seat.selected))
  %+  turn  wanted
  |=  pax=path
  [%give %fact ~[pax] %noun !>((project b (need (route pax))))]
++  prove
  =/  selected=selection:r  [0v1 %flunky %repo 10 20 0 `/lib/test/hoon 64]
  ?>  =(`selected (route (path-for selected)))
  ?>  ?=(~ (route ~[%changes '0v01' %flunky %repo '10' '20' '0' '0']))
  ?>  ?=(~ (route /changes/0v1/stranger/repo/10/20/0/0))
  ?>  ?=(~ (route /changes/0v1/flunky/flunky/10/20/0/0))
  ?>  ?=(~ (token '-1'))
  ?>  ?=(^ (token '0v0'))
  %readymade-changes-publisher-proof-v1
--
