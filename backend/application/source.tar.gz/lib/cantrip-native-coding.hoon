::  Cantrip's standing native tool scope and replay ledger, without expiry.
::  Tool candidates remain proposals; separate native checks and Viki decisions
::  admit one guarded landing under the current Cantrip law window.
/-  nc=native-coding
/+  project=native-coding-project, files=native-coding-files, guard=viki-scry-guard,
    accept=native-coding-accept, editor=cantrip-editor-save, law=cantrip-law-window,
    local=native-coding-local-decision, artifact=readymade-artifact-executor,
    contract=cantrip-native-coding-contract, budget=native-coding-hoon-check-budget,
    ceiling=native-coding-request-ceiling
|%
::  Lifetime stores: never evicted, so these are ceilings across all campaigns.
::  Raised 2026-11-01 for the 34-task measurement (docs/qpc/QPC-TASK-BACKLOG-20261101.md).
++  capacity  8.192
++  grant-capacity  512
++  key  key:contract
++  digest
  |=  value=*
  ^-  @ux
  (shax (jam [%cantrip-native-coding-v1 value]))
++  wire-for
  |=  id=@ux
  ^-  wire
  /native-coding/(scot %ux id)
++  wire-key
  |=  w=wire
  ^-  (unit @ux)
  ?.  ?=([%native-coding @ ~] w)  ~
  =/  id  (slaw %ux i.t.w)
  ?~  id  ~
  ?:(=(w (wire-for u.id)) id ~)
++  identifier
  |=  id=@ux
  ^-  ?
  &(!=(0 id) (lte (met 0 id) 256))
++  executable
  |=  op=operation:nc
  ^-  ?
  ?=(?(%compile %check %eval %inspect) op)
+$  grant  grant:contract
+$  scope  scope:contract
+$  record  record:contract
+$  organ  organ:contract
+$  command
  $%  [%native-coding-grant-v1 value=grant]
      [%native-coding-revoke-v1 id=@ux]
      [%native-coding-execute-v1 grant=@ux request=tool-request:nc]
      [%native-coding-observe-v1 id=@ux]
      [%native-coding-cancel-v1 id=@ux]
  ==
+$  change  [next=organ cards=(list card:agent:gall)]
++  candidate-budget-scope-valid
  ::  The larger total is for Hoon candidate checks, not PLAN or eval tools.
  |=  g=grant
  ^-  ?
  ?&  ?=(^ targets.project.g)  (supported:budget targets.project.g)
      !(~(has in operations.g) %eval)  !(~(has in operations.g) %inspect)
      (levy ~(tap by file-types.project.g) |=([suffix=@tas mark=@tas] &(=(%hoon suffix) =(%hoon mark))))
  ==
++  grant-valid
  |=  [our=@p g=grant]
  ^-  ?
  ?&  (identifier id.g)  (identifier session.g)
      (valid:project project.g)  =(our authority.spec.project.g)
      (lte ~(wyt in operations.g) 32)
      (levy ~(tap in operations.g) |=(op=operation:nc (~(has in operations.policy.project.g) op)))
      (lte ~(wyt in inspections.g) 32)
      (levy ~(tap in inspections.g) |=([app=@tas pax=path] &(!=(0 app) (path-valid:project pax))))
      (gte max-eval-work.g 1)  (lte max-eval-work.g candidate-total-limit:budget)
      |((lte max-eval-work.g expression-limit:budget) (candidate-budget-scope-valid g))
  ==
++  evaluation-budget-valid
  ::  A larger explicitly granted candidate total never enlarges one eval.
  |=  [g=grant fuel=@ud]
  ^-  ?
  &((gte fuel 1) (lte fuel max-eval-work.g) (lte fuel expression-limit:budget))
++  rejected-valid
  ::  Compatibility only. A retained refusal grants no operation or worker order.
  ::  The producer still emits only the original four stages in this phase.
  |=  [our=@p id=@ux r=record]
  ^-  ?
  ?.  =(%rejected stage.r)  %.n
  ?~  result.r  %.n
  =/  request=tool-request:nc  request.r
  =/  c=context:nc  context.request
  =/  out=tool-result:nc  u.result.r
  ?.  ?&  (identifier id)  (identifier grant.r)
          (lte (met 3 (jam request)) 262.144)  =(id (key request))
          (gth at.r 0)  (lte (met 0 at.r) 128)
          (gte (met 3 project.c) 1)  (lte (met 3 project.c) 128)
          (identifier configuration.c)  (identifier session.c)  (identifier request.c)
          (lte (met 0 actor.c) 128)  =(our owner.source.c)
          (revision-valid:project source.c)  (segment-valid:project desk.source.c)
          (lte (met 0 number.source.c) 64)
          (lte (met 0 root.source.c) 256)  (lte (met 0 commit.source.c) 256)
          (gte (met 3 call-id.request) 1)  (lte (met 3 call-id.request) 256)
          =(c context.out)  =(call-id.request call-id.out)
          ?=(%refused -.output.out)
      ==  %.n
  ?>  ?=(%refused -.output.out)
  ?&  (gte (met 3 reason.output.out) 1)  (lte (met 3 reason.output.out) 128)
      (gte (met 3 detail.output.out) 1)  (lte (met 3 detail.output.out) 2.048)
  ==
++  valid
  |=  [our=@p s=organ]
  ^-  ?
  ?&  (lte ~(wyt by grants.s) grant-capacity)  (lte ~(wyt by records.s) capacity)
      (levy ~(tap by grants.s) |=([id=@ux v=scope] &(=(id id.grant.v) (grant-valid our grant.v))))
      %+  levy  ~(tap by records.s)
      |=  [id=@ux r=record]
      ?:  =(%rejected stage.r)  (rejected-valid our id r)
      ?&  =(id (key request.r))  (~(has by grants.s) grant.r)
          ?~  result.r
            ?=(?(%running %unknown) stage.r)
          &(=(context.request.r context.u.result.r) =(call-id.request.r call-id.u.result.r) !=(%running stage.r))
      ==
  ==
++  pending
  ::  A same-ship poke alone cannot invent Viki's selected tool request.
  |=  [our=@p at=@da r=tool-request:nc]
  ^-  ?
  ?.  (agent-live:guard our at %viki)  %.n
  =/  id=@ux  (key r)
  =/  canonical=(unit tool-request:nc)
    .^((unit tool-request:nc) %gx /(scot %p our)/viki/(scot %da at)/native-coding/tool/(scot %ux id)/noun)
  =(`r canonical)
++  request-permits
  ::  Same-event owner-private read; a missing route fails closed, while a
  ::  canonical empty entry preserves unrestricted legacy request behavior.
  |=  [our=@p at=@da g=@ux c=context:nc operations=(list operation:nc)]
  ^-  ?
  =/  retained=(unit record:ceiling)
    .^((unit record:ceiling) %gx /(scot %p our)/cantrip/(scot %da at)/native-coding/request-ceiling/(scot %ux request.c)/noun)
  (permits:ceiling our g retained c operations)
++  allowed
  |=  [our=@p at=@da g=scope r=tool-request:nc]
  ^-  (each ~ @tas)
  ?.  &((grant-valid our grant.g) =(~ revoked.g))  [%| %standing-grant-revoked]
  =/  p=project:nc  project.grant.g
  =/  c=context:nc  context.r
  ?.  &(=(session.grant.g session.c) =(actor.grant.g actor.c) =((configuration:project p) configuration.c))
    [%| %standing-scope-mismatch]
  =/  operations=(list operation:nc)  (operations:project arguments.r)
  ?.  (request-permits our at id.grant.g c operations)
    [%| %request-operation-ceiling]
  ?.  &((levy operations |=(op=operation:nc (~(has in operations.grant.g) op))) ?=(^ operations) (gte (met 3 call-id.r) 1) (lte (met 3 call-id.r) 256))
    [%| %tool-outside-scope]
  =/  catalog  (catalog:project our at p)
  ?:  ?=(%| -.catalog)  [%| p.catalog]
  =/  denied=(list @tas)
    %+  murn  operations
    |=  op=operation:nc
    =/  admitted  (authorize:project p p.catalog c op)
    ?:(?=(%| -.admitted) `p.admitted ~)
  ?^  denied  [%| i.denied]
  =/  current  (current:project our at p)
  ?:  ?=(%| -.current)  [%| p.current]
  =/  source  (tree-at:project our at p desk.source.c number.source.c)
  ?:  ?=(%| -.source)  [%| p.source]
  ?.  =(source.c revision.p.source)  [%| %source-commitment-mismatch]
  ?:  &((mutating:project -.arguments.r) !=(source.c revision.working.p.current))
    [%| %working-source-changed]
  ::  Fixed artifact requests retain ALL ordinary standing-scope checks above.
  ::  candidate-permission reuses this arm immediately before final landing.
  =/  bilateral  (permission:artifact our at p r)
  ?:  ?=(%| -.bilateral)  [%| p.bilateral]
  ?:  ?=(%eval -.arguments.r)
    ?:  |(!(evaluation-budget-valid grant.g fuel.arguments.r) (gth (met 3 expression.arguments.r) 8.192))
      [%| %evaluation-budget-refused]
    ?:  !(readable:project p pax.arguments.r)  [%| %evaluation-path-refused]
    [%& ~]
  ?:  ?=(%inspect -.arguments.r)
    ?:  !(~(has in inspections.grant.g) [app.arguments.r pax.arguments.r])  [%| %inspection-outside-scope]
    [%& ~]
  [%& ~]
++  report
  |=  [our=@p r=tool-result:nc]
  ^-  card:agent:gall
  [%pass /native-coding-result %agent [our %viki] %poke %noun !>(r)]
++  evidence
  |=  [our=@p value=*]
  ^-  card:agent:gall
  [%pass /native-coding-evidence %agent [our %graf] %poke %graf-action !>([%attest [%cantrip-native-coding-v1 (digest value) value]])]
++  refusal
  |=  [r=tool-request:nc reason=@tas detail=@t]
  ^-  tool-result:nc
  [%native-coding-tool-result-v1 context.r call-id.r [%refused reason detail]]
++  finish
  |=  [our=@p s=organ id=@ux r=record value=tool-result:nc]
  ^-  change
  =/  out=record  r(stage %finished, result `value)
  [s(records (~(put by records.s) id out)) ~[(evidence our [%result id out]) (report our value)]]
++  public-job
  |=  [id=@ux r=record]
  ^-  job:nc
  [id context.request.r ?-(stage.r %running %running, %unknown %unknown, %cancelled %cancelled, %rejected %refused, %finished ?~(result.r %refused ?:(?=(%refused -.output.u.result.r) %refused %finished))) ~[(digest r)]]
++  jobs
  |=  [s=organ r=tool-request:nc cursor=@ud limit=@ud]
  ^-  tool-output:nc
  ?.  &((gte limit 1) (lte limit 64))  [%refused %page-invalid 'Use one to 64 jobs per page.']
  =/  rows=(list [@ux record])
    (skim ~(tap by records.s) |=([id=@ux v=record] &(=(session.context.r session.context.request.v) =(actor.context.r actor.context.request.v))))
  ?.  (lte cursor (lent rows))  [%refused %cursor-invalid 'The job cursor is outside this session.']
  =/  picked=(list [@ux record])  (scag limit (slag cursor rows))
  =/  next=@ud  (add cursor (lent picked))
  [%jobs (turn picked public-job) ?:(=(next (lent rows)) ~ `next)]
++  undo-parent
  ::  A parent comes from the canonical finished tool journal, never tool JSON.
  ::  Historical grants identify its source; only the current grant authorizes
  ::  the inverse operation. Replacing a grant does not erase earlier history.
  |=  [s=organ grant=@ux r=tool-request:nc]
  ^-  (unit candidate:nc)
  ?.  &(?=(%undo -.arguments.r) (lte ~(wyt by records.s) capacity))  ~
  =/  current  (~(get by grants.s) grant)
  ?~  current  ~
  =/  p=project:nc  project.grant.u.current
  ?.  &(=(~ revoked.u.current) (grant-valid authority.spec.p grant.u.current) =(session.context.r session.grant.u.current) =(actor.context.r actor.grant.u.current) =(configuration.context.r (configuration:project p)))  ~
  =/  matches=(list candidate:nc)
    %+  murn  ~(tap by records.s)
    |=  [id=@ux row=record]
    ^-  (unit candidate:nc)
    ?.  &(=(%finished stage.row) =(id (key request.row)))  ~
    ?~  result.row  ~
    =/  result=tool-result:nc  u.result.row
    ?.  &(?=(%candidate -.output.result) =(context.result context.request.row) =(call-id.result call-id.request.row))  ~
    =/  c=candidate:nc  value.output.result
    =/  origin  (~(get by grants.s) grant.row)
    ?~  origin  ~
    ?.  &(=(candidate.arguments.r id.c) =(context.c context.result) =(project.grant.u.origin p) =(session.grant.u.origin session.context.c) =(actor.grant.u.origin actor.context.c) =(session.context.r session.context.c) =(actor.context.r actor.context.c) =(configuration.context.r configuration.context.c) =(owner.source.context.r owner.source.context.c) =(desk.source.context.r desk.source.context.c) (candidate-valid:files p c))  ~
    `c
  ?.  =(1 (lent matches))  ~
  ?~  matches  ~
  `i.matches
++  submit
  |=  [b=bowl:gall s=organ grant=@ux r=tool-request:nc]
  ^-  change
  ?.  &(=(our.b src.b) (pending our.b now.b r))  [s ~]
  =/  id=@ux  (key r)
  =/  old  (~(get by records.s) id)
  ?^  old
    [s ?~(result.u.old ~ ~[(report our.b u.result.u.old)])]
  =/  reject
    |=  reason=@tas
    ^-  change
    [s ~[(report our.b (refusal r reason 'Cantrip refused this tool request.'))]]
  ?:  (gte ~(wyt by records.s) capacity)  (reject %tool-journal-capacity)
  ?:  %+  lien  ~(val by records.s)
      |=  old=record
      &(=(session.context.r session.context.request.old) =(request.context.r request.context.request.old) =(call-id.r call-id.request.old))
    (reject %tool-call-conflict)
  =/  held  (~(get by grants.s) grant)
  ?~  held  (reject %standing-grant-missing)
  =/  permission  (allowed our.b now.b u.held r)
  ?:  ?=(%| -.permission)  (reject p.permission)
  ?:  &((executable -.arguments.r) (lien ~(val by records.s) |=(v=record &((executable -.arguments.request.v) ?=(?(%running %unknown) stage.v)))))
    (reject %native-worker-occupied)
  =/  entry=record  [grant r now.b %running ~]
  =.  s  s(records (~(put by records.s) id entry))
  ?:  |((executable -.arguments.r) ?=(%cancel -.arguments.r))
    ::  Cantrip's job runner retains an exact Spider handle before dispatch.
    ::  Scoped cancellation reaches that runner only after this admission.
    [s ~[(evidence our.b [%admission id entry])]]
  =/  output=tool-output:nc
    =/  args=tool-args:nc  arguments.r
    ?:  ?=(%jobs -.args)  (jobs s r cursor.args limit.args)
    ?:  ?=(%observe -.args)
      =/  found  (~(get by records.s) job.args)
      ?~  found  [%refused %job-missing 'No such retained tool job.']
      ?.  &(=(session.context.r session.context.request.u.found) =(actor.context.r actor.context.request.u.found))
        [%refused %foreign-job 'The job belongs to another session.']
      [%job (public-job job.args u.found)]
    =/  prior=(unit candidate:nc)  (undo-parent s grant r)
    =/  result  (mule |.((execute:files our.b actor.context.r now.b project.grant.u.held r prior)))
    ?:  ?=(%| -.result)  [%refused %native-file-tool-failed 'The read-only file tool could not finish; no candidate was saved.']
    output.p.result
  (finish our.b s id entry [%native-coding-tool-result-v1 context.r call-id.r output])
++  act
  |=  [b=bowl:gall s=organ c=command]
  ^-  change
  ?>  =(our.b src.b)
  ?-  -.c
    %native-coding-grant-v1
      ?>  (grant-valid our.b value.c)
      =/  catalog  (catalog:project our.b now.b project.value.c)
      ?>  ?=(%& -.catalog)
      =/  prior  (~(get by grants.s) id.value.c)
      ?^  prior
        ?>  &(=(value.c grant.u.prior) =(~ revoked.u.prior))
        [s ~]
      ?>  (lth ~(wyt by grants.s) grant-capacity)
      =/  held=scope  [value.c ~]
      [s(grants (~(put by grants.s) id.value.c held)) ~[(evidence our.b [%grant held])]]
    %native-coding-revoke-v1
      =/  found  (~(get by grants.s) id.c)
      ?~  found  [s ~]
      ?^  revoked.u.found  [s ~]
      =/  held=scope  u.found(revoked `now.b)
      [s(grants (~(put by grants.s) id.c held)) ~[(evidence our.b [%revoked held])]]
    %native-coding-execute-v1  (submit b s grant.c request.c)
    %native-coding-observe-v1
      =/  found  (~(get by records.s) id.c)
      ?~  found  [s ~]
      [s ?~(result.u.found ~ ~[(report our.b u.result.u.found)])]
    %native-coding-cancel-v1
      ::  Only the owning app's handle-aware runner implements this command.
      ~|  [%native-coding-cancel-unavailable id.c]
      !!
  ==
++  arvo
  |=  [b=bowl:gall s=organ w=wire sign=sign-arvo]
  ^-  change
  =/  id  (wire-key w)
  ?~  id  [s ~]
  ?.  &(=(our.b src.b) ?=([%khan %arow *] sign))  [s ~]
  =/  found  (~(get by records.s) u.id)
  ?~  found  [s ~]
  ?.  =(%running stage.u.found)  [s ~]
  =/  uncertain
    |=  reason=@tas
    ^-  change
    =/  r=tool-result:nc
      [%native-coding-tool-result-v1 context.request.u.found call-id.request.u.found [%unknown reason 'Native tool completion is unconfirmed; no tool was resubmitted.']]
    =/  out=record  u.found(stage %unknown, result `r)
    [s(records (~(put by records.s) u.id out)) ~[(evidence our.b [%unknown u.id out]) (report our.b r)]]
  ?.  ?=(%& -.p.sign)  (uncertain %native-thread-failed)
  =/  parsed  ((soft tool-result:nc) q.q.p.p.sign)
  ?~  parsed  (uncertain %native-result-invalid)
  ?.  =(u.parsed q.q.p.p.sign)  (uncertain %native-result-invalid)
  ?.  &(=(context.request.u.found context.u.parsed) =(call-id.request.u.found call-id.u.parsed))
    (uncertain %native-result-mismatch)
  (finish our.b s u.id u.found u.parsed)
++  candidate-source
  |=  [s=organ id=@ux]
  ^-  (unit record)
  =/  rows=(list record)  ~(val by records.s)
  |-  ^-  (unit record)
  ?~  rows  ~
  =/  r=record  i.rows
  =/  result  result.r
  ?~  result  $(rows t.rows)
  ?.  &(=(%finished stage.r) ?=(%candidate -.output.u.result))  $(rows t.rows)
  ?:  =(id id.value.output.u.result)  `r
  $(rows t.rows)
++  candidate-permission
  |=  [our=@p at=@da s=organ r=record:accept]
  ^-  (each ~ @tas)
  =/  original  (candidate-source s id.candidate.r)
  ?~  original  [%| %retained-candidate-missing]
  =/  result  result.u.original
  ?~  result  [%| %retained-candidate-missing]
  ?.  ?=(%candidate -.output.u.result)  [%| %retained-candidate-missing]
  ?.  &(=(candidate.r value.output.u.result) =(grant.r grant.u.original))
    [%| %candidate-source-mismatch]
  =/  g  (~(get by grants.s) grant.r)
  ?~  g  [%| %standing-grant-missing]
  ?.  &(=(project.r project.grant.u.g) (~(has in operations.grant.u.g) %compile) (~(has in operations.grant.u.g) %check))
    [%| %candidate-check-scope-refused]
  ?.  (request-permits our at grant.r context.request.u.original ~[%compile %check])
    [%| %candidate-request-ceiling]
  (allowed our at u.g request.u.original)
++  retire-check-source
  ::  Refusal only: a completed PATCH and read-only failed check, never an
  ::  unconfirmed Clay write. The accepted tree is the immutable old revision.
  |=  [our=@p r=record:accept original=record g=scope accepted=tree:nc working=tree:nc staged=tree:nc]
  ^-  (unit record:accept)
  ?.  ?&
    =(%unknown stage.r)
    |(=(`%candidate-check-unconfirmed reason.r) =(`%candidate-recheck-unconfirmed reason.r))
    =(~ report.r)  =(~ decision.r)  =(~ landed.r)
    ?=(^ revoked.g)  (grant-valid our grant.g)
    =(grant.r id.grant.g)  =(grant.r grant.original)
    =(project.r project.grant.g)
    (~(has in operations.grant.g) %patch)
    (~(has in operations.grant.g) %compile)
    (~(has in operations.grant.g) %check)
    =(%finished stage.original)  ?=(%patch -.arguments.request.original)
    ?=(^ result.original)  ?=(^ staging.r)
  ==  ~
  =/  result=tool-result:nc  u.result.original
  ?.  ?=(%candidate -.output.result)  ~
  =/  c=candidate:nc  candidate.r
  ?.  =(1 (lent edits.c))  ~
  ?.  ?=(^ edits.c)  ~
  =/  e=edit:nc  i.edits.c
  ?.  ?&  =(%modify kind.change.e)
          =(pax.arguments.request.original path.change.e)
          =(`before.arguments.request.original before.change.e)
      ==  ~
  ?.  ?&  =(c value.output.result)  (candidate-valid:files project.r c)
          =(context.c context.request.original)  =(context.c context.result)
          =(call-id.request.original call-id.result)
          (gte (met 3 call-id.result) 1)  (lte (met 3 call-id.result) 256)
          =(session.context.c session.grant.g)  =(actor.context.c actor.grant.g)
          =(configuration.context.c (configuration:project project.r))
          =(source.context.c revision.basis.c)
          =(accepted.c revision.accepted)  (tree-valid:project project.r accepted)
          =(basis.c working)  (tree-valid:project project.r working)
          =(u.staging.r staged)  (tree-valid:project project.r staged)
          =(our owner.revision.staged)
          =((staging-desk:accept id.c) desk.revision.staged)
          =(2 number.revision.staged)
          =((after-map:files c) files.body.snapshot.staged)
      ==  ~
  `r(stage %refused, reason `%standing-grant-revoked)
++  retire-revoked-check
  |=  [b=bowl:gall s=organ r=record:accept]
  ^-  (unit record:accept)
  ?.  ?&
    =(%unknown stage.r)
    |(=(`%candidate-check-unconfirmed reason.r) =(`%candidate-recheck-unconfirmed reason.r))
    =(~ report.r)  =(~ decision.r)  =(~ landed.r)
  ==  ~
  =/  original  (candidate-source s id.candidate.r)
  ?~  original  ~
  =/  g  (~(get by grants.s) grant.r)
  ?~  g  ~
  ?.  ?=(^ revoked.u.g)  ~
  ::  Native permission must authenticate the retained origin and scope and
  ::  report this exact revocation; missing or unrelated grants cannot retire.
  ?.  =([%| %standing-grant-revoked] (candidate-permission our.b now.b s r))  ~
  =/  current  (current:project our.b now.b project.r)
  ?:  ?=(%| -.current)  ~
  =/  staged  (staged:accept our.b now.b r)
  ?:  ?=(%| -.staged)  ~
  =/  accepted  (tree-at:project our.b now.b project.r desk.accepted.candidate.r number.accepted.candidate.r)
  ?:  ?=(%| -.accepted)  ~
  (retire-check-source our.b r u.original u.g p.accepted working.p.current p.staged)
++  candidate-act
  |=  [b=bowl:gall s=organ held=ledger:accept c=command:accept window=window:law]
  ^-  change:accept
  ?>  =(our.b src.b)
  =/  id=@ux  candidate.c
  =/  found  (~(get by held) id)
  ?-  -.c
      %native-coding-review-v1
    ?^  found  [held (publish:accept our.b u.found)]
    ?>  (permission:editor window)
    =/  original  (candidate-source s id)
    ?>  ?=(^ original)
    =/  result  result.u.original
    ?>  ?=(^ result)
    ?>  ?=(%candidate -.output.u.result)
    =/  g  (~(get by grants.s) grant.u.original)
    ?>  ?=(^ g)
    =/  p=project:nc  project.grant.u.g
    =/  candidate=candidate:nc  value.output.u.result
    =/  rehearsal=record:accept
      [%native-coding-acceptance-v1 p candidate grant.u.original now.b %cloning ~ ~ ~ ~ ~]
    =/  allowed  (candidate-permission our.b now.b s rehearsal)
    ?>  ?=(%& -.allowed)
    ?>  !(lien ~(val by records.s) |=(r=record &((executable -.arguments.request.r) ?=(?(%running %unknown) stage.r))))
    (begin:accept b held p candidate grant.u.original)
  ::
      %native-coding-candidate-recheck-v1
    ?~  found  [held ~]
    ?>  (permission:editor window)
    =/  permission  (candidate-permission our.b now.b s u.found)
    ?:  ?=(%| -.permission)  [held ~]
    ?>  !(lien ~(val by records.s) |=(r=record &((executable -.arguments.request.r) ?=(?(%running %unknown) stage.r))))
    (recheck:accept b held id)
  ::
      %native-coding-candidate-observe-v1
    ?~  found  [held ~]
    =/  r=record:accept  u.found
    =/  retired  (retire-revoked-check b s r)
    ?^  retired  (put:accept our.b held u.retired ~)
    ?.  ?=(?(%cloning %staging) stage.r)  (observe:accept b held id)
    ?:  &(=(%cloning stage.r) !(permission:editor window))
      (put:accept our.b held r(reason `%cantrip-law-blocked) ~)
    =/  permission  (candidate-permission our.b now.b s r)
    ?:  ?=(%| -.permission)
      (put:accept our.b held r(stage %refused, reason `p.permission) ~)
    (observe:accept b held id)
  ::
      %native-coding-decide-v1
    ?~  found  [held ~]
    =/  r=record:accept  u.found
    ?.  =(%review stage.r)  [held (publish:accept our.b r)]
    =/  permission  (candidate-permission our.b now.b s r)
    ?:  ?=(%| -.permission)
      (put:accept our.b held r(stage %refused, reason `p.permission) ~)
    ?>  (agent-live:guard our.b now.b %viki)
    =/  decision=(unit decision:accept)
      .^((unit decision:accept) %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/decision/(scot %ux id)/noun)
    ?~  decision  [held (publish:accept our.b r)]
    =/  denied  (admit:local our.b now.b candidate.r u.decision)
    ?^  denied
      (put:accept our.b held r(reason `u.denied) ~)
    ?:  &(=(%approve verdict.u.decision) !(permission:editor window))
      (put:accept our.b held r(reason `%cantrip-law-blocked) ~)
    (decide:accept b held id u.decision)
  ==
++  candidate-arvo
  |=  [b=bowl:gall s=organ held=ledger:accept w=wire sign=sign-arvo window=window:law]
  ^-  change:accept
  ?.  &(=(our.b src.b) ?=([%native-candidate @ @ ~] w))  [held ~]
  =/  key  (slaw %ux i.t.w)
  ?~  key  [held ~]
  =/  id=@ux  u.key
  ?.  =(w (wire-for:accept id i.t.t.w))  [held ~]
  =/  found  (~(get by held) id)
  ?~  found  [held ~]
  =/  r=record:accept  u.found
  ?:  ?=([%behn %wake *] sign)
    ?.  &((check-scheduled:accept r) =(w (check-wire:accept r)))  [held ~]
    ::  A failed wake rolls back to this exact scheduled record. Terminate
    ::  before any scry or dispatch; the error is not a failed proposition.
    ?^  error.sign
      =/  retry=?  =(`%candidate-recheck-scheduled reason.r)
      (put:accept our.b held r(stage %unknown, reason `?:(retry %candidate-recheck-unconfirmed %candidate-check-unconfirmed)) ~)
    =/  permission  (candidate-permission our.b now.b s r)
    ?:  ?=(%| -.permission)
      (put:accept our.b held r(stage %refused, reason `p.permission) ~)
    ?:  |(!(ready-at:accept our.b now.b (~(del by held) id)) (lien ~(val by records.s) |=(v=record &((executable -.arguments.request.v) ?=(?(%running %unknown) stage.v)))))
      (put:accept our.b held r(stage %unknown, reason `%native-worker-occupied) ~)
    =/  current  (current:project our.b now.b project.r)
    ?:  ?=(%| -.current)
      (put:accept our.b held r(stage %unknown, reason `p.current) ~)
    =/  stage  (staged:accept our.b now.b r)
    ?:  ?=(%| -.stage)
      (put:accept our.b held r(stage %unknown, reason `p.stage) ~)
    (start-check:accept b held r accepted.p.current working.p.current p.stage)
  ?:  |(=(w (wire-for:accept id %checks)) =(w (wire-for:accept id %checks-retry)))
    ?.  &(=(%checking stage.r) ?=([%khan %arow *] sign))  [held ~]
    =/  retry=?  =(w (wire-for:accept id %checks-retry))
    ?.  =(reason.r ?:(retry `%candidate-recheck ~))  [held ~]
    ?.  ?=(%& -.p.sign)
      (put:accept our.b held r(stage %unknown, reason `?:(retry %candidate-recheck-unconfirmed %candidate-check-unconfirmed)) ~)
    =/  report  ((soft ,(each report:accept @tas)) q.q.p.p.sign)
    ?~  report
      (put:accept our.b held r(stage %unknown, reason `%candidate-report-invalid) ~)
    ?:  ?=(%| -.u.report)
      (put:accept our.b held r(stage %refused, reason `p.u.report) ~)
    (checked:accept our.b held id p.u.report)
  ?.  ?=([%clay %writ *] sign)  [held ~]
  ::  The callback only triggers a read. Exact desk/revision/root/parent joins
  ::  determine progress, so duplicate or late notifications cannot replay.
  (candidate-act b s held [%native-coding-candidate-observe-v1 id] window)
--
