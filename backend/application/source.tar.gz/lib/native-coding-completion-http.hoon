::  Owner presentation only. Preparation reads current native authority; an
::  acceptance carries that exact proposal to Viki for atomic revalidation.
/-  nc=native-coding, protocol=native-coding-completion-review
/+  kernel=native-coding-completion, runtime=native-coding-completion-runtime,
    reviewed=native-coding-reviewed-completion,
    campaign=native-coding-completion-review-orchestration,
    session=native-coding-session, loop=native-coding-loop,
    scopes=native-coding-campaign-http, guard=viki-scry-guard,
    cr=codex-responses, terminal=native-coding-terminal
|%
++  hex
  |=  [o=json name=@t]
  ^-  @ux
  =/  text=@t  (need (string:cr o name))
  =/  id=@ux  (need (slaw %ux text))
  ?>  &((identifier:kernel id) =(text (scot %ux id)))
  id
++  revision
  |=  r=revision:nc
  ^-  json
  %-  pairs:enjs:format
  :~  ['owner' s+(scot %p owner.r)]
      ['desk' s+desk.r]
      ['number' s+(scot %ud number.r)]
      ['root' s+(scot %uv root.r)]
      ['commit' s+(scot %uv commit.r)]
  ==
++  proposal-json
  |=  p=proposal:kernel
  ^-  json
  %-  pairs:enjs:format
  :~  ['digest' s+(scot %ux (digest:kernel p))]
      ['tag' s+-.p]
      ['session' s+(scot %ux session.p)]
      ['project' s+project.p]
      ['configuration' s+(scot %ux configuration.p)]
      ['source' (revision source.p)]
      ['accepted' (revision accepted.p)]
      ['grant' s+(scot %ux grant.p)]
      ['assignment' ?~(assignment.p ~ s+(scot %ux u.assignment.p))]
      ['objective' s+objective.p]
      ['latest' s+(scot %ux latest.p)]
      ['head' s+(scot %ux head.p)]
      ['sequence' s+(scot %ud sequence.p)]
      ['model' s+(scot %ux model.p)]
      ['snapshot' s+(scot %ux snapshot.p)]
      ['evidence' a+(turn evidence.p |=(e=evidence:kernel (pairs:enjs:format ~[['record' s+(scot %ux record.e)] ['tool' s+(scot %ux tool.e)] ['result' s+(scot %ux result.e)]])))]
  ==
++  prepare
  |=  [our=@p now=@da id=@ux]
  ^-  (each proposal:kernel @tas)
  ?.  (agent-live:guard our now %viki)  [%| %completion-viki-unavailable]
  .^((each proposal:kernel @tas) %gx /(scot %p our)/viki/(scot %da now)/native-coding/completion-proposal/(scot %ux id)/noun)
++  owner-json
  |=  [key=@ux r=receipt:runtime]
  ^-  json
  %-  pairs:enjs:format
  :~  ['key' s+(scot %ux key)]
      ['session' s+(scot %ux session.proposal.decision.r)]
      ['proposal' s+(scot %ux (digest:kernel proposal.decision.r))]
      ['reason' s+reason.decision.r]
      ['judgment' s+(scot %ux judgment.r)]
      ['verdict' s+verdict.decision.r]
      ['historical' b+%.y]
  ==
++  owner-receipt
  ::  Historical receipt for the latest judgment, even if later work followed.
  ::  The separately projected session phase describes current session state.
  |=  [our=@p now=@da id=@ux expected=(unit @ux)]
  ^-  json
  ?^  expected
    ::  Explicit recovery read only: later judgments must not hide the exact
    ::  historical acceptance whose HTTP delivery was uncertain.
    =/  ledger=state:runtime
      .^(state:runtime %gx /(scot %p our)/viki/(scot %da now)/native-coding/completions/noun)
    ?>  (lte ~(wyt by ledger) 128)
    =/  matching=(list [@ux receipt:runtime])
      %+  skim  ~(tap by ledger)
      |=  [key=@ux r=receipt:runtime]
      &(=(id session.proposal.decision.r) =(u.expected (digest:kernel proposal.decision.r)))
    ?:  =(0 (lent matching))  ~
    ?>  ?=(^ matching)
    ?>  ?=(~ t.matching)
    =/  [key=@ux r=receipt:runtime]  i.matching
    ?>  =(key (key:runtime decision.r))
    (owner-json key r)
  =/  found=(unit public-session:loop)
    .^((unit public-session:loop) %gx /(scot %p our)/viki/(scot %da now)/native-coding/session/(scot %ux id)/noun)
  ?~  found  ~
  =/  rows=(list record:session)
    (flop (skim records.u.found |=(r=record:session ?=(%judgment -.body.r))))
  ?~  rows  ~
  =/  last=record:session  i.rows
  ?>  ?=(%judgment -.body.last)
  ?~  evidence.body.last  ~
  =/  key=@ux  i.evidence.body.last
  =/  held=(unit receipt:runtime)
    .^((unit receipt:runtime) %gx /(scot %p our)/viki/(scot %da now)/native-coding/completion/(scot %ux key)/noun)
  ?~  held  ~
  =/  r=receipt:runtime  u.held
  ?.  ?&  =(key (key:runtime decision.r))
          =(id session.proposal.decision.r)
          =(id.last judgment.r)
      ==
    ~
  (owner-json key r)
++  job-json
  |=  [id=@ux j=job:campaign]
  ^-  json
  %-  pairs:enjs:format
  :~  ['id' s+(scot %ux id)]
      ['reviewer' (reviewer-json:scopes [worker.j config.j])]
      ['mode' s+mode.request.j]
      ['phase' s+?~(event.j 'awaiting-response' phase.u.event.j)]
      ['reason' s+?~(event.j '' reason.u.event.j)]
      ['receipt' ?~(event.j ~ s+(scot %ux receipt.u.event.j))]
  ==
++  receipt-json
  |=  [key=@ux r=receipt:reviewed]
  ^-  json
  =/  proof  (proof-of:reviewed outcome.r)
  %-  pairs:enjs:format
  :~  ['key' s+(scot %ux key)]
      ['judgment' s+(scot %ux judgment.r)]
      ['proposal' s+(scot %ux proposal.proof)]
      ['scope' s+(scot %ux scope.proof)]
      ['head' s+(scot %ux head.proof)]
      ['projection' s+(scot %ux projection.proof)]
      ['target' s+(scot %ud target.proof)]
      ['admissions' a+(turn admissions.proof |=(id=@ux s+(scot %ux id)))]
      ['reason' s+(reason:reviewed r)]
      ['move' ?:(?=(%negative -.outcome.r) s+(scot %ud move.outcome.r) ~)]
  ==
++  view
  |=  [our=@p now=@da id=@ux detail=? selected=(unit @ux) expected=(unit @ux)]
  ^-  json
  ?.  &((identifier:kernel id) (agent-live:guard our now %viki))
    (pairs:enjs:format ~[['available' b+%.n] ['session' s+(scot %ux id)] ['campaigns' a+~] ['ownerReceipt' ~]])
  =/  all=(map @ux campaign:campaign)
    .^((map @ux campaign:campaign) %gx /(scot %p our)/viki/(scot %da now)/native-coding/completion-review-campaigns/noun)
  =/  current=(map @t scope:protocol)  (scopes:scopes our now)
  =/  rows=(list json)
    %+  turn  (scag 32 (skim ~(tap by all) |=([key=@ux e=campaign:campaign] =(id session.proposal.packet.e))))
    |=  [key=@ux e=campaign:campaign]
    =/  applied=(unit @ux)
      .^((unit @ux) %gx /(scot %p our)/viki/(scot %da now)/native-coding/reviewed-completion-campaign/(scot %ux key)/noun)
    =/  held=(unit receipt:reviewed)
      ?~  applied  ~
      .^((unit receipt:reviewed) %gx /(scot %p our)/viki/(scot %da now)/native-coding/reviewed-completion/(scot %ux u.applied)/noun)
    ::  Canonical receipt lookup supplies provenance. Do not rehash its full
    ::  retained review packet on every terminal notification.
    ?>  ?~(held %.y &(=(key campaign.u.held) =(id session.proposal.packet.u.held)))
    =/  unconfirmed=?  &(?=(^ applied) ?=(~ held))
    =/  public=json
      %-  pairs:enjs:format
      :~  ['id' s+(scot %ux key)]
          ['project' s+project.scope.e]
          ['workspace' s+workspace.e]
          ['reviewReady' b+done.e]
          ['reason' s+?:(unconfirmed %completion-receipt-unconfirmed reason.e)]
          ['scopeCurrent' b+&(enabled.scope.e =(`scope.e (~(get by current) project.scope.e)))]
          ['application' s+?:(unconfirmed 'unconfirmed' ?~(held 'none' 'retained'))]
          ['applied' ?:(unconfirmed ~ b+?=(^ held))]
          ['receipt' ?~(applied ~ s+(scot %ux u.applied))]
          ['historical' b+%.y]
          ['outcome' ?~(held ~ s+-.outcome.u.held)]
      ==
    ?.  detail  public
    ?>  ?=(%o -.public)
    (pairs:enjs:format (weld ~(tap by p.public) `(list [@t json])`~[['jobs' a+(turn (scag 5 ~(tap by jobs.e)) job-json)] ['scope' (scope-json:scopes scope.e)] ['proposal' ?:(=(`key selected) (proposal-json proposal.packet.e) ~)] ['provenance' ?~(held ~ (receipt-json (need applied) u.held))]]))
  =/  fields=(list [@t json])
    ~[['available' b+%.y] ['session' s+(scot %ux id)] ['campaigns' a+rows] ['ownerReceipt' (owner-receipt our now id expected)]]
  ?.  detail  (pairs:enjs:format fields)
  =/  proposed  (prepare our now id)
  (pairs:enjs:format (weld fields ~[['proposal' (pairs:enjs:format ~[['ready' b+?=(%& -.proposed)] ['reason' s+?:(?=(%| -.proposed) p.proposed '')] ['value' ?:(?=(%& -.proposed) (proposal-json p.proposed) ~)]])]]))
++  options
  |=  text=@t
  ^-  [selected=(unit @ux) expected=(unit @ux)]
  =/  selected=(unit @ux)  ~
  =/  expected=(unit @ux)  ~
  =/  left=@ud  2
  |-  ^-  [selected=(unit @ux) expected=(unit @ux)]
  ?:  =('' text)  [selected expected]
  ?>  (gth left 0)
  =/  field  (split:terminal 38 text)
  =/  pair  (split:terminal 61 head.field)
  ?>  found.pair
  =/  id=@ux  (need (slaw %ux tail.pair))
  ?>  &((identifier:kernel id) =(tail.pair (scot %ux id)))
  ?>  |(!found.field !=('' tail.field))
  ?:  =('campaign' head.pair)
    ?>  =(~ selected)
    $(text tail.field, selected `id, left (dec left))
  ?>  &(=(~ expected) =('proposal' head.pair))
  $(text tail.field, expected `id, left (dec left))
++  route
  |=  [our=@p now=@da url=@t]
  ^-  (unit json)
  =/  prefix=@t  '/apps/pataphor-native/coding/completion?session='
  ?.  =(prefix (cut 3 [0 (met 3 prefix)] url))  ~
  =/  parsed
    %-  mole
    |.
    ?>  (lte (met 3 url) 320)
    =/  query  (split:terminal 38 (rsh [3 (met 3 prefix)] url))
    =/  id=@ux  (need (slaw %ux head.query))
    ?>  &((identifier:kernel id) =(head.query (scot %ux id)))
    ?>  |(!found.query !=('' tail.query))
    =/  extra  (options tail.query)
    (view our now id %.y selected.extra expected.extra)
  ?~  parsed  `(pairs:enjs:format ~[['available' b+%.n] ['error' s+'completion-view-refused']])
  parsed
++  decode
  ::  Called only after the shared owner/CSRF/body checks. Model text is never consent.
  |=  [our=@p now=@da o=json]
  ^-  *
  ?>  (agent-live:guard our now %viki)
  =/  id=@ux  (hex o 'session')
  =/  kind=@t  (need (string:cr o 'kind'))
  ?:  =('completion-observe' kind)
    =/  key=@ux  (hex o 'campaign')
    =/  held=(unit campaign:campaign)
      .^((unit campaign:campaign) %gx /(scot %p our)/viki/(scot %da now)/native-coding/completion-review-campaign/(scot %ux key)/noun)
    ?>  ?=(^ held)
    ?>  =(id session.proposal.packet.u.held)
    [%native-coding-completion-review-action-v1 [%observe key]]
  ?>  =('completion-accept' kind)
  ?>  =(`[%b %.y] (field:cr o 'consent'))
  =/  proposed  (prepare our now id)
  ?>  ?=(%& -.proposed)
  ?>  =((hex o 'proposal') (digest:kernel p.proposed))
  =/  decision=decision:kernel
    [%native-coding-completion-decision-v1 p.proposed %complete (need (string:cr o 'reason'))]
  ?>  (decision-valid:kernel decision)
  [%native-coding-completion-decide-v1 decision]
--
