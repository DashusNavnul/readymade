::  New prospective policy only; v1 windows and manifests remain immutable.
::  This core orders admitted points, not provider evidence or permissions.
::  Its native owner must freeze the manifest before generation, reserve each
::  position before dispatch, and stop its canonical queue at unresolved work.
/+  old=qpc-window, obs=qpc-observation, ct=qpc-ct-update,
    decision=qpc-decision, policy=qpc-successor-policy
|%
+$  binding
  $:  instrument=@ux  stream=@ux  manifest=@ux
      policy=policy:policy
      arithmetic=%qpc-ct-update-v1
  ==
+$  point  point:old
+$  body  body:old
+$  event  event:old
+$  epoch
  $:  %qpc-successor-epoch-v1  id=@ux  binding=binding
      reference=(list point)  covariance=covariance:old
  ==
+$  reading
  $:  %qpc-successor-reading-v1  id=@ux  epoch=@ux  generation=@ud
      previous=(unit @ux)  source=@ux  live=(list point)
      tensor=reading:ct  shape=(unit normalized-shape:ct)
      reference-mixed-law=?  live-mixed-law=?
      comparison=(list comparison:old)
  ==
+$  state
  $:  %qpc-successor-window-v1  binding=binding  manifest=manifest:obs
      next=@ud  ordinal=@ud  segment=(unit @ux)  segments=(set @ux)
      source=(unit @ux)  events=(map @ud event)
      ids=(set @ux)  works=(set @ux)  buffer=(list point)
      reference=(unit epoch)  measured=(unit reading)
      readings=(map @ud reading)
  ==
++  policy-text  text:policy
++  digest  |=(v=* ^-(@ux (shax (jam [%qpc-successor-window-v1 v]))))
++  start
  |=  [b=binding m=manifest:obs]
  ^-  (each state @tas)
  ?.  ?&  (levy `(list @ux)`~[instrument.b stream.b manifest.b] identifier:decision)
          (manifest-valid:obs m)  =(%qpc-observation-manifest-v4 version.m)
          =(16 width.m)  =(2 (lent propositions.m))
          =(policy-text baseline-policy.m)  =(manifest.b (digest:obs m))
      ==  [%| %successor-binding-invalid]
  =/  s=state  *state
  [%& s(binding b, manifest m)]
++  seal
  |=  [b=binding rows=(list point)]
  ^-  epoch
  =/  ps=window:ct  (reports:old rows)
  ?>  (valid:ct 2 16 ps)
  =/  axes=(list @ud)  ~[0 1]
  =/  entries=matrix:ct
    %+  turn  axes
    |=  a=@ud
    %+  turn  axes
    |=  z=@ud
    (pro:si --2 (numerator:ct ps a z))
  =/  k=covariance:old  [(mul 256 (mul scale:ct scale:ct)) entries]
  =/  value=epoch  [%qpc-successor-epoch-v1 0x0 b rows k]
  value(id (digest value))
++  measure
  |=  [e=epoch live=(list point) generation=@ud previous=(unit @ux)]
  ^-  reading
  =/  computed  (measure:ct 2 16 (reports:old live) (reports:old reference.e))
  ?>  ?=(%& -.computed)
  =/  compared=(list comparison:old)
    (turn `(list @ud)`~[0 1] |=(axis=@ud (score:old reference.e live axis)))
  =/  source=@ux  resulting-source.row:(rear live)
  =/  value=reading
    :*  %qpc-successor-reading-v1  0x0  id.e  generation  previous
        source  live  p.computed  (shape:ct p.computed)
        (mixed-law:old reference.e)  (mixed-law:old live)  compared
    ==
  value(id (digest value))
++  append
  ::  Only native owner-derived points reach this pure gate. A selected point
  ::  still requires the separate authenticated collection-to-execution join.
  |=  [s=state e=event]
  ^-  (each state @tas)
  =/  prior  (~(get by events.s) order.e)
  ?^  prior  ?:(=(e u.prior) [%& s] [%| %successor-event-conflict])
  ?.  =(order.e next.s)  [%| %successor-event-order]
  ?:  (gte next.s 256)  [%| %successor-capacity]
  =/  next=state  s(next +(next.s), events (~(put by events.s) order.e e))
  ?:  ?=(%outside -.body.e)
    ?.  (identifier:decision evidence.body.e)  [%| %successor-evidence-invalid]
    [%& next]
  ?:  ?=(%gap -.body.e)
    ?.  &((identifier:decision evidence.body.e) !=(%$ reason.body.e))
      [%| %successor-evidence-invalid]
    [%& next(ordinal +(ordinal.s), buffer ~, segment ~, source ~, measured ~)]
  =/  p=point  value.body.e
  ?.  (point-valid:old p)  [%| %successor-point-invalid]
  ?.  =(ordinal.s step.row.p)  [%| %successor-report-order]
  ?:  |((~(has in ids.s) id.row.p) (~(has in works.s) work.row.p))
    [%| %successor-report-reused]
  ?^  segment.s
    ?.  &(=(u.segment.s segment.row.p) =(source.s `prediction.p))
      [%| %successor-continuity]
    (record next p)
  ?:  (~(has in segments.s) segment.row.p)  [%| %successor-segment-reused]
  (record next p)
++  record
  |=  [s=state p=point]
  ^-  (each state @tas)
  =/  buffer=(list point)  (weld buffer.s ~[p])
  ::  Archive the prior reading, but never expose it as current while a new
  ::  block is being collected, even when an unapplied work kept the source.
  =.  s
    s(ordinal +(ordinal.s), segment `segment.row.p, source `resulting-source.row.p, segments (~(put in segments.s) segment.row.p), ids (~(put in ids.s) id.row.p), works (~(put in works.s) work.row.p), buffer buffer, measured ~)
  ?:  (lth (lent buffer) 17)  [%& s]
  ?>  =(17 (lent buffer))
  ?~  reference.s
    [%& s(reference `(seal binding.s buffer), buffer ~)]
  =/  n=@ud  ~(wyt by readings.s)
  =/  previous=(unit @ux)
    ?:  =(0 n)  ~
    `id:(~(got by readings.s) n)
  =/  value=reading  (measure u.reference.s buffer +(n) previous)
  [%& s(measured `value, readings (~(put by readings.s) +(n) value), buffer ~)]
++  current
  ::  Caller must supply the actual current native source digest and prove no
  ::  queued work is unresolved. A retained past reading is not a fallback.
  |=  [s=state source=@ux]
  ^-  (each reading @tas)
  ?~  reference.s  [%| %qpc-reference-unavailable]
  ?~  measured.s  [%| %qpc-reading-unavailable]
  ?.  &((identifier:decision source) =(source.s `source) =(source.u.measured.s source) =(~ buffer.s))
    [%| %qpc-settled-source-mismatch]
  [%& u.measured.s]
++  replay
  |=  [b=binding m=manifest:obs events=(list event)]
  ^-  (each state @tas)
  =/  begun  (start b m)
  ?:  ?=(%| -.begun)  begun
  =/  held=state  p.begun
  |-  ^-  (each state @tas)
  ?~  events  [%& held]
  =/  next  (append held i.events)
  ?:  ?=(%| -.next)  next
  $(held p.next, events t.events)
++  valid
  |=  s=state
  ^-  ?
  ?.  &((lte next.s 256) =(next.s ~(wyt by events.s)))  %.n
  =/  events=(list event)
    (sort ~(val by events.s) |=([a=event b=event] (lth order.a order.b)))
  =/  got  (replay binding.s manifest.s events)
  =([%& s] got)
--
