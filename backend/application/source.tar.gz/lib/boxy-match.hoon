::  /lib/boxy-match.hoon
::
::  Pure absorption of the Juggler match law onto Boxy's constitutional
::  chain.  Hosting is one constitutional %publish per match action; the
::  projection folds a workspace's admitted events oldest-first through the
::  donor's own event-sourced kernel (apply:jmk), so move validity, turn
::  law, dual-accept, and finalization are preserved exactly.  Followers
::  need no parallel channel: the same projection over a replicated chain
::  yields the same match, provided the replica bootstrapped from the
::  genesis boundary (a late-joining bounded replica projects only the
::  suffix it holds and must not be read as the whole match).
::
/-  bx=boxy, br=boxy-replica, jm=juggler-match, bm=boxy-match
/+  jmk=juggler-match
|%
++  fact-for
  |=  action=match-action:jm
  ^-  match-fact:bm
  ?-  -.action
    %open    [%juggler-match-open config.action]
    %submit  [%juggler-match-submit contribution.action]
    %settle  [%juggler-match-settle proposal-id.action admission.action]
  ==
::
++  command-for
  |=  action=match-action:jm
  ^-  command:bx
  [%publish (fact-for action)]
::
++  decode-fact
  |=  fact=*
  ^-  (unit match-fact:bm)
  ((soft match-fact:bm) fact)
::
::  The donor's source discipline, mapped from Boxy's authenticated actor:
::  opening claims host authority, submitting claims participant authority,
::  settling claims the Cantrip-relay authority.  The kernel itself then
::  enforces that the claimed role matches the match config.
++  source-for
  |=  [fact=match-fact:bm actor=@p]
  ^-  source:jm
  ?-  -.fact
    %juggler-match-open    [%host actor]
    %juggler-match-submit  [%participant actor]
    %juggler-match-settle  [%cantrip actor]
  ==
::
++  action-for
  |=  fact=match-fact:bm
  ^-  match-action:jm
  ?-  -.fact
    %juggler-match-open    [%open config.fact]
    %juggler-match-submit  [%submit contribution.fact]
    %juggler-match-settle  [%settle proposal-id.fact admission.fact]
  ==
::
++  initial-projection
  ^-  projection:bm
  [initial-state:jmk 0 0 0 %not-run]
::
++  step
  |=  [proj=projection:bm event=event:bx]
  ^-  projection:bm
  ?.  ?=([%command *] action.event)
    proj(foreign +(foreign.proj))
  =/  command=command:bx  command.envelope.action.event
  ?.  ?=([%publish *] command)
    proj(foreign +(foreign.proj))
  =/  fact=(unit match-fact:bm)  (decode-fact fact.command)
  ?~  fact
    proj(foreign +(foreign.proj))
  =/  result=match-result:jm
    (apply:jmk match.proj (action-for u.fact) (source-for u.fact actor.event))
  ?.  ok.result
    proj(refused +(refused.proj), last code.result)
  [state.result +(applied.proj) refused.proj foreign.proj code.result]
::
::  Chains are stored newest-first; the kernel replays oldest-first.
++  project-events
  |=  events=(list event:bx)
  ^-  projection:bm
  =/  ordered=(list event:bx)  (flop events)
  =/  proj=projection:bm  initial-projection
  |-
  ?~  ordered  proj
  $(ordered t.ordered, proj (step proj i.ordered))
::
++  project-workspace
  |=  workspace=workspace-state:bx
  ^-  projection:bm
  (project-events events.workspace)
::
++  project-replica
  |=  replica=replica:br
  ^-  projection:bm
  (project-events events.replica)
--
