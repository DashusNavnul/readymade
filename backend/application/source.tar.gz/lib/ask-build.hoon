::  /lib/ask-build.hoon
::
::  THE PROMPT-DETERMINISM DISCIPLINE, in one file.
::
::  A derivation's address is its question, so the SAME question must
::  assemble the SAME bytes every time or nothing ever interns and
::  every ask is a fresh generation.  That is a discipline no type can
::  enforce, so it is concentrated here:
::
::    NO CLOCK.       `now` never enters a prompt.
::    NO "LATEST".    the refs are given, never fetched.
::    NO UNORDERED.   sets are sorted before rendering; map iteration
::                    order never reaches the bytes.
::    NO AMBIENT.     every input is an argument.
::    NO COLLISION.   byte lengths frame every free-text field, so task
::                    bytes cannot impersonate appended evidence.
::
::  The three ways to break it, all of which turned a READ back into a
::  GENERATION and none of which would have failed a type check:
::    - stamping the date into the prompt
::    - citing "the 3 most recent facts" (graf grew by one overnight)
::    - walking a (set) and printing it in iteration order
::
::  FRESHNESS LIVES NEXT DOOR.  /lib/ref-pick MAY be fresh -- choosing
::  WHICH refs a turn should see is a judgment that should use current
::  knowledge.  It records its choice in the want, and this lib
::  consumes only that recorded list.  The seam between "may be fresh"
::  and "must be frozen" is the want itself.
::
/-  dvn=derivation
|%
::  a ref as the prompt sees it: a handle and the text it stands for.
::  The asker resolves these ONCE, records the handles in the want, and
::  passes the pairs here.  Nothing in this lib reads graf.
+$  ref  [handle=@t text=@t]
::
::  canonical ref order: by handle, then text, ascending.  Callers may pass refs
::  in any order -- including whatever order a (set) tapped out in --
::  and get identical bytes.  This is the single most likely place for
::  nondeterminism to enter, so it is not left to the caller.
++  order-refs
  |=  rs=(list ref)
  ^-  (list ref)
  %+  sort  rs
  |=  [a=ref b=ref]
  ^-  ?
  ?:  =(handle.a handle.b)
    (aor text.a text.b)
  (aor handle.a handle.b)
::
::  Render the evidence block as readable, length-framed bytes.  The model
::  still sees the source text, while a parser can recover the only possible
::  [handle text] sequence even when either field contains our separators.
++  render-refs
  |=  rs=(list ref)
  ^-  @t
  =/  ordered=(list ref)  (order-refs rs)
  %+  rap  3
  :~  'REFS '
      (scot %ud (lent ordered))
      '\0a'
      %+  roll  ordered
      |=  [r=ref acc=@t]
      %+  rap  3
      :~  acc
          'REF '
          (scot %ud (met 3 handle.r))
          ' '
          (scot %ud (met 3 text.r))
          '\0a'
          handle.r
          text.r
          '\0a'
      ==
  ==
::
::  THE BUILDER.  (task, refs, oracle, law) -> ask.  Pure, total, and
::  deterministic in its arguments alone.  The version tag and byte length
::  make task/ref boundaries injective without hiding the prompt from the
::  Bachelor model.
++  build
  |=  $:  task=@t
          refs=(list ref)
          oracle=oracle-id:dvn
          law=gen-law:dvn
      ==
  ^-  ask:dvn
  :-  oracle
  :-  %+  rap  3
      :~  'PATAPHOR-ASK-V1\0aTASK '
          (scot %ud (met 3 task))
          '\0a'
          task
          '\0a'
          (render-refs refs)
      ==
  law
::
::  the want around it.  `at` and `by` and `purpose` are provenance and
::  live OUTSIDE the ask, so planting the same question twice -- at
::  different times, by different organs, for different purposes --
::  still addresses ONE derivation.
++  want-for
  |=  $:  =ask:dvn
          by=@tas
          purpose=@tas
          at=@da
          refs=(list ref)
      ==
  ^-  want:dvn
  [ask by purpose at (turn (order-refs refs) |=(r=ref handle.r))]
::
::  A retry is a new ask, never a second execution of the old one.  Preserve
::  the complete previous prompt as length-framed input, name the search that
::  changed the context, and render only the genuinely fresh refs below it.
::  The oracle and generation law remain the ones the prior ask was bound to.
++  retry-build
  |=  [prior=ask:dvn query=@t fresh=(list ref)]
  ^-  ask:dvn
  =/  task=@t
    %+  rap  3
    :~  'PATAPHOR-EVIDENCE-RETRY-V1\0aPREVIOUS-ASK '
        (scot %ud (met 3 prompt.prior))
        '\0a'
        prompt.prior
        '\0aSEARCH '
        (scot %ud (met 3 query))
        '\0a'
        query
        '\0aUse the new REFS below to answer the previous ask.\0a'
    ==
  (build task fresh oracle.prior law.prior)
::
::  Want provenance must remember the whole evidence history even though the
::  retry prompt embeds old evidence and renders only new pairs.  Set-to-list
::  gives one deterministic, duplicate-free handle sequence.
++  merge-handles
  |=  [prior=(list @t) fresh=(list ref)]
  ^-  (list @t)
  =/  all=(list @t)
    (weld prior (turn fresh |=(r=ref handle.r)))
  ~(tap in (~(gas in *(set @t)) all))
::
::  SELF-CHECK.  Given the same inputs twice, is the ask identical?
::  Cheap enough to run in a proof and honest about what it can prove:
::  it catches order-dependence and accidental ambient state in THIS
::  lib; it cannot catch a caller that put a clock in `task`.
++  deterministic
  |=  $:  task=@t
          refs=(list ref)
          oracle=oracle-id:dvn
          law=gen-law:dvn
      ==
  ^-  ?
  =/  a  (build task refs oracle law)
  =/  b  (build task (flop refs) oracle law)
  &(=(a (build task refs oracle law)) =(a b))
--
