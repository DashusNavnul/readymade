::  Identity-only proposal ingress and native retained-result observation.
/+  git=readymade-git-proposal, cr=codex-responses,
    guard=viki-scry-guard, terminal=native-coding-terminal
|%
++  hex
  |=  [o=json key=@t]
  ^-  @ux
  =/  text=@t  (need (string:cr o key))
  =/  id=@ux  (need (slaw %ux text))
  ?>  &(!=(0 id) (lte (met 0 id) 256) =(text (scot %ux id)))
  id
++  selection
  |=  [our=@p o=json]
  ^-  source-selection:git
  ?>  =(`(scot %p our) (string:cr o 'owner'))
  =/  repo=@t  (need (string:cr o 'repository'))
  =/  number=@ud  (need (natural:cr (field:cr o 'number')))
  =/  base=@ux  (need (token:git (need (string:cr o 'base'))))
  =/  head=@ux  (need (token:git (need (string:cr o 'head'))))
  ?>  (selection-valid:git [repo number base head 0x1])
  [repo number base head]
++  decode
  ::  The caller has already checked owner HTTP authority and CSRF.
  |=  [our=@p nonce=@ux o=json]
  ^-  *
  [%native-coding-action-v1 [%git-proposal (hex o 'session') nonce (hex o 'source') (selection our o)]]
++  status-json
  |=  s=candidate-status:git
  ^-  json
  %-  pairs:enjs:format
  :~  ['session' s+(scot %ux session.s)]
      ['request' s+(scot %ux request.s)]
      ['state' s+state.s]
      ['candidate' ?~(candidate.s ~ s+(scot %ux u.candidate.s))]
      ['reason' ?~(reason.s ~ s+u.reason.s)]
  ==
++  query
  ::  These identities need no URL escapes. Reject duplicates and unknown keys.
  |=  text=@t
  ^-  json
  =/  fields=(map @t json)  ~
  =/  left=@ud  8
  |-  ^-  json
  ?:  =('' text)  [%o fields]
  ?>  (gth left 0)
  =/  field  (split:terminal 38 text)
  =/  pair  (split:terminal 61 head.field)
  ?>  &(found.pair !=('' tail.pair))
  ?>  |(!found.field !=('' tail.field))
  ?>  ?=(?(%session %request %source %owner %repository %number %base %head) head.pair)
  ?>  !(~(has by fields) head.pair)
  =/  value=json  ?:(=('number' head.pair) [%n tail.pair] [%s tail.pair])
  $(text tail.field, left (dec left), fields (~(put by fields) head.pair value))
++  route
  |=  [our=@p now=@da url=@t]
  ^-  (unit json)
  =/  exact=@t  '/apps/pataphor-native/coding/git-proposal?'
  =/  lookup=@t  '/apps/pataphor-native/coding/git-proposals?'
  =/  single=?  =(exact (cut 3 [0 (met 3 exact)] url))
  ?.  |(single =(lookup (cut 3 [0 (met 3 lookup)] url)))  ~
  =/  parsed
    %-  mole
    |.
    ?>  (lte (met 3 url) 1.024)
    =/  o=json  (query (rsh [3 (met 3 ?:(single exact lookup))] url))
    =/  id=@ux  (hex o 'session')
    ?>  (agent-live:guard our now %viki)
    ?:  single
      =/  request=@ux  (hex o 'request')
      =/  raw  .^(* %gx /(scot %p our)/viki/(scot %da now)/native-coding/git-proposal/(scot %ux id)/(scot %ux request)/noun)
      =/  held=candidate-status:git  ;;(candidate-status:git raw)
      ?>  &(=(id session.held) =(request request.held))
      (pairs:enjs:format ~[['available' b+%.y] ['status' (status-json held)]])
    =/  source=@ux  (hex o 'source')
    =/  origin=@ux  (candidate-origin:git (selection our o) source)
    =/  raw  .^(* %gx /(scot %p our)/viki/(scot %da now)/native-coding/git-proposals/(scot %ux id)/(scot %ux origin)/noun)
    =/  held=candidate-lookup:git  ;;(candidate-lookup:git raw)
    ?>  &((lte (lent matches.held) 16) (gte total.held (lent matches.held)))
    ?>  &(=(id session.held) =(origin origin.held))
    ?>  (levy matches.held |=(s=candidate-status:git =(id session.s)))
    (pairs:enjs:format ~[['available' b+%.y] ['session' s+(scot %ux id)] ['origin' s+(scot %ux origin)] ['matches' a+(turn matches.held status-json)] ['total' (numb:enjs:format total.held)]])
  ?~  parsed  `(pairs:enjs:format ~[['available' b+%.n] ['error' s+'git-proposal-observation-unavailable']])
  parsed
--
