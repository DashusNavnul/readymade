::  Hot module owner: wraps an agent and holds gates that Clay builds from
::  /hot/<name>/hoon on the HOT DESK, each checked once (+admit) against the
::  types the agent was compiled with. The agent reads an installed gate by
::  scrying itself at /x/hot-module/<name> and runs its compiled default
::  when there is none. Nothing is saved: on-save and on-load pass straight
::  through, and a reload asks Clay again (answered from its build cache).
::  A refused build keeps the previous gate and is visible at /x/hot-module.
::
::  The hot desk is law data (%host-law /law/hot-modules/hoon, one @tas),
::  %hot-viki by default. It must be a dead desk that no app watches: a
::  commit to a watched desk (e.g. %host-viki, watched by brain-shell)
::  rebuilds that app. Phase98 measured 2.5 h of a frozen dashus from one.
::  [%hot-module-reread ~] from our rereads the law and moves without a rebuild.
/+  hot=hot-module
|%
+$  spec  [name=term arg=type res=type]
++  default-desk  %hot-viki
++  law-path  /law/hot-modules/hoon
++  path-of  |=(name=term ^-(path /hot/[name]/hoon))
++  law-desk
  |=  [our=@p now=@da]
  ^-  @tas
  =/  pax=path  (weld /(scot %p our)/host-law/(scot %da now) law-path)
  ?.  .^(? %cu pax)  default-desk
  =/  got  (mule |.(;;(@tas q:(slap !>(~) (ream .^(@t %cx pax))))))
  ?:  ?=(%| -.got)  default-desk
  ?.  &(!=(%$ p.got) ((sane %tas) p.got) !=(%host-viki p.got))  default-desk
  p.got
++  asks
  ::  Cancel any older subscription (this desk, and the phase98 %host-viki
  ::  wires), then ask for the current build and every later change.
  |=  [b=bowl:gall desk=@tas specs=(list spec)]
  ^-  (list card:agent:gall)
  %-  zing
  %+  turn  specs
  |=  s=spec
  :~  [%pass /hot-module/next/[name.s] %arvo %c %warp our.b %host-viki ~]
      [%pass /hot-module/next/[desk]/[name.s] %arvo %c %warp our.b desk ~]
      [%pass /hot-module/sing/[desk]/[name.s] %arvo %c %warp our.b desk `[%sing %a da+now.b (path-of name.s)]]
      [%pass /hot-module/next/[desk]/[name.s] %arvo %c %warp our.b desk `[%next %a da+now.b (path-of name.s)]]
  ==
++  agent
  |=  specs=(list spec)
  |=  inner=agent:gall
  =|  slots=(map term slot:hot)
  =|  desk=@tas
  ^-  agent:gall
  |_  =bowl:gall
  +*  this  .
      ag  ~(. inner bowl)
  ++  on-init
    =.  desk  (law-desk our.bowl now.bowl)
    =^  cards  inner  on-init:ag
    [(weld (asks bowl desk specs) cards) this]
  ++  on-save  on-save:ag
  ++  on-load
    |=  old=vase
    =.  desk  (law-desk our.bowl now.bowl)
    =^  cards  inner  (on-load:ag old)
    [(weld (asks bowl desk specs) cards) this]
  ++  on-poke
    |=  [=mark =vase]
    ?:  &(=(%noun mark) =([%hot-module-reread ~] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  old=@tas  desk
      =.  desk  (law-desk our.bowl now.bowl)
      =/  drop=(list card:agent:gall)
        (turn specs |=(s=spec [%pass /hot-module/next/[old]/[name.s] %arvo %c %warp our.bowl old ~]))
      [(weld drop (asks bowl desk specs)) this]
    =^  cards  inner  (on-poke:ag mark vase)
    [cards this]
  ++  on-watch
    |=  =path
    =^  cards  inner  (on-watch:ag path)
    [cards this]
  ++  on-leave
    |=  =path
    =^  cards  inner  (on-leave:ag path)
    [cards this]
  ++  on-peek
    |=  =path
    ^-  (unit (unit cage))
    ?:  ?=([%x %hot-module-desk ~] path)  ``noun+!>(desk)
    ?.  ?=([%x %hot-module *] path)  (on-peek:ag path)
    ?.  =(our.bowl src.bowl)  ~
    ?:  ?=([%x %hot-module ~] path)
      ``noun+!>((~(run by slots) |=(s=slot:hot [path.s digest.s fault.s])))
    ?.  ?=([%x %hot-module @ ~] path)  [~ ~]
    =/  s  (~(get by slots) i.t.t.path)
    ``noun+!>(`(unit vase)`?~(s ~ gate.u.s))
  ++  on-agent
    |=  [=wire =sign:agent:gall]
    =^  cards  inner  (on-agent:ag wire sign)
    [cards this]
  ++  on-arvo
    |=  [=wire =sign-arvo]
    ::  Old-shape (phase98) or other-desk answers are stale: ignore, never rearm.
    ?:  ?=([%hot-module ?(%next %sing) @ ~] wire)  `this
    ?.  ?=([%hot-module ?(%next %sing) @ @ ~] wire)
      =^  cards  inner  (on-arvo:ag wire sign-arvo)
      [cards this]
    ?.  =(desk i.t.t.wire)  `this
    =/  name=term  i.t.t.t.wire
    =/  found  (skim specs |=(s=spec =(name name.s)))
    ?~  found  `this
    =/  s=spec  i.found
    =/  rearm=(list card:agent:gall)
      ?.  =(%next i.t.wire)  ~
      ~[[%pass /hot-module/next/[desk]/[name] %arvo %c %warp our.bowl desk `[%next %a da+now.bowl (path-of name)]]]
    ?.  ?=([%clay %writ *] sign-arvo)  [rearm this]
    =/  prior=slot:hot  (~(gut by slots) name [(path-of name) ~ 0x0 ~])
    =/  riot  p.sign-arvo
    ?~  riot
      [rearm this(slots (~(put by slots) name prior(fault `~[leaf+"no build: the module is absent or does not compile"])))]
    =/  built  (mule |.(!<(vase q.r.u.riot)))
    ?:  ?=(%| -.built)
      [rearm this(slots (~(put by slots) name prior(fault `p.built)))]
    [rearm this(slots (~(put by slots) name (install:hot prior p.built arg.s res.s)))]
  ++  on-fail
    |=  [=term =tang]
    =^  cards  inner  (on-fail:ag term tang)
    [cards this]
  --
--
