::  Provenance only: matching never authorizes execution or compiled reuse.
::  Callers supply bindings from independently validated versioned orders and
::  still require authenticated worker transport and fresh canonical law.
/-  r=native-coding-build-reference, x=native-coding-worker-work,
    nc=native-coding
/+  work=native-coding-worker-work, law=native-coding-worker,
    project=native-coding-project
|%
++  digest
  |=  ref=reference:r
  ^-  @ux
  (shax (jam ref(digest 0x0)))
++  revision-valid
  |=  v=revision:nc
  ^-  ?
  ?&  (revision-valid:project v)
      (lte (met 0 owner.v) 128)  (lte (met 0 number.v) 64)
      (segment-valid:project desk.v)
      (identifier:law `@ux`root.v)  (identifier:law `@ux`commit.v)
  ==
++  binding-valid
  |=  b=binding:r
  ^-  ?
  ?&  (pairing-valid:law pairing.b)
      (revision-valid source.b)  (revision-valid local.b)
      =(owner.pairing.b owner.source.b)  =(worker.pairing.b owner.local.b)
      =(root.source.b root.local.b)
      ?=(^ entry.b)  (path-valid:project entry.b)
      (levy `(list @ux)`~[order.b ticket.b namespace.b input.b scope.b] identifier:law)
  ==
++  valid
  |=  ref=reference:r
  ^-  ?
  ?&  (binding-valid binding.ref)
      (levy `(list @ux)`~[type-hash.ref product.ref digest.ref] identifier:law)
      =(digest.ref (digest ref))
      (lte (met 3 (jam ref)) 4.096)
  ==
++  matches
  ::  Equality binds every selected identity and source field, not a digest
  ::  reconstructed from a differently versioned worker order.
  |=  [expected=binding:r ref=reference:r]
  ^-  ?
  &((valid ref) =(expected binding.ref))
++  from-order
  ::  Compatibility adapter only; old order/task/admission bytes stay intact.
  |=  [o=tool-order:x local=revision:nc]
  ^-  (each binding:r @tas)
  ?.  (tool-order-valid:work o)  [%| %build-reference-order-invalid]
  =/  b=binding:r
    [(digest:work o) ticket.o pairing.o source.o local namespace.o input.purpose.o scope.purpose.o entry.purpose.o]
  ?.  (binding-valid b)  [%| %build-reference-binding-invalid]
  [%& b]
++  make
  ::  Hash the actual typed Ford result locally. Never reconstruct a vase
  ::  from remote DATA, execute it, or serialize it as part of the reference.
  |=  [b=binding:r built=vase]
  ^-  (each reference:r @tas)
  =/  ref=reference:r
    [%native-coding-build-reference-v1 b (shax (jam p.built)) (shax (jam q.built)) 0x0]
  =.  digest.ref  (digest ref)
  ?.  (matches b ref)  [%| %build-reference-binding-invalid]
  [%& ref]
--
