::  Sticky QPC session requirement around the complete native agent.
::  Foundation: managed sessions stay closed until selected admission is wired.
/-  nc=native-coding
/+  tools=cantrip-native-coding, pool=qpc-native-pool
|%
+$  gate-role  ?(%viki %cantrip)
+$  tool-record
  [grant=@ux request=tool-request:nc at=@da stage=@tas result=(unit tool-result:nc)]
+$  tool-state  [grants=* records=(map @ux tool-record)]
++  executable-session
  |=  value=*
  ^-  (unit @ux)
  =/  parsed
    ((soft ,[%native-coding-execute-v1 grant=@ux request=tool-request:nc]) value)
  ?~  parsed  ~
  ?.  (executable:tools -.arguments.request.u.parsed)  ~
  `session.context.request.u.parsed
++  candidate-id
  |=  [role=gate-role value=*]
  ^-  (unit @ux)
  ?:  =(%viki role)
    =/  parsed  ((soft ,[%native-coding-review-action-v1 [%start id=@ux]]) value)
    ?~(parsed ~ `id.u.parsed)
  =/  native
    ((soft ,[?(%native-coding-review-v1 %native-coding-decide-v1 %native-coding-candidate-observe-v1) id=@ux]) value)
  ?^  native  `id.u.native
  ::  The permissions UI internally calls Cantrip's inner on-poke; intercept
  ::  its envelope too, before that internal call can bypass this wrapper.
  =/  ui
    ((soft ,[%readymade-permissions-action-v1 source=@ux [?(%review %decide %observe) id=@ux]]) value)
  ?~(ui ~ `id.u.ui)
++  payload
  |=  value=(unit (unit cage))
  ^-  (unit *)
  ?~  value  ~
  ?~  u.value  ~
  ?.  =(%noun p.u.u.value)  ~
  `q.q.u.u.value
++  candidate-session
  |=  [role=gate-role inner=agent:gall b=bowl:gall id=@ux]
  ^-  (unit @ux)
  =/  ag  ~(. inner b(src our.b))
  ?:  =(%viki role)
    =/  data  (payload (on-peek:ag /x/native-coding/candidate/(scot %ux id)))
    ?~  data  ~
    =/  candidate  ((soft ,(unit candidate:nc)) u.data)
    ?~  candidate  ~
    ?~  u.candidate  ~
    `session.context.u.u.candidate
  =/  data  (payload (on-peek:ag /x/native-coding/tool-state))
  ?~  data  ~
  =/  tools  ((soft tool-state) u.data)
  ?~  tools  ~
  =/  rows=(list tool-record)  ~(val by records.u.tools)
  |-  ^-  (unit @ux)
  ?~  rows  ~
  =/  result  result.i.rows
  ?~  result  $(rows t.rows)
  ?.  ?=(%candidate -.output.u.result)  $(rows t.rows)
  ?:  =(id id.value.output.u.result)  `session.context.value.output.u.result
  $(rows t.rows)
++  unused
  |=  [role=gate-role inner=agent:gall b=bowl:gall id=@ux]
  ^-  ?
  =/  ag  ~(. inner b(src our.b))
  =/  data  (payload (on-peek:ag /x/native-coding/used-sessions))
  ?~  data  %.n
  =/  used  ((soft ,(set @ux)) u.data)
  ?~  used  %.n
  !(~(has in u.used) id)
++  agent
  |=  [role=gate-role inner=agent:gall]
  =|  required=(set @ux)
  =|  pools=(map @ux pool:pool)
  ^-  agent:gall
  |_  =bowl:gall
  +*  this  .
      ag  ~(. inner bowl)
  ++  on-init
    =^  cards  inner  on-init:ag
    [cards this]
  ++  on-save
    !>([%qpc-session-gate-v2 role required pools on-save:ag])
  ++  on-load
    |=  old=vase
    =/  saved=[role=gate-role required=(set @ux) pools=(map @ux pool:pool) inner=vase]
      ?:  ?=([%qpc-session-gate-v2 *] q.old)
        =/  prior
          !<([%qpc-session-gate-v2 role=gate-role required=(set @ux) pools=(map @ux pool:pool) inner=vase] old)
        +.prior
      ?.  ?=([%qpc-session-gate-v1 *] q.old)  [role ~ ~ old]
      =/  prior
        !<([%qpc-session-gate-v1 role=gate-role required=(set @ux) inner=vase] old)
      [role.prior required.prior ~ inner.prior]
    ?>  =(role role.saved)
    ?>  (lte ~(wyt in required.saved) 128)
    ?>  (levy ~(tap in required.saved) |=(id=@ux &(!=(0 id) (lte (met 0 id) 256))))
    ?>  (lte ~(wyt by pools.saved) 64)
    ?>  ?:(=(%cantrip role) =(~ pools.saved) %.y)
    ?>  %+  levy  ~(tap by pools.saved)
        |=  [id=@ux p=pool:pool]
        &((valid:pool p) =(our.bowl owner.p) =(id session.p) (~(has in required.saved) id))
    =.  required  required.saved
    =.  pools  pools.saved
    =^  cards  inner  (on-load:ag inner.saved)
    [cards this]
  ++  on-poke
    |=  [=mark =vase]
    ?:  &(=(%noun mark) ?=([%qpc-pool-seal-v1 @] q.vase))
      ?>  &(=(%viki role) =(our.bowl src.bowl))
      =/  id=@ux  `@ux`+.q.vase
      ?>  (~(has in required) id)
      ?:  (~(has by pools) id)  [~ this]
      ?>  (lth ~(wyt by pools) 64)
      =/  sealed  (read:pool inner bowl id)
      ?:  ?=(%| -.sealed)
        ~|  [%qpc-pool-refused-v1 id p.sealed]
        !!
      =/  cards=(list card:agent:gall)
        ~[[%pass /qpc/pool/(scot %ux id) %agent [our.bowl %graf] %poke %graf-action !>([%attest [%qpc-native-pool-v1 p.sealed]])]]
      [cards this(pools (~(put by pools) id p.sealed))]
    ?:  &(=(%noun mark) ?=([%qpc-session-require-v1 @] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  id=@ux  `@ux`+.q.vase
      ?>  &(!=(0 id) (lte (met 0 id) 256))
      ?:  (~(has in required) id)  [~ this]
      ?>  (lth ~(wyt in required) 128)
      ~|  %qpc-session-must-be-unused
      ?>  (unused role inner bowl id)
      [~ this(required (~(put in required) id))]
    =/  executable
      ?:(&(=(%cantrip role) =(%noun mark)) (executable-session q.vase) ~)
    ?^  executable
      ~|  [%qpc-selection-required u.executable]
      ?>  !(~(has in required) u.executable)
      =^  cards  inner  (on-poke:ag mark vase)
      [cards this]
    =/  id  ?:(=(%noun mark) (candidate-id role q.vase) ~)
    ?:  &(?=(^ id) (gth ~(wyt in required) 0))
      ?>  ?=(^ id)
      =/  session  (candidate-session role inner bowl u.id)
      ~|  [%qpc-candidate-unreadable u.id]
      ?>  ?=(^ session)
      ~|  [%qpc-selection-required u.session u.id]
      ?>  !(~(has in required) u.session)
      =^  cards  inner  (on-poke:ag mark vase)
      [cards this]
    =^  cards  inner  (on-poke:ag mark vase)
    [cards this]
  ++  on-watch
    |=  =path
    =^  cards  inner  (on-watch:ag path)
    [cards this]
  ++  on-leave
    |=  =path
    =^  cards  inner  (on-leave:ag path)
    [cards this]
  ++  on-peek
    |=  =path
    ?:  ?=([%x %qpc %pool @ ~] path)
      ?.  &(=(%viki role) =(our.bowl src.bowl))  ~
      =/  id  (slaw %ux i.t.t.t.path)
      ?~  id  ``noun+!>(*(unit pool:pool))
      ``noun+!>((~(get by pools) u.id))
    ?:  =(/x/qpc/required-sessions path)
      ?.  =(our.bowl src.bowl)  ~
      ``noun+!>([%qpc-session-gate-v1 role required])
    (on-peek:ag path)
  ++  on-agent
    |=  [=wire =sign:agent:gall]
    =^  cards  inner  (on-agent:ag wire sign)
    [cards this]
  ++  on-arvo
    |=  [=wire =sign-arvo]
    =^  cards  inner  (on-arvo:ag wire sign-arvo)
    [cards this]
  ++  on-fail
    |=  [=term =tang]
    =^  cards  inner  (on-fail:ag term tang)
    [cards this]
  --
--
