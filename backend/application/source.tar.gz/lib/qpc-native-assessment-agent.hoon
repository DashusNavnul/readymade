::  Owner-only private staging and shared worker assessment. No review,
::  landing, admission receipt or ordinary acceptance row is created.
/-  nc=native-coding, w=native-coding-worker
/+  a=qpc-native-assessment, read=qpc-native-assessment-read,
    parent=native-coding-worker-owner-runtime,
    worker=native-coding-worker-owner, instrument=qpc-instrument-contract,
    journal=native-coding-worker-journal, accept=native-coding-accept,
    dsr=desk-shell-read, source=native-coding-worker-source
|%
+$  found  [record=record:a row=row:a]
+$  absent-reader  $-([inner=agent:gall b=bowl:gall desk=@tas] ?)
+$  tree-reader  $-([inner=agent:gall b=bowl:gall r=record:a v=row:a] (each tree:nc @tas))
+$  parents-reader  $-([inner=agent:gall b=bowl:gall tree=tree:nc] (list @uv))
+$  parent-reader  $-([inner=agent:gall b=bowl:gall] state:parent)
++  absent
  |=  [inner=agent:gall b=bowl:gall desk=@tas]
  (absent:source our.b now.b desk)
++  tree
  |=  [inner=agent:gall b=bowl:gall r=record:a v=row:a]
  (staged:accept our.b now.b (bridge:a r v))
++  parents
  |=  [inner=agent:gall b=bowl:gall tree=tree:nc]
  ^-  (list @uv)
  =/  commit=yaki:clay
    .^(yaki:clay %cs (beam:dsr our.b now.b desk.revision.tree /yaki/(scot %uv commit.revision.tree)))
  p.commit
++  parent-state
  |=  [inner=agent:gall b=bowl:gall]
  .^(state:parent %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/worker/state/noun)
++  find
  |=  [s=state:a id=@ux ticket=?]
  ^-  (unit found)
  =/  matches=(list found)
    %-  zing
    %+  turn  ~(val by records.s)
    |=  r=record:a
    %+  murn  ~(val by rows.r)
    |=  v=row:a
    =/  key=@ux  ?:(ticket (ticket:worker (bridge:a r v)) id.candidate.v)
    ?:(=(id key) `[r v] ~)
  ?.  ?=([* ~] matches)  ~
  `i.matches
++  wire-for
  |=  [r=record:a v=row:a kind=@tas]
  /qpc-assessment/(scot %ux session.pool.binding.r)/(scot %ux id.candidate.v)/[kind]
++  wrap-with
  ::  Proof seams are native gates, not caller-supplied command fields.
  |=  [inner=agent:gall fetch=reader:read empty-desk=absent-reader read-tree=tree-reader read-parents=parents-reader read-parent=parent-reader]
  =/  held=state:a  empty:a
  ^-  agent:gall
  |_  =bowl:gall
  +*  this  .
      ag  ~(. inner bowl)
      refuse
        |=  [id=@ux reason=@tas]
        ^-  (quip card:agent:gall _this)
        =.  held  (unavailable:a held id reason)
        [~[[%give %fact ~[/qpc/assessments] %noun !>([%qpc-assessment-unavailable-v1 id reason])]] this]
      fail
        |=  [r=record:a v=row:a reason=@tas]
        ^-  (quip card:agent:gall _this)
        =/  next=record:a  (stop:a r id.candidate.v %unknown reason)
        [~ this(held held(records (~(put by records.held) session.pool.binding.r next)))]
      fresh
        |=  r=record:a
        ^-  (unit @tas)
        =/  attempt  (mule |.((fetch inner bowl(src our.bowl) session.pool.binding.r)))
        ?:  ?=(%| -.attempt)  `%qpc-assessment-read-unconfirmed
        =/  got  p.attempt
        ?:  ?=(%| -.got)  `p.got
        ?:(=(binding.r binding.p.got) ~ `%qpc-assessment-binding-changed)
      next
        |=  id=@ux
        ^-  (quip card:agent:gall _this)
        =/  r=record:a  (~(got by records.held) id)
        ?:  (lien ~(val by rows.r) |=(v=row:a ?=(?(%cloning %staging %staged %sent %unknown) phase.v)))  `this
        =/  todo=(list row:a)  (skim ~(val by rows.r) |=(v=row:a =(%prepared phase.v)))
        ?~  todo  `this
        =/  v=row:a  i.todo
        ?:  (gte now.bowl (add at.r ~m20))  (fail r v %qpc-assessment-deadline-unconfirmed)
        =/  issue  (fresh r)
        ?^  issue  (fail r v u.issue)
        =/  selected  (read-parent inner bowl)
        ?.  &((valid:parent our.bowl selected) engaged.selected ?=(^ pairing.owner.selected))  (fail r v %worker-not-selected)
        ?:  (busy:journal journal.owner.selected worker.u.pairing.owner.selected)  (fail r v %worker-unresolved)
        =/  desk=@tas  (staging-desk:accept id.candidate.v)
        ?.  (empty-desk inner bowl desk)  (fail r v %qpc-assessment-desk-exists)
        =/  started  (start-clone:a r id.candidate.v)
        ?:  ?=(%| -.started)  (fail r v p.started)
        =.  held  held(records (~(put by records.held) id p.started))
        :_  this
        :~  [%pass (wire-for r v %clone) %arvo %c %merg desk our.bowl desk.source.context.candidate.v [%ud number.source.context.candidate.v] %init]
            [%pass (wire-for r v %clone-ready) %arvo %c %warp our.bowl desk ~ %sing %z [%ud 1] /]
            [%pass (wire-for r v %deadline) %arvo %b %wait (add at.r ~m20)]
        ==
      bind-order
        |=  ticket=@ux
        ^-  (quip card:agent:gall _this)
        =/  found  (find held ticket %.y)
        ?~  found  `this
        =/  r=record:a  record.u.found
        =/  v=row:a  row.u.found
        ?.  =(%staged phase.v)  `this
        =/  issue  (fresh r)
        ?^  issue  (fail r v u.issue)
        =/  shared=state:parent  (read-parent inner bowl)
        =/  rows=(list record:w)
          (skim ~(val by journal.owner.shared) |=(row=record:w =(ticket ticket.order.row)))
        ?.  ?=([* ~] rows)  (fail r v %qpc-assessment-order-missing)
        =/  kept=record:w  i.rows
        ?.  &(!sent.kept =(%reserved phase.kept) !(~(has by failures.shared) ticket) =(`id.candidate.v (~(get by pending.shared) ticket)))
          (fail r v %qpc-assessment-order-not-reserved)
        =/  bound  (map-order:a r id.candidate.v order.kept)
        ?:  ?=(%| -.bound)  (fail r v p.bound)
        [~ this(held held(records (~(put by records.held) session.pool.binding.r p.bound)))]
      complete
        |=  ticket=@ux
        ^-  (quip card:agent:gall _this)
        =/  found  (find held ticket %.y)
        ?~  found
          =^  cards  inner  (on-poke:ag %noun !>([%native-coding-worker-apply-v1 ticket]))
          [cards this]
        =/  r=record:a  record.u.found
        =/  v=row:a  row.u.found
        =/  shared=state:parent  (read-parent inner bowl)
        =/  failed  (~(get by failures.shared) ticket)
        =/  issue  (fresh r)
        =.  r
          ?^  failed  (stop:a r id.candidate.v %unknown u.failed)
          ?^  issue  (stop:a r id.candidate.v %unknown u.issue)
          r
        =/  rows=(list record:w)
          (skim ~(val by journal.owner.shared) |=(row=record:w =(ticket ticket.order.row)))
        =/  changed=record:a
          ?.  ?=([* ~] rows)  r
          =/  result  (settle:a r id.candidate.v i.rows)
          ?:(?=(%& -.result) p.result r)
        =.  held  held(records (~(put by records.held) session.pool.binding.r changed))
        (next session.pool.binding.r)
  ++  on-init
    =^  cards  inner  on-init:ag
    [cards this]
  ++  on-save  !>([%qpc-assessment-owner-v1 held on-save:ag])
  ++  on-load
    |=  old=vase
    =/  saved=[held=state:a inner=vase]
      ?.  ?=([%qpc-assessment-owner-v1 *] q.old)  [empty:a old]
      =/  prior  !<([%qpc-assessment-owner-v1 held=state:a inner=vase] old)
      +.prior
    ?>  (valid:a our.bowl held.saved)
    =.  held  (recover:a held.saved)
    =^  cards  inner  (on-load:ag inner.saved)
    [cards this]
  ++  on-poke
    |=  [=mark =vase]
    ?:  &(=(%noun mark) ?=([%qpc-assess-v1 @] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  id=@ux  +.q.vase
      ?>  &(!=(0 id) (lte (met 0 id) 256))
      ?:  |((~(has by records.held) id) (~(has by unavailable.held) id))  [~ this]
      =/  attempted  (mule |.((fetch inner bowl id)))
      ?:  ?=(%| -.attempted)  (refuse id %qpc-assessment-read-unconfirmed)
      =/  got  p.attempted
      ?:  ?=(%| -.got)  (refuse id p.got)
      =/  prepared  (begin:a held our.bowl src.bowl now.bowl p.got)
      ?:  ?=(%| -.prepared)  (refuse id p.prepared)
      =.  held  p.prepared
      (next id)
    ?:  &(=(%noun mark) ?=([%qpc-assessment-worker-bind-v1 @] q.vase))
      ?>  =(our.bowl src.bowl)
      (bind-order `@ux`+.q.vase)
    ?:  &(=(%noun mark) ?=([%native-coding-worker-apply-v1 @] q.vase))
      ?>  =(our.bowl src.bowl)
      (complete `@ux`+.q.vase)
    =^  cards  inner  (on-poke:ag mark vase)
    [cards this]
  ++  on-peek
    |=  =path
    ?:  =(/x/qpc/assessments path)
      ?.  =(our.bowl src.bowl)  ~
      ``noun+!>(held)
    ?:  ?=([%x %qpc %assessment-candidate @ ~] path)
      ?.  =(our.bowl src.bowl)  ~
      =/  id  (slaw %ux i.t.t.t.path)
      ?~  id  ``noun+!>(*(unit found))
      ``noun+!>((find held u.id %.n))
    ?:  |(=(path /x/native-coding/reserved-desks) ?=([%x %native-coding %reserved-desks %except-worker-export @ ~] path))
      ?.  =(our.bowl src.bowl)  (on-peek:ag path)
      =/  raw  (raw:instrument inner bowl path)
      ?~  raw  [~ ~]
      =/  desks=(set @tas)  ;;((set @tas) u.raw)
      =/  private=(list @tas)
        %-  zing
        %+  turn  ~(val by records.held)
        |=  r=record:a
        (turn ~(val by rows.r) |=(v=row:a (staging-desk:accept id.candidate.v)))
      ``noun+!>((~(gas in desks) private))
    (on-peek:ag path)
  ++  on-arvo
    |=  [=wire sign=sign-arvo]
    ?.  ?=([%qpc-assessment @ @ @ ~] wire)
      =^  cards  inner  (on-arvo:ag wire sign)
      [cards this]
    ?.  =(our.bowl src.bowl)  `this
    =/  id  (slaw %ux i.t.wire)
    =/  candidate  (slaw %ux i.t.t.wire)
    ?~  id  `this
    ?~  candidate  `this
    =/  found  (find held u.candidate %.n)
    ?~  found  `this
    =/  r=record:a  record.u.found
    =/  v=row:a  row.u.found
    =/  kind=@tas  i.t.t.t.wire
    ?.  &(=(u.id session.pool.binding.r) =(wire (wire-for r v kind)))  `this
    ?:  =(%deadline kind)
      ?.  &(?=([%behn %wake *] sign) (gte now.bowl (add at.r ~m20)))  `this
      (fail r v %qpc-assessment-deadline-unconfirmed)
    ?.  ?=([%clay %writ *] sign)  `this
    ?.  |(&(=(%clone-ready kind) =(%cloning phase.v)) &(=(%stage-ready kind) =(%staging phase.v)))  `this
    =/  issue  (fresh r)
    ?^  issue  (fail r v u.issue)
    =/  snapshot  (read-tree inner bowl r v)
    ?:  ?=(%| -.snapshot)  (fail r v p.snapshot)
    ?:  =(%clone-ready kind)
      =/  changed  (cloned:a r id.candidate.v p.snapshot)
      ?:  ?=(%| -.changed)  (fail r v p.changed)
      =.  held  held(records (~(put by records.held) u.id p.changed))
      :_  this
      :~  [%pass (wire-for r v %edit) %arvo %c %info desk.revision.p.snapshot %.y (edits:accept candidate.v)]
          [%pass (wire-for r v %stage-ready) %arvo %c %warp our.bowl desk.revision.p.snapshot ~ %sing %z [%ud 2] /]
      ==
    =/  changed  (stage:a r id.candidate.v p.snapshot (read-parents inner bowl p.snapshot))
    ?:  ?=(%| -.changed)  (fail r v p.changed)
    =.  held  held(records (~(put by records.held) u.id p.changed))
    [~[[%pass (wire-for r v %start) %agent [our.bowl dap.bowl] %poke %noun (start-payload:a id.candidate.v)]] this]
  ++  on-watch
    |=  =path
    =^  cards  inner  (on-watch:ag path)
    [cards this]
  ++  on-leave
    |=  =path
    =^  cards  inner  (on-leave:ag path)
    [cards this]
  ++  on-agent
    |=  [=wire =sign:agent:gall]
    ?:  ?=([%qpc-assessment @ @ %start ~] wire)
      ?.  &(=(our.bowl src.bowl) ?=(%poke-ack -.sign) ?=(^ p.sign))  `this
      =/  id  (slaw %ux i.t.t.wire)
      ?~  id  `this
      =/  found  (find held u.id %.n)
      ?~  found  `this
      ?.  =(wire (wire-for record.u.found row.u.found %start))  `this
      (fail record.u.found row.u.found %qpc-assessment-worker-start-unconfirmed)
    =^  cards  inner  (on-agent:ag wire sign)
    [cards this]
  ++  on-fail
    |=  [=term =tang]
    =^  cards  inner  (on-fail:ag term tang)
    [cards this]
  --
++  wrap
  |=  [inner=agent:gall fetch=reader:read]
  (wrap-with inner fetch absent tree parents parent-state)
++  agent  |=(inner=agent:gall (wrap inner read:read))
--
