::  /lib/multiplayer-communication
::
::  Pure communication law. Presence is deliberately separate from authority.
::
/-  mm=multiplayer-communication, mr=multiplayer-receipt
/+  mrl=multiplayer-receipt
|%
++  max-gap  `@ud`64
++  message-digest
  |=  body=message-body:mm
  ^-  digest:mm
  `@ux`(shax (jam [%multiplayer-message-v1 body]))
++  make-message
  |=  body=message-body:mm
  ^-  message:mm
  [body (message-digest body)]
++  message-valid
  |=  item=message:mm
  ^-  ?
  ?&  =(1 version.body.item)
      !=(0 project.body.item)
      !=(0 source-sequence.body.item)
      !=(0 sent-at.body.item)
      =((message-digest body.item) digest.item)
      ?-  -.action.body.item
        %comment  !=(0 text.action.body.item)
        %mention  ?&  !=(0 target.action.body.item)  !=(0 text.action.body.item)  ==
        %review   !=(0 changeset.action.body.item)
        %reply    ?&  !=(0 parent.action.body.item)  !=(0 text.action.body.item)  ==
      ==
  ==
++  init-mailbox
  |=  project=project-id:mr
  ^-  mailbox:mm
  [project ~ ~]
++  enqueue
  |=  [box=mailbox:mm item=message:mm]
  ^-  (unit mailbox:mm)
  ?.  ?&  (message-valid item)  =(project.box project.body.item)  ==  ~
  `box(outbox (~(put by outbox.box) digest.item item))
++  accept
  |=  [box=mailbox:mm item=message:mm]
  ^-  (unit mailbox:mm)
  ?.  ?&  (message-valid item)  =(project.box project.body.item)  ==  ~
  `box(inbox (~(put by inbox.box) digest.item item))
++  init-cursor  [next=1 seen=~ gaps=~ overflow=%.n]
++  add-gaps
  |=  [gaps=(set @ud) from=@ud to=@ud remaining=@ud]
  ^-  (set @ud)
  ?:  ?|  (gte from to)  =(0 remaining)  ==  gaps
  $(gaps (~(put in gaps) from), from +(from), remaining (dec remaining))
++  advance
  |=  cursor=cursor:mm
  ^-  cursor:mm
  ?.  (~(has in seen.cursor) next.cursor)  cursor
  $(cursor cursor(next +(next.cursor), seen (~(del in seen.cursor) next.cursor), gaps (~(del in gaps.cursor) next.cursor)))
++  observe
  |=  [cursor=cursor:mm sequence=@ud]
  ^-  cursor:mm
  ?:  (lth sequence next.cursor)  cursor
  ?:  (gth sequence (add next.cursor max-gap))  cursor(overflow %.y)
  =/  gaps=(set @ud)
    (add-gaps gaps.cursor next.cursor sequence max-gap)
  =/  next=cursor:mm
    cursor(seen (~(put in seen.cursor) sequence), gaps (~(del in gaps) sequence))
  (advance next)
++  record
  |=  $:  chain=chain:mr
          kind=operation-kind:mm
          payload=*
          actor=@p
          host-sequence=@ud
          source-sequence=@ud
          occurred-at=@da
      ==
  ^-  receipt-result:mm
  =/  stamped=actor:mr  [actor ~ ~]
  =/  item=event:mr
    (make-live:mrl project.chain authority-host.chain host-sequence head.chain actor source-sequence kind stamped payload occurred-at ~)
  (append:mrl chain item occurred-at)
++  set-presence
  |=  [board=presence-board:mm actor=@p state=presence-state:mm observed-at=@da]
  ^-  presence-board:mm
  (~(put by board) actor [state observed-at])
--
