::  Owner presentation of explicit root exports. No compiler invocation,
::  inferred names, installation rights or model-supplied configuration.
/-  nc=native-coding
/+  runtime=native-coding-compiler-exports-runtime,
    selected=native-coding-compiler-mapping-http,
    project=native-coding-project, modules=native-coding-module-sources,
    input=native-coding-onboarding-http, terminal=native-coding-terminal,
    artifact=native-coding-compiler-artifact, guard=viki-scry-guard
|%
++  read
  |=  [our=@p now=@da]
  ^-  (unit (map key:runtime choice:runtime))
  ?.  (agent-live:guard our now %cantrip)  ~
  =/  choices=(map key:runtime choice:runtime)
    .^((map key:runtime choice:runtime) %gx /(scot %p our)/cantrip/(scot %da now)/native-coding/compiler-export-choices/noun)
  `choices
++  target-json
  |=  [p=project:nc choices=(map key:runtime choice:runtime) target=build-target:nc]
  ^-  json
  =/  found  (~(get by choices) [(configuration:project p) name.target])
  =/  exact=?
    ?~(found %.y &(=(p project.selection.u.found) =(target target.selection.u.found)))
  =/  status=@t
    ?.  exact  'conflict'
    ?~  found  'absent'
    ?:(enabled.u.found 'configured' 'revoked')
  (pairs:enjs:format ~[['name' s+name.target] ['entry' s+(spat entry.target)] ['targetDigest' s+(scot %ux (digest:modules target))] ['status' s+status] ['names' a+?~(found ~ (turn names.selection.u.found |=(name=@t s+name)))]])
++  view
  |=  [our=@p now=@da session=@ux]
  ^-  json
  =/  found  (selected:selected our now session)
  =/  choices  (read our now)
  =/  reason=@tas
    ?:  ?=(%| -.found)  p.found
    ?~  choices  %compiler-export-choices-unavailable
    %compiler-export-choices-observed
  =/  targets=(list json)
    ?.  ?=(%& -.found)  ~
    ?~  choices  ~
    =/  p=project:nc  project.p.found
    (turn (skim targets.p |=(t=build-target:nc =(%gallowglass kind.t))) |=(t=build-target:nc (target-json p u.choices t)))
  (pairs:enjs:format ~[['available' b+&(?=(%& -.found) ?=(^ choices))] ['reason' s+reason] ['session' s+(scot %ux session)] ['project' s+?:(?=(%& -.found) id.spec.project.p.found '')] ['configuration' s+?:(?=(%& -.found) (scot %ux (configuration:project project.p.found)) '')] ['ready' b+?:(?=(%& -.found) ready.p.found %.n)] ['targets' a+targets]])
++  route
  |=  [our=@p now=@da url=@t]
  ^-  (unit json)
  =/  prefix=@t  '/apps/pataphor-native/coding/compiler-exports?'
  ?.  &(=(prefix (cut 3 [0 (met 3 prefix)] url)) (lte (met 3 url) 180))  ~
  =/  text=@t  (rsh [3 (met 3 prefix)] url)
  =/  session  (slaw %ux text)
  ?~  session  ~
  ?.  &((lte (met 0 u.session) 256) =(text (scot %ux u.session)))  ~
  `(view our now u.session)
++  decode
  ::  The caller supplies authenticated owner/CSRF checks before this gate.
  |=  [our=@p now=@da object=json]
  ^-  command:runtime
  =/  kind=@t  (text:input object 'kind' 40 %.y)
  =/  session=@ux  (digest:terminal (text:input object 'session' 82 %.y))
  =/  found  (selected:selected our now session)
  ?>  ?=(%& -.found)
  =/  p=project:nc  project.p.found
  =/  configuration=@ux  (digest:terminal (text:input object 'configuration' 82 %.y))
  ?>  =(configuration (configuration:project p))
  =/  name=@tas  (name:terminal (text:input object 'target' 64 %.y))
  =/  matches=(list build-target:nc)  (skim targets.p |=(t=build-target:nc =(name name.t)))
  ?>  ?=(^ matches)
  ?>  ?=(~ t.matches)
  =/  target=build-target:nc  i.matches
  ?>  &(!=(0 session) =(%gallowglass kind.target))
  ?>  =((digest:modules target) (digest:terminal (text:input object 'targetDigest' 82 %.y)))
  =/  old  (~(get by (need (read our now))) [configuration name])
  ?:  =('compiler-exports-revoke' kind)
    ?>  ?=(^ old)
    ?>  &(=(project.selection.u.old p) =(target.selection.u.old target))
    [%native-coding-compiler-exports-revoke-v1 configuration name]
  ?>  &(=('compiler-exports-configure' kind) ready.p.found)
  =/  names=(list @t)  (strings:input object 'names' 8)
  ?>  &((gte (lent names) 1) (levy names name-valid:artifact) =((lent names) ~(wyt in (silt names))))
  ?>  ?~(old %.y &(enabled.u.old =(project.selection.u.old p) =(target.selection.u.old target) =(names.selection.u.old names)))
  [%native-coding-compiler-exports-configure-v1 p name names]
--
