::  Pure one-write history state. A native adapter must read actual private
::  Clay heads, exact trees and the record; this law itself performs no IO.
/+  receipt=native-coding-session-archive-retirement,
    names=native-coding-provider
|%
+$  head  [desk=@tas number=@ud commit=@uv]
+$  state  [head=(unit head) writing=(unit receipt:receipt)]
+$  confirmed  [state=state receipt=receipt:receipt]
++  path-for
  |=(id=@ux ^-(path /native-coding-session-history/by-session/(scot %ux id)/noun))
++  valid-head
  |=  h=head
  ^-  ?
  &((name-valid:names desk.h) !=(%base desk.h) !=(0 number.h) !=(0 commit.h))
++  begin
  ::  Only the owner may set a pending intent. The caller must already have
  ::  qualified its evidence and observed absence of the immutable path.
  |=  [our=@p actor=@p s=state e=receipt:receipt]
  ^-  (each state @tas)
  ?.  =(our actor)  [%| %archive-owner-required]
  ?~  head.s  [%| %archive-history-unconfigured]
  ?.  (valid-head u.head.s)  [%| %archive-history-invalid]
  ?^  writing.s  [%| %archive-write-pending]
  ?.  (valid-receipt:receipt our e)  [%| %archive-receipt-invalid]
  [%& s(writing `e)]
++  append-valid
  |=  [before=head after=head e=receipt:receipt old=yaki:clay new=yaki:clay]
  ^-  ?
  ?&  (valid-head before)  (valid-head after)
      =(desk.before desk.after)  =(+(number.before) number.after)
      !=(commit.before commit.after)
      =(r.old commit.before)  =(r.new commit.after)  =(~[commit.before] p.new)
      !(~(has by q.old) (path-for session.e))
      =(q.new (~(put by q.old) (path-for session.e) (page-to-lobe:clay [%noun e])))
  ==
++  confirm
  ::  A missing, changed or unnumbered observation cannot clear pending.
  |=  [our=@p actor=@p s=state after=head old=yaki:clay new=yaki:clay stored=(unit receipt:receipt)]
  ^-  (each confirmed @tas)
  ?.  =(our actor)  [%| %archive-owner-required]
  ?~  head.s  [%| %archive-history-unconfigured]
  ?~  writing.s  [%| %archive-write-not-pending]
  ?~  stored  [%| %archive-readback-unavailable]
  ?.  =(u.writing.s u.stored)  [%| %archive-readback-mismatch]
  ?.  (valid-receipt:receipt our u.stored)  [%| %archive-receipt-invalid]
  ?.  (append-valid u.head.s after u.stored old new)  [%| %archive-history-not-confirmed]
  [%& [[`after ~] u.stored]]
--
