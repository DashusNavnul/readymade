::  Pure owner-edit admission and journal mechanics. Not installed authority.
::  A future Cantrip handler must reserve and emit the card in one Gall event.
::  No model identity, execution, compilation or acceptance is asserted.
/+  model=pataphor-editor-model, law=cantrip-law-window, demo=vibecoding-demo
|%
+$  support  (map path @uv)
+$  basis  [current=snapshot:model support=support parent=@uv]
+$  admission
  $:  %cantrip-editor-save-admission-v1
      change=change:model  basis=basis  window=window:law  at=@da
  ==
+$  commit  [id=@uv parents=(list @uv) at=@da]
+$  observation  [current=snapshot:model support=support commit=(unit commit)]
+$  record-v1
  $:  %cantrip-editor-save-record-v1
      admission=admission  status=?(%submitted %unknown %applied)
      observation=(unit observation)
  ==
+$  ledger-v1  (map @ux record-v1)
+$  historical
  $:  %cantrip-editor-save-history-v1
      owner=@p  at=@da  work=revision:model  pax=path
      blob=@uv  body=content:model  support=support  commit=commit
      files=(set path)
  ==
+$  recovery  [current=basis historical=(unit historical)]
+$  record
  $:  %cantrip-editor-save-record-v2
      admission=admission  status=?(%submitted %unknown %applied)
      observation=(unit observation)
      historical=(unit historical)  fence=(unit basis)
      legacy=(unit record-v1)
  ==
+$  ledger  (map @ux record)
+$  transition  [next=ledger record=record card=card:agent:gall]
+$  action
  $%  [%pataphor-editor-save change=change:model]
      [%pataphor-editor-save-observe nonce=@ux]
  ==
++  digest
  |=  value=*
  ^-  @ux
  `@ux`(shax (jam value))
++  support-valid
  |=  hashes=support
  ^-  ?
  ?&  =((silt `(list path)`[guard:demo support:demo]) ~(key by hashes))
      (levy ~(val by hashes) |=(hash=@uv !=(0 hash)))
  ==
++  basis-valid
  |=  b=basis
  ^-  ?
  ?&  (snapshot-valid:model current.b)
      (support-valid support.b)
      =(%pataphor-demo-work selected.current.b)
      =(target:demo pax.current.b)
      ?=(%text -.body.current.b)
      !=(0 parent.b)
  ==
++  permission
  ::  The authenticated owner's exact change is explicit ratification.
  ::  Ratification never overrides a block or grants a different act.
  |=  w=window:law
  ^-  ?
  &((~(has in admissible.w) %inscribe) !(~(has in blocked.w) %inscribe))
++  judge
  |=  [our=@p actor=@p at=@da change=change:model b=basis w=window:law]
  ^-  (each admission @tas)
  ?.  =(our actor)  [%| %foreign-actor]
  ?.  (basis-valid b)  [%| %basis-invalid]
  =/  compared  (compare-change:model our actor at change current.b)
  ?:  ?=(%| -.compared)  [%| p.compared]
  ?.  (permission w)  [%| %inscribe-blocked]
  ?.  ?=(%text -.body.current.b)  [%| %basis-invalid]
  ?:  =(replacement.change source.body.current.b)  [%| %source-unchanged]
  [%& [%cantrip-editor-save-admission-v1 change b w at]]
++  admission-valid
  |=  a=admission
  ^-  ?
  =/  checked  (judge owner.change.a owner.change.a at.a change.a basis.a window.a)
  &(?=(%& -.checked) =(p.checked a))
++  confirmed
  |=  [a=admission o=observation]
  ^-  ?
  ?.  &((admission-valid a) (snapshot-valid:model current.o))  %.n
  ?~  commit.o  %.n
  =/  before=snapshot:model  current.basis.a
  =/  after=snapshot:model  current.o
  ?.  ?=(%text -.body.after)  %.n
  ?&  (gth at.after at.a)
      =(owner.before owner.after)
      =(selected.before selected.after)
      =(pax.before pax.after)
      =(base.before base.after)
      =(desk.work.before desk.work.after)
      =(+(number.work.before) number.work.after)
      !=(root.work.before root.work.after)
      =(replacement.change.a source.body.after)
      =(support.basis.a support.o)
      (support-valid support.o)
      !=(0 id.u.commit.o)
      =(~[parent.basis.a] parents.u.commit.o)
      =(at.a at.u.commit.o)
  ==
++  record-v1-valid
  |=  r=record-v1
  ^-  ?
  ?.  (admission-valid admission.r)  %.n
  ?-  status.r
    %submitted  =(~ observation.r)
    %unknown    ?~(observation.r %.n !(confirmed admission.r u.observation.r))
    %applied    ?~(observation.r %.n (confirmed admission.r u.observation.r))
  ==
++  upgrade
  ::  Preserve the exact old receipt, including its observation semantics.
  |=  old=record-v1
  ^-  record
  ?>  (record-v1-valid old)
  [%cantrip-editor-save-record-v2 admission.old status.old observation.old ~ ~ `old]
++  upgrade-ledger
  |=  old=ledger-v1
  ^-  ledger
  (~(run by old) upgrade)
++  historical-confirmed
  ::  This is evidence about one PINNED work commit, not today's project.
  |=  [a=admission h=historical]
  ^-  ?
  ?.  (admission-valid a)  %.n
  ?.  ?=(%text -.body.h)  %.n
  =/  before=snapshot:model  current.basis.a
  ?&  =(owner.change.a owner.h)
      (gth at.h at.a)
      (revision-valid:model work.h)
      =(desk.work.before desk.work.h)
      =(+(number.work.before) number.work.h)
      !=(root.work.before root.work.h)
      =(target:demo pax.h)
      !=(0 blob.h)
      =(blob.h (source-blob source.body.h))
      =(replacement.change.a source.body.h)
      =(hash.body.h (shax source.body.h))
      =(support.basis.a support.h)
      (support-valid support.h)
      =(files.h (silt `(list path)`[target:demo guard:demo support:demo]))
      !=(0 id.commit.h)
      =(~[parent.basis.a] parents.commit.h)
      =(at.a at.commit.h)
  ==
++  source-blob
  ::  Clay %cz for one file: the committed page's lobe, folded at its root.
  |=  source=@t
  ^-  @uv
  `@uv`(shax (jam [[~ (page-to-lobe:clay [%hoon source])] `@uv`0]))
++  fence-valid
  ::  A later canonical read establishes that the synchronous %info event
  ::  has finished. It does not establish whether that write succeeded.
  |=  [a=admission b=basis]
  ^-  ?
  ?&  (basis-valid b)
      =(owner.change.a owner.current.b)
      (gth at.current.b at.a)
      (gte number.work.current.b number.work.current.basis.a)
  ==
++  record-valid
  |=  r=record
  ^-  ?
  ?.  (admission-valid admission.r)  %.n
  ?.  ?~(legacy.r %.y &((record-v1-valid u.legacy.r) =(admission.r admission.u.legacy.r)))
    %.n
  ?.  ?~(historical.r %.y (historical-confirmed admission.r u.historical.r))
    %.n
  ?.  ?~  fence.r  %.y
      ?~  observation.r  %.n
      ?&  (fence-valid admission.r u.fence.r)
          =(current.u.fence.r current.u.observation.r)
          =(support.u.fence.r support.u.observation.r)
      ==
    %.n
  ?-  status.r
    %submitted  &(=(~ observation.r) =(~ historical.r) =(~ fence.r))
    %unknown
      &(=(~ historical.r) (record-v1-valid [%cantrip-editor-save-record-v1 admission.r %unknown observation.r]))
    %applied
      |(?=(^ historical.r) (record-v1-valid [%cantrip-editor-save-record-v1 admission.r %applied observation.r]))
  ==
++  released
  |=  [r=record a=admission]
  ^-  ?
  ?:  =(%applied status.r)  %.y
  ?.  =(%unknown status.r)  %.n
  ?~  fence.r  %.n
  &((fence-valid admission.r u.fence.r) (gte at.current.basis.a at.current.u.fence.r))
++  ledger-valid
  |=  held=ledger
  ^-  ?
  ?&  (lte ~(wyt by held) 128)
      %+  levy  ~(tap by held)
      |=  [nonce=@ux r=record]
      &((record-valid r) =(nonce nonce.change.admission.r))
  ==
++  lookup
  ::  Read this before admission on retries: the original source is now stale.
  |=  [held=ledger change=change:model]
  ^-  (each (unit record) @tas)
  ?.  &((ledger-valid held) (change-valid:model change))  [%| %request-invalid]
  =/  prior  (~(get by held) nonce.change)
  ?~  prior  [%& ~]
  ?.  =(change change.admission.u.prior)  [%| %nonce-conflict]
  [%& prior]
++  reserve
  |=  [held=ledger a=admission our=@p now=@da]
  ^-  (each transition @tas)
  ?.  =(our owner.change.a)  [%| %foreign-actor]
  ?.  &(=(now at.a) (admission-valid a))  [%| %expired-admission]
  =/  prior  (lookup held change.a)
  ?:  ?=(%| -.prior)  [%| p.prior]
  ?^  p.prior  [%| %already-submitted]
  ?:  (lien ~(val by held) |=(r=record !(released r a)))
    [%| %save-unresolved]
  ?:  (gte ~(wyt by held) 128)  [%| %capacity]
  =/  key=@ux  nonce.change.a
  =/  r=record  [%cantrip-editor-save-record-v2 a %submitted ~ ~ ~ ~]
  =/  c=card:agent:gall
    [%pass /editor-save/(scot %ux key) %arvo %c [%info work:demo %.y ~[[target:demo %mut %hoon !>(replacement.change.a)]]]]
  [%& [(~(put by held) key r) r c]]
++  observe
  ::  Observation never returns a write card. Applied history is immutable.
  |=  [r=record o=recovery]
  ^-  record
  ?:  =(%applied status.r)  r
  ?.  (fence-valid admission.r current.o)  r
  =/  proven=(unit historical)
    ?~  historical.o  ~
    ?.  (historical-confirmed admission.r u.historical.o)  ~
    historical.o
  =/  seen=observation
    [current.current.o support.current.o ?~(proven ~ `commit.u.proven)]
  r(status ?~(proven %unknown %applied), observation `seen, historical proven, fence `current.o)
++  fact
  |=  r=record
  [%cantrip-editor-save-record (scot %ux (digest r)) r]
--
