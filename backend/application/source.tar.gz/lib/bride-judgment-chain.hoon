::  /lib/bride-judgment-chain.hoon
::
::  Content-addressed continuity for Viki/Bride's sovereign judgments.  Viki
::  retains one authenticated head, not an ever-growing list.  Each
::  head commits the typed candidate's SHA-256 identity, the Bride decision,
::  the trusted ship/app checkpoint, and the prior head.  Append therefore has
::  constant work and constant retained state while preserving continuity.
::
/+  bj=bride-judgment
|%
+$  digest  @ux
+$  authority
  $:  ship=@p
      app=@tas
      checkpoint=@ux
  ==
+$  entry
  $:  judgment=bound-judgment:bj
      authority=authority
      previous=(unit digest)
      digest=digest
  ==
+$  chain
  $:  count=@ud
      head=(unit digest)
      latest=(unit entry)
  ==
::
++  init
  ^-  chain
  [0 ~ ~]
::
++  checkpoint-for
  |=  ship=@p
  ^-  digest
  (shax (jam [%viki-bride-checkpoint-v1 ship %viki]))
::
::  Historical heads retain the checkpoint committed by the predecessor app.
++  predecessor-checkpoint-for
  |=  ship=@p
  ^-  digest
  (shax (jam [%viki-bride-checkpoint-v1 ship %viki-core]))
::
++  trusted-authority
  |=  ship=@p
  ^-  authority
  [ship %viki (checkpoint-for ship)]
::
++  valid-authority
  |=  auth=authority
  ^-  ?
  ?+  app.auth  %.n
    %viki
      =((checkpoint-for ship.auth) checkpoint.auth)
    %viki-core
      =((predecessor-checkpoint-for ship.auth) checkpoint.auth)
  ==
::
++  digest-for
  |=  $:  judgment=bound-judgment:bj
          authority=authority
          previous=(unit digest)
      ==
  ^-  digest
  (shax (jam [%viki-judgment-chain-v1 judgment authority previous]))
::
++  make-entry
  |=  $:  judgment=bound-judgment:bj
          authority=authority
          previous=(unit digest)
      ==
  ^-  entry
  =/  address=digest
    (digest-for judgment authority previous)
  [judgment authority previous address]
::
++  valid-entry
  |=  item=entry
  ^-  ?
  ?&  (valid-authority authority.item)
      !=(0 evidence-digest.judgment.item)
      =(digest.item (digest-for judgment.item authority.item previous.item))
  ==
::
::  Only the retained head is inspected.  Its digest already commits the
::  predecessor accumulator, so work does not grow with historical count.
++  valid
  |=  log=chain
  ^-  ?
  ?~  latest.log
    ?&  =(0 count.log)
        ?=(~ head.log)
    ==
  ?:  =(0 count.log)  %.n
  ?~  head.log  %.n
  ?&  =(u.head.log digest.u.latest.log)
      (valid-entry u.latest.log)
      ?:  =(1 count.log)
        ?=(~ previous.u.latest.log)
      ?=(^ previous.u.latest.log)
  ==
::
::  Invalid restored state or an untrusted checkpoint cannot receive another
::  sovereign judgment.  This is O(1): one header and one entry are checked.
++  append
  |=  $:  log=chain
          judgment=bound-judgment:bj
          authority=authority
      ==
  ^-  (unit chain)
  ?.  (valid log)  ~
  ?.  (valid-authority authority)  ~
  ?:  ?&  ?=(^ latest.log)
          =(judgment.u.latest.log judgment)
          =(authority.u.latest.log authority)
      ==
    `log
  =/  item=entry
    (make-entry judgment authority head.log)
  =/  next=chain
    [+(count.log) `digest.item `item]
  `next
--
