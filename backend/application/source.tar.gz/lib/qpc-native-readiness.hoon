:: Pure prospective readiness semantics: no cards, scries, effects or reports.
:: +arm is NOT an owner command and +activate does NOT authenticate +ready.
:: A native owner must obtain typed canonical reads, authenticate the owner
:: intent/CLI receipt, and commit this ledger AND campaign activation in one
:: state transition before emitting any inference. Caller nouns prove no origin.
:: This admission is required before EVERY next inference, not just opening.
:: Refusal must leave the runtime waiting with no newly persisted pending request
:: or deadline/gap. This library does not implement that runtime integration.
/-  rs=qpc-native-readiness
|%
++  empty  ^-(state:rs [%qpc-native-readiness-v1 ~ ~ ~ ~])
++  digest  |=(v=* ^-(@ux (shax (jam [%qpc-native-readiness-v1 v]))))
++  identifier  |=(v=@ux &(!=(0 v) (lte (met 0 v) 256)))
++  intent-valid
  |=  i=intent:rs
  ^-  ?
  ?&  (levy `(list @ux)`~[id.i campaign.i task.i handoff.i member.i source.i grant.i executor.i request.i] identifier)
      !=(%$ connector.i)
      (lth turn.i 32)
  ==
++  terminal
  |=  q=queue:rs
  ^-  ?
  (levy ~(val by q) |=(j=job:rs &(?=(?(%completed %failed %cancelled) phase.j) (identifier fingerprint.j))))
++  preserved
  :: A once-observed terminal row remains exact, including its full DATA hash.
  |=  [s=state:rs q=queue:rs]
  ^-  ?
  %+  levy  ~(tap by settled.s)
  |=  [id=@ux j=job:rs]
  =(`j (~(get by q) id))
++  previous-settled
  :: A Viki decision may precede CLI enqueue. Missing is unresolved, not idle.
  :: Runtime must also persist its own pending state atomically with admission.
  |=  [s=state:rs campaign=@ux q=queue:rs]
  ^-  ?
  =/  prior=(list record:rs)
    (skim ~(val by intents.s) |=(v=record:rs &(=(campaign campaign.intent.v) =(%activated phase.v))))
  %+  levy  prior
  |=  v=record:rs
  =/  found  (~(get by q) request.intent.v)
  ?~  found  %.n
  ?=(?(%completed %failed %cancelled) phase.u.found)
++  usage
  :: Sum retained windows, including current waiting time; never reset budget.
  |=  [s=state:rs campaign=@ux at=@da]
  ^-  (unit [elapsed=@dr turns=@ud])
  =/  rows=(list window:rs)
    (skim ~(val by windows.s) |=(w=window:rs =(campaign campaign.w)))
  =/  elapsed=@dr  ~s0
  =/  turns=@ud  0
  |-  ^-  (unit [elapsed=@dr turns=@ud])
  ?~  rows  `[elapsed turns]
  =/  w=window:rs  i.rows
  =/  end=@da  (fall stop.w at)
  ?.  &((lte start.w end) (lte end at))  ~
  $(rows t.rows, elapsed (add elapsed (sub end start.w)), turns (add turns turns.w))
++  arm
  :: Runtime-only owner admission must precede this pure transition.
  |=  [s=state:rs i=intent:rs]
  ^-  (each state:rs @tas)
  ?.  (intent-valid i)  [%| %readiness-intent-invalid]
  =/  old  (~(get by intents.s) id.i)
  ?^  old
    ?:(=(i intent.u.old) [%& s] [%| %readiness-intent-conflict])
  ?:  (gte ~(wyt by intents.s) 512)  [%| %readiness-intent-capacity]
  ?:  (lien ~(val by intents.s) |=(v=record:rs =(request.i request.intent.v)))
    [%| %readiness-request-retained]
  [%& s(intents (~(put by intents.s) id.i [i %prepared ~]))]
++  open-window
  :: The runtime binds start to actual finite-worker admission. Prepared wait
  :: before this transition does not consume a request or start its deadline.
  :: Generation comes from the authenticated current native pairing, not a
  :: caller integer. A clean new window does not alter the armed owner intent.
  |=  [s=state:rs id=@ux campaign=@ux connector=@tas generation=@ud at=@da]
  ^-  (each state:rs @tas)
  ?.  &((identifier id) (identifier campaign) !=(%$ connector) (gth generation 0) (lte generation 0xffff.ffff))
    [%| %readiness-window-invalid]
  ?:  (~(has by windows.s) id)  [%| %readiness-window-retained]
  ?:  (gte ~(wyt by windows.s) 512)  [%| %readiness-window-capacity]
  ?:  (lien ~(val by windows.s) |=(w=window:rs &(|(=(campaign campaign.w) =(connector connector.w)) !=(%closed phase.w))))
    [%| %readiness-window-unsettled]
  =/  used  (usage s campaign at)
  ?~  used  [%| %readiness-window-time]
  ?.  &((lte (add elapsed.u.used ~m10) ~m30) (lth turns.u.used 32))
    [%| %readiness-budget]
  [%& s(windows (~(put by windows.s) id [id campaign connector generation at ~ %open 0]))]
++  close-window
  :: Runtime must independently prove normal/reaped adapter exit AND canonical
  :: terminal jobs and actual model-turn usage. This pure gate cannot certify
  :: evidence origin; runtime must enforce budgets on every model dispatch.
  |=  [s=state:rs id=@ux at=@da turns=@ud q=queue:rs]
  ^-  (each state:rs @tas)
  =/  found  (~(get by windows.s) id)
  ?~  found  [%| %readiness-window-missing]
  =/  w=window:rs  u.found
  ?.  &(=(%open phase.w) ?=(~ stop.w) (lte start.w at) (terminal q))
    [%| %readiness-window-unsettled]
  =/  owned=(list record:rs)
    (skim ~(val by intents.s) |=(v=record:rs ?~(activation.v %.n =(id window.u.activation.v))))
  ?.  (levy owned |=(v=record:rs (~(has by q) request.intent.v)))
    [%| %readiness-job-missing]
  ?.  (preserved s q)  [%| %readiness-retained-job-changed]
  =/  used  (usage s campaign.w at)
  ?~  used  [%| %readiness-window-time]
  ?.  &((gte turns turns.w) (lte (add (sub turns.u.used turns.w) turns) 32))
    [%| %readiness-budget]
  [%& s(windows (~(put by windows.s) id w(stop `at, phase %closed, turns turns)), settled q)]
++  stop-window
  :: Unknown/revoked is retained and blocks a new window. No implicit close.
  |=  [s=state:rs id=@ux phase=?(%unknown %revoked)]
  ^-  state:rs
  =/  found  (~(get by windows.s) id)
  ?~  found  s
  ?.  =(%open phase.u.found)  s
  s(windows (~(put by windows.s) id u.found(phase phase)))
++  revoke
  :: Revokes this owner intent only, not standing session/grant authority.
  |=  [s=state:rs id=@ux]
  ^-  state:rs
  =/  found  (~(get by intents.s) id)
  ?~  found  s
  ?.  =(%prepared phase.u.found)  s
  s(intents (~(put by intents.s) id u.found(phase %revoked)))
++  activate
  :: +fresh must come from the runtime's fresh source/grant/handoff reader;
  :: +ready from authenticated canonical CLI state, +q from complete job DATA.
  :: Readiness binds the current pairing incarnation and complete current queue.
  :: These execution conditions are not frozen into the owner task's authority.
  :: No boolean parameter can pretend those reads have been authenticated.
  :: Consume at the actual inference dispatch event, not an earlier opening
  :: event that schedules a one-second wake. That later event must re-read and
  :: admit its own exact request with current time before creating pending DATA.
  |=  [s=state:rs at=@da fresh=intent:rs ready=ready:rs q=queue:rs]
  ^-  (each change:rs @tas)
  =/  found  (~(get by intents.s) intent.ready)
  ?~  found  [%| %readiness-intent-missing]
  =/  r=record:rs  u.found
  ?.  &(=(fresh intent.r) (intent-valid fresh))
    [%| %readiness-fresh-binding]
  =/  token=nonce:rs  [connector.ready generation.ready nonce.ready]
  ?:  =(%activated phase.r)
    ?~  activation.r  [%| %readiness-activation-invalid]
    ?.  &((~(has in consumed.s) token) =((digest ready) readiness.u.activation.r))
      [%| %readiness-replay-conflict]
    [%& [s ~]]
  ?.  =(%prepared phase.r)  [%| %readiness-intent-revoked]
  ?.  ?&  (identifier nonce.ready)  (identifier window.ready)  (identifier queue.ready)
          =(connector.ready connector.fresh)
          (gth generation.ready 0)  (lte generation.ready 0xffff.ffff)
          (lte issued.ready at)  (lth at expires.ready)
          (lth issued.ready expires.ready)
          (lte (sub expires.ready issued.ready) ~s60)
      ==  [%| %readiness-receipt-invalid]
  ?:  (~(has in consumed.s) token)  [%| %readiness-nonce-consumed]
  =/  win  (~(get by windows.s) window.ready)
  ?~  win  [%| %readiness-window-missing]
  =/  w=window:rs  u.win
  ?.  ?&  =(campaign.fresh campaign.w)  =(%open phase.w)
          =(connector.ready connector.w)  =(generation.ready generation.w)
          ?=(~ stop.w)  (lte start.w issued.ready)
      ==  [%| %readiness-window-unsettled]
  ?.  (terminal q)  [%| %readiness-queue-unsettled]
  ?.  (previous-settled s campaign.fresh q)
    [%| %readiness-prior-request-unresolved]
  ?.  (preserved s q)  [%| %readiness-retained-job-changed]
  ?:  (~(has by q) request.fresh)  [%| %readiness-request-retained]
  ?.  =((digest q) queue.ready)  [%| %readiness-queue-changed]
  =/  used  (usage s campaign.fresh at)
  ?~  used  [%| %readiness-window-time]
  :: Conservative admission: the unchanged 600-second dispatch must fit wholly
  :: inside the remaining 1800-second campaign budget. No deadline extension.
  ?.  &((lte (add elapsed.u.used ~m10) ~m30) (lth turns.u.used 32))
    [%| %readiness-budget]
  =/  d=decision:rs
    [id.fresh (digest ready) id.w request.fresh at (add at ~m10) (digest q)]
  =.  s
    s(intents (~(put by intents.s) id.fresh r(phase %activated, activation `d)), windows (~(put by windows.s) id.w w(turns +(turns.w))), consumed (~(put in consumed.s) token), settled q)
  [%& [s `d]]
--
