::  Pure durable checks mechanics. Only the owning app supplies the ledger
::  and compilation journal. No imported outcome or admission is a command.
/-  cs=vibecoding-check-spec, itn=intent, vc=vibecoding-candidate
/+  connected=vibecoding-connected-preview, preview=vibecoding-local-preview,
    compiler=cantrip-connected-compile, compilation=cantrip-connected-compile-ledger,
    result=vibecoding-connected-result, image=vibecoding-local-image,
    protocol=vibecoding-compile-protocol, vcl=vibecoding-candidate,
    vcr=vibecoding-candidate-review,
    law=cantrip-law-window
|%
+$  command
  [%cantrip-connected-checks-run-v2 nonce=@ux write=@ux image=@ux input=sample:image]
+$  record
  [%cantrip-connected-checks-v2 request=command compilation=record-v2:compiler run=record:preview]
+$  ledger  (map @ux record)
+$  transition  [next=ledger record=record repeated=?]
+$  observation  [record=record fresh=? reason=(unit @tas)]
++  command-valid
  |=  c=command
  ^-  ?
  ?&  !=(0 nonce.c)  (lte (met 0 nonce.c) 128)
      !=(0 write.c)  (lte (met 0 write.c) 128)
      !=(0 image.c)  (lte (met 0 image.c) 256)
      (lte participants.input.c 1.000)  (lte minutes.input.c 1.000)
  ==
++  record-valid
  ::  Structural preservation, not proof of an imported record's origin.
  ::  Execution authority comes only from the app's own saved journal.
  |=  r=record
  ^-  ?
  ?.  &((command-valid request.r) (record-valid-v2:compiler compilation.r))  %.n
  =/  s=snapshot-v2:compiler  snapshot.compilation.r
  =/  run=record:preview  run.r
  =/  c=command  request.r
  =/  artifact=artifact:protocol  artifact.compilation.r
  =/  native=compiler:protocol  compiler.artifact
  =/  written  entry.receipt.s
  ?.  ?=(%submitted -.state.written)  %.n
  =/  candidate=candidate-v4:vc  candidate.body.review.body.intake.state.written
  ?.  ?=([%native-compiler-v2 *] -.compiler.run)  %.n
  =/  provenance  provenance.compiler.run
  =/  img=image:image
    [%vibecoding-local-image-v1 result.commitment.s source.order.s (file-hash:vcr source.order.s) compiler.run gate.artifact]
  ?&  (valid:preview run)  (valid:image img)
      (specification-matches-v2:image compiler.run packet.candidate)
      =(write.c nonce.commitment.s)  =(image.c image.run)
      =(image.run (digest:vcl img))  =(input.c input.actual.run)
      =(owner.order.s actor.run)  (gte at.run received.compilation.r)
      !=(0 law.run)
      =(result.commitment.s write.run)  =(source-hash.img source-hash.run)
      =(owner.provenance owner.order.s)
      =(request.provenance (digest:protocol order.s))
      =(compilation.provenance (digest:protocol compilation.r))
      =(candidate.provenance (digest:vcl candidate))
      =(intent.provenance (digest:vcl intent.commitment.s))
      =(beak.provenance beak.native)
      =([ship.compiler.run desk.compiler.run] [p.beak.native q.beak.native])
      =(0 revision.compiler.run)  =(root.compiler.run root.native)
      =(hoon.compiler.run `@uv`hoon.native)  =(zuse.compiler.run `@uv`zuse.native)
      =(at.compiler.run at.native)  =(500.000 fuel.actual.run)
  ==
++  valid
  |=  held=ledger
  ^-  ?
  ?&  (lte ~(wyt by held) 128)
      %+  levy  ~(tap by held)
      |=  [key=@ux r=record]
      &(=(key nonce.request.r) (record-valid r))
  ==
++  restore
  ::  Load validation only. No execution or cards, including failed runs.
  |=  [our=@p at=@da held=ledger]
  ^-  (each ledger @tas)
  ?.  (valid held)  [%| %ledger-invalid]
  ?.  (levy ~(val by held) |=(r=record &(=(our actor.run.r) (lte at.run.r at))))
    [%| %ledger-owner-or-time-invalid]
  [%& held]
++  lookup
  |=  [our=@p actor=@p at=@da held=ledger c=command]
  ^-  (each (unit record) @tas)
  ?.  =(our actor)  [%| %foreign-actor]
  ?.  (command-valid c)  [%| %command-invalid]
  =/  checked  (restore our at held)
  ?:  ?=(%| -.checked)  [%| p.checked]
  =/  prior  (~(get by held) nonce.c)
  ?~  prior  [%& ~]
  ?.  =(c request.u.prior)  [%| %nonce-conflict]
  ?.  &(=(our actor.run.u.prior) (lte at.run.u.prior at))
    [%| %record-binding-invalid]
  [%& prior]
++  start
  ::  Caller must atomically save next in its native event. There is no
  ::  async boundary, effect card, caller-selected fuel, or retry arm.
  |=  $:  our=@p  actor=@p  at=@da  held=ledger  c=command
          e=entry-v2:compilation  view=view-v2:result  rows=(list attested:cs)
          stated=(unit record:itn)  window=window:law
      ==
  ^-  (each transition @tas)
  =/  existing  (lookup our actor at held c)
  ?:  ?=(%| -.existing)  [%| p.existing]
  ?^  p.existing  [%& [held u.p.existing %.y]]
  ?:  (gte ~(wyt by held) 128)  [%| %capacity]
  ?.  =(write.c nonce.command.e)  [%| %write-mismatch]
  =/  admitted
    (judge-v2:connected our actor at image.c e view rows stated window)
  ?:  ?=(%| -.admitted)  [%| p.admitted]
  ?~  record.e  [%| %compilation-missing]
  =/  ran  (execute:connected p.admitted our at input.c)
  ?:  ?=(%| -.ran)  [%| p.ran]
  =/  r=record  [%cantrip-connected-checks-v2 c u.record.e p.ran]
  ?.  (record-valid r)  [%| %record-binding-invalid]
  [%& [(~(put by held) nonce.c r) r %.n]]
++  observe
  ::  No evaluation. Historical truth is returned even when today's source,
  ::  intent or law no longer permits approval of that original run.
  |=  [our=@p actor=@p at=@da held=ledger c=command current=decision:preview]
  ^-  (each observation @tas)
  =/  found  (lookup our actor at held c)
  ?:  ?=(%| -.found)  [%| p.found]
  ?~  p.found  [%| %checks-missing]
  =/  r=record  u.p.found
  ?:  ?=(%| -.current)  [%& [r %.n `p.current]]
  =/  a=admission:preview  p.current
  ?.  ?&  =(our actor.a)  =(at at.a)  (valid:image image.a)
          =(image.c (digest:vcl image.a))  =(write.run.r write.image.a)
      ==  [%& [r %.n `%current-binding-invalid]]
  ?.  =(law.run.r law.a)  [%& [r %.n `%law-changed]]
  [%& [r %.y ~]]
--
