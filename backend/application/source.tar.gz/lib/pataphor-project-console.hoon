::  Pure command adapter. The caller supplies Viki's canonical view; this
::  library owns no jobs, calls no provider and emits no mutation cards.
/-  pc=pataphor-project-coding
/+  coding=pataphor-project-coding, law=qpc-law-command
|%
+$  command
  $%  [%help ~]
      [%status key=(unit @ux)]
      [%develop text=@t]
      [%continue key=@ux text=@t]
      [%observe key=@ux]
      [%law cmd=command:law]
      [%ark key=(unit @ux)]
  ==
+$  action
  $%  [%text body=@t]
      [%request request=request:pc]
      [%observe key=@ux]
      [%law cmd=command:law]
      [%ark key=(unit @ux)]
  ==
++  max-line  4.160
++  help
  ^-  @t
  'Native project commands:\0ahelp\0aark [stream-id]\0astatus [0xnonce]\0adevelop <goal>\0acontinue <0xnonce> <goal>\0aobserve <0xnonce>\0alaw gain <instrument> <revision> <decimal gain> <reason>\0aGain is positive, at most 32, with up to six decimal places. Use ark to read saved law and measurement state. Goals use ASCII text. Viki owns execution; observe never resends a command.'
++  split
  |=  text=@t
  ^-  [head=@t tail=@t]
  =/  chars=tape  (trip text)
  =/  kept=tape  ~
  |-  ^-  [head=@t tail=@t]
  ?~  chars  [(crip (flop kept)) '']
  ?:  =(32 i.chars)  [(crip (flop kept)) (crip t.chars)]
  $(chars t.chars, kept [i.chars kept])
++  hex
  |=  text=@t
  ^-  (unit @ux)
  ?.  &((gte (met 3 text) 3) (lte (met 3 text) 41))  ~
  =/  value  (slaw %ux text)
  ?~  value  ~
  ?.  &(!=(0 u.value) (lte (met 0 u.value) 128))  ~
  ?.  =(text (scot %ux u.value))  ~
  `u.value
++  goal-valid
  |=  text=@t
  ^-  ?
  &((text-valid:coding text) (lien (trip text) |=(c=@t !=(32 c))))
++  law-id
  ::  Law identities are full SHA-256 values, unlike 128-bit request nonces.
  |=  text=@t
  ^-  (unit @ux)
  ?.  &((gte (met 3 text) 3) (lte (met 3 text) 81))  ~
  =/  value  (slaw %ux text)
  ?~  value  ~
  ?.  &(!=(0 u.value) (lte (met 0 u.value) 256))  ~
  ?.  =(text (scot %ux u.value))  ~
  `u.value
++  law-gain
  ::  Decimal text to exact millionths; no float, exponent or rounding.
  |=  text=@t
  ^-  (unit @ud)
  ?.  &((gth (met 3 text) 0) (lte (met 3 text) 9))  ~
  =/  chars=tape  (trip text)
  =/  point=?  %.n
  =/  whole=@ud  0
  =/  places=@ud  0
  =/  value=@ud  0
  |-  ^-  (unit @ud)
  ?~  chars
    ?.  &((gth whole 0) |(!point (gth places 0)))  ~
    |-  ^-  (unit @ud)
    ?:  (lth places 6)  $(places +(places), value (mul value 10))
    ?.  &((gth value 0) (lte value 32.000.000))  ~
    `value
  ?:  =(46 i.chars)
    ?.  &(!point (gth whole 0))  ~
    $(chars t.chars, point %.y)
  ?.  &((gte i.chars 48) (lte i.chars 57))  ~
  ?.  ?:(point (lth places 6) (lth whole 2))  ~
  $(chars t.chars, whole ?:(point whole +(whole)), places ?:(point +(places) places), value (add (mul value 10) (sub i.chars 48)))
++  parse-law
  |=  text=@t
  ^-  (each command @tas)
  =/  kind  (split text)
  ?.  =('gain' head.kind)  [%| %law-command-invalid]
  =/  target  (split tail.kind)
  =/  revision  (split tail.target)
  =/  parameter  (split tail.revision)
  =/  id  (law-id head.target)
  =/  expected  (law-id head.revision)
  ?~  id  [%| %law-instrument-invalid]
  ?~  expected  [%| %law-revision-invalid]
  =/  gain  (law-gain head.parameter)
  ?~  gain  [%| %law-gain-invalid]
  ?.  &((reason-valid:law tail.parameter) (lien (trip tail.parameter) |=(c=@t !=(32 c))))
    [%| %law-rationale-required]
  [%& [%law [%qpc-law-edit-v1 u.id u.expected [%gain u.gain] tail.parameter]]]
++  law-card
  ::  Returned data only. Viki authenticates the binding and expected revision.
  |=  [our=@p nonce=@ux cmd=command:law]
  ^-  card:agent:gall
  [%pass /glass-goal/(scot %ux nonce) %agent [our %viki] %poke %noun !>(cmd)]
++  parse
  |=  line=@t
  ^-  (each command @tas)
  ?.  &(!=('' line) (lte (met 3 line) max-line))  [%| %line-bound]
  ?.  (levy (trip line) |=(c=@t &((gte c 32) (lte c 126))))
    [%| %unsupported-text]
  ?:  =('help' line)  [%& [%help ~]]
  ?:  =('status' line)  [%& [%status ~]]
  ?:  =('ark' line)  [%& [%ark ~]]
  =/  words  (split line)
  ?:  =('ark' head.words)
    =/  key  (law-id tail.words)
    ?~  key  [%| %ark-stream-invalid]
    [%& [%ark `u.key]]
  ?:  =('law' head.words)  (parse-law tail.words)
  ?:  =('develop' head.words)
    ?.  (goal-valid tail.words)  [%| %goal-invalid]
    [%& [%develop tail.words]]
  ?:  =('continue' head.words)
    =/  rest  (split tail.words)
    =/  key  (hex head.rest)
    ?~  key  [%| %nonce-invalid]
    ?.  (goal-valid tail.rest)  [%| %goal-invalid]
    [%& [%continue u.key tail.rest]]
  ?:  |(=('status' head.words) =('observe' head.words))
    =/  key  (hex tail.words)
    ?~  key  [%| %nonce-invalid]
    ?:  =('status' head.words)  [%& [%status `u.key]]
    [%& [%observe u.key]]
  [%| %unknown-command]
++  lookup
  |=  [key=@ux rows=(list result:pc)]
  ^-  (unit result:pc)
  ?~  rows  ~
  ?:  =(key nonce.request.i.rows)  `i.rows
  $(rows t.rows)
++  summary
  ::  Never include goal, source, check detail or provider output in a TTY.
  ::  Phase is a closed mold; request nonce is bounded by result-valid.
  |=  r=result:pc
  ^-  @t
  ?.  (result-valid:coding r)  'Invalid project result.'
  =/  reason=@t
    ?~  reason.r  ''
    =/  text=@t  `@t`(end [3 80] u.reason.r)
    (cat 3 ' reason=' (crip (turn (trip text) |=(c=@tD ^-(@tD ?:(|((lth c 32) (gth c 126)) '?' c))))))
  %+  rap  3
  :~  (scot %ux nonce.request.r)  ' '  (scot %tas phase.r)
      ' edits='  (scot %ud (lent edits.r))
      ' checks='  (scot %ud (lent checks.r))  reason  '\0a'
  ==
++  prepare
  ::  expected binds the manifest the command was submitted against.
  ::  Continue names an old request; coding binds its exact saved result.
  |=  $:  our=@p  actor=@p  nonce=@ux  expected=@ux
          cmd=command  view=view:pc
      ==
  ^-  (each action @tas)
  ?.  =(our actor)  [%| %foreign-owner]
  ?:  ?=(%help -.cmd)  [%& [%text help]]
  ?.  &(=(our owner.view) (view-valid:coding view))
    [%| %project-view-invalid]
  ::  The law's expected revision is its own basis. Its canonical instrument
  ::  and authority are resolved by Viki, not the coding manifest.
  ?:  ?=(%law -.cmd)  [%& [%law cmd.cmd]]
  ?:  ?=(%ark -.cmd)  [%& [%ark key.cmd]]
  ?:  ?=(%status -.cmd)
    ?~  key.cmd
      =/  body=@t
        ?~  results.view  'No project requests.\0a'
        (rap 3 (turn results.view summary))
      [%& [%text body]]
    =/  found  (lookup u.key.cmd results.view)
    ?~  found  [%| %request-missing]
    [%& [%text (summary u.found)]]
  ?:  ?=(%observe -.cmd)
    ?~  (lookup key.cmd results.view)  [%| %request-missing]
    [%& [%observe key.cmd]]
  ?~  manifest.view  [%| %project-basis-unavailable]
  ?.  =(expected (manifest-id:coding u.manifest.view))
    [%| %project-basis-changed]
  ?^  (lookup nonce results.view)  [%| %request-already-retained]
  =/  prior=(unit result:pc)
    ?:  ?=(%develop -.cmd)  ~
    ?>  ?=(%continue -.cmd)
    (lookup key.cmd results.view)
  ?:  &(?=(%continue -.cmd) ?=(~ prior))  [%| %prior-result-missing]
  =/  text=@t
    ?:  ?=(%develop -.cmd)  text.cmd
    ?>  ?=(%continue -.cmd)
    text.cmd
  ?.  (goal-valid text)  [%| %goal-invalid]
  =/  ready  (prepare-request:coding our actor nonce u.manifest.view prior text)
  ?:  ?=(%| -.ready)  [%| p.ready]
  [%& [%request p.ready]]
--
