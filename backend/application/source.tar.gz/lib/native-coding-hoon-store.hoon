::  One private Clay archive writer sharing the existing GLS cache config.
::  Caller persists state/cache/artifacts together before emitting cards.
::  Full vases stay in the artifact organ until explicit confirmed retirement.
/-  nc=native-coding
/+  hoon=native-coding-hoon-artifact, cache=native-coding-compiler-store,
    tools=cantrip-native-coding, project=native-coding-project,
    dsr=desk-shell-read
|%
+$  reference
  [job=@ux artifact=@ux product=@ux input=@ux source=revision:nc scope=@ux]
+$  entry
  [ref=reference before=revision:nc before-tree=@ux expected-tree=@ux pax=path blob=lobe:clay phase=?(%submitted %confirmed %unknown) saved=(unit revision:nc) retired=? reason=@tas]
+$  organ  [%native-coding-hoon-store-v1 records=(map @ux entry)]
+$  change
  [state=organ cache=organ:cache artifacts=organ:hoon cards=(list card:agent:gall)]
+$  command
  $%  [%native-coding-hoon-store-v1 id=@ux]
      [%native-coding-hoon-store-observe-v1 id=@ux]
      [%native-coding-hoon-artifact-retire-v1 id=@ux]
  ==
++  empty  `organ`[%native-coding-hoon-store-v1 ~]
++  capacity  128
++  reference-of
  |=  a=artifact:hoon
  ^-  reference
  [(key:tools request.input.a) digest.a product.a (shax (jam input.a)) revision.input.a scope.a]
++  path-for
  |=  r=reference
  ^-  path
  /native-coding/hoon/(scot %ux artifact.r)/noun
++  wire-for
  |=  id=@ux
  ^-  wire
  /native-hoon-store/(scot %ux id)
++  ready
  |=  s=organ
  ^-  ?
  !(lien ~(val by records.s) |=(e=entry !=(%confirmed phase.e)))
++  linked
  ::  Historical revocation never erases a lawful earlier artifact.
  |=  [jobs=organ:tools r=reference a=artifact:hoon]
  ^-  ?
  ?.  &((artifact-valid:hoon job.r a) =(r (reference-of a)))  %.n
  =/  j  (~(get by records.jobs) job.r)
  ?~  j  %.n
  ?.  =(request.input.a request.u.j)  %.n
  =/  scope  (~(get by grants.jobs) grant.u.j)
  ?~  scope  %.n
  &(=(project.input.a project.grant.u.scope) =(scope.a (scope-digest:hoon u.scope(revoked ~))))
++  exact
  ::  Re-read both numbered namespaces, the exact parent and complete noun.
  ::  The compact journal commits to the before-image; it does not duplicate
  ::  the vase or file map. Clay retains their immutable numbered history.
  |=  [our=@p now=@da e=entry jobs=organ:tools]
  ^-  (each artifact:hoon @tas)
  ?~  saved.e  [%| %hoon-archive-not-observed]
  =/  before  (at:cache our now desk.before.e number.before.e)
  ?~  before  [%| %hoon-archive-before-unavailable]
  ?.  &(=(before.e revision.u.before) =(before-tree.e (shax (jam files.u.before))) !(~(has by files.u.before) pax.e))
    [%| %hoon-archive-before-mismatch]
  =/  location=revision:nc  u.saved.e
  ?.  &(=(our owner.location) =(desk.before.e desk.location) =(+(number.before.e) number.location))
    [%| %hoon-archive-revision-mismatch]
  =/  actual  (at:cache our now desk.location number.location)
  ?~  actual  [%| %hoon-archive-unavailable]
  =/  expected=(map path lobe:clay)  (~(put by files.u.before) pax.e blob.e)
  ?.  ?&  =(location revision.u.actual)  =(expected files.u.actual)
          =(expected-tree.e (shax (jam expected)))
          =(parents.u.actual ~[commit.before.e])
      ==
    [%| %hoon-archive-tree-mismatch]
  =/  raw=*
    .^(* %cx (beam-at:dsr our desk.location (scot %ud number.location) pax.e))
  =/  parsed  ((soft artifact:hoon) raw)
  ?~  parsed  [%| %hoon-archive-page-invalid]
  ?.  &(=(u.parsed raw) (linked jobs ref.e u.parsed) =(blob.e (page-to-lobe:clay [%noun u.parsed])))
    [%| %hoon-archive-artifact-mismatch]
  [%& u.parsed]
++  put
  |=  [s=organ shared=organ:cache artifacts=organ:hoon e=entry cards=(list card:agent:gall)]
  ^-  change
  [s(records (~(put by records.s) job.ref.e e)) shared artifacts cards]
++  observe
  |=  [b=bowl:gall s=organ shared=organ:cache artifacts=organ:hoon jobs=organ:tools id=@ux]
  ^-  change
  =/  found  (~(get by records.s) id)
  ?~  found  [s shared artifacts ~]
  =/  e=entry  u.found
  ?:  =(%confirmed phase.e)  [s shared artifacts ~]
  =/  unknown
    |=  reason=@tas
    (put s shared artifacts e(phase %unknown, reason reason) ~)
  ?~  config.shared  (unknown %hoon-archive-config-missing)
  ?.  &(=(current.u.config.shared before.e) (ready:cache shared))
    (unknown %hoon-archive-shared-revision-conflict)
  =/  current  (current:cache our.b now.b desk.before.e)
  ?~  current  (unknown %hoon-archive-desk-unavailable)
  ?:  =(revision.u.current before.e)
    (put s shared artifacts e(reason %hoon-archive-unconfirmed) ~)
  ?.  =(number.revision.u.current +(number.before.e))
    (unknown %hoon-archive-revision-conflict)
  =/  candidate=entry  e(saved `revision.u.current)
  =/  checked  (exact our.b now.b candidate jobs)
  ?:  ?=(%| -.checked)  (unknown p.checked)
  ::  Only confirmation advances the SINGLE shared cache current revision.
  =.  shared  shared(config `u.config.shared(current revision.u.current))
  (put s shared artifacts candidate(phase %confirmed, reason %hoon-archive-confirmed) ~)
++  act
  |=  [b=bowl:gall s=organ shared=organ:cache artifacts=organ:hoon jobs=organ:tools c=command idle=?]
  ^-  (each change @tas)
  ?.  =(our.b src.b)  [%| %hoon-archive-owner-required]
  ?:  ?=(%native-coding-hoon-store-observe-v1 -.c)
    [%& (observe b s shared artifacts jobs id.c)]
  =/  held  (~(get by records.s) id.c)
  ?:  ?=(%native-coding-hoon-artifact-retire-v1 -.c)
    ?~  held  [%| %hoon-archive-missing]
    ?.  =(%confirmed phase.u.held)  [%| %hoon-archive-not-confirmed]
    =/  checked  (exact our.b now.b u.held jobs)
    ?:  ?=(%| -.checked)  [%| p.checked]
    =/  retained  (get:hoon artifacts id.c)
    ?:  retired.u.held
      ?^  retained  [%| %hoon-archive-retirement-conflict]
      [%& [s shared artifacts ~]]
    ?~  retained  [%| %hoon-archive-retained-missing]
    ?.  =(u.retained p.checked)  [%| %hoon-archive-retained-mismatch]
    =/  job  (~(get by records.jobs) id.c)
    ?~  job  [%| %hoon-archive-job-missing]
    ?:  =(%running stage.u.job)  [%| %hoon-archive-job-still-running]
    =.  artifacts  artifacts(records (~(del by records.artifacts) id.c))
    [%& (put s shared artifacts u.held(retired %.y, reason %hoon-artifact-retired) ~)]
  ?^  held  [%& [s shared artifacts ~]]
  ?.  &(idle (ready s) (ready:cache shared))  [%| %hoon-archive-writer-busy]
  ?:  (gte ~(wyt by records.s) capacity)  [%| %hoon-archive-capacity]
  ?~  config.shared  [%| %hoon-archive-config-missing]
  ?.  enabled.u.config.shared  [%| %hoon-archive-disabled]
  =/  retained  (get:hoon artifacts id.c)
  ?~  retained  [%| %hoon-archive-artifact-missing]
  =/  a=artifact:hoon  u.retained
  =/  ref=reference  (reference-of a)
  ?.  (linked jobs ref a)  [%| %hoon-archive-evidence-invalid]
  =/  location=revision:nc  current.u.config.shared
  ?.  &(=(our.b owner.location) (project-free:cache our.b now.b desk.location))
    [%| %hoon-archive-desk-refused]
  =/  before  (current:cache our.b now.b desk.location)
  ?~  before  [%| %hoon-archive-desk-unavailable]
  ?.  &(=(location revision.u.before) (lth ~(wyt by files.u.before) 4.096))
    [%| %hoon-archive-current-mismatch]
  =/  pax=path  (path-for ref)
  ?:  (~(has by files.u.before) pax)  [%| %hoon-archive-path-exists]
  =/  blob=lobe:clay  (page-to-lobe:clay [%noun a])
  =/  expected=(map path lobe:clay)  (~(put by files.u.before) pax blob)
  =/  e=entry
    [ref location (shax (jam files.u.before)) (shax (jam expected)) pax blob %submitted ~ %.n %hoon-archive-submitted]
  ::  This is the only %info site. Reload, observe and retire never resend it.
  [%& (put s shared artifacts e ~[[%pass (wire-for id.c) %arvo %c %info desk.location [%& [[pax %ins %noun !>(a)] ~]]] [%pass (wire-for id.c) %arvo %c %warp our.b desk.location ~ %sing %z [%ud +(number.location)] /]])]
++  arvo
  |=  [b=bowl:gall s=organ shared=organ:cache artifacts=organ:hoon jobs=organ:tools w=wire sign=sign-arvo]
  ^-  change
  ?.  &(=(our.b src.b) ?=([%native-hoon-store @ ~] w) ?=([%clay %writ *] sign))
    [s shared artifacts ~]
  =/  id  (slaw %ux i.t.w)
  ?~  id  [s shared artifacts ~]
  ?.  =(w (wire-for u.id))  [s shared artifacts ~]
  (observe b s shared artifacts jobs u.id)
++  valid
  ::  Static restoration only. Canonical archive reads happen on observation,
  ::  retrieval and retirement, never through a load-time retry or write.
  |=  [our=@p s=organ shared=organ:cache artifacts=organ:hoon jobs=organ:tools]
  ^-  ?
  ?.  (lte ~(wyt by records.s) capacity)  %.n
  ?~  config.shared  ?=(~ records.s)
  ?.  (lte (lent (skim ~(val by records.s) |=(e=entry !=(%confirmed phase.e)))) 1)
    %.n
  ?.  |((ready s) (ready:cache shared))  %.n
  %+  levy  ~(tap by records.s)
  |=  [id=@ux e=entry]
  ?.  ?&  =(id job.ref.e)  (identifier:tools id)
          (identifier:tools artifact.ref.e)  (lte (met 0 product.ref.e) 256)
          (lte (met 0 input.ref.e) 256)  (lte (met 0 scope.ref.e) 256)
          (lte (met 0 before-tree.e) 256)  (lte (met 0 expected-tree.e) 256)
          (lte (met 0 blob.e) 256)  (lte (met 3 reason.e) 128)
          =(pax.e (path-for ref.e))  (revision-valid:project before.e)
          (revision-valid:project source.ref.e)  =(our owner.before.e)
          =(desk.before.e desk.current.u.config.shared)
          (gte number.before.e number.origin.u.config.shared)
      ==
    %.n
  =/  job  (~(get by records.jobs) id)
  ?~  job  %.n
  ?.  =(source.ref.e source.context.request.u.job)  %.n
  =/  scope  (~(get by grants.jobs) grant.u.job)
  ?~  scope  %.n
  =/  context=context:nc  context.request.u.job
  =/  p=project:nc  project.grant.u.scope
  ?.  ?&  =(scope.ref.e (scope-digest:hoon u.scope(revoked ~)))
          =(configuration.context (configuration:project p))
          =(project.context id.spec.p)  =(actor.context actor.grant.u.scope)
          =(session.context session.grant.u.scope)
          =(our owner.source.ref.e)  =(our authority.spec.p)
      ==
    %.n
  ?.  ?:  =(%confirmed phase.e)
        ?~  saved.e  %.n
        &((revision-valid:project u.saved.e) =(our owner.u.saved.e) =(desk.before.e desk.u.saved.e) =(+(number.before.e) number.u.saved.e) (lte number.u.saved.e number.current.u.config.shared))
      &(?=(~ saved.e) !retired.e =(before.e current.u.config.shared))
    %.n
  =/  retained  (get:hoon artifacts id)
  ?:  retired.e  ?=(~ retained)
  ?~  retained  %.n
  &((linked jobs ref.e u.retained) =(blob.e (page-to-lobe:clay [%noun u.retained])))
--
