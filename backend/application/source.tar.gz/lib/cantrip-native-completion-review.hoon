::  Cantrip admits an exact queued AI completion review, never a source write.
::  Viki supplies canonical captured worker provenance; current source, scope
::  and native evidence are rejoined before admission. Reload emits no effects.
/-  protocol=native-coding-completion-review, bx=boxy, jm=juggler-match
/+  request=native-coding-completion-review-request,
    worker=native-coding-completion-review-worker,
    completion=native-coding-completion, tools=cantrip-native-coding,
    boxy=boxy-law, match=boxy-match, juggler=juggler-match, guard=viki-scry-guard
|%
+$  key  [campaign=@ux request=@ux]
+$  retained
  [context=context:protocol verdict=verdict:protocol queued=workspace-state:bx grant=scope:tools]
+$  ledger  (map key retained)
+$  change  [next=ledger cards=(list card:agent:gall)]
++  capacity  256
++  row-limit  1.048.576
++  identity
  |=  ctx=context:protocol
  ^-  @ux
  (digest:request ctx)
++  config
  |=  ctx=context:protocol
  ^-  config:request
  ?:(=(worker.ctx ship.left.scope.ctx) config.left.scope.ctx config.right.scope.ctx)
++  scope-valid
  |=  [our=@p ctx=context:protocol]
  ^-  ?
  =/  s=scope:protocol  scope.ctx
  ::  Both reviewer configurations must belong to this owner; config-valid
  ::  also requires each reviewer to be that owner's moon.
  ?&  (identifier:completion campaign.ctx)  enabled.s
      (text-valid:completion project.s 128)
      =(project.s project.proposal.packet.request.ctx)
      !=(ship.left.s ship.right.s)
      =(our parent.config.left.s)  =(our parent.config.right.s)
      (config-valid:request ship.left.s config.left.s)
      (config-valid:request ship.right.s config.right.s)
      |(=(worker.ctx ship.left.s) =(worker.ctx ship.right.s))
  ==
++  grant-valid
  |=  [our=@p ctx=context:protocol g=scope:tools]
  ^-  ?
  =/  p=packet:request  packet.request.ctx
  ?&  ?=(~ revoked.g)  (grant-valid:tools our grant.g)
      =(id.grant.g grant.proposal.p)  =(project.grant.g project.p)
      =(session.grant.g session.proposal.p)  =(actor.grant.g our)
      =(`g (~(get by grants.tools.p) grant.proposal.p))
  ==
++  packet-current
  ::  Hash agreement alone is not this current-state join. Compare the exact
  ::  minimal retained records and grants against Cantrip's actual organ.
  |=  [p=packet:request held=organ:tools]
  ^-  ?
  ?&  (levy ~(tap by records.tools.p) |=([id=@ux r=record:tools] =(`r (~(get by records.held) id))))
      (levy ~(tap by grants.tools.p) |=([id=@ux g=scope:tools] =(`g (~(get by grants.held) id))))
  ==
++  refusal
  ::  Pure checks over the exact frozen request and one subsequent Boxy queue
  ::  event. Caller separately authenticates Viki/current proposal and scope.
  |=  [our=@p ctx=context:protocol w=workspace-state:bx]
  ^-  (unit @tas)
  ?.  (scope-valid our ctx)  `%completion-review-scope-invalid
  =/  c=config:request  (config ctx)
  =/  r=request:request  request.ctx
  =/  e=event:worker  result.ctx
  =/  prepared  (inference:request worker.ctx c r)
  ?.  ?&  ?=(%& -.prepared)  =(id.r id.e)
          =((digest:request r) request.e)  =((digest:request c) binding.e)
          =(generation.c generation.e)  =(%submitted phase.e)
          (identifier:completion receipt.e)  ?=(^ contribution.e)
      ==  `%completion-review-evidence-invalid
  ?>  ?=(^ contribution.e)
  ?.  (contribution-valid:request c r u.contribution.e receipt.e)
    `%completion-review-contribution-invalid
  =/  previous  (project-workspace:match workspace.r)
  ?~  config.match.previous  `%completion-review-match-missing
  =/  cfg=match-config:jm  u.config.match.previous
  ?.  ?&  =(ship.left.scope.ctx ship.left.cfg)  =(ship.right.scope.ctx ship.right.cfg)
          =((label:request ship.left.scope.ctx model.selection.config.left.scope.ctx) human.left.cfg)
          =((label:request ship.right.scope.ctx model.selection.config.right.scope.ctx) human.right.cfg)
          (event-chain-valid:boxy w)  =(event-seq.w (lent events.w))
          =(id.w id.workspace.r)  =(event-seq.w +(event-seq.workspace.r))
          ?=(^ events.w)
      ==  `%completion-review-queue-invalid
  ?>  ?=(^ events.w)
  =/  queued=event:bx  i.events.w
  ?.  ?&  =(events.workspace.r t.events.w)  =(actor.queued worker.ctx)
          =(action.queued [%command (envelope:request r u.contribution.e)])
          =(members.w members.workspace.r)
          =(membership-epoch.w membership-epoch.workspace.r)
          =(law-digest.w law-digest.workspace.r)
      ==  `%completion-review-queue-mismatch
  =/  current  (project-workspace:match w)
  ?.  ?&  =(0 refused.current)  =(%open status.match.current)
          =(config.match.current config.match.previous)
          =(moves.match.current moves.match.previous)
          =(pending.match.current ~[[worker.ctx (label:request worker.ctx model.selection.c) u.contribution.e]])
          ?=(~ (contribution-error:juggler match.previous u.contribution.e))
      ==  `%completion-review-projection-mismatch
  ~
++  verdict-for
  |=  [ctx=context:protocol denied=(unit @tas)]
  ^-  verdict:protocol
  =/  id=@ux  (identity ctx)
  =/  admission=admission:jm
    [(proposal-id:request id.request.ctx) (cat 3 'native-ai-completion-review:' (scot %ux id)) ?=(~ denied) law:request ?~(denied 'Standing AI completion review; exact native evidence and Boxy queue.' `@t`u.denied)]
  [%native-coding-completion-review-admission-v1 campaign.ctx id.request.ctx id admission]
++  row-valid
  ::  Frozen historical authority and the complete queue remain checkable
  ::  after later scope changes. This performs no live reads on load.
  |=  [our=@p k=key r=retained]
  ^-  ?
  ?.  (lte (met 3 (jam r)) row-limit)  %.n
  ?.  ?&  (identifier:completion campaign.k)  (identifier:completion request.k)
          =(campaign.k campaign.context.r)  =(request.k id.request.context.r)
          (scope-valid our context.r)  (grant-valid our context.r grant.r)
          (packet-valid:request our packet.request.context.r)
          (event-chain-valid:boxy queued.r)
      ==  %.n
  =(verdict.r (verdict-for context.r (refusal our context.r queued.r)))
++  valid
  |=  [our=@p s=ledger]
  ^-  ?
  &((lte ~(wyt by s) capacity) (levy ~(tap by s) |=([k=key r=retained] (row-valid our k r))))
++  path-for
  |=  k=key
  ^-  path
  /native-coding/completion-review-admission/(scot %ux campaign.k)/(scot %ux request.k)
++  publish
  |=  v=verdict:protocol
  ^-  card:agent:gall
  [%give %fact ~[(path-for [campaign.v request.v])] %noun !>(`(unit verdict:protocol)`[~ v])]
++  lookup
  |=  [s=ledger k=key]
  ^-  (unit verdict:protocol)
  =/  found  (~(get by s) k)
  ?~(found ~ `verdict.u.found)
++  act
  |=  [b=bowl:gall s=ledger held=organ:tools command=command:protocol]
  ^-  change
  ?>  =(our.b src.b)
  =/  k=key  [campaign.command request.command]
  ?>  &((identifier:completion campaign.k) (identifier:completion request.k))
  =/  old  (~(get by s) k)
  ?^  old
    ?>  (row-valid our.b k u.old)
    [s ~[(publish verdict.u.old)]]
  ?>  (lth ~(wyt by s) capacity)
  ?>  (agent-live:guard our.b now.b %viki)
  =/  raw=*
    .^(* %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/completion-review-admission/(scot %ux campaign.k)/(scot %ux request.k)/noun)
  =/  decoded  ((soft (unit context:protocol)) raw)
  ?>  ?=(^ decoded)
  ?>  =(u.decoded raw)
  ?>  ?=(^ u.decoded)
  =/  ctx=context:protocol  u.u.decoded
  ?>  &(=(campaign.k campaign.ctx) =(request.k id.request.ctx) (scope-valid our.b ctx))
  ?>  (agent-live:guard our.b now.b %viki)
  =/  scopes=(map @t scope:protocol)
    .^((map @t scope:protocol) %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/review-scopes/noun)
  ?>  =(`scope.ctx (~(get by scopes) project.scope.ctx))
  =/  p=packet:request  packet.request.ctx
  ?>  (packet-valid:request our.b p)
  ?>  (packet-current p held)
  ?>  (agent-live:guard our.b now.b %viki)
  =/  current=(each proposal:completion @tas)
    .^((each proposal:completion @tas) %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/completion-proposal/(scot %ux session.proposal.p)/noun)
  ?>  ?=(%& -.current)
  ?>  =(p.current proposal.p)
  =/  grant  (~(get by grants.held) grant.proposal.p)
  ?>  ?=(^ grant)
  ?>  (grant-valid our.b ctx u.grant)
  ?>  (agent-live:guard our.b now.b %boxy)
  =/  all=state:bx
    .^(state:bx %gx /(scot %p our.b)/boxy/(scot %da now.b)/state/noun)
  =/  found  (~(get by workspaces.all) id.workspace.request.ctx)
  ?>  ?=(^ found)
  =/  denied  (refusal our.b ctx u.found)
  =/  row=retained  [ctx (verdict-for ctx denied) u.found u.grant]
  ?>  (row-valid our.b k row)
  :-  (~(put by s) k row)
  :~  (publish verdict.row)
      [%pass /native-completion-review-evidence %agent [our.b %graf] %poke %graf-action !>([%attest [%native-coding-completion-review-admission-evidence-v1 (identity ctx) row]])]
  ==
--
