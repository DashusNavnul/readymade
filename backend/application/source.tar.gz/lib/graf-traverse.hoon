::  /lib/graf-traverse.hoon
::
::  graf Stage 1: the three jug indexes (rel-by-source / -target / -kind) that make
::  relational reads O(1) instead of a full scan, plus MULTI-HOP TRAVERSE -- a
::  genuine EXCEED, since neither the old nor the new graf had transitive
::  reachability. Index a relation set once; `reach` walks kind-k edges from a start
::  fact up to `depth` hops (BFS, cycle-safe). This is how a fact's neighborhood --
::  its provenance chain, its lineage -- is recovered without a linear crawl.
::
/+  graf-relations
=,  graf-relations
|%
+$  jugs  [bs=(jug fact rel) bt=(jug fact rel) bk=(jug @tas rel)]
::  reindex a relation set by source, target, and kind (as %graf does on write).
++  index
  |=  rs=(set rel)
  ^-  jugs
  %+  roll  ~(tap in rs)
  |=  [r=rel acc=jugs]
  ^-  jugs
  :+  (~(put ju bs.acc) src.r r)
    (~(put ju bt.acc) dst.r r)
  (~(put ju bk.acc) kind.r r)
::  O(1) relational reads.
++  from     |=([j=jugs f=fact] ^-((list rel) ~(tap in (~(get ju bs.j) f))))   ::  edges out of f
++  into     |=([j=jugs f=fact] ^-((list rel) ~(tap in (~(get ju bt.j) f))))   ::  edges into f
++  of-kind  |=([j=jugs k=@tas] ^-((list rel) ~(tap in (~(get ju bk.j) k))))   ::  edges of kind k
::  multi-hop: from `start`, follow kind-`k` edges up to `depth` hops; return the
::  set of reachable dst facts. BFS, cycle-safe via `seen`.
++  reach
  |=  [j=jugs start=fact k=@tas depth=@ud]
  ^-  (set fact)
  =|  out=(set fact)
  =/  seen=(set fact)  (~(put in *(set fact)) start)
  =/  frontier=(set fact)  seen
  |-  ^-  (set fact)
  ?:  |(=(depth 0) =(~ frontier))  out
  =/  edges=(list rel)  (zing (turn ~(tap in frontier) |=(f=fact (from j f))))
  =/  nxt=(set fact)
    %+  roll  edges
    |=  [r=rel acc=(set fact)]
    ?:  &(=(kind.r k) !(~(has in seen) dst.r))
      (~(put in acc) dst.r)
    acc
  =.  out  (~(uni in out) nxt)
  =.  seen  (~(uni in seen) nxt)
  $(frontier nxt, depth (dec depth))
--
