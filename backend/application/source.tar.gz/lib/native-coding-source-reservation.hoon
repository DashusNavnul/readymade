::  Allocation fence for the owner's native source-import journal. A stopped
::  importer is unavailable, not evidence that its retained work disappeared.
/+  guard=viki-scry-guard
|%
++  free
  |=  [our=@p now=@da desk=@tas]
  ^-  (each ~ @tas)
  ?.  (agent-live:guard our now %native-coding-source-import)
    [%| %source-import-journal-unavailable]
  =/  reserved=(set @tas)
    .^((set @tas) %gx /(scot %p our)/native-coding-source-import/(scot %da now)/reservations/noun)
  ?:  (~(has in reserved) desk)  [%| %source-import-desk-reserved]
  [%& ~]
--
