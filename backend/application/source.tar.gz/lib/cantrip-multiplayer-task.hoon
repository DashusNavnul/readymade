::  /lib/cantrip-multiplayer-task
::
::  Pure Cantrip law for remote task authority.  Identity and binding values
::  must come from the receiving ship's local bowl/state, never the envelope.
::
/-  cmt=cantrip-multiplayer-task, mse=multiplayer-session-executor
|%
++  max-roots  `@ud`32
++  max-tools  `@ud`16
++  max-label-bytes  `@ud`512
++  ceiling-digest
  |=  body=ceiling-body:cmt
  ^-  @ux
  `@ux`(shax (jam [%cantrip-multiplayer-task-ceiling-v1 body]))
++  bounded-text
  |=  text=@t
  ^-  ?
  ?&  (gth (met 3 text) 0)
      (lte (met 3 text) max-label-bytes)
  ==
++  texts-valid
  |=  [values=(list @t) limit=@ud]
  ^-  ?
  ?&  (lte (lent values) limit)
      (levy values |=(value=@t (bounded-text value)))
  ==
++  tools-valid
  |=  tools=(list @tas)
  ^-  ?
  ?&  (gth (lent tools) 0)
      (lte (lent tools) max-tools)
      (levy tools |=(tool=@tas !=(0 tool)))
  ==
++  ceiling-body-valid
  |=  body=ceiling-body:cmt
  ^-  ?
  ?&  =(%cantrip-multiplayer-task-ceiling-v1 -.body)
      !=(0 issuer.body)
      !=(0 peer.body)
      (bounded-text peer-session.body)
      (bounded-text local-session.body)
      (bounded-text workspace.body)
      (texts-valid read-roots.body max-roots)
      (texts-valid write-roots.body max-roots)
      (tools-valid tools.body)
      (gth max-runtime.body ~s0)
      (gth max-output.body 0)
      !=(0 expires-at.body)
  ==
++  ceiling-valid
  |=  item=ceiling:cmt
  ^-  ?
  ?&  (ceiling-body-valid body.item)
      =((ceiling-digest body.item) digest.item)
  ==
++  text-subset
  |=  [child=(list @t) parent=(list @t)]
  ^-  ?
  %+  levy  child
  |=  item=@t
  (lien parent |=(candidate=@t =(item candidate)))
++  tool-subset
  |=  [child=(list @tas) parent=(list @tas)]
  ^-  ?
  %+  levy  child
  |=  item=@tas
  (lien parent |=(candidate=@tas =(item candidate)))
++  authorize
  |=  $:  ceiling=ceiling:cmt
          task=task-authority:mse
          observed-at=@da
          issuer=@p
          peer=@p
          peer-session=@t
          local-session=@t
          workspace=@t
      ==
  ^-  authorization:cmt
  =/  body=ceiling-body:cmt  body.ceiling
  ?.  (ceiling-body-valid body)  [%| [%invalid-ceiling ~]]
  ?.  =((ceiling-digest body) digest.ceiling)
    [%| [%ceiling-digest-mismatch (ceiling-digest body) digest.ceiling]]
  ?:  (gte observed-at expires-at.body)
    [%| [%ceiling-expired expires-at.body observed-at]]
  ?.  =(issuer.body issuer)
    [%| [%issuer-mismatch issuer.body issuer]]
  ?.  =(peer.body peer)
    [%| [%peer-mismatch peer.body peer]]
  ?.  =(peer-session.body peer-session)
    [%| [%peer-session-mismatch peer-session.body peer-session]]
  ?.  =(local-session.body local-session)
    [%| [%local-session-mismatch local-session.body local-session]]
  ?.  =(workspace.body workspace)
    [%| [%workspace-mismatch workspace.body workspace]]
  ?.  (text-subset read-paths.task read-roots.body)
    [%| [%read-path-widens read-paths.task]]
  ?.  (text-subset write-paths.task write-roots.body)
    [%| [%write-path-widens write-paths.task]]
  ?.  (tool-subset tools.task tools.body)
    [%| [%tool-widens tools.task]]
  ?.  ?|  !allow-mutations.task  allow-mutations.body  ==
    [%| [%mutation-widens ~]]
  ?:  (gth max-runtime.task max-runtime.body)
    [%| [%runtime-widens max-runtime.body max-runtime.task]]
  ?:  (gth max-output.task max-output.body)
    [%| [%output-widens max-output.body max-output.task]]
  [%& ceiling]
--
