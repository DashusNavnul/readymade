::  Sovereign-local demo admission, NOT a tenth Bachelor seat.
::  Read-shaped Cantrip law admits one exact data write, never execution or
::  acceptance. Callers cannot supply a destination, source, or passed flag.
/-  vc=vibecoding-candidate, vp=vibecoding-proposal
/+  clw=cantrip-law-window, cvp=cantrip-vibecoding-proposal,
    demo=vibecoding-demo, vcl=vibecoding-candidate,
    vcr=vibecoding-candidate-review
|%
+$  refusal
  $?  %foreign-actor  %agent-unavailable  %candidate-missing  %review-missing
      %evidence-missing  %intent-changed  %candidate-invalid  %review-invalid
      %project-changed  %revision-changed  %time-invalid  %file-hash-mismatch
  ==
+$  admission
  $:  %vibecoding-local-admission-v1
      actor=@p
      candidate=@ux
      review=@ux
      proposal=@ux
      base=revision:vc
      work=revision:vc
      path=path
      before=@ux
      after=@ux
      source=@t
      law=@ux
      at=@da
  ==
+$  decision  (each admission refusal)
++  judge
  |=  $:  our=@p  actor=@p  candidate=candidate:vc  record=record:vp
          window=window:clw  accepted=snapshot:demo  working=snapshot:demo
          base-number=@ud  work-number=@ud  at=@da
      ==
  ^-  decision
  ?.  =(our actor)  [%| %foreign-actor]
  =/  context=context:vc  (context-of:vcl packet.candidate)
  ?.  =(our by.intent.intent.context)  [%| %foreign-actor]
  ?.  ?&  (gte at recorded-at.record)
          (gte recorded-at.record proposed-at.proposal.body.record)
          (gte proposed-at.proposal.body.record at.candidate)
      ==
    [%| %time-invalid]
  =/  prepared  (prepare:vcr candidate window proposed-at.proposal.body.record)
  ?:  ?=(%| -.prepared)  [%| %candidate-invalid]
  =/  current=verdict:vp
    (judge:cvp proposal.p.prepared intent.intent.context request.p.prepared result.p.prepared (law-binding-for:cvp 1 window))
  ?.  ?&  (record-valid:cvp record)
          =(proposal.p.prepared proposal.body.record)
          =(current verdict.body.record)
          review-admitted.current
          !execution-admitted.current
      ==
    [%| %review-invalid]
  ?.  ?&  =(base:demo desk.accepted)  =(work:demo desk.working)
          exists.accepted  exists.working
          |(?=(%vibecoding-candidate-packet-v4 -.packet.candidate) &(seed.accepted seed.working))
          private.accepted  private.working
          =(7 files.accepted)  =(7 files.working)
          =(`root.base.context root.accepted)
          =(`root.work.context root.working)
      ==
    [%| %project-changed]
  ?.  &(=(base-number number.base.context) =(work-number number.work.context))
    [%| %revision-changed]
  [%& [%vibecoding-local-admission-v1 actor (digest:vcl candidate) digest.record digest.proposal.body.record base.context work.context target:demo (file-hash:vcr before.context) (file-hash:vcr source.candidate) source.candidate (digest:vcl window) at]]
++  write-card
  |=  [admission=admission our=@p now=@da]
  ^-  (unit card:agent:gall)
  ::  This is not a transferable ticket. The live Cantrip read and this card
  ::  must occur in the SAME event, with no watch/poke/wait between them.
  ?.  ?&  =(our actor.admission)  =(now at.admission)
          =(base:demo desk.base.admission)  =(work:demo desk.work.admission)
          =(target:demo path.admission)
          =(after.admission (file-hash:vcr source.admission))
          !=(before.admission after.admission)
      ==
    ~
  `[%pass /vibecoding-local-write %arvo %c [%info work:demo %.y ~[[target:demo %mut %hoon !>(source.admission)]]]]
--
