::  Derive guidance from one selected failed Viki request's owner-retained
::  execution judgment. No separate guidance attestation is needed.
::  No latest-record heuristic, model call, mutation or background work.
/-  project=viki-glass-project, cs=vibecoding-check-spec
/+  remediation=glass-coding-remediation, execution=glass-coding-execution,
    generation=cantrip-glass-generation, guard=viki-scry-guard,
    coding=viki-glass-coding, result=glass-coding-result
|%
+$  view  (each (unit guidance:remediation) @tas)
++  failed
  |=  s=status:project
  ^-  ?
  ?&  =('pataphor-demo' project.s)  ?=(~ saved.s)  ?=(^ source.s)
      =(`%request-remediation judgment.s)
      |(&(=(%judgment phase.s) =(`%.n checks.s)) &(=(%rejection phase.s) ?=(~ checks.s)))
  ==
++  matches
  ::  Structural binding; only select/read supply the owner attribution.
  |=  [our=@p s=status:project g=guidance:remediation]
  ^-  ?
  ?.  (failed s)  %.n
  ?.  ?:(?=(%checks -.evidence.g) =(%judgment phase.s) =(%rejection phase.s))  %.n
  =/  p=pending:execution  (pending:remediation evidence.g)
  =/  prepared=prepared-v1:coding  (base:coding prepared.result.p)
  =/  original=evidence:generation  evidence.admission.prepared
  ?.  ?&  =(our owner.order.p)
          =(nonce.s nonce.admission.prepared)
          =(goal.s gid.goal.original)  =(text.s text.goal.original)
          =(`source-hash.order.p source.s)
      ==  %.n
  %.y
++  select
  |=  [our=@p s=status:project rows=(list attested:cs)]
  ^-  view
  ?.  (failed s)  [%& ~]
  =|  found=(unit guidance:remediation)
  |-
  ?~  rows  [%& found]
  =/  row=attested:cs  i.rows
  ?.  (~(has in ships.row) our)  $(rows t.rows)
  =/  tag  ((soft ,[@tas *]) fact.row)
  ?~  tag  $(rows t.rows)
  ?.  ?=(?(%glass-coding-judgment %glass-coding-compiler-rejection) -.u.tag)  $(rows t.rows)
  =/  parsed  ((soft ,[tag=@tas key=@t value=failure:result]) fact.row)
  ::  Unidentifiable malformed history cannot claim this request or suppress
  ::  its valid judgment. Parsed records are bound by nonce before validation.
  ?~  parsed  $(rows t.rows)
  =/  f=failure:result  value.u.parsed
  =/  p=pending:execution  (failure-pending:result f)
  =/  prepared=prepared-v1:coding  (base:coding prepared.result.p)
  ?.  =(nonce.s nonce.admission.prepared)  $(rows t.rows)
  ?.  =(fact.row (failure-fact:result f))  [%| %guidance-invalid]
  =/  e=evidence:remediation
    ?:(?=(%glass-coding-judgment-v1 -.f) [%checks f] [%compiler f])
  ?:  ?&(?=(^ found) =(e evidence.u.found))  $(rows t.rows)
  =/  made
    ?:(?=(%glass-coding-judgment-v1 -.f) (from-checks:remediation our our f) (from-compiler:remediation our our f))
  ?:  ?=(%| -.made)  [%| p.made]
  =/  g=guidance:remediation  p.made
  ?.  (matches our s g)  [%| %guidance-binding-mismatch]
  ?^  found
    ?.  =(g u.found)  [%| %guidance-conflict]
    $(rows t.rows)
  $(rows t.rows, found `g)
++  read
  |=  [our=@p actor=@p at=@da s=status:project]
  ^-  view
  ?.  =(our actor)  [%| %owner-required]
  ?.  (failed s)  [%& ~]
  ?.  (agent-live:guard our at %graf)  [%| %graf-unavailable]
  =/  rows=(list attested:cs)
    .^((list attested:cs) %gx /(scot %p our)/graf/(scot %da at)/attested/noun)
  (select our s rows)
--
