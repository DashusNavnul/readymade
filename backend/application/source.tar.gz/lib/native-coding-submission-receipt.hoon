::  Called inside the submitting Viki event, never on client-supplied records.
::  Exact before/after transition evidence; acceptance is not completion.
/+  sessions=native-coding-session
|%
+$  receipt
  $:  %native-coding-submission-receipt-v1
      session=@ux  request=@ux  input=@ux  baseline=@ud
      prior=(unit @ux)  outcome=?(%recorded %refused %unknown)
      record=(unit @ux)  reason=(unit @tas)
  ==
++  classify
  |=  [request=@ux input=@t before=entry:sessions after=entry:sessions refusal=(unit @tas)]
  ^-  receipt
  =/  base=receipt
    [%native-coding-submission-receipt-v1 id.session.before request (shax input) sequence.before head.before %unknown ~ ~]
  ?.  &(=(session.before session.after) (gth request 0) (lte (met 0 request) 256))  base
  =/  count=@ud  (lent records.before)
  ?.  &((lte count (lent records.after)) =(records.before (scag count records.after)))  base
  =/  tail=(list record:sessions)  (slag count records.after)
  =/  valid=?
    =/  rows  tail
    =/  sequence=@ud  sequence.before
    =/  previous=(unit @ux)  head.before
    |-  ^-  ?
    ?~  rows  &(=(sequence sequence.after) =(previous head.after))
    =/  row  i.rows
    ?.  ?&  =(sequence sequence.row)  =(previous previous.row)
            =(id.row (event-id:sessions id.session.before sequence.row previous.row at.row body.row))
        ==  %.n
    $(rows t.rows, sequence +(sequence), previous `id.row)
  ?.  valid  base
  =/  operators=(list record:sessions)
    (skim tail |=(row=record:sessions ?=(%operator -.body.row)))
  ?~  operators
    ?~  refusal  base
    base(outcome %refused, reason refusal)
  ?.  =(1 (lent operators))  base
  =/  row  i.operators
  ?>  ?=(%operator -.body.row)
  ?.  &(=(input text.body.row) ?=(~ refusal))  base
  base(outcome %recorded, record `id.row)
++  encode
  |=  value=receipt
  ^-  @t
  (cat 3 'Readymade submission receipt: ' (scot %uv (jam value)))
++  decode
  |=  text=@t
  ^-  (unit receipt)
  ?.  (lte (met 3 text) 4.096)  ~
  =/  prefix=@t  'Readymade submission receipt: '
  ?.  =(prefix (end [3 (met 3 prefix)] text))  ~
  =/  value  (slaw %uv (rsh [3 (met 3 prefix)] text))
  ?~  value  ~
  (mole |.(;;(receipt (cue u.value))))
++  lookup
  |=  [e=entry:sessions request=@ux]
  ^-  (unit receipt)
  =/  matches=(list receipt)
    %+  murn  records.e
    |=  row=record:sessions
    ?.  ?=(%terminal -.body.row)  ~
    ?.  =('' input.body.row)  ~
    =/  value  (decode output.body.row)
    ?~  value  ~
    ?.  &(=(request request.u.value) =(id.session.e session.u.value))  ~
    ?.  =(id.row (event-id:sessions id.session.e sequence.row previous.row at.row body.row))  ~
    value
  ?.  =(1 (lent matches))  ~
  ?>  ?=(^ matches)
  `i.matches
--
