::  Human terminal proposals retain Viki's decision for an explicit Decide.
::  This changes dispatch only; Cantrip still reads the canonical decision
::  and checks the original grant, context, checks and landing authority.
/-  nc=native-coding
/+  loop=native-coding-loop, session=native-coding-session,
    terminal=native-coding-terminal, git=readymade-git-proposal
|%
++  human
  ::  The input nonce and tool result are retained by the owning Viki loop.
  ::  Worker location or a model's text cannot establish human provenance.
  |=  [our=@p coding=state:loop c=candidate:nc]
  ^-  ?
  =/  ctx=context:nc  context.c
  =/  input  (~(get by inputs.coding) request.ctx)
  =/  found  (~(get by sessions.coding) session.ctx)
  ?~  input  %.n
  ?~  found  %.n
  =/  e=entry:session  u.found
  ?.  ?&  !=(0 request.ctx)  =(our actor.ctx)  =(our owner.session.e)
          =(session.ctx id.session.e)  =(session.ctx session.u.input)
          =(project.ctx project.session.e)
          =(configuration.ctx configuration.e)
          =(source.ctx working.session.e)
          =(`c (~(get by candidates.coding) id.c))
      ==  %.n
  =/  owner-proposal=?
    =/  words=(list @t)  (words:terminal input.u.input)
    ?:  &(?=([@ @ @ ~] words) =('/git-proposal' i.words))
      =/  origin  (slaw %ux i.t.words)
      ?~  origin  %.n
      =(input.u.input (command-input:git u.origin request.ctx))
    =/  parsed  (parse:terminal input.u.input directory.session.e accepted.c)
    ?:  ?=(%| -.parsed)  %.n
    ?.  ?=(%tool -.p.parsed)  %.n
    ?=(?(%create %replace %patch %delete %move %undo) -.arguments.p.parsed)
  ?.  owner-proposal  %.n
  =/  rows=(list record:session)  records.e
  =/  submitted=(unit @ud)  ~
  |-  ^-  ?
  ?~  rows  %.n
  =/  r=record:session  i.rows
  ?:  ?=(%terminal -.body.r)
    =/  matched=?
      &(=(input.u.input input.body.r) =('Native tool submitted.' output.body.r))
    $(rows t.rows, submitted ?:(matched `sequence.r submitted))
  ?:  ?=(%tool -.body.r)
    =/  result=tool-result:nc  result.body.r
    ?:  ?&  =(context.result ctx)
            =(call-id.result (scot %ux request.ctx))
            ?=(%candidate -.output.result)  =(value.output.result c)
        ==
      ?~  submitted  %.n
      (lth u.submitted sequence.r)
    $(rows t.rows)
  $(rows t.rows)
++  cards
  |=  [our=@p coding=state:loop c=candidate:nc]
  ^-  (list card:agent:gall)
  ?:  (human our coding c)  ~
  ~[(poke:loop our %cantrip /native-coding/decide/(scot %ux id.c) [%native-coding-decide-v1 id.c])]
--
