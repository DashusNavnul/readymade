::  /lib/boks
::
::  Pure Boks identity, admission, and legacy-wire compatibility law.
::
/-  b=boks, ms=multiplayer-session, net
/+  msl=multiplayer-session
|%
++  max-label-bytes  `@ud`256
++  max-text-bytes  `@ud`16.384
++  max-paths  `@ud`32
++  max-envelope-bytes  `@ud`65.536
++  wire-size-valid
  |=  envelope=envelope:b
  ^-  ?
  (lte (met 3 (jam envelope)) max-envelope-bytes)
++  envelope-digest
  |=  body=envelope-body:b
  ^-  digest:b
  `@ux`(shax (jam [%boks-envelope-v1 body]))
++  make-envelope
  |=  body=envelope-body:b
  ^-  envelope:b
  [body (envelope-digest body)]
++  receipt-digest
  |=  body=receipt-body:b
  ^-  digest:b
  `@ux`(shax (jam [%boks-receipt-v1 body]))
++  make-receipt
  |=  body=receipt-body:b
  ^-  receipt:b
  [body (receipt-digest body)]
++  nonempty-bounded
  |=  [text=@t maximum=@ud]
  ^-  ?
  ?&  (gth (met 3 text) 0)
      (lte (met 3 text) maximum)
  ==
++  authority-valid
  |=  authority=task-authority:b
  ^-  ?
  ?&  =(%boks-task-authority-v1 -.authority)
      (lte (lent read-paths.authority) max-paths)
      (lte (lent write-paths.authority) max-paths)
      (lte (lent tools.authority) max-paths)
      (gth max-runtime.authority 0)
      (gth max-output.authority 0)
  ==
++  task-valid
  |=  task=task-request:b
  ^-  ?
  ?&  =(%boks-task-request-v1 -.task)
      (nonempty-bounded task-id.task max-label-bytes)
      (nonempty-bounded intent.task max-text-bytes)
      (authority-valid authority.task)
      (lte (lent expected-evidence.task) max-paths)
  ==
++  proposal-valid
  |=  proposal=proposal:b
  ^-  ?
  ?&  =(%boks-proposal-v1 -.proposal)
      (nonempty-bounded proposal-id.proposal max-label-bytes)
      (nonempty-bounded `@t`source.proposal max-label-bytes)
      (gth (lent paths.proposal) 0)
      (lte (lent paths.proposal) max-paths)
      (nonempty-bounded intent.proposal max-text-bytes)
      (nonempty-bounded task-id.proposal max-label-bytes)
      !=(0 submitted-at.proposal)
  ==
++  payload-valid
  |=  payload=payload:b
  ^-  ?
  ?-  -.payload
    %session
      (nonempty-bounded text.payload max-text-bytes)
    %task
      (task-valid request.payload)
    %release  %.y
    %proposal
      (proposal-valid proposal.payload)
    %proposal-verdict
      ?&  (nonempty-bounded proposal-id.verdict.payload max-label-bytes)
          !=(0 decided-at.verdict.payload)
      ==
    %membership  %.y
    %heartbeat
      ?&  !=(0 desk-hash.payload)
          !=(0 revision.payload)
      ==
    %status
      (nonempty-bounded text.payload max-text-bytes)
  ==
++  body-valid
  |=  body=envelope-body:b
  ^-  ?
  ?&  =(%boks-envelope-v1 -.body)
      (nonempty-bounded sender-session.body max-label-bytes)
      (nonempty-bounded recipient-session.body max-label-bytes)
      (nonempty-bounded correlation.body max-label-bytes)
      (payload-valid payload.body)
      !=(0 sent-at.body)
      (gth expires-at.body sent-at.body)
  ==
++  envelope-valid
  |=  envelope=envelope:b
  ^-  ?
  ?&  (wire-size-valid envelope)
      (body-valid body.envelope)
      =((envelope-digest body.envelope) digest.envelope)
  ==
++  receipt-valid
  |=  receipt=receipt:b
  ^-  ?
  ?&  =(%boks-receipt-v1 -.body.receipt)
      !=(0 envelope-id.body.receipt)
      !=(0 received-at.body.receipt)
      =((receipt-digest body.receipt) digest.receipt)
  ==
++  admit
  |=  $:  our=@p
          source=@p
          received-at=@da
          trusted=(set @p)
          envelope=envelope:b
      ==
  ^-  (each admitted:b refusal:b)
  ?.  (~(has in trusted) source)  [%.n %untrusted-peer]
  ?.  =(our recipient.body.envelope)  [%.n %wrong-recipient]
  ?.  (wire-size-valid envelope)  [%.n %invalid-envelope]
  ?.  (body-valid body.envelope)  [%.n %invalid-envelope]
  ?.  =((envelope-digest body.envelope) digest.envelope)
    [%.n %digest-mismatch]
  ?.  (gth expires-at.body.envelope received-at)
    [%.n %expired]
  [%.y [%boks-admitted-v1 source received-at envelope]]
::
::  The legacy sender field is consumed only at the compatibility boundary.
::  It becomes the attested-source candidate beside the new envelope, never a
::  field inside that envelope.
++  session-to-envelope
  |=  [item=message:ms expires-at=@da]
  ^-  (unit [source=@p envelope=envelope:b])
  ?.  (message-valid:msl item)  ~
  ?.  (gth expires-at sent-at.body.item)  ~
  =/  payload=payload:b
    [%session kind.body.item text.body.item]
  =/  body=envelope-body:b
    :*  %boks-envelope-v1
        recipient.body.item
        sender-session.body.item
        recipient-session.body.item
        thread.body.item
        reply-to.body.item
        payload
        sent-at.body.item
        expires-at
    ==
  `[sender.body.item (make-envelope body)]
++  session-from-admitted
  |=  ingress=admitted:b
  ^-  (unit message:ms)
  ?.  ?=(%session -.payload.body.envelope.ingress)  ~
  =/  body=message-body:ms
    :*  %multiplayer-session-message-v1
        correlation.body.envelope.ingress
        source.ingress
        recipient.body.envelope.ingress
        sender-session.body.envelope.ingress
        recipient-session.body.envelope.ingress
        kind.payload.body.envelope.ingress
        parent.body.envelope.ingress
        text.payload.body.envelope.ingress
        sent-at.body.envelope.ingress
    ==
  =/  item=message:ms  (make-message:msl body)
  ?.  (message-valid:msl item)  ~
  `item
++  proposal-to-envelope
  |=  $:  p=proposal:net
          recipient=@p
          sender-session=@t
          recipient-session=@t
          expires-at=@da
      ==
  ^-  (unit [source=@p envelope=envelope:b])
  ?.  (gth expires-at submitted-at.p)  ~
  =/  proposal=proposal:b
    :*  %boks-proposal-v1
        proposal-id.p
        source.p
        paths.p
        intent.p
        task-id.p
        submitted-at.p
    ==
  ?.  (proposal-valid proposal)  ~
  =/  body=envelope-body:b
    :*  %boks-envelope-v1
        recipient
        sender-session
        recipient-session
        proposal-id.p
        ~
        [%proposal proposal]
        submitted-at.p
        expires-at
    ==
  `[from.p (make-envelope body)]
++  proposal-from-admitted
  |=  ingress=admitted:b
  ^-  (unit proposal:net)
  ?.  ?=(%proposal -.payload.body.envelope.ingress)  ~
  =/  p=proposal:b  proposal.payload.body.envelope.ingress
  =/  proposal=proposal:net
    :*  %net-proposal-v1
        proposal-id.p
        source.ingress
        source.p
        paths.p
        intent.p
        task-id.p
        submitted-at.p
    ==
  `proposal
--
