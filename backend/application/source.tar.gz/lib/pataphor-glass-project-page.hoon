::  Exact owner examples and presentation; Viki supplies approval and execution.
/-  project=viki-glass-project,  cs=vibecoding-check-spec
/+  checks=vibecoding-check-spec, ui=pataphor-chat-page,
    remediation=glass-coding-remediation, guidance=glass-coding-remediation-read
|%
+$  form  [text=@t specification=specification:cs]
++  project-name  'pataphor-demo'
++  normalize
  |=  text=@t
  ^-  (unit @t)
  ?.  &(!=('' text) (lte (met 3 text) 8.192))  ~
  =/  chars  (trip text)
  =|  out=tape
  |-  ^-  (unit @t)
  ?~  chars  `(crip (flop out))
  ?:  =(13 i.chars)
    =/  tail=tape  t.chars
    ?~  tail  ~
    ?.  =(10 i.tail)  ~
    $(chars t.tail, out ['\0a' out])
  ?.  |(=(9 i.chars) =(10 i.chars) (gte i.chars 32))  ~
  ?:  =(127 i.chars)  ~
  $(chars t.chars, out [i.chars out])
++  decimal
  |=  text=@t
  ^-  (unit @ud)
  ?.  &(!=('' text) (lte (met 3 text) 20))  ~
  =/  chars  (trip text)
  =|  value=@ud
  |-  ^-  (unit @ud)
  ?~  chars  ?:((lte value 18.446.744.073.709.551.615) `value ~)
  ?.  &((gte i.chars 48) (lte i.chars 57))  ~
  $(chars t.chars, value (add (mul value 10) (sub i.chars 48)))
++  number
  |=  [fields=(map @t @t) name=@t]
  ^-  (unit @ud)
  =/  value  (~(get by fields) name)
  ?~  value  ~
  (decimal u.value)
++  decode
  |=  [token=@uv body=@t]
  ^-  (unit form)
  ?.  &(!=(0 token) (lte (met 3 body) 16.384))  ~
  ?:  ?=(^ (find (trip '%00') (trip body)))  ~
  =/  parsed  (rush (cat 3 '?' body) yque:de-purl:html)
  ?~  parsed  ~
  ?.  =(10 (lent u.parsed))  ~
  =/  fields  (~(gas by *(map @t @t)) u.parsed)
  ?.  =(10 ~(wyt by fields))  ~
  ?.  ?&  =(`(scot %uv token) (~(get by fields) 'nonce'))
          =(`'project-submit' (~(get by fields) 'op'))
          =(`project-name (~(get by fields) 'project'))
      ==  ~
  =/  text  (~(get by fields) 'text')
  ?~  text  ~
  =/  text  (normalize u.text)
  ?~  text  ~
  =/  p1  (number fields 'participants-1')
  =/  m1  (number fields 'minutes-1')
  =/  e1  (number fields 'expected-1')
  =/  p2  (number fields 'participants-2')
  =/  m2  (number fields 'minutes-2')
  =/  e2  (number fields 'expected-2')
  ?.  ?&(?=(^ p1) ?=(^ m1) ?=(^ e1) ?=(^ p2) ?=(^ m2) ?=(^ e2))  ~
  =/  spec=specification:cs
    [%vibecoding-check-spec-v1 %two-ud-ud-v1 target:checks %entry-fuel-500k-v1 ~[[[u.p1 u.m1] u.e1] [[u.p2 u.m2] u.e2]]]
  ?.  (valid:checks spec)  ~
  `[u.text spec]
++  action
  |=  [our=@p token=@uv item=form]
  ^-  request:project
  =/  nonce=@ux  `@ux`(sham [%viki-glass-project-form-v1 our token project-name item])
  [%viki-glass-project-request-v1 nonce (cat 3 'glass-project-' (scot %ux nonce)) project-name text.item specification.item]
++  href
  |=  nonce=(unit @ux)
  ^-  @t
  =/  base=@t  '/apps/pataphor-work?glass=1&project=pataphor-demo'
  ?~  nonce  base
  (rap 3 ~[base '&request=' (scot %ux u.nonce)])
++  field
  |=  [name=@t value=@t]
  ^-  @t
  (rap 3 ~['<dt>' (escape:ui name) '</dt><dd>' (escape:ui value) '</dd>'])
++  label
  |=  phase=@tas
  ^-  @t
  ?+  phase  (cat 3 'Viki: ' `@t`phase)
    %retaining  'Viki is retaining the request'
    %approving  'Viki is checking the project basis'
    %submitted  'Viki has submitted bounded work'
    %generation  'Moon is generating a candidate'
    %compile   'Compiling the candidate'
    %judgment  'Viki judgment is available'
    %rejection  'Compiler rejected the candidate; Viki correction is available'
    %save      'Saving Viki-approved source'
    %applied   'Source saved'
    %refused   'Viki refused this request'
  ==
++  row
  |=  item=status:project
  ^-  @t
  %+  rap  3
  :~  '<article class="source"><h3><a href="'  (escape:ui (href `nonce.item))  '">'
      (escape:ui text.item)  '</a></h3><p>'  (escape:ui (label phase.item))  '</p><dl>'
      (field 'Request' (scot %ux nonce.item))  (field 'Goal' goal.item)
      ?~(reason.item '' (field 'Reason' `@t`u.reason.item))
      ?~(source.item '' (field 'Source hash' (scot %ux u.source.item)))
      ?~(checks.item '' (field 'Expected examples' ?:(u.checks.item 'Passed' 'Failed')))
      ?~(judgment.item '' (field 'Viki judgment' `@t`u.judgment.item))
      ?~(saved.item '' (field 'Saved revision' (scot %ud u.saved.item)))
      '</dl></article>'
  ==
++  example
  |=  [index=@t participants=@t minutes=@t expected=@t]
  ^-  @t
  %+  rap  3
  :~  '<tr><th scope="row">'  index  '</th><td><input aria-label="Example '  index  ' participants" type="number" min="0" max="1000" name="participants-'  index  '" value="'  participants  '" required></td>'
      '<td><input aria-label="Example '  index  ' minutes" type="number" min="0" max="1000" name="minutes-'  index  '" value="'  minutes  '" required></td>'
      '<td><input aria-label="Example '  index  ' expected result" type="number" min="0" max="18446744073709551615" name="expected-'  index  '" value="'  expected  '" required></td></tr>'
  ==
++  page
  |=  [our=@p token=@uv selected=(unit @ux) current=(each catalog:project @tas)]
  ^-  @t
  (page-with-guidance our token selected current [%& ~])
++  guidance-block
  |=  text=@t
  ^-  @t
  (rap 3 ~['<section class="source"><h3>Viki correction</h3><pre>' (escape:ui text) '</pre></section>'])
++  related-attempts
  |=  [selected=status:project catalog=catalog:project]
  ^-  @t
  =/  related=(list status:project)
    %+  skim  ~(val by catalog)
    |=  item=status:project
    ?&  !=(nonce.selected nonce.item)  =(goal.selected goal.item)
        =(project.selected project.item)  =(text.selected text.item)
    ==
  ?~  related  ''
  (rap 3 ~['<section><h3>Other attempt for this request</h3>' (rap 3 (turn related row)) '</section>'])
++  correction
  |=  [our=@p selected=(unit @ux) current=(each catalog:project @tas) view=view:guidance]
  ^-  @t
  ?~  selected  ''
  ?:  ?=(%| -.current)  ''
  =/  held  (~(get by p.current) u.selected)
  ?~  held  ''
  ?.  (failed:guidance u.held)  ''
  ?:  ?=(%| -.view)
    (rap 3 ~['<p class="notice">Viki correction unavailable: ' (escape:ui `@t`p.view) '.</p>'])
  ?~  p.view  ''
  ::  The canonical reader already validated and evaluated the judgment.
  ::  Rendering checks its selected binding and text bound without rerunning.
  ?.  ?&  (matches:guidance our u.held u.p.view)
          (lte (met 3 instructions.u.p.view) max-instructions:remediation)
      ==  ''
  (guidance-block instructions.u.p.view)
++  page-with-guidance
  |=  [our=@p token=@uv selected=(unit @ux) current=(each catalog:project @tas) view=view:guidance]
  ^-  @t
  %+  rap  3
  :~  '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Build with Viki | Pataphor</title><style>'  css:ui  '</style></head><body><main><header><a href="/apps/pataphor">Pataphor</a><span>'  (escape:ui (scot %p our))  '</span></header>'
      '<h2>Build the session-estimate demo with Viki</h2><p>This private project estimates total session minutes from participants and minutes. Describe the change and provide the expected examples for this request. Viki reviews the candidate and decides whether it may be saved.</p>'
      '<p><a href="/apps/pataphor-work?editor=1">Project source</a> &#183; <a href="/apps/pataphor">Conversation and calls</a> &#183; <a href="/apps/pataphor-work?glass=1">Other Viki goals</a></p>'
      ?:  ?=(%| -.current)
        (rap 3 ~['<p class="notice">Project requests unavailable: ' (escape:ui `@t`p.current) '. Refresh to check again.</p>'])
      %+  rap  3
      :~  ?^  selected  ''
          %+  rap  3
          :~  '<form method="post" action="'  (escape:ui (href ~))  '">'
              (field:ui 'nonce' (scot %uv token))  (field:ui 'op' 'project-submit')  (field:ui 'project' project-name)
              '<label for="project-goal">What should change?</label><textarea id="project-goal" name="text" maxlength="8192" required></textarea><h3>Expected examples</h3><p>Edit these values to define success. The starting examples use five setup minutes per participant; change them to match your request.</p>'
              '<table><thead><tr><th>Example</th><th>Participants</th><th>Minutes</th><th>Expected total</th></tr></thead><tbody>'  (example '1' '2' '30' '70')  (example '2' '1' '5' '10')  '</tbody></table><button type="submit">Ask Viki to build</button></form>'
          ==
          '<h2>Project requests</h2>'
          ?~  selected  (rap 3 (turn ~(val by p.current) row))
          =/  held  (~(get by p.current) u.selected)
          ?~  held  '<p class="notice">This request is not confirmed in Viki. Refresh to observe its original nonce; do not submit it again.</p>'
          (cat 3 (row u.held) (related-attempts u.held p.current))
          (correction our selected current view)
          '<p><a href="'  (escape:ui (href selected))  '">Refresh saved progress</a> &#183; <a href="'  (escape:ui (href ~))  '">New project request</a></p>'
      ==
      '</main></body></html>'
  ==
--
