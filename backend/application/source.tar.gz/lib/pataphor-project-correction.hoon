::  Pure one-correction contract. Claims need the engine's canonical join.
/-  pc=pataphor-project-coding
/+  save=cantrip-project-save
|%
++  checks-valid
  |=  checks=(list check:pc)
  ^-  ?
  =/  names=(list [path @tas])
    (turn checks |=(c=check:pc [pax.c name.c]))
  ?&  =(names ~[[/lib/pataphor-workspace-ui/hoon %compile] [/lib/pataphor-workspace-ui/hoon %welcome] [/lib/pataphor-noltbook/hoon %compile] [/lib/pataphor-noltbook/hoon %reply]])
      (levy checks |=(c=check:pc (lte (met 3 detail.c) 2.048)))
      !(levy checks |=(c=check:pc passed.c))
  ==
++  failed
  ::  Saved fields here identify an inscribed failed candidate, not approval.
  |=  r=result:pc
  ^-  ?
  ?&  =(%refused phase.r)  =(`%native-checks-failed reason.r)
      ?=(^ saved.r)  ?=(^ receipt.r)  ?=(^ proposal.r)
      !=(0 u.receipt.r)  !=(0 u.proposal.r)  =(~ preview.r)
      !=(0 desk.u.saved.r)  !=(0 number.u.saved.r)  !=(0 root.u.saved.r)
      =(2 (lent edits.r))  (checks-valid checks.r)
  ==
++  nonce
  |=  r=result:pc
  ^-  @ux
  `@ux`(sham [%pataphor-project-correction-v1 r])
++  source-matches
  |=  [m=manifest:pc r=result:pc]
  ^-  ?
  ?.  (failed r)  %.n
  ?>  ?=(^ saved.r)
  =/  w  working.basis.m
  ?&  =([base-desk.body.snapshot.w base-revision.body.snapshot.w root.w] u.saved.r)
      %+  levy  edits.r
      |=  e=edit:save
      =(`source.e (~(get by sources.m) path.change.e))
  ==
++  guidance
  |=  r=result:pc
  ^-  @t
  %+  rap  3
  :~  '\0aViki correction 1 of 1. Fix the failed candidate below for the unchanged request and checks. No tools or writes. Exact native checks:\0a'
      %+  rap  3
      %+  turn  checks.r
      |=  c=check:pc
      (rap 3 ~[(crip (spud pax.c)) ' ' `@t`name.c ?:(passed.c ' PASS: ' ' FAIL: ') detail.c '\0a'])
  ==
--
