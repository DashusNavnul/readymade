::  /lib/a2a
::
::  Pure A2A border law: decode a foreign message into bounded nouns with a
::  typed refusal for every way it can be wrong, derive collision-safe keys,
::  lower an accepted message into cantrip's existing multiplayer move,
::  project cantrip's inbox status back onto the A2A task lifecycle, and
::  encode responses.  No effects, no state, no scries -- the Gall shell
::  (Phase 2) owns those.  Twinned with gallowglass/src/A2A/Border.gls.
::
/-  a=a2a, ct=cantrip
/+  flect, flect-law, shadow=cantrip-shadow
|%
++  enjs  enjs:format
::
::  ---- keys ----
::
::  Two principals reusing the same contextId/messageId must never collide,
::  and one principal resending one messageId must land on the same move so
::  cantrip's duplicate-move-id law answers instead of a second dispatch.
++  dedupe-key
  |=  [who=principal:a context=@t message=@t]
  ^-  @ux
  `@ux`(shax (jam [%a2a-dedupe-v1 who context message]))
++  task-key
  |=  [who=principal:a context=@t seq=@ud]
  ^-  @ux
  `@ux`(shax (jam [%a2a-task-v1 who context seq]))
++  key-text
  |=  key=@ux
  ^-  @t
  (crip (scow %ux key))
::  a contextId the caller did not supply: minted, opaque, per task.
++  mint-context
  |=  [who=principal:a seq=@ud now=@da]
  ^-  @t
  (key-text `@ux`(shax (jam [%a2a-context-v1 who seq now])))
::
::  ---- version ----
::
::  The spec says an absent A2A-Version means a 0.3 client.  We do not speak
::  0.3 and will not pretend to: absent or foreign versions are refused.
++  version-ok
  |=  version=(unit @t)
  ^-  ?
  ?~  version  %.n
  ?:  =(u.version protocol-version:a)  %.y
  =/  t=tape  (trip u.version)
  ?&  (gte (lent t) 3)
      =("1." (scag 2 t))
  ==
::
::  ---- projection ----
::
::  cantrip's inbox status IS the task lifecycle; this is the only table.
::  %abandoned splits on who abandoned: the caller's own cancel is CANCELED,
::  anything else is FAILED.
++  project-state
  |=  [status=mp-inbox-status:ct reason=(unit @t)]
  ^-  task-state:a
  ?-  status
    %pending    %submitted
    %accepted   %working
    %held       %input-required
    %completed  %completed
    %refused    %rejected
    %abandoned  ?:((caller-cancel reason) %canceled %failed)
  ==
++  cancel-reason-prefix  'a2a-cancel:'
++  caller-cancel
  |=  reason=(unit @t)
  ^-  ?
  ?~  reason  %.n
  =/  pre=tape  (trip cancel-reason-prefix)
  =/  t=tape  (trip u.reason)
  ?&  (gte (lent t) (lent pre))
      =(pre (scag (lent pre) t))
  ==
++  cancel-reason
  |=  who=principal:a
  ^-  @t
  (cat 3 cancel-reason-prefix who)
::  a caller may cancel only what has not started: submitted or held.
++  cancelable
  |=  state=task-state:a
  ^-  ?
  ?=(?(%submitted %input-required) state)
++  terminal
  |=  state=task-state:a
  ^-  ?
  ?=(?(%completed %failed %canceled %rejected) state)
::  one principal never sees another's task; the answer is not-found, not
::  forbidden, so existence does not leak.
++  visible
  |=  [who=principal:a =task:a]
  ^-  ?
  =(who principal.task)
::
::  ---- decode ----
::
++  json-text
  |=  jon=(unit json)
  ^-  (unit @t)
  ?~  jon  ~
  ?.  ?=([%s *] u.jon)  ~
  `p.u.jon
++  bounded-id
  |=  [jon=(unit json) what=@tas]
  ^-  (each @t error:a)
  =/  t=(unit @t)  (json-text jon)
  ?~  t  [%| %invalid (cat 3 'missing-' what)]
  ?:  =(0 (met 3 u.t))  [%| %invalid (cat 3 'empty-' what)]
  ?:  (gth (met 3 u.t) max-id-bytes:a)  [%| %too-large what]
  [%& u.t]
++  optional-id
  |=  [jon=(unit json) what=@tas]
  ^-  (each (unit @t) error:a)
  ?~  jon  [%& ~]
  ?:  ?=(~ u.jon)  [%& ~]
  =/  r=(each @t error:a)  (bounded-id jon what)
  ?-  -.r
    %&  [%& `p.r]
    %|  [%| p.r]
  ==
++  decode-role
  |=  jon=(unit json)
  ^-  (each role:a error:a)
  =/  t=(unit @t)  (json-text jon)
  ?~  t  [%| %invalid 'missing-role']
  ?:  =('ROLE_USER' u.t)  [%& %user]
  ?:  =('ROLE_AGENT' u.t)  [%& %agent]
  [%| %invalid 'unknown-role']
::  a Part is one of text / raw / url / data.  Only text and small JSON data
::  cross the door; raw bytes and URLs are refused before anything durable.
++  decode-part
  |=  jon=json
  ^-  (each part:a error:a)
  ?.  ?=([%o *] jon)  [%| %invalid 'part-not-object']
  =/  obj=(map @t json)  p.jon
  =/  media=@t  (fall (json-text (~(get by obj) 'mediaType')) 'text/plain')
  ?^  (~(get by obj) 'raw')  [%| %unsupported-part 'raw']
  ?^  (~(get by obj) 'url')  [%| %unsupported-part 'url']
  ?^  (~(get by obj) 'data')
    =/  data=json  (need (~(get by obj) 'data'))
    =/  enc=@t  (en:json:html data)
    ?:  (gth (met 3 enc) max-data-bytes:a)  [%| %too-large %data]
    [%& 'application/json' enc]
  =/  text=(unit @t)  (json-text (~(get by obj) 'text'))
  ?~  text  [%| %invalid 'part-without-content']
  ?:  (gth (met 3 u.text) max-text-bytes:a)  [%| %too-large %text]
  [%& media u.text]
++  decode-parts
  |=  jon=(unit json)
  ^-  (each (list part:a) error:a)
  ?~  jon  [%| %invalid 'missing-parts']
  ?.  ?=([%a *] u.jon)  [%| %invalid 'parts-not-array']
  ?~  p.u.jon  [%| %invalid 'empty-parts']
  ?:  (gth (lent p.u.jon) max-parts:a)  [%| %too-large %parts]
  =/  items=(list json)  p.u.jon
  =|  out=(list part:a)
  =|  total=@ud
  |-  ^-  (each (list part:a) error:a)
  ?~  items  [%& (flop out)]
  =/  one=(each part:a error:a)  (decode-part i.items)
  ?:  ?=(%| -.one)  [%| p.one]
  =/  size=@ud  (add total (met 3 text.p.one))
  ?:  (gth size max-text-bytes:a)  [%| %too-large %text]
  $(items t.items, out [p.one out], total size)
::  Message decode.  Metadata, extensions and referenceTaskIds are read for
::  shape only and DISCARDED: nothing in them can become policy, and nothing
::  in them is stored.  A ROLE_AGENT message from a caller is refused: the
::  wire direction is not the caller's to assert.
++  decode-message
  |=  jon=json
  ^-  (each message:a error:a)
  ?.  ?=([%o *] jon)  [%| %invalid 'message-not-object']
  =/  obj=(map @t json)  p.jon
  =/  mid=(each @t error:a)  (bounded-id (~(get by obj) 'messageId') %message-id)
  ?:  ?=(%| -.mid)  [%| p.mid]
  =/  ctx=(each (unit @t) error:a)  (optional-id (~(get by obj) 'contextId') %context-id)
  ?:  ?=(%| -.ctx)  [%| p.ctx]
  =/  tid=(each (unit @t) error:a)  (optional-id (~(get by obj) 'taskId') %task-id)
  ?:  ?=(%| -.tid)  [%| p.tid]
  =/  rol=(each role:a error:a)  (decode-role (~(get by obj) 'role'))
  ?:  ?=(%| -.rol)  [%| p.rol]
  ?:  ?=(%agent p.rol)  [%| %forbidden ~]
  =/  parts=(each (list part:a) error:a)  (decode-parts (~(get by obj) 'parts'))
  ?:  ?=(%| -.parts)  [%| p.parts]
  [%& p.mid p.ctx p.tid p.rol p.parts]
::  SendMessageRequest: the message plus a tenant we do not serve.
++  decode-send
  |=  jon=json
  ^-  (each message:a error:a)
  ?.  ?=([%o *] jon)  [%| %invalid 'request-not-object']
  =/  obj=(map @t json)  p.jon
  =/  tenant=(unit @t)  (json-text (~(get by obj) 'tenant'))
  ?:  &(?=(^ tenant) !=('' u.tenant))  [%| %not-found ~]
  =/  msg=(unit json)  (~(get by obj) 'message')
  ?~  msg  [%| %invalid 'missing-message']
  (decode-message u.msg)
::
::  ---- lowering ----
::
::  The accepted message becomes a %task-share move whose intent is the joined
::  text.  The principal rides in `origin`, the namespaced context in
::  `session-id`; source-ship is `our` because the border speaks for the door,
::  not for the caller -- cantrip's allowlist on `our` is the open/closed switch.
++  joined-text
  |=  parts=(list part:a)
  ^-  @t
  %+  rap  3
  %+  join  `@t`10
  (turn parts |=(p=part:a text.p))
::  a task's whole conversation as one text: messages in order, blank line between
++  history-text
  |=  history=(list message:a)
  ^-  @t
  %+  rap  3
  %+  join  `@t`(rap 3 ~[10 10])
  (turn history |=(m=message:a (joined-text parts.m)))
++  lower-move
  |=  [who=principal:a task-id=@t context=@t msg=message:a now=@da]
  ^-  mp-move:ct
  =/  move-id=@t  (key-text (dedupe-key who context message-id.msg))
  :*  move-id
      %task-share
      [%task-share [task-id (joined-text parts.msg) ~ ~]]
      now
      ~
      `%verbatim
      `context
      `(cat 3 'a2a:' who)
  ==
::
::  ---- encode ----
::
++  state-text
  |=  state=task-state:a
  ^-  @t
  ?-  state
    %submitted       'TASK_STATE_SUBMITTED'
    %working         'TASK_STATE_WORKING'
    %completed       'TASK_STATE_COMPLETED'
    %failed          'TASK_STATE_FAILED'
    %canceled        'TASK_STATE_CANCELED'
    %input-required  'TASK_STATE_INPUT_REQUIRED'
    %rejected        'TASK_STATE_REJECTED'
  ==
++  encode-part
  |=  p=part:a
  ^-  json
  (pairs:enjs ~[['text' s+text.p] ['mediaType' s+media.p]])
++  encode-message
  |=  msg=message:a
  ^-  json
  %-  pairs:enjs
  ^-  (list [@t json])
  :~  ['messageId' s+message-id.msg]
      ['contextId' ?~(context-id.msg ~ s+u.context-id.msg)]
      ['taskId' ?~(task-id.msg ~ s+u.task-id.msg)]
      ['role' s+?:(?=(%user role.msg) 'ROLE_USER' 'ROLE_AGENT')]
      ['parts' a+(turn parts.msg encode-part)]
  ==
::  history is returned newest-last and capped by the caller's historyLength
::  (unset = our max; zero = none), never above max-history.
++  history-window
  |=  [history=(list message:a) length=(unit @ud)]
  ^-  (list message:a)
  =/  cap=@ud  ?~(length max-history:a (min u.length max-history:a))
  =/  n=@ud  (lent history)
  ?:  (lte n cap)  history
  (slag (sub n cap) history)
++  encode-task
  |=  [=task:a length=(unit @ud) now=@da]
  ^-  json
  =/  artifacts=(list json)
    ?~  artifact.task  ~
    :_  ~
    %-  pairs:enjs
    :~  ['artifactId' s+(cat 3 task-id.task '-result')]
        ['name' s+'result']
        ['parts' a+~[(pairs:enjs ~[['text' s+u.artifact.task] ['mediaType' s+'text/plain']])]]
    ==
  %-  pairs:enjs
  ^-  (list [@t json])
  :~  ['id' s+task-id.task]
      ['contextId' s+context-id.task]
      ['status' (pairs:enjs ~[['state' s+(state-text state.task)] ['timestamp' s+(time-text status-at.task)]])]
      ['artifacts' a+artifacts]
      ['history' a+(turn (history-window history.task length) encode-message)]
  ==
::  ISO 8601 without fractional seconds, UTC.
++  time-text
  |=  t=@da
  ^-  @t
  =/  d=date  (yore t)
  =/  pad  |=(n=@ud ^-(tape ?:((lth n 10) ['0' (a-co:co n)] (a-co:co n))))
  %-  crip
  ;:  weld
    (a-co:co y.d)  "-"  (pad m.d)  "-"  (pad d.t.d)  "T"
    (pad h.t.d)  ":"  (pad m.t.d)  ":"  (pad s.t.d)  "Z"
  ==
::
::  ---- errors ----
::
++  http-status
  |=  err=error:a
  ^-  @ud
  ?-  -.err
    %unauthenticated      401
    %forbidden            403
    %not-found            404
    %invalid              400
    %unsupported-part     400
    %conflict             409
    %too-large            413
    %capacity             429
    %unsupported-version  400
    %unimplemented        501
  ==
++  error-code
  |=  err=error:a
  ^-  @t
  ?-  -.err
    %unauthenticated      'UNAUTHENTICATED'
    %forbidden            'PERMISSION_DENIED'
    %not-found            'TaskNotFoundError'
    %invalid              'InvalidRequestError'
    %unsupported-part     'ContentTypeNotSupportedError'
    %conflict             'TaskNotCancelableError'
    %too-large            'InvalidRequestError'
    %capacity             'RESOURCE_EXHAUSTED'
    %unsupported-version  'VersionNotSupportedError'
    %unimplemented        'UnsupportedOperationError'
  ==
++  error-text
  |=  err=error:a
  ^-  @t
  ?-  -.err
    %unauthenticated      'bearer token required'
    %forbidden            'not permitted for this principal'
    %not-found            'task not found'
    %invalid              (cat 3 'invalid request: ' reason.err)
    %unsupported-part     (cat 3 'unsupported part kind: ' reason.err)
    %conflict             (cat 3 'conflict: ' reason.err)
    %too-large            (cat 3 'exceeds limit: ' what.err)
    %capacity             'principal task capacity reached'
    %unsupported-version  (cat 3 'unsupported A2A-Version: ' version.err)
    %unimplemented        (cat 3 'not implemented: ' method.err)
  ==
++  encode-error
  |=  err=error:a
  ^-  json
  (frond:enjs 'error' (pairs:enjs ~[['code' s+(error-code err)] ['message' s+(error-text err)]]))
::
::  ---- the card ----
::
::  Private, truthful, and nothing more: one bearer scheme, one skill, no
::  streaming, no push, no extended card, no provider, no signature.
++  agent-card
  |=  [our=@p base-url=@t]
  ^-  json
  %-  pairs:enjs
  ^-  (list [@t json])
  :~  ['name' s+(cat 3 'pataphor-' (scot %p our))]
      ['description' s+'Pataphor border: foreign tasks are lowered into Cantrip law and judged by Viki; completion is a claim, not canon.']
      ['version' s+'0.1.0']
      ['supportedInterfaces' a+~[(pairs:enjs ~[['url' s+base-url] ['protocolBinding' s+'HTTP+JSON'] ['protocolVersion' s+protocol-version:a]])]]
      ['capabilities' (pairs:enjs ~[['streaming' b+%.n] ['pushNotifications' b+%.n] ['extendedAgentCard' b+%.n]])]
      ['securitySchemes' (frond:enjs 'pataphor-bearer' (frond:enjs 'httpAuthSecurityScheme' (pairs:enjs ~[['scheme' s+'bearer']])))]
      ['securityRequirements' a+~[(frond:enjs 'schemes' (frond:enjs 'pataphor-bearer' a+~))]]
      ['defaultInputModes' a+~[s+'text/plain']]
      ['defaultOutputModes' a+~[s+'text/plain']]
      ['skills' a+~[(pairs:enjs ~[['id' s+'task-share'] ['name' s+'Share a task'] ['description' s+'Submit bounded text as a task for local judgment.'] ['tags' a+~[s+'pataphor' s+'cantrip']]])]]
  ==
::
::  ---- the law outward (flect phase 20) ----
::
::  A receipt (lib/cantrip-shadow) as JSON: tags as sigil text, the verdict,
::  the judge's word.  A verify request is the jam of [law act-vase env
::  claimed]; the answer recomputes it with +verify:flect-law, the same
::  arm any fleet ship runs.  Pure, so the border's answers are provable
::  without the border.
++  flect-receipt-json
  |=  s=shadow:shadow
  ^-  json
  %-  pairs:enjs
  :~  lane+s+lane.s
      act+s+(crip (cells:flect act.s))
      law+s+(crip (cells:flect law.receipt.s))
      fit+b+fit.verdict.receipt.s
      misses+(numb:enjs (lent misses.verdict.receipt.s))
      judged+b+old.s
      why+s+why.s
  ==
+$  flect-ask  [law=law:flect-law act=[p=type q=*] env=* claimed=receipt:flect-law]
++  flect-verify
  |=  body=@
  ^-  (each [fits=? law=@t act=@t] ?(%not-a-jam %not-a-verify-request))
  =/  cued  (mule |.((cue body)))
  ?:  ?=(%| -.cued)  [%| %not-a-jam]
  =/  ask=(unit flect-ask)  ((soft flect-ask) p.cued)
  ?~  ask  [%| %not-a-verify-request]
  :-  %&
  :*  (verify:flect-law law.u.ask act.u.ask env.u.ask claimed.u.ask)
      (crip (cells:flect (tag:flect law.u.ask)))
      (crip (cells:flect (tag:flect q.act.u.ask)))
  ==
--
