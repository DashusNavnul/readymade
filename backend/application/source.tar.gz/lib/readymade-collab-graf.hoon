::  Bounded metadata evidence queue. No source bundle, execution or retry loop.
/-  c=readymade-collab, j=readymade-collab-jobs, pkg=readymade-package
/+  flow=readymade-collab, package=readymade-package,
    pact=readymade-pact, b=readymade-package-build
|%
+$  retained
  $%  [%readymade-package-released request=@t original=pin:pkg release=pin:pkg files=(list file:pkg)]
      [%readymade-package-release-refused request=@t reason=@tas]
      [%readymade-package-release-uncertain request=@t desk=@tas reason=@tas]
      [%readymade-package-inspection-receipt-v1 offer=@ux nonce=@ux pin=pin:pkg manifest=@ux proof=@ux]
      [%readymade-package-inspection-v1 offer=@ux nonce=@ux answer=[%| reason=@tas]]
      [%readymade-package-stage-v1 offer=@ux nonce=@ux answer=stage-result:j]
      [%readymade-package-build-v1 offer=@ux nonce=@ux answer=result:b]
  ==
+$  fact
  $%  [%readymade-collab-evidence-v1 our=@p peer=@p event=envelope:c]
      $:  %readymade-collab-operation-v1
          tid=@ta
          request=@t
          nonce=@ux
          kind=kind:j
          phase=phase:j
          offer=(unit @ux)
          result=(unit retained)
      ==
  ==
+$  entry  [fact=fact request=@t]
+$  pending  (map @ux entry)
+$  change
  $:  pending=pending
      cards=(list card:agent:gall)
      accepted=?
      receipt=(unit receipt:c)
  ==
++  digest
  |=  value=fact
  ^-  @ux
  (shax (jam value))
++  request-of
  |=  value=fact
  ^-  @t
  ?-  -.value
    %readymade-collab-evidence-v1  request.event.value
    %readymade-collab-operation-v1  request.value
  ==
++  owner-of
  |=  value=fact
  ^-  (unit @p)
  ?:  ?=(%readymade-collab-evidence-v1 -.value)  `our.value
  ~
++  event-valid
  |=  event=envelope:c
  ^-  ?
  ?.  (identifier:flow request.event)  %.n
  ?-  -.payload.event
    %package
      ?&  (identifier:flow title.payload.event)
          (bounded-text:flow summary.payload.event 4.096)
          (valid:package offer.payload.event)
      ==
    %propose
      ?&  (identifier:flow reference.payload.event)
          (bounded-text:flow text.payload.event 16.384)
          (valid-terms:pact terms.payload.event)
          =(scope.terms.payload.event (shax text.payload.event))
      ==
    %pact
      ?&  (digest-valid:package id.payload.event)
          (digest-valid:package terms-digest.move.payload.event)
          (bounded-number:pact generation.move.payload.event)
          (bounded-number:pact sequence.move.payload.event)
          ?:  ?=(%approve -.action.move.payload.event)
            (digest-valid:package artifact.action.move.payload.event)
          %.y
      ==
  ==
++  bounded
  |=  value=fact
  ^-  ?
  ?&  (identifier:flow (request-of value))
      (lte (met 3 (jam value)) 131.072)
      (lte (met 3 (scot %uw (jam value))) 131.072)
      ?:  ?=(%readymade-collab-evidence-v1 -.value)
        (event-valid event.value)
      ?&  (gth (met 3 tid.value) 0)
          (lte (met 3 tid.value) 128)
          (digest-valid:package nonce.value)
          ?~(offer.value %.y (digest-valid:package u.offer.value))
          ?~(result.value %.y (lte (met 3 (jam u.result.value)) 32.768))
      ==
  ==
++  event
  |=  [our=@p peer=@p event=envelope:c]
  ^-  (unit fact)
  ?.  !=(our peer)  ~
  =/  value=fact  [%readymade-collab-evidence-v1 our peer event]
  ?.  (bounded value)  ~
  `value
++  operation
  ::  Soft only known compact callbacks. Raw inspection bundles are excluded.
  |=  [our=@p tid=@ta work=job:j]
  ^-  (unit fact)
  ?.  =(owner.command.work (scot %p our))  ~
  =/  result=(unit retained)
    ?~  result.work  ~
    =/  parsed=(unit retained)  ((soft retained) u.result.work)
    ?~  parsed  ~
    `u.parsed
  ?:  &(?=(^ result.work) ?=(~ result))  ~
  =/  value=fact
    [%readymade-collab-operation-v1 tid request.command.work nonce.work kind.work phase.work offer.work result]
  ?.  (bounded value)  ~
  `value
++  read-path
  ::  Existing local exact membership route returns bool. The argument is our
  ::  own bounded canonical jam, never arbitrary external query text.
  |=  value=fact
  ^-  path
  /gx/graf/contains/(scot %uw (jam value))/noun
++  receipt
  |=  [our=@p hash=@ux status=?(%confirmed %refused %uncertain) message=@t]
  ^-  receipt:c
  [(cat 3 'graf:' (scot %ux hash)) 'graf' status our message]
++  queue
  ::  Failure never changes operation state, revocation or Cantrip authority.
  |=  [our=@p held=pending value=fact]
  ^-  change
  =/  hash=@ux  (digest value)
  ?.  (bounded value)
    [held ~ %.n `(receipt our hash %refused 'Graf metadata was refused; no write was sent.')]
  =/  owner=(unit @p)  (owner-of value)
  ?:  &(?=(^ owner) !=(our u.owner))
    [held ~ %.n `(receipt our hash %refused 'Graf metadata owner mismatch; no write was sent.')]
  =/  old=(unit entry)  (~(get by held) hash)
  ?^  old
    ?.  =(value fact.u.old)
      [held ~ %.n `(receipt our hash %refused 'Graf evidence hash conflict; no write was sent.')]
    [held ~ %.y `(receipt our hash %uncertain 'Graf evidence awaits exact readback; nothing was resent.')]
  ?:  (gte ~(wyt by held) 256)
    [held ~ %.n `(receipt our hash %uncertain 'Graf evidence queue is full; operation authority is unchanged.')]
  =/  next=pending  (~(put by held) hash [value (request-of value)])
  =/  card=card:agent:gall
    [%pass /collab/graf/(scot %ux hash) %agent [our %graf] %poke %graf-action !>([%light value])]
  [next ~[card] %.y `(receipt our hash %uncertain 'Graf evidence submitted; immutable readback is not yet verified.')]
++  settle
  ::  observation comes from authenticated local Graf handling, never wire data.
  ::  False means definitive native refusal/absent exact readback after completion.
  ::  Null retains the entry for observation only; it never emits a retry card.
  |=  [our=@p held=pending hash=@ux observation=(unit ?)]
  ^-  change
  ?.  (~(has by held) hash)  [held ~ %.n ~]
  ?~  observation
    [held ~ %.y `(receipt our hash %uncertain 'Graf outcome is uncertain; exact evidence remains pending, without retry.')]
  =/  next=pending  (~(del by held) hash)
  ?:  u.observation
    [next ~ %.y `(receipt our hash %confirmed 'Exact immutable Graf evidence was read back.')]
  [next ~ %.y `(receipt our hash %refused 'Native Graf completion did not retain the exact immutable fact.')]
--
