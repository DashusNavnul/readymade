::  Transparent presentation wrapper outside the composed Viki owners.
::  No saved carrier, endpoint, timer, write command or dispatch is added.
::  Standalone qpc-law remains unchanged. Existing mutation authorization
::  and error responses still belong to that original owner.
/+  status=qpc-native-status, web=pataphor-terminal-http
|%
++  base
  |=  [inner=agent:gall b=bowl:gall]
  ^-  (unit json)
  =/  raw  (raw:status inner b /x/qpc/ark/view)
  ?~  raw  ~
  =/  value  ((soft ,json) u.raw)
  ?~  value  ~
  ?:(=(u.raw u.value) value ~)
++  edit-response
  ::  Replace only the exact existing successful JSON response. Any error,
  ::  unrelated card, additional effect or unknown shape is preserved whole.
  |=  [inner=agent:gall b=bowl:gall id=@ta cards=(list card:agent:gall)]
  ^-  (list card:agent:gall)
  =/  old  (base inner b)
  ?~  old  cards
  ?.  =(cards (json-response:web id 200 u.old))  cards
  =/  next  (view:status inner b)
  ?~  next  cards
  (json-response:web id 200 u.next)
++  agent
  |=  inner=agent:gall
  ^-  agent:gall
  |_  =bowl:gall
  +*  this  .
      ag  ~(. inner bowl)
  ++  on-init
    =^  cards  inner  on-init:ag
    [cards this]
  ++  on-save  on-save:ag
  ++  on-load
    |=  old=vase
    =^  cards  inner  (on-load:ag old)
    [cards this]
  ++  on-poke
    |=  [=mark =vase]
    ?:  =(%handle-http-request mark)
      =/  [id=@ta req=inbound-request:eyre]  !<([@ta inbound-request:eyre] vase)
      =/  url=@t  url.request.req
      ?:  &(=('GET' method.request.req) =('/apps/qpc-ark/state' url))
        ?.  &(authenticated.req =(our.bowl src.bowl))
          [(failure:web id 403 'Owner authentication required.') this]
        =/  shown  (view:status inner bowl)
        ?~  shown  [(failure:web id 503 'Native QPC view unavailable.') this]
        [(json-response:web id 200 u.shown) this]
      =^  cards  inner  (on-poke:ag mark vase)
      ?.  ?&  authenticated.req  =(our.bowl src.bowl)
              =('POST' method.request.req)  =('/apps/qpc-ark/edit' url)
          ==  [cards this]
      [(edit-response inner bowl id cards) this]
    =^  cards  inner  (on-poke:ag mark vase)
    [cards this]
  ++  on-peek
    |=  =path
    ?:  =(/x/qpc/ark/view path)
      ?.  =(our.bowl src.bowl)  ~
      =/  shown  (view:status inner bowl)
      ?~  shown  ~
      ``noun+!>(u.shown)
    (on-peek:ag path)
  ++  on-watch
    |=  =path
    =^  cards  inner  (on-watch:ag path)
    [cards this]
  ++  on-leave
    |=  =path
    =^  cards  inner  (on-leave:ag path)
    [cards this]
  ++  on-agent
    |=  [=wire =sign:agent:gall]
    =^  cards  inner  (on-agent:ag wire sign)
    [cards this]
  ++  on-arvo
    |=  [=wire =sign-arvo]
    =^  cards  inner  (on-arvo:ag wire sign-arvo)
    [cards this]
  ++  on-fail
    |=  [=term =tang]
    =^  cards  inner  (on-fail:ag term tang)
    [cards this]
  --
--
