::  Item 19: settled coding grants leave Cantrip's 512-grant and 8,192-record
::  walls for a Clay store, so the walls count only live work.
::
::  A grant is settled when it is revoked, every call record under it is
::  finished, cancelled or rejected (never running or unknown), and no
::  candidate under it is still in progress. Each settled grant becomes one
::  immutable file /grant/<id>/noun on the private dead desk
::  %native-grant-history, holding the grant and all its records, plus one
::  index file per call, /call/<digest of session, request, call id>/noun.
::
::  Nothing leaves Cantrip until its file reads back exactly equal to what
::  Cantrip holds, so an unknown write outcome is resolved by reading, never by
::  writing again. A call found in the index is refused on submit, so an
::  archived call is never run a second time.
/-  nc=native-coding
/+  contract=cantrip-native-coding-contract
|%
++  desk  %native-grant-history
++  batch  16
+$  entry
  [%native-grant-archive-v1 id=@ux scope=scope:contract records=(list [key=@ux record=record:contract])]
+$  index  [%native-call-archived-v1 grant=@ux key=@ux]
+$  plan  [write=(list entry) verified=(list @ux)]
++  call-digest
  |=  r=tool-request:nc
  ^-  @ux
  (shax (jam [%native-call-v1 session.context.r request.context.r call-id.r]))
++  grant-path  |=(id=@ux `path`/grant/(scot %ux id)/noun)
++  call-path  |=(d=@ux `path`/call/(scot %ux d)/noun)
++  at-path
  |=  [our=@p at=@da pax=path]
  ^-  path
  (weld /(scot %p our)/[desk]/(scot %da at) pax)
++  archived
  ::  One cheap existence read per new call (a missing desk answers no).
  |=  [our=@p at=@da r=tool-request:nc]
  ^-  ?
  .^(? %cu (at-path our at (call-path (call-digest r))))
++  terminal
  |=  r=record:contract
  ^-  ?
  ?=(?(%finished %cancelled %rejected) stage.r)
++  settled
  ::  busy: grants of candidates that are not yet applied or refused.
  |=  [tools=organ:contract busy=(set @ux) id=@ux]
  ^-  ?
  =/  s=(unit scope:contract)  (~(get by grants.tools) id)
  ?~  s  %.n
  ?~  revoked.u.s  %.n
  ?:  (~(has in busy) id)  %.n
  (levy ~(val by records.tools) |=(r=record:contract |(!=(id grant.r) (terminal r))))
++  entry-for
  |=  [tools=organ:contract id=@ux]
  ^-  entry
  =/  rows=(list [key=@ux record=record:contract])
    (skim ~(tap by records.tools) |=(row=[key=@ux record=record:contract] =(id grant.record.row)))
  :*  %native-grant-archive-v1  id  (~(got by grants.tools) id)
      (sort rows |=([a=[key=@ux record=record:contract] b=[key=@ux record=record:contract]] (lth key.a key.b)))
  ==
++  store
  ::  The store must exist, be dead, private, and have no reins or watchers.
  |=  [our=@p at=@da]
  ^-  ?
  =/  domes=cone:clay  .^(cone:clay %cx /(scot %p our)//(scot %da at)/domes)
  =/  d  (~(get by domes) [our desk])
  ?~  d  %.n
  ?.  &(=(%dead liv.u.d) =(~ ren.u.d) =(~ wic.u.d))  %.n
  =/  rules=[r=dict:clay w=dict:clay]
    .^([r=dict:clay w=dict:clay] %cp /(scot %p our)/[desk]/(scot %da at))
  &(=([%white ~ ~] rul.r.rules) =([%white ~ ~] rul.w.rules))
++  held
  ::  Exact readback of one grant and every call index it names.
  |=  [our=@p at=@da e=entry]
  ^-  ?(%absent %equal %conflict)
  =/  pax=path  (at-path our at (grant-path id.e))
  ?.  .^(? %cu pax)  %absent
  ?.  =(.^(* %cx pax) e)  %conflict
  =/  calls-ok=?
    %+  levy  records.e
    |=  row=[key=@ux record=record:contract]
    =/  p=path  (at-path our at (call-path (call-digest request.record.row)))
    ?&  .^(? %cu p)
        =(.^(* %cx p) `index`[%native-call-archived-v1 id.e key.row])
    ==
  ?:(calls-ok %equal %conflict)
++  plan-for
  ::  Up to one batch of settled grants: write the absent ones, mark the ones
  ::  whose files already read back equal as verified. A conflict refuses.
  |=  [our=@p at=@da tools=organ:contract busy=(set @ux)]
  ^-  (each plan @tas)
  ?.  (store our at)  [%| %grant-archive-store-unavailable]
  =/  ids=(list @ux)
    %+  scag  batch
    (sort (skim ~(tap in ~(key by grants.tools)) |=(id=@ux (settled tools busy id))) lth)
  =|  write=(list entry)
  =|  verified=(list @ux)
  |-  ^-  (each plan @tas)
  ?~  ids  [%& (flop write) (flop verified)]
  =/  e=entry  (entry-for tools i.ids)
  =/  seen  (held our at e)
  ?-  seen
    %absent    $(ids t.ids, write [e write])
    %equal     $(ids t.ids, verified [i.ids verified])
    %conflict  [%| %grant-archive-conflict]
  ==
++  drop
  |=  [tools=organ:contract id=@ux]
  ^-  organ:contract
  :-  (~(del by grants.tools) id)
  ^-  (map @ux record:contract)
  %-  malt
  (skip ~(tap by records.tools) |=(row=[key=@ux record=record:contract] =(id grant.record.row)))
++  write
  ::  One insert-only Clay commit: each grant file and each call index.
  |=  es=(list entry)
  ^-  card:agent:gall
  =/  changes=(list [path miso:clay])
    %-  zing
    %+  turn  es
    |=  e=entry
    :-  [(grant-path id.e) %ins %noun !>(e)]
    %+  turn  records.e
    |=  row=[key=@ux record=record:contract]
    [(call-path (call-digest request.record.row)) %ins %noun !>(`index`[%native-call-archived-v1 id.e key.row])]
  [%pass /grant-archive/write %arvo %c [%info desk %& changes]]
--
