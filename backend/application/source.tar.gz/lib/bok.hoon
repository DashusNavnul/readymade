::  /lib/bok.hoon
::
::  BOK GROUNDING (Phase 1). Pure. The corpus grounds the Nick seat: given a
::  task in plain words, the ship computes which corpus OPERATORS the corpus
::  itself points to -- by set intersection over a content-derived containment
::  index, with no embeddings and no model. Diomora's reverse-BOK, minimal:
::  a word IS its own key (a Hoon cord is its little-endian ASCII atom), chunks
::  down-link to the words they contain, and an operator's gravity for a task is
::  the weighted overlap between the task's chunks and the operator's anchor
::  chunks, doubled when the concept spans more than one document (the
::  cross-corpus signal). Where nothing converges the grounding SCATTERS -- the
::  honest "the corpus has nothing to say here". Advisory only: gravity ranks,
::  it never authorizes; execution admission stays the honesty lattice's job.
::  COMPUTED -- deterministic, exact, no now/entropy.
::
|%
+$  key       @ud                        ::  a chunk id
+$  position  ?(%opening %closing %body)
+$  side      ?(%qpc %rudolph)
+$  node
  $:  =position
      doc=@t                             ::  owning document name
      =side
      toks=(list @t)                     ::  ordered lowercased word tokens
  ==
+$  bok
  $:  nodes=(map key node)               ::  chunk id -> node
      windex=(jar @t key)                ::  word -> chunk ids that contain it
      aidx=(map @tas (set key))          ::  operator -> its anchor chunk ids
      avocab=(set @t)                    ::  every word of every anchor phrase --
  ==                                     ::  DF-vetted at curation, never noise
+$  chunk-in  [=key =node]               ::  an ingest pair (faced, for access)
+$  evidence
  $:  =key
      =position
      doc=@t
  ==
+$  row
  $:  op=@tas
      gravity=@ud
      ev=(list evidence)
  ==
+$  grounding
  $:  scatter=?
      rows=(list row)
  ==
::  ---- tuning ----
::  gravity is the RAW weighted overlap (hits x position-weight x cross-doc
::  multiplier). A fixed scale saturates any cap on a real corpus (learned on
::  3.065 live chunks: every op pegged the cap, ranking destroyed) -- raw
::  scores discriminate; the cap is only an overflow guard.
++  cap       1.000.000
++  min-tok   4                          ::  task words shorter than this = noise
++  pos-edge  2                          ::  opening/closing structural weight
++  pos-body  1
++  cross-x   2                          ::  >=2 documents -> cross-corpus doubling
++  floor     10                         ::  total gravity < floor -> scatter
::  a task word carried by more than a tenth of the corpus is noise ("what",
::  "capital") -- the same DF discipline the anchors pass, applied at query
::  time. The absolute floor keeps small fixtures un-gutted.
++  max-df    |=(n=@ud (max 25 (div n 10)))
::  ---- tokenization ----
++  lc  |=(c=@ ?:(&((gte c 'A') (lte c 'Z')) (add c 32) c))
++  wc                                   ::  is c a word character?
  |=  c=@  ^-  ?
  ?|  &((gte c 'a') (lte c 'z'))  &((gte c 'A') (lte c 'Z'))
      &((gte c '0') (lte c '9'))  =(c '-')  =(c '_')  =(c 39)
  ==
++  tok                                  ::  cord -> lowercased word tokens
  |=  t=@t  ^-  (list @t)
  =/  cs=tape  (trip t)
  =|  cur=tape                           ::  reversed current word
  =|  out=(list @t)                      ::  reversed output
  |-  ^-  (list @t)
  ?~  cs
    (flop ?~(cur out [(crip (flop cur)) out]))
  ?:  (wc i.cs)
    $(cs t.cs, cur [(lc i.cs) cur])
  ?~  cur  $(cs t.cs)
  $(cs t.cs, cur ~, out [(crip (flop cur)) out])
::  ---- phrase adjacency ----
++  has-phrase                           ::  does phrase appear as an adjacent run?
  |=  [toks=(list @t) phrase=(list @t)]  ^-  ?
  ?~  phrase  %.n
  =/  n=@  (lent phrase)
  |-  ^-  ?
  ?:  (lth (lent toks) n)  %.n
  ?:  =(phrase (scag n toks))  %.y
  $(toks (slag 1 toks))
++  any-phrase
  |=  [toks=(list @t) phrases=(list (list @t))]  ^-  ?
  ?~  phrases  %.n
  ?:  (has-phrase toks i.phrases)  %.y
  $(phrases t.phrases)
::  ---- build the index from chunks + anchors ----
::  chunks: (list [key node]) ; anchors: op -> list of phrases (each a token list)
++  build
  |=  [chunks=(list chunk-in) anchors=(map @tas (list (list @t)))]
  ^-  bok
  =/  av=(set @t)
    =|  acc=(set @t)
    =/  ps=(list (list (list @t)))  ~(val by anchors)
    |-  ^-  (set @t)
    ?~  ps  acc
    =/  ws=(list @t)  `(list @t)`(zing i.ps)
    $(ps t.ps, acc (~(gas in acc) ws))
  :*  (~(gas by *(map key node)) chunks)
      (mk-windex chunks)
      (mk-aidx chunks anchors)
      av
  ==
++  mk-windex
  |=  chunks=(list chunk-in)  ^-  (jar @t key)
  =|  j=(jar @t key)
  |-  ^-  (jar @t key)
  ?~  chunks  j
  =/  ws=(list @t)  ~(tap in (silt toks.node.i.chunks))
  =.  j
    |-  ^-  (jar @t key)
    ?~  ws  j
    $(ws t.ws, j (~(add ja j) i.ws key.i.chunks))
  $(chunks t.chunks)
++  mk-aidx
  |=  [chunks=(list chunk-in) anchors=(map @tas (list (list @t)))]
  ^-  (map @tas (set key))
  =/  ops=(list [op=@tas phrases=(list (list @t))])  ~(tap by anchors)
  =|  out=(map @tas (set key))
  |-  ^-  (map @tas (set key))
  ?~  ops  out
  =.  out  (~(put by out) op.i.ops (chunks-for chunks phrases.i.ops))
  $(ops t.ops)
++  chunks-for                           ::  chunk ids matching any of the phrases
  |=  [chunks=(list chunk-in) phrases=(list (list @t))]  ^-  (set key)
  =|  acc=(set key)
  |-  ^-  (set key)
  ?~  chunks  acc
  =?  acc  (any-phrase toks.node.i.chunks phrases)
    (~(put in acc) key.i.chunks)
  $(chunks t.chunks)
::  ---- the grounding: task -> ranked operators + evidence ----
++  mk-profile                           ::  chunk -> count of distinct task words in it
  |=  [b=bok ttoks=(list @t)]  ^-  (map key @ud)
  =/  df-lim=@ud  (max-df ~(wyt by nodes.b))
  =/  words=(list @t)  ~(tap in (silt ttoks))
  =|  prof=(map key @ud)
  |-  ^-  (map key @ud)
  ?~  words  prof
  =/  hits=(list key)  (~(get ja windex.b) i.words)
  ::  corpus-common words are noise -- UNLESS curated into an anchor phrase
  ::  (learned live: "microvita" itself sat just over the 10% line).
  ?:  ?&  (gth (lent hits) df-lim)
          !(~(has in avocab.b) i.words)
      ==
    $(words t.words)
  =.  prof
    |-  ^-  (map key @ud)
    ?~  hits  prof
    $(hits t.hits, prof (~(put by prof) i.hits +((~(gut by prof) i.hits 0))))
  $(words t.words)
::  an operator with no anchor chunks (corpus-silent, or no match) naturally
::  scores 0 with empty evidence -- no special-casing needed.
++  score-op
  |=  [b=bok op=@tas profile=(map key @ud)]  ^-  row
  =/  al=(list key)  ~(tap in (~(gut by aidx.b) op *(set key)))
  ::  cross-corpus multiplier: distinct docs across the FULL anchor set
  =/  docs=(set @t)
    %+  roll  al
    |=  [k=key s=(set @t)]
    (~(put in s) doc:(~(got by nodes.b) k))
  =/  mult=@ud  ?:((gte ~(wyt in docs) 2) cross-x 1)
  ::  base score = sum over (anchor chunks in the task profile) of hits * posweight
  =/  base=@ud
    %+  roll  al
    |=  [k=key acc=@ud]
    =/  h=@ud  (~(gut by profile) k 0)
    ?:  =(0 h)  acc
    =/  n=node  (~(got by nodes.b) k)
    =/  pw=@ud  ?:(?=(?(%opening %closing) position.n) pos-edge pos-body)
    (add acc (mul h pw))
  ::  DENSITY, not bulk: normalize by anchor-set size, or operators with
  ::  hundreds of anchor chunks hoover generic overlap and drown small precise
  ::  concepts (learned live: resonance's 5 chunks lost to a-ia's 170).
  =/  g=@ud  (min cap (div (mul (mul base mult) 100) (max 1 (lent al))))
  =/  ev=(list evidence)
    =/  hitk=(list key)  (skim al |=(k=key (gth (~(gut by profile) k 0) 0)))
    %+  turn  (scag 3 hitk)
    |=  k=key
    =/  n=node  (~(got by nodes.b) k)
    [k position.n doc.n]
  [op g ev]
++  ground
  |=  [b=bok task=@t vocab=(list @tas)]  ^-  grounding
  =/  ttoks=(list @t)  (skim (tok task) |=(w=@t (gte (met 3 w) min-tok)))
  =/  profile=(map key @ud)  (mk-profile b ttoks)
  =/  rows=(list row)  (turn vocab |=(op=@tas (score-op b op profile)))
  =/  sorted=(list row)  (sort rows |=([a=row c=row] (gth gravity.a gravity.c)))
  =/  total=@ud  (roll sorted |=([r=row s=@ud] (add gravity.r s)))
  [scatter=(lth total floor) rows=sorted]
::  ---- convenience: a row's gravity by op (for callers/proofs) ----
++  grav-of
  |=  [rows=(list row) op=@tas]  ^-  @ud
  ?~  rows  0
  ?:  =(op op.i.rows)  gravity.i.rows
  $(rows t.rows)
--
