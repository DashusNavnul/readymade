::  Cantrip wrapper: preserve the whole inner agent and replace one exact
::  candidate Ford card with a committed, once-only native moon order.
/-  w=native-coding-worker, nc=native-coding,
    b=boks
/+  owner=native-coding-worker-owner, law=native-coding-worker,
    journal=native-coding-worker-journal, read=native-coding-worker-owner-read,
    peer=native-coding-worker-runtime, source=native-coding-worker-source,
    accept=native-coding-accept, allowance=native-coding-check-authorization
|%
+$  state
  [%native-coding-worker-parent-v1 engaged=? owner=state:owner pending=(map @ux @ux) failures=(map @ux @tas)]
+$  parent-state  state
+$  execution-pin  [desk=@tas revision=@ud root=@uv]
+$  execution-state
  [%native-coding-worker-execution-v1 selected=? source=(unit execution-pin)]
+$  outcome
  $%  [%checked report=report:accept]
      [%refused reason=@tas]
      [%unknown reason=@tas]
  ==
+$  completion  [candidate=@ux ticket=@ux outcome=outcome]
+$  cleaner  $-([our=@p now=@da order=order:w] (list card:agent:gall))
++  empty  ^-(state [%native-coding-worker-parent-v1 %.n empty:owner ~ ~])
++  execution-empty
  ^-(execution-state [%native-coding-worker-execution-v1 %.n ~])
++  execution-valid
  |=  chosen=execution-state
  ^-  ?
  ?~  source.chosen  %.y
  ?&  selected.chosen  !=(0 desk.u.source.chosen)
      !=(%base desk.u.source.chosen)  (lte (met 3 desk.u.source.chosen) 63)
      (gth revision.u.source.chosen 0)  !=(0 root.u.source.chosen)
  ==
++  execution-source-with
  |=  [b=bowl:gall chosen=execution-state]
  ^-  (each beak @tas)
  ?>  (execution-valid chosen)
  ?.  selected.chosen  [%& byk.b(r da+now.b)]
  ?~  source.chosen  [%| %worker-execution-revoked]
  =/  pin=execution-pin  u.source.chosen
  =/  domes=cone:clay  .^(cone:clay %cx /(scot %p our.b)//(scot %da now.b)/domes)
  =/  found  (~(get by domes) [our.b desk.pin])
  ?~  found  [%| %worker-execution-source-changed]
  ?.  (~(has by hit.u.found) revision.pin)  [%| %worker-execution-source-changed]
  =/  at=path  /(scot %p our.b)/[desk.pin]/(scot %ud revision.pin)
  ?.  =(root.pin .^(@uv %cz at))  [%| %worker-execution-source-changed]
  ?.  %+  levy  `(list path)`~[/ted/ph/native-coding-tool/hoon /ted/ph/native-coding-worker-export/hoon /ted/ph/native-coding-worker-tool-export/hoon]
      |=(pax=path .^(? %cu (weld at pax)))
    [%| %worker-execution-source-changed]
  [%& [our.b desk.pin ud+revision.pin]]
++  execution-source
  |=  b=bowl:gall
  ^-  (each beak @tas)
  (execution-source-with b .^(execution-state %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/worker/execution/noun))
++  execution-bear-with
  |=  [b=bowl:gall chosen=execution-state]
  ^-  (each bear:khan @tas)
  =/  picked  (execution-source-with b chosen)
  ?:  ?=(%| -.picked)  [%| p.picked]
  [%& ?:(selected.chosen p.picked q.byk.b)]
++  execution-bear
  |=  b=bowl:gall
  ^-  (each bear:khan @tas)
  (execution-bear-with b .^(execution-state %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/worker/execution/noun))
++  wire-for
  |=([key=@ux kind=@tas] ^-(wire /native-worker-owner/(scot %ux key)/[kind]))
++  reclaim-grace  ~s30
++  no-such-job
  ::  The worker answered that it holds no job for a sent order. Its inbox refuses
  ::  an order past its expiry, which is the order's deadline, so past that
  ::  deadline the job can never start and no worker receipt can ever come. This
  ::  records what the worker would have: the outcome is unconfirmed, never success.
  |=  [o=order:w key=@ux at=@da]
  ^-  result:w
  :*  %native-coding-worker-result-v1  key  worker.pairing.o  generation.pairing.o
      toolchain.pairing.o  source.o  namespace.o  ~  issued.o  at
      [%refused %worker-deadline-unconfirmed 'The worker holds no such job.']
  ==
++  wake
  |=  [key=@ux kind=@tas at=@da]
  ^-  card:agent:gall
  [%pass (wire-for key kind) %arvo %b %wait at]
++  apply-card
  ::  Arvo callbacks inherit the remote event's attribution. A self poke
  ::  commits the receipt first and reaches the existing owner-only handler.
  |=  [b=bowl:gall ticket=@ux]
  ^-  card:agent:gall
  [%pass (wire-for ticket %apply) %agent [our.b dap.b] %poke %noun !>([%native-coding-worker-apply-v1 ticket])]
++  close
  |=(key=@ux ^-(card:agent:gall [%give %kick ~[(offer-path:peer key)] ~]))
++  valid
  |=  [our=@p s=state]
  ^-  ?
  ?&  (valid:owner our owner.s)  (lte ~(wyt by pending.s) capacity:journal)
      (levy ~(tap by pending.s) |=([ticket=@ux id=@ux] &((identifier:law ticket) (identifier:law id))))
      (levy ~(tap by failures.s) |=([ticket=@ux reason=@tas] &((~(has by pending.s) ticket) !=(0 reason) (lte (met 3 reason) 128))))
      %+  levy  ~(val by journal.owner.s)
      |=  r=record:w
      =(`candidate.order.r (~(get by pending.s) ticket.order.r))
  ==
++  intercept
  ::  The already-admitted inner transition is authoritative. Match the
  ::  entire returned card, including its desk, wire and typed argument.
  |=  [bowl=bowl:gall before=record:accept after=record:accept cards=(list card:agent:gall)]
  ^-  [ticket=@ux cards=(list card:agent:gall)]
  =/  retry=?  =(`%candidate-recheck-scheduled reason.before)
  ?>  &((check-scheduled:accept before) =(after before(reason ?:(retry `%candidate-recheck ~))))
  =/  id=@ux  id.candidate.after
  =/  expected=card:agent:gall
    [%pass (wire-for:accept id ?:(retry %checks-retry %checks)) %arvo %k %fard q.byk.bowl %ph-native-coding-candidate %noun !>(`id)]
  ?>  =(1 (lent (skim cards |=(c=card:agent:gall =(expected c)))))
  =/  ticket=@ux  (ticket:owner after)
  [ticket (turn cards |=(c=card:agent:gall ?:(=(expected c) (wake ticket %start (add now.bowl ~s1)) c)))]
++  agent  |=(inner=agent:gall (agent-with current:read revoke-export:source inner))
++  capacity-completion
  |=  [inner=agent:gall b=bowl:gall s=state id=@ux]
  ^-  (unit completion)
  ?.  &(engaged.s (gte ~(wyt by pending.s) capacity:journal))  ~
  =/  r  (candidate:read inner b id)
  ?~  r  ~
  ?.  (check-dispatched:accept u.r)  ~
  =/  ticket=@ux  (ticket:owner u.r)
  ?:  (~(has by pending.s) ticket)  ~
  `[id ticket [%refused %worker-capacity]]
++  agent-with
  ::  Only native proof supplies inert readers/cleanup. No runtime command can.
  |=  [inspect=reader:read cleanup=cleaner inner=agent:gall]
  =/  state=state  empty
  =/  execution=execution-state  execution-empty
  ^-  agent:gall
  |_  =bowl:gall
  +*  this  .
      ag  ~(. inner bowl)
      current
        |=  [o=order:w canonical=?]
        ^-  (each scope:w @tas)
        ?.  =(`pairing.o pairing.owner.state)  [%| %worker-not-selected]
        =/  facts  (inspect inner bowl candidate.o canonical)
        ?:  ?=(%| -.facts)  [%| p.facts]
        =/  auth=scope:w  (scope:read pairing.o p.facts)
        ?:((authorized:law auth o) [%& auth] [%| %worker-authority-changed])
      exporting
        |=  key=@ux
        ^-  (unit order:w)
        =/  found  (~(get by journal.owner.state) key)
        ?~  found  ~
        =/  r=record:w  u.found
        ?.  &(!sent.r =(%reserved phase.r) !(~(has by failures.state) ticket.order.r) (lth now.bowl deadline.order.r))  ~
        =/  auth  (current order.r %.y)
        ?:(?=(%& -.auth) `order.r ~)
      forget
        |=  [key=@ux o=order:w]
        ^-  (list card:agent:gall)
        [(close key) (cleanup our.bowl now.bowl o)]
      reclaim
        ::  Past its deadline the worker answers a fresh watch with a terminal
        ::  refusal. Only that receipt frees the slot (journal ++busy), and a job
        ::  that went unknown on the worker never publishes on its own.
        |=  [key=@ux o=order:w]
        ^-  (list card:agent:gall)
        =/  peer-dock=dock  [worker.pairing.o %native-coding-worker]
        :~  [%pass (wire-for key %result) %agent peer-dock %leave ~]
            [%pass (wire-for key %result) %agent peer-dock %watch (result-path:peer key)]
        ==
      uncertain
        |=  [ticket=@ux reason=@tas cards=(list card:agent:gall)]
        ^-  (quip card:agent:gall _this)
        ?:  (~(has by failures.state) ticket)  [cards this]
        :_  this(state state(failures (~(put by failures.state) ticket reason)))
        (weld cards ~[(apply-card bowl ticket)])
      reconcile
        ::  This only narrows authority. New dispatch always uses canonical
        ::  reads after Behn has committed the preceding state transition.
        |=  cards=(list card:agent:gall)
        ^-  (quip card:agent:gall _this)
        =/  rows=(list [@ux record:w])  ~(tap by journal.owner.state)
        =/  next=parent-state  state
        |-
        ?~  rows  [cards this(state next)]
        =/  [key=@ux r=record:w]  i.rows
        ?:  |(?=(?(%checked %refused) phase.r) &(=(%revoked phase.r) (~(has by failures.next) ticket.order.r)))
          $(rows t.rows)
        =/  auth=(each scope:w @tas)
          ?:(=(%revoked phase.r) [%| %worker-authority-changed] (current order.r %.n))
        ?:  ?=(%& -.auth)  $(rows t.rows)
        =.  next  next(owner owner.next(journal (~(put by journal.owner.next) key r(phase %revoked, reason `p.auth))))
        =.  cards  (weld cards (forget key order.r))
        ?:  (~(has by failures.next) ticket.order.r)  $(rows t.rows)
        =.  next  next(failures (~(put by failures.next) ticket.order.r p.auth))
        $(rows t.rows, cards (weld cards ~[(apply-card bowl ticket.order.r)]))
      complete
        |=  ticket=@ux
        ^-  (unit completion)
        =/  id  (~(get by pending.state) ticket)
        ?~  id  ~
        =/  candidate  (candidate:read inner bowl u.id)
        ?~  candidate  ~
        ?.  &((check-dispatched:accept u.candidate) =(ticket (ticket:owner u.candidate)))  ~
        =/  failed  (~(get by failures.state) ticket)
        ?^  failed
          ?:  ?=(?(%worker-execution-revoked %worker-execution-source-changed) u.failed)
            `[u.id ticket [%refused u.failed]]
          `[u.id ticket [%unknown u.failed]]
        =/  rows=(list [@ux record:w])
          (skim ~(tap by journal.owner.state) |=([key=@ux r=record:w] =(ticket ticket.order.r)))
        ?.  ?=([* ~] rows)  ~
        =/  [key=@ux r=record:w]  i.rows
        =/  auth  (current order.r %.y)
        ?:  ?=(%| -.auth)  `[u.id ticket [%unknown p.auth]]
        ?~  result.r  ~
        ?:  =(%refused phase.r)
          ?>  ?=(%refused -.outcome.u.result.r)
          `[u.id ticket [%refused reason.outcome.u.result.r]]
        =/  report  (report:owner owner.state p.auth key u.candidate)
        ?:  ?=(%| -.report)  `[u.id ticket [%unknown p.report]]
        `[u.id ticket [%checked p.report]]
  ++  on-init
    =^  cards  inner  on-init:ag
    [cards this]
  ++  on-save  !>([%native-coding-worker-parent-save-v2 state execution on-save:ag])
  ++  on-load
    |=  old=vase
    =/  saved=[state=parent-state execution=execution-state inner=vase]
      ?:  ?=([%native-coding-worker-parent-save-v2 *] q.old)
        =/  parsed
          !<([%native-coding-worker-parent-save-v2 state=parent-state execution=execution-state inner=vase] old)
        +.parsed
      ?.  ?=([%native-coding-worker-parent-save-v1 *] q.old)  [empty execution-empty old]
      ::  Gall supplies the original typed save carrier. Extract its existing
      ::  inner vase through that type; never mold-walk an opaque type noun.
      =/  parsed
        !<([%native-coding-worker-parent-save-v1 state=parent-state inner=vase] old)
      [state.parsed execution-empty inner.parsed]
    ?>  &((valid our.bowl state.saved) (execution-valid execution.saved))
    =.  execution  execution.saved
    =.  state  state.saved(owner state:(recover:owner owner.state.saved))
    ::  A pre-export start ticket is also unconfirmed on reload. Never let
    ::  its already queued Behn wake silently create fresh work afterward.
    =/  interrupted=(list [@ux @ux])
      %+  skim  ~(tap by pending.state)
      |=  [ticket=@ux id=@ux]
      !(lien ~(val by journal.owner.state) |=(r=record:w &(=(ticket ticket.order.r) ?=(^ result.r))))
    =.  failures.state
      %-  ~(gas by failures.state)
      (turn (skim interrupted |=([ticket=@ux id=@ux] !(~(has by failures.state) ticket))) |=([ticket=@ux id=@ux] [ticket %worker-reload-unconfirmed]))
    =^  cards  inner  (on-load:ag inner.saved)
    =.  cards  (weld cards (turn interrupted |=([ticket=@ux id=@ux] (apply-card bowl ticket))))
    =/  rows=(list [@ux record:w])  ~(tap by journal.owner.state)
    |-
    ?~  rows  [cards this]
    =/  [key=@ux r=record:w]  i.rows
    ?^  result.r  $(rows t.rows)
    $(rows t.rows, cards [(close key) cards])
  ++  on-poke
    |=  [=mark =vase]
    ?:  &(?=(%noun mark) ?=([%qpc-assessment-worker-start-v1 @] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  id=@ux  +.q.vase
      =/  managed  (assessment-entry:read inner bowl id)
      ?>  ?=(^ managed)
      ?>  &(engaged.state =(%staged phase.row.u.managed))
      ?>  ?=(~ (ordinary:read inner bowl id))
      =/  facts  (inspect inner bowl id %.y)
      ?>  ?=(%& -.facts)
      =/  ticket=@ux  (ticket:owner candidate.p.facts)
      =/  existing  (~(get by pending.state) ticket)
      ?^  existing
        ?>  =(id u.existing)
        `this
      ?>  (lth ~(wyt by pending.state) capacity:journal)
      [~[(wake ticket %start (add now.bowl ~s1))] this(state state(pending (~(put by pending.state) ticket id)))]
    ?:  &(?=(%noun mark) ?=([%native-coding-worker-execution-select-v1 *] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  parsed  ((soft ,[%native-coding-worker-execution-select-v1 source=(unit execution-pin)]) q.vase)
      ?>  &(?=(^ parsed) =(q.vase u.parsed))
      =/  chosen=execution-state  [%native-coding-worker-execution-v1 %.y source.u.parsed]
      ?>  (execution-valid chosen)
      =/  checked  (execution-source-with bowl chosen)
      ?>  ?~(source.chosen %.y ?=(%& -.checked))
      `this(execution chosen)
    ?:  &(?=(%noun mark) ?=([%native-coding-worker-receipt-reclaim-v1 @] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  key=@ux  +.q.vase
      =/  found  (~(get by journal.owner.state) key)
      ?>  ?=(^ found)
      ?>  &(sent.u.found ?=(~ result.u.found) (gte now.bowl deadline.order.u.found))
      [(reclaim key order.u.found) this]
    ?:  &(?=(%noun mark) ?=([%native-coding-worker-parent-configure-v1 *] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  parsed  ((soft ,[%native-coding-worker-parent-configure-v1 pairing=(unit pairing:w)]) q.vase)
      ?>  &(?=(^ parsed) =(u.parsed q.vase))
      =/  changed  (configure:owner our.bowl src.bowl owner.state pairing.u.parsed)
      ?>  ?=(%& -.changed)
      ?:  &(engaged.state =(owner.state p.changed))  `this
      =/  cards=(list card:agent:gall)
        (zing (turn ~(tap by journal.owner.state) |=([key=@ux r=record:w] (forget key order.r))))
      =.  state  state(engaged %.y, owner p.changed)
      (reconcile cards)
    =^  cards  inner  (on-poke:ag mark vase)
    (reconcile cards)
  ++  on-watch
    |=  =path
    ?.  ?=([%native-coding %worker %order @ ~] path)
      =^  cards  inner  (on-watch:ag path)
      [cards this]
    =/  key  (key:read i.t.t.t.path)
    ?>  ?=(^ key)
    =/  held  (~(get by journal.owner.state) u.key)
    ?>  ?=(^ held)
    ?>  |(=(our.bowl src.bowl) =(worker.pairing.order.u.held src.bowl))
    ?:  (~(has by failures.state) ticket.order.u.held)  [~[(close u.key)] this]
    =/  auth  (current order.u.held %.y)
    ?:  ?=(%| -.auth)  [~[(close u.key)] this]
    =/  offered  (offered:owner our.bowl src.bowl now.bowl owner.state p.auth u.key)
    ?~  offered  [~[(close u.key)] this]
    [~[[%give %fact ~ %noun !>(u.offered)]] this]
  ++  on-peek
    |=  =path
    ?.  =(our.bowl src.bowl)
      ?:  ?=([%x %native-coding %reserved-desks %except-worker-export @ ~] path)  [~ ~]
      (on-peek:ag path)
    ?:  =(path /x/native-coding/worker/state)  ``noun+!>(state)
    ?:  =(path /x/native-coding/worker/execution)  ``noun+!>(execution)
    ?:  |(=(path /x/native-coding/reserved-desks) ?=([%x %native-coding %reserved-desks %except-worker-export @ ~] path))
      =/  raw  (payload:allowance (on-peek:ag /x/native-coding/reserved-desks))
      ?>  ?=(^ raw)
      =/  held  ;;((set @tas) u.raw)
      =.  held  ?~(source.execution held (~(put in held) desk.u.source.execution))
      =/  omitted=(unit @ux)
        ?:  =(path /x/native-coding/reserved-desks)  ~
        ?>  ?=([%x %native-coding %reserved-desks %except-worker-export @ ~] path)
        =/  matches=(list [@ux record:w])
          (skim ~(tap by journal.owner.state) |=([key=@ux r=record:w] =(i.t.t.t.t.path (export-desk:source order.r))))
        ?.  ?=([* ~] matches)  ~
        =/  [key=@ux r=record:w]  i.matches
        ?~((exporting key) ~ `key)
      =/  rows=(list [@ux record:w])
        (skim ~(tap by journal.owner.state) |=([key=@ux r=record:w] !=(`key omitted)))
      ``noun+!>((~(gas in held) (turn rows |=([key=@ux r=record:w] (export-desk:source order.r)))))
    ?.  ?=([%x %native-coding %worker ?(%export %completion %capacity) @ ~] path)  (on-peek:ag path)
    =/  key  (key:read i.t.t.t.t.path)
    ?~  key  [~ ~]
    ?:  =(%capacity i.t.t.t.path)  ``noun+!>((capacity-completion inner bowl state u.key))
    ?:  =(%completion i.t.t.t.path)  ``noun+!>((complete u.key))
    ``noun+!>((exporting u.key))
  ++  on-agent
    |=  [=wire =sign:agent:gall]
    ?.  ?=([%native-worker-owner @ %result ~] wire)
      =^  cards  inner  (on-agent:ag wire sign)
      (reconcile cards)
    =/  key  (key:read i.t.wire)
    ?~  key  `this
    =/  found  (~(get by journal.owner.state) u.key)
    ?~  found  `this
    =/  r=record:w  u.found
    ?.  &(sent.r =(worker.pairing.order.r src.bowl))  `this
    ?^  result.r  `this
    ?:  |(?=(%kick -.sign) &(?=(%watch-ack -.sign) ?=(^ p.sign)))
      (uncertain ticket.order.r %worker-result-unconfirmed (forget u.key order.r))
    ?.  &(?=(%fact -.sign) =(%noun p.cage.sign) (held:peer bowl wire src.bowl %native-coding-worker (result-path:peer u.key)))  `this
    =/  raw=*  q.q.cage.sign
    ?.  (lte (met 3 (jam raw)) 262.400)  `this
    =/  parsed  ((soft (unit result:w)) raw)
    ?~  parsed  `this
    ?.  =(raw u.parsed)  `this
    =/  received=(unit result:w)
      ?^  u.parsed  u.parsed
      ?.  (gte now.bowl deadline.order.r)  ~
      `(no-such-job order.r u.key now.bowl)
    ?~  received  `this
    =/  auth  (current order.r %.y)
    =/  scope=scope:w
      ?:(?=(%& -.auth) p.auth [pairing.order.r grant.order.r authority.order.r decision.order.r %.y])
    =/  changed  (receive:owner our.bowl src.bowl %native-coding-worker %.y now.bowl owner.state scope u.received)
    ?:  ?=(%| -.changed)  `this
    =.  state  state(owner state.p.changed)
    :_  this
    (weld (forget u.key order.r) ~[(apply-card bowl ticket.order.r)])
  ++  on-arvo
    |=  [=wire =sign-arvo]
    ?.  ?=([%native-worker-owner @ @ ~] wire)
      =/  before=(unit record:accept)
        ?.  &(engaged.state ?=([%native-candidate @ @ ~] wire) ?=([%behn %wake ~] sign-arvo))  ~
        =/  id  (key:read i.t.wire)
        ?~  id  ~
        =/  r  (candidate:read inner bowl u.id)
        ?~  r  ~
        ?.  &((check-scheduled:accept u.r) =(wire (check-wire:accept u.r)) (supported:allowance (required:accept project.u.r candidate.u.r)))  ~
        r
      =^  cards  inner  (on-arvo:ag wire sign-arvo)
      ?~  before  (reconcile cards)
      =/  after  (candidate:read inner bowl id.candidate.u.before)
      ?>  ?=(^ after)
      ?.  (check-dispatched:accept u.after)  (reconcile cards)
      =/  routed  (intercept bowl u.before u.after cards)
      ?.  |((~(has by pending.state) ticket.routed) (lth ~(wyt by pending.state) capacity:journal))
        :_  this
        (turn cards.routed |=(c=card:agent:gall ?:(=(c (wake ticket.routed %start (add now.bowl ~s1))) (wake id.candidate.u.after %capacity (add now.bowl ~s1)) c)))
      [cards.routed this(state state(pending (~(put by pending.state) ticket.routed id.candidate.u.after)))]
    ?.  =(our.bowl src.bowl)  `this
    =/  key  (key:read i.t.wire)
    ?~  key  `this
    =/  kind=@tas  i.t.t.wire
    ?:  =(%capacity kind)
      ?.  ?=([%behn %wake ~] sign-arvo)  `this
      =^  cards  inner  (on-poke:ag %noun !>([%native-coding-worker-capacity-v1 u.key]))
      (reconcile cards)
    ?:  =(%qpc-bind kind)
      ?.  ?=([%behn %wake ~] sign-arvo)  `this
      =/  id  (~(get by pending.state) u.key)
      ?~  id  `this
      ?:  (~(has by failures.state) u.key)  `this
      =/  before  (assessment-entry:read inner bowl u.id)
      ?~  before  `this
      ?.  =(%staged phase.row.u.before)  `this
      =/  rows=(list record:w)
        (skim ~(val by journal.owner.state) |=(r=record:w =(u.key ticket.order.r)))
      ?.  ?=([* ~] rows)  `this
      =/  reserved=record:w  i.rows
      ?.  &(!sent.reserved =(%reserved phase.reserved))  `this
      =^  cards  inner  (on-poke:ag %noun !>([%qpc-assessment-worker-bind-v1 u.key]))
      =/  after  (assessment-entry:read inner bowl u.id)
      ?~  after  (uncertain u.key %qpc-assessment-bind-unconfirmed cards)
      ?.  &(=(%sent phase.row.u.after) =(`order.reserved order.row.u.after))
        (uncertain u.key %qpc-assessment-bind-unconfirmed cards)
      =/  auth  (current order.reserved %.y)
      ?:  ?=(%| -.auth)  (uncertain u.key p.auth cards)
      =/  executor  (execution-bear-with bowl execution)
      ?:  ?=(%| -.executor)  (uncertain u.key p.executor cards)
      =/  order-key=@ux  (digest:law order.reserved)
      =/  dispatched=(list card:agent:gall)
        :~  [%pass (wire-for order-key %export) %arvo %k %fard p.executor %ph-native-coding-worker-export %noun !>(`order-key)]
            (wake order-key %deadline deadline.order.reserved)
        ==
      [(weld cards dispatched) this]
    ?:  ?=(?(%start %apply) kind)
      ?.  ?=([%behn %wake ~] sign-arvo)  `this
      =/  id  (~(get by pending.state) u.key)
      ?~  id  `this
      ?:  =(%apply kind)
        =^  cards  inner  (on-poke:ag %noun !>([%native-coding-worker-apply-v1 u.key]))
        (reconcile cards)
      =/  candidate  (candidate:read inner bowl u.id)
      ?~  candidate  `this
      ?.  &((check-dispatched:accept u.candidate) =(u.key (ticket:owner u.candidate)))  `this
      ?:  (~(has by failures.state) u.key)  `this
      =/  executor  (execution-bear-with bowl execution)
      ?:  ?=(%| -.executor)  (uncertain u.key p.executor ~)
      =/  facts  (inspect inner bowl u.id %.y)
      ?:  ?=(%| -.facts)  (uncertain u.key p.facts ~)
      =/  changed  (begin:owner our.bowl src.bowl now.bowl (add now.bowl ~m20) owner.state candidate.p.facts grant.p.facts allowance.p.facts)
      ?:  ?=(%| -.changed)  (uncertain u.key p.changed ~)
      =.  state  state(owner state.p.changed)
      ?^  (assessment-entry:read inner bowl u.id)
        ::  Persist the actual reservation before the inner assessment reads
        ::  and binds it. No stale self-scry or caller-supplied order grants work.
        ?~  effects.p.changed  `this
        [~[(wake u.key %qpc-bind (add now.bowl ~s1))] this]
      =/  cards=(list card:agent:gall)
        %-  zing
        %+  turn  effects.p.changed
        |=  effect=effect:owner
        ?>  ?=(%export -.effect)
        =/  key=@ux  (digest:law order.effect)
        :~  [%pass (wire-for key %export) %arvo %k %fard p.executor %ph-native-coding-worker-export %noun !>(`key)]
            (wake key %deadline deadline.order.effect)
        ==
      [cards this]
    =/  found  (~(get by journal.owner.state) u.key)
    ?~  found  `this
    =/  r=record:w  u.found
    ?^  result.r  `this
    ?:  =(%reclaim kind)
      ?.  &(?=([%behn %wake ~] sign-arvo) sent.r)  `this
      [(reclaim u.key order.r) this]
    ?:  ?=(?(%deadline %source-stage %source-working %source-accepted) kind)
      ?.  |(?=([%behn %wake *] sign-arvo) ?=([%clay %writ *] sign-arvo))  `this
      =/  auth  (current order.r %.y)
      ?:  &(?=(%& -.auth) (lth now.bowl deadline.order.r))  `this
      =^  cards  this
        (uncertain ticket.order.r ?:(?=(%| -.auth) p.auth %worker-deadline) (forget u.key order.r))
      ?.  &(=(%deadline kind) sent.r)  [cards this]
      [(weld cards ~[(wake u.key %reclaim (add deadline.order.r reclaim-grace))]) this]
    ?.  &(=(%export kind) ?=([%khan %arow *] sign-arvo) !sent.r)  `this
    ?:  |(!=(%reserved phase.r) (~(has by failures.state) ticket.order.r))
      [(forget u.key order.r) this]
    ?.  ?=(%& -.p.sign-arvo)
      (uncertain ticket.order.r %worker-export-unconfirmed (forget u.key order.r))
    =/  raw=*  q.q.p.p.sign-arvo
    =/  parsed  ((soft (each revision:nc @tas)) raw)
    ?~  parsed  (uncertain ticket.order.r %worker-export-invalid (forget u.key order.r))
    ?.  &(=(raw u.parsed) ?=(%& -.u.parsed))
      (uncertain ticket.order.r %worker-export-unconfirmed (forget u.key order.r))
    =/  auth  (current order.r %.y)
    ?:  ?=(%| -.auth)  (uncertain ticket.order.r p.auth (forget u.key order.r))
    ?.  (export-valid:source our.bowl now.bowl order.r p.u.parsed)
      (uncertain ticket.order.r %worker-export-mismatch (forget u.key order.r))
    =/  view  (snapshot:source our.bowl now.bowl desk.p.u.parsed number.p.u.parsed)
    ?>  ?=(%& -.view)
    =/  retained  (exported:owner our.bowl owner.state u.key p.u.parsed (hashes:source files.p.view) parents.p.view)
    ?>  ?=(%& -.retained)
    =/  changed  (dispatch:owner our.bowl src.bowl now.bowl p.retained p.auth u.key)
    ?:  ?=(%| -.changed)
      (uncertain ticket.order.r p.changed (forget u.key order.r))
    =.  state  state(owner state.p.changed)
    ?~  effects.p.changed  `this
    ?>  =(effects.p.changed ~[[%dispatch order.r]])
    =/  candidate  (candidate:read inner bowl candidate.order.r)
    ?>  &(?=(^ candidate) ?=(^ staging.u.candidate))
    =/  revisions=(list [@tas revision:nc])
      ~[[%source-stage source.order.r] [%source-working revision.basis.candidate.u.candidate] [%source-accepted accepted.candidate.u.candidate]]
    =/  watches=(list card:agent:gall)
      %+  turn  revisions
      |=  [kind=@tas v=revision:nc]
      [%pass (wire-for u.key kind) %arvo %c %warp our.bowl desk.v ~ %sing %z [%ud +(number.v)] /]
    :_  this
    :*  [%pass (wire-for u.key %result) %agent [worker.pairing.order.r %native-coding-worker] %watch (result-path:peer u.key)]
        [%pass (wire-for u.key %send) %agent [our.bowl %boks] %poke %noun !>(`local-action:b`[%send (envelope:law order.r)])]
        watches
    ==
  ++  on-leave
    |=  =path
    ?:  ?=([%native-coding %worker %order @ ~] path)  `this
    =^  cards  inner  (on-leave:ag path)
    [cards this]
  ++  on-fail
    |=  [=term =tang]
    =^  cards  inner  (on-fail:ag term tang)
    [cards this]
  --
--
