::  Pure exact Git proposal -> one native candidate plan. No writes or grants.
::  The caller must obtain the receipt from Urgit and the trees from Clay.
/-  nc=native-coding
/+  git=readymade-git-proposal, files=native-coding-files,
    law=native-coding-project
|%
+$  selection  source-selection:git
+$  plan  [origin=selection receipt=@ux candidate=candidate:nc]
++  valid
  |=  s=selection
  (selection-valid:git [repository.s number.s base.s head.s 0x1])
++  identity
  candidate-identity:git
++  build
  |=  [our=@p p=project:nc ctx=context:nc basis=tree:nc accepted=revision:nc selected=selection receipt=proposal:git]
  ^-  (each plan @tas)
  ?.  &((valid selected) (valid:law p))  [%| %selection-invalid]
  ?.  ?&  =(our owner.receipt)  =(our actor.ctx)
          =(our authority.spec.p)  =(our owner.revision.basis)
          =(source.ctx revision.basis)
          =(repository.selected repository.receipt)
          =(number.selected number.receipt)
          =(base.selected base.receipt)  =(head.selected head.receipt)
          =(%open state.receipt)
          (lte (met 3 source-repository.receipt) 128)
          (lte (met 3 source-ref.receipt) 256)
          (lte (met 3 target-ref.receipt) 256)
      ==  [%| %proposal-identity-mismatch]
  =/  before  (namespace:git p before.receipt)
  ?:  ?=(%| -.before)  [%| p.before]
  =/  after  (namespace:git p after.receipt)
  ?:  ?=(%| -.after)  [%| p.after]
  ?.  =(p.before files.body.snapshot.basis)  [%| %base-namespace-mismatch]
  =/  bodies=(map path replacement:nc)
    (malt (turn after.receipt |=(e=leaf:git [clay-path.e [mark.e text.e]])))
  =/  paths=(set path)  (~(uni in ~(key by p.before)) ~(key by p.after))
  =/  edits=(list edit:nc)
    %+  murn  ~(tap in paths)
    |=  pax=path
    ^-  (unit edit:nc)
    ?:  =((~(get by p.before) pax) (~(get by p.after) pax))  ~
    `(edit-one:files p basis pax (~(get by bodies) pax))
  ?.  &((gth (lent edits) 0) (lte (lent edits) 32))  [%| %proposal-edit-count]
  =/  candidate  (candidate:files p ctx basis accepted edits ~)
  ?:  ?=(%| -.candidate)  [%| p.candidate]
  ?.  =(p.after (after-map:files p.candidate))  [%| %head-namespace-mismatch]
  [%& [selected (shax (jam receipt)) p.candidate]]
--
