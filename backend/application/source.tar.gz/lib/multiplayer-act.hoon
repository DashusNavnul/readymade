::  /lib/multiplayer-act
::
::  Pure exact-act proposal and approval law.  Live callers must supply actor
::  and approver ships from src.bowl; this library never reads identity from a
::  submitted payload.
::
/-  ma=multiplayer-act
|%
++  max-changes  `@ud`64
++  bytes-for
  |=  content=@t
  ^-  bytes:ma
  [(met 3 content) `@ux`(shax content)]
++  change-for
  |=  $:  desk=@tas
          path=(list @tas)
          before=(unit @t)
          after=(unit @t)
      ==
  ^-  change:ma
  :*  desk
      path
      ?~(before ~ `(bytes-for u.before))
      ?~(after ~ `(bytes-for u.after))
  ==
::
++  proposal-digest
  |=  body=proposal-body:ma
  ^-  digest:ma
  `@ux`(shax (jam [%multiplayer-act-proposal-v1 body]))
++  approval-digest
  |=  body=approval-body:ma
  ^-  digest:ma
  `@ux`(shax (jam [%multiplayer-act-approval-v1 body]))
++  ceiling-digest
  |=  ceiling=ceiling:ma
  ^-  digest:ma
  `@ux`(shax (jam [%multiplayer-act-ceiling-v1 ceiling]))
::
++  path-valid
  |=  path=(list @tas)
  ^-  ?
  ?~  path  %.n
  ?&  !=(0 i.path)
      ?~(t.path %.y (path-valid t.path))
  ==
++  bytes-valid
  |=  item=bytes:ma
  ^-  ?
  !=(0 digest.item)
++  change-valid
  |=  item=change:ma
  ^-  ?
  ?&  !=(0 desk.item)
      (path-valid path.item)
      ?|  ?=(^ before.item)
          ?=(^ after.item)
      ==
      ?~(before.item %.y (bytes-valid u.before.item))
      ?~(after.item %.y (bytes-valid u.after.item))
      !=(before.item after.item)
  ==
++  change-key
  |=  item=change:ma
  ^-  digest:ma
  `@ux`(shax (jam [desk.item path.item]))
++  unique-changes
  |=  items=(list change:ma)
  ^-  ?
  ?~  items  %.y
  =/  key=digest:ma  (change-key i.items)
  ?&  !(lien t.items |=(item=change:ma =(key (change-key item))))
      (unique-changes t.items)
  ==
++  all-changes-valid
  |=  items=(list change:ma)
  ^-  ?
  ?~  items  %.y
  ?&  (change-valid i.items)
      (all-changes-valid t.items)
  ==
::
++  proposal-valid
  |=  item=proposal:ma
  ^-  ?
  ?&  =(1 version.body.item)
      !=(0 project.body.item)
      !=(0 workspace.body.item)
      !=(0 semantic-proposal.body.item)
      !=(0 ceiling-digest.body.item)
      !=(0 evidence-root.body.item)
      ?=(^ changes.body.item)
      (lte (lent changes.body.item) max-changes)
      (all-changes-valid changes.body.item)
      (unique-changes changes.body.item)
      =((proposal-digest body.item) digest.item)
  ==
++  proposal-for
  |=  [body=proposal-body:ma proposed-at=@da]
  ^-  proposal:ma
  [%multiplayer-act-proposal-v1 body (proposal-digest body) proposed-at]
::
++  approval-valid
  |=  item=approval:ma
  ^-  ?
  ?&  =(1 version.body.item)
      !=(0 proposal-digest.body.item)
      !=(0 project.body.item)
      !=(0 workspace.body.item)
      !=(0 ceiling-digest.body.item)
      !=(0 evidence-root.body.item)
      !=(0 nonce.body.item)
      (gth expires-at.body.item issued-at.body.item)
      =((approval-digest body.item) digest.item)
  ==
++  issue
  |=  $:  proposal=proposal:ma
          authority-host=@p
          source=@p
          issued-at=@da
          expires-at=@da
          nonce=digest:ma
      ==
  ^-  issue-result:ma
  ?.  (proposal-valid proposal)  [%| [%invalid-proposal ~]]
  ?.  =(authority-host source)
    [%| [%foreign-approver authority-host source]]
  ?:  =(0 nonce)  [%| [%nonce-absent ~]]
  ?.  (gth expires-at issued-at)
    [%| [%expiry-invalid issued-at expires-at]]
  =/  proposal-body=proposal-body:ma  body.proposal
  =/  body=approval-body:ma
    :*  1
        digest.proposal
        project.proposal-body
        workspace.proposal-body
        actor.proposal-body
        actor-class.proposal-body
        ceiling-digest.proposal-body
        action.proposal-body
        evidence-root.proposal-body
        source
        nonce
        issued-at
        expires-at
    ==
  [%& [%multiplayer-act-approval-v1 body (approval-digest body)]]
::
++  authorize
  |=  $:  proposal=proposal:ma
          approval=approval:ma
          actor=@p
          actor-class=actor-class:ma
          action=action:ma
          evidence-root=digest:ma
          observed-at=@da
      ==
  ^-  authorization:ma
  ?.  (proposal-valid proposal)  [%| [%invalid-proposal ~]]
  ?.  (approval-valid approval)  [%| [%invalid-approval ~]]
  =/  p=proposal-body:ma  body.proposal
  =/  a=approval-body:ma  body.approval
  ?.  =(digest.proposal proposal-digest.a)
    [%| [%proposal-mismatch proposal-digest.a digest.proposal]]
  ?.  =(project.p project.a)
    [%| [%project-mismatch project.a project.p]]
  ?.  =(workspace.p workspace.a)
    [%| [%workspace-mismatch workspace.a workspace.p]]
  ?.  =(actor.p actor.a)
    [%| [%actor-mismatch actor.a actor.p]]
  ?.  =(actor-class.p actor-class.a)
    [%| [%actor-class-mismatch actor-class.a actor-class.p]]
  ?.  =(action.p action.a)
    [%| [%action-mismatch action.a action.p]]
  ?.  =(evidence-root.p evidence-root.a)
    [%| [%evidence-mismatch evidence-root.a evidence-root.p]]
  ?.  =(actor.a actor)
    [%| [%actor-mismatch actor.a actor]]
  ?.  =(actor-class.a actor-class)
    [%| [%actor-class-mismatch actor-class.a actor-class]]
  ?.  =(action.a action)
    [%| [%action-mismatch action.a action]]
  ?.  =(evidence-root.a evidence-root)
    [%| [%evidence-mismatch evidence-root.a evidence-root]]
  ?:  (lth observed-at issued-at.a)
    [%| [%not-yet-valid issued-at.a observed-at]]
  ?:  (gte observed-at expires-at.a)
    [%| [%stale expires-at.a observed-at]]
  [%& approval]
::
::  Delegation is set intersection plus monotonic numeric/time bounds.  Exact
::  project, workspace, and evidence coordinates can never be translated.
++  ceiling-valid
  |=  ceiling=ceiling:ma
  ^-  ?
  =/  actions=(list action:ma)  ~(tap in actions.ceiling)
  =/  classes=(list actor-class:ma)  ~(tap in actor-classes.ceiling)
  ?&  =(1 version.ceiling)
      !=(0 project.ceiling)
      !=(0 workspace.ceiling)
      ?=(^ actions)
      ?=(^ classes)
      (gth max-changes.ceiling 0)
      (lte max-changes.ceiling max-changes)
      !=(0 evidence-root.ceiling)
      !=(0 expires-at.ceiling)
  ==
++  action-subset
  |=  [child=(set action:ma) parent=(set action:ma)]
  ^-  ?
  (levy ~(tap in child) |=(item=action:ma (~(has in parent) item)))
++  class-subset
  |=  [child=(set actor-class:ma) parent=(set actor-class:ma)]
  ^-  ?
  (levy ~(tap in child) |=(item=actor-class:ma (~(has in parent) item)))
++  tightens
  |=  [parent=ceiling:ma child=ceiling:ma]
  ^-  ?
  ?&  (ceiling-valid parent)
      (ceiling-valid child)
      =(project.parent project.child)
      =(workspace.parent workspace.child)
      =(evidence-root.parent evidence-root.child)
      (action-subset actions.child actions.parent)
      (class-subset actor-classes.child actor-classes.parent)
      (lte max-changes.child max-changes.parent)
      (lte expires-at.child expires-at.parent)
  ==
++  delegate
  |=  [parent=ceiling:ma child=ceiling:ma]
  ^-  delegation-result:ma
  ?.  (ceiling-valid parent)  [%| [%invalid-ceiling ~]]
  ?.  (ceiling-valid child)  [%| [%invalid-ceiling ~]]
  ?.  (tightens parent child)  [%| [%delegation-widens ~]]
  [%& child]
::
++  ceiling-refusal
  |=  [ceiling=ceiling:ma proposal=proposal:ma observed-at=@da]
  ^-  (unit refusal:ma)
  ?.  (ceiling-valid ceiling)  `[%invalid-ceiling ~]
  =/  p=proposal-body:ma  body.proposal
  ?.  =((ceiling-digest ceiling) ceiling-digest.p)
    `[%ceiling-mismatch ceiling-digest.p (ceiling-digest ceiling)]
  ?.  =(project.ceiling project.p)
    `[%ceiling-project project.ceiling project.p]
  ?.  =(workspace.ceiling workspace.p)
    `[%ceiling-workspace workspace.ceiling workspace.p]
  ?.  (~(has in actions.ceiling) action.p)
    `[%ceiling-action action.p]
  ?.  (~(has in actor-classes.ceiling) actor-class.p)
    `[%ceiling-actor-class actor-class.p]
  ?.  =(evidence-root.ceiling evidence-root.p)
    `[%ceiling-evidence evidence-root.ceiling evidence-root.p]
  ?:  (gth (lent changes.p) max-changes.ceiling)
    `[%ceiling-change-limit max-changes.ceiling (lent changes.p)]
  ?:  (gte observed-at expires-at.ceiling)
    `[%ceiling-expired expires-at.ceiling observed-at]
  ~
::
::  Simulator and live mutation gate share this exact verdict function.
++  simulate
  |=  $:  ceiling=ceiling:ma
          proposal=proposal:ma
          approval=approval:ma
          actor=@p
          actor-class=actor-class:ma
          action=action:ma
          evidence-root=digest:ma
          observed-at=@da
      ==
  ^-  authorization:ma
  =/  ceiling-failure=(unit refusal:ma)
    (ceiling-refusal ceiling proposal observed-at)
  ?^  ceiling-failure  [%| u.ceiling-failure]
  (authorize proposal approval actor actor-class action evidence-root observed-at)
::
::  This is the authority-bearing edge.  Inspection above is reusable; a
::  mutation must pass through consume so the approval digest becomes spent.
++  consume
  |=  $:  state=approval-state:ma
          ceiling=ceiling:ma
          proposal=proposal:ma
          approval=approval:ma
          actor=@p
          actor-class=actor-class:ma
          action=action:ma
          evidence-root=digest:ma
          observed-at=@da
      ==
  ^-  consume-result:ma
  =/  checked=authorization:ma
    (simulate ceiling proposal approval actor actor-class action evidence-root observed-at)
  ?-  -.checked
    %|  [%| p.checked]
    %&
      ?:  (~(has in used.state) digest.p.checked)
        [%| [%approval-spent digest.p.checked]]
      =/  next=approval-state:ma
        [(~(put in used.state) digest.p.checked)]
      [%& [next p.checked]]
  ==
--
