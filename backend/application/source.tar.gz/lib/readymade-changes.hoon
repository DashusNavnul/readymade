::  Exact reviewed versions. The native court owns permission and landing.
/+  p=readymade-projects, dd=desk-diff, h=readymade-history,
    c=readymade-bench-compose
|%
+$  selection
  $:  source=@uv  seat=@tas  base=@tas  base-revision=@ud
      fork-revision=@ud  start=@ud  file=(unit path)  line=@ud
  ==
+$  identity
  [source=@uv seat=@tas base=@tas base-revision=@ud fork-revision=@ud manifest=@ux]
+$  change  [pax=path before=(unit @uv) after=(unit @uv)]
+$  blob  [lobe=(unit @uv) bytes=@ud hash=@ux source=(unit @t)]
+$  line  [op=?(%context %remove %add) before=(unit @ud) after=(unit @ud) text=text:h]
+$  delta  [prefix=@ud suffix=@ud removed=wain added=wain]
+$  diff
  [pax=path before=blob after=blob start=@ud total=(unit @ud) next=(unit @ud) rows=(list line) problem=(unit @t)]
+$  snapshot
  [%readymade-changes-v1 owner=@p reviewed=identity start=@ud total=@ud next=(unit @ud) rows=(list change) file=(unit diff) problem=(unit @t)]
+$  command
  $:  %readymade-change-command-v1  id=@uv  nonce=@uv  source=@uv
      seat=@tas  base=@tas  base-revision=@ud  fork-revision=@ud
      manifest=@ux  action=?(%approve %refuse %land)  peer=(unit @tas)
  ==
+$  controls
  $:  %readymade-change-controls-v1  reviewed=identity  nonce=@uv
      available=(set ?(%approve %refuse %land))  approved=(unit identity)
      reason=(unit @t)
  ==
+$  receipt
  $:  %readymade-change-receipt-v1  id=@uv  reviewed=identity
      action=?(%approve %refuse %land)  at=@da
      status=?(%accepted %refused %unknown %landed %failed)
      reason=(unit @t)  after-root=(unit @uv)
  ==
+$  status
  [%readymade-change-status-v1 controls=(unit controls) latest=(unit receipt)]
++  token-valid
  |=  value=@uv
  ^-  ?
  &(!=(0v0 value) (lte (met 0 value) 128))
++  identity-valid
  |=  value=identity
  ^-  ?
  ?&  (lte (met 0 source.value) 128)  (seat-valid:c seat.value)
      (desk-valid:p base.value)  !=(base.value seat.value)
      (lte (met 0 base-revision.value) 64)  (lte (met 0 fork-revision.value) 64)
      (lte (met 0 manifest.value) 256)
  ==
++  selection-valid
  |=  value=selection
  ^-  ?
  ?&  (identity-valid [source.value seat.value base.value base-revision.value fork-revision.value 0x0])
      (lte (met 0 start.value) 64)  (lte (met 0 line.value) 64)
      ?~(file.value %.y (path-valid:p u.file.value))
  ==
++  manifest
  |=  [before=(map path @uv) after=(map path @uv)]
  ^-  (list change)
  =/  changed=(list change:dd)  (diff-maps:dd before after)
  =/  rows=(list change)
    %+  turn  changed
    |=  item=change:dd
    [pax.item (~(get by before) pax.item) (~(get by after) pax.item)]
  (sort rows |=([a=change b=change] (aor (spat pax.a) (spat pax.b))))
++  fingerprint
  |=  [source=@uv seat=@tas base=@tas base-revision=@ud fork-revision=@ud rows=(list change)]
  ^-  @ux
  (shax (jam [source seat base base-revision fork-revision rows]))
++  page
  |=  [owner=@p source=@uv seat=@tas base=@tas base-revision=@ud fork-revision=@ud before=(map path @uv) after=(map path @uv) start=@ud]
  ^-  snapshot
  =/  all=(list change)  (manifest before after)
  =/  reviewed=identity
    [source seat base base-revision fork-revision (fingerprint source seat base base-revision fork-revision all)]
  =/  rows=(list change)  (scag 64 (slag start all))
  =/  next=(unit @ud)  ?:((lth (add start (lent rows)) (lent all)) `(add start (lent rows)) ~)
  [%readymade-changes-v1 owner reviewed start (lent all) next rows ~ ~]
++  common-head
  |=  [a=wain b=wain]
  ^-  @ud
  =/  count=@ud  0
  |-  ^-  @ud
  ?~  a  count
  ?~  b  count
  ?.  =(i.a i.b)  count
  $(a t.a, b t.b, count +(count))
++  split
  |=  [before=wain after=wain]
  ^-  delta
  =/  prefix=@ud  (common-head before after)
  =/  a=wain  (slag prefix before)
  =/  b=wain  (slag prefix after)
  =/  suffix=@ud  (common-head (flop a) (flop b))
  [prefix suffix (scag (sub (lent a) suffix) a) (scag (sub (lent b) suffix) b)]
++  numbered
  |=  [op=?(%context %remove %add) before=(unit @ud) after=(unit @ud) source=wain]
  ^-  (list line)
  =|  rows=(list line)
  |-  ^-  (list line)
  ?~  source  (flop rows)
  =/  text=text:h  (bounded:h i.source 1.024)
  $(source t.source, before (bind before |=(n=@ud +(n))), after (bind after |=(n=@ud +(n))), rows [[op before after text] rows])
++  diff-lines
  |=  [before=wain after=wain]
  ^-  (list line)
  =/  change=delta  (split before after)
  ?:  &(=(~ removed.change) =(~ added.change))  ~
  =/  first=@ud  (sub prefix.change (min 2 prefix.change))
  =/  head=(list line)
    (numbered %context `+(first) `+(first) (scag (sub prefix.change first) (slag first before)))
  =/  removed=(list line)  (numbered %remove `+(prefix.change) ~ removed.change)
  =/  added=(list line)  (numbered %add ~ `+(prefix.change) added.change)
  =/  tail=(list line)
    (numbered %context `(add 1 (sub (lent before) suffix.change)) `(add 1 (sub (lent after) suffix.change)) (scag 2 (slag (sub (lent before) suffix.change) before)))
  (weld head (weld removed (weld added tail)))
++  source-lines
  |=  source=@t
  ^-  wain
  ?:  =(0 (met 3 source))  ~
  =/  len=@ud  (met 3 source)
  =|  [at=@ud start=@ud rows=wain]
  |-  ^-  wain
  ?:  =(at len)  (flop [`@t`(cut 3 [start (sub len start)] source) rows])
  ?.  =(10 (cut 3 [at 1] source))  $(at +(at))
  $(at +(at), start +(at), rows [`@t`(cut 3 [start (sub at start)] source) rows])
++  file-page
  |=  [pax=path before=blob after=blob start=@ud]
  ^-  diff
  =/  out=diff  [pax before after start ~ ~ ~ ~]
  ?~  source.before  out(problem `'The exact base source is unavailable or exceeds 64 KiB.')
  ?~  source.after  out(problem `'The exact fork source is unavailable or exceeds 64 KiB.')
  =/  a=wain  (source-lines u.source.before)
  =/  b=wain  (source-lines u.source.after)
  ?:  |((gth (lent a) 8.192) (gth (lent b) 8.192))
    out(problem `'File exceeds 8192 lines; no partial diff was presented as complete.')
  =/  all=(list line)  (diff-lines a b)
  =/  rows=(list line)  (scag 64 (slag start all))
  out(total `(lent all), rows rows, next ?:((lth (add start (lent rows)) (lent all)) `(add start (lent rows)) ~))
++  blob-valid
  |=  value=blob
  ^-  ?
  ?.  &((lte (met 0 bytes.value) 64) (lte (met 0 hash.value) 256))  %.n
  ?^  lobe.value
    ?.  &(!=(0v0 u.lobe.value) (lte (met 0 u.lobe.value) 256))  %.n
    ?~  source.value  %.y
    &((lte bytes.value 65.536) =(bytes.value (met 3 u.source.value)) =(hash.value (shax u.source.value)))
  &(=(0 bytes.value) =(`'' source.value) =(hash.value (shax '')))
++  change-valid
  |=  item=change
  ^-  ?
  ?&  (path-valid:p pax.item)  !=(before.item after.item)
      ?~(before.item %.y &(!=(0v0 u.before.item) (lte (met 0 u.before.item) 256)))
      ?~(after.item %.y &(!=(0v0 u.after.item) (lte (met 0 u.after.item) 256)))
  ==
++  line-valid
  |=  row=line
  ^-  ?
  ?.  ?&  (lte bytes.text.row 65.536)
          =(shown.text.row (met 3 body.text.row))
          (lte shown.text.row 1.024)  (lte shown.text.row bytes.text.row)
          =(truncated.text.row (lth shown.text.row bytes.text.row))
          ?~(before.row %.y &((gth u.before.row 0) (lte u.before.row 8.192)))
          ?~(after.row %.y &((gth u.after.row 0) (lte u.after.row 8.192)))
      ==  %.n
  ?-  op.row
    %remove   &(?=(^ before.row) =(~ after.row))
    %add      &(=(~ before.row) ?=(^ after.row))
    %context  &(?=(^ before.row) ?=(^ after.row))
  ==
++  valid
  |=  [owner=@p wanted=selection value=snapshot]
  ^-  ?
  ?.  ?&  (selection-valid wanted)  (identity-valid reviewed.value)
          =(owner owner.value)  =(source.wanted source.reviewed.value)
          =(seat.wanted seat.reviewed.value)  =(base.wanted base.reviewed.value)
          |(=(0 base-revision.wanted) =(base-revision.wanted base-revision.reviewed.value))
          |(=(0 fork-revision.wanted) =(fork-revision.wanted fork-revision.reviewed.value))
          =(start.wanted start.value)  (lte total.value 40.000)  (lte (lent rows.value) 64)
          ?~(problem.value %.y (lte (met 3 u.problem.value) 512))
      ==  %.n
  ?.  (levy rows.value change-valid)  %.n
  ?.  =((lent rows.value) ~(wyt in (silt (turn rows.value |=(r=change pax.r)))))  %.n
  ?.  =(rows.value (sort rows.value |=([a=change b=change] (aor (spat pax.a) (spat pax.b)))))  %.n
  ?.  ?~(problem.value =((lent rows.value) (min 64 (sub total.value (min total.value start.value)))) %.y)  %.n
  ?.  ?~(next.value %.y &(=(64 (lent rows.value)) =(u.next.value (add start.value 64)) (lth u.next.value total.value)))  %.n
  ?~  file.value  %.y
  ?~  file.wanted  %.n
  =/  d=diff  u.file.value
  ?&  =(u.file.wanted pax.d)  =(line.wanted start.d)
      (blob-valid before.d)  (blob-valid after.d)  (lte (lent rows.d) 64)
      (levy rows.d line-valid)
      ?~(problem.d %.y (lte (met 3 u.problem.d) 512))
      ?~(total.d =(~ next.d) &((lte u.total.d 16.388) (lte (lent rows.d) u.total.d)))
      ?~(next.d %.y ?~(total.d %.n &(=(64 (lent rows.d)) =(u.next.d (add start.d 64)) (lth u.next.d u.total.d))))
  ==
++  status-valid
  |=  [wanted=selection value=status]
  ^-  ?
  =/  matches
    |=  id=identity
    ?&  (identity-valid id)  =(source.wanted source.id)
        =(seat.wanted seat.id)  =(base.wanted base.id)
        (gth base-revision.id 0)  (gth fork-revision.id 0)
    ==
  =/  control-ok=?
    ?~  controls.value  %.y
    =/  x=controls  u.controls.value
    ?&  (matches reviewed.x)  (token-valid nonce.x)
        ?~(reason.x %.y (lte (met 3 u.reason.x) 512))
        ?~(approved.x %.y &(=(reviewed.x u.approved.x) (matches u.approved.x)))
        |(!(~(has in available.x) %land) =(`reviewed.x approved.x))
    ==
  ?.  control-ok  %.n
  ?~  latest.value  %.y
  =/  x=receipt  u.latest.value
  ?&  (matches reviewed.x)  (token-valid id.x)
      ?~(reason.x %.y (lte (met 3 u.reason.x) 512))
      ?~(after-root.x !=(%landed status.x) &((lte (met 0 u.after-root.x) 256) =(%land action.x)))
      ?:(=(%landed status.x) &(=(%land action.x) ?=(^ after-root.x)) %.y)
  ==
++  command-identity
  |=  cmd=command
  ^-  identity
  [source.cmd seat.cmd base.cmd base-revision.cmd fork-revision.cmd manifest.cmd]
++  admit
  |=  [our=@p src=@p cmd=command current=identity nonce=@uv approved=(unit identity) allowed=(set ?(%approve %refuse %land))]
  ^-  (unit @t)
  ?.  =(our src)  `'Only the operator may review or land changes.'
  ?.  &((token-valid id.cmd) (token-valid nonce.cmd) (token-valid source.cmd))  `'Invalid command or original submission identity.'
  ?.  &((gth base-revision.cmd 0) (gth fork-revision.cmd 0))  `'Load exact nonzero native revisions before submitting a review.'
  ?.  &(=(nonce nonce.cmd) (identity-valid current) =(current (command-identity cmd)))  `'The reviewed request or exact versions changed. Load the native review again.'
  ?.  (~(has in allowed) action.cmd)  `'The native owner does not currently allow this action.'
  ?.  ?~(peer.cmd %.y &((seat-valid:c u.peer.cmd) !=(seat.cmd u.peer.cmd)))  `'Invalid comparison Bachelor.'
  ?:  =(%land action.cmd)
    ?.  =(`current approved)  `'This exact change has no retained approval.'
    ~
  ?.  =(~ peer.cmd)  `'Peer selection applies only to landing.'
  ~
--
