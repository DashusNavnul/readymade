::  Shared law command data and text bounds. Viki retains all authority.
::  No owner, instrument, execution or presentation dependencies.
|%
+$  edit
  $%  [%gain value=@ud]
      [%weights footprint=@ud indirection=@ud]
  ==
+$  command
  [%qpc-law-edit-v1 instrument=@ux expected=@ux change=edit reason=@t]
++  reason-valid
  |=  reason=@t
  &((gth (met 3 reason) 0) (lte (met 3 reason) 256) (levy (trip reason) |=(c=@t &((gte c 32) (lte c 126)))))
--
