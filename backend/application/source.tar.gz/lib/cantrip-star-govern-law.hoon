::  /lib/cantrip-star-govern-law
::
::  Binding law for admitting multiplayer dispatches under a star-govern
::  observation.  The verdict name itself is advisory.  Three control fields
::  bind: grounding blocks NEW work while prior work is unverified; high Zeno
::  pressure enforces the caller's stated rate ceiling; reject-only blocks a
::  retry.  Missing and stale observations fail closed.
::
::  An override is not an untrusted request flag.  The IO caller may populate
::  `override-from-star` only by reading the matching typed override fact back
::  from the star's Graf.  This core then checks actor, subject, reason and
::  time.  The ship's local operator is the only override authority.  A stale
::  or missing verdict cannot be overridden because there is no current
::  judgment to override.
::
|%
+$  governor-record
  $:  version=%star-govern-verdict-v1
      verdict-id=@t
      source=@p
      window-size=@ud
      samples=@ud
      rank-collapsed=?
      looping=?
      aligned=?
      grounded=?
      rhythm=@ud
      verdict=@tas
      clamp=@tas
      zeno-pressure=@tas
      retry-policy=@tas
      observed-at=@da
      expires-at=@da
  ==
+$  governor-read
  $%  [%signal record=governor-record]
      $:  %no-signal
          reason=?(%missing %stale)
          observed-at=(unit @da)
          expires-at=(unit @da)
      ==
  ==
+$  override-fact
  $:  version=%star-govern-override-v1
      override-id=@t
      verdict-id=@t
      actor=@p
      reason=@t
      recorded-at=@da
  ==
::  %report is NOT a third flavour of dispatch.  It carries evidence that work
::  ALREADY COMPLETED and was ALREADY VERIFIED -- a %familiar-submit move.  It
::  cannot add load to the collective, because the load it describes is spent.
::
::  Measured 2026-08-29 (spec S78): with clamp=grounding and the verdict
::  `looping`, a member could not report.  ted/ph/star-report sends
::  %familiar-submit, so the channel carrying proof of good work was the one the
::  verdict closed -- and the record could only stop looping if members reported
::  varied real work.  The law refused the reports for looping, and the looping
::  could not end without them.
::
::  A clamp on NEW work must never close the channel that proves work FINISHED.
+$  admission-kind  ?(%new-dispatch %retry %report)
+$  context
  $:  kind=admission-kind
      operator=@p
      now=@da
      outstanding-unverified=@ud
      dispatches-in-rate-window=@ud
      max-dispatches-per-window=@ud
      override-from-star=(unit override-fact)
  ==
+$  decision
  $%  [%admit overridden=? reason=@tas]
      [%refuse reason=@tas]
  ==
::
++  valid-override
  |=  [record=governor-record context=context]
  ^-  ?
  ?~  override-from-star.context  %.n
  =/  override=override-fact  u.override-from-star.context
  ?&  =(actor.override operator.context)
      =(verdict-id.override verdict-id.record)
      (gth (met 3 reason.override) 0)
      (lte recorded-at.override now.context)
      (lte recorded-at.override expires-at.record)
      (lth now.context expires-at.record)
  ==
::
++  binding-refusal
  |=  [record=governor-record context=context]
  ^-  (unit @tas)
  ::  A report is exempt before any other test, including the rate policy: a
  ::  misconfigured ceiling is an operator error about DISPATCH, and silencing
  ::  the evidence channel is not a proportionate response to it.
  ?:  =(%report kind.context)  ~
  ?:  =(0 max-dispatches-per-window.context)
    `%invalid-rate-policy
  ?:  ?&  =(%new-dispatch kind.context)
          =(%grounding clamp.record)
          (gth outstanding-unverified.context 0)
      ==
    `%grounding-unverified
  ?:  ?&  =(%new-dispatch kind.context)
          =(%high zeno-pressure.record)
          (gte dispatches-in-rate-window.context max-dispatches-per-window.context)
      ==
    `%zeno-rate-limit
  ?:  ?&  =(%retry kind.context)
          =(%reject-only retry-policy.record)
      ==
    `%reject-only
  ~
::
++  decide
  |=  [signal=governor-read context=context]
  ^-  decision
  ::  A REPORT IS ADMITTED WITHOUT A VERDICT.  Everything else fails closed on a
  ::  missing or stale observation, and should.  But a member whose cache is
  ::  empty is exactly the member the star has never heard from, and refusing
  ::  its report is how a star stays deaf: no signal, so no reports; no reports,
  ::  so no signal.  Reporting is the mechanism by which the star acquires the
  ::  judgment that governs everything else, so it cannot be gated on that
  ::  judgment existing.
  ::
  ::  The exemption is narrow on purpose.  It admits ONLY %report, it is
  ::  recorded as %report-exempt rather than %within-law so an auditor can see
  ::  it was never judged, and it grants nothing else: a report may not dispatch,
  ::  retry, or override.
  ?:  =(%report kind.context)
    [%admit %.n %report-exempt]
  ?-  -.signal
    %no-signal
      [%refuse ?:(=(%stale reason.signal) %stale-verdict %missing-verdict)]
    %signal
      =/  blocked=(unit @tas)  (binding-refusal record.signal context)
      ?~  blocked
        [%admit %.n %within-law]
      ?:  (valid-override record.signal context)
        [%admit %.y %operator-override]
      [%refuse u.blocked]
  ==
::
::  %guidance-context.  The target worker's regime, as the circulation record
::  shows it (lib/seiv-guidance +regime-of), is READ by the decision; the
::  packet never admits anything by itself.  REFUSALS NAME THE REGIME so a
::  refused worker knows what to repair: a %repair-needed worker (its last
::  guided release failed verification) and a %drifting worker (it wrote
::  outside its packet's paths) get no NEW dispatch until the record shows
::  them grounded again.  Reports and retries are untouched -- the channel
::  that proves repair stays open (the S84 rule, applied here).
++  guidance-refusal
  |=  [kind=admission-kind regime=(unit @tas)]
  ^-  (unit @tas)
  ?.  =(%new-dispatch kind)  ~
  ?~  regime  ~
  ?:  =(%repair-needed u.regime)  `%guidance-repair-needed
  ?:  =(%drifting u.regime)  `%guidance-drifting
  ~
::
::  +decide, then the guidance context.  An operator override of the star's
::  verdict overrides a guidance refusal too, and the decision says so; the
::  override fact carries the regime census it overrode (app/cantrip).
++  decide-guided
  |=  [signal=governor-read context=context regime=(unit @tas)]
  ^-  decision
  =/  base=decision  (decide signal context)
  ?.  ?=([%admit *] base)  base
  =/  g=(unit @tas)  (guidance-refusal kind.context regime)
  ?~  g  base
  ?:  ?&  ?=([%signal *] signal)
          (valid-override record.signal context)
      ==
    [%admit %.y %operator-override]
  [%refuse u.g]
--
