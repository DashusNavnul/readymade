::  Item 100: one owner view of running work, recent changes, blockers, the
::  decisions waiting on the owner, and what happens next. Read-only; every
::  line comes from a native record (Cantrip's candidate ledger, the peer
::  work store, task claims and questions, diagnostics, the standing policy),
::  and an unreadable source is reported as unavailable, never as empty.
/-  nc=native-coding
/+  accept=native-coding-accept, queue=readymade-work-queue, tasks=owner-tasks,
    diagnostics=native-diagnostics-http
|%
++  prefix  '/apps/pataphor-native/coding/overview'
++  window  ~d1
++  line
  |=  [kind=@t what=@t]
  ^-  json
  (pairs:enjs:format ~[['kind' s+kind] ['what' s+what]])
++  route
  |=  [our=@p src=@p now=@da url=@t]
  ^-  (unit json)
  ?.  =(prefix url)  ~
  ?.  =(our src)  `(pairs:enjs:format ~[['schema' s+'owner-overview-v1'] ['error' s+'owner-required']])
  =/  unavailable=(list @t)  ~
  ::  candidates
  ::  A read of an agent that is not running ends the whole request and no
  ::  mole catches it, so it is asked whether it runs first.
  =/  ledger=(unit ledger:accept)
    ?.  .^(? %gu /(scot %p our)/cantrip/(scot %da now)/$)  ~
    (mole |.(.^(ledger:accept %gx /(scot %p our)/cantrip/(scot %da now)/native-coding/candidate-ledger/noun)))
  =?  unavailable  ?=(~ ledger)  ['candidate ledger' unavailable]
  =/  cands=(list record:accept)  ?~(ledger ~ ~(val by u.ledger))
  =/  short  |=(x=@ux (end [3 6] (scot %ux x)))
  =/  running-cands=(list json)
    %+  murn  cands
    |=  r=record:accept
    ?.  ?=(?(%cloning %staging %checking %landing) stage.r)  ~
    `(line 'candidate' (rap 3 ~[(short id.candidate.r) ' in ' id.spec.project.r ': ' stage.r ?~(reason.r '' (cat 3 ' (' (cat 3 u.reason.r ')')))]))
  =/  review-cands=(list json)
    %+  murn  cands
    |=  r=record:accept
    ?.  ?=(%review stage.r)  ~
    `(line 'candidate review' (rap 3 ~[(short id.candidate.r) ' in ' id.spec.project.r ' waits for a review decision']))
  =/  landed=(list json)
    %+  murn  cands
    |=  r=record:accept
    ?.  ?=(%applied stage.r)  ~
    ?~  landed.r  ~
    ?~  decision.r  ~
    ?.  (gth at.u.decision.r (sub now window))  ~
    `(line 'landed' (rap 3 ~[(short id.candidate.r) ' landed in ' desk.revision.u.landed.r ' at revision ' (scot %ud number.revision.u.landed.r)]))
  ::  peer work
  =/  rows=(unit (list row:queue))
    (mole |.(?.((store:queue our now) ~ (rows:queue our now))))
  =?  unavailable  ?=(~ rows)  ['peer work store' unavailable]
  =/  work=(list row:queue)  (fall rows ~)
  =/  policy  (mole |.((policy-now:queue our now)))
  =?  unavailable  ?=(~ policy)  ['standing policy' unavailable]
  =/  left=(unit @ud)
    ?~  policy  ~
    ?~  u.policy  `0
    ::  Dispatches whose requests left the window still count; a count that
    ::  cannot be read is taken as none, never as a failed page.
    =/  spent=@ud  (fall (mole |.((spent:queue our now version.u.u.policy))) 0)
    `(sub max.u.u.policy (min max.u.u.policy (dispatched-under:queue work version.u.u.policy spent)))
  =/  running-work=(list json)
    %+  murn  work
    |=  r=row:queue
    ?.  ?=(%dispatched (status-of:queue r))  ~
    `(line 'peer work' (rap 3 ~[(scot %p peer.request.r) ' request ' (short nonce.request.r) ' running in session ' (short session.request.r)]))
  =/  finished-work=(list json)
    %+  murn  work
    |=  r=row:queue
    ?~  outcome.r  ~
    ?.  (gth at.u.outcome.r (sub now window))  ~
    `(line 'peer work done' (rap 3 ~[(scot %p peer.request.r) ' request ' (short nonce.request.r) ' finished: ' phase.u.outcome.r]))
  =/  next-work=(list json)
    %+  murn  work
    |=  r=row:queue
    ?.  ?=(%queued (status-of:queue r))  ~
    =/  why=@t
      ?~  left  'dispatch waits: the policy cannot be read'
      ?:  =(0 u.left)  'dispatch waits for a new policy version: this version\'s admission budget is spent'
      (rap 3 ~['dispatches once session ' (short session.request.r) ' is idle (checked every five minutes while it waits)'])
    `(line 'peer work queued' (rap 3 ~[(scot %p peer.request.r) ' request ' (short nonce.request.r) ': ' why]))
  ::  claims and questions
  =/  owned=(unit json)  (mole |.((view:tasks our now)))
  =?  unavailable  ?=(~ owned)  ['task claims' unavailable]
  =/  qs=(list question:tasks)  (fall (mole |.((questions:tasks our now))) ~)
  =/  as=(set @ux)  (fall (mole |.((closed:tasks our now))) ~)
  =/  open-qs=(list json)
    %+  murn  qs
    |=  q=question:tasks
    ?:  (~(has in as) id.q)  ~
    `(line 'question' (rap 3 ~[who.q ' asks on ' task.q ': ' text.q ' (consequence: ' consequence.q ')']))
  ::  diagnostics
  =/  diag=(unit (unit json))
    (mole |.((route:diagnostics our src now '/apps/pataphor-native/coding/diagnostics')))
  =?  unavailable  |(?=(~ diag) ?=([~ ~] diag))  ['diagnostics' unavailable]
  =/  blockers=(list json)
    ?.  ?=([~ ~ %o *] diag)  ~
    =/  fs  (~(get by p.u.u.diag) 'findings')
    ?.  ?=([~ %a *] fs)  ~
    %+  murn  p.u.fs
    |=  f=json
    ?.  ?=(%o -.f)  ~
    =/  st  (~(get by p.f) 'status')
    ?.  ?=([~ %s *] st)  ~
    ?:  =('ok' p.u.st)  ~
    =/  area  (~(get by p.f) 'area')
    =/  sum  (~(get by p.f) 'summary')
    :-  ~
    %+  line  (cat 3 'blocker ' p.u.st)
    (rap 3 ~[?.(?=([~ %s *] area) '' p.u.area) ': ' ?.(?=([~ %s *] sum) '' p.u.sum)])
  :-  ~
  %-  pairs:enjs:format
  :~  ['schema' s+'owner-overview-v1']  ['observedAt' s+(scot %da now)]
      ['running' a+(weld running-cands running-work)]
      ['changes' a+(weld landed finished-work)]
      ['blockers' a+blockers]
      ['decisions' a+(weld review-cands open-qs)]
      ['next' a+next-work]
      ['policyAdmissionsLeft' ?~(left ~ (numb:enjs:format u.left))]
      ['unavailable' a+(turn unavailable |=(t=@t s+t))]
  ==
--
