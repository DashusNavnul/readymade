::  Private reads from the returned inner agent, not its previous-event scry.
::  External Cantrip/provider and numbered Clay reads retain native authority.
/-  nc=native-coding
/+  bind=qpc-native-owner-binding, d=qpc-native-declaration,
    owner=qpc-native-owner, instrument=qpc-instrument-read-contract,
    history=qpc-instrument-history, observer=qpc-observer,
    obs=qpc-observation, law=qpc-law-core, project=native-coding-project,
    tools=cantrip-native-coding,
    provider=native-coding-provider, evidence=qpc-native-evidence,
    guard=viki-scry-guard, decision=qpc-native-decision,
    recurring=qpc-successor-history, successor=qpc-successor-window,
    selected=qpc-selected-history, sessions=native-coding-session
|%
+$  reader  $-([inner=agent:gall b=bowl:gall id=@ux] (each view:bind @tas))
+$  sealer  $-([inner=agent:gall b=bowl:gall s=state:owner id=@ux] (each state:owner @tas))
++  managed
  |=  [inner=agent:gall b=bowl:gall]
  ^-  (unit (set @ux))
  =/  raw  (raw:instrument inner b /x/qpc/required-sessions)
  ?~  raw  ~
  =/  parsed  ((soft ,[%qpc-session-gate-v1 %viki ids=(set @ux)]) u.raw)
  ?~(parsed ~ `ids.u.parsed)
++  ledger
  |=  b=bowl:gall
  ^-  (each organ:tools @tas)
  ?.  (agent-live:guard our.b now.b %cantrip)  [%| %qpc-cantrip-unavailable]
  =/  raw=*
    .^(* %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/tool-state/noun)
  =/  parsed  ((soft organ:tools) raw)
  ?~(parsed [%| %qpc-pool-ledger-invalid] [%& u.parsed])
++  prefixes
  ::  Read the registered policy's actual owner state. Successor readiness
  ::  includes the instrument's unresolved-work and actual-Clay source guard;
  ::  no retained old reading or manufactured v1 prefix can substitute for it.
  |=  [inner=agent:gall b=bowl:gall p=plan:instrument work=work:obs current=revision:nc]
  ^-  (each (map @ux prefix:decision) @tas)
  ?.  (successor-plan:instrument p)
    =/  raw  (raw:instrument inner b /x/qpc/instrument/measurements)
    ?~  raw  [%| %qpc-owner-measurements-unavailable]
    =/  parsed  ((soft ,[%qpc-instrument-measurements-v1 value=state:history]) u.raw)
    ?~  parsed  [%| %qpc-owner-measurements-invalid]
    ?^  fault.value.u.parsed  [%| %qpc-owner-history-fault]
    =/  widened=(map @ux prefix:decision)
      windows.value.u.parsed
    [%& widened]
  =/  raw  (raw:instrument inner b /x/qpc/instrument/successors)
  ?~  raw  [%| %qpc-owner-measurements-unavailable]
  =/  parsed  ((soft ,[%qpc-instrument-successors-v1 value=state:recurring refresh=(unit @da)]) u.raw)
  ?~  parsed  [%| %qpc-owner-measurements-invalid]
  ?^  refresh.u.parsed  [%| %qpc-successor-refresh-unconfirmed]
  ?^  fault.value.u.parsed  [%| %qpc-owner-history-fault]
  ?:  (pending:recurring value.u.parsed stream.p)
    =/  raw  (raw:instrument inner b /x/qpc/instrument/selected)
    ?~  raw  [%| %qpc-successor-work-unresolved]
    =/  book  ((soft ,[%qpc-instrument-selected-v1 value=state:selected]) u.raw)
    ?~  book  [%| %qpc-owner-selected-history-invalid]
    =/  reopened  (reopen:selected value.u.parsed value.u.book session.p work current)
    ?:  ?=(%| -.reopened)  [%| p.reopened]
    [%& (malt ~[[stream.p `prefix:decision`p.reopened]])]
  =/  found  (~(get by windows.value.u.parsed) stream.p)
  ?~  found  [%| %qpc-owner-window-missing]
  =/  available  (raw:instrument inner b /x/qpc/instrument/successor/(scot %ux stream.p)/current)
  ?~  available  [%| %qpc-owner-reading-unavailable]
  =/  reading  ((soft ,(each reading:successor @tas)) u.available)
  ?~  reading  [%| %qpc-owner-reading-invalid]
  ?:  ?=(%| -.u.reading)  [%| p.u.reading]
  ?.  =(measured.u.found `p.u.reading)  [%| %qpc-owner-reading-changed]
  [%& (malt ~[[stream.p `prefix:decision`u.found]])]
++  read
  |=  [inner=agent:gall b=bowl:gall id=@ux]
  ^-  (each view:bind @tas)
  =/  required  (managed inner b)
  ?~  required  [%| %qpc-owner-gate-unavailable]
  ?.  (~(has in u.required) id)  [%| %qpc-owner-unmanaged-session]
  =/  registry  (raw:instrument inner b /x/qpc/profile-declarations)
  =/  plans  (raw:instrument inner b /x/qpc/instrument/state)
  =/  laws  (raw:instrument inner b /x/qpc/laws)
  =/  observed  (raw:instrument inner b /x/qpc/observations)
  ?~  registry  [%| %qpc-owner-registry-unavailable]
  ?~  plans  [%| %qpc-owner-instrument-unavailable]
  ?~  laws  [%| %qpc-owner-law-unavailable]
  ?~  observed  [%| %qpc-owner-observer-unavailable]
  =/  rr  ((soft state:d) u.registry)
  =/  pp  ((soft state:instrument) u.plans)
  =/  ll  ((soft state:law) u.laws)
  =/  oo  ((soft state:obs) u.observed)
  ?~  rr  [%| %qpc-owner-registry-invalid]
  ?~  pp  [%| %qpc-owner-instrument-invalid]
  ?~  ll  [%| %qpc-owner-law-invalid]
  ?~  oo  [%| %qpc-owner-observer-invalid]
  =/  found  (~(get by records.u.rr) id)
  ?~  found  [%| %qpc-owner-declaration-missing]
  =/  r=record:d  u.found
  =/  a=association:d  value.r
  ?:  (~(has by plans.u.pp) id)  [%| %qpc-owner-session-already-enrolled]
  =/  plan  (~(get by plans.u.pp) member.command.a)
  ?~  plan  [%| %qpc-owner-member-missing]
  ?.  =(plan.a plan.u.plan)  [%| %qpc-owner-plan-changed]
  =/  input  (input:observer inner b id)
  ?~  input  [%| %qpc-owner-session-missing]
  =/  config  (project-read:instrument inner b id project.manifest.plan.a)
  ?:  ?=(%| -.config)  [%| p.config]
  ?.  =(project.a p.config)  [%| %qpc-owner-project-changed]
  =/  current  (current:project our.b now.b p.config)
  ?:  ?=(%| -.current)  [%| p.current]
  ::  The complete source closure was authenticated by registration. Numbered
  ::  Clay content is immutable; equality to its current native revision is
  ::  the freshness boundary, without recompiling or trusting Earthside files.
  ?.  =(source.source.a revision.working.p.current)  [%| %qpc-owner-source-changed]
  ::  Before dispatch use the next request; after preparation use the exact
  ::  pending request's original turn. This only reconstructs the expected
  ::  work commitment for the private reservation match, never journal data.
  =/  entry=entry:sessions  entry.u.input
  ?.  ?~(pending.entry %.y (gth turn.entry 0))  [%| %qpc-owner-pending-turn-invalid]
  =/  before=entry:sessions
    ?~  pending.entry  entry
    entry(turn (dec turn.entry))
  =/  work=work:obs  (work:bind r u.input(entry before))
  =/  measured  (prefixes inner b plan.a work revision.working.p.current)
  ?:  ?=(%| -.measured)  [%| p.measured]
  =/  cases  (raw:instrument inner b /x/qpc/cases/(scot %ux cases.plan.a))
  ?~  cases  [%| %qpc-owner-cases-unavailable]
  ?.  =(`cases.task.a u.cases)  [%| %qpc-owner-cases-changed]
  =/  book  (ledger b)
  ?:  ?=(%| -.book)  [%| p.book]
  =/  required-cantrip=[%qpc-session-gate-v1 %cantrip ids=(set @ux)]
    .^([%qpc-session-gate-v1 %cantrip ids=(set @ux)] %gx /(scot %p our.b)/cantrip/(scot %da now.b)/qpc/required-sessions/noun)
  ?.  (~(has in ids.required-cantrip) id)  [%| %qpc-owner-cantrip-unmanaged]
  =/  snapshot=snapshot:owner
    [u.input u.required u.ll (binding-of:instrument plan.a) id.law.a p.measured p.book]
  =/  v=view:bind  [r snapshot u.oo]
  =/  issue  (compatible:bind our.b v)
  ?^  issue  [%| u.issue]
  [%& v]
++  seal
  |=  [inner=agent:gall b=bowl:gall s=state:owner id=@ux]
  ^-  (each state:owner @tas)
  =/  found  (~(get by records.s) id)
  ?~  found  [%| %qpc-owner-not-open]
  =/  r=record:owner  u.found
  =/  input  (input:observer inner b id)
  ?~  input  [%| %qpc-owner-session-missing]
  =/  book  (ledger b)
  ?:  ?=(%| -.book)  [%| p.book]
  ?:  ?=(^ (cli-backend:provider selection.request.r))
    =/  kept  (lookup-cli:evidence our.b now.b id.request.r id key.r)
    ?:  ?=(%| -.kept)  [%| p.kept]
    (seal-cli:owner s our.b src.b u.input p.kept p.book)
  =/  kept  (lookup:evidence our.b now.b id.request.r id key.r)
  ?:  ?=(%| -.kept)  [%| p.kept]
  (seal-http:owner s our.b src.b u.input p.kept p.book)
--
