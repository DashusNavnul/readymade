::  Bounded native compilation for pinned, flat /- and /+ import closures.
::  No authority, writes, persistent cache, source rewriting or budget change.
::  Callers retain project admission, exact source and freshness checks.
::  Size/count ceilings bound this optimized route only; larger closures use
::  existing Ford under the caller's unchanged project and operation limits.
/-  spider
/+  io=strandio
|%
+$  result
  $%  [%built product=vase files=@ud bytes=@ud]
      [%failed reason=@tas trace=tang]
      [%unsupported reason=@tas]
  ==
+$  detailed  [built=(unit vase) detail=(unit @t)]
+$  dependency  [face=(unit @tas) pax=path]
+$  prepared  [pax=path deps=(list dependency) syntax=hoon]
+$  task  $%([%visit pax=path] [%finish file=prepared])
+$  discovery
  $%  [%ready bytes=@ud files=(list prepared)]
      [%failed reason=@tas trace=tang]
      [%unsupported reason=@tas]
  ==
++  attempt
  |=  [target=beak pax=path]
  =/  m  (strand:spider ,result)
  ^-  form:m
  ;<  b=bowl:spider  bind:m  get-bowl:io
  =/  ran  (mule |.((attempt-at target pax our.b now.b)))
  ?:  ?=(%| -.ran)
    (pure:m [%failed %native-flat-read-or-parse-failed p.ran])
  (pure:m p.ran)
++  build-file
  ::  Only unsupported semantics delegate to Ford. An actual flat-route
  ::  failure stays the existing missing-build result; +attempt retains tang.
  |=  [target=beak pax=path]
  =/  m  (strand:spider ,(unit vase))
  ^-  form:m
  ;<  got=result  bind:m  (attempt target pax)
  ?-  -.got
    %built        (pure:m `product.got)
    %failed       (pure:m ~)
    %unsupported  (build-file:io [target pax])
  ==
++  build-file-detail
  ::  Retain the first attempt's failure. Only unsupported semantics use
  ::  Ford, exactly as +build-file does; never recompile to explain an error.
  |=  [target=beak pax=path]
  =/  m  (strand:spider ,detailed)
  ^-  form:m
  ;<  got=result  bind:m  (attempt target pax)
  ?-  -.got
    %built   (pure:m [`product.got ~])
    %failed  (pure:m [~ `(failure-detail reason.got trace.got)])
    %unsupported
      ;<  built=(unit vase)  bind:m  (build-file:io [target pax])
      (pure:m [built ~])
  ==
++  compact-tank
  ::  Bound work BEFORE rendering. Per-atom and total bytes are separate:
  ::  many individually small cords must not produce an enormous frame.
  |=  value=tank
  ^-  ?
  =/  todo=(list *)  ~[value]
  =/  left=@ud  4.096
  =/  bytes=@ud  0
  |-  ^-  ?
  ?~  todo  %.y
  ?:  =(0 left)  %.n
  =/  node=*  i.todo
  ?^  node  $(todo [-.node +.node t.todo], left (dec left))
  =/  size=@ud  (met 3 node)
  ?:  |((gth size 4.096) (gth (add bytes size) 4.096))  %.n
  $(todo t.todo, left (dec left), bytes (add bytes size))
++  frame-text
  |=  value=tank
  ^-  @t
  ?.  (compact-tank value)  '[compiler frame omitted: size limit]'
  =/  text=@t  (crip ~(ram re value))
  ?:  (lte (met 3 text) 1.024)  text
  (cat 3 (end [3 992] text) ' [compiler frame truncated]')
++  failure-detail
  ::  Export text, never the compiler's VASE/TYPE tree. Inspect at most the
  ::  first 256 frames, then retain both ends of that bounded prefix.
  |=  [reason=@tas trace=tang]
  ^-  @t
  =/  limited=?  ?=(^ (slag 256 trace))
  =/  prefix=tang  (scag 256 trace)
  =/  frames=tang
    ?:  (lte (lent prefix) 16)  prefix
    (weld (scag 8 prefix) (flop (scag 8 (flop prefix))))
  =/  body=@t
    ?~  frames  '[compiler supplied no trace]'
    (rap 3 (join '\0a' (turn frames frame-text)))
  =/  notice=@t
    ?:(limited '\0a[compiler frame limit: first 256 only]' '')
  =/  text=@t  (rap 3 ~['Native compiler failure (' reason '):\0a' body notice])
  ?:  (lte (met 3 text) 6.144)  text
  (rap 3 ~[(end [3 3.040] text) '\0a[compiler trace truncated]\0a' (cut 3 [(sub (met 3 text) 3.040) 3.040] text)])
++  path-valid
  |=  pax=path
  ^-  ?
  ?.  ?=([?(%lib %sur) @ %hoon ~] pax)  %.n
  &((gth (met 3 i.t.pax) 0) (lte (met 3 i.t.pax) 128))
++  entry-valid
  ::  Explicit target paths need no import-name resolution. App and thread
  ::  entries use the same native parser and Zuse subject as library entries.
  |=  pax=path
  ^-  ?
  ?~  pax  %.n
  ?&  (lte (lent pax) 32)  =(%hoon (rear pax))
      (levy `path`pax |=(part=@ta &((gth (met 3 part) 0) (lte (met 3 part) 128))))
  ==
++  tree
  ::  Native immutable commit metadata; no Ford or mark conversion.
  |=  at=path
  ^-  (map path lobe:clay)
  =/  commit=tako:clay  .^(tako:clay %cs (weld at /tako/now))
  q:.^(yaki:clay %cs (weld at /yaki/(scot %uv commit)))
++  page
  |=  [at=path files=(map path lobe:clay) pax=path]
  ^-  (unit page:clay)
  =/  found  (~(get by files) pax)
  ?~  found  ~
  `.^(page:clay %cs (weld at /blob/(scot %uv u.found)))
++  fail
  |=  [reason=@tas pax=path]
  ^-  [%failed reason=@tas trace=tang]
  [%failed reason ~[leaf+(trip (spat pax))]]
++  attempt-at
  |=  [target=beak pax=path our=@p now=@da]
  ^-  result
  ?.  =(our p.target)  [%unsupported %native-flat-remote-target]
  ?.  ?=(%ud -.r.target)  [%unsupported %native-flat-unpinned-target]
  ?.  &((gth p.r.target 0) (lte (met 0 p.r.target) 64))
    [%unsupported %native-flat-unpinned-target]
  ?.  (entry-valid pax)  [%unsupported %native-flat-target-path]
  =/  at=path  /(scot %p p.target)/[q.target]/(scot %ud p.r.target)
  =/  files=(map path lobe:clay)  (tree at)
  =/  base-at=path  /(scot %p our)/base/(scot %da now)
  =/  wanted  (page at files /sys/kelvin)
  =/  native  (page base-at (tree base-at) /sys/kelvin)
  ?~  wanted  [%unsupported %native-flat-kelvin-unavailable]
  ?~  native  [%unsupported %native-flat-kelvin-unavailable]
  ?.  =(u.wanted u.native)  [%unsupported %native-flat-kelvin-mismatch]
  =/  ready=discovery  (discover at files pax)
  ?:  ?=(%failed -.ready)  ready
  ?:  ?=(%unsupported -.ready)  ready
  ::  Native Clay disables namespace forwarding during compilation. Sources
  ::  cannot use this optimization to scry their surrounding agent context.
  =/  built  (~(mule vi |) |.((compile files.ready pax)))
  ?:  ?=(%| -.built)  [%failed %native-flat-compile-failed p.built]
  [%built p.built (lent files.ready) bytes.ready]
++  discover
  ::  DFS produces postorder before any body is compiled. Cache identity is
  ::  path, not source hash: native source hints name the original path.
  |=  [at=path files=(map path lobe:clay) pax=path]
  ^-  discovery
  =/  todo=(list task)  ~[[%visit pax]]
  =/  seen=(set path)  ~
  =/  active=(set path)  ~
  =/  done=(set path)  ~
  =/  bytes=@ud  0
  =/  ready=(list prepared)  ~
  |-  ^-  discovery
  ?~  todo  [%ready bytes (flop ready)]
  =/  next=task  i.todo
  ?:  ?=(%finish -.next)
    =/  file=prepared  file.next
    ?.  &((~(has in active) pax.file) (levy deps.file |=(d=dependency (~(has in done) pax.d))))
      (fail %native-flat-dependency-order pax.file)
    $(todo t.todo, active (~(del in active) pax.file), done (~(put in done) pax.file), ready [file ready])
  =/  path=path  pax.next
  ?:  (~(has in done) path)  $(todo t.todo)
  ?:  (~(has in active) path)  (fail %native-flat-import-cycle path)
  ?:  (gte ~(wyt in seen) 256)  [%unsupported %native-flat-file-limit]
  ?.  |(=(path pax) (path-valid path))  [%unsupported %native-flat-import-path]
  =/  stored  (page at files path)
  ::  Native fit-path may find hyphen-to-directory variants. Its precedence
  ::  belongs to Ford; no missing flat path is silently interpreted here.
  ?~  stored  [%unsupported %native-flat-path-resolution]
  ?.  =(%hoon p.u.stored)  [%unsupported %native-flat-source-mark]
  ?.  ?=(@ q.u.stored)  (fail %native-flat-source-invalid path)
  =/  source=@t  q.u.stored
  =/  size=@ud  (met 3 source)
  ?:  =(size 0)  (fail %native-flat-source-empty path)
  ?:  (gth size 131.072)  [%unsupported %native-flat-source-size]
  ?:  (gth (add bytes size) 2.097.152)  [%unsupported %native-flat-total-size]
  ~|  [%native-flat-parse path]
  =/  parsed=pile:clay  (parse:parser path source)
  ?.  ?&(=(~ raw.parsed) =(~ raz.parsed) =(~ maz.parsed) =(~ caz.parsed) =(~ bar.parsed))
    [%unsupported %native-flat-special-header]
  =/  deps=(list dependency)
    %+  weld
      (turn sur.parsed |=(v=taut:clay [face.v /sur/[pax.v]/hoon]))
    (turn lib.parsed |=(v=taut:clay [face.v /lib/[pax.v]/hoon]))
  ?:  (gth (lent deps) 256)  [%unsupported %native-flat-import-limit]
  =/  file=prepared  [path deps hoon.parsed]
  =/  visits=(list task)  (turn deps |=(d=dependency [%visit pax.d]))
  =/  pending=(list task)  [[%finish file] t.todo]
  $(todo (weld visits pending), seen (~(put in seen) path), active (~(put in active) path), bytes (add bytes size))
++  compile
  |=  [todo=(list prepared) target=path]
  ^-  vase
  =/  built=(map path vase)  ~
  |-  ^-  vase
  ?~  todo  (~(got by built) target)
  =/  file=prepared  i.todo
  ~|  [%native-flat-compile pax.file]
  ?>  !(~(has by built) pax.file)
  =/  subject=vase
    =/  deps=(list dependency)  deps.file
    =/  subject=vase  !>(..zuse)
    |-  ^-  vase
    ?~  deps  subject
    =/  dep=vase  (~(got by built) pax.i.deps)
    =?  p.dep  ?=(^ face.i.deps)  [%face u.face.i.deps p.dep]
    $(deps t.deps, subject (slop dep subject))
  =/  product=vase  (slub subject syntax.file)
  $(todo t.todo, built (~(put by built) pax.file product))
++  parser
  ::  Exact native Clay parsing-rules/pile-rule from the proof loader.
  ::  Copied parser-helper fragment SHA256 (not the complete Clay file):
  ::  414b9fd18b6740ce558f435a01182d3f1cd42c40f49ee8cc826f146f4381eb44
  ::  Full original source retains /? semantics, path and line hints, and
  ::  the native %tssg body. Discovery rejects all five special import kinds.
  =,  clay
  |%
  ++  parsing-rules
    |%
    ++  pant
      |*  fel=^rule
      ;~(pose fel (easy ~))
    ::
    ++  mast
      |*  [bus=^rule fel=^rule]
      ;~(sfix (more bus fel) bus)
    ::
    ++  rune
      |*  [bus=^rule fel=^rule]
      %-  pant
      %+  mast  gap
      ;~(pfix fas bus gap fel)
    ::
    ++  taut-rule
      %+  cook  |=(taut +<)
      ;~  pose
        (stag ~ ;~(pfix tar sym))
        ;~(plug (stag ~ sym) ;~(pfix tis sym))
        (cook |=(a=term [`a a]) sym)
      ==
    --
  ::
  ++  pile-rule
    =>  [..lull parsing-rules]
    =,  clay
    |=  pax=path
    %-  full
    %+  ifix
      :_  gay
      ::  parse optional /? and ignore
      ::
      ;~(plug gay (punt ;~(plug fas wut gap dem gap)))
    ;~  plug
      %+  cook  (bake zing (list (list taut)))
      %+  rune  hep
      (most ;~(plug com gaw) taut-rule)
    ::
      %+  cook  (bake zing (list (list taut)))
      %+  rune  lus
      (most ;~(plug com gaw) taut-rule)
    ::
      %+  rune  tis
      ;~(plug sym ;~(pfix gap stap))
    ::
      %+  rune  sig
      ;~((glue gap) sym wyde:vast stap)
    ::
      %+  rune  cen
      ;~(plug sym ;~(pfix gap ;~(pfix cen sym)))
    ::
      %+  rune  buc
      ;~  (glue gap)
        sym
        ;~(pfix cen sym)
        ;~(pfix cen sym)
      ==
    ::
      %+  rune  tar
      ;~  (glue gap)
        sym
        ;~(pfix cen sym)
        ;~(pfix stap)
      ==
    ::
      %+  stag  %tssg
      (most gap tall:(vang & pax))
    ==
  ++  parse
    |=  [pax=path txt=@t]
    =/  [=hair res=(unit [pile=pile:clay =nail])]  ((pile-rule pax) [1 1] (trip txt))
    ~|  [%native-flat-syntax pax hair]
    ?>  ?=(^ res)
    pile.u.res
  --
--
