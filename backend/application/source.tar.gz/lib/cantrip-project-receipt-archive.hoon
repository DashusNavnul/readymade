::  Pure owner receipt archival law. No cards, native reads or app migration.
::  A stored suggestion means recorded by its owner, never delivered, taken,
::  checked or landed. Outstanding delivery observations remain separate.
/-  pa=cantrip-project-access, mp=multiplayer-project, nc=native-coding,
    j=cantrip-project-suggestion-journal
/+  access=cantrip-project-access, runtime=cantrip-project-access-runtime,
    recovery=cantrip-project-receipt, law=cantrip-law-window,
    names=native-coding-provider, journal=cantrip-project-suggestion-journal
|%
+$  key  [project=@t peer=@p generation=@ud nonce=@ux]
+$  pointer  [%cantrip-project-receipt-pointer-v1 key=key hash=@ux]
+$  head  [desk=@tas number=@ud commit=@uv]
+$  state  [head=(unit head) writing=(unit receipt:pa)]
+$  change  [state=state records=records:pa]
+$  found  (each (unit receipt:pa) @tas)
+$  indexed  (each (unit pointer) @tas)
+$  raw  (each (unit *) @tas)
+$  delivery  (unit (set key))
++  empty  *state
++  hot-limit  48
++  key-for
  |=  r=receipt:pa
  ^-  key
  [project.request.r peer.r generation.request.r nonce.request.r]
++  hash
  |=(r=receipt:pa ^-(@ux (shax (jam r))))
++  pointer-for
  |=(r=receipt:pa ^-(pointer [%cantrip-project-receipt-pointer-v1 (key-for r) (hash r)]))
++  path-for
  |=(digest=@ux ^-(path /project-access-history/receipts/(scot %ux digest)/noun))
++  nonce-path
  |=  k=key
  ^-  path
  /project-access-history/nonces/(scot %ux (shax (jam [%project-access-nonce-v1 k])))/noun
++  receipt-valid
  |=  [our=@p k=key r=receipt:pa]
  ^-  ?
  &((receipt-valid:runtime r) =(our owner.r) =(k (key-for r)))
++  valid
  |=  [our=@p s=state grants=grants:pa records=records:pa]
  ^-  ?
  ?.  (valid:runtime our grants records)  %.n
  ?~  head.s  ?=(~ writing.s)
  ?.  &((name-valid:names desk.u.head.s) !=(%base desk.u.head.s) (lte (met 0 commit.u.head.s) 256))  %.n
  ?~  writing.s  %.y
  =/  r=receipt:pa  u.writing.s
  &((receipt-valid our (key-for r) r) =(`r (~(get by records) (key-for r))))
++  delivery-keys
  ::  The future native adapter supplies its actual Gall bowl. Preserve exact
  ::  original/recovery subscriptions; absence does not prove peer delivery.
  |=  b=bowl:gall
  ^-  (set key)
  %-  silt
  %+  murn  ~(val by sup.b)
  |=  [peer=@p pax=path]
  ^-  (unit key)
  =/  original  (parse:runtime pax)
  ?^  original
    ?.  =(peer peer.u.original)  ~
    =/  q=request:pa  request.u.original
    `[project.q peer generation.q nonce.q]
  =/  recovered  (parse:recovery pax)
  ?~  recovered  ~
  ?.  =(peer peer.u.recovered)  ~
  =/  q  query.u.recovered
  `[project.q peer generation.q nonce.q]
++  choose
  ::  Total hot pressure, not the number of eligible rows, selects work.
  ::  Missing delivery observation is unknown and cannot authorize retirement.
  |=  [our=@p src=@p grants=grants:pa records=records:pa delivery=delivery]
  ^-  found
  ?.  =(our src)  [%| %receipt-archive-owner-required]
  ?.  (valid:runtime our grants records)  [%| %receipt-archive-journal-invalid]
  ?~  delivery  [%| %receipt-delivery-unobserved]
  ?.  (gth ~(wyt by records) hot-limit)  [%& ~]
  =/  eligible=(list receipt:pa)
    (skim ~(val by records) |=(r=receipt:pa !(~(has in u.delivery) (key-for r))))
  =.  eligible
    %+  sort  eligible
    |=  [a=receipt:pa z=receipt:pa]
    ?:(=(at.a at.z) (lth (hash a) (hash z)) (lth at.a at.z))
  [%& ?~(eligible ~ `i.eligible)]
++  begin
  ::  One retained intent only. No second submit while any outcome is pending.
  |=  [our=@p src=@p s=state grants=grants:pa records=records:pa r=receipt:pa delivery=delivery by-nonce=indexed by-hash=found]
  ^-  (each state @tas)
  ?.  =(our src)  [%| %receipt-archive-owner-required]
  ?.  (valid our s grants records)  [%| %receipt-archive-state-invalid]
  ?~  head.s  [%| %receipt-archive-unconfigured]
  ?^  writing.s  [%| %receipt-archive-pending]
  ?.  &((receipt-valid our (key-for r) r) =(`r (~(get by records) (key-for r))))
    [%| %receipt-archive-record-mismatch]
  ?~  delivery  [%| %receipt-delivery-unobserved]
  ?:  (~(has in u.delivery) (key-for r))  [%| %receipt-delivery-pending]
  ?:  ?=(%| -.by-nonce)  [%| p.by-nonce]
  ?:  ?=(%| -.by-hash)  [%| p.by-hash]
  ?.  &(=(~ p.by-nonce) =(~ p.by-hash))  [%| %receipt-archive-index-exists]
  [%& s(writing `r)]
++  append-valid
  |=  [before=head after=head r=receipt:pa old=yaki:clay new=yaki:clay]
  ^-  ?
  =/  pax=path  (path-for (hash r))
  =/  nonce=path  (nonce-path (key-for r))
  ?&  =(desk.before desk.after)  =(+(number.before) number.after)
      =(~[commit.before] p.new)
      !(~(has by q.old) pax)  !(~(has by q.old) nonce)
      =/  expected  (~(put by q.old) pax (page-to-lobe:clay [%noun r]))
      =(q.new (~(put by expected) nonce (page-to-lobe:clay [%noun (pointer-for r)])))
  ==
++  confirm
  ::  Native callers must supply exact numbered Clay observations and full
  ::  readback, never an ACK. Grant and delivery state are re-read in that event.
  |=  [our=@p src=@p s=state grants=grants:pa records=records:pa after=head old=yaki:clay new=yaki:clay observed=found delivery=delivery]
  ^-  (each change @tas)
  ?.  =(our src)  [%| %receipt-archive-owner-required]
  ?.  (valid our s grants records)  [%| %receipt-archive-state-invalid]
  ?~  head.s  [%| %receipt-archive-unconfigured]
  ?~  writing.s  [%| %receipt-archive-no-pending]
  =/  r=receipt:pa  u.writing.s
  ?~  delivery  [%| %receipt-delivery-unobserved]
  ?:  (~(has in u.delivery) (key-for r))  [%| %receipt-delivery-pending]
  ?:  ?=(%| -.observed)  [%| p.observed]
  ?.  =(`r p.observed)  [%| %receipt-archive-readback-mismatch]
  ?.  (append-valid u.head.s after r old new)  [%| %receipt-archive-append-mismatch]
  =/  next=records:pa  (~(del by records) (key-for r))
  =/  saved=state  [`after ~]
  ?>  (valid our saved grants next)
  [%& [saved next]]
++  decode-receipt
  |=  [our=@p actor=@p digest=@ux got=raw]
  ^-  found
  ?.  =(our actor)  [%| %receipt-archive-owner-required]
  ?:  ?=(%| -.got)  [%| p.got]
  ?~  p.got  [%& ~]
  =/  parsed  ((soft receipt:pa) u.p.got)
  ?~  parsed  [%| %receipt-archive-invalid]
  ?.  &((receipt-valid our (key-for u.parsed) u.parsed) =(u.p.got u.parsed) =(digest (hash u.parsed)))
    [%| %receipt-archive-invalid]
  [%& parsed]
++  decode-pointer
  |=  [our=@p actor=@p k=key got=raw]
  ^-  indexed
  ?.  =(our actor)  [%| %receipt-archive-owner-required]
  ?:  ?=(%| -.got)  [%| p.got]
  ?~  p.got  [%& ~]
  =/  parsed  ((soft pointer) u.p.got)
  ?~  parsed  [%| %receipt-archive-index-invalid]
  ?.  &(=(u.p.got u.parsed) =(k key.u.parsed) !=(0 hash.u.parsed) (lte (met 0 hash.u.parsed) 256))
    [%| %receipt-archive-index-invalid]
  [%& parsed]
++  join
  |=  [our=@p actor=@p k=key index=indexed got=found]
  ^-  found
  ?.  =(our actor)  [%| %receipt-archive-owner-required]
  ?:  ?=(%| -.index)  [%| p.index]
  ?~  p.index  [%& ~]
  ?:  ?=(%| -.got)  [%| p.got]
  ?~  p.got  [%| %receipt-archive-body-unavailable]
  =/  r=receipt:pa  u.p.got
  ?.  &((receipt-valid our k r) =(u.p.index (pointer-for r)))
    [%| %receipt-archive-index-mismatch]
  got
++  replay
  ::  Current canonical catalog/member/grant/law must authorize even an exact
  ::  historical nonce. The receipt remains evidence, never fresh authority.
  |=  [our=@p actor=@p now=@da p=project:mp grants=grants:pa r=request:pa w=window:law scope=(unit project:nc) got=found]
  ^-  found
  ?.  (request-valid:runtime r)  [%| %request-invalid]
  =/  permitted  (authorize-scoped:access our actor now p grants r w scope)
  ?:  ?=(%| -.permitted)  [%| p.permitted]
  ?:  ?=(%| -.got)  [%| p.got]
  ?~  p.got  [%& ~]
  =/  old=receipt:pa  u.p.got
  ?.  (receipt-valid our [project.r actor generation.r nonce.r] old)
    [%| %receipt-archive-invalid]
  ?.  &(=(r request.old) =((digest:access p.permitted) grant.old))
    [%| %nonce-conflict]
  got
::  Additive mixed-format API. A future app must use ONE shared-state for
::  both maps; keeping the old writer alongside this one is not supported.
+$  shared-state  [head=(unit head) writing=(unit entry:j)]
+$  shared-change  [state=shared-state records=journal:j]
++  upgrade-state
  |=  s=state
  ^-  shared-state
  [head.s ?~(writing.s ~ `[%legacy u.writing.s])]
++  shared-valid
  |=  [our=@p s=shared-state grants=grants:pa records=journal:j]
  ^-  ?
  ?.  (valid:journal our grants records)  %.n
  ?~  head.s  ?=(~ writing.s)
  ?.  &((name-valid:names desk.u.head.s) !=(%base desk.u.head.s) (lte (met 0 commit.u.head.s) 256))  %.n
  ?~  writing.s  %.y
  =/  r=entry:j  u.writing.s
  &((entry-valid:journal our r) =(`r (lookup:journal records (key-for:journal r))))
++  shared-pointer
  |=  r=entry:j
  ^-  pointer
  [%cantrip-project-receipt-pointer-v1 (key-for:journal r) (hash:journal r)]
++  shared-delivery-keys
  ::  Prospective bundle transport paths share the permanent identity. Exact
  ::  actor/path joins only; a native caller must provide actual sup.bowl.
  |=  b=bowl:gall
  ^-  (set key)
  %-  ~(uni in (delivery-keys b))
  %-  silt
  %+  murn  ~(val by sup.b)
  |=  [peer=@p pax=path]
  ^-  (unit key)
  ?.  ?=([?(%project-bundle %project-bundle-receipt) *] pax)  ~
  =/  parsed  (view-parse:runtime pax(i %project-view))
  ?~  parsed  ~
  ?.  =(peer peer.u.parsed)  ~
  =/  q  query.u.parsed
  `[project.q peer generation.q nonce.q]
++  shared-choose
  |=  [our=@p src=@p grants=grants:pa records=journal:j delivery=delivery]
  ^-  observed:j
  ?.  =(our src)  [%| %receipt-archive-owner-required]
  ?.  (valid:journal our grants records)  [%| %receipt-archive-journal-invalid]
  ?~  delivery  [%| %receipt-delivery-unobserved]
  ?.  (gth (count:journal records) hot-limit)  [%& ~]
  =/  eligible=(list entry:j)
    (skim (entries:journal records) |=(r=entry:j !(~(has in u.delivery) (key-for:journal r))))
  =.  eligible
    %+  sort  eligible
    |=  [a=entry:j z=entry:j]
    ?:(=((at:journal a) (at:journal z)) (lth (hash:journal a) (hash:journal z)) (lth (at:journal a) (at:journal z)))
  [%& ?~(eligible ~ `i.eligible)]
++  shared-begin
  |=  [our=@p src=@p s=shared-state grants=grants:pa records=journal:j r=entry:j delivery=delivery by-nonce=indexed by-hash=observed:j]
  ^-  (each shared-state @tas)
  ?.  =(our src)  [%| %receipt-archive-owner-required]
  ?.  (shared-valid our s grants records)  [%| %receipt-archive-state-invalid]
  ?~  head.s  [%| %receipt-archive-unconfigured]
  ?^  writing.s  [%| %receipt-archive-pending]
  ?.  &((entry-valid:journal our r) =(`r (lookup:journal records (key-for:journal r))))
    [%| %receipt-archive-record-mismatch]
  ?~  delivery  [%| %receipt-delivery-unobserved]
  ?:  (~(has in u.delivery) (key-for:journal r))  [%| %receipt-delivery-pending]
  ?:  ?=(%| -.by-nonce)  [%| p.by-nonce]
  ?:  ?=(%| -.by-hash)  [%| p.by-hash]
  ?.  &(=(~ p.by-nonce) =(~ p.by-hash))  [%| %receipt-archive-index-exists]
  [%& s(writing `r)]
++  shared-append-valid
  |=  [before=head after=head r=entry:j old=yaki:clay new=yaki:clay]
  ^-  ?
  =/  pax=path  (path-for (hash:journal r))
  =/  nonce=path  (nonce-path (key-for:journal r))
  ?&  =(desk.before desk.after)  =(+(number.before) number.after)
      =(~[commit.before] p.new)
      !(~(has by q.old) pax)  !(~(has by q.old) nonce)
      =/  expected  (~(put by q.old) pax (page-to-lobe:clay [%noun (raw:journal r)]))
      =(q.new (~(put by expected) nonce (page-to-lobe:clay [%noun (shared-pointer r)])))
  ==
++  shared-confirm
  |=  [our=@p src=@p s=shared-state grants=grants:pa records=journal:j after=head old=yaki:clay new=yaki:clay observed=observed:j delivery=delivery]
  ^-  (each shared-change @tas)
  ?.  =(our src)  [%| %receipt-archive-owner-required]
  ?.  (shared-valid our s grants records)  [%| %receipt-archive-state-invalid]
  ?~  head.s  [%| %receipt-archive-unconfigured]
  ?~  writing.s  [%| %receipt-archive-no-pending]
  =/  r=entry:j  u.writing.s
  ?~  delivery  [%| %receipt-delivery-unobserved]
  ?:  (~(has in u.delivery) (key-for:journal r))  [%| %receipt-delivery-pending]
  ?:  ?=(%| -.observed)  [%| p.observed]
  ?.  =(`r p.observed)  [%| %receipt-archive-readback-mismatch]
  ?.  (shared-append-valid u.head.s after r old new)  [%| %receipt-archive-append-mismatch]
  =/  next=journal:j  (remove:journal records (key-for:journal r))
  =/  saved=shared-state  [`after ~]
  ?>  (shared-valid our saved grants next)
  [%& [saved next]]
++  shared-decode
  |=  [our=@p actor=@p digest=@ux got=raw]
  ^-  observed:j
  ?.  =(our actor)  [%| %receipt-archive-owner-required]
  ?:  ?=(%| -.got)  [%| p.got]
  ?~  p.got  [%& ~]
  =/  body=*  u.p.got
  =/  bundle  ((soft bundle:pa) body)
  ?^  bundle
    =/  r=entry:j  [%bundle u.bundle]
    ?.  &((entry-valid:journal our r) =(body (raw:journal r)) =(digest (hash:journal r)))
      [%| %receipt-archive-invalid]
    [%& `r]
  =/  old  (decode-receipt our actor digest got)
  ?:  ?=(%| -.old)  [%| p.old]
  [%& ?~(p.old ~ `[%legacy u.p.old])]
++  shared-join
  |=  [our=@p actor=@p k=key index=indexed got=observed:j]
  ^-  observed:j
  ?.  =(our actor)  [%| %receipt-archive-owner-required]
  ?:  ?=(%| -.index)  [%| p.index]
  ?:  ?=(%| -.got)  [%| p.got]
  ?~  p.index
    ?~  p.got  [%& ~]
    [%| %receipt-archive-index-missing]
  ?~  p.got  [%| %receipt-archive-body-unavailable]
  =/  r=entry:j  u.p.got
  ?.  &((entry-valid:journal our r) =(k (key-for:journal r)) =(u.p.index (shared-pointer r)))
    [%| %receipt-archive-index-mismatch]
  got
--
