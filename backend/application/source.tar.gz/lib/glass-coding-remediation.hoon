::  Viki's bounded correction guidance, before any further model request.
::  Full failure evidence preserves the original goal, intent, checks, source
::  and candidate. Structural validity never authenticates imported evidence;
::  callers establish ownership from the exact judgment retained in Graf.
::  No dispatch, write, timer, retry reservation or authority lives here.
/+  execution=glass-coding-execution, result=glass-coding-result
|%
+$  evidence
  $%  [%checks judgment=judgment:execution]
      [%compiler rejection=rejection:result]
  ==
+$  guidance
  [%glass-coding-remediation-v1 evidence=evidence instructions=@t]
++  max-instructions  `@ud`16.384
++  failure
  |=  e=evidence
  ^-  failure:result
  ?:(?=(%checks -.e) judgment.e rejection.e)
++  pending
  |=  e=evidence
  ^-  pending:execution
  (failure-pending:result (failure e))
++  evidence-valid
  |=  e=evidence
  ^-  ?
  (failure-rejected:result (failure e))
++  check-text  check-text:result
++  instructions
  |=  e=evidence
  ^-  @t
  (failure-guidance:result (failure e))
++  make
  ::  Structural constructor only. The reader authenticates the retained
  ::  judgment before deriving guidance; no second retention is required.
  |=  e=evidence
  ^-  (each guidance @tas)
  ?.  (evidence-valid e)  [%| %failure-not-remediable]
  =/  text=@t  (instructions e)
  ?:  (gth (met 3 text) max-instructions)  [%| %guidance-over-limit]
  [%& [%glass-coding-remediation-v1 e text]]
++  from-checks
  ::  Called by the owner from its exact retained judgment continuation.
  |=  [our=@p actor=@p j=judgment:execution]
  ^-  (each guidance @tas)
  ?.  &(=(our actor) =(our owner.order.pending.j))  [%| %foreign-owner]
  (make [%checks j])
++  from-compiler
  ::  The owner supplies its exact retained compiler refusal.
  |=  [our=@p actor=@p r=rejection:result]
  ^-  (each guidance @tas)
  ?.  &(=(our actor) =(our owner.order.pending.r))  [%| %foreign-owner]
  (make [%compiler r])
++  valid
  |=  g=guidance
  ^-  ?
  =/  made  (make evidence.g)
  &(?=(%& -.made) =(p.made g))
--
