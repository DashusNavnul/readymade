::  Exact native compilation requests. No image import, execution, or write.
/-  vc=vibecoding-candidate
/+  protocol=vibecoding-compile-protocol, clw=cantrip-law-window,
    lr=vibecoding-local-result, vcl=vibecoding-candidate,
    vcr=vibecoding-candidate-review
|%
+$  binding
  [%vibecoding-compiler-binding-v1 owner=@p worker=@p desk=@tas root=@uv hoon=@ux zuse=@ux]
+$  snapshot
  $:  %vibecoding-compile-snapshot-v1
      order=order:protocol  binding=binding
      accepted=revision:vc  working=revision:vc
      candidate=@ux  review=@ux  law=@ux  intent=@ux
  ==
+$  admission  [snapshot=snapshot at=@da]
+$  record
  [%vibecoding-compilation-v1 snapshot=snapshot artifact=artifact:protocol received=@da]
+$  refusal
  $?  %foreign-actor  %compiler-binding-invalid  %binding-missing
      %binding-conflict  %agent-unavailable  %result-unavailable
      %project-changed  %intent-changed  %law-changed  %probe-not-admitted
      %request-invalid  %expired-request  %artifact-mismatch
  ==
+$  decision  (each admission refusal)
++  binding-valid
  |=  b=binding
  ^-  ?
  ?&  =(%earl (clan:title worker.b))  =(owner.b (^sein:title worker.b))
      !=(owner.b worker.b)  =(%compiler desk.b)
      !=(0 root.b)  !=(0 hoon.b)  !=(0 zuse.b)
  ==
++  binding-fact
  |=  b=binding
  [%vibecoding-compiler-binding (scot %ux (digest:vcl b)) b]
++  valid
  |=  s=snapshot
  ^-  ?
  ?&  (binding-valid binding.s)  (valid:protocol order.s)
      =(owner.binding.s owner.order.s)  =(worker.binding.s worker.order.s)
      =(%pataphor-demo desk.accepted.s)  =(%pataphor-demo-work desk.working.s)
      (gth number.accepted.s 0)  (gth number.working.s 0)
      !=(0 root.accepted.s)  !=(0 root.working.s)
      !=(0 candidate.s)  !=(0 review.s)  !=(0 law.s)  !=(0 intent.s)
  ==
++  permission
  |=  window=window:clw
  ^-  ?
  %+  levy  `(list act:clw)`~[%probe %compare]
  |=  act=act:clw
  ?&  (~(has in admissible.window) act)
      !(~(has in blocked.window) act)
      !(~(has in never-auto.window) act)
  ==
++  view-valid
  |=  [our=@p at=@da view=view:lr]
  ^-  ?
  ?&  =(our owner.view)  =(at at.view)
      historical.view  fresh.view  verified.receipt.view
      =(key.view (digest:vcl receipt.view))
      (linked:lr our at receipt.view candidate.view review.view)
      (fresh:lr receipt.view current.view)
  ==
++  law-valid
  |=  [view=view:lr window=window:clw]
  ^-  ?
  =/  checked  (prepare:vcr candidate.view window proposed-at.proposal.body.review.view)
  ?:  ?=(%| -.checked)  %.n
  =(proposal.p.checked proposal.body.review.view)
++  freeze
  |=  [our=@p actor=@p at=@da b=binding view=view:lr window=window:clw]
  ^-  (each snapshot refusal)
  ?.  =(our actor)  [%| %foreign-actor]
  ?.  &((binding-valid b) =(our owner.b))  [%| %compiler-binding-invalid]
  ?.  (view-valid our at view)  [%| %project-changed]
  ?.  (permission window)  [%| %probe-not-admitted]
  ?.  (law-valid view window)  [%| %law-changed]
  =/  context=context:vc  (context-of:vcl packet.candidate.view)
  =/  o=order:protocol
    [%vibecoding-compile-order-v1 our worker.b key.view source.candidate.view (shax source.candidate.view) at (add at ~m5)]
  =/  s=snapshot
    :*  %vibecoding-compile-snapshot-v1  o  b
        [%pataphor-demo accepted-number.current.view (need root.accepted.current.view)]
        [%pataphor-demo-work work-number.current.view (need root.working.current.view)]
        (digest:vcl candidate.view)  digest.review.view
        (digest:vcl window)  (digest:vcl intent.context)
    ==
  ?.  (valid s)  [%| %request-invalid]
  [%& s]
++  admit
  |=  [our=@p actor=@p at=@da s=snapshot view=view:lr window=window:clw]
  ^-  decision
  ?.  =(our actor)  [%| %foreign-actor]
  ?.  &((valid s) =(our owner.order.s))  [%| %request-invalid]
  ?.  &((lte at.order.s at) (lth at expires.order.s))  [%| %expired-request]
  =/  fresh  (freeze our actor at binding.s view window)
  ?:  ?=(%| -.fresh)  [%| p.fresh]
  ::  Refresh permission, not the frozen bytes, compiler, identity, or deadline.
  =/  expected=order:protocol  order.p.fresh(at at.order.s, expires expires.order.s)
  =/  current=snapshot  p.fresh(order expected)
  ?.  =(s current)  [%| %project-changed]
  [%& [s at]]
++  dispatch
  |=  [our=@p now=@da a=admission]
  ^-  (unit card:agent:gall)
  =/  s=snapshot  snapshot.a
  ?.  &((valid s) =(our owner.order.s) =(now at.a) (lte at.order.s now) (lth now expires.order.s))  ~
  `[%pass /compiler-order/(scot %ux (digest:protocol order.s)) %agent [worker.order.s %vibecoding-compiler] %poke %noun !>([%compile order.s])]
++  receive
  |=  [our=@p src=@p now=@da s=snapshot a=artifact:protocol]
  ^-  (each record refusal)
  ?.  &((valid s) =(our owner.order.s) =(src worker.order.s))  [%| %foreign-actor]
  ?.  &((lte at.order.s now) (lth now expires.order.s))  [%| %expired-request]
  ?.  ?&  (matches:protocol order.s a)
          =(desk.binding.s q.beak.compiler.a)
          =(root.binding.s root.compiler.a)
          =(hoon.binding.s hoon.compiler.a)  =(zuse.binding.s zuse.compiler.a)
          (lte at.compiler.a now)
      ==  [%| %artifact-mismatch]
  [%& [%vibecoding-compilation-v1 s a now]]
++  record-valid
  |=  r=record
  ^-  ?
  =/  s=snapshot  snapshot.r
  =/  result  (receive owner.order.s worker.order.s received.r s artifact.r)
  &(?=(%& -.result) =(p.result r))
++  fact
  |=  r=record
  [%vibecoding-compilation (scot %ux (digest:vcl r)) r]
--
