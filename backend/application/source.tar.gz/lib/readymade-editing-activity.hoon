::  Project file activity is advisory, never a permission or source mutation.
::  Caller supplies same-event canonical observation and current Cantrip window.
::  Keep the per-actor sequence tombstones: expiry hides activity, not ordering.
/-  pa=cantrip-project-access
/+  access=cantrip-project-access, sharing=readymade-project-sharing,
    coding=native-coding-project, projects=multiplayer-project,
    law=cantrip-law-window
|%
+$  file  [desk=@tas pax=path]
+$  update  [sequence=@ud file=(unit file)]
+$  entry  [update=update received=@da binding=@ux]
+$  state  (map @p entry)
++  permission
  |=  [o=observation:sharing w=window:law who=@p f=file editing=?]
  ^-  (unit @ux)
  ?.  ?&  (project-valid:projects catalog.o)
          (time-valid:projects catalog.o at.o)
          =(owner.o authority.spec.catalog.o)
          (path-valid:access pax.f)
          (~(has in admissible.w) %read)
          !(~(has in blocked.w) %read)
          |(!editing &((~(has in admissible.w) %compare) !(~(has in blocked.w) %compare)))
      ==  ~
  ?:  =(who owner.o)
    =/  scope  scope.o
    ?~  scope  ~
    ?.  ?&  (valid:coding u.scope)  =(spec.catalog.o spec.u.scope)
            |(=(desk.f working.u.scope) =(desk.f base-desk.spec.catalog.o))
            (readable:coding u.scope pax.f)
        ==  ~
    `(shax (jam [%readymade-activity-owner-v1 spec.catalog.o u.scope]))
  =/  held  (~(get by held.o) [id.spec.catalog.o who])
  ?~  held  ~
  =/  g=grant:pa  grant.u.held
  ?.  ?&  !revoked.u.held  =(who peer.g)
          (grant-valid:access g)
          (member-scoped:access owner.o at.o catalog.o g scope.o)
          (time-valid:access g at.o)
          =(desk.f desk.g)  (~(has in paths.g) pax.f)
          view.permissions.g  |(!editing suggest.permissions.g)
      ==  ~
  `(digest:access g)
++  apply
  ::  src is Gall's authenticated actor, never a body-provided ship name.
  |=  [o=observation:sharing w=window:law s=state src=@p u=update]
  ^-  (each state @tas)
  ?.  &((gth sequence.u 0) (lte (met 0 sequence.u) 64))
    [%| %activity-sequence-invalid]
  =/  old  (~(get by s) src)
  ?:  &(?=(~ old) ?=(~ file.u))  [%| %activity-missing]
  ?:  ?~(old %.n =(u update.u.old))  [%& s]
  ?.  =(sequence.u ?~(old 1 +(sequence.update.u.old)))
    [%| %activity-sequence-conflict]
  ?:  &(?=(~ old) (gte ~(wyt by s) 32))  [%| %activity-capacity]
  =/  permitted=(unit @ux)
    ?~  file.u  [~ `@ux`0]
    (permission o w src u.file.u %.y)
  ?~  permitted  [%| %activity-permission-refused]
  =/  binding=@ux
    u.permitted
  [%& (~(put by s) src [u at.o binding])]
++  visible
  ::  Revalidate both parties on every disclosure. No file text is retained.
  |=  [o=observation:sharing w=window:law s=state viewer=@p]
  ^-  (list [ship=@p file=file])
  %+  murn  ~(tap by s)
  |=  [ship=@p e=entry]
  =/  f  file.update.e
  ?~  f  ~
  ?.  &((lte received.e at.o) (lth at.o (add received.e ~s30)))  ~
  =/  actor  (permission o w ship u.f %.y)
  =/  recipient  (permission o w viewer u.f %.n)
  ?.  &(?=(^ actor) ?=(^ recipient))  ~
  ?.  =(binding.e u.actor)  ~
  `[ship u.f]
::  Native transport boundary. Epoch is the owning event's time, not grant expiry.
+$  address  [owner=@p project=@t epoch=@da]
+$  room  [address=address entries=state]
+$  message  [address=address update=update]
++  open-room
  |=  o=observation:sharing
  ^-  (each room @tas)
  ?.  ?&  (project-valid:projects catalog.o)
          (time-valid:projects catalog.o at.o)
          =(owner.o authority.spec.catalog.o)
          !=(0 at.o)
      ==  [%| %activity-scope-invalid]
  [%& [[owner.o id.spec.catalog.o at.o] ~]]
++  reset-room
  ::  Never clear tombstones without advancing the epoch, including same-event load.
  |=  [o=observation:sharing r=room]
  ^-  (each room @tas)
  ?.  (gth at.o epoch.address.r)  [%| %activity-epoch-not-advanced]
  (open-room o)
++  room-current
  |=  [o=observation:sharing r=room a=address]
  ^-  ?
  ?&  =(address.r a)  =(owner.o owner.a)
      =(id.spec.catalog.o project.a)
      !=(0 epoch.a)  (lte epoch.a at.o)
      (project-valid:projects catalog.o)
      (time-valid:projects catalog.o at.o)
      =(owner.o authority.spec.catalog.o)
  ==
++  receive
  |=  [o=observation:sharing w=window:law r=room src=@p msg=message]
  ^-  (each room @tas)
  ?.  (room-current o r address.msg)  [%| %activity-scope-mismatch]
  =/  changed  (apply o w entries.r src update.msg)
  ?-  -.changed
    %|  [%| p.changed]
    %&  [%& r(entries p.changed)]
  ==
++  read-room
  |=  [o=observation:sharing w=window:law r=room viewer=@p a=address]
  ^-  (list [ship=@p file=file])
  ?.  (room-current o r a)  ~
  (visible o w entries.r viewer)
--
