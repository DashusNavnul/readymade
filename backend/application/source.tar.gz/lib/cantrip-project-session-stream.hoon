::  Items 31 and 32: stream one shared session's status to a peer, and let the
::  peer reconnect from a cursor.
::
::  A stream is one authenticated Ames watch that stays open. Opening it runs
::  the same authority check as the one-shot observation (cantrip-project-
::  session: share, inspection grant, membership, law window); so does every
::  later update. While any stream is open, one Behn tick every 15 s rechecks
::  each stream and sends a fact only when the session's sequence moved. When
::  authority ends, the stream gets a final %ended fact with the reason and is
::  closed. A reconnect names the last sequence the peer holds (the cursor):
::  authority is checked again, and nothing is sent unless the session moved
::  past it. Nothing here is saved; the last-sent map is transient.
/-  pa=cantrip-project-access, ps=cantrip-project-session
/+  core=cantrip-project-session, runtime=cantrip-project-session-runtime,
    law=cantrip-law-window
|%
+$  update
  $%  [%status response=response:ps sequence=@ud]
      [%ended reason=@tas]
  ==
+$  event  [%cantrip-project-session-stream-v1 =update]
+$  sent  (map path @ud)
++  tick-every  ~s15
++  limit  16
::  One peer's share of the table. A peer's own agent follows at most eight
::  sessions; without this one ship could hold all sixteen streams and every
::  other peer was refused. Counted by session, not by subscription: a peer
::  that opens a session again under a new cursor (its agent restarted and
::  forgot the first) leaves a subscription behind, which must neither count
::  against it nor stay in the table.
++  per-peer  8
++  sessions-of
  ::  The distinct sessions one ship streams.
  |=  [sup=bitt:gall who=@p]
  ^-  (set @ux)
  %-  silt
  %+  murn  ~(val by sup)
  |=  [s=@p p=path]
  ?.  =(who s)  ~
  =/  parsed  (parse p)
  ?~(parsed ~ `session.query.u.parsed)
++  stale
  ::  This ship's other subscriptions to the session `pax` opens: the same
  ::  session under another cursor or an older query.
  |=  [sup=bitt:gall who=@p pax=path]
  ^-  (list path)
  =/  mine  (parse pax)
  ?~  mine  ~
  %~  tap  in
  %-  silt
  %+  murn  ~(val by sup)
  |=  [s=@p p=path]
  ?.  &(=(who s) !=(p pax))  ~
  =/  other  (parse p)
  ?~  other  ~
  ?.(=(session.query.u.other session.query.u.mine) ~ `p)
++  replace
  ::  End the subscriptions a watch replaces: one kick each, to that ship
  ::  only, and their sequences forgotten.
  |=  [old=(list path) who=@p s=sent]
  ^-  [cards=(list card:agent:gall) s=sent]
  :-  (turn old |=(p=path `card:agent:gall`[%give %kick ~[p] `who]))
  (roll old |=([p=path acc=_s] (~(del by acc) p)))
++  room
  ::  held: every stream path in the table, the one being opened included;
  ::  replaced: how many of them this watch ends; mine: the sessions the
  ::  peer streams, this one included.
  |=  [held=@ud replaced=@ud mine=@ud]
  ^-  (each ~ @tas)
  ?:  (gth mine per-peer)  [%| %stream-peer-limit]
  ?:  (gth (sub held (min held replaced)) limit)  [%| %stream-capacity]
  [%& ~]
++  route
  |=  [peer=@p q=query:ps cursor=@ud]
  ^-  path
  =/  base=path  [%project-session-stream (slag 1 (route:core peer q))]
  (snoc base (scot %ud cursor))
++  parse
  |=  pax=path
  ^-  (unit [peer=@p query=query:ps cursor=@ud])
  ?.  ?=([%project-session-stream *] pax)  ~
  =/  rest=path  t.pax
  ?.  =(7 (lent rest))  ~
  =/  base  (parse:core `path`[%project-session (scag 6 rest)])
  ?~  base  ~
  =/  c  (slaw %ud (rear rest))
  ?~  c  ~
  `[peer.u.base query.u.base u.c]
++  streaming
  |=  b=bowl:gall
  ^-  (list path)
  %~  tap  in
  %-  silt
  %+  murn  ~(val by sup.b)
  |=([s=@p p=path] ?.(?=([%project-session-stream *] p) ~ `p))
++  sequence
  |=  [b=bowl:gall session=@ux]
  ^-  (unit @ud)
  =/  raw=*
    .^(* %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/session/(scot %ux session)/noun)
  =/  decoded  ((soft ,(unit session-view:core)) raw)
  ?~  decoded  ~
  ?~  u.decoded  ~
  `sequence.u.u.decoded
++  look
  ::  One authority-checked observation of one peer's session, and its sequence.
  |=  [b=bowl:gall peer=@p grants=grants:pa held=scopes:core q=query:ps w=window:law]
  ^-  (each [r=response:ps n=@ud] @tas)
  =/  checked  (preflight:core our.b peer q held w)
  ?:  ?=(%| -.checked)  [%| p.checked]
  =/  observed  (mole |.((observe:runtime b(src peer) grants held q w)))
  ?~  observed  [%| %session-observation-unavailable]
  ?:  ?=(%| -.u.observed)  [%| p.u.observed]
  =/  s  (mole |.((sequence b session.q)))
  ?~  s  [%| %session-observation-unavailable]
  ?~  u.s  [%| %session-missing]
  [%& p.u.observed u.u.s]
++  fact
  |=  [pax=path u=update]
  ^-  card:agent:gall
  [%give %fact ~[pax] %noun !>(`event`[%cantrip-project-session-stream-v1 u])]
++  timer
  ::  At most one tick per 15 s slot, however many streams armed it.
  |=  now=@da
  ^-  (list card:agent:gall)
  =/  slot=@da  (add (sub now (mod now tick-every)) tick-every)
  :~  [%pass /project-session-stream/tick %arvo %b %rest slot]
      [%pass /project-session-stream/tick %arvo %b %wait slot]
  ==
++  watch
  |=  [b=bowl:gall grants=grants:pa held=scopes:core pax=path w=window:law s=sent]
  ^-  (each [cards=(list card:agent:gall) s=sent] @tas)
  =/  parsed  (parse pax)
  ?~  parsed  [%| %path-invalid]
  ?.  =(src.b peer.u.parsed)  [%| %foreign-peer]
  ::  What this watch replaces is ended here and does not count.
  =/  old=(list path)  (stale sup.b src.b pax)
  =/  fits  (room (lent (streaming b)) (lent old) ~(wyt in (sessions-of sup.b src.b)))
  ?:  ?=(%| -.fits)  [%| p.fits]
  =/  seen  (look b peer.u.parsed grants held query.u.parsed w)
  ?:  ?=(%| -.seen)  [%| p.seen]
  =/  replaced  (replace old src.b s)
  =/  later=(list card:agent:gall)  (weld cards.replaced (timer now.b))
  =.  s  s.replaced
  ::  A reconnect already holding this sequence gets nothing new.
  ?:  &(!=(0 cursor.u.parsed) (lte n.p.seen cursor.u.parsed))
    [%& later (~(put by s) pax n.p.seen)]
  [%& [(fact pax [%status p.seen]) later] (~(put by s) pax n.p.seen)]
++  tick
  |=  [b=bowl:gall grants=grants:pa held=scopes:core w=window:law s=sent]
  ^-  [cards=(list card:agent:gall) s=sent]
  =/  paths=(list path)  (streaming b)
  =/  again=?  !=(~ paths)
  =/  kept=sent  (malt (skim ~(tap by s) |=([p=path n=@ud] (lien paths |=(q=path =(p q))))))
  =|  cards=(list card:agent:gall)
  |-  ^-  [cards=(list card:agent:gall) s=sent]
  ?~  paths  [?.(again cards (weld cards (timer now.b))) kept]
  =/  parsed  (parse i.paths)
  ?~  parsed  $(paths t.paths)
  =/  seen  (look b peer.u.parsed grants held query.u.parsed w)
  ?:  ?=(%| -.seen)
    %=  $
      paths  t.paths
      kept   (~(del by kept) i.paths)
      cards  (weld cards ~[(fact i.paths [%ended p.seen]) [%give %kick ~[i.paths] ~]])
    ==
  ?:  =(`n.p.seen (~(get by kept) i.paths))  $(paths t.paths)
  $(paths t.paths, kept (~(put by kept) i.paths n.p.seen), cards (snoc cards (fact i.paths [%status p.seen])))
--
