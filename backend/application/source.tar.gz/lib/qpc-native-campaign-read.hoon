::  Actual native task/scope/source reads; no caller-authored eligibility.
/-  np=native-coding-provider
/+  c=qpc-native-campaign, instrument=qpc-instrument-read-contract, law=qpc-law-core,
    q=qpc-native-outcome, project=native-coding-project,
    source=qpc-instrument-source, ct=cantrip-native-coding,
    local=native-coding-local-review, guard=viki-scry-guard,
    successor=qpc-successor-window, selected=qpc-selected-history,
    measured=qpc-selected-measurement, accept=native-coding-accept,
    declarations=qpc-native-declaration, provider=native-coding-provider,
    att=native-coding-provider-attestation, reservation=qpc-session-reservation
|%
+$  reader
  $-([inner=agent:gall b=bowl:gall command=command:c unused=?] (each snapshot:c @tas))
+$  terminal  [enrollment=@ux receipt=receipt:measured acceptance=record:accept]
++  selection
  |=  [b=bowl:gall key=@tas expected=selection:np]
  ^-  (unit @tas)
  ?:  ?=(^ (cli-backend:provider expected))
    =/  paired  (current-cli:att our.b now.b key expected)
    ?:(?=(%| -.paired) `p.paired ~)
  ?.  (agent-live:guard our.b now.b %codex-inference)  `%qpc-campaign-provider-unavailable
  =/  status=*
    .^(* %gx /(scot %p our.b)/codex-inference/(scot %da now.b)/native-coding/status/noun)
  ?.  ?=([%native-coding-inference-status-v1 %viki @ @ @ @] status)
    `%qpc-campaign-provider-owner-mismatch
  =/  actual=*
    .^(* %gx /(scot %p our.b)/codex-inference/(scot %da now.b)/native-coding/selection/(scot %tas key)/noun)
  ?.(=(`expected actual) `%qpc-campaign-selection-changed ~)
++  read
  |=  [inner=agent:gall b=bowl:gall command=command:c unused=?]
  ^-  (each snapshot:c @tas)
  =/  raw  (raw:instrument inner b /x/qpc/instrument/state)
  ?~  raw  [%| %qpc-campaign-instrument-unavailable]
  =/  plans  ((soft state:instrument) u.raw)
  ?~  plans  [%| %qpc-campaign-instrument-invalid]
  =/  member  (~(get by plans.u.plans) member.command)
  ?~  member  [%| %qpc-campaign-member-missing]
  =/  p=plan:instrument  plan.u.member
  ?.  active.u.member  [%| %qpc-campaign-member-inactive]
  ?^  ticket.u.member  [%| %qpc-campaign-member-pending]
  ?^  awaiting.u.member  [%| %qpc-campaign-member-pending]
  =/  used  (raw:instrument inner b /x/native-coding/local-used-sessions)
  =/  required  (raw:instrument inner b /x/qpc/required-sessions)
  ?~  used  [%| %qpc-campaign-sessions-unavailable]
  ?~  required  [%| %qpc-campaign-gate-unavailable]
  =/  ids  ((soft (set @ux)) u.used)
  =/  gate  ((soft ,[%qpc-session-gate-v1 %viki ids=(set @ux)]) u.required)
  ?~  ids  [%| %qpc-campaign-sessions-invalid]
  ?~  gate  [%| %qpc-campaign-gate-invalid]
  ?:  (~(has in ids.u.gate) member.command)  [%| %qpc-campaign-member-managed]
  =/  config  (project-read:instrument inner b member.command project.manifest.p)
  ?:  ?=(%| -.config)  [%| p.config]
  =/  raw  (raw:instrument inner b /x/qpc/cases/(scot %ux cases.p))
  ?~  raw  [%| %qpc-campaign-cases-unavailable]
  =/  parsed  ((soft ,(unit cases:q)) u.raw)
  ?~  parsed  [%| %qpc-campaign-cases-invalid]
  ?~  u.parsed  [%| %qpc-campaign-cases-missing]
  =/  cases=cases:q  u.u.parsed
  =/  pinned  (read:source our.b now.b p.config expected.command artifact.p cases)
  ?:  ?=(%| -.pinned)  [%| p.pinned]
  =/  raw  (raw:instrument inner b /x/qpc/laws)
  ?~  raw  [%| %qpc-campaign-law-unavailable]
  =/  laws  ((soft state:law) u.raw)
  ?~  laws  [%| %qpc-campaign-law-invalid]
  =/  frozen  (freeze:law u.laws (binding-of:instrument p) our.b expected-law.command)
  ?:  ?=(%| -.frozen)  [%| p.frozen]
  ?.  (agent-live:guard our.b now.b %cantrip)  [%| %qpc-campaign-cantrip-unavailable]
  =/  raw=*
    .^(* %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/tool-state/noun)
  =/  ledger  ((soft organ:ct) raw)
  ?~  ledger  [%| %qpc-campaign-ledger-invalid]
  ::  The start grant's own reservation is expected; any other use is not.
  ?:  &(unused !=(``grant.command (spare:reservation u.ledger u.ids member.command)))
    [%| %qpc-campaign-member-used]
  =/  grant  (~(get by grants.u.ledger) grant.command)
  =/  baseline  (~(get by records.u.ledger) baseline.command)
  ?~  grant  [%| %qpc-campaign-grant-missing]
  ?~  baseline  [%| %qpc-campaign-baseline-missing]
  =/  raw  (raw:instrument inner b /x/native-coding/local-review/scopes)
  ?~  raw  [%| %qpc-campaign-reviewer-unavailable]
  =/  scopes  ((soft ,(map @t scope:local)) u.raw)
  ?~  scopes  [%| %qpc-campaign-reviewer-invalid]
  =/  reviewer  (~(get by u.scopes) id.spec.p.config)
  ?~  reviewer  [%| %qpc-campaign-reviewer-missing]
  =/  issue  (selection b key.command selection.manifest.p)
  ?^  issue  [%| u.issue]
  =/  issue  (selection b provider-key.u.reviewer selection.u.reviewer)
  ?^  issue  [%| u.issue]
  =/  value=snapshot:c  [p p.config cases p.pinned p.frozen u.grant u.reviewer u.baseline]
  ::  Name the failing clause (2026-11-01); the family tag was unactionable.
  =/  why  (incompatible:c our.b command value)
  ?^  why  [%| u.why]
  [%& value]
++  current
  |=  [inner=agent:gall b=bowl:gall r=record:c]
  ^-  (each (unit reading:successor) @tas)
  =/  stream=@ux  stream.plan.snapshot.task.r
  =/  raw  (raw:instrument inner b /x/qpc/instrument/successor/(scot %ux stream)/current)
  ?~  raw  [%| %qpc-campaign-reading-unavailable]
  =/  parsed  ((soft ,(each reading:successor @tas)) u.raw)
  ?~  parsed  [%| %qpc-campaign-reading-invalid]
  ?:  ?=(%& -.u.parsed)  [%& `p.u.parsed]
  ?:  ?=(?(%qpc-reference-unavailable %qpc-reading-unavailable) p.u.parsed)  [%& ~]
  [%| p.u.parsed]
++  registry
  |=  [inner=agent:gall b=bowl:gall id=@ux]
  ^-  (unit record:declarations)
  =/  raw  (raw:instrument inner b /x/qpc/profile-declarations)
  ?~  raw  ~
  =/  decoded  ((soft state:declarations) u.raw)
  ?~  decoded  ~
  (~(get by records.u.decoded) id)
++  gates
  |=  [inner=agent:gall b=bowl:gall child=child:c]
  ^-  (unit @tas)
  ?.  (agent-live:guard our.b now.b %cantrip)  `%qpc-campaign-cantrip-unavailable
  =/  required=[%qpc-session-gate-v1 %cantrip ids=(set @ux)]
    .^([%qpc-session-gate-v1 %cantrip ids=(set @ux)] %gx /(scot %p our.b)/cantrip/(scot %da now.b)/qpc/required-sessions/noun)
  ?.  (~(has in ids.required) session.child)  `%qpc-campaign-cantrip-gate-missing
  =/  ledger=organ:ct
    .^(organ:ct %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/tool-state/noun)
  ?.  =(`[grant.child ~] (~(get by grants.ledger) id.grant.child))
    `%qpc-campaign-child-grant-changed
  =/  raw  (raw:instrument inner b /x/qpc/required-sessions)
  ?~  raw  `%qpc-campaign-viki-gate-missing
  =/  parsed  ((soft ,[%qpc-session-gate-v1 %viki ids=(set @ux)]) u.raw)
  ?~  parsed  `%qpc-campaign-viki-gate-invalid
  ?.  (~(has in ids.u.parsed) session.child)  `%qpc-campaign-viki-gate-missing
  ~
++  settlement
  |=  [inner=agent:gall b=bowl:gall r=record:c]
  ^-  (each terminal @tas)
  ?~  child.r  [%| %qpc-campaign-collection-missing]
  =/  raw  (raw:instrument inner b /x/qpc/instrument/selected)
  ?~  raw  [%| %qpc-campaign-selected-unavailable]
  =/  decoded  ((soft ,[%qpc-instrument-selected-v1 value=state:selected]) u.raw)
  ?~  decoded  [%| %qpc-campaign-selected-invalid]
  =/  s=state:selected  value.u.decoded
  =/  matches=(list registration:selected)
    (skim ~(val by reservations.s) |=(v=registration:selected &(=(member.command.task.r member.v) =(session.u.child.r session.work.enrollment.reservation.v))))
  ?.  =(1 (lent matches))  [%| %qpc-campaign-reservation-unavailable]
  =/  id=@ux  id.enrollment.reservation:(snag 0 matches)
  =/  receipt  (~(get by receipts.s) id)
  ?~  receipt  [%| %qpc-campaign-settlement-pending]
  =/  reads=(list [@ux ticket:selected])
    (skim ~(tap by reads.s) |=([candidate=@ux t=ticket:selected] &(=(%settled phase.t) =(acceptance.u.receipt acceptance.t) =(decision.u.receipt decision.t))))
  ?.  =(1 (lent reads))  [%| %qpc-campaign-settlement-read-missing]
  =/  candidate=@ux  -:(snag 0 reads)
  ?.  (agent-live:guard our.b now.b %cantrip)  [%| %qpc-campaign-cantrip-unavailable]
  =/  actual=(unit record:accept)
    .^((unit record:accept) %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/candidate/(scot %ux candidate)/noun)
  ?~  actual  [%| %qpc-campaign-acceptance-missing]
  ?.  =(acceptance.u.receipt (digest:accept u.actual))  [%| %qpc-campaign-acceptance-changed]
  ?~  decision.u.actual  [%| %qpc-campaign-decision-missing]
  ?.  =(decision.u.receipt (digest:accept u.decision.u.actual))  [%| %qpc-campaign-decision-changed]
  [%& [id u.receipt u.actual]]
++  ready
  ::  Local returned-inner notification only. Native reads wait until Behn.
  |=  [inner=agent:gall b=bowl:gall r=record:c]
  ^-  ?
  ?~  child.r  %.n
  ?:  =(%profile phase.r)
    =/  d  (registry inner b session.u.child.r)
    ?~  d  %.n
    ?=(?(%verified %refused %unknown %cancelled) phase.u.d)
  ?.  =(%pool phase.r)  %.n
  =/  raw  (raw:instrument inner b /x/qpc/instrument/selected)
  ?~  raw  %.n
  =/  decoded  ((soft ,[%qpc-instrument-selected-v1 value=state:selected]) u.raw)
  ?~  decoded  %.n
  %+  lien  ~(tap by reservations.value.u.decoded)
  |=  [id=@ux v=registration:selected]
  &((~(has by receipts.value.u.decoded) id) =(member.command.task.r member.v) =(session.u.child.r session.work.enrollment.reservation.v))
--
