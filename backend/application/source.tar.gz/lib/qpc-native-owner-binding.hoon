::  Projection of an explicitly verified registry association. No sample,
::  assessment, grant or eligibility is created by preparing a collection.
/-  nc=native-coding, np=native-coding-provider
/+  d=qpc-native-declaration, owner=qpc-native-owner,
    decision=qpc-native-decision, obs=qpc-observation,
    sensing=qpc-task-sensing, sessions=native-coding-session,
    law=qpc-law-core, pool=qpc-native-pool,
    outcomes=qpc-native-outcome, provider=native-coding-provider,
    tools=cantrip-native-coding, project=native-coding-project
|%
+$  view  [registration=record:d snapshot=snapshot:owner observed=state:obs]
+$  ticket
  $:  registration=record:d  work=work:obs  before=@ux  due=@da
      phase=?(%scheduled %opened %sealed %unavailable %unknown)
      reason=(unit @tas)  seal=(unit [due=@da pending=?])
  ==
+$  state
  $:  %qpc-native-owner-agent-v1  journal=state:owner
      tickets=(map @ux ticket)  unavailable=(map @ux @tas)
  ==
++  empty  ^-(state [%qpc-native-owner-agent-v1 empty:owner ~ ~])
++  digest  |=(v=* ^-(@ux (shax (jam [%qpc-owner-prospective-v1 v]))))
++  declared
  |=  r=record:d
  ^-  declaration:owner
  =/  a=association:d  value.r
  =/  c=certificate:d  (need certificate.r)
  ::  New declarations freeze compilation, the registered propositions and
  ::  every project constraint before generation. Existing incompatible
  ::  openings cannot acquire this requirement after candidates were made.
  =/  names=(list @tas)
    [%compile (turn rows.cases.task.a |=(r=case:outcomes proposition.r))]
  =/  constraints=(list @tas)  ~[%project-constraints]
  :*  (digest:sensing task.a)  objective.task.a  %qpc-energy-v1
      source.c  pax.c  hash.c  parameters.law.a
      (weld names constraints)
  ==
++  contract
  |=  r=record:d
  ^-  contract:sensing
  =/  a=association:d  value.r
  [%qpc-task-sensing-v1 instrument.plan.a id.law.a (digest:obs manifest.plan.a) 16 (need (policy-of:sensing manifest.plan.a))]
++  work
  |=  [r=record:d input=input:pool]
  ^-  work:obs
  =/  a=association:d  value.r
  =/  t=task:sensing  task.a
  =/  id=@ux  id.session.entry.input
  =/  request=@ux  (request-id:sessions id turn.entry.input)
  :*  %qpc-observation-work-v1  (digest:obs manifest.plan.a)
      (digest [id.r id request])  id  request  configuration.t  source.t
      artifact.t  cases.plan.a  (substitutions:sensing (contract r) t)  evidence.t
  ==
++  compatible
  |=  [our=@p v=view]
  ^-  (unit @tas)
  =/  r=record:d  registration.v
  =/  a=association:d  value.r
  =/  input=input:pool  input.snapshot.v
  =/  e=entry:sessions  entry.input
  ?.  &((valid:d our [%qpc-native-declarations-v1 (malt ~[[session.command.a r]])]) (usable:d r))
    `%qpc-owner-profile-unavailable
  ?.  ?&  =(session.command.a id.session.e)  =(our owner.session.e)
          =(our worker.e)  =(objective.a objective.session.e)
          =(project.manifest.plan.a project.session.e)
          =(source.source.a working.session.e)
          =(configuration.task.a configuration.e)
          =(selection.manifest.plan.a selection.e)
          (~(has in managed.snapshot.v) id.session.e)
          =(binding.law.a binding.snapshot.v)
          =(id.law.a expected-law.snapshot.v)
      ==  `%qpc-owner-task-changed
  =/  frozen  (freeze:law laws.snapshot.v binding.law.a our id.law.a)
  ?:  ?=(%| -.frozen)  `p.frozen
  ?.  =(law.a p.frozen)  `%qpc-owner-law-changed
  =/  grant  (~(get by grants.ledger.snapshot.v) grant.input)
  ?~  grant  `%qpc-owner-grant-missing
  ?.  &((scope-valid:owner our input u.grant) =(project.a project.grant.u.grant))
    `%qpc-owner-grant-mismatch
  ~
++  ready
  |=  [our=@p v=view]
  ^-  (each work:obs @tas)
  =/  issue  (compatible our v)
  ?^  issue  [%| u.issue]
  =/  r=record:d  registration.v
  =/  a=association:d  value.r
  =/  input=input:pool  input.snapshot.v
  =/  w=work:obs  (work r input)
  ?.  (validate:sensing (contract r) task.a manifest.plan.a w project.a cases.task.a entry.input)
    [%| %qpc-owner-prospective-binding-invalid]
  =/  prefix  (~(get by windows.snapshot.v) session.binding.law.a)
  ?~  prefix  [%| %qpc-owner-window-missing]
  ?.  =(?=([%qpc-successor-window-v1 *] u.prefix) =(`%first-17-reference-successive-disjoint-17-live (policy-of:sensing manifest.plan.a)))
    [%| %qpc-owner-policy-mismatch]
  =/  reading  (read-prefix:decision u.prefix (source-digest:decision source.w))
  ?:  ?=(%| -.reading)  [%| p.reading]
  =/  armed  (enroll:obs our observed.v manifest.plan.a w entry.input)
  ?:  ?=(%| -.armed)  [%| p.armed]
  [%& w]
++  wire-for
  |=  [id=@ux t=ticket]
  ^-  wire
  /qpc-owner-wake/(scot %ux id)/(scot %ux (digest [id.registration.t work.t before.t due.t]))
++  unavailable
  |=  [s=state id=@ux reason=@tas]
  ^-  state
  ?.  |((~(has by unavailable.s) id) (lth ~(wyt by unavailable.s) 128))  s
  s(unavailable (~(put by unavailable.s) id reason))
++  seal-wire
  |=  [id=@ux t=ticket]
  ^-  wire
  =/  due=@da  due:(need seal.t)
  /qpc-owner-seal/(scot %ux id)/(scot %ux (digest [id.registration.t work.t due]))
++  expected-card
  |=  [our=@p r=record:owner]
  ^-  card:agent:gall
  ::  Match native-coding-loop++poke's noun-typed payload. Full card equality
  ::  still binds the exact owner, destination, wire, mark, key and request.
  =/  value=*  [%native-coding-infer key.r request.r]
  [%pass /native-coding/infer %agent [our (transport:provider selection.request.r)] %poke %noun !>(value)]
++  infer
  ::  Strip only the already-typed card envelope. Never mold-walk vase.type.
  |=  c=card:agent:gall
  ^-  (unit [key=@tas request=request:np])
  =/  p  ((soft ,[%pass wire=wire %agent target=[ship=@p app=@tas] %poke %noun payload=*]) c)
  ?~  p  ~
  ?.  ?=([* *] payload.u.p)  ~
  =/  q  ((soft ,[%native-coding-infer key=@tas request=request:np]) +.payload.u.p)
  ?~  q  ~
  `[key.u.q request.u.q]
++  seal-card
  |=  [our=@p c=card:agent:gall]
  ^-  (unit @ux)
  =/  p  ((soft ,[%pass wire=wire %agent target=[ship=@p app=@tas] %poke %noun payload=*]) c)
  ?~  p  ~
  ?.  &(=(our ship.target.u.p) =(%viki app.target.u.p) ?=([* *] payload.u.p))  ~
  =/  q  ((soft ,[%qpc-pool-seal-v1 id=@ux]) +.payload.u.p)
  ?~(q ~ `id.u.q)
++  journal-valid
  ::  This owner only opens and collects. Reload cannot smuggle a selected
  ::  or released decision through this presently non-executing wrapper.
  |=  [our=@p id=@ux r=record:owner t=ticket]
  ^-  ?
  =/  f=opening:decision  frozen.decision.r
  =/  replayed  (open:decision f)
  ?.  ?=(%& -.replayed)  %.n
  ?.  ?&  =(decision.r p.replayed)  ?=(~ closed.r)
          =(our owner.f)  =(id session.f)  =(request.f id.request.r)
          =(request-digest.f (shax (jam request.r)))
          =(authority.f (digest:owner scope.r))
          (grant-valid:tools our grant.scope.r)  ?=(~ revoked.scope.r)
          =(grant.f id.grant.scope.r)  =(id session.grant.scope.r)
          =(project.f id.spec.project.grant.scope.r)
          =(configuration.f (configuration:project project.grant.scope.r))
          =(declaration.r (declared registration.t))
          =(law.f law.value.registration.t)  =(scorer.declaration.r scorer.f)
          =(scorer-source.f (digest:owner [scorer.declaration.r source.declaration.r pax.declaration.r hash.declaration.r]))
          =(task.declaration.r task.f)  =(objective.declaration.r objective.f)
          =(required.declaration.r required.f)
          (request-valid:provider request.r)  (proposal-tools:pool tools.request.r)
          !=(%$ key.r)
          =(position.f sequence.context.r)  ?=(%context -.body.context.r)
          =(request.f request.value.body.context.r)
          =(source.f source.value.body.context.r)
          =(request-digest.f request-digest.value.body.context.r)
          =((shax (jam history.request.r)) history-digest.value.body.context.r)
          =((shax (jam tools.request.r)) tools-digest.value.body.context.r)
          =(source.f source.work.t)  =(request.f request.work.t)
      ==  %.n
  ?~  collection.r  =(%opened phase.t)
  =/  c=collection:owner  u.collection.r
  ?.  ?&  =(%sealed phase.t)  (valid:pool pool.c)
          =(id session.pool.c)  =(id.decision.r opening.generation.c)
          =(request.f request.generation.c)  =(request-digest.f request-digest.generation.c)
          =(provider.c receipt.generation.c)  =(request.f request.pool.c)
          =(source.f source.pool.c)  =(grant.f grant.pool.c)
          =(id.context.r context-record.pool.c)
          =(value.body.context.r context.pool.c)
          =(key.r provider-key.pool.c)
          (lth sequence.context.r position.generation.c)
          (lth position.generation.c position.c)
      ==  %.n
  =/  rows=(list record:sessions)  extension.c
  =/  previous=@ux  id.context.r
  =/  sequence=@ud  +(sequence.context.r)
  =/  model=?  %.n
  |-  ^-  ?
  ?~  rows  &(model =(previous through.pool.c) =(sequence +(position.c)))
  =/  v=record:sessions  i.rows
  ?.  ?&  =(sequence sequence.v)  =(`previous previous.v)
          =(id.v (event-id:sessions id sequence `previous at.v body.v))
      ==  %.n
  =.  model
    ?.  =(sequence position.generation.c)  model
    &(?=(%model -.body.v) =(id.v model-record.pool.c))
  ?~  t.rows
    ?.  =([%status %paused %qpc-pool-collected] body.v)  %.n
    $(rows t.rows, previous id.v, sequence +(sequence))
  $(rows t.rows, previous id.v, sequence +(sequence))
++  valid
  |=  [our=@p s=state]
  ^-  ?
  ?&  (lte ~(wyt by tickets.s) 64)  (lte ~(wyt by records.journal.s) 64)
      (lte ~(wyt by unavailable.s) 128)
      (levy ~(tap by unavailable.s) |=([id=@ux reason=@tas] &((identifier:sensing id) !=(%$ reason))))
      %+  levy  ~(tap by tickets.s)
      |=  [id=@ux t=ticket]
      =/  r=record:d  registration.t
      =/  a=association:d  value.r
      ?&  =(id session.command.a)  =(id session.work.t)
          (valid:d our [%qpc-native-declarations-v1 (malt ~[[id r]])])
          =(%verified phase.r)  (identifier:sensing before.t)
          (work-valid:obs manifest.plan.a work.t)
          =(artifact.task.a artifact.work.t)  =(source.task.a source.work.t)
          =(cases.plan.a case-set.work.t)
          =(configuration.task.a configuration.work.t)
          =(evidence.task.a available-evidence.work.t)
          =((substitutions:sensing (contract r) task.a) substitutions.work.t)
          =(nonce.work.t (digest [id.r id request.work.t]))
          (gth due.t at.a)
          ?:  ?=(?(%scheduled %opened %sealed) phase.t)  ?=(~ reason.t)
          ?~(reason.t %.n !=(%$ u.reason.t))
          =(?=(?(%opened %sealed) phase.t) (~(has by records.journal.s) id))
          ?~  seal.t  %.y
          &(?=(?(%opened %sealed) phase.t) (gth due.u.seal.t due.t) ?:(pending.u.seal.t =(%opened phase.t) %.y))
      ==
      %+  levy  ~(tap by records.journal.s)
      |=  [id=@ux r=record:owner]
      =/  t  (~(get by tickets.s) id)
      ?~(t %.n (journal-valid our id r u.t))
  ==
--
