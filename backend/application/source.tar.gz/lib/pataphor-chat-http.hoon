::  Bounded native form parsing; no browser runtime.
/-  pc=pataphor-chat
|%
+$  card  card:agent:gall
+$  fields  (map @t @t)
+$  location  [selected=(unit @ta) connecting=?]
+$  result-route
  $%  [%chat ~]  [%invalid ~]  [%index ~]  [%result key=@ux]  ==
++  parse-fields
  |=  body=@t
  ^-  (unit fields)
  ?:  (gth (met 3 body) 16.384)  ~
  =/  parsed=(unit (list [@t @t]))
    (rush (cat 3 '?' body) yque:de-purl:html)
  ?~  parsed  ~
  ?:  (gth (lent u.parsed) 8)  ~
  =/  result=fields  (~(gas by *fields) u.parsed)
  ?.  =((lent u.parsed) ~(wyt by result))  ~
  `result
++  decode
  |=  [nonce=@uv body=@t]
  ^-  (unit action:pc)
  =/  parsed=(unit fields)  (parse-fields body)
  ?~  parsed  ~
  ?.  &(!=(0 nonce) =(`(scot %uv nonce) (~(get by u.parsed) 'nonce')))  ~
  =/  op=(unit @t)  (~(get by u.parsed) 'op')
  ?~  op  ~
  =/  text=(unit @t)  (~(get by u.parsed) 'text')
  ?:  =('new' u.op)  `[%new ~]
  ?:  =('ask' u.op)  ?~(text ~ `[%ask u.text])
  ::  connect, disconnect, send and stop-tracking went with the Noltbook app
  ::  (removed 2026-09-23): an old form with those ops is expired, nothing more
  ~
++  result-location
  |=  url=@t
  ^-  result-route
  =/  prefix=@t  '/apps/pataphor-work?'
  =/  size=@ud  (met 3 prefix)
  ?.  &((gte (met 3 url) size) =(prefix (cut 3 [0 size] url)))
    [%chat ~]
  =/  parsed=(unit fields)
    (parse-fields (cut 3 [size (sub (met 3 url) size)] url))
  ?~  parsed  [%invalid ~]
  =/  key=(unit @t)  (~(get by u.parsed) 'result')
  =/  index=(unit @t)  (~(get by u.parsed) 'results')
  ?:  &(=(~ key) =(~ index))  [%chat ~]
  ?.  =(1 ~(wyt by u.parsed))  [%invalid ~]
  ?~  key
    ?:  =('/apps/pataphor-work?results=1' url)  [%index ~]
    [%invalid ~]
  =/  digest=(unit @ux)  (slaw %ux u.key)
  ?~  digest  [%invalid ~]
  ?.  &((gth u.digest 0) (lte (met 0 u.digest) 256))  [%invalid ~]
  ?.  =(url (cat 3 '/apps/pataphor-work?result=' (scot %ux u.digest)))
    [%invalid ~]
  [%result u.digest]
++  locate
  ::  the conversation has one page: the bare path. (?note= and ?connect= were
  ::  the connected chats; the page sends those old links back here.)
  |=  url=@t
  ^-  (unit location)
  ?:  |(=('/apps/pataphor' url) =('/apps/pataphor/' url))  `[~ %.n]
  ~
++  field
  |=  [jon=json key=@t]
  ^-  (unit json)
  ?.  ?=([%o *] jon)  ~
  (~(get by p.jon) key)
++  string
  |=  [jon=json key=@t]
  ^-  @t
  =/  value=(unit json)  (field jon key)
  ?~  value  ''
  ?.  ?=([%s *] u.value)  ''
  p.u.value
++  respond
  |=  [id=@ta code=@ud body=@t extra=header-list:http head=?]
  ^-  (list card)
  =/  headers=header-list:http
    :~  ['content-type' 'text/html; charset=utf-8']
        ['cache-control' 'no-store']
        ['referrer-policy' 'no-referrer']
        ['x-content-type-options' 'nosniff']
        ::  font-src data:: the delay's sigil typeface rides inside dialogue.js
        ::  as a data: url (2026-09-26); every other fetch class stays shut
        ['content-security-policy' (crip "default-src 'none'; connect-src 'self' http://localhost:*; frame-src 'self' http://localhost:*; script-src 'self'; style-src 'unsafe-inline'; font-src data:; form-action 'self'; base-uri 'none'; frame-ancestors 'self'")]
    ==
  =/  payload=simple-payload:http
    [[code (weld headers extra)] ?:(head ~ `(as-octs:mimes:html body))]
  =/  route=path  /http-response/[id]
  :~  [%give %fact ~[route] %http-response-header !>(response-header.payload)]
      [%give %fact ~[route] %http-response-data !>(data.payload)]
      [%give %kick ~[route] ~]
  ==
--
