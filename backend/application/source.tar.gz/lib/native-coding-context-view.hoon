::  Owner-only source preview and exact immutable Graf receipt readback.
/-  nc=native-coding, frozen=native-coding-context
/+  journal=native-coding-session, context=native-coding-context,
    projection=native-coding-context-json, scoped=native-coding-session-project,
    guard=viki-scry-guard, window=graf-evidence-window
|%
+$  stored
  [family=@tas digest=@ux payload=receipt:frozen]
++  unavailable
  |=  reason=@tas
  ^-  json
  (pairs:enjs:format ~[['schema' s+'native-coding-context-view-v1'] ['available' b+%.n] ['reason' s+reason] ['context' ~]])
++  verified
  |=  [lim=limits:context binding=binding:frozen page=kind-page:window]
  ^-  (unit receipt:frozen)
  ?.  ?&  =(kind.page (receipt-kind:frozen receipt-digest.binding))
          =(0 offset.page)  =(1 limit.page)  =(1 returned.page)
          !more.page  =(1 next-offset.page)  =(1 (lent items.page))
      ==  ~
  ?>  ?=(^ items.page)
  =/  found  ((soft stored) i.items.page)
  ?~  found  ~
  =/  value=receipt:frozen  payload.u.found
  ?.  &((frozen-valid:context lim prepared.value) =(binding (bind-receipt:frozen value)))  ~
  ?.  =(u.found (receipt-fact:frozen value))  ~
  `value
++  read
  |=  [b=bowl:gall projects=(map @t project:nc) sessions=organ:journal id=@ux request=(unit @ux)]
  ^-  json
  ?.  =(our.b src.b)  (unavailable %owner-required)
  =/  found  (~(get by sessions) id)
  ?~  found  (unavailable %session-unavailable)
  =/  e=entry:journal  u.found
  ?.  =(our.b owner.session.e)  (unavailable %owner-required)
  ?~  request
    =/  project  (resolve:scoped our.b now.b projects id project.session.e)
    ?:  ?=(%| -.project)  (unavailable p.project)
    =/  prepared  (prepare:context (law:context our.b now.b %host-law) our.b now.b p.project session.e ~ project.session.e)
    ?:  ?=(%| -.prepared)  (unavailable p.prepared)
    (pairs:enjs:format ~[['schema' s+'native-coding-context-view-v1'] ['available' b+%.y] ['mode' s+'preview'] ['owner' s+(scot %p our.b)] ['session' s+(scot %ux id)] ['worker' s+(scot %p worker.e)] ['model' s+model.selection.e] ['provider' s+provider.selection.e] ['sourceDigest' s+(scot %ux (shax (jam working.session.e)))] ['at' s+(scot %da now.b)] ['context' (prepared:projection p.prepared)]])
  =/  records
    (skim records.e |=(r=record:journal &(?=(%context -.body.r) =(u.request request.value.body.r))))
  ?~  records  (unavailable %context-not-retained)
  ?^  t.records  (unavailable %context-binding-ambiguous)
  ?>  ?=(%context -.body.i.records)
  =/  binding=binding:frozen  value.body.i.records
  ?.  &(=(our.b owner.binding) =(id session.binding) =(u.request request.binding) =(our.b owner.source.binding))
    (unavailable %context-binding-mismatch)
  ?.  (agent-live:guard our.b now.b %graf)  (unavailable %graf-unavailable)
  =/  kind=@tas  (receipt-kind:frozen receipt-digest.binding)
  =/  page=kind-page:window
    .^(kind-page:window %gx /(scot %p our.b)/graf/(scot %da now.b)/by-kind-page/[kind]/0/1/noun)
  =/  receipt  (verified lim:(law:context our.b now.b %host-law) binding page)
  ?~  receipt  (unavailable %exact-graf-receipt-unavailable)
  (pairs:enjs:format ~[['schema' s+'native-coding-context-view-v1'] ['available' b+%.y] ['mode' s+'retained'] ['receiptDigest' s+(scot %ux receipt-digest.binding)] ['context' (full-receipt:projection u.receipt)]])
++  key
  |=  text=@t
  ^-  (unit @ux)
  ?.  (lte (met 3 text) 96)  ~
  =/  parsed  (slaw %ux text)
  ?~  parsed  ~
  ?:(&((lte (met 0 u.parsed) 256) =(text (scot %ux u.parsed))) parsed ~)
++  peek
  |=  [b=bowl:gall projects=(map @t project:nc) sessions=organ:journal path=path]
  ^-  (unit (unit cage))
  ?.  |(?=([%x %native-coding %context-preview @ ~] path) ?=([%x %native-coding %request-context @ @ ~] path))  ~
  ?.  =(our.b src.b)  ~
  ?:  ?=([%x %native-coding %context-preview @ ~] path)
    =/  id  (key i.t.t.t.path)
    ?~  id  [~ ~]
    ``json+!>((read b projects sessions u.id ~))
  ?>  ?=([%x %native-coding %request-context @ @ ~] path)
  =/  id  (key i.t.t.t.path)
  ?~  id  [~ ~]
  =/  request  (key i.t.t.t.t.path)
  ?~  request  [~ ~]
  ``json+!>((read b projects sessions u.id `u.request))
--
