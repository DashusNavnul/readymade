::  Isolated selected-provider imports; protocol nouns and agent names stay unchanged.
::  /lib/glass-moon-command
::
::  Pure deadline composition and exact response correlation for the
::  Dashus/Baldur command lane.
::
/-  ms=multiplayer-session, mse=glass-moon-executor
|%
++  delivery-margin  `@dr`~m2
++  max-command-wait  `@dr`~m8
++  effective-limit
  |=  [requested=@dr task=task-request:mse]
  ^-  (unit @dr)
  =/  required=@dr  (add max-runtime.authority.task delivery-margin)
  =/  chosen=@dr  ?:((gte requested required) requested required)
  ?:((lte chosen max-command-wait) `chosen ~)
++  response-matches
  |=  $:  our=@p
          peer=@p
          local-session=@t
          peer-session=@t
          request=message:ms
          candidate=message:ms
      ==
  ^-  ?
  ?&  =(%response kind.body.candidate)
      =(`digest.request reply-to.body.candidate)
      =(peer sender.body.candidate)
      =(our recipient.body.candidate)
      =(peer-session sender-session.body.candidate)
      =(local-session recipient-session.body.candidate)
  ==
--
