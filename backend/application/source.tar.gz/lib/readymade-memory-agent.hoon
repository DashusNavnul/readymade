::  Owner-only metadata publisher. Native inner saves and effects stay intact.
/+  m=readymade-memory, gew=graf-evidence-window
|%
+$  pages  (map path observation:m)
++  watch-count
  |=  [view=mode:m b=bowl:gall]
  ^-  @ud
  %-  lent
  %+  skim  ~(val by sup.b)
  |=  [who=@p pax=path]
  ?.  =(who our.b)  %.n
  =/  r=(unit request:m)  (route:m pax)
  ?~(r %.n =(view view.u.r))
++  paths
  |=  [view=mode:m b=bowl:gall]
  ^-  (list path)
  =/  found=(list path)
    %+  murn  ~(val by sup.b)
    |=  [who=@p pax=path]
    ^-  (unit path)
    ?.  =(who our.b)  ~
    =/  r=(unit request:m)  (route:m pax)
    ?~  r  ~
    ?.(=(view view.u.r) ~ `pax)
  ~(tap in (silt found))
++  page
  |=  [inner=agent:gall b=bowl:gall r=request:m]
  ^-  observation:m
  =/  result=(each observation:m tang)
    %-  mule
    |.
    =/  ag  ~(. inner b(src our.b))
    =/  pax=path
      ?:(=(%catalog view.r) /x/memory /x/by-kind-page/[(scot %tas family.r)]/[(scot %ud offset.r)]/64)
    =/  got=(unit (unit cage))  (on-peek:ag pax)
    ?~  got  [%readymade-memory-unavailable-v1 %native-unavailable]
    ?~  u.got  [%readymade-memory-unavailable-v1 %native-unavailable]
    ?.  =(%noun p.u.u.got)  [%readymade-memory-unavailable-v1 %incoherent]
    ?:  =(%catalog view.r)
      =/  values=(unit (list catalog-row:m))
        ((soft ,(list catalog-row:m)) q.q.u.u.got)
      ?~  values  [%readymade-memory-unavailable-v1 %incoherent]
      (catalog:m r u.values)
    =/  values=(unit kind-page:gew)  ((soft kind-page:gew) q.q.u.u.got)
    ?~  values  [%readymade-memory-unavailable-v1 %incoherent]
    (facts:m r u.values)
  ?:(?=(%& -.result) p.result [%readymade-memory-unavailable-v1 %incoherent])
++  capture
  |=  [view=mode:m inner=agent:gall b=bowl:gall]
  ^-  pages
  %-  malt
  (turn (paths view b) |=(pax=path [pax (page inner b (need (route:m pax)))]))
++  updates
  |=  [before=pages after=pages reseed=?]
  ^-  (list card:agent:gall)
  %+  murn  ~(tap by after)
  |=  [pax=path value=observation:m]
  ^-  (unit card:agent:gall)
  ?:  &(!reseed =(`value (~(get by before) pax)))  ~
  `[%give %fact ~[pax] %noun !>(value)]
++  follow
  |=  [view=mode:m b=bowl:gall]
  ^-  (list card:agent:gall)
  ?.  &(=(%catalog view) !=(~ (paths view b)))  ~
  ~[[%pass /readymade-memory-updates %agent [our.b %graf] %watch /updates]]
++  unavailable
  |=  [view=mode:m b=bowl:gall]
  ^-  (list card:agent:gall)
  =/  value=observation:m  [%readymade-memory-unavailable-v1 %native-unavailable]
  (turn (paths view b) |=(pax=path [%give %fact ~[pax] %noun !>(value)]))
++  relevant
  |=  =vase
  ^-  ?
  =/  fact=*  q.vase
  ?@  fact  %.n
  ?^  -.fact  %.n
  ?=(kind:m -.fact)
++  agent
  |=  [view=mode:m inner=agent:gall]
  ^-  agent:gall
  |_  =bowl:gall
  +*  this  .
      ag  ~(. inner bowl)
  ++  on-init
    =^  cards  inner  on-init:ag
    [(weld cards (weld (follow view bowl) (updates ~ (capture view inner bowl) %.y))) this]
  ++  on-save  on-save:ag
  ++  on-load
    |=  old=vase
    =^  cards  inner  (on-load:ag old)
    [(weld cards (weld (follow view bowl) (updates ~ (capture view inner bowl) %.y))) this]
  ++  on-poke
    |=  [=mark =vase]
    =/  before=pages  (capture view inner bowl)
    =^  cards  inner  (on-poke:ag mark vase)
    [(weld cards (updates before (capture view inner bowl) %.n)) this]
  ++  on-watch
    |=  =path
    ?:  (memory-path:m path)
      ?>  =(src.bowl our.bowl)
      =/  r=(unit request:m)  (route:m path)
      ?>  ?=(^ r)
      ?>  =(view view.u.r)
      ?>  (lte (lent ~(tap in (silt [path (paths view bowl)]))) 16)
      =/  value=observation:m  (page inner bowl u.r)
      =/  watch=(list card:agent:gall)
        ::  Gall installs the joining duct before calling on-watch.
        ?.  &(=(%catalog view) =(1 (watch-count view bowl)))  ~
        ~[[%pass /readymade-memory-updates %agent [our.bowl %graf] %watch /updates]]
      [(weld watch ^-((list card:agent:gall) ~[[%give %fact ~[path] %noun !>(value)]])) this]
    =/  before=pages  (capture view inner bowl)
    =^  cards  inner  (on-watch:ag path)
    [(weld cards (updates before (capture view inner bowl) %.n)) this]
  ++  on-leave
    |=  =path
    ?:  (memory-path:m path)
      ::  Gall removes this duct first. Same-page sibling viewers still count.
      ?.  &(=(%catalog view) =(0 (watch-count view bowl)))  [~ this]
      [~[[%pass /readymade-memory-updates %agent [our.bowl %graf] %leave ~]] this]
    =^  cards  inner  (on-leave:ag path)
    [cards this]
  ++  on-peek
    |=  =path
    ?:  ?=([%x %readymade %memory *] path)
      ?.  =(src.bowl our.bowl)  ~
      =/  r=(unit request:m)  (route:m t.path)
      ?~  r  ~
      ?.  =(view view.u.r)  ~
      ``noun+!>((page inner bowl u.r))
    (on-peek:ag path)
  ++  on-agent
    |=  [=wire =sign:agent:gall]
    ?:  =(/readymade-memory-updates wire)
      ?>  &(=(%catalog view) =(src.bowl our.bowl))
      ?:  ?=(%kick -.sign)  [(unavailable view bowl) this]
      ?:  ?=(%watch-ack -.sign)
        ?~(p.sign [~ this] [(unavailable view bowl) this])
      ?.  &(?=(%fact -.sign) =(%noun p.cage.sign))  [~ this]
      ?.  (relevant q.cage.sign)  [~ this]
      ::  Graf has committed before this native notification. Re-read Bench's
      ::  live-version/tier projection; never derive authority from the event.
      [(updates ~ (capture view inner bowl) %.y) this]
    =/  before=pages  (capture view inner bowl)
    =^  cards  inner  (on-agent:ag wire sign)
    [(weld cards (updates before (capture view inner bowl) %.n)) this]
  ++  on-arvo
    |=  [=wire sign=sign-arvo]
    =/  before=pages  (capture view inner bowl)
    =^  cards  inner  (on-arvo:ag wire sign)
    [(weld cards (updates before (capture view inner bowl) %.n)) this]
  ++  on-fail
    |=  [=term =tang]
    =/  before=pages  (capture view inner bowl)
    =^  cards  inner  (on-fail:ag term tang)
    [(weld cards (updates before (capture view inner bowl) %.n)) this]
  --
--
