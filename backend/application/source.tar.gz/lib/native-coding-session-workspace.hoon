::  Owner-prepared session forks under one canonical project identity.
::  Viki must persist this state before cards, and select the scoped config
::  for opening/tools/context/fleet. This helper never registers another project.
/-  nc=native-coding, ws=workspace
/+  bootstrap=native-coding-bootstrap, project=native-coding-project,
    workspace=workspace, guard=viki-scry-guard
|%
+$  request
  [%native-coding-session-workspace-v1 session=@ux project=@t accepted=revision:nc working=@tas holder=@p mode=?(%clone %adopt) existing=(unit existing:bootstrap)]
+$  entry
  [request=request base=project:nc configuration=@ux bootstrap=@ux phase=?(%preparing %ready %unknown) reason=@tas]
+$  state  [bootstraps=ledger:bootstrap sessions=(map @ux entry)]
+$  command  $%([%prepare request=request] [%observe session=@ux])
+$  change  [state=state cards=(list card:agent:gall)]
++  scoped
  |=  e=entry
  ^-  project:nc
  base.e(working working.request.e)
++  nonce
  |=  [r=request base=project:nc]
  ^-  @ux
  (shax (jam [%native-coding-session-workspace-bootstrap-v1 r (configuration:project base)]))
++  purpose
  |=  r=request
  ^-  @t
  (rap 3 ~['Native coding session ' (scot %ux session.r) ' / ' project.r])
++  request-for
  |=  e=entry
  ^-  request:bootstrap
  [%native-coding-bootstrap-request-v1 bootstrap.e (scoped e) accepted.request.e holder.request.e ?~(existing.request.e (purpose request.e) purpose.claim.u.existing.request.e) `session.request.e mode.request.e existing.request.e]
++  owns
  |=  [s=state w=wire]
  ^-  ?
  =/  id  (key-for:bootstrap w)
  ?~  id  %.n
  (~(has by bootstraps.s) u.id)
++  claim-known
  ::  Adoption preserves a real owner-attested claim. A same-ship supplied
  ::  claim noun is not enough; conflicting claims for the fork fail closed.
  |=  [our=@p now=@da expected=claim:ws]
  ^-  ?
  ?.  (agent-live:guard our now %graf)  %.n
  =/  facts=(list [fact=* ships=(set @p)])
    .^((list [fact=* ships=(set @p)]) %gx /(scot %p our)/graf/(scot %da now)/attested/noun)
  =/  claims=(list claim:ws)
    %+  murn  facts
    |=  [fact=* ships=(set @p)]
    ?.  (~(has in ships) our)  ~
    =/  c  (claim-of:workspace fact)
    ?~  c  ~
    ?:(=(fork.u.c fork.expected) c ~)
  =(~[expected] claims)
++  notice
  |=  e=entry
  ^-  card:agent:gall
  [%give %fact ~[/native-coding] %noun !>([%native-coding-session-workspace-status-v1 session.request.e project.request.e working.request.e phase.e reason.e configuration.e])]
++  put
  |=  [our=@p s=state e=entry cards=(list card:agent:gall)]
  ^-  change
  [s(sessions (~(put by sessions.s) session.request.e e)) [(notice e) [%pass /native-session-workspace-evidence %agent [our %graf] %poke %graf-action !>([%attest [%native-coding-session-workspace-v1 (shax (jam e)) e]])] cards]]
++  retain
  |=  [b=bowl:gall s=state e=entry moved=transition:bootstrap]
  ^-  change
  =/  previous  (~(get by bootstraps.s) bootstrap.e)
  =/  changed=?  !=(previous `record.moved)
  =.  s  s(bootstraps held.moved)
  =/  r=record:bootstrap  record.moved
  =/  cards=(list card:agent:gall)
    (weld cards.moved ?:(changed (completion:bootstrap our.b r) ~))
  ?.  =(%ready status.r)
    (put our.b s e(phase %preparing, reason %session-workspace-preparing) cards)
  ?>  ?=(^ observed.r)
  ?.  =(accepted.request.e revision.accepted.u.observed.r)
    (put our.b s e(phase %unknown, reason %session-accepted-source-changed) cards)
  ?:  &(!=(%ready phase.e) =(~ previous))
    ::  Adopt is already backed by Graf, so no replacement claim is needed.
    (put our.b s e(phase %ready, reason %session-workspace-ready) cards)
  ?:  &(changed =(%clone mode.request.e))
    =.  cards
      [[%pass /native-session-workspace-claim/(scot %ux session.request.e) %agent [our.b %graf] %poke %graf-action !>([%attest (claim-fact:workspace claim.u.observed.r)])] cards]
    ::  Retain pending before dispatch. A Graf ACK only invites a canonical
    ::  reread; missing/unknown claims never cause this poke to be repeated.
    (put our.b s e(phase %preparing, reason %claimpending) cards)
  ?.  (claim-known our.b now.b claim.u.observed.r)
    (put our.b s e(phase %preparing, reason %claimpending) cards)
  (put our.b s e(phase %ready, reason %session-workspace-ready) cards)
++  act
  ::  projects/used/reserved are the owner's canonical ledgers, never fields
  ::  supplied by the model. Reserved includes other bootstrap/cache/fleet desks.
  |=  [b=bowl:gall s=state projects=(map @t project:nc) used=(set @ux) reserved=(set @tas) c=command]
  ^-  change
  ?>  =(our.b src.b)
  ?:  ?=(%observe -.c)  (observe b s projects session.c)
  =/  q=request  request.c
  =/  old  (~(get by sessions.s) session.q)
  ?^  old
    ?>  =(q request.u.old)
    [s ~[(notice u.old)]]
  ?>  &(!=(0 session.q) (lte (met 0 session.q) 256) (lth ~(wyt by sessions.s) 64) !(~(has in used) session.q) !(~(has in reserved) working.q))
  ?>  !(lien ~(val by sessions.s) |=(e=entry =(working.q working.request.e)))
  ?>  !(lien ~(val by projects) |=(p=project:nc |(=(working.q working.p) =(working.q base-desk.spec.p))))
  =/  base  (~(get by projects) project.q)
  ?>  ?=(^ base)
  ?>  &(=(our.b authority.spec.u.base) =(project.q id.spec.u.base) (valid:project u.base))
  =/  e=entry
    [q u.base (configuration:project u.base) (nonce q u.base) %preparing %session-workspace-requested]
  =/  r=request:bootstrap  (request-for e)
  ?>  (request-valid:bootstrap our.b r)
  =/  source  (current:project our.b now.b u.base)
  ?>  ?=(%& -.source)
  ?>  =(accepted.q revision.accepted.p.source)
  ?:  =(%adopt mode.q)
    ?>  ?=(^ existing.q)
    ?>  (claim-known our.b now.b claim.u.existing.q)
    (submit b s e r)
  (submit b s e r)
++  submit
  |=  [b=bowl:gall s=state e=entry r=request:bootstrap]
  ^-  change
  =/  moved  (submit:bootstrap our.b now.b src.b bootstraps.s r)
  ?>  ?=(%& -.moved)
  (retain b s e p.moved)
++  observe
  |=  [b=bowl:gall s=state projects=(map @t project:nc) session=@ux]
  ^-  change
  ?>  =(our.b src.b)
  =/  old  (~(get by sessions.s) session)
  ?~  old  [s ~]
  =/  e=entry  u.old
  =/  base  (~(get by projects) project.request.e)
  ?.  =(`base.e base)
    (put our.b s e(phase %unknown, reason %session-project-policy-changed) ~)
  =/  origin  (~(get by bootstraps.s) bootstrap.e)
  ?:  ?~(origin %.n =(%ready status.u.origin))
    ::  Recheck current authority against the retained origin. An approved
    ::  working-head advance never restarts the bootstrap or replaces its proof.
    =/  ready=entry  e(phase %ready, reason %session-workspace-ready)
    =/  checked
      (ready-project b s(sessions (~(put by sessions.s) session ready)) projects session)
    ?:  ?=(%| -.checked)
      ?:  =(%session-workspace-claim-unconfirmed p.checked)
        (put our.b s e(phase %preparing, reason %claimpending) ~)
      (put our.b s e(phase %unknown, reason p.checked) ~)
    ?:  =(e ready)  [s ~[(notice e)]]
    (put our.b s ready ~)
  =/  moved  (advance:bootstrap our.b now.b bootstraps.s bootstrap.e)
  ?:  ?=(%| -.moved)
    (put our.b s e(phase %unknown, reason p.moved) ~)
  (retain b s e p.moved)
++  arvo
  |=  [b=bowl:gall s=state projects=(map @t project:nc) w=wire sign=sign-arvo]
  ^-  change
  ?.  &(=(our.b src.b) (owns s w) ?=([%clay *] sign))  [s ~]
  =/  id=@ux  (need (key-for:bootstrap w))
  =/  matches=(list entry)  (skim ~(val by sessions.s) |=(e=entry =(id bootstrap.e)))
  ?.  =(1 (lent matches))  [s ~]
  =/  e=entry  (snag 0 matches)
  (observe b s projects session.request.e)
++  claim-event
  ::  This exact wire is emitted only to [our %graf]. Gall binds its reply
  ::  to that target; neither an ACK nor its success bit certifies the claim.
  |=  [b=bowl:gall s=state projects=(map @t project:nc) w=wire sign=sign:agent:gall]
  ^-  change
  ?.  &(=(our.b src.b) ?=(%poke-ack -.sign))  [s ~]
  ?.  ?=([%native-session-workspace-claim @ ~] w)  [s ~]
  =/  id  (slaw %ux i.t.w)
  ?~  id  [s ~]
  ?.  =((scot %ux u.id) i.t.w)  [s ~]
  =/  found  (~(get by sessions.s) u.id)
  ?~  found  [s ~]
  ?.  =(%clone mode.request.u.found)  [s ~]
  =/  origin  (~(get by bootstraps.s) bootstrap.u.found)
  ?~  origin  [s ~]
  ?.  =(%ready status.u.origin)  [s ~]
  (observe b s projects u.id)
++  ready-project
  ::  Some entry, even unknown, forbids falling back to the global work desk.
  ::  This returns only a freshly checked configuration, never opens a session.
  |=  [b=bowl:gall s=state projects=(map @t project:nc) session=@ux]
  ^-  (each project:nc @tas)
  =/  old  (~(get by sessions.s) session)
  ?~  old  [%| %session-workspace-missing]
  =/  e=entry  u.old
  ?.  &(=(our.b src.b) =(%ready phase.e))  [%| %session-workspace-not-ready]
  =/  current  (~(get by projects) project.request.e)
  ?.  =(current `base.e)  [%| %session-project-policy-changed]
  =/  p=project:nc  (scoped e)
  =/  source  (current:project our.b now.b p)
  ?:  ?=(%| -.source)  [%| p.source]
  ?.  =(accepted.request.e revision.accepted.p.source)  [%| %session-accepted-source-changed]
  =/  r=record:bootstrap  (~(got by bootstraps.s) bootstrap.e)
  ?~  observed.r  [%| %session-workspace-unconfirmed]
  ::  Approved edits may advance this desk. Preserve the initial clone/adopt
  ::  proof and accepted reference, rather than pinning every session to rev1.
  ?.  (claim-known our.b now.b claim.u.observed.r)  [%| %session-workspace-claim-unconfirmed]
  [%& p]
++  valid
  |=  [our=@p s=state]
  ^-  ?
  ?&  (lte ~(wyt by sessions.s) 64)  (valid:bootstrap our bootstraps.s)
      =(~(wyt by sessions.s) ~(wyt by bootstraps.s))
      =((lent ~(val by sessions.s)) ~(wyt in (silt (turn ~(val by sessions.s) |=(e=entry working.request.e)))))
      %+  levy  ~(tap by sessions.s)
      |=  [id=@ux e=entry]
      =/  r  (~(get by bootstraps.s) bootstrap.e)
      ?~  r  %.n
      ?&  =(id session.request.e)  !=(0 id)  (lte (met 0 id) 256)
          =(our authority.spec.base.e)  =(project.request.e id.spec.base.e)
          =(configuration.e (configuration:project base.e))
          =(bootstrap.e (nonce request.e base.e))  =(request.u.r (request-for e))
          (valid:project base.e)  (valid:project (scoped e))
          !=(working.request.e working.base.e)
          ?:  =(%ready phase.e)
            ?~  observed.u.r  %.n
            &(=(%ready status.u.r) =(accepted.request.e revision.accepted.u.observed.u.r))
          %.y
      ==
  ==
++  peek
  |=  [s=state path=path]
  ^-  (unit (unit cage))
  ?:  =(/x/native-coding/session-workspaces path)
    =/  rows
      (turn ~(val by sessions.s) |=(e=entry [session.request.e project.request.e working.request.e phase.e reason.e configuration.e]))
    ``noun+!>([%native-coding-session-workspaces-v1 rows])
  ?.  ?=([%x %native-coding %session-workspace @ ~] path)  ~
  =/  id  (slaw %ux i.t.t.t.path)
  ?~  id  [~ ~]
  ``noun+!>((~(get by sessions.s) u.id))
--
