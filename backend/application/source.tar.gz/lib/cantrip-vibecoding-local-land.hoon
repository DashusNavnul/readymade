::  Exact sovereign-local acceptance. A saved submission is NOT an applied
::  change. Cantrip must save the reservation and emit its card in one event.
::  Reload and reconciliation never return another write card.
/-  itn=intent
/+  clw=cantrip-law-window, demo=vibecoding-demo,
    image=vibecoding-local-image, lr=vibecoding-local-result,
    preview=vibecoding-local-preview, vcl=vibecoding-candidate,
    vcr=vibecoding-candidate-review, vlj=viki-vibecoding-local-judgment
|%
+$  refusal
  $?  %foreign-actor  %agent-unavailable  %judgment-missing
      %judgment-conflict  %judgment-superseded  %not-approved  %time-invalid
      %result-unavailable  %image-missing  %run-missing  %binding-invalid
      %stale-source  %intent-changed  %law-changed  %checks-failed
      %landing-not-admitted  %already-submitted  %landing-unresolved
      %capacity  %expired-admission
  ==
+$  admission
  $:  %vibecoding-local-land-admission-v1
      actor=@p  at=@da  judgment=judgment:vlj  source=@t  parent=@uv
  ==
+$  decision  (each admission refusal)
+$  commit  [id=@uv parents=(list @uv) at=@da]
+$  observation
  [at=@da current=observation:lr commit=(unit commit)]
+$  record
  $:  %vibecoding-local-land-record-v1
      admission=admission  status=?(%submitted %unknown %applied)
      observation=(unit observation)
  ==
+$  ledger  (map @ux record)
+$  transition  [next=ledger record=record card=card:agent:gall]
+$  action
  $%  [%vibecoding-local-land judgment=@ux]
      [%vibecoding-local-land-observe judgment=@ux]
  ==
++  select
  |=  [our=@p at=@da rows=(list *) key=@ux]
  ^-  (each judgment:vlj refusal)
  =/  chosen  (find:vlj rows key)
  ?~  chosen  [%| %judgment-missing]
  =/  j=judgment:vlj  u.chosen
  ?.  =(our operator.body.j)  [%| %foreign-actor]
  ?.  (lte judged-at.j at)  [%| %time-invalid]
  =|  nonces=@ud
  |-  ^-  (each judgment:vlj refusal)
  ?~  rows
    ?.  =(1 nonces)  [%| %judgment-conflict]
    ?.  =(%approve-landing decision.body.j)  [%| %not-approved]
    [%& j]
  =/  tagged=(unit [kind=@tas rest=*])  ((soft ,[@tas *]) i.rows)
  ?~  tagged  $(rows t.rows)
  ?.  =(%vibecoding-local-judgment kind.u.tagged)  $(rows t.rows)
  =/  parsed=(unit [kind=@tas key=@t item=judgment:vlj])
    ((soft ,[@tas @t judgment:vlj]) i.rows)
  ?~  parsed  [%| %judgment-conflict]
  =/  other=judgment:vlj  item.u.parsed
  ?.  &((valid:vlj other) =(i.rows (fact:vlj other)))
    [%| %judgment-conflict]
  =.  nonces
    ?:  &(=(our operator.body.other) =(nonce.body.j nonce.body.other))
      +(nonces)
    nonces
  ?:  &(=(write.subject.body.j write.subject.body.other) !=(j other))
    ?.  =(our operator.body.other)  [%| %judgment-conflict]
    ?:  (gth judged-at.other judged-at.j)  [%| %judgment-superseded]
    ?:  =(judged-at.other judged-at.j)  [%| %judgment-conflict]
    $(rows t.rows)
  $(rows t.rows)
++  judge
  |=  $:  our=@p  actor=@p  at=@da  rows=(list *)  key=@ux
          view=view:lr  img=image:image  run=record:preview
          intent=(unit record:itn)  window=window:clw  parent=@uv
      ==
  ^-  decision
  ?.  =(our actor)  [%| %foreign-actor]
  =/  picked  (select our at rows key)
  ?:  ?=(%| -.picked)  picked
  =/  j=judgment:vlj  p.picked
  ?.  &(=(key digest.j) (gte judged-at.j at.run) !=(0 parent))
    [%| %binding-invalid]
  ::  Recompute Viki's exact approval body from current canonical evidence.
  ::  Retention is selected above; this does not issue a new judgment.
  =/  item=action:vlj
    [%viki-vibecoding-local-judge nonce.body.j write.subject.body.j run.subject.body.j decision.body.j note.body.j]
  =/  checked  (judge:vlj our actor at item view img run intent `window)
  ?:  ?=(%| -.checked)
    :-  %|
    ?+  p.checked  %binding-invalid
      %foreign-actor  %foreign-actor
      %stale-source  %stale-source
      %intent-changed  %intent-changed
      %law-changed  %law-changed
      %checks-failed  %checks-failed
    ==
  ?.  =(body.j body.p.checked)  [%| %binding-invalid]
  ::  Explicit approval satisfies never-auto; it cannot override a block or
  ::  make implementation admissible in a non-ratification regime.
  ?.  &((~(has in admissible.window) %implement) !(~(has in blocked.window) %implement))
    [%| %landing-not-admitted]
  =/  a=admission
    [%vibecoding-local-land-admission-v1 our at j source.candidate.view parent]
  ?.  (admission-valid a)  [%| %binding-invalid]
  [%& a]
++  admission-valid
  |=  a=admission
  ^-  ?
  =/  j=judgment:vlj  judgment.a
  ?&  (valid:vlj j)  =(actor.a operator.body.j)
      =(%approve-landing decision.body.j)
      (gte at.a judged-at.j)  !=(0 parent.a)
      (source-valid:image source.a)
      =((file-hash:vcr source.a) after.subject.body.j)
  ==
++  reserve
  |=  [held=ledger a=admission our=@p now=@da]
  ^-  (each transition refusal)
  ?.  &(=(our actor.a) =(now at.a))  [%| %expired-admission]
  ?.  &((ledger-valid held) (admission-valid a))  [%| %binding-invalid]
  =/  key=@ux  digest.judgment.a
  ?:  (~(has by held) key)  [%| %already-submitted]
  ?:  (lien ~(val by held) |=(r=record !=(%applied status.r)))
    [%| %landing-unresolved]
  ?:  (gte ~(wyt by held) 128)  [%| %capacity]
  =/  r=record  [%vibecoding-local-land-record-v1 a %submitted ~]
  =/  c=card:agent:gall
    [%pass /vibecoding-local-land/(scot %ux key) %arvo %c [%info base:demo %.y ~[[target:demo %mut %hoon !>(source.a)]]]]
  [%& [(~(put by held) key r) r c]]
++  confirmed
  |=  [a=admission o=observation]
  ^-  ?
  ?.  (admission-valid a)  %.n
  =/  s=subject:vlj  subject.body.judgment.a
  =/  c=observation:lr  current.o
  ?~  commit.o  %.n
  ?&  (gth at.o at.a)
      =(at.a at.u.commit.o)  !=(0 id.u.commit.o)
      =(~[parent.a] parents.u.commit.o)
      =(base:demo desk.accepted.c)  =(work:demo desk.working.c)
      exists.accepted.c  exists.working.c
      private.accepted.c  private.working.c
      =(7 files.accepted.c)  =(7 files.working.c)
      =(`root.work.s root.accepted.c)  =(`root.work.s root.working.c)
      =((add 1 number.base.s) accepted-number.c)
      =(number.work.s work-number.c)
      =(`source.a accepted-source.c)  =(`source.a working-source.c)
  ==
++  observe
  |=  [r=record o=observation]
  ^-  record
  ::  Never rewrite an already-proved historical outcome, nor emit a card.
  ?:  =(%applied status.r)  r
  ?.  (gte at.o at.admission.r)  r
  =/  previous  observation.r
  ?:  ?~(previous %.n (lth at.o at.u.previous))  r
  r(status ?:((confirmed admission.r o) %applied %unknown), observation `o)
++  record-valid
  |=  r=record
  ^-  ?
  ?.  (admission-valid admission.r)  %.n
  ?~  observation.r  =(%submitted status.r)
  ?&  !=(%submitted status.r)
      (gte at.u.observation.r at.admission.r)
      =((confirmed admission.r u.observation.r) =(%applied status.r))
  ==
++  ledger-valid
  |=  held=ledger
  ^-  ?
  ?&  (lte ~(wyt by held) 128)
      (lte (lent (skim ~(val by held) |=(r=record !=(%applied status.r)))) 1)
      %+  levy  ~(tap by held)
      |=  [key=@ux r=record]
      &(=(key digest.judgment.admission.r) (record-valid r))
  ==
++  fact
  |=  r=record
  ^-  *
  [%vibecoding-local-land-record (scot %ux (digest:vcl r)) r]
--
