::  Shared native plan and read contract. No measurement-owner wrapper,
::  scheduling, state migration or new authority. Existing owners delegate
::  these unchanged data definitions and checks here.
/+  obs=qpc-observation, sensing=qpc-task-sensing,
    gate=qpc-session-gate, law=qpc-law-core
|%
+$  plan
  $:  %qpc-instrument-plan-v1  instrument=@ux  law=@ux  stream=@ux
      session=@ux  task=@t  objective=@ux  manifest=manifest:obs
      cases=@ux  artifact=path  horizon=@t
  ==
++  plan-valid
  |=  [our=@p p=plan]
  ?&  (levy `(list @ux)`~[instrument.p law.p stream.p session.p objective.p cases.p] identifier:sensing)
      (text-valid:obs task.p)  (lte (met 3 task.p) 128)
      (text-valid:obs horizon.p)  (manifest-valid:obs manifest.p)
      =(our owner.manifest.p)  =(16 width.manifest.p)
      (tool-bound:obs manifest.p)
      =((propositions:sensing horizon.p) propositions.manifest.p)
      ?=(^ (policy-of:sensing manifest.p))
      (~(has in (silt scope.manifest.p)) artifact.p)
  ==
++  raw
  |=  [inner=agent:gall b=bowl:gall path=path]
  =/  ag  ~(. inner b(src our.b))
  (payload:gate (on-peek:ag path))
++  binding-of
  ::  A v4 (pooled) instrument's law belongs to the pool, not to one member:
  ::  its binding names the stream and manifest, so it is identical for
  ::  every member and never changes as sessions join. v1-v3 keep theirs.
  |=  p=plan
  ^-  binding:law
  ?:  =(%qpc-observation-manifest-v4 version.manifest.p)
    [instrument.p stream.p law.p (digest:obs manifest.p) project.manifest.p /pool]
  [instrument.p session.p law.p objective.p project.manifest.p artifact.p]
--
