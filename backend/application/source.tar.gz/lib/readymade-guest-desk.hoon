::  Publish the Readymade guest desk from this ship's own installed code.
::
::  A collaborator's ship installs %readymade-peer with kiln to join a shared
::  project; kiln then keeps it synced to the publisher. The file list is
::  /data/readymade-guest-manifest/txt ("self <path>" from this ship's own
::  Readymade desk, "base <path>" from its %base), so nothing outside that
::  list can ever be published. The first publication is a parentless root
::  commit; later ones commit exactly the manifest's files on top. Read for
::  everyone, write for this ship only. Owner-only; reads Clay, sends only
::  this ship's own Clay cards.
/+  mg=readymade-app-management
|%
++  guest-desk  %readymade-peer
::  Bumped when a guest's collaboration routes change incompatibly.
++  protocol  1
+$  from  ?(%self %base)
+$  entry  [=from pax=path]
+$  status
  $:  published=?  public=?  revision=@ud  source=desk
      files=@ud  missing=(list path)
  ==
++  pre
  |=  [our=@p at=@da d=desk]
  ^-  path
  /(scot %p our)/[d]/(scot %da at)
++  source
  ::  Where this ship's %readymade-collab code really lives: a hosted agent's
  ::  dead host desk when there is one, else the agent's own desk.
  |=  [our=@p at=@da self=desk]
  ^-  desk
  =/  desks=(set desk)  .^((set desk) %cd /(scot %p our)//(scot %da at))
  ?:((~(has in desks) %host-readymade-collab) %host-readymade-collab self)
++  manifest
  |=  [our=@p at=@da src=desk]
  ^-  (unit (list entry))
  =/  at-path=path  (weld (pre our at src) /data/readymade-guest-manifest/txt)
  ?.  .^(? %cu at-path)  ~
  =/  lines=wain  .^(wain %cx at-path)
  :-  ~
  %+  murn  lines
  |=  l=@t
  ^-  (unit entry)
  =/  t=tape  (trip l)
  ?:  (lth (lent t) 6)  ~
  =/  kind=tape  (scag 5 t)
  =/  rest=@t  (crip (slag 5 t))
  =/  pax=(unit path)  (rush rest stap)
  ?~  pax  ~
  ?:  =("self " kind)  `[%self u.pax]
  ?:  =("base " kind)  `[%base u.pax]
  ~
++  desk-of
  |=  [src=desk e=entry]
  ^-  desk
  ?:(?=(%self from.e) src %base)
++  missing
  |=  [our=@p at=@da src=desk m=(list entry)]
  ^-  (list path)
  %+  murn  m
  |=  e=entry
  ?:  .^(? %cu (weld (pre our at (desk-of src e)) pax.e))  ~
  `pax.e
++  public
  |=  [our=@p at=@da]
  ^-  ?
  =/  rules=[r=dict:clay w=dict:clay]
    .^([r=dict:clay w=dict:clay] %cp (pre our at guest-desk))
  ?&  =(%black mod.rul.r.rules)  =([~ ~] who.rul.r.rules)
      =(%white mod.rul.w.rules)  =([~ ~] who.rul.w.rules)
  ==
++  observe
  |=  [our=@p at=@da self=desk]
  ^-  status
  =/  src=desk  (source our at self)
  =/  m  (manifest our at src)
  =/  domes=cone:clay  .^(cone:clay %cx /(scot %p our)//(scot %da at)/domes)
  =/  d  (~(get by domes) [our guest-desk])
  :*  ?=(^ d)
      ?~(d %.n (public our at))
      ?~(d 0 let.u.d)
      src
      ?~(m 0 (lent u.m))
      ?~(m ~ (missing our at src u.m))
  ==
++  plan
  ::  The cards that make %readymade-peer equal the manifest, and how many
  ::  files that changes. An empty list means it already does.
  |=  [our=@p at=@da self=desk]
  ^-  (each [cards=(list card:agent:gall) changed=@ud] @tas)
  =/  src=desk  (source our at self)
  =/  m  (manifest our at src)
  ?~  m  [%| %guest-manifest-missing]
  ?~  u.m  [%| %guest-manifest-empty]
  ?^  (missing our at src u.m)  [%| %guest-files-missing]
  =/  want=(map path page:clay)
    %-  ~(put by (malt (turn u.m |=(e=entry [pax.e `page:clay`[(rear pax.e) .^(* %cx (weld (pre our at (desk-of src e)) pax.e))]]))))
    [/desk/bill `page:clay`[%bill `(list dude:gall)`~[%readymade-collab]]]
  =/  perm=card:agent:gall
    [%pass /guest-desk/perm %arvo %c %perm guest-desk / %r `[%black ~]]
  =/  domes=cone:clay  .^(cone:clay %cx /(scot %p our)//(scot %da at)/domes)
  =/  d  (~(get by domes) [our guest-desk])
  ?~  d
    [%& [~[[%pass /guest-desk/new %arvo (new-desk:cloy guest-desk ~ want)] perm] ~(wyt by want)]]
  =/  head=(unit tako:clay)  (~(get by hit.u.d) let.u.d)
  ?~  head  [%| %guest-desk-unreadable]
  =/  now=(list path)  .^((list path) %ct (pre our at guest-desk))
  =/  extra=@ud  (lent (skip now |=(p=path (~(has by want) p))))
  =/  changed=@ud
    %+  add  extra
    %-  lent
    %+  skip  ~(tap by want)
    |=  [p=path g=page:clay]
    ?.  .^(? %cu (weld (pre our at guest-desk) p))  %.n
    =(q.g .^(* %cx (weld (pre our at guest-desk) p)))
  ?:  =(0 changed)
    ?:((public our at) [%& [~ 0]] [%& [~[perm] 0]])
  [%& [~[[%pass /guest-desk/update %arvo (new-desk:cloy guest-desk head want)] perm] changed]]
::  HTTP: GET reports the status; POST publishes. Both owner-only.
++  status-json
  |=  s=status
  ^-  json
  %-  pairs:enjs:format
  :~  ['schema' s+'readymade-guest-desk-v1']
      ['desk' s+(scot %tas guest-desk)]
      ['protocol' (numb:enjs:format protocol)]
      ['published' b+published.s]
      ['public' b+public.s]
      ['revision' (numb:enjs:format revision.s)]
      ['source' s+(scot %tas source.s)]
      ['files' (numb:enjs:format files.s)]
      ['missing' a+(turn (scag 32 missing.s) |=(p=path s+(spat p)))]
  ==
++  receipt-json
  |=  changed=@ud
  ^-  json
  %-  pairs:enjs:format
  :~  ['schema' s+'readymade-guest-desk-receipt-v1']
      ['status' s+?:(=(0 changed) 'unchanged' 'submitted')]
      ['changed' (numb:enjs:format changed)]
      ['confirmed' b+%.n]
  ==
++  post-valid
  ::  Same-origin JSON with the explicit header and the one known body.
  |=  req=inbound-request:eyre
  ^-  ?
  ?.  &(authenticated.req =('POST' method.request.req))  %.n
  =/  host  (header:mg header-list.request.req 'host')
  =/  origin  (header:mg header-list.request.req 'origin')
  =/  mime  (header:mg header-list.request.req 'content-type')
  ?~  host  %.n
  ?~  origin  %.n
  ?~  mime  %.n
  ?.  ?&  =(u.origin (cat 3 ?:(secure.req 'https://' 'http://') u.host))
          |(=(u.mime 'application/json') =(u.mime 'application/json; charset=utf-8'))
          =(`'v1' (header:mg header-list.request.req 'x-readymade-guest-desk'))
      ==
    %.n
  ?~  body.request.req  %.n
  =(q.u.body.request.req '{"schema":"readymade-guest-desk-command-v1","operation":"publish"}')
--
