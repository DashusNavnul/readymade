::  Additional request-specific restrictions, never a grant or execution.
/-  nc=native-coding
/+  project=native-coding-project, contract=cantrip-native-coding-contract
|%
+$  request
  [session=@ux request=@ux grant=@ux source=revision:nc operations=(set operation:nc)]
+$  record
  $:  owner=@p  session=@ux  request=@ux  grant=@ux  project=@t
      configuration=@ux  source=revision:nc  request-digest=@ux
      operations=(set operation:nc)
  ==
+$  ledger  (map @ux record)
++  identifier
  |=  id=@ux
  &(!=(0 id) (lte (met 0 id) 256))
++  valid
  |=  [our=@p r=record]
  ^-  ?
  ?&  =(our owner.r)  =(our owner.source.r)
      (identifier session.r)  (identifier request.r)
      (identifier grant.r)  (identifier configuration.r)
      (identifier request-digest.r)
      (gte (met 3 project.r) 1)  (lte (met 3 project.r) 128)
      (lte (met 0 our) 128)
      (revision-valid:project source.r)
      (segment-valid:project desk.source.r)
      (lte (met 0 number.source.r) 64)
      (lte (met 0 root.source.r) 256)  (lte (met 0 commit.source.r) 256)
      (lte ~(wyt in operations.r) 32)
      =(operations.r (silt ~(tap in operations.r)))
  ==
++  same
  |=  [a=record b=record]
  =(a(operations ~) b(operations ~))
++  narrow
  |=  [our=@p held=ledger proposed=record]
  ^-  (each ledger @tas)
  ?.  (valid our proposed)  [%| %request-ceiling-invalid]
  =/  old  (~(get by held) request.proposed)
  ?^  old
    ?.  (same u.old proposed)  [%| %request-ceiling-conflict]
    ?.  (levy ~(tap in operations.proposed) |=(op=operation:nc (~(has in operations.u.old) op)))
      [%| %request-ceiling-widening]
    [%& (~(put by held) request.proposed proposed)]
  ?.  (lth ~(wyt by held) 512)  [%| %request-ceiling-capacity]
  [%& (~(put by held) request.proposed proposed)]
++  permits
  |=  [our=@p g=@ux value=(unit record) context=context:nc operations=(list operation:nc)]
  ^-  ?
  ?~  value  %.y
  =/  r=record  u.value
  ?&  (valid our r)  =(g grant.r)
      =(session.r session.context)  =(request.r request.context)
      =(project.r project.context)  =(configuration.r configuration.context)
      =(owner.r actor.context)  =(source.r source.context)
      (levy operations |=(op=operation:nc (~(has in operations.r) op)))
  ==
++  restore
  |=  [our=@p raw=*]
  ^-  (unit ledger)
  =/  parsed  ((soft ledger) raw)
  ?~  parsed  ~
  ?.  &(=(raw u.parsed) =(u.parsed (malt ~(tap by u.parsed))) (lte ~(wyt by u.parsed) 512))  ~
  ?.  (levy ~(tap by u.parsed) |=([id=@ux r=record] &(=(id request.r) (valid our r))))  ~
  parsed
++  bound
  ::  Revocation remains live law; historical ceilings survive revocation.
  |=  [our=@p held=ledger tools=organ:contract]
  ^-  ?
  %+  levy  ~(tap by held)
  |=  [id=@ux r=record]
  =/  found  (~(get by grants.tools) grant.r)
  ?~  found  %.n
  =/  g=grant:contract  grant.u.found
  ?&  =(id request.r)  (valid our r)
      =(owner.r actor.g)  =(session.r session.g)
      =(project.r id.spec.project.g)
      =(configuration.r (configuration:project project.g))
      =(desk.source.r working.project.g)
      (levy ~(tap in operations.r) |=(op=operation:nc (~(has in operations.g) op)))
  ==
--
