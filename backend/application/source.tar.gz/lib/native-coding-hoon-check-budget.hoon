::  Pure allocation of a total Hoon evaluation allowance; no authority grant.
/-  nc=native-coding
|%
++  expression-limit  2.000.000
++  candidate-total-limit  8.000.000
++  supported
  |=  targets=(list build-target:nc)
  ^-  ?
  (levy targets |=(target=build-target:nc =(%hoon kind.target)))
++  units
  |=  targets=(list build-target:nc)
  ^-  @ud
  %+  roll  targets
  |=  [target=build-target:nc total=@ud]
  (add total (lent checks.target))
++  target-budget
  ::  Atoms do not overflow. Floors leave rounding remainder unallocated.
  ::  No-check Hoon builds perform no expression evaluation and receive zero.
  |=  [targets=(list build-target:nc) maximum=@ud target=build-target:nc]
  ^-  (each @ud @tas)
  ?.  (supported targets)  [%| %hoon-check-budget-unsupported]
  ?.  &((gte maximum 1) (lte maximum candidate-total-limit))
    [%| %hoon-check-budget-range]
  ?.  (lien targets |=(found=build-target:nc =(target found)))
    [%| %hoon-check-budget-target-missing]
  =/  count=@ud  (units targets)
  ?:  =(0 count)  [%& 0]
  ?:  (lth maximum count)  [%| %hoon-check-budget-insufficient]
  ::  A larger authorized total never raises one expression's ceiling.
  ::  Capped shares remain unused; they are not reassigned to other targets.
  [%& (min (mul expression-limit (lent checks.target)) (div (mul maximum (lent checks.target)) count))]
--
