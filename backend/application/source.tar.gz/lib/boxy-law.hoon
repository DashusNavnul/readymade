::  /lib/boxy-law.hoon
::
::  Pure, host-sequenced constitutional law for Boxy workspaces.  Explicitly
::  common publication is a capability-bound command; private state is never
::  projected by this law.
::
/-  bx=boxy
|%
++  initial-state
  ^-  state:bx
  ['boxy-constitutional-state-v3' ~]
::
++  event-history-limit  4.096
::
++  non-empty
  |=  text=@t
  ^-  ?
  !=(0 (met 3 text))
::
++  policy-valid
  |=  policy=decision-policy:bx
  ^-  ?
  ?-  -.policy
    %quorum    (gth minimum.policy 0)
    %unanimity  %.y
  ==
::
++  authorship-valid
  |=  authorship=authorship:bx
  ^-  ?
  ?-  -.authorship
    %human          %.y
    %model-assisted  (non-empty model.authorship)
    %model-proposed  (non-empty model.authorship)
  ==
::
++  law-digest-for-values
  |=  [id=workspace-id:bx policy=decision-policy:bx]
  ^-  digest:bx
  (shax (jam [%boxy-constitutional-law-v2 id policy %cantrip-boxy-motion-v1]))
::
++  law-digest-for
  |=  config=workspace-config:bx
  ^-  digest:bx
  (law-digest-for-values id.config policy.config)
::
++  payload-digest-for
  |=  command=command:bx
  ^-  digest:bx
  (shax (jam command))
::
++  event-digest-for
  |=  $:  seq=@ud
          actor=@p
          action=action:bx
          code=@tas
          membership-epoch=@ud
          previous=(unit digest:bx)
      ==
  ^-  digest:bx
  (shax (jam [%boxy-event-v1 seq actor action code membership-epoch previous]))
::
++  append-event
  |=  [workspace=workspace-state:bx actor=@p action=action:bx code=@tas]
  ^-  workspace-state:bx
  =/  seq=@ud  +(event-seq.workspace)
  =/  previous=(unit digest:bx)  head.workspace
  =/  digest=digest:bx
    (event-digest-for seq actor action code membership-epoch.workspace previous)
  =/  event=event:bx
    [seq actor action code membership-epoch.workspace previous digest]
  %=  workspace
    event-seq  seq
    events     (scag event-history-limit ^+(events.workspace [event events.workspace]))
    head       `digest
  ==
::
++  event-valid
  |=  event=event:bx
  ^-  ?
  =(digest.event (event-digest-for seq.event actor.event action.event code.event membership-epoch.event previous.event))
::
++  event-list-valid
  |=  events=(list event:bx)
  ^-  ?
  ?~  events  %.y
  ?.  (event-valid i.events)  %.n
  ?~  t.events  %.y
  ?&  =(previous.i.events `digest.i.t.events)
      =(seq.i.events +(seq.i.t.events))
      $(events t.events)
  ==
::
++  event-chain-valid
  |=  workspace=workspace-state:bx
  ^-  ?
  ?~  events.workspace
    =(0 event-seq.workspace)
  ?&  =(event-seq.workspace seq.i.events.workspace)
      =(head.workspace `digest.i.events.workspace)
      (event-list-valid events.workspace)
  ==
::
++  migrate-stored-motion-v2
  |=  old=stored-motion-v2:bx
  ^-  stored-motion:bx
  [proposer.old motion.old votes.old ~ executed.old]
::
++  migrate-motions-v2
  |=  old=(map @t stored-motion-v2:bx)
  ^-  (map @t stored-motion:bx)
  %-  ~(urn by old)
  |=  [id=@t motion=stored-motion-v2:bx]
  (migrate-stored-motion-v2 motion)
::
++  migrate-state-v2
  |=  old=state-v2:bx
  ^-  state:bx
  =/  migrated=(map workspace-id:bx workspace-state:bx)
    %-  ~(urn by workspaces.old)
    |=  [id=workspace-id:bx legacy=workspace-state-v2:bx]
    ^-  workspace-state:bx
    :*  id
        title.legacy
        membership-epoch.legacy
        (law-digest-for-values id policy.legacy)
        policy.legacy
        members.legacy
        invitations.legacy
        (migrate-motions-v2 motions.legacy)
        seen-nonces.legacy
        event-seq.legacy
        events.legacy
        head.legacy
    ==
  ['boxy-constitutional-state-v3' migrated]
::
++  migrate-state-v1
  |=  old=state-v1:bx
  ^-  state:bx
  =/  migrated=(map workspace-id:bx workspace-state:bx)
    %-  ~(urn by workspaces.old)
    |=  [id=workspace-id:bx legacy=workspace-state-v1:bx]
    ^-  workspace-state:bx
    :*  id
        title.legacy
        membership-epoch.legacy
        (law-digest-for-values id policy.legacy)
        policy.legacy
        members.legacy
        invitations.legacy
        (migrate-motions-v2 motions.legacy)
        seen-nonces.legacy
        0
        ~
        head.legacy
    ==
  ['boxy-constitutional-state-v3' migrated]
::
++  member-for
  |=  [workspace=workspace-state:bx actor=@p]
  ^-  (unit member:bx)
  (~(get by members.workspace) actor)
::
++  has-capability
  |=  [workspace=workspace-state:bx actor=@p capability=capability:bx]
  ^-  ?
  =/  found=(unit member:bx)  (member-for workspace actor)
  ?~  found  %.n
  (~(has in capabilities.u.found) capability)
::
++  parents-valid
  |=  [workspace=workspace-state:bx parents=(list digest:bx)]
  ^-  ?
  ?~  head.workspace  ?=(~ parents)
  ?~  parents  %.n
  ?&  ?=(~ t.parents)
      =(u.head.workspace i.parents)
  ==
::
++  motion-valid
  |=  motion=motion:bx
  ^-  ?
  ?&  (non-empty motion-id.motion)
      (authorship-valid authorship.motion)
      (non-empty summary.motion)
      (non-empty payload.motion)
  ==
::
++  approval-count
  |=  [members=(map @p member:bx) votes=(map @p ballot:bx)]
  ^-  @ud
  =/  rows=(list [@p ballot:bx])  ~(tap by votes)
  |-
  ?~  rows  0
  =/  rest=@ud  $(rows t.rows)
  ?:  ?&  =(%approve +.i.rows)
          (~(has by members) -.i.rows)
      ==
    +(rest)
  rest
::
++  policy-satisfied
  |=  [policy=decision-policy:bx members=(map @p member:bx) votes=(map @p ballot:bx)]
  ^-  ?
  =/  approvals=@ud  (approval-count members votes)
  ?-  -.policy
    %quorum    (gte approvals minimum.policy)
    %unanimity  =(approvals ~(wyt by members))
  ==
::
++  motion-digest-for
  |=  motion=motion:bx
  ^-  digest:bx
  (shax (jam [%boxy-motion-v1 motion]))
::
++  decision-digest-for
  |=  [workspace=workspace-state:bx stored=stored-motion:bx]
  ^-  digest:bx
  %-  shax
  %-  jam
  :*  %boxy-decision-v1
      id.workspace
      membership-epoch.workspace
      law-digest.workspace
      policy.workspace
      members.workspace
      proposer.stored
      motion.stored
      votes.stored
  ==
::
++  admission-binding-for
  |=  [workspace=workspace-state:bx stored=stored-motion:bx]
  ^-  motion-admission-binding:bx
  :*  id.workspace
      motion-id.motion.stored
      (motion-digest-for motion.stored)
      membership-epoch.workspace
      law-digest.workspace
      (decision-digest-for workspace stored)
  ==
::
++  admission-valid-for
  |=  $:  workspace=workspace-state:bx
          stored=stored-motion:bx
          admission=motion-admission:bx
      ==
  ^-  ?
  ?&  =(binding.admission (admission-binding-for workspace stored))
      (non-empty receipt-id.admission)
      (non-empty policy.admission)
      (non-empty reason.admission)
  ==
::
++  motion-lifecycle-for
  |=  [workspace=workspace-state:bx stored=stored-motion:bx]
  ^-  motion-lifecycle:bx
  ?:  executed.stored  %executed
  ?~  admission.stored
    ?:  (policy-satisfied policy.workspace members.workspace votes.stored)
      %decided
    %proposed
  ?:  (admission-valid-for workspace stored u.admission.stored)
    ?:(admitted.u.admission.stored %admitted %refused)
  ?:  (policy-satisfied policy.workspace members.workspace votes.stored)
    %decided
  %proposed
::
++  record-admission
  |=  $:  state=state:bx
          workspace-id=workspace-id:bx
          motion-id=@t
          admission=motion-admission:bx
      ==
  ^-  result:bx
  =/  found-workspace=(unit workspace-state:bx)
    (~(get by workspaces.state) workspace-id)
  ?~  found-workspace  (refuse state %workspace-not-found)
  =/  workspace=workspace-state:bx  u.found-workspace
  =/  found-motion=(unit stored-motion:bx)
    (~(get by motions.workspace) motion-id)
  ?~  found-motion  (refuse state %motion-not-found)
  =/  stored=stored-motion:bx  u.found-motion
  ?:  executed.stored  (refuse state %motion-executed)
  ?.  (admission-valid-for workspace stored admission)
    (refuse state %admission-binding-mismatch)
  =/  next-motion=stored-motion:bx  stored(admission `admission)
  =/  next-workspace=workspace-state:bx
    workspace(motions (~(put by motions.workspace) motion-id next-motion))
  (allow state ?:(admitted.admission %motion-admitted %motion-refused) next-workspace)
::
++  refuse-workspace
  |=  [workspace=workspace-state:bx code=@tas]
  ^-  workspace-result:bx
  [%.n code workspace]
::
++  allow-workspace
  |=  [workspace=workspace-state:bx code=@tas]
  ^-  workspace-result:bx
  [%.y code workspace]
::
++  refuse
  |=  [state=state:bx code=@tas]
  ^-  result:bx
  [%.n code state]
::
++  allow
  |=  [state=state:bx code=@tas workspace=workspace-state:bx]
  ^-  result:bx
  [%.y code state(workspaces (~(put by workspaces.state) id.workspace workspace))]
::
++  open-workspace
  |=  [state=state:bx founder=@p config=workspace-config:bx]
  ^-  result:bx
  ?:  (~(has by workspaces.state) id.config)  (refuse state %workspace-exists)
  ?.  ?&  (non-empty id.config)
          (non-empty title.config)
          (policy-valid policy.config)
          !=(0 ~(wyt in founder-capabilities.config))
      ==
    (refuse state %invalid-workspace)
  =/  founder-member=member:bx
    [founder-role.config founder-capabilities.config]
  =/  workspace=workspace-state:bx
    :*  id.config
        title.config
        1
        (law-digest-for config)
        policy.config
        (~(put by *(map @p member:bx)) founder founder-member)
        ~
        ~
        ~
        0
        ~
        ~
    ==
  =/  committed=workspace-state:bx
    (append-event workspace founder [%open config] %workspace-opened)
  (allow state %workspace-opened committed)
::
++  required-capability
  |=  command=command:bx
  ^-  (unit capability:bx)
  ?-  -.command
    %invite   `%invite
    %accept   ~
    %revoke   `%revoke
    %leave    `%leave
    %propose  `%propose
    %publish  `%publish
    %vote     `%vote
    %execute  `%execute
  ==
::
++  accept-invite
  |=  [workspace=workspace-state:bx actor=@p]
  ^-  workspace-result:bx
  ?:  (~(has by members.workspace) actor)
    (refuse-workspace workspace %already-member)
  =/  invitation=(unit invite-record:bx)
    (~(get by invitations.workspace) actor)
  ?~  invitation  (refuse-workspace workspace %invite-required)
  =/  admitted=member:bx
    [role.u.invitation capabilities.u.invitation]
  =/  next=workspace-state:bx
    %=  workspace
      membership-epoch  +(membership-epoch.workspace)
      members           (~(put by members.workspace) actor admitted)
      invitations       (~(del by invitations.workspace) actor)
    ==
  (allow-workspace next %invite-accepted)
::
++  apply-member-command
  |=  [workspace=workspace-state:bx actor=@p command=command:bx]
  ^-  workspace-result:bx
  ?-  -.command
    %invite
      ?:  |(=(actor ship.command) (~(has by members.workspace) ship.command))
        (refuse-workspace workspace %invalid-invitee)
      ?:  (~(has by invitations.workspace) ship.command)
        (refuse-workspace workspace %invite-exists)
      ?.  ?&  (non-empty role.command)
              !=(0 ~(wyt in capabilities.command))
          ==
        (refuse-workspace workspace %invalid-invite)
      =/  invitation=invite-record:bx
        [role.command capabilities.command actor]
      (allow-workspace workspace(invitations (~(put by invitations.workspace) ship.command invitation)) %invited)
    %accept
      (accept-invite workspace actor)
    %revoke
      ?:  =(actor ship.command)  (refuse-workspace workspace %use-leave)
      ?.  (~(has by members.workspace) ship.command)
        (refuse-workspace workspace %member-not-found)
      ?:  =(1 ~(wyt by members.workspace))
        (refuse-workspace workspace %last-member)
      =/  next=workspace-state:bx
        %=  workspace
          membership-epoch  +(membership-epoch.workspace)
          members           (~(del by members.workspace) ship.command)
        ==
      (allow-workspace next %member-revoked)
    %leave
      ?:  =(1 ~(wyt by members.workspace))
        (refuse-workspace workspace %last-member)
      =/  next=workspace-state:bx
        %=  workspace
          membership-epoch  +(membership-epoch.workspace)
          members           (~(del by members.workspace) actor)
        ==
      (allow-workspace next %member-left)
    %propose
      ?.  (motion-valid motion.command)
        (refuse-workspace workspace %invalid-motion)
      ?:  (~(has by motions.workspace) motion-id.motion.command)
        (refuse-workspace workspace %motion-exists)
      =/  stored=stored-motion:bx
        [actor motion.command ~ ~ %.n]
      (allow-workspace workspace(motions (~(put by motions.workspace) motion-id.motion.command stored)) %motion-proposed)
    %publish
      (allow-workspace workspace %common-published)
    %vote
      =/  found=(unit stored-motion:bx)
        (~(get by motions.workspace) motion-id.command)
      ?~  found  (refuse-workspace workspace %motion-not-found)
      ?:  executed.u.found  (refuse-workspace workspace %motion-executed)
      =/  voted=stored-motion:bx
        u.found(votes (~(put by votes.u.found) actor ballot.command))
      (allow-workspace workspace(motions (~(put by motions.workspace) motion-id.command voted)) %vote-recorded)
    %execute
      =/  found=(unit stored-motion:bx)
        (~(get by motions.workspace) motion-id.command)
      ?~  found  (refuse-workspace workspace %motion-not-found)
      ?:  executed.u.found  (refuse-workspace workspace %motion-executed)
      ?:  ?=(%model-proposed -.authorship.motion.u.found)
        (refuse-workspace workspace %model-proposed-execution)
      ?~  admission.u.found
        (refuse-workspace workspace %motion-admission-required)
      ?.  (admission-valid-for workspace u.found u.admission.u.found)
        (refuse-workspace workspace %motion-admission-stale)
      ?.  admitted.u.admission.u.found
        (refuse-workspace workspace %motion-admission-refused)
      ?.  (policy-satisfied policy.workspace members.workspace votes.u.found)
        (refuse-workspace workspace %decision-not-reached)
      =/  executed=stored-motion:bx  u.found(executed %.y)
      (allow-workspace workspace(motions (~(put by motions.workspace) motion-id.command executed)) %motion-executed)
  ==
::
++  apply
  |=  [state=state:bx actor=@p envelope=command-envelope:bx]
  ^-  result:bx
  =/  found=(unit workspace-state:bx)
    (~(get by workspaces.state) workspace.envelope)
  ?~  found  (refuse state %workspace-not-found)
  =/  workspace=workspace-state:bx  u.found
  ?.  =(membership-epoch.workspace membership-epoch.envelope)
    (refuse state %stale-membership-epoch)
  ?.  =(law-digest.workspace law-digest.envelope)
    (refuse state %law-digest-mismatch)
  ?.  =((payload-digest-for command.envelope) payload-digest.envelope)
    (refuse state %payload-digest-mismatch)
  ?.  (non-empty idempotency-nonce.envelope)
    (refuse state %invalid-idempotency-nonce)
  ?:  (~(has in seen-nonces.workspace) idempotency-nonce.envelope)
    (refuse state %replay)
  ?.  (parents-valid workspace causal-parents.envelope)
    (refuse state %causal-parent-mismatch)
  =/  command=command:bx  command.envelope
  =/  applied=workspace-result:bx
    ?:  =(%accept -.command)
      (accept-invite workspace actor)
    =/  member=(unit member:bx)  (member-for workspace actor)
    ?~  member  (refuse-workspace workspace %not-member)
    =/  required=(unit capability:bx)  (required-capability command)
    ?~  required  (refuse-workspace workspace %missing-capability)
    ?.  (has-capability workspace actor u.required)
      (refuse-workspace workspace %missing-capability)
    (apply-member-command workspace actor command)
  ?.  ok.applied  (refuse state code.applied)
  =/  replay-safe=workspace-state:bx
    %=  workspace.applied
      seen-nonces
        (~(put in seen-nonces.workspace.applied) idempotency-nonce.envelope)
    ==
  =/  committed=workspace-state:bx
    (append-event replay-safe actor [%command envelope] code.applied)
  (allow state code.applied committed)
--
