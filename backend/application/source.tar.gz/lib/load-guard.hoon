::  Load guard: the deploy rehearsal's data check, run by the new build
::  itself while it installs. Wrap an agent outermost; it saves nothing.
::
::  A new build gets the running agent's save in +on-load. When the saved
::  shape did not change (same tags and the same inner version), a
::  code-only deploy must carry every owned value over unchanged. After the
::  wrapped +on-load the guard saves again and checks:
::    1. +on-load sent no %poke card (a load must not act);
::    2. each part from +owned (the agent's own extractor: wrapper data and
::       the inner state, types left out) is equal before and after;
::    3. the two saved types nest both ways, so either build can load the
::       other's save (the way back stays open).
::  A changed shape is a migration: only check 1 runs, and the result says
::  so. A failure crashes the load with its reason, so brain-shell refuses
::  the candidate, keeps the running agent, and shows the reason at
::  /x/brain-shell/status. The last result is at /x/load-guard.
::
::  Law: %host-law /law/load-guard/hoon holds %on or %off (absent = %on).
::  %off is the way out if the guard itself is ever wrong: one dead-desk
::  commit, no rebuild.
|%
+$  part  [tag=@tas data=*]
+$  result
  $%  [%checked at=@da parts=@ud]
      [%migration at=@da why=@t]
      [%off at=@da]
  ==
++  law-path  /law/load-guard/hoon
++  law-on
  |=  [our=@p now=@da]
  ^-  ?
  =/  pax=path  (weld /(scot %p our)/host-law/(scot %da now) law-path)
  ?.  .^(? %cu pax)  &
  =/  got  (mule |.(;;(@tas q:(slap !>(~) (ream .^(@t %cx pax))))))
  ?:  ?=(%| -.got)  &
  !=(%off p.got)
::  the parts' tags, with the inner state's head (its version) for %inner
++  shape
  |=  parts=(list part)
  ^-  (list @)
  %+  turn  parts
  |=  p=part
  ?.  =(%inner tag.p)  tag.p
  ?@(data.p data.p ?@(-.data.p -.data.p 0))
++  pokes
  |=  cards=(list card:agent:gall)
  ^-  @ud
  (lent (skim cards |=(c=card:agent:gall ?=([%pass * %agent * %poke *] c))))
++  check
  |=  [owned=$-(vase (list part)) old=vase new=vase cards=(list card:agent:gall) now=@da]
  ^-  (each result tang)
  =/  n  (pokes cards)
  ?.  =(0 n)
    [%| ~[leaf+"load-guard: +on-load sent {<n>} %poke card(s); a load must not act"]]
  =/  is  (mule |.((owned new)))
  ?:  ?=(%| -.is)
    [%| [leaf+"load-guard: +owned cannot read this build's own save; update +owned with the state" p.is]]
  =/  was  (mule |.((owned old)))
  ?:  ?=(%| -.was)  [%& %migration now 'the old save has another layout']
  ?.  =((shape p.was) (shape p.is))  [%& %migration now 'saved tags or inner version changed']
  =/  a  p.was
  =/  b  p.is
  |-  ^-  (each result tang)
  ?~  a
    ?.  (~(nest ut p.old) | p.new)
      [%| ~[leaf+"load-guard: the running build's saved type does not take the new save; the way back would fail"]]
    ?.  (~(nest ut p.new) | p.old)
      [%| ~[leaf+"load-guard: the new saved type does not take the running build's save"]]
    [%& %checked now (lent p.was)]
  ?~  b  [%| ~[leaf+"load-guard: the new save has fewer parts"]]
  ?.  =(data.i.a data.i.b)
    :-  %|
    :~  leaf+"load-guard: owned part %{(trip tag.i.a)} changed across +on-load (mug {<(mug data.i.a)>} -> {<(mug data.i.b)>})"
        leaf+"a code-only build must carry it unchanged; bump the state version to migrate, or set law %off"
    ==
  $(a t.a, b t.b)
::
++  agent
  |=  owned=$-(vase (list part))
  |=  inner=agent:gall
  =|  last=(unit result)
  ^-  agent:gall
  |_  =bowl:gall
  +*  this  .
      ag  ~(. inner bowl)
  ++  on-init
    =^  cards  inner  on-init:ag
    [cards this]
  ++  on-save  on-save:ag
  ++  on-load
    |=  old=vase
    =^  cards  inner  (on-load:ag old)
    ?.  (law-on our.bowl now.bowl)  [cards this(last `[%off now.bowl])]
    =/  got  (check owned old on-save:~(. inner bowl) cards now.bowl)
    ?:  ?=(%| -.got)  (mean p.got)
    [cards this(last `p.got)]
  ++  on-poke
    |=  [=mark =vase]
    =^  cards  inner  (on-poke:ag mark vase)
    [cards this]
  ++  on-watch
    |=  =path
    =^  cards  inner  (on-watch:ag path)
    [cards this]
  ++  on-leave
    |=  =path
    =^  cards  inner  (on-leave:ag path)
    [cards this]
  ++  on-peek
    |=  =path
    ^-  (unit (unit cage))
    ?:  ?=([%x %load-guard ~] path)  ``noun+!>(last)
    (on-peek:ag path)
  ++  on-agent
    |=  [=wire =sign:agent:gall]
    =^  cards  inner  (on-agent:ag wire sign)
    [cards this]
  ++  on-arvo
    |=  [=wire =sign-arvo]
    =^  cards  inner  (on-arvo:ag wire sign-arvo)
    [cards this]
  ++  on-fail
    |=  [=term =tang]
    =^  cards  inner  (on-fail:ag term tang)
    [cards this]
  --
--
