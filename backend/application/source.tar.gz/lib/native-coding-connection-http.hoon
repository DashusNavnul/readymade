::  Select an existing connection without changing its registry or credentials.
::  Only Viki's existing session selection action is returned; no inference.
/-  np=native-coding-provider
/+  solo=native-coding-solo-review-http, law=native-coding-provider,
    loop=native-coding-loop, cr=codex-responses
|%
++  prepare
  |=  [our=@p e=public-session:loop project=@t source=@ux key=@tas chosen=selection:np binding=@ux]
  ^-  (each action:loop @tas)
  ?.  &(=(our owner.session.e) =(our worker.e))
    [%| %connection-local-owner-required]
  ?.  &(=(project project.session.e) =(source (shax (jam working.session.e))))
    [%| %connection-session-source-changed]
  ?.  &((name-valid:law key) (selection-valid:law chosen))
    [%| %connection-invalid]
  ?.  =(binding (digest:solo chosen))
    [%| %connection-binding-changed]
  [%& [%select id.session.e chosen key our]]
++  decode
  |=  [our=@p now=@da object=json]
  ^-  *
  ?>  ?=(%o -.object)
  ?>  =((silt ~['nonce' 'kind' 'session' 'project' 'source' 'providerKey' 'binding']) ~(key by p.object))
  ?>  =(`'connection-select' (string:cr object 'kind'))
  =/  id=@ux  (hex:solo object 'session')
  =/  e  (session:solo our now id)
  =/  key=@tas  (need (string:cr object 'providerKey'))
  =/  chosen=selection:np  (need (registered:solo our now key))
  =/  action  (prepare our e (need (string:cr object 'project')) (hex:solo object 'source') key chosen (hex:solo object 'binding'))
  ?>  ?=(%& -.action)
  [%native-coding-action-v1 p.action]
--
