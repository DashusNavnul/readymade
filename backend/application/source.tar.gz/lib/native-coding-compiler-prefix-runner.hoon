::  Private Spider completion adapter. A large compiler receipt enters only
::  through its current local result watch, never through a public retain poke.
::  Retain it together with the old runner's compact terminal transition. The
::  old runner still owns start ACK ordering, cancellation and job completion.
/-  nc=native-coding
/+  runner=native-coding-job-runner, tools=cantrip-native-coding,
    core=native-coding-compiler-prefix,
    runtime=native-coding-compiler-prefix-runtime
|%
+$  completion
  [%native-coding-compiler-prefix-completion-v1 id=@ux value=retained:core]
+$  change
  $:  state=state:runner
      tools=organ:tools
      prefixes=organ:runtime
      cards=(list card:agent:gall)
  ==
++  byte-limit
  ::  The retained value has its own 32MiB cap; allow only a small envelope.
  (add byte-limit:core 4.096)
++  compact
  |=  value=retained:core
  ^-  tool-result:nc
  :*  %native-coding-tool-result-v1  context.request.job.request.value
      call-id.request.job.request.value  (report:core value)
  ==
++  delegate
  |=  [b=bowl:gall s=state:runner jobs=organ:tools prefixes=organ:runtime w=wire sign=sign:agent:gall]
  ^-  change
  =/  next  (on-agent:runner b s jobs w sign)
  [state.next tools.next prefixes cards.next]
++  unknown
  |=  [b=bowl:gall s=state:runner jobs=organ:tools prefixes=organ:runtime id=@ux e=handle:runner reason=@tas]
  ^-  change
  =/  next  (unknown:runner b s jobs id e reason)
  [state.next tools.next prefixes cards.next]
++  on-agent
  |=  [b=bowl:gall s=state:runner jobs=organ:tools prefixes=organ:runtime w=wire sign=sign:agent:gall]
  ^-  change
  ?.  ?=(%fact -.sign)  (delegate b s jobs prefixes w sign)
  ?.  =(%thread-done p.cage.sign)  (delegate b s jobs prefixes w sign)
  =/  raw=*  q.q.cage.sign
  ?.  |(?=(%native-coding-compiler-prefix-completion-v1 raw) ?=([%native-coding-compiler-prefix-completion-v1 *] raw))
    (delegate b s jobs prefixes w sign)
  ::  No normalization of foreign source identity, even for malformed facts.
  ?.  &(=(our.b src.b) ?=([%native-job @ %result ~] w))  [s jobs prefixes ~]
  =/  parsed  (slaw %ux i.t.w)
  ?~  parsed  [s jobs prefixes ~]
  =/  id=@ux  u.parsed
  ?.  =(w (wire-for:runner id %result))  [s jobs prefixes ~]
  =/  found  (~(get by s) id)
  ?~  found  [s jobs prefixes ~]
  =/  e=handle:runner  u.found
  =/  job  (~(get by records.jobs) id)
  ?~  job  [s jobs prefixes ~]
  ?.  ?&  =(id (key:tools request.e))
          =(request.e request.u.job)
          =(our.b actor.context.request.e)
          =(our.b p.source.e)
          =(tid.e (tid-for:runner our.b id request.e source.e salt.e))
      ==
    [s jobs prefixes ~]
  ?:  ?=(?(%finished %cancelled) phase.e)  [s jobs prefixes ~]
  ?.  &(?=(?(%running %unknown) stage.u.job) ?=(?(%sent %accepted) start.e))
    [s jobs prefixes ~]
  ?.  =(`[%& (result-path:runner e)] (~(get by wex.b) [w our.b %spider]))
    [s jobs prefixes ~]
  ?^  terminal.e  [s jobs prefixes ~]
  ?.  (lte (met 3 (jam raw)) byte-limit)
    (unknown b s jobs prefixes id e %native-prefix-terminal-too-large)
  =/  received  ((soft completion) raw)
  ?~  received  (unknown b s jobs prefixes id e %native-prefix-terminal-invalid)
  ?.  &(=(u.received raw) =(id id.u.received))
    (unknown b s jobs prefixes id e %native-prefix-terminal-mismatch)
  =/  value=retained:core  value.u.received
  ::  Retention performs fresh native permission/source/selection joins. A
  ::  failure is uncertainty, not a fabricated completion or compiler retry.
  =/  retained  (retain:runtime b prefixes jobs id value)
  ?:  ?=(%| -.retained)
    (unknown b s jobs prefixes id e p.retained)
  =/  result=tool-result:nc  (compact value)
  ?.  (lte (met 3 (jam [%thread-done result])) 262.144)
    (unknown b s jobs prefixes id e %native-prefix-report-too-large)
  ::  If start ACK is pending, old runner queues this exact compact fact; a
  ::  later ACK finalizes it. Both organs are returned in one native mutation.
  (delegate b s jobs p.retained w [%fact %thread-done !>(result)])
++  valid
  ::  Historical reload joins only. Current permission checks belong to retain
  ::  and prepare. No Clay/agent reads and no restoration of discarded data.
  |=  [our=@p prefixes=organ:runtime s=state:runner jobs=organ:tools]
  ^-  ?
  ?.  (valid:runner our s jobs)  %.n
  %+  levy  ~(tap by results.prefixes)
  |=  [id=@ux value=retained:core]
  =/  found  (~(get by s) id)
  ?~  found  %.n
  =/  e=handle:runner  u.found
  ?.  &(=(request.e request.job.request.value) (linked:core jobs id value %.n))  %.n
  =/  expected=tool-result:nc  (compact value)
  ?^  terminal.e
    ?.  =(u.terminal.e [%thread-done expected])  %.n
    ?:  =(%finished phase.e)  (linked:core jobs id value %.y)
    ::  A sent result may be retained before Spider's start acknowledgement.
    &(!=(%cancelled phase.e) ?=(?(%sent %accepted) start.e))
  ::  The old runner clears a queued fact on a late start refusal. Keep the
  ::  factual compiler receipt but never make it reusable: linked(...true)
  ::  requires the exact finished report. A later watch kick can update only
  ::  this unknown reason; neither transition repeats a command.
  ?.  ?&  =(%refused start.e)
          =(%unknown phase.e)
          ?=(?(%native-start-refused %native-result-watch-ended) reason.e)
      ==
    %.n
  =/  r=record:tools  (~(got by records.jobs) id)
  =/  unconfirmed=tool-result:nc
    :*  %native-coding-tool-result-v1  context.request.e  call-id.request.e
        [%unknown reason.e 'Native job outcome remains unconfirmed; no start or stop was repeated.']
    ==
  &(=(%unknown stage.r) =(`unconfirmed result.r))
--
