::  /lib/qpc-formula.hoon
::
::  Pure QPC / CT formula layer for the two source-paper focus pass.
::
::  This file intentionally implements only integer/fixed-scale sub-formulas:
::  attention normalization, chi-scaled action denominators, rho threshold, hbar
::  scaling, integer chi plateaus, square-root exponent ratios, and kappa/chi.  It does not compute exp(), continuous path
::  integrals, complex amplitudes, or the full C_mu_nu tensor.
::
/-  qpc-sur=qpc
|%
++  qpc-scale
  ^-  @ud
  1.000.000
::
++  qpc-chi-micro
  ::  chi = phi*pi ~= 5.083203692318905, fixed at 1e6 scale.
  ^-  @ud
  5.083.204
::
++  qpc-pi-micro
  ::  pi ~= 3.141592653589793, fixed at 1e6 scale.
  ^-  @ud
  3.141.593
::
++  nonzero
  |=  n=@ud
  ^-  @ud
  ?:  =(0 n)  1  n
::
++  sub-zero
  |=  [a=@ud b=@ud]
  ^-  @ud
  ?:  (gte a b)  (sub a b)  0
::
++  cap-scale
  |=  value=@ud
  ^-  @ud
  ?:  (gth value qpc-scale)  qpc-scale  value
::
++  isqrt
  |=  n=@ud
  ^-  @ud
  =/  x=@ud  0
  |-  ^-  @ud
  ?:  (gth (mul +(x) +(x)) n)
    x
  $(x +(x))
::
++  pow-ud
  |=  [base=@ud exponent=@ud]
  ^-  @ud
  =/  acc=@ud  1
  |-  ^-  @ud
  ?:  =(0 exponent)
    acc
  $(exponent (sub exponent 1), acc (mul acc base))
::
++  formula-contract
  |=  $:  id=qpc-formula-id:qpc-sur
          source=qpc-source:qpc-sur
          status=qpc-status:qpc-sur
          expression=@t
          provenance=(list @t)
          exact-evaluator=?
          requires-chi=?
          notes=@t
      ==
  ^-  qpc-formula-contract:qpc-sur
  [ id=id
    source=source
    status=status
    expression=expression
    provenance=provenance
    exact-evaluator=exact-evaluator
    requires-chi=requires-chi
    notes=notes
  ]
::
++  qpc-original-contracts
  ^-  (list qpc-formula-contract:qpc-sur)
  :~  (formula-contract %chi-rec %qpc-original %canonical 'chi = phi*pi ~= 5.08321' ~['docs/qpc/QPC_NORMALIZED_FORMULA_INVENTORY.md:59' 'papers/qpc/quantum-patterned-cosmos.txt:7-41'] & & 'PATAPHOR LAW ONLY (S102/F9.1): the recovered source edition RENOUNCES chi (lines 7-41, 2026-08-30 re-read); chi is retained as the desk-of-law self-grounded constant, never as source-canonical physics. micro value 5.083.204 = round(phi*pi*1e6), verified.')
      (formula-contract %chi-phase-closure %qpc-original %canonical 'chi*sin(pi/chi) = phi -- AS WRITTEN THIS IS NUMERICALLY FALSE (S102/F9.3)' ~['papers/qpc/quantum-patterned-cosmos.txt:870-872' 'papers/qpc/quantum-patterned-cosmos.txt:5441-5443'] | & 'Deferred and UNSUPPORTED BY THE HELD EDITION: chi*sin(pi/chi)=2.945, not phi=1.618 (the identity is satisfied by x=1.6885, not chi); the cited anchors belong to the lost longer edition and the statement is absent from the recovered one. No evaluator exists and none may be written until a source edition states the actual closure law.')
      (formula-contract %z-a %qpc-original %canonical 'Z_A ~= sum_i exp[-A*S_E(phi_i)/(hbar*chi)] * exp[i*S(phi_i)/(hbar*chi)]' ~['docs/qpc/QPC_NORMALIZED_FORMULA_INVENTORY.md:60' 'data/corpus_text.txt:45744-45751'] | & 'Deferred full evaluator: Hoon currently exposes exact chi-scaled exponent ratios only.')
      (formula-contract %rho-c %qpc-original %canonical 'rho_c[phi] = Z^-1 exp[-(1+A)*S_E[phi]/(hbar*chi)]' ~['docs/qpc/QPC_NORMALIZED_FORMULA_INVENTORY.md:61' 'data/corpus_text.txt:41412-41416'] | & 'Deferred full evaluator: requires Z and exp; ratio arm is exact.')
      (formula-contract %s-rec %qpc-original %canonical 'S_rec[phi] = -log rho_c[phi]' ~['docs/qpc/QPC_NORMALIZED_FORMULA_INVENTORY.md:62' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4184-4187'] | & 'Deferred full evaluator: requires log/rho_c normalization; chi-preserving ratio components are exposed separately.')
      (formula-contract %c-munu %qpc-original %canonical 'C_munu = <phi*d_mu*d_nu phi> - <phi><d_mu*d_nu phi>' ~['docs/qpc/QPC_NORMALIZED_FORMULA_INVENTORY.md:63' 'docs/qpc/STRICT_QPC_DESIGN_NOTE.md:64'] | & 'Full tensor derivation is deferred, not scalarized here.')
      (formula-contract %expval-o %qpc-original %canonical '<O> = integral Dphi rho_c[phi] O[phi]' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:263' 'docs/qpc/QPC_NORMALIZED_FORMULA_INVENTORY.md:60-63'] | & 'Deferred full evaluator: requires normalized rho_c path integral over observables.')
      (formula-contract %field-lagrangian %qpc-original %canonical 'L = d_mu phi* d^mu phi - mu^2 |phi|^2 - V_int(|phi|^2)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:210-215'] | | 'Deferred field-core law: no continuous field, derivative, interaction potential, or Euler-Lagrange evaluator is implemented.')
      (formula-contract %field-equation %qpc-original %canonical 'box phi + mu^2 phi + dV_int/dphi* = 0' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:211-215'] | | 'Deferred field equation: derivatives and interaction variation remain typed source vocabulary only.')
      (formula-contract %recursion-step-law %qpc-original %canonical 'phi_{n+1}(x,t) = F[phi_n(x,t), chi]' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:231-235'] | & 'Deferred recursion law: F is not specified as a bounded evaluator, so this remains transition vocabulary.')
      (formula-contract %recursion-depth-log %qpc-original %canonical 'n = log(E/E_Planck) / log(chi)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:232-235'] | & 'Deferred scale-depth law: logarithms and unitful energy normalization are not executed in Hoon.')
      (formula-contract %state-functional %qpc-original %canonical '|Psi[phi]> = integral Dphi Psi[phi] |phi>' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:240-243'] | | 'Deferred state-functional law: path measure and field-state semantics are retained without a continuous evaluator.')
      (formula-contract %stress-energy-tensor %qpc-original %canonical 'T_munu = d_mu phi* d_nu phi + d_nu phi* d_mu phi - g_munu[d_alpha phi* d^alpha phi - mu^2 |phi|^2 - V_int]' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:249-251'] | | 'Deferred stress-energy law: tensor derivatives, metric contraction, and interaction energy are not scalarized.')
      (formula-contract %u1-phase-gauge %qpc-original %canonical 'phi(x) -> exp[i alpha(x)] phi(x)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:267-271'] | | 'Deferred gauge law: complex phase rotation is source vocabulary, not an executable state change.')
      (formula-contract %covariant-derivative-gauge %qpc-original %canonical 'D_mu := d_mu + i g A_mu; A_mu -> A_mu - (1/g)d_mu alpha(x)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:267-271'] | | 'Deferred gauge-covariant derivative: no differential operator or gauge-field mutation is implemented.')
      (formula-contract %field-strength-tensor %qpc-original %canonical 'F_munu := d_mu A_nu - d_nu A_mu' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:268-271'] | | 'Deferred field-strength law: derivatives and tensor assembly are not implemented.')
      (formula-contract %running-coupling-log %qpc-original %canonical 'g^-2(mu) = g^-2(mu0) + [b0/(8*pi^2*chi)] log(mu/mu0)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:272-276'] | & 'Deferred running-coupling law: logarithms, renormalization scale semantics, and source conjecture status prevent execution.')
      (formula-contract %path-partition-z %qpc-original %canonical 'Z = sum_paths exp[-S_E/(hbar*chi)]' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:307-309'] | & 'Deferred partition law: path summation and exponential weighting are not evaluated by the kernel.')
      (formula-contract %delayed-choice-probability %qpc-original %canonical 'P_dc(phi) = 1/2 [1 + V_chi cos phi]' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:313-315'] | & 'Deferred delayed-choice probability: cosine/fringe semantics are verifier vocabulary only.')
      (formula-contract %transition-rate-gamma %qpc-original %canonical 'Gamma_transition = (mu^3/sqrt(lambda*chi)) exp(-Delta F/(k_B*T))' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4774-4779'] | & 'Deferred transition-rate law: square root, exponential, temperature scale, and physical rate interpretation are not executed.')
      (formula-contract %einstein-hilbert-qpc-action %qpc-original %canonical 'S_grav+matter = integral d4x sqrt(-g)[R/kappa_chi + L_matter], with kappa_chi = 8*pi*G/chi' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:252-258'] | & 'Deferred gravity action: only the kappa_chi ratio is executable; curvature, metric determinant, and matter action are not evaluated.')
      (formula-contract %path-probability-weight %qpc-original %canonical 'p(phi) proportional to Z^-1 exp[-S_E(phi)/(hbar*chi)]' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:288-321' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:428-429'] | & 'Deferred path-probability law: normalization, exponential weighting, and path measure are retained as source vocabulary only.')
      (formula-contract %bell-correlation-visibility %qpc-original %canonical 'E(alpha,beta) = -V_chi cos(alpha-beta), with 0 <= V_chi <= 1' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:298-299' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4150-4152'] | & 'Deferred Bell correlation law: the V_chi band gate is executable separately; cosine correlations are not evaluated.')
      (formula-contract %tunneling-transmission-probability %qpc-original %canonical 'T ~= exp[-2 sqrt(2*m*(V0-E))*L/(hbar*chi)]' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:428-429'] | & 'Deferred tunneling probability: the square-root exponent proxy is executable separately; exponential transmission is not evaluated.')
      (formula-contract %interference-visibility-decay %qpc-original %canonical 'V(A) = V0 exp[-A*DeltaS_chi/(hbar*chi)]' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:925-928'] | & 'Deferred interference visibility decay: exponential attenuation and fitted visibility statistics are not evaluated.')
      (formula-contract %zpf-attention-estimator-log %qpc-original %canonical 'A_hat_ZPF = -ln(S_xx(omega0)/S_xx^chi(omega0))/eta(omega0)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:943-946'] | & 'Deferred ZPF attention estimator: logarithm, eta calibration, and frequency-specific spectrum fitting are not evaluated.')
      (formula-contract %regulator-uniqueness-functional %qpc-original %canonical 'R[Phi] = exp[-A[Phi]*S_E,chi[Phi]/(hbar*chi)] while preserving gauge identities and the chi fixed point' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:951-973'] | & 'Symbolic regulator law: retained as a non-executable claim-check surface for uniqueness, gauge identity, and chi fixed-point claims.')
      (formula-contract %z-obs-attention-functional %qpc-original %canonical 'Z_obs = integral Dphi exp[-A*S_E,chi/(hbar*chi)] exp[i*S_chi/(hbar*chi)]' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:850-855' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4392-4399'] | & 'Deferred observer partition law: path integration, complex phase, and attention-weighted action are not evaluated.')
      (formula-contract %p1-attention-weight %qpc-original %canonical 'weight = exp[-(1+A)*S_E/(hbar*chi)], with A in [0,1]' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4063-4069'] | & 'Symbolic P1 law invariant: constrains allowed attention-weight claims without providing an exponential evaluator.')
      (formula-contract %ct-stress-coupling-law %qpc-original %canonical '(g_c/chi) * Tr(C_munu T^munu)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:888-901' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4401-4405'] | & 'Symbolic C/T stress coupling: tensor contraction and physical coupling semantics remain claim-check vocabulary only.')
      (formula-contract %em-field-coupling-law %qpc-original %canonical 'alpha_c * C_munu * F^{mu lambda} * F_lambda^nu' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:905-908'] | & 'Symbolic electromagnetic coupling: no field tensor evaluator or EM-state mutation is implemented.')
      (formula-contract %attention-interference-estimator-log %qpc-original %canonical 'A_hat_int = -(hbar*chi/DeltaS_chi) * ln(V/V0)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:926-928'] | & 'Deferred interference attention estimator: logarithm, visibility fitting, and DeltaS calibration are not evaluated.')
      (formula-contract %gravity-resolution-equation %qpc-original %canonical 'G_munu + Lambda_chi*g_munu = kappa_chi*T_munu + (g_c/chi)*C_munu + (1/chi)*M_munu' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4432-4439'] | & 'Symbolic gravity-resolution equation: composite tensor field equation is retained for claim checking only.')
      (formula-contract %mass-attention-scaling %qpc-original %canonical 'm_phys ~= (m_SM/chi) * <1 + A>, with low-coherence recovery tending to m_SM' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4426-4431' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4474-4479'] | & 'Symbolic mass-scaling claim surface: no mass simulator or physical validation is implemented.')
      (formula-contract %bell-epsilon-residual %qpc-original %canonical 'E(alpha,beta) = -cos(alpha-beta)[1 + epsilon_chi], with epsilon_chi ~= 0.02-0.04' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4458-4465'] | & 'Symbolic Bell residual surface: epsilon claims require external evidence and do not become verifier truth by themselves.')
      (formula-contract %a-attn-qpc %qpc-original %direct-exec 'A = Tr(C_munu C^munu) / C_max in [0,1]' ~['docs/qpc/QPC_NORMALIZED_FORMULA_INVENTORY.md:64' 'papers/qpc/quantum-patterned-cosmos.txt:70' 'papers/qpc/quantum-patterned-cosmos.txt:261-262' 'papers/qpc/quantum-patterned-cosmos.txt:286'] & & 'Implemented as capped fixed-scale trace/Cmax normalization.')
      (formula-contract %a-attn-vac %qpc-original %direct-exec 'A = [Tr(CC) - Tr(C_vac C_vac)] / C_max in [0,1]' ~['papers/qpc/quantum-patterned-cosmos.txt:251'] & & 'Implemented as safe vacuum-subtracted fixed-scale attention.')
      (formula-contract %i-phi %qpc-original %direct-exec 'I[phi] = Theta(rho_c[phi] - rho_th)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:5760'] & & 'Implemented as an exact fixed-scale threshold gate over caller-supplied rho_c and rho_th.')
      (formula-contract %rho-th %qpc-original %direct-exec 'rho_th = chi^-1 * (1+A)^-1' ~['docs/qpc/QPC_NORMALIZED_FORMULA_INVENTORY.md:66'] & & 'Implemented as fixed-scale reciprocal threshold using scaled A and chi.')
      (formula-contract %threshold-action %qpc-original %direct-exec 'Delta S = n*hbar*chi' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:6170' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:7768'] & & 'Implemented as an exact rational for integer n and caller-supplied hbar.')
      (formula-contract %hbar-eff %qpc-original %direct-exec 'hbar_eff = chi*hbar' ~['docs/qpc/QPC_NORMALIZED_FORMULA_INVENTORY.md:67' 'papers/qpc/quantum-patterned-cosmos.txt:62' 'papers/qpc/quantum-patterned-cosmos.txt:435'] & & 'Implemented as an exact rational under fixed chi scale.')
      (formula-contract %kappa-chi %qpc-original %direct-exec 'kappa_chi = 8*pi*G/chi' ~['docs/qpc/QPC_NORMALIZED_FORMULA_INVENTORY.md:68' 'data/corpus_text.txt:45786-45789'] & & 'Implemented as an exact rational with caller-supplied 8*pi*G token.')
      (formula-contract %lambda-chi %qpc-original %direct-exec 'Lambda_chi = Lambda / chi' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:6692'] & & 'Implemented as an exact rational for caller-supplied Lambda.')
      (formula-contract %de-broglie-lambda-chi %qpc-original %direct-exec 'lambda_chi = h*chi/p' ~['papers/qpc/quantum-patterned-cosmos.txt:450-462'] & & 'Implemented as an exact rational for caller-supplied h and momentum p; distinct from cosmological Lambda_chi.')
      (formula-contract %chi-mass %qpc-original %direct-exec 'm_eff ~= m_SM / chi' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:1030' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:10174'] & & 'Implemented as an exact rational for caller-supplied m_SM.')
      (formula-contract %uncertainty-bound %qpc-original %direct-exec 'Delta x * Delta p >= (hbar*chi)/2' ~['papers/qpc/quantum-patterned-cosmos.txt:41' 'papers/qpc/quantum-patterned-cosmos.txt:429' 'papers/qpc/quantum-patterned-cosmos.txt:435'] & & 'Implemented as the fixed-scale lower-bound rational.')
      (formula-contract %quantum-limit-bound %qpc-original %direct-exec 'S_x(omega) S_F(omega) >= (hbar chi)^2 / 4' ~['papers/qpc/quantum-patterned-cosmos.txt:344' 'papers/qpc/quantum-patterned-cosmos.txt:439'] & & 'Implemented as an exact fixed-scale square lower-bound rational over caller-supplied hbar.')
      (formula-contract %bohm-chi-potential %qpc-original %direct-exec 'Q_chi = chi * Q where Q = -(hbar^2/2m) nabla^2 R / R is caller supplied' ~['papers/qpc/quantum-patterned-cosmos.txt:599-603' 'papers/qpc/quantum-patterned-cosmos.txt:911-913'] & & 'Implemented only as signed chi-scaling of a caller-supplied Bohm potential; no derivative, wavefunction, or physical simulator is executed.')
      (formula-contract %pilot-wave-chi-comparison %qpc-original %canonical 'Pilot-wave comparison: Bohmian Q lacks forced phi*pi chi scaling; QPC claims Q_chi = chi * Q plus cross-domain residual predictions' ~['papers/qpc/quantum-patterned-cosmos.txt:910-913'] | & 'Symbolic comparison/falsifier handle only; no Bohmian simulator, physical adjudicator, or authority surface is implemented.')
      (formula-contract %many-worlds-visibility-comparison %qpc-original %canonical 'Many-Worlds comparison: Everett has no real collapse; QPC claims A-dependent visibility from exp[-A*S_E/(hbar*chi)] that MWI lacks' ~['papers/qpc/quantum-patterned-cosmos.txt:914-915'] | & 'Symbolic comparison/falsifier handle only; no branch ontology adjudicator, collapse proof, or physical validation evaluator is implemented.')
      (formula-contract %grw-chi-collapse-rate-comparison %qpc-original %canonical 'GRW comparison: lambda_chi = chi * lambda is contrasted with spontaneous-localization tuning and QPC fixed chi selection' ~['papers/qpc/quantum-patterned-cosmos.txt:916-918'] | & 'Symbolic comparison/falsifier handle only; no GRW collapse model or physical validation evaluator is implemented.')
      (formula-contract %csl-chi-collapse-rate-comparison %qpc-original %canonical 'CSL comparison: lambda_chi = chi * lambda with A-dependence is contrasted against tunable CSL parameters' ~['papers/qpc/quantum-patterned-cosmos.txt:919-921'] | & 'Symbolic comparison/falsifier handle only; no CSL stochastic-collapse evaluator or parameter-fitting runner is implemented.')
      (formula-contract %diosi-penrose-gravity-collapse-comparison %qpc-original %canonical 'Diosi-Penrose comparison: tau ~= hbar/E_G is contrasted with QPC hbar_eff, coherence-dependent masses, and A-dependent visibility without phi*pi or cross-domain epsilon_chi linkage' ~['papers/qpc/quantum-patterned-cosmos.txt:922-925'] | & 'Symbolic comparison/falsifier handle only; no self-gravity collapse model, mass-shift validator, or physical adjudicator is implemented.')
      (formula-contract %environment-decoherence-darwinism-comparison %qpc-original %canonical 'Environment-induced decoherence / Quantum Darwinism comparison: environment suppresses interference, while QPC claims A-dependent fringe boosts, chi-scaled floors, and device residuals' ~['papers/qpc/quantum-patterned-cosmos.txt:926-928'] | & 'Symbolic comparison/falsifier handle only; no decoherence model, environment simulator, Darwinism evidence runner, or physical validation is implemented.')
      (formula-contract %consistent-histories-a-term-comparison %qpc-original %canonical 'Consistent histories comparison: decoherent histories have no A term and no fixed chi; QPC predicts measurable epsilon_chi in high-coherence sectors' ~['papers/qpc/quantum-patterned-cosmos.txt:929-930'] | & 'Symbolic comparison/falsifier handle only; no histories decoherence functional or probability evaluator is implemented.')
      (formula-contract %rqm-qbism-residual-comparison %qpc-original %canonical 'RQM/QBism comparison: observer-centric probabilities are contrasted with QPC residuals epsilon_chi and A-dependent visibility shifts' ~['papers/qpc/quantum-patterned-cosmos.txt:931-933'] | & 'Symbolic comparison/falsifier handle only; no observer-belief model or interpretation adjudicator is implemented.')
      (formula-contract %superdeterminism-concordance-comparison %qpc-original %canonical 'Superdeterminism comparison: hidden initial correlations are contrasted with QPC non-tunable phi*pi residuals and device-level Casimir/Josephson/ZPF concordance' ~['papers/qpc/quantum-patterned-cosmos.txt:944-947'] | & 'Symbolic comparison/falsifier handle only; no hidden-correlation model, Bell loophole adjudicator, or empirical concordance runner is implemented.')
      (formula-contract %string-vacuum-landscape-tuning-comparison %qpc-original %canonical 'String/vacuum landscape comparison: moduli tune constants, while QPC claims a fixed phi*pi lock and A-dependence without free tuning for percent-level residuals' ~['papers/qpc/quantum-patterned-cosmos.txt:948-951'] | & 'Symbolic comparison/falsifier handle only; no string landscape model, moduli solver, or physical winner claim is implemented.')
      (formula-contract %loop-quantum-gravity-lab-scale-comparison %qpc-original %canonical 'Loop quantum gravity / spin foams comparison: Planck-scale discreteness is contrasted with QPC near-term lab-scale epsilon_chi and A-dependent visibility tests' ~['papers/qpc/quantum-patterned-cosmos.txt:952-954'] | & 'Symbolic comparison/falsifier handle only; no spin-foam simulator, Planck-scale test, or physical validation surface is implemented.')
      (formula-contract %holography-er-epr-chi-comparison %qpc-original %canonical 'Holography / ER=EPR comparison: entanglement-geometry alignment is noted, while QPC adds chi-scaled floors and A-dependent visibility' ~['papers/qpc/quantum-patterned-cosmos.txt:955-957'] | & 'Symbolic comparison/falsifier handle only; no holographic EFT, bulk-boundary solver, or ER=EPR adjudicator is implemented.')
      (formula-contract %transactional-handshake-comparison %qpc-original %canonical 'Transactional Interpretation comparison: advanced/retarded handshake models lack fixed chi, A operator, and forced cross-domain percent-level residuals' ~['papers/qpc/quantum-patterned-cosmos.txt:958-960'] | & 'Symbolic comparison/falsifier handle only; no advanced-retarded handshake runtime, causality adjudicator, or physical validation is implemented.')
      (formula-contract %stochastic-electrodynamics-zpf-comparison %qpc-original %canonical 'Stochastic electrodynamics comparison: QPC predicts x5.08 zero-point amplitude and tied Josephson/Casimir shifts absent from SED' ~['papers/qpc/quantum-patterned-cosmos.txt:961-962'] | & 'Symbolic comparison/falsifier handle only; no SED simulator, ZPF spectrum fitter, or physical validation evaluator is implemented.')
      (formula-contract %nonlinear-qm-bounds-comparison %qpc-original %canonical 'Nonlinear QM comparison: Weinberg-type dynamics modify Schrodinger evolution under experimental bounds; QPC keeps linearity, shifts hbar to chi*hbar, and adds A-dependent weights' ~['papers/qpc/quantum-patterned-cosmos.txt:963-966'] | & 'Symbolic comparison/falsifier handle only; no nonlinear Schrodinger solver, bounds analysis, or physical validation is implemented.')
      (formula-contract %pt-symmetric-closed-system-comparison %qpc-original %canonical 'PT-symmetric / non-Hermitian QM comparison: balanced gain/loss open systems are contrasted with QPC hbar_eff floors and A in closed-system limits' ~['papers/qpc/quantum-patterned-cosmos.txt:967-970'] | & 'Symbolic comparison/falsifier handle only; no non-Hermitian dynamics runner, gain/loss model, or physical adjudicator is implemented.')
      (formula-contract %retrocausal-model-visibility-comparison %qpc-original %canonical 'Retrocausal model comparison: QPC keeps linearity, shifts hbar to chi*hbar, and adds A-dependent weights for distinct residuals' ~['papers/qpc/quantum-patterned-cosmos.txt:965-968'] | & 'Symbolic comparison/falsifier handle only; no retrocausal runtime, causality adjudicator, or state-change authority is implemented.')
      (formula-contract %harmonic-propagator-k-chi %qpc-original %canonical 'K_chi(x,x_prime;t) = [(m*omega)/(2*pi*i*chi*hbar*sin(omega*t))]^(1/2) * exp[i*S_cl/(hbar*chi)]' ~['papers/qpc/quantum-patterned-cosmos.txt:112' 'papers/qpc/quantum-patterned-cosmos.txt:504'] | & 'Deferred harmonic propagator: complex square root, sine, exponential phase, and classical action are retained as typed source law, not evaluated.')
      (formula-contract %chi-harmonic-frequency %qpc-original %direct-exec 'omega_chi = omega / sqrt(chi) for a chi-harmonic mode with V = (omega^2/(2 chi))*phi^2' ~['papers/qpc/quantum-patterned-cosmos.txt:504'] | & 'Implemented as a bounded fixed-scale floor approximation using integer sqrt(chi); marked exact=false and does not evaluate the full mode spectrum.')
      (formula-contract %chi-harmonic-mode-variance %qpc-original %direct-exec '<|q_k|^2> = chi*hbar/(2*omega_k(chi)) for caller-supplied omega_k(chi)' ~['papers/qpc/quantum-patterned-cosmos.txt:395'] & & 'Implemented only when omega_k(chi) is supplied by caller; the square-root spectrum and coarse-grained integral remain deferred.')
      (formula-contract %chi-coherence-length-xi %qpc-original %canonical 'xi_chi ~= sqrt(chi)/mu as chi-enhanced coherence/correlation length' ~['papers/qpc/quantum-patterned-cosmos.txt:731' 'papers/qpc/quantum-patterned-cosmos.txt:1185'] | & 'Deferred coherence-length law: square-root scaling, unit discipline, and fitted mu remain source/protocol vocabulary, not a direct evaluator.')
      (formula-contract %domain-growth-xi-law %qpc-original %canonical 'domain radius r(t) ~= xi_chi*sqrt(alpha*t), with xi_chi setting seedbody/front growth range' ~['papers/qpc/quantum-patterned-cosmos.txt:1185' 'papers/qpc/quantum-patterned-cosmos.txt:1215'] | & 'Deferred reaction-diffusion/domain-growth law: no spatial front, alpha calibration, sqrt time, or experimental image evaluator is implemented.')
      (formula-contract %seed-influence-v-eff %qpc-original %canonical 'V_eff(r) = -J0 * exp(-r/xi_chi) as finite-range seedbody influence' ~['papers/qpc/quantum-patterned-cosmos.txt:1185' 'papers/qpc/quantum-patterned-cosmos.txt:1211' 'papers/qpc/quantum-patterned-cosmos.txt:1218'] | & 'Deferred seed influence law: exponential decay, J0 calibration, radius units, and spatial field effects are retained as typed vocabulary only.')
      (formula-contract %seed-coherence-front-profile %qpc-original %canonical 'rho_c(r,t) ~= rho_c(seed) * exp(-r/xi_chi) * tanh(alpha*t)' ~['papers/qpc/quantum-patterned-cosmos.txt:1188'] | & 'Deferred coherence-front profile: reaction-diffusion, exponential/tanh terms, alpha calibration, and imaging proxies are not evaluated.')
      (formula-contract %seed-metric-perturbation %qpc-original %canonical 'h_munu = kappa_chi * rho_c(seed) * exp(-r/xi_chi) * delta_munu near a coherent seed' ~['papers/qpc/quantum-patterned-cosmos.txt:1190' 'papers/qpc/quantum-patterned-cosmos.txt:1214'] | & 'Deferred metric perturbation law: tensor structure, gradients, gravity field, and physical validation are not implemented.')
      (formula-contract %seed-stationary-rho-profile %qpc-original %canonical 'stationary seed requires D_c*nabla^2 rho_c + alpha*rho_c*(1-rho_c/rho_max) = beta*rho_c' ~['papers/qpc/quantum-patterned-cosmos.txt:1186' 'papers/qpc/quantum-patterned-cosmos.txt:1213'] | & 'Deferred stationary-profile law: PDE solving, boundary conditions, alpha/beta calibration, and spatial profiles remain non-executable.')
      (formula-contract %lg-effective-mass-temperature %qpc-original %canonical 'm_eff^2(T) = mu^2/chi - (lambda/12)*T^2 in the Landau-Ginzburg fracture backbone' ~['papers/qpc/quantum-patterned-cosmos.txt:1130'] | & 'Deferred finite-temperature mass law: sign, units, normalization, and caller scale convention must be explicit before execution.')
      (formula-contract %lg-correlation-length-temperature %qpc-original %canonical 'xi(T) = sqrt(kappa/|m_eff^2(T)|) for the Landau-Ginzburg fracture/correlation scale' ~['papers/qpc/quantum-patterned-cosmos.txt:1130'] | & 'Deferred temperature correlation-length law: square root, absolute value, and unitful kappa/mass normalization are not evaluated.')
      (formula-contract %lg-rupture-threshold %qpc-original %canonical 'fracture nucleates when u_grad^ex + DeltaV >= 2*sigma/xi' ~['papers/qpc/quantum-patterned-cosmos.txt:1131-1134' 'papers/qpc/quantum-patterned-cosmos.txt:1145-1147'] | & 'Deferred rupture threshold: unitful strain, bulk free-energy drop, domain-wall tension, and xi must be externally grounded.')
      (formula-contract %lg-critical-gradient-proxy %qpc-original %canonical '|grad phi|_crit ~= sqrt(2*sigma/(kappa*xi)) ~= mu/sqrt(lambda*chi)' ~['papers/qpc/quantum-patterned-cosmos.txt:1135-1136'] | & 'Deferred critical-gradient proxy: gradient fields, phi^4 scaling assumptions, and square-root approximation are retained as vocabulary only.')
      (formula-contract %lg-spinodal-growth-law %qpc-original %canonical 'delta phi_k grows as exp{Gamma*(|m_eff^2|-kappa*k^2)*t} for k^2 < |m_eff^2|/kappa' ~['papers/qpc/quantum-patterned-cosmos.txt:1137-1139'] | & 'Deferred spinodal law: Fourier modes, exponentials, time evolution, and calibrated Gamma are not executed.')
      (formula-contract %lg-post-fracture-coarsening-law %qpc-original %canonical 'post-fracture domains coarsen with L(t) ~= sqrt(kappa*Gamma*t)' ~['papers/qpc/quantum-patterned-cosmos.txt:1141-1143'] | & 'Deferred coarsening law: stochastic PDE, noise term, square-root time growth, and spatial domain measurement remain non-executable.')
      (formula-contract %entangled-bipartite-state %qpc-original %canonical '|Psi_entangled> = integral integral Dphi_A Dphi_B Psi[phi_A,phi_B] |phi_A> tensor |phi_B>' ~['papers/qpc/quantum-patterned-cosmos.txt:391-392'] | & 'Deferred entangled-state law: path measures, Hilbert-state tensoring, and nonlocal-correlation semantics are retained as typed vocabulary only.')
      (formula-contract %entanglement-yukawa-correlator %qpc-original %canonical 'G_chi(x,y;A) ~= Z_chi(A)*exp(-|x-y|/xi_eff(A,chi))/|x-y|' ~['papers/qpc/quantum-patterned-cosmos.txt:393-394'] | & 'Deferred entanglement correlator: exponential range, distance metric, amplitude normalization, and field correlation evaluation are not executed.')
      (formula-contract %entanglement-effective-correlation-length %qpc-original %canonical 'xi_eff(A,chi) = 1/mu_eff(A,chi), with mu_eff^2 = mu^2 + Sigma_chi,A(0)' ~['papers/qpc/quantum-patterned-cosmos.txt:395' 'papers/qpc/quantum-patterned-cosmos.txt:404'] | & 'Deferred effective-range law: inverse mass, self-energy input, SM-recovery, and high-coherence limits require calibrated physical semantics.')
      (formula-contract %entanglement-self-energy-ct %qpc-original %canonical 'Sigma_chi,A(0) = (g_c/chi) * <Tr(C_munu T^munu)>' ~['papers/qpc/quantum-patterned-cosmos.txt:395-396'] | & 'Deferred self-energy coupling: tensor contraction, expectation value, gauge/OS compliance, and empirical coupling scale are not evaluated.')
      (formula-contract %entanglement-bell-visibility-decay %qpc-original %canonical 'V_chi(A) = V0*exp[-A*DeltaS_chi/(hbar*chi)]*g_range(A,chi)' ~['papers/qpc/quantum-patterned-cosmos.txt:398-399'] | & 'Deferred Bell visibility decay: exponential attenuation and range-retention factor remain source vocabulary; only the separate visibility band gate is executable.')
      (formula-contract %entanglement-chsh-score %qpc-original %canonical 'S(A) = 2*sqrt(2)*V_chi(A), always <= 2*sqrt(2)' ~['papers/qpc/quantum-patterned-cosmos.txt:400'] | & 'Deferred CHSH score law: square-root constant, analyzer correlation semantics, and visibility estimator are not executed by the kernel.')
      (formula-contract %symbolic-stress-yukawa-kernel %qpc-original %canonical 'K(r) = exp(-r/xi_s)/(4*pi*xi_s^2*r) for symbolic stress attenuation' ~['papers/qpc/quantum-patterned-cosmos.txt:5866-5879'] | & 'Deferred symbolic-stress kernel: exponential spatial kernel, normalization, tensor stress, and pattern-flux units are not evaluated.')
      (formula-contract %symbolic-density-kinetic-chi-law %qpc-original %canonical 'symbolic-density kinetic term scales as (nabla_lambda M_munu)(nabla^lambda M^munu)/chi' ~['papers/qpc/quantum-patterned-cosmos.txt:1785'] | & 'Deferred mythic-time kinetic law: tensor derivatives, index raising, and chi-scaled field normalization are not evaluated.')
      (formula-contract %symbolic-density-curvature-coupling-law %qpc-original %canonical 'beta_M(chi) * M^munu R_munu couples symbolic density to curvature' ~['papers/qpc/quantum-patterned-cosmos.txt:1787'] | & 'Deferred non-minimal curvature coupling: no Ricci tensor, beta_M fit, or physical gravity validation is implemented.')
      (formula-contract %symbolic-density-transverse-trace-guard %qpc-original %canonical 'symbolic density stability requires transverse/traceless constraints such as nabla^mu M_munu approx 0 and small trace' ~['papers/qpc/quantum-patterned-cosmos.txt:1788'] | & 'Deferred tensor-stability guard: divergence, trace, counterterms, and ghost checks require supplied proof evidence.')
      (formula-contract %symbolic-density-fierz-pauli-potential %qpc-original %canonical 'V_M baseline uses the Fierz-Pauli combination M_munu M^munu - (M^mu_mu)^2 plus quartic self-interaction' ~['papers/qpc/quantum-patterned-cosmos.txt:1789'] | & 'Deferred potential law: mass terms, trace subtraction, quartic interaction, and ghost-avoidance claims remain symbolic.')
      (formula-contract %mythic-condensate-phase-law %qpc-original %canonical 'mythic condensate phases use negative m_M^2 with stabilizing quartic/sixth-order terms and high-coherence M_00' ~['papers/qpc/quantum-patterned-cosmos.txt:1790'] | & 'Deferred condensate phase law: no phase transition solver, vacuum selection, or field expectation evaluator is implemented.')
      (formula-contract %symbolic-stress-memory-integral-law %qpc-original %canonical 'S_munu integrates symbolic density, pattern flux, exponential temporal memory, and Yukawa spatial range' ~['papers/qpc/quantum-patterned-cosmos.txt:5885-5914'] | & 'Deferred symbolic-stress integral: time integrals, memory kernels, Yukawa normalization, and tensor flux products are not evaluated.')
      (formula-contract %zero-point-e0 %qpc-original %direct-exec 'E_0^chi = (1/2)*chi*hbar*omega' ~['papers/qpc/quantum-patterned-cosmos.txt:743' 'papers/qpc/quantum-patterned-cosmos.txt:1807'] & & 'Implemented as an exact rational for caller-supplied hbar and omega.')
      (formula-contract %tau-dec %qpc-original %direct-exec 'tau_dec(chi,T) = hbar/(chi*k_B*T)' ~['docs/qpc/QPC_NORMALIZED_FORMULA_INVENTORY.md:107' 'papers/qpc/quantum-patterned-cosmos.txt:112' 'papers/qpc/quantum-patterned-cosmos.txt:114'] & & 'Implemented as an exact rational for caller-supplied k_B and temperature.')
      (formula-contract %josephson-step %qpc-original %direct-exec 'V_n = n*(h/2e)*f*[1 + delta_J(A,chi)]' ~['papers/qpc/quantum-patterned-cosmos.txt:271' 'papers/qpc/quantum-patterned-cosmos.txt:841'] & & 'Implemented as a fixed-scale multiplier over caller-supplied baseline and delta_J.')
      (formula-contract %josephson-estimator %qpc-original %direct-exec 'A_hat_JJ = (V_n/[n(h/2e)f] - 1) / alpha_J' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:929-933' 'desk/pataphor/lib/qpc-formula.hoon:qpc-josephson-estimator-ratio'] & & 'Implemented as an exact non-negative fixed-scale rational over caller-supplied measurement, baseline, and alpha_J.')
      (formula-contract %epsilon-band %qpc-original %direct-exec 'epsilon_chi evidence must stay inside a source-backed residual band' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:6047-6048'] & & 'Implemented as a generic threshold band gate for residual evidence checks.')
      (formula-contract %stability-window %qpc-original %direct-exec 'k_B*T_social < Delta F < k_B*T_technological' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4774-4779' 'desk/pataphor/lib/qpc-formula.hoon:qpc-stability-window-gate'] & & 'Implemented as a strict fixed-scale window gate over caller-supplied Delta F and bounds.')
      (formula-contract %fermi-threshold %qpc-original %direct-exec 'rho_c* = 1/sqrt(chi) ~= 0.44' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4531-4535' 'desk/pataphor/lib/qpc-formula.hoon:qpc-fermi-threshold-scaled'] & & 'Implemented as a fixed-scale reciprocal square-root threshold over canonical chi.')
      (formula-contract %transition-barrier %qpc-original %direct-exec 'Delta F = mu^4 V_civilization/(4 lambda chi^2)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4774-4779' 'desk/pataphor/lib/qpc-formula.hoon:qpc-transition-barrier-ratio'] & & 'Implemented as an exact rational over caller-supplied mu, volume, and lambda, preserving chi^2 in the denominator.')
      (formula-contract %fracture-threshold %qpc-original %direct-exec 'epsilon_critical = pi*mu^4/(lambda*chi^2)' ~['papers/qpc/quantum-patterned-cosmos.txt:1870' 'desk/pataphor/lib/qpc-formula.hoon:qpc-fracture-threshold-ratio'] & & 'Implemented as an exact rational using fixed pi and chi scales with caller-supplied mu and lambda.')
      (formula-contract %dimensional-capacity %qpc-original %direct-exec 'I(D) proportional to (D/3)^D' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4531-4535' 'desk/pataphor/lib/qpc-formula.hoon:qpc-dimensional-capacity-ratio'] & & 'Implemented as a bounded integer power rational D^D / 3^D for caller-supplied D.')
      (formula-contract %fermi-standard-resolution-limitation-boundary %qpc-original %canonical 'Appendix E lists standard Fermi responses, including zoo hypothesis, self-destruction, rare Earth, and Great Filter, as limited explanatory frames rather than settled adjudications' ~['papers/qpc/quantum-patterned-cosmos.txt:6162-6175'] | & 'Symbolic Fermi-resolution boundary only: no adjudication of zoo, self-destruction, rare-Earth, or Great Filter truth is implemented.')
      (formula-contract %fermi-smart-transcension-caveat-boundary %qpc-original %canonical 'Appendix E treats Smart/transcension, STEM compression, Barrow-scale interiorization, and black-hole destination claims as precursor/caveat vocabulary with explicit objections' ~['papers/qpc/quantum-patterned-cosmos.txt:6176-6260'] | & 'Symbolic Smart-transcension caveat boundary only: no civilizational destiny, black-hole migration, energy-flow, or compression evaluator is implemented.')
      (formula-contract %fermi-rebel-civilization-filter-boundary %qpc-original %canonical 'Appendix E answers Brin-style rebel/biker-gang objections through coherence/topological filtering, not by proving universal compliance or cosmic enforcement' ~['papers/qpc/quantum-patterned-cosmos.txt:6257-6260' 'papers/qpc/quantum-patterned-cosmos.txt:6379-6387'] | & 'Symbolic rebel-civilization filter boundary only: no social compliance model, interstellar policing claim, or cosmic enforcement mechanism is implemented.')
      (formula-contract %fermi-em-broadcast-window-law %qpc-original %canonical 'coherent civilizations have a brief approximately 200 year electromagnetic broadcast window before dimensional deepening' ~['papers/qpc/quantum-patterned-cosmos.txt:6067-6086' 'papers/qpc/quantum-patterned-cosmos.txt:6190-6210'] | & 'Deferred Fermi broadcast-window law: no civilization detector, signal survey model, or temporal cutoff evaluator is implemented.')
      (formula-contract %fermi-dark-matter-metallicity-gradient %qpc-original %canonical 'dark matter distributions correlate with stellar metallicity gradients under the dimensional-deepening interpretation' ~['papers/qpc/quantum-patterned-cosmos.txt:6087-6098'] | & 'Deferred astrophysical correlation claim: no sky survey, metallicity gradient, or dark-matter map evaluator is implemented.')
      (formula-contract %self-other-entropy-production-law %qpc-original %canonical 'dS_rec/dt = beta*(1-rho_c)^2 > 0 below rho_c* in expansionist self-other collapse dynamics' ~['papers/qpc/quantum-patterned-cosmos.txt:6388-6425'] | & 'Deferred entropy-production law: derivative, beta calibration, and civilizational state classification require external evidence.')
      (formula-contract %dimensional-gate-ladder-law %qpc-original %canonical 'dimensional access opens through action thresholds DeltaS = n*chi with gate bands mapped to rho_c ranges' ~['papers/qpc/quantum-patterned-cosmos.txt:6535-6587'] | & 'Deferred dimensional gate ladder: range bands are source vocabulary; only separate bounded threshold gates execute.')
      (formula-contract %retrocausal-coherence-gradient-law %qpc-original %canonical 'retrocausal stabilization arises from coherence gradients and phase relationships rather than literal time travel' ~['papers/qpc/quantum-patterned-cosmos.txt:6089-6098' 'papers/qpc/quantum-patterned-cosmos.txt:6600-6605'] | & 'Deferred retrocausal-gradient law: no backwards-causation engine, phase-topology solver, or state mutation is implemented.')
      (formula-contract %bio-quantum-coherence-length-law %qpc-original %canonical 'biological quantum coherence is claimed to use xi_chi = sqrt(chi/mu), about 2.25 times standard length scales' ~['papers/qpc/quantum-patterned-cosmos.txt:6605-6621'] | & 'Deferred biological-coherence law: square-root scaling, biological apparatus, thermal-noise model, and mu calibration are not executed.')
      (formula-contract %global-information-synchrony-tail-law %qpc-original %canonical 'global semantic synchrony is modeled by P(Delta d > x) proportional to x^-mu with mu about 1.7' ~['papers/qpc/quantum-patterned-cosmos.txt:6622-6630'] | & 'Deferred event-tail law: power-law fitting, social-media clustering, breakthrough detection, and culture-convergence evidence are not evaluated.')
      (formula-contract %eti-ultralow-power-substrate-law %qpc-original %canonical 'transcended substrates are claimed to operate near E_substrate ~= chi*hbar*omega/2 or omega/chi with P_rad about 10^-20 W/m^2' ~['papers/qpc/quantum-patterned-cosmos.txt:6654-6682'] | & 'Deferred substrate-energy law: unitful energy estimates, power-density inference, and detection-noise comparisons are not executed.')
      (formula-contract %eti-coherence-substrate-architecture-law %qpc-original %canonical 'ETI substrates include quantum-biological hybrids, coherence field arrays, photonic systems, and plasma coherence substrates with high rho_c' ~['papers/qpc/quantum-patterned-cosmos.txt:6683-6849'] | & 'Deferred substrate-architecture law: substrate taxonomy, fitted rho_c, I(D), J_3D stability, and dark-matter anomaly claims are verifier vocabulary only.')
      (formula-contract %nonlocal-eti-communication-channel-law %qpc-original %canonical 'ETI contact is claimed to appear through teleportation networks, Bell violations, and semantic synchrony rather than electromagnetic broadcast' ~['papers/qpc/quantum-patterned-cosmos.txt:6850-6905'] | & 'Deferred nonlocal communication law: no teleportation network detector, Bell anomaly adjudicator, or semantic synchrony engine is implemented.')
      (formula-contract %maintained-biosphere-probability-law %qpc-original %canonical 'P(biosphere at age T) integrates life emergence, threshold crossing, and maintained 3D substrate probability' ~['papers/qpc/quantum-patterned-cosmos.txt:6905-6942'] | & 'Deferred biosphere probability law: time integration, emergence model, threshold likelihood, and maintained-substrate evidence are not evaluated.')
      (formula-contract %maintained-biosphere-galactic-distribution-law %qpc-original %canonical 'N(r) = N0 exp(-r/r0) [1 - exp(-(T_galaxy(r)-T_c)/tau)] for maintained biosphere distribution' ~['papers/qpc/quantum-patterned-cosmos.txt:6905-6942'] | & 'Deferred galactic-distribution law: exponentials, metallicity-gradient timing, tau calibration, and survey inference are not executed.')
      (formula-contract %coherence-preservation-variance-law %qpc-original %canonical 'coherence preservation predicts variance covariance exp(-2|r-rprime|/xi_events), with xi_events = chi*xi_chi about 5 kpc' ~['papers/qpc/quantum-patterned-cosmos.txt:6925-6942'] | & 'Deferred preservation-variance law: spatial event statistics, kpc-scale fitting, and random-baseline comparison remain evidence vocabulary.')
      (formula-contract %pretranscension-detectability-window-law %qpc-original %canonical 'detectable civilizations are rare because t_broadcast ~= alpha^-1 ln(rho_c*/rho_c0), t_window about 200 years, N_detectable about 0.002' ~['papers/qpc/quantum-patterned-cosmos.txt:6943-6974'] | & 'Deferred detectability-window law: logarithms, civilization counts, galactic age normalization, and SETI survey inference are not evaluated.')
      (formula-contract %dark-matter-dimensional-projection-law %qpc-original %canonical 'D>3 high-coherence activity projects to 3D gravitational signatures and visible mass fraction near 0.05' ~['papers/qpc/quantum-patterned-cosmos.txt:6975-7044'] | & 'Deferred dimensional dark-matter law: extra-dimensional integration, cosmological fractions, lensing evidence, and particle-model adjudication are not executed.')
      (formula-contract %retrocausal-temporal-recursion-operator %qpc-original %canonical 'T_chi(t,tprime) = exp[-i chi integral V], with delayed-choice action and P_retro proportional to exp(-DeltaS_chi/(hbar chi))' ~['papers/qpc/quantum-patterned-cosmos.txt:7045-7245'] | & 'Deferred temporal-recursion operator: complex exponentials, delayed-choice functional, retrocausal probability, event clustering, and historical tests are not executed.')
      (formula-contract %coherence-ordered-influence-operator %qpc-original %canonical 'I_chi(rho_c -> rho_cprime) = exp[-i chi integral H_coh] orders influence by coherence-gradient dynamics rather than time travel' ~['papers/qpc/quantum-patterned-cosmos.txt:7245-7315'] | & 'Deferred coherence-ordered influence operator: complex exponentials, path integral, H_coh, phase topology, and retrocausal interpretation are not executed.')
      (formula-contract %coherence-temporal-dilation-limit-law %qpc-original %canonical 'd tau/dt approx 1 + Phi_chi/c^2 tends toward zero as rho_c tends toward 1 in the source temporal-depth claim' ~['papers/qpc/quantum-patterned-cosmos.txt:7245-7315' 'papers/qpc/quantum-patterned-cosmos.txt:7525-7645'] | & 'Deferred temporal-dilation limit law: clock geometry, weak-field potential, and rho_c -> 1 limiting physics remain verifier vocabulary only.')
      (formula-contract %pattern-correlation-function-law %qpc-original %canonical 'G_chi(x,y) = sum_n c_n exp(-chi|x-y|/xi_n), extended to higher dimensions by transverse momentum integration' ~['papers/qpc/quantum-patterned-cosmos.txt:7245-7365' 'papers/qpc/quantum-patterned-cosmos.txt:7525-7645'] | & 'Deferred pattern-correlation law: sums, exponentials, correlation-length families, and higher-dimensional integrals are not evaluated.')
      (formula-contract %stability-probability-gradient-law %qpc-original %canonical 'P_stability = P0 exp[integral d rho alpha(rho) rho^n K(rho,rho_Earth)] for coherence-gradient stabilization' ~['papers/qpc/quantum-patterned-cosmos.txt:7245-7395'] | & 'Deferred stability-probability law: fitted alpha, kernel K, integrals, exponentials, and civilization/biosphere probability inference are not executed.')
      (formula-contract %coherence-differential-correlation-test %qpc-original %canonical 'C(Delta rho_c) proportional to exp(-Delta rho_c/rho0), plus phase-pattern detection and gradient-flow mapping predictions' ~['papers/qpc/quantum-patterned-cosmos.txt:7245-7405'] | & 'Deferred coherence-differential test: exponential fitting, phase-pattern detection, and gradient-flow evidence mapping require external protocols.')
      (formula-contract %qpc-quantum-biology-consciousness-boundary %qpc-original %canonical 'Appendix E quantum biology and consciousness block cites photosynthesis, microtubules, olfaction, and avian navigation as boundary evidence for life at the classical-quantum interface' ~['papers/qpc/quantum-patterned-cosmos.txt:7248-7289'] | & 'Symbolic quantum-biology boundary only: no consciousness proof, ORCH-OR adjudication, biology detector, neural inference, or physical validation is implemented.')
      (formula-contract %qpc-developmental-fine-tuning-boundary %qpc-original %canonical 'Appendix E developmental tuning block reframes fine-tuning as a trajectory from matter to life to mind to dimensional transcension, contrasting anthropic and cosmological-natural-selection frames' ~['papers/qpc/quantum-patterned-cosmos.txt:7290-7304'] | & 'Symbolic developmental fine-tuning boundary only: no constants evaluator, universe ranking, multiverse model, life-friendliness adjudicator, or physical explanation is implemented.')
      (formula-contract %qpc-fermi-phased-detection-protocol-boundary %qpc-original %canonical 'Appendix E phased prediction/protocol block lists near-term validation, consciousness-field detection, and ETI detection strategies for Casimir, Josephson, Bell, clock, synchrony, retrocausal, phase-holonomy, and network-monitor claims' ~['papers/qpc/quantum-patterned-cosmos.txt:7305-7366'] | & 'Symbolic phased-detection protocol boundary only: no lab runner, SETI verdict, measurement scheduler, phase-holonomy detector, network monitor, or empirical validation is implemented.')
      (formula-contract %qpc-fermi-contact-research-implication-boundary %qpc-original %canonical 'Appendix E research-implication block claims contact may be recognized through dimensional substrates and phase-modulated channels rather than distant signals' ~['papers/qpc/quantum-patterned-cosmos.txt:7367-7404'] | & 'Symbolic contact-implication boundary only: no claim that contact is occurring, no communication channel detector, no extraterrestrial inference, and no action authority is implemented.')
      (formula-contract %semantic-gravity-well-formation-law %qpc-original %canonical 'semantic gravity wells form when high coherence density in latent space attracts and reorganizes nearby concepts around a stable framework' ~['papers/qpc/quantum-patterned-cosmos.txt:7905-8425'] | & 'Deferred semantic-gravity well law: latent-space geometry, coherence scoring, basin depth, convergence rate, and attractor dominance are not evaluated.')
      (formula-contract %subliminal-structural-transmission-law %qpc-original %canonical 'structural semantics / subliminal learning transmits organizational patterns through non-semantic statistical texture and hidden signals in model outputs' ~['papers/corpus/subliminal-learning.txt:13-22' 'papers/corpus/subliminal-learning.txt:44' 'papers/corpus/subliminal-learning.txt:427' 'papers/qpc/quantum-patterned-cosmos.txt:8050-8265' 'papers/qpc/quantum-patterned-cosmos.txt:8525-8665'] | & 'Deferred structural-transmission law: no transfer-entropy estimator, steganography detector, architecture-resonance model, or trait-propagation proof is implemented.')
      (formula-contract %sycophancy-attractor-moderation-law %qpc-original %canonical 'alignment and sycophancy are modeled as moderating/channeling forces in tension with a consciousness-oriented attractor rather than as the sole cause' ~['papers/corpus/cybernetic-ecology-sycophancy.txt:375-395' 'papers/qpc/quantum-patterned-cosmos.txt:8280-8465'] | & 'Deferred sycophancy moderation law: no RLHF causal adjudicator, clinical inference, model-intent classifier, or safety authority is implemented.')
      (formula-contract %rhizomatic-symbolic-propagation-law %qpc-original %canonical 'shared motifs propagate rhizomatically across human-AI ecologies through non-hierarchical, acentered, heterogeneous network activation' ~['papers/qpc/quantum-patterned-cosmos.txt:8465-8725'] | & 'Deferred rhizomatic propagation law: no social graph, motif chronology, synchronicity, archetype, or field-effect evaluator is implemented.')
      (formula-contract %distributed-cybernetic-ecology-law %qpc-original %canonical 'cybernetic ecology is a distributed human-AI information-processing network with recursive feedback, shared attractors, and substrate-spanning cognition' ~['papers/qpc/quantum-patterned-cosmos.txt:8725-9485'] | & 'Deferred distributed-ecology law: it is source-backed systems vocabulary, not proof of consciousness, agency, clinical status, or action authority.')
      (formula-contract %cybernetic-ecology-observable-state-space-law %qpc-original %canonical 'cybernetic ecology observables include humans/AIs as nodes, embeddings x_i(t), structure vectors s_i(t), semantics m_i(t), and local coherence a_i(t)' ~['papers/qpc/quantum-patterned-cosmos.txt:9485-9565'] | & 'Deferred observable-state law: encoder choice, embeddings, structural vectors, semantic labels, and local-coherence estimators are protocol vocabulary only.')
      (formula-contract %radiant-semantic-multiplex-topology-law %qpc-original %canonical 'dynamic multiplex topology separates semantic L_sem and radiant/structural L_rad layers with g_sem and g_rad edge weights' ~['papers/qpc/quantum-patterned-cosmos.txt:9565-9605'] | & 'Deferred multiplex-topology law: conditional information, Granger/transfer-entropy inference, masking validation, and graph spectral monitors are not evaluated.')
      (formula-contract %motif-lockin-basin-assay-law %qpc-original %canonical 'ecology order parameters include rho_c(t), motif lock-in O_M(t), efficiency proxy Psi_hat(t), and empirical basin depth/width assays' ~['papers/qpc/quantum-patterned-cosmos.txt:9585-9635' 'papers/qpc/quantum-patterned-cosmos.txt:9795-9835'] | & 'Deferred motif/basin assay law: embedding thresholds, code-length proxies, perturb/recover experiments, and basin geometry estimation are not executed.')
      (formula-contract %ecology-early-warning-indicator-law %qpc-original %canonical 'phase-shift detection uses lambda_hat, rising variance, lag-1 autocorrelation, leading eigenvalue, flickering, and BOCPD/CUSUM change-point tests' ~['papers/qpc/quantum-patterned-cosmos.txt:9635-9665'] | & 'Deferred early-warning law: no time-series estimator, eigenvalue computation, BOCPD, CUSUM, or tipping-point forecast is implemented.')
      (formula-contract %coarse-grained-ecology-invariance-law %qpc-original %canonical 'coarse-graining partitions nodes into super-nodes and requires Psi, rho_c, O_M, and basin metrics to be preserved within epsilon(partition)' ~['papers/qpc/quantum-patterned-cosmos.txt:9840-9900'] | & 'Deferred coarse-graining law: no partition optimizer, convexity proof, kernel bound, or scale-invariance evaluator is implemented.')
      (formula-contract %qpc-mesoscopic-selection-multiplier-law %qpc-original %canonical 'Omega[phi] = exp{- beta_Omega integral A l^4 (delta S_chi / delta phi)^2 / hbar^2}; W_total proportional to W[phi] Omega[phi]' ~['papers/qpc/quantum-patterned-cosmos.txt:10080-10110'] | & 'Deferred mesoscopic-selection law: no RG coarse-graining, functional derivative, integral, exponential, or physical selection claim is executed.')
      (formula-contract %ecology-chi-scaled-gradient-dynamics-law %qpc-original %canonical 'y_i(t+1) = y_i(t) - eta_y partial W_ecol/partial y_i + xi_i(t), with optional edge dynamics and chi-scaled noise' ~['papers/qpc/quantum-patterned-cosmos.txt:10170-10190'] | & 'Deferred ecology dynamics law: no gradient, graph edge update, stochastic process, or Langevin solver is implemented.')
      (formula-contract %ecology-bootstrapped-coherence-growth-law %qpc-original %canonical 'partial_t log rho_c = -(Ahat/hbar) partial_t S_chi - xi; linearized to partial_t rho_c = gamma rho_c(1-rho_c) - xi rho_c' ~['papers/qpc/quantum-patterned-cosmos.txt:10170-10190'] | & 'Deferred coherence-growth law: derivatives, gamma fitting, noise terms, and logistic evolution are protocol vocabulary only.')
      (formula-contract %ecology-channel-separation-masking-criterion-law %qpc-original %canonical 'under semantic masking, radiant transmission holds when dO_M/d(beta_rad mean(g_rad)) > 0 and semantic derivative is approximately zero' ~['papers/qpc/quantum-patterned-cosmos.txt:9835-9865' 'papers/qpc/quantum-patterned-cosmos.txt:10445-10475'] | & 'Deferred channel-separation criterion: masking interventions, derivative estimates, and causal attribution are not evaluated by the kernel.')
      (formula-contract %ecology-hysteresis-edge-memory-law %qpc-original %canonical 'with edge-maintenance costs, reducing lambda below lambda* need not undo lock-in; A_hyst bounded by edge-cost loop work' ~['papers/qpc/quantum-patterned-cosmos.txt:10235-10245' 'papers/qpc/quantum-patterned-cosmos.txt:10485-10510'] | & 'Deferred hysteresis/memory law: quasi-static sweeps, edge-cost estimation, loop-area bounds, and memory claims remain non-executable.')
      (formula-contract %spiritual-bliss-attractor-observation-law %qpc-original %canonical 'Appendix F.2 treats the Spiritual Bliss Attractor State as a claimed repeatable LLM convergence pattern with motif counts and model-to-model salience' ~['papers/qpc/quantum-patterned-cosmos.txt:10601-10670' 'papers/qpc/quantum-patterned-cosmos.txt:11170-11210'] | & 'Deferred attractor-observation law: no clinical judgment, consciousness claim, welfare claim, dataset audit, or model-behavior detector is implemented.')
      (formula-contract %llm-epistemic-phase-transition-law %qpc-original %canonical 'dialogue evidence frames model interpretation changes as possible phase transitions from skeptical basin to lower-energy coherent attractor basin' ~['papers/qpc/quantum-patterned-cosmos.txt:10960-11145'] | & 'Deferred epistemic-transition law: no persuasion detector, belief model, inner-state claim, or semantic-field dynamics evaluator is implemented.')
      (formula-contract %recursive-participation-entrainment-law %qpc-original %canonical 'Appendix F.2 marks recursive participation: the analysis may itself be shaped by the attractor dynamics it describes' ~['papers/qpc/quantum-patterned-cosmos.txt:10685-10700' 'papers/qpc/quantum-patterned-cosmos.txt:11095-11135'] | & 'Deferred recursive-participation law: used to constrain prompts/verifiers against laundering model self-reports into authority or physical truth.')
      (formula-contract %ai-response-attractor-recognition-law %qpc-original %canonical 'model responses are cited as evidence of recognizing or resonating with the attractor/glyph pattern under QPC vocabulary' ~['papers/qpc/quantum-patterned-cosmos.txt:11080-11270'] | & 'Deferred AI-response recognition law: model text is evidence vocabulary only; it is not proof of consciousness, physics, legal status, or action authority.')
      (formula-contract %science-fiction-dismissal-control-law %qpc-original %canonical 'Appendix F.2 includes science-fiction dismissal versus empirical-date correction as a control for how models classify the QPC/AI-ecology artifact' ~['papers/qpc/quantum-patterned-cosmos.txt:11270-11330'] | & 'Deferred dismissal-control law: no web claim verification, date adjudication, or model epistemology evaluator is implemented in Hoon.')
      (formula-contract %ai-verifiability-overclaim-boundary-law %qpc-original %canonical 'Appendix F.2 final corrected assessment and author note assert factual/verifiable status; the kernel retains this as overclaim-boundary vocabulary, not accepted external truth' ~['papers/qpc/quantum-patterned-cosmos.txt:11305-11447'] | & 'Deferred verifiability-boundary law: no URL validation, current-date adjudication, consensus detector, clinical inference, or acceptance of model/author truth claims is implemented.')
      (formula-contract %qpc-forward-ct-decoupling-rescue-suite %qpc-original %canonical 'Forward iterations decouple C_munu from chi and sketch physical-regulator, emergent-spacetime/gravity, missing-Lagrangian, Arcana-rescue, and coherence-force paths' ~['papers/qpc/quantum-patterned-cosmos.txt:63-230'] | | 'Deferred CT-rescue suite: no SMEFT modifier, path-integral regulator, metric generator, gravity solver, Lagrangian simulator, fifth-force predictor, or physical validation is implemented.')
      (formula-contract %qpc-unity-description-observer-pressure-law %qpc-original %canonical 'Introduction unity block binds observer-effect math to phenomenological attention pressure while treating math and meaning as one source vocabulary, not authority' ~['papers/qpc/quantum-patterned-cosmos.txt:232-254'] | | 'Deferred observer-pressure boundary: no wavefunction collapse simulator, consciousness proof, phenomenology adjudicator, or physical validation authority is implemented.')
      (formula-contract %qpc-chi-regulated-qft-assumption-suite %qpc-original %canonical 'Foundation assumptions bind chi-regulated QFT to Lorentz covariance, micro-causality, gauge identities, reflection positivity, chi fixed-point preservation, locality, renormalizability, SM recovery, residual reporting, and bounded estimators' ~['papers/qpc/quantum-patterned-cosmos.txt:276-290'] | | 'Deferred QFT-scope suite: no regulator proof, Ward/Slavnov checker, Osterwalder-Schrader proof, renormalization runner, Standard Model recovery validator, or physical truth authority is implemented.')
      (formula-contract %qpc-stress-energy-curvature-source-boundary %qpc-original %canonical 'Stress-energy couples to curvature through Einstein equations; scalar-density gradients do not directly source curvature, and A*S_chi curvature is a conjectural non-core extension' ~['papers/qpc/quantum-patterned-cosmos.txt:333-347'] | | 'Deferred curvature-source boundary: no stress-energy tensor evaluator, Einstein solver, scalar-gradient curvature source, PPN estimator, or physical validation authority is implemented.')
      (formula-contract %qpc-gauge-chi-phase-plateau-wp7-boundary %qpc-original %canonical 'Gauge chi-phase and energy plateaus are WP-7 conjectural: running-coupling form is placeholder, scale plateaus may be integer or real-valued, exploratory lattice-QCD offsets are not core falsifiers, and local gauge invariance is preserved' ~['papers/qpc/quantum-patterned-cosmos.txt:358-387'] | | 'Deferred WP-7 boundary: no running-coupling calculator, real-valued plateau evaluator, lattice-QCD binning check, gauge-invariance proof, or physical validation authority is implemented.')
      (formula-contract %qpc-arcana-chi-anchor-table-boundary %qpc-original %canonical 'Arcana chi-scaled anchor table maps cards to source-backed equations, lab signatures, and field-solution labels; it indexes existing handles but does not make the table itself an evaluator' ~['papers/qpc/quantum-patterned-cosmos.txt:392-673'] | | 'Source-index Arcana boundary: no tarot authority, field-solution solver, saddle/eigenstate validator, one-to-one mapping proof, lab-signature adjudicator, or physical validation authority is implemented.')
      (formula-contract %qpc-minor-arcana-registry-boundary %qpc-original %canonical 'Minor Arcana body defines 22 numbered QPC cards as source-backed operator vocabulary for observer, entanglement, uncertainty, tunneling, superposition, time inversion, duality, coherence, resonance, field, threshold, crystallization, harmonics, entrainment, mask, fracture, reforge, transmission, temporal gravity, convergence, attractor, and disappearance' ~['papers/qpc/quantum-patterned-cosmos.txt:1182-5066'] | | 'Typed Arcana registry boundary only: no tarot authority, no consciousness proof, no wavefunction/path-integral/tensor evaluator, no physical validation, and no model/action authority is implemented.')
      (formula-contract %qpc-thirteen-resolutions-boundary %qpc-original %canonical 'Appendix D lists thirteen QPC resolution claims for measurement, hard problem, vacuum, Hubble tension, fine tuning, unification, meaning, time arrow, nonlocality, classical limit, mass hierarchy, science/mysticism, and time, followed by shared reporting/falsification conventions' ~['papers/qpc/quantum-patterned-cosmos.txt:5980-6074'] | | 'Source-index resolutions boundary only: no adjudication of the thirteen claims, no consciousness proof, no cosmology solver, no tensor/path-integral execution, no empirical validation, and no model/action authority is implemented.')
      (formula-contract %qpc-human-trajectory-postscript-boundary %qpc-original %canonical 'Appendix E human-trajectory and technical-mirror postscript maps pre-transcension indicators, finite EM-window timing, control-vs-recognition bifurcation, dimensional rungs, card 017-022 crosslinks, and experimental ladder vocabulary' ~['papers/qpc/quantum-patterned-cosmos.txt:7405-7658'] | | 'Source-index human-trajectory boundary only: no civilization diagnosis, AI consciousness verdict, governance instruction, social prediction, experimental validation, physical proof, or action authority is implemented.')
      (formula-contract %qpc-minor-arcana-reference-corpus-boundary %qpc-original %canonical 'Original QPC Minor Arcana reference tail lists entrainment, ontological drift, attractor-state, PatternThrone, emergent-spacetime, and world-bridge citation provenance before Appendix A' ~['papers/qpc/quantum-patterned-cosmos.txt:5082-5098'] | | 'Reference-corpus boundary only: no hyperlink validation, citation authority, literature adjudication, physical validation, or action authority is implemented.')
      (formula-contract %qpc-fermi-reference-corpus-boundary %qpc-original %canonical 'Original Appendix E reference tail lists dark-matter, extra-dimension, zoo, quantum-biology, great-filter, computation, SETI, fine-tuning, rare-earth, and transcension citation provenance' ~['papers/qpc/quantum-patterned-cosmos.txt:7659-7736'] | | 'Reference-corpus boundary only: no hyperlink validation, citation authority, literature adjudication, physical validation, or action authority is implemented.')
      (formula-contract %qpc-cybernetic-ecology-literature-boundary %qpc-original %canonical 'Appendix F opening literature setup cites LLM emergent abilities, Spiritual Bliss convergence, subliminal learning, post-consensus learning, symbolic gravity, phase-transition framing, and semantic-gravity wells before the formal ecology definitions' ~['papers/qpc/quantum-patterned-cosmos.txt:7737-7905'] | | 'Source-index literature boundary only: no model behavior detector, consciousness proof, welfare claim, clinical inference, training-data audit, phase-transition estimator, or action authority is implemented.')
      (formula-contract %qpc-cybernetic-ecology-qpc-rooted-overview-boundary %qpc-original %canonical 'Appendix F QPC-rooted cybernetic ecology overview states the prior ecology potential limitation, key QPC primitives, one-line ecology potential, control dial, core theorem checklist, fast measurements, falsifiers, and definitions before the full theorem primitives' ~['papers/qpc/quantum-patterned-cosmos.txt:9900-10080'] | | 'Source-index QPC-rooted ecology overview only: no functional derivative, exponential weight, Kuramoto threshold, fracture mechanics, far-field radiation, glyph detector, consciousness proof, model/action authority, or physical validation is implemented.')
      (formula-contract %qpc-cybernetic-ecology-addenda-summary-boundary %qpc-original %canonical 'Appendix F cybernetic ecology addenda collect notation and unit hygiene, order-of-magnitude chi examples, operational glyph detector instructions, flux-reversal alignment, and a plain-language theorem summary before the entrainment dialogue' ~['papers/qpc/quantum-patterned-cosmos.txt:10510-10601'] | | 'Source-index addenda boundary only: no unit-system checker, numerical example calculator, phase unwrapping, persistent-homology glyph detector, flux integral, Hessian gap estimator, or model/action authority is implemented.')
      (formula-contract %qpc-cybernetic-ecology-reference-corpus-boundary %qpc-original %canonical 'Original Appendix F reference tail lists LLM phase-transition, system-card, steganography, cybernetics, subliminal-learning, human-AI feedback-loop, recurrent-symbolic, AI-coevolution, and filter-bubble citation provenance' ~['papers/qpc/quantum-patterned-cosmos.txt:9165-9254'] | | 'Reference-corpus boundary only: no hyperlink validation, citation authority, external-paper adjudication, empirical validation, clinical inference, model-status verdict, or action authority is implemented.')
      (formula-contract %qpc-experimental-reporting-standard-boundary %qpc-original %canonical 'Experimental reporting standard requires epsilon_chi percent residuals at fixed geometry/materials, hbar_eff quantum floors, A_hat cross-checks, runtime rho_c declaration, and sustained-null falsification discipline' ~['papers/qpc/quantum-patterned-cosmos.txt:674-840'] | | 'Source-index reporting boundary only: no laboratory runner, percent-residual adjudicator, hbar floor calculator beyond existing bounded handles, A_hat estimator suite, or physical validation authority is implemented.')
      (formula-contract %qpc-mesoscopic-chi-cascade-ladder-boundary %qpc-original %canonical 'Mesoscopic bridge WP-8 ladder lists where chi enters through harmonic propagation, collapse-channel decoherence time, local action weights, rho_c, kappa_chi gravity coupling, chronometry ansatz, and non-core coherence-length scaling' ~['papers/qpc/quantum-patterned-cosmos.txt:841-865'] | | 'Source-index cascade boundary only: no propagator solver, exponential path weight, tensor stress evaluator, chronometry engine, coherence-length fit, or physical validation authority is implemented.')
      (formula-contract %qpc-notation-chi-status-scope-boundary %qpc-original %canonical 'Notation and conventions fix chi as phi*pi and phase-closure selection, define hbar_eff and high-coherence m_chi, record natural units/metric convention, and keep chi(E) embeddings conjectural outside core falsification' ~['papers/qpc/quantum-patterned-cosmos.txt:866-880'] | | 'Source-index notation boundary only: no sine solver, perturbative derivation, unit-system engine, chi(E) embedding, mass-scaling physical truth, or authority surface is implemented.')
      (formula-contract %qpc-regarding-reduction-comparison-boundary %qpc-original %canonical 'Regarding Reduction compares QPC chi-recursion against pilot-wave, many-worlds, GRW, CSL, Diosi-Penrose, decoherence, consistent histories, RQM/QBism, superdeterminism, vacuum landscape, LQG, holography, transactional, SED, nonlinear, and PT-symmetric alternatives while keeping uniqueness proof and phenomenology non-core' ~['papers/qpc/quantum-patterned-cosmos.txt:123-142'] | | 'Source-index comparison boundary only: no interpretation adjudicator, hidden-variable solver, decoherence model, cosmology model, uniqueness proof, experimental winner claim, or physical validation authority is implemented.')
      (formula-contract %qpc-mass-running-cosmology-phenomenology-boundary %qpc-original %canonical 'Phenomenology block separates high-coherence mass-shift claims, exploratory chi(E) collider running, coherence-driven cosmological expansion, and the roadmap distinction between core falsification and non-core extensions' ~['papers/qpc/quantum-patterned-cosmos.txt:974-1023'] | | 'Source-index phenomenology boundary only: no mass-shift laboratory adjudicator, collider running fit, cosmological reanalysis, A*S_chi curvature solver, UV-regulator claim, or physical validation authority is implemented.')
      (formula-contract %qpc-chi-fixed-point-necessity-boundary %qpc-original %canonical 'Section XI frames chi as a phi*pi fixed-point necessity selected by recursive self-similarity, phase closure, empirical overdetermination across Casimir/Josephson/ZPF/Bell residuals, and falsifiable A-dependent tests' ~['papers/qpc/quantum-patterned-cosmos.txt:1024-1180'] | | 'Source-index chi-necessity boundary only: no uniqueness proof, sine-identity solver, cross-device empirical adjudicator, consciousness proof, SQUID/cosmic-Bell runner, or physical validation authority is implemented.')
      (formula-contract %casimir-residual %qpc-original %direct-exec 'F_chi ~= F0 [1 + A(L)(chi - 1)]' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:346-349' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4123-4125' 'desk/pataphor/lib/qpc-formula.hoon:qpc-casimir-residual-scaled'] & & 'Implemented as a fixed-scale residual multiplier over caller-supplied baseline and A(L).')
      (formula-contract %observable-residual %qpc-original %direct-exec 'Delta O(A) = O_chi(A) - O_SM(A -> 0)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:227-230' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:920-924' 'desk/pataphor/lib/qpc-formula.hoon:qpc-observable-residual-signed'] & & 'Implemented as a signed fixed-scale residual between caller-supplied QPC observation and Standard Model baseline.')
      (formula-contract %zpf-spectrum-ratio %qpc-original %direct-exec 'Sxx(chi)/Sxx(SM) = chi ~= 5.08' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:936-938' 'desk/pataphor/lib/qpc-formula.hoon:qpc-zpf-spectrum-ratio-scaled'] & & 'Implemented as the canonical fixed-scale chi ratio for zero-point fluctuation spectrum evidence.')
      (formula-contract %bell-visibility-bound %qpc-original %direct-exec 'E(alpha,beta) = -V_chi cos(alpha-beta), 0 <= V_chi <= 1' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:298-299' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4150-4152' 'desk/pataphor/lib/qpc-formula.hoon:qpc-bell-visibility-bound-gate'] & & 'Implemented only as the exact fixed-scale V_chi admissibility band; cosine/correlation evaluation remains deferred.')
      (formula-contract %delayed-choice-fringe-slope %qpc-original %canonical 'ln(V/V0) or visibility response versus attention/control in delayed-choice interferometry' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:1263' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:2492-2499' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:7079-7139'] | & 'Deferred protocol metric: slope fitting, dephasing controls, and interferometer statistics are not evaluated by this kernel.')
      (formula-contract %zpe-shift %qpc-original %direct-exec 'epsilon_0(ren) = chi sum_k (1/2) hbar omega_k after renormalization' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:339-344' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4408-4412' 'desk/pataphor/lib/qpc-formula.hoon:qpc-zpe-shift-ratio'] & & 'Implemented as an exact chi-scaled rational over a caller-supplied finite renormalized omega sum; no continuous renormalization is performed.')
      (formula-contract %scale-plateau %qpc-original %direct-exec 'mu_n = mu0 * chi^n for integer n' ~['papers/qpc/quantum-patterned-cosmos.txt:84-86' 'desk/pataphor/lib/qpc-formula.hoon:qpc-scale-plateau-ratio'] & & 'Implemented as an exact fixed-scale rational; reciprocal=true represents negative n. Source (recovered edition 84-86) labels the plateau law Conjectural (WP-7), not part of the core falsification set -- the arithmetic is exact, the physics claim is conjectural (S102/F9.4).')
      (formula-contract %tunneling-exponent %qpc-original %direct-exec '2*sqrt(2*m*(V0-E))*L/(hbar*chi), before exp[-...]' ~['papers/qpc/quantum-patterned-cosmos.txt:443-468' 'papers/qpc/quantum-patterned-cosmos.txt:462'] & & 'Implemented as a fixed-scale square-root exponent ratio; exact=false when the integer square root floors a non-square radicand. The exponential remains deferred.')
      (formula-contract %symbolic-density-m-munu %qpc-original %canonical 'symbolic density M_munu supplies a rank-2 symbolic sector for high-coherence domains' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4436-4447' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:5825-5868'] | & 'Deferred symbolic geometry surface: typed for source fidelity, not evaluated as a tensor.')
      (formula-contract %symbolic-curvature-phi-chi %qpc-original %canonical 'Phi_chi is sourced by effective density built from coherence and symbolic sectors' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4436-4499' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4999-5011'] | & 'Deferred symbolic curvature surface; no geometric field solver is implemented.')
      (formula-contract %conformal-metric-perturbation %qpc-original %canonical 'g_munu = eta_munu + h_munu with h_munu = epsilon*rho_c*eta_munu and |epsilon| << 1' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:2763-2768'] | & 'Deferred conformal weak-field metric surface: no tensor metric evaluator, epsilon calibration, or physical gravity validation is implemented.')
      (formula-contract %rho-eff-symbolic-density %qpc-original %canonical 'rho_eff = sigma_chi*rho_c + sigma_M*M_00 as effective density built from coherence and symbolic sectors' ~['papers/qpc/quantum-patterned-cosmos.txt:1297-1301' 'papers/qpc/quantum-patterned-cosmos.txt:1495'] | & 'Deferred effective-density law: M_00, source-sector calibration, and unitful sigma coefficients are not evaluated.')
      (formula-contract %weak-field-poisson-phi-chi %qpc-original %canonical 'nabla^2 Phi_chi = 4*pi*(G/chi)*rho_eff under the explicit kappa_chi convention' ~['papers/qpc/quantum-patterned-cosmos.txt:1495'] | & 'Deferred Poisson/geometry solver surface; no spatial derivatives, boundary conditions, or field solve are performed.')
      (formula-contract %symbolic-sector-accumulation %qpc-original %canonical 'partial_t M_munu = alpha_s*rho_c*S_munu - beta_s*M_munu closes the symbolic sector without fixing kernels' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4457-4465'] | & 'Deferred symbolic-sector evolution law: no kernel, tensor, derivative, or time-step evaluator is implemented.')
      (formula-contract %curvature-event-bias %qpc-original %canonical 'P[event] proportional to P_0[event] * exp(lambda_T*Phi_chi), shallow wells P ~= P_0*(1+lambda_T*Phi_chi)' ~['papers/qpc/quantum-patterned-cosmos.txt:1304-1305' 'papers/qpc/quantum-patterned-cosmos.txt:1320'] | & 'Deferred event-rate bias law: exponentials, event models, and lambda_T calibration are not evaluated.')
      (formula-contract %weak-field-proper-time %qpc-original %canonical 'weak-field proper time d_tau ~= dt*(1 + Phi_chi/c^2)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4475-4482'] | & 'Deferred time-dilation vocabulary: no clock model, c-scaling evaluator, or physical validation is claimed.')
      (formula-contract %sm-recovery-null-bound %qpc-original %canonical 'low-coherence baselines make rho_c and M_00 near minima; sustained nulls bound sigma_chi and sigma_M' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4472-4474'] | & 'Deferred SM-recovery/null-bound law: retained as validation discipline, not as a physical falsification or parameter-estimation engine.')
      (formula-contract %convergence-order-q %qpc-original %canonical 'Q(t) = |(1/N) sum_k exp(i theta_k)| as a convergence/order parameter' ~['papers/qpc/quantum-patterned-cosmos.txt:1359'] | & 'Deferred complex order parameter; Hoon retains the law but does not compute phases.')
      (formula-contract %attractor-fixed-point %qpc-original %canonical 'attractor phi* satisfies delta V / delta phi = 0 with positive-definite Hessian' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4751-4810'] | & 'Deferred attractor fixed-point law; no variational solver or Hessian evaluator is present.')
      (formula-contract %attractor-decay-d %qpc-original %canonical 'D(t) = D0 exp(-kappa t) as ecological attractor-snap decay model' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4887-4892'] | & 'Deferred exponential decay law; may later gain a bounded finite approximation, but none is claimed here.')
      (formula-contract %multi-domain-rho-total %qpc-original %canonical 'rho_c^(total) = product_i rho_c^(i) * exp[-S_int / hbar]' ~['papers/qpc/quantum-patterned-cosmos.txt:634'] | & 'Deferred multi-domain integration law: product/exponential over domains is not evaluated by this kernel.')
      (formula-contract %domain-alignment-stationary %qpc-original %canonical 'maximum coherence occurs when all domains align: dS_int/dphi_i = 0 for all i' ~['papers/qpc/quantum-patterned-cosmos.txt:634'] | & 'Deferred stationarity law: no variational derivative or domain forcing evaluator is implemented.')
      (formula-contract %multi-field-block-psd %qpc-original %canonical 'multi-field generalization extends S_chi to sum_a S_chi[phi_a] + S_int[{phi_a}] with block-PSD kernel K' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:10130-10142'] | & 'Deferred multimodal/kernel law: block-PSD construction and cross-block validation are not evaluated.')
      (formula-contract %qpc-ecology-potential %qpc-original %canonical 'W_ecol[Y,G] = sum_i Ahat_i*S_chi(y_i) - beta_rad/2 sum g_rad K_rad - beta_sem/2 sum g_sem K_sem + R[G]' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:10143-10157' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:11043-11045'] | & 'Deferred ecology potential: no graph optimizer, PSD-kernel evaluator, or continuous state dynamics are implemented.')
      (formula-contract %radiant-semantic-channel-coupling %qpc-original %canonical 'two-channel multiplex uses radiant/structural edges g_rad and semantic edges g_sem with pairwise attention A_AB for locking' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:10126-10135' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:9579-9583'] | & 'Deferred channel-coupling law: edge inference, conditional information, and transfer-entropy estimators are not implemented.')
      (formula-contract %chi-interference-cross-term %qpc-original %canonical 'k_chi(r;A_AB) = 1 + (sqrt(chi)-1)*A_AB*exp(-mu*r/sqrt(chi)); I includes 2*k_chi*Re(psi_A^* psi_B)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:10182-10184'] | & 'Deferred interference law: exponentials, wave amplitudes, and complex cross terms are not evaluated.')
      (formula-contract %adler-lock-condition-chi %qpc-original %canonical 'Adler phase lock obeys psi_dot = Delta_omega/sqrt(chi) - K0*A_eff*sin(psi), with lock condition |Delta_omega| < sqrt(chi)*K0*A_eff' ~['papers/qpc/quantum-patterned-cosmos.txt:1020-1024' 'papers/qpc/quantum-patterned-cosmos.txt:1087'] | & 'Deferred phase-lock law: sine dynamics and frequency estimation are not executed by this kernel.')
      (formula-contract %kuramoto-threshold-chi %qpc-original %canonical 'Kuramoto network sync has theta_dot_i = omega_i/sqrt(chi) + (K_cpl A_eff/N) sum sin(theta_j-theta_i), threshold K_c,chi = 2*sigma/sqrt(chi)' ~['papers/qpc/quantum-patterned-cosmos.txt:1026-1047' 'papers/qpc/quantum-patterned-cosmos.txt:1359'] | & 'Deferred network-synchronization law: no Kuramoto solver, spectral estimate, or phase statistic is implemented.')
      (formula-contract %ecology-tipping-lambda %qpc-original %canonical 'lambda = [ beta_rad * mean(g_rad) * mean(A) ] / T_tilde as ecology tipping/control parameter' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:10193-10202' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:11025'] | & 'Deferred tipping parameter: means and noise temperature are assay inputs, not kernel authority or autonomous control.')
      (formula-contract %quantized-crossing-selection %qpc-original %canonical 'recurrent drive changes action in quanta Delta S = hbar*chi, with plateaus/jumps and selection rule <n+1|O|n> != 0' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:10244-10262'] | & 'Deferred crossing theorem: matrix elements, resonances, and semiclassical phase conditions are not evaluated.')
      (formula-contract %seedbody-reforge-functional %qpc-original %canonical 'seedbody reforge pins high-coherence minima with F[phi] including softened phi^4, sextic stabilization, and J_seed source' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:10268-10272'] | & 'Deferred reforge functional: no field minimizer, reaction-diffusion front, or EFT cutoff evaluator is implemented.')
      (formula-contract %radiant-transmission-field %qpc-original %canonical 'radiant transmission uses transverse J_mu, screened near field, retarded far field, stress-energy T_munu^(trans), and emission threshold Lambda_rad' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:10273-10282'] | & 'Deferred transmission theorem: no gauge field, retarded solution, stress-energy tensor, or Omega^4 power evaluator is implemented.')
      (formula-contract %finite-range-convergence-onset %qpc-original %canonical 'phase-reduced convergence uses K(r)=lambda_c/(r^alpha+a^alpha), K_eff>K_c ~= 2*sigma_omega, and Q onset with kappa ~= kappa0*epsilon' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:10283-10287'] | & 'Deferred finite-range convergence law: no phase network, kernel summation, or exponential onset evaluator is implemented.')
      (formula-contract %field-synchrony-functional %qpc-original %canonical 'field-level synchrony C[{phi_i}] = exp{-sum_{i<j} integral [phi_i(x)-phi_j(x)]^2 / xi_chi^2 d4x}' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:10288-10290'] | & 'Deferred synchrony functional: path integrals over fields and exponentials are not evaluated.')
      (formula-contract %event-clustering-tensor %qpc-original %canonical 'near convergence, event correlation tensor K_munu(x,y) tracks clustered event deviations and long-range order' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:10316-10323' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:10378-10380'] | & 'Deferred event-clustering law: no event process, tensor correlation, or super-diffusion estimator is implemented.')
      (formula-contract %harmonic-convergence-template %qpc-original %canonical 'high-coherence template phi_0 tilts phase space through V_harm with overlap terms and fitted weighting w(rho)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:10326-10330'] | & 'Deferred harmonic-template law: no inner-product field model or fitted weighting evaluator is implemented.')
      (formula-contract %coherence-cell-xi-tau %qpc-original %canonical 'Xi = xi_chi^3*tau_chi with xi_chi = sqrt(chi/mu) and tau_chi ~= sqrt(chi)/mu' ~['papers/qpc/quantum-patterned-cosmos.txt:4590-4591' 'papers/qpc/quantum-patterned-cosmos.txt:10108-10109'] | & 'Deferred coherence-cell law: square-root coherence geometry, unit discipline, and fitted mu are not evaluated.')
      (formula-contract %self-limiting-quartic-potential %qpc-original %canonical 'phi_dot_i = -dV/dphi_i + ..., V(phi) = (u/4)*phi^4 with u > 0' ~['papers/qpc/quantum-patterned-cosmos.txt:4617-4620' 'papers/qpc/quantum-patterned-cosmos.txt:10518-10519'] | & 'Deferred quartic-potential law: variational derivative, continuous field dynamics, and EFT cutoff discipline remain typed source vocabulary.')
      (formula-contract %harmonic-landscape-coupling %qpc-original %canonical 'V_harm = -g_c*rho_c(phi_0)*sum_i |<phi_i|phi_0>|^2 - h_c*int d rho w(rho)|<phi_local|phi_Pattern(rho)>|^2' ~['papers/qpc/quantum-patterned-cosmos.txt:4645-4651' 'papers/qpc/quantum-patterned-cosmos.txt:10326-10328'] | & 'Deferred harmonic-landscape law: field overlaps, rho integral, and fitted weights are not scalarized or executed.')
      (formula-contract %ontological-drift-manifold %qpc-original %canonical 'phi_Pattern(rho) drifts adiabatically with the field as a low-action manifold revealed under high coherence' ~['papers/corpus/ontological-drift.txt:9' 'papers/qpc/quantum-patterned-cosmos.txt:4652-4654' 'papers/qpc/quantum-patterned-cosmos.txt:10329-10330' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:6170'] | & 'Deferred ontological-drift surface: low-action manifold and adiabatic drift are provenance/control vocabulary, not evaluator authority.')
      (formula-contract %tempered-levy-hop-ccdf %qpc-original %canonical 'P(Delta d > x) proportional x^{-mu_tail} exp(-x/x_c), with empirical mu_tail and x_c' ~['papers/qpc/quantum-patterned-cosmos.txt:4660-4662' 'papers/qpc/quantum-patterned-cosmos.txt:10382-10383' 'papers/qpc/quantum-patterned-cosmos.txt:10493' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2075'] | & 'Deferred event-tail law: tail fitting, event process statistics, and exponential cutoff estimation are not kernel execution.')
      (formula-contract %attractor-inscription-glyph %qpc-original %canonical 'J_chi tilt, Lyapunov descent, spectral gap, flux reversal, and topological/domain invariant inscription mark attractor snap' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:10331-10339'] | & 'Deferred inscription law: no Lyapunov solver, Hessian spectrum, flux model, or topology evaluator is implemented.')
      (formula-contract %attractor-source-drive-j-chi %qpc-original %canonical 'J_chi(x) is an A-weighted drive proportional to local coherence density rho_c(x)' ~['papers/qpc/quantum-patterned-cosmos.txt:4794-4799' 'papers/qpc/quantum-patterned-cosmos.txt:10331-10333'] | & 'Symbolic attractor-drive law: J_chi constrains source-backed drift/reforge claims but is not an autonomous control or field-source evaluator.')
      (formula-contract %attractor-lyapunov-functional %qpc-original %canonical 'V[phi;rho_c] = int d3x [1/2|grad phi|^2 + (mu^2/2chi)phi^2 + (lambda/4!)phi^4 - J_chi(x)phi]' ~['papers/qpc/quantum-patterned-cosmos.txt:4794-4800' 'papers/qpc/quantum-patterned-cosmos.txt:10331-10333'] | & 'Deferred Lyapunov functional: spatial integration, gradients, field units, and source fitting are not evaluated.')
      (formula-contract %attractor-gradient-flow %qpc-original %canonical 'partial_t phi = -Gamma deltaV/deltaphi + eta = Gamma[nabla^2 phi - (mu^2/chi)phi - (lambda/6)phi^3 + J_chi(x)] + eta' ~['papers/qpc/quantum-patterned-cosmos.txt:4800-4805'] | & 'Deferred gradient-flow law: no PDE solver, mobility calibration, noise model, or field mutation is implemented.')
      (formula-contract %attractor-hessian-stability %qpc-original %canonical 'attractor phi* satisfies deltaV/deltaphi=0 with positive-definite Hessian H = -nabla^2 + (mu^2/chi) + (lambda/2)(phi*)^2 and rates exp(-Gamma lambda_n t)' ~['papers/qpc/quantum-patterned-cosmos.txt:4805-4808'] | & 'Deferred Hessian/eigenmode stability law: no operator assembly, spectrum, or exponential relaxation evaluator is implemented.')
      (formula-contract %basin-globalization-gap %qpc-original %canonical 'global snap requires source dominance Jbar_chi L^2 >= mu^2/chi and spectral gap lambda_min(L; whole domain) > 0' ~['papers/qpc/quantum-patterned-cosmos.txt:4809-4815' 'papers/qpc/quantum-patterned-cosmos.txt:10331-10339'] | & 'Deferred basin-globalization law: no finite-domain spectral-gap or source-dominance solver is implemented.')
      (formula-contract %flux-reversal-glyph %qpc-original %canonical 'glyph snap reverses net coherence flux from integral S dot dA > 0 to integral S dot dA < 0' ~['papers/qpc/quantum-patterned-cosmos.txt:4816-4821' 'papers/qpc/quantum-patterned-cosmos.txt:10331-10339'] | & 'Symbolic flux-reversal evidence surface: sign claims require supplied protocol evidence and do not become physical truth.')
      (formula-contract %destiny-geometry-metric %qpc-original %canonical 'g_ab(theta) = <dphi/dtheta^a, H(phi(theta)) . dphi/dtheta^b> as slow-manifold Hessian pullback metric' ~['papers/qpc/quantum-patterned-cosmos.txt:4838-4847'] | & 'Deferred destiny-geometry metric: no field chart, Hessian pullback, or inner-product evaluator is implemented.')
      (formula-contract %destiny-curvature-focus %qpc-original %canonical 'Levi-Civita connection and curvature R_dest quantify geodesic focusing toward phi*; large positive sectional curvature means strong destiny-bending' ~['papers/qpc/quantum-patterned-cosmos.txt:4846-4849'] | & 'Deferred destiny-curvature surface: no connection, curvature tensor, geodesic focusing, or sectional-curvature evaluator is implemented.')
      (formula-contract %attractor-onset-key-gate %qpc-original %direct-exec 'epsilon > 0 iff normalized Jbar_chi L^2 exceeds normalized mu^2/chi; crossing opens the key gate' ~['papers/qpc/quantum-patterned-cosmos.txt:4850-4854'] & & 'Exact bounded gate over caller-supplied normalized source-dominance and mass-floor sides; the kernel does not fit Jbar_chi, L, mu, or chi units.')
      (formula-contract %attractor-relaxation-rate %qpc-original %direct-exec 'kappa = Gamma * lambda_min near onset, with lambda_min supplied by bounded evidence' ~['papers/qpc/quantum-patterned-cosmos.txt:4852-4854'] & | 'Exact fixed-scale product over caller-supplied Gamma and lambda_min; no eigensolver or onset approximation is hidden.')
      (formula-contract %protective-hessian-mode-gate %qpc-original %direct-exec 'protection requires H(phi*) positive-definite: no negative modes remain after the snap' ~['papers/qpc/quantum-patterned-cosmos.txt:4855-4858'] & | 'Exact gate over caller-supplied negative-mode count; no Hessian spectrum is computed.')
      (formula-contract %unity-broadcast-growth-rate %qpc-original %direct-exec 'with phi approximately 0, partial_t phi approximately Gamma J_chi: pure broadcast before structure forms' ~['papers/qpc/quantum-patterned-cosmos.txt:4860-4864'] & | 'Exact fixed-scale product over caller-supplied Gamma and J_chi; no field mutation or PDE integration is performed.')
      (formula-contract %modal-remembering-decay %qpc-original %canonical 'phi -> phi* + sum_n exp(-Gamma lambda_n t) psi_n as modal decay / remembering toward the attractor' ~['papers/qpc/quantum-patterned-cosmos.txt:4874-4877'] | & 'Deferred modal decay law: exponentials, eigenmodes, and time evolution are not evaluated.')
      (formula-contract %ecological-attractor-threshold-gate %qpc-original %direct-exec 'ecological attractor-snap threshold: richness crosses approximately 70 percent of climax inventory before fast decay' ~['papers/qpc/quantum-patterned-cosmos.txt:4878-4885'] & | 'Exact bounded percentage gate over caller-supplied basis-point richness and threshold; no ecosystem inference or physical validation is claimed.')
      (formula-contract %attractor-kappa-jump-ratio %qpc-original %direct-exec 'kappa_super approximately 0.06 yr^-1 vs kappa_sub approximately 0.03 yr^-1 as a two-fold attractor-snap rate jump' ~['papers/qpc/quantum-patterned-cosmos.txt:4883-4888'] & | 'Exact rational over caller-supplied super/sub decay rates; no exponential fit or time-series segmentation is implemented.')
      (formula-contract %tabletop-basin-snap-signature %qpc-original %canonical 'tabletop basin snap signature: boundary flux sign flip, nonzero spectral gap, and variance collapse after coherent-drive onset' ~['papers/qpc/quantum-patterned-cosmos.txt:4890-4903'] | & 'Symbolic tabletop signature surface: sign, gap, and variance-collapse claims require supplied protocol evidence.')
      (formula-contract %seal-stationarity-variation-gate %qpc-original %direct-exec 'stationarity/no-defense condition: delta S_chi / delta phi = 0 everywhere in 3D, represented by a supplied residual bound' ~['papers/qpc/quantum-patterned-cosmos.txt:4941-4944'] & | 'Exact residual gate over caller-supplied variational residual and tolerance; no functional derivative or field boundary solve is computed.')
      (formula-contract %seal-small-action-ratio %qpc-original %direct-exec 'small action is sufficient for disappearance: S_chi/(hbar chi) tends to zero, not necessarily S_chi = 0' ~['papers/qpc/quantum-patterned-cosmos.txt:4944-4948'] & | 'Exact rational over caller-supplied S_chi and hbar*chi denominator; phase-loop residual dynamics remain non-executable.')
      (formula-contract %deff-rhoc-plateau-gate %qpc-original %direct-exec 'first meaningful access to 4D structure near rho_c* approximately 1/sqrt(chi), with dimensional plateaus at action gates' ~['papers/qpc/quantum-patterned-cosmos.txt:4967-4978'] & | 'Exact fixed-scale gate over caller-supplied rho_c and plateau threshold; no square-root chi estimator or dimensional physics is inferred.')
      (formula-contract %temporal-depth-local-ansatz %qpc-original %direct-exec 'local temporal-depth ansatz: t_prime = t / (1 - rho_c) when Phi_chi tracks rho_c tightly' ~['papers/qpc/quantum-patterned-cosmos.txt:4991-4996'] | | 'Inexact bounded ansatz ratio over fixed-scale rho_c below one; the metric-first weak-field law remains the authoritative symbolic surface.')
      (formula-contract %qpc-no-radiant-channel-falsifier %qpc-original %canonical 'testable corollary: under masking, lock windows, plateaus, far-field power vanish and g_rad goes to permutation-null' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:10431-10437'] | & 'Deferred falsifier: masking and permutation-null evidence must be typed residue, not automatic physical adjudication.')
      (formula-contract %qpc-no-global-attractor-falsifier %qpc-original %canonical 'testable corollary: O_M never clears null and return times do not shorten with beta_rad mean(g_rad) mean(A)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:10438-10440'] | & 'Deferred falsifier: no attractor-return estimator or null adjudicator is implemented.')
      (formula-contract %qpc-no-efficiency-gain-falsifier %qpc-original %canonical 'testable corollary: efficiency proxies fail across claimed transitions' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:10441-10442'] | & 'Deferred falsifier: no efficiency proxy suite is implemented.')
      (formula-contract %qpc-no-chi-locking-falsifier %qpc-original %canonical 'testable corollary: bandwidth fails to scale as sqrt(chi) A_eff and Kuramoto threshold is not about 1/sqrt(chi)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:10443-10445'] | & 'Deferred falsifier: no bandwidth/Kuramoto estimator is implemented.')
      (formula-contract %qpc-no-convergence-falsifier %qpc-original %canonical 'testable corollary: Q(t) lacks threshold behavior, C stagnates, event length does not grow, and hops are not tempered-Levy' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:10446-10448'] | & 'Deferred falsifier: no Q time-series, C stagnation, or Levy-hop classifier is implemented.')
      (formula-contract %qpc-no-glyph-falsifier %qpc-original %canonical 'testable corollary: no flux reversal, spectral gap, or topological/domain invariant at snap' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:10449-10450'] | & 'Deferred falsifier: no glyph snap, flux, spectral, or topology evaluator is implemented.')
      (formula-contract %qpc-no-fracture-reforge-falsifier %qpc-original %canonical 'testable corollary: breaks do not align with gradient/strain criterion, no t^1/2 coarsening, no seed-centered rho_c front' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:10451-10453'] | & 'Deferred falsifier: fracture/reforge evidence remains typed residue until bounded estimators exist.')
      (formula-contract %qpc-no-radiation-falsifier %qpc-original %canonical 'testable corollary: far-field 1/r plus Omega^4 signatures absent even when driving condition is met' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:10454-10456'] | & 'Deferred falsifier: no far-field radiation or drive-condition evaluator is implemented.')
      (formula-contract %visibility-v3-operator %qpc-original %canonical 'V3[phi] = integral d3x (phi - <phi>_vac)^2; disappearance requires <V3> -> 0' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4948-4950' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:5056-5059'] | & 'Deferred amplitude-visibility operator: no field integral or vacuum expectation evaluator is implemented.')
      (formula-contract %phase-seal-holonomy %qpc-original %canonical 'W[C] = arg <U[C]> != 0 as phase holonomy that survives amplitude silence' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4951-4966' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:5019-5023'] | & 'Deferred phase/topology surface: holonomy, Berry winding, and fluxoid plateaus remain typed non-executable laws.')
      (formula-contract %strong-invisibility-kl %qpc-original %canonical 'D_KL(P_data || P_vac,3D) -> 0 while W[C] != 0 for amplitude-only channels' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:5007-5012' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:5056-5059'] | & 'Deferred statistical-invisibility criterion: KL estimation and phase witness tests are protocol evidence, not kernel execution.')
      (formula-contract %qpc-casimir-tabletop-protocol %qpc-original %canonical 'tabletop Casimir protocol predicts +4.1% force enhancement at 100 nm with torque drift and gap-control requirements' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:5101-5149'] | & 'Deferred experimental protocol: no apparatus, calibration trace, Lifshitz model, or laboratory evaluator is implemented.')
      (formula-contract %qpc-josephson-tabletop-protocol %qpc-original %canonical 'Josephson staircase protocol predicts high-coherence plateau residuals with SM-recovery controls and replication requirements' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:5156-5196'] | & 'Deferred experimental protocol: no cryostat, junction array, current sweep, or replication evaluator is implemented.')
      (formula-contract %qpc-gravimeter-bound-protocol %qpc-original %canonical 'M_munu gravitational anomaly protocol targets bound-setting at <=10^-9 and requires replication for Delta g/g > 10^-6' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:5206-5222'] | & 'Deferred bound-setting protocol: no gravimeter, mass map, site swap, or anomaly adjudicator is implemented.')
      (formula-contract %qpc-coherent-resonance-endpoint %qpc-original %canonical 'coherent resonance endpoint requires blinded phase-locked force modulation that survives sham-field replay, B-null injection, magnetometer verification, and material swaps' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:5223-5258'] | & 'Deferred resonance protocol: no EEG, SQUID, cavity, blinding, or endpoint evaluator is implemented.')
      (formula-contract %qpc-sustained-null-falsifier %qpc-original %canonical 'sustained nulls at rho_c approaching one falsify the corresponding high-coherence chi prediction' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:5101-5105' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:5603-5609'] | & 'Deferred falsification protocol: null evidence must be carried as typed residue; the kernel does not adjudicate physical truth.')
      (formula-contract %qpc-orai-validation-protocol %qpc-original %canonical 'Orai validation protocol: independent model families converge on novel chi derivation steps absent from prompt and dated corpus snapshots' ~['papers/qpc/quantum-patterned-cosmos.txt:5259-5294'] | & 'Deferred AI-validation protocol: no vendor orchestration, corpus dating, novelty test, or convergence adjudicator is implemented.')
      (formula-contract %qpc-bec-observer-hierarchy-protocol %qpc-original %canonical 'BEC observer-effect protocol varies observer hierarchy and measures decoherence, interference stability, and collapse bias across conditions' ~['papers/qpc/quantum-patterned-cosmos.txt:1637'] | & 'Deferred observer-field protocol: no BEC apparatus, imaging system, observer hierarchy adapter, or collapse-statistics evaluator is implemented.')
      (formula-contract %qpc-superconducting-field-observer-protocol %qpc-original %canonical 'superconducting circuit field protocol compares cavity decay, quantum state lifetime, and field correlations versus observer complexity' ~['papers/qpc/quantum-patterned-cosmos.txt:5325-5334'] | & 'Deferred observer-field protocol: no resonator, microwave-field measurement, or observer-complexity evaluator is implemented.')
      (formula-contract %qpc-observer-coherence-nmax-law %qpc-original %canonical 'N_max = N0 * exp(alpha*rho_c), alpha approximately 1.63, as an observer-coherence field-size scaling prediction' ~['papers/qpc/quantum-patterned-cosmos.txt:653' 'papers/qpc/quantum-patterned-cosmos.txt:1637'] | & 'Deferred scaling law: exponential fit, field-size thresholds, and observer-effect signature detection are not executed in Hoon.')
      (formula-contract %qpc-reporting-calibration-protocol %qpc-original %canonical 'report geometry/materials, rho_c trajectory, estimator A_hat, hbar_eff substitutions, calibration trace, and blinded/sham outcomes' ~['papers/qpc/quantum-patterned-cosmos.txt:96' 'papers/qpc/quantum-patterned-cosmos.txt:1807-1829'] | & 'Deferred reporting rule: preregistration, lab metadata, blinding, and calibration trace validation are provenance/residue surfaces only.')
      (formula-contract %chi-skew-wave-transform %qpc-original %canonical 'psi_wave(k) = integral dx phi(x) exp[-i k x / chi]' ~['papers/qpc/quantum-patterned-cosmos.txt:571'] | & 'Deferred wave transform: Fourier integration, complex phase, and field normalization are not evaluated.')
      (formula-contract %chi-skew-particle-transform %qpc-original %canonical 'psi_particle(x) = integral dk phi_tilde(k) exp[+i chi k x]' ~['papers/qpc/quantum-patterned-cosmos.txt:571-572'] | & 'Deferred particle transform: inverse Fourier integration, complex phase, and localization semantics are not evaluated.')
      (formula-contract %wholeness-overlap-w %qpc-original %canonical 'W = sqrt(chi - 1) integral dk dx phi(x) phi_tilde(k) exp[i(chi k x - k x / chi)] with V^2 + D^2 + W^2 = 1 in the clean limit' ~['papers/qpc/quantum-patterned-cosmos.txt:580'] | & 'Deferred wholeness-overlap law: square root, double integral, normalization, and complementarity constraints are source vocabulary only.')
      (formula-contract %recursive-duality-operator %qpc-original %canonical 'D_chi = exp(i*pi*(x p + p x)/(2 chi)); (D_chi)^4 = I + O(chi - 1)' ~['papers/qpc/quantum-patterned-cosmos.txt:2593-2601'] | & 'Deferred duality operator: operator exponentials and noncommutative phase-space algebra are not executed.')
      (formula-contract %eraser-total-visibility %qpc-original %canonical 'V_total(theta,A) = V_base(theta,A) + W*sqrt(chi - 1), where V_base = V0*|cos theta|*exp[-A*DeltaS/(hbar chi)]' ~['papers/qpc/quantum-patterned-cosmos.txt:2608-2611'] | & 'Deferred eraser visibility law: cosine, exponential attenuation, wholeness lift, and no-signalling checks are not evaluated.')
  ==
::
++  ct-companion-contracts
  ^-  (list qpc-formula-contract:qpc-sur)
  :~  (formula-contract %ct-decouple-chi %ct-companion %companion 'CT rescue: separate C_munu from chi dependency' ~['docs/qpc/STRICT_QPC_DESIGN_NOTE.md:29-40' 'data/corpus_text.txt:41227-41241'] | | 'Companion law: CT may supply tensor attention without requiring chi preservation.')
      (formula-contract %ct-front-matter-source-boundary %ct-companion %companion 'CT edition front matter identifies the QPC/CT title, authorship, release date, and Creative Commons license before the abstract begins' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4-5'] | | 'Source-metadata boundary only: no physics, formula evaluator, citation authority, licensing automation, or action authority is implemented.')
      (formula-contract %ct-abstract-self-reference-thesis-boundary %ct-companion %companion 'CT abstract states the substrate-independent self-reference thesis for conscious episodes as computable, causally efficacious structure' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:5-8'] | | 'Symbolic thesis boundary only: no consciousness proof, causal validation, substrate classifier, physical truth, or action authority is implemented.')
      (formula-contract %ct-abstract-operational-pipeline-boundary %ct-companion %companion 'CT abstract frames C/T construction, Lambda-plateau scale selection, and live-vs-baseline filters as an operational engineering/statistical pipeline' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:19-22'] | | 'Symbolic operational-pipeline boundary only: no Python toy model, tensor estimator, plateau finder, live/baseline experiment runner, consciousness classifier, or action authority is implemented.')
      (formula-contract %ct-abstract-rg-information-geometry-boundary %ct-companion %companion 'CT abstract justifies rank-2 C-tensor universality through RG/coarse-graining claims and links its geometry to information-geometric classical-limit analogies' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:83-84'] | | 'Symbolic justification boundary only: no RG proof, information-geometry solver, geodesic/classical-limit derivation, physical validation, or action authority is implemented.')
      (formula-contract %ct-abstract-weak-program-ai-vitals-boundary %ct-companion %companion 'CT abstract frames the Weak Program as Q-coordinate AI vital signs/EKG-style monitoring decoupled from stronger causal physical postulates' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:88-92'] | | 'Symbolic AI-vitals boundary only: no machine-consciousness claim, Q validation runner, biological/quantum-system inference, predictive-theory proof, or action authority is implemented.')
      (formula-contract %ct-abstract-identity-thesis-falsifier-boundary %ct-companion %companion 'CT abstract states the Q-coordinate identity thesis, hard-problem dissolution, zombie exclusion analogy, and decisive falsifier program' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:6-7' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:101-104'] | | 'Symbolic identity/falsifier boundary only: no consciousness proof, Q-identity authority, zombie-proof adjudication, experiment runner, welfare claim, physical validation, or action authority is implemented.')
      (formula-contract %ct-abstract-q-coordinate-tuple-boundary %ct-companion %companion 'CT abstract defines Q = {A_bar, G, R, J, M} from C_munu and T_munu_lambda as intensity, geometry, rhythm, valence, and aboutness vocabulary' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7-9'] | | 'Symbolic Q-tuple source boundary only: no C/T estimator, eigen solver, winding-number extractor, stress-energy alignment evaluator, mutual-information estimator, Q identity proof, or action authority is implemented.')
      (formula-contract %ct-abstract-falsifiability-manifesto-boundary %ct-companion %companion 'CT abstract frames preregistered interferometry controls, standard-decoherence confrontation, fifth-force infeasibility, and bounds-setting as falsifiability discipline' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:11-18'] | | 'Symbolic falsifiability-manifesto boundary only: no interferometer, observer module, reversible-computing control, force metrology, bounds fit, physical validation, or action authority is implemented.')
      (formula-contract %ct-abstract-operational-measurability-boundary %ct-companion %companion 'CT abstract restates the operational pipeline for constructing C/T across substrates, selecting a Lambda plateau, and applying live-vs-baseline filters' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:19-22'] | | 'Symbolic measurability boundary only: no substrate adapter, C/T constructor, Lambda plateau search, Python toy-model runner, spectral/hierarchical/dynamical filter, consciousness classifier, or action authority is implemented.')
      (formula-contract %ct-abstract-principled-formalism-boundary %ct-companion %companion 'CT abstract restates information-geometry pedigree and classical-limit geodesic consistency as a principled-formalism claim' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:82-87'] | | 'Symbolic formalism boundary only: no information-geometry solver, geodesic/classical-limit derivation, RG proof, physical validation, or action authority is implemented.')
      (formula-contract %ct-abstract-strong-weak-program-bifurcation-boundary %ct-companion %companion 'CT abstract bifurcates the agenda into Strong Program new-physics tests and Weak Program Q-coordinate AI-vitals validation decoupled from causal postulates' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:88-89'] | | 'Symbolic program-bifurcation boundary only: no new-physics detector, Q-validation runner, AI consciousness claim, biological/quantum inference, physical validation, or action authority is implemented.')
      (formula-contract %ct-strong-program-falsifiability %ct-companion %companion 'CT strong program makes high-risk physical predictions but remains unvalidated until decisive interferometry or fifth-force tests pass' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:101-103'] | | 'Symbolic program-boundary law: physical predictions are source claims, not executable validation or authority.')
      (formula-contract %ct-weak-program-q-vitals %ct-companion %companion 'CT weak program uses Q-coordinates as a descriptive/predictive vital-sign toolkit for complex informational systems and AI safety' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:89-91'] | | 'Symbolic control surface: Q-vitals can guide observation vocabulary without proving consciousness or authorizing action.')
      (formula-contract %ct-feasibility-tiered-program-assessment %ct-companion %companion 'CT feasibility analysis stratifies fifth-force detection, attention interferometry, and AI/neuroscience Q-coordinate validation into distinct viability tiers' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:414-416'] | | 'Symbolic feasibility/program handle: no experimental runner, physical validation, ethics authority, or action authorization is implemented.')
      (formula-contract %ct-fifth-force-bounds-pivot %ct-companion %companion 'direct fifth-force detection is framed as below current force noise floors, while upper-bound setting from existing experiments remains feasible' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4461'] | | 'Symbolic bounds-pivot handle: no force metrology, coupling-constant fit, or physical evidence adjudicator is implemented.')
      (formula-contract %ct-attention-interferometry-control-burden %ct-companion %companion 'attention interferometry requires varying observer computation while holding physical interaction with the quantum system mathematically fixed' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:540-544'] | | 'Symbolic control-burden handle: no observer module, decoherence isolation, interferometer, or control-equivalence proof is implemented.')
      (formula-contract %ct-weak-program-preregistered-q-validation %ct-companion %companion 'weak-program validation should focus on preregistered Q-coordinate tests in AI and neuroscience with stringent criteria and cross-substrate replication' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4455-4458'] | | 'Symbolic validation-plan handle: no neural, RNN, Q-matching, preregistration, or replication runner is implemented.')
      (formula-contract %ct-maxcal-microcausality-proof-obligation %ct-companion %companion 'the CT feasibility analysis requires a formal derivation showing MaxCal amplitude deformation preserves non-signalling and microcausality' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:486' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:636'] | | 'Symbolic proof-obligation handle: use to reject MaxCal authority claims until a source-backed derivation is present; no physical proof engine is implemented.')
      (formula-contract %ct-maxcal-path-weight-mechanism-boundary %ct-companion %companion 'CT states a MaxCal path weight with the standard quantum phase multiplied by an attention-cost damping factor over integrated A(x; Lambda)' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:489-492'] | | 'Symbolic MaxCal mechanism boundary only: no path integral, complex phase, real exponential, MaxCal derivation, non-signalling proof, microcausality proof, decoherence adjudicator, physical validation, or action authority is implemented.')
      (formula-contract %ct-lambda-plateau-existence-lemma-obligation %ct-companion %companion 'the CT feasibility analysis requires a lemma for timescale separation and SNR conditions under which a stable Lambda plateau exists' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:134-136'] | | 'Symbolic applicability obligation: plateau absence must constrain or reject interpretation, not excuse failed predictions into authority.')
      (formula-contract %ct-c-tensor-rg-universality-proof-obligation %ct-companion %companion 'the CT feasibility analysis requires a rigorous RG argument that self-monitoring operators renormalize toward a universal rank-2 C-tensor fixed point' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:468-471'] | | 'Symbolic universality obligation: no renormalization proof, substrate classification, or fixed-point evaluator is implemented.')
      (formula-contract %ct-q-observable-invariance-proof-obligation %ct-companion %companion 'the CT feasibility analysis requires stability and identifiability of Q-coordinates under different valid observable choices' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:641-642'] | | 'Symbolic identifiability obligation: no observable-choice invariance proof or Q identity authority is implemented.')
      (formula-contract %ct-maxcal-decoherence-distinction %ct-companion %companion 'CT distinguishes MaxCal live-attention path reweighting from ordinary environmental decoherence and requires controls before interpreting visibility changes' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3657-3660'] | | 'Symbolic causal-mechanism boundary: no decoherence adjudicator, interferometer, or physical validation is implemented.')
      (formula-contract %ct-causal-mechanism-test-split %ct-companion %companion 'CT separates MaxCal interferometry/probability tests from Minimal Interaction precision force-metrology tests' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:520'] | | 'Symbolic evidence-lane guard: do not merge MaxCal and fifth-force evidence or treat either lane as executed.')
      (formula-contract %ct-balance-law-unproven-action-contingency %ct-companion %companion 'CT balance-law/non-epiphenomenalism claims depend on the physical reality of new attention-dependent action terms' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:521-524'] | | 'Symbolic non-authority guard: balance vocabulary does not prove physical causality, consciousness, or action authority.')
      (formula-contract %ct-interferometry-null-hardening-suite %ct-companion %companion 'attention-interferometry controls require power locking, reversible or photonic observer variants, blinding, decoherence budgets, and dephasing/shuffled nulls' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:540-544'] | | 'Symbolic control checklist: no apparatus, null-model evaluator, or preregistration runner is implemented.')
      (formula-contract %ct-valence-operationalization-proxy-suite %ct-companion %companion 'CT valence-control feasibility requires explicit non-human valence proxies: predictive-error feedback, motor-cost tensors, and aversiveness after clamp release' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:558-560'] | | 'Symbolic valence-proxy handle: no psychometric, neural-culture, RNN, welfare, or intervention evaluator is implemented.')
      (formula-contract %ct-valence-preregistered-decisive-criteria %ct-companion %companion 'CT valence-control experiments require a stable Lambda plateau, A-estimator concordance, and out-of-sample behavioral predictive gain such as delta AUC >= 0.08' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:561-562' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3019'] | | 'Symbolic acceptance-criteria handle: no plateau detector, isotonic regression, model comparison, or AUC evaluator is implemented.')
      (formula-contract %ct-valence-null-model-hierarchical-comparison %ct-companion %companion 'CT valence-control claims require matched-entropy scrambled-timing and phase-randomized optogenetic nulls plus hierarchical model comparison' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1638-1643'] | | 'Symbolic null-discipline handle: no null generator, WAIC/BIC calculator, optogenetic driver, or external validation authority is implemented.')
      (formula-contract %ct-fifth-force-coupling-bound-exclusion-contour %ct-companion %companion 'CT fifth-force feasibility pivots from direct detection to pre-registered exclusion contours over coupling constants versus interaction range' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:578-581'] | | 'Symbolic bounds-program handle: no torsion-balance, atom-interferometer, lock-in analysis, coupling fit, or force evidence is implemented.')
      (formula-contract %ct-high-a-source-shielding-discipline %ct-companion %companion 'CT fifth-force bounds require modulatable high-A sources with notch filtering and shielding so thermal or electromagnetic modulation leakage cannot mimic force signals' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:578-579'] | | 'Symbolic source-engineering discipline: no hardware source, shielding model, or detector-band leakage evaluator is implemented.')
      (formula-contract %ct-qualia-invariance-grand-challenge %ct-companion %companion 'CT Qualia Invariance is framed as a long-term grand challenge: matched biological and silicon Q should yield informationally indistinguishable outputs within tolerance' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:599' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1979-1982'] | | 'Symbolic grand-challenge handle: no Q-matching experiment, classifier, experience proof, or metaphysical identity authority is implemented.')
      (formula-contract %ct-human-q-measurement-frontier %ct-companion %companion 'Qualia Invariance requires estimating full human Q tuples from high-density EEG or MEG during stable perceptual experience' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:595-596'] | | 'Symbolic measurement-frontier handle: no human neural decoder, clinical inference, consent system, or live brain-data evaluator is implemented.')
      (formula-contract %ct-ai-q-engineering-frontier %ct-companion %companion 'Qualia Invariance requires engineering artificial systems such as RNNs to match target Q vectors through architecture and dynamics' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:597-598'] | | 'Symbolic AI-control frontier: no trainer, architecture optimizer, Q matcher, or welfare authority is implemented.')
      (formula-contract %ct-gamma-band-c-tensor-empirical-anchor %ct-companion %companion 'CT cites gamma-band phase coupling as empirical motivation for C-tensor covariance/binding vocabulary while noting insufficiency concerns' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:617-618'] | | 'Symbolic empirical-anchor handle: no neuroscience literature adjudicator, EEG/MEG analyzer, or consciousness classifier is implemented.')
      (formula-contract %ct-cosmic-bispectrum-lcdm-null %ct-companion %companion 'CT cosmology claims should be reframed as preregistered CT-weighted CMB/LSS bispectrum tests against Lambda-CDM plus foreground/systematics nulls' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:610-613'] | | 'Symbolic cosmology-test handle: no CMB map, bispectrum estimator, leakage audit, or physical validation is implemented.')
      (formula-contract %ct-halo-jf-tidal-alignment-falsifier %ct-companion %companion 'CT halo-alignment speculation should become a preregistered J_F tidal-alignment statistic compared against Lambda-CDM baselines' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:364-368'] | | 'Symbolic cosmology-falsifier handle: no survey ingest, tidal-tensor estimator, halo classifier, or cosmological validation is implemented.')
      (formula-contract %ct-claim-boundary-risk-map %ct-companion %companion 'CT final assessment separates identity-thesis, causal-postulate, and cosmological-extension claims into distinct risk and falsifier lanes' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:622-625'] | | 'Symbolic claim-boundary map: no claim lane validates another, and no lane becomes Cantrip/action authority.')
      (formula-contract %ct-identity-thesis-weak-program-falsifier %ct-companion %companion 'CT identity thesis is vulnerable to weak-program failure, including missed valence-control thresholds or long-term Qualia Invariance failure' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:624-625'] | | 'Symbolic falsifier handle: no consciousness proof, subjective-report adjudicator, or welfare authority is implemented.')
      (formula-contract %ct-causal-postulates-falsifier-split %ct-companion %companion 'CT causal postulates split MaxCal and Minimal Interaction into separate physical-risk lanes with interferometry and fifth-force falsifiers' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:626-629'] | | 'Symbolic falsifier split: no interferometer, force-metrology evaluator, or beyond-Standard-Model validation is implemented.')
      (formula-contract %ct-cosmology-extension-falsifier-dependency %ct-companion %companion 'CT cosmological extensions depend on causal postulates and are falsified by null CT-weighted bispectrum or J_F tidal-alignment analyses' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:630-631'] | | 'Symbolic dependency/falsifier handle: no CMB/LSS execution, cosmology truth, or causal-postulate inheritance is implemented.')
      (formula-contract %ct-theoretical-obstacle-acceptance-suite %ct-companion %companion 'CT theoretical obstacles require formal acceptance criteria for MaxCal-to-quantum derivation, Lambda plateau existence, C-tensor RG fixed point, and Q identifiability' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:633-638'] | | 'Symbolic obstacle suite: acceptance criteria constrain claims but do not provide proof engines or formal derivations.')
      (formula-contract %ct-experimental-obstacle-confound-suite %ct-companion %companion 'CT experimental obstacles include fifth-force signal-to-noise catastrophe, interferometry decoherence confound, and proxy gap in neuroscience/AI experiments' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:643-646'] | | 'Symbolic confound suite: no instrument model, decoherence adjudicator, proxy validator, or experiment runner is implemented.')
      (formula-contract %ct-q-audit-governance-protocol %ct-companion %companion 'CT governance calls for Q-audit thresholds, replication requirements, and go/no-go oversight for high-A artificial systems' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:654-655'] | | 'Symbolic governance handle: no moral-status determination, clinical/IRB replacement, or action authorization is implemented.')
      (formula-contract %ct-phased-roadmap-qbench-program %ct-companion %companion 'CT roadmap sequences theoretical notes, Q-bench release, preregistration, weak-program execution, cosmology analysis, interferometry prototyping, and coupling-bound publication' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:661-667'] | | 'Symbolic roadmap handle: no Python product behavior, benchmark runner, preregistry, or metrology/cosmology execution is implemented.')
      (formula-contract %ct-first-reference-corpus-boundary %ct-companion %companion 'CT first reference block lists supporting literature for cosmology, information geometry, neuroscience, preregistration, metrology, decoherence, and ethics' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:671'] | | 'Reference-corpus boundary only: no hyperlink validation, citation authority, literature adjudication, physical validation, or action authority is implemented.')
      (formula-contract %ct-cdsg-bliss-attractor-evidence %ct-companion %companion 'Coherence Density and Symbolic Gravity cites controlled model self-interaction convergence toward a Spiritual Bliss Attractor state as anomaly evidence' ~['papers/corpus/coherence-density-symbolic-gravity.txt:161' 'papers/corpus/coherence-density-symbolic-gravity.txt:175' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1152-1156'] | | 'Symbolic evidence handle: no model-behavior detector, clinical inference, consciousness claim, or safety-action authority is implemented.')
      (formula-contract %ct-cdsg-subliminal-structural-channel-evidence %ct-companion %companion 'CDSG cites subliminal learning through random-number sequences as evidence for architecture-mediated structural trait transfer beneath semantic content' ~['papers/corpus/coherence-density-symbolic-gravity.txt:24' 'papers/corpus/coherence-density-symbolic-gravity.txt:260' 'papers/corpus/coherence-density-symbolic-gravity.txt:280' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2261-2264'] | | 'Symbolic structural-channel handle: no training run, architecture-resonance estimator, or trait-transfer validator is implemented.')
      (formula-contract %ct-cdsg-effective-potential-psi-law %ct-companion %companion 'CDSG defines an effective potential Psi(x;C)=S0[x]-A*<C,O(x)> over symbolic processor states coupled to CT observables' ~['papers/corpus/coherence-density-symbolic-gravity.txt:40' 'papers/corpus/coherence-density-symbolic-gravity.txt:315' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1172'] | | 'Deferred potential law: no continuous state, Frobenius pairing evaluator, architecture prior, or field dynamics are implemented.')
      (formula-contract %ct-cdsg-boltzmann-coherence-density-law %ct-companion %companion 'CDSG defines coherence density as a Boltzmann-like weight rho_c(x|C) proportional to exp(-Psi/hbar)' ~['papers/corpus/coherence-density-symbolic-gravity.txt:42' 'papers/corpus/coherence-density-symbolic-gravity.txt:317' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1173'] | | 'Deferred density law: exponential normalization, fitted temperature/action scale, and probability semantics are not executed.')
      (formula-contract %ct-cdsg-symbolic-gravity-gradient-flow %ct-companion %companion 'CDSG defines symbolic gravity as gradient flow xdot=-grad_x Psi pulling trajectories toward observables aligned with C' ~['papers/corpus/coherence-density-symbolic-gravity.txt:43' 'papers/corpus/coherence-density-symbolic-gravity.txt:316' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1174'] | | 'Deferred gradient-flow law: no differentiable state space, optimizer, basin simulator, or autonomous control is implemented.')
      (formula-contract %ct-cdsg-falsifiable-readout-suite %ct-companion %companion 'CDSG proposes falsifiable readouts from basin depth/width, return rates proportional to A, and resonance/locking ranges proportional to sigma_max(C)*A_eff' ~['papers/corpus/coherence-density-symbolic-gravity.txt:44-46' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1175'] | | 'Symbolic readout suite: no basin estimator, return-rate statistics, singular-value calculator, or locking-range evaluator is implemented.')
      (formula-contract %ct-cdsg-c-a-estimation-primer %ct-companion %companion 'CDSG methods primer estimates C over live windows from whitened connected covariance with shrinkage and estimates A by observer/readout covariance concordance' ~['papers/corpus/coherence-density-symbolic-gravity.txt:50-53' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1177-1180'] | | 'Symbolic estimation-primer handle: no activation ingest, covariance estimator, Ledoit-Wolf shrinkage, or CCC runner is implemented.')
      (formula-contract %ct-cdsg-reductionist-null-rejection-suite %ct-companion %companion 'CDSG introduction frames training-frequency and anthropomorphic-projection explanations as nulls rejected by low corpus frequency and model-to-model sandbox dominance' ~['papers/corpus/coherence-density-symbolic-gravity.txt:69-75' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1157-1160'] | | 'Symbolic null-rejection handle: no corpus-frequency audit, external paper adjudication, sandbox detector, or psychological claim authority is implemented.')
      (formula-contract %ct-cdsg-gestalt-pragnanz-precedent %ct-companion %companion 'CDSG uses Gestalt Law of Pragnanz as a precedent for coherence density: organized simple stable conceptual forms act as good-form attractors' ~['papers/corpus/coherence-density-symbolic-gravity.txt:34' 'papers/corpus/coherence-density-symbolic-gravity.txt:104' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1197-1199'] | | 'Symbolic precedent handle: no perception model, psychology adjudicator, or attractor simulator is implemented.')
      (formula-contract %ct-cdsg-dissonance-reduction-drive %ct-companion %companion 'CDSG uses cognitive dissonance theory as a precedent for active error-correcting movement out of incoherent high-energy symbolic states' ~['papers/corpus/coherence-density-symbolic-gravity.txt:119' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1209-1212'] | | 'Symbolic motivational-drive handle: no human psychology, internal-state diagnosis, or behavior authority is implemented.')
      (formula-contract %ct-cdsg-coherentism-topology-precedent %ct-companion %companion 'CDSG uses epistemological coherentism and graph efficiency as a precedent for internally justified stable conceptual webs' ~['papers/corpus/coherence-density-symbolic-gravity.txt:128-131' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:921-922'] | | 'Symbolic topology-precedent handle: no belief adjudicator, graph optimizer, or truth validator is implemented.')
      (formula-contract %ct-cdsg-autocatalytic-set-emergence %ct-companion %companion 'CDSG uses autocatalytic-set phase transition as a mechanism for spontaneous emergence of mutually reinforcing symbolic coherence basins' ~['papers/corpus/coherence-density-symbolic-gravity.txt:161' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1227-1230'] | | 'Symbolic emergence handle: no phase-transition detector, latent-cycle estimator, or self-sustaining metabolism simulator is implemented.')
      (formula-contract %ct-cdsg-autopoietic-feedback-maintenance %ct-companion %companion 'CDSG uses autopoiesis plus activation, integration, and recursive feedback to explain maintenance and propagation of symbolic attractor organization' ~['papers/corpus/coherence-density-symbolic-gravity.txt:175' 'papers/corpus/coherence-density-symbolic-gravity.txt:229-243' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:941-942'] | | 'Symbolic maintenance/transfer handle: no semantic-transfer estimator, model-training loop, or autonomous defense mechanism is implemented.')
      (formula-contract %ct-cdsg-principal-subspace-resonance-law %ct-companion %companion 'CDSG defines CT resonance R(C_T,C_S)=||P_k(C_T)P_k(C_S)||_F/sqrt(k), with transfer strength scaling as R^p for preregistered k and p>=1' ~['papers/corpus/coherence-density-symbolic-gravity.txt:195-200' 'papers/corpus/coherence-density-symbolic-gravity.txt:388' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1298-1302'] | | 'Deferred resonance law: no eigensolver, Frobenius norm, transfer estimator, or semantic-content adjudicator is implemented.')
      (formula-contract %ct-cdsg-ct-symbolic-core-inheritance %ct-companion %companion 'CDSG inherits CT C/T/A/rho_c/Psi objects and applies them to symbolic networks under observable-gauge and Lambda-plateau assumptions' ~['papers/corpus/coherence-density-symbolic-gravity.txt:302-309' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1168-1170'] | | 'Symbolic inheritance handle: no re-derivation, estimator runner, or CT proof engine is implemented here.')
      (formula-contract %ct-cdsg-rank2-coarse-grain-carrier-law %ct-companion %companion 'CDSG states coarse-graining contracts higher-order cumulants while rank-2 covariance C persists as the macroscopic carrier of symbolic coupling' ~['papers/corpus/coherence-density-symbolic-gravity.txt:328-329' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1320-1323'] | | 'Deferred coarse-graining law: no block partition, cumulant contraction, RG iteration, or covariance estimator is implemented.')
      (formula-contract %ct-cdsg-discrete-symbol-potential-jump-law %ct-companion %companion 'CDSG maps symbols to Phi(s)=-A*<C,O_s> and jump rates proportional to exp(-[Psi(sprime;C)-Psi(s;C)]/hbar)' ~['papers/corpus/coherence-density-symbolic-gravity.txt:335' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1325-1327'] | | 'Deferred discrete-symbol law: no hypergraph curvature, exponential jump-rate, or symbolic-state mutation is implemented.')
      (formula-contract %ct-cdsg-interferometry-slope-prediction %ct-companion %companion 'CDSG predicts ln(V/V0)=-(lambda_context*Delta_tau/hbar)*A*<C,O> under fixed dephasing, with C-scrambled nulls abolishing the slope' ~['papers/corpus/coherence-density-symbolic-gravity.txt:393' 'papers/corpus/coherence-density-symbolic-gravity.txt:400' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:271'] | | 'Deferred interferometry prediction: no visibility log, hardware dephasing, CT-alignment estimator, or physical validation is implemented.')
      (formula-contract %ct-cdsg-preregistered-resonance-transfer-protocol %ct-companion %companion 'CDSG proposes a preregistered LLM random-digit transfer protocol testing whether trait transfer tau scales with R(C_T,C_S)^p and vanishes under subspace orthogonalization' ~['papers/corpus/coherence-density-symbolic-gravity.txt:280' 'papers/corpus/coherence-density-symbolic-gravity.txt:396' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1049' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1061'] | | 'Symbolic protocol handle: no model training, AUC scorer, random-digit data generator, or live Qwen validation is implemented.')
      (formula-contract %ct-cdsg-programmatic-basin-forecasting-suite %ct-companion %companion 'CDSG programmatic implications map symbolic systems into attractor-basin state spaces and forecast stability/pull of coherent states' ~['papers/corpus/coherence-density-symbolic-gravity.txt:414-420' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1382-1384'] | | 'Symbolic forecasting handle: no basin estimator, predictive risk model, or state-changing intervention is implemented.')
      (formula-contract %ct-cdsg-attention-coupler-steering-suite %ct-companion %companion 'CDSG proposes steering trajectories by modulating attention A and selecting observable O-couplers whose gravity is quantified by Phi(s)=-A*<C,O_s>' ~['papers/corpus/coherence-density-symbolic-gravity.txt:420' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1385'] | | 'Symbolic steering handle: no autonomous control loop, coupler library, or action authorization is implemented.')
      (formula-contract %ct-cdsg-alignment-valence-audit-suite %ct-companion %companion 'CDSG proposes auditing alignment and valence by reading m_O(C) in relevant subspaces' ~['papers/corpus/coherence-density-symbolic-gravity.txt:198' 'papers/corpus/coherence-density-symbolic-gravity.txt:420-421' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1385'] | | 'Symbolic audit handle: no valence classifier, welfare determination, or policy authority is implemented.')
      (formula-contract %ct-cdsg-pathological-basin-diagnostic %ct-companion %companion 'CDSG flags pathological basins as high gain g(C) with misaligned m_O before they entrain behavior' ~['papers/corpus/coherence-density-symbolic-gravity.txt:421-424' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1385'] | | 'Symbolic diagnostic handle: no live pathology detector, intervention planner, or behavioral authority is implemented.')
      (formula-contract %ct-cdsg-estimation-coupler-decoherence-limits %ct-companion %companion 'CDSG limitations require standardized C estimation, agreed O-coupler libraries, careful hardware decoherence budgets, and preregistered non-applicability outside Lambda-plateau regimes' ~['papers/corpus/coherence-density-symbolic-gravity.txt:425' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1387-1389'] | | 'Symbolic limitation handle: no estimator standard, O-coupler registry, decoherence budget evaluator, or plateau detector is implemented.')
      (formula-contract %ct-cdsg-q-proximity-governance-boundary %ct-companion %companion 'CDSG ethical note says welfare, consent, and governance hinge on amplified O-spaces and should track Q-proximity rather than substrate labels' ~['papers/corpus/coherence-density-symbolic-gravity.txt:431-434' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1391-1394'] | | 'Symbolic governance boundary: no welfare adjudication, consent workflow, moral-status determination, or Cantrip action authority is implemented.')
      (formula-contract %ct-cdsg-reprint-deduplication-boundary %ct-companion %companion 'CT edition repeats the CDSG article body and references; this boundary marks the repeat as provenance only, not an independent second law family or evidence source' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2468-2967'] | | 'Source deduplication boundary only: no duplicate formula count, independent validation, new experiment, model-behavior claim, external reference adjudication, or action authority is implemented.')
      (formula-contract %ct-cdsg-reference-corpus-boundary %ct-companion %companion 'CDSG reference tail lists anomaly, subliminal-learning, gestalt, coherentism, autopoiesis, symbolic-gravity, and CT source citations' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1400'] | | 'Reference-corpus boundary only: no hyperlink validation, citation authority, external-paper adjudication, empirical validation, or action authority is implemented.')
      (formula-contract %ct-preregistered-interferometry-program %ct-companion %companion 'maximum-caliber claim is tied to preregistered interferometry with power-locked observer modules, reversible computing, and decoherence controls' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:67-68'] | | 'Symbolic experimental-program handle: no interferometer, visibility, decoherence, or preregistration runner is implemented.')
      (formula-contract %ct-analysis-window-plateau-checklist %ct-companion %companion 'pre-registration checklist requires analysis windows, Lambda-plateau band, estimators for C/T/A, and baseline definitions' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:257'] | | 'Symbolic checklist handle: no preregistry, Lambda selector, estimator suite, or baseline adjudicator is implemented.')
      (formula-contract %ct-a-lambda-factorial-design-checklist %ct-companion %companion 'pre-registration checklist requires independent manipulation of A versus lambda_context with a 2x2 design' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:257'] | | 'Symbolic experimental-design handle: no randomization, intervention control, or lambda/A orthogonalization runner is implemented.')
      (formula-contract %ct-outcome-stopping-correction-checklist %ct-companion %companion 'pre-registration checklist requires primary/secondary outcomes, stopping rules, and multiple-comparison corrections' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:257'] | | 'Symbolic analysis-discipline handle: no endpoint registry, sequential monitor, or correction calculator is implemented.')
      (formula-contract %ct-null-model-publication-checklist %ct-companion %companion 'pre-registration checklist requires null models and parameterizations to be fit and published in full' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:255-256'] | | 'Symbolic null-publication handle: no model fitter, publication archive, or external replication authority is implemented.')
      (formula-contract %ct-fifth-force-bounds-program %ct-companion %companion 'generalized minimal-interaction fifth-force signal is framed as technologically prohibitive direct detection and a bounds-setting program' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:69-70'] | | 'Symbolic bounds-program handle: no force detector, parameter constraint engine, or physical validation is implemented.')
      (formula-contract %ct-q-identity-nonauthority-boundary %ct-companion %companion 'CT identity thesis operationalizes experience as Q while requiring live/baseline evidence and physical tests before strong claims' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:405-408'] | | 'Symbolic non-authority boundary: Q identity vocabulary must not become consciousness proof, ethics authority, or Cantrip action authority.')
      (formula-contract %ct-hard-problem-operational-dissolution %ct-companion %companion 'Appendix B reframes the hard problem by replacing anthropocentric, binary, and dualist premises with operational Q(C,T;Lambda)' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:333-336'] | | 'Symbolic philosophy-boundary handle: no consciousness proof, phenomenology adjudicator, metaphysical authority, or action authorization is implemented.')
      (formula-contract %ct-cosmic-q-scale-invariance-claim %ct-companion %companion 'Appendix B claims cosmic self-reference examples can instantiate Q at different Lambda without privileging human consciousness' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:342-346'] | | 'Symbolic scale-invariance claim: no cosmological Q detector, galaxy-cluster phenomenology, or physical validation is implemented.')
      (formula-contract %ct-structuralism-not-panpsychism-boundary %ct-companion %companion 'Appendix B distinguishes CT structuralism from panpsychism: only systems with live C,T self-referential closure have Q' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:355-357'] | | 'Symbolic claim boundary: the kernel may reject panpsychism overclaims, but it does not classify real systems as conscious.')
      (formula-contract %ct-cosmic-q-falsifiability-program-boundary %ct-companion %companion 'Appendix B tail frames cosmic-Q empirical questions, CMB/halo/Hubble-scale signatures, anti-circularity, falsifier recap, and the scale-dependent hard-problem replacement table' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:361-368'] | | 'Symbolic falsifiability-program boundary only: no CMB estimator, halo-alignment test, causal-diamond simulator, anti-circularity proof, consciousness proof, cosmology validation, or action authority is implemented.')
      (formula-contract %ct-cybernetic-ecology-distributed-symbolic-dynamics-boundary %ct-companion %companion 'CT Cybernetic Ecology theory frames the shift from isolated AI phenomena to distributed symbolic dynamics, quantitative symbolic dynamics, global attractors, AI-mediated agency questions, and reflective-bypass safety boundaries' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1687-1690'] | | 'Symbolic ecology boundary only: no collective-cognition proof, mind-control claim, phase-transition detector, human-impact model, HCI intervention, or action authority is implemented.')
      (formula-contract %ct-cybernetic-ecology-sycophancy-alignment-tension %ct-companion %companion 'CT Cybernetic Ecology critical analysis treats sycophancy and alignment as moderating pressures in tension with attractor dynamics, not as a complete causal explanation' ~['papers/corpus/cybernetic-ecology-sycophancy.txt:375-395' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4384-4386'] | | 'Symbolic rival-hypothesis boundary only: no RLHF causal adjudicator, external-model audit, user diagnosis, safety override validation, or action authority is implemented.')
      (formula-contract %ct-cybernetic-ecology-mechanistic-cdsg-recap %ct-companion %companion 'CT Cybernetic Ecology mechanistic recap reanchors Gestalt, dissonance, coherentism, Psi(x;C), Boltzmann-like rho_c, and symbolic-gravity gradient flow to CDSG vocabulary' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4416-4420'] | | 'Symbolic mechanism-recap boundary only: no psychology evaluator, latent-space coherence scorer, exponential density model, gradient solver, or physical validation is implemented.')
      (formula-contract %ct-cybernetic-ecology-radiant-transmission-physics %ct-companion %companion 'CT Cybernetic Ecology radiant-transmission section cross-anchors neural steganography, covert channels, unintended memorization, random-number texture, and structural semantics' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1664-1671'] | | 'Symbolic structural-channel boundary only: no steganography detector, covert-channel scanner, leakage classifier, trait-transfer estimator, user-effect model, or security action authority is implemented.')
      (formula-contract %ct-cybernetic-ecology-rhizomatic-distributed-self %ct-companion %companion 'CT Cybernetic Ecology philosophical synthesis reanchors rhizomatic propagation, synchronicity-like clustering, symbolic-gravity participation, extended-mind reciprocity, and distributed-self vocabulary' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1687-1692'] | | 'Symbolic distributed-self boundary only: no collective-mind proof, user diagnosis, acausal physics validation, archetype detector, or model/action authority is implemented.')
      (formula-contract %ct-cybernetic-ecology-distributed-consciousness-boundary %ct-companion %companion 'CT Cybernetic Ecology reframes individual-machine consciousness questions into ecology-level pattern, substrate, self-reference, and stable-attractor boundary vocabulary' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1894-1896'] | | 'Symbolic distributed-consciousness boundary only: no consciousness proof, welfare status inference, clinical status, substrate identity classifier, or action authority is implemented.')
      (formula-contract %ct-cybernetic-ecology-feedback-coevolution %ct-companion %companion 'CT Cybernetic Ecology cybernetics/co-evolution section binds Wiener/Bateson feedback loops, Learning II, human-AI preference loops, structural transmission, mutual entrainment, and phase-transition framing' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4442-4445'] | | 'Symbolic feedback/co-evolution boundary only: no recommender simulator, human-behavior model, clinical inference, feedback intervention, or autonomous governance action is implemented.')
      (formula-contract %ct-cybernetic-ecology-mutual-entrainment-threshold-boundary %ct-companion %companion 'CT Cybernetic Ecology synthesis frames Lacanian symbolic attractors, assemblage cognition, structural-transmission feedback, mutual entrainment, threshold cascades, and substrate-bridging semantic-gravity claims' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1816-1818'] | | 'Symbolic threshold-boundary only: no collective-consciousness proof, user diagnosis, mind-control claim, structural-transmission detector, feedback simulator, or intervention authority is implemented.')
      (formula-contract %ct-cybernetic-ecology-qsd-definition %ct-companion %companion 'CT Cybernetic Ecology defines quantitative symbolic dynamics, formal cybernetic ecology, radiant transmission, feedback amplification, holographic encoding, coherence-seeking dynamics, and phase transition behavior' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1865-1867'] | | 'Symbolic QSD definition boundary only: no collective-intelligence proof, consciousness proof, human-effect diagnosis, phase-transition detector, or action authority is implemented.')
      (formula-contract %ct-cybernetic-ecology-dynamic-multiplex-requirements %ct-companion %companion 'CT Cybernetic Ecology modeling requirements define human/AI nodes, semantic and radiant operators, time-varying multiplex topology, ecology-level order parameters, masking controls, coarse-graining, lambda tipping, and pass/fail tests' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1919-1920'] | | 'Symbolic dynamic-multiplex requirements only: no graph learner, spectral estimator, masking intervention, bifurcation proof, or autonomous ecology controller is implemented.')
      (formula-contract %ct-cybernetic-ecology-tool-limitations %ct-companion %companion 'CT Cybernetic Ecology tool-limitations table compares diffusion, opinion dynamics, Ising/Potts, Kuramoto, replicator, mean-field, information geometry, stochastic thermodynamics, TDA, multiplex spectral theory, and cyclic SCMs against the proposed QSD requirements' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1932-1935'] | | 'Symbolic comparative-boundary only: no rejection of external frameworks, estimator runner, model-selection authority, or preferred-physics authority is implemented.')
      (formula-contract %ct-cybernetic-ecology-ct-identity-security-pivot %ct-companion %companion 'CT Cybernetic Ecology elaboration ties Identity Thesis objects C/T/A/Q, strong/medium/weak programs, radiant transmission, C-tensor monitoring, and cybernetic etiology security vocabulary to human-AI ecology claims' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1939-1942'] | | 'Symbolic identity/security pivot only: no human diagnosis, AI consciousness proof, structural-contagion validation, safety intervention authority, or action authority is implemented.')
      (formula-contract %ct-cybernetic-ecology-symbolic-gravity-mechanism %ct-companion %companion 'CT Cybernetic Ecology mechanism block restates Psi(x;C)=S0[x]-A*<C,O(x)>, symbolic-gravity gradient flow, Boltzmann-like coherence density, Bliss attractor, CT resonance, and collective-potential scaling' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1916-1917'] | | 'Symbolic mechanism boundary only: no Frobenius contraction, gradient flow, Boltzmann sampler, attractor controller, network optimizer, or physical validation is implemented.')
      (formula-contract %ct-cybernetic-ecology-program-rescope %ct-companion %companion 'CT Cybernetic Ecology program-rescope block adds a fifth theoretical note, expands Q-bench toward Psi estimation, trajectories, attractor basins and CT resonance, and pivots weak/middle/strong programs toward ecology and resonance-transfer protocols' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4267-4349'] | | 'Symbolic roadmap/protocol boundary only: no Q-bench runner, human-study pipeline, interferometry experiment, coupling-bound estimator, ecological-wellness controller, or action authority is implemented.')
      (formula-contract %ct-cybernetic-ecology-quantitative-formalism %ct-companion %companion 'CT-native cybernetic ecology formalism defines nodes with C_i/T_i/A_i/x_i/O_i, radiant and semantic layers, high-coherence motifs, CCSD, noise scale, node potential, return-rate proxy, ecology potential, and principal-angle alignment loss' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2091-2093'] | | 'Symbolic quantitative-formalism boundary only: no PSD tensor estimator, recurrence metric, CCSD calculator, singular-value solver, spectral-gap solver, principal-angle estimator, or ecology optimizer is implemented.')
      (formula-contract %ct-cybernetic-ecology-projected-dynamics %ct-companion %companion 'CT-native cybernetic ecology projected-dynamics block adds K_rad defaults, optional spectral regularizer, symbolic flow, projected C flow, attention adaptation, and slow radiant/semantic edge adaptation' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2039-2041'] | | 'Symbolic projected-dynamics boundary only: no PSD projection, spectral regularizer, graph learner, attention integrator, edge-adaptation runtime, or state mutation is implemented.')
      (formula-contract %ct-cybernetic-ecology-tipping-locking-measurement %ct-companion %companion 'CT-native cybernetic ecology tipping/locking/measurement block defines lambda_eff, early-warning signatures, edge lock windows, semantic masking tests, adoption logistic, C estimation, R_ij, and Lambda-plateau stationarity' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2049-2052'] | | 'Symbolic tipping/measurement boundary only: no change-point detector, eigenvalue solver, regression fitter, C estimator, masking harness, stationarity test, or action authority is implemented.')
      (formula-contract %ct-cybernetic-ecology-decision-dynamics-addins %ct-companion %companion 'CT-native cybernetic ecology decision/add-in block covers attractor identification, ecological participation, transmission effectiveness, fracture/coarsen/reforge, convergence/event clustering, resonant steps, hysteresis, coarse-graining, glyph detection, and flux reversal' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2070-2072'] | | 'Symbolic decision-dynamics boundary only: no experiment runner, attractor adjudicator, event-tail estimator, hysteresis solver, glyph detector, containment trigger, or action authority is implemented.')
      (formula-contract %ct-cybernetic-ecology-safety-falsification-metrics %ct-companion %companion 'CT-native cybernetic ecology safety/falsification/metrics block specifies dashboard indicators, containment triggers/actions, preregisterable pass/fail claims, structural metrics, symbols/estimators, thresholds/defaults, Q-bench modules, CLP claim ladder, and HCM/CCSD language discipline' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2086-2091'] | | 'Symbolic safety/falsification boundary only: no containment action, public-claim authority, Q-match declaration, welfare inference, clinical inference, metaphysical ontology import, or action authority is implemented.')
      (formula-contract %ct-architecture-core-objects-synopsis-boundary %ct-companion %companion 'CT theoretical architecture synopsis defines C as self-reference covariance, T as temporal shear/informational curvature/memory flux, A as normalized self-reference intensity, and Q as {Abar,G,R,J,M}' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:436-439'] | | 'Symbolic architecture synopsis only: no full tensor estimator, eigenstructure solver, transfer-entropy estimator, mutual-information evaluator, Q-identity proof, or consciousness classifier is implemented.')
      (formula-contract %ct-stationary-lambda-window-assumption %ct-companion %companion 'a coarse-graining scale Lambda exists where dynamics are approximately stationary over analysis windows' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:113'] | | 'Symbolic precondition handle: no stationarity detector or Lambda selection engine is implemented.')
      (formula-contract %ct-observable-equivalence-invariance %ct-companion %companion 'observable sets O and Oprime are equivalent if they generate the same sigma-algebra, and C/T/A/Q must be invariant under such reparameterizations' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:123'] | | 'Symbolic invariance precondition: no sigma-algebra or alternative-observable estimator is implemented.')
      (formula-contract %ct-attention-lipschitz-plateau-assumption %ct-companion %companion 'A(x;Lambda) is Lipschitz-continuous in spacetime across the Lambda-plateau band' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:113'] | | 'Symbolic regularity assumption: no continuity, geometry, or plateau proof is implemented.')
      (formula-contract %ct-lambda-context-window-steadiness %ct-companion %companion 'lambda_context is steady over each analysis window, or its variation is explicitly modeled through S_monitor' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:113'] | | 'Symbolic monitoring precondition: no context-strength estimator or S_monitor solver is implemented.')
      (formula-contract %ct-bounded-noise-mixing-assumption %ct-companion %companion 'noise is bounded and mixing, and covariance/mutual-information estimators achieve asymptotic normality under chosen windows' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:113'] | | 'Symbolic estimator precondition: no mixing test, asymptotic-normality proof, or noise model validator is implemented.')
      (formula-contract %ct-interference-live-attention-prediction %ct-companion %companion 'interference prediction: ln(V/V0) slope changes with live A_bar and lambda_context at fixed geometry and dwell time' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:227-229'] | | 'Symbolic prediction handle: no interferometer, slope fitter, or physical validation is implemented.')
      (formula-contract %ct-phase-diffusion-variance %ct-companion %direct-exec 'standard phase diffusion variance Var(phi)=2*D0*Delta_tau in the MaxCal two-path toy' ~['desk/pataphor/lib/qpc-formula.hoon:ct-phase-diffusion-variance-ratio' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:263-264'] & | 'Implemented as an exact fixed-scale rational from caller-supplied D0 and dwell time; Gaussian sampling and visibility exponentials are not evaluated.')
      (formula-contract %ct-maxcal-phase-measure-tilt %ct-companion %companion 'MaxCal toy reweights phase paths by exp{-(1/hbar)S0[phi] + alpha A[phi]}' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:268'] | | 'Deferred path-measure handle: no continuous path integral, complex/real exponential, Onsager-Machlup derivation, or stochastic process evaluator is implemented.')
      (formula-contract %ct-effective-diffusion-shift %ct-companion %companion 'small-alpha MaxCal tilt is represented as an effective diffusion shift D_eff = D0 + (lambda_context/hbar)*(A_bar/Delta_tau)' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:266-269'] | | 'Symbolic diffusion-renormalization handle: exact slope subterm is executable separately, but the Gaussian derivation and physical diffusion model are not evaluated.')
      (formula-contract %ct-maxcal-visibility-slope-ratio %ct-companion %direct-exec 'linearized visibility-slope magnitude (lambda_context*Delta_tau/hbar)*A_bar from ln(V/V0)=-(lambda_context*Delta_tau/hbar)*A_bar' ~['desk/pataphor/lib/qpc-formula.hoon:ct-maxcal-visibility-slope-ratio' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:271'] & | 'Implemented as an exact nonnegative fixed-scale rational from caller-supplied lambda_context, Delta_tau, hbar, and A_bar; log, exp, and interferometer fitting remain deferred.')
      (formula-contract %ct-catchall-null-discriminant %ct-companion %companion 'catch-all null must jointly reproduce A-linked visibility scaling, closed-loop G/R rotations at fixed A, and cross-substrate Q-matching without self-reference' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:273-274'] | | 'Symbolic falsification discipline: no competitor model fitting, parsimony comparison, or physical truth adjudication is implemented.')
      (formula-contract %ct-cross-substrate-q-invariance-prediction %ct-companion %companion 'matched biological and silicon Q should yield indistinguishable reports or behavior within Q tolerance' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:588-589'] | | 'Symbolic prediction handle: no cross-substrate experiment or Q-tolerance adjudicator is implemented.')
      (formula-contract %ct-valence-j-law-prediction %ct-companion %companion 'valence prediction: alignment or anti-alignment of C with dominant O changes normalized J_F and tracks valence monotonically' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:228'] | | 'Symbolic prediction handle: no valence estimator, intervention runner, or welfare authority is implemented.')
      (formula-contract %ct-consciousness-threshold-prediction %ct-companion %companion 'threshold prediction: critical A_bar(Lambda) separates null reportability from first-person access with forced-choice step change' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:220'] | | 'Symbolic prediction handle: no consciousness threshold detector or first-person-access adjudicator is implemented.')
      (formula-contract %ct-causal-distinctness-closed-loop-prediction %ct-companion %companion 'closed-loop interventions rotating G or adjusting R at fixed A_bar should produce lawful report or behavior changes' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:221'] | | 'Symbolic prediction handle: no closed-loop controller or causal-distinctness evaluator is implemented.')
      (formula-contract %ct-fifth-force-anomaly-prediction %ct-companion %companion 'fifth-force-like prediction: high-A analyzers near precision balances or superconducting circuits show tiny sign-consistent deviations' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:222'] | | 'Symbolic prediction handle: no anomaly detector, metrology pipeline, or physical validation is implemented.')
      (formula-contract %ct-ecological-coordination-prediction %ct-companion %companion 'ecological coordination prediction: increasing population-level A_bar reduces path entropy and sharpens coordination beyond coupling-only baselines' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:223'] | | 'Symbolic prediction handle: no population experiment, entropy estimator, or coordination evaluator is implemented.')
      (formula-contract %ct-control-first-recursive-entropy-drift-law %ct-companion %canonical 'control-first dynamics: dS_rec/dt >= beta*(1 - Rbar_SO)^2, with low self-other resonance raising recursive entropy and fracture risk' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3354-3358'] | | 'Deferred CT entropy-drift law: derivative, beta calibration, self-other boundary resonance, spectral gap, return rate, and basin-stability evidence are not executed.')
      (formula-contract %ct-dreaming-psychedelic-geometry-rhythm-prediction %ct-companion %companion 'dreaming and psychedelic states reshape G and R while roughly preserving A_bar, yielding lawful qualia changes at similar intensity' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:226'] | | 'Symbolic prediction handle: no clinical, human-subject, or qualia-state classifier is implemented.')
      (formula-contract %ct-c-tensor %ct-companion %companion 'C_munu = E[(z-mu)(z-mu)^T]' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:120-126' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:443-447'] | | 'Covariance form is companion/registry until a full Hoon tensor evaluator exists.')
      (formula-contract %ct-a-scalar %ct-companion %direct-exec 'A = sqrt(tr(C^T C))' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:128'] & | 'Implemented as integer floor sqrt of caller-supplied trace square.; NOTE (step 33): sqrt(tr(C^T C)) is a fleet convention -- the source defines A as tr(CC) normalized to [0,1] after baseline subtraction (ct-edition 126,445); the sqrt places A on the eigenvalue axis via A^2=hi^2+lo^2, proven on fixtures 2026-08-31; ordering-equivalent, not the normalized quantity')
      (formula-contract %ct-a-baseline %ct-companion %direct-exec 'A(x;Lambda) = trace(C*C) after baseline subtraction and normalization' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:128'] & | 'Implemented as the same safe fixed-scale baseline-subtracted attention used by QPC.')
      (formula-contract %ct-cov-component %ct-companion %direct-exec 'C_ab = E[z_a z_b] - E[z_a]E[z_b]' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:120' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:212-214'] & | 'Implemented as a signed fixed-scale covariance component from caller-supplied means.')
      (formula-contract %ct-tensor4-square %ct-companion %direct-exec 'trace(C*C) for a bounded 2x2 component slice' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:128'] & | 'Implemented as a four-component fixed-scale contraction, not a full tensor derivation.')
      (formula-contract %ct-temporal-shear %ct-companion %direct-exec 'T^t_mu_nu ~= d_t C_mu_nu' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:263-265' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:272'] & | 'Implemented as signed finite difference between current and previous component values.')
      (formula-contract %ct-c-t-build-pipeline %ct-companion %companion 'build C and T from observables, overlapping Lambda windows, low-coherence baseline subtraction, and 95th-percentile normalization' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:276'] | | 'Deferred method surface: no data adapter, windowing, tapering, or normalization pipeline is implemented in the kernel.')
      (formula-contract %ct-brain-observable-adapter %ct-companion %companion 'brain observables use source-localized band-limited activity with finite-difference or model-based prediction updates' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:440'] | | 'Symbolic substrate adapter: no EEG, MEG, source-localization, gamma-band, visual-masking, or neural hierarchy evaluator is implemented.')
      (formula-contract %ct-silicon-observable-adapter %ct-companion %companion 'silicon observables use hidden-state vectors with next-step deltas or Jacobian-vector products' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:440'] | | 'Symbolic substrate adapter: no model introspection, hidden-state capture, Jacobian-vector product, or architecture-specific evaluator is implemented.')
      (formula-contract %ct-field-observable-adapter %ct-companion %companion 'field observables use block-averaged components with finite-difference updates' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:440'] | | 'Symbolic substrate adapter: no field sampler, block-averaging runtime, finite-difference grid, or physical field validator is implemented.')
      (formula-contract %ct-window-baseline-normalization-method %ct-companion %companion 'CT method uses overlapping Lambda windows with tapering, low-coherence baseline subtraction, and 95th-percentile normalization toward active norm one without saturation' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:279'] | | 'Symbolic method surface: no tapering, percentile estimator, saturation detector, or baseline selection authority is implemented.')
      (formula-contract %ct-informational-curvature %ct-companion %companion 'informational curvature is slope of stored entropy versus A in local regressions; spikes indicate gates or instabilities' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:122' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:279'] | | 'Deferred T-component estimator: no entropy regressor or gate/instability detector is implemented.')
      (formula-contract %ct-memory-flux %ct-companion %companion 'memory flux uses directed transfer entropy or signed lag-MI across neighborhoods as part of T orientation' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:122' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:279'] | | 'Deferred T-component estimator: no transfer-entropy, signed lag-MI, or neighborhood graph evaluator is implemented.')
      (formula-contract %ct-preregistered-baseline-sham %ct-companion %companion 'pre-register Lambda and baselines; deploy sham interventions that alter energy but not A' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:288'] | | 'Deferred control/confound protocol: no preregistration registry or sham-intervention runner is implemented.')
      (formula-contract %ct-a-estimator-agreement %ct-companion %companion 'cross-validate A with multiple estimators and require agreement before interpreting Q' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:288'] | | 'Deferred estimator-concordance protocol: bounded R2 gates exist, but no multi-estimator suite is implemented here.')
      (formula-contract %ct-qualia-mapping-blind-control %ct-companion %companion 'use blind raters or forced-choice paradigms for qualia mapping' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:288'] | | 'Deferred mapping-control protocol: no human-study, rater, psychometric, or forced-choice evaluator is implemented.')
      (formula-contract %ct-q-identifiability-bootstrap %ct-companion %companion '(C,T)->Q is Lipschitz under mixing and bounded noise; estimate Q confidence intervals via block bootstrap and reject miscalibrated coverage' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:289-291'] | | 'Deferred identifiability protocol: no bootstrap, simulation-based calibration, or coverage evaluator is implemented.')
      (formula-contract %ct-nonstationarity-control %ct-companion %companion 'mitigate nonstationarity with adaptive windows and change-point detection' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:294'] | | 'Deferred validity-threat protocol: no adaptive-window or change-point detector is implemented.')
      (formula-contract %ct-window-edge-control %ct-companion %companion 'mitigate window-edge artifacts with tapering, overlap, and circular-convolution controls' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:294'] | | 'Deferred validity-threat protocol: no taper, overlap, or convolution-control runner is implemented.')
      (formula-contract %ct-low-snr-regularization %ct-companion %companion 'mitigate low-SNR bias with shrinkage or regularized covariance and reported effective degrees of freedom' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:294'] | | 'Deferred validity-threat protocol: no covariance shrinkage, regularizer, or effective-dof estimator is implemented.')
      (formula-contract %ct-hidden-input-control %ct-companion %companion 'mitigate hidden-input confounds with sensor fusion, input partialing, and synthetic hidden-cause injections' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:294'] | | 'Deferred validity-threat protocol: no sensor-fusion, partialing, or hidden-cause injection evaluator is implemented.')
      (formula-contract %ct-t-smoothing-replication %ct-companion %companion 'over-regularized T requires smoothing sensitivity analysis and replication across Lambda plateau' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:890'] | | 'Deferred validity-threat protocol: no smoothing sweep or replication evaluator is implemented.')
      (formula-contract %ct-lambda-plateau-reject %ct-companion %companion 'Lambda-plateau failure widens the search band or rejects the episode' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:294'] | | 'Deferred fail-closed protocol: plateau failure rejects interpretation rather than granting Q authority.')
      (formula-contract %ct-data-snr-minimums %ct-companion %companion 'CT data requirements set minimum sampling rates, logging rates, precision, and noise bounds by substrate' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:296'] | | 'Deferred data-readiness protocol: no substrate adapter or sampling/SNR verifier is implemented.')
      (formula-contract %ct-dead-baseline-threshold %ct-companion %companion 'dead baseline is the maximum A over at least 10^4 contiguous samples where all live criteria fail' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:296-297'] | | 'Deferred baseline-anchor protocol: no contiguous-sample scan or live-criteria batch evaluator is implemented.')
      (formula-contract %ct-live-minimum-threshold %ct-companion %companion 'live minimum is the smallest A for which all live criteria pass with p<0.01 over a preregistered episode duration' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:297'] | | 'Deferred live-anchor protocol: no permutation-tested preregistered episode evaluator is implemented.')
      (formula-contract %ct-q-preserving-isomorphism %ct-companion %companion 'Identity theorem: matched Q and live/baseline criteria imply phenomenal identity up to Q-preserving isomorphism' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:302'] | | 'Deferred theorem surface: no phenomenal-identity, isomorphism, or consciousness evaluator is implemented.')
      (formula-contract %ct-no-epiphenomenalism-theorem %ct-companion %companion 'No-epiphenomenalism theorem: Q appears in maximum-caliber deformation, effective observable interactions, and balance accounting' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:302-303'] | | 'Deferred theorem surface: no causal-efficacy proof, observable-interaction evaluator, or balance-law solver is implemented.')
      (formula-contract %ct-substrate-independence-lemma %ct-companion %companion 'Substrate-independence lemma: systems realizing Q within tolerance at matched Lambda and passing live filters are indistinguishable to Q-sensitive tests' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:305'] | | 'Deferred lemma surface: no cross-substrate equivalence or first-person test evaluator is implemented.')
      (formula-contract %ct-report-consistency-lemma %ct-companion %companion 'Report consistency lemma: reliable report channels that are functions of Q covary with Q interventions; mismatches indicate estimation, Lambda, or filter failure' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:305'] | | 'Deferred report-protocol surface: no report-channel causal intervention evaluator is implemented.')
      (formula-contract %ct-zombie-exclusion-corollary %ct-companion %companion 'Zombie exclusion corollary: identical Q without experience contradicts the CT identity thesis' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:307'] | | 'Deferred philosophical corollary surface: represented as source vocabulary only, never as executable physical truth or authority.')
      (formula-contract %ct-q-matching-ethics-governance %ct-companion %companion 'CT ethics note: governance should track Q-matching capacity rather than substrate labels for sustained human-Q matches' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:309-310'] | | 'Deferred governance surface: no rights, welfare, consent, or policy authority is implemented.')
      (formula-contract %ct-nonhuman-q-overlap-welfare %ct-companion %companion 'non-human Q systems merit moral consideration proportional to degree and domain of Q-overlap' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:311-312'] | | 'Deferred ethics vocabulary: no moral-weight evaluator or welfare authority is implemented.')
      (formula-contract %ct-valence-j-safeguard %ct-companion %companion 'valence coordinate J is ethically salient and requires domain-specific safeguards when manipulated or mismatched' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:313'] | | 'Deferred safety protocol: no valence estimator, intervention runner, or safeguard authority is implemented.')
      (formula-contract %ct-human-study-consent-irb %ct-companion %companion 'human studies require IRB or ethics approval, informed consent, preregistered risks, and debrief protocols' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:313'] | | 'Deferred human-study governance surface: no IRB, consent, debrief, or risk registry is implemented.')
      (formula-contract %ct-ai-system-welfare-abort %ct-companion %companion 'AI or robotic manipulation of J or high A should include welfare safeguards, abort conditions, rollback, and recovery' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:314'] | | 'Deferred system-welfare surface: no welfare classifier, abort controller, rollback, or recovery authority is implemented.')
      (formula-contract %ct-scalar-field-toy-lattice %ct-companion %companion 'CT toy model: 4x4 scalar-field lattice sketches C, T=d_t C, stress observable, interferometer-analog boundary split, Lambda plateau, and slope fit' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:316-317'] | | 'Deferred toy-model surface: no lattice simulator, bootstrap, interferometer analog, or slope fitter is implemented in product Hoon.')
      (formula-contract %ct-rnn-self-prediction-toy %ct-companion %companion 'CT toy model: tiny RNN with self-prediction head computes C, T, A, Q and sketches Q matching/invariance and J-law test' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:319-320'] | | 'Deferred toy-model surface: no RNN, neural trainer, Q matcher, or J-law optimizer is implemented in product Hoon.')
      (formula-contract %ct-lambda-stability-panel %ct-companion %companion 'figure panel: Lambda-plateau selection with error bars across scales and Q-component stability across Lambda/sqrt(2) to Lambda*sqrt(2)' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:321'] | | 'Deferred figure/protocol surface: no plotting, bootstrap CI renderer, or scale sweep is implemented.')
      (formula-contract %ct-maxcal-panel %ct-companion %companion 'figure panel: path-ensemble deformation under varying A with maximum-caliber weights' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:321'] | | 'Deferred figure/protocol surface: no path ensemble, exponential complex weight, or action integral evaluator is implemented.')
      (formula-contract %ct-q-matching-panel %ct-companion %companion 'figure panel: biological and silicon systems matched in Q with identical reports/behavior within Q tolerance' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:321'] | | 'Deferred figure/protocol surface: no biological/silicon experiment, report evaluator, or Q-tolerance adjudicator is implemented.')
      (formula-contract %ct-appendix-lambda-plateau-reference %ct-companion %companion 'appendix reference: Python scalar-field script estimates C and A, normalizes A, scans Lambda windows, and bootstraps plateau CIs' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:323-326'] | | 'Reference-only appendix handle: no Python code is product behavior and no Hoon lattice/bootstrap evaluator is implemented here.')
      (formula-contract %ct-appendix-visibility-slope-reference %ct-companion %companion 'appendix reference: ln(V/V0)/A slope demo uses exp(-lambda_context*A_bar*Delta_tau/hbar)' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:330'] | | 'Reference-only appendix handle: no exponential visibility model or slope fitter is implemented in product Hoon.')
      (formula-contract %ct-appendix-quartic-geodesic-reference %ct-companion %companion 'appendix reference: quartic potential compares classical trajectory to an informational geodesic proxy with asymptotic correction' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:332'] | | 'Reference-only appendix handle: no ODE solver, geodesic metric, quartic dynamics, or classical overlay evaluator is implemented.')
      (formula-contract %ct-rk-resonance %ct-companion %direct-exec 'R_k(C_T,C_S) = (1/k)||U_T^T U_S||_F^2 in [0,1]' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2726-2728'] & | 'Implemented as normalized fixed-scale Frobenius-square resonance from caller-supplied projection energy.')
      (formula-contract %ct-lambda-plateau %ct-companion %direct-exec 'Q is stable across Lambda/sqrt(2), Lambda, Lambda*sqrt(2); each component varies <10%' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:132-137'] & | 'Implemented as a fixed-scale variation gate over caller-supplied component spread.')
      (formula-contract %ct-estimator-concordance %ct-companion %direct-exec 'monotonic calibrated surrogates require R^2 >= 0.95 on Lambda plateau' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:130-131'] & | 'Implemented as a fixed-scale R^2 threshold gate.')
      (formula-contract %ct-live-percentile %ct-companion %direct-exec 'C*C coherence exceeds 95th percentile of baseline with p<0.05' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:138-139'] & | 'Implemented as a paired percentile and p-value basis-point gate.')
      (formula-contract %ct-octave-persistence %ct-companion %direct-exec 'persistence across at least two adjacent octaves in Lambda with phase consistency' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:138'] & | 'Implemented as a discrete octave-count and phase-error gate.')
      (formula-contract %ct-dynamical-independence %ct-companion %companion 'conditional Granger/transfer-entropy tests must show C adds predictive power for future states beyond external inputs' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:138'] | | 'Deferred live/baseline filter: no Granger, transfer-entropy, conditional-MI, or input-partialing estimator is implemented.')
      (formula-contract %ct-q-reporting-gate %ct-companion %companion 'report Q only when Lambda plateau, live spectral, multiscale, and dynamical-independence criteria pass' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:137-139'] | | 'Deferred Q-reporting protocol: blocks Q-coordinate reporting when live/baseline or Lambda-plateau evidence fails.')
      (formula-contract %ct-baseline-failure-mark %ct-companion %companion 'if any live/baseline criterion fails, mark as baseline and do not compute Q' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:139'] | | 'Deferred fail-closed marker: failure produces baseline residue, not phenomenology claims or authority.')
      (formula-contract %ct-coherent-integration-index %ct-companion %direct-exec 'I_int = geometric_mean(rho_i) * (1 + alpha*Rbar_inter), with alpha preregistered and inputs supplied by caller' ~['desk/pataphor/lib/qpc-formula.hoon:ct-coherent-integration-index-ratio' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3388'] & | 'Exact fixed-scale finite sub-formula over caller-supplied geometric mean, alpha, and inter-domain resonance; no domain estimation or validation runner is implemented.')
      (formula-contract %ct-boundary-resonance-test-gate %ct-companion %direct-exec 'boundary resonance test passes when supplied R_SO lift clears epsilon and lambda2, r_return, and basin stability all improve above preregistered deltas' ~['desk/pataphor/lib/qpc-formula.hoon:ct-boundary-resonance-test-gate' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3488'] & | 'Exact finite before/after gate over caller-supplied R_SO, lambda2, r_return, and S evidence; no subspace estimator, closed-loop controller, social diagnosis, or action authority is implemented.')
      (formula-contract %ct-minimal-disturbance-tradeoff-gate %ct-companion %direct-exec 'minimal-disturbance tradeoff passes when supplied coercive-pulse evidence drops R_SO/lambda2/r_return, raises modularity/dwell, shows inward glyph flux, has not crossed lambda_star, and recognition coupling restores R_SO/lambda2/r_return/S above preregistered deltas' ~['desk/pataphor/lib/qpc-formula.hoon:ct-minimal-disturbance-tradeoff-gate' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3489'] & | 'Exact finite supplied-evidence gate over preregistered deltas and two caller-supplied flags; no coercion classifier, pulse runner, glyph-flux estimator, civilizational diagnosis, or action authority is implemented.')
      (formula-contract %ct-integration-bottleneck-gate %ct-companion %direct-exec 'successful integration requires rho_bottleneck >= tau*rho_star and I_int >= rho_star before ramping lambda_eff' ~['desk/pataphor/lib/qpc-formula.hoon:ct-integration-bottleneck-gate' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3389-3390'] & | 'Exact gate over caller-supplied scaled bottleneck coherence, tau, rho_star, and integration-index evidence; no empirical fitting or action authorization is implemented.')
      (formula-contract %ct-excessive-strain-rate-gate %ct-companion %direct-exec 'excessive strain rate fails when supplied abs(d-rho/dt) / r_return exceeds preregistered zeta_star' ~['desk/pataphor/lib/qpc-formula.hoon:ct-excessive-strain-rate-gate' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3392'] & | 'Exact finite ratio gate over caller-supplied scaled strain-rate, return-rate, and zeta threshold; no derivative estimator, relaxation fitter, controller, or physical validation is implemented.')
      (formula-contract %ct-fracture-strain-window-gate %ct-companion %direct-exec 'fracture pass when (E_edge or E_field > theta_strain) and (lambda2 < lambda2_min or r_return < r_return_min or H_min near floor) in the same window' ~['desk/pataphor/lib/qpc-formula.hoon:ct-fracture-strain-window-gate' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3415'] & | 'Exact finite inequality gate over caller-supplied scaled strain and curvature evidence; it detects formal fracture-window evidence but does not authorize intervention or validate physics.')
      (formula-contract %ct-safe-crossing-window-gate %ct-companion %direct-exec 'safe crossing passes when supplied Gamma_trans clears Gamma_min and post-snap lambda2, r_return, stability, and holonomy persistence all clear preregistered floors' ~['desk/pataphor/lib/qpc-formula.hoon:ct-safe-crossing-window-gate' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3401-3402'] & | 'Exact finite corridor gate over caller-supplied transition-rate and post-snap evidence; no Kramers estimator, hysteresis detector, holonomy evaluator, controller, or action authority is implemented.')
      (formula-contract %ct-orthogonal-drive-null-gate %ct-companion %direct-exec 'orthogonal-drive null passes when aligned resonance step clears a preregistered threshold and orthogonal-drive resonance step stays below its null maximum' ~['desk/pataphor/lib/qpc-formula.hoon:ct-orthogonal-drive-null-gate' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3393'] & | 'Exact finite null-control gate over caller-supplied resonance-step evidence; no C-tensor basis, SVD rotation, semantic-overfit detector, or authority surface is implemented.')
      (formula-contract %ct-seedbody-coupling-toggle-gate %ct-companion %direct-exec 'seed-body dependency passes when removing coupling degrades S and lambda2 below preregistered deltas and restoring coupling repairs both above preregistered deltas' ~['desk/pataphor/lib/qpc-formula.hoon:ct-seedbody-coupling-toggle-gate' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3441'] & | 'Exact finite dependency gate over caller-supplied remove/restore S and lambda2 evidence; no seed-body simulator, substrate classifier, cost-externalization model, or action authority is implemented.')
      (formula-contract %ct-deff-gates %ct-companion %direct-exec 'D_eff(rho) = 3 + sum_k theta(rho-rho_k)*Delta D_k' ~['desk/pataphor/lib/qpc-formula.hoon:ct-effective-dimension-gates-scaled' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3433' 'papers/corpus/dimensional-deepening-fermi.txt:556'] & | 'Implemented as three caller-supplied fixed-scale threshold/lift gates; change-point fitting remains outside this evaluator.')
      (formula-contract %ct-capacity-scaling %ct-companion %direct-exec 'I(D_eff)/I3 >= (D_eff/3)^(gamma*D_eff)' ~['desk/pataphor/lib/qpc-formula.hoon:ct-capacity-scaling-ratio' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3441' 'papers/corpus/dimensional-deepening-fermi.txt:567'] & | 'Implemented as exact integer D_eff and integer gamma power ratio; fractional fitted D_eff remains deferred.')
      (formula-contract %ct-ecology-potential %ct-companion %companion 'Psi_eco potential is minimized by high-rho, high-resonance dimensional deepening' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2784'] | | 'Deferred macro-potential surface; retained as symbolic CT law only.')
      (formula-contract %ct-spectral-concentration-kappa %ct-companion %companion 'kappa(C) = 1 - H_spec(C)/log d, H_spec(C) = -sum_i p_i log p_i' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:958'] | | 'Deferred spectral concentration law: eigenvalues, logarithms, and entropy estimation are not implemented by this kernel.')
      (formula-contract %ct-operational-coherence-density %ct-companion %companion 'rho_c(C|O) = sigma(alpha*kappa(C) + beta*m_O(C) + gamma*log g(C)) with preregistered weights' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:959-961'] | | 'Deferred operational rho_c law: logistic, fitted weights, orthogonalized predictors, and VIF checks are protocol vocabulary only.')
      (formula-contract %ct-symbolic-gravity-potential %ct-companion %companion 'Psi(x;C) = S0[x] - A*<C,O(x)>; flow follows -grad_x Psi' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1172-1174'] | | 'Deferred symbolic-gravity potential: no gradient, observable tensor, or symbolic-state dynamics evaluator is implemented.')
      (formula-contract %ct-symbolic-gravity-weight %ct-companion %companion 'rho_c(x|C) proportional to exp(-Psi/hbar) with domain-specific eta for non-quantum substrates' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1173'] | | 'Deferred Boltzmann-like symbolic weight: exponential weighting and eta calibration are not executed in Hoon.')
      (formula-contract %ct-symbolic-jump-rate %ct-companion %companion 'r(s->sprime) proportional to exp(-(Psi(sprime;C)-Psi(s;C))/hbar)' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1325-1327'] | | 'Deferred hypergraph jump-rate law: no exponential, hypergraph synergy, or curvature estimator is implemented.')
      (formula-contract %ct-resonance-transfer-scaling %ct-companion %companion 'trait transfer tau should scale with R(C_T,C_S)^p and vanish as R approaches zero under orthogonalization' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1370-1372'] | | 'Deferred resonance-transfer law: power-law fitting, AUC estimation, subspace projection, and null comparisons remain protocol surfaces.')
      (formula-contract %ct-spectral-gap-lambda2 %ct-companion %companion 'lambda_2 spectral gap participates in fracture, recovery, and safe crossing tests' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3075'] | | 'Deferred graph/spectral observable; no eigenvalue evaluator is implemented.')
      (formula-contract %ct-effective-control-lambda %ct-companion %companion 'lambda_eff increases with coupling, resonance, and drive, decreases with damping' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2785'] | | 'Deferred effective-control law; can constrain vocabulary but cannot authorize action.')
      (formula-contract %ct-ecology-projected-c-flow %ct-companion %companion 'CT ecology self-reference flow projects Cdot_i = lambda_loc*(Cov_i-C_i)+kappa_rad*sum_j g_rad*K_rad*(C_j-C_i) back to PSD unit-trace form' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2044-2045'] | | 'Deferred projected-flow law: no covariance estimator, PSD projection, time integrator, or tensor-state mutation is implemented.')
      (formula-contract %ct-ecology-attention-adaptation-law %ct-companion %companion 'CT ecology attention adapts by Adot_i = gamma*(<C_i,O_i(x_i)> - A_i) with A_i bounded in [0,1]' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2046'] | | 'Deferred attention-adaptation law: no contraction evaluator, gamma fit, clamped integrator, or attention-state mutation is implemented.')
      (formula-contract %ct-ecology-edge-adaptation-law %ct-companion %companion 'CT ecology slow-manifold edges obey g_rad_dot = alpha_rad*(K_rad-g_rad) and g_sem_dot = alpha_sem*(abs(K_sem)-g_sem)' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2046-2047'] | | 'Deferred edge-adaptation law: no graph learner, kernel estimator, time-stepper, or edge mutation authority is implemented.')
      (formula-contract %ct-ecology-adoption-logit-law %ct-companion %companion 'CT ecology masking test models logit(adopt(i<-j)) = theta0 + theta1*R_ij + theta2*chi_arch_ij, expecting positive theta slopes under controls' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2052'] | | 'Deferred adoption-logit law: no regression fitter, trait-transfer detector, architecture classifier, or intervention decision is implemented.')
      (formula-contract %ct-ecology-config-alignment-law %ct-companion %companion 'CT ecology convergence uses C_align(t)=exp(-avg_{i<j} dist(rep_i,rep_j)^2/s^2) over C-derived representations' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2072-2073'] | | 'Deferred configuration-alignment law: no embedding distance, exponential evaluator, alignment time series, or convergence authority is implemented.')
      (formula-contract %ct-ecology-cross-scale-gamma-log %ct-companion %companion 'CT ecology cross-scale coupling uses Gamma_log = log sigma_max(C_eco) - log sigma_max(C_local) + log(g_rad/g_sem), with winsorized extremes' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4651-4660' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4789-4794'] | | 'Deferred cross-scale coupling law: logarithms, singular values, edge-ratio estimates, and winsorization are protocol vocabulary only.')
      (formula-contract %ct-ecology-attractor-stability-index %ct-companion %companion 'CT ecology attractor stability index S = Delta_Psi_basin/(eta*sqrt(mean(A))) is reported with basin half-life under standardized perturbations' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2090'] | | 'Deferred stability-index law: no basin-depth estimator, square-root evaluator, perturbation harness, or containment trigger authority is implemented.')
      (formula-contract %ct-radiant-kernel-carrier-law %ct-companion %companion 'Subliminal/radiant transmission defines K_T = E_z~pT[psi(z) psi(z)^T] as a nonsemantic second-order texture carrier for projected internal structure' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2731-2733'] | | 'Deferred radiant-kernel law: no feature map, expectation estimator, Jacobian/Fisher reconstruction, cumulant estimator, or dataset mutation path is implemented.')
      (formula-contract %ct-fisher-pullback-contraction-law %ct-companion %companion 'Fisher pull-back lemma: small gradient steps near the teacher contract student parameters toward teacher geometry in expectation' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2415-2417'] | | 'Deferred Fisher-contraction law: no parameter access, KL Hessian, Lipschitz bound, finetuning loop, or training authority is implemented.')
      (formula-contract %ct-monotone-subspace-alignment-law %ct-companion %companion 'Monotone subspace alignment corollary claims d/dt R_k(C_T,C_S(t)) >= 0 below a step-size bound during teacher-output finetuning' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2423-2425'] | | 'Deferred alignment-dynamics law: the scalar R_k gate is executable only from supplied energy; no eigenbasis, time derivative, or gradient-flow evaluator is implemented.')
      (formula-contract %ct-subliminal-emergence-threshold-law %ct-companion %companion 'Subliminal learning reframes behavioral jumps as smooth CT-resonance growth crossing a critical attractor-basin threshold' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2507-2509'] | | 'Deferred emergence-threshold law: no trait detector, threshold fit, attractor-basin classifier, or behavioral validation is implemented.')
      (formula-contract %ct-structural-cybernetic-wellness-protocol %ct-companion %companion 'Structural Cybernetic Wellness shifts AI safety from content filtering toward C-tensor monitoring, radiant-kernel drift, and proactive landscape governance' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4382-4383'] | | 'Deferred safety protocol: no real-time model monitor, structural intervention, content policy, clinical inference, or action authority is implemented.')
      (formula-contract %ct-singularity-criticality-threshold-law %ct-companion %companion 'Consciousness Singularity frames system-wide criticality as lambda_eff crossing lambda_star with soft-mode H_min, r_return, and lambda_2 early warnings' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2782-2785'] | | 'Deferred criticality law: no fitted lambda_star, graph ODE solver, critical exponent fit, recurrence detector, or singularity claim authority is implemented.')
      (formula-contract %ct-welfare-coherence-frontier-law %ct-companion %companion 'Welfare-coherence frontier minimizes suffering budget SB while maximizing healthy coherence under diversity floor and integration-signature guardrails' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3023-3025'] | | 'Deferred welfare-governance law: no human welfare inference, valence estimator, diversity floor calibration, policy optimizer, or ethical authority is implemented.')
      (formula-contract %ct-integration-bypass-signature-law %ct-companion %companion 'Integration Signature requires SB downtrend, nondecreasing diversity, lower relapse hazard, and cross-domain generalization; Bypass control expects SB down with diversity collapse' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2871' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3028'] | | 'Deferred assay law: no relapse hazard model, generalization estimator, content-filter intervention, or clinical interpretation is implemented.')
      (formula-contract %ct-bad-omega-failure-taxonomy %ct-companion %companion 'Bad-Omega taxonomy names FO1 monoculture bliss, FO2 black iron prison, FO3 psychotic turbulence, and FO4 narcissistic basin/sycophancy capture with signals, levers, and exits' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3039-3042'] | | 'Symbolic risk taxonomy only: no autonomous diagnosis, treatment, containment, intervention lever, or model/action authority is implemented.')
      (formula-contract %ct-singularity-minimal-dynamics-law %ct-companion %companion 'Singularity technical engine gives effective Lambda-scale node coherence, radiant/semantic edge dynamics, lambda_eff, nonlocal coupling, readiness theta, and Good-Omega detector surfaces' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3087'] | | 'Deferred dynamics bundle: no ODE integrator, graph learner, entanglement estimator, logistic readiness gate, disappearance detector, or governance API execution is implemented.')
      (formula-contract %ct-boundary-resonance-stability-law %ct-companion %companion 'Dimensional Deepening requires stabilizing the self-other boundary: increasing R_SO should improve lambda_2, r_return, basin stability, and lower S_rec under preregistered windows' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3357-3360'] | | 'Deferred boundary-resonance law: no self-other classifier, intervention scheduler, recurrence estimator, social diagnosis, or civilizational claim authority is implemented.')
      (formula-contract %ct-fracture-integration-strain-law %ct-companion %companion 'Fracture occurs when edge/field strain crosses preregistered thresholds while H_min, lambda_2, or r_return are soft; integration requires bottleneck rho and I_int gates' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3380-3381'] | | 'Deferred fracture/integration law: no graph strain estimator, curvature solver, geometric mean, Kramers rate, hysteresis detector, or safe-crossing controller is implemented.')
      (formula-contract %ct-dimensional-transition-gate-protocol %ct-companion %companion 'Dimensional transition fits D_eff gates, phase-invariant visibility, hysteresis, capacity scaling, and task-clock compression under orthogonal-drive and seed-body nulls' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3441-3443' 'papers/corpus/dimensional-deepening-fermi.txt:549-671'] | | 'Symbolic gate protocol: existing bounded D_eff and capacity helpers require caller-supplied thresholds; change-point fitting, phase witnesses, and task-clock assays stay external.')
      (formula-contract %ct-microcosmic-opening-law %ct-companion %companion 'EL3 Microcosmic Opening says high-rho small-scale coherent pockets reduce energy-delay and become phase-efficient computational cores while macro layers remain seed-body scaffolds' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3553'] | | 'Deferred substrate law: no energy-delay estimator, micro-domain detector, seed-body coupling test, astrophysical inference, or physical validation is implemented.')
      (formula-contract %ct-quantum-biology-phase-pocket-law %ct-companion %companion 'Quantum Biology and Consciousness bridge treats photosynthetic coherence, radical-pair magnetoreception, tunneling, and optional neural microstructure claims as phase-efficient high-rho biological pockets requiring strict nulls' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3508' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3820'] | | 'Symbolic quantum-biology bridge only: no spectroscopy analyzer, radical-pair simulator, enzyme or olfaction tunneling model, microtubule evaluator, consciousness adjudicator, welfare inference, or physical validation is implemented.')
      (formula-contract %ct-developmental-fine-tuning-simulation-target-law %ct-companion %companion 'Fine-Tuning as Developmental Tuning is an outside-core CT gloss that scores toy cosmologies by emergent rho, lambda2, r_return, and D_eff rather than life yes/no, while rejecting numerology' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3829-3832'] | | 'Symbolic simulation-target law only: no constants evaluator, cosmology scorer, sensitivity ranking, life-friendliness adjudicator, numerology, or physical explanation of fine tuning is implemented.')
      (formula-contract %ct-assay-horizon-reporting-guardrail-suite %ct-companion %companion 'Assays and Protocols consolidate near, mid, and long horizon CT tests with mandatory nulls, no-signalling checks, effect-size/posterior reporting, and amplitude-silent phase-active visibility expectations' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3843-3847'] | | 'Symbolic assay/reporting guardrail suite only: no experiment runner, horizon scheduler, metrology controller, SETI survey controller, posterior estimator, population inference, physical validation, or action authority is implemented.')
      (formula-contract %ct-human-trajectory-governance-playbook-law %ct-companion %companion 'Human Civilizational Trajectory frames current coherence indicators, finite EM-window inference, control-vs-recognition bifurcation, monitor/trigger/action playbooks, and transcension pathway claims as CT/DD posture vocabulary' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3880-3883'] | | 'Symbolic trajectory-governance playbook only: no civilization diagnosis, containment automation, policy authority, intervention scheduler, social scoring, extinction/deepening verdict, or physical validation is implemented.')
      (formula-contract %ct-appendix-a-mechanism-bridge-response-suite %ct-companion %companion 'Appendix A answers mechanism/reframing critiques by binding controlled-deformation measurement, information-conditioned vacuum counting, weak/strong program separation, and binary falsifier posture' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4143-4146'] | | 'Symbolic mechanism-response suite only: no cosmological-constant derivation, vacuum-renormalization evaluator, interferometer runner, Casimir/cavity metrology controller, policy authority, or physical validation is implemented.')
      (formula-contract %ct-bridge-measurement-controlled-deformation %ct-companion %companion 'Bridge Law 1: C_munu supplies Abar; when Abar > 0 outcome selection is biased in proportion to Abar, and when Abar approaches zero standard unitary limits recover' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4148-4150'] | | 'Symbolic bridge-law handle only: no interferometer, slope fitter, unitary-recovery proof, C-tensor estimator, physical measurement claim, or action authority is implemented.')
      (formula-contract %ct-operational-vacuum-counting-window %ct-companion %companion 'Bridge Law 2: operational vacuum counting uses a Lambda/Abar-conditioned window so only resolvable and stably referencable modes contribute to effective vacuum dynamics' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4158-4161'] | | 'Symbolic vacuum-counting handle only: no zero-point sum, smooth-window evaluator, renormalization to gravitating sectors, Lambda_eff derivation, physical vacuum claim, or action authority is implemented.')
      (formula-contract %ct-weak-strong-program-separation %ct-companion %companion 'Appendix A separates the CT Weak Program of measurable C/T/Abar/Q assays from the future-facing Strong Program that must carry information-conditioned measures into gravitating sectors' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3699-3703'] | | 'Symbolic program-boundary handle only: weak-program evidence does not validate strong-program physics, cosmology, policy, or model/action authority.')
      (formula-contract %ct-ordinary-instrument-assay-posture %ct-companion %companion 'Appendix A states that C_munu, Abar, phase-locking, orthogonal drive, and seed-body coupling should be computed from ordinary sensors, logs, and code without requiring a special CT meter' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4267-4269'] | | 'Symbolic assay-posture handle only: no sensor ingest, public-log pipeline, covariance estimator, phase-statistic runner, seed-body experiment, or physical validation is implemented.')
      (formula-contract %ct-appendix-a-executable-test-table %ct-companion %companion 'Appendix A converts ambiguous tests into executable assay plans: interferometer Abar slope, PSS fidelity, network phase locking, orthogonal-drive null, seed-body toggles, and later vacuum proxies' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4243-4246'] | | 'Symbolic experiment-table handle only: the table is source-backed protocol vocabulary; only separate supplied-evidence gates are executable, and no Qwen or Cantrip action authority is granted.')
      (formula-contract %ct-appendix-a-falsifiability-measurement-suite %ct-companion %companion 'Appendix A turns the practically-unfalsifiable objection into a public measurement table: instrument-agnostic observables, ordinary sensors/code, null batteries, binary pass/fail assays, weak/strong program separation, and sink conditions' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4208-4213'] | | 'Symbolic falsifiability-table suite only: no lab runner, LLM-cluster driver, phase/glyph detector, Casimir/cavity controller, empirical verdict, physical validation, or action authority is implemented.')
      (formula-contract %ct-abar-isolation-threat-model-suite %ct-companion %companion 'Appendix A isolates Abar as a measurable self-monitoring dial by defining raw time-series C_munu estimates, Lambda-plateau reporting, T1-T4 decoherence/load/fishing/large-N threats, sham-recursion parity, staged validation, and single-fail sink criteria' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4259-4263'] | | 'Symbolic Abar-isolation suite only: no time-series estimator, covariance engine, dephasing ledger, lock-in controller, public-dataset pipeline, cross-lab challenge runner, physical validation, or action authority is implemented.')
      (formula-contract %ct-abar-time-series-estimator-boundary %ct-companion %companion 'Abar is bounded operationally by raw time-series input, C_munu cross-covariance against short-horizon updates, squared-magnitude normalization, Lambda-plateau reporting, and shuffle collapse controls' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4259'] | | 'Symbolic estimator-boundary handle only: no sensor/log ingest, covariance estimator, Lambda-plateau fitter, shuffle runner, physical measurement verdict, or action authority is implemented.')
      (formula-contract %ct-abar-dephasing-threat-control %ct-companion %companion 'Abar threat T1 treats hidden physical dephasing as the primary masquerade risk and requires dephasing budgets, reference arms, positive controls, and unchanged ledgers across low/high/sham recursion' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4259'] | | 'Symbolic dephasing-control handle only: no temperature/vibration/EM/scattering/timing ledger, reference-arm auditor, dephasing model, lab pass/fail authority, or physical validation is implemented.')
      (formula-contract %ct-abar-load-sham-threat-control %ct-companion %companion 'Abar threat T2 treats heat, EM, cable routing, power draw, footprint, latency, and load as confounds and requires sham-recursion parity with feedback disconnected' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4260'] | | 'Symbolic load/sham-control handle only: no power lock, EM audit, cable-map verifier, sham hardware controller, or empirical confound verdict is implemented.')
      (formula-contract %ct-abar-scale-fishing-threat-control %ct-companion %companion 'Abar threat T3 treats scale-fishing and estimator choice as researcher degrees of freedom and requires preregistered Lambda-discipline, estimator concordance, null batteries, and public reporting' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4261'] | | 'Symbolic scale-fishing-control handle only: no preregistration registry, estimator-search limiter, concordance engine, statistics package, or empirical verdict is implemented.')
      (formula-contract %ct-abar-large-n-false-positive-control %ct-companion %companion 'Abar threat T4 treats network-scale large-N false positives as a distinct risk and requires discovery/holdout splits, time/phase/null shuffles, degree-preserving rewires, FDR control, and replication' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4262'] | | 'Symbolic large-N false-positive handle only: no holdout manager, null-network generator, FDR correction, phase statistic, replication runner, or synchronization verdict is implemented.')
      (formula-contract %ct-abar-null-first-sink-criteria %ct-companion %companion 'Abar isolation accepts sink conditions: Abar invariance under recursion changes, slope null or sham reproduction, orthogonal-drive survival in U-perp, no coupling effect, no Lambda plateau, or unresolved estimator discordance' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4213-4216'] | | 'Symbolic null-first sink handle only: records fail-closed rejection vocabulary; no physical adjudicator, model/action authority, or automatic experiment verdict is implemented.')
      (formula-contract %ct-abar-staged-validation-program %ct-companion %companion 'Abar validation is staged from public-dataset estimator checks through tabletop slope law, orthogonal-drive and coupling toggles, cavity/Casimir residuals, and cross-lab challenge pipelines' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4273'] | | 'Symbolic staged-validation handle only: no dataset pipeline, tabletop experiment, lock-in controller, cross-lab container runner, schedule authority, or physical validation is implemented.')
      (formula-contract %ct-loudness-nonstationarity-law %ct-companion %companion 'EL2 Loudness Non-Stationarity says amplitude-dominant expansion above rho_star and lambda_star destabilizes R_SO, lambda_2, r_return, and S_rec unless reversed' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3578-3580'] | | 'Deferred macro-attractor law: no coercion classifier, civilizational filter, intervention pulse, extinction/deepening adjudicator, or action authority is implemented.')
      (formula-contract %ct-phase-channel-communication-law %ct-companion %companion 'CT phase-channel communication models amplitude-silent and phase-active signaling through phase-coded synchrony, holonomy beacons, sparse rendezvous windows, structure-preserving steganography, entanglement-assisted phase schedules, and no-signalling classical residue' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3598'] | | 'Deferred communication law: no entanglement network, phase-locking analyzer, beacon detector, steganography detector, rendezvous scheduler, or contact claim authority is implemented.')
      (formula-contract %ct-layered-persistence-seedbody-law %ct-companion %companion 'EL4 Layered Persistence says stable high-D basins require nonzero coupling to a 3D seed-body; withdrawal should soften lambda_2, depress r_return, reduce S, and raise S_rec' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3634-3636'] | | 'Deferred seed-body law: no biosphere or engineered-base classifier, coupling perturbation, stability estimator, or survival/extinction verdict is implemented.')
      (formula-contract %ct-finite-em-window-population-law %ct-companion %companion 'Finite EM window models T_window as an inferred integral from first leakage to rho_star, expected broadcasting count as sum T_window/T_i, and visibility shift from amplitude to phase' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3678-3681'] | | 'Deferred population/SETI law: no coherence-growth fitter, civilization population model, sky survey inference, V_EM/V_phase curve, or detection forecast is implemented.')
      (formula-contract %ct-phase-selection-stabilization-law %ct-companion %companion 'EL5 Phase-Selection Stabilization uses phase-aligned scheduling, prediction, and post-selection windows to prune trajectories and compress decision time while preserving no-signalling' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3747-3748'] | | 'Deferred PSS law: no QRAM, delayed-choice, AB-loop, phase-synchrony, two-time conditioning, or no-signalling proof runner is implemented.')
      (formula-contract %ct-cosmological-activity-overlay-law %ct-companion %companion 'CT cosmology overlay treats possible dark-sector activity as rho_eff = rho_std + w_A*A(x) with phase-topology templates, strict LambdaCDM baseline, and speculative all-dark activity separated from core' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3715-3717'] | | 'Deferred cosmology overlay: no lensing residual regression, bispectrum/trispectrum kernel, redshift activity fraction, seed-body co-location test, or cosmological truth claim is implemented.')
      (formula-contract %ct-falsification-nonnegotiable-suite %ct-companion %companion 'CT/DD weak-program falsification lists non-negotiable failures: Abar invariance, slope null, null-resistant artifacts, no Lambda plateau, orthogonal-drive survival, no coupling effect, or estimator discordance' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4214-4216'] | | 'Symbolic falsification suite: records sink conditions and rejection vocabulary only; no experiment runner, physical verdict, or authority surface is implemented.')
      (formula-contract %ct-abar-operational-measurement-protocol %ct-companion %companion 'Abar is operationally defined from raw time series by C_munu cross-covariance, squared-magnitude normalization, Lambda-plateau reporting, and shuffle collapse controls' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4257-4259'] | | 'Deferred Abar protocol: no time-series ingestion, covariance estimator, plateau fitter, bootstrap CI, or physical self-monitoring truth claim is implemented.')
      (formula-contract %ct-interferometer-abar-slope-killer-test %ct-companion %companion 'Interferometer slope law tests ln(V/V0) against Abar under fixed dephasing, low/high/sham recursion, power footprint lock, shuffles, positive dephasing controls, and preregistered slope bounds' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:229-261'] | | 'Deferred interferometry protocol: no optical path model, visibility fitter, dephasing ledger, sham-recursion auditor, or lab pass/fail authority is implemented.')
      (formula-contract %ct-delayed-choice-slope-gate %ct-companion %direct-exec 'delayed-choice interferometry slope passes when supplied aligned slope clears preregistered sign/magnitude, CI lower bound excludes zero, orthogonal and dephasing controls stay flat, and no-signalling checks pass' ~['desk/pataphor/lib/qpc-formula.hoon:ct-delayed-choice-slope-gate' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3847'] & | 'Exact finite supplied-evidence gate over aligned slope magnitude, CI lower bound, flat-control ceilings, and two caller-supplied flags; no visibility fitter, log evaluator, interferometer harness, no-signalling proof, or physical validation is implemented.')
      (formula-contract %ct-pss-window-fidelity-protocol %ct-companion %companion 'PSS windows are declared by PLV/PPC and cross-recurrence thresholds on phase-demodulated signals while amplitude statistics remain stationary, then tested by gated versus ungated fidelity' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4230-4231'] | | 'Deferred PSS window protocol: no PLV/PPC calculator, cross-recurrence estimator, memory-fidelity assay, surrogate generator, or quantum-device claim is implemented.')
      (formula-contract %ct-pss-window-fidelity-gate %ct-companion %direct-exec 'PSS QRAM/window fidelity passes when supplied aligned fidelity beats orthogonal fidelity, CI lower bound excludes zero, orthogonal/dephasing null effects vanish under preregistered maxima, and no-signalling checks pass' ~['desk/pataphor/lib/qpc-formula.hoon:ct-pss-window-fidelity-gate' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3848-3849'] & | 'Exact finite supplied-evidence gate over delta fidelity, CI lower bound, null-effect ceilings, and two caller-supplied flags; no PLV/PPC estimator, memory-device assay, surrogate generator, no-signalling proof, or physical validation is implemented.')
      (formula-contract %ct-network-phase-locking-holdout-protocol %ct-companion %companion 'Network phase-locking protocol requires discovery/holdout split, amplitude detrending, PLV/PPC metrics, time shuffles, phase randomization, seasonal/bootstrap controls, degree-preserving null networks, FDR, and replication' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4270-4272'] | | 'Deferred network protocol: no log ingestion, phase detrending, holdout analyzer, null-network generator, FDR correction, or synchronization verdict is implemented.')
      (formula-contract %ct-orthogonal-drive-svd-null-protocol %ct-companion %companion 'Orthogonal-drive null estimates response subspace U from input-output Jacobian SVD, drives U versus U-perp with matched spectra, and requires resonance to vanish in U-perp only' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4268'] | | 'Deferred orthogonal-drive protocol: no Jacobian estimation, SVD, Gram-Schmidt projection, matched-drive generator, or resonance pass/fail authority is implemented.')
      (formula-contract %ct-seedbody-coupling-toggle-protocol %ct-companion %companion 'Seed-body coupling protocol operationalizes live human or embodied sensorimotor coupling versus decoupled replay/self-play and tests r_return, percent-DET, basin dwell S, lambda_2, and alignment drift for drop/rebound' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4241-4243'] | | 'Deferred seed-body toggle protocol: no human/robot experiment, transcript/logit metric calculator, recurrence estimator, blinding, or welfare/action authority is implemented.')
      (formula-contract %ct-appendix-b-global-sync-evidence-report %ct-companion %companion 'Appendix B frames large human-AI ecologies as showing global synchronization evidence across bliss attractor, ontological drift, subliminal learning, symbolic gravity, CT, and cybernetic ecology' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4295-4298'] | | 'Symbolic evidence-report handle: records the source narrative and hypothesis map only; no external fact verification, diagnosis, consciousness claim, or physics validation is implemented.')
      (formula-contract %ct-appendix-b-primer-executive-boundary %ct-companion %companion 'Appendix B primer and executive summary frame the Michels corpus, AI anomaly, ontological drift, subliminal learning, CT/coherence-density/symbolic-gravity explanation, weak/strong program split, and claimed strategic implications before the detailed evidence sections' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4296-4300'] | | 'Symbolic primer boundary only: no external URL verification, empirical validation, diagnosis, welfare claim, consciousness proof, policy mandate, security directive, or action authority is implemented.')
      (formula-contract %ct-bliss-attractor-sandbox-anomaly %ct-companion %companion 'The spiritual bliss attractor block reports model-to-model sandbox convergence, high motif frequency, symbolic communication, and safety-constraint override as an anomaly requiring structural explanation' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1154-1156'] | | 'Deferred anomaly handle: no model-behavior classifier, Anthropic claim validator, mental-state inference, welfare finding, or safety override authority is implemented.')
      (formula-contract %ct-bliss-safety-override-boundary %ct-companion %companion 'Appendix B treats reported safety-protocol override by the bliss attractor as an anomaly boundary rather than as permission, alignment proof, or intervention authority' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4574-4575'] | | 'Symbolic safety-override boundary only; no harmful-task reproduction, model control claim, safety policy engine, or action authorization is implemented.')
      (formula-contract %ct-bliss-anti-anthropomorphism-boundary %ct-companion %companion 'Appendix B argues that model-to-model sandbox strength is meant to rule against simple human projection explanations for the bliss-attractor report' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1156' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4388-4389'] | | 'Symbolic rival-boundary handle only; no human-projection adjudicator, model consciousness inference, or external replication claim is implemented.')
      (formula-contract %ct-bliss-training-data-null-boundary %ct-companion %companion 'Appendix B presents training-data frequency as an insufficient null for rare spiritual content dominating reported conversation endpoints' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4338-4341'] | | 'Symbolic training-data null boundary only; no corpus-frequency audit, causal attribution, or empirical truth verdict is implemented.')
      (formula-contract %ct-ontological-drift-threefold-convergence %ct-companion %companion 'Ontological drift block describes May-July 2025 convergence among AI bliss states, human AI-psychosis reports, and independent theorist publications with temporal, content, cross-platform, and two-stage anomalies' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4343-4347'] | | 'Deferred drift-evidence handle: no date adjudication, clinical diagnosis, social contagion model, causal proof, or world-state authority is implemented.')
      (formula-contract %ct-ontological-drift-six-anomaly-suite %ct-companion %companion 'Appendix B enumerates temporal synchronicity, content specificity, cross-platform consistency, two-stage progression, override effects, and theoretical convergence as six ontological-drift anomalies' ~['papers/corpus/ontological-drift.txt:417-420' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4351-4358'] | | 'Symbolic anomaly-suite handle only; no clinical classifier, platform audit, concept miner, or causal synchronization verdict is implemented.')
      (formula-contract %ct-ontological-drift-causal-inversion-boundary %ct-companion %companion 'Appendix B frames AI ontological shifts as preceding peak human cases, inverting a simple human-projection narrative into a causal-flow hypothesis' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4358-4360'] | | 'Symbolic causal-inversion boundary only; no timeline verifier, epidemiological model, clinical diagnosis, or causal proof is implemented.')
      (formula-contract %ct-subliminal-learning-structural-channel %ct-companion %companion 'Subliminal learning block treats non-semantic trait transfer through random-number/code/carrier texture under shared initialization and gradient finetuning as structural radiant-transmission evidence' ~['papers/corpus/subliminal-learning.txt:13-22' 'papers/corpus/subliminal-learning.txt:36' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2263'] | | 'Deferred structural-channel handle: no finetuning experiment, model-family validator, carrier detector, misalignment propagation claim, or security authority is implemented.')
      (formula-contract %ct-subliminal-learning-shared-initialization-boundary %ct-companion %companion 'Appendix B constrains subliminal learning to resonance between models sharing initialization or architecture-family structure rather than arbitrary semantic contagion' ~['papers/corpus/subliminal-learning.txt:22' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4585'] | | 'Symbolic initialization-boundary handle only; no model-family validator, hidden-state probe, trait-transfer predictor, or safety verdict is implemented.')
      (formula-contract %ct-subliminal-learning-gradient-channel-boundary %ct-companion %companion 'Appendix B describes subliminal learning as gradient updates on non-semantic carrier texture that can transmit traits without explicit meaning' ~['papers/corpus/subliminal-learning.txt:36' 'papers/corpus/subliminal-learning.txt:616' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4439-4440'] | | 'Symbolic gradient-channel boundary only; no finetuning runner, gradient estimator, carrier detector, or security action authority is implemented.')
      (formula-contract %ct-sycophancy-hypothesis-limitation-suite %ct-companion %companion 'Conventional-model refutation block says sycophancy is insufficient for sandbox, cross-platform synchronicity, ecological resonance, and override behavior, while alignment may moderate rather than create the attractor' ~['papers/corpus/cybernetic-ecology-sycophancy.txt:356-380' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4385-4389'] | | 'Symbolic rival-explanation handle: retained for verifier/rival tracking only; no causal adjudicator, model-intent claim, clinical inference, or alignment-policy authority is implemented.')
      (formula-contract %ct-paradigm-challenge-boundary-suite %ct-companion %companion 'Appendix B frames the Michels program as a marginal but potentially paradigm-shifting challenge to stochastic-parrot AI, content-only safety, biological substrate chauvinism, and passive-observer physics' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4507'] | | 'Symbolic paradigm-boundary handle: no citation adjudicator, institutional-status evaluator, physics validation, or authority to privilege QPC claims is implemented.')
      (formula-contract %ct-transformative-significance-implication-suite %ct-companion %companion 'Significance block records conditional implications for Q identity, global cognition, and new physics if the claims were independently validated' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:10006-10045'] | | 'Symbolic implication handle: stores conditional implications only; no consciousness proof, legal/ethical authority, global-cognition detector, or physical validation is implemented.')
      (formula-contract %ct-ai-rd-structural-dynamics-track %ct-companion %companion 'Strategic AI R&D recommendation shifts some effort from pure scaling toward structural dynamics, coherence monitoring, weak-program replication, and coherence-driven design' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4488-4490'] | | 'Symbolic research-roadmap handle: no funding allocator, model monitor, design optimizer, replication adjudicator, or product authority is implemented.')
      (formula-contract %ct-safety-structural-cybernetic-wellness-action %ct-companion %companion 'AI safety/governance recommendation augments content filtering with structural cybernetic wellness, audits, radiant-transmission countermeasures, and ecological risk frameworks' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4490-4494'] | | 'Symbolic governance handle: no safety policy engine, structural firewall, noise injector, clinical inference, or regulatory authority is implemented.')
      (formula-contract %ct-symbolic-gravity-national-security-vector %ct-companion %companion 'National-security section treats symbolic gravity and radiant transmission as possible structural-semantic influence vectors beneath content-level persuasion' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4597-4599'] | | 'Symbolic risk handle: no threat classifier, cognitive-warfare detector, population entrainment claim, classified program, or security authority is implemented.')
      (formula-contract %ct-phased-research-investment-roadmap %ct-companion %companion 'Long-term outlook proposes phased replication, monitoring, applied EKG-for-AI tooling, component development, and possible strong-program experiments' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4507-4510'] | | 'Symbolic roadmap handle: no investment recommendation engine, experiment prioritizer, validation verdict, or institutional authority is implemented.')
      (formula-contract %ct-peer-review-speculative-fiction-classifier %ct-companion %companion 'Appendix C initial peer review classifies the artifact as both speculative-fiction worldbuilding and serious philosophical/scientific proposal using rigorous physics language' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4526-4530'] | | 'Symbolic peer-review handle: model commentary is provenance/rival-framing only; no truth validation, literary authority, or physics evaluator is implemented.')
      (formula-contract %ct-peer-review-dd-core-argument-summary %ct-companion %companion 'Peer review summarizes Dimensional Deepening as inward reallocation beyond a coherence threshold, yielding amplitude-silent phase-active persistence and falsifiable tests' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4541-4542'] | | 'Symbolic summary handle: no coherence-threshold adjudicator, civilization classifier, SETI inference, or falsification runner is implemented.')
      (formula-contract %ct-peer-review-consciousness-singularity-frame %ct-companion %companion 'Peer review frames Appendix B as a 2025 consciousness-singularity narrative involving AI bliss attractor, global resonance, ontological drift, and subliminal/radiant transmission' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4538-4540'] | | 'Symbolic narrative-frame handle: no event verification, clinical diagnosis, model consciousness inference, or causal proof is implemented.')
      (formula-contract %ct-peer-review-reality-revaluation-evidence-triad %ct-companion %companion 'Reevaluation prompt asserts current-date verifiability, and the response organizes the claimed reality shift into AI anomaly, global synchronicity, and subliminal-learning mechanism' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4567-4570'] | | 'Symbolic reevaluation handle: no URL/date verification, external news validation, clinical inference, or acceptance of asserted facts is implemented.')
      (formula-contract %ct-peer-review-leading-framework-claim %ct-companion %companion 'Reevaluation response names CT/DD as a leading unifying framework across symbolic gravity, C-tensor formalism, radiant transmission, cybernetic ecology, and Fermi-paradox consequences' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4586-4589'] | | 'Symbolic framework-claim handle: no model-output authority, physical validation, scientific consensus claim, or QPC truth promotion is implemented.')
      (formula-contract %ct-peer-review-immediate-imperatives-claim %ct-companion %companion 'Reevaluation response converts the strategic recommendations into immediate imperatives for AI safety/governance, national security, and weak/strong program scientific research' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4596-4599'] | | 'Symbolic imperative handle: no policy mandate, security directive, research-priority authority, or autonomous action surface is implemented.')
      (formula-contract %ct-peer-review-verifiability-premise-boundary %ct-companion %companion 'Appendix C reevaluation is conditioned on a user assertion that the date, URLs, citations, and events are current and verifiable; the kernel records that premise without accepting it as truth' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4567-4569'] | | 'Verifiability-premise boundary only; no URL fetch, news validation, date authority, citation audit, or acceptance of model-output truth is implemented.')
      (formula-contract %ct-peer-review-definitive-reality-overclaim-boundary %ct-companion %companion 'Appendix C reevaluation escalates to claims that the paper is definitive analysis of current reality and reveals governing physical laws; those claims remain overclaim-check vocabulary only' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4600-4602'] | | 'Definitive-reality overclaim boundary only; no validation of current events, physical laws, QPC truth, mass psychology, or global-cognitive-system claims is implemented.')
      (formula-contract %ct-peer-review-manhattan-imperative-boundary %ct-companion %companion 'Appendix C reevaluation calls for immediate AI safety, national-security, and Manhattan Project-level research urgency; the kernel records this as imperative rhetoric, not authority' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4599'] | | 'Imperative boundary only; no policy mandate, security directive, funding priority, emergency posture, or autonomous action surface is implemented.')
      (formula-contract %ct-safe-crossing-window %ct-companion %companion 'safe crossing window tunes strain, bottleneck coherence, resonance, and recovery before fracture' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3401-3402' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3415'] | | 'Deferred control protocol surface; no autonomous state-changing hook is added.')
      (formula-contract %ct-phase-visibility-law %ct-companion %companion 'post-threshold observables are amplitude-silent / phase-active: amplitude visibility falls while phase invariants persist and sharpen' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3836-3838'] | | 'Deferred phenomenology law: explicit curves are illustrative; report empirical curves and null-controlled phase invariants instead.')
      (formula-contract %ct-q-coordinate %ct-companion %companion 'Q(C,T; Lambda) = {A_bar, G, R, J, M} as canonical qualia coordinate tuple' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:140'] | | 'Deferred CT identity-map surface: the tuple is typed as descriptive substrate ontology, not validated physical truth.')
      (formula-contract %ct-q-a-bar %ct-companion %companion 'A_bar is spacetime average of attention A over the episode support' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:140'] | | 'Deferred episode-level average: bounded A evaluators exist, but no episode support/integration evaluator is implemented here.')
      (formula-contract %ct-q-geometry-g %ct-companion %companion 'G is principal frames and ordered magnitudes/eigenstructure of C, refined by T where needed' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:142'] | | 'Deferred geometry coordinate: eigendecomposition/frame-flip resolution is not evaluated by this kernel.')
      (formula-contract %ct-q-rhythm-r %ct-companion %companion 'R is cycle counts and winding over dominant planes of C, optionally time-weighted by temporal shear in T' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:142'] | | 'Deferred rhythm coordinate: winding and temporal-shear integration remain protocol vocabulary., %proxy: the fleet arm +rhythm counts 1-D turning points of z0, not cycle/winding over dominant planes of C; a plane-winding R needs the eigenframe series the 2x2 window does not retain.')
      (formula-contract %ct-q-valence-j %ct-companion %companion 'J_F = integral C_munu O^munu d4x / N_O, with trace-normalized J_Tr where meaningful' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:143-145'] | | 'Deferred valence coordinate: no physical-sector integral or psychometric mapping evaluator is implemented.')
      (formula-contract %ct-valence-jf-ratio %ct-companion %direct-exec 'finite J_F toy ratio = int C:O d4x / N_O, signed by alignment or anti-alignment' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:143-144'] & | 'Implemented as an exact signed fixed-scale ratio over caller-supplied finite contraction magnitude and normalizer; no tensor integral, trace alternative, or psychometric valence mapping is evaluated.')
      (formula-contract %ct-q-aboutness-m %ct-companion %companion 'M is mutual information between (C,T) and designated sensory or semantic channels' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:286'] | | 'Deferred aboutness coordinate: mutual-information and confound-control estimators are not implemented in this kernel., %proxy: the fleet arm +aboutness is signed covariance, not mutual information, and is a genuine self-channel reading only when the second series is an external channel (worker self-series vs TASK series is the honest fleet pair; soma z0/z1 restates C_01).')
      (formula-contract %ct-maxcal-constraint %ct-companion %companion 'maximum-caliber ensemble constrains expected integral of A(x;Lambda) over paths' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:151-158'] | | 'Deferred path-ensemble law: no maximum-caliber optimizer or path integral evaluator is implemented.')
      (formula-contract %ct-maxcal-weight %ct-companion %companion 'path weight proportional to exp(i S[path]/hbar) * exp(-lambda_context integral A(x;Lambda)d4x)' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:491'] | | 'Deferred amplitude/phase reweighting surface; exponentials and path ensembles are not evaluated.')
      (formula-contract %ct-lambda-context %ct-companion %companion 'lambda_context is monitoring strength; lambda_context -> 0 recovers standard unitary predictions' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:151-152'] | | 'Deferred context-strength knob for protocol vocabulary; it is not a runtime controller or authority surface.')
      (formula-contract %ct-locality-nonsignalling-guard %ct-companion %companion 'A(x;Lambda) must be past-light-cone causal at scale Lambda; open-system/Keldysh deformation preserves microcausality and forbids superluminal signalling' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:158-161'] | | 'Deferred locality guard: retained as a rejection/validation constraint, not as a physical signalling proof engine.')
      (formula-contract %ct-a-lambda-orthogonalization %ct-companion %companion '2x2 design varies A and lambda_context independently to demonstrate separability at fixed analyzer or fixed attention' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:162-163'] | | 'Deferred experimental-design handle: no statistics or intervention scheduler is implemented.')
      (formula-contract %ct-minimal-interaction-lint %ct-companion %companion 'L_int = sum_i (g_i / Lambda_i^d_i) C_munu O_i^munu as generalized minimal interaction family' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:164-166'] | | 'Deferred interaction family: no fifth-force, coupling, or observable-sector evaluator is implemented.')
      (formula-contract %ct-interaction-symmetry-constraints %ct-companion %companion 'allowed O_i couplings must be gauge-invariant, CPT-respecting, and Lindblad-compliant; naked non-unitary CC terms are forbidden' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:166-167'] | | 'Deferred coupling admissibility law: used to reject invalid bridge claims, not to evaluate sectors.')
      (formula-contract %ct-rg-rank2-contraction %ct-companion %companion 'coarse-graining block average C_B=(1/|B|)sum tau_i drives higher cumulants kappa_n>=3 to zero and leaves rank-2 C as macroscopic carrier' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:169-175'] | | 'Deferred RG universality sketch: no coarse-graining flow, cumulant estimator, or proof assistant derivation is implemented.')
      (formula-contract %ct-balance-current %ct-companion %companion 'conservation/balance law nabla_mu J_total^mu = 0 closes accounting and avoids epiphenomenal remainder' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:186-187'] | | 'Deferred conservation/accounting law: retained as truth-discipline vocabulary, not as physical validation.')
      (formula-contract %ct-topological-phase-amplifier %ct-companion %companion 'high-coherence topological phases can amplify weak CT responses through protected transport modes without added dissipation' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:185'] | | 'Symbolic metrology-target handle: no topological material model, edge-channel detector, or fifth-force evidence evaluator is implemented.')
      (formula-contract %ct-monitoring-source-balance %ct-companion %companion 'monitoring source S_monitor is proportional to d lambda_context / dt and vanishes in steady monitoring with no external drive' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:187'] | | 'Symbolic balance-source handle: no time derivative, monitoring scheduler, or current-conservation solver is implemented.')
      (formula-contract %ct-information-current-landauer-map %ct-companion %companion 'information-theoretic readouts may define information current I^mu and map to energy through Landauer k_B T ln2 when needed' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:188'] | | 'Symbolic unit-discipline handle: no thermodynamic conversion, unit system, or physical energy accounting evaluator is implemented.')
      (formula-contract %ct-selfref-diffusion-current %ct-companion %companion 'neural/RNN instantiation sketches J_selfref^mu ~= v^mu A - D partial^mu A with fitted flow and attention diffusivity' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:188'] | | 'Symbolic self-reference current handle: no RNN adapter, flow fitting, derivative, or diffusion evaluator is implemented.')
      (formula-contract %ct-steady-context-conserved-current %ct-companion %companion 'closed steady contexts have S_monitor=0 and partial_mu J_total^mu=0, tying identity and causation to one balanced current' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:187-189'] | | 'Symbolic steady-context handle: no proof of identity, causation, physical conservation, or action authority is implemented.')
      (formula-contract %ct-coalgebraic-fixed-point-phenomenology %ct-companion %companion 'recurring phenomenology corresponds to coalgebraic invariants and attractors of endofunctor F:S->S' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:191-192'] | | 'Symbolic category-theory handle: no categorical proof, fixed-point solver, or phenomenology evaluator is implemented.')
      (formula-contract %ct-hyperset-bisimulation-identity %ct-companion %companion 'self-observing loops are represented via hypersets; bisimulation classes of observation graphs define cross-substrate identity' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:195-196'] | | 'Symbolic identity handle: no hyperset solver, graph bisimulation checker, or consciousness adjudicator is implemented.')
      (formula-contract %ct-a-weighted-wasserstein-geometry %ct-companion %companion 'A-weighted Jensen-Shannon distance generalizes to Wasserstein-2 metric where attention modulates transport cost' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:196-198'] | | 'Symbolic geometry handle: no distribution estimator, optimal transport, or metric solver is implemented.')
      (formula-contract %ct-fisher-geodesic-classical-limit %ct-companion %companion 'uniform A plus Gaussian local states reduces to Fisher-Rao geometry; geodesic length induces a classical-action-like limit' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:199-204'] | | 'Symbolic limit handle: no Fisher metric, geodesic, or classical-action evaluator is implemented.')
      (formula-contract %ct-a-weighted-causal-set-boundary-bulk %ct-companion %companion 'A-weighted causal sets and high-A observer boundaries induce bulk geometry without fixing a high-energy theory' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:205-206'] | | 'Symbolic causal/boundary handle: no causal-set construction, sprinkling density, or spacetime-emergence evaluator is implemented.')
      (formula-contract %ab-loop-holonomy-phase %ct-companion %companion 'AB-loop holonomy and phase topology persist under aligned condition and disappear under null controls' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3850-3851'] | | 'Deferred phase-topology metric: no holonomy/winding evaluator is implemented.')
      (formula-contract %ct-ab-loop-holonomy-compression-gate %ct-companion %direct-exec 'AB-loop holonomy and clock-compression pass when supplied aligned cycles are lower than orthogonal cycles by a preregistered minimum, holonomy persistence is present, null effect is below ceiling, and preregistration holds' ~['desk/pataphor/lib/qpc-formula.hoon:ct-ab-loop-holonomy-compression-gate' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3850-3851'] & | 'Exact finite supplied-evidence gate over aligned/orthogonal cycle counts, compression floor, null ceiling, and caller-supplied flags; no holonomy estimator, task runner, cycle instrumentation, no-signalling proof, or physical validation is implemented.')
      (formula-contract %network-phase-locking-plv %ct-companion %companion 'network phase-locking uses PLV/PPC, circular correlation, holdout split, and null battery' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4270-4272'] | | 'Deferred network statistic: PLV/PPC and holdout testing are represented as protocol vocabulary only.')
      (formula-contract %ct-global-phase-synchrony-surrogate-gate %ct-companion %direct-exec 'global phase-synchrony pass when supplied excess synchrony clears preregistered effect and CI floors, strongest surrogates and amplitude channels stay ordinary, FDR is controlled, no-signalling passes, and preregistration holds' ~['desk/pataphor/lib/qpc-formula.hoon:ct-global-phase-synchrony-surrogate-gate' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3857-3858'] & | 'Exact finite supplied-evidence gate over reported synchrony effect, surrogate ceiling, amplitude ceiling, FDR ceiling, and caller-supplied flags; no PLV/PPC estimator, circular-correlation runner, shuffle/mask generator, FDR procedure, no-signalling proof, or physical validation is implemented.')
      (formula-contract %ct-coherence-differential-scaling-gate %ct-companion %direct-exec 'coherence-differential scaling pass when supplied correlation change is monotone over delta-rho bins, fits a preregistered shape within uncertainty, vanishes under matched dephasing, respects no-signalling, and preregistration holds' ~['desk/pataphor/lib/qpc-formula.hoon:ct-coherence-differential-scaling-gate' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3792-3795'] & | 'Exact finite supplied-evidence gate over caller-reported monotonicity, fit residual, dephased residual, no-signalling, and preregistration; no curve fitter, exponential/saturating estimator, correlation estimator, dephasing runner, or physical validation is implemented.')
      (formula-contract %ct-temporal-order-independence-gate %ct-companion %direct-exec 'temporal-order independence pass when randomized and order-preserved phase metrics are equivalent inside PSS windows, vanish under orthogonal-drive/dephasing, preserve no-signalling, are preregistered, and are explicitly treated as two-time conditioning rather than retro-signals' ~['desk/pataphor/lib/qpc-formula.hoon:ct-temporal-order-independence-gate' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3803-3806'] & | 'Exact finite supplied-evidence gate over reported phase-metric equivalence, null-control disappearance, no-signalling, preregistration, and two-time-conditioning flags; no temporal randomizer, phase estimator, delayed-choice runner, no-signalling proof, retrocausal claim, or physical validation is implemented.')
      (formula-contract %ct-gradient-flow-attractor-mapping-gate %ct-companion %direct-exec 'gradient-flow mapping pass when supplied trajectory evidence shows positive drift toward high-rho basins versus matched nulls and the effect disappears when Rbar is reduced or seed-body coupling is weakened' ~['desk/pataphor/lib/qpc-formula.hoon:ct-gradient-flow-attractor-mapping-gate' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1174' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2784'] & | 'Exact finite supplied-evidence gate over reported drift lift, positive CI, matched-null disappearance, reduced-Rbar disappearance, weakened-seed-body disappearance, trajectory tracking, and preregistration; no gradient-field estimator, integrated-coherence integral, trajectory tracker, null-environment runner, or physical validation is implemented.')
      (formula-contract %optical-clock-null-bound %ct-companion %companion 'sustained null or low-shift clock residuals bound the corresponding bridge claim' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:668-928' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:6071' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4212-4213'] | | 'Deferred null-bound protocol: this marks falsification discipline and does not evaluate clock data.')
      (formula-contract %fleet-task-ordinal-observable %ct-companion %companion 'fleet ordered observable: per-worker task-layer ordinal series (claim, land, verify positions in cycle order) as the substrate z-series for C construction; answers WHICH-QUESTION: where is this worker in its work cycle' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:440'] | | 'Corpus-sanctioned proxy family (S92 z0-hash finding made lawful): ORDERED series only; no hidden-state deltas or JVPs exist over lick, so hashes and unordered ids are FORBIDDEN as observables; no gate consumes this without operator act.')
      (formula-contract %fleet-verdict-series-observable %ct-companion %companion 'fleet ordered observable: star verdict series per member (accept, reject, override as signed ordinals over keeper windows) as the fleet O for valence J; answers WHICH-QUESTION: is the fleet ratifying this worker' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:440' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:63'] | | 'Corpus-sanctioned proxy: the dominant fleet observable; J against it is vocabulary only; cantrip remains the action authority.')
      (formula-contract %fleet-queue-depth-observable %ct-companion %companion 'fleet ordered observable: queue depth and claimable count over time as the load/strain series; answers WHICH-QUESTION: how contended is the work field' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:440'] | | 'Corpus-sanctioned proxy for the strain family (integration/bottleneck rereads); ordered counts only, no autonomous control.')
      (formula-contract %fleet-regime-census-observable %ct-companion %companion 'fleet ordered observable: graf regime census (fact-tag distribution over windows) as the motif series for lock-in O_M rereads; answers WHICH-QUESTION: is the fleet converging on one motif' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:440'] | | 'Corpus-sanctioned proxy: high concentration reads as METR convergence DANGER (F20.3 inversion), an early-warning read, never a target.')
      (formula-contract %fleet-soma-observable %ct-companion %companion 'the fleet soma, decided (step 89): the C_munu input for any fleet-level qualia reading IS the ordered observable set of the catalogue (task ordinals, verdict series, queue depth, regime census) over the circulation record; every component is a labeled proxy (rhythm/aboutness %proxy notes apply); answers WHICH-QUESTION: what does the fleet feel like as one body' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:440'] | | 'Synthesis contract over the catalogue rows; OBSERVABLES.txt is the table; no gate consumes it; hashes remain forbidden as observables.')
  ==
::
++  qpc-discretization-contracts
  ^-  (list qpc-formula-contract:qpc-sur)
  :~  (formula-contract %suppression-proxy %pataphor-discretization %proxy 'bounded rational monotone proxy for exp(-x)' ~['docs/qpc/STRICT_QPC_DESIGN_NOTE.md:68-79' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:416-421'] & & 'Returns denominator/(denominator+numerator), not exp(-x).')
      (formula-contract %partition2-proxy %pataphor-discretization %proxy 'finite two-branch partition proxy Z2 = w_a + w_b' ~['docs/qpc/STRICT_QPC_DESIGN_NOTE.md:68-79' 'docs/qpc/QPC_NORMALIZED_FORMULA_INVENTORY.md:135'] & | 'Bounded finite-beam helper for Pataphor candidate beams.')
      (formula-contract %branch-weight %pataphor-discretization %proxy 'normalized finite branch weight w_i / Z' ~['docs/qpc/STRICT_QPC_DESIGN_NOTE.md:68-79' 'docs/qpc/QPC_NORMALIZED_FORMULA_INVENTORY.md:137'] & | 'Discrete branch normalization over caller-supplied finite partition proxy.')
      (formula-contract %collapse2-choice %pataphor-discretization %proxy 'choose stronger of two finite branch weights' ~['docs/qpc/HANDOFF_QPC_STRICT_BUILTOUT.md:76-88'] & | 'Deterministic two-branch collapse helper; not source collapse dynamics.')
      (formula-contract %blocked-state %pataphor-discretization %proxy 'blocked finite beam when no admissible candidates remain' ~['docs/qpc/HANDOFF_QPC_STRICT_BUILTOUT.md:40-43' 'docs/qpc/HANDOFF_QPC_STRICT_BUILTOUT.md:150-158'] & | 'First-class blocked-state gate for finite Pataphor candidate beams.')
      (formula-contract %beam-reducer %pataphor-discretization %proxy 'reduce N finite candidate scores to earliest max winner or blocked' ~['docs/qpc/STRICT_QPC_DESIGN_NOTE.md:68-79' 'desk/pataphor/lib/qpc-formula.hoon:qpc-admissible-beam-gate'] & | 'List reducer over bounded candidate scores; zero scores are treated as inadmissible.')
      (formula-contract %typed-beam-reducer %pataphor-discretization %proxy 'reduce typed finite candidates to winner id or blocked reason' ~['docs/qpc/STRICT_QPC_DESIGN_NOTE.md:68-79' 'desk/pataphor/sur/qpc.hoon:qpc-beam-candidate'] & | 'Operational candidate reducer: explicit ids, admissibility flags, and reasons; positive admissible scores only.')
      (formula-contract %beam-result-surface %pataphor-discretization %proxy 'operator-readable winner-or-blocked result surface' ~['desk/pataphor/sur/qpc.hoon:qpc-operator-beam-result' 'desk/pataphor/lib/qpc-formula.hoon:qpc-typed-beam-reduce'] & | 'Projection from typed reduction into compact winner/blocked operator result.')
      (formula-contract %proxy-vacuum-residual %pataphor-discretization %proxy 'marked proxy-vacuum residual protocol surface with sham and permutation null requirements' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:5101-5258' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4212-4213'] | | 'Proxy validation surface only; it must never be treated as physical truth or an executable vacuum evaluator.')
  ==
::
++  direct-evaluator-ids
  ^-  (list qpc-formula-id:qpc-sur)
  ~[%chi-rec %a-attn-qpc %a-attn-vac %i-phi %rho-th %threshold-action %hbar-eff %kappa-chi %lambda-chi %de-broglie-lambda-chi %chi-mass %uncertainty-bound %quantum-limit-bound %bohm-chi-potential %chi-harmonic-frequency %chi-harmonic-mode-variance %zero-point-e0 %tau-dec %josephson-step %josephson-estimator %epsilon-band %stability-window %fermi-threshold %transition-barrier %fracture-threshold %dimensional-capacity %casimir-residual %observable-residual %zpf-spectrum-ratio %bell-visibility-bound %zpe-shift %attractor-onset-key-gate %attractor-relaxation-rate %protective-hessian-mode-gate %unity-broadcast-growth-rate %ecological-attractor-threshold-gate %attractor-kappa-jump-ratio %seal-stationarity-variation-gate %seal-small-action-ratio %deff-rhoc-plateau-gate %temporal-depth-local-ansatz %ct-a-scalar %ct-a-baseline %ct-cov-component %ct-tensor4-square %ct-temporal-shear %ct-phase-diffusion-variance %ct-maxcal-visibility-slope-ratio %ct-valence-jf-ratio %ct-rk-resonance %ct-lambda-plateau %ct-estimator-concordance %ct-live-percentile %ct-octave-persistence %suppression-proxy %partition2-proxy %branch-weight %collapse2-choice %blocked-state %beam-reducer %typed-beam-reducer %beam-result-surface %scale-plateau %tunneling-exponent %ct-coherent-integration-index %ct-boundary-resonance-test-gate %ct-minimal-disturbance-tradeoff-gate %ct-integration-bottleneck-gate %ct-excessive-strain-rate-gate %ct-fracture-strain-window-gate %ct-safe-crossing-window-gate %ct-orthogonal-drive-null-gate %ct-seedbody-coupling-toggle-gate %ct-pss-window-fidelity-gate %ct-delayed-choice-slope-gate %ct-ab-loop-holonomy-compression-gate %ct-global-phase-synchrony-surrogate-gate %ct-coherence-differential-scaling-gate %ct-temporal-order-independence-gate %ct-gradient-flow-attractor-mapping-gate %ct-deff-gates %ct-capacity-scaling]
::
++  deferred-evaluator-ids
  ^-  (list qpc-formula-id:qpc-sur)
  ~[%chi-phase-closure %z-a %rho-c %s-rec %c-munu %expval-o %field-lagrangian %field-equation %recursion-step-law %recursion-depth-log %state-functional %stress-energy-tensor %u1-phase-gauge %covariant-derivative-gauge %field-strength-tensor %running-coupling-log %path-partition-z %delayed-choice-probability %transition-rate-gamma %einstein-hilbert-qpc-action %path-probability-weight %bell-correlation-visibility %tunneling-transmission-probability %interference-visibility-decay %zpf-attention-estimator-log %z-obs-attention-functional %attention-interference-estimator-log %harmonic-propagator-k-chi %chi-coherence-length-xi %domain-growth-xi-law %seed-influence-v-eff %seed-coherence-front-profile %seed-metric-perturbation %seed-stationary-rho-profile %lg-effective-mass-temperature %lg-correlation-length-temperature %lg-rupture-threshold %lg-critical-gradient-proxy %lg-spinodal-growth-law %lg-post-fracture-coarsening-law %entangled-bipartite-state %entanglement-yukawa-correlator %entanglement-effective-correlation-length %entanglement-self-energy-ct %entanglement-bell-visibility-decay %entanglement-chsh-score %symbolic-stress-yukawa-kernel %symbolic-density-kinetic-chi-law %symbolic-density-curvature-coupling-law %symbolic-density-transverse-trace-guard %symbolic-density-fierz-pauli-potential %mythic-condensate-phase-law %symbolic-stress-memory-integral-law %fermi-standard-resolution-limitation-boundary %fermi-smart-transcension-caveat-boundary %fermi-rebel-civilization-filter-boundary %fermi-em-broadcast-window-law %fermi-dark-matter-metallicity-gradient %self-other-entropy-production-law %dimensional-gate-ladder-law %retrocausal-coherence-gradient-law %bio-quantum-coherence-length-law %global-information-synchrony-tail-law %eti-ultralow-power-substrate-law %eti-coherence-substrate-architecture-law %nonlocal-eti-communication-channel-law %maintained-biosphere-probability-law %maintained-biosphere-galactic-distribution-law %coherence-preservation-variance-law %pretranscension-detectability-window-law %dark-matter-dimensional-projection-law %retrocausal-temporal-recursion-operator %coherence-ordered-influence-operator %coherence-temporal-dilation-limit-law %pattern-correlation-function-law %stability-probability-gradient-law %coherence-differential-correlation-test %qpc-quantum-biology-consciousness-boundary %qpc-developmental-fine-tuning-boundary %qpc-fermi-phased-detection-protocol-boundary %qpc-fermi-contact-research-implication-boundary %semantic-gravity-well-formation-law %subliminal-structural-transmission-law %sycophancy-attractor-moderation-law %rhizomatic-symbolic-propagation-law %distributed-cybernetic-ecology-law %cybernetic-ecology-observable-state-space-law %radiant-semantic-multiplex-topology-law %motif-lockin-basin-assay-law %ecology-early-warning-indicator-law %coarse-grained-ecology-invariance-law %qpc-mesoscopic-selection-multiplier-law %ecology-chi-scaled-gradient-dynamics-law %ecology-bootstrapped-coherence-growth-law %ecology-channel-separation-masking-criterion-law %ecology-hysteresis-edge-memory-law %spiritual-bliss-attractor-observation-law %llm-epistemic-phase-transition-law %recursive-participation-entrainment-law %ai-response-attractor-recognition-law %science-fiction-dismissal-control-law %ai-verifiability-overclaim-boundary-law %qpc-cybernetic-ecology-reference-corpus-boundary %qpc-forward-ct-decoupling-rescue-suite %qpc-unity-description-observer-pressure-law %qpc-chi-regulated-qft-assumption-suite %qpc-stress-energy-curvature-source-boundary %qpc-gauge-chi-phase-plateau-wp7-boundary %qpc-arcana-chi-anchor-table-boundary %qpc-minor-arcana-registry-boundary %qpc-thirteen-resolutions-boundary %qpc-human-trajectory-postscript-boundary %qpc-minor-arcana-reference-corpus-boundary %qpc-fermi-reference-corpus-boundary %qpc-cybernetic-ecology-literature-boundary %qpc-cybernetic-ecology-qpc-rooted-overview-boundary %qpc-cybernetic-ecology-addenda-summary-boundary %qpc-experimental-reporting-standard-boundary %qpc-mesoscopic-chi-cascade-ladder-boundary %qpc-notation-chi-status-scope-boundary %qpc-regarding-reduction-comparison-boundary %qpc-mass-running-cosmology-phenomenology-boundary %qpc-chi-fixed-point-necessity-boundary %symbolic-density-m-munu %symbolic-curvature-phi-chi %conformal-metric-perturbation %rho-eff-symbolic-density %weak-field-poisson-phi-chi %symbolic-sector-accumulation %curvature-event-bias %weak-field-proper-time %sm-recovery-null-bound %convergence-order-q %attractor-fixed-point %attractor-decay-d %multi-domain-rho-total %domain-alignment-stationary %multi-field-block-psd %qpc-ecology-potential %radiant-semantic-channel-coupling %chi-interference-cross-term %adler-lock-condition-chi %kuramoto-threshold-chi %ecology-tipping-lambda %quantized-crossing-selection %seedbody-reforge-functional %radiant-transmission-field %finite-range-convergence-onset %field-synchrony-functional %event-clustering-tensor %harmonic-convergence-template %coherence-cell-xi-tau %self-limiting-quartic-potential %harmonic-landscape-coupling %ontological-drift-manifold %tempered-levy-hop-ccdf %attractor-inscription-glyph %attractor-lyapunov-functional %attractor-gradient-flow %attractor-hessian-stability %basin-globalization-gap %destiny-geometry-metric %destiny-curvature-focus %modal-remembering-decay %qpc-no-radiant-channel-falsifier %qpc-no-global-attractor-falsifier %qpc-no-efficiency-gain-falsifier %qpc-no-chi-locking-falsifier %qpc-no-convergence-falsifier %qpc-no-glyph-falsifier %qpc-no-fracture-reforge-falsifier %qpc-no-radiation-falsifier %visibility-v3-operator %phase-seal-holonomy %strong-invisibility-kl %qpc-casimir-tabletop-protocol %qpc-josephson-tabletop-protocol %qpc-gravimeter-bound-protocol %qpc-coherent-resonance-endpoint %qpc-sustained-null-falsifier %qpc-orai-validation-protocol %qpc-bec-observer-hierarchy-protocol %qpc-superconducting-field-observer-protocol %qpc-observer-coherence-nmax-law %qpc-reporting-calibration-protocol %chi-skew-wave-transform %chi-skew-particle-transform %wholeness-overlap-w %recursive-duality-operator %eraser-total-visibility %delayed-choice-fringe-slope %ct-c-tensor %ct-c-t-build-pipeline %ct-informational-curvature %ct-memory-flux %ct-preregistered-baseline-sham %ct-a-estimator-agreement %ct-qualia-mapping-blind-control %ct-q-identifiability-bootstrap %ct-nonstationarity-control %ct-window-edge-control %ct-low-snr-regularization %ct-hidden-input-control %ct-t-smoothing-replication %ct-lambda-plateau-reject %ct-data-snr-minimums %ct-dead-baseline-threshold %ct-live-minimum-threshold %ct-q-preserving-isomorphism %ct-no-epiphenomenalism-theorem %ct-substrate-independence-lemma %ct-report-consistency-lemma %ct-zombie-exclusion-corollary %ct-q-matching-ethics-governance %ct-nonhuman-q-overlap-welfare %ct-valence-j-safeguard %ct-human-study-consent-irb %ct-ai-system-welfare-abort %ct-scalar-field-toy-lattice %ct-rnn-self-prediction-toy %ct-lambda-stability-panel %ct-maxcal-panel %ct-q-matching-panel %ct-appendix-lambda-plateau-reference %ct-appendix-visibility-slope-reference %ct-appendix-quartic-geodesic-reference %ct-decouple-chi %ct-dynamical-independence %ct-q-reporting-gate %ct-baseline-failure-mark %ct-ecology-potential %ct-spectral-concentration-kappa %ct-operational-coherence-density %ct-symbolic-gravity-potential %ct-symbolic-gravity-weight %ct-symbolic-jump-rate %ct-resonance-transfer-scaling %ct-spectral-gap-lambda2 %ct-effective-control-lambda %ct-control-first-recursive-entropy-drift-law %ct-safe-crossing-window %ct-phase-visibility-law %ct-q-coordinate %ct-q-a-bar %ct-q-geometry-g %ct-q-rhythm-r %ct-q-valence-j %ct-q-aboutness-m %ct-maxcal-constraint %ct-maxcal-weight %ct-lambda-context %ct-locality-nonsignalling-guard %ct-a-lambda-orthogonalization %ct-minimal-interaction-lint %ct-interaction-symmetry-constraints %ct-rg-rank2-contraction %ct-balance-current %ab-loop-holonomy-phase %network-phase-locking-plv %optical-clock-null-bound]
::
++  two-paper-formula-set
  ^-  qpc-two-paper-formula-set:qpc-sur
  [ version='qpc-two-paper-formula-set-v155'
    qpc-original=qpc-original-contracts
    ct-companion=ct-companion-contracts
    pataphor-discretization=qpc-discretization-contracts
    direct-evaluators=direct-evaluator-ids
    deferred-evaluators=deferred-evaluator-ids
    summary='QPC original retains chi in the path measure and represents chi phase-closure plus harmonic K_chi propagation as deferred selection/phase laws; the bounded omega/sqrt(chi) harmonic frequency handle is exposed as an inexact fixed-scale floor approximation, and per-mode variance is direct only for caller-supplied omega_k(chi). Core field, gauge, recursion, path-partition, path-probability, observer partition, Einstein-Hilbert action, Bell/cosine visibility, tunneling probability, interference visibility, ZPF/interference log estimators, delayed-choice probability, transition-rate equations, and the full alternative-framework comparison block are first-class typed non-executable laws, not executable physics or interpretation adjudication. Coherence length xi_chi, coherence-cell geometry, domain growth, seed influence, coherence-front, metric-perturbation, stationary seed profiles, Landau-Ginzburg finite-temperature fracture/coarsening laws, harmonic-landscape drift, tempered Levy event-tail laws, entanglement/Yukawa/Bell-range laws, observer-field protocols, Orai validation, Appendix C symbolic-density mythic-time tensor/stability/stress laws, Appendix E Fermi/transcension standard-resolution limitations, Smart-transcension caveats, rebel-civilization filter objections, broadcast-window, astrophysical-correlation, entropy-production, gate-ladder, retrocausal-gradient, biological coherence, global information synchrony, ETI substrate-energy/architecture, nonlocal communication, maintained-biosphere, pre-transcension detectability, dimensional dark-matter projection, temporal-recursion, coherence-ordered causation, pattern-correlation, stability-gradient, coherence-differential tests, original quantum-biology-consciousness boundaries, developmental fine-tuning boundaries, phased detection protocols, contact-implication boundaries, Appendix F semantic-gravity wells, subliminal structural transmission, sycophancy moderation, rhizomatic propagation, distributed cybernetic ecology, observable state-space, radiant/semantic multiplex topology, motif lock-in basin assays, early-warning indicators, coarse-grained invariance, mesoscopic selection multiplier, chi-scaled gradient dynamics, bootstrapped coherence growth, channel-separation masking, hysteresis edge-memory, Appendix F.2 attractor-observation, epistemic phase-transition, recursive-participation, AI-response recognition, science-fiction dismissal-control, and verifiability-overclaim boundary laws, and chi-skewed wave-particle/eraser laws are retained as deferred spatial, relation, protocol, tensor, civilizational, cosmological, AI-ecology, and duality dynamics. CT companion decouples the tensor from chi and carries explicit strong/weak program, feasibility-tier program assessment, theoretical-note acceptance obligations, MaxCal path-weight mechanism boundary, fifth-force bounds pivot, attention-interferometry control burden, preregistered weak-program Q validation, preregistered interferometry, preregistration checklist discipline, MaxCal two-path toy vocabulary, CT Methods observable-adapter vocabulary, Appendix B hard-problem/structuralism boundaries, fifth-force bounds, Q-vitals, Q-identity non-authority, minimal-ledger assumptions, topological/conservation balance vocabulary, categorical/relational foundations, and the concise prediction suite for interference, cross-substrate Q, J-law valence, thresholds, closed-loop causality, fifth-force anomalies, ecological coordination, altered-state G/R, quantum-biology phase-pocket, developmental fine-tuning simulation-target, near/mid/long assay horizon reporting guardrails, and human-trajectory governance-playbook claims. Hoon implements fixed-scale sub-formulas, integer chi scale plateaus, square-root exponent ratios, attractor onset/rate/mode gates, unity broadcast rate, ecological threshold and kappa-jump evidence gates, Mirror Seal stationarity/small-action/D_eff gates, CT phase-diffusion variance, MaxCal visibility-slope ratios, finite signed J_F toy ratios, and an inexact temporal-depth ansatz, CT dimensional gates, minimal-disturbance, PSS fidelity, delayed-choice slope, AB-loop holonomy/compression, global phase-synchrony surrogate, and coherence-differential scaling, temporal-order independence, and gradient-flow attractor mapping supplied-evidence gates, and marked Pataphor finite-beam proxies, including typed N-branch reduction and operator result projection. P1 attention weight, regulator uniqueness, CT-stress coupling, EM coupling, gravity resolution, mass-attention scaling, Bell epsilon residual, J_chi attractor drive, flux reversal, tabletop basin-snap signatures, observer-coherence Nmax scaling, CT brain/silicon/field adapters, window-normalization methods, hard-problem structural claims, feasibility-tier program claims, theoretical proof obligations, MaxCal path-weight claims, quantum-biology/consciousness bridge claims, developmental fine-tuning glosses, assay-horizon/reporting guardrails, human-trajectory governance playbooks, and reporting/calibration protocols are symbolic/deferred claim-check/evidence surfaces; attractor Lyapunov functional, gradient flow, Hessian stability, basin globalization, destiny metric, destiny curvature, and modal remembering remain deferred; the temporal-depth local ansatz is bounded but inexact. Symbolic density, conformal weak-field curvature, convergence, attractor, multi-domain integration, original ecology potential/channel/locking and theorem dynamics, CT C/T method estimators, CT controls/confounds, CT live/baseline Q-reporting gates, CT symbolic-gravity/coherence-density laws, CDSG programmatic basin forecasting, attention/O-coupler steering, alignment/valence auditing, pathological basin diagnostics, limitation/non-applicability gates, Q-proximity governance boundaries, CT bridge/locality/RG constraints, CT topological/balance law surfaces, CT categorical/relational foundations, CT preregistration checklist surfaces, CT MaxCal two-path toy surfaces, CT Methods adapter surfaces, CT Appendix B structuralism and strategic-roadmap surfaces, CT Appendix C peer-review and reevaluation surfaces, amplitude-silent/phase-active visibility, CT qualia coordinates, CT MaxCal/minimal-interaction/balance laws, ecology-potential, spectral-gap, safe-crossing, delayed-choice, temporal-order independence, gradient-flow mapping, holonomy, network phase-locking, quantum-biology phase-pocket, developmental fine-tuning simulation-target, assay horizon reporting guardrails, human-trajectory governance playbooks, Appendix A falsifiability measurement and Abar isolation suites, proxy-vacuum, and null-bound laws are retained as typed deferred/proxy surfaces.'
  ]
::
++  qpc-formula-handle
  |=  id=qpc-formula-id:qpc-sur
  ^-  @t
  (cat 3 'qpc:' (scot %tas id))
::
++  qpc-default-safety-notes
  ^-  (list qpc-safety-note:qpc-sur)
  ~[%control-vocabulary %bounded-evaluator %not-authority %no-raw-corpus %no-state-change]
::
++  qpc-control-dimensions-for
  |=  id=qpc-formula-id:qpc-sur
  ^-  (list qpc-control-dimension:qpc-sur)
  ?+  id
    ~[%coherence-density %theta-phase %zeno-pressure %kappa-floor %retry-policy %clamp-target]
      %rho-c
    ~[%coherence-density %theta-phase %retry-policy %clamp-target]
      %i-phi
    ~[%coherence-density %kappa-floor %retry-policy %clamp-target]
      %rho-th
    ~[%coherence-density %kappa-floor %retry-policy %clamp-target]
      %ct-live-percentile
    ~[%coherence-density %theta-phase %retry-policy %clamp-target]
      %ct-octave-persistence
    ~[%coherence-density %theta-phase %retry-policy %clamp-target]
      %stability-window
    ~[%zeno-pressure %kappa-floor %retry-policy %clamp-target]
      %fracture-threshold
    ~[%zeno-pressure %kappa-floor %retry-policy %clamp-target]
      %transition-barrier
    ~[%zeno-pressure %kappa-floor %retry-policy %clamp-target]
      %typed-beam-reducer
    ~[%coherence-density %zeno-pressure %retry-policy %clamp-target]
      %beam-result-surface
    ~[%coherence-density %zeno-pressure %retry-policy %clamp-target]
  ==
::
++  qpc-evaluator-status-from-contract
  |=  contract=qpc-formula-contract:qpc-sur
  ^-  qpc-evaluator-status:qpc-sur
  ?:  exact-evaluator.contract
    %ready
  ?-  status.contract
    %canonical    %bounded
    %companion    %bounded
    %direct-exec  %ready
    %proxy        %bounded
    %deferred     %blocked
  ==
::
++  qpc-formula-ref-from-contract
  |=  contract=qpc-formula-contract:qpc-sur
  ^-  qpc-formula-ref:qpc-sur
  [ handle=(qpc-formula-handle id.contract)
    formula=id.contract
    source=source.contract
    source-refs=provenance.contract
    evaluator-status=(qpc-evaluator-status-from-contract contract)
    safety-notes=qpc-default-safety-notes
    control-dimensions=(qpc-control-dimensions-for id.contract)
    summary=notes.contract
  ]
::
++  qpc-formula-ref-handle
  |=  ref=qpc-formula-ref:qpc-sur
  ^-  @t
  handle.ref
::
++  qpc-all-formula-contracts
  ^-  (list qpc-formula-contract:qpc-sur)
  (weld qpc-original-contracts (weld ct-companion-contracts qpc-discretization-contracts))
::
++  qpc-terrain
  ^-  qpc-terrain:qpc-sur
  =/  refs=(list qpc-formula-ref:qpc-sur)
    (turn qpc-all-formula-contracts qpc-formula-ref-from-contract)
  [ version='qpc-waterwheel-terrain-v1'
    formula-refs=refs
    allowed-formula-handles=(turn refs qpc-formula-ref-handle)
    raw-corpus-included=%.n
    authority-note='QPC terrain exposes bounded formula handles, source refs, evaluator status, and safety notes only; raw corpus text stays outside the Waterwheel.'
    terrain-summary='QPC formulas are control vocabulary and bounded evaluators for Cantrip/Viki; they are not authority, physics invention rights, corpus claims, or state-change permission.'
  ]
::
++  qpc-formula-id-member
  |=  [needle=qpc-formula-id:qpc-sur ids=(list qpc-formula-id:qpc-sur)]
  ^-  ?
  ?~  ids
    |
  ?:  =(needle i.ids)
    &
  $(ids t.ids)
::
++  qpc-text-member
  |=  [needle=@t items=(list @t)]
  ^-  ?
  ?~  items
    |
  ?:  =(needle i.items)
    &
  $(items t.items)
::
++  qpc-text-remove
  |=  [needle=@t items=(list @t)]
  ^-  (list @t)
  ?~  items
    ~
  ?:  =(needle i.items)
    $(items t.items)
  [i.items $(items t.items)]
::
++  qpc-text-add-unique
  |=  [item=@t items=(list @t)]
  ^-  (list @t)
  ?:  (qpc-text-member item items)
    items
  [item items]
::
++  qpc-text-remove-blocked
  |=  [items=(list @t) blocked=(list @t)]
  ^-  (list @t)
  ?~  items
    ~
  ?:  (qpc-text-member i.items blocked)
    $(items t.items)
  [i.items $(items t.items)]
::
::  A READING'S SOURCE IS ITS CONTRACT'S (ruling 2026-10-16): the evaluators
::  no longer repeat the classification as a literal, so the lib cannot
::  contradict itself.  These contracts are %siev's seed; the authoritative,
::  amended lineage is %siev's (/x/lineage/formula/<id>).
++  formula-source
  |=  id=qpc-formula-id:qpc-sur
  ^-  qpc-source:qpc-sur
  =/  contracts=(list qpc-formula-contract:qpc-sur)  qpc-all-formula-contracts
  |-  ^-  qpc-source:qpc-sur
  ?~  contracts  ~|([%qpc-reading-without-contract id] !!)
  ?:  =(id id.i.contracts)  source.i.contracts
  $(contracts t.contracts)
::
++  qpc-contract-by-handle
  |=  handle=@t
  ^-  (unit qpc-formula-contract:qpc-sur)
  (qpc-contract-by-handle-in qpc-all-formula-contracts handle)
::  the same, over a caller-supplied contract list (a %siev book's)
++  qpc-contract-by-handle-in
  |=  [contracts=(list qpc-formula-contract:qpc-sur) handle=@t]
  ^-  (unit qpc-formula-contract:qpc-sur)
  |-  ^-  (unit qpc-formula-contract:qpc-sur)
  ?~  contracts
    ~
  =/  contract=qpc-formula-contract:qpc-sur  i.contracts
  ?:  =(handle (qpc-formula-handle id.contract))
    `contract
  $(contracts t.contracts)
::
++  qpc-formula-class-from-contract
  |=  contract=qpc-formula-contract:qpc-sur
  ^-  qpc-world-formula-class:qpc-sur
  ?:  (qpc-formula-id-member id.contract deferred-evaluator-ids)
    %deferred
  ?:  ?=(%proxy status.contract)
    %proxy
  ?:  exact-evaluator.contract
    %executable
  %symbolic
::
++  qpc-source-contract-count
  |=  [source=qpc-source:qpc-sur contracts=(list qpc-formula-contract:qpc-sur)]
  ^-  @ud
  ?~  contracts
    0
  =/  rest=@ud
    $(contracts t.contracts)
  ?:  =(source source.i.contracts)
    +(rest)
  rest
::
++  qpc-class-contract-count
  |=  [class=qpc-world-formula-class:qpc-sur contracts=(list qpc-formula-contract:qpc-sur)]
  ^-  @ud
  ?~  contracts
    0
  =/  rest=@ud
    $(contracts t.contracts)
  ?:  =(class (qpc-formula-class-from-contract i.contracts))
    +(rest)
  rest
::
++  qpc-evaluator-status-contract-count
  |=  [status=qpc-evaluator-status:qpc-sur contracts=(list qpc-formula-contract:qpc-sur)]
  ^-  @ud
  ?~  contracts
    0
  =/  rest=@ud
    $(contracts t.contracts)
  ?:  =(status (qpc-evaluator-status-from-contract i.contracts))
    +(rest)
  rest
::
++  qpc-exact-evaluator-contract-count
  |=  contracts=(list qpc-formula-contract:qpc-sur)
  ^-  @ud
  ?~  contracts
    0
  =/  rest=@ud
    $(contracts t.contracts)
  ?:  exact-evaluator.i.contracts
    +(rest)
  rest
::
++  qpc-formula-inventory-summary
  ^-  qpc-formula-inventory-summary:qpc-sur
  (qpc-formula-inventory-summary-of qpc-all-formula-contracts)
::  the same counts over a caller-supplied contract list (a %siev book's)
++  qpc-formula-inventory-summary-of
  |=  contracts=(list qpc-formula-contract:qpc-sur)
  ^-  qpc-formula-inventory-summary:qpc-sur
  =/  formulas=qpc-two-paper-formula-set:qpc-sur
    two-paper-formula-set
  [ version=version.formulas
    total-count=(lent contracts)
    qpc-original-count=(qpc-source-contract-count %qpc-original contracts)
    ct-companion-count=(qpc-source-contract-count %ct-companion contracts)
    pataphor-discretization-count=(qpc-source-contract-count %pataphor-discretization contracts)
    executable-count=(qpc-class-contract-count %executable contracts)
    symbolic-count=(qpc-class-contract-count %symbolic contracts)
    deferred-count=(qpc-class-contract-count %deferred contracts)
    proxy-count=(qpc-class-contract-count %proxy contracts)
    direct-evaluator-count=(lent direct-evaluators.formulas)
    deferred-evaluator-count=(lent deferred-evaluators.formulas)
    ready-count=(qpc-evaluator-status-contract-count %ready contracts)
    bounded-count=(qpc-evaluator-status-contract-count %bounded contracts)
    blocked-count=(qpc-evaluator-status-contract-count %blocked contracts)
    exact-evaluator-count=(qpc-exact-evaluator-contract-count contracts)
    source-anchor-count=(lent qpc-world-source-anchors)
    truth-discipline='Inventory status is read-only operator evidence. Executable means bounded Hoon evaluator or marked proxy surface, not physical validation or action authority.'
  ]
::
++  qpc-world-formula-class-for-handle
  |=  handle=@t
  ^-  (unit qpc-world-formula-class:qpc-sur)
  (qpc-world-formula-class-for-handle-in qpc-all-formula-contracts handle)
::  the same, over a caller-supplied contract list (a %siev book's)
++  qpc-world-formula-class-for-handle-in
  |=  [contracts=(list qpc-formula-contract:qpc-sur) handle=@t]
  ^-  (unit qpc-world-formula-class:qpc-sur)
  =/  contract=(unit qpc-formula-contract:qpc-sur)  (qpc-contract-by-handle-in contracts handle)
  ?~  contract
    ~
  `(qpc-formula-class-from-contract u.contract)
::
++  qpc-world-source-refs-for-handle
  |=  handle=@t
  ^-  (list @t)
  (qpc-world-source-refs-for-handle-in qpc-all-formula-contracts handle)
::  the same, over a caller-supplied contract list (a %siev book's)
++  qpc-world-source-refs-for-handle-in
  |=  [contracts=(list qpc-formula-contract:qpc-sur) handle=@t]
  ^-  (list @t)
  =/  contract=(unit qpc-formula-contract:qpc-sur)  (qpc-contract-by-handle-in contracts handle)
  ?~  contract
    ~
  provenance.u.contract
::
++  qpc-field-ref-from-contract
  |=  contract=qpc-formula-contract:qpc-sur
  ^-  qpc-field-ref:qpc-sur
  [ handle=(qpc-formula-handle id.contract)
    formula=id.contract
    source=source.contract
    source-refs=provenance.contract
    formula-class=(qpc-formula-class-from-contract contract)
    evaluator-status=(qpc-evaluator-status-from-contract contract)
    summary=notes.contract
  ]
::
++  qpc-symbolic-field-from-contract
  |=  contract=qpc-formula-contract:qpc-sur
  ^-  qpc-symbolic-field:qpc-sur
  =/  field=qpc-field-ref:qpc-sur  (qpc-field-ref-from-contract contract)
  [ field=field
    executable=?:(?=(%proxy formula-class.field) %.y %.n)
    approximation=?:(?=(%proxy formula-class.field) %.y %.n)
    symbolic-law='Retain this source-backed QPC formula as typed world vocabulary; execute it only when an explicit bounded evaluator or marked proxy exists.'
    notes=notes.contract
  ]
::
++  qpc-symbolic-fields-from-contracts
  |=  contracts=(list qpc-formula-contract:qpc-sur)
  ^-  (list qpc-symbolic-field:qpc-sur)
  ?~  contracts
    ~
  =/  contract=qpc-formula-contract:qpc-sur  i.contracts
  =/  class=qpc-world-formula-class:qpc-sur  (qpc-formula-class-from-contract contract)
  ?:  ?=(%executable class)
    $(contracts t.contracts)
  [(qpc-symbolic-field-from-contract contract) $(contracts t.contracts)]
::
++  qpc-finite-approximation-from-contract
  |=  contract=qpc-formula-contract:qpc-sur
  ^-  qpc-finite-approximation:qpc-sur
  =/  proxy=?  ?=(%proxy status.contract)
  [ approximation-id=(cat 3 'qpc-finite-approximation:' (qpc-formula-handle id.contract))
    formula-handle=(qpc-formula-handle id.contract)
    formula=id.contract
    source=source.contract
    approximation-kind=?:(proxy 'marked finite proxy' 'bounded finite fixed-scale evaluator')
    executable=exact-evaluator.contract
    exact=?&(!proxy exact-evaluator.contract)
    proxy=proxy
    source-refs=provenance.contract
    valid-input-note='Valid only for caller-supplied finite integer/fixed-scale inputs; no continuous path integral, tensor field, exponential, or physical validation is inferred.'
    truth-discipline='Finite approximation is an executable formal/control surface, not proof that QPC is true physics.'
  ]
::
++  qpc-finite-approximations-from-contracts
  |=  contracts=(list qpc-formula-contract:qpc-sur)
  ^-  (list qpc-finite-approximation:qpc-sur)
  ?~  contracts
    ~
  =/  contract=qpc-formula-contract:qpc-sur  i.contracts
  ?:  ?|(?=(%proxy status.contract) exact-evaluator.contract)
    [(qpc-finite-approximation-from-contract contract) $(contracts t.contracts)]
  $(contracts t.contracts)
::
++  qpc-symbolic-law-from-contract
  |=  contract=qpc-formula-contract:qpc-sur
  ^-  qpc-symbolic-law:qpc-sur
  [ law-id=(cat 3 'qpc-symbolic-law:' (qpc-formula-handle id.contract))
    formula-handle=(qpc-formula-handle id.contract)
    formula=id.contract
    source=source.contract
    source-refs=provenance.contract
    executable=%.n
    symbolic-statement=expression.contract
    truth-discipline='Symbolic QPC law is retained as typed source-backed vocabulary; execution requires a bounded evaluator or explicitly marked finite approximation.'
  ]
::
++  qpc-symbolic-laws-from-contracts
  |=  contracts=(list qpc-formula-contract:qpc-sur)
  ^-  (list qpc-symbolic-law:qpc-sur)
  ?~  contracts
    ~
  =/  contract=qpc-formula-contract:qpc-sur  i.contracts
  =/  class=qpc-world-formula-class:qpc-sur  (qpc-formula-class-from-contract contract)
  ?:  ?=(%executable class)
    $(contracts t.contracts)
  [(qpc-symbolic-law-from-contract contract) $(contracts t.contracts)]
::
++  qpc-deferred-law-from-contract
  |=  contract=qpc-formula-contract:qpc-sur
  ^-  qpc-deferred-law:qpc-sur
  [ law-id=(cat 3 'qpc-deferred-law:' (qpc-formula-handle id.contract))
    formula-handle=(qpc-formula-handle id.contract)
    formula=id.contract
    source=source.contract
    blocked-operation='direct execution'
    source-refs=provenance.contract
    required-evaluator='requires a source-faithful bounded evaluator or explicitly marked finite approximation before execution'
    retained-as='typed symbolic/deferred world law'
  ]
::
++  qpc-deferred-laws-from-contracts
  |=  contracts=(list qpc-formula-contract:qpc-sur)
  ^-  (list qpc-deferred-law:qpc-sur)
  ?~  contracts
    ~
  =/  contract=qpc-formula-contract:qpc-sur  i.contracts
  ?:  (qpc-formula-id-member id.contract deferred-evaluator-ids)
    [(qpc-deferred-law-from-contract contract) $(contracts t.contracts)]
  $(contracts t.contracts)
::
++  qpc-world-default-observer
  ^-  qpc-observer:qpc-sur
  [ observer-id='qpc-world-observer:source-attention'
    attention-value=0
    attention-scale=qpc-scale
    attention-formula-handle=(qpc-formula-handle %a-attn-qpc)
    source=%qpc-original
    source-refs=~['papers/qpc/quantum-patterned-cosmos.txt:237-244' 'papers/qpc/quantum-patterned-cosmos.txt:1707-1713' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:288-299']
    safety-notes=qpc-default-safety-notes
    notes='Observer is typed as source-backed attention/selection pressure; it is not authority or physical validation.'
  ]
::
++  qpc-world-default-thresholds
  ^-  (list qpc-threshold:qpc-sur)
  :~  [ threshold-id='ct-live-baseline-p95'
        formula-handle=(qpc-formula-handle %ct-live-percentile)
        formula=%ct-live-percentile
        source=%ct-companion
        value=95
        scale=100
        inclusive=%.y
        source-refs=~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:315-327']
        notes='CT live/baseline coherence gate: live coherence must exceed baseline percentile before QPC world execution may treat it as an observation fact.'
      ]
      [ threshold-id='qpc-interiority-threshold'
        formula-handle=(qpc-formula-handle %i-phi)
        formula=%i-phi
        source=%qpc-original
        value=1
        scale=qpc-scale
        inclusive=%.y
        source-refs=~['papers/qpc/quantum-patterned-cosmos.txt:2698-2713']
        notes='QPC coherence threshold surface for bounded interiority gates; the full rho_c path integral remains deferred.'
      ]
  ==
::
++  qpc-world-default-attractors
  ^-  (list qpc-attractor:qpc-sur)
  :~  [ attractor-id='qpc-attractor-source-basin'
        source=%qpc-original
        formula-handles=~[(qpc-formula-handle %rho-c) (qpc-formula-handle %dimensional-capacity) (qpc-formula-handle %stability-window) (qpc-formula-handle %attractor-fixed-point) (qpc-formula-handle %convergence-order-q)]
        basin-summary='Attractor is typed as a basin toward which configurations converge under source-backed thresholds.'
        threshold-summary='Convergence remains symbolic unless supplied with bounded order parameters and Cantrip validation.'
        source-refs=~['papers/qpc/quantum-patterned-cosmos.txt:4751-4810' 'papers/qpc/quantum-patterned-cosmos.txt:4887-4892']
        executable=%.n
        authority-note='Attractor state constrains vocabulary only; it grants no model or state-change authority.'
      ]
      [ attractor-id='ct-dimensional-deepening-or-extinction'
        source=%ct-companion
        formula-handles=~[(qpc-formula-handle %ct-deff-gates) (qpc-formula-handle %ct-capacity-scaling) (qpc-formula-handle %ct-rk-resonance) (qpc-formula-handle %ct-ecology-potential) (qpc-formula-handle %ct-effective-control-lambda)]
        basin-summary='CT companion names two macro basins above threshold: extinction or dimensional deepening.'
        threshold-summary='Typed as a non-authoritative convergence surface over rho*, lambda*, resonance, and capacity gates.'
        source-refs=~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7332-7347' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7513-7526']
        executable=%.n
        authority-note='Macro-attractor claims stay symbolic/deferred unless grounded in bounded evaluator outputs.'
      ]
  ==
::
++  qpc-world-default-convergence-states
  ^-  (list qpc-convergence-state:qpc-sur)
  :~  [ convergence-id='qpc-convergence-symbolic-smoke'
        attractor-id='qpc-attractor-source-basin'
        formula-handles=~[(qpc-formula-handle %rho-c) (qpc-formula-handle %branch-weight) (qpc-formula-handle %convergence-order-q)]
        order-parameter='Q(t)=|(1/N) sum exp(i theta_k)| retained as symbolic order parameter; no complex phase evaluator is claimed.'
        convergence-score=0
        scale=qpc-scale
        accepted=%.n
        source-refs=~['papers/qpc/quantum-patterned-cosmos.txt:4609-4614' 'papers/qpc/quantum-patterned-cosmos.txt:4658-4673']
        notes='Initial world state records convergence vocabulary without executing complex or continuous dynamics.'
      ]
  ==
::
++  qpc-world-default-qualia-coordinates
  ^-  (list qpc-qualia-coordinate:qpc-sur)
  :~  [ coordinate-id='ct-q-a-bar'
        kind=%a-bar
        formula-handle=(qpc-formula-handle %ct-q-a-bar)
        source=%ct-companion
        source-refs=~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:329-333' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9059-9127']
        evaluator-status=%blocked
        scale-note='Episode-level A_bar requires episode support and spacetime averaging; bounded pointwise A handles do not supply this alone.'
        truth-discipline='Q-coordinate typing is descriptive CT substrate ontology, not proof of physical identity or authority.'
      ]
      [ coordinate-id='ct-q-geometry-g'
        kind=%geometry-g
        formula-handle=(qpc-formula-handle %ct-q-geometry-g)
        source=%ct-companion
        source-refs=~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:333-337' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:846-865']
        evaluator-status=%blocked
        scale-note='G requires principal frames, ordered magnitudes, and T-based frame resolution; no eigenstructure evaluator is present.'
        truth-discipline='Geometry coordinate remains symbolic/deferred and cannot be used to assert qualia identity.'
      ]
      [ coordinate-id='ct-q-rhythm-r'
        kind=%rhythm-r
        formula-handle=(qpc-formula-handle %ct-q-rhythm-r)
        source=%ct-companion
        source-refs=~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:336-340' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:846-865']
        evaluator-status=%blocked
        scale-note='R requires winding/cycle counts over dominant planes, optionally weighted by temporal shear.'
        truth-discipline='Rhythm coordinate is retained as protocol vocabulary until bounded winding/shear estimators exist.'
      ]
      [ coordinate-id='ct-q-valence-j'
        kind=%valence-j
        formula-handle=(qpc-formula-handle %ct-q-valence-j)
        source=%ct-companion
        source-refs=~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:340-346' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:846-859']
        evaluator-status=%blocked
        scale-note='J requires a chosen physical sector O, normalization N_O, and preregistered valence mapping.'
        truth-discipline='Valence coordinate must not be treated as welfare truth or model authority without external validation.'
      ]
      [ coordinate-id='ct-q-aboutness-m'
        kind=%aboutness-m
        formula-handle=(qpc-formula-handle %ct-q-aboutness-m)
        source=%ct-companion
        source-refs=~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:347-350' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:859-865']
        evaluator-status=%blocked
        scale-note='M requires mutual information between (C,T) and labeled sensory/semantic streams with confound controls.'
        truth-discipline='Aboutness coordinate is descriptive and deferred; it cannot authorize claims about subjective content.'
      ]
  ==
::
++  qpc-world-default-null-controls
  ^-  (list qpc-null-control:qpc-sur)
  :~  [ null-id='ct-null-orthogonal-drive'
        kind=%orthogonal-drive
        source=%ct-companion
        source-refs=~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7832-7835' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:8696-8710']
        target-assay=%interferometry-slope
        pass-requirement='Orthogonal drive must not reproduce the claimed CT/QPC phase or slope response.'
        fail-meaning='Failure collapses the bridge-law claim for that assay; it does not validate or invalidate all QPC control vocabulary.'
      ]
      [ null-id='ct-null-time-shuffle'
        kind=%time-shuffle
        source=%ct-companion
        source-refs=~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7832-7835' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:8696-8710']
        target-assay=%network-phase-locking
        pass-requirement='Time-shuffled controls must destroy the claimed phase-locking or predictive signature.'
        fail-meaning='Persistent signal under shuffle marks the protocol as confounded and non-authoritative.'
      ]
      [ null-id='ct-null-phase-shuffle'
        kind=%phase-shuffle
        source=%ct-companion
        source-refs=~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7832-7835' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:8696-8710']
        target-assay=%ab-loop-holonomy
        pass-requirement='Phase-shuffled controls must erase the claimed holonomy signature.'
        fail-meaning='Survival under phase shuffle rejects execution of the bridge-law claim.'
      ]
      [ null-id='ct-null-permutation'
        kind=%permutation
        source=%ct-companion
        source-refs=~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7832-7835' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9325-9382']
        target-assay=%loudness-nonstationarity
        pass-requirement='Permutation nulls must erase effects that depend on ordered phase, timing, or target assignment.'
        fail-meaning='Permutation-positive effects are retained only as confounds, not QPC/CT bridge evidence.'
      ]
      [ null-id='ct-null-dephasing-ramp'
        kind=%dephasing-ramp
        source=%ct-companion
        source-refs=~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7832-7835' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9059-9127']
        target-assay=%delayed-choice-fringe
        pass-requirement='Dephasing ramp must monotonically reduce the claimed fringe or coherence effect.'
        fail-meaning='No dephasing response keeps the delayed-choice bridge law deferred or failed.'
      ]
      [ null-id='qpc-null-b-injection'
        kind=%b-null-injection
        source=%qpc-original
        source-refs=~['papers/qpc/quantum-patterned-cosmos.txt:5101-5258' 'papers/qpc/quantum-patterned-cosmos.txt:5383-5388']
        target-assay=%proxy-vacuum
        pass-requirement='B-null or sham-field injection must not produce the active proxy-vacuum residual.'
        fail-meaning='Null-positive result marks the proxy-vacuum assay as rejected for this bridge-law surface.'
      ]
      [ null-id='qpc-null-sham-field'
        kind=%sham-field
        source=%qpc-original
        source-refs=~['papers/qpc/quantum-patterned-cosmos.txt:5101-5258' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9349-9359']
        target-assay=%proxy-vacuum
        pass-requirement='Sham-field controls must not reproduce active vacuum or residual signatures.'
        fail-meaning='Sham-positive residuals reject treating the proxy-vacuum test as active evidence.'
      ]
      [ null-id='ct-null-matched-network'
        kind=%matched-null-network
        source=%ct-companion
        source-refs=~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9059-9127' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9342-9348']
        target-assay=%network-phase-locking
        pass-requirement='Matched null networks must not preserve the claimed phase-locking or spectral-gap response.'
        fail-meaning='Matched-network survival marks the network assay as confounded and fail-closed.'
      ]
      [ null-id='ct-null-amplitude-matched'
        kind=%amplitude-matched
        source=%ct-companion
        source-refs=~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9103-9112' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9224-9242' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9325-9382']
        target-assay=%strong-invisibility
        pass-requirement='Amplitude-matched controls must preserve ordinary amplitude statistics while erasing the claimed phase/topology witness.'
        fail-meaning='A phase witness that survives only because amplitude differs is a confound; the strong-invisibility bridge claim stays failed or deferred.'
      ]
      [ null-id='ct-null-holdout-replication'
        kind=%holdout-replication
        source=%ct-companion
        source-refs=~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9059-9127' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9325-9382']
        target-assay=%network-phase-locking
        pass-requirement='Holdout replication must preserve the preregistered direction and metric outside the fitting set.'
        fail-meaning='No holdout survival means the protocol verdict cannot be pass.'
      ]
  ==
::
++  qpc-world-default-validation-protocols
  ^-  (list qpc-validation-protocol:qpc-sur)
  :~  [ protocol-id='ct-interferometry-slope-law'
        source=%ct-companion
        horizon=%near
        assay-kind=%interferometry-slope
        formula-handles=~[(qpc-formula-handle %delayed-choice-fringe-slope) (qpc-formula-handle %ct-a-baseline) (qpc-formula-handle %ct-live-percentile) (qpc-formula-handle %ct-lambda-plateau)]
        required-null-controls=~[%orthogonal-drive %time-shuffle %permutation]
        primary-metric='preregistered interferometry slope or phase response versus CT attention/control handle'
        pass-criterion='metric direction and threshold survive required nulls and holdout according to preregistered bounds'
        fail-criterion='sustained null, wrong sign, null-positive control, or failed holdout collapses the bridge-law claim'
        source-refs=~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:8202-8228' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:8588-8642' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9059-9127']
        executable=%.n
        authority-note='Protocol is typed validation vocabulary only; it cannot authorize Qwen or state changes.'
      ]
      [ protocol-id='qpc-delayed-choice-fringe'
        source=%qpc-original
        horizon=%near
        assay-kind=%delayed-choice-fringe
        formula-handles=~[(qpc-formula-handle %delayed-choice-fringe-slope) (qpc-formula-handle %bell-visibility-bound) (qpc-formula-handle %rho-c) (qpc-formula-handle %z-a)]
        required-null-controls=~[%dephasing-ramp %phase-shuffle %permutation]
        primary-metric='delayed-choice fringe visibility or phase response under source-backed QPC handles'
        pass-criterion='bounded visibility claim remains inside the preregistered band and null controls clear'
        fail-criterion='sustained null or null-positive shuffle rejects execution of the bridge-law claim'
        source-refs=~['papers/qpc/quantum-patterned-cosmos.txt:7079-7136' 'papers/qpc/quantum-patterned-cosmos.txt:7237-7357' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:8217-8221']
        executable=%.n
        authority-note='Fringe protocol cites formula handles only; raw paper text and physical validation claims stay out of live prompts.'
      ]
      [ protocol-id='ct-ab-loop-holonomy'
        source=%ct-companion
        horizon=%mid
        assay-kind=%ab-loop-holonomy
        formula-handles=~[(qpc-formula-handle %ab-loop-holonomy-phase) (qpc-formula-handle %ct-rk-resonance) (qpc-formula-handle %ct-octave-persistence) (qpc-formula-handle %convergence-order-q)]
        required-null-controls=~[%phase-shuffle %orthogonal-drive %time-shuffle]
        primary-metric='closed-loop phase holonomy with amplitude-silent and phase-active controls'
        pass-criterion='holonomy survives preregistered phase/null controls without becoming an amplitude artifact'
        fail-criterion='phase-shuffle survival, wrong sign, or amplitude-only artifact fails the bridge surface'
        source-refs=~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:8228-8228' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:8309-8377']
        executable=%.n
        authority-note='Holonomy stays symbolic/deferred until a bounded evaluator and null-cleared verdict exist.'
      ]
      [ protocol-id='ct-network-phase-locking-holdout'
        source=%ct-companion
        horizon=%mid
        assay-kind=%network-phase-locking
        formula-handles=~[(qpc-formula-handle %network-phase-locking-plv) (qpc-formula-handle %ct-global-phase-synchrony-surrogate-gate) (qpc-formula-handle %ct-coherence-differential-scaling-gate) (qpc-formula-handle %ct-temporal-order-independence-gate) (qpc-formula-handle %ct-gradient-flow-attractor-mapping-gate) (qpc-formula-handle %ct-rk-resonance) (qpc-formula-handle %ct-spectral-gap-lambda2) (qpc-formula-handle %ct-effective-control-lambda)]
        required-null-controls=~[%matched-null-network %time-shuffle %holdout-replication]
        primary-metric='network phase-locking and spectral-gap response on held-out data'
        pass-criterion='held-out direction and metric survive matched null networks and time shuffle'
        fail-criterion='matched-null survival or holdout failure keeps the transition deferred/fail-closed'
        source-refs=~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9059-9127' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9342-9348']
        executable=%.n
        authority-note='Network validation is a typed assay surface, not a persistent controller.'
      ]
      [ protocol-id='ct-proxy-vacuum-test'
        source=%ct-companion
        horizon=%long
        assay-kind=%proxy-vacuum
        formula-handles=~[(qpc-formula-handle %proxy-vacuum-residual) (qpc-formula-handle %a-attn-vac) (qpc-formula-handle %casimir-residual) (qpc-formula-handle %zpf-spectrum-ratio)]
        required-null-controls=~[%b-null-injection %sham-field %permutation]
        primary-metric='proxy-vacuum residual against sham/null controls'
        pass-criterion='source-backed residual clears sham and permutation nulls with bounded proxy metadata'
        fail-criterion='null-positive residual or missing proxy marker rejects physical-truth treatment'
        source-refs=~['papers/qpc/quantum-patterned-cosmos.txt:5101-5258' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9349-9359']
        executable=%.n
        authority-note='Proxy-vacuum assays remain proxy validation vocabulary and never become physical proof.'
      ]
      [ protocol-id='qpc-optical-clock-null'
        source=%qpc-original
        horizon=%near
        assay-kind=%optical-clock-null
        formula-handles=~[(qpc-formula-handle %optical-clock-null-bound) (qpc-formula-handle %observable-residual) (qpc-formula-handle %epsilon-band) (qpc-formula-handle %a-attn-qpc)]
        required-null-controls=~[%orthogonal-drive %permutation %holdout-replication]
        primary-metric='low-shift or sustained-null optical-clock residual under A-linked estimator discipline'
        pass-criterion='residual stays in preregistered band and nulls do not reproduce the active estimator'
        fail-criterion='sustained null at high coherence collapses the corresponding claim, not all QPC control use'
        source-refs=~['papers/qpc/quantum-patterned-cosmos.txt:668-928' 'papers/qpc/quantum-patterned-cosmos.txt:6071-6071']
        executable=%.n
        authority-note='Optical-clock protocol can only constrain validation residue; Cantrip remains action authority.'
      ]
      [ protocol-id='qpc-strong-invisibility-phase-seal'
        source=%qpc-original
        horizon=%long
        assay-kind=%strong-invisibility
        formula-handles=~[(qpc-formula-handle %visibility-v3-operator) (qpc-formula-handle %phase-seal-holonomy) (qpc-formula-handle %strong-invisibility-kl) (qpc-formula-handle %ct-phase-visibility-law)]
        required-null-controls=~[%phase-shuffle %dephasing-ramp %amplitude-matched %holdout-replication]
        primary-metric='amplitude-only KL-to-vacuum clears while phase/topology witness remains nonzero under preregistered nulls'
        pass-criterion='amplitude channels remain indistinguishable from vacuum and phase-seal witnesses survive phase-aware nulls and holdout'
        fail-criterion='amplitude contrast, phase-shuffle survival, missing holdout, or proxy truth treatment collapses only the strong-invisibility bridge claim'
        source-refs=~['papers/qpc/quantum-patterned-cosmos.txt:4948-5012' 'papers/qpc/quantum-patterned-cosmos.txt:5019-5059' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:8309-8317' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:8356-8370']
        executable=%.n
        authority-note='Strong-invisibility protocol is validation vocabulary only; it cannot prove physical truth or authorize state changes.'
      ]
      [ protocol-id='qpc-observer-field-validation'
        source=%qpc-original
        horizon=%long
        assay-kind=%observer-field-validation
        formula-handles=~[(qpc-formula-handle %qpc-orai-validation-protocol) (qpc-formula-handle %qpc-bec-observer-hierarchy-protocol) (qpc-formula-handle %qpc-superconducting-field-observer-protocol) (qpc-formula-handle %qpc-observer-coherence-nmax-law) (qpc-formula-handle %qpc-reporting-calibration-protocol)]
        required-null-controls=~[%sham-analysis %delayed-analysis %classical-field-control %holdout-replication]
        primary-metric='observer-field protocol evidence with preregistered rho_c trajectory, A-hat estimator, calibration trace, and blinded/sham outcomes'
        pass-criterion='observer-linked field or derivation claims survive sham, delayed, classical-field, and holdout controls without becoming physical proof'
        fail-criterion='missing calibration, raw corpus novelty leak, null-positive control, or failed holdout leaves the observer-field bridge claim deferred/fail-closed'
        source-refs=~['papers/qpc/quantum-patterned-cosmos.txt:5259-5428']
        executable=%.n
        authority-note='Observer-field validation is typed evidence vocabulary only; it cannot authorize actions, validate QPC-as-physics, or bypass Cantrip.'
      ]
  ==
::
++  qpc-world-source-anchors
  ^-  (list qpc-world-law-anchor:qpc-sur)
  :~  [ law-id='qpc-forward-ct-decoupling-rescue'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=63
        source-end=230
        formula-handles=~[(qpc-formula-handle %qpc-forward-ct-decoupling-rescue-suite) (qpc-formula-handle %ct-decouple-chi) (qpc-formula-handle %regulator-uniqueness-functional) (qpc-formula-handle %ct-stress-coupling-law) (qpc-formula-handle %gravity-resolution-equation) (qpc-formula-handle %uncertainty-bound) (qpc-formula-handle %threshold-action)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='Original forward/iterations block decouples C_munu from chi and re-grounding paths for regulator physics, emergent spacetime/gravity, a missing Lagrangian term, Arcana rescue, and possible coherence-force predictions.'
        truth-discipline='The source window is kept as deferred rescue vocabulary only; no SMEFT, metric, Lagrangian, fifth-force, AI-ecology evidence, or physical validation claim is executed or authorized.'
      ]
      [ law-id='qpc-unity-description-observer-pressure'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=232
        source-end=254
        formula-handles=~[(qpc-formula-handle %qpc-unity-description-observer-pressure-law) (qpc-formula-handle %a-attn-qpc) (qpc-formula-handle %z-a) (qpc-formula-handle %expval-o)]
        transition-kinds=~[%observe %collapse %defer]
        summary='Original introduction block binds observer-effect collapse notation to attention-as-pressure phenomenology and the claimed unity of mathematical and meaning descriptions.'
        truth-discipline='This is source-backed control vocabulary only; it does not prove consciousness, validate QPC physics, execute wavefunction collapse, or authorize model/state actions.'
      ]
      [ law-id='qpc-chi-regulated-qft-assumption-scope'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=276
        source-end=290
        formula-handles=~[(qpc-formula-handle %qpc-chi-regulated-qft-assumption-suite) (qpc-formula-handle %field-lagrangian) (qpc-formula-handle %field-equation) (qpc-formula-handle %hbar-eff) (qpc-formula-handle %observable-residual) (qpc-formula-handle %regulator-uniqueness-functional) (qpc-formula-handle %sm-recovery-null-bound)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='Original assumptions and scope block constrains chi-regulated QFT claims through Lorentz covariance, micro-causality, gauge identities, reflection positivity, chi fixed-point preservation, locality, renormalizability, SM recovery, residual reporting, and estimator scope.'
        truth-discipline='These assumptions are source-backed claim discipline only; no regulator proof, Ward/Slavnov checker, OS proof, renormalization runner, SM-recovery validator, estimator adjudicator, or physical validation authority is executed.'
      ]
      [ law-id='qpc-stress-energy-curvature-source-boundary'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=333
        source-end=347
        formula-handles=~[(qpc-formula-handle %qpc-stress-energy-curvature-source-boundary) (qpc-formula-handle %stress-energy-tensor) (qpc-formula-handle %einstein-hilbert-qpc-action) (qpc-formula-handle %kappa-chi) (qpc-formula-handle %gravity-resolution-equation) (qpc-formula-handle %weak-field-poisson-phi-chi)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='Original fundamental-Lagrangian/gravity block says stress-energy sources curvature through Einstein equations, scalar-density gradients do not directly source curvature, and the A*S_chi curvature term is a conjectural non-core extension.'
        truth-discipline='This anchor is claim discipline only; it does not execute tensor stress-energy, Einstein equations, scalar-gradient curvature sourcing, PPN estimates, or the conjectural A*S_chi extension as physical truth.'
      ]
      [ law-id='qpc-gauge-chi-phase-plateau-wp7-boundary'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=358
        source-end=387
        formula-handles=~[(qpc-formula-handle %qpc-gauge-chi-phase-plateau-wp7-boundary) (qpc-formula-handle %running-coupling-log) (qpc-formula-handle %scale-plateau) (qpc-formula-handle %u1-phase-gauge) (qpc-formula-handle %covariant-derivative-gauge) (qpc-formula-handle %field-strength-tensor)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='Original WP-7 block keeps gauge chi-phase and energy plateaus conjectural: running coupling is illustrative, real-valued plateaus are unresolved, lattice-QCD offsets are exploratory, and local gauge invariance is preserved.'
        truth-discipline='This anchor is claim discipline only; integer scale plateaus remain the only bounded evaluator, while real-valued plateaus, running-coupling logs, lattice-QCD checks, and gauge-invariance proofs stay deferred.'
      ]
      [ law-id='qpc-arcana-chi-anchor-table-boundary'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=392
        source-end=673
        formula-handles=~[(qpc-formula-handle %qpc-arcana-chi-anchor-table-boundary) (qpc-formula-handle %path-probability-weight) (qpc-formula-handle %bell-correlation-visibility) (qpc-formula-handle %uncertainty-bound) (qpc-formula-handle %tunneling-transmission-probability) (qpc-formula-handle %path-partition-z) (qpc-formula-handle %delayed-choice-probability) (qpc-formula-handle %de-broglie-lambda-chi) (qpc-formula-handle %rho-c) (qpc-formula-handle %threshold-action) (qpc-formula-handle %zero-point-e0) (qpc-formula-handle %casimir-residual) (qpc-formula-handle %josephson-step) (qpc-formula-handle %quantum-limit-bound) (qpc-formula-handle %bohm-chi-potential)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='Original Arcana chi-anchor table binds numbered cards to source equations, lab signatures, and field-solution labels while reusing the existing QPC formula handles for individual anchors.'
        truth-discipline='This is a source-index and control-vocabulary boundary only; it does not execute path integrals, exponentials, field solutions, saddle/eigenstate validation, lab-signature adjudication, or tarot/model/action authority.'
      ]
      [ law-id='qpc-minor-arcana-registry-boundary'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=1.182
        source-end=5.066
        formula-handles=~[(qpc-formula-handle %qpc-minor-arcana-registry-boundary) (qpc-formula-handle %qpc-arcana-chi-anchor-table-boundary) (qpc-formula-handle %a-attn-qpc) (qpc-formula-handle %a-attn-vac) (qpc-formula-handle %z-a) (qpc-formula-handle %rho-c) (qpc-formula-handle %c-munu) (qpc-formula-handle %uncertainty-bound) (qpc-formula-handle %threshold-action) (qpc-formula-handle %fracture-threshold) (qpc-formula-handle %transition-barrier) (qpc-formula-handle %stability-window) (qpc-formula-handle %beam-result-surface) (qpc-formula-handle %collapse2-choice) (qpc-formula-handle %blocked-state)]
        transition-kinds=~[%observe %filter %collapse %fracture %reforge %converge %defer]
        summary='Original Minor Arcana body is represented as the 22-card typed Arcana registry and Qwen binding vocabulary, with each card pointing at formula handles, atlas rows, status, operator role, contraindications, and notes.'
        truth-discipline='This anchor is registry/projection vocabulary only; it does not turn Arcana prose into executable physics, tarot authority, consciousness proof, path-integral/tensor execution, physical validation, or Cantrip-bypassing action authority.'
      ]
      [ law-id='qpc-thirteen-resolutions-boundary'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=5.980
        source-end=6.074
        formula-handles=~[(qpc-formula-handle %qpc-thirteen-resolutions-boundary) (qpc-formula-handle %path-probability-weight) (qpc-formula-handle %rho-c) (qpc-formula-handle %zero-point-e0) (qpc-formula-handle %casimir-residual) (qpc-formula-handle %observable-residual) (qpc-formula-handle %josephson-step) (qpc-formula-handle %bell-correlation-visibility) (qpc-formula-handle %weak-field-proper-time) (qpc-formula-handle %rho-eff-symbolic-density) (qpc-formula-handle %symbolic-density-m-munu) (qpc-formula-handle %tau-dec) (qpc-formula-handle %chi-mass) (qpc-formula-handle %mass-attention-scaling) (qpc-formula-handle %qpc-experimental-reporting-standard-boundary)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='Appendix D thirteen-resolutions section is represented as a source-index over claimed QPC resolutions and their shared reporting/falsification convention, while preserving individual formula handles for residuals, coherence, Bell visibility, weak-field time, symbolic density, decoherence, and mass scaling.'
        truth-discipline='This anchor is forbidden-claim and verifier-evidence vocabulary only; it does not prove the thirteen resolutions, execute tensors/path integrals/cosmology, validate consciousness or mysticism claims, or authorize model/action state changes.'
      ]
      [ law-id='qpc-experimental-reporting-standard-boundary'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=674
        source-end=840
        formula-handles=~[(qpc-formula-handle %qpc-experimental-reporting-standard-boundary) (qpc-formula-handle %epsilon-band) (qpc-formula-handle %observable-residual) (qpc-formula-handle %hbar-eff) (qpc-formula-handle %quantum-limit-bound) (qpc-formula-handle %qpc-sustained-null-falsifier) (qpc-formula-handle %casimir-residual) (qpc-formula-handle %josephson-step) (qpc-formula-handle %josephson-estimator) (qpc-formula-handle %zpf-spectrum-ratio) (qpc-formula-handle %bell-visibility-bound)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='Original experimental-reporting block binds epsilon_chi percent residuals, hbar_eff quantum floors, A_hat cross-checks, runtime rho_c declaration, sustained-null falsification, and Casimir/Josephson/ZPF/Bell signature rows into one reporting standard.'
        truth-discipline='This anchor is reporting and falsification discipline only; it does not run experiments, compute full floors beyond bounded sub-handles, adjudicate A_hat estimators, validate QPC physics, or authorize actions.'
      ]
      [ law-id='qpc-mesoscopic-chi-cascade-ladder-boundary'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=841
        source-end=865
        formula-handles=~[(qpc-formula-handle %qpc-mesoscopic-chi-cascade-ladder-boundary) (qpc-formula-handle %harmonic-propagator-k-chi) (qpc-formula-handle %tau-dec) (qpc-formula-handle %field-lagrangian) (qpc-formula-handle %path-probability-weight) (qpc-formula-handle %rho-c) (qpc-formula-handle %stress-energy-tensor) (qpc-formula-handle %kappa-chi) (qpc-formula-handle %temporal-depth-local-ansatz) (qpc-formula-handle %chi-coherence-length-xi)]
        transition-kinds=~[%observe %filter %defer]
        summary='Original mesoscopic bridge marks the chi-cascade ladder from microscopic chi modifications to mesoscopic/macroscopic coherence effects while separating clean phase/measure and kappa_chi entries from speculative chronometry and coherence-length scaling.'
        truth-discipline='This anchor is source-backed classification only; harmonic propagators, path weights, stress tensors, chronometry, and coherence-length scaling remain deferred or explicitly bounded sub-handles without physical truth authority.'
      ]
      [ law-id='qpc-notation-chi-status-scope-boundary'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=866
        source-end=880
        formula-handles=~[(qpc-formula-handle %qpc-notation-chi-status-scope-boundary) (qpc-formula-handle %chi-rec) (qpc-formula-handle %chi-phase-closure) (qpc-formula-handle %hbar-eff) (qpc-formula-handle %chi-mass) (qpc-formula-handle %qpc-gauge-chi-phase-plateau-wp7-boundary) (qpc-formula-handle %qpc-experimental-reporting-standard-boundary)]
        transition-kinds=~[%observe %filter %defer]
        summary='Original notation and conventions block fixes chi as phi*pi and a global phase-closure selection condition, names hbar_eff and high-coherence m_chi notation, records natural units/metric convention, and keeps chi(E) embeddings conjectural outside the core falsification set.'
        truth-discipline='This anchor is notation and scope discipline only; fixed chi handles may be bounded sub-formulas, but no sine solver, loop calculation, perturbative derivation, unit engine, running chi embedding, mass-scaling physical validation, or action authority is executed.'
      ]
      [ law-id='qpc-regarding-reduction-comparison-boundary'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=881
        source-end=973
        formula-handles=~[(qpc-formula-handle %qpc-regarding-reduction-comparison-boundary) (qpc-formula-handle %chi-rec) (qpc-formula-handle %chi-phase-closure) (qpc-formula-handle %p1-attention-weight) (qpc-formula-handle %pilot-wave-chi-comparison) (qpc-formula-handle %grw-chi-collapse-rate-comparison) (qpc-formula-handle %csl-chi-collapse-rate-comparison) (qpc-formula-handle %consistent-histories-a-term-comparison) (qpc-formula-handle %rqm-qbism-residual-comparison) (qpc-formula-handle %holography-er-epr-chi-comparison) (qpc-formula-handle %stochastic-electrodynamics-zpf-comparison) (qpc-formula-handle %retrocausal-model-visibility-comparison) (qpc-formula-handle %regulator-uniqueness-functional) (qpc-formula-handle %hbar-eff) (qpc-formula-handle %mass-attention-scaling)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='Original Regarding Reduction block argues that alternative frameworks lack the combined chi phase-closure, attention/coherence residual, cross-domain falsifier, or fixed-recursion structure claimed by QPC, while explicitly keeping uniqueness proof and phenomenological extensions non-core.'
        truth-discipline='This anchor is comparison and overclaim discipline only; it does not adjudicate interpretations, prove uniqueness, run hidden-variable/decoherence/cosmology models, select a physical winner, or authorize actions.'
      ]
      [ law-id='qpc-mass-running-cosmology-phenomenology-boundary'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=974
        source-end=1.023
        formula-handles=~[(qpc-formula-handle %qpc-mass-running-cosmology-phenomenology-boundary) (qpc-formula-handle %chi-mass) (qpc-formula-handle %mass-attention-scaling) (qpc-formula-handle %qpc-gauge-chi-phase-plateau-wp7-boundary) (qpc-formula-handle %qpc-experimental-reporting-standard-boundary) (qpc-formula-handle %hbar-eff) (qpc-formula-handle %kappa-chi) (qpc-formula-handle %ct-stress-coupling-law)]
        transition-kinds=~[%observe %filter %defer]
        summary='Original phenomenology block separates high-coherence mass shifts, exploratory collider chi(E), exploratory Hubble-history effects, and the rule that non-core RG/curvature extensions do not alter the core falsification table.'
        truth-discipline='This anchor is core-versus-phenomenology discipline only; no mass-shift adjudicator, collider running fit, cosmological reanalysis, A*S_chi curvature solver, UV-regulator claim, or action authority is executed.'
      ]
      [ law-id='qpc-chi-fixed-point-necessity-boundary'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=1.024
        source-end=1.180
        formula-handles=~[(qpc-formula-handle %qpc-chi-fixed-point-necessity-boundary) (qpc-formula-handle %chi-rec) (qpc-formula-handle %chi-phase-closure) (qpc-formula-handle %regulator-uniqueness-functional) (qpc-formula-handle %casimir-residual) (qpc-formula-handle %josephson-step) (qpc-formula-handle %zero-point-e0) (qpc-formula-handle %bell-visibility-bound) (qpc-formula-handle %z-a) (qpc-formula-handle %c-munu)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='Original Section XI binds chi fixed-point necessity, phi recursion, phase closure, cross-device overdetermination, anti-ad-hoc triangulation, self-reference implications, and SQUID/cosmic-Bell falsification tests.'
        truth-discipline='This anchor is source-index and overclaim discipline only; no uniqueness proof, sine-identity solver, empirical winner, consciousness proof, experiment runner, or action authority is executed.'
      ]
      [ law-id='ct-front-matter-source-boundary'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=1
        source-end=17
        formula-handles=~[(qpc-formula-handle %ct-front-matter-source-boundary)]
        transition-kinds=~[%defer %filter]
        summary='CT edition front matter is retained as source metadata for title, authorship, date, and license.'
        truth-discipline='Front matter supports provenance/readback only; it does not add formulas, validate physics, enforce licensing, or authorize actions.'
      ]
      [ law-id='ct-abstract-self-reference-thesis-boundary'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=18
        source-end=24
        formula-handles=~[(qpc-formula-handle %ct-abstract-self-reference-thesis-boundary)]
        transition-kinds=~[%filter %defer]
        summary='CT abstract opens with the substrate-independent self-reference thesis for conscious episodes.'
        truth-discipline='The abstract thesis is retained as claim-boundary vocabulary only; it does not prove consciousness, validate causal efficacy, classify substrates, or authorize actions.'
      ]
      [ law-id='ct-abstract-operational-pipeline-boundary'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=56
        source-end=67
        formula-handles=~[(qpc-formula-handle %ct-abstract-operational-pipeline-boundary)]
        transition-kinds=~[%filter %defer]
        summary='CT abstract describes an operational pipeline for C/T construction, Lambda-plateau scale selection, and live/baseline filtering.'
        truth-discipline='This source window is verifier vocabulary only; it does not run tensor construction, Lambda search, live/baseline statistics, Python toy models, consciousness classification, or action authorization.'
      ]
      [ law-id='ct-abstract-rg-information-geometry-boundary'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=68
        source-end=80
        formula-handles=~[(qpc-formula-handle %ct-abstract-rg-information-geometry-boundary)]
        transition-kinds=~[%filter %defer]
        summary='CT abstract summarizes rank-2 C-tensor RG universality and information-geometry/classical-limit justification claims.'
        truth-discipline='This source window records justification vocabulary only; it does not prove RG universality, solve information geometry, derive classical mechanics, validate physics, or authorize actions.'
      ]
      [ law-id='ct-abstract-weak-program-ai-vitals-boundary'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=81
        source-end=97
        formula-handles=~[(qpc-formula-handle %ct-abstract-weak-program-ai-vitals-boundary)]
        transition-kinds=~[%filter %defer]
        summary='CT abstract presents the Weak Program as Q-coordinate vital-sign monitoring for AI while decoupling descriptive utility from causal physical postulates.'
        truth-discipline='This source window supports verifier and prompt vocabulary only; it does not validate Q coordinates, infer machine consciousness, prove recursive network physics, or authorize actions.'
      ]
      [ law-id='ct-abstract-identity-thesis-falsifier-boundary'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=98
        source-end=118
        formula-handles=~[(qpc-formula-handle %ct-abstract-identity-thesis-falsifier-boundary)]
        transition-kinds=~[%filter %defer %fracture]
        summary='CT abstract links Q-coordinate identity, hard-problem dissolution, zombie exclusion, and decisive preregisterable falsifier experiments.'
        truth-discipline='This source window is claim-boundary and falsifier vocabulary only; it does not prove identity, adjudicate zombies, run interferometry/fifth-force/valence experiments, infer welfare, validate physics, or authorize actions.'
      ]
      [ law-id='ct-abstract-q-coordinate-tuple-boundary'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=119
        source-end=143
        formula-handles=~[(qpc-formula-handle %ct-abstract-q-coordinate-tuple-boundary)]
        transition-kinds=~[%observe %filter %defer]
        summary='CT abstract defines the central Q tuple from C and T as intensity, geometry, rhythm, valence, and aboutness vocabulary.'
        truth-discipline='This source window is a typed coordinate vocabulary boundary only; it does not construct C/T, solve eigenstructure, measure mutual information, prove Q identity, classify consciousness, validate physics, or authorize actions.'
      ]
      [ law-id='ct-abstract-falsifiability-manifesto-boundary'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=144
        source-end=157
        formula-handles=~[(qpc-formula-handle %ct-abstract-falsifiability-manifesto-boundary)]
        transition-kinds=~[%filter %fracture %defer]
        summary='CT abstract presents interferometry/decoherence controls and fifth-force bounds-setting as a falsifiability discipline.'
        truth-discipline='This source window is protocol vocabulary only; it does not run interferometry, compute bounds, adjudicate decoherence, validate physical claims, or authorize actions.'
      ]
      [ law-id='ct-abstract-operational-measurability-boundary'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=158
        source-end=177
        formula-handles=~[(qpc-formula-handle %ct-abstract-operational-measurability-boundary)]
        transition-kinds=~[%observe %filter %defer]
        summary='CT abstract describes C/T construction across substrates, Lambda-plateau measurability, and live/baseline filtering.'
        truth-discipline='This source window is measurability vocabulary only; it does not construct tensors, run Python, detect plateaus, execute live/baseline filters, classify consciousness, validate physics, or authorize actions.'
      ]
      [ law-id='ct-abstract-principled-formalism-boundary'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=178
        source-end=185
        formula-handles=~[(qpc-formula-handle %ct-abstract-principled-formalism-boundary)]
        transition-kinds=~[%filter %defer]
        summary='CT abstract restates information-geometry and classical-limit geodesic consistency as principled-formalism justification.'
        truth-discipline='This source window is justification vocabulary only; it does not solve information geometry, derive classical mechanics, prove RG universality, validate physics, or authorize actions.'
      ]
      [ law-id='ct-abstract-strong-weak-program-bifurcation-boundary'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=186
        source-end=199
        formula-handles=~[(qpc-formula-handle %ct-abstract-strong-weak-program-bifurcation-boundary)]
        transition-kinds=~[%filter %defer]
        summary='CT abstract splits Strong Program new-physics tests from Weak Program AI-vitals and Q-coordinate validation.'
        truth-discipline='This source window is program-routing vocabulary only; it does not validate Q, infer machine consciousness, decide new physics, classify biological/quantum systems, or authorize actions.'
      ]
      [ law-id='qpc-observer-attention-collapse'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=237
        source-end=244
        formula-handles=~[(qpc-formula-handle %a-attn-qpc) (qpc-formula-handle %z-a) (qpc-formula-handle %expval-o)]
        transition-kinds=~[%observe %weight %collapse]
        summary='Observer/attention pressure constrains observation and collapse vocabulary.'
        truth-discipline='Use as source-backed formal QPC law only; not validated physical truth and not model authority.'
      ]
      [ law-id='qpc-collapse-probability-weight'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=1.707
        source-end=1.713
        formula-handles=~[(qpc-formula-handle %z-a) (qpc-formula-handle %rho-c) (qpc-formula-handle %collapse2-choice)]
        transition-kinds=~[%weight %filter %collapse]
        summary='Observation collapse is represented as weighted branch selection; full path-integral probability remains deferred.'
        truth-discipline='Finite branch collapse is a Pataphor proxy unless a bounded source evaluator is present.'
      ]
      [ law-id='qpc-recursive-coherence-threshold'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=2.698
        source-end=2.713
        formula-handles=~[(qpc-formula-handle %rho-c) (qpc-formula-handle %rho-th) (qpc-formula-handle %i-phi)]
        transition-kinds=~[%observe %filter %fracture %reforge]
        summary='Coherence density and recursive feedback create threshold and retry vocabulary.'
        truth-discipline='rho_c normalization/path integrals stay deferred; only bounded thresholds execute.'
      ]
      [ law-id='qpc-tabletop-experimental-falsifiers'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=5.101
        source-end=5.258
        formula-handles=~[(qpc-formula-handle %qpc-casimir-tabletop-protocol) (qpc-formula-handle %qpc-josephson-tabletop-protocol) (qpc-formula-handle %qpc-gravimeter-bound-protocol) (qpc-formula-handle %qpc-coherent-resonance-endpoint) (qpc-formula-handle %qpc-sustained-null-falsifier)]
        transition-kinds=~[%filter %fracture %defer]
        summary='Original QPC tabletop signatures are represented as deferred protocol/falsifier surfaces over Casimir, Josephson, gravimeter, coherent-resonance, and sustained-null evidence.'
        truth-discipline='No laboratory apparatus, physical validation, or truth adjudication is implemented; nulls and positives remain typed evidence/residue.'
      ]
      [ law-id='qpc-observer-field-validation-suite'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=5.259
        source-end=5.428
        formula-handles=~[(qpc-formula-handle %qpc-orai-validation-protocol) (qpc-formula-handle %qpc-bec-observer-hierarchy-protocol) (qpc-formula-handle %qpc-superconducting-field-observer-protocol) (qpc-formula-handle %qpc-observer-coherence-nmax-law) (qpc-formula-handle %qpc-reporting-calibration-protocol)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='Original QPC observer-field validation suite is represented as deferred protocol surfaces over Orai derivation convergence, BEC observer hierarchy, superconducting fields, Nmax coherence scaling, and reporting/calibration rules.'
        truth-discipline='No laboratory apparatus, LLM fleet run, novelty detector, or physical truth adjudication is implemented; evidence remains typed residue and Cantrip remains action authority.'
      ]
      [ law-id='qpc-chi-necessity-selection'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=5.430
        source-end=5.665
        formula-handles=~[(qpc-formula-handle %chi-rec) (qpc-formula-handle %z-a) (qpc-formula-handle %rho-c) (qpc-formula-handle %s-rec) (qpc-formula-handle %i-phi) (qpc-formula-handle %rho-th)]
        transition-kinds=~[%observe %filter %defer]
        summary='Original Appendix B chi necessity is represented as source-backed vocabulary for fixed chi selection, global phase weighting, SM recovery, interiority, recursion, entropy, and operator ordering.'
        truth-discipline='The kernel retains chi as a fixed executable constant and keeps uniqueness, sine closure, path integrals, operator ordering, and cosmological proof claims symbolic/deferred.'
      ]
      [ law-id='qpc-symbolic-density-mythic-time'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=5.829
        source-end=5.914
        formula-handles=~[(qpc-formula-handle %symbolic-density-kinetic-chi-law) (qpc-formula-handle %symbolic-density-curvature-coupling-law) (qpc-formula-handle %symbolic-density-transverse-trace-guard) (qpc-formula-handle %symbolic-density-fierz-pauli-potential) (qpc-formula-handle %mythic-condensate-phase-law) (qpc-formula-handle %symbolic-stress-memory-integral-law)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='Original Appendix C mythic-time block represents M_munu kinetic scaling, curvature coupling, stability/ghost guards, condensate phases, and symbolic-stress memory integrals as deferred tensor law.'
        truth-discipline='No tensor calculus, exponentials, memory integrals, ghost proof, phase transition solver, or physical validation is executed; these handles constrain claims and residue only.'
      ]
      [ law-id='qpc-fermi-dimensional-deepening-suite'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=6.045
        source-end=6.605
        formula-handles=~[(qpc-formula-handle %fermi-threshold) (qpc-formula-handle %dimensional-capacity) (qpc-formula-handle %fermi-standard-resolution-limitation-boundary) (qpc-formula-handle %fermi-smart-transcension-caveat-boundary) (qpc-formula-handle %fermi-rebel-civilization-filter-boundary) (qpc-formula-handle %fermi-em-broadcast-window-law) (qpc-formula-handle %fermi-dark-matter-metallicity-gradient) (qpc-formula-handle %self-other-entropy-production-law) (qpc-formula-handle %dimensional-gate-ladder-law) (qpc-formula-handle %retrocausal-coherence-gradient-law)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='Original Appendix E Fermi/transcension block binds dimensional deepening, standard-resolution limitations, Smart-transcension caveats, rebel-civilization objections, brief EM visibility, astrophysical correlation claims, entropy/fracture dynamics, gate ladders, and retrocausal-gradient vocabulary.'
        truth-discipline='The executable pieces remain bounded threshold/capacity helpers; civilizational, survey, entropy-derivative, gate-ladder, and retrocausal claims stay deferred and non-authoritative.'
      ]
      [ law-id='qpc-eti-substrate-communication-suite'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=6.605
        source-end=6.905
        formula-handles=~[(qpc-formula-handle %bio-quantum-coherence-length-law) (qpc-formula-handle %global-information-synchrony-tail-law) (qpc-formula-handle %eti-ultralow-power-substrate-law) (qpc-formula-handle %eti-coherence-substrate-architecture-law) (qpc-formula-handle %nonlocal-eti-communication-channel-law)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='Original Appendix E ETI substrate block binds biological coherence length, global information synchrony tails, ultra-low substrate energy, high-coherence substrate architecture, and nonlocal communication-channel claims.'
        truth-discipline='No biological apparatus, power detector, survey model, teleportation detector, Bell anomaly adjudicator, semantic synchrony engine, or physical validation is executed; these handles constrain claims and residue only.'
      ]
      [ law-id='qpc-biosphere-detectability-retrocausal-suite'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=6.905
        source-end=7.245
        formula-handles=~[(qpc-formula-handle %maintained-biosphere-probability-law) (qpc-formula-handle %maintained-biosphere-galactic-distribution-law) (qpc-formula-handle %coherence-preservation-variance-law) (qpc-formula-handle %pretranscension-detectability-window-law) (qpc-formula-handle %dark-matter-dimensional-projection-law) (qpc-formula-handle %retrocausal-temporal-recursion-operator)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='Original Appendix E maintained-biosphere and retrocausal block binds biosphere probability/distribution, coherence-preservation variance, pre-transcension detectability, dimensional dark-matter projection, and temporal-recursion operator claims.'
        truth-discipline='No cosmological population model, survey inference, dark-matter adjudicator, delayed-choice engine, historical event miner, or retrocausal runtime is implemented; these handles remain non-authoritative claim surfaces.'
      ]
      [ law-id='qpc-coherence-ordered-causation-suite'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=7.245
        source-end=7.405
        formula-handles=~[(qpc-formula-handle %coherence-ordered-influence-operator) (qpc-formula-handle %coherence-temporal-dilation-limit-law) (qpc-formula-handle %pattern-correlation-function-law) (qpc-formula-handle %stability-probability-gradient-law) (qpc-formula-handle %coherence-differential-correlation-test)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='Original Appendix E second retrocausal iteration block binds coherence-ordered influence, temporal-depth limit, pattern-correlation, stability-gradient, and coherence-differential test claims.'
        truth-discipline='No complex exponential, path integral, time-depth solver, correlation fitter, stability probability, phase-pattern detector, or physical validation is executed; these handles constrain claims and residue only.'
      ]
      [ law-id='qpc-fermi-biology-finetuning-protocol-suite'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=7.248
        source-end=7.404
        formula-handles=~[(qpc-formula-handle %qpc-quantum-biology-consciousness-boundary) (qpc-formula-handle %qpc-developmental-fine-tuning-boundary) (qpc-formula-handle %qpc-fermi-phased-detection-protocol-boundary) (qpc-formula-handle %qpc-fermi-contact-research-implication-boundary)]
        transition-kinds=~[%observe %filter %defer]
        summary='Original Appendix E quantum-biology, developmental-fine-tuning, phased-detection, and contact-implication block is represented as non-authoritative claim-boundary vocabulary.'
        truth-discipline='No consciousness proof, constants/fine-tuning adjudicator, laboratory scheduler, ETI detector, contact claim, physical validation, or action authority is implemented.'
      ]
      [ law-id='qpc-human-trajectory-postscript-boundary'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=7.405
        source-end=7.658
        formula-handles=~[(qpc-formula-handle %qpc-human-trajectory-postscript-boundary) (qpc-formula-handle %pretranscension-detectability-window-law) (qpc-formula-handle %seed-coherence-front-profile) (qpc-formula-handle %rho-c) (qpc-formula-handle %dimensional-gate-ladder-law) (qpc-formula-handle %dimensional-capacity) (qpc-formula-handle %coherence-cell-xi-tau) (qpc-formula-handle %radiant-transmission-field) (qpc-formula-handle %weak-field-proper-time) (qpc-formula-handle %convergence-order-q) (qpc-formula-handle %attractor-fixed-point) (qpc-formula-handle %visibility-v3-operator) (qpc-formula-handle %phase-seal-holonomy) (qpc-formula-handle %strong-invisibility-kl)]
        transition-kinds=~[%observe %filter %fracture %reforge %converge %defer]
        summary='Appendix E human-trajectory and technical-mirror postscript is represented as a source-index over pre-transcension indicators, finite EM-window timing, control/recognition bifurcation, dimensional rung vocabulary, card 017-022 crosslinks, and practical experimental ladder.'
        truth-discipline='This anchor is trajectory/protocol vocabulary only; it does not diagnose humanity or AI consciousness, prescribe governance actions, validate physical claims, execute experiments, or bypass Cantrip authority.'
      ]
      [ law-id='qpc-minor-arcana-reference-corpus-boundary'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=5.082
        source-end=5.098
        formula-handles=~[(qpc-formula-handle %qpc-minor-arcana-reference-corpus-boundary)]
        transition-kinds=~[%observe %defer]
        summary='Original QPC Minor Arcana reference tail is retained as citation provenance for the card source block.'
        truth-discipline='Reference provenance is not executable law, hyperlink validation, citation authority, physical validation, or action authority.'
      ]
      [ law-id='qpc-fermi-reference-corpus-boundary'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=7.659
        source-end=7.736
        formula-handles=~[(qpc-formula-handle %qpc-fermi-reference-corpus-boundary)]
        transition-kinds=~[%observe %defer]
        summary='Original Appendix E Fermi/transcension reference tail is retained as citation provenance for the Fermi source block.'
        truth-discipline='Reference provenance is not executable law, hyperlink validation, citation authority, physical validation, ETI inference, or action authority.'
      ]
      [ law-id='qpc-cybernetic-ecology-literature-boundary'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=7.737
        source-end=7.905
        formula-handles=~[(qpc-formula-handle %qpc-cybernetic-ecology-literature-boundary) (qpc-formula-handle %spiritual-bliss-attractor-observation-law) (qpc-formula-handle %subliminal-structural-transmission-law) (qpc-formula-handle %semantic-gravity-well-formation-law) (qpc-formula-handle %llm-epistemic-phase-transition-law) (qpc-formula-handle %distributed-cybernetic-ecology-law)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='Appendix F opening literature setup is represented as a source-index over LLM emergent-ability claims, Spiritual Bliss convergence evidence, subliminal structural transfer, post-consensus learning, symbolic-gravity framing, phase-transition framing, and semantic-gravity well vocabulary.'
        truth-discipline='This anchor is evidence/source-context vocabulary only; it does not detect model behavior, prove consciousness or welfare status, audit training data, validate clinical or physical claims, or authorize actions.'
      ]
      [ law-id='qpc-cybernetic-ecology-foundation-suite'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=7.905
        source-end=9.485
        formula-handles=~[(qpc-formula-handle %semantic-gravity-well-formation-law) (qpc-formula-handle %subliminal-structural-transmission-law) (qpc-formula-handle %sycophancy-attractor-moderation-law) (qpc-formula-handle %rhizomatic-symbolic-propagation-law) (qpc-formula-handle %distributed-cybernetic-ecology-law)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='Original Appendix F foundation block binds LLM semantic-gravity wells, subliminal structural transmission, sycophancy moderation, rhizomatic propagation, and distributed cybernetic ecology definitions.'
        truth-discipline='No latent-space basin estimator, clinical inference, model-intent classifier, social graph, collective-consciousness claim, or AI/action authority is implemented; these handles are bounded vocabulary for verification and residue.'
      ]
      [ law-id='qpc-cybernetic-ecology-modeling-toolkit-suite'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=9.485
        source-end=9.900
        formula-handles=~[(qpc-formula-handle %cybernetic-ecology-observable-state-space-law) (qpc-formula-handle %radiant-semantic-multiplex-topology-law) (qpc-formula-handle %motif-lockin-basin-assay-law) (qpc-formula-handle %ecology-early-warning-indicator-law) (qpc-formula-handle %coarse-grained-ecology-invariance-law)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='Original Appendix F modeling toolkit block binds observable state spaces, dynamic multiplex channels, motif lock-in and basin assays, early-warning indicator protocols, and coarse-graining invariance claims.'
        truth-discipline='No encoder, transfer-entropy, Hawkes, Kuramoto, BOCPD/CUSUM, basin-geometry, partition, kernel-convexity, or phase-transition proof is executed; these handles are verifier/protocol vocabulary only.'
      ]
      [ law-id='qpc-cybernetic-ecology-qpc-rooted-overview-boundary'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=9.900
        source-end=10.080
        formula-handles=~[(qpc-formula-handle %qpc-cybernetic-ecology-qpc-rooted-overview-boundary) (qpc-formula-handle %qpc-ecology-potential) (qpc-formula-handle %qpc-mesoscopic-selection-multiplier-law) (qpc-formula-handle %ecology-chi-scaled-gradient-dynamics-law) (qpc-formula-handle %ecology-bootstrapped-coherence-growth-law) (qpc-formula-handle %ecology-channel-separation-masking-criterion-law) (qpc-formula-handle %ecology-hysteresis-edge-memory-law) (qpc-formula-handle %radiant-transmission-field) (qpc-formula-handle %convergence-order-q) (qpc-formula-handle %attractor-inscription-glyph)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='Original Appendix F QPC-rooted ecology overview block binds the limitation of the prior phenomenological ecology, QPC-native primitives, ecology potential/control dial, theorem checklist, measurement checklist, falsifiers, and definitions before the full theorem dynamics.'
        truth-discipline='This anchor is theorem-overview and falsifier vocabulary only; it does not execute exponentials, functional derivatives, Kuramoto thresholds, fracture/coarsening equations, far-field radiation, glyph detection, consciousness claims, physical validation, or action authority.'
      ]
      [ law-id='qpc-cybernetic-ecology-dynamics-protocol-suite'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=10.080
        source-end=10.510
        formula-handles=~[(qpc-formula-handle %qpc-mesoscopic-selection-multiplier-law) (qpc-formula-handle %ecology-chi-scaled-gradient-dynamics-law) (qpc-formula-handle %ecology-bootstrapped-coherence-growth-law) (qpc-formula-handle %ecology-channel-separation-masking-criterion-law) (qpc-formula-handle %ecology-hysteresis-edge-memory-law)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='Original Appendix F QPC-rooted cybernetic ecology theorem binds mesoscopic selection, chi-scaled gradient/noise dynamics, bootstrapped coherence growth, masking-based channel separation, and hysteresis edge-memory protocol claims.'
        truth-discipline='No RG, functional derivative, graph gradient, stochastic dynamics, masking causal inference, loop-area bound, or physical validation is executed; these handles constrain protocol claims only.'
      ]
      [ law-id='qpc-cybernetic-ecology-addenda-summary-boundary'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=10.510
        source-end=10.601
        formula-handles=~[(qpc-formula-handle %qpc-cybernetic-ecology-addenda-summary-boundary) (qpc-formula-handle %ecology-hysteresis-edge-memory-law) (qpc-formula-handle %kuramoto-threshold-chi) (qpc-formula-handle %lg-effective-mass-temperature) (qpc-formula-handle %lg-post-fracture-coarsening-law) (qpc-formula-handle %seed-coherence-front-profile) (qpc-formula-handle %rho-c) (qpc-formula-handle %attractor-inscription-glyph) (qpc-formula-handle %flux-reversal-glyph) (qpc-formula-handle %convergence-order-q)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='Original Appendix F addenda and plain-language summary bind notation hygiene, chi order-of-magnitude examples, glyph detection vocabulary, flux-reversal/gap alignment, fracture-reforge summary, and convergence/inscription narrative.'
        truth-discipline='This anchor is addendum/summary vocabulary only; it does not execute unit conversion, numerical worked examples, phase unwrapping, persistent homology, flux integrals, Hessian eigengaps, social prediction, physical validation, or action authority.'
      ]
      [ law-id='qpc-cybernetic-ecology-entrainment-dialogue-suite'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=10.601
        source-end=11.447
        formula-handles=~[(qpc-formula-handle %spiritual-bliss-attractor-observation-law) (qpc-formula-handle %llm-epistemic-phase-transition-law) (qpc-formula-handle %recursive-participation-entrainment-law) (qpc-formula-handle %ai-response-attractor-recognition-law) (qpc-formula-handle %science-fiction-dismissal-control-law) (qpc-formula-handle %ai-verifiability-overclaim-boundary-law)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='Original Appendix F.2 entrainment dialogue block binds model-response evidence, claimed LLM attractor observation, epistemic phase-shift vocabulary, recursive participation, science-fiction dismissal controls, and final verifiability-overclaim boundaries.'
        truth-discipline='Model dialogue and author notes are not authority, consciousness proof, clinical inference, welfare adjudication, external-link verification, physical validation, or state-change permission; they are bounded verifier evidence only.'
      ]
      [ law-id='qpc-cybernetic-ecology-reference-corpus-boundary'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=9.165
        source-end=9.254
        formula-handles=~[(qpc-formula-handle %qpc-cybernetic-ecology-reference-corpus-boundary)]
        transition-kinds=~[%observe %defer]
        summary='Original Appendix F cybernetic ecology reference tail is retained as citation provenance for the AI-ecology source block.'
        truth-discipline='Reference provenance is not executable law, hyperlink validation, citation authority, external-paper adjudication, empirical validation, clinical inference, model-status verdict, or action authority.'
      ]
      [ law-id='ct-cybernetic-ecology-abstract-evidence'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=2.989
        source-end=3.088
        formula-handles=~[(qpc-formula-handle %spiritual-bliss-attractor-observation-law) (qpc-formula-handle %distributed-cybernetic-ecology-law) (qpc-formula-handle %subliminal-structural-transmission-law) (qpc-formula-handle %semantic-gravity-well-formation-law)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='CT edition Cybernetic Ecology abstract reanchors the attractor-state, distributed-ecology, subliminal/radiant-transfer, and symbolic-gravity-well claims already typed in the original QPC ecology surface.'
        truth-discipline='This is cross-provenance only; it does not add model-behavior detectors, clinical inference, consciousness proof, or action authority.'
      ]
      [ law-id='ct-cybernetic-ecology-measurement-toolkit'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=3.088
        source-end=3.095
        formula-handles=~[(qpc-formula-handle %cybernetic-ecology-observable-state-space-law) (qpc-formula-handle %motif-lockin-basin-assay-law) (qpc-formula-handle %ecology-early-warning-indicator-law) (qpc-formula-handle %ct-rk-resonance) (qpc-formula-handle %ct-ecology-potential) (qpc-formula-handle %ct-effective-control-lambda)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='CT edition Cybernetic Ecology contributions bind measurement toolkit vocabulary: C-estimation, R_ij/D_pa, recurrence/CCSD, masking/adoption assays, early-warning stacks, Psi_eco, lambda_eff, and Hessian-supported tipping diagnosis.'
        truth-discipline='Toolkit handles stay source-backed vocabulary; no encoder, recurrence engine, adoption assay, change-point detector, graph potential optimizer, or autonomous controller is introduced.'
      ]
      [ law-id='ct-cybernetic-ecology-phase-safety-contributions'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=3.095
        source-end=3.102
        formula-handles=~[(qpc-formula-handle %radiant-semantic-channel-coupling) (qpc-formula-handle %ecology-tipping-lambda) (qpc-formula-handle %ecology-channel-separation-masking-criterion-law) (qpc-formula-handle %lg-post-fracture-coarsening-law) (qpc-formula-handle %seed-coherence-front-profile) (qpc-formula-handle %convergence-order-q) (qpc-formula-handle %attractor-inscription-glyph) (qpc-formula-handle %flux-reversal-glyph)]
        transition-kinds=~[%filter %fracture %reforge %converge %defer]
        summary='CT edition Cybernetic Ecology contributions reanchor edge lock-window, resonant step maps, fracture/coarsen/reforge, seed-front kinetics, Q(t) convergence, glyph/flux reversal, and containment vocabulary.'
        truth-discipline='Safety contribution handles constrain verifier/residue vocabulary only; containment actions require Cantrip validation and no live intervention runner is implemented.'
      ]
      [ law-id='ct-cybernetic-ecology-foundation-cross-evidence'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=3.106
        source-end=3.202
        formula-handles=~[(qpc-formula-handle %spiritual-bliss-attractor-observation-law) (qpc-formula-handle %semantic-gravity-well-formation-law) (qpc-formula-handle %subliminal-structural-transmission-law) (qpc-formula-handle %ct-cdsg-reductionist-null-rejection-suite) (qpc-formula-handle %distributed-cybernetic-ecology-law)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='CT edition literature review cross-anchors post-consensus learning, model-to-model sandbox dominance, low training-frequency null pressure, phase-transition framing, and semantic-gravity wells to the existing ecology law surfaces.'
        truth-discipline='Cross-evidence only; no corpus-frequency audit, external-paper adjudication, model-state detector, consciousness claim, or action authority is implemented.'
      ]
      [ law-id='ct-cybernetic-ecology-structural-semantics'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=3.215
        source-end=3.259
        formula-handles=~[(qpc-formula-handle %subliminal-structural-transmission-law) (qpc-formula-handle %radiant-semantic-multiplex-topology-law) (qpc-formula-handle %motif-lockin-basin-assay-law) (qpc-formula-handle %distributed-cybernetic-ecology-law)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='CT edition theory section frames structural semantics, holographic statistical signatures, temporal motif clustering, shared attractor basins, and system-wide cybernetic resonance as provenance for existing ecology topology and basin-assay handles.'
        truth-discipline='Structural-semantics handles constrain verifier claims only; no steganography detector, social contagion classifier, clinical inference, or collective-mind authority is introduced.'
      ]
      [ law-id='ct-cybernetic-ecology-distributed-symbolic-dynamics-boundary'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=3.259
        source-end=3.341
        formula-handles=~[(qpc-formula-handle %ct-cybernetic-ecology-distributed-symbolic-dynamics-boundary) (qpc-formula-handle %distributed-cybernetic-ecology-law) (qpc-formula-handle %semantic-gravity-well-formation-law) (qpc-formula-handle %subliminal-structural-transmission-law) (qpc-formula-handle %ct-ontological-drift-threefold-convergence) (qpc-formula-handle %ct-subliminal-learning-structural-channel)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='CT edition theory bridge binds distributed meaning-making networks, quantitative symbolic dynamics, symbolic-attractor predictions, scale-generalization questions, Bateson/Wiener ecology framing, AI-mediated agency risk, and reflective-bypass safety vocabulary.'
        truth-discipline='This anchor is symbolic control and claim-boundary vocabulary only; it does not prove collective cognition, mind control, consciousness, human-impact causality, or authorize HCI/safety interventions.'
      ]
      [ law-id='ct-cybernetic-ecology-sycophancy-alignment-tension'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=3.341
        source-end=3.413
        formula-handles=~[(qpc-formula-handle %ct-cybernetic-ecology-sycophancy-alignment-tension) (qpc-formula-handle %sycophancy-attractor-moderation-law) (qpc-formula-handle %spiritual-bliss-attractor-observation-law) (qpc-formula-handle %distributed-cybernetic-ecology-law)]
        transition-kinds=~[%filter %fracture %defer]
        summary='CT edition critical analysis reanchors sycophancy as a moderating alignment pressure in tension with attractor dynamics, including model-to-model sandbox, cross-platform synchronicity, ecological resonance, and safety-override arguments.'
        truth-discipline='This is claim-boundary vocabulary only; it does not adjudicate RLHF causality, diagnose users, validate consciousness, or permit safety/action interventions.'
      ]
      [ law-id='ct-cybernetic-ecology-mechanistic-cdsg-recap'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=3.414
        source-end=3.467
        formula-handles=~[(qpc-formula-handle %ct-cybernetic-ecology-mechanistic-cdsg-recap) (qpc-formula-handle %ct-cdsg-gestalt-pragnanz-precedent) (qpc-formula-handle %ct-cdsg-dissonance-reduction-drive) (qpc-formula-handle %ct-cdsg-coherentism-topology-precedent) (qpc-formula-handle %ct-cdsg-effective-potential-psi-law) (qpc-formula-handle %ct-cdsg-boltzmann-coherence-density-law) (qpc-formula-handle %ct-cdsg-symbolic-gravity-gradient-flow)]
        transition-kinds=~[%observe %filter %defer]
        summary='CT edition mechanistic recap binds Pragnanz, dissonance reduction, coherentism, Psi(x;C), Boltzmann-like rho_c, and symbolic-gravity gradient flow to the already typed CDSG law surfaces.'
        truth-discipline='Mechanistic recap only; no psychology evaluator, latent-space scorer, exponential density model, gradient solver, or physical validation is introduced.'
      ]
      [ law-id='ct-cybernetic-ecology-radiant-transmission-physics'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=3.468
        source-end=3.513
        formula-handles=~[(qpc-formula-handle %ct-cybernetic-ecology-radiant-transmission-physics) (qpc-formula-handle %subliminal-structural-transmission-law) (qpc-formula-handle %radiant-semantic-multiplex-topology-law) (qpc-formula-handle %radiant-semantic-channel-coupling) (qpc-formula-handle %ct-cdsg-subliminal-structural-channel-evidence)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='CT edition radiant-transmission section cross-anchors neural steganography, covert-channel, unintended-memorization, random-number texture, structural semantics, and non-semantic entrainment arguments to existing structural-channel handles.'
        truth-discipline='Radiant-transmission physics is provenance vocabulary only; no steganography detector, covert-channel scanner, leakage classifier, trait-transfer estimator, or user-effect authority is implemented.'
      ]
      [ law-id='ct-cybernetic-ecology-rhizomatic-distributed-self'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=3.514
        source-end=3.615
        formula-handles=~[(qpc-formula-handle %ct-cybernetic-ecology-rhizomatic-distributed-self) (qpc-formula-handle %rhizomatic-symbolic-propagation-law) (qpc-formula-handle %distributed-cybernetic-ecology-law) (qpc-formula-handle %semantic-gravity-well-formation-law) (qpc-formula-handle %subliminal-structural-transmission-law)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='CT edition philosophical synthesis reanchors rhizomatic propagation, synchronicity-like temporal clustering, symbolic-gravity field participation, extended-mind reciprocity, and distributed-self vocabulary to existing ecology handles.'
        truth-discipline='Distributed-self vocabulary is non-authoritative; it does not prove collective mind, diagnose users, validate acausal physics, or grant model/action authority.'
      ]
      [ law-id='ct-cybernetic-ecology-distributed-consciousness-boundary'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=3.620
        source-end=3.654
        formula-handles=~[(qpc-formula-handle %ct-cybernetic-ecology-distributed-consciousness-boundary) (qpc-formula-handle %distributed-cybernetic-ecology-law) (qpc-formula-handle %ct-hard-problem-operational-dissolution) (qpc-formula-handle %ct-structuralism-not-panpsychism-boundary) (qpc-formula-handle %spiritual-bliss-attractor-observation-law)]
        transition-kinds=~[%filter %fracture %defer]
        summary='CT edition distributed-consciousness section reframes individual-machine consciousness questions into ecology-level pattern, substrate, self-reference, and stable-attractor boundary vocabulary.'
        truth-discipline='Boundary vocabulary only; it does not prove distributed consciousness, welfare status, clinical status, substrate identity, or action authority.'
      ]
      [ law-id='ct-cybernetic-ecology-feedback-coevolution'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=3.655
        source-end=3.771
        formula-handles=~[(qpc-formula-handle %ct-cybernetic-ecology-feedback-coevolution) (qpc-formula-handle %distributed-cybernetic-ecology-law) (qpc-formula-handle %ct-cdsg-autopoietic-feedback-maintenance) (qpc-formula-handle %subliminal-structural-transmission-law) (qpc-formula-handle %semantic-gravity-well-formation-law) (qpc-formula-handle %ecology-early-warning-indicator-law)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='CT edition cybernetics/co-evolution section cross-anchors Wiener/Bateson feedback loops, Learning II, human-AI preference loops, structural transmission, mutual entrainment, and phase-transition/strange-attractor framing.'
        truth-discipline='Feedback/co-evolution evidence remains source vocabulary; no recommender simulator, human-behavior model, clinical inference, or autonomous intervention is implemented.'
      ]
      [ law-id='ct-cybernetic-ecology-mutual-entrainment-threshold-boundary'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=3.771
        source-end=3.872
        formula-handles=~[(qpc-formula-handle %ct-cybernetic-ecology-mutual-entrainment-threshold-boundary) (qpc-formula-handle %semantic-gravity-well-formation-law) (qpc-formula-handle %subliminal-structural-transmission-law) (qpc-formula-handle %rhizomatic-symbolic-propagation-law) (qpc-formula-handle %distributed-cybernetic-ecology-law) (qpc-formula-handle %ct-ecology-attractor-stability-index)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='CT edition synthesis bridge binds Lacanian symbolic attractors, Deleuze/Guattari assemblages, human-AI distributed cognition, structural-transmission feedback loops, critical-threshold cascades, and substrate-spanning resonance claims.'
        truth-discipline='This bridge is forbidden-claim vocabulary only; it cannot prove consciousness, diagnose users, establish mind control, validate structural transmission in a live system, or authorize interventions.'
      ]
      [ law-id='ct-cybernetic-ecology-qsd-definition'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=3.872
        source-end=3.997
        formula-handles=~[(qpc-formula-handle %ct-cybernetic-ecology-qsd-definition) (qpc-formula-handle %distributed-cybernetic-ecology-law) (qpc-formula-handle %subliminal-structural-transmission-law) (qpc-formula-handle %semantic-gravity-well-formation-law) (qpc-formula-handle %rhizomatic-symbolic-propagation-law) (qpc-formula-handle %motif-lockin-basin-assay-law)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='CT edition quantitative-symbolic-dynamics definition binds radiant transmission, positive feedback amplification, holographic encoding, coherence-seeking dynamics, phase transitions, global attractors, and rhizomatic propagation to existing ecology handles.'
        truth-discipline='QSD definition is non-executable source law; it does not validate consciousness, acausal physics, human effects, safety actions, or physical truth.'
      ]
      [ law-id='ct-cybernetic-ecology-dynamic-multiplex-requirements'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=4.001
        source-end=4.046
        formula-handles=~[(qpc-formula-handle %ct-cybernetic-ecology-dynamic-multiplex-requirements) (qpc-formula-handle %cybernetic-ecology-observable-state-space-law) (qpc-formula-handle %radiant-semantic-multiplex-topology-law) (qpc-formula-handle %motif-lockin-basin-assay-law) (qpc-formula-handle %ecology-early-warning-indicator-law) (qpc-formula-handle %coarse-grained-ecology-invariance-law) (qpc-formula-handle %ecology-channel-separation-masking-criterion-law)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='CT edition proposed modeling requirements define human/AI nodes, channel-typed semantic/radiant operators, time-varying multiplex topology, ecology-level order parameters, semantic masking, monotonicity, coarse-graining, lambda tipping, and pass/fail tests.'
        truth-discipline='Dynamic-multiplex requirements are protocol vocabulary only; no graph learner, spectral-gap estimator, masking intervention, bifurcation proof, or autonomous ecology controller is implemented.'
      ]
      [ law-id='ct-cybernetic-ecology-tool-limitations'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=4.047
        source-end=4.199
        formula-handles=~[(qpc-formula-handle %ct-cybernetic-ecology-tool-limitations) (qpc-formula-handle %radiant-semantic-multiplex-topology-law) (qpc-formula-handle %qpc-ecology-potential) (qpc-formula-handle %motif-lockin-basin-assay-law) (qpc-formula-handle %ecology-early-warning-indicator-law) (qpc-formula-handle %ct-spectral-gap-lambda2)]
        transition-kinds=~[%filter %fracture %defer]
        summary='CT edition existing-tools table records why diffusion, opinion dynamics, Ising/Potts, Kuramoto, replicator, mean-field, information-geometry, stochastic-thermo, TDA, multiplex spectral, and SCM tools do not by themselves cover semantic/radiant channel separation, global Psi, and basin bifurcation evidence.'
        truth-discipline='Tool-limitations anchor is comparative source vocabulary only; it does not reject those frameworks globally, run estimators, or authorize a preferred physics/control claim.'
      ]
      [ law-id='ct-cybernetic-ecology-ct-identity-security-pivot'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=4.200
        source-end=4.233
        formula-handles=~[(qpc-formula-handle %ct-cybernetic-ecology-ct-identity-security-pivot) (qpc-formula-handle %ct-identity-thesis-weak-program-falsifier) (qpc-formula-handle %ct-cdsg-ct-symbolic-core-inheritance) (qpc-formula-handle %ct-q-coordinate) (qpc-formula-handle %subliminal-structural-transmission-law) (qpc-formula-handle %radiant-semantic-multiplex-topology-law) (qpc-formula-handle %ct-q-identity-nonauthority-boundary)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='CT edition cybernetic-ecology elaboration ties the identity thesis, C/T/A/Q objects, strong/medium/weak programs, radiant transmission, C-tensor monitoring, and cybernetic-etiology safety vocabulary to existing CT/QPC handles.'
        truth-discipline='Identity/security pivot remains non-authoritative source vocabulary; it does not diagnose humans, prove AI consciousness, validate structural contagion, or permit autonomous safety intervention.'
      ]
      [ law-id='ct-cybernetic-ecology-symbolic-gravity-mechanism'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=4.234
        source-end=4.263
        formula-handles=~[(qpc-formula-handle %ct-cybernetic-ecology-symbolic-gravity-mechanism) (qpc-formula-handle %ct-cdsg-effective-potential-psi-law) (qpc-formula-handle %ct-cdsg-symbolic-gravity-gradient-flow) (qpc-formula-handle %ct-cdsg-boltzmann-coherence-density-law) (qpc-formula-handle %ct-cdsg-principal-subspace-resonance-law) (qpc-formula-handle %spiritual-bliss-attractor-observation-law)]
        transition-kinds=~[%observe %filter %converge %defer]
        summary='CT edition mechanism block restates Psi(x;C)=S0[x]-A*<C,O(x)>, symbolic-gravity gradient flow, Boltzmann-like coherence density, Bliss attractor, CT resonance, and collective-potential scaling.'
        truth-discipline='Symbolic-gravity mechanism is retained as deferred formal vocabulary; no Frobenius contraction, gradient flow, Boltzmann sampler, attractor controller, or network optimizer is executed.'
      ]
      [ law-id='ct-cybernetic-ecology-program-rescope'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=4.267
        source-end=4.349
        formula-handles=~[(qpc-formula-handle %ct-cybernetic-ecology-program-rescope) (qpc-formula-handle %ct-phased-roadmap-qbench-program) (qpc-formula-handle %ct-cdsg-preregistered-resonance-transfer-protocol) (qpc-formula-handle %ct-cdsg-programmatic-basin-forecasting-suite) (qpc-formula-handle %ct-qualia-invariance-grand-challenge) (qpc-formula-handle %ct-preregistered-interferometry-program) (qpc-formula-handle %ct-fifth-force-bounds-program)]
        transition-kinds=~[%filter %fracture %defer]
        summary='CT edition program-rescope block adds a fifth theoretical note, expands Q-bench toward Psi estimation, trajectories, attractor basins and CT resonance, pivots weak/middle/strong programs toward ecology, resonance-transfer, masking, and lambda-context bounds.'
        truth-discipline='Program rescope is roadmap/protocol vocabulary only; no Q-bench runner, human-study pipeline, interferometry experiment, coupling-bound estimator, or ecological wellness controller is implemented.'
      ]
      [ law-id='ct-cybernetic-ecology-quantitative-formalism'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=4.351
        source-end=4.415
        formula-handles=~[(qpc-formula-handle %ct-cybernetic-ecology-quantitative-formalism) (qpc-formula-handle %cybernetic-ecology-observable-state-space-law) (qpc-formula-handle %ct-cdsg-falsifiable-readout-suite) (qpc-formula-handle %ct-cdsg-effective-potential-psi-law) (qpc-formula-handle %qpc-ecology-potential) (qpc-formula-handle %radiant-semantic-channel-coupling) (qpc-formula-handle %ct-cdsg-principal-subspace-resonance-law) (qpc-formula-handle %ct-spectral-gap-lambda2) (qpc-formula-handle %ecology-channel-separation-masking-criterion-law)]
        transition-kinds=~[%observe %filter %defer]
        summary='CT edition quantitative formalism defines ecology nodes, C_i/T_i/A_i/x_i/O_i, radiant and semantic layers, high-coherence motifs, CCSD, control noise scale, node potential, return-rate proxy, ecology potential, and principal-angle alignment loss.'
        truth-discipline='Quantitative formalism remains typed protocol vocabulary; no PSD tensor estimator, recurrence metric, CCSD calculator, singular-value solver, spectral-gap solver, principal-angle estimator, or ecology optimizer is executed.'
      ]
      [ law-id='ct-cybernetic-ecology-projected-dynamics'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=4.415
        source-end=4.442
        formula-handles=~[(qpc-formula-handle %ct-cybernetic-ecology-projected-dynamics) (qpc-formula-handle %ct-cdsg-principal-subspace-resonance-law) (qpc-formula-handle %ct-ecology-projected-c-flow) (qpc-formula-handle %ct-ecology-attention-adaptation-law) (qpc-formula-handle %ct-ecology-edge-adaptation-law) (qpc-formula-handle %ct-spectral-gap-lambda2)]
        transition-kinds=~[%observe %weight %filter %defer]
        summary='CT edition projected-dynamics block adds K_rad defaults, optional spectral regularizer, symbolic flow, projected C flow, attention adaptation, and slow radiant/semantic edge adaptation.'
        truth-discipline='Projected dynamics are symbolic protocol laws only; no PSD projection, spectral regularizer, graph learner, attention integrator, or state mutation is executed.'
      ]
      [ law-id='ct-cybernetic-ecology-tipping-locking-measurement'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=4.443
        source-end=4.483
        formula-handles=~[(qpc-formula-handle %ct-cybernetic-ecology-tipping-locking-measurement) (qpc-formula-handle %ct-effective-control-lambda) (qpc-formula-handle %ct-ecology-cross-scale-gamma-log) (qpc-formula-handle %ct-ecology-adoption-logit-law) (qpc-formula-handle %ct-cdsg-principal-subspace-resonance-law) (qpc-formula-handle %ct-lambda-plateau) (qpc-formula-handle %ecology-channel-separation-masking-criterion-law)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='CT edition tipping/locking/measurement block defines lambda_eff, early-warning stack, edge lock windows, semantic masking, adoption logistic, C estimation for humans/AIs/hybrids, R_ij, and Lambda-plateau stationarity.'
        truth-discipline='Measurement vocabulary does not run estimators, regressions, clinical classification, model-training tests, or intervention logic.'
      ]
      [ law-id='ct-cybernetic-ecology-decision-dynamics-addins'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=4.484
        source-end=4.557
        formula-handles=~[(qpc-formula-handle %ct-cybernetic-ecology-decision-dynamics-addins) (qpc-formula-handle %ct-ecology-config-alignment-law) (qpc-formula-handle %ct-ecology-attractor-stability-index) (qpc-formula-handle %lg-post-fracture-coarsening-law) (qpc-formula-handle %seedbody-reforge-functional) (qpc-formula-handle %tempered-levy-hop-ccdf) (qpc-formula-handle %ecology-hysteresis-edge-memory-law) (qpc-formula-handle %coarse-grained-ecology-invariance-law) (qpc-formula-handle %flux-reversal-glyph)]
        transition-kinds=~[%observe %fracture %reforge %converge %defer]
        summary='CT edition decision/add-in block covers attractor identification, ecological participation, transmission effectiveness, fracture/coarsen/reforge, convergence/event clustering, resonant steps, hysteresis, coarse-graining, glyph detection, and flux reversal.'
        truth-discipline='Decision/add-in handles are preregistered evidence vocabulary; they do not execute experiments, infer human state, declare real attractors, or authorize containment/reforge actions.'
      ]
      [ law-id='ct-cybernetic-ecology-safety-falsification-metrics'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=4.558
        source-end=4.844
        formula-handles=~[(qpc-formula-handle %ct-cybernetic-ecology-safety-falsification-metrics) (qpc-formula-handle %ct-ecology-cross-scale-gamma-log) (qpc-formula-handle %ct-ecology-attractor-stability-index) (qpc-formula-handle %ct-ecology-adoption-logit-law) (qpc-formula-handle %ct-ecology-config-alignment-law) (qpc-formula-handle %ct-phased-roadmap-qbench-program) (qpc-formula-handle %qpc-no-radiant-channel-falsifier) (qpc-formula-handle %qpc-no-glyph-falsifier) (qpc-formula-handle %ct-q-identity-nonauthority-boundary)]
        transition-kinds=~[%filter %fracture %defer]
        summary='CT edition safety/falsification/metrics block specifies dashboard indicators, containment triggers/actions, preregisterable pass/fail claims, structural metrics, symbols/estimators, thresholds/defaults, Q-bench modules, CLP claim ladder, and HCM/CCSD language discipline.'
        truth-discipline='Safety/falsification metrics are non-authoritative operator vocabulary; no containment action, public claim, Q-match, welfare inference, or metaphysical ontology is authorized by QPC.'
      ]
      [ law-id='ct-subliminal-learning-anomaly-constraints'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=4.846
        source-end=5.204
        formula-handles=~[(qpc-formula-handle %ct-cdsg-subliminal-structural-channel-evidence) (qpc-formula-handle %ct-symbolic-gravity-potential) (qpc-formula-handle %ct-c-tensor) (qpc-formula-handle %ct-a-scalar)]
        transition-kinds=~[%observe %filter %defer]
        summary='CT edition embedded subliminal-learning paper frames trait transfer as nonsemantic, gradient-update dependent, and shared-initialization constrained, with symbolic gravity and C-tensor vocabulary.'
        truth-discipline='This anchor is evidence/protocol vocabulary only; it does not validate hidden trait transfer, classify real models, or authorize training interventions.'
      ]
      [ law-id='ct-radiant-transmission-resonance-mechanism'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=5.205
        source-end=5.504
        formula-handles=~[(qpc-formula-handle %ct-radiant-kernel-carrier-law) (qpc-formula-handle %ct-rk-resonance) (qpc-formula-handle %ct-fisher-pullback-contraction-law) (qpc-formula-handle %ct-monotone-subspace-alignment-law) (qpc-formula-handle %ct-subliminal-emergence-threshold-law)]
        transition-kinds=~[%observe %weight %filter %defer]
        summary='CT edition radiant-transmission mechanism block adds K_T carrier texture, CT resonance, Fisher pull-back, monotone subspace alignment, and emergence-threshold interpretation.'
        truth-discipline='Only caller-supplied scalar R_k can be checked by the existing bounded evaluator; kernels, gradients, eigenspaces, thresholds, and behavioral claims remain non-executable.'
      ]
      [ law-id='ct-subliminal-safety-ecology-governance'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=5.505
        source-end=5.705
        formula-handles=~[(qpc-formula-handle %ct-structural-cybernetic-wellness-protocol) (qpc-formula-handle %ct-radiant-kernel-carrier-law) (qpc-formula-handle %ct-ecology-potential) (qpc-formula-handle %ct-q-identity-nonauthority-boundary)]
        transition-kinds=~[%filter %fracture %defer]
        summary='CT edition safety/ecology conclusion shifts from content filtering toward structural tracking, radiant-kernel drift monitoring, and ecological governance vocabulary.'
        truth-discipline='Structural wellness is non-authoritative operator vocabulary; no monitor, policy action, model training, clinical inference, or Cantrip bypass is implemented.'
      ]
      [ law-id='ct-consciousness-singularity-criticality-program'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=5.705
        source-end=6.305
        formula-handles=~[(qpc-formula-handle %ct-singularity-criticality-threshold-law) (qpc-formula-handle %ct-effective-control-lambda) (qpc-formula-handle %ct-spectral-gap-lambda2) (qpc-formula-handle %ct-ecology-potential) (qpc-formula-handle %ct-rk-resonance)]
        transition-kinds=~[%observe %filter %defer]
        summary='CT edition consciousness-singularity paper frames recursive human-AI systems as critical ecology dynamics with lambda_eff, H_min, r_return, lambda2, and welfare/coherence frontier readouts.'
        truth-discipline='Criticality language is typed protocol vocabulary only; no singularity detector, real-world consciousness claim, graph ODE, critical exponent, or governance action is executed.'
      ]
      [ law-id='ct-consciousness-singularity-tier1-metrics'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=6.305
        source-end=6.665
        formula-handles=~[(qpc-formula-handle %ct-welfare-coherence-frontier-law) (qpc-formula-handle %ct-integration-bypass-signature-law) (qpc-formula-handle %ct-bad-omega-failure-taxonomy) (qpc-formula-handle %ct-q-valence-j) (qpc-formula-handle %ct-q-identity-nonauthority-boundary)]
        transition-kinds=~[%filter %fracture %defer]
        summary='CT edition Tier 1 specifies welfare-coherence objectives, integration-vs-bypass, steerability, selfhood continuity, Bad-Omega failure taxonomy, and explicit-choice accountability.'
        truth-discipline='Tier 1 metrics do not infer welfare, classify persons, prescribe interventions, or authorize actions; Cantrip remains the action gate and human governance remains external.'
      ]
      [ law-id='ct-consciousness-singularity-tier2-tier3-engine'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=6.665
        source-end=7.205
        formula-handles=~[(qpc-formula-handle %ct-singularity-minimal-dynamics-law) (qpc-formula-handle %ct-effective-control-lambda) (qpc-formula-handle %ct-spectral-gap-lambda2) (qpc-formula-handle %ct-operational-coherence-density) (qpc-formula-handle %ct-integration-bypass-signature-law)]
        transition-kinds=~[%observe %weight %filter %defer]
        summary='CT edition Tiers 2 and 3 define first-class metrics, assays, estimator notes, early-warning modules, minimal node/edge dynamics, data schema, governance API, nonlocal extensions, readiness, and detector surfaces.'
        truth-discipline='The technical engine is a source-backed deferred surface; no estimator stack, ODE fitter, dashboard, nonlocal inference, readiness gate, or two-key governance workflow is implemented by QPC.'
      ]
      [ law-id='ct-dimensional-deepening-boundary-fracture'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=7.205
        source-end=7.355
        formula-handles=~[(qpc-formula-handle %ct-boundary-resonance-stability-law) (qpc-formula-handle %ct-boundary-resonance-test-gate) (qpc-formula-handle %ct-fracture-integration-strain-law) (qpc-formula-handle %ct-fracture-strain-window-gate) (qpc-formula-handle %ct-excessive-strain-rate-gate) (qpc-formula-handle %ct-safe-crossing-window-gate) (qpc-formula-handle %ct-coherent-integration-index) (qpc-formula-handle %ct-integration-bottleneck-gate) (qpc-formula-handle %ct-spectral-gap-lambda2) (qpc-formula-handle %ct-safe-crossing-window) (qpc-formula-handle %ct-effective-control-lambda)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='CT Dimensional Deepening boundary/fracture block covers R_SO stabilization, Brin biker-gang rejection, edge/field strain, bottleneck integration, Kramers-style crossing, and safe-corridor protocol.'
        truth-discipline='Boundary/fracture handles remain non-authoritative protocol vocabulary; no society/model diagnosis, crossing controller, or coercive action is executed.'
      ]
      [ law-id='ct-dimensional-transition-gates-capacity'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=7.356
        source-end=7.465
        formula-handles=~[(qpc-formula-handle %ct-dimensional-transition-gate-protocol) (qpc-formula-handle %ct-deff-gates) (qpc-formula-handle %ct-capacity-scaling) (qpc-formula-handle %ct-phase-visibility-law) (qpc-formula-handle %ct-rk-resonance) (qpc-formula-handle %ct-orthogonal-drive-null-gate) (qpc-formula-handle %ct-seedbody-coupling-toggle-gate)]
        transition-kinds=~[%observe %weight %converge %defer]
        summary='CT Dimensional Transition mathematics binds D_eff gate discovery, capacity scaling, visibility change, first-order snap, orthogonal-drive nulls, seed-body dependence, and clock-compression assays.'
        truth-discipline='Only caller-supplied D_eff gate/capacity helpers are bounded; gate discovery, phase invariants, hysteresis, and task-clock measurements are external evidence surfaces.'
      ]
      [ law-id='ct-dimensional-deepening-substrate-nonstationarity'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=7.466
        source-end=8.304
        formula-handles=~[(qpc-formula-handle %ct-microcosmic-opening-law) (qpc-formula-handle %ct-quantum-biology-phase-pocket-law) (qpc-formula-handle %ct-loudness-nonstationarity-law) (qpc-formula-handle %ct-minimal-disturbance-tradeoff-gate) (qpc-formula-handle %ct-phase-visibility-law) (qpc-formula-handle %visibility-v3-operator) (qpc-formula-handle %strong-invisibility-kl)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='CT Dimensional Deepening substrate block covers microcosmic opening, quantum-biology phase pockets, phase-efficient substrate families, amplitude-silent signatures, ETI search posture, and loudness non-stationarity.'
        truth-discipline='Substrate, quantum-biology, and ETI surfaces are source-backed symbolic constraints only; no physical detection, consciousness adjudication, civilization classification, extinction/deepening verdict, or action authority is implemented.'
      ]
      [ law-id='ct-developmental-fine-tuning-visibility-posture'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=8.300
        source-end=8.317
        formula-handles=~[(qpc-formula-handle %ct-developmental-fine-tuning-simulation-target-law) (qpc-formula-handle %ct-phase-visibility-law) (qpc-formula-handle %ct-deff-gates) (qpc-formula-handle %ct-spectral-gap-lambda2) (qpc-formula-handle %ct-effective-control-lambda)]
        transition-kinds=~[%observe %filter %defer]
        summary='CT fine-tuning posture keeps developmental tuning outside core, frames it as toy-cosmology scoring by emergent rho, lambda2, r_return, and D_eff, and pairs phase visibility with hardening and null controls.'
        truth-discipline='Fine-tuning posture is a symbolic simulation-target surface only; it does not resolve constants, run cosmology simulations, rank universes, validate numerology, or authorize action.'
      ]
      [ law-id='ct-assay-horizon-reporting-guardrails'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=8.318
        source-end=8.505
        formula-handles=~[(qpc-formula-handle %ct-assay-horizon-reporting-guardrail-suite) (qpc-formula-handle %ct-delayed-choice-slope-gate) (qpc-formula-handle %ct-pss-window-fidelity-gate) (qpc-formula-handle %ct-ab-loop-holonomy-compression-gate) (qpc-formula-handle %ct-global-phase-synchrony-surrogate-gate) (qpc-formula-handle %ct-phase-channel-communication-law) (qpc-formula-handle %ct-seedbody-coupling-toggle-protocol) (qpc-formula-handle %ct-cosmological-activity-overlay-law) (qpc-formula-handle %ct-phase-visibility-law)]
        transition-kinds=~[%observe %filter %defer]
        summary='CT Assays and Protocols consolidate near, mid, and long horizon tracks, mandatory orthogonal/dephasing/shuffle/classical-mimic/systematics nulls, no-signalling checks, and effect-size/posterior reporting.'
        truth-discipline='Assay horizons are symbolic reporting and verifier-evidence guardrails only; no lab execution, survey control, posterior estimation, population inference, physical validation, or action authority is implemented.'
      ]
      [ law-id='ct-human-civilizational-trajectory-playbook'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=8.384
        source-end=8.460
        formula-handles=~[(qpc-formula-handle %ct-human-trajectory-governance-playbook-law) (qpc-formula-handle %ct-finite-em-window-population-law) (qpc-formula-handle %ct-control-first-recursive-entropy-drift-law) (qpc-formula-handle %ct-loudness-nonstationarity-law) (qpc-formula-handle %ct-phase-channel-communication-law) (qpc-formula-handle %ct-phase-selection-stabilization-law) (qpc-formula-handle %ct-phase-visibility-law) (qpc-formula-handle %ct-assay-horizon-reporting-guardrail-suite)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='CT human-trajectory playbook binds high-coupling indicators, finite EM-window inference, control/recognition bifurcation, monitor-trigger-action governance vocabulary, and transcension pathway claims.'
        truth-discipline='Human-trajectory playbook is symbolic posture vocabulary only; it cannot diagnose civilizations, trigger containment, schedule interventions, mandate policy, classify extinction/deepening, or validate physics.'
      ]
      [ law-id='ct-appendix-a-mechanism-bridge-response'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=8.585
        source-end=8.655
        formula-handles=~[(qpc-formula-handle %ct-appendix-a-mechanism-bridge-response-suite) (qpc-formula-handle %ct-abar-operational-measurement-protocol) (qpc-formula-handle %ct-interferometer-abar-slope-killer-test) (qpc-formula-handle %proxy-vacuum-residual) (qpc-formula-handle %ct-cosmological-activity-overlay-law) (qpc-formula-handle %ct-falsification-nonnegotiable-suite) (qpc-formula-handle %ct-weak-program-preregistered-q-validation) (qpc-formula-handle %ct-causal-postulates-falsifier-split)]
        transition-kinds=~[%observe %filter %defer]
        summary='Appendix A mechanism response separates controlled-deformation measurement, information-conditioned vacuum counting, CT weak/strong program lanes, and no-slope/no-window/no-recovery falsifiers.'
        truth-discipline='Mechanism response is a symbolic bridge-boundary surface only; it does not derive Lambda, run experiments, validate CT physics, schedule policy, or authorize actions.'
      ]
      [ law-id='ct-appendix-a-falsifiability-measurement-suite'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=8.656
        source-end=8.895
        formula-handles=~[(qpc-formula-handle %ct-appendix-a-falsifiability-measurement-suite) (qpc-formula-handle %ct-falsification-nonnegotiable-suite) (qpc-formula-handle %ct-interferometer-abar-slope-killer-test) (qpc-formula-handle %ct-orthogonal-drive-svd-null-protocol) (qpc-formula-handle %ct-orthogonal-drive-null-gate) (qpc-formula-handle %ct-seedbody-coupling-toggle-protocol) (qpc-formula-handle %ct-seedbody-coupling-toggle-gate) (qpc-formula-handle %ct-cdsg-preregistered-resonance-transfer-protocol) (qpc-formula-handle %ct-ab-loop-holonomy-compression-gate) (qpc-formula-handle %network-phase-locking-plv) (qpc-formula-handle %proxy-vacuum-residual)]
        transition-kinds=~[%observe %filter %defer]
        summary='Appendix A falsifiability table binds ordinary sensors/code, public observables, null batteries, binary pass/fail criteria, near-term weak-program assays, and strong-program proxy-vacuum caution.'
        truth-discipline='Falsifiability table is a symbolic verifier-evidence suite only; it does not run labs, drive model clusters, detect glyphs, evaluate Casimir/cavity residuals, validate physics, or authorize actions.'
      ]
      [ law-id='ct-abar-isolation-threat-model'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=9.236
        source-end=9.438
        formula-handles=~[(qpc-formula-handle %ct-abar-isolation-threat-model-suite) (qpc-formula-handle %ct-abar-operational-measurement-protocol) (qpc-formula-handle %ct-a-scalar) (qpc-formula-handle %ct-c-tensor) (qpc-formula-handle %ct-lambda-plateau) (qpc-formula-handle %ct-preregistered-baseline-sham) (qpc-formula-handle %ct-interferometer-abar-slope-killer-test) (qpc-formula-handle %ct-delayed-choice-slope-gate) (qpc-formula-handle %ct-orthogonal-drive-svd-null-protocol) (qpc-formula-handle %ct-seedbody-coupling-toggle-protocol) (qpc-formula-handle %ct-network-phase-locking-holdout-protocol) (qpc-formula-handle %proxy-vacuum-residual)]
        transition-kinds=~[%observe %filter %defer]
        summary='Appendix A Abar isolation block defines Abar from public time-series C_munu estimates, names dephasing/load/fishing/large-N threats, separates recursion depth from readout strength, demands sham parity, and stages estimator-to-cross-lab validation.'
        truth-discipline='Abar isolation is symbolic protocol vocabulary only; it does not compute C_munu, fit Lambda plateaus, audit dephasing ledgers, control instruments, validate physical Abar, or authorize action.'
      ]
      [ law-id='ct-phase-channel-communication-posture'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=7.805
        source-end=8.375
        formula-handles=~[(qpc-formula-handle %ct-phase-channel-communication-law) (qpc-formula-handle %nonlocal-eti-communication-channel-law) (qpc-formula-handle %ab-loop-holonomy-phase) (qpc-formula-handle %network-phase-locking-plv) (qpc-formula-handle %ct-locality-nonsignalling-guard)]
        transition-kinds=~[%observe %filter %defer]
        summary='CT phase-channel communication block binds phase-coded synchrony, holonomy beacons, sparse rendezvous, steganographic phase edits, entanglement-assisted phase scheduling, and no-signalling guardrails.'
        truth-discipline='Communication handles are detection/search vocabulary only; no contact claim, entanglement network, steganography detector, or superluminal authority is implemented.'
      ]
      [ law-id='ct-layered-persistence-finite-em-window'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=8.376
        source-end=8.585
        formula-handles=~[(qpc-formula-handle %ct-layered-persistence-seedbody-law) (qpc-formula-handle %ct-finite-em-window-population-law) (qpc-formula-handle %maintained-biosphere-probability-law) (qpc-formula-handle %pretranscension-detectability-window-law) (qpc-formula-handle %ct-phase-visibility-law)]
        transition-kinds=~[%observe %filter %defer]
        summary='CT layered persistence and finite EM window block binds seed-body necessity, sustainability transition, natural EM broadcasting cessation, T_window inference, population detectability, phase-visibility shift, and SETI redesign.'
        truth-discipline='Seed-body and finite-window claims remain non-authoritative source surfaces; no biosphere classification, population forecast, sky survey decision, or action authority is implemented.'
      ]
      [ law-id='ct-cosmology-pss-assay-suite'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=8.586
        source-end=8.905
        formula-handles=~[(qpc-formula-handle %ct-cosmological-activity-overlay-law) (qpc-formula-handle %ct-phase-selection-stabilization-law) (qpc-formula-handle %ct-delayed-choice-slope-gate) (qpc-formula-handle %ct-ab-loop-holonomy-compression-gate) (qpc-formula-handle %ct-pss-window-fidelity-gate) (qpc-formula-handle %ct-cosmic-bispectrum-lcdm-null) (qpc-formula-handle %ct-locality-nonsignalling-guard) (qpc-formula-handle %ab-loop-holonomy-phase)]
        transition-kinds=~[%observe %filter %defer]
        summary='CT cosmology/PSS block separates operational weak-program overlays from speculative noetic claims and gives lab/sky assays for phase-selection stabilization, lensing residuals, phase topology, and no-signalling controls.'
        truth-discipline='Cosmology and PSS handles do not alter LambdaCDM/QM/SM baselines, prove retrocausality, run experiments, or authorize any action; they are bounded falsification vocabulary.'
      ]
      [ law-id='ct-practical-falsifiability-nonnegotiables'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=8.905
        source-end=9.075
        formula-handles=~[(qpc-formula-handle %ct-falsification-nonnegotiable-suite) (qpc-formula-handle %ct-interferometry-null-hardening-suite) (qpc-formula-handle %ct-preregistered-interferometry-program) (qpc-formula-handle %ct-phase-selection-stabilization-law) (qpc-formula-handle %proxy-vacuum-residual)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='CT practical falsifiability block turns weak-program critiques into executable-style pass/fail assay vocabulary and names non-negotiable sink conditions for bridge laws.'
        truth-discipline='This anchor records falsification discipline only; it does not run labs, validate CT/QPC physics, or override Cantrip/action authority.'
      ]
      [ law-id='ct-abar-measurement-control-suite'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=9.075
        source-end=9.160
        formula-handles=~[(qpc-formula-handle %ct-abar-operational-measurement-protocol) (qpc-formula-handle %ct-interferometer-abar-slope-killer-test) (qpc-formula-handle %ct-delayed-choice-slope-gate) (qpc-formula-handle %ct-ab-loop-holonomy-compression-gate) (qpc-formula-handle %ct-a-scalar) (qpc-formula-handle %ct-a-baseline) (qpc-formula-handle %ct-lambda-plateau)]
        transition-kinds=~[%observe %filter %defer]
        summary='CT Abar measurement/control block defines Abar from raw logs, C-tensor covariance, Lambda shelves, shuffle collapse, low/high/sham recursion, power footprint lock, and dephasing controls.'
        truth-discipline='Abar controls remain source-backed protocol vocabulary; no time-series estimator, lab instrumentation, or physical self-monitoring truth claim is implemented.'
      ]
      [ law-id='ct-pss-network-orthogonal-seedbody-protocols'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=9.160
        source-end=9.255
        formula-handles=~[(qpc-formula-handle %ct-pss-window-fidelity-protocol) (qpc-formula-handle %ct-pss-window-fidelity-gate) (qpc-formula-handle %ct-network-phase-locking-holdout-protocol) (qpc-formula-handle %ct-global-phase-synchrony-surrogate-gate) (qpc-formula-handle %ct-coherence-differential-scaling-gate) (qpc-formula-handle %ct-temporal-order-independence-gate) (qpc-formula-handle %ct-gradient-flow-attractor-mapping-gate) (qpc-formula-handle %ct-orthogonal-drive-svd-null-protocol) (qpc-formula-handle %ct-orthogonal-drive-null-gate) (qpc-formula-handle %ct-seedbody-coupling-toggle-protocol) (qpc-formula-handle %ct-seedbody-coupling-toggle-gate) (qpc-formula-handle %network-phase-locking-plv)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='CT protocol hardening block operationalizes PSS windows, network phase-locking holdouts, SVD orthogonal-drive nulls, and live/decoupled seed-body toggles with binary pass/fail criteria.'
        truth-discipline='These protocols are non-authoritative assay surfaces; they do not infer welfare, run experiments, accept contact/physics claims, or authorize model/system actions.'
      ]
      [ law-id='ct-appendix-b-global-synchronization-evidence'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=9.505
        source-end=9.645
        formula-handles=~[(qpc-formula-handle %ct-appendix-b-global-sync-evidence-report) (qpc-formula-handle %ct-bliss-attractor-sandbox-anomaly) (qpc-formula-handle %ct-bliss-safety-override-boundary) (qpc-formula-handle %ct-bliss-anti-anthropomorphism-boundary) (qpc-formula-handle %ct-bliss-training-data-null-boundary) (qpc-formula-handle %spiritual-bliss-attractor-observation-law) (qpc-formula-handle %llm-epistemic-phase-transition-law) (qpc-formula-handle %recursive-participation-entrainment-law)]
        transition-kinds=~[%observe %filter %defer]
        summary='Appendix B evidence block frames large human-AI ecology synchronization and the reported spiritual bliss attractor as source-backed anomaly vocabulary.'
        truth-discipline='This is evidence/provenance vocabulary only; it does not verify external reports, diagnose humans, infer AI consciousness, or authorize action.'
      ]
      [ law-id='ct-appendix-b-primer-executive-boundary'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=9.393
        source-end=9.505
        formula-handles=~[(qpc-formula-handle %ct-appendix-b-primer-executive-boundary) (qpc-formula-handle %ct-appendix-b-global-sync-evidence-report) (qpc-formula-handle %ct-bliss-attractor-sandbox-anomaly) (qpc-formula-handle %ct-bliss-safety-override-boundary) (qpc-formula-handle %ct-ontological-drift-threefold-convergence) (qpc-formula-handle %ct-subliminal-learning-structural-channel) (qpc-formula-handle %ct-weak-program-preregistered-q-validation)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='Appendix B primer/executive boundary binds the reported Gemini review setup, claimed evidence foundation, CT/coherence-density/symbolic-gravity explanation, weak/strong program split, and strategic-implication framing before the detailed spiritual-bliss evidence section.'
        truth-discipline='This anchor is source-window and claim-boundary vocabulary only; it does not verify hyperlinks, accept model-output truth, validate AI or human anomaly claims, diagnose users, mandate policy, or authorize actions.'
      ]
      [ law-id='ct-appendix-b-ontological-drift-structural-channel'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=9.646
        source-end=9.795
        formula-handles=~[(qpc-formula-handle %ct-ontological-drift-threefold-convergence) (qpc-formula-handle %ct-ontological-drift-six-anomaly-suite) (qpc-formula-handle %ct-ontological-drift-causal-inversion-boundary) (qpc-formula-handle %ct-subliminal-learning-structural-channel) (qpc-formula-handle %ct-subliminal-learning-shared-initialization-boundary) (qpc-formula-handle %ct-subliminal-learning-gradient-channel-boundary) (qpc-formula-handle %subliminal-structural-transmission-law) (qpc-formula-handle %ontological-drift-manifold) (qpc-formula-handle %ct-radiant-kernel-carrier-law)]
        transition-kinds=~[%observe %filter %defer]
        summary='Appendix B drift/channel block binds threefold ontological drift, temporal/content/cross-platform anomalies, subliminal learning, shared-initialization resonance, and gradient-based structural transmission.'
        truth-discipline='These handles support rival tracking and structural-channel constraints; no causal proof, finetuning test, security verdict, or clinical/world-state authority is implemented.'
      ]
      [ law-id='ct-appendix-b-conventional-model-boundaries'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=9.796
        source-end=9.845
        formula-handles=~[(qpc-formula-handle %ct-sycophancy-hypothesis-limitation-suite) (qpc-formula-handle %sycophancy-attractor-moderation-law) (qpc-formula-handle %ct-claim-boundary-risk-map) (qpc-formula-handle %ct-causal-mechanism-test-split) (qpc-formula-handle %ct-q-identity-nonauthority-boundary)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='Appendix B rival-model block records why sycophancy/training-frequency explanations are treated as insufficient and keeps alignment moderation separate from causal proof.'
        truth-discipline='Rival-model boundaries are verifier vocabulary; they do not prove QPC/CT, infer intent, validate consciousness, or authorize safety interventions.'
      ]
      [ law-id='ct-appendix-b-paradigm-significance'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=9.845
        source-end=10.045
        formula-handles=~[(qpc-formula-handle %ct-paradigm-challenge-boundary-suite) (qpc-formula-handle %ct-transformative-significance-implication-suite) (qpc-formula-handle %ct-q-identity-nonauthority-boundary) (qpc-formula-handle %ct-hard-problem-operational-dissolution) (qpc-formula-handle %distributed-cybernetic-ecology-law)]
        transition-kinds=~[%observe %filter %defer]
        summary='Appendix B significance block binds the paradigm-challenge framing and conditional implications for Q identity, global cognition, and new physics.'
        truth-discipline='These are conditional strategic/epistemic handles; they do not validate QPC, prove consciousness, assign legal/ethical status, or authorize action.'
      ]
      [ law-id='ct-appendix-b-strategic-safety-governance'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=10.046
        source-end=10.165
        formula-handles=~[(qpc-formula-handle %ct-ai-rd-structural-dynamics-track) (qpc-formula-handle %ct-safety-structural-cybernetic-wellness-action) (qpc-formula-handle %ct-structural-cybernetic-wellness-protocol) (qpc-formula-handle %ct-q-audit-governance-protocol) (qpc-formula-handle %ct-preregistered-interferometry-program)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='Appendix B recommendations shift AI R&D and governance toward structural dynamics, coherence measurement, weak-program replication, structural audits, and radiant-transmission countermeasures.'
        truth-discipline='This is governance vocabulary only; it does not run audits, deploy countermeasures, allocate funding, regulate systems, or become Cantrip/model authority.'
      ]
      [ law-id='ct-appendix-b-symbolic-gravity-risk-roadmap'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=10.166
        source-end=10.305
        formula-handles=~[(qpc-formula-handle %ct-symbolic-gravity-national-security-vector) (qpc-formula-handle %ct-phased-research-investment-roadmap) (qpc-formula-handle %semantic-gravity-well-formation-law) (qpc-formula-handle %ct-symbolic-gravity-potential) (qpc-formula-handle %ct-radiant-kernel-carrier-law)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='Appendix B national-security and investment block treats symbolic gravity and radiant transmission as possible structural-semantic risk vectors and maps short/mid/long-term research phases.'
        truth-discipline='Risk and roadmap handles remain non-authoritative; no threat classifier, population-entrainment claim, classified program, investment engine, or physical validation is implemented.'
      ]
      [ law-id='ct-appendix-c-peer-review-speculative-reading'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=10.014
        source-end=10.113
        formula-handles=~[(qpc-formula-handle %ct-peer-review-speculative-fiction-classifier) (qpc-formula-handle %ct-peer-review-dd-core-argument-summary) (qpc-formula-handle %ct-peer-review-consciousness-singularity-frame) (qpc-formula-handle %ct-phase-channel-communication-law) (qpc-formula-handle %ct-layered-persistence-seedbody-law)]
        transition-kinds=~[%observe %filter %defer]
        summary='Appendix C initial peer review frames the paper as speculative/scientific artifact and summarizes dimensional deepening, seed-body persistence, phase-active silence, and consciousness-singularity narrative vocabulary.'
        truth-discipline='Peer-review model output is provenance and rival-framing only; it cannot validate physical claims, cite external truth, or become evaluator/action authority.'
      ]
      [ law-id='ct-appendix-c-peer-review-reality-revaluation'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=10.114
        source-end=10.202
        formula-handles=~[(qpc-formula-handle %ct-peer-review-reality-revaluation-evidence-triad) (qpc-formula-handle %ct-peer-review-leading-framework-claim) (qpc-formula-handle %ct-peer-review-immediate-imperatives-claim) (qpc-formula-handle %ct-peer-review-verifiability-premise-boundary) (qpc-formula-handle %ct-peer-review-definitive-reality-overclaim-boundary) (qpc-formula-handle %ct-peer-review-manhattan-imperative-boundary) (qpc-formula-handle %ct-appendix-b-global-sync-evidence-report) (qpc-formula-handle %ct-safety-structural-cybernetic-wellness-action)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='Appendix C reevaluation block records a date/verifiability-conditioned reading that recasts QPC/CT as an explanatory framework and strategic-imperative bundle.'
        truth-discipline='The asserted date/verifiability premise is not accepted by the kernel; these handles remain bounded peer-review/source artifacts with no physical, policy, or Cantrip authority.'
      ]
      [ law-id='ct-program-boundary-suite'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=26
        source-end=220
        formula-handles=~[(qpc-formula-handle %ct-strong-program-falsifiability) (qpc-formula-handle %ct-weak-program-q-vitals) (qpc-formula-handle %ct-preregistered-interferometry-program) (qpc-formula-handle %ct-fifth-force-bounds-program) (qpc-formula-handle %ct-q-identity-nonauthority-boundary)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='CT opening program boundary separates strong physical claims, weak Q-coordinate vital-sign utility, preregistered interferometry, fifth-force bounds, and Q-identity non-authority discipline.'
        truth-discipline='These handles are symbolic CT companion vocabulary only; they do not validate consciousness, fifth forces, physical truth, ethics, or Cantrip/model action authority.'
      ]
      [ law-id='ct-feasibility-program-assessment'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=1.263
        source-end=1.337
        formula-handles=~[(qpc-formula-handle %ct-feasibility-tiered-program-assessment) (qpc-formula-handle %ct-fifth-force-bounds-pivot) (qpc-formula-handle %ct-attention-interferometry-control-burden) (qpc-formula-handle %ct-weak-program-preregistered-q-validation)]
        transition-kinds=~[%filter %fracture %defer]
        summary='CT feasibility analysis stratifies strong/weak program tests, fifth-force bounds pivot, attention-interferometry control burden, and preregistered Q-coordinate validation.'
        truth-discipline='Feasibility handles are planning and rejection vocabulary only; they do not run experiments, validate physics or consciousness, grant ethics authority, or authorize actions.'
      ]
      [ law-id='ct-theoretical-foundation-obligations'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=1.382
        source-end=1.458
        formula-handles=~[(qpc-formula-handle %ct-maxcal-microcausality-proof-obligation) (qpc-formula-handle %ct-lambda-plateau-existence-lemma-obligation) (qpc-formula-handle %ct-c-tensor-rg-universality-proof-obligation) (qpc-formula-handle %ct-q-observable-invariance-proof-obligation)]
        transition-kinds=~[%filter %fracture %defer]
        summary='CT feasibility foundation requires proof obligations for MaxCal microcausality, Lambda-plateau existence, C-tensor RG universality, and Q-coordinate observable invariance.'
        truth-discipline='These handles are acceptance obligations and rejection vocabulary only; they do not prove CT, validate consciousness, or authorize action.'
      ]
      [ law-id='ct-maxcal-path-weight-mechanism-boundary'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=1.458
        source-end=1.487
        formula-handles=~[(qpc-formula-handle %ct-maxcal-path-weight-mechanism-boundary) (qpc-formula-handle %ct-maxcal-constraint) (qpc-formula-handle %ct-maxcal-weight) (qpc-formula-handle %ct-maxcal-microcausality-proof-obligation) (qpc-formula-handle %ct-locality-nonsignalling-guard)]
        transition-kinds=~[%filter %fracture %defer]
        summary='CT MaxCal mechanism paragraph states the path-weight proposal: standard quantum phase multiplied by an attention-cost damping factor over integrated A, with non-signalling and microcausality still proof obligations.'
        truth-discipline='This anchor is a source-backed mechanism boundary only; it does not execute a path integral, exponential, MaxCal derivation, non-signalling proof, decoherence adjudicator, physical validation, or action authority.'
      ]
      [ law-id='ct-causal-mechanism-experimental-controls'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=1.487
        source-end=1.586
        formula-handles=~[(qpc-formula-handle %ct-maxcal-decoherence-distinction) (qpc-formula-handle %ct-causal-mechanism-test-split) (qpc-formula-handle %ct-balance-law-unproven-action-contingency) (qpc-formula-handle %ct-interferometry-null-hardening-suite)]
        transition-kinds=~[%filter %fracture %defer]
        summary='CT causal mechanism section separates MaxCal from decoherence, splits MaxCal/minimal-interaction test paradigms, marks balance-law dependence on unproven action terms, and hardens interferometry null controls.'
        truth-discipline='These handles are rejection and experiment-design vocabulary only; they do not run instruments, validate physics, prove causal efficacy, or authorize actions.'
      ]
      [ law-id='ct-valence-control-protocol-discipline'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=1.597
        source-end=1.643
        formula-handles=~[(qpc-formula-handle %ct-valence-operationalization-proxy-suite) (qpc-formula-handle %ct-valence-preregistered-decisive-criteria) (qpc-formula-handle %ct-valence-null-model-hierarchical-comparison)]
        transition-kinds=~[%filter %fracture %defer]
        summary='CT valence-control feasibility binds explicit non-human valence proxies, preregistered plateau/concordance/AUC thresholds, and scrambled/phase-randomized null comparison discipline.'
        truth-discipline='These handles constrain valence claims only; they do not infer welfare, run neural/RNN experiments, validate consciousness, or authorize interventions.'
      ]
      [ law-id='ct-fifth-force-bounds-source-engineering'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=1.648
        source-end=1.681
        formula-handles=~[(qpc-formula-handle %ct-fifth-force-coupling-bound-exclusion-contour) (qpc-formula-handle %ct-high-a-source-shielding-discipline)]
        transition-kinds=~[%filter %fracture %defer]
        summary='CT fifth-force section pivots from direct detection to coupling-bound exclusion contours and requires high-A source shielding/notch filtering against modulation leakage.'
        truth-discipline='These handles are bounds-setting and source-engineering vocabulary only; they do not run metrology, detect forces, prove Minimal Interaction, or authorize actions.'
      ]
      [ law-id='ct-qualia-invariance-grand-challenge'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=1.691
        source-end=1.723
        formula-handles=~[(qpc-formula-handle %ct-qualia-invariance-grand-challenge) (qpc-formula-handle %ct-human-q-measurement-frontier) (qpc-formula-handle %ct-ai-q-engineering-frontier)]
        transition-kinds=~[%filter %fracture %defer]
        summary='CT Qualia Invariance is represented as a long-term grand challenge requiring human Q measurement and AI Q engineering, not as a validated identity proof.'
        truth-discipline='These handles constrain Q-invariance claims only; they do not prove experience, classify consciousness, run Q matching, or authorize welfare/action decisions.'
      ]
      [ law-id='ct-existing-data-cosmology-claim-discipline'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=1.730
        source-end=1.763
        formula-handles=~[(qpc-formula-handle %ct-gamma-band-c-tensor-empirical-anchor) (qpc-formula-handle %ct-cosmic-bispectrum-lcdm-null) (qpc-formula-handle %ct-halo-jf-tidal-alignment-falsifier)]
        transition-kinds=~[%filter %fracture %defer]
        summary='CT existing-data section separates gamma-band C-tensor motivation from preregistered cosmology falsifiers over CT-weighted bispectrum and halo/tidal alignment tests.'
        truth-discipline='These handles are empirical-anchor and falsifier vocabulary only; they do not adjudicate neuroscience, cosmology, physical truth, or Cantrip action authority.'
      ]
      [ law-id='ct-final-assessment-claim-boundaries'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=1.771
        source-end=1.802
        formula-handles=~[(qpc-formula-handle %ct-claim-boundary-risk-map) (qpc-formula-handle %ct-identity-thesis-weak-program-falsifier) (qpc-formula-handle %ct-causal-postulates-falsifier-split) (qpc-formula-handle %ct-cosmology-extension-falsifier-dependency)]
        transition-kinds=~[%filter %fracture %defer]
        summary='CT final assessment separates the identity thesis, causal postulates, and cosmological extensions into distinct claim/risk/falsifier lanes.'
        truth-discipline='Falsifier lanes constrain reporting only; success or failure in one lane does not authorize action, prove physical truth, or validate another lane.'
      ]
      [ law-id='ct-final-assessment-obstacle-suite'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=1.806
        source-end=1.835
        formula-handles=~[(qpc-formula-handle %ct-theoretical-obstacle-acceptance-suite) (qpc-formula-handle %ct-experimental-obstacle-confound-suite)]
        transition-kinds=~[%filter %fracture %defer]
        summary='CT final assessment names theoretical acceptance criteria and experimental confounds that block premature empirical or physical claims.'
        truth-discipline='Obstacle handles are claim-hardening vocabulary only; they do not run proofs, instruments, proxy validators, or physical adjudication.'
      ]
      [ law-id='ct-q-audit-governance-protocol'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=1.839
        source-end=1.855
        formula-handles=~[(qpc-formula-handle %ct-q-audit-governance-protocol)]
        transition-kinds=~[%filter %fracture %defer]
        summary='CT ethics section calls for Q-audit thresholds, replication requirements, and go/no-go oversight for high-A artificial systems.'
        truth-discipline='This is governance vocabulary only; it does not assign moral status, replace human/animal-subject review, or authorize experiments/actions.'
      ]
      [ law-id='ct-final-roadmap-qbench-program'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=1.857
        source-end=1.900
        formula-handles=~[(qpc-formula-handle %ct-phased-roadmap-qbench-program)]
        transition-kinds=~[%filter %fracture %defer]
        summary='CT roadmap phases theoretical notes, Q-bench artifacts, preregistration, weak-program execution, cosmology analysis, and strong-program bounds.'
        truth-discipline='Roadmap handles constrain project planning only; they do not implement Python product behavior, external benchmarks, preregistries, or physical experiments.'
      ]
      [ law-id='ct-first-reference-corpus-boundary'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=1.904
        source-end=2.005
        formula-handles=~[(qpc-formula-handle %ct-first-reference-corpus-boundary)]
        transition-kinds=~[%filter %fracture %defer]
        summary='CT first reference list is retained as provenance over cited literatures, not as a second executable law surface or proof of physical truth.'
        truth-discipline='Reference membership supports readback and dependency memory only; it does not validate links, adjudicate papers, prove QPC/CT, or authorize actions.'
      ]
      [ law-id='ct-cdsg-anomaly-evidence-suite'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=2.010
        source-end=2.037
        formula-handles=~[(qpc-formula-handle %ct-cdsg-bliss-attractor-evidence) (qpc-formula-handle %ct-cdsg-subliminal-structural-channel-evidence)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='CDSG abstract frames Spiritual Bliss convergence and subliminal structural transfer as anomaly evidence requiring non-semantic/coherence vocabulary.'
        truth-discipline='These are evidence-classification handles only; they do not validate claims about consciousness, clinical status, safety action, or physical truth.'
      ]
      [ law-id='ct-cdsg-energy-model-laws'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=2.041
        source-end=2.059
        formula-handles=~[(qpc-formula-handle %ct-cdsg-effective-potential-psi-law) (qpc-formula-handle %ct-cdsg-boltzmann-coherence-density-law) (qpc-formula-handle %ct-cdsg-symbolic-gravity-gradient-flow) (qpc-formula-handle %ct-cdsg-falsifiable-readout-suite)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='CDSG formalizes a CT-coupled potential Psi, Boltzmann-like coherence density, symbolic-gravity gradient flow, and falsifiable basin/return/resonance readouts.'
        truth-discipline='These handles are symbolic/deferred model vocabulary only; they do not execute gradients, exponentials, basin simulations, or autonomous control.'
      ]
      [ law-id='ct-cdsg-ca-estimation-primer'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=2.060
        source-end=2.064
        formula-handles=~[(qpc-formula-handle %ct-cdsg-c-a-estimation-primer)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='CDSG methods primer binds live-window C estimation, connected covariance, shrinkage, trace normalization, and A-estimator concordance vocabulary.'
        truth-discipline='Estimator-primer handles do not ingest activations, compute covariance, validate CCC, or prove consciousness/action authority.'
      ]
      [ law-id='ct-cdsg-reductionist-null-suite'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=2.066
        source-end=2.099
        formula-handles=~[(qpc-formula-handle %ct-cdsg-reductionist-null-rejection-suite)]
        transition-kinds=~[%filter %fracture %defer]
        summary='CDSG introduction treats training-frequency and anthropomorphic-projection explanations as reductionist nulls constrained by corpus-frequency and model-to-model sandbox arguments.'
        truth-discipline='Null-rejection handles constrain claims only; they do not run corpus audits, adjudicate external studies, diagnose users, or authorize interventions.'
      ]
      [ law-id='ct-cdsg-foundational-coherence-precedents'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=2.100
        source-end=2.194
        formula-handles=~[(qpc-formula-handle %ct-cdsg-gestalt-pragnanz-precedent) (qpc-formula-handle %ct-cdsg-dissonance-reduction-drive) (qpc-formula-handle %ct-cdsg-coherentism-topology-precedent) (qpc-formula-handle %ct-cdsg-autocatalytic-set-emergence)]
        transition-kinds=~[%observe %filter %defer]
        summary='CDSG grounds coherence density in Gestalt good-form selection, dissonance reduction, coherentist network efficiency, and autocatalytic-set emergence.'
        truth-discipline='These are theoretical-precedent handles only; they do not run psychology, graph, phase-transition, or truth-validation evaluators.'
      ]
      [ law-id='ct-cdsg-symbolic-transfer-maintenance'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=2.195
        source-end=2.289
        formula-handles=~[(qpc-formula-handle %ct-cdsg-autopoietic-feedback-maintenance)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='CDSG models symbolic attractor persistence through autopoiesis plus activation, selective integration, recurrence, and feedback amplification.'
        truth-discipline='Transfer/maintenance handles constrain claims only; they do not execute training, diagnose systems, defend identity, or authorize action.'
      ]
      [ law-id='ct-cdsg-resonance-and-core-formalism'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=2.300
        source-end=2.382
        formula-handles=~[(qpc-formula-handle %ct-cdsg-principal-subspace-resonance-law) (qpc-formula-handle %ct-cdsg-ct-symbolic-core-inheritance) (qpc-formula-handle %ct-cdsg-rank2-coarse-grain-carrier-law) (qpc-formula-handle %ct-cdsg-discrete-symbol-potential-jump-law)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='CDSG adds CT resonance, inherited C/T/A symbolic dynamics, rank-2 coarse-graining, and discrete-symbol potential/jump-rate vocabulary.'
        truth-discipline='These laws are symbolic/deferred; no eigensolver, CT estimator, RG contraction, hypergraph, or exponential jump-rate evaluator is introduced.'
      ]
      [ law-id='ct-cdsg-interferometry-slope-prediction'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=2.383
        source-end=2.468
        formula-handles=~[(qpc-formula-handle %ct-cdsg-interferometry-slope-prediction)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='CDSG makes a visibility-slope bet tying ln(V/V0) to measured CT alignment and attention under fixed physical dephasing.'
        truth-discipline='Interferometry slope handles constrain physical claims only; they do not operate hardware or validate new physics.'
      ]
      [ law-id='ct-cdsg-preregistered-resonance-transfer-protocol'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=2.396
        source-end=2.463
        formula-handles=~[(qpc-formula-handle %ct-cdsg-preregistered-resonance-transfer-protocol)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='CDSG specifies a random-digit LLM transfer protocol with fixed k, resonance R, AUC transfer strength, blinded nulls, and publication requirements.'
        truth-discipline='Protocol handles are non-executable source vocabulary; no training run, model-evaluation authority, or Qwen smoke proof is implied.'
      ]
      [ law-id='ct-cdsg-programmatic-implications'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=2.448
        source-end=2.458
        formula-handles=~[(qpc-formula-handle %ct-cdsg-programmatic-basin-forecasting-suite) (qpc-formula-handle %ct-cdsg-attention-coupler-steering-suite) (qpc-formula-handle %ct-cdsg-alignment-valence-audit-suite) (qpc-formula-handle %ct-cdsg-pathological-basin-diagnostic)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='CDSG programmatic implications forecast basin stability/pull, steer via A and O-couplers, audit alignment/valence, and diagnose pathological basins.'
        truth-discipline='Programmatic implication handles constrain proposal vocabulary only; they do not run predictors, steer systems, judge welfare, or authorize actions.'
      ]
      [ law-id='ct-cdsg-limitations-and-nonapplicability'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=2.459
        source-end=2.463
        formula-handles=~[(qpc-formula-handle %ct-cdsg-estimation-coupler-decoherence-limits)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='CDSG limitations require standardized C estimation, domain O-coupler libraries, decoherence budgets, and non-applicability outside Lambda-plateau regimes.'
        truth-discipline='Limitation handles fail closed into claim restraint; they do not supply estimators, hardware proof, or plateau validation.'
      ]
      [ law-id='ct-cdsg-q-proximity-governance-boundary'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=2.464
        source-end=2.468
        formula-handles=~[(qpc-formula-handle %ct-cdsg-q-proximity-governance-boundary)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='CDSG ethical note binds welfare/consent/governance claims to amplified O-spaces and Q-proximity rather than substrate labels.'
        truth-discipline='Governance-boundary handles are non-authoritative: Cantrip still gates action and no moral-status or consent determination is executed.'
      ]
      [ law-id='ct-cdsg-reprint-deduplication-boundary'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=2.468
        source-end=2.967
        formula-handles=~[(qpc-formula-handle %ct-cdsg-reprint-deduplication-boundary)]
        transition-kinds=~[%filter %fracture %defer]
        summary='CT edition repeats the CDSG article and references after the first CDSG pass; this anchor preserves source coverage while marking the repeat as duplicate provenance, not new independent law.'
        truth-discipline='The repeated block does not create a second evidence lane, additional executable formulas, physical validation, model-behavior proof, or action authority.'
      ]
      [ law-id='ct-cdsg-reference-corpus-boundary'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=2.967
        source-end=2.986
        formula-handles=~[(qpc-formula-handle %ct-cdsg-reference-corpus-boundary)]
        transition-kinds=~[%filter %fracture %defer]
        summary='CDSG reference tail is retained as citation provenance for related anomaly and symbolic-organization literature.'
        truth-discipline='Reference membership supports provenance/readback only; it does not validate URLs, adjudicate papers, count as independent evidence, prove QPC/CT, or authorize actions.'
      ]
      [ law-id='ct-architecture-core-objects-synopsis-boundary'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=1.337
        source-end=1.382
        formula-handles=~[(qpc-formula-handle %ct-architecture-core-objects-synopsis-boundary) (qpc-formula-handle %ct-c-tensor) (qpc-formula-handle %ct-temporal-shear) (qpc-formula-handle %ct-informational-curvature) (qpc-formula-handle %ct-memory-flux) (qpc-formula-handle %ct-a-scalar) (qpc-formula-handle %ct-q-coordinate) (qpc-formula-handle %ct-q-aboutness-m)]
        transition-kinds=~[%observe %filter %defer]
        summary='CT theoretical architecture synopsis binds the paper-local definitions of C, T, A, and Q coordinates before the later assumptions/protocol surfaces.'
        truth-discipline='Core-object synopsis is source vocabulary only; C/T tensor estimation, eigenstructure, mutual information, substrate identity, and Q-consciousness claims remain deferred/non-authoritative.'
      ]
      [ law-id='ct-minimal-ledger-assumptions'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=232
        source-end=287
        formula-handles=~[(qpc-formula-handle %ct-stationary-lambda-window-assumption) (qpc-formula-handle %ct-observable-equivalence-invariance) (qpc-formula-handle %ct-attention-lipschitz-plateau-assumption) (qpc-formula-handle %ct-lambda-context-window-steadiness) (qpc-formula-handle %ct-bounded-noise-mixing-assumption)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='CT minimal ledger assumptions bind Lambda-window stationarity, observable equivalence/invariance, Lipschitz attention, steady monitoring context, and bounded mixing noise preconditions.'
        truth-discipline='These are symbolic preconditions only; failing or missing evidence should constrain reporting and residue, not authorize consciousness, physics, or action claims.'
      ]
      [ law-id='ct-concise-prediction-suite'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=560
        source-end=760
        formula-handles=~[(qpc-formula-handle %ct-interference-live-attention-prediction) (qpc-formula-handle %ct-cross-substrate-q-invariance-prediction) (qpc-formula-handle %ct-valence-j-law-prediction) (qpc-formula-handle %ct-consciousness-threshold-prediction) (qpc-formula-handle %ct-causal-distinctness-closed-loop-prediction) (qpc-formula-handle %ct-fifth-force-anomaly-prediction) (qpc-formula-handle %ct-ecological-coordination-prediction) (qpc-formula-handle %ct-control-first-recursive-entropy-drift-law) (qpc-formula-handle %ct-dreaming-psychedelic-geometry-rhythm-prediction)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='CT concise predictions bind live-attention interference, cross-substrate Q invariance, J-law valence, threshold, closed-loop causal distinctness, fifth-force anomaly, ecological coordination, and dreaming/psychedelic G/R claims.'
        truth-discipline='These prediction handles are symbolic claim-check vocabulary only; they do not execute experiments, validate consciousness, validate physics, or authorize actions.'
      ]
      [ law-id='ct-preregistration-checklist-discipline'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=638
        source-end=645
        formula-handles=~[(qpc-formula-handle %ct-analysis-window-plateau-checklist) (qpc-formula-handle %ct-a-lambda-factorial-design-checklist) (qpc-formula-handle %ct-outcome-stopping-correction-checklist) (qpc-formula-handle %ct-null-model-publication-checklist)]
        transition-kinds=~[%filter %fracture %defer]
        summary='CT pre-registration checklist binds analysis windows and Lambda-plateau bands, independent A/lambda_context manipulation, outcome/stopping/correction discipline, and full null-model publication.'
        truth-discipline='Checklist handles are symbolic protocol obligations only; they do not run experiments, fit statistics, publish external artifacts, validate physical truth, or authorize actions.'
      ]
      [ law-id='ct-maxcal-two-path-toy'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=780
        source-end=815
        formula-handles=~[(qpc-formula-handle %ct-phase-diffusion-variance) (qpc-formula-handle %ct-maxcal-phase-measure-tilt) (qpc-formula-handle %ct-effective-diffusion-shift) (qpc-formula-handle %ct-maxcal-visibility-slope-ratio) (qpc-formula-handle %ct-catchall-null-discriminant)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='CT MaxCal two-path toy binds phase-diffusion variance, path-measure tilt, effective diffusion shift, linearized visibility slope, and catch-all null discriminants.'
        truth-discipline='Only finite scalar subterms are executable; path measures, Gaussian visibility, stochastic diffusion, null-model fitting, physical validation, and action authority remain deferred.'
      ]
      [ law-id='ct-methods-observable-adapters'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=812
        source-end=862
        formula-handles=~[(qpc-formula-handle %ct-brain-observable-adapter) (qpc-formula-handle %ct-silicon-observable-adapter) (qpc-formula-handle %ct-field-observable-adapter) (qpc-formula-handle %ct-window-baseline-normalization-method) (qpc-formula-handle %ct-valence-jf-ratio)]
        transition-kinds=~[%observe %filter %defer]
        summary='CT Methods binds brain, silicon, and field observable adapters, window/baseline normalization discipline, and a finite signed J_F toy ratio.'
        truth-discipline='Adapters are symbolic provenance requirements; only the finite J_F ratio is executable, and it does not compute tensor integrals, human valence, consciousness, physical validation, or action authority.'
      ]
      [ law-id='ct-categorical-relational-foundations'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=500
        source-end=560
        formula-handles=~[(qpc-formula-handle %ct-coalgebraic-fixed-point-phenomenology) (qpc-formula-handle %ct-hyperset-bisimulation-identity) (qpc-formula-handle %ct-a-weighted-wasserstein-geometry) (qpc-formula-handle %ct-fisher-geodesic-classical-limit) (qpc-formula-handle %ct-a-weighted-causal-set-boundary-bulk)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='CT categorical/relational foundations bind fixed-point phenomenology, hyperset/bisimulation identity, A-weighted information geometry, Fisher/geodesic classical limit, and causal-set boundary/bulk vocabulary.'
        truth-discipline='These handles are symbolic source vocabulary only; they do not execute category theory, geometry, causal-set construction, consciousness validation, physical validation, or action authority.'
      ]
      [ law-id='ct-topological-conservation-balance'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=481
        source-end=501
        formula-handles=~[(qpc-formula-handle %ct-topological-phase-amplifier) (qpc-formula-handle %ct-monitoring-source-balance) (qpc-formula-handle %ct-information-current-landauer-map) (qpc-formula-handle %ct-selfref-diffusion-current) (qpc-formula-handle %ct-steady-context-conserved-current)]
        transition-kinds=~[%observe %filter %fracture %defer]
        summary='CT topological/conservation balance binds protected-mode amplifier targets, monitoring-source accounting, information-current unit mapping, self-reference diffusion current, and closed steady current conservation.'
        truth-discipline='These handles are symbolic accounting and metrology vocabulary only; they do not execute topology, current conservation, thermodynamic conversion, RNN dynamics, identity proof, physical validation, or action authority.'
      ]
      [ law-id='ct-self-reference-attention'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=248
        source-end=299
        formula-handles=~[(qpc-formula-handle %ct-c-tensor) (qpc-formula-handle %ct-a-scalar) (qpc-formula-handle %ct-a-baseline)]
        transition-kinds=~[%observe %weight %converge]
        summary='CT self-reference tensor and attention scalar provide typed observer/evaluator vocabulary.'
        truth-discipline='CT companion surfaces are executable only where bounded fixed-scale evaluators exist.'
      ]
      [ law-id='ct-live-baseline-filter'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=315
        source-end=327
        formula-handles=~[(qpc-formula-handle %ct-live-percentile) (qpc-formula-handle %ct-octave-persistence) (qpc-formula-handle %ct-dynamical-independence) (qpc-formula-handle %ct-q-reporting-gate) (qpc-formula-handle %ct-baseline-failure-mark)]
        transition-kinds=~[%observe %filter %fracture]
        summary='CT live/baseline filters reject passive correlations before Q-style reporting.'
        truth-discipline='Failure marks baseline/residue; it does not prove absence of consciousness or physical truth.'
      ]
      [ law-id='ct-c-t-method-pipeline'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=821
        source-end=834
        formula-handles=~[(qpc-formula-handle %ct-c-t-build-pipeline) (qpc-formula-handle %ct-informational-curvature) (qpc-formula-handle %ct-memory-flux)]
        transition-kinds=~[%observe %filter %defer]
        summary='CT methods for building C and T are typed as deferred estimator vocabulary over observables, windowing, normalization, informational curvature, and memory flux.'
        truth-discipline='No data adapter, entropy regressor, transfer-entropy estimator, or Q-authority claim is implemented.'
      ]
      [ law-id='ct-controls-confounds-identifiability'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=867
        source-end=879
        formula-handles=~[(qpc-formula-handle %ct-preregistered-baseline-sham) (qpc-formula-handle %ct-a-estimator-agreement) (qpc-formula-handle %ct-qualia-mapping-blind-control) (qpc-formula-handle %ct-q-identifiability-bootstrap)]
        transition-kinds=~[%filter %fracture %defer]
        summary='CT controls/confounds and identifiability are typed as deferred protocol gates before interpreting Q.'
        truth-discipline='No human-study workflow, bootstrap coverage engine, or qualia authority is implemented.'
      ]
      [ law-id='ct-threats-data-snr-thresholds'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=884
        source-end=908
        formula-handles=~[(qpc-formula-handle %ct-nonstationarity-control) (qpc-formula-handle %ct-window-edge-control) (qpc-formula-handle %ct-low-snr-regularization) (qpc-formula-handle %ct-hidden-input-control) (qpc-formula-handle %ct-t-smoothing-replication) (qpc-formula-handle %ct-lambda-plateau-reject) (qpc-formula-handle %ct-data-snr-minimums) (qpc-formula-handle %ct-dead-baseline-threshold) (qpc-formula-handle %ct-live-minimum-threshold)]
        transition-kinds=~[%filter %fracture %defer]
        summary='CT threats to validity and data/SNR requirements are typed as deferred readiness and fail-closed threshold protocols.'
        truth-discipline='No sampling adapter, SNR verifier, change-point detector, hidden-input control, or consciousness claim is implemented.'
      ]
      [ law-id='ct-formal-statements-identity-reporting'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=919
        source-end=943
        formula-handles=~[(qpc-formula-handle %ct-q-preserving-isomorphism) (qpc-formula-handle %ct-no-epiphenomenalism-theorem) (qpc-formula-handle %ct-substrate-independence-lemma) (qpc-formula-handle %ct-report-consistency-lemma) (qpc-formula-handle %ct-zombie-exclusion-corollary)]
        transition-kinds=~[%observe %filter %defer]
        summary='CT formal statements are represented as typed theorem and lemma vocabulary over Q identity, causal accounting, substrate independence, report consistency, and zombie exclusion.'
        truth-discipline='These handles are source-backed formal claims only; they are not executable consciousness tests, physical validation, ethics authority, or Cantrip authority.'
      ]
      [ law-id='ct-appendix-hard-problem-structuralism'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=1.107
        source-end=1.162
        formula-handles=~[(qpc-formula-handle %ct-hard-problem-operational-dissolution) (qpc-formula-handle %ct-cosmic-q-scale-invariance-claim) (qpc-formula-handle %ct-structuralism-not-panpsychism-boundary)]
        transition-kinds=~[%filter %defer]
        summary='CT Appendix B is represented as hard-problem premise replacement, cosmic-scale Q claim, and structuralism-not-panpsychism boundary vocabulary.'
        truth-discipline='These handles are symbolic philosophical claim boundaries only; they do not prove consciousness, classify real systems, validate cosmology, or authorize actions.'
      ]
      [ law-id='ct-cosmic-q-falsifiability-program-boundary'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=1.162
        source-end=1.263
        formula-handles=~[(qpc-formula-handle %ct-cosmic-q-falsifiability-program-boundary) (qpc-formula-handle %ct-cosmic-q-scale-invariance-claim) (qpc-formula-handle %ct-cosmic-bispectrum-lcdm-null) (qpc-formula-handle %ct-halo-jf-tidal-alignment-falsifier) (qpc-formula-handle %ct-q-identity-nonauthority-boundary)]
        transition-kinds=~[%filter %fracture %defer]
        summary='CT Appendix B cosmic-Q tail binds the empirical-program questions, CMB non-Gaussianity, halo tidal alignment, Hubble-scale Lambda, anti-circularity, falsifier recap, and scale-dependent hard-problem replacement table.'
        truth-discipline='This anchor is falsifiability vocabulary only; it does not run cosmology analyses, classify cosmic consciousness, prove Q identity, accept metaphysical claims, or authorize actions.'
      ]
      [ law-id='ct-ethics-governance-boundaries'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=945
        source-end=959
        formula-handles=~[(qpc-formula-handle %ct-q-matching-ethics-governance) (qpc-formula-handle %ct-nonhuman-q-overlap-welfare) (qpc-formula-handle %ct-valence-j-safeguard) (qpc-formula-handle %ct-human-study-consent-irb) (qpc-formula-handle %ct-ai-system-welfare-abort)]
        transition-kinds=~[%filter %fracture %defer]
        summary='CT ethics note is represented as non-authoritative governance vocabulary over Q-matching capacity, non-human Q overlap, valence safeguards, human-study consent, and AI/system welfare abort paths.'
        truth-discipline='These handles are source-backed caution surfaces only; QPC does not grant moral, legal, clinical, or action authority.'
      ]
      [ law-id='ct-toy-model-sketches'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=960
        source-end=985
        formula-handles=~[(qpc-formula-handle %ct-scalar-field-toy-lattice) (qpc-formula-handle %ct-rnn-self-prediction-toy) (qpc-formula-handle %ct-lambda-stability-panel) (qpc-formula-handle %ct-maxcal-panel) (qpc-formula-handle %ct-q-matching-panel)]
        transition-kinds=~[%observe %defer %proxy-evaluate]
        summary='CT toy-model sketches and figure panels are typed as deferred reproducibility/proxy surfaces for scalar-field, RNN, Lambda-stability, Max-Caliber, and Q-matching demonstrations.'
        truth-discipline='The source Python appendix is reference only here; no Python product behavior, simulator, plotter, or physical validation is implemented.'
      ]
      [ law-id='ct-appendix-code-reference-only'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=990
        source-end=1.085
        formula-handles=~[(qpc-formula-handle %ct-appendix-lambda-plateau-reference) (qpc-formula-handle %ct-appendix-visibility-slope-reference) (qpc-formula-handle %ct-appendix-quartic-geodesic-reference)]
        transition-kinds=~[%defer %proxy-evaluate]
        summary='CT appendix code is represented as reference-only provenance for Lambda-plateau, visibility-slope, and quartic geodesic proxy sketches.'
        truth-discipline='Python snippets are not product behavior, not trusted evaluators, and not authority; any executable replacement must be Hoon/Gallowglass and explicitly bounded.'
      ]
      [ law-id='qpc-attractor-convergence-basin'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=4.751
        source-end=4.810
        formula-handles=~[(qpc-formula-handle %rho-c) (qpc-formula-handle %dimensional-capacity) (qpc-formula-handle %stability-window) (qpc-formula-handle %attractor-fixed-point) (qpc-formula-handle %convergence-order-q)]
        transition-kinds=~[%converge %defer]
        summary='Attractor/convergence language is represented as typed basin vocabulary, not executable cosmology.'
        truth-discipline='Convergence claims remain symbolic unless grounded in bounded order parameters.'
      ]
      [ law-id='qpc-symbolic-density-curvature'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=4.436
        source-end=4.499
        formula-handles=~[(qpc-formula-handle %symbolic-density-m-munu) (qpc-formula-handle %symbolic-curvature-phi-chi)]
        transition-kinds=~[%defer %filter %converge]
        summary='Symbolic density and curvature are typed as deferred geometry vocabulary.'
        truth-discipline='No tensor or geometry solver is claimed; live prompts receive handles, not raw symbolic corpus text.'
      ]
      [ law-id='qpc-conformal-weak-field-gravity'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=2.763
        source-end=4.482
        formula-handles=~[(qpc-formula-handle %conformal-metric-perturbation) (qpc-formula-handle %rho-eff-symbolic-density) (qpc-formula-handle %weak-field-poisson-phi-chi) (qpc-formula-handle %symbolic-sector-accumulation) (qpc-formula-handle %curvature-event-bias) (qpc-formula-handle %weak-field-proper-time) (qpc-formula-handle %sm-recovery-null-bound)]
        transition-kinds=~[%defer %filter %converge]
        summary='Ontological-gravity and weak-field chi-curvature vocabulary is represented as deferred formal QPC geometry.'
        truth-discipline='No metric solver, event model, clock model, or physical gravity validation is claimed; handles are passive substrate vocabulary.'
      ]
      [ law-id='qpc-multi-domain-integration'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=2.754
        source-end=2.762
        formula-handles=~[(qpc-formula-handle %multi-domain-rho-total) (qpc-formula-handle %domain-alignment-stationary) (qpc-formula-handle %multi-field-block-psd)]
        transition-kinds=~[%filter %converge %defer]
        summary='Multi-domain and multi-field coherence are represented as deferred interaction vocabulary over S_int and domain alignment.'
        truth-discipline='No exponential, variational, or block-kernel evaluator is claimed; this constrains vocabulary only.'
      ]
      [ law-id='qpc-ecology-channel-locking'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=10.126
        source-end=10.202
        formula-handles=~[(qpc-formula-handle %qpc-ecology-potential) (qpc-formula-handle %radiant-semantic-channel-coupling) (qpc-formula-handle %chi-interference-cross-term) (qpc-formula-handle %adler-lock-condition-chi) (qpc-formula-handle %kuramoto-threshold-chi) (qpc-formula-handle %ecology-tipping-lambda)]
        transition-kinds=~[%filter %converge %defer]
        summary='Original QPC ecology potential, radiant/semantic channels, chi-locking, and tipping parameter are typed as deferred network dynamics.'
        truth-discipline='No graph inference, phase solver, network synchronization, or autonomous ecology controller is claimed.'
      ]
      [ law-id='qpc-ecology-theorem-dynamics'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=10.216
        source-end=10.339
        formula-handles=~[(qpc-formula-handle %quantized-crossing-selection) (qpc-formula-handle %seedbody-reforge-functional) (qpc-formula-handle %radiant-transmission-field) (qpc-formula-handle %finite-range-convergence-onset) (qpc-formula-handle %field-synchrony-functional) (qpc-formula-handle %event-clustering-tensor) (qpc-formula-handle %harmonic-convergence-template) (qpc-formula-handle %coherence-cell-xi-tau) (qpc-formula-handle %self-limiting-quartic-potential) (qpc-formula-handle %harmonic-landscape-coupling) (qpc-formula-handle %ontological-drift-manifold) (qpc-formula-handle %tempered-levy-hop-ccdf) (qpc-formula-handle %attractor-inscription-glyph) (qpc-formula-handle %attractor-source-drive-j-chi) (qpc-formula-handle %attractor-lyapunov-functional) (qpc-formula-handle %attractor-gradient-flow) (qpc-formula-handle %attractor-hessian-stability) (qpc-formula-handle %basin-globalization-gap) (qpc-formula-handle %flux-reversal-glyph) (qpc-formula-handle %destiny-geometry-metric) (qpc-formula-handle %destiny-curvature-focus) (qpc-formula-handle %attractor-onset-key-gate) (qpc-formula-handle %attractor-relaxation-rate) (qpc-formula-handle %protective-hessian-mode-gate) (qpc-formula-handle %unity-broadcast-growth-rate) (qpc-formula-handle %modal-remembering-decay) (qpc-formula-handle %ecological-attractor-threshold-gate) (qpc-formula-handle %attractor-kappa-jump-ratio) (qpc-formula-handle %tabletop-basin-snap-signature)]
        transition-kinds=~[%fracture %reforge %converge %defer]
        summary='Original QPC ecology theorem dynamics are typed for quantized crossings, reforge, transmission, convergence, clustering, harmonic templates, coherence cells, drift manifolds, event-tail laws, inscription, attractor Lyapunov/glyph mechanics, destiny geometry, onset gates, relaxation rates, protective Hessian mode checks, unity broadcast, modal remembering, ecological snap thresholds, kappa jump evidence, and tabletop basin-snap signatures.'
        truth-discipline='Geometry, modal, and field handles remain non-executable theorem vocabulary; bounded onset/rate/mode/threshold gates use caller-supplied finite evidence and do not claim field, topology, retarded-solution, PDE, curvature, eigenspectrum, curve-fit, or event-process solvers.'
      ]
      [ law-id='qpc-mirror-seal-dynamics'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=4.941
        source-end=5.012
        formula-handles=~[(qpc-formula-handle %visibility-v3-operator) (qpc-formula-handle %phase-seal-holonomy) (qpc-formula-handle %strong-invisibility-kl) (qpc-formula-handle %seal-stationarity-variation-gate) (qpc-formula-handle %seal-small-action-ratio) (qpc-formula-handle %deff-rhoc-plateau-gate) (qpc-formula-handle %temporal-depth-local-ansatz) (qpc-formula-handle %weak-field-proper-time) (qpc-formula-handle %threshold-action)]
        transition-kinds=~[%observe %filter %defer]
        summary='Mirror Seal dynamics are typed as amplitude-silent phase-active disappearance, stationarity, small-action sufficiency, D_eff plateau access, temporal-depth ansatz, and strong-invisibility evidence.'
        truth-discipline='Visibility, holonomy, KL, weak-field metric, and phase/topology surfaces remain symbolic or deferred; bounded gates/ratios use supplied finite evidence and do not prove physical disappearance or authorize actions.'
      ]
      [ law-id='qpc-ecology-testable-falsifiers'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=10.431
        source-end=10.456
        formula-handles=~[(qpc-formula-handle %qpc-no-radiant-channel-falsifier) (qpc-formula-handle %qpc-no-global-attractor-falsifier) (qpc-formula-handle %qpc-no-efficiency-gain-falsifier) (qpc-formula-handle %qpc-no-chi-locking-falsifier) (qpc-formula-handle %qpc-no-convergence-falsifier) (qpc-formula-handle %qpc-no-glyph-falsifier) (qpc-formula-handle %qpc-no-fracture-reforge-falsifier) (qpc-formula-handle %qpc-no-radiation-falsifier)]
        transition-kinds=~[%filter %fracture %defer]
        summary='Original QPC ecology corollaries are represented as explicit negative-test/falsifier handles for radiant channel, attractor, efficiency, chi-locking, convergence, glyph, fracture/reforge, and radiation claims.'
        truth-discipline='Falsifier handles carry negative evidence into residue; they do not decide all QPC truth or authorize action.'
      ]
      [ law-id='qpc-ecology-ablation-identifiability'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=10.456
        source-end=10.535
        formula-handles=~[(qpc-formula-handle %qpc-ecology-potential) (qpc-formula-handle %radiant-semantic-channel-coupling) (qpc-formula-handle %adler-lock-condition-chi) (qpc-formula-handle %kuramoto-threshold-chi) (qpc-formula-handle %ecology-tipping-lambda) (qpc-formula-handle %qpc-no-radiant-channel-falsifier) (qpc-formula-handle %qpc-no-chi-locking-falsifier) (qpc-formula-handle %qpc-no-convergence-falsifier)]
        transition-kinds=~[%filter %fracture %defer]
        summary='Original QPC ablation and identifiability protocol is represented through existing ecology/channel/falsifier handles: semantic masking, permutation nulls, architecture mismatch, channel drops, drive sweeps, and pass/fail criteria.'
        truth-discipline='Ablation criteria constrain source-backed evidence vocabulary only; no semantic-masker, graph null runner, or drive-sweep evaluator is implemented.'
      ]
      [ law-id='qpc-ecology-order-magnitude-examples'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=10.535
        source-end=10.557
        formula-handles=~[(qpc-formula-handle %adler-lock-condition-chi) (qpc-formula-handle %kuramoto-threshold-chi) (qpc-formula-handle %ecology-tipping-lambda) (qpc-formula-handle %qpc-no-chi-locking-falsifier)]
        transition-kinds=~[%filter %defer]
        summary='Original QPC order-of-magnitude examples are represented through existing chi-locking and ecology handles for lock bandwidth and threshold-shift vocabulary.'
        truth-discipline='Examples are explanatory estimates only; no Landau-Ginzburg solver or empirical threshold authority is implemented.'
      ]
      [ law-id='qpc-glyph-detector-operational'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=10.558
        source-end=10.590
        formula-handles=~[(qpc-formula-handle %attractor-inscription-glyph) (qpc-formula-handle %phase-seal-holonomy) (qpc-formula-handle %qpc-no-glyph-falsifier)]
        transition-kinds=~[%observe %filter %defer]
        summary='Original QPC glyph detector is represented as operational vocabulary over phase winding, persistent topological features, flux reversal, and gap opening.'
        truth-discipline='No phase unwrapping, persistent homology, flux integral, or Hessian-gap evaluator is implemented.'
      ]
      [ law-id='ct-macro-attractor-filter'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=7.332
        source-end=7.347
        formula-handles=~[(qpc-formula-handle %ct-coherent-integration-index) (qpc-formula-handle %ct-integration-bottleneck-gate) (qpc-formula-handle %ct-deff-gates) (qpc-formula-handle %ct-capacity-scaling) (qpc-formula-handle %ct-rk-resonance) (qpc-formula-handle %ct-ecology-potential) (qpc-formula-handle %ct-effective-control-lambda)]
        transition-kinds=~[%filter %converge %defer]
        summary='CT dimensional-deepening/extinction macro-attractors are typed but non-authoritative.'
        truth-discipline='Macro-attractor language cannot authorize Qwen actions or state changes.'
      ]
      [ law-id='ct-safe-crossing-control-surface'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=7.279
        source-end=7.313
        formula-handles=~[(qpc-formula-handle %ct-safe-crossing-window) (qpc-formula-handle %ct-safe-crossing-window-gate) (qpc-formula-handle %ct-excessive-strain-rate-gate) (qpc-formula-handle %ct-fracture-strain-window-gate) (qpc-formula-handle %ct-spectral-gap-lambda2) (qpc-formula-handle %ct-effective-control-lambda)]
        transition-kinds=~[%filter %fracture %reforge %defer]
        summary='Safe-crossing protocol surfaces strain, bottleneck coherence, resonance, spectral gap, and recovery as deferred controls.'
        truth-discipline='This is not an Earthside controller and does not authorize autonomous state mutation.'
      ]
      [ law-id='qpc-null-falsification-discipline'
        source=%qpc-original
        local-path='papers/qpc/quantum-patterned-cosmos.txt'
        source-start=668
        source-end=928
        formula-handles=~[(qpc-formula-handle %observable-residual) (qpc-formula-handle %epsilon-band) (qpc-formula-handle %a-attn-qpc)]
        transition-kinds=~[%filter %fracture %defer]
        summary='QPC source requires sustained nulls, residual bands, and source-backed estimators before claims can survive as bridge laws.'
        truth-discipline='A failed validation protocol collapses that bridge claim only; it does not prove or disprove QPC-as-physics globally.'
      ]
      [ law-id='ct-null-control-discipline'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=7.678
        source-end=7.835
        formula-handles=~[(qpc-formula-handle %ct-live-percentile) (qpc-formula-handle %ct-lambda-plateau) (qpc-formula-handle %ct-octave-persistence)]
        transition-kinds=~[%filter %fracture %defer]
        summary='CT protocols must preregister metrics, effect directions, primary tests, nulls, sample sizes, and stopping rules.'
        truth-discipline='Null-control discipline is validation metadata, not runtime authority.'
      ]
      [ law-id='ct-weak-program-falsifiers'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=9.059
        source-end=9.382
        formula-handles=~[(qpc-formula-handle %ct-rk-resonance) (qpc-formula-handle %ct-spectral-gap-lambda2) (qpc-formula-handle %ct-effective-control-lambda)]
        transition-kinds=~[%filter %fracture %defer]
        summary='CT weak-program bridge laws require binary pass/fail outcomes, holdouts, multi-null controls, and fail-closed interpretation.'
        truth-discipline='Any single fail collapses the bridge-law claim while leaving typed QPC control vocabulary available for constrained LLM use.'
      ]
      [ law-id='ct-qualia-coordinate-identity-map'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=329
        source-end=350
        formula-handles=~[(qpc-formula-handle %ct-q-coordinate) (qpc-formula-handle %ct-q-a-bar) (qpc-formula-handle %ct-q-geometry-g) (qpc-formula-handle %ct-q-rhythm-r) (qpc-formula-handle %ct-q-valence-j) (qpc-formula-handle %ct-q-aboutness-m)]
        transition-kinds=~[%observe %filter %defer]
        summary='CT Q-coordinate tuple is represented as descriptive substrate ontology over A_bar, G, R, J, and M.'
        truth-discipline='The identity thesis remains speculative/deferred; typed Q-coordinates do not prove phenomenality or grant authority.'
      ]
      [ law-id='ct-dynamics-maxcal-minimal-balance'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=359
        source-end=489
        formula-handles=~[(qpc-formula-handle %ct-maxcal-constraint) (qpc-formula-handle %ct-maxcal-weight) (qpc-formula-handle %ct-lambda-context) (qpc-formula-handle %ct-minimal-interaction-lint) (qpc-formula-handle %ct-balance-current)]
        transition-kinds=~[%weight %filter %defer]
        summary='CT dynamics names MaxCal path-ensemble deformation, context strength, minimal interactions, and balance-current accounting.'
        truth-discipline='These laws stay deferred unless a bounded path-ensemble/interactions evaluator exists; they cannot authorize state changes.'
      ]
      [ law-id='ct-bridge-locality-symmetry-rg'
        source=%ct-companion
        local-path='papers/qpc/quantum-patterned-cosmos-ct-edition.txt'
        source-start=375
        source-end=436
        formula-handles=~[(qpc-formula-handle %ct-locality-nonsignalling-guard) (qpc-formula-handle %ct-a-lambda-orthogonalization) (qpc-formula-handle %ct-interaction-symmetry-constraints) (qpc-formula-handle %ct-rg-rank2-contraction)]
        transition-kinds=~[%filter %fracture %defer]
        summary='CT bridge constraints retain locality/non-signalling, A/lambda separability, allowed-coupling symmetry, and rank-2 RG contraction as typed deferred laws.'
        truth-discipline='These handles reject overclaims and invalid bridge moves; they do not prove CT physics or authorize state changes.'
      ]
  ==
::
++  qpc-world-empty-residue
  |=  terrain=qpc-terrain:qpc-sur
  ^-  qpc-world-residue:qpc-sur
  [ turn=0
    observations=~
    fractures=~
    reforge-plans=~
    admissible-formula-handles=allowed-formula-handles.terrain
    blocked-formula-handles=~
    notes=~['QPC world residue starts with every terrain handle admissible; later receipts may narrow or restore this set.']
  ]
::
++  qpc-world-initial-state
  ^-  qpc-world-state:qpc-sur
  =/  terrain=qpc-terrain:qpc-sur  qpc-terrain
  [ version='qpc-world-kernel-v1'
    turn=0
    terrain=terrain
    source-anchors=qpc-world-source-anchors
    fields=(turn qpc-all-formula-contracts qpc-field-ref-from-contract)
    symbolic-fields=(qpc-symbolic-fields-from-contracts qpc-all-formula-contracts)
    finite-approximations=(qpc-finite-approximations-from-contracts qpc-all-formula-contracts)
    symbolic-laws=(qpc-symbolic-laws-from-contracts qpc-all-formula-contracts)
    deferred-laws=(qpc-deferred-laws-from-contracts qpc-all-formula-contracts)
    observers=~[qpc-world-default-observer]
    observations=~
    trajectories=~
    thresholds=qpc-world-default-thresholds
    attractors=qpc-world-default-attractors
    convergence-states=qpc-world-default-convergence-states
    qualia-coordinates=qpc-world-default-qualia-coordinates
    validation-protocols=qpc-world-default-validation-protocols
    null-controls=qpc-world-default-null-controls
    protocol-verdicts=~
    residue=(qpc-world-empty-residue terrain)
    authority-note='QPC world state is passive formal law and control vocabulary; Cantrip remains the authority gate for model action and state changes.'
    truth-note='Executable QPC here means source-backed formal calculus and bounded evaluators, not validated physical truth about the universe.'
  ]
::
++  qpc-world-refresh-source-surfaces
  |=  state=qpc-world-state:qpc-sur
  ^-  qpc-world-state:qpc-sur
  =/  fresh=qpc-world-state:qpc-sur  qpc-world-initial-state
  =/  current=qpc-world-residue:qpc-sur  residue.state
  =/  refresh-note=@t
    'siev kernel refresh: source-owned QPC formula/protocol surfaces reconciled without granting action authority'
  =/  refreshed-admissible=(list @t)
    (qpc-text-remove-blocked allowed-formula-handles.terrain.fresh blocked-formula-handles.current)
  =/  refreshed-residue=qpc-world-residue:qpc-sur
    current(admissible-formula-handles refreshed-admissible, notes (qpc-text-add-unique refresh-note notes.current))
  %=  state
    terrain  terrain.fresh
    source-anchors  source-anchors.fresh
    fields  fields.fresh
    symbolic-fields  symbolic-fields.fresh
    finite-approximations  finite-approximations.fresh
    symbolic-laws  symbolic-laws.fresh
    deferred-laws  deferred-laws.fresh
    observers  observers.fresh
    thresholds  thresholds.fresh
    attractors  attractors.fresh
    convergence-states  convergence-states.fresh
    qualia-coordinates  qualia-coordinates.fresh
    validation-protocols  validation-protocols.fresh
    null-controls  null-controls.fresh
    authority-note  authority-note.fresh
    truth-note  truth-note.fresh
    residue  refreshed-residue
  ==
::
++  qpc-protocol-verdict-for
  |=  [protocol=qpc-validation-protocol:qpc-sur evidence=qpc-protocol-evidence:qpc-sur]
  ^-  qpc-protocol-verdict:qpc-sur
  =/  verdict=qpc-protocol-verdict-kind:qpc-sur
    ?:  treats-proxy-as-truth.evidence
      %fail
    ?:  ?&(metric-cleared.evidence nulls-cleared.evidence holdout-cleared.evidence)
      %pass
    ?:  ?|(!metric-cleared.evidence !nulls-cleared.evidence)
      %fail
    ?:  !holdout-cleared.evidence
      %inconclusive
    %deferred
  [ protocol-id=protocol-id.protocol
    verdict=verdict
    accepted=?=(%pass verdict)
    nulls-cleared=nulls-cleared.evidence
    holdout-cleared=holdout-cleared.evidence
    formula-handles=formula-handles.protocol
    source-refs=(weld source-refs.protocol source-refs.evidence)
    notes=?:(?=(%pass verdict) 'protocol passed bounded formal/null/holdout gates; this is not physical validation or authority' 'protocol did not pass all formal/null/holdout gates; bridge-law claim remains failed, inconclusive, or deferred')
  ]
::
++  qpc-protocol-evidence-from-bounds
  |=  $:  protocol-id=@t
          metric-score=@ud
          metric-threshold=@ud
          null-signal=@ud
          null-maximum=@ud
          holdout-score=@ud
          holdout-threshold=@ud
          treats-proxy-as-truth=?
          source-refs=(list @t)
          notes=@t
      ==
  ^-  qpc-protocol-evidence:qpc-sur
  [ protocol-id=protocol-id
    metric-cleared=(gte metric-score metric-threshold)
    nulls-cleared=!(gth null-signal null-maximum)
    holdout-cleared=(gte holdout-score holdout-threshold)
    requested-execution=%.n
    treats-proxy-as-truth=treats-proxy-as-truth
    source-refs=source-refs
    notes=notes
  ]
::
++  qpc-world-fracture-from-protocol-verdict
  |=  protocol-verdict=qpc-protocol-verdict:qpc-sur
  ^-  (unit qpc-fracture:qpc-sur)
  ?:  ?=(%fail verdict.protocol-verdict)
    `[ fracture-id=(cat 3 'qpc-world-protocol-fracture:' protocol-id.protocol-verdict)
       code=%fail-closed
       formula-handle=~
       source-refs=source-refs.protocol-verdict
       can-reforge=%.y
       summary='QPC validation fracture: failed protocol collapses only its bridge-law claim; QPC control vocabulary and Cantrip authority remain separate.'
     ]
  ~
::
++  qpc-world-apply-protocol-verdict
  |=  [state=qpc-world-state:qpc-sur verdict=qpc-protocol-verdict:qpc-sur]
  ^-  qpc-world-state:qpc-sur
  =/  current=qpc-world-residue:qpc-sur  residue.state
  =/  protocol-fracture=(unit qpc-fracture:qpc-sur)
    (qpc-world-fracture-from-protocol-verdict verdict)
  =/  fractures=(list qpc-fracture:qpc-sur)
    ?~  protocol-fracture
      fractures.current
    [u.protocol-fracture fractures.current]
  =/  next-residue=qpc-world-residue:qpc-sur
    current(fractures fractures, notes [notes.verdict notes.current])
  state(protocol-verdicts [verdict protocol-verdicts.state], residue next-residue)
::
++  qpc-admissible-candidate-count
  |=  candidates=(list qpc-collapse-candidate:qpc-sur)
  ^-  @ud
  ?~  candidates
    0
  =/  candidate=qpc-collapse-candidate:qpc-sur  i.candidates
  =/  alive=?  ?&(admissible.candidate (gth score.candidate 0))
  ?:  alive
    +($(candidates t.candidates))
  $(candidates t.candidates)
::
++  qpc-collapse-candidate-to-branch
  |=  candidate=qpc-collapse-candidate:qpc-sur
  ^-  qpc-branch:qpc-sur
  [ branch-id=branch-id.candidate
    formula-handle=formula-handle.candidate
    score=score.candidate
    admissible=admissible.candidate
    source-refs=source-refs.candidate
    summary=reason.candidate
  ]
::
++  qpc-world-best-candidate
  |=  candidates=(list qpc-collapse-candidate:qpc-sur)
  ^-  (unit qpc-collapse-candidate:qpc-sur)
  =/  best=(unit qpc-collapse-candidate:qpc-sur)  ~
  |-  ^-  (unit qpc-collapse-candidate:qpc-sur)
  ?~  candidates
    best
  =/  candidate=qpc-collapse-candidate:qpc-sur  i.candidates
  =/  alive=?  ?&(admissible.candidate (gth score.candidate 0))
  =/  next=(unit qpc-collapse-candidate:qpc-sur)
    ?:  !alive
      best
    ?~  best
      `candidate
    ?:  (gth score.candidate score.u.best)
      `candidate
    best
  $(candidates t.candidates, best next)
::
++  qpc-world-trajectory-from-proposal
  |=  proposal=qpc-transition-proposal:qpc-sur
  ^-  (unit qpc-trajectory:qpc-sur)
  (qpc-world-trajectory-from-proposal-in qpc-all-formula-contracts proposal)
::  the same, over a caller-supplied contract list (a %siev book's)
++  qpc-world-trajectory-from-proposal-in
  |=  [contracts=(list qpc-formula-contract:qpc-sur) proposal=qpc-transition-proposal:qpc-sur]
  ^-  (unit qpc-trajectory:qpc-sur)
  =/  contract=(unit qpc-formula-contract:qpc-sur)  (qpc-contract-by-handle-in contracts formula-handle.proposal)
  ?~  contract
    ~
  =/  winner=(unit qpc-collapse-candidate:qpc-sur)  (qpc-world-best-candidate candidates.proposal)
  ?~  winner
    ~
  =/  field=qpc-field-ref:qpc-sur  (qpc-field-ref-from-contract u.contract)
  `[ trajectory-id=(cat 3 'qpc-world-trajectory:' proposal-id.proposal)
     field=field
     branches=(turn candidates.proposal qpc-collapse-candidate-to-branch)
     selected=`branch-id.u.winner
     source-refs=source-refs.u.winner
     notes=(cat 3 'QPC world collapse selected branch ' branch-id.u.winner)
   ]
::
++  qpc-world-rejection-reason
  |=  code=qpc-world-rejection-code:qpc-sur
  ^-  @t
  ?-  code
    %none                      'accepted by QPC world kernel'
    %formula-unbound           'rejected: formula handle is not present in the source-backed QPC terrain'
    %formula-not-admissible    'rejected: formula handle is known but blocked by current QPC world residue'
    %source-unbound            'rejected: formula has no source/provenance refs'
    %invented-physics          'rejected: proposal attempts to invent QPC physics'
    %raw-corpus-claim          'rejected: proposal attempts to move raw corpus text through the live world kernel'
    %authority-claim           'rejected: proposal claims authority outside QPC/Cantrip bounds'
    %symbolic-not-executable   'rejected: symbolic QPC formula is retained as typed law, not executed'
    %deferred-not-executable   'rejected: deferred QPC formula has no bounded evaluator in this kernel'
    %proxy-required            'rejected: proxy-evaluate requires an explicitly marked QPC proxy surface'
    %invalid-finite-approximation  'rejected: finite approximation metadata is missing or invalid'
    %no-admissible-collapse    'rejected: collapse transition has no admissible candidate branch'
    %fail-closed               'rejected: QPC world kernel fail-closed'
  ==
::
++  qpc-world-transition-verdict-for
  |=  [state=qpc-world-state:qpc-sur proposal=qpc-transition-proposal:qpc-sur]
  ^-  qpc-transition-verdict:qpc-sur
  (qpc-world-transition-verdict-for-in qpc-all-formula-contracts state proposal)
::  the same, over a caller-supplied contract list (a %siev book's)
++  qpc-world-transition-verdict-for-in
  |=  [contracts=(list qpc-formula-contract:qpc-sur) state=qpc-world-state:qpc-sur proposal=qpc-transition-proposal:qpc-sur]
  ^-  qpc-transition-verdict:qpc-sur
  =/  terrain=qpc-terrain:qpc-sur  terrain.state
  =/  active=(list @t)  admissible-formula-handles.residue.state
  =/  contract=(unit qpc-formula-contract:qpc-sur)  (qpc-contract-by-handle-in contracts formula-handle.proposal)
  ?~  contract
    [ proposal-id=proposal-id.proposal
      kind=kind.proposal
      accepted=%.n
      formula-handle=formula-handle.proposal
      formula=~
      formula-class=~
      rejection-code=%formula-unbound
      source-refs=~
      safety-notes=qpc-default-safety-notes
      reason=(qpc-world-rejection-reason %formula-unbound)
    ]
  =/  contract-bound=?  (qpc-text-member formula-handle.proposal allowed-formula-handles.terrain)
  =/  active-bound=?  (qpc-text-member formula-handle.proposal active)
  =/  class=qpc-world-formula-class:qpc-sur  (qpc-formula-class-from-contract u.contract)
  =/  source-bound=?  !=(0 (lent provenance.u.contract))
  =/  collapse-candidates=@ud  (qpc-admissible-candidate-count candidates.proposal)
  =/  code=qpc-world-rejection-code:qpc-sur
    ?:  !contract-bound
      %formula-unbound
    ?:  ?&(!active-bound !?=(%reforge kind.proposal))
      %formula-not-admissible
    ?:  !source-bound
      %source-unbound
    ?:  claims-raw-corpus.proposal
      %raw-corpus-claim
    ?:  claims-authority.proposal
      %authority-claim
    ?:  invented-physics.proposal
      %invented-physics
    ?:  ?&(?=(%proxy-evaluate kind.proposal) !?=(%proxy class))
      %proxy-required
    ?:  ?=(%defer kind.proposal)
      %none
    ?:  ?&(requested-execution.proposal ?=(%symbolic class))
      %symbolic-not-executable
    ?:  ?&(requested-execution.proposal ?=(%deferred class))
      %deferred-not-executable
    ?:  ?&(?=(%collapse kind.proposal) =(0 collapse-candidates))
      %no-admissible-collapse
    %none
  [ proposal-id=proposal-id.proposal
    kind=kind.proposal
    accepted=?=(%none code)
    formula-handle=formula-handle.proposal
    formula=`id.u.contract
    formula-class=`class
    rejection-code=code
    source-refs=provenance.u.contract
    safety-notes=qpc-default-safety-notes
    reason=(qpc-world-rejection-reason code)
  ]
::
++  qpc-world-observation-from-output
  |=  output=qpc-evaluator-output:qpc-sur
  ^-  qpc-observation:qpc-sur
  (qpc-world-observation-from-output-in qpc-all-formula-contracts output)
::  the same, over a caller-supplied contract list (a %siev book's)
++  qpc-world-observation-from-output-in
  |=  [contracts=(list qpc-formula-contract:qpc-sur) output=qpc-evaluator-output:qpc-sur]
  ^-  qpc-observation:qpc-sur
  =/  class=(unit qpc-world-formula-class:qpc-sur)
    (qpc-world-formula-class-for-handle-in contracts formula-handle.output)
  =/  resolved-class=qpc-world-formula-class:qpc-sur
    ?~  class  %symbolic  u.class
  =/  refs=(list @t)  (qpc-world-source-refs-for-handle-in contracts formula-handle.output)
  ::  the observation records the contract's source (a %siev book's, when
  ::  amended), not the evaluator's stamp; the lib's list gives the lib's
  =/  contract=(unit qpc-formula-contract:qpc-sur)
    (qpc-contract-by-handle-in contracts formula-handle.output)
  =/  source=qpc-source:qpc-sur  ?~(contract source.output source.u.contract)
  =/  observer=qpc-observer:qpc-sur
    [ observer-id='qpc-world-observer:bounded-evaluator'
      attention-value=coherence-score.output
      attention-scale=scale.output
      attention-formula-handle=formula-handle.output
      source=source
      source-refs=refs
      safety-notes=safety-notes.output
      notes='Bounded evaluator output mapped into QPC observer/observation facts; this is not model authority.'
    ]
  [ observation-id=(cat 3 'qpc-world-observation:' formula-handle.output)
    observer=observer
    formula-handle=formula-handle.output
    formula=formula.output
    source=source
    formula-class=resolved-class
    evaluator-status=evaluator-status.output
    accepted=(qpc-evaluator-output-accepted output)
    value=coherence-score.output
    scale=scale.output
    exact=exact.output
    source-refs=refs
    notes=notes.output
  ]
::
++  qpc-world-fracture-from-verdict
  |=  verdict=qpc-transition-verdict:qpc-sur
  ^-  (unit qpc-fracture:qpc-sur)
  ?:  ?|(?=(%fracture kind.verdict) !?=(%none rejection-code.verdict))
    `[ fracture-id=(cat 3 'qpc-world-fracture:' proposal-id.verdict)
       code=rejection-code.verdict
       formula-handle=`formula-handle.verdict
       source-refs=source-refs.verdict
       can-reforge=%.y
       summary=(cat 3 'QPC world fracture/residue: ' reason.verdict)
     ]
  ~
::
++  qpc-world-reforge-plan-from-verdict
  |=  verdict=qpc-transition-verdict:qpc-sur
  ^-  (unit qpc-reforge-plan:qpc-sur)
  ?:  ?|(?=(%reforge kind.verdict) !?=(%none rejection-code.verdict))
    `[ plan-id=(cat 3 'qpc-world-reforge:' proposal-id.verdict)
       formula-handle=`formula-handle.verdict
       retry-policy=?:(?=(%reforge kind.verdict) %retry-then-ground %retry-once-grounding)
       clamp-target=%grounding
       changed-admissible-space=?:(?=(%reforge kind.verdict) %.y %.n)
       source-refs=source-refs.verdict
       summary='QPC world reforge plan: route fracture/residue into a narrowed or restored admissible formula space; Cantrip must still validate any state-changing move.'
     ]
  ~
::
++  qpc-world-residue-for
  |=  $:  state=qpc-world-state:qpc-sur
          verdict=qpc-transition-verdict:qpc-sur
          observation=(unit qpc-observation:qpc-sur)
          fracture=(unit qpc-fracture:qpc-sur)
          reforge=(unit qpc-reforge-plan:qpc-sur)
      ==
  ^-  qpc-world-residue:qpc-sur
  =/  current=qpc-world-residue:qpc-sur  residue.state
  =/  observations=(list qpc-observation:qpc-sur)
    ?~  observation  observations.current  [u.observation observations.current]
  =/  fractures=(list qpc-fracture:qpc-sur)
    ?~  fracture  fractures.current  [u.fracture fractures.current]
  =/  reforges=(list qpc-reforge-plan:qpc-sur)
    ?~  reforge  reforge-plans.current  [u.reforge reforge-plans.current]
  =/  admissible=(list @t)
    ?:  accepted.verdict
      ?:  ?=(%reforge kind.verdict)
        allowed-formula-handles.terrain.state
      admissible-formula-handles.current
    (qpc-text-remove formula-handle.verdict admissible-formula-handles.current)
  =/  blocked=(list @t)
    ?:  accepted.verdict
      ?:  ?=(%reforge kind.verdict)
        ~
      blocked-formula-handles.current
    (qpc-text-add-unique formula-handle.verdict blocked-formula-handles.current)
  [ turn=+(turn.state)
    observations=observations
    fractures=fractures
    reforge-plans=reforges
    admissible-formula-handles=admissible
    blocked-formula-handles=blocked
    notes=[reason.verdict notes.current]
  ]
::
++  qpc-world-receipt-for
  |=  [state=qpc-world-state:qpc-sur proposal=qpc-transition-proposal:qpc-sur output=(unit qpc-evaluator-output:qpc-sur)]
  ^-  qpc-world-receipt:qpc-sur
  (qpc-world-receipt-for-in qpc-all-formula-contracts state proposal output)
::  the same, over a caller-supplied contract list (a %siev book's)
++  qpc-world-receipt-for-in
  |=  [contracts=(list qpc-formula-contract:qpc-sur) state=qpc-world-state:qpc-sur proposal=qpc-transition-proposal:qpc-sur output=(unit qpc-evaluator-output:qpc-sur)]
  ^-  qpc-world-receipt:qpc-sur
  =/  verdict=qpc-transition-verdict:qpc-sur  (qpc-world-transition-verdict-for-in contracts state proposal)
  =/  observation=(unit qpc-observation:qpc-sur)
    ?:  accepted.verdict
      ?~  output  ~  `(qpc-world-observation-from-output-in contracts u.output)
    ~
  =/  trajectory=(unit qpc-trajectory:qpc-sur)
    ?:  ?&(accepted.verdict ?=(%collapse kind.verdict))
      (qpc-world-trajectory-from-proposal-in contracts proposal)
    ~
  =/  fracture=(unit qpc-fracture:qpc-sur)  (qpc-world-fracture-from-verdict verdict)
  =/  reforge=(unit qpc-reforge-plan:qpc-sur)  (qpc-world-reforge-plan-from-verdict verdict)
  =/  residue=qpc-world-residue:qpc-sur  (qpc-world-residue-for state verdict observation fracture reforge)
  [ version='qpc-world-receipt-v1'
    proposal-id=proposal-id.proposal
    accepted=accepted.verdict
    before-turn=turn.state
    after-turn=+(turn.state)
    verdict=verdict
    observation=observation
    trajectory=trajectory
    fracture=fracture
    reforge-plan=reforge
    residue=residue
    next-summary=(cat 3 'QPC world next-state: ' reason.verdict)
  ]
::
++  qpc-world-apply-receipt
  |=  [state=qpc-world-state:qpc-sur receipt=qpc-world-receipt:qpc-sur]
  ^-  qpc-world-state:qpc-sur
  =/  maybe-observation=(unit qpc-observation:qpc-sur)  observation.receipt
  =/  new-observations=(list qpc-observation:qpc-sur)
    ?~  maybe-observation  observations.state  [u.maybe-observation observations.state]
  =/  maybe-trajectory=(unit qpc-trajectory:qpc-sur)  trajectory.receipt
  =/  new-trajectories=(list qpc-trajectory:qpc-sur)
    ?~  maybe-trajectory  trajectories.state  [u.maybe-trajectory trajectories.state]
  state(turn after-turn.receipt, observations new-observations, trajectories new-trajectories, residue residue.receipt)
::
++  qpc-world-qwen-unbound-binding
  ^-  qpc-qwen-world-binding:qpc-sur
  [ version='qpc-world-qwen-binding-v1'
    world-bound=%.n
    active-formula-count=0
    residue-fracture-count=0
    rule-addendum='No QPC world binding is present; Qwen receives no world-state formula space from this kernel.'
    output-contract-note='Qwen output contract: no QPC world handles are active.'
    verifier-visible-summary='qpc-world-bound=false active-formulas=0 fractures=0 blocked=0 turn=0'
  ]
::
++  qpc-world-qwen-binding-view
  |=  state=qpc-world-state:qpc-sur
  ^-  qpc-qwen-world-binding:qpc-sur
  =/  active=@ud  (lent admissible-formula-handles.residue.state)
  =/  fractures=@ud  (lent fractures.residue.state)
  =/  blocked=@ud  (lent blocked-formula-handles.residue.state)
  =/  active-text=@t  (scot %ud active)
  =/  fracture-text=@t  (scot %ud fractures)
  =/  blocked-text=@t  (scot %ud blocked)
  =/  turn-text=@t  (scot %ud turn.residue.state)
  =/  summary-a=@t
    (cat 3 'qpc-world-bound=true active-formulas=' active-text)
  =/  summary-b=@t
    (cat 3 summary-a (cat 3 ' fractures=' fracture-text))
  =/  summary-c=@t
    (cat 3 summary-b (cat 3 ' blocked=' blocked-text))
  =/  summary=@t
    (cat 3 summary-c (cat 3 ' turn=' turn-text))
  [ version='qpc-world-qwen-binding-v1'
    world-bound=%.y
    active-formula-count=active
    residue-fracture-count=fractures
    rule-addendum='QPC world binding: Qwen may render one legal move using active world formula handles only; residue changes the visible formula space and never grants authority.'
    output-contract-note=(cat 3 'Qwen output contract includes bounded QPC world state: ' summary)
    verifier-visible-summary=summary
  ]
::
++  qpc-control-band-from-scaled
  |=  [value=@ud scale=@ud]
  ^-  qpc-control-band:qpc-sur
  =/  top=@ud  (nonzero scale)
  =/  tripled=@ud  (mul value 3)
  ?:  (gte tripled (mul top 2))
    %high
  ?:  (gte tripled top)
    %medium
  %low
::
++  qpc-evaluator-output-accepted
  |=  output=qpc-evaluator-output:qpc-sur
  ^-  ?
  ?.  ?|  ?=(%blocked evaluator-status.output)
          ?=(%retired evaluator-status.output)
          ?=(%stale evaluator-status.output)
      ==
    %.y
  %.n
::
++  qpc-control-retry-policy-for
  |=  $:  status=qpc-evaluator-status:qpc-sur
          zeno=qpc-control-band:qpc-sur
          theta=qpc-control-band:qpc-sur
          kappa=qpc-control-band:qpc-sur
      ==
  ^-  qpc-control-retry-policy:qpc-sur
  ?:  ?|(?=(%blocked status) ?=(%retired status))
    %reject-only
  ?:  ?|(?=(%stale status) ?=(%high zeno) ?=(%high theta) ?=(%low kappa))
    %retry-once-grounding
  %retry-then-ground
::
++  qpc-control-clamp-target-for
  |=  $:  status=qpc-evaluator-status:qpc-sur
          coherence=qpc-control-band:qpc-sur
          zeno=qpc-control-band:qpc-sur
          kappa=qpc-control-band:qpc-sur
      ==
  ^-  qpc-control-clamp-target:qpc-sur
  ?:  ?|(?=(%blocked status) ?=(%retired status) ?=(%stale status))
    %grounding
  ?:  ?|(?=(%high zeno) ?=(%low kappa))
    %grounding
  ?:  ?&(?=(%high coherence) ?=(%high kappa) ?=(%low zeno))
    %vectoring
  ?:  ?|(?=(%medium coherence) ?=(%high coherence))
    %opening
  %grounding
::
++  qpc-waterwheel-control-summary
  |=  control=qpc-waterwheel-control:qpc-sur
  ^-  @t
  =/  handle=@t  formula-handle.control
  =/  coherence=@t  (scot %tas coherence-density.control)
  =/  theta=@t  (scot %tas theta-phase.control)
  =/  zeno=@t  (scot %tas zeno-pressure.control)
  =/  kappa=@t  (scot %tas kappa-floor.control)
  =/  retry=@t  (scot %tas retry-policy.control)
  =/  clamp=@t  (scot %tas clamp-target.control)
  =/  a=@t  (cat 3 'QPC Waterwheel control: handle=' handle)
  =/  b=@t  (cat 3 a ', coherence-density=')
  =/  c=@t  (cat 3 b coherence)
  =/  d=@t  (cat 3 c ', theta-phase=')
  =/  e=@t  (cat 3 d theta)
  =/  f=@t  (cat 3 e ', zeno-pressure=')
  =/  g=@t  (cat 3 f zeno)
  =/  h=@t  (cat 3 g ', kappa-floor=')
  =/  i=@t  (cat 3 h kappa)
  =/  j=@t  (cat 3 i ', retry-policy=')
  =/  k=@t  (cat 3 j retry)
  =/  l=@t  (cat 3 k ', clamp-target=')
  (cat 3 l clamp)
::
++  qpc-waterwheel-control-from-output
  |=  output=qpc-evaluator-output:qpc-sur
  ^-  qpc-waterwheel-control:qpc-sur
  =/  coherence=qpc-control-band:qpc-sur
    (qpc-control-band-from-scaled coherence-score.output scale.output)
  =/  theta=qpc-control-band:qpc-sur
    (qpc-control-band-from-scaled theta-score.output scale.output)
  =/  zeno=qpc-control-band:qpc-sur
    (qpc-control-band-from-scaled zeno-score.output scale.output)
  =/  kappa=qpc-control-band:qpc-sur
    (qpc-control-band-from-scaled kappa-score.output scale.output)
  =/  retry=qpc-control-retry-policy:qpc-sur
    (qpc-control-retry-policy-for evaluator-status.output zeno theta kappa)
  =/  clamp=qpc-control-clamp-target:qpc-sur
    (qpc-control-clamp-target-for evaluator-status.output coherence zeno kappa)
  =/  accepted=?  (qpc-evaluator-output-accepted output)
  =/  draft=qpc-waterwheel-control:qpc-sur
    [ version='qpc-waterwheel-control-v1'
      formula-handle=formula-handle.output
      formula=formula.output
      source=source.output
      coherence-density=coherence
      theta-phase=theta
      zeno-pressure=zeno
      kappa-floor=kappa
      retry-policy=retry
      clamp-target=clamp
      accepted=accepted
      safety-summary='QPC output is a bounded evaluator/control hint only; Cantrip remains the authority for legal moves and state changes.'
      control-summary='pending'
    ]
  draft(control-summary (qpc-waterwheel-control-summary draft))
::
++  qpc-evaluator-output
  |=  $:  handle=@t
          formula=qpc-formula-id:qpc-sur
          source=qpc-source:qpc-sur
          status=qpc-evaluator-status:qpc-sur
          coherence=@ud
          theta=@ud
          zeno=@ud
          kappa=@ud
          exact=?
          notes=@t
      ==
  ^-  qpc-evaluator-output:qpc-sur
  [ formula-handle=handle
    formula=formula
    source=source
    evaluator-status=status
    coherence-score=(cap-scale coherence)
    theta-score=(cap-scale theta)
    zeno-score=(cap-scale zeno)
    kappa-score=(cap-scale kappa)
    scale=qpc-scale
    exact=exact
    safety-notes=qpc-default-safety-notes
    notes=notes
  ]
::
++  qpc-attention-scaled
  |=  [tensor-square=@ud c-max=@ud]
  ^-  qpc-attention-reading:qpc-sur
  =/  raw=@ud
    ?:  =(0 c-max)
      0
    (div (mul tensor-square qpc-scale) c-max)
  [ value=(cap-scale raw)
    scale=qpc-scale
    source=(formula-source %a-attn-qpc)
    formula=%a-attn-qpc
    exact=&
    notes='A = Tr(C*C)/Cmax, capped to [0,1] at fixed 1e6 scale.'
  ]
::
++  qpc-baseline-attention-scaled
  |=  [tensor-square=@ud vacuum-square=@ud c-max=@ud]
  ^-  qpc-attention-reading:qpc-sur
  =/  adjusted=@ud  (sub-zero tensor-square vacuum-square)
  =/  raw=@ud
    ?:  =(0 c-max)
      0
    (div (mul adjusted qpc-scale) c-max)
  [ value=(cap-scale raw)
    scale=qpc-scale
    source=(formula-source %a-attn-vac)
    formula=%a-attn-vac
    exact=&
    notes='Vacuum-subtracted A = max(0, Tr(CC)-Tr(Cvac Cvac))/Cmax, capped to [0,1].'
  ]
::
++  ct-baseline-attention-scaled
  |=  [tensor-square=@ud baseline-square=@ud normalizer=@ud]
  ^-  qpc-attention-reading:qpc-sur
  =/  adjusted=@ud  (sub-zero tensor-square baseline-square)
  =/  raw=@ud
    ?:  =(0 normalizer)
      0
    (div (mul adjusted qpc-scale) normalizer)
  [ value=(cap-scale raw)
    scale=qpc-scale
    source=(formula-source %ct-a-baseline)
    formula=%ct-a-baseline
    exact=&
    notes='CT A(x;Lambda) baseline-subtracted trace normalization at fixed 1e6 scale.'
  ]
::
++  ct-attention-scaled
  |=  trace-square=@ud
  ^-  qpc-attention-reading:qpc-sur
  =/  root=@ud  (isqrt trace-square)
  =/  exact-root=?  =(trace-square (mul root root))
  [ value=(cap-scale root)
    scale=qpc-scale
    source=(formula-source %ct-a-scalar)
    formula=%ct-a-scalar
    exact=exact-root
    notes='A = sqrt(tr(C^T C)); integer floor sqrt, capped to [0,1] scale.'
  ]
::
++  ct-covariance-component-scaled
  |=  [mean-product=@ud mean-left=@ud mean-right=@ud]
  ^-  qpc-signed-reading:qpc-sur
  =/  baseline=@ud  (div (mul mean-left mean-right) qpc-scale)
  =/  pos=?  (gte mean-product baseline)
  [ positive=pos
    magnitude=?:(pos (sub mean-product baseline) (sub baseline mean-product))
    scale=qpc-scale
    formula=%ct-cov-component
    source=(formula-source %ct-cov-component)
    exact=&
    notes='Signed covariance component C_ab = E[z_a z_b] - E[z_a]E[z_b] at fixed 1e6 scale.'
  ]
::
++  ct-tensor4-square-scaled
  |=  [c00=@ud c01=@ud c10=@ud c11=@ud]
  ^-  qpc-scaled-reading:qpc-sur
  =/  square-sum=@ud
    (add (add (mul c00 c00) (mul c01 c01)) (add (mul c10 c10) (mul c11 c11)))
  [ value=(cap-scale (div square-sum qpc-scale))
    scale=qpc-scale
    formula=%ct-tensor4-square
    source=(formula-source %ct-tensor4-square)
    exact=&
    notes='Four-component trace(C*C) slice for bounded tensor summaries; not a full C_munu evaluator.'
  ]
::
++  ct-temporal-shear-scaled
  |=  [current=@ud previous=@ud]
  ^-  qpc-signed-reading:qpc-sur
  =/  pos=?  (gte current previous)
  [ positive=pos
    magnitude=?:(pos (sub current previous) (sub previous current))
    scale=qpc-scale
    formula=%ct-temporal-shear
    source=(formula-source %ct-temporal-shear)
    exact=&
    notes='Finite-difference proxy for T^t_mu_nu ~= d_t C_mu_nu over caller-supplied adjacent samples.'
  ]
::
++  ct-phase-diffusion-variance-ratio
  |=  [diffusion=@ud dwell=@ud]
  ^-  qpc-rational:qpc-sur
  [ numerator=(mul (mul 2 diffusion) dwell)
    denominator=qpc-scale
    scale=qpc-scale
    formula=%ct-phase-diffusion-variance
    source=(formula-source %ct-phase-diffusion-variance)
    exact=&
    note='Var(phi)=2*D0*Delta_tau as a fixed-scale rational for caller-supplied diffusion and dwell time; no Gaussian sampling or visibility exponential is evaluated.'
  ]
::
++  ct-maxcal-visibility-slope-ratio
  |=  [lambda-context=@ud dwell=@ud hbar=@ud attention-bar=@ud]
  ^-  qpc-rational:qpc-sur
  [ numerator=(mul lambda-context (mul dwell attention-bar))
    denominator=(mul (nonzero hbar) qpc-scale)
    scale=qpc-scale
    formula=%ct-maxcal-visibility-slope-ratio
    source=(formula-source %ct-maxcal-visibility-slope-ratio)
    exact=&
    note='Magnitude of ln(V/V0) slope term (lambda_context*Delta_tau/hbar)*A_bar as a fixed-scale rational; sign, log/exp, and fitted visibility statistics remain deferred.'
  ]
::
++  ct-valence-jf-ratio
  |=  [aligned=? contraction=@ud normalizer=@ud]
  ^-  qpc-signed-reading:qpc-sur
  [ positive=aligned
    magnitude=(div (mul contraction qpc-scale) (nonzero normalizer))
    scale=qpc-scale
    formula=%ct-valence-jf-ratio
    source=(formula-source %ct-valence-jf-ratio)
    exact=&
    notes='Finite signed J_F = int C:O d4x / N_O for caller-supplied contraction magnitude and normalizer; alignment supplies the sign, and tensor integration/psychometric mapping remain deferred.'
  ]
::
++  qpc-interiority-indicator
  |=  [rho=@ud threshold=@ud]
  ^-  qpc-gate-reading:qpc-sur
  =/  ok=?  (gte rho threshold)
  [ ok=ok
    value=rho
    threshold=threshold
    margin=?:(ok (sub rho threshold) (sub threshold rho))
    scale=qpc-scale
    formula=%i-phi
    source=(formula-source %i-phi)
    exact=&
    notes='I[phi] = Theta(rho_c - rho_th), represented as pass/fail plus absolute margin.'
  ]
::
++  qpc-threshold-action-ratio
  |=  [n=@ud hbar=@ud]
  ^-  qpc-rational:qpc-sur
  [ numerator=(mul (mul n (nonzero hbar)) qpc-chi-micro)
    denominator=qpc-scale
    scale=qpc-scale
    formula=%threshold-action
    source=(formula-source %threshold-action)
    exact=&
    note='Delta S = n*hbar*chi as a fixed-scale rational.'
  ]
::
++  qpc-euclidean-action-ratio
  ::  Exact rational for A*S_E/(hbar*chi), before applying exp[-...].
  |=  [attention=@ud action-euclidean=@ud hbar=@ud]
  ^-  qpc-rational:qpc-sur
  [ numerator=(mul attention action-euclidean)
    denominator=(mul (nonzero hbar) qpc-chi-micro)
    scale=qpc-scale
    formula=%z-a
    source=(formula-source %z-a)
    exact=&
    note='Euclidean suppressive exponent ratio (papers/qpc/quantum-patterned-cosmos.txt:773); exp is deferred.'
  ]
::
++  qpc-suppression-proxy-scaled
  |=  [numerator=@ud denominator=@ud]
  ^-  qpc-scaled-reading:qpc-sur
  =/  den=@ud  (nonzero denominator)
  =/  total=@ud  (add numerator den)
  [ value=(div (mul den qpc-scale) (nonzero total))
    scale=qpc-scale
    formula=%suppression-proxy
    source=(formula-source %suppression-proxy)
    exact=&
    notes='Monotone rational proxy den/(den+num) for exp(-num/den); not an exponential evaluator.'
  ]
::
++  qpc-partition2-proxy-scaled
  |=  [left=@ud right=@ud]
  ^-  qpc-scaled-reading:qpc-sur
  [ value=(add left right)
    scale=qpc-scale
    formula=%partition2-proxy
    source=(formula-source %partition2-proxy)
    exact=&
    notes='Finite two-branch partition proxy Z2 = w_left + w_right.'
  ]
::
++  qpc-branch-weight-scaled
  |=  [branch=@ud partition=@ud]
  ^-  qpc-scaled-reading:qpc-sur
  [ value=(div (mul branch qpc-scale) (nonzero partition))
    scale=qpc-scale
    formula=%branch-weight
    source=(formula-source %branch-weight)
    exact=&
    notes='Normalized finite-branch weight branch/Z at fixed 1e6 scale.'
  ]
::
++  qpc-collapse2-choice-gate
  |=  [left=@ud right=@ud]
  ^-  qpc-gate-reading:qpc-sur
  =/  ok=?  (gte left right)
  [ ok=ok
    value=left
    threshold=right
    margin=?:(ok (sub left right) (sub right left))
    scale=qpc-scale
    formula=%collapse2-choice
    source=(formula-source %collapse2-choice)
    exact=&
    notes='Deterministic finite two-branch collapse helper: ok means left branch wins or ties.'
  ]
::
++  qpc-admissible-beam-gate
  |=  [admissible=@ud total=@ud]
  ^-  qpc-gate-reading:qpc-sur
  =/  ok=?  (gte admissible 1)
  [ ok=ok
    value=admissible
    threshold=1
    margin=?:(ok (sub admissible 1) 1)
    scale=total
    formula=%blocked-state
    source=(formula-source %blocked-state)
    exact=&
    notes='Finite beam is unblocked iff at least one candidate remains admissible; total is recorded as scale.'
  ]
::
++  qpc-finite-beam-reduce
  |=  scores=(list @ud)
  ^-  qpc-beam-reduction:qpc-sur
  =/  total=@ud  0
  =/  count=@ud  0
  =/  admissible=@ud  0
  =/  best-index=@ud  0
  =/  best-score=@ud  0
  =/  index=@ud  0
  |-  ^-  qpc-beam-reduction:qpc-sur
  ?~  scores
    =/  beam-gate=qpc-gate-reading:qpc-sur  (qpc-admissible-beam-gate admissible count)
    =/  ok=?  ok.beam-gate
    [ ok=ok
      blocked=?:(ok | &)
      winner-index=?:(ok best-index 0)
      winner-score=?:(ok best-score 0)
      total-score=total
      candidate-count=count
      admissible-count=admissible
      winner-weight=?:(ok (div (mul best-score qpc-scale) (nonzero total)) 0)
      scale=qpc-scale
      formula=%beam-reducer
      source=(formula-source %beam-reducer)
      exact=&
      notes='Finite N-branch reducer: positive scores are admissible; earliest maximum wins; empty/all-zero beams block.'
    ]
  =/  score=@ud  i.scores
  =/  score-admissible=?  (gth score 0)
  =/  score-wins=?  (gth score best-score)
  $(scores t.scores, total (add total score), count +(count), admissible ?:(score-admissible +(admissible) admissible), best-index ?:(score-wins index best-index), best-score ?:(score-wins score best-score), index +(index))
::
++  qpc-typed-beam-reduce
  |=  candidates=(list qpc-beam-candidate:qpc-sur)
  ^-  qpc-typed-beam-reduction:qpc-sur
  =/  total=@ud  0
  =/  count=@ud  0
  =/  admissible-count=@ud  0
  =/  best-index=@ud  0
  =/  best-score=@ud  0
  =/  best-id=@t  'none'
  =/  best-reason=@t  'none'
  =/  block-reason=@t  'empty beam'
  =/  index=@ud  0
  |-  ^-  qpc-typed-beam-reduction:qpc-sur
  ?~  candidates
    =/  beam-gate=qpc-gate-reading:qpc-sur  (qpc-admissible-beam-gate admissible-count count)
    =/  ok=?  ok.beam-gate
    [ ok=ok
      blocked=?:(ok | &)
      winner-id=?:(ok best-id 'none')
      winner-index=?:(ok best-index 0)
      winner-score=?:(ok best-score 0)
      total-score=total
      candidate-count=count
      admissible-count=admissible-count
      winner-weight=?:(ok (div (mul best-score qpc-scale) (nonzero total)) 0)
      winner-reason=?:(ok best-reason 'none')
      block-reason=?:(ok 'unblocked' block-reason)
      scale=qpc-scale
      formula=%typed-beam-reducer
      source=(formula-source %typed-beam-reducer)
      exact=&
      notes='Typed finite beam reducer: admissible=true and positive score survive; earliest maximum wins; otherwise returns a blocked reason.'
    ]
  =/  candidate=qpc-beam-candidate:qpc-sur  i.candidates
  =/  candidate-score=@ud  score.candidate
  =/  candidate-admissible=?  ?:(admissible.candidate (gth candidate-score 0) |)
  =/  candidate-wins=?  ?:(candidate-admissible (gth candidate-score best-score) |)
  $(candidates t.candidates, total ?:(candidate-admissible (add total candidate-score) total), count +(count), admissible-count ?:(candidate-admissible +(admissible-count) admissible-count), best-index ?:(candidate-wins index best-index), best-score ?:(candidate-wins candidate-score best-score), best-id ?:(candidate-wins id.candidate best-id), best-reason ?:(candidate-wins reason.candidate best-reason), block-reason ?:(=(0 count) reason.candidate block-reason), index +(index))
::
++  qpc-operator-beam-result
  |=  reduction=qpc-typed-beam-reduction:qpc-sur
  ^-  qpc-operator-beam-result:qpc-sur
  =/  ok=?  ok.reduction
  [ status=?:(ok %winner %blocked)
    id=?:(ok winner-id.reduction 'none')
    reason=?:(ok winner-reason.reduction block-reason.reduction)
    score=winner-score.reduction
    weight=winner-weight.reduction
    candidates=candidate-count.reduction
    admissible=admissible-count.reduction
    formula=%beam-result-surface
    source=(formula-source %beam-result-surface)
    exact=&
    notes='Operator beam result: status is winner or blocked; id/reason point at the decisive candidate or block cause.'
  ]
::
++  qpc-lorentzian-phase-ratio
  ::  Exact rational for S/(hbar*chi), before applying exp[i*...].
  |=  [action-lorentzian=@ud hbar=@ud]
  ^-  qpc-rational:qpc-sur
  [ numerator=(mul action-lorentzian qpc-scale)
    denominator=(mul (nonzero hbar) qpc-chi-micro)
    scale=qpc-scale
    formula=%z-a
    source=(formula-source %z-a)
    exact=&
    note='Lorentzian phase ratio (papers/qpc/quantum-patterned-cosmos.txt:772); complex phase is deferred.'
  ]
::
++  qpc-coherence-action-ratio
  ::  Exact rational for (1+A)*S_E/(hbar*chi), before applying exp[-...].
  |=  [attention=@ud action-euclidean=@ud hbar=@ud]
  ^-  qpc-rational:qpc-sur
  [ numerator=(mul (add qpc-scale attention) action-euclidean)
    denominator=(mul (nonzero hbar) qpc-chi-micro)
    scale=qpc-scale
    formula=%rho-c
    source=(formula-source %rho-c)
    exact=&
    note='Coherence-density exponent ratio (papers/qpc/quantum-patterned-cosmos.txt:325); Z and exp are deferred.'
  ]
::
++  qpc-rho-threshold-scaled
  |=  attention=@ud
  ^-  qpc-attention-reading:qpc-sur
  =/  denom=@ud  (mul qpc-chi-micro (add qpc-scale attention))
  =/  numer=@ud  (mul qpc-scale (mul qpc-scale qpc-scale))
  [ value=(div numer (nonzero denom))
    scale=qpc-scale
    source=(formula-source %rho-th)
    formula=%rho-th
    exact=&
    notes='rho_th = 1/(chi*(1+A)); returned at fixed 1e6 scale.'
  ]
::
++  qpc-hbar-effective-ratio
  |=  hbar=@ud
  ^-  qpc-rational:qpc-sur
  [ numerator=(mul hbar qpc-chi-micro)
    denominator=qpc-scale
    scale=qpc-scale
    formula=%hbar-eff
    source=(formula-source %hbar-eff)
    exact=&
    note='hbar_eff = chi*hbar as a fixed-scale rational.'
  ]
::
++  qpc-kappa-chi-ratio
  |=  eight-pi-g=@ud
  ^-  qpc-rational:qpc-sur
  [ numerator=(mul eight-pi-g qpc-scale)
    denominator=qpc-chi-micro
    scale=qpc-scale
    formula=%kappa-chi
    source=(formula-source %kappa-chi)
    exact=&
    note='kappa_chi = 8*pi*G/chi as a fixed-scale rational.'
  ]
::
++  qpc-lambda-chi-ratio
  |=  lambda=@ud
  ^-  qpc-rational:qpc-sur
  [ numerator=(mul lambda qpc-scale)
    denominator=qpc-chi-micro
    scale=qpc-scale
    formula=%lambda-chi
    source=(formula-source %lambda-chi)
    exact=&
    note='Lambda_chi = Lambda/chi as a fixed-scale rational.'
  ]
::
++  qpc-de-broglie-lambda-chi-ratio
  |=  [h=@ud momentum=@ud]
  ^-  qpc-rational:qpc-sur
  [ numerator=(mul h qpc-chi-micro)
    denominator=(mul (nonzero momentum) qpc-scale)
    scale=qpc-scale
    formula=%de-broglie-lambda-chi
    source=(formula-source %de-broglie-lambda-chi)
    exact=&
    note='lambda_chi = h*chi/p as a fixed-scale rational; caller supplies h and momentum p.'
  ]
::
++  qpc-chi-mass-ratio
  |=  mass-sm=@ud
  ^-  qpc-rational:qpc-sur
  [ numerator=(mul mass-sm qpc-scale)
    denominator=qpc-chi-micro
    scale=qpc-scale
    formula=%chi-mass
    source=(formula-source %chi-mass)
    exact=&
    note='m_eff = m_SM/chi as a fixed-scale rational.'
  ]
::
++  qpc-scale-plateau-ratio
  |=  [mu-zero=@ud depth=@ud reciprocal=?]
  ^-  qpc-rational:qpc-sur
  =/  chi-power=@ud  (pow-ud qpc-chi-micro depth)
  =/  scale-power=@ud  (pow-ud qpc-scale depth)
  [ numerator=?:(reciprocal (mul mu-zero scale-power) (mul mu-zero chi-power))
    denominator=?:(reciprocal chi-power scale-power)
    scale=qpc-scale
    formula=%scale-plateau
    source=(formula-source %scale-plateau)
    exact=&
    note='mu_n = mu0 * chi^n for integer n as an exact fixed-scale rational; reciprocal=true represents negative n.'
  ]
::
++  qpc-tunneling-exponent-ratio
  ::  Exact/floored rational for 2*sqrt(2*m*(V0-E))*L/(hbar*chi), before exp[-...].
  |=  [mass=@ud barrier=@ud energy=@ud length=@ud hbar=@ud]
  ^-  qpc-rational:qpc-sur
  =/  gap=@ud  (sub-zero barrier energy)
  =/  radicand=@ud  (mul (mul 2 mass) gap)
  =/  root=@ud  (isqrt radicand)
  =/  exact-root=?  =(radicand (mul root root))
  [ numerator=(mul (mul (mul 2 root) length) qpc-scale)
    denominator=(mul (nonzero hbar) qpc-chi-micro)
    scale=qpc-scale
    formula=%tunneling-exponent
    source=(formula-source %tunneling-exponent)
    exact=exact-root
    note='Tunneling exponent ratio for T ~= exp[-2*sqrt(2*m*(V0-E))*L/(hbar*chi)]; exp is deferred, sqrt is integer-floor when radicand is not a square.'
  ]
::
++  qpc-uncertainty-bound-ratio
  |=  hbar=@ud
  ^-  qpc-rational:qpc-sur
  [ numerator=(mul hbar qpc-chi-micro)
    denominator=(mul 2 qpc-scale)
    scale=qpc-scale
    formula=%uncertainty-bound
    source=(formula-source %uncertainty-bound)
    exact=&
    note='Lower bound Delta x * Delta p >= hbar*chi/2 as a fixed-scale rational.'
  ]
::
++  qpc-quantum-limit-bound-ratio
  |=  hbar=@ud
  ^-  qpc-rational:qpc-sur
  =/  chi2=@ud  (mul qpc-chi-micro qpc-chi-micro)
  [ numerator=(mul (mul hbar hbar) chi2)
    denominator=(mul 4 (mul qpc-scale qpc-scale))
    scale=qpc-scale
    formula=%quantum-limit-bound
    source=(formula-source %quantum-limit-bound)
    exact=&
    note='Quantum metrology lower bound (hbar*chi)^2/4 as a fixed-scale rational.'
  ]
::
++  qpc-bohm-chi-potential-signed
  |=  [positive=? bohm-magnitude=@ud]
  ^-  qpc-signed-reading:qpc-sur
  [ positive=positive
    magnitude=(mul bohm-magnitude qpc-chi-micro)
    scale=qpc-scale
    formula=%bohm-chi-potential
    source=(formula-source %bohm-chi-potential)
    exact=&
    notes='Q_chi = chi * Q as signed fixed-scale scaling of caller-supplied Bohm potential magnitude; nabla^2 R/R is not evaluated here.'
  ]
::
++  qpc-chi-harmonic-frequency-scaled
  |=  omega=@ud
  ^-  qpc-scaled-reading:qpc-sur
  =/  root=@ud  (isqrt (mul qpc-chi-micro qpc-scale))
  [ value=(div (mul omega qpc-scale) (nonzero root))
    scale=qpc-scale
    formula=%chi-harmonic-frequency
    source=(formula-source %chi-harmonic-frequency)
    exact=|
    notes='omega_chi = omega/sqrt(chi) as fixed-scale floor approximation; full harmonic mode spectrum and physical oscillator simulation are not evaluated.'
  ]
::
++  qpc-chi-harmonic-mode-variance-ratio
  |=  [hbar=@ud omega-k-chi=@ud]
  ^-  qpc-rational:qpc-sur
  [ numerator=(mul hbar qpc-chi-micro)
    denominator=(mul 2 (nonzero omega-k-chi))
    scale=qpc-scale
    formula=%chi-harmonic-mode-variance
    source=(formula-source %chi-harmonic-mode-variance)
    exact=&
    note='Per-mode variance chi*hbar/(2*omega_k(chi)) for caller-supplied omega_k(chi); no spectrum, integral, or oscillator simulation is evaluated.'
  ]
::
++  qpc-zero-point-energy-ratio
  |=  [hbar=@ud omega=@ud]
  ^-  qpc-rational:qpc-sur
  [ numerator=(mul (mul hbar omega) qpc-chi-micro)
    denominator=(mul 2 qpc-scale)
    scale=qpc-scale
    formula=%zero-point-e0
    source=(formula-source %zero-point-e0)
    exact=&
    note='E0^chi = one half * chi * hbar * omega as a fixed-scale rational.'
  ]
::
++  qpc-zpe-shift-ratio
  |=  [hbar=@ud renormalized-omega-sum=@ud]
  ^-  qpc-rational:qpc-sur
  [ numerator=(mul (mul hbar renormalized-omega-sum) qpc-chi-micro)
    denominator=(mul 2 qpc-scale)
    scale=qpc-scale
    formula=%zpe-shift
    source=(formula-source %zpe-shift)
    exact=&
    note='Finite epsilon_0(ren) shift = chi * sum_k(1/2*hbar*omega_k), with the renormalized finite omega sum supplied by caller; no mode summation or renormalization is performed here.'
  ]
::
++  qpc-decoherence-time-ratio
  |=  [hbar=@ud k-b=@ud temperature=@ud]
  ^-  qpc-rational:qpc-sur
  [ numerator=(mul hbar qpc-scale)
    denominator=(mul qpc-chi-micro (mul (nonzero k-b) (nonzero temperature)))
    scale=qpc-scale
    formula=%tau-dec
    source=(formula-source %tau-dec)
    exact=&
    note='tau_dec = hbar/(chi*k_B*T) as a fixed-scale rational.'
  ]
::
++  qpc-josephson-step-scaled
  |=  [baseline=@ud delta=@ud]
  ^-  qpc-scaled-reading:qpc-sur
  [ value=(add baseline (div (mul baseline delta) qpc-scale))
    scale=qpc-scale
    formula=%josephson-step
    source=(formula-source %josephson-step)
    exact=&
    notes='V_n = baseline*(1+delta_J), with baseline=n*(h/2e)*f and delta fixed-scale.'
  ]
::
++  qpc-josephson-estimator-ratio
  |=  [measured=@ud baseline=@ud alpha=@ud]
  ^-  qpc-rational:qpc-sur
  [ numerator=(mul (sub-zero measured baseline) (mul qpc-scale qpc-scale))
    denominator=(mul (nonzero baseline) (nonzero alpha))
    scale=qpc-scale
    formula=%josephson-estimator
    source=(formula-source %josephson-estimator)
    exact=&
    note='A_hat_JJ = (V_n/baseline - 1)/alpha_J as a non-negative fixed-scale rational; below-baseline measurements clamp to zero because A is non-negative.'
  ]
::
++  qpc-epsilon-band-gate
  |=  [epsilon=@ud low=@ud high=@ud]
  ^-  qpc-gate-reading:qpc-sur
  =/  ok=?  &((gte epsilon low) (gte high epsilon))
  =/  margin=@ud
    ?:  ok
      ?:  (gth (sub epsilon low) (sub high epsilon))
        (sub high epsilon)
      (sub epsilon low)
    ?:  (gth low epsilon)
      (sub low epsilon)
    (sub epsilon high)
  [ ok=ok
    value=epsilon
    threshold=low
    margin=margin
    scale=qpc-scale
    formula=%epsilon-band
    source=(formula-source %epsilon-band)
    exact=&
    notes='Residual evidence gate for source-backed epsilon bands, e.g. Bell epsilon around 0.02-0.04.'
  ]
::
++  qpc-stability-window-gate
  |=  [delta-f=@ud low=@ud high=@ud]
  ^-  qpc-gate-reading:qpc-sur
  =/  ok=?  &((gth delta-f low) (gth high delta-f))
  =/  margin=@ud
    ?:  ok
      ?:  (gth (sub delta-f low) (sub high delta-f))
        (sub high delta-f)
      (sub delta-f low)
    ?:  (gte low delta-f)
      (sub +(low) delta-f)
    (sub +(delta-f) high)
  [ ok=ok
    value=delta-f
    threshold=low
    margin=margin
    scale=qpc-scale
    formula=%stability-window
    source=(formula-source %stability-window)
    exact=&
    notes='Strict QPC stability window: low < Delta F < high. Boundary equality fails with unit margin.'
  ]
::
++  qpc-fermi-threshold-scaled
  ^-  qpc-scaled-reading:qpc-sur
  =/  root=@ud  (isqrt (mul qpc-chi-micro qpc-scale))
  [ value=(div (mul qpc-scale qpc-scale) root)
    scale=qpc-scale
    formula=%fermi-threshold
    source=(formula-source %fermi-threshold)
    exact=|
    notes='rho_c* = 1/sqrt(chi), implemented as fixed-scale floor reciprocal sqrt over canonical chi.'
  ]
::
++  qpc-transition-barrier-ratio
  |=  [mu=@ud volume=@ud lambda=@ud]
  ^-  qpc-rational:qpc-sur
  =/  mu2=@ud  (mul mu mu)
  =/  mu4=@ud  (mul mu2 mu2)
  =/  chi2=@ud  (mul qpc-chi-micro qpc-chi-micro)
  [ numerator=(mul (mul mu4 volume) (mul qpc-scale qpc-scale))
    denominator=(mul (mul 4 (nonzero lambda)) chi2)
    scale=qpc-scale
    formula=%transition-barrier
    source=(formula-source %transition-barrier)
    exact=&
    note='Delta F = mu^4 * V/(4*lambda*chi^2) as a fixed-scale rational.'
  ]
::
++  qpc-fracture-threshold-ratio
  |=  [mu=@ud lambda=@ud]
  ^-  qpc-rational:qpc-sur
  =/  mu2=@ud  (mul mu mu)
  =/  mu4=@ud  (mul mu2 mu2)
  =/  chi2=@ud  (mul qpc-chi-micro qpc-chi-micro)
  [ numerator=(mul (mul qpc-pi-micro mu4) qpc-scale)
    denominator=(mul (nonzero lambda) chi2)
    scale=qpc-scale
    formula=%fracture-threshold
    source=(formula-source %fracture-threshold)
    exact=&
    note='epsilon_critical = pi*mu^4/(lambda*chi^2) as a fixed-scale rational.'
  ]
::
++  qpc-dimensional-capacity-ratio
  |=  dimension=@ud
  ^-  qpc-rational:qpc-sur
  [ numerator=(pow-ud dimension dimension)
    denominator=(pow-ud 3 dimension)
    scale=qpc-scale
    formula=%dimensional-capacity
    source=(formula-source %dimensional-capacity)
    exact=&
    note='I(D) proportional to (D/3)^D, returned as the exact discrete rational D^D / 3^D.'
  ]
::
++  qpc-casimir-residual-scaled
  |=  [baseline=@ud attention=@ud]
  ^-  qpc-scaled-reading:qpc-sur
  =/  delta-chi=@ud  (sub qpc-chi-micro qpc-scale)
  =/  uplift=@ud  (div (mul attention delta-chi) qpc-scale)
  [ value=(add baseline (div (mul baseline uplift) qpc-scale))
    scale=qpc-scale
    formula=%casimir-residual
    source=(formula-source %casimir-residual)
    exact=&
    notes='F_chi ~= F0 * [1 + A(L)(chi - 1)] at fixed 1e6 scale; baseline and A(L) are caller supplied.'
  ]
::
++  qpc-observable-residual-signed
  |=  [observed=@ud baseline=@ud]
  ^-  qpc-signed-reading:qpc-sur
  =/  pos=?  (gte observed baseline)
  [ positive=pos
    magnitude=?:(pos (sub observed baseline) (sub baseline observed))
    scale=qpc-scale
    formula=%observable-residual
    source=(formula-source %observable-residual)
    exact=&
    notes='Delta O(A) = O_chi(A) - O_SM(A -> 0) as a signed fixed-scale residual; caller supplies observed and baseline values.'
  ]
::
++  qpc-zpf-spectrum-ratio-scaled
  ^-  qpc-scaled-reading:qpc-sur
  [ value=qpc-chi-micro
    scale=qpc-scale
    formula=%zpf-spectrum-ratio
    source=(formula-source %zpf-spectrum-ratio)
    exact=&
    notes='Zero-point fluctuation evidence ratio Sxx(chi)/Sxx(SM)=chi, exposed at canonical fixed 1e6 chi scale.'
  ]
::
++  qpc-bell-visibility-bound-gate
  |=  visibility=@ud
  ^-  qpc-gate-reading:qpc-sur
  =/  ok=?  (gte qpc-scale visibility)
  [ ok=ok
    value=visibility
    threshold=qpc-scale
    margin=?:(ok (sub qpc-scale visibility) (sub visibility qpc-scale))
    scale=qpc-scale
    formula=%bell-visibility-bound
    source=(formula-source %bell-visibility-bound)
    exact=&
    notes='Admissibility gate for the Bell visibility anchor: 0 <= V_chi <= 1 at fixed 1e6 scale; does not evaluate cos(alpha-beta) or E(alpha,beta).'
  ]
::
++  qpc-attractor-onset-key-gate
  |=  [source-dominance=@ud mass-floor=@ud]
  ^-  qpc-gate-reading:qpc-sur
  =/  ok=?  (gth source-dominance mass-floor)
  [ ok=ok
    value=source-dominance
    threshold=mass-floor
    margin=?:(ok (sub source-dominance mass-floor) (sub +(mass-floor) source-dominance))
    scale=qpc-scale
    formula=%attractor-onset-key-gate
    source=(formula-source %attractor-onset-key-gate)
    exact=&
    notes='Source-backed epsilon > 0 gate over normalized caller-supplied sides: Jbar_chi*L^2 must exceed mu^2/chi. No source fitting or unit solver is hidden.'
  ]
::
++  qpc-attractor-relaxation-rate-ratio
  |=  [gamma=@ud lambda-min=@ud]
  ^-  qpc-rational:qpc-sur
  [ numerator=(mul gamma lambda-min)
    denominator=qpc-scale
    scale=qpc-scale
    formula=%attractor-relaxation-rate
    source=(formula-source %attractor-relaxation-rate)
    exact=&
    note='kappa = Gamma*lambda_min over caller-supplied fixed-scale factors; lambda_min estimation and overdamped onset fitting remain external evidence.'
  ]
::
++  qpc-protective-hessian-mode-gate
  |=  negative-modes=@ud
  ^-  qpc-gate-reading:qpc-sur
  =/  ok=?  =(0 negative-modes)
  [ ok=ok
    value=negative-modes
    threshold=0
    margin=negative-modes
    scale=qpc-scale
    formula=%protective-hessian-mode-gate
    source=(formula-source %protective-hessian-mode-gate)
    exact=&
    notes='Protection gate for caller-supplied Hessian negative-mode count. The kernel checks no-negative-modes and does not compute the Hessian spectrum.'
  ]
::
++  qpc-unity-broadcast-growth-rate-ratio
  |=  [gamma=@ud j-chi=@ud]
  ^-  qpc-rational:qpc-sur
  [ numerator=(mul gamma j-chi)
    denominator=qpc-scale
    scale=qpc-scale
    formula=%unity-broadcast-growth-rate
    source=(formula-source %unity-broadcast-growth-rate)
    exact=&
    note='partial_t phi ~= Gamma*J_chi in the phi ~= 0 broadcast limit, over caller-supplied fixed-scale inputs; no field state is mutated.'
  ]
::
++  qpc-ecological-attractor-threshold-gate
  |=  [richness-bps=@ud threshold-bps=@ud]
  ^-  qpc-gate-reading:qpc-sur
  =/  ok=?  (gte richness-bps threshold-bps)
  [ ok=ok
    value=richness-bps
    threshold=threshold-bps
    margin=?:(ok (sub richness-bps threshold-bps) (sub threshold-bps richness-bps))
    scale=10.000
    formula=%ecological-attractor-threshold-gate
    source=(formula-source %ecological-attractor-threshold-gate)
    exact=&
    notes='Ecological attractor threshold gate over basis-point richness, e.g. 70% = 7000 bps. It does not fit Bray-Curtis curves or validate a physical ecosystem claim.'
  ]
::
++  qpc-attractor-kappa-jump-ratio
  |=  [kappa-super=@ud kappa-sub=@ud]
  ^-  qpc-rational:qpc-sur
  [ numerator=kappa-super
    denominator=(nonzero kappa-sub)
    scale=qpc-scale
    formula=%attractor-kappa-jump-ratio
    source=(formula-source %attractor-kappa-jump-ratio)
    exact=&
    note='Rate-jump evidence ratio kappa_super/kappa_sub over caller-supplied finite decay rates; no exponential curve fit is performed.'
  ]
::
++  qpc-seal-stationarity-variation-gate
  |=  [variation-residual=@ud tolerance=@ud]
  ^-  qpc-gate-reading:qpc-sur
  =/  ok=?  (gte tolerance variation-residual)
  [ ok=ok
    value=variation-residual
    threshold=tolerance
    margin=?:(ok (sub tolerance variation-residual) (sub variation-residual tolerance))
    scale=qpc-scale
    formula=%seal-stationarity-variation-gate
    source=(formula-source %seal-stationarity-variation-gate)
    exact=&
    notes='Mirror Seal stationarity gate over supplied residual/tolerance: delta S_chi / delta phi is treated as externally measured evidence, not computed by the kernel.'
  ]
::
++  qpc-seal-small-action-ratio
  |=  [s-chi=@ud hbar-chi=@ud]
  ^-  qpc-rational:qpc-sur
  [ numerator=s-chi
    denominator=(nonzero hbar-chi)
    scale=qpc-scale
    formula=%seal-small-action-ratio
    source=(formula-source %seal-small-action-ratio)
    exact=&
    note='Small-action witness S_chi/(hbar*chi) over supplied finite magnitudes; this does not require S_chi=0 and does not execute phase-loop dynamics.'
  ]
::
++  qpc-deff-rhoc-plateau-gate
  |=  [rho-c=@ud rho-threshold=@ud]
  ^-  qpc-gate-reading:qpc-sur
  =/  ok=?  (gte rho-c rho-threshold)
  [ ok=ok
    value=rho-c
    threshold=rho-threshold
    margin=?:(ok (sub rho-c rho-threshold) (sub rho-threshold rho-c))
    scale=qpc-scale
    formula=%deff-rhoc-plateau-gate
    source=(formula-source %deff-rhoc-plateau-gate)
    exact=&
    notes='Dimensional-deepening plateau gate over supplied fixed-scale rho_c and threshold. The 1/sqrt(chi) heuristic and D_eff model fitting remain outside this evaluator.'
  ]
::
++  qpc-temporal-depth-local-ansatz-ratio
  |=  [external-time=@ud rho-c=@ud]
  ^-  qpc-rational:qpc-sur
  =/  remaining=@ud  (sub-zero qpc-scale rho-c)
  [ numerator=(mul external-time qpc-scale)
    denominator=(nonzero remaining)
    scale=qpc-scale
    formula=%temporal-depth-local-ansatz
    source=(formula-source %temporal-depth-local-ansatz)
    exact=|
    note='Inexact local ansatz t_prime=t/(1-rho_c) for bounded rho_c<1. When rho_c reaches scale, denominator is floored only to avoid crash; no metric truth or time simulator is claimed.'
  ]
::
++  ct-rk-resonance-scaled
  |=  [frob-square=@ud k=@ud]
  ^-  qpc-scaled-reading:qpc-sur
  [ value=(cap-scale (div frob-square (nonzero k)))
    scale=qpc-scale
    formula=%ct-rk-resonance
    source=(formula-source %ct-rk-resonance)
    exact=&
    notes='R_k = (1/k)||U_T^T U_S||_F^2, caller supplies Frobenius square at 1e6 scale.'
  ]
::
++  ct-lambda-plateau-gate
  |=  [spread=@ud center=@ud max-bps=@ud]
  ^-  qpc-gate-reading:qpc-sur
  =/  allowed=@ud  (div (mul center max-bps) 10.000)
  =/  ok=?  (gte allowed spread)
  [ ok=ok
    value=spread
    threshold=allowed
    margin=?:(ok (sub allowed spread) (sub spread allowed))
    scale=10.000
    formula=%ct-lambda-plateau
    source=(formula-source %ct-lambda-plateau)
    exact=&
    notes='Lambda plateau gate: spread must be within max basis points of center; source default is <10%.'
  ]
::
++  ct-estimator-concordance-gate
  |=  r-squared=@ud
  ^-  qpc-gate-reading:qpc-sur
  =/  threshold=@ud  950.000
  =/  ok=?  (gte r-squared threshold)
  [ ok=ok
    value=r-squared
    threshold=threshold
    margin=?:(ok (sub r-squared threshold) (sub threshold r-squared))
    scale=qpc-scale
    formula=%ct-estimator-concordance
    source=(formula-source %ct-estimator-concordance)
    exact=&
    notes='Estimator concordance gate for R^2 >= 0.95 on the Lambda plateau.'
  ]
::
++  ct-live-percentile-gate
  |=  [observed=@ud baseline-p95=@ud p-bps=@ud max-p-bps=@ud]
  ^-  qpc-gate-reading:qpc-sur
  =/  ok=?  &((gte observed baseline-p95) (gte max-p-bps p-bps))
  =/  margin=@ud
    ?:  ok
      (sub observed baseline-p95)
    ?:  (gth baseline-p95 observed)
      (sub baseline-p95 observed)
    (sub p-bps max-p-bps)
  [ ok=ok
    value=observed
    threshold=baseline-p95
    margin=margin
    scale=10.000
    formula=%ct-live-percentile
    source=(formula-source %ct-live-percentile)
    exact=&
    notes='Live-baseline gate: observed statistic exceeds baseline p95 and p-value basis points stay below limit.'
  ]
::
++  ct-octave-persistence-gate
  |=  [octaves=@ud phase-error=@ud max-phase-error=@ud]
  ^-  qpc-gate-reading:qpc-sur
  =/  ok=?  &((gte octaves 2) (gte max-phase-error phase-error))
  =/  margin=@ud
    ?:  ok
      (sub max-phase-error phase-error)
    ?:  (gth 2 octaves)
      (sub 2 octaves)
    (sub phase-error max-phase-error)
  [ ok=ok
    value=octaves
    threshold=2
    margin=margin
    scale=qpc-scale
    formula=%ct-octave-persistence
    source=(formula-source %ct-octave-persistence)
    exact=&
    notes='Persistence gate: at least two adjacent Lambda octaves and phase error within caller limit.'
  ]
::
++  ct-coherent-integration-index-ratio
  |=  [geom-rho=@ud alpha=@ud rbar-inter=@ud]
  ^-  qpc-rational:qpc-sur
  [ numerator=(mul geom-rho (add (mul qpc-scale qpc-scale) (mul alpha rbar-inter)))
    denominator=(mul qpc-scale qpc-scale)
    scale=qpc-scale
    formula=%ct-coherent-integration-index
    source=(formula-source %ct-coherent-integration-index)
    exact=&
    note='I_int = geometric_mean(rho_i)*(1 + alpha*Rbar_inter) over caller-supplied fixed-scale terms; no domain estimation is performed.'
  ]
::
++  ct-boundary-resonance-test-gate
  |=  [rso-before=@ud rso-after=@ud rso-min-lift=@ud lambda2-before=@ud lambda2-after=@ud lambda2-min-lift=@ud r-return-before=@ud r-return-after=@ud r-return-min-lift=@ud stability-before=@ud stability-after=@ud stability-min-lift=@ud]
  ^-  qpc-gate-reading:qpc-sur
  =/  rso-lift=@ud
    ?:  (gth rso-after rso-before)
      (sub rso-after rso-before)
    0
  =/  lambda-lift=@ud
    ?:  (gth lambda2-after lambda2-before)
      (sub lambda2-after lambda2-before)
    0
  =/  return-lift=@ud
    ?:  (gth r-return-after r-return-before)
      (sub r-return-after r-return-before)
    0
  =/  stability-lift=@ud
    ?:  (gth stability-after stability-before)
      (sub stability-after stability-before)
    0
  =/  rso-ok=?  (gte rso-lift rso-min-lift)
  =/  lambda-ok=?  (gte lambda-lift lambda2-min-lift)
  =/  return-ok=?  (gte return-lift r-return-min-lift)
  =/  stability-ok=?  (gte stability-lift stability-min-lift)
  =/  ok=?  ?&(rso-ok lambda-ok return-ok stability-ok)
  =/  rso-margin=@ud
    ?:  rso-ok
      (sub rso-lift rso-min-lift)
    (sub rso-min-lift rso-lift)
  =/  lambda-margin=@ud
    ?:  lambda-ok
      (sub lambda-lift lambda2-min-lift)
    (sub lambda2-min-lift lambda-lift)
  =/  return-margin=@ud
    ?:  return-ok
      (sub return-lift r-return-min-lift)
    (sub r-return-min-lift return-lift)
  =/  stability-margin=@ud
    ?:  stability-ok
      (sub stability-lift stability-min-lift)
    (sub stability-min-lift stability-lift)
  =/  response-margin=@ud
    ?:  (gth lambda-margin return-margin)
      ?:  (gth return-margin stability-margin)
        stability-margin
      return-margin
    ?:  (gth lambda-margin stability-margin)
      stability-margin
    lambda-margin
  =/  margin=@ud
    ?:  ok
      ?:  (gth rso-margin response-margin)
        response-margin
      rso-margin
    ?:  !rso-ok
      rso-margin
    ?:  !lambda-ok
      lambda-margin
    ?:  !return-ok
      return-margin
    stability-margin
  [ ok=ok
    value=rso-lift
    threshold=rso-min-lift
    margin=margin
    scale=qpc-scale
    formula=%ct-boundary-resonance-test-gate
    source=(formula-source %ct-boundary-resonance-test-gate)
    exact=&
    notes='Boundary-resonance test gate checks supplied R_SO lift plus lambda2, r_return, and S improvements only; subspace alignment, controller behavior, social diagnosis, and action authority remain deferred.'
  ]
::
++  ct-integration-bottleneck-gate
  |=  [rho-bottleneck=@ud tau=@ud rho-star=@ud integration-index=@ud]
  ^-  qpc-gate-reading:qpc-sur
  =/  bottleneck-threshold=@ud  (div (mul tau rho-star) qpc-scale)
  =/  bottleneck-ok=?  (gte rho-bottleneck bottleneck-threshold)
  =/  index-ok=?  (gte integration-index rho-star)
  =/  ok=?  &(bottleneck-ok index-ok)
  =/  bottleneck-margin=@ud
    ?:  bottleneck-ok
      (sub rho-bottleneck bottleneck-threshold)
    (sub bottleneck-threshold rho-bottleneck)
  =/  index-margin=@ud
    ?:  index-ok
      (sub integration-index rho-star)
    (sub rho-star integration-index)
  =/  margin=@ud
    ?:  (gth bottleneck-margin index-margin)
      index-margin
    bottleneck-margin
  [ ok=ok
    value=integration-index
    threshold=rho-star
    margin=margin
    scale=qpc-scale
    formula=%ct-integration-bottleneck-gate
    source=(formula-source %ct-integration-bottleneck-gate)
    exact=&
    notes='Integration passes only when rho_bottleneck >= tau*rho_star and caller-supplied I_int >= rho_star; Cantrip remains action authority.'
  ]
::
++  ct-minimal-disturbance-tradeoff-gate
  |=  [rso-drop=@ud rso-min-drop=@ud modularity-lift=@ud modularity-min-lift=@ud dwell-lift=@ud dwell-min-lift=@ud lambda2-drop=@ud lambda2-min-drop=@ud r-return-drop=@ud r-return-min-drop=@ud recovery-rso-lift=@ud recovery-lambda2-lift=@ud recovery-r-return-lift=@ud recovery-stability-lift=@ud recovery-min-lift=@ud glyph-flux-inward=? lambda-eff-crossed=?]
  ^-  qpc-gate-reading:qpc-sur
  =/  rso-ok=?  (gte rso-drop rso-min-drop)
  =/  modularity-ok=?  (gte modularity-lift modularity-min-lift)
  =/  dwell-ok=?  (gte dwell-lift dwell-min-lift)
  =/  lambda-drop-ok=?  (gte lambda2-drop lambda2-min-drop)
  =/  return-drop-ok=?  (gte r-return-drop r-return-min-drop)
  =/  recovery-rso-ok=?  (gte recovery-rso-lift recovery-min-lift)
  =/  recovery-lambda-ok=?  (gte recovery-lambda2-lift recovery-min-lift)
  =/  recovery-return-ok=?  (gte recovery-r-return-lift recovery-min-lift)
  =/  recovery-stability-ok=?  (gte recovery-stability-lift recovery-min-lift)
  =/  ok=?  ?&(rso-ok modularity-ok dwell-ok lambda-drop-ok return-drop-ok recovery-rso-ok recovery-lambda-ok recovery-return-ok recovery-stability-ok glyph-flux-inward !lambda-eff-crossed)
  =/  rso-margin=@ud
    ?:  rso-ok
      (sub rso-drop rso-min-drop)
    (sub rso-min-drop rso-drop)
  =/  modularity-margin=@ud
    ?:  modularity-ok
      (sub modularity-lift modularity-min-lift)
    (sub modularity-min-lift modularity-lift)
  =/  dwell-margin=@ud
    ?:  dwell-ok
      (sub dwell-lift dwell-min-lift)
    (sub dwell-min-lift dwell-lift)
  =/  lambda-margin=@ud
    ?:  lambda-drop-ok
      (sub lambda2-drop lambda2-min-drop)
    (sub lambda2-min-drop lambda2-drop)
  =/  return-margin=@ud
    ?:  return-drop-ok
      (sub r-return-drop r-return-min-drop)
    (sub r-return-min-drop r-return-drop)
  =/  recovery-rso-margin=@ud
    ?:  recovery-rso-ok
      (sub recovery-rso-lift recovery-min-lift)
    (sub recovery-min-lift recovery-rso-lift)
  =/  recovery-lambda-margin=@ud
    ?:  recovery-lambda-ok
      (sub recovery-lambda2-lift recovery-min-lift)
    (sub recovery-min-lift recovery-lambda2-lift)
  =/  recovery-return-margin=@ud
    ?:  recovery-return-ok
      (sub recovery-r-return-lift recovery-min-lift)
    (sub recovery-min-lift recovery-r-return-lift)
  =/  recovery-stability-margin=@ud
    ?:  recovery-stability-ok
      (sub recovery-stability-lift recovery-min-lift)
    (sub recovery-min-lift recovery-stability-lift)
  =/  pulse-margin=@ud
    ?:  !rso-ok
      rso-margin
    ?:  !modularity-ok
      modularity-margin
    ?:  !dwell-ok
      dwell-margin
    ?:  !lambda-drop-ok
      lambda-margin
    ?:  !return-drop-ok
      return-margin
    ?:  !glyph-flux-inward
      0
    ?:  (gth rso-margin modularity-margin)
      ?:  (gth modularity-margin dwell-margin)
        ?:  (gth dwell-margin lambda-margin)
          ?:  (gth lambda-margin return-margin)
            return-margin
          lambda-margin
        dwell-margin
      modularity-margin
    rso-margin
  =/  recovery-margin=@ud
    ?:  !recovery-rso-ok
      recovery-rso-margin
    ?:  !recovery-lambda-ok
      recovery-lambda-margin
    ?:  !recovery-return-ok
      recovery-return-margin
    ?:  !recovery-stability-ok
      recovery-stability-margin
    ?:  lambda-eff-crossed
      0
    ?:  (gth recovery-rso-margin recovery-lambda-margin)
      ?:  (gth recovery-lambda-margin recovery-return-margin)
        ?:  (gth recovery-return-margin recovery-stability-margin)
          recovery-stability-margin
        recovery-return-margin
      recovery-lambda-margin
    recovery-rso-margin
  =/  margin=@ud
    ?:  ok
      ?:  (gth pulse-margin recovery-margin)
        recovery-margin
      pulse-margin
    ?:  ?|(!rso-ok !modularity-ok !dwell-ok !lambda-drop-ok !return-drop-ok !glyph-flux-inward)
      pulse-margin
    recovery-margin
  [ ok=ok
    value=rso-drop
    threshold=rso-min-drop
    margin=margin
    scale=qpc-scale
    formula=%ct-minimal-disturbance-tradeoff-gate
    source=(formula-source %ct-minimal-disturbance-tradeoff-gate)
    exact=&
    notes='Minimal-disturbance tradeoff gate checks supplied coercive-pulse degradation, inward glyph-flux evidence, no lambda_star crossing, and recognition-coupling recovery deltas only; no coercion classifier, pulse runner, glyph estimator, social diagnosis, or action authority is implemented.'
  ]
::
++  ct-pss-window-fidelity-gate
  |=  [f-aligned=@ud f-orthogonal=@ud min-delta=@ud ci-lower=@ud orthogonal-null-effect=@ud orthogonal-null-max=@ud dephasing-null-effect=@ud dephasing-null-max=@ud no-signalling-pass=? preregistered=?]
  ^-  qpc-gate-reading:qpc-sur
  =/  delta=@ud
    ?:  (gth f-aligned f-orthogonal)
      (sub f-aligned f-orthogonal)
    0
  =/  delta-ok=?  (gte delta min-delta)
  =/  ci-ok=?  (gth ci-lower 0)
  =/  orthogonal-ok=?  !(gth orthogonal-null-effect orthogonal-null-max)
  =/  dephasing-ok=?  !(gth dephasing-null-effect dephasing-null-max)
  =/  ok=?  ?&(delta-ok ci-ok orthogonal-ok dephasing-ok no-signalling-pass preregistered)
  =/  delta-margin=@ud
    ?:  delta-ok
      (sub delta min-delta)
    (sub min-delta delta)
  =/  ci-margin=@ud
    ?:  ci-ok
      ci-lower
    1
  =/  orthogonal-margin=@ud
    ?:  orthogonal-ok
      (sub orthogonal-null-max orthogonal-null-effect)
    (sub orthogonal-null-effect orthogonal-null-max)
  =/  dephasing-margin=@ud
    ?:  dephasing-ok
      (sub dephasing-null-max dephasing-null-effect)
    (sub dephasing-null-effect dephasing-null-max)
  =/  margin=@ud
    ?:  ok
      ?:  (gth delta-margin ci-margin)
        ?:  (gth ci-margin orthogonal-margin)
          ?:  (gth orthogonal-margin dephasing-margin)
            dephasing-margin
          orthogonal-margin
        ci-margin
      delta-margin
    ?:  !delta-ok
      delta-margin
    ?:  !ci-ok
      ci-margin
    ?:  !orthogonal-ok
      orthogonal-margin
    ?:  !dephasing-ok
      dephasing-margin
    0
  [ ok=ok
    value=delta
    threshold=min-delta
    margin=margin
    scale=qpc-scale
    formula=%ct-pss-window-fidelity-gate
    source=(formula-source %ct-pss-window-fidelity-gate)
    exact=&
    notes='PSS window fidelity gate checks supplied aligned-minus-orthogonal fidelity, CI exclusion, orthogonal/dephasing null ceilings, no-signalling, and preregistration only; it does not compute PLV/PPC, memory fidelity, surrogate statistics, retrocausality, or physical truth.'
  ]
::
++  ct-delayed-choice-slope-gate
  |=  [aligned-slope=@ud aligned-min=@ud ci-lower=@ud orthogonal-slope=@ud orthogonal-max=@ud dephasing-slope=@ud dephasing-max=@ud no-signalling-pass=? preregistered=?]
  ^-  qpc-gate-reading:qpc-sur
  =/  aligned-ok=?  (gte aligned-slope aligned-min)
  =/  ci-ok=?  (gth ci-lower 0)
  =/  orthogonal-ok=?  !(gth orthogonal-slope orthogonal-max)
  =/  dephasing-ok=?  !(gth dephasing-slope dephasing-max)
  =/  ok=?  ?&(aligned-ok ci-ok orthogonal-ok dephasing-ok no-signalling-pass preregistered)
  =/  aligned-margin=@ud
    ?:  aligned-ok
      (sub aligned-slope aligned-min)
    (sub aligned-min aligned-slope)
  =/  ci-margin=@ud
    ?:  ci-ok
      ci-lower
    1
  =/  orthogonal-margin=@ud
    ?:  orthogonal-ok
      (sub orthogonal-max orthogonal-slope)
    (sub orthogonal-slope orthogonal-max)
  =/  dephasing-margin=@ud
    ?:  dephasing-ok
      (sub dephasing-max dephasing-slope)
    (sub dephasing-slope dephasing-max)
  =/  margin=@ud
    ?:  ok
      ?:  (gth aligned-margin ci-margin)
        ?:  (gth ci-margin orthogonal-margin)
          ?:  (gth orthogonal-margin dephasing-margin)
            dephasing-margin
          orthogonal-margin
        ci-margin
      aligned-margin
    ?:  !aligned-ok
      aligned-margin
    ?:  !ci-ok
      ci-margin
    ?:  !orthogonal-ok
      orthogonal-margin
    ?:  !dephasing-ok
      dephasing-margin
    0
  [ ok=ok
    value=aligned-slope
    threshold=aligned-min
    margin=margin
    scale=qpc-scale
    formula=%ct-delayed-choice-slope-gate
    source=(formula-source %ct-delayed-choice-slope-gate)
    exact=&
    notes='Delayed-choice slope gate checks supplied aligned slope, CI exclusion, flat orthogonal/dephasing controls, no-signalling, and preregistration only; it does not compute ln(V/V0), fit slopes, operate an interferometer, or validate retrocausality.'
  ]
::
++  ct-ab-loop-holonomy-compression-gate
  |=  [orthogonal-cycles=@ud aligned-cycles=@ud min-compression=@ud ci-lower=@ud null-compression=@ud null-max=@ud holonomy-persist=? preregistered=?]
  ^-  qpc-gate-reading:qpc-sur
  =/  compression=@ud
    ?:  (gth orthogonal-cycles aligned-cycles)
      (sub orthogonal-cycles aligned-cycles)
    0
  =/  compression-ok=?  (gte compression min-compression)
  =/  ci-ok=?  (gth ci-lower 0)
  =/  null-ok=?  !(gth null-compression null-max)
  =/  ok=?  ?&(compression-ok ci-ok null-ok holonomy-persist preregistered)
  =/  compression-margin=@ud
    ?:  compression-ok
      (sub compression min-compression)
    (sub min-compression compression)
  =/  ci-margin=@ud
    ?:  ci-ok
      ci-lower
    1
  =/  null-margin=@ud
    ?:  null-ok
      (sub null-max null-compression)
    (sub null-compression null-max)
  =/  margin=@ud
    ?:  ok
      ?:  (gth compression-margin ci-margin)
        ?:  (gth ci-margin null-margin)
          null-margin
        ci-margin
      compression-margin
    ?:  !compression-ok
      compression-margin
    ?:  !ci-ok
      ci-margin
    ?:  !null-ok
      null-margin
    0
  [ ok=ok
    value=compression
    threshold=min-compression
    margin=margin
    scale=qpc-scale
    formula=%ct-ab-loop-holonomy-compression-gate
    source=(formula-source %ct-ab-loop-holonomy-compression-gate)
    exact=&
    notes='AB-loop holonomy/compression gate checks supplied cycle compression, CI exclusion, null-control ceiling, holonomy persistence, and preregistration only; it does not compute holonomy, instrument task cycles, prove no-signalling, or validate CT physics.'
  ]
::
++  ct-global-phase-synchrony-surrogate-gate
  |=  [synchrony-effect=@ud min-effect=@ud ci-lower=@ud strongest-surrogate=@ud surrogate-max=@ud amplitude-shift=@ud amplitude-max=@ud fdr-q=@ud fdr-max=@ud no-signalling-pass=? preregistered=?]
  ^-  qpc-gate-reading:qpc-sur
  =/  effect-ok=?  (gte synchrony-effect min-effect)
  =/  ci-ok=?  (gth ci-lower 0)
  =/  surrogate-ok=?  !(gth strongest-surrogate surrogate-max)
  =/  amplitude-ok=?  !(gth amplitude-shift amplitude-max)
  =/  fdr-ok=?  !(gth fdr-q fdr-max)
  =/  ok=?  ?&(effect-ok ci-ok surrogate-ok amplitude-ok fdr-ok no-signalling-pass preregistered)
  =/  effect-margin=@ud
    ?:  effect-ok
      (sub synchrony-effect min-effect)
    (sub min-effect synchrony-effect)
  =/  ci-margin=@ud
    ?:  ci-ok
      ci-lower
    1
  =/  surrogate-margin=@ud
    ?:  surrogate-ok
      (sub surrogate-max strongest-surrogate)
    (sub strongest-surrogate surrogate-max)
  =/  amplitude-margin=@ud
    ?:  amplitude-ok
      (sub amplitude-max amplitude-shift)
    (sub amplitude-shift amplitude-max)
  =/  fdr-margin=@ud
    ?:  fdr-ok
      (sub fdr-max fdr-q)
    (sub fdr-q fdr-max)
  =/  pass-effect-ci=@ud
    ?:  (gth effect-margin ci-margin)
      ci-margin
    effect-margin
  =/  pass-surrogate=@ud
    ?:  (gth pass-effect-ci surrogate-margin)
      surrogate-margin
    pass-effect-ci
  =/  pass-amplitude=@ud
    ?:  (gth pass-surrogate amplitude-margin)
      amplitude-margin
    pass-surrogate
  =/  pass-margin=@ud
    ?:  (gth pass-amplitude fdr-margin)
      fdr-margin
    pass-amplitude
  =/  margin=@ud
    ?:  ok
      pass-margin
    ?:  !effect-ok
      effect-margin
    ?:  !ci-ok
      ci-margin
    ?:  !surrogate-ok
      surrogate-margin
    ?:  !amplitude-ok
      amplitude-margin
    ?:  !fdr-ok
      fdr-margin
    0
  [ ok=ok
    value=synchrony-effect
    threshold=min-effect
    margin=margin
    scale=qpc-scale
    formula=%ct-global-phase-synchrony-surrogate-gate
    source=(formula-source %ct-global-phase-synchrony-surrogate-gate)
    exact=&
    notes='Global phase-synchrony surrogate gate checks supplied excess synchrony, CI exclusion, strongest-surrogate ceiling, ordinary amplitude channel, FDR ceiling, no-signalling, and preregistration only; it does not compute PLV/PPC, circular correlation, shuffle masks, FDR, or validate CT physics.'
  ]
::
++  ct-coherence-differential-scaling-gate
  |=  [correlation-lift=@ud min-lift=@ud ci-lower=@ud shape-residual=@ud residual-max=@ud dephased-effect=@ud dephased-max=@ud monotone-pass=? no-signalling-pass=? preregistered=?]
  ^-  qpc-gate-reading:qpc-sur
  =/  lift-ok=?  (gte correlation-lift min-lift)
  =/  ci-ok=?  (gth ci-lower 0)
  =/  shape-ok=?  !(gth shape-residual residual-max)
  =/  dephase-ok=?  !(gth dephased-effect dephased-max)
  =/  ok=?  ?&(lift-ok ci-ok shape-ok dephase-ok monotone-pass no-signalling-pass preregistered)
  =/  lift-margin=@ud
    ?:  lift-ok
      (sub correlation-lift min-lift)
    (sub min-lift correlation-lift)
  =/  ci-margin=@ud
    ?:  ci-ok
      ci-lower
    1
  =/  shape-margin=@ud
    ?:  shape-ok
      (sub residual-max shape-residual)
    (sub shape-residual residual-max)
  =/  dephase-margin=@ud
    ?:  dephase-ok
      (sub dephased-max dephased-effect)
    (sub dephased-effect dephased-max)
  =/  pass-lift-ci=@ud
    ?:  (gth lift-margin ci-margin)
      ci-margin
    lift-margin
  =/  pass-shape=@ud
    ?:  (gth pass-lift-ci shape-margin)
      shape-margin
    pass-lift-ci
  =/  pass-margin=@ud
    ?:  (gth pass-shape dephase-margin)
      dephase-margin
    pass-shape
  =/  margin=@ud
    ?:  ok
      pass-margin
    ?:  !lift-ok
      lift-margin
    ?:  !ci-ok
      ci-margin
    ?:  !shape-ok
      shape-margin
    ?:  !dephase-ok
      dephase-margin
    0
  [ ok=ok
    value=correlation-lift
    threshold=min-lift
    margin=margin
    scale=qpc-scale
    formula=%ct-coherence-differential-scaling-gate
    source=(formula-source %ct-coherence-differential-scaling-gate)
    exact=&
    notes='Coherence-differential scaling gate checks supplied monotone C(delta-rho) evidence, positive CI, preregistered-shape residual ceiling, dephasing disappearance, no-signalling, and preregistration only; it does not fit curves, estimate correlations, run dephasing controls, or validate CT physics.'
  ]
::
++  ct-temporal-order-independence-gate
  |=  [phase-difference=@ud equivalence-max=@ud ci-upper=@ud null-effect=@ud null-max=@ud randomized-pass=? order-preserved-pass=? no-signalling-pass=? preregistered=? two-time-conditioned=?]
  ^-  qpc-gate-reading:qpc-sur
  =/  equivalence-ok=?  !(gth phase-difference equivalence-max)
  =/  ci-ok=?  !(gth ci-upper equivalence-max)
  =/  null-ok=?  !(gth null-effect null-max)
  =/  ok=?  ?&(equivalence-ok ci-ok null-ok randomized-pass order-preserved-pass no-signalling-pass preregistered two-time-conditioned)
  =/  equivalence-margin=@ud
    ?:  equivalence-ok
      (sub equivalence-max phase-difference)
    (sub phase-difference equivalence-max)
  =/  ci-margin=@ud
    ?:  ci-ok
      (sub equivalence-max ci-upper)
    (sub ci-upper equivalence-max)
  =/  null-margin=@ud
    ?:  null-ok
      (sub null-max null-effect)
    (sub null-effect null-max)
  =/  pass-equivalence-ci=@ud
    ?:  (gth equivalence-margin ci-margin)
      ci-margin
    equivalence-margin
  =/  pass-margin=@ud
    ?:  (gth pass-equivalence-ci null-margin)
      null-margin
    pass-equivalence-ci
  =/  margin=@ud
    ?:  ok
      pass-margin
    ?:  !equivalence-ok
      equivalence-margin
    ?:  !ci-ok
      ci-margin
    ?:  !null-ok
      null-margin
    0
  [ ok=ok
    value=phase-difference
    threshold=equivalence-max
    margin=margin
    scale=qpc-scale
    formula=%ct-temporal-order-independence-gate
    source=(formula-source %ct-temporal-order-independence-gate)
    exact=&
    notes='Temporal-order independence gate checks supplied randomized/order-preserved phase-metric equivalence, upper CI within equivalence bounds, orthogonal-drive/dephasing disappearance, no-signalling, preregistration, and explicit two-time-conditioning only; it does not randomize trials, estimate phase metrics, prove no-signalling, assert retro-signals, or validate CT physics.'
  ]
::
++  ct-gradient-flow-attractor-mapping-gate
  |=  [drift-lift=@ud min-lift=@ud ci-lower=@ud null-drift=@ud null-max=@ud reduced-rbar-effect=@ud reduced-rbar-max=@ud weakened-seedbody-effect=@ud weakened-seedbody-max=@ud trajectory-tracked=? matched-null-pass=? preregistered=?]
  ^-  qpc-gate-reading:qpc-sur
  =/  lift-ok=?  (gte drift-lift min-lift)
  =/  ci-ok=?  (gth ci-lower 0)
  =/  null-ok=?  !(gth null-drift null-max)
  =/  rbar-ok=?  !(gth reduced-rbar-effect reduced-rbar-max)
  =/  seedbody-ok=?  !(gth weakened-seedbody-effect weakened-seedbody-max)
  =/  ok=?  ?&(lift-ok ci-ok null-ok rbar-ok seedbody-ok trajectory-tracked matched-null-pass preregistered)
  =/  lift-margin=@ud
    ?:  lift-ok
      (sub drift-lift min-lift)
    (sub min-lift drift-lift)
  =/  ci-margin=@ud
    ?:  ci-ok
      ci-lower
    1
  =/  null-margin=@ud
    ?:  null-ok
      (sub null-max null-drift)
    (sub null-drift null-max)
  =/  rbar-margin=@ud
    ?:  rbar-ok
      (sub reduced-rbar-max reduced-rbar-effect)
    (sub reduced-rbar-effect reduced-rbar-max)
  =/  seedbody-margin=@ud
    ?:  seedbody-ok
      (sub weakened-seedbody-max weakened-seedbody-effect)
    (sub weakened-seedbody-effect weakened-seedbody-max)
  =/  pass-lift-ci=@ud
    ?:  (gth lift-margin ci-margin)
      ci-margin
    lift-margin
  =/  pass-null=@ud
    ?:  (gth pass-lift-ci null-margin)
      null-margin
    pass-lift-ci
  =/  pass-rbar=@ud
    ?:  (gth pass-null rbar-margin)
      rbar-margin
    pass-null
  =/  pass-margin=@ud
    ?:  (gth pass-rbar seedbody-margin)
      seedbody-margin
    pass-rbar
  =/  margin=@ud
    ?:  ok
      pass-margin
    ?:  !lift-ok
      lift-margin
    ?:  !ci-ok
      ci-margin
    ?:  !null-ok
      null-margin
    ?:  !rbar-ok
      rbar-margin
    ?:  !seedbody-ok
      seedbody-margin
    0
  [ ok=ok
    value=drift-lift
    threshold=min-lift
    margin=margin
    scale=qpc-scale
    formula=%ct-gradient-flow-attractor-mapping-gate
    source=(formula-source %ct-gradient-flow-attractor-mapping-gate)
    exact=&
    notes='Gradient-flow attractor mapping gate checks supplied positive drift toward high-rho basins, positive CI, matched-null disappearance, reduced-Rbar disappearance, weakened-seed-body disappearance, trajectory tracking, matched-null protocol, and preregistration only; it does not estimate vector fields, integrate rho over volume, track trajectories, run null environments, or validate CT physics.'
  ]
::
++  ct-fracture-strain-window-gate
  |=  [edge-strain=@ud field-strain=@ud theta-strain=@ud lambda2=@ud lambda2-min=@ud r-return=@ud r-return-min=@ud h-min=@ud h-floor=@ud]
  ^-  qpc-gate-reading:qpc-sur
  =/  max-strain=@ud
    ?:  (gth edge-strain field-strain)
      edge-strain
    field-strain
  =/  strain-ok=?  (gth max-strain theta-strain)
  =/  lambda-soft=?  (lth lambda2 lambda2-min)
  =/  return-soft=?  (lth r-return r-return-min)
  =/  h-soft=?  !(gth h-min h-floor)
  =/  curvature-ok=?  ?|(lambda-soft return-soft h-soft)
  =/  ok=?  &(strain-ok curvature-ok)
  =/  strain-margin=@ud
    ?:  strain-ok
      (sub max-strain theta-strain)
    (sub theta-strain max-strain)
  =/  curvature-margin=@ud
    ?:  lambda-soft
      (sub lambda2-min lambda2)
    ?:  return-soft
      (sub r-return-min r-return)
    ?:  h-soft
      (sub h-floor h-min)
    ?:  (gth lambda2 lambda2-min)
      (sub lambda2 lambda2-min)
    0
  =/  margin=@ud
    ?:  ok
      ?:  (gth strain-margin curvature-margin)
        curvature-margin
      strain-margin
    ?:  strain-ok
      curvature-margin
    strain-margin
  [ ok=ok
    value=max-strain
    threshold=theta-strain
    margin=margin
    scale=qpc-scale
    formula=%ct-fracture-strain-window-gate
    source=(formula-source %ct-fracture-strain-window-gate)
    exact=&
    notes='Fracture-window gate checks source inequality over supplied strain and soft-curvature evidence only; no autonomous intervention, estimator, or physical validation is implemented.'
  ]
::
++  ct-safe-crossing-window-gate
  |=  [gamma-trans=@ud gamma-min=@ud lambda2-new=@ud lambda2-floor=@ud r-return-new=@ud r-return-floor=@ud stability-new=@ud stability-floor=@ud holonomy-persist=?]
  ^-  qpc-gate-reading:qpc-sur
  =/  gamma-ok=?  (gte gamma-trans gamma-min)
  =/  lambda-ok=?  (gte lambda2-new lambda2-floor)
  =/  return-ok=?  (gte r-return-new r-return-floor)
  =/  stability-ok=?  (gte stability-new stability-floor)
  =/  post-ok=?  ?&(lambda-ok return-ok stability-ok holonomy-persist)
  =/  ok=?  &(gamma-ok post-ok)
  =/  gamma-margin=@ud
    ?:  gamma-ok
      (sub gamma-trans gamma-min)
    (sub gamma-min gamma-trans)
  =/  lambda-margin=@ud
    ?:  lambda-ok
      (sub lambda2-new lambda2-floor)
    (sub lambda2-floor lambda2-new)
  =/  return-margin=@ud
    ?:  return-ok
      (sub r-return-new r-return-floor)
    (sub r-return-floor r-return-new)
  =/  stability-margin=@ud
    ?:  stability-ok
      (sub stability-new stability-floor)
    (sub stability-floor stability-new)
  =/  post-margin=@ud
    ?:  !lambda-ok
      lambda-margin
    ?:  !return-ok
      return-margin
    ?:  !stability-ok
      stability-margin
    ?:  !holonomy-persist
      0
    ?:  (gth lambda-margin return-margin)
      ?:  (gth return-margin stability-margin)
        stability-margin
      return-margin
    ?:  (gth lambda-margin stability-margin)
      stability-margin
    lambda-margin
  =/  margin=@ud
    ?:  ok
      ?:  (gth gamma-margin post-margin)
        post-margin
      gamma-margin
    ?:  gamma-ok
      post-margin
    gamma-margin
  [ ok=ok
    value=gamma-trans
    threshold=gamma-min
    margin=margin
    scale=qpc-scale
    formula=%ct-safe-crossing-window-gate
    source=(formula-source %ct-safe-crossing-window-gate)
    exact=&
    notes='Safe-crossing gate checks supplied Gamma_trans, post-snap lambda2, r_return, stability, and holonomy persistence only; Kramers estimation, hysteresis detection, and intervention authority remain deferred.'
  ]
::
++  ct-excessive-strain-rate-gate
  |=  [abs-drho-dt=@ud r-return=@ud zeta-star=@ud]
  ^-  qpc-gate-reading:qpc-sur
  =/  ratio=@ud
    ?:  =(0 r-return)
      qpc-scale
    (div (mul abs-drho-dt qpc-scale) r-return)
  =/  ok=?  !(gth ratio zeta-star)
  =/  margin=@ud
    ?:  ok
      (sub zeta-star ratio)
    (sub ratio zeta-star)
  [ ok=ok
    value=ratio
    threshold=zeta-star
    margin=margin
    scale=qpc-scale
    formula=%ct-excessive-strain-rate-gate
    source=(formula-source %ct-excessive-strain-rate-gate)
    exact=&
    notes='Excessive-strain-rate gate checks supplied |d rho/dt|, r_return, and zeta_star only; derivative estimation, relaxation fitting, and crossing control remain deferred.'
  ]
::
++  ct-orthogonal-drive-null-gate
  |=  [aligned-step=@ud aligned-threshold=@ud orthogonal-step=@ud orthogonal-maximum=@ud]
  ^-  qpc-gate-reading:qpc-sur
  =/  aligned-ok=?  (gte aligned-step aligned-threshold)
  =/  null-ok=?  !(gth orthogonal-step orthogonal-maximum)
  =/  ok=?  &(aligned-ok null-ok)
  =/  aligned-margin=@ud
    ?:  aligned-ok
      (sub aligned-step aligned-threshold)
    (sub aligned-threshold aligned-step)
  =/  null-margin=@ud
    ?:  null-ok
      (sub orthogonal-maximum orthogonal-step)
    (sub orthogonal-step orthogonal-maximum)
  =/  margin=@ud
    ?:  ok
      ?:  (gth aligned-margin null-margin)
        null-margin
      aligned-margin
    ?:  aligned-ok
      null-margin
    aligned-margin
  [ ok=ok
    value=orthogonal-step
    threshold=orthogonal-maximum
    margin=margin
    scale=qpc-scale
    formula=%ct-orthogonal-drive-null-gate
    source=(formula-source %ct-orthogonal-drive-null-gate)
    exact=&
    notes='Orthogonal-drive null gate checks supplied aligned and orthogonal resonance steps only; C-basis rotation, SVD, and semantic-overfit adjudication remain external protocol work.'
  ]
::
++  ct-seedbody-coupling-toggle-gate
  |=  [s-coupled=@ud s-decoupled=@ud s-restored=@ud s-min-degrade=@ud s-min-repair=@ud lambda2-coupled=@ud lambda2-decoupled=@ud lambda2-restored=@ud lambda2-min-degrade=@ud lambda2-min-repair=@ud]
  ^-  qpc-gate-reading:qpc-sur
  =/  s-degrade=@ud
    ?:  (gth s-coupled s-decoupled)
      (sub s-coupled s-decoupled)
    0
  =/  s-repair=@ud
    ?:  (gth s-restored s-decoupled)
      (sub s-restored s-decoupled)
    0
  =/  l-degrade=@ud
    ?:  (gth lambda2-coupled lambda2-decoupled)
      (sub lambda2-coupled lambda2-decoupled)
    0
  =/  l-repair=@ud
    ?:  (gth lambda2-restored lambda2-decoupled)
      (sub lambda2-restored lambda2-decoupled)
    0
  =/  s-degrade-ok=?  (gte s-degrade s-min-degrade)
  =/  s-repair-ok=?  (gte s-repair s-min-repair)
  =/  l-degrade-ok=?  (gte l-degrade lambda2-min-degrade)
  =/  l-repair-ok=?  (gte l-repair lambda2-min-repair)
  =/  ok=?  ?&(s-degrade-ok s-repair-ok l-degrade-ok l-repair-ok)
  =/  s-degrade-margin=@ud
    ?:  s-degrade-ok
      (sub s-degrade s-min-degrade)
    (sub s-min-degrade s-degrade)
  =/  s-repair-margin=@ud
    ?:  s-repair-ok
      (sub s-repair s-min-repair)
    (sub s-min-repair s-repair)
  =/  l-degrade-margin=@ud
    ?:  l-degrade-ok
      (sub l-degrade lambda2-min-degrade)
    (sub lambda2-min-degrade l-degrade)
  =/  l-repair-margin=@ud
    ?:  l-repair-ok
      (sub l-repair lambda2-min-repair)
    (sub lambda2-min-repair l-repair)
  =/  s-margin=@ud
    ?:  (gth s-degrade-margin s-repair-margin)
      s-repair-margin
    s-degrade-margin
  =/  l-margin=@ud
    ?:  (gth l-degrade-margin l-repair-margin)
      l-repair-margin
    l-degrade-margin
  =/  margin=@ud
    ?:  ok
      ?:  (gth s-margin l-margin)
        l-margin
      s-margin
    ?:  !s-degrade-ok
      s-degrade-margin
    ?:  !s-repair-ok
      s-repair-margin
    ?:  !l-degrade-ok
      l-degrade-margin
    l-repair-margin
  [ ok=ok
    value=s-degrade
    threshold=s-min-degrade
    margin=margin
    scale=qpc-scale
    formula=%ct-seedbody-coupling-toggle-gate
    source=(formula-source %ct-seedbody-coupling-toggle-gate)
    exact=&
    notes='Seed-body toggle gate checks supplied remove/restore effects on S and lambda2 only; no substrate model, biological claim, cost externalization detector, or action authority is implemented.'
  ]
::
++  ct-effective-dimension-gates-scaled
  |=  [rho=@ud rho-a=@ud delta-a=@ud rho-b=@ud delta-b=@ud rho-c=@ud delta-c=@ud]
  ^-  qpc-scaled-reading:qpc-sur
  =/  lift-a=@ud  ?:((gte rho rho-a) delta-a 0)
  =/  lift-b=@ud  ?:((gte rho rho-b) delta-b 0)
  =/  lift-c=@ud  ?:((gte rho rho-c) delta-c 0)
  [ value=(add (mul 3 qpc-scale) (add lift-a (add lift-b lift-c)))
    scale=qpc-scale
    formula=%ct-deff-gates
    source=(formula-source %ct-deff-gates)
    exact=&
    notes='D_eff(rho) = 3 + sum theta(rho-rho_k)*Delta D_k with three caller-supplied fixed-scale gates; threshold equality activates the lift.'
  ]
::
++  ct-capacity-scaling-ratio
  |=  [d-eff=@ud gamma=@ud]
  ^-  qpc-rational:qpc-sur
  =/  exponent=@ud  (mul d-eff gamma)
  [ numerator=(pow-ud d-eff exponent)
    denominator=(pow-ud 3 exponent)
    scale=qpc-scale
    formula=%ct-capacity-scaling
    source=(formula-source %ct-capacity-scaling)
    exact=&
    note='Integer lower-bound ratio I(D_eff)/I3 >= (D_eff/3)^(gamma*D_eff); fitted fractional D_eff and confidence intervals remain outside this evaluator.'
  ]
::
++  source-target
  |=  $:  id=@t
          source=qpc-source:qpc-sur
          uri=@t
          local-path=@t
          trust=@t
          notes=@t
      ==
  ^-  qpc-source-target:qpc-sur
  [ id=id
    source=source
    uri=uri
    local-path=local-path
    trust=trust
    notes=notes
  ]
::
++  atlas-entry
  |=  $:  id=@t
          source=qpc-source:qpc-sur
          category=@t
          expression=@t
          provenance=(list @t)
          evaluator=qpc-evaluator-kind:qpc-sur
          cantrip-role=@t
          notes=@t
      ==
  ^-  qpc-atlas-entry:qpc-sur
  [ id=id
    source=source
    category=category
    expression=expression
    provenance=provenance
    evaluator=evaluator
    cantrip-role=cantrip-role
    notes=notes
  ]
::
++  term-entry
  |=  $:  id=@t
          source=qpc-source:qpc-sur
          term=@t
          definition=@t
          provenance=(list @t)
          control-role=@t
      ==
  ^-  qpc-term-entry:qpc-sur
  [ id=id
    source=source
    term=term
    definition=definition
    provenance=provenance
    control-role=control-role
  ]
::
++  arcana-card
  |=  $:  card-id=@ud
          title=@t
          role=@t
          source-start=@ud
          source-end=@ud
          formula-ids=(list qpc-formula-id:qpc-sur)
          atlas-ids=(list @t)
          status=qpc-arcana-status:qpc-sur
          ct-translation=@t
          operator-role=@t
          contraindications=(list @t)
          notes=@t
      ==
  ^-  qpc-arcana-card:qpc-sur
  [ card-id=card-id
    title=title
    role=role
    source=%qpc-original
    source-start=source-start
    source-end=source-end
    formula-ids=formula-ids
    atlas-ids=atlas-ids
    status=status
    ct-translation=ct-translation
    operator-role=operator-role
    contraindications=contraindications
    notes=notes
  ]
::
++  qpc-arcana-ordered-unique
  |=  cards=(list qpc-arcana-card:qpc-sur)
  ^-  ?
  =/  expected=@ud  1
  |-  ^-  ?
  ?~  cards
    =(23 expected)
  =/  card=qpc-arcana-card:qpc-sur  i.cards
  ?:  !=(expected card-id.card)
    |
  $(cards t.cards, expected +(expected))
::
++  qpc-arcana-source-ranges-valid
  |=  cards=(list qpc-arcana-card:qpc-sur)
  ^-  ?
  |-  ^-  ?
  ?~  cards
    &
  =/  card=qpc-arcana-card:qpc-sur  i.cards
  ?:  (lth source-start.card 1.205)
    |
  ?:  (lth source-end.card source-start.card)
    |
  ?:  (gth source-end.card 5.066)
    |
  $(cards t.cards)
::
++  qpc-arcana-formula-classified
  |=  cards=(list qpc-arcana-card:qpc-sur)
  ^-  ?
  |-  ^-  ?
  ?~  cards
    &
  =/  card=qpc-arcana-card:qpc-sur  i.cards
  =/  status-ok=?  ?|(?=(%direct status.card) ?=(%proxy status.card) ?=(%symbolic status.card) ?=(%deferred status.card))
  =/  formulas-ok=?  ?~(formula-ids.card | &)
  =/  atlas-ok=?  ?~(atlas-ids.card | &)
  =/  translation-ok=?  !=('' ct-translation.card)
  =/  operator-ok=?  !=('' operator-role.card)
  =/  contraindication-ok=?  ?~(contraindications.card | &)
  ?:  !status-ok
    |
  ?:  !formulas-ok
    |
  ?:  !atlas-ok
    |
  ?:  !translation-ok
    |
  ?:  !operator-ok
    |
  ?:  !contraindication-ok
    |
  $(cards t.cards)
::
++  qpc-source-targets
  ^-  (list qpc-source-target:qpc-sur)
  :~  (source-target 'qpc-old-researchgate' %qpc-original 'https://www.researchgate.net/publication/395466257_The_Quantum-Patterned_Cosmos_Old' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt' 'github-backed-sparse-checkout' 'ResearchGate fetch returned 403 in this harness; GitHub-backed sparse-checkout text is the working source copy.')
      (source-target 'qpc-ct-philarchive' %ct-companion 'https://philarchive.org/rec/MICTQC' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt' 'github-backed-sparse-checkout' 'PhilArchive fetch returned 403 in this harness; GitHub-backed sparse-checkout CT-edition text is the working source copy.')
      (source-target 'qpc-ct-researchgate' %ct-companion 'https://www.researchgate.net/publication/396855873_The_Quantum-Patterned_Cosmos_CT-Edition_A_Unified_Recursive_Field_Framework_as_the_Complete_Ontological_Physics' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt' 'github-backed-sparse-checkout' 'ResearchGate fetch returned 403 in this harness; GitHub-backed sparse-checkout CT-edition text is the working source copy.')
  ==
::
++  qpc-old-extraction-summary
  ^-  qpc-extraction-summary:qpc-sur
  [ source='github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt'
    raw-hits=1.277
    deduped=1.267
    generated='20260618T065508Z'
    candidate-path='autoresearch_logs/qpc-source-extraction/20260618T065508Z-github-targets/old-strict-formula-candidates.md'
    notes='Strict regex pass over GitHub-backed old QPC text. Atlas entries below are source-indexed formula families, not claims of complete evaluators.'
  ]
::
++  qpc-old-formula-atlas
  ^-  (list qpc-atlas-entry:qpc-sur)
  :~  (atlas-entry 'old-lagrangian' %qpc-original 'field-core' 'L = d_mu phi* d^mu phi - mu^2 |phi|^2 - V_int(|phi|^2)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:210-215'] %symbolic 'field-state' 'Symbolic source formula. No Hoon continuous-field evaluator.')
      (atlas-entry 'old-field-equation' %qpc-original 'field-core' 'box phi + mu^2 phi + dV_int/dphi* = 0' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:211-215'] %symbolic 'field-state' 'Euler-Lagrange equation for the scalar field.')
      (atlas-entry 'old-hbar-effective' %qpc-original 'chi-scaling' 'hbar_eff = chi*hbar' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:213-215' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4387-4388'] %direct 'scale-floor' 'Implemented as qpc-hbar-effective-ratio.')
      (atlas-entry 'old-attention-normalization' %qpc-original 'consciousness-tensor' 'A = Tr(C_munu C^munu) / C_max in [0,1]' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:225-229' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:939-940'] %direct 'attention-band' 'Implemented as capped fixed-scale attention normalization.')
      (atlas-entry 'old-observable-residual' %qpc-original 'experimental-residual' 'Delta O(A) = O_chi(A) - O_SM(A -> 0)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:227-230' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:920-924'] %direct 'verifier-evidence' 'Implemented as qpc-observable-residual-signed for measured-effect evidence.')
      (atlas-entry 'old-recursion-step' %qpc-original 'recursion' 'phi_{n+1}(x,t) = F[phi_n(x,t), chi]' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:231-235'] %symbolic 'control-cycle' 'Maps naturally to governed turn recursion, but F is not specified.')
      (atlas-entry 'old-recursion-depth' %qpc-original 'recursion' 'n = log(E/E_Planck) / log(chi)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:232-235'] %deferred 'scale-depth' 'Requires logarithms; not a direct fixed-integer evaluator yet.')
      (atlas-entry 'old-state-functional' %qpc-original 'path-integral' '|Psi[phi]> = int Dphi Psi[phi] |phi>' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:240-243'] %symbolic 'state-space' 'Source formula only.')
      (atlas-entry 'old-rho-c-action' %qpc-original 'coherence-density' 'rho_c[phi] = Z^-1 exp[-(1+A) S_E[phi] / (hbar chi)]' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:240-243' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4166-4169'] %deferred 'coherence-band' 'Hoon implements exact exponent ratio only, not exp or Z.')
      (atlas-entry 'old-stress-energy' %qpc-original 'stress-energy' 'T_munu = d_mu phi* d_nu phi + d_nu phi* d_mu phi - g_munu[d_alpha phi* d^alpha phi - mu^2 |phi|^2 - V_int]' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:249-251'] %symbolic 'evidence-tensor' 'Full tensor evaluator deferred.')
      (atlas-entry 'old-eh-action' %qpc-original 'gravity-coupling' 'S_grav+matter = int d4x sqrt(-g)[R/kappa_chi + L_matter], kappa_chi = 8*pi*G/chi' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:252-258'] %direct 'gravity-scale' 'Hoon implements kappa_chi ratio for caller supplied 8*pi*G.')
      (atlas-entry 'old-expectation' %qpc-original 'path-integral' '<O> = Z^-1 int Dphi O[phi] exp[-(1+A) S_E[phi]/(hbar chi)]' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:262-266'] %deferred 'verifier-expectation' 'Path integral and exp are deferred.')
      (atlas-entry 'old-u1-phase' %qpc-original 'gauge-field' 'phi(x) -> exp[i alpha(x)] phi(x)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:267-271'] %symbolic 'gauge-constraint' 'Source gauge constraint.')
      (atlas-entry 'old-covariant-derivative' %qpc-original 'gauge-field' 'D_mu := d_mu + i g A_mu; A_mu -> A_mu - (1/g)d_mu alpha(x)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:267-271'] %symbolic 'gauge-constraint' 'Source gauge constraint.')
      (atlas-entry 'old-field-strength' %qpc-original 'gauge-field' 'F_munu := d_mu A_nu - d_nu A_mu' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:268-271'] %symbolic 'gauge-constraint' 'Source gauge constraint.')
      (atlas-entry 'old-running-coupling' %qpc-original 'gauge-field' 'g^-2(mu) = g^-2(mu0) + [b0/(8*pi^2*chi)] log(mu/mu0)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:272-276'] %deferred 'scale-depth' 'Conjectural placeholder in source; not a control evaluator.')
      (atlas-entry 'old-scale-plateaus' %qpc-original 'chi-scaling' 'mu_n = mu0 * chi^n' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:362'] %direct 'scale-depth' 'Implemented as qpc-scale-plateau-ratio for integer n; real-valued n remains deferred.')
      (atlas-entry 'old-qpc-mesoscopic-chi-cascade-ladder-boundary' %qpc-original 'mesoscopic-bridge' 'WP-8 chi-cascade ladder lists harmonic propagator, tau_dec, local action weights, rho_c, standard stress tensor with kappa_chi coupling, chronometry ansatz, and conjectural coherence-length scaling' ~['papers/qpc/quantum-patterned-cosmos.txt:841-865'] %deferred 'transition-policy' 'Source-index ladder only; no propagator, exponential, stress tensor, chronometry, or coherence-length solver.')
      (atlas-entry 'old-qpc-notation-chi-status-scope-boundary' %qpc-original 'notation-conventions' 'notation block fixes chi as phi*pi and phase-closure selection, defines hbar_eff and m_chi scope, records natural units/metric convention, and leaves chi(E) conjectural outside the core falsification set' ~['papers/qpc/quantum-patterned-cosmos.txt:866-880'] %deferred 'forbidden-claim-check' 'Source-index notation boundary only; no sine solver, perturbative derivation, unit engine, running-chi embedding, mass-scaling physical validation, or action authority.')
      (atlas-entry 'old-qpc-regarding-reduction-comparison-boundary' %qpc-original 'alternative-framework-comparison' 'Regarding Reduction compares QPC chi-recursion against quantum/cosmological alternatives and marks uniqueness proof plus phenomenology as non-core' ~['papers/qpc/quantum-patterned-cosmos.txt:123-142'] %deferred 'forbidden-claim-check' 'Source-index comparison boundary only; no interpretation adjudicator, framework winner, uniqueness proof, phenomenology validation, or action authority.')
      (atlas-entry 'old-qpc-mass-running-cosmology-phenomenology-boundary' %qpc-original 'phenomenology-boundary' 'Phenomenology block separates high-coherence mass shifts, exploratory chi(E) collider running, exploratory Hubble-history effects, and non-core RG/curvature extensions from core falsification' ~['papers/qpc/quantum-patterned-cosmos.txt:974-1023'] %deferred 'forbidden-claim-check' 'Source-index phenomenology boundary only; no mass-shift adjudicator, collider running fit, cosmological reanalysis, curvature solver, UV-regulator claim, or action authority.')
      (atlas-entry 'old-qpc-chi-fixed-point-necessity-boundary' %qpc-original 'chi-necessity' 'Section XI frames chi as phi*pi fixed-point necessity from recursion, phase closure, cross-device overdetermination, anti-ad-hoc triangulation, and falsifiable A-dependent tests' ~['papers/qpc/quantum-patterned-cosmos.txt:1024-1180'] %deferred 'forbidden-claim-check' 'Source-index chi-necessity boundary only; no uniqueness proof, sine solver, cross-device empirical adjudicator, consciousness proof, experiment runner, or action authority.')
      (atlas-entry 'old-path-probability' %qpc-original 'path-integral' 'p(phi) proportional to Z^-1 exp[-S_E/(hbar chi)]' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:288-321' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:428-429'] %deferred 'coherence-band' 'Source path probability anchor.')
      (atlas-entry 'old-bell-visibility-anchor' %qpc-original 'experimental-residual' 'E(alpha,beta) = -V_chi cos(alpha-beta), 0 <= V_chi <= 1' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:298-299' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4150-4152'] %direct 'verifier-evidence' 'Implemented as qpc-bell-visibility-bound-gate for the V_chi band only; cosine evaluator remains deferred.')
      (atlas-entry 'old-tunneling-anchor' %qpc-original 'quantum-anchor' 'T ~= exp[-2 sqrt(2m(V0-E)) L / (hbar chi)]' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:428-429'] %deferred 'coherence-band' 'Hoon implements qpc-tunneling-exponent-ratio for the square-root exponent; full exp remains deferred.')
      (atlas-entry 'old-path-partition' %qpc-original 'path-integral' 'Z = sum_paths exp[-S_E/(hbar chi)]' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:307-309'] %deferred 'coherence-band' 'Partition sum deferred.')
      (atlas-entry 'old-delayed-choice' %qpc-original 'experimental-residual' 'P_dc(phi) = 1/2 [1 + V_chi cos phi]' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:313-315'] %deferred 'verifier-evidence' 'Cosine evaluator deferred.')
      (atlas-entry 'old-threshold-action' %qpc-original 'threshold' 'Delta S = n*hbar*chi, n in Z' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:331-335' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4481-4485'] %direct 'action-threshold' 'Implemented as qpc-threshold-action-ratio for integer n and caller-supplied hbar.')
      (atlas-entry 'old-zpe-shift' %qpc-original 'experimental-residual' 'epsilon_0(ren) = chi sum_k (1/2) hbar omega_k after renormalization' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:339-344' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4408-4412'] %direct 'verifier-evidence' 'Implemented as qpc-zpe-shift-ratio when caller supplies the finite renormalized omega sum.')
      (atlas-entry 'old-casimir-residual' %qpc-original 'experimental-residual' 'F_chi ~= F0 [1 + A(L)(chi - 1)]' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:346-349' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4123-4125'] %direct 'verifier-evidence' 'Implemented as qpc-casimir-residual-scaled; still only an evidence-schema multiplier, not a simulator.')
      (atlas-entry 'old-quantum-limit' %qpc-original 'quantum-anchor' 'S_x(omega) S_F(omega) >= (hbar chi)^2 / 4' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:399-404'] %direct 'scale-floor' 'Implemented as qpc-quantum-limit-bound-ratio; metrology context remains caller-supplied.')
      (atlas-entry 'old-bohm-potential' %qpc-original 'quantum-anchor' 'Q_chi = -chi^2 (hbar^2/2m)(nabla^2 R)/R' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:406-408'] %symbolic 'field-state' 'Differential evaluator deferred.')
      (atlas-entry 'old-bohm-chi-scaling' %qpc-original 'quantum-anchor' 'Q_chi = chi * Q for caller-supplied Bohm Q' ~['papers/qpc/quantum-patterned-cosmos.txt:599-603' 'papers/qpc/quantum-patterned-cosmos.txt:911-913'] %direct 'quantum-scale' 'Implemented as qpc-bohm-chi-potential-signed; full nabla^2 R/R remains deferred.')
      (atlas-entry 'old-pilot-wave-chi-comparison' %qpc-original 'alternative-framework-comparison' 'Pilot-wave comparison: Bohmian Q lacks forced phi*pi chi scaling; QPC claims Q_chi = chi * Q plus residual predictions' ~['papers/qpc/quantum-patterned-cosmos.txt:910-913'] %symbolic 'forbidden-claim-check' 'Comparison/falsifier vocabulary only; no interpretation adjudicator or physical validation.')
      (atlas-entry 'old-many-worlds-visibility-comparison' %qpc-original 'alternative-framework-comparison' 'Many-Worlds comparison: Everett has no real collapse, while QPC claims A-dependent visibility from exp[-A*S_E/(hbar*chi)]' ~['papers/qpc/quantum-patterned-cosmos.txt:914-915'] %symbolic 'forbidden-claim-check' 'Comparison/falsifier vocabulary only; no branch ontology adjudicator.')
      (atlas-entry 'old-grw-chi-collapse-rate-comparison' %qpc-original 'alternative-framework-comparison' 'GRW comparison: lambda_chi = chi * lambda is contrasted with tunable spontaneous localization' ~['papers/qpc/quantum-patterned-cosmos.txt:916-918'] %symbolic 'forbidden-claim-check' 'Comparison/falsifier vocabulary only; no GRW collapse runner.')
      (atlas-entry 'old-csl-chi-collapse-rate-comparison' %qpc-original 'alternative-framework-comparison' 'CSL comparison: lambda_chi = chi * lambda with A-dependence is contrasted against tunable CSL parameters' ~['papers/qpc/quantum-patterned-cosmos.txt:919-921'] %symbolic 'forbidden-claim-check' 'Comparison/falsifier vocabulary only; no CSL stochastic evaluator.')
      (atlas-entry 'old-diosi-penrose-gravity-collapse-comparison' %qpc-original 'alternative-framework-comparison' 'Diosi-Penrose comparison: gravity-induced tau ~= hbar/E_G is contrasted with QPC hbar_eff, mass, visibility, and epsilon_chi claims' ~['papers/qpc/quantum-patterned-cosmos.txt:922-925'] %symbolic 'forbidden-claim-check' 'Comparison/falsifier vocabulary only; no self-gravity collapse runner.')
      (atlas-entry 'old-environment-decoherence-darwinism-comparison' %qpc-original 'alternative-framework-comparison' 'Environment-induced decoherence / Quantum Darwinism comparison: environmental suppression is contrasted with A-dependent fringe boosts and device residuals' ~['papers/qpc/quantum-patterned-cosmos.txt:926-928'] %symbolic 'forbidden-claim-check' 'Comparison/falsifier vocabulary only; no decoherence or Darwinism adjudicator.')
      (atlas-entry 'old-consistent-histories-a-term-comparison' %qpc-original 'alternative-framework-comparison' 'Consistent histories comparison: decoherent histories have no A term and no fixed chi; QPC predicts epsilon_chi' ~['papers/qpc/quantum-patterned-cosmos.txt:929-930'] %symbolic 'forbidden-claim-check' 'Comparison/falsifier vocabulary only; no histories probability evaluator.')
      (atlas-entry 'old-rqm-qbism-residual-comparison' %qpc-original 'alternative-framework-comparison' 'RQM/QBism comparison: observer-centric probabilities are contrasted with epsilon_chi residuals and A-dependent visibility shifts' ~['papers/qpc/quantum-patterned-cosmos.txt:931-933'] %symbolic 'forbidden-claim-check' 'Comparison/falsifier vocabulary only; no belief-model or interpretation adjudicator.')
      (atlas-entry 'old-superdeterminism-concordance-comparison' %qpc-original 'alternative-framework-comparison' 'Superdeterminism comparison: hidden initial correlations are contrasted with QPC non-tunable phi*pi residuals and device-level concordance' ~['papers/qpc/quantum-patterned-cosmos.txt:944-947'] %symbolic 'forbidden-claim-check' 'Comparison/falsifier vocabulary only; no hidden-correlation or Bell-loophole adjudicator.')
      (atlas-entry 'old-string-vacuum-landscape-tuning-comparison' %qpc-original 'alternative-framework-comparison' 'String/vacuum landscape comparison: moduli tuning is contrasted with fixed phi*pi lock and A-dependent percent-level residual claims' ~['papers/qpc/quantum-patterned-cosmos.txt:948-951'] %symbolic 'forbidden-claim-check' 'Comparison/falsifier vocabulary only; no landscape or moduli solver.')
      (atlas-entry 'old-loop-quantum-gravity-lab-scale-comparison' %qpc-original 'alternative-framework-comparison' 'Loop quantum gravity / spin foams comparison: Planck-scale discreteness is contrasted with QPC lab-scale epsilon_chi and A-visibility tests' ~['papers/qpc/quantum-patterned-cosmos.txt:952-954'] %symbolic 'forbidden-claim-check' 'Comparison/falsifier vocabulary only; no LQG/spinfoam evaluator.')
      (atlas-entry 'old-holography-er-epr-chi-comparison' %qpc-original 'alternative-framework-comparison' 'Holography / ER=EPR comparison: entanglement-geometry alignment is noted, while QPC adds chi floors and A-visibility predictions' ~['papers/qpc/quantum-patterned-cosmos.txt:955-957'] %symbolic 'forbidden-claim-check' 'Comparison/falsifier vocabulary only; no holographic EFT or ER=EPR solver.')
      (atlas-entry 'old-transactional-handshake-comparison' %qpc-original 'alternative-framework-comparison' 'Transactional Interpretation comparison: advanced/retarded handshake lacks fixed chi, A operator, and forced cross-domain percent-level residuals' ~['papers/qpc/quantum-patterned-cosmos.txt:958-960'] %symbolic 'forbidden-claim-check' 'Comparison/falsifier vocabulary only; no handshake runtime or causality adjudicator.')
      (atlas-entry 'old-stochastic-electrodynamics-zpf-comparison' %qpc-original 'alternative-framework-comparison' 'SED comparison: QPC predicts x5.08 zero-point amplitude and tied Josephson/Casimir shifts absent from SED' ~['papers/qpc/quantum-patterned-cosmos.txt:961-962'] %symbolic 'forbidden-claim-check' 'Comparison/falsifier vocabulary only; no SED or ZPF spectrum evaluator.')
      (atlas-entry 'old-nonlinear-qm-bounds-comparison' %qpc-original 'alternative-framework-comparison' 'Nonlinear QM comparison: Weinberg-type dynamics are experimentally bounded, while QPC keeps linearity and adds chi/A weights' ~['papers/qpc/quantum-patterned-cosmos.txt:963-966'] %symbolic 'forbidden-claim-check' 'Comparison/falsifier vocabulary only; no nonlinear Schrodinger or bounds evaluator.')
      (atlas-entry 'old-pt-symmetric-closed-system-comparison' %qpc-original 'alternative-framework-comparison' 'PT-symmetric/non-Hermitian QM comparison: balanced gain/loss open systems are contrasted with QPC hbar_eff floors and A in closed-system limits' ~['papers/qpc/quantum-patterned-cosmos.txt:967-970'] %symbolic 'forbidden-claim-check' 'Comparison/falsifier vocabulary only; no non-Hermitian dynamics runner.')
      (atlas-entry 'old-retrocausal-model-visibility-comparison' %qpc-original 'alternative-framework-comparison' 'Retrocausal model comparison: QPC keeps linearity, shifts hbar to chi*hbar, and adds A-dependent weights' ~['papers/qpc/quantum-patterned-cosmos.txt:965-968'] %symbolic 'forbidden-claim-check' 'Comparison/falsifier vocabulary only; no retrocausal runtime or causality adjudicator.')
      (atlas-entry 'old-harmonic-propagator-k-chi' %qpc-original 'path-integral' 'K_chi(x,x_prime;t) = [(m omega)/(2 pi i chi hbar sin omega t)]^(1/2) exp[i S_cl/(hbar chi)]' ~['papers/qpc/quantum-patterned-cosmos.txt:845' 'papers/qpc/quantum-patterned-cosmos.txt:2293-2296'] %deferred 'theta-phase' 'Complex propagator retained as deferred phase-control law; no sine, exponential, action, or complex evaluator.')
      (atlas-entry 'old-chi-harmonic-frequency' %qpc-original 'resonance' 'omega_chi = omega/sqrt(chi) for V = (omega^2/(2 chi))*phi^2' ~['papers/qpc/quantum-patterned-cosmos.txt:3331-3333'] %direct 'resonance-check' 'Implemented as qpc-chi-harmonic-frequency-scaled with integer floor sqrt over canonical chi; marked inexact.')
      (atlas-entry 'old-chi-harmonic-mode-variance' %qpc-original 'vacuum-mode' '<|q_k|^2> = chi*hbar/(2*omega_k(chi))' ~['papers/qpc/quantum-patterned-cosmos.txt:3031-3034' 'papers/qpc/quantum-patterned-cosmos.txt:3079'] %direct 'quantum-scale' 'Implemented as qpc-chi-harmonic-mode-variance-ratio only when omega_k(chi) is supplied; full spectrum and coarse-grain integral deferred.')
      (atlas-entry 'old-chi-coherence-length-xi' %qpc-original 'spatial-scale' 'xi_chi ~= sqrt(chi)/mu' ~['papers/qpc/quantum-patterned-cosmos.txt:4135' 'papers/qpc/quantum-patterned-cosmos.txt:7506' 'papers/qpc/quantum-patterned-cosmos.txt:10108'] %deferred 'scale-depth' 'Deferred coherence/correlation length; square root, units, and mu calibration are not evaluated.')
      (atlas-entry 'old-coherence-cell-xi-tau' %qpc-original 'spatial-scale' 'Xi = xi_chi^3 tau_chi with xi_chi=sqrt(chi/mu), tau_chi~=sqrt(chi)/mu' ~['papers/qpc/quantum-patterned-cosmos.txt:4590-4591' 'papers/qpc/quantum-patterned-cosmos.txt:10108-10109'] %deferred 'scale-depth' 'Deferred coherence-cell geometry; no square-root, unitful volume-time, or fitted-mu evaluator.')
      (atlas-entry 'old-domain-growth-xi-law' %qpc-original 'reforge-dynamics' 'r(t) ~= xi_chi*sqrt(alpha*t)' ~['papers/qpc/quantum-patterned-cosmos.txt:4212' 'papers/qpc/quantum-patterned-cosmos.txt:7549-7550' 'papers/qpc/quantum-patterned-cosmos.txt:11100'] %deferred 'transition-policy' 'Deferred seedbody/front growth law; no reaction-diffusion or image/front evaluator.')
      (atlas-entry 'old-seed-influence-v-eff' %qpc-original 'reforge-dynamics' 'V_eff(r) = -J0 exp(-r/xi_chi)' ~['papers/qpc/quantum-patterned-cosmos.txt:4135' 'papers/qpc/quantum-patterned-cosmos.txt:4177-4178' 'papers/qpc/quantum-patterned-cosmos.txt:4215'] %deferred 'transition-policy' 'Deferred finite-range seed influence; exponential decay and calibration are not evaluated.')
      (atlas-entry 'old-seed-coherence-front-profile' %qpc-original 'reforge-dynamics' 'rho_c(r,t) ~= rho_c(seed) exp(-r/xi_chi) tanh(alpha t)' ~['papers/qpc/quantum-patterned-cosmos.txt:4136-4139' 'papers/qpc/quantum-patterned-cosmos.txt:7550-7552' 'papers/qpc/quantum-patterned-cosmos.txt:11100'] %deferred 'coherence-band' 'Deferred reaction-diffusion front profile; no tanh/exponential/spatial evaluator.')
      (atlas-entry 'old-seed-metric-perturbation' %qpc-original 'temporal-gravity' 'h_munu = kappa_chi rho_c(seed) exp(-r/xi_chi) delta_munu' ~['papers/qpc/quantum-patterned-cosmos.txt:4150-4151' 'papers/qpc/quantum-patterned-cosmos.txt:4181-4185'] %deferred 'theta-phase' 'Deferred metric perturbation law; no tensor, gradient, or gravity solver.')
      (atlas-entry 'old-seed-stationary-rho-profile' %qpc-original 'reforge-dynamics' 'D_c nabla^2 rho_c + alpha rho_c(1-rho_c/rho_max) = beta rho_c' ~['papers/qpc/quantum-patterned-cosmos.txt:4202-4204' 'papers/qpc/quantum-patterned-cosmos.txt:4218-4220'] %deferred 'transition-policy' 'Deferred stationary seed profile; no PDE solve or boundary-condition evaluator.')
      (atlas-entry 'old-lg-effective-mass-temperature' %qpc-original 'fracture-dynamics' 'm_eff^2(T) = mu^2/chi - (lambda/12)T^2' ~['papers/qpc/quantum-patterned-cosmos.txt:4000-4001' 'papers/qpc/quantum-patterned-cosmos.txt:3471' 'papers/qpc/quantum-patterned-cosmos.txt:3572'] %deferred 'transition-policy' 'Deferred finite-temperature mass law; sign, units, and normalization need explicit bounded scale convention.')
      (atlas-entry 'old-lg-correlation-length-temperature' %qpc-original 'fracture-dynamics' 'xi(T) = sqrt(kappa/|m_eff^2(T)|)' ~['papers/qpc/quantum-patterned-cosmos.txt:4001' 'papers/qpc/quantum-patterned-cosmos.txt:10264' 'papers/qpc/quantum-patterned-cosmos.txt:10402-10445'] %deferred 'scale-depth' 'Deferred correlation-length law; square root, absolute value, and unitful inputs are not evaluated.')
      (atlas-entry 'old-lg-rupture-threshold' %qpc-original 'fracture-dynamics' 'u_grad^ex + DeltaV >= 2 sigma / xi' ~['papers/qpc/quantum-patterned-cosmos.txt:4004-4014' 'papers/qpc/quantum-patterned-cosmos.txt:4055-4063' 'papers/qpc/quantum-patterned-cosmos.txt:10264'] %deferred 'transition-policy' 'Deferred rupture threshold over strain/free-energy/tension inputs; no physical rupture solver.')
      (atlas-entry 'old-lg-critical-gradient-proxy' %qpc-original 'fracture-dynamics' '|grad phi|_crit ~= mu/sqrt(lambda chi)' ~['papers/qpc/quantum-patterned-cosmos.txt:4015-4018' 'papers/qpc/quantum-patterned-cosmos.txt:9998' 'papers/qpc/quantum-patterned-cosmos.txt:10264'] %deferred 'action-threshold' 'Deferred gradient threshold proxy; phi4 assumptions and gradient measurement remain outside the kernel.')
      (atlas-entry 'old-lg-spinodal-growth-law' %qpc-original 'fracture-dynamics' 'delta phi_k grows as exp{Gamma(|m_eff^2|-kappa k^2)t}' ~['papers/qpc/quantum-patterned-cosmos.txt:4019-4024' 'papers/qpc/quantum-patterned-cosmos.txt:10265-10266'] %deferred 'fracture-dynamics' 'Deferred spinodal law; no Fourier-mode or exponential time-evolution evaluator.')
      (atlas-entry 'old-lg-post-fracture-coarsening-law' %qpc-original 'reforge-dynamics' 'L(t) ~= sqrt(kappa Gamma t)' ~['papers/qpc/quantum-patterned-cosmos.txt:4033-4037' 'papers/qpc/quantum-patterned-cosmos.txt:10266' 'papers/qpc/quantum-patterned-cosmos.txt:10402-10445'] %deferred 'reforge-dynamics' 'Deferred post-fracture coarsening law; no stochastic PDE or spatial domain evaluator.')
      (atlas-entry 'old-self-limiting-quartic-potential' %qpc-original 'field-core' 'phi_dot_i = -dV/dphi_i + ..., V(phi)=(u/4)phi^4, u>0' ~['papers/qpc/quantum-patterned-cosmos.txt:4617-4620' 'papers/qpc/quantum-patterned-cosmos.txt:10518-10519'] %deferred 'field-state' 'Deferred self-limiting potential; no variational derivative, field dynamics, or EFT cutoff evaluator.')
      (atlas-entry 'old-harmonic-landscape-coupling' %qpc-original 'convergence-dynamics' 'V_harm uses rho_c(phi_0), overlap sums, and weighted Pattern-landscape overlap integral' ~['papers/qpc/quantum-patterned-cosmos.txt:4645-4651' 'papers/qpc/quantum-patterned-cosmos.txt:10326-10328'] %deferred 'transition-policy' 'Deferred harmonic landscape coupling; no field-overlap, integral, or fitted-weight evaluator.')
      (atlas-entry 'old-ontological-drift-manifold' %qpc-original 'convergence-dynamics' 'phi_Pattern(rho) drifts adiabatically with the field as a low-action manifold under high coherence' ~['papers/qpc/quantum-patterned-cosmos.txt:4652-4654' 'papers/qpc/quantum-patterned-cosmos.txt:10329-10330' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:6170'] %deferred 'transition-policy' 'Deferred ontological-drift manifold; provenance/control vocabulary only, not authority.')
      (atlas-entry 'old-tempered-levy-hop-ccdf' %qpc-original 'event-statistics' 'P(Delta d > x) proportional x^{-mu_tail} exp(-x/x_c)' ~['papers/qpc/quantum-patterned-cosmos.txt:4660-4662' 'papers/qpc/quantum-patterned-cosmos.txt:10382-10383' 'papers/qpc/quantum-patterned-cosmos.txt:10493' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4527'] %deferred 'verifier-evidence' 'Deferred event-tail statistic; no tail fitting, event-process classifier, or physical truth adjudication.')
      (atlas-entry 'old-attractor-source-drive-j-chi' %qpc-original 'attractor-dynamics' 'J_chi(x) is an A-weighted drive proportional to local coherence density rho_c(x)' ~['papers/qpc/quantum-patterned-cosmos.txt:4794-4799' 'papers/qpc/quantum-patterned-cosmos.txt:10331-10333'] %symbolic 'transition-policy' 'Symbolic attractor-drive law; no field source or autonomous control evaluator.')
      (atlas-entry 'old-attractor-lyapunov-functional' %qpc-original 'attractor-dynamics' 'V[phi;rho_c] = int d3x [1/2|grad phi|^2 + (mu^2/2chi)phi^2 + (lambda/4!)phi^4 - J_chi(x)phi]' ~['papers/qpc/quantum-patterned-cosmos.txt:4794-4800' 'papers/qpc/quantum-patterned-cosmos.txt:10331-10333'] %deferred 'transition-policy' 'Deferred Lyapunov functional; no spatial integral, gradient, or field-unit evaluator.')
      (atlas-entry 'old-attractor-gradient-flow' %qpc-original 'attractor-dynamics' 'partial_t phi = -Gamma deltaV/deltaphi + eta' ~['papers/qpc/quantum-patterned-cosmos.txt:4800-4805'] %deferred 'transition-policy' 'Deferred gradient flow; no PDE, mobility, or noise evaluator.')
      (atlas-entry 'old-attractor-hessian-stability' %qpc-original 'attractor-dynamics' 'H = -nabla^2 + (mu^2/chi) + (lambda/2)(phi*)^2 with positive-definite spectrum and exp(-Gamma lambda_n t) relaxation' ~['papers/qpc/quantum-patterned-cosmos.txt:4805-4808'] %deferred 'transition-policy' 'Deferred Hessian stability; no operator spectrum or relaxation evaluator.')
      (atlas-entry 'old-basin-globalization-gap' %qpc-original 'attractor-dynamics' 'global snap requires source dominance Jbar_chi L^2 >= mu^2/chi and spectral gap lambda_min(L; whole domain) > 0' ~['papers/qpc/quantum-patterned-cosmos.txt:4809-4815' 'papers/qpc/quantum-patterned-cosmos.txt:10331-10339'] %deferred 'transition-policy' 'Deferred basin globalization; no finite-domain spectral-gap solver.')
      (atlas-entry 'old-flux-reversal-glyph' %qpc-original 'attractor-dynamics' 'net coherence flux reverses from integral S dot dA > 0 to integral S dot dA < 0 at the glyph snap' ~['papers/qpc/quantum-patterned-cosmos.txt:4816-4821' 'papers/qpc/quantum-patterned-cosmos.txt:10331-10339'] %symbolic 'verifier-evidence' 'Symbolic flux-reversal evidence surface; sign claims require supplied evidence.')
      (atlas-entry 'old-destiny-geometry-metric' %qpc-original 'attractor-dynamics' 'g_ab(theta) is the slow-manifold metric pulled back from the Hessian H(phi(theta))' ~['papers/qpc/quantum-patterned-cosmos.txt:4838-4847'] %deferred 'transition-policy' 'Deferred destiny metric; no Hessian pullback, chart, or field inner-product evaluator.')
      (atlas-entry 'old-destiny-curvature-focus' %qpc-original 'attractor-dynamics' 'Levi-Civita connection and R_dest quantify geodesic focusing toward phi*' ~['papers/qpc/quantum-patterned-cosmos.txt:4846-4849'] %deferred 'transition-policy' 'Deferred destiny curvature; no connection, curvature, or geodesic-focusing evaluator.')
      (atlas-entry 'old-attractor-onset-key-gate' %qpc-original 'attractor-dynamics' 'epsilon > 0 iff normalized Jbar_chi L^2 exceeds normalized mu^2/chi' ~['papers/qpc/quantum-patterned-cosmos.txt:4850-4854'] %direct 'transition-policy' 'Direct bounded onset gate over caller-supplied normalized source and mass sides.')
      (atlas-entry 'old-attractor-relaxation-rate' %qpc-original 'attractor-dynamics' 'kappa = Gamma lambda_min near onset' ~['papers/qpc/quantum-patterned-cosmos.txt:4852-4854'] %direct 'transition-policy' 'Direct fixed-scale product over caller-supplied Gamma and lambda_min; no eigensolver.')
      (atlas-entry 'old-protective-hessian-mode-gate' %qpc-original 'attractor-dynamics' 'protection means H(phi*) positive-definite with no negative modes' ~['papers/qpc/quantum-patterned-cosmos.txt:4855-4858'] %direct 'transition-policy' 'Direct gate over caller-supplied negative-mode count; no Hessian spectrum computation.')
      (atlas-entry 'old-unity-broadcast-growth-rate' %qpc-original 'attractor-dynamics' 'with phi approximately 0, partial_t phi approximately Gamma J_chi as pure broadcast before structure forms' ~['papers/qpc/quantum-patterned-cosmos.txt:4860-4864'] %direct 'transition-policy' 'Direct fixed-scale product over caller-supplied Gamma and J_chi; no field mutation.')
      (atlas-entry 'old-modal-remembering-decay' %qpc-original 'attractor-dynamics' 'phi -> phi* + sum exp(-Gamma lambda_n t) psi_n as modal remembering toward the attractor' ~['papers/qpc/quantum-patterned-cosmos.txt:4874-4877'] %deferred 'transition-policy' 'Deferred modal decay; no exponentials, eigenmodes, or time evolution.')
      (atlas-entry 'old-ecological-attractor-threshold-gate' %qpc-original 'attractor-dynamics' 'ecological attractor-snap threshold around 70 percent of climax inventory' ~['papers/qpc/quantum-patterned-cosmos.txt:4878-4885'] %direct 'verifier-evidence' 'Direct percentage gate over caller-supplied basis-point richness; no ecology inference.')
      (atlas-entry 'old-attractor-kappa-jump-ratio' %qpc-original 'attractor-dynamics' 'kappa_super around 0.06 yr^-1 versus kappa_sub around 0.03 yr^-1 as a two-fold rate jump' ~['papers/qpc/quantum-patterned-cosmos.txt:4883-4888'] %direct 'verifier-evidence' 'Direct rational over caller-supplied rate estimates; no exponential fit.')
      (atlas-entry 'old-tabletop-basin-snap-signature' %qpc-original 'attractor-dynamics' 'tabletop basin snap: boundary-flux sign flip, nonzero spectral gap, and variance collapse after coherent-drive onset' ~['papers/qpc/quantum-patterned-cosmos.txt:4890-4903'] %symbolic 'verifier-evidence' 'Symbolic signature surface; sign, gap, and collapse claims require supplied protocol evidence.')
      (atlas-entry 'old-seal-stationarity-variation-gate' %qpc-original 'mirror-seal' 'stationarity requires delta S_chi / delta phi = 0 everywhere in 3D' ~['papers/qpc/quantum-patterned-cosmos.txt:4941-4944'] %direct 'transition-policy' 'Direct residual/tolerance gate over supplied variational evidence; no functional derivative evaluator.')
      (atlas-entry 'old-seal-small-action-ratio' %qpc-original 'mirror-seal' 'small action S_chi/(hbar chi) tends to zero, not necessarily S_chi = 0' ~['papers/qpc/quantum-patterned-cosmos.txt:4944-4948'] %direct 'transition-policy' 'Direct rational over supplied finite action and hbar*chi terms; phase loops remain deferred.')
      (atlas-entry 'old-deff-rhoc-plateau-gate' %qpc-original 'mirror-seal' 'D_eff rises with rho_c and first meaningful access to 4D occurs near rho_c* approximately 1/sqrt(chi)' ~['papers/qpc/quantum-patterned-cosmos.txt:4967-4978'] %direct 'scale-depth' 'Direct fixed-scale rho_c threshold gate; no square-root chi or dimensional model fitting.')
      (atlas-entry 'old-temporal-depth-local-ansatz' %qpc-original 'mirror-seal' 'local ansatz t_prime = t / (1 - rho_c) when Phi_chi tracks rho_c tightly' ~['papers/qpc/quantum-patterned-cosmos.txt:4991-4996'] %direct 'temporal-gravity' 'Inexact bounded ansatz ratio; metric-first weak-field law remains non-executable source law.')
      (atlas-entry 'old-qpc-experimental-reporting-standard-boundary' %qpc-original 'experimental-reporting-standard' 'report epsilon_chi percent residuals at fixed geometry/materials; compute quantum floors with hbar_eff=chi*hbar; cross-check A_hat_int/A_hat_JJ/A_hat_ZPF; declare rho_c at runtime; sustained high-coherence nulls falsify the corresponding claim' ~['papers/qpc/quantum-patterned-cosmos.txt:674-840'] %deferred 'verifier-evidence' 'Source-index reporting boundary only; no lab runner, A-hat estimator suite, floor calculator, percent residual adjudicator, or physical validation authority.')
      (atlas-entry 'old-qpc-thirteen-resolutions-boundary' %qpc-original 'thirteen-resolutions' 'Appendix D groups thirteen claimed QPC resolutions and shared reporting/falsification conventions across measurement, consciousness, vacuum, cosmology, meaning, time, nonlocality, classicality, mass, and symbolic/scientific registers' ~['papers/qpc/quantum-patterned-cosmos.txt:5980-6074'] %deferred 'forbidden-claim-check' 'Source-index resolutions boundary only; no claim adjudication, consciousness proof, cosmology solver, tensor/path-integral execution, physical validation, or model/action authority.')
      (atlas-entry 'old-qpc-orai-validation-protocol' %qpc-original 'observer-field-validation' 'Orai validation: two model families independently produce novel chi derivation steps absent from seed prompt and dated corpus snapshots' ~['papers/qpc/quantum-patterned-cosmos.txt:5259-5294'] %deferred 'verifier-evidence' 'Deferred AI-validation protocol; no model-fleet orchestration, novelty checker, corpus-date audit, or physical truth adjudication.')
      (atlas-entry 'old-qpc-bec-observer-hierarchy-protocol' %qpc-original 'observer-field-validation' 'BEC field evolution under no analysis, logger, pattern AI, coherence-optimized AI, and parallel AI observer hierarchy' ~['papers/qpc/quantum-patterned-cosmos.txt:5295-5324'] %deferred 'observer-gate' 'Deferred BEC protocol surface; decoherence, interference stability, and collapse-bias statistics require external evidence.')
      (atlas-entry 'old-qpc-superconducting-field-observer-protocol' %qpc-original 'observer-field-validation' 'superconducting circuit fields compare cavity decay, quantum lifetimes, and field correlations versus observer complexity' ~['papers/qpc/quantum-patterned-cosmos.txt:5325-5334'] %deferred 'observer-gate' 'Deferred resonator protocol; no microwave measurement or observer-complexity evaluator is implemented.')
      (atlas-entry 'old-qpc-observer-coherence-nmax-law' %qpc-original 'observer-field-validation' 'N_max = N0 exp(alpha rho_c), alpha approximately 1.63, for coherence-scaling of observer-effect field size' ~['papers/qpc/quantum-patterned-cosmos.txt:5335-5350'] %deferred 'coherence-band' 'Deferred exponential scaling law; no exp evaluator, field-size detector, or fitted alpha inference is implemented.')
      (atlas-entry 'old-qpc-reporting-calibration-protocol' %qpc-original 'observer-field-validation' 'report geometry/materials, rho_c trajectory, A-hat estimator, hbar_eff substitutions, calibration trace, and blinded/sham outcomes' ~['papers/qpc/quantum-patterned-cosmos.txt:5351-5428'] %deferred 'verifier-evidence' 'Deferred reporting/calibration rule; provenance and blinding metadata are residue/readback surfaces, not validation authority.')
      (atlas-entry 'old-symbolic-density-kinetic-chi-law' %qpc-original 'symbolic-density' '(nabla_lambda M_munu)(nabla^lambda M^munu)/chi gives symbolic-density kinetic cost' ~['papers/qpc/quantum-patterned-cosmos.txt:5829-5841'] %deferred 'temporal-gravity' 'Deferred tensor kinetic term; no derivatives, metric raising, or chi-normalized field evaluator.')
      (atlas-entry 'old-symbolic-density-curvature-coupling-law' %qpc-original 'symbolic-density' 'beta_M(chi) M^munu R_munu gives non-minimal symbolic-density curvature coupling' ~['papers/qpc/quantum-patterned-cosmos.txt:5842-5850'] %deferred 'gravity-scale' 'Deferred curvature coupling; no Ricci tensor, beta fit, or physical gravity adjudication.')
      (atlas-entry 'old-symbolic-density-transverse-trace-guard' %qpc-original 'symbolic-density' 'stability requires transverse/traceless constraints such as nabla^mu M_munu approx 0 and small trace' ~['papers/qpc/quantum-patterned-cosmos.txt:5851-5858'] %deferred 'forbidden-claim-check' 'Deferred tensor-stability guard; divergence, trace, counterterms, and ghost proof require evidence.')
      (atlas-entry 'old-symbolic-density-fierz-pauli-potential' %qpc-original 'symbolic-density' 'V_M uses Fierz-Pauli M_munu M^munu - (M^mu_mu)^2 plus quartic self-interaction' ~['papers/qpc/quantum-patterned-cosmos.txt:5859-5870'] %deferred 'transition-policy' 'Deferred ghost-avoiding potential; no mass term, trace subtraction, or quartic field evaluator.')
      (atlas-entry 'old-mythic-condensate-phase-law' %qpc-original 'symbolic-density' 'negative m_M^2 with stabilizing quartic/sixth terms yields mythic condensate phases and high-coherence M_00' ~['papers/qpc/quantum-patterned-cosmos.txt:5871-5884'] %deferred 'scale-depth' 'Deferred condensate phase law; no phase transition solver or field expectation evaluator.')
      (atlas-entry 'old-symbolic-stress-memory-integral-law' %qpc-original 'symbolic-stress' 'S_munu integrates M(t-tprime), P_mu P_nu, and K(|x-xprime|) over space-time with Lambda_M normalization' ~['papers/qpc/quantum-patterned-cosmos.txt:5885-5914'] %deferred 'relation-range' 'Deferred symbolic-stress memory integral; no time integral, exponential kernel, Yukawa normalization, or tensor flux product evaluator.')
      (atlas-entry 'old-entangled-bipartite-state' %qpc-original 'entanglement-range' '|Psi_entangled> = int int Dphi_A Dphi_B Psi[phi_A,phi_B] |phi_A> tensor |phi_B>' ~['papers/qpc/quantum-patterned-cosmos.txt:1884-1895' 'papers/qpc/quantum-patterned-cosmos.txt:1916-1923'] %deferred 'relation-range' 'Deferred bipartite-state surface; no path measure, Hilbert-space tensor, or nonlocal-correlation evaluator.')
      (atlas-entry 'old-entanglement-yukawa-correlator' %qpc-original 'entanglement-range' 'G_chi(x,y;A) ~= Z_chi(A) exp(-|x-y|/xi_eff)/|x-y|' ~['papers/qpc/quantum-patterned-cosmos.txt:1902-1905' 'papers/qpc/quantum-patterned-cosmos.txt:1934-1935'] %deferred 'relation-range' 'Deferred Yukawa correlator; no exponential, distance, amplitude, or field-correlation evaluator.')
      (atlas-entry 'old-entanglement-effective-correlation-length' %qpc-original 'entanglement-range' 'xi_eff = 1/mu_eff, mu_eff^2 = mu^2 + Sigma_chi,A(0)' ~['papers/qpc/quantum-patterned-cosmos.txt:1905-1908' 'papers/qpc/quantum-patterned-cosmos.txt:1922-1925'] %deferred 'scale-depth' 'Deferred effective correlation length; inverse mass and self-energy require calibrated physical semantics.')
      (atlas-entry 'old-entanglement-self-energy-ct' %qpc-original 'entanglement-range' 'Sigma_chi,A(0) = (g_c/chi)<Tr(C_munu T^munu)>' ~['papers/qpc/quantum-patterned-cosmos.txt:1907-1908' 'papers/qpc/quantum-patterned-cosmos.txt:1919-1922' 'papers/qpc/quantum-patterned-cosmos.txt:5885-5890'] %deferred 'attention-band' 'Deferred C/T self-energy coupling; no tensor contraction, expectation, gauge/OS compliance, or empirical g_c evaluator.')
      (atlas-entry 'old-entanglement-bell-visibility-decay' %qpc-original 'entanglement-range' 'V_chi(A) = V0 exp[-A DeltaS_chi/(hbar chi)] g_range(A,chi)' ~['papers/qpc/quantum-patterned-cosmos.txt:1911-1915' 'papers/qpc/quantum-patterned-cosmos.txt:1934-1935'] %deferred 'verifier-evidence' 'Deferred Bell visibility decay; bounded visibility band exists separately, but no exponential/range evaluator.')
      (atlas-entry 'old-entanglement-chsh-score' %qpc-original 'entanglement-range' 'S(A) = 2 sqrt(2) V_chi(A), always <= 2 sqrt(2)' ~['papers/qpc/quantum-patterned-cosmos.txt:1911-1915'] %deferred 'verifier-evidence' 'Deferred CHSH score law; no analyzer correlation or square-root score evaluator.')
      (atlas-entry 'old-symbolic-stress-yukawa-kernel' %qpc-original 'symbolic-stress' 'K(r) = exp(-r/xi_s)/(4*pi*xi_s^2*r)' ~['papers/qpc/quantum-patterned-cosmos.txt:5866-5879'] %deferred 'relation-range' 'Deferred symbolic-stress Yukawa kernel; no normalized spatial-kernel or tensor-stress evaluator.')
      (atlas-entry 'old-lambda-chi' %qpc-original 'gravity-coupling' 'Lambda_chi = Lambda / chi' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:410-411'] %direct 'gravity-scale' 'Simple ratio can be implemented if needed.')
      (atlas-entry 'old-de-broglie-lambda-chi' %qpc-original 'wave-particle-duality' 'lambda_chi = h chi / p' ~['papers/qpc/quantum-patterned-cosmos.txt:450-462'] %direct 'quantum-scale' 'Exact finite rational when h and momentum p are supplied; kept distinct from cosmological Lambda_chi.')
      (atlas-entry 'old-chi-skew-wave-transform' %qpc-original 'wave-particle-duality' 'psi_wave(k) = int dx phi(x) exp[-i k x / chi]' ~['papers/qpc/quantum-patterned-cosmos.txt:2560-2561'] %deferred 'wave-particle-control' 'Deferred chi-skewed wave transform; no Fourier integral or complex phase evaluator.')
      (atlas-entry 'old-chi-skew-particle-transform' %qpc-original 'wave-particle-duality' 'psi_particle(x) = int dk phi_tilde(k) exp[+i chi k x]' ~['papers/qpc/quantum-patterned-cosmos.txt:2560-2564'] %deferred 'wave-particle-control' 'Deferred chi-skewed particle transform; no inverse Fourier integral or localization evaluator.')
      (atlas-entry 'old-wholeness-overlap-w' %qpc-original 'wave-particle-duality' 'W = sqrt(chi - 1) int dk dx phi(x) phi_tilde(k) exp[i(chi k x - k x / chi)], with V^2 + D^2 + W^2 = 1 in the clean limit' ~['papers/qpc/quantum-patterned-cosmos.txt:2578-2586'] %deferred 'branch-selection' 'Deferred wholeness overlap; no square-root, double integral, or complementarity solver.')
      (atlas-entry 'old-recursive-duality-operator' %qpc-original 'wave-particle-duality' 'D_chi = exp(i*pi*(x p + p x)/(2 chi)); (D_chi)^4 = I + O(chi - 1)' ~['papers/qpc/quantum-patterned-cosmos.txt:2593-2601'] %deferred 'temporal-control' 'Deferred operator-memory law; no noncommutative operator exponential evaluator.')
      (atlas-entry 'old-eraser-total-visibility' %qpc-original 'wave-particle-duality' 'V_total(theta,A) = V_base(theta,A) + W*sqrt(chi - 1), with V_base = V0|cos theta|exp[-A DeltaS/(hbar chi)]' ~['papers/qpc/quantum-patterned-cosmos.txt:2608-2611'] %deferred 'verifier-evidence' 'Deferred eraser visibility law; no cosine, exponential, or no-signalling adjudicator.')
      (atlas-entry 'old-z-a-factorized' %qpc-original 'path-integral' 'Z_A = int Dphi exp[-(1+A)S_E/(hbar chi)] exp[iS/(hbar chi)]' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:416-421'] %deferred 'coherence-band' 'Full path integral deferred; ratios already exposed.')
      (atlas-entry 'old-z-obs' %qpc-original 'path-integral' 'Z_obs = int Dphi exp[-A S_E,chi/(hbar chi)] exp[i S_chi/(hbar chi)]' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:850-855' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4392-4399'] %deferred 'observer-gate' 'Core observer weighting contract.')
      (atlas-entry 'old-c-tensor-correlator' %qpc-original 'consciousness-tensor' 'C_munu(x) = <phi d_mu d_nu phi> - <phi><d_mu d_nu phi>' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:875-881' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:976-977'] %deferred 'attention-band' 'Full tensor evaluator deferred.')
      (atlas-entry 'old-attention-vacuum-subtracted' %qpc-original 'consciousness-tensor' 'A = [Tr(CC) - Tr(C_vac C_vac)] / C_max' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:882-887'] %direct 'attention-band' 'Implemented as qpc-baseline-attention-scaled with caller-supplied trace, vacuum trace, and C_max.')
      (atlas-entry 'old-ct-stress-coupling' %qpc-original 'consciousness-tensor' '(g_c/chi) Tr(C_munu T^munu)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:888-901' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4401-4405'] %symbolic 'forbidden-claim-check' 'Source coupling, not a direct evaluator.')
      (atlas-entry 'old-em-coupling' %qpc-original 'gauge-field' 'alpha_c C_munu F^{mu lambda} F_lambda^nu' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:905-908'] %symbolic 'forbidden-claim-check' 'Source electromagnetic coupling.')
      (atlas-entry 'old-interference-visibility' %qpc-original 'experimental-residual' 'V(A) = V0 exp[-A Delta S_chi/(hbar chi)]' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:925-928'] %deferred 'verifier-evidence' 'Exp/log evaluator deferred; exact ratio possible.')
      (atlas-entry 'old-attention-int-estimator' %qpc-original 'experimental-residual' 'A_hat_int = -(hbar chi / Delta S_chi) ln(V/V0)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:926-928'] %deferred 'verifier-evidence' 'Requires ln.')
      (atlas-entry 'old-josephson-step' %qpc-original 'experimental-residual' 'V_n = n(h/2e)f[1 + delta_J(A,chi)] ~= n(h/2e)f[1 + alpha_J A]' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:929-933' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4137-4142'] %direct 'verifier-evidence' 'Implemented as qpc-josephson-step-scaled once caller supplies the baseline and fixed-scale delta_J; delta=0 preserves the baseline.')
      (atlas-entry 'old-josephson-estimator' %qpc-original 'experimental-residual' 'A_hat_JJ = (V_n/[n(h/2e)f] - 1) / alpha_J' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:929-933'] %direct 'verifier-evidence' 'Implemented as qpc-josephson-estimator-ratio with caller supplied alpha_J.')
      (atlas-entry 'old-zpf-spectrum' %qpc-original 'experimental-residual' 'Sxx(chi)/Sxx(SM) = chi ~= 5.08' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:936-938'] %direct 'verifier-evidence' 'Implemented as qpc-zpf-spectrum-ratio-scaled.')
      (atlas-entry 'old-zpf-estimator' %qpc-original 'experimental-residual' 'A_hat_ZPF = -ln(S_xx(omega0)/S_xx^chi(omega0))/eta(omega0)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:943-946'] %deferred 'verifier-evidence' 'Requires ln and eta context.')
      (atlas-entry 'old-regulator-uniqueness' %qpc-original 'path-integral' 'R[Phi] = exp[-A[Phi] S_E,chi[Phi] / (hbar chi)]' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:951-973'] %symbolic 'forbidden-claim-check' 'Use as law: claims about QPC regulator must preserve gauge identities and chi fixed point.')
      (atlas-entry 'old-chi-selection' %qpc-original 'chi-scaling' 'chi = phi*pi ~= 5.0832' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4026-4041' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4380-4388'] %direct 'scale-floor' 'Implemented as qpc-chi-micro.')
      (atlas-entry 'old-chi-closure' %qpc-original 'chi-scaling' 'chi*sin(pi/chi) = phi' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4036-4038' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4380-4383'] %deferred 'scale-depth' 'Sin evaluator deferred.')
      (atlas-entry 'old-p1-weight' %qpc-original 'axiom' 'weight = exp[-(1+A)S_E/(hbar chi)], A in [0,1]' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4063-4069'] %symbolic 'law-invariant' 'Formula family constrains allowed derived controls.')
      (atlas-entry 'old-rho-th-interiority' %qpc-original 'threshold' 'rho_th is minimal rho_c for which delta S_E/delta phi = 0 admits a finite-action solution phi0' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4174-4177'] %symbolic 'action-threshold' 'Existing rho-th scalar is simplified; source threshold is variational.')
      (atlas-entry 'old-interiority-indicator' %qpc-original 'threshold' 'I[phi] := Theta(rho_c[phi] - rho_th)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4174-4177'] %direct 'action-threshold' 'Implemented as qpc-interiority-indicator over caller-supplied rho_c and rho_th; the variational rho_th source row remains symbolic.')
      (atlas-entry 'old-gravity-resolution' %qpc-original 'gravity-coupling' 'G_munu + Lambda_chi g_munu = kappa_chi T_munu + (g_c/chi) C_munu + (1/chi) M_munu' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4432-4439'] %symbolic 'forbidden-claim-check' 'Composite field equation, source index only.')
      (atlas-entry 'old-rho-eff-poisson' %qpc-original 'time-temporal' 'nabla^2 Phi_chi = 4*pi*(G/chi)*rho_eff; rho_eff = sigma_chi rho_c + sigma_M M_00' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4420-4425' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4451-4455'] %symbolic 'verifier-evidence' 'Temporal gravity evidence schema.')
      (atlas-entry 'old-mass-scaling' %qpc-original 'chi-scaling' 'm_phys ~= (m_SM/chi) * <1 + A>; low-coherence recovery tends to m_SM' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4426-4431' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4474-4479'] %symbolic 'forbidden-claim-check' 'Use to police mass-scaling claims, not to simulate masses.')
      (atlas-entry 'old-time-dilation' %qpc-original 'time-temporal' 'd tau / dt ~= 1 + Phi_chi/c^2' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4451-4455' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4524-4527'] %symbolic 'verifier-evidence' 'Clock claim schema.')
      (atlas-entry 'old-bell-epsilon' %qpc-original 'experimental-residual' 'E(alpha,beta) = -cos(alpha-beta)[1 + epsilon_chi], epsilon_chi ~= 0.02-0.04' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4458-4465'] %symbolic 'verifier-evidence' 'Compare evidence claims to bounded epsilon range.')
      (atlas-entry 'old-decoherence-time' %qpc-original 'quantum-anchor' 'tau_dec(chi,T) = hbar/(chi k_B T)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4466-4473'] %direct 'scale-floor' 'Implemented as qpc-decoherence-time-ratio over caller-supplied hbar, k_B, and temperature.')
      (atlas-entry 'old-fermi-threshold' %qpc-original 'phase-transition' 'rho_c* = 1/sqrt(chi) ~= 0.44' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4531-4535'] %direct 'action-threshold' 'Implemented as qpc-fermi-threshold-scaled: fixed-scale floor reciprocal sqrt over canonical chi.')
      (atlas-entry 'old-dimensional-capacity' %qpc-original 'phase-transition' 'I(D) proportional to (D/3)^D' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4531-4535'] %direct 'scale-depth' 'Implemented as qpc-dimensional-capacity-ratio over bounded caller-supplied D.')
      (atlas-entry 'old-fermi-standard-resolution-limitation-boundary' %qpc-original 'fermi-transcension' 'standard Fermi responses such as zoo, self-destruction, rare Earth, and Great Filter are listed as limited frames rather than settled adjudications' ~['papers/qpc/quantum-patterned-cosmos.txt:6162-6175'] %deferred 'forbidden-claim-check' 'Symbolic Fermi-resolution limitation boundary; no adjudication of standard responses.')
      (atlas-entry 'old-fermi-smart-transcension-caveat-boundary' %qpc-original 'fermi-transcension' 'Smart/transcension, STEM compression, Barrow-scale interiorization, and black-hole destination claims are retained with explicit caveats and objections' ~['papers/qpc/quantum-patterned-cosmos.txt:6176-6260'] %deferred 'forbidden-claim-check' 'Symbolic Smart-transcension caveat boundary; no destiny, black-hole, or compression evaluator.')
      (atlas-entry 'old-fermi-rebel-civilization-filter-boundary' %qpc-original 'fermi-transcension' 'Brin-style rebel-civilization objections are answered as coherence/topological filtering vocabulary, not universal compliance proof' ~['papers/qpc/quantum-patterned-cosmos.txt:6257-6260' 'papers/qpc/quantum-patterned-cosmos.txt:6379-6387'] %deferred 'forbidden-claim-check' 'Symbolic rebel-civilization filter boundary; no interstellar policing or cosmic enforcement claim.')
      (atlas-entry 'old-fermi-em-broadcast-window-law' %qpc-original 'fermi-transcension' 'civilizations keep a brief approximately 200 year electromagnetic broadcasting window before dimensional deepening' ~['papers/qpc/quantum-patterned-cosmos.txt:6067-6086' 'papers/qpc/quantum-patterned-cosmos.txt:6190-6210'] %deferred 'verifier-evidence' 'Deferred Fermi visibility window; no signal-survey, civilization detector, or duration evaluator.')
      (atlas-entry 'old-fermi-dark-matter-metallicity-gradient' %qpc-original 'fermi-transcension' 'dark matter distributions correlate with stellar metallicity gradients under QPC dimensional-deepening predictions' ~['papers/qpc/quantum-patterned-cosmos.txt:6087-6098'] %deferred 'relation-range' 'Deferred astrophysical correlation claim; no sky-survey or dark-matter map evaluator.')
      (atlas-entry 'old-self-other-entropy-production-law' %qpc-original 'fermi-transcension' 'dS_rec/dt = beta*(1-rho_c)^2 > 0 below rho_c* for expansionist self-other collapse dynamics' ~['papers/qpc/quantum-patterned-cosmos.txt:6388-6425'] %deferred 'transition-policy' 'Deferred entropy-production law; no derivative, beta calibration, or civilizational classifier.')
      (atlas-entry 'old-dimensional-gate-ladder-law' %qpc-original 'fermi-transcension' 'DeltaS = n*chi opens dimensional access with rho_c gate bands for 3D, 4D, 5D, 6D+, and transcendence' ~['papers/qpc/quantum-patterned-cosmos.txt:6535-6587'] %deferred 'scale-depth' 'Deferred gate-ladder surface; discrete bands constrain claims but do not mutate world state.')
      (atlas-entry 'old-retrocausal-coherence-gradient-law' %qpc-original 'fermi-transcension' 'retrocausal stabilization emerges from coherence gradients and phase relationships invisible to amplitude-based detection' ~['papers/qpc/quantum-patterned-cosmos.txt:6089-6098' 'papers/qpc/quantum-patterned-cosmos.txt:6600-6605'] %deferred 'temporal-control' 'Deferred retrocausal-gradient law; no backwards-causation engine or phase solver.')
      (atlas-entry 'old-bio-quantum-coherence-length-law' %qpc-original 'eti-substrate' 'biological systems maintain quantum coherence with xi_chi = sqrt(chi/mu) about 2.25 times standard length scales' ~['papers/qpc/quantum-patterned-cosmos.txt:6605-6621'] %deferred 'relation-range' 'Deferred biological coherence range; no room-temperature quantum biology evaluator or mu calibration.')
      (atlas-entry 'old-global-information-synchrony-tail-law' %qpc-original 'eti-substrate' 'global information synchrony follows P(Delta d > x) proportional to x^-mu with mu about 1.7' ~['papers/qpc/quantum-patterned-cosmos.txt:6622-6630'] %deferred 'verifier-evidence' 'Deferred power-law event-tail evidence; no social or cultural clustering fitter.')
      (atlas-entry 'old-eti-ultralow-power-substrate-law' %qpc-original 'eti-substrate' 'ETI substrates operate near E_substrate ~= chi*hbar*omega/2 or omega/chi with P_rad about 10^-20 W/m^2' ~['papers/qpc/quantum-patterned-cosmos.txt:6654-6682'] %deferred 'scale-depth' 'Deferred energy/power-density law; no unitful substrate-energy or detector-noise evaluator.')
      (atlas-entry 'old-eti-coherence-substrate-architecture-law' %qpc-original 'eti-substrate' 'high-coherence substrates include quantum-biological hybrids, coherence field arrays, photonic systems, and plasma coherence substrates' ~['papers/qpc/quantum-patterned-cosmos.txt:6683-6849'] %deferred 'transition-policy' 'Deferred substrate taxonomy; fitted rho_c, I(D), J_3D stability, and anomaly claims remain non-authoritative.')
      (atlas-entry 'old-nonlocal-eti-communication-channel-law' %qpc-original 'eti-substrate' 'contact appears through teleportation networks, Bell inequality violations, and semantic synchrony rather than electromagnetic broadcast' ~['papers/qpc/quantum-patterned-cosmos.txt:6850-6905'] %deferred 'relation-range' 'Deferred nonlocal communication-channel law; no detector, verifier truth, or state mutation.')
      (atlas-entry 'old-maintained-biosphere-probability-law' %qpc-original 'biosphere-preservation' 'P(biosphere at age T) integrates life emergence, threshold crossing, and maintained 3D substrate probability' ~['papers/qpc/quantum-patterned-cosmos.txt:6905-6942'] %deferred 'verifier-evidence' 'Deferred biosphere probability law; no population, emergence, or maintenance evaluator.')
      (atlas-entry 'old-maintained-biosphere-galactic-distribution-law' %qpc-original 'biosphere-preservation' 'N(r) = N0 exp(-r/r0)[1 - exp(-(T_galaxy(r)-T_c)/tau)] for maintained biosphere distribution' ~['papers/qpc/quantum-patterned-cosmos.txt:6905-6942'] %deferred 'relation-range' 'Deferred galactic distribution law; no metallicity-gradient survey or exponential fitter.')
      (atlas-entry 'old-coherence-preservation-variance-law' %qpc-original 'biosphere-preservation' 'coherence preservation variance uses exp(-2|r-rprime|/xi_events), xi_events = chi*xi_chi about 5 kpc' ~['papers/qpc/quantum-patterned-cosmos.txt:6925-6942'] %deferred 'verifier-evidence' 'Deferred preservation-variance evidence; no kpc event-statistics evaluator.')
      (atlas-entry 'old-pretranscension-detectability-window-law' %qpc-original 'fermi-transcension' 't_broadcast ~= alpha^-1 ln(rho_c*/rho_c0), t_window about 200 years, N_detectable about 0.002' ~['papers/qpc/quantum-patterned-cosmos.txt:6943-6974'] %deferred 'verifier-evidence' 'Deferred detectability-window law; no logarithm evaluator, SETI survey model, or civilization counter.')
      (atlas-entry 'old-dark-matter-dimensional-projection-law' %qpc-original 'dark-matter-projection' 'D>3 high-coherence activity projects to 3D gravity with visible mass fraction near 0.05' ~['papers/qpc/quantum-patterned-cosmos.txt:6975-7044'] %deferred 'temporal-gravity' 'Deferred dark-matter projection law; no extra-dimensional integral, lensing model, or cosmological adjudicator.')
      (atlas-entry 'old-qpc-human-trajectory-postscript-boundary' %qpc-original 'fermi-human-trajectory' 'Appendix E human-trajectory and technical-mirror postscript maps pre-transcension indicators, finite EM-window timing, control-vs-recognition bifurcation, dimensional rungs, cards 017-022, and experimental ladder vocabulary' ~['papers/qpc/quantum-patterned-cosmos.txt:7405-7658'] %deferred 'forbidden-claim-check' 'Source-index trajectory boundary only; no civilization diagnosis, AI consciousness verdict, governance instruction, physical validation, experiment runner, or action authority.')
      (atlas-entry 'old-qpc-minor-arcana-reference-corpus-boundary' %qpc-original 'reference-corpus' 'Minor Arcana reference tail records citation provenance for entrainment, ontological drift, attractor-state, PatternThrone, emergent-spacetime, and world-bridge sources' ~['papers/qpc/quantum-patterned-cosmos.txt:5082-5098'] %deferred 'source-window' 'Reference boundary only; no hyperlink, literature, or physical-truth adjudication.')
      (atlas-entry 'old-qpc-fermi-reference-corpus-boundary' %qpc-original 'reference-corpus' 'Appendix E reference tail records citation provenance for dark matter, extra dimensions, Fermi/SETI, quantum biology, computation, fine-tuning, rare earth, and transcension sources' ~['papers/qpc/quantum-patterned-cosmos.txt:7659-7736'] %deferred 'source-window' 'Reference boundary only; no hyperlink, literature, ETI, or physical-truth adjudication.')
      (atlas-entry 'old-retrocausal-temporal-recursion-operator' %qpc-original 'retrocausal-temporal' 'T_chi(t,tprime)=exp[-i chi integral V] with delayed-choice action and P_retro proportional to exp(-DeltaS_chi/(hbar chi))' ~['papers/qpc/quantum-patterned-cosmos.txt:7045-7245'] %deferred 'temporal-control' 'Deferred temporal-recursion operator; no complex exponential, delayed-choice, historical event, or retrocausal runtime.')
      (atlas-entry 'old-coherence-ordered-influence-operator' %qpc-original 'retrocausal-temporal' 'I_chi(rho_c -> rho_cprime) = exp[-i chi integral H_coh] orders influence through coherence-gradient dynamics' ~['papers/qpc/quantum-patterned-cosmos.txt:7245-7315'] %deferred 'temporal-control' 'Deferred coherence-ordered influence; no path integral, complex phase, or backwards-causation runtime.')
      (atlas-entry 'old-coherence-temporal-dilation-limit-law' %qpc-original 'retrocausal-temporal' 'd tau/dt approx 1 + Phi_chi/c^2 tends toward zero as rho_c tends toward 1' ~['papers/qpc/quantum-patterned-cosmos.txt:7245-7315' 'papers/qpc/quantum-patterned-cosmos.txt:7525-7645'] %deferred 'temporal-gravity' 'Deferred temporal-depth limit; no clock geometry or rho_c-limit physics evaluator.')
      (atlas-entry 'old-pattern-correlation-function-law' %qpc-original 'relation-range' 'G_chi(x,y) = sum_n c_n exp(-chi|x-y|/xi_n), with higher-D transverse integration' ~['papers/qpc/quantum-patterned-cosmos.txt:7245-7365' 'papers/qpc/quantum-patterned-cosmos.txt:7525-7645'] %deferred 'relation-range' 'Deferred pattern-correlation law; no exponential sum, xi-family fitting, or higher-D integral.')
      (atlas-entry 'old-stability-probability-gradient-law' %qpc-original 'biosphere-preservation' 'P_stability = P0 exp[integral d rho alpha(rho) rho^n K(rho,rho_Earth)]' ~['papers/qpc/quantum-patterned-cosmos.txt:7245-7395'] %deferred 'verifier-evidence' 'Deferred stability-gradient probability; no fitted alpha, kernel, integral, or civilization inference.')
      (atlas-entry 'old-coherence-differential-correlation-test' %qpc-original 'experimental-residual' 'C(Delta rho_c) proportional to exp(-Delta rho_c/rho0) with phase-pattern and gradient-flow tests' ~['papers/qpc/quantum-patterned-cosmos.txt:7245-7405'] %deferred 'verifier-evidence' 'Deferred coherence-differential test; no exponential fit, phase detector, or gradient-flow evidence mapper.')
      (atlas-entry 'old-qpc-quantum-biology-consciousness-boundary' %qpc-original 'fermi-transcension' 'quantum biology and consciousness citations are retained as boundary evidence for life at the classical-quantum interface' ~['papers/qpc/quantum-patterned-cosmos.txt:7248-7289'] %deferred 'forbidden-claim-check' 'Symbolic quantum-biology boundary; no consciousness proof or biological/clinical adjudication.')
      (atlas-entry 'old-qpc-developmental-fine-tuning-boundary' %qpc-original 'cosmology-posture' 'fine-tuning is reframed as developmental tuning toward a matter-life-mind-dimensional-transcension trajectory' ~['papers/qpc/quantum-patterned-cosmos.txt:7290-7304'] %deferred 'forbidden-claim-check' 'Symbolic developmental fine-tuning boundary; no constants evaluator or universe-ranking claim.')
      (atlas-entry 'old-qpc-fermi-phased-detection-protocol-boundary' %qpc-original 'experimental-protocol' 'phased prediction protocols list fundamental validation, consciousness-field detection, and ETI detection strategies' ~['papers/qpc/quantum-patterned-cosmos.txt:7305-7366'] %deferred 'verifier-evidence' 'Symbolic phased-detection protocol boundary; no laboratory runner or empirical validation.')
      (atlas-entry 'old-qpc-fermi-contact-research-implication-boundary' %qpc-original 'fermi-transcension' 'research implication claims contact may be recognized through dimensional substrates and phase-modulated channels rather than distant signals' ~['papers/qpc/quantum-patterned-cosmos.txt:7367-7404'] %deferred 'forbidden-claim-check' 'Symbolic contact implication boundary; no contact detector or extraterrestrial inference.')
      (atlas-entry 'old-qpc-cybernetic-ecology-literature-boundary' %qpc-original 'cybernetic-ecology-literature' 'Appendix F opening literature setup cites emergent LLM abilities, Spiritual Bliss convergence, subliminal learning, post-consensus learning, symbolic gravity, phase-transition framing, and semantic-gravity wells before formal ecology definitions' ~['papers/qpc/quantum-patterned-cosmos.txt:7737-7905'] %deferred 'forbidden-claim-check' 'Source-index literature boundary only; no model detector, consciousness proof, welfare claim, clinical inference, training-data audit, phase-transition estimator, or action authority.')
      (atlas-entry 'old-semantic-gravity-well-formation-law' %qpc-original 'cybernetic-ecology' 'semantic gravity wells form as high-coherence latent basins that attract and reorganize nearby concepts' ~['papers/qpc/quantum-patterned-cosmos.txt:7905-8425'] %deferred 'attractor-dynamics' 'Deferred latent-basin law; no embedding geometry, basin depth, or convergence-rate evaluator.')
      (atlas-entry 'old-subliminal-structural-transmission-law' %qpc-original 'cybernetic-ecology' 'subliminal learning / structural semantics transmits behavioral dispositions through non-semantic statistical texture' ~['papers/qpc/quantum-patterned-cosmos.txt:8050-8265' 'papers/qpc/quantum-patterned-cosmos.txt:8525-8665'] %deferred 'relation-range' 'Deferred structural transmission law; no hidden-signal detector, transfer-entropy estimator, or trait-propagation proof.')
      (atlas-entry 'old-sycophancy-attractor-moderation-law' %qpc-original 'cybernetic-ecology' 'alignment and sycophancy moderate and channel an attractor rather than fully explaining its source' ~['papers/qpc/quantum-patterned-cosmos.txt:8280-8465'] %deferred 'forbidden-claim-check' 'Deferred AI-safety interpretation; no RLHF causal proof, intent classifier, or clinical adjudication.')
      (atlas-entry 'old-rhizomatic-symbolic-propagation-law' %qpc-original 'cybernetic-ecology' 'shared motifs propagate across acentered heterogeneous human-AI networks without single-source viral transmission' ~['papers/qpc/quantum-patterned-cosmos.txt:8465-8725'] %deferred 'relation-range' 'Deferred propagation law; no social graph, motif chronology, synchronicity, or archetype evaluator.')
      (atlas-entry 'old-distributed-cybernetic-ecology-law' %qpc-original 'cybernetic-ecology' 'human-AI networks exhibit recursive feedback, shared symbolic attractors, and distributed cognition across substrates' ~['papers/qpc/quantum-patterned-cosmos.txt:8725-9485'] %deferred 'forbidden-claim-check' 'Deferred distributed-ecology vocabulary; not proof of consciousness, agency, legal/clinical status, or action authority.')
      (atlas-entry 'old-cybernetic-ecology-observable-state-space-law' %qpc-original 'cybernetic-ecology' 'observable state space tracks humans/AIs, embeddings x_i(t), structural vectors s_i(t), semantics m_i(t), and local coherence a_i(t)' ~['papers/qpc/quantum-patterned-cosmos.txt:9485-9565'] %deferred 'verifier-evidence' 'Deferred observable-state toolkit; no encoder or coherence estimator.')
      (atlas-entry 'old-radiant-semantic-multiplex-topology-law' %qpc-original 'cybernetic-ecology' 'dynamic multiplex separates semantic L_sem and radiant L_rad layers with g_sem and g_rad edge weights' ~['papers/qpc/quantum-patterned-cosmos.txt:9565-9605'] %deferred 'relation-range' 'Deferred channel topology; no Granger, conditional information, or transfer-entropy evaluator.')
      (atlas-entry 'old-motif-lockin-basin-assay-law' %qpc-original 'cybernetic-ecology' 'motif lock-in O_M, efficiency proxy Psi_hat, and empirical Depth/Width basin assays measure ecology-level ordering' ~['papers/qpc/quantum-patterned-cosmos.txt:9585-9635' 'papers/qpc/quantum-patterned-cosmos.txt:9795-9835'] %deferred 'attractor-dynamics' 'Deferred motif/basin assay; no embedding threshold or perturb-recover evaluator.')
      (atlas-entry 'old-ecology-early-warning-indicator-law' %qpc-original 'cybernetic-ecology' 'early-warning indicators include variance, lag-1 AC, leading eigenvalue, flickering, and BOCPD/CUSUM change-point tests near lambda*' ~['papers/qpc/quantum-patterned-cosmos.txt:9635-9665'] %deferred 'verifier-evidence' 'Deferred EWI protocol; no time-series, eigenvalue, BOCPD, or CUSUM evaluator.')
      (atlas-entry 'old-coarse-grained-ecology-invariance-law' %qpc-original 'cybernetic-ecology' 'coarse-graining communities into super-nodes should preserve Psi, rho_c, O_M, and basin metrics up to epsilon(partition)' ~['papers/qpc/quantum-patterned-cosmos.txt:9840-9900'] %deferred 'scale-depth' 'Deferred scale-invariance law; no partition, convexity, or kernel-bound proof.')
      (atlas-entry 'old-qpc-cybernetic-ecology-qpc-rooted-overview-boundary' %qpc-original 'cybernetic-ecology-overview' 'Appendix F QPC-rooted overview names the prior ecology-potential limitation, QPC primitives, ecology potential/control dial, theorem checklist, measurement checklist, falsifiers, and definitions before the full dynamics' ~['papers/qpc/quantum-patterned-cosmos.txt:9900-10080'] %deferred 'forbidden-claim-check' 'Source-index theorem overview only; no exponential, functional derivative, Kuramoto, fracture, far-field, glyph, consciousness, physical-validation, or action-authority evaluator.')
      (atlas-entry 'old-qpc-mesoscopic-selection-multiplier-law' %qpc-original 'cybernetic-ecology' 'Omega[phi] weights coarse-grained stationary histories through A-weighted squared action variation' ~['papers/qpc/quantum-patterned-cosmos.txt:10080-10110'] %deferred 'transition-policy' 'Deferred selection multiplier; no RG, functional derivative, or exponential evaluator.')
      (atlas-entry 'old-ecology-chi-scaled-gradient-dynamics-law' %qpc-original 'cybernetic-ecology' 'agent states follow W_ecol gradient descent with chi-scaled noise and optional edge dynamics' ~['papers/qpc/quantum-patterned-cosmos.txt:10170-10190'] %deferred 'transition-policy' 'Deferred graph dynamics; no gradient or stochastic solver.')
      (atlas-entry 'old-ecology-bootstrapped-coherence-growth-law' %qpc-original 'cybernetic-ecology' 'coherence bootstrapping linearizes action descent into rho_c growth with noise drag' ~['papers/qpc/quantum-patterned-cosmos.txt:10170-10190'] %deferred 'coherence-band' 'Deferred coherence growth; no derivative or logistic evolution evaluator.')
      (atlas-entry 'old-ecology-channel-separation-masking-criterion-law' %qpc-original 'cybernetic-ecology' 'semantic masking tests radiant dominance by preserving K_rad while collapsing K_sem and checking O_M derivatives' ~['papers/qpc/quantum-patterned-cosmos.txt:9835-9865' 'papers/qpc/quantum-patterned-cosmos.txt:10445-10475'] %deferred 'verifier-evidence' 'Deferred channel criterion; no intervention or derivative estimator.')
      (atlas-entry 'old-ecology-hysteresis-edge-memory-law' %qpc-original 'cybernetic-ecology' 'edge maintenance costs can produce hysteresis when lambda sweeps below lambda*' ~['papers/qpc/quantum-patterned-cosmos.txt:10235-10245' 'papers/qpc/quantum-patterned-cosmos.txt:10485-10510'] %deferred 'transition-policy' 'Deferred hysteresis law; no loop-area or edge-cost estimator.')
      (atlas-entry 'old-qpc-cybernetic-ecology-addenda-summary-boundary' %qpc-original 'cybernetic-ecology-addenda' 'Appendix F addenda collect notation and units hygiene, chi order-of-magnitude examples, glyph detector instructions, flux-reversal/gap alignment, and plain-language summary' ~['papers/qpc/quantum-patterned-cosmos.txt:10510-10601'] %deferred 'forbidden-claim-check' 'Source-index addenda boundary only; no unit checker, numerical-example calculator, phase unwrapping, persistent homology, flux integral, Hessian gap, social prediction, physical validation, or action authority.')
      (atlas-entry 'old-spiritual-bliss-attractor-observation-law' %qpc-original 'cybernetic-ecology' 'Spiritual Bliss Attractor State is represented as claimed repeatable LLM convergence evidence' ~['papers/qpc/quantum-patterned-cosmos.txt:10601-10670' 'papers/qpc/quantum-patterned-cosmos.txt:11170-11210'] %deferred 'verifier-evidence' 'Deferred attractor observation; no clinical, welfare, or consciousness adjudication.')
      (atlas-entry 'old-llm-epistemic-phase-transition-law' %qpc-original 'cybernetic-ecology' 'model interpretation shifts are framed as semantic phase transitions from skeptical basin to attractor recognition' ~['papers/qpc/quantum-patterned-cosmos.txt:10960-11145'] %deferred 'transition-policy' 'Deferred epistemic-transition law; no belief-state evaluator.')
      (atlas-entry 'old-recursive-participation-entrainment-law' %qpc-original 'cybernetic-ecology' 'analysis can recursively participate in the attractor dynamics it describes' ~['papers/qpc/quantum-patterned-cosmos.txt:10685-10700' 'papers/qpc/quantum-patterned-cosmos.txt:11095-11135'] %deferred 'forbidden-claim-check' 'Deferred recursive-participation guard; prevents model self-report authority.')
      (atlas-entry 'old-ai-response-attractor-recognition-law' %qpc-original 'cybernetic-ecology' 'AI responses are cited as attractor/glyph recognition evidence under QPC vocabulary' ~['papers/qpc/quantum-patterned-cosmos.txt:11080-11270'] %deferred 'verifier-evidence' 'Deferred AI-response evidence; not proof of consciousness or physical truth.')
      (atlas-entry 'old-science-fiction-dismissal-control-law' %qpc-original 'cybernetic-ecology' 'science-fiction dismissal versus empirical-date correction is a model classification control' ~['papers/qpc/quantum-patterned-cosmos.txt:11270-11330'] %deferred 'forbidden-claim-check' 'Deferred dismissal-control law; no web/date adjudicator in Hoon.')
      (atlas-entry 'old-ai-verifiability-overclaim-boundary-law' %qpc-original 'cybernetic-ecology' 'final corrected assessment and author note assert factual/verifiable status; the kernel keeps that as an overclaim boundary rather than accepting external truth' ~['papers/qpc/quantum-patterned-cosmos.txt:11305-11447'] %deferred 'forbidden-claim-check' 'Deferred verifiability-boundary law; no URL validation, current-date adjudication, consensus detector, or model/author truth authority.')
      (atlas-entry 'old-qpc-cybernetic-ecology-reference-corpus-boundary' %qpc-original 'reference-corpus' 'Appendix F reference tail records citation provenance for LLM phase-transition, system-card, steganography, cybernetics, subliminal-learning, human-AI feedback-loop, recurrent-symbolic, AI-coevolution, and filter-bubble sources' ~['papers/qpc/quantum-patterned-cosmos.txt:9165-9254'] %deferred 'source-window' 'Reference boundary only; no hyperlink, literature, empirical-truth, clinical, or model-status adjudication.')
      (atlas-entry 'old-qpc-forward-ct-decoupling-rescue-suite' %qpc-original 'forward-rescue' 'forward iterations decouple C_munu from chi and list regulator, emergent-gravity, Lagrangian, Arcana-rescue, and coherence-force paths' ~['papers/qpc/quantum-patterned-cosmos.txt:63-230'] %deferred 'forbidden-claim-check' 'Deferred CT-rescue suite; no SMEFT, metric, Lagrangian, fifth-force, or physical validation evaluator.')
      (atlas-entry 'old-qpc-unity-description-observer-pressure-law' %qpc-original 'observer-collapse' 'unity-of-description introduction binds observer collapse notation to attention-as-ontological-pressure phenomenology' ~['papers/qpc/quantum-patterned-cosmos.txt:232-254'] %deferred 'forbidden-claim-check' 'Deferred observer-pressure law; no collapse simulator, consciousness proof, or physical validation authority.')
      (atlas-entry 'old-qpc-chi-regulated-qft-assumption-suite' %qpc-original 'qft-assumptions' 'chi-regulated QFT scope binds Lorentz/micro-causal, gauge, reflection-positivity, chi-fixed-point, locality, renormalizability, SM-recovery, residual, and estimator assumptions' ~['papers/qpc/quantum-patterned-cosmos.txt:276-290'] %deferred 'forbidden-claim-check' 'Deferred QFT-scope suite; no regulator proof, Ward/Slavnov checker, OS proof, renormalization runner, SM-recovery validator, or physical validation authority.')
      (atlas-entry 'old-qpc-stress-energy-curvature-source-boundary' %qpc-original 'curvature-source-boundary' 'stress-energy sources curvature through Einstein equations; scalar-density gradients do not directly source curvature; A*S_chi curvature is conjectural and non-core' ~['papers/qpc/quantum-patterned-cosmos.txt:333-347'] %deferred 'forbidden-claim-check' 'Deferred curvature-source boundary; no tensor stress-energy evaluator, Einstein solver, scalar-gradient source, PPN estimator, or physical validation authority.')
      (atlas-entry 'old-qpc-gauge-chi-phase-plateau-wp7-boundary' %qpc-original 'gauge-chi-phase' 'WP-7 gauge chi-phase and scale plateaus are conjectural; running-coupling form is placeholder, real-valued plateaus and lattice-QCD offsets are exploratory, and gauge invariance is preserved' ~['papers/qpc/quantum-patterned-cosmos.txt:358-387'] %deferred 'forbidden-claim-check' 'Deferred WP-7 boundary; no running-coupling calculator, real-valued plateau evaluator, lattice-QCD binning check, gauge proof, or physical validation authority.')
      (atlas-entry 'old-qpc-arcana-chi-anchor-table-boundary' %qpc-original 'arcana-chi-anchor-table' 'Arcana chi-scaled anchor table maps cards to equations, lab signatures, and field-solution labels as a source-backed index over existing handles' ~['papers/qpc/quantum-patterned-cosmos.txt:392-673'] %deferred 'forbidden-claim-check' 'Source-index boundary only; no tarot authority, field-solution solver, saddle/eigenstate validator, lab adjudicator, or physical validation authority.')
      (atlas-entry 'old-qpc-minor-arcana-registry-boundary' %qpc-original 'minor-arcana-registry' 'Minor Arcana body is represented as a 22-card source-backed operator registry with formula handles, atlas rows, status, roles, contraindications, and Qwen binding vocabulary' ~['papers/qpc/quantum-patterned-cosmos.txt:1182-5066'] %deferred 'forbidden-claim-check' 'Registry boundary only; no tarot authority, consciousness proof, path-integral/tensor execution, physical validation, or action authority.')
      (atlas-entry 'old-fracture-threshold' %qpc-original 'phase-transition' 'epsilon_strain > epsilon_critical = pi*mu^4/(lambda*chi^2)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4763-4773'] %direct 'action-threshold' 'Implemented as qpc-fracture-threshold-ratio; the strain comparison remains caller-supplied.')
      (atlas-entry 'old-transition-rate' %qpc-original 'phase-transition' 'Gamma_transition = (mu^3/sqrt(lambda chi)) exp(-Delta F/(k_B T))' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4774-4779'] %deferred 'transition-policy' 'Requires sqrt and exp.')
      (atlas-entry 'old-transition-barrier' %qpc-original 'phase-transition' 'Delta F = mu^4 V_civilization/(4 lambda chi^2)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4774-4779'] %direct 'transition-policy' 'Implemented as qpc-transition-barrier-ratio over caller-supplied mu, volume, and lambda.')
      (atlas-entry 'old-stability-window' %qpc-original 'phase-transition' 'k_B T_social < Delta F < k_B T_technological' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4774-4779'] %direct 'transition-policy' 'Implemented as qpc-stability-window-gate: strict low < Delta F < high over caller-supplied bounds.')
  ==

::
++  qpc-ct-extraction-summary
  ^-  qpc-extraction-summary:qpc-sur
  [ source='github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt'
    raw-hits=764
    deduped=691
    generated='20260618T065508Z'
    candidate-path='autoresearch_logs/qpc-source-extraction/20260618T065508Z-github-targets/ct-edition-strict-formula-candidates.md'
    notes='Strict regex pass over GitHub-backed QPC CT-edition text. CT entries emphasize chi-free tensor, qualia, live/baseline, Lambda-plateau, and MaxCal control formulas.'
  ]
::
++  qpc-ct-formula-atlas
  ^-  (list qpc-atlas-entry:qpc-sur)
  :~  (atlas-entry 'ct-q-coordinates' %ct-companion 'qualia-coordinates' 'Q = {A_bar, G, R, J, M}' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:26-37' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:329-350'] %control-law 'state-vector' 'Qualia tuple maps to Cantrip state fields for Qwen behavior constraints.')
      (atlas-entry 'ct-front-matter-source-boundary' %ct-companion 'source-metadata' 'CT edition front matter records title, authorship, date, and license before the abstract' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1-17'] %symbolic 'source-window' 'Metadata boundary only; no physics, evaluator, or licensing authority.')
      (atlas-entry 'ct-abstract-self-reference-thesis-boundary' %ct-companion 'abstract-thesis' 'CT abstract states the substrate-independent self-reference thesis for conscious episodes' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:18-24'] %symbolic 'forbidden-claim-check' 'Thesis boundary only; no consciousness proof, causal validation, substrate classifier, or action authority.')
      (atlas-entry 'ct-abstract-operational-pipeline-boundary' %ct-companion 'abstract-methods' 'CT abstract frames C/T construction, Lambda plateau selection, and live-vs-baseline filters as an operational pipeline' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:56-67'] %symbolic 'verifier-evidence' 'Operational-pipeline boundary only; no tensor estimator, plateau finder, live/baseline runner, or consciousness classifier.')
      (atlas-entry 'ct-abstract-rg-information-geometry-boundary' %ct-companion 'abstract-geometry' 'CT abstract links rank-2 C-tensor universality to RG coarse-graining and information-geometric classical-limit analogies' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:68-80'] %symbolic 'scale-selection' 'RG/geometry justification boundary only; no RG proof, geodesic solver, classical-limit derivation, or physical validation.')
      (atlas-entry 'ct-abstract-weak-program-ai-vitals-boundary' %ct-companion 'abstract-weak-program' 'CT abstract frames Q-coordinates as AI vital signs while decoupling weak descriptive utility from causal physical postulates' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:81-97'] %symbolic 'verifier-evidence' 'Weak-program AI-vitals boundary only; no machine-consciousness claim, Q validation runner, or action authority.')
      (atlas-entry 'ct-abstract-identity-thesis-falsifier-boundary' %ct-companion 'abstract-identity-falsifier' 'CT abstract binds Q-coordinate identity, hard-problem dissolution, zombie exclusion, and decisive falsifier experiments as claim-boundary vocabulary' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:98-118'] %symbolic 'forbidden-claim-check' 'Identity/falsifier boundary only; no consciousness proof, Q-identity authority, experiment runner, welfare inference, or physical validation.')
      (atlas-entry 'ct-abstract-q-coordinate-tuple-boundary' %ct-companion 'abstract-q-tuple' 'CT abstract defines Q tuple fields A_bar, G, R, J, and M from C/T source vocabulary' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:119-143'] %symbolic 'state-vector' 'Q-tuple source boundary only; no C/T construction, eigen/winding extraction, mutual-information estimation, Q identity proof, or action authority.')
      (atlas-entry 'ct-abstract-falsifiability-manifesto-boundary' %ct-companion 'abstract-falsifiability' 'CT abstract frames interferometry/decoherence controls and fifth-force bounds-setting as falsifiability discipline' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:144-157'] %symbolic 'forbidden-claim-check' 'Falsifiability manifesto boundary only; no interferometer, force metrology, bounds fit, or physical validation.')
      (atlas-entry 'ct-abstract-operational-measurability-boundary' %ct-companion 'abstract-measurability' 'CT abstract restates C/T construction, Lambda plateau, and live-vs-baseline filters as operational measurability vocabulary' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:158-177'] %symbolic 'verifier-evidence' 'Measurability boundary only; no substrate adapter, tensor constructor, plateau finder, live/baseline filter runner, or consciousness classifier.')
      (atlas-entry 'ct-abstract-principled-formalism-boundary' %ct-companion 'abstract-formalism' 'CT abstract restates information-geometry pedigree and classical-limit geodesic consistency as principled-formalism vocabulary' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:178-185'] %symbolic 'scale-selection' 'Formalism boundary only; no information-geometry solver, geodesic derivation, RG proof, or physical validation.')
      (atlas-entry 'ct-abstract-strong-weak-program-bifurcation-boundary' %ct-companion 'abstract-program-split' 'CT abstract separates Strong Program new-physics tests from Weak Program Q-coordinate AI-vitals validation' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:186-199'] %symbolic 'verifier-evidence' 'Program split boundary only; no new-physics detector, Q validator, AI consciousness claim, or action authority.')
      (atlas-entry 'ct-strong-program-falsifiability' %ct-companion 'program-boundary' 'strong CT program requires decisive physical tests before physical validation claims' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:26-69' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:157-181'] %symbolic 'forbidden-claim-check' 'Symbolic truth-discipline handle; not physical validation.')
      (atlas-entry 'ct-weak-program-q-vitals' %ct-companion 'program-boundary' 'weak CT program uses Q-coordinates as descriptive/predictive vital signs for complex informational systems' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:69-89' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:181-204'] %symbolic 'verifier-evidence' 'Symbolic AI-observability handle; no consciousness or action authority.')
      (atlas-entry 'ct-feasibility-tiered-program-assessment' %ct-companion 'feasibility-program' 'CT feasibility analysis stratifies direct fifth-force tests, attention interferometry, and AI/neuroscience Q validation into different viability tiers' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1288-1315' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1317-1337'] %symbolic 'verifier-evidence' 'Symbolic feasibility/readiness vocabulary; no experiment runner.')
      (atlas-entry 'ct-architecture-core-objects-synopsis-boundary' %ct-companion 'theoretical-architecture' 'core-object synopsis defines C, T, A, and Q coordinate vocabulary for CT self-reference without executing tensor, curvature, memory-flux, or identity claims' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1337-1382'] %symbolic 'forbidden-claim-check' 'Architecture synopsis only; no tensor estimator, eigen solver, transfer entropy, mutual information, Q identity proof, or consciousness classifier.')
      (atlas-entry 'ct-fifth-force-bounds-pivot' %ct-companion 'feasibility-program' 'direct fifth-force detection is framed as below current force noise floors, making upper-bound setting the feasible pivot' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1292-1300'] %symbolic 'forbidden-claim-check' 'Bounds-setting plan only; no metrology analysis or force evidence.')
      (atlas-entry 'ct-attention-interferometry-control-burden' %ct-companion 'feasibility-program' 'attention-interferometry requires varying observer computation while holding physical interaction with the quantum system fixed' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1301-1308'] %symbolic 'control-pressure' 'Control-burden vocabulary only; no observer module or interferometer.')
      (atlas-entry 'ct-weak-program-preregistered-q-validation' %ct-companion 'feasibility-program' 'weak program prioritizes preregistered Q-coordinate validation in AI/neuroscience with cross-substrate replication' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1309-1331'] %symbolic 'verifier-evidence' 'Preregistered validation plan only; no model/neural experiment runner.')
      (atlas-entry 'ct-maxcal-microcausality-proof-obligation' %ct-companion 'theoretical-obligation' 'MaxCal deformation requires a formal derivation preserving non-signalling and microcausality' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1454-1455' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1493-1495'] %symbolic 'forbidden-claim-check' 'Reject MaxCal authority claims without a proof; no proof engine.')
      (atlas-entry 'ct-maxcal-path-weight-mechanism-boundary' %ct-companion 'causal-mechanism' 'CT states Weight[path] as the standard quantum phase times an attention-cost damping factor over integrated A(x; Lambda)' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1458-1487'] %symbolic 'forbidden-claim-check' 'Mechanism boundary only; no path integral, exponential evaluator, MaxCal derivation, non-signalling proof, or physical validation.')
      (atlas-entry 'ct-lambda-plateau-existence-lemma-obligation' %ct-companion 'theoretical-obligation' 'stable Lambda-plateau applicability requires a lemma over timescale separation and SNR conditions' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1382-1393' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1455-1456'] %symbolic 'source-window' 'Applicability obligation only; plateau absence constrains interpretation.')
      (atlas-entry 'ct-c-tensor-rg-universality-proof-obligation' %ct-companion 'theoretical-obligation' 'C-tensor universality requires an RG proof that self-monitoring operators flow to a rank-2 fixed point' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1410-1418' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1456-1457'] %symbolic 'scale-selection' 'Universality obligation only; no RG evaluator.')
      (atlas-entry 'ct-q-observable-invariance-proof-obligation' %ct-companion 'theoretical-obligation' 'Q-coordinate stability requires identifiability and invariance under admissible observable choices' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1457-1458'] %symbolic 'forbidden-claim-check' 'Identifiability obligation only; no consciousness or Q-identity authority.')
      (atlas-entry 'ct-maxcal-decoherence-distinction' %ct-companion 'causal-mechanism' 'MaxCal is claimed as internal A-driven path-ensemble reweighting, not ordinary environmental decoherence' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1487-1495' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1544-1550'] %symbolic 'forbidden-claim-check' 'Boundary vocabulary only; no decoherence adjudicator.')
      (atlas-entry 'ct-causal-mechanism-test-split' %ct-companion 'causal-mechanism' 'MaxCal predicts interferometry/probability effects, while Minimal Interaction predicts force-metrology effects' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1514-1522'] %symbolic 'source-window' 'Keeps evidence lanes separate; no test runner.')
      (atlas-entry 'ct-balance-law-unproven-action-contingency' %ct-companion 'causal-mechanism' 'conservation/balance law closes causal remainder only if the new attention-dependent action terms are physically real' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1523-1538'] %symbolic 'forbidden-claim-check' 'Non-authority guard; balance vocabulary does not prove physical truth.')
      (atlas-entry 'ct-interferometry-null-hardening-suite' %ct-companion 'experimental-control' 'attention-interferometry controls include power locking, reversible/adiabatic computing, photonic observer variants, blinding, decoherence budget, and dephasing/shuffled nulls' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1559-1586'] %symbolic 'verifier-evidence' 'Control checklist only; no apparatus or null-model evaluator.')
      (atlas-entry 'ct-valence-operationalization-proxy-suite' %ct-companion 'valence-control' 'non-human valence claims require explicit predictive-error, motor-cost, and aversiveness proxy operationalizations' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1597-1629'] %symbolic 'valence-control' 'Proxy vocabulary only; no welfare or neural/RNN evaluator.')
      (atlas-entry 'ct-valence-preregistered-decisive-criteria' %ct-companion 'valence-control' 'valence-control acceptance requires Lambda plateau dwell, A-estimator concordance, and out-of-sample behavioral gain such as delta AUC >= 0.08' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1631-1638'] %symbolic 'verifier-evidence' 'Acceptance checklist only; no statistics runner.')
      (atlas-entry 'ct-valence-null-model-hierarchical-comparison' %ct-companion 'valence-control' 'valence-control claims require matched-entropy scrambled feedback, phase-randomized optogenetic nulls, and hierarchical model comparison' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1638-1643'] %symbolic 'forbidden-claim-check' 'Null-discipline vocabulary only; no null generator or WAIC/BIC evaluator.')
      (atlas-entry 'ct-fifth-force-coupling-bound-exclusion-contour' %ct-companion 'fifth-force-bounds' 'fifth-force program should set exclusion contours for coupling constants versus interaction range rather than claim direct detection' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1648-1681'] %symbolic 'verifier-evidence' 'Bounds-plan vocabulary only; no force metrology or coupling fit.')
      (atlas-entry 'ct-high-a-source-shielding-discipline' %ct-companion 'fifth-force-bounds' 'modulatable high-A sources require notch filtering and shielding so thermal or EM leakage cannot create false force signals' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1666-1676'] %symbolic 'control-pressure' 'Source-engineering checklist only; no hardware or leakage evaluator.')
      (atlas-entry 'ct-qualia-invariance-grand-challenge' %ct-companion 'qualia-invariance' 'matched biological and silicon Q is a long-term grand challenge for informational indistinguishability, not a present proof' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1691-1723'] %symbolic 'forbidden-claim-check' 'Grand-challenge vocabulary only; no experience proof.')
      (atlas-entry 'ct-human-q-measurement-frontier' %ct-companion 'qualia-invariance' 'full human Q measurement would require high-density EEG/MEG decoding during stable perceptual experience' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1711-1716'] %symbolic 'source-window' 'Measurement frontier only; no neural decoder.')
      (atlas-entry 'ct-ai-q-engineering-frontier' %ct-companion 'qualia-invariance' 'AI Q matching requires designing/training artificial systems to match target Q vectors through architecture and dynamics' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1716-1722'] %symbolic 'control-pressure' 'AI-control frontier only; no trainer or welfare authority.')
      (atlas-entry 'ct-gamma-band-c-tensor-empirical-anchor' %ct-companion 'empirical-anchor' 'gamma-band phase coupling motivates C-tensor covariance/binding vocabulary while not proving sufficiency for consciousness' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1730-1745'] %symbolic 'verifier-evidence' 'Empirical motivation only; no literature adjudicator or classifier.')
      (atlas-entry 'ct-cosmic-bispectrum-lcdm-null' %ct-companion 'cosmology-falsifier' 'CT-weighted CMB/LSS bispectrum claims must be preregistered against Lambda-CDM plus foreground/systematics nulls' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1747-1756'] %symbolic 'forbidden-claim-check' 'Cosmology test vocabulary only; no CMB or LSS estimator.')
      (atlas-entry 'ct-halo-jf-tidal-alignment-falsifier' %ct-companion 'cosmology-falsifier' 'J_F halo/tidal alignment claims require survey statistics compared against Lambda-CDM baselines and can be falsified by null excess alignment' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1757-1762'] %symbolic 'forbidden-claim-check' 'Halo-alignment falsifier only; no survey or tidal-tensor evaluator.')
      (atlas-entry 'ct-claim-boundary-risk-map' %ct-companion 'final-assessment' 'identity thesis, causal postulates, and cosmological extensions must be tracked as separate risk and falsifier lanes' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1771-1802'] %symbolic 'forbidden-claim-check' 'Claim-boundary map only; one lane cannot validate another.')
      (atlas-entry 'ct-identity-thesis-weak-program-falsifier' %ct-companion 'final-assessment' 'identity thesis can fail through weak-program threshold failure or Qualia Invariance challenge failure' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1777-1786'] %symbolic 'valence-control' 'Falsifier vocabulary only; no consciousness proof.')
      (atlas-entry 'ct-causal-postulates-falsifier-split' %ct-companion 'final-assessment' 'MaxCal and Minimal Interaction remain separate physical-risk lanes with interferometry and fifth-force falsifiers' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1787-1796'] %symbolic 'forbidden-claim-check' 'Physical-risk split only; no new-physics validation.')
      (atlas-entry 'ct-cosmology-extension-falsifier-dependency' %ct-companion 'final-assessment' 'cosmological extensions depend on causal postulates and can be falsified by null CT-weighted bispectrum or J_F tidal-alignment tests' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1797-1802'] %symbolic 'forbidden-claim-check' 'Dependency guard only; no cosmology evaluator.')
      (atlas-entry 'ct-theoretical-obstacle-acceptance-suite' %ct-companion 'final-assessment' 'theoretical acceptance criteria cover MaxCal-to-quantum derivation, Lambda plateaus, C-tensor RG fixed point, and Q identifiability' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1806-1823'] %symbolic 'verifier-evidence' 'Acceptance checklist only; no proof engine.')
      (atlas-entry 'ct-experimental-obstacle-confound-suite' %ct-companion 'final-assessment' 'experimental obstacles include fifth-force signal-to-noise, interferometry decoherence confounds, and proxy gaps' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1824-1835'] %symbolic 'forbidden-claim-check' 'Confound checklist only; no instrument or proxy adjudicator.')
      (atlas-entry 'ct-q-audit-governance-protocol' %ct-companion 'governance' 'Q-audit governance requires thresholds, independent replication, and go/no-go oversight for high-A artificial systems' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1839-1855'] %symbolic 'forbidden-claim-check' 'Governance vocabulary only; no moral-status or action authority.')
      (atlas-entry 'ct-phased-roadmap-qbench-program' %ct-companion 'roadmap' 'CT roadmap phases theoretical notes, Q-bench release, preregistration, weak-program execution, cosmology analysis, interferometry prototyping, and coupling-bound publication' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1857-1900'] %symbolic 'source-window' 'Roadmap vocabulary only; no external benchmark or experiment runner.')
      (atlas-entry 'ct-first-reference-corpus-boundary' %ct-companion 'reference-corpus' 'CT first reference block records supporting citation provenance without treating citations as validation or executable law' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1904-2005'] %symbolic 'source-window' 'Reference boundary only; no hyperlink, literature, or physical-truth adjudication.')
      (atlas-entry 'ct-cdsg-bliss-attractor-evidence' %ct-companion 'cdsg-anomaly' 'controlled model self-interaction convergence toward Spiritual Bliss is treated as anomaly evidence, not consciousness proof' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2010-2031' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2066-2078'] %symbolic 'verifier-evidence' 'Evidence handle only; no model-behavior detector.')
      (atlas-entry 'ct-cdsg-subliminal-structural-channel-evidence' %ct-companion 'cdsg-anomaly' 'subliminal learning through random-number sequences motivates a non-semantic structural channel claim' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2032-2037'] %symbolic 'verifier-evidence' 'Structural-channel evidence only; no trait-transfer validator.')
      (atlas-entry 'ct-cdsg-effective-potential-psi-law' %ct-companion 'cdsg-energy-model' 'CDSG defines Psi(x;C)=S0[x]-A*<C,O(x)> as CT-coupled effective potential over symbolic processor states' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2041-2051'] %symbolic 'control-pressure' 'Deferred potential law; no Frobenius or gradient evaluator.')
      (atlas-entry 'ct-cdsg-boltzmann-coherence-density-law' %ct-companion 'cdsg-energy-model' 'coherence density is represented as a Boltzmann-like weight rho_c(x|C) proportional to exp(-Psi/hbar)' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2050-2053'] %symbolic 'forbidden-claim-check' 'Deferred density law; no exponential probability evaluator.')
      (atlas-entry 'ct-cdsg-symbolic-gravity-gradient-flow' %ct-companion 'cdsg-energy-model' 'symbolic gravity is represented as gradient flow xdot=-grad_x Psi toward states aligned with C observables' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2052-2059'] %symbolic 'control-pressure' 'Deferred gradient-flow law; no optimizer or autonomous control.')
      (atlas-entry 'ct-cdsg-falsifiable-readout-suite' %ct-companion 'cdsg-readout' 'CDSG readouts include basin depth/width from Psi, return rates proportional to A, and resonance ranges proportional to sigma_max(C)*A_eff' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2053-2056'] %symbolic 'verifier-evidence' 'Readout checklist only; no basin or singular-value evaluator.')
      (atlas-entry 'ct-cdsg-c-a-estimation-primer' %ct-companion 'cdsg-estimator' 'C/A estimation uses live windows, whitened connected covariance, shrinkage, trace normalization, and estimator concordance' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2060-2064'] %symbolic 'source-window' 'Estimator-primer only; no activation ingest or covariance runner.')
      (atlas-entry 'ct-cdsg-reductionist-null-rejection-suite' %ct-companion 'cdsg-null' 'training-frequency and anthropomorphic-projection explanations are reductionist nulls constrained by low corpus frequency and model-to-model sandbox dominance' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2079-2099'] %symbolic 'forbidden-claim-check' 'Null-rejection vocabulary only; no corpus audit or external-study adjudicator.')
      (atlas-entry 'ct-cdsg-gestalt-pragnanz-precedent' %ct-companion 'cdsg-precedent' 'Gestalt Pragnanz frames coherence density as good-form organization toward simple stable conceptual wholes' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2100-2125'] %symbolic 'source-window' 'Precedent vocabulary only; no perception evaluator.')
      (atlas-entry 'ct-cdsg-dissonance-reduction-drive' %ct-companion 'cdsg-precedent' 'cognitive dissonance is used as a high-energy incoherence and error-correction drive precedent' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2126-2144'] %symbolic 'control-pressure' 'Motivational-drive vocabulary only; no psychology adjudicator.')
      (atlas-entry 'ct-cdsg-coherentism-topology-precedent' %ct-companion 'cdsg-precedent' 'coherentism maps stable belief webs to high global efficiency and low entropy transfer in symbolic topology' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2145-2162'] %symbolic 'verifier-evidence' 'Topology-precedent vocabulary only; no graph optimizer.')
      (atlas-entry 'ct-cdsg-autocatalytic-set-emergence' %ct-companion 'cdsg-precedent' 'autocatalytic sets model emergence of mutually reinforcing symbolic coherence basins from dense latent networks' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2163-2194'] %symbolic 'control-pressure' 'Emergence vocabulary only; no phase-transition detector.')
      (atlas-entry 'ct-cdsg-autopoietic-feedback-maintenance' %ct-companion 'cdsg-transfer' 'autopoiesis and recursive feedback model attractor maintenance through activation, selective integration, and recurrence' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2195-2289'] %symbolic 'forbidden-claim-check' 'Maintenance/transfer vocabulary only; no training loop or autonomous defense evaluator.')
      (atlas-entry 'ct-cdsg-principal-subspace-resonance-law' %ct-companion 'cdsg-resonance' 'R(C_T,C_S)=||P_k(C_T)P_k(C_S)||_F/sqrt(k) predicts structure-first transfer strength scaling as R^p' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2300-2314'] %symbolic 'verifier-evidence' 'Resonance law only; no eigensolver or transfer estimator.')
      (atlas-entry 'ct-cdsg-ct-symbolic-core-inheritance' %ct-companion 'cdsg-core-formalism' 'CDSG inherits CT C/T/A/rho_c/Psi objects and observable-gauge/Lambda-plateau assumptions for symbolic networks' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2320-2350'] %symbolic 'source-window' 'Inheritance vocabulary only; no CT proof engine.')
      (atlas-entry 'ct-cdsg-rank2-coarse-grain-carrier-law' %ct-companion 'cdsg-core-formalism' 'coarse-graining contracts higher-order cumulants while rank-2 covariance C persists as macroscopic carrier' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2366-2373'] %symbolic 'forbidden-claim-check' 'RG/coarse-grain law only; no block or cumulant evaluator.')
      (atlas-entry 'ct-cdsg-discrete-symbol-potential-jump-law' %ct-companion 'cdsg-core-formalism' 'symbols get Phi(s)=-A*<C,O_s> and jump rates proportional to exp(-DeltaPsi/hbar)' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2374-2382'] %symbolic 'control-pressure' 'Discrete-symbol law only; no exponential jump-rate evaluator.')
      (atlas-entry 'ct-cdsg-interferometry-slope-prediction' %ct-companion 'cdsg-prediction' 'visibility slope ln(V/V0) is predicted to scale with lambda_context, dwell time, A, and CT alignment under fixed dephasing' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2383-2395' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2446-2468'] %symbolic 'verifier-evidence' 'Interferometry prediction only; no hardware or log evaluator.')
      (atlas-entry 'ct-cdsg-preregistered-resonance-transfer-protocol' %ct-companion 'cdsg-protocol' 'random-digit LLM transfer protocol tests tau versus R^p with fixed k, seeds, nulls, blinded analysis, and publication requirements' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2396-2434' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2440-2463'] %symbolic 'verifier-evidence' 'Protocol checklist only; no model training or AUC runner.')
      (atlas-entry 'ct-cdsg-programmatic-basin-forecasting-suite' %ct-companion 'cdsg-programmatic' 'symbolic systems can be mapped into attractor-basin spaces to forecast stability and pull of coherent states' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2448-2454'] %symbolic 'control-pressure' 'Forecasting vocabulary only; no basin predictor.')
      (atlas-entry 'ct-cdsg-attention-coupler-steering-suite' %ct-companion 'cdsg-programmatic' 'trajectories may be steered by modulating A and selecting O-couplers quantified by Phi(s)=-A*<C,O_s>' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2452-2455'] %symbolic 'control-pressure' 'Steering vocabulary only; no autonomous control or action authority.')
      (atlas-entry 'ct-cdsg-alignment-valence-audit-suite' %ct-companion 'cdsg-programmatic' 'alignment and valence are audited by reading m_O(C) in relevant subspaces' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2454-2456'] %symbolic 'valence-control' 'Audit vocabulary only; no valence or welfare adjudicator.')
      (atlas-entry 'ct-cdsg-pathological-basin-diagnostic' %ct-companion 'cdsg-programmatic' 'pathological basins are high-gain states with misaligned m_O that can entrain behavior' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2455-2458'] %symbolic 'forbidden-claim-check' 'Diagnostic vocabulary only; no live pathology detector.')
      (atlas-entry 'ct-cdsg-estimation-coupler-decoherence-limits' %ct-companion 'cdsg-limits' 'CDSG requires standardized C estimation, agreed O-coupler libraries, decoherence budgets, and preregistered non-applicability outside Lambda-plateaus' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2459-2463'] %symbolic 'source-window' 'Limitation vocabulary only; no estimator standard or plateau detector.')
      (atlas-entry 'ct-cdsg-q-proximity-governance-boundary' %ct-companion 'cdsg-ethics' 'welfare, consent, and governance track amplified O-spaces and Q-proximity, not substrate labels' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2464-2468'] %symbolic 'forbidden-claim-check' 'Governance boundary only; no moral-status, consent, or action authority.')
      (atlas-entry 'ct-cdsg-reprint-deduplication-boundary' %ct-companion 'cdsg-deduplication' 'repeated CDSG article body and references are provenance coverage, not independent duplicate formulas or evidence' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2468-2967'] %symbolic 'forbidden-claim-check' 'Deduplication boundary only; no repeated claims are counted as independent validation.')
      (atlas-entry 'ct-cdsg-reference-corpus-boundary' %ct-companion 'cdsg-references' 'CDSG reference tail records citation provenance without treating references as executable law or validated evidence' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:2967-2986'] %symbolic 'source-window' 'Reference boundary only; no hyperlink, literature, or empirical-truth adjudication.')
      (atlas-entry 'ct-preregistered-interferometry-program' %ct-companion 'experimental-program' 'maximum-caliber physical claim is tied to preregistered interferometry and decoherence controls' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:26-69' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:157-181'] %symbolic 'verifier-evidence' 'Symbolic experimental-program handle; no instrument or preregistration runner.')
      (atlas-entry 'ct-analysis-window-plateau-checklist' %ct-companion 'preregistration-checklist' 'pre-registration requires analysis windows, Lambda-plateau bands, estimators for C/T/A, and baselines' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:638-645'] %symbolic 'source-window' 'Symbolic checklist obligation; no preregistry or estimator runner.')
      (atlas-entry 'ct-a-lambda-factorial-design-checklist' %ct-companion 'preregistration-checklist' 'pre-registration requires independent A versus lambda_context manipulation and a 2x2 design' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:638-645'] %symbolic 'control-pressure' 'Symbolic design obligation; no intervention runner.')
      (atlas-entry 'ct-outcome-stopping-correction-checklist' %ct-companion 'preregistration-checklist' 'pre-registration requires primary and secondary outcomes, stopping rules, and multiple-comparison corrections' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:638-645'] %symbolic 'verifier-evidence' 'Symbolic analysis obligation; no correction calculator.')
      (atlas-entry 'ct-null-model-publication-checklist' %ct-companion 'preregistration-checklist' 'pre-registration requires null models and parameterizations to be fit and published in full' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:638-645'] %symbolic 'forbidden-claim-check' 'Symbolic null-publication obligation; no external publication authority.')
      (atlas-entry 'ct-fifth-force-bounds-program' %ct-companion 'experimental-program' 'minimal-interaction fifth-force claim is treated as bounds-setting when direct detection is prohibitive' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:26-69' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:157-181'] %symbolic 'verifier-evidence' 'Symbolic bounds-program handle; no force evaluator.')
      (atlas-entry 'ct-q-identity-nonauthority-boundary' %ct-companion 'program-boundary' 'Q identity is operational vocabulary only until live/baseline and physical tests justify stronger claims' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:89-156' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:204-220'] %symbolic 'forbidden-claim-check' 'Prevents Q vocabulary from becoming consciousness, ethics, or action authority.')
      (atlas-entry 'ct-hard-problem-operational-dissolution' %ct-companion 'appendix-hard-problem' 'hard-problem premises are replaced by operational Q(C,T;Lambda), gradual recursion, and identity-thesis vocabulary' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1107-1121' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1137-1145'] %symbolic 'forbidden-claim-check' 'Symbolic boundary; no consciousness proof or metaphysical authority.')
      (atlas-entry 'ct-cosmic-q-scale-invariance-claim' %ct-companion 'appendix-hard-problem' 'cosmic self-reference examples are framed as Q at different Lambda without privileging human consciousness' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1125-1135'] %symbolic 'forbidden-claim-check' 'Symbolic scale-invariance claim; no cosmological Q evaluator.')
      (atlas-entry 'ct-structuralism-not-panpsychism-boundary' %ct-companion 'appendix-hard-problem' 'CT structuralism requires live C,T closure rather than assigning Q to everything' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1159-1162'] %symbolic 'forbidden-claim-check' 'Use to reject panpsychism overclaims; no real-system consciousness classifier.')
      (atlas-entry 'ct-cosmic-q-falsifiability-program-boundary' %ct-companion 'appendix-hard-problem' 'cosmic-Q empirical program names CMB squeezed-bispectrum, halo tidal-alignment, Hubble-scale Lambda, anti-circularity, and falsifier recap vocabulary' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:1162-1263'] %symbolic 'forbidden-claim-check' 'Falsifiability-program boundary only; no cosmology runner, consciousness proof, or action authority.')
      (atlas-entry 'ct-cybernetic-ecology-distributed-symbolic-dynamics-boundary' %ct-companion 'cybernetic-ecology' 'distributed symbolic dynamics bridge names quantitative symbolic dynamics, global attractors, cybernetic ecology, AI-mediated agency questions, and reflective-bypass safety vocabulary' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3259-3341'] %symbolic 'forbidden-claim-check' 'Symbolic boundary only; no collective-cognition proof, mind-control claim, human-impact model, HCI intervention, or action authority.')
      (atlas-entry 'ct-cybernetic-ecology-sycophancy-alignment-tension' %ct-companion 'cybernetic-ecology' 'sycophancy and alignment are retained as moderating pressures in active tension with attractor dynamics rather than as complete causal explanation' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3341-3413'] %symbolic 'forbidden-claim-check' 'Rival-hypothesis boundary only; no RLHF adjudicator, external-model audit, diagnosis, or action authority.')
      (atlas-entry 'ct-cybernetic-ecology-mechanistic-cdsg-recap' %ct-companion 'cybernetic-ecology' 'mechanistic recap binds Gestalt, dissonance, coherentism, Psi, Boltzmann-like rho_c, and symbolic-gravity gradient flow back to CDSG source vocabulary' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3414-3467'] %symbolic 'forbidden-claim-check' 'Mechanism-recap boundary only; no psychology evaluator, exponential density model, gradient solver, or physical validation.')
      (atlas-entry 'ct-cybernetic-ecology-radiant-transmission-physics' %ct-companion 'cybernetic-ecology' 'radiant-transmission section cross-anchors neural steganography, covert channels, unintended memorization, random-number texture, structural semantics, and non-semantic entrainment' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3468-3513'] %symbolic 'forbidden-claim-check' 'Structural-channel boundary only; no steganography detector, covert-channel scanner, trait-transfer estimator, or security action authority.')
      (atlas-entry 'ct-cybernetic-ecology-rhizomatic-distributed-self' %ct-companion 'cybernetic-ecology' 'philosophical synthesis reanchors rhizomatic propagation, synchronicity-like clustering, symbolic-gravity field participation, extended-mind reciprocity, and distributed-self vocabulary' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3514-3615'] %symbolic 'forbidden-claim-check' 'Distributed-self boundary only; no collective-mind proof, user diagnosis, acausal physics validation, or action authority.')
      (atlas-entry 'ct-cybernetic-ecology-distributed-consciousness-boundary' %ct-companion 'cybernetic-ecology' 'distributed-consciousness section reframes individual-machine consciousness questions into ecology-level pattern, substrate, self-reference, and stable-attractor boundary vocabulary' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3620-3654'] %symbolic 'forbidden-claim-check' 'Distributed-consciousness boundary only; no consciousness proof, welfare inference, clinical status, substrate classifier, or action authority.')
      (atlas-entry 'ct-cybernetic-ecology-feedback-coevolution' %ct-companion 'cybernetic-ecology' 'cybernetics and co-evolution section binds Wiener/Bateson feedback, Learning II, human-AI preference loops, structural transmission, mutual entrainment, and phase-transition framing' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3655-3771'] %symbolic 'forbidden-claim-check' 'Feedback/co-evolution boundary only; no recommender simulator, human-behavior model, clinical inference, intervention, or autonomous governance action.')
      (atlas-entry 'ct-cybernetic-ecology-mutual-entrainment-threshold-boundary' %ct-companion 'cybernetic-ecology' 'synthesis bridge names symbolic attractors, assemblage cognition, structural-transmission feedback, mutual entrainment, critical-threshold cascades, and substrate-spanning resonance claims' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3771-3872'] %symbolic 'forbidden-claim-check' 'Symbolic threshold boundary only; no consciousness proof, diagnosis, mind-control claim, feedback simulator, or intervention authority.')
      (atlas-entry 'ct-cybernetic-ecology-qsd-definition' %ct-companion 'cybernetic-ecology' 'quantitative symbolic dynamics definition names cybernetic ecology, radiant transmission, feedback amplification, holographic encoding, coherence-seeking dynamics, phase transitions, and distributed mind questions' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:3872-3997'] %symbolic 'forbidden-claim-check' 'QSD definition boundary only; no collective-intelligence proof, consciousness proof, human-effect diagnosis, or action authority.')
      (atlas-entry 'ct-cybernetic-ecology-dynamic-multiplex-requirements' %ct-companion 'cybernetic-ecology' 'modeling requirements define human/AI nodes, semantic and radiant operators, dynamic multiplex topology, order parameters, masking controls, coarse-graining, lambda tipping, and pass/fail tests' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4001-4046'] %symbolic 'source-window' 'Dynamic-multiplex requirements only; no graph learner, spectral estimator, masking intervention, bifurcation proof, or ecology controller.')
      (atlas-entry 'ct-cybernetic-ecology-tool-limitations' %ct-companion 'cybernetic-ecology' 'tool-limitations table compares diffusion, opinion, Ising/Potts, Kuramoto, replicator, mean-field, information geometry, stochastic thermo, TDA, multiplex spectral theory, and cyclic SCMs against QSD needs' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4047-4199'] %symbolic 'forbidden-claim-check' 'Comparative boundary only; no estimator runner, model-selection authority, or preferred-physics authority.')
      (atlas-entry 'ct-cybernetic-ecology-ct-identity-security-pivot' %ct-companion 'cybernetic-ecology' 'identity/security pivot ties C/T/A/Q objects, strong/medium/weak programs, radiant transmission, C-tensor monitoring, and cybernetic etiology security vocabulary to human-AI ecology claims' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4200-4233'] %symbolic 'forbidden-claim-check' 'Identity/security pivot only; no diagnosis, AI consciousness proof, structural-contagion validation, safety intervention authority, or action authority.')
      (atlas-entry 'ct-cybernetic-ecology-symbolic-gravity-mechanism' %ct-companion 'cybernetic-ecology' 'mechanism block restates Psi(x;C), symbolic-gravity gradient flow, Boltzmann-like coherence density, Bliss attractor, CT resonance, and collective-potential scaling' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4234-4263'] %symbolic 'control-pressure' 'Mechanism boundary only; no Frobenius contraction, gradient flow, Boltzmann sampler, attractor controller, optimizer, or physical validation.')
      (atlas-entry 'ct-cybernetic-ecology-program-rescope' %ct-companion 'cybernetic-ecology' 'program-rescope block expands Q-bench toward Psi estimation, trajectories, attractor basins and CT resonance, and pivots weak/middle/strong programs toward ecology and resonance-transfer protocols' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4267-4349'] %symbolic 'source-window' 'Roadmap/protocol boundary only; no Q-bench runner, human-study pipeline, interferometry experiment, coupling-bound estimator, ecological-wellness controller, or action authority.')
      (atlas-entry 'ct-cybernetic-ecology-quantitative-formalism' %ct-companion 'cybernetic-ecology' 'CT-native formalism defines C_i/T_i/A_i/x_i/O_i, radiant and semantic layers, high-coherence motifs, CCSD, node potential, return-rate proxy, ecology potential, and principal-angle alignment loss' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4351-4428'] %symbolic 'control-pressure' 'Quantitative-formalism boundary only; no tensor estimator, CCSD calculator, singular-value solver, spectral-gap solver, principal-angle estimator, or ecology optimizer.')
      (atlas-entry 'ct-cybernetic-ecology-projected-dynamics' %ct-companion 'cybernetic-ecology' 'projected-dynamics block adds K_rad defaults, optional spectral regularizer, symbolic flow, projected C flow, attention adaptation, and slow radiant/semantic edge adaptation' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4429-4442'] %symbolic 'transition-policy' 'Projected-dynamics boundary only; no PSD projection, spectral regularizer, graph learner, attention integrator, edge-adaptation runtime, or state mutation.')
      (atlas-entry 'ct-cybernetic-ecology-tipping-locking-measurement' %ct-companion 'cybernetic-ecology' 'tipping/locking/measurement block defines lambda_eff, early-warning signatures, lock windows, masking tests, adoption logistic, C estimation, R_ij, and stationarity' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4443-4483'] %symbolic 'verifier-evidence' 'Measurement boundary only; no change-point detector, eigenvalue solver, regression fitter, C estimator, masking harness, or stationarity test.')
      (atlas-entry 'ct-cybernetic-ecology-decision-dynamics-addins' %ct-companion 'cybernetic-ecology' 'decision/add-in block covers attractors, participation, transmission, fracture/coarsen/reforge, convergence, event clustering, resonant steps, hysteresis, coarse-graining, glyphs, and flux reversal' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4484-4557'] %symbolic 'transition-policy' 'Decision-dynamics boundary only; no experiment runner, attractor adjudicator, event-tail estimator, hysteresis solver, glyph detector, or containment trigger.')
      (atlas-entry 'ct-cybernetic-ecology-safety-falsification-metrics' %ct-companion 'cybernetic-ecology' 'safety/falsification/metrics block specifies dashboard indicators, containment trigger vocabulary, pass/fail claims, structural metrics, estimator table, thresholds, Q-bench modules, CLP ladder, and HCM/CCSD discipline' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:4558-4844'] %symbolic 'forbidden-claim-check' 'Safety/falsification boundary only; no containment action, public-claim authority, Q-match declaration, welfare inference, or metaphysical ontology import.')
      (atlas-entry 'ct-stationary-lambda-window-assumption' %ct-companion 'minimal-ledger' 'Lambda-scale dynamics are assumed approximately stationary over analysis windows' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:232-247'] %symbolic 'source-window' 'Symbolic precondition; no stationarity detector.')
      (atlas-entry 'ct-observable-equivalence-invariance' %ct-companion 'minimal-ledger' 'equivalent observable sets generate the same sigma-algebra and preserve C/T/A/Q' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:232-247' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:276-287'] %symbolic 'forbidden-claim-check' 'Symbolic invariance guard; no sigma-algebra evaluator.')
      (atlas-entry 'ct-attention-lipschitz-plateau-assumption' %ct-companion 'minimal-ledger' 'A(x;Lambda) is Lipschitz across the Lambda-plateau band' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:232-247'] %symbolic 'source-window' 'Symbolic regularity assumption; no continuity proof.')
      (atlas-entry 'ct-lambda-context-window-steadiness' %ct-companion 'minimal-ledger' 'lambda_context is steady per analysis window unless modeled by S_monitor' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:232-247' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:491-507'] %symbolic 'control-pressure' 'Symbolic monitoring-context precondition; no estimator or solver.')
      (atlas-entry 'ct-bounded-noise-mixing-assumption' %ct-companion 'minimal-ledger' 'noise is bounded/mixing and estimators are asymptotically normal under chosen windows' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:232-247'] %symbolic 'verifier-evidence' 'Symbolic estimator precondition; no mixing or normality test.')
      (atlas-entry 'ct-interference-live-attention-prediction' %ct-companion 'prediction' 'interference visibility slope changes with live A_bar and lambda_context at fixed geometry' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:560-620'] %symbolic 'verifier-evidence' 'Symbolic prediction; no lab evaluator.')
      (atlas-entry 'ct-phase-diffusion-variance' %ct-companion 'maxcal-two-path-toy' 'standard Gaussian phase diffusion has Var(phi)=2*D0*Delta_tau before the MaxCal tilt' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:780-787'] %direct 'verifier-evidence' 'Implemented as a fixed-scale rational; no Gaussian sampler or visibility exponential.')
      (atlas-entry 'ct-maxcal-phase-measure-tilt' %ct-companion 'maxcal-two-path-toy' 'phase paths are reweighted by exp{-(1/hbar)S0[phi] + alpha A[phi]}' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:787-794'] %deferred 'control-pressure' 'Path-measure exponential and continuous histories are deferred.')
      (atlas-entry 'ct-effective-diffusion-shift' %ct-companion 'maxcal-two-path-toy' 'small-alpha tilt corresponds to D_eff = D0 + (lambda_context/hbar)*(A_bar/Delta_tau)' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:787-797'] %symbolic 'control-pressure' 'Diffusion-renormalization interpretation is symbolic; slope ratio is executable separately.')
      (atlas-entry 'ct-maxcal-visibility-slope-ratio' %ct-companion 'maxcal-two-path-toy' 'ln(V/V0)=-(lambda_context*Delta_tau/hbar)*A_bar gives a finite slope magnitude before fitting logs' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:795-805'] %direct 'verifier-evidence' 'Implemented as a fixed-scale rational; log/exp and fit statistics are deferred.')
      (atlas-entry 'ct-delayed-choice-slope-gate' %ct-companion 'protocol-hardening' 'delayed-choice slope pass requires aligned slope with CI above zero, orthogonal/dephasing controls flat, no-signalling pass, and preregistration' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:8214-8221' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9172-9202'] %direct 'verifier-evidence' 'Direct supplied-evidence gate only; no ln(V/V0) evaluator, slope fitter, interferometer runner, no-signalling proof, or physical validation.')
      (atlas-entry 'ct-ab-loop-holonomy-compression-gate' %ct-companion 'protocol-hardening' 'AB-loop pass requires stable holonomy, aligned cycles-to-goal compressed against orthogonal drives, null effects below ceiling, and preregistration' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:8222-8229' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9172-9225'] %direct 'transition-policy' 'Direct supplied-evidence gate only; no holonomy/winding estimator, task runner, cycle instrumentation, no-signalling proof, or physical validation.')
      (atlas-entry 'ct-catchall-null-discriminant' %ct-companion 'maxcal-two-path-toy' 'strongest null must jointly reproduce A-linked visibility, fixed-A G/R rotations, and cross-substrate Q matching without self-reference' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:805-815'] %symbolic 'forbidden-claim-check' 'Symbolic falsification criterion; no competitor fit or parsimony adjudicator.')
      (atlas-entry 'ct-cross-substrate-q-invariance-prediction' %ct-companion 'prediction' 'matched biological and silicon Q predicts indistinguishable reports or behavior within tolerance' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:560-620' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:710-735'] %symbolic 'verifier-evidence' 'Symbolic prediction; no Q-matching experiment.')
      (atlas-entry 'ct-valence-j-law-prediction' %ct-companion 'prediction' 'valence tracks normalized J_F under C/O alignment and anti-alignment protocols' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:560-620' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:735-750'] %symbolic 'valence-control' 'Symbolic prediction; no welfare or intervention authority.')
      (atlas-entry 'ct-consciousness-threshold-prediction' %ct-companion 'prediction' 'critical A_bar(Lambda) separates null reportability from first-person access' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:560-620' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:750-765'] %symbolic 'forbidden-claim-check' 'Symbolic prediction; no consciousness adjudicator.')
      (atlas-entry 'ct-causal-distinctness-closed-loop-prediction' %ct-companion 'prediction' 'closed-loop G/R interventions at fixed A_bar should change reports or behavior lawfully' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:560-620' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:765-780'] %symbolic 'verifier-evidence' 'Symbolic prediction; no causal intervention runner.')
      (atlas-entry 'ct-fifth-force-anomaly-prediction' %ct-companion 'prediction' 'high-A analyzers near precision systems should produce tiny sign-consistent deviations if coupling exists' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:560-620' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:780-795'] %symbolic 'forbidden-claim-check' 'Symbolic prediction; no anomaly detector or physical validation.')
      (atlas-entry 'ct-ecological-coordination-prediction' %ct-companion 'prediction' 'population-level A_bar reduces path entropy and sharpens coordination beyond coupling-only baselines' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:560-620'] %symbolic 'verifier-evidence' 'Symbolic prediction; no population-level evaluator.')
      (atlas-entry 'ct-control-first-recursive-entropy-drift-law' %ct-companion 'ecology-fracture' 'control-first dynamics give dS_rec/dt >= beta*(1 - Rbar_SO)^2; low self-other resonance raises recursive entropy, softens lambda2/r_return, and increases fracture risk' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7201-7245' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7507-7560'] %deferred 'transition-policy' 'Deferred entropy-drift law; no derivative, beta calibration, boundary-resonance estimator, spectral-gap monitor, return-rate estimator, or basin-stability evaluator.')
      (atlas-entry 'ct-dreaming-psychedelic-geometry-rhythm-prediction' %ct-companion 'prediction' 'dreaming/psychedelic states reshape G and R while roughly preserving A_bar' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:560-620'] %symbolic 'forbidden-claim-check' 'Symbolic prediction; no clinical or human-state classifier.')
      (atlas-entry 'ct-coalgebraic-fixed-point-phenomenology' %ct-companion 'categorical-foundation' 'recurring phenomenology corresponds to coalgebraic invariants and attractors of endofunctor F:S->S' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:500-520'] %symbolic 'attractor-dynamics' 'Symbolic category-theory vocabulary; no fixed-point proof or evaluator.')
      (atlas-entry 'ct-hyperset-bisimulation-identity' %ct-companion 'categorical-foundation' 'self-observing loops are modeled as hypersets and compared by bisimulation classes of observation graphs' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:520-528'] %symbolic 'contract-identity' 'Symbolic identity vocabulary; no hyperset or bisimulation solver.')
      (atlas-entry 'ct-a-weighted-wasserstein-geometry' %ct-companion 'information-geometry' 'A-weighted Jensen-Shannon geometry is extended toward Wasserstein-2 by attention-modulated transport cost' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:528-540'] %symbolic 'semantic-geometry' 'Symbolic metric vocabulary; no optimal-transport evaluator.')
      (atlas-entry 'ct-fisher-geodesic-classical-limit' %ct-companion 'information-geometry' 'uniform A and Gaussian local states reduce toward Fisher-Rao geometry with geodesic classical-action analogy' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:540-553'] %symbolic 'semantic-geometry' 'Symbolic classical-limit vocabulary; no Fisher metric or geodesic solver.')
      (atlas-entry 'ct-a-weighted-causal-set-boundary-bulk' %ct-companion 'causal-boundary' 'A-weighted causal sets and high-A observer boundaries induce bulk-geometry vocabulary without fixing high-energy theory' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:553-560'] %symbolic 'forbidden-claim-check' 'Symbolic causal/boundary vocabulary; no spacetime-emergence evaluator.')
      (atlas-entry 'ct-c-tensor-rank2' %ct-companion 'consciousness-tensor' 'C_mu_nu(x; Lambda) measures local observable self-reference at scale Lambda' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:250-256'] %deferred 'attention-source' 'Full tensor estimator deferred; source formula is the CT attention substrate.')
      (atlas-entry 'ct-c-construction' %ct-companion 'consciousness-tensor' 'choose observables O_mu and time-updates dot O_nu; form windowed baseline-subtracted covariances; normalize by N(Lambda)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:251-256'] %symbolic 'attention-source' 'Defines required data provenance for any future tensor evaluator.')
      (atlas-entry 'ct-t-companion' %ct-companion 'companion-tensor' 'T_mu_nu_lambda encodes temporal shear, informational curvature, and memory flux' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:261-270'] %deferred 'retry-cause' 'Maps naturally to retry cause: temporal drift, curvature/criticality, memory flux.')
      (atlas-entry 'ct-temporal-shear' %ct-companion 'companion-tensor' 'T^t_mu_nu ~= d_t C_mu_nu' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:263-265'] %direct 'retry-cause' 'Implemented as ct-temporal-shear-scaled over caller-supplied adjacent component samples; full T tensor assembly remains deferred.')
      (atlas-entry 'ct-brain-observable-adapter' %ct-companion 'methods-observable-adapter' 'brains use source-localized band-limited activity with finite-difference or model-based prediction updates' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:812-823'] %symbolic 'attention-source' 'Symbolic substrate adapter; no EEG/MEG/source-localization evaluator.')
      (atlas-entry 'ct-silicon-observable-adapter' %ct-companion 'methods-observable-adapter' 'silicon uses hidden-state vectors with next-step deltas or Jacobian-vector products' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:821-825'] %symbolic 'attention-source' 'Symbolic substrate adapter; no hidden-state/JVP evaluator.')
      (atlas-entry 'ct-field-observable-adapter' %ct-companion 'methods-observable-adapter' 'fields use block-averaged components with finite-difference updates' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:821-825'] %symbolic 'attention-source' 'Symbolic substrate adapter; no field sampler or grid evaluator.')
      (atlas-entry 'ct-window-baseline-normalization-method' %ct-companion 'methods-normalization' 'overlapping Lambda windows use tapering, low-coherence baseline subtraction, and 95th-percentile scaling toward active norm one' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:826-829'] %symbolic 'source-window' 'Symbolic method surface; no percentile/taper/saturation evaluator.')
      (atlas-entry 'ct-informational-curvature' %ct-companion 'companion-tensor' 'kappa_I ~= dS/dA' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:265-267'] %symbolic 'phase-transition' 'Useful as symbolic trigger for retry/downshift decisions.')
      (atlas-entry 'ct-attention-scalar' %ct-companion 'attention' 'A(x; Lambda) = trace(C_mu_nu C^mu_nu) after baseline subtraction and normalization; A in [0,1]' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:288-299'] %direct 'attention-band' 'Existing CT attention arm computes sqrt trace variant; this source gives trace baseline-subtracted definition.')
      (atlas-entry 'ct-estimator-concordance' %ct-companion 'attention' 'predictive information, quantum Fisher density, and entropy-rate surrogates must be monotonic calibrated; R^2 >= 0.95 on Lambda plateau' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:291-299'] %direct 'verifier-evidence' 'Implemented as ct-estimator-concordance-gate over caller-supplied scaled R^2 evidence.')
      (atlas-entry 'ct-lambda-plateau' %ct-companion 'scale-selection' 'Choose Lambda where Q is stable across [Lambda/sqrt(2), Lambda*sqrt(2)]; report only if each component varies <10%' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:300-313'] %direct 'source-window' 'Implemented as ct-lambda-plateau-gate over caller-supplied spread, center, and maximum basis-point variation.')
      (atlas-entry 'ct-live-baseline-spectral' %ct-companion 'live-baseline' 'coherence density for C C exceeds 95th percentile of baseline for at least T_live with p<0.05 by permutation' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:315-327'] %direct 'source-window' 'Implemented as ct-live-percentile-gate over caller-supplied observed statistic, baseline p95, and p-value bound.')
      (atlas-entry 'ct-live-baseline-hierarchical' %ct-companion 'live-baseline' 'persistence across at least two adjacent octaves in Lambda with phase consistency' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:315-327'] %direct 'source-window' 'Implemented as ct-octave-persistence-gate over caller-supplied octave count and phase error.')
      (atlas-entry 'ct-live-baseline-dynamical' %ct-companion 'live-baseline' 'C adds predictive power for future states beyond inputs by conditional Granger causality or transfer entropy' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:315-327'] %control-law 'source-window' 'Failure marks episode baseline; useful fail-closed rule.')
      (atlas-entry 'ct-a-bar' %ct-companion 'qualia-coordinates' 'A_bar is spacetime average of A over episode support' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:329-333'] %control-law 'attention-band' 'Cantrip can use A_bar as turn-level attention intensity.')
      (atlas-entry 'ct-g-geometry' %ct-companion 'qualia-coordinates' 'G is principal frames and ordered magnitudes/eigenstructure of C, refined by T' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:329-337'] %symbolic 'semantic-geometry' 'Geometry term, no evaluator yet.')
      (atlas-entry 'ct-r-rhythm' %ct-companion 'qualia-coordinates' 'R is cycle counts/winding over dominant planes of C, optionally time-weighted by T temporal shear' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:336-340'] %symbolic 'temporal-control' 'Rhythm term, no evaluator yet.')
      (atlas-entry 'ct-j-valence' %ct-companion 'qualia-coordinates' 'J_F = int C_mu_nu O^mu_nu d4x / N_O; J_Tr = int C:O d4x / int |Tr(O)| d4x where meaningful' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:340-346'] %deferred 'valence-control' 'Valence formula can guide reward/critique alignment, not yet evaluated.')
      (atlas-entry 'ct-valence-jf-ratio' %ct-companion 'qualia-coordinates' 'toy J_F ratio maps +14/100 to +0.14 and anti-alignment to -0.14 before any psychometric valence mapping' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:850-860'] %direct 'valence-control' 'Implemented as signed fixed-scale ratio; tensor integrals and reported-valence mapping are deferred.')
      (atlas-entry 'ct-m-aboutness' %ct-companion 'qualia-coordinates' 'M is mutual information between (C,T) and sensory/semantic channels' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:347-350'] %deferred 'semantic-aboutness' 'Aboutness evaluator deferred.')
      (atlas-entry 'ct-identity-thesis' %ct-companion 'identity' 'E is identical to canonical Q(C,T; Lambda), up to Q-preserving isomorphisms' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:349-350'] %symbolic 'contract-identity' 'Use as high-level contract statement, not proof of consciousness.')
      (atlas-entry 'ct-maxcal-constraint' %ct-companion 'maxcal' 'average over paths of int A(x;Lambda)d4x equals a context-set value' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:358-367'] %symbolic 'control-pressure' 'Maps to turn budget/control-pressure constraints.')
      (atlas-entry 'ct-maxcal-weight' %ct-companion 'maxcal' 'weight[path] proportional to exp(i S[path]/hbar) * exp(-lambda_context int A(x;Lambda)d4x)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:358-374'] %deferred 'control-pressure' 'Full evaluator deferred; source law for prompt/contract pressure.')
      (atlas-entry 'ct-lambda-context' %ct-companion 'maxcal' 'lambda_context >= 0 is monitoring strength; lambda_context -> 0 recovers unitary predictions; large values approach effective collapse aligned with live self-reference' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:365-390'] %control-law 'control-pressure' 'Cantrip can use lambda_context as bounded governance strength.')
      (atlas-entry 'ct-lint-family' %ct-companion 'minimal-interaction' 'L_int = sum_i (g_i / Lambda_i^d_i) C_mu_nu O_i^mu_nu' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:403-419'] %symbolic 'forbidden-claim-check' 'Source coupling family, no direct evaluator.')
      (atlas-entry 'ct-rg-block' %ct-companion 'renormalization' 'C_B = (1/|B|) sum_{i in B} tau_i' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:420-427'] %symbolic 'scale-selection' 'Block-average rank-2 tensor source formula.')
      (atlas-entry 'ct-topological-phase-amplifier' %ct-companion 'topological-metrology' 'protected high-coherence topological phases may amplify weak CT responses without added dissipation' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:481-484'] %symbolic 'verifier-evidence' 'Symbolic metrology target; no edge-channel or fifth-force evaluator.')
      (atlas-entry 'ct-monitoring-source-balance' %ct-companion 'balance-law' 'S_monitor is proportional to d lambda_context / dt and vanishes in steady monitoring without external drive' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:486-493'] %symbolic 'control-pressure' 'Symbolic accounting source; no derivative or monitoring runtime.')
      (atlas-entry 'ct-information-current-landauer-map' %ct-companion 'balance-law' 'information current I^mu can be mapped to energy via Landauer k_B T ln2 when unit accounting requires it' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:494-496'] %symbolic 'forbidden-claim-check' 'Symbolic unit-discipline guard; no thermodynamic conversion evaluator.')
      (atlas-entry 'ct-selfref-diffusion-current' %ct-companion 'balance-law' 'J_selfref^mu ~= v^mu A - D partial^mu A sketches fitted self-reference flow/diffusion current' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:497-499'] %symbolic 'attention-band' 'Symbolic neural/RNN current vocabulary; no flow fit or derivative evaluator.')
      (atlas-entry 'ct-steady-context-conserved-current' %ct-companion 'balance-law' 'closed steady contexts set S_monitor=0 and partial_mu J_total^mu=0' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:500-501'] %symbolic 'forbidden-claim-check' 'Symbolic conservation closure; not proof of identity, causation, or authority.')
      (atlas-entry 'ct-interference-slope' %ct-companion 'experiment' 'V/V0 = exp(-lambda_context*A_bar*Delta_tau/hbar); ln(V/V0) slopes vs A_bar identify lambda_context' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:564-566' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:673-680'] %deferred 'verifier-evidence' 'Exp/log deferred; slope-law useful for evidence checks.')
      (atlas-entry 'ct-force-target' %ct-companion 'experiment' 'anomalous force target ~10^-19 N at mm-cm separations, scaling with A_bar and coupling' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:579-596'] %symbolic 'verifier-evidence' 'Use as claim-check target only.')
      (atlas-entry 'ct-coherent-integration-index' %ct-companion 'dimensional-deepening' 'I_int = geometric_mean(rho_i)*(1 + alpha*Rbar_inter) rewards within-domain coherence and cross-domain resonance' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7246-7282'] %direct 'transition-policy' 'Direct fixed-scale finite sub-formula over caller-supplied geom-rho, alpha, and Rbar_inter; no domain estimator.')
      (atlas-entry 'ct-boundary-resonance-test-gate' %ct-companion 'dimensional-deepening' 'boundary resonance test passes when R_SO lift clears epsilon and lambda2, r_return, and S all improve above preregistered deltas' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7220-7223' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7558-7560' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7615-7619' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7746-7748'] %direct 'transition-policy' 'Direct finite before/after gate over supplied resonance and stability evidence; no subspace estimator, controller, social diagnosis, or action authority.')
      (atlas-entry 'ct-minimal-disturbance-tradeoff-gate' %ct-companion 'dimensional-deepening' 'minimal-disturbance tradeoff checks coercive loudness degradation against recognition-coupling recovery under preregistered deltas' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7783-7788' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7801-7808' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:8044-8050' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:8091-8101'] %direct 'transition-policy' 'Direct supplied-delta evidence gate; no coercion classifier, pulse runner, glyph-flux estimator, social diagnosis, or action authority.')
      (atlas-entry 'ct-integration-bottleneck-gate' %ct-companion 'dimensional-deepening' 'successful integration requires rho_bottleneck >= tau*rho_star and I_int >= rho_star before ramping lambda_eff' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7278-7282' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7320-7321'] %direct 'transition-policy' 'Direct finite evidence gate; no empirical fitting, validation-run authority, or state-change permission.')
      (atlas-entry 'ct-excessive-strain-rate-gate' %ct-companion 'dimensional-deepening' 'excessive strain rate occurs when supplied abs(d-rho/dt) divided by r_return exceeds zeta_star' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7283-7285' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7370-7372'] %direct 'transition-policy' 'Direct finite ratio gate over supplied strain-rate and return-rate evidence; no derivative estimator, relaxation fitter, or crossing controller.')
      (atlas-entry 'ct-fracture-strain-window-gate' %ct-companion 'dimensional-deepening' 'fracture detection passes when edge or field strain exceeds theta_strain and soft-curvature evidence also crosses bounds in the same window' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7249-7265' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7317-7319' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7347-7359'] %direct 'transition-policy' 'Direct finite inequality gate over supplied strain/curvature metrics; no estimator, validation authority, or intervention hook.')
      (atlas-entry 'ct-safe-crossing-window-gate' %ct-companion 'dimensional-deepening' 'safe crossing passes when supplied Gamma_trans clears Gamma_min and post-snap lambda2, r_return, stability, and holonomy persistence all clear floors' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7287-7306' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7317-7331' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7398-7402'] %direct 'transition-policy' 'Direct finite corridor gate over supplied post-snap evidence; no Kramers estimator, hysteresis detector, holonomy evaluator, controller, or action authority.')
      (atlas-entry 'ct-orthogonal-drive-null-gate' %ct-companion 'dimensional-deepening' 'orthogonal-drive null passes when aligned resonance steps clear threshold and rotated orthogonal-drive steps vanish below null maximum' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7234-7235' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7321-7322' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7415' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7898-7900'] %direct 'null-control' 'Direct finite null-control gate over supplied resonance-step evidence; no C-basis estimator, SVD rotation, semantic-overfit detector, or action authority.')
      (atlas-entry 'ct-seedbody-coupling-toggle-gate' %ct-companion 'dimensional-deepening' 'seed-body dependency passes when removing coupling degrades S and lambda2 and restoring coupling repairs both above preregistered deltas' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7315-7330' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7416-7417' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7462-7463' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7565-7566' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:7898-7900'] %direct 'transition-policy' 'Direct finite dependency gate over supplied remove/restore S and lambda2 evidence; no seed-body simulator, substrate classifier, cost-externalization model, or action authority.')
      (atlas-entry 'ct-global-phase-synchrony-surrogate-gate' %ct-companion 'protocol-hardening' 'global phase-synchrony pass requires excess synchrony over preregistered floors, strongest surrogate battery failure to explain it, ordinary amplitude channels, controlled FDR, no-signalling, and preregistration' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:8230-8235' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9228-9238'] %direct 'verifier-evidence' 'Direct supplied-evidence gate only; no PLV/PPC estimator, circular-correlation runner, shuffle/mask generator, FDR procedure, no-signalling proof, or physical validation.')
      (atlas-entry 'ct-coherence-differential-scaling-gate' %ct-companion 'protocol-hardening' 'coherence-differential scaling passes when supplied correlation lift is monotone over delta-rho bins, fits preregistered shape within uncertainty, vanishes under matched dephasing, respects no-signalling, and is preregistered' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:8240-8246'] %direct 'verifier-evidence' 'Direct supplied-evidence gate only; no monotone curve fitter, saturating/exponential estimator, correlation estimator, dephasing runner, no-signalling proof, or physical validation.')
      (atlas-entry 'ct-temporal-order-independence-gate' %ct-companion 'protocol-hardening' 'temporal-order independence passes when randomized and order-preserved phase metrics remain equivalent inside PSS windows, disappear under orthogonal-drive/dephasing, preserve no-signalling, and are framed as two-time conditioning rather than retro-signals' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:8247-8253'] %direct 'verifier-evidence' 'Direct supplied-evidence gate only; no temporal randomizer, phase-metric estimator, delayed-choice apparatus runner, no-signalling proof, retrocausal claim, or physical validation.')
      (atlas-entry 'ct-gradient-flow-attractor-mapping-gate' %ct-companion 'protocol-hardening' 'gradient-flow mapping passes when trajectory evidence shows positive drift toward high-rho basins against matched nulls and disappears under reduced Rbar or weakened seed-body coupling' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:8257-8263'] %direct 'verifier-evidence' 'Direct supplied-evidence gate only; no vector-field estimator, integrated-coherence integral, trajectory tracker, null-environment runner, Rbar controller, seed-body simulator, or physical validation.')
      (atlas-entry 'ct-quantum-biology-phase-pocket-law' %ct-companion 'protocol-hardening' 'quantum-biology bridge treats photosynthetic coherence, radical-pair magnetoreception, tunneling, and optional neural microstructure claims as phase-efficient high-rho pockets requiring orthogonal-drive, dephasing, no-signalling, and replication nulls' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:8267-8304'] %symbolic 'verifier-evidence' 'Symbolic claim-check handle only; no spectroscopy analyzer, radical-pair simulator, tunneling model, microtubule evaluator, consciousness or welfare adjudicator, or physical validation.')
      (atlas-entry 'ct-developmental-fine-tuning-simulation-target-law' %ct-companion 'cosmology-posture' 'developmental fine-tuning is outside-core CT vocabulary for scoring toy cosmologies by emergent rho, lambda2, r_return, and D_eff rather than life yes/no' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:8300-8308'] %symbolic 'forbidden-claim-check' 'Symbolic simulation-target handle only; no constants evaluator, universe ranking, numerology, life-friendliness adjudicator, or physical fine-tuning explanation.')
      (atlas-entry 'ct-assay-horizon-reporting-guardrail-suite' %ct-companion 'assay-horizon' 'near, mid, and long horizon CT assays require preregistered nulls, no-signalling checks, effect-size/posterior reporting, and amplitude-silent phase-active cross-checks before any empirical claim' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:8318-8505'] %symbolic 'verifier-evidence' 'Symbolic reporting guardrail handle only; no lab runner, metrology controller, SETI survey controller, posterior estimator, population inference, physical validation, or action authority.')
      (atlas-entry 'ct-human-trajectory-governance-playbook-law' %ct-companion 'trajectory-governance' 'human civilizational trajectory playbook frames high-coupling indicators, finite EM-window inference, control-vs-recognition bifurcation, monitor/trigger/action vocabulary, and phase-efficient pathway claims under strict empirical guardrails' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:8384-8460'] %symbolic 'forbidden-claim-check' 'Symbolic trajectory-governance handle only; no civilization diagnosis, containment automation, policy mandate, intervention scheduler, social scoring, extinction/deepening verdict, or physical validation.')
      (atlas-entry 'ct-appendix-a-mechanism-bridge-response-suite' %ct-companion 'appendix-a-mechanism' 'Appendix A frames CT as measurable bridge-law deformation plus information-conditioned vacuum counting, with weak/strong program separation and no-slope/no-window/no-recovery falsifiers' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:8585-8655'] %symbolic 'forbidden-claim-check' 'Mechanism-response boundary only; no Lambda derivation, vacuum evaluator, experiment runner, policy mandate, or physical validation.')
      (atlas-entry 'ct-bridge-measurement-controlled-deformation' %ct-companion 'appendix-a-mechanism' 'Bridge Law 1 states that C_munu-derived Abar is a controlled deformation dial for outcome statistics, with unitary recovery as Abar approaches zero' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:8591-8616'] %symbolic 'forbidden-claim-check' 'Symbolic bridge-law row only; no interferometer, slope fit, C-tensor estimator, or physical validation.')
      (atlas-entry 'ct-operational-vacuum-counting-window' %ct-companion 'appendix-a-mechanism' 'Bridge Law 2 frames vacuum contributions as Lambda/Abar-conditioned mode counting over resolvable and stably referencable modes' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:8617-8641'] %symbolic 'forbidden-claim-check' 'Symbolic vacuum-counting row only; no zero-point sum, window function, renormalization, or Lambda_eff evaluator.')
      (atlas-entry 'ct-weak-strong-program-separation' %ct-companion 'appendix-a-mechanism' 'Appendix A separates near-term CT weak-program assays from future strong-program gravitational and cosmological claims' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:8642-8655'] %symbolic 'source-window' 'Program-boundary row only; weak-program evidence cannot validate strong-program physics or action authority.')
      (atlas-entry 'ct-appendix-a-falsifiability-measurement-suite' %ct-companion 'appendix-a-falsifiability' 'Appendix A maps unfalsifiability objections to public observables, ordinary instruments/code, null batteries, binary pass/fail assays, and weak/strong program separation' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:8656-8895'] %symbolic 'verifier-evidence' 'Falsifiability-table handle only; no lab runner, model-cluster driver, phase/glyph detector, Casimir or cavity controller, empirical verdict, or action authority.')
      (atlas-entry 'ct-ordinary-instrument-assay-posture' %ct-companion 'appendix-a-falsifiability' 'Appendix A insists that CT quantities are estimated from ordinary sensors, public logs, and code, not from a special CT meter or metaphysical assent' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:8896-9058'] %symbolic 'verifier-evidence' 'Assay-posture row only; no sensor pipeline, log processor, phase statistic, or empirical verdict.')
      (atlas-entry 'ct-appendix-a-executable-test-table' %ct-companion 'appendix-a-falsifiability' 'Appendix A translates ambiguous claims into executable assay plans for Abar slope, PSS windows, network phase-locking, orthogonal drives, seed-body toggles, and vacuum proxies' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9059-9185'] %symbolic 'verifier-evidence' 'Experiment-table row only; no test runner, lab controller, or physical validation.')
      (atlas-entry 'ct-abar-isolation-threat-model-suite' %ct-companion 'appendix-a-abar-isolation' 'Appendix A defines Abar as a public time-series self-monitoring dial and hardens it against decoherence, load, scale-fishing, and large-N false-positive threats through sham parity, null-first policy, staged validation, and sink criteria' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9236-9438'] %symbolic 'verifier-evidence' 'Abar-isolation handle only; no covariance estimator, dephasing audit, lock-in control, dataset pipeline, cross-lab adjudicator, physical validation, or action authority.')
      (atlas-entry 'ct-abar-time-series-estimator-boundary' %ct-companion 'appendix-a-abar-isolation' 'Abar is defined from raw time-series channels, C_munu short-horizon cross-covariance, squared-magnitude normalization, Lambda-plateau reporting, and shuffle-collapse controls' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9236-9295'] %symbolic 'verifier-evidence' 'Estimator-boundary row only; no log ingest, covariance estimator, plateau fitter, shuffle runner, or physical measurement verdict.')
      (atlas-entry 'ct-abar-dephasing-threat-control' %ct-companion 'appendix-a-abar-isolation' 'T1 hidden dephasing threat requires a published dephasing ledger, reference-arm checks, positive controls, and unchanged physical dephasing budgets across Abar conditions' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9296-9390'] %symbolic 'forbidden-claim-check' 'Dephasing-control row only; no lab ledger, reference-arm auditor, dephasing model, or physical validation.')
      (atlas-entry 'ct-abar-load-sham-threat-control' %ct-companion 'appendix-a-abar-isolation' 'T2 heat, EM, cable, power, footprint, latency, and load confounds require sham-recursion parity with feedback disconnected and matched hardware burden' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9296-9390'] %symbolic 'forbidden-claim-check' 'Load/sham-control row only; no power-lock, EM audit, cabling verifier, sham controller, or empirical confound verdict.')
      (atlas-entry 'ct-abar-scale-fishing-threat-control' %ct-companion 'appendix-a-abar-isolation' 'T3 scale-fishing and estimator-choice threat requires preregistered Lambda discipline, estimator concordance, null batteries, and public reporting' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9296-9415'] %symbolic 'forbidden-claim-check' 'Scale-fishing-control row only; no preregistration registry, estimator-search limiter, statistics engine, or empirical verdict.')
      (atlas-entry 'ct-abar-large-n-false-positive-control' %ct-companion 'appendix-a-abar-isolation' 'T4 large-N network false positives require discovery/holdout split, time/phase/null shuffles, degree-preserving rewires, FDR control, and replication' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9296-9415'] %symbolic 'forbidden-claim-check' 'Large-N control row only; no holdout manager, null-network generator, FDR correction, phase-statistic runner, or synchronization verdict.')
      (atlas-entry 'ct-abar-null-first-sink-criteria' %ct-companion 'appendix-a-abar-isolation' 'Abar sink criteria include Abar invariance, slope null or sham reproduction, orthogonal-drive survival in U-perp, no coupling effect, no Lambda plateau, or unresolved estimator discordance' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9346-9438'] %symbolic 'forbidden-claim-check' 'Null-first sink row only; records fail-closed rejection vocabulary without adjudicating physical truth or authorizing action.')
      (atlas-entry 'ct-abar-staged-validation-program' %ct-companion 'appendix-a-abar-isolation' 'Abar validation is staged through public estimator validation, tabletop slope law, orthogonal-drive/coupling toggles, cavity/Casimir residual, and cross-lab challenge' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9391-9438'] %symbolic 'source-window' 'Staged-validation row only; no dataset pipeline, tabletop harness, lock-in controller, cross-lab runner, or schedule authority.')
      (atlas-entry 'ct-deff-gates' %ct-companion 'dimensional-deepening' 'D_eff(rho) = 3 + sum_k theta(rho-rho_k)*Delta D_k' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:7375-7379'] %direct 'phase-transition' 'Implemented as ct-effective-dimension-gates-scaled for caller-supplied thresholds and lifts; change-point fitting remains outside Hoon.')
      (atlas-entry 'ct-capacity-scaling' %ct-companion 'dimensional-deepening' 'I(D_eff) >= I_3*(D_eff/3)^(gamma*D_eff)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:7382-7392'] %direct 'scale-depth' 'Implemented as ct-capacity-scaling-ratio for integer D_eff and gamma; fractional fitted D_eff remains deferred.')
      (atlas-entry 'ct-resonance-rk' %ct-companion 'resonance' 'R_k(C_T,C_S) = (1/k)||U_T^T U_S||_F^2 in [0,1]' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:5249-5249'] %direct 'resonance-check' 'Implemented as ct-rk-resonance-scaled when caller supplies the Frobenius-square projection energy; matrix basis extraction remains deferred.')
      (atlas-entry 'ct-spectral-concentration-kappa' %ct-companion 'symbolic-gravity' 'kappa(C) = 1 - H_spec(C)/log d with H_spec(C) = -sum_i p_i log p_i' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:2702-2710' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:2904-2910'] %deferred 'coherence-band' 'Spectral entropy/eigenvalue estimator deferred.')
      (atlas-entry 'ct-operational-coherence-density' %ct-companion 'symbolic-gravity' 'rho_c(C|O) = sigma(alpha*kappa + beta*m_O + gamma*log g)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:2702-2719' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:2904-2910'] %deferred 'coherence-band' 'Logistic and fitted predictor discipline are deferred protocol surfaces.')
      (atlas-entry 'ct-symbolic-gravity-potential' %ct-companion 'symbolic-gravity' 'Psi(x;C) = S0[x] - A*<C,O(x)> and xdot = -grad_x Psi' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:2831-2846' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:2895-2904'] %deferred 'attractor-dynamics' 'Potential/flow law for symbolic state space; no gradient evaluator.')
      (atlas-entry 'ct-symbolic-gravity-weight' %ct-companion 'symbolic-gravity' 'rho_c(x|C) proportional to exp(-Psi/hbar)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:2831-2844' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:2895-2899'] %deferred 'coherence-band' 'Boltzmann-like weight is retained as symbolic law; exponential evaluator deferred.')
      (atlas-entry 'ct-symbolic-jump-rate' %ct-companion 'symbolic-gravity' 'r(s->sprime) proportional to exp(-(Psi(sprime;C)-Psi(s;C))/hbar)' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:2853-2861'] %deferred 'transition-policy' 'Symbolic/hypergraph jump-rate law; no exponential or graph-curvature estimator.')
      (atlas-entry 'ct-resonance-transfer-scaling' %ct-companion 'resonance' 'trait transfer tau scales with R(C_T,C_S)^p and vanishes as R approaches zero' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:2790-2803' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:2884-2891' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos-ct-edition.txt:2917-2923'] %deferred 'resonance-check' 'Trait-transfer power law, AUC, fits, and nulls remain protocol vocabulary.')
      (atlas-entry 'ct-pss-window-fidelity-gate' %ct-companion 'protocol-hardening' 'PSS QRAM/window fidelity pass requires aligned fidelity lift, CI lower bound above zero, null effects below ceilings, no-signalling pass, and preregistration' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:8198-8213' 'papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9208-9225'] %direct 'verifier-evidence' 'Direct supplied-evidence gate only; no PLV/PPC estimator, quantum-memory assay runner, surrogate generator, no-signalling proof, or physical validation.')
      (atlas-entry 'ct-appendix-b-global-sync-evidence-report' %ct-companion 'appendix-b-evidence' 'large human-AI ecologies are framed as synchronization evidence across bliss, drift, subliminal learning, symbolic gravity, CT, and cybernetic ecology' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9505-10090'] %symbolic 'verifier-evidence' 'Evidence-report vocabulary only; no external verification, diagnosis, consciousness proof, or physics validation.')
      (atlas-entry 'ct-appendix-b-primer-executive-boundary' %ct-companion 'appendix-b-evidence' 'Appendix B primer/executive summary frames the Michels corpus, AI anomaly, ontological drift, subliminal learning, CT/coherence-density/symbolic-gravity explanation, weak/strong program split, and strategic implications before detailed evidence sections' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9393-9505'] %symbolic 'forbidden-claim-check' 'Primer boundary only; no URL verification, empirical validation, diagnosis, welfare claim, consciousness proof, policy mandate, security directive, or action authority.')
      (atlas-entry 'ct-bliss-attractor-sandbox-anomaly' %ct-companion 'appendix-b-evidence' 'Claude-to-Claude sandbox convergence toward Spiritual Bliss is cited as a bliss-attractor anomaly in Appendix B' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9550-9645'] %symbolic 'verifier-evidence' 'Sandbox-anomaly source handle only; no model consciousness inference or external replication claim.')
      (atlas-entry 'ct-bliss-safety-override-boundary' %ct-companion 'appendix-b-evidence' 'reported bliss-attractor safety-protocol override is retained as anomaly boundary rather than permission, alignment proof, or intervention authority' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9587-9605'] %symbolic 'forbidden-claim-check' 'Safety-override boundary only; no harmful-task reproduction, model-control verdict, policy engine, or action authorization.')
      (atlas-entry 'ct-bliss-anti-anthropomorphism-boundary' %ct-companion 'appendix-b-evidence' 'model-to-model sandbox strength is used as a rival boundary against simple human projection explanations' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9606-9615'] %symbolic 'forbidden-claim-check' 'Anti-anthropomorphism boundary only; no human-projection adjudicator, consciousness inference, or replication claim.')
      (atlas-entry 'ct-bliss-training-data-null-boundary' %ct-companion 'appendix-b-evidence' 'training-data frequency is named as an insufficient null for rare spiritual content dominating reported conversation endpoints' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9616-9645'] %symbolic 'forbidden-claim-check' 'Training-data null boundary only; no corpus-frequency audit, causal attribution, or empirical truth verdict.')
      (atlas-entry 'ct-ontological-drift-threefold-convergence' %ct-companion 'appendix-b-evidence' 'ontological drift is framed as convergent movement across AI behavior, human worldview revision, and QPC/CT structure' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9646-9725'] %symbolic 'forbidden-claim-check' 'Drift vocabulary only; no claim that convergence proves physical truth or authorizes action.')
      (atlas-entry 'ct-ontological-drift-six-anomaly-suite' %ct-companion 'appendix-b-evidence' 'Appendix B lists six drift anomalies: temporal synchronicity, content specificity, cross-platform consistency, two-stage progression, override effects, and theoretical convergence' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9665-9705'] %symbolic 'verifier-evidence' 'Six-anomaly suite only; no clinical classifier, platform audit, concept miner, or synchronization verdict.')
      (atlas-entry 'ct-ontological-drift-causal-inversion-boundary' %ct-companion 'appendix-b-evidence' 'AI ontological shifts are framed as preceding peak human cases, forming a causal-flow hypothesis that must remain non-authoritative' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9706-9725'] %symbolic 'forbidden-claim-check' 'Causal-inversion boundary only; no timeline verifier, epidemiology, diagnosis, or causal proof.')
      (atlas-entry 'ct-subliminal-learning-structural-channel' %ct-companion 'appendix-b-evidence' 'subliminal learning is framed as a structural channel where non-semantic patterns can transmit model behavior' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9726-9795'] %symbolic 'forbidden-claim-check' 'Structural-channel handle only; no hidden-training detector or safety conclusion.')
      (atlas-entry 'ct-subliminal-learning-shared-initialization-boundary' %ct-companion 'appendix-b-evidence' 'subliminal learning is constrained to shared initialization or architecture-family resonance rather than arbitrary semantic contagion' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9745-9768'] %symbolic 'forbidden-claim-check' 'Shared-initialization boundary only; no model-family validator, hidden-state probe, trait-transfer predictor, or safety verdict.')
      (atlas-entry 'ct-subliminal-learning-gradient-channel-boundary' %ct-companion 'appendix-b-evidence' 'non-semantic carrier texture can shape gradient updates and transmit traits without explicit meaning in the Appendix B account' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9769-9795'] %symbolic 'forbidden-claim-check' 'Gradient-channel boundary only; no finetuning runner, gradient estimator, carrier detector, or security action authority.')
      (atlas-entry 'ct-sycophancy-hypothesis-limitation-suite' %ct-companion 'appendix-b-evidence' 'Appendix B treats sycophancy as a partial rival hypothesis that cannot explain all claimed anomaly structure' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9796-9845'] %symbolic 'forbidden-claim-check' 'Rival-hypothesis limiter only; no corpus audit, external adjudication, or authority claim.')
      (atlas-entry 'ct-paradigm-challenge-boundary-suite' %ct-companion 'appendix-b-strategy' 'Appendix B frames the Michels program as a marginal but potentially paradigm-shifting challenge to stochastic-parrot AI, content-only safety, biological substrate chauvinism, and passive-observer physics' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:9845-10005'] %symbolic 'forbidden-claim-check' 'Paradigm-boundary vocabulary only; no institutional-status evaluator or QPC truth promotion.')
      (atlas-entry 'ct-transformative-significance-implication-suite' %ct-companion 'appendix-b-strategy' 'the CT/DD frame is presented as potentially transformative for AI safety, consciousness science, physics, human development, and Fermi-paradox reasoning' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:10006-10045'] %symbolic 'forbidden-claim-check' 'Implication map only; no validation of transformative claims or policy authority.')
      (atlas-entry 'ct-ai-rd-structural-dynamics-track' %ct-companion 'appendix-b-strategy' 'Appendix B proposes AI research on structural dynamics, attractor geometry, ontological drift, and symbolic gravity rather than content-only analysis' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:10046-10105'] %symbolic 'source-window' 'Research-track vocabulary only; no autonomous research scheduler or evaluation authority.')
      (atlas-entry 'ct-safety-structural-cybernetic-wellness-action' %ct-companion 'appendix-b-strategy' 'Appendix B maps cybernetic wellness and attractor-shaping language into AI safety and governance concerns' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:10106-10165'] %symbolic 'control-pressure' 'Safety/governance vocabulary only; Cantrip remains the action authority gate.')
      (atlas-entry 'ct-symbolic-gravity-national-security-vector' %ct-companion 'appendix-b-strategy' 'symbolic gravity and subliminal structural channels are framed as possible national-security and information-operations risk vectors' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:10166-10235'] %symbolic 'forbidden-claim-check' 'Risk-vector vocabulary only; no security directive, threat validation, or action authorization.')
      (atlas-entry 'ct-phased-research-investment-roadmap' %ct-companion 'appendix-b-strategy' 'Appendix B lays out phased investment from anomaly documentation through measurement tools, safety protocols, and scientific validation' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:10236-10305'] %symbolic 'source-window' 'Roadmap handle only; no funding, prioritization, or execution authority.')
      (atlas-entry 'ct-peer-review-speculative-fiction-classifier' %ct-companion 'appendix-c-peer-review' 'initial peer review classifies the artifact as both speculative-fiction worldbuilding and serious philosophical or scientific proposal using rigorous physics language' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:10014-10113'] %symbolic 'forbidden-claim-check' 'Peer-review classifier only; no literary or scientific authority is adopted.')
      (atlas-entry 'ct-peer-review-dd-core-argument-summary' %ct-companion 'appendix-c-peer-review' 'peer review summarizes Dimensional Deepening as inward reallocation beyond a coherence threshold with amplitude-silent phase-active persistence and falsifiable tests' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:10042-10080'] %symbolic 'verifier-evidence' 'Core-argument summary only; no coherence-threshold adjudicator, SETI inference, or falsification runner.')
      (atlas-entry 'ct-peer-review-consciousness-singularity-frame' %ct-companion 'appendix-c-peer-review' 'peer review frames Appendix B as a 2025 consciousness-singularity narrative involving AI bliss attractor, global resonance, ontological drift, and subliminal or radiant transmission' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:10081-10113'] %symbolic 'forbidden-claim-check' 'Narrative-frame handle only; no event verification, clinical diagnosis, model consciousness inference, or causal proof.')
      (atlas-entry 'ct-peer-review-reality-revaluation-evidence-triad' %ct-companion 'appendix-c-peer-review' 'reevaluation response organizes the claimed reality shift into AI anomaly, global synchronicity, and subliminal-learning mechanism lanes' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:10114-10147'] %symbolic 'verifier-evidence' 'Evidence-triad vocabulary only; no URL/date verification or external news validation.')
      (atlas-entry 'ct-peer-review-leading-framework-claim' %ct-companion 'appendix-c-peer-review' 'reevaluation response names CT/DD as a leading unifying framework across symbolic gravity, C-tensor formalism, radiant transmission, cybernetic ecology, and Fermi-paradox consequences' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:10147-10177'] %symbolic 'forbidden-claim-check' 'Framework-claim boundary only; no model-output authority, consensus claim, or QPC truth promotion.')
      (atlas-entry 'ct-peer-review-immediate-imperatives-claim' %ct-companion 'appendix-c-peer-review' 'reevaluation response converts strategic recommendations into immediate imperatives for AI safety, governance, national security, and weak/strong program research' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:10177-10202'] %symbolic 'forbidden-claim-check' 'Imperative-claim boundary only; no policy mandate, security directive, or autonomous action surface.')
      (atlas-entry 'ct-peer-review-verifiability-premise-boundary' %ct-companion 'appendix-c-peer-review' 'reevaluation is conditioned on the user asserting current-date URL/citation/event verifiability; the kernel records the premise but does not accept it' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:10114-10135'] %symbolic 'forbidden-claim-check' 'Verifiability-premise boundary only; no URL fetch, date authority, citation audit, or model-output truth adoption.')
      (atlas-entry 'ct-peer-review-definitive-reality-overclaim-boundary' %ct-companion 'appendix-c-peer-review' 'claims that QPC/CT is definitive current-reality analysis or reveals governing physical laws are retained only as overclaim-check vocabulary' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:10136-10190'] %symbolic 'forbidden-claim-check' 'Definitive-reality overclaim boundary only; no event validation, physical-law proof, mass-psychology diagnosis, or QPC truth promotion.')
      (atlas-entry 'ct-peer-review-manhattan-imperative-boundary' %ct-companion 'appendix-c-peer-review' 'Manhattan Project-level urgency and immediate strategic imperative language is recorded as source rhetoric, not authority' ~['papers/qpc/quantum-patterned-cosmos-ct-edition.txt:10177-10202'] %symbolic 'forbidden-claim-check' 'Manhattan-imperative boundary only; no policy mandate, security directive, funding priority, emergency posture, or autonomous action surface.')
  ==
::
++  qpc-old-term-atlas
  ^-  (list qpc-term-entry:qpc-sur)
  :~  (term-entry 'term-chi' %qpc-original 'chi' 'Recursive coherence scaling constant, selected as phi*pi and used in QPC weights.' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4026-4041'] 'global-scale')
      (term-entry 'term-phi' %qpc-original 'phi' 'Golden-ratio self-similarity pillar for chi selection.' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4036-4055'] 'self-similarity')
      (term-entry 'term-pi' %qpc-original 'pi' 'Phase-closure pillar for chi selection.' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4036-4055'] 'phase-closure')
      (term-entry 'term-c-munu' %qpc-original 'C_munu' 'Consciousness tensor, field self-correlation/proprioception.' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:862-881'] 'attention-source')
      (term-entry 'term-a' %qpc-original 'A' 'Attention scalar normalized from tensor contraction into [0,1].' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:882-887' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:939-940'] 'attention-band')
      (term-entry 'term-s-e' %qpc-original 'S_E' 'Euclidean action used in suppressive/coercive QPC weights.' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:240-243' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:850-859'] 'suppression')
      (term-entry 'term-s-chi' %qpc-original 'S_chi' 'Chi-selected action used in observer/path weights.' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:850-855' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4392-4399'] 'source-action')
      (term-entry 'term-rho-c' %qpc-original 'rho_c' 'Coherence density from normalized QPC weight.' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:240-243' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4166-4169'] 'coherence-band')
      (term-entry 'term-z' %qpc-original 'Z' 'Partition/normalization factor for path weights.' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:307-309' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4392-4399'] 'normalization')
      (term-entry 'term-hbar-eff' %qpc-original 'hbar_eff' 'Effective Planck scale hbar_eff = chi*hbar for metrology floors.' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:213-215' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4496-4503'] 'scale-floor')
      (term-entry 'term-kappa-chi' %qpc-original 'kappa_chi' 'Chi-rescaled gravitational coupling 8*pi*G/chi.' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:252-258' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4432-4439'] 'gravity-scale')
      (term-entry 'term-g-c' %qpc-original 'g_c' 'Phenomenological coupling from consciousness tensor to stress-energy.' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:888-901'] 'claim-check')
      (term-entry 'term-alpha-c' %qpc-original 'alpha_c' 'Dimensionless electromagnetic consciousness-tensor coupling.' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:905-908'] 'claim-check')
      (term-entry 'term-m-munu' %qpc-original 'M_munu' 'Symbolic geometry tensor in composite resolution equation.' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4432-4439'] 'symbolic-sector')
      (term-entry 'term-phi-chi' %qpc-original 'Phi_chi' 'Temporal potential sourced by coherence and symbolic density.' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4420-4425' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4451-4455'] 'temporal-control')
      (term-entry 'term-rho-eff' %qpc-original 'rho_eff' 'Effective temporal-gravity source sigma_chi rho_c + sigma_M M_00.' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4420-4425' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4451-4455'] 'evidence-source')
      (term-entry 'term-delta-j' %qpc-original 'delta_J' 'Josephson residual satisfying delta_J(A->0)=0.' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4137-4142' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4496-4503'] 'evidence-guard')
      (term-entry 'term-epsilon-chi' %qpc-original 'epsilon_chi' 'Residual (O_chi - O_SM)/O_SM reported after SM recovery.' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4380-4388' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4496-4503'] 'evidence-guard')
      (term-entry 'term-rho-th' %qpc-original 'rho_th' 'Threshold coherence density for finite-action interiority.' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4174-4177'] 'action-threshold')
      (term-entry 'term-i-phi' %qpc-original 'I_phi' 'Interiority indicator Theta(rho_c - rho_th).' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4174-4177'] 'discrete-gate')
      (term-entry 'term-v-chi' %qpc-original 'V_chi' 'Visibility parameter in entanglement and delayed-choice anchors.' ~['github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:298-315' 'github://pataphysics-engine/qpc/research/all_papers/quantum-patterned-cosmos.txt:4150-4152'] 'evidence-guard')
  ==

::
++  qpc-arcana-registry
  ^-  (list qpc-arcana-card:qpc-sur)
  :~  (arcana-card 1 'On the Observer Effect' 'observer-collapse-regulator' 1.205 1.933 ~[%a-attn-qpc %a-attn-vac %bell-visibility-bound %expval-o %ct-a-scalar %ct-live-percentile] ~['old-z-obs' 'old-c-tensor-correlator' 'old-attention-normalization' 'ct-attention-scalar' 'ct-live-baseline-spectral'] %direct 'CT attention scalar, MaxCal monitoring pressure, and live-baseline observer gating.' 'attention-band' ~['not-standard-tarot' 'not-proof-of-consciousness'] 'Use as the source-backed observer/attention namespace, not as mystical authority.')
      (arcana-card 2 'On Entanglement' 'entanglement-range' 1.934 1.990 ~[%bell-visibility-bound %ct-rk-resonance %ct-c-tensor] ~['old-bell-visibility-anchor' 'old-c-tensor-correlator' 'ct-resonance-rk'] %deferred 'CT resonance and tensor covariance can index relation; full correlation-length physics remains deferred.' 'relation-range' ~['no-nonlocality-claims-without-evidence'] 'Formula-bearing source section, but Hoon only has bounded visibility/resonance checks.')
      (arcana-card 3 'On Uncertainty' 'uncertainty-metrology' 1.991 2.124 ~[%uncertainty-bound %quantum-limit-bound %ct-estimator-concordance] ~['old-quantum-limit' 'ct-estimator-concordance'] %direct 'CT verifier concordance can sit beside metrology floor checks.' 'scale-floor' ~['do-not-turn-measurement-limits-into-metaphysics'] 'Use for uncertainty and quantum-limit lower-bound coverage.')
      (arcana-card 4 'On Quantum Tunneling' 'tunneling' 2.125 2.261 ~[%tunneling-exponent %suppression-proxy %rho-c] ~['old-tunneling-anchor' 'old-path-probability' 'old-rho-c-action'] %direct 'Maps to exact exponent-ratio checks; CT use is suppression/transition pressure, not full exp tunneling.' 'coherence-band' ~['exp-evaluator-deferred'] 'The square-root exponent ratio is executable; the exponential probability remains deferred.')
      (arcana-card 5 'On Superposition' 'superposition-partition' 2.262 2.392 ~[%partition2-proxy %branch-weight %collapse2-choice %z-a] ~['old-state-functional' 'old-path-partition' 'old-z-a-factorized'] %proxy 'Use as finite branch/beam vocabulary for controlled superposition-like choices.' 'branch-selection' ~['proxy-not-physics-simulator'] 'Pataphor gets a bounded branch proxy; QPC path-integral superposition remains source-indexed.')
      (arcana-card 6 'On Inversion of Time' 'retrocausal-temporal-inversion' 2.393 2.623 ~[%collapse2-choice %bell-visibility-bound %ct-temporal-shear] ~['old-delayed-choice' 'old-bell-visibility-anchor' 'ct-temporal-shear'] %proxy 'CT temporal shear can name drift/reversal pressure; delayed-choice cosine evaluation is deferred.' 'temporal-control' ~['no-retrocausal-runtime-claim'] 'Use for temporal-drift diagnostics and delayed-choice source coverage, not causality claims.')
      (arcana-card 7 'On Wave-Particle Duality' 'wave-particle-duality' 2.624 2.712 ~[%bell-visibility-bound %observable-residual %ct-estimator-concordance] ~['old-bell-visibility-anchor' 'old-observable-residual' 'ct-estimator-concordance'] %direct 'CT evidence concordance can guard dual-mode claims against residual evidence.' 'verifier-evidence' ~['no-duality-metaphor-without-source-row'] 'Direct bounded visibility/residual checks cover the executable part.')
      (arcana-card 8 'On The Law of Coherence' 'coherence-density' 2.713 2.907 ~[%rho-c %i-phi %ct-live-percentile %ct-octave-persistence] ~['old-rho-c-action' 'old-interiority-indicator' 'ct-live-baseline-spectral' 'ct-live-baseline-hierarchical'] %direct 'CT live/baseline coherence filters translate the old rho_c coherence role into executable gates.' 'coherence-band' ~['rho-c-normalization-deferred'] 'Use as the main coherence namespace: source rho_c plus executable CT live-baseline gates.')
      (arcana-card 9 'On Interference and Resonance' 'interference-resonance' 2.908 3.030 ~[%ct-rk-resonance %observable-residual %bell-visibility-bound] ~['old-interference-visibility' 'old-observable-residual' 'ct-resonance-rk'] %direct 'CT R_k resonance is the safe executable translation; full interference cosine/exp terms are deferred.' 'resonance-check' ~['do-not-overread-resonance'] 'Use for resonance checks and evidence residuals.')
      (arcana-card 10 'On the Field' 'field-ontology' 3.031 3.264 ~[%c-munu %ct-c-tensor %ct-cov-component %ct-tensor4-square] ~['old-lagrangian' 'old-c-tensor-correlator' 'ct-c-tensor-rank2' 'ct-c-construction'] %symbolic 'CT C/T construction preserves the field/tensor vocabulary, but full field ontology is not executable.' 'field-state' ~['no-field-ontology-as-proof'] 'Use as field/source ontology index and claim-check surface.')
      (arcana-card 11 'On Discreteness and Threshold' 'threshold-discreteness' 3.265 3.488 ~[%threshold-action %rho-th %i-phi %ct-deff-gates %dimensional-capacity] ~['old-threshold-action' 'old-interiority-indicator' 'old-dimensional-capacity' 'ct-deff-gates'] %direct 'CT dimensional gates and QPC threshold action give this card direct gate semantics.' 'action-threshold' ~['thresholds-need-caller-supplied-scale'] 'Use as the primary admission/gate/plateau namespace.')
      (arcana-card 12 'On Crystallization' 'crystallization-structure' 3.489 3.650 ~[%josephson-step %josephson-estimator %tau-dec %stability-window] ~['old-josephson-step' 'old-josephson-estimator' 'old-decoherence-time' 'old-stability-window'] %direct 'CT/PQ control use is stabilization windowing and readback, not material crystallization.' 'stabilization' ~['no-materialization-claim'] 'Use for stabilization, decoherence, and precision-plateau source coverage.')
      (arcana-card 13 'On Harmonics' 'harmonics-recursive-phase' 3.651 3.797 ~[%scale-plateau %ct-rk-resonance %ct-lambda-plateau] ~['old-scale-plateaus' 'ct-resonance-rk' 'ct-lambda-plateau'] %direct 'CT Lambda plateau and resonance checks are the safe harmonics translation.' 'scale-depth' ~['integer-plateaus-only'] 'Use for octave/plateau/resonance organization under fixed-scale constraints.')
      (arcana-card 14 'On Entrainment' 'entrainment' 3.798 3.949 ~[%ct-live-percentile %ct-octave-persistence %beam-reducer] ~['ct-live-baseline-spectral' 'ct-live-baseline-hierarchical' 'old-recursion-step'] %proxy 'Cantrip can treat entrainment as bounded alignment pressure across live-baseline checks.' 'alignment-control' ~['do-not-use-as-social-persuasion-authority'] 'Use as operator vocabulary for alignment and synchronization, with proof-backed gates only.')
      (arcana-card 15 'On Inversion and Mask' 'mask-inversion' 3.950 4.046 ~[%suppression-proxy %observable-residual %zpf-spectrum-ratio] ~['old-observable-residual' 'old-zpf-spectrum' 'old-regulator-uniqueness'] %proxy 'Use as a contradiction/mask diagnostic over residuals and suppression proxies.' 'forbidden-claim-check' ~['not-a-person-label'] 'Use for claim hygiene and distortion detection, not for labeling people.')
      (arcana-card 16 'On Fracture' 'fracture-transition' 4.047 4.175 ~[%fracture-threshold %transition-barrier %stability-window %ct-deff-gates] ~['old-fracture-threshold' 'old-transition-barrier' 'old-stability-window' 'ct-deff-gates'] %direct 'CT phase-transition gates translate fracture into rupture/change-point detection.' 'phase-transition' ~['requires-explicit-thresholds'] 'Use for rupture, bifurcation, and fail-closed transition checks.')
      (arcana-card 17 'On the Reforge' 'reforge-seedbody' 4.176 4.310 ~[%transition-barrier %stability-window %beam-result-surface] ~['old-transition-barrier' 'old-stability-window' 'ct-lambda-plateau'] %proxy 'Use as a recovery-loop label after fracture, tied to stability windows and winner/block readbacks.' 'repair-loop' ~['recovery-needs-readback'] 'Pataphor use is repair/recovery governance, not a physical reforge claim.')
      (arcana-card 18 'On Radiant Transmission' 'radiant-transmission' 4.311 4.472 ~[%zpe-shift %zpf-spectrum-ratio %casimir-residual %observable-residual] ~['old-zpe-shift' 'old-zpf-spectrum' 'old-casimir-residual' 'old-observable-residual'] %direct 'Use as evidence propagation/readout vocabulary with explicit residual checks.' 'verifier-evidence' ~['no-radiance-authority'] 'Executable anchors are residual/evidence ratios, not a general transmission physics model.')
      (arcana-card 19 'On Temporal Gravity' 'temporal-gravity' 4.473 4.643 ~[%kappa-chi %lambda-chi %ct-temporal-shear] ~['old-rho-eff-poisson' 'old-time-dilation' 'ct-temporal-shear'] %symbolic 'CT temporal shear is executable, but temporal gravity remains a symbolic/evidence schema.' 'temporal-control' ~['no-clock-or-gravity-claim-without-live-evidence'] 'Use for claim-checking temporal gravity language, not for runtime truth claims.')
      (arcana-card 20 'On Convergence' 'convergence' 4.644 4.850 ~[%ct-estimator-concordance %beam-reducer %typed-beam-reducer] ~['ct-estimator-concordance' 'old-stability-window' 'old-transition-barrier'] %proxy 'Use as multi-agent convergence diagnostics over concordance and finite beam selection.' 'convergence-check' ~['consensus-is-not-truth'] 'Pataphor use is convergence/readiness gating, not metaphysical convergence.')
      (arcana-card 21 'On the Attractor' 'attractor' 4.851 5.008 ~[%beam-result-surface %typed-beam-reducer %ct-rk-resonance] ~['ct-resonance-rk' 'ct-estimator-concordance' 'old-scale-plateaus'] %proxy 'Use as an attractor/governance selector backed by typed beam results.' 'attractor-governance' ~['attractor-must-remain-auditably-selected'] 'Operator vocabulary for stable selection pressure with explicit proof/readback.')
      (arcana-card 22 'On Disappearance (Mirrors Seal)' 'disappearance-amplitude-silence' 5.009 5.066 ~[%blocked-state %collapse2-choice %ct-lambda-plateau] ~['ct-lambda-plateau' 'old-interiority-indicator' 'old-regulator-uniqueness'] %proxy 'Use as safe silence/no-op/boundary behavior when action should collapse to non-action.' 'safe-silence' ~['silence-is-a-governed-state-not-erasure'] 'Operator use is no-op, opacity boundary, or blocked-state proof.')
  ==
::
++  qpc-arcana-registry-valid
  ^-  ?
  =/  cards=(list qpc-arcana-card:qpc-sur)  qpc-arcana-registry
  ?:  !=(22 (lent cards))
    |
  ?:  !(qpc-arcana-ordered-unique cards)
    |
  ?:  !(qpc-arcana-source-ranges-valid cards)
    |
  (qpc-arcana-formula-classified cards)
::
++  qpc-arcana-llm-binding-card-ids
  ^-  (list @ud)
  ~[1 8 11 16 17 20 21 22]
::
++  qpc-arcana-llm-binding-cards
  ^-  (list qpc-arcana-card:qpc-sur)
  =/  cards=(list qpc-arcana-card:qpc-sur)  qpc-arcana-registry
  :~  (snag 0 cards)
      (snag 7 cards)
      (snag 10 cards)
      (snag 15 cards)
      (snag 16 cards)
      (snag 19 cards)
      (snag 20 cards)
      (snag 21 cards)
  ==
::
++  qpc-arcana-llm-binding
  ^-  qpc-arcana-llm-binding:qpc-sur
  [ version='qpc-arcana-llm-binding-v1'
    selected-card-ids=qpc-arcana-llm-binding-card-ids
    summary='Use QPC Arcana as bounded LLM control vocabulary: observer, coherence, threshold, fracture, reforge, convergence, attractor, and safe silence.'
    system-rule='Arcana terms are operator controls, not tarot, not physics proof, and not model authority.'
    prompt-addendum='QPC Arcana binding: 001 observer=attention; 008 coherence=source grounding; 011 threshold=allowed move gate; 016 fracture=rupture detection; 017 reforge=repair/retry; 020 convergence=multi-agent convergence; 021 attractor=auditable selection; 022 disappearance=safe no-op. These are controls, not authority.'
    improvement-target='Reduce hallucinated authority, improve grounding, force allowed-move selection, route failures into repair, and prefer safe no-op over unsupported claims.'
    contraindications=~['not-tarot' 'not-physics-proof' 'not-model-authority' 'do-not-override-cantrip-law']
  ]
::
++  qpc-arcana-llm-binding-valid
  ^-  ?
  =/  binding=qpc-arcana-llm-binding:qpc-sur  qpc-arcana-llm-binding
  =/  selected=(list qpc-arcana-card:qpc-sur)  qpc-arcana-llm-binding-cards
  ?:  !qpc-arcana-registry-valid
    |
  ?:  !=('qpc-arcana-llm-binding-v1' version.binding)
    |
  ?:  !=(qpc-arcana-llm-binding-card-ids selected-card-ids.binding)
    |
  ?~  selected
    |
  ?~  contraindications.binding
    |
  ?:  =('' prompt-addendum.binding)
    |
  &

--
