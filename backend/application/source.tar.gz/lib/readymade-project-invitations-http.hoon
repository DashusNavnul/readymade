::  Exact invitation command parsing; authenticated local HTTP owner only.
/+  inv=readymade-project-invitations, mg=readymade-app-management
|%
++  ux
  |=  value=@t
  ^-  @ux
  =/  n=@ux  (need (slaw %ux value))
  ?>  &((gth n 0) (lte (met 0 n) 256) =(value (scot %ux n)))
  n
++  decode
  |=  raw=@t
  ^-  command:inv
  ?>  (lte (met 3 raw) 4.096)
  =/  value=json  (need (de:json:html raw))
  ?>  ?=(%o -.value)
  =/  obj=(map @t json)  p.value
  =/  fields=@ud  ~(wyt by obj)
  ::  No duplicate keys or nested objects. Colon-containing strings are not
  ::  in this protocol; all fields are bounded identifiers or canonical atoms.
  ?>  =(fields (lent (skim (trip raw) |=(c=@t =(c ':')))))
  ?>  =('readymade-project-invitation-v1' (text-field:mg obj 'schema' 64))
  =/  request=@t  (text-field:mg obj 'request' 36)
  =/  authority-text=@t  (text-field:mg obj 'authority' 128)
  =/  authority=@p  (need (slaw %p authority-text))
  ?>  =(authority-text (scot %p authority))
  =/  project=@t  (text-field:mg obj 'project' 128)
  =/  operation=@t  (text-field:mg obj 'operation' 32)
  =/  action=action:inv
    ?:  =('invite-member' operation)
      ?>  =(9 fields)
      =/  target-text=@t  (text-field:mg obj 'target' 128)
      =/  target=@p  (need (slaw %p target-text))
      ?>  =(target-text (scot %p target))
      =/  role=@tas  (text-field:mg obj 'role' 16)
      ?>  ?=(?(%maintainer %contributor %observer %model) role)
      =/  expires-text=@t  (text-field:mg obj 'expiresAt' 128)
      =/  expires=@da  (need (slaw %da expires-text))
      ?>  =(expires-text (scot %da expires))
      =/  nonce=@ux  (ux (text-field:mg obj 'nonce' 81))
      [%invite-member project target role expires nonce]
    ?:  =('leave' operation)
      ?>  =(5 fields)
      [%leave project]
    ?>  =(6 fields)
    ?>  ?=(?(%join %decline-invitation %revoke-invitation %expire-invitation) operation)
    =/  invitation=@ux  (ux (text-field:mg obj 'invitation' 81))
    ?-  operation
      %join                [%join project invitation]
      %decline-invitation  [%decline-invitation project invitation]
      %revoke-invitation   [%revoke-invitation project invitation]
      %expire-invitation   [%expire-invitation project invitation]
    ==
  =/  cmd=command:inv  [request authority action]
  ?>  (valid:inv cmd)
  cmd
++  parse
  |=  raw=@t
  ^-  (unit command:inv)
  (mole |.((decode raw)))
++  post-request
  |=  req=inbound-request:eyre
  ^-  (unit command:inv)
  ?.  &(authenticated.req =('POST' method.request.req))  ~
  =/  host  (header:mg header-list.request.req 'host')
  =/  origin  (header:mg header-list.request.req 'origin')
  =/  mime  (header:mg header-list.request.req 'content-type')
  ?~  host  ~
  ?~  origin  ~
  ?~  mime  ~
  ?.  ?&  =(u.origin (cat 3 ?:(secure.req 'https://' 'http://') u.host))
          |(=(u.mime 'application/json') =(u.mime 'application/json; charset=utf-8'))
      ==  ~
  =/  protocol  (header:mg header-list.request.req 'x-readymade-project-invitation')
  ?.  =(`'v1' protocol)  ~
  ?~  body.request.req  ~
  =/  body  u.body.request.req
  ?.  &((lte p.body 4.096) =(p.body (met 3 q.body)))  ~
  (parse q.body)
++  result-request
  |=  req=inbound-request:eyre
  ^-  (unit @t)
  ?.  &(authenticated.req =('GET' method.request.req))  ~
  =/  id  (header:mg header-list.request.req 'x-readymade-project-request')
  ?~  id  ~
  ?:((uuid:mg u.id) id ~)
++  view
  |=  r=record:inv
  ^-  json
  %-  pairs:enjs:format
  :~  ['schema' s+'readymade-project-invitation-result-v1']
      ['request' s+request.command.r]
      ['authority' s+(scot %p authority.command.r)]
      ['project' s+(project-of:inv action.command.r)]
      ['operation' s+-.action.command.r]
      ['digest' s+(scot %ux digest.r)]
      ['status' s+status.r]
      ['permissionGranted' b+%.n]
      ['outcome' ?~(outcome.r ~ ?:(?=(%accepted -.u.outcome.r) s+code.u.outcome.r s+'native-refused'))]
  ==
--
