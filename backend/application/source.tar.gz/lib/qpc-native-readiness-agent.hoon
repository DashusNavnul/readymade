::  Readiness owner, directly outside the campaign owner. A protected
::  campaign's charging wake is held undelivered until an authenticated CLI
::  readiness offer joins an owner-armed intent. The composed event delivers
::  that wake, fires the instrument ticket enrolled in the same event, and
::  commits ledger and inner together only for exactly one inference and its
::  deadline; otherwise it returns the original core unchanged.
/-  rs=qpc-native-readiness, ro=qpc-native-readiness-owner
/+  readiness=qpc-native-readiness, campaign=qpc-native-campaign,
    observer=qpc-observer, sessions=native-coding-session,
    bind=qpc-native-owner-binding, guard=viki-scry-guard,
    read=qpc-native-campaign-read
|%
+$  card  card:agent:gall
++  empty
  ^-  state:ro
  [%qpc-readiness-owner-state-v1 empty:readiness ~ ~ ~ ~]
++  valid
  |=  s=state:ro
  ^-  ?
  ?&  (lte ~(wyt by holds.s) 64)  (lte ~(wyt by sent.s) 512)  (lte ~(wyt in released.s) 64)
      (levy ~(tap by holds.s) |=([c=@ux *] !(~(has in released.s) c)))
      (levy ~(tap by keys.s) |=([w=@ux k=@tas] &((~(has by windows.ledger.s) w) !=(%$ k))))
      (levy ~(tap by sent.s) |=([r=@ux v=sent:ro] =(r id.request.v)))
  ==
++  notice
  |=  value=*
  ^-  card
  [%give %fact ~[/native-coding] %noun !>(value)]
++  refused
  |=  reason=@tas
  ^-  card
  (notice [%qpc-readiness-refused-v1 reason])
++  campaigns
  |=  [inner=agent:gall b=bowl:gall]
  ^-  (unit state:campaign)
  =/  got  (on-peek:~(. inner b(src our.b)) /x/qpc/campaigns)
  ?~  got  ~
  ?~  u.got  ~
  ((soft state:campaign) q.q.u.u.got)
++  native-intent
  ::  Re-derive every field Viki owns. Identity, handoff, executor and the
  ::  connector label stay as armed and are compared exactly on every use.
  |=  [inner=agent:gall b=bowl:gall i=intent:rs]
  ^-  (each intent:rs @tas)
  =/  cs  (campaigns inner b)
  ?~  cs  [%| %readiness-campaigns-unavailable]
  =/  found  (~(get by records.u.cs) campaign.i)
  ?~  found  [%| %readiness-campaign-missing]
  =/  r=record:campaign  u.found
  =/  c=command:campaign  command.task.r
  =/  input  (input:observer inner b member.c)
  ?~  input  [%| %readiness-session-missing]
  =/  turn=@ud  turn.entry.u.input
  :-  %&
  i(owner our.b, task (digest:campaign task.r), member member.c, grant grant.c, source (digest:campaign expected.c), turn turn, request (request-id:sessions member.c turn))
++  cli-read
  ::  Liveness first: a missing scry bails the event and +mule cannot help.
  |=  [b=bowl:gall =path]
  ^-  (unit *)
  ?.  (agent-live:guard our.b now.b %cli-inference)  ~
  `.^(* %gx (weld /(scot %p our.b)/cli-inference/(scot %da now.b) path))
++  cli-state
  |=  b=bowl:gall
  ^-  (unit cli-readiness:ro)
  =/  raw  (cli-read b /readiness/noun)
  ?~  raw  ~
  ((soft cli-readiness:ro) u.raw)
++  pairing
  |=  [b=bowl:gall key=@tas]
  ^-  cli-pairing:ro
  =/  raw  (cli-read b /pairing/[key]/noun)
  ?~  raw  ~
  =/  parsed  ((soft cli-pairing:ro) u.raw)
  ?~(parsed ~ u.parsed)
++  open-window-for
  |=  [s=state:ro campaign=@ux connector=@tas]
  ^-  (unit window:rs)
  =/  rows=(list window:rs)
    (skim ~(val by windows.ledger.s) |=(w=window:rs &(=(campaign campaign.w) =(connector connector.w) =(%open phase.w))))
  ?~  rows  ~
  ?^  t.rows  ~
  `i.rows
++  prepared-for
  |=  [s=state:ro campaign=@ux request=@ux]
  ^-  (unit intent:rs)
  =/  rows=(list record:rs)
    (skim ~(val by intents.ledger.s) |=(v=record:rs &(=(%prepared phase.v) =(campaign campaign.intent.v) =(request request.intent.v))))
  ?~  rows  ~
  ?^  t.rows  ~
  `intent.i.rows
++  protected
  ::  Any intent for a campaign gates its charging wakes, until released.
  |=  [s=state:ro campaign=@ux]
  ^-  ?
  ?:  (~(has in released.s) campaign)  %.n
  (lien ~(val by intents.ledger.s) |=(v=record:rs =(campaign campaign.intent.v)))
++  release
  ::  Owner exit from protection: revoke this campaign's prepared intents and
  ::  stop gating it. Activated history and windows stay exactly as they are.
  |=  [s=state:ro campaign=@ux]
  ^-  state:ro
  =/  rows=(list [id=@ux v=record:rs])  ~(tap by intents.ledger.s)
  |-  ^-  state:ro
  ?~  rows
    s(released (~(put in released.s) campaign), holds (~(del by holds.s) campaign))
  =?  ledger.s  &(=(campaign campaign.intent.v.i.rows) =(%prepared phase.v.i.rows))
    (revoke:readiness ledger.s id.i.rows)
  $(rows t.rows)
++  derive
  ::  A continuation turn inherits the latest activated parent's task, source
  ::  and grant while that parent's native window stays open. Never across
  ::  windows, and never when Viki's own reads disagree with the parent.
  |=  [s=state:ro inner=agent:gall b=bowl:gall campaign=@ux request=@ux]
  ^-  state:ro
  ?^  (prepared-for s campaign request)  s
  =/  parents=(list record:rs)
    %+  skim  ~(val by intents.ledger.s)
    |=  v=record:rs
    ?.  &(=(%activated phase.v) =(campaign campaign.intent.v))  %.n
    ?~  activation.v  %.n
    =/  w  (~(get by windows.ledger.s) window.u.activation.v)
    &(?=(^ w) =(%open phase.u.w))
  ?~  parents  s
  =/  latest=record:rs
    (snag 0 (sort `(list record:rs)`parents |=([a=record:rs z=record:rs] (gth turn.intent.a turn.intent.z))))
  =/  parent=intent:rs  intent.latest
  =/  fresh  (native-intent inner b parent)
  ?:  ?=(%| -.fresh)  s
  =/  next=intent:rs  p.fresh
  ?.  ?&  =(request request.next)  (gth turn.next turn.parent)
          =([task.parent source.parent grant.parent member.parent] [task.next source.next grant.next member.next])
      ==  s
  =/  armed  (arm:readiness ledger.s next(id (digest:readiness [%derived id.parent request])))
  ?:  ?=(%| -.armed)  s
  s(ledger p.armed)
++  stage
  ::  Retain, rather than deliver, a protected campaign's charging wake.
  |=  [s=state:ro inner=agent:gall b=bowl:gall =wire sign=sign-arvo]
  ^-  (unit [campaign=@ux request=@ux state=state:ro])
  ?.  &(=(our.b src.b) ?=([%behn %wake ~] sign) ?=([%qpc-campaign @ @ ~] wire))  ~
  =/  id  (slaw %ux i.t.wire)
  ?~  id  ~
  ?.  (protected s u.id)  ~
  =/  cs  (campaigns inner b)
  ?~  cs  ~
  =/  found  (~(get by records.u.cs) u.id)
  ?~  found  ~
  =/  r=record:campaign  u.found
  ?.  &(=(%deciding phase.r) ?=(^ request.r) ?=(^ due.r))  ~
  ?.  &(=(wire (wire-for:campaign u.id r)) (gte now.b u.due.r))  ~
  ::  Hold only the ordinary charge-and-run path (no new reading). A wake
  ::  with a reading opens a collection child, and one whose reading fails
  ::  ends the record; neither charges a model turn, so both pass through.
  =/  reading  (current:read inner b r)
  ?.  ?=([%& ~] reading)  ~
  =.  s  (derive s inner b u.id u.request.r)
  `[u.id u.request.r s(holds (~(put by holds.s) u.id [wire u.due.r]))]
++  deadlines
  |=  [cards=(list card) member=@ux request=@ux]
  ^-  (list @da)
  %+  murn  cards
  |=  c=card
  =/  t  ((soft ,[%pass [%native-coding %deadline session=@ta request=@ta ~] %arvo %b %wait at=@da]) c)
  ?~  t  ~
  ?.  &(=(`member (slaw %ux session.u.t)) =(`request (slaw %ux request.u.t)))  ~
  `at.u.t
++  compose
  ::  The single native event that consumes readiness, charges, reserves and
  ::  dispatches. Refusal returns no state at all: the caller keeps its core.
  |=  [s=state:ro inner=agent:gall b=bowl:gall id=@ux =receipt:ro]
  ^-  (each [cards=(list card) inner=agent:gall state=state:ro] @tas)
  =/  found  (~(get by intents.ledger.s) id)
  ?~  found  [%| %readiness-intent-missing]
  ?.  =(%prepared phase.u.found)  [%| %readiness-intent-not-prepared]
  =/  i=intent:rs  intent.u.found
  =/  hold  (~(get by holds.s) campaign.i)
  ?~  hold  [%| %readiness-task-not-staged]
  =/  cli  (cli-state b)
  ?~  cli  [%| %readiness-cli-unavailable]
  =/  offer  (~(get by offers.u.cli) receipt)
  ?~  offer  [%| %readiness-offer-missing]
  ?.  &(=(i intent.u.offer) =(key.receipt key.u.offer))  [%| %readiness-offer-mismatch]
  ?.  =(`key.receipt (~(get by keys.s) window.ready.u.offer))  [%| %readiness-window-key]
  =/  fresh  (native-intent inner b i)
  ?:  ?=(%| -.fresh)  [%| p.fresh]
  =/  admitted  (activate:readiness ledger.s now.b p.fresh ready.u.offer queue.u.cli)
  ?:  ?=(%| -.admitted)  [%| p.admitted]
  ?~  activation.p.admitted  [%| %readiness-replayed]
  =/  d=decision:rs  u.activation.p.admitted
  ::  The retained wake genuinely fired; it is delivered late, not invented.
  =^  first  inner  (on-arvo:~(. inner b) wire.u.hold [%behn %wake ~])
  =^  second  inner  (on-poke:~(. inner b(src our.b)) %noun !>([%qpc-instrument-dispatch-v1 member.i]))
  =/  cards=(list card)  (weld first second)
  =/  inferred  (murn cards infer:bind)
  ::  Backstop: a wake that still took the collection-child path made
  ::  progress without a model turn. Keep that progress; consume nothing.
  ?:  =(~ inferred)
    =/  after  (campaigns inner b)
    =/  moved  ?~(after ~ (~(get by records.u.after) campaign.i))
    ?.  &(?=(^ moved) =(%gating phase.u.moved))  [%| %readiness-dispatch-unconfirmed]
    [%& cards inner s(holds (~(del by holds.s) campaign.i))]
  ?.  ?&  =(1 (lent inferred))
          =(request.i id.request:(snag 0 inferred))
          =(member.i session.request:(snag 0 inferred))
          =(~[deadline.d] (deadlines cards member.i request.i))
      ==
    [%| %readiness-dispatch-unconfirmed]
  =/  next=state:ro
    s(ledger state.p.admitted, holds (~(del by holds.s) campaign.i), sent (~(put by sent.s) request.i (snag 0 inferred)))
  [%& (snoc cards (notice [%qpc-readiness-dispatched-v1 id request.i window.d])) inner next]
++  arm-command
  |=  [s=state:ro inner=agent:gall b=bowl:gall i=intent:rs]
  ^-  (each state:ro @tas)
  =/  fresh  (native-intent inner b i)
  ?:  ?=(%| -.fresh)  [%| p.fresh]
  ?.  =(i p.fresh)  [%| %readiness-arm-native-mismatch]
  =/  armed  (arm:readiness ledger.s i)
  ?:  ?=(%| -.armed)  [%| p.armed]
  [%& s(ledger p.armed, released (~(del in released.s) campaign.i))]
++  open-command
  |=  [s=state:ro inner=agent:gall b=bowl:gall window=@ux id=@ux key=@tas connector=@tas]
  ^-  (each state:ro @tas)
  =/  cs  (campaigns inner b)
  ?~  cs  [%| %readiness-campaigns-unavailable]
  =/  found  (~(get by records.u.cs) id)
  ?~  found  [%| %readiness-campaign-missing]
  ?.  =(key key.command.task.u.found)  [%| %readiness-key-mismatch]
  =/  paired  (pairing b key)
  ?~  paired  [%| %readiness-pairing-missing]
  ?.  &(active.binding.u.paired =(key key.binding.u.paired) =(connector connector.binding.u.paired))
    [%| %readiness-pairing-mismatch]
  =/  opened  (open-window:readiness ledger.s window id connector generation.u.paired now.b)
  ?:  ?=(%| -.opened)  [%| p.opened]
  [%& s(ledger p.opened, keys (~(put by keys.s) window key))]
++  close-command
  ::  The operator closes only after independently proving the finite
  ::  adapter's normal, reaped exit; turns come from this ledger, not a caller.
  |=  [s=state:ro b=bowl:gall window=@ux]
  ^-  (each state:ro @tas)
  =/  w  (~(get by windows.ledger.s) window)
  ?~  w  [%| %readiness-window-missing]
  =/  cli  (cli-state b)
  ?~  cli  [%| %readiness-cli-unavailable]
  =/  closed  (close-window:readiness ledger.s window now.b turns.u.w queue.u.cli)
  ?:  ?=(%| -.closed)  [%| p.closed]
  [%& s(ledger p.closed)]
++  cli-view
  ::  Every route answers a unit value. A missing path would bail the CLI's
  ::  event, so absence is ~, never [~ ~]. Shapes mirror sur/cli-inference.
  |=  [s=state:ro our=@p rest=path]
  ^-  (unit *)
  ?+    rest  ~
      [%readiness @ ~]
    =/  id  (slaw %ux i.t.rest)
    ?~  id  ~
    =/  found  (~(get by intents.ledger.s) u.id)
    ?~  found  ~
    ?.  =(%prepared phase.u.found)  ~
    =/  i=intent:rs  intent.u.found
    =/  w  (open-window-for s campaign.i connector.i)
    ?~  w  ~
    =/  key  (~(get by keys.s) id.u.w)
    ?~  key  ~
    `[%qpc-cli-readiness-context-v1 our u.key i u.w]
  ::
      [%window @ ~]
    =/  id  (slaw %ux i.t.rest)
    ?~  id  ~
    =/  w  (~(get by windows.ledger.s) u.id)
    ?~  w  ~
    =/  key  (~(get by keys.s) u.id)
    ?~  key  ~
    ?:  =(%closed phase.u.w)  `[%qpc-cli-next-v1 our u.key u.w %closed ~ ~]
    ?.  =(%open phase.u.w)  `[%qpc-cli-next-v1 our u.key u.w %blocked ~ `phase.u.w]
    =/  waiting=(list intent:rs)
      %+  murn  ~(val by intents.ledger.s)
      |=  v=record:rs
      ?.  &(=(%prepared phase.v) =(campaign.u.w campaign.intent.v) =(connector.u.w connector.intent.v))  ~
      `intent.v
    ?~  waiting  `[%qpc-cli-next-v1 our u.key u.w %waiting ~ `%readiness-no-prepared-intent]
    ?^  t.waiting  `[%qpc-cli-next-v1 our u.key u.w %blocked ~ `%readiness-ambiguous-intent]
    ?.  (~(has by holds.s) campaign.u.w)
      `[%qpc-cli-next-v1 our u.key u.w %waiting ~ `%readiness-task-not-staged]
    `[%qpc-cli-next-v1 our u.key u.w %ready `i.waiting ~]
  ::
      [%dispatch @ ~]
    =/  id  (slaw %ux i.t.rest)
    ?~  id  ~
    =/  rows=(list record:rs)
      (skim ~(val by intents.ledger.s) |=(v=record:rs =(u.id request.intent.v)))
    ?~  rows  `[%ordinary u.id]
    ?^  t.rows  `[%refused %readiness-request-ambiguous]
    =/  v=record:rs  i.rows
    ?.  =(%activated phase.v)  `[%refused %readiness-not-activated]
    ?~  activation.v  `[%refused %readiness-activation-missing]
    =/  d=decision:rs  u.activation.v
    =/  w  (~(get by windows.ledger.s) window.d)
    =/  key  (~(get by keys.s) window.d)
    =/  out  (~(get by sent.s) u.id)
    ?~  w  `[%refused %readiness-window-missing]
    ?~  key  `[%refused %readiness-window-key]
    ?~  out  `[%refused %readiness-request-unsent]
    `[%protected u.key request.u.out intent.v d u.w]
  ==
++  agent
  |=  inner=agent:gall
  =|  held=state:ro
  ^-  agent:gall
  |_  =bowl:gall
  +*  this  .
      ag  ~(. inner bowl)
  ++  on-init
    =^  cards  inner  on-init:ag
    [cards this]
  ++  on-save
    ::  No envelope until first used: an install leaves saved DATA, and every
    ::  existing reader of it, exactly as it was.
    ?:  =(held empty)  on-save:ag
    !>([%qpc-readiness-owner-v1 held on-save:ag])
  ++  on-load
    |=  old=vase
    =/  saved=[held=state:ro inner=vase]
      ?.  ?=([%qpc-readiness-owner-v1 *] q.old)  [empty old]
      =/  prior  !<([%qpc-readiness-owner-v1 held=state:ro inner=vase] old)
      +.prior
    ?>  (valid held.saved)
    =.  held  held.saved
    =^  cards  inner  (on-load:ag inner.saved)
    [cards this]
  ++  on-poke
    |=  [=mark =vase]
    ?:  &(=(%noun mark) ?=([%qpc-cli-ready-v1 @ [@ @ @]] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  c  ;;(ready:ro q.vase)
      =/  done  (compose held inner bowl intent.c receipt.c)
      ?:  ?=(%| -.done)  [~[(refused p.done)] this]
      [cards.p.done this(inner inner.p.done, held state.p.done)]
    ?:  &(=(%noun mark) ?=([%qpc-readiness-release-v1 @] q.vase))
      ::  A held wake is delivered now, on the ordinary unprotected path.
      ?>  =(our.bowl src.bowl)
      =/  campaign=@ux  ;;(@ux +.q.vase)
      =/  hold  (~(get by holds.held) campaign)
      =.  held  (release held campaign)
      =/  done  (notice [%qpc-readiness-released-v1 campaign ?=(^ hold)])
      ?~  hold  [~[done] this]
      =^  cards  inner  (on-arvo:ag wire.u.hold [%behn %wake ~])
      [(snoc cards done) this]
    ?:  &(=(%noun mark) ?=([?(%qpc-readiness-arm-v1 %qpc-readiness-open-v1 %qpc-readiness-close-v1 %qpc-readiness-stop-v1 %qpc-readiness-revoke-v1) *] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  c  ;;(command:ro q.vase)
      =/  moved=(each state:ro @tas)
        ?-  -.c
          %qpc-readiness-arm-v1     (arm-command held inner bowl intent.c)
          %qpc-readiness-open-v1    (open-command held inner bowl window.c campaign.c key.c connector.c)
          %qpc-readiness-close-v1   (close-command held bowl window.c)
          %qpc-readiness-stop-v1    [%& held(ledger (stop-window:readiness ledger.held window.c phase.c))]
          %qpc-readiness-revoke-v1  [%& held(ledger (revoke:readiness ledger.held intent.c))]
          %qpc-readiness-release-v1  [%| %readiness-release-has-own-route]
        ==
      ?:  ?=(%| -.moved)  [~[(refused p.moved)] this]
      [~[(notice [%qpc-readiness-accepted-v1 -.c])] this(held p.moved)]
    =^  cards  inner  (on-poke:ag mark vase)
    [cards this]
  ++  on-peek
    |=  =path
    ?:  ?=([%x %qpc %cli *] path)
      ?.  =(our.bowl src.bowl)  ~
      ``noun+!>((cli-view held our.bowl t.t.t.path))
    ?:  =(/x/qpc/readiness path)
      ?.  =(our.bowl src.bowl)  ~
      ``noun+!>(held)
    (on-peek:ag path)
  ++  on-arvo
    |=  [=wire =sign-arvo]
    =/  staged  (stage held inner bowl wire sign-arvo)
    ?^  staged
      [~[(notice [%qpc-readiness-held-v1 campaign.u.staged request.u.staged])] this(held state.u.staged)]
    =^  cards  inner  (on-arvo:ag wire sign-arvo)
    [cards this]
  ++  on-watch
    |=  =path
    =^  cards  inner  (on-watch:ag path)
    [cards this]
  ++  on-leave
    |=  =path
    =^  cards  inner  (on-leave:ag path)
    [cards this]
  ++  on-agent
    |=  [=wire =sign:agent:gall]
    =^  cards  inner  (on-agent:ag wire sign)
    [cards this]
  ++  on-fail
    |=  [=term =tang]
    =^  cards  inner  (on-fail:ag term tang)
    [cards this]
  --
--
