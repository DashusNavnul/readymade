::  Private, optional Cantrip assembly journal. No evaluation or effect cards.
::  The admitted tool thread assembles and retains before returning its result.
::  Retention records unchecked owner-supplied evidence, never a passed check.
/-  nc=native-coding
/+  assembly=native-coding-terminal-assembly, compiler=native-coding-compiler,
    tools=cantrip-native-coding, editor=native-coding-terminal-state,
    scalar=terminal-plan
|%
+$  retained
  [input=job:compiler seed=@ux fuel=@ud scope=@ux output=result:assembly]
+$  organ
  [%native-coding-terminal-assembly-state-v1 seed=(unit seed:assembly) results=(map @ux retained)]
+$  command
  $%  [%native-coding-terminal-assembly-install-v1 value=seed:assembly]
      [%native-coding-terminal-assembly-retain-v1 id=@ux value=retained]
  ==
++  empty
  ^-  organ
  [%native-coding-terminal-assembly-state-v1 ~ ~]
++  capacity  8
++  scope-digest
  |=  value=scope:tools
  ^-  @ux
  (shax (jam value))
++  retained-valid
  ::  Static joins only: reload never reads a ship, reruns or reinstalls code.
  |=  [id=@ux r=retained]
  ^-  ?
  ?.  ?&  =(id (key:tools request.input.r))
          (identifier:tools id)  (identifier:tools seed.r)
          (lte (met 0 scope.r) 256)
          (gte fuel.r 1)  (lte fuel.r 2.000.000)
          (lte (met 3 (jam r)) 2.097.152)
      ==
    %.n
  =/  source  (inputs:assembly input.r)
  ?:  ?=(%| -.source)  %.n
  =/  out=result:assembly  output.r
  ?.  (result-profile-valid:assembly out)  %.n
  =/  failed  (failure:assembly out)
  ?^  failed
    ?&  !=(0 reason.u.failed)  (lte (met 3 reason.u.failed) 128)
        (lte code.u.failed 65.535)  (lte (met 3 module.u.failed) 128)
        (lte (met 3 symbol.u.failed) 128)
    ==
  ?>  ?=(%& -.out)
  =/  value=evidence:assembly  p.out
  =/  b=bundle:editor  bundle.value
  ?&  =(seed.r seed.value)  =((identity:compiler input.r) job.value)
      (execution-valid:assembly value fuel.r)  (bundle-valid:editor b)
      =(`0 (arity:scalar initial.b))  =(`1 (arity:scalar valid.b))
      =(`2 (arity:scalar reduce.b))  =(`1 (arity:scalar contents.b))
  ==
++  valid
  |=  s=organ
  ^-  ?
  ?.  (lte ~(wyt by results.s) capacity)  %.n
  ?~  seed.s  =(0 ~(wyt by results.s))
  ?.  (seed-valid:assembly u.seed.s)  %.n
  %+  levy  ~(tap by results.s)
  |=  [id=@ux r=retained]
  ?.  &((retained-valid id r) =(digest.u.seed.s seed.r))  %.n
  (execution-seed-valid:assembly u.seed.s output.r)
++  act
  |=  [b=bowl:gall s=organ jobs=organ:tools c=command]
  ^-  (each organ @tas)
  ?.  =(our.b src.b)  [%| %terminal-assembly-owner-required]
  ?:  ?=(%native-coding-terminal-assembly-install-v1 -.c)
    ?^  seed.s
      ?:  =(u.seed.s value.c)  [%& s]
      [%| %terminal-assembly-seed-already-installed]
    ?.  (seed-valid:assembly value.c)  [%| %terminal-assembly-seed-invalid]
    ?:  %+  lien  ~(val by records.jobs)
        |=  r=record:tools
        &(?=(?(%compile %check) -.arguments.request.r) ?=(?(%running %unknown) stage.r))
      [%| %terminal-assembly-install-busy]
    [%& s(seed `value.c)]
  =/  incoming=retained  value.c
  =/  prior  (~(get by results.s) id.c)
  ?^  prior
    ::  An exact replay observes the journal even after the native job finishes.
    ?:  =(u.prior incoming)  [%& s]
    [%| %terminal-assembly-retention-conflict]
  ?~  seed.s  [%| %terminal-assembly-seed-missing]
  ?:  (gte ~(wyt by results.s) capacity)  [%| %terminal-assembly-capacity]
  ?.  &(=(digest.u.seed.s seed.incoming) (retained-valid id.c incoming))
    [%| %terminal-assembly-evidence-invalid]
  ?.  (execution-seed-valid:assembly u.seed.s output.incoming)
    [%| %terminal-assembly-profile-refused]
  =/  admitted  (~(get by records.jobs) id.c)
  ?~  admitted  [%| %terminal-assembly-admission-missing]
  ?.  &(=(%running stage.u.admitted) =(request.input.incoming request.u.admitted))
    [%| %terminal-assembly-admission-mismatch]
  =/  grant  (~(get by grants.jobs) grant.u.admitted)
  ?~  grant  [%| %terminal-assembly-grant-missing]
  ?.  &(=(scope.incoming (scope-digest u.grant)) =(project.input.incoming project.grant.u.grant))
    [%| %terminal-assembly-scope-mismatch]
  =/  allowed  (allowed:tools our.b now.b u.grant request.input.incoming)
  ?:  ?=(%| -.allowed)  [%| p.allowed]
  ?.  (pending:tools our.b now.b request.input.incoming)
    [%| %terminal-assembly-request-not-pending]
  ::  Clay, project mapping and exact numbered closure are read in this Gall
  ::  event. A same-ship output or source digest cannot substitute for this.
  =/  prepared
    (prepare:compiler our.b now.b project.input.incoming request.input.incoming)
  ?:  ?=(%| -.prepared)  [%| p.prepared]
  ?.  =(input.incoming p.prepared)  [%| %terminal-assembly-source-mismatch]
  [%& s(results (~(put by results.s) id.c incoming))]
++  report
  ::  The model receives bounded diagnostics and commitments, never PLAN code.
  |=  r=retained
  ^-  tool-output:nc
  ?.  (retained-valid (key:tools request.input.r) r)
    [%refused %terminal-assembly-evidence-invalid 'The retained assembly evidence is invalid.']
  =/  refs=(list @ux)  ~[(identity:compiler input.r) seed.r scope.r]
  =/  out=result:assembly  output.r
  =/  failed  (failure:assembly out)
  ?^  failed
    =/  detail=@t
      (cat 3 'Terminal artifact assembly refused: ' `@t`reason.u.failed)
    =.  refs
      ?.  ?=(%native-coding-compiler-refusal-v1 -.out)  refs
      [profile.out refs]
    [%diagnostics ~[[%gallowglass %.n detail source.context.request.input.r refs]]]
  ?>  ?=(%& -.out)
  =/  detail=@t
    'Terminal exports assembled and retained as unchecked artifacts. Type checking, native execution verification and explicit installation remain separate.'
  [%diagnostics ~[[%gallowglass %.n detail source.context.request.input.r [digest.bundle.p.out refs]]]]
--
