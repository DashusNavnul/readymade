::  Pure selected-source release and suggestion law; no cards or acceptance.
::  Future owner hook supplies current catalog, retained grants/records, law
::  window and same-event canonical basis. A caller's noun proves none of these.
/-  pa=cantrip-project-access, mp=multiplayer-project,
    mc=multiplayer-changeset, nc=native-coding
/+  project=multiplayer-project, changes=multiplayer-changeset,
    concurrency=multiplayer-concurrency, model=pataphor-editor-model,
    law=cantrip-law-window, coding=native-coding-project
|%
++  path-valid
  |=  pax=path
  ^-  ?
  ?~  pax  %.n
  ?&  (path-valid:model pax)
      |(=(%app i.pax) =(%lib i.pax) =(%ted i.pax))
      =(%hoon (rear pax))
      (gte (lent pax) 3)
  ==
++  paths-valid
  |=  paths=(set path)
  ^-  ?
  &((gth ~(wyt in paths) 0) (lte ~(wyt in paths) 8) (levy ~(tap in paths) path-valid))
++  digest
  |=  g=grant:pa
  ^-  @ux
  (shax (jam [%cantrip-project-access-v1 g]))
++  grant-valid
  |=  g=grant:pa
  ^-  ?
  ?&  !=(0 project.g)  (segment-valid:model desk.g)
      !=(0 law-version.g)  !=(0 law-digest.g)
      (gth generation.g 0)  !=(0 issued.g)
      |(=(0 expires.g) &((lth issued.g expires.g) (lte expires.g (add issued.g ~d1))))
      (paths-valid paths.g)  |(view.permissions.g suggest.permissions.g)
      (lte joined-at.member.g issued.g)
      !=(%model role.member.g)
      ?|  !suggest.permissions.g
          |(=(%operator role.member.g) =(%maintainer role.member.g) =(%contributor role.member.g))
      ==
  ==
++  time-valid
  ::  Zero is the native standing grant sentinel; revocation is separate.
  |=  [g=grant:pa now=@da]
  ^-  ?
  &((lte issued.g now) |(=(0 expires.g) (lth now expires.g)))
++  source-current
  ::  Scope is a same-event canonical Viki read supplied by the native hook.
  ::  Never rewrite the catalog to turn a working desk into a base desk.
  |=  [p=project:mp g=grant:pa scope=(unit project:nc)]
  ^-  ?
  ?:  =(desk.g base-desk.spec.p)  %.y
  ?~  scope  %.n
  ?&  (valid:coding u.scope)  =(spec.p spec.u.scope)
      =(desk.g working.u.scope)
      (levy ~(tap in paths.g) |=(pax=path (readable:coding u.scope pax)))
  ==
++  member-current
  |=  [our=@p now=@da p=project:mp g=grant:pa]
  ^-  ?
  (member-scoped our now p g ~)
++  member-scoped
  |=  [our=@p now=@da p=project:mp g=grant:pa scope=(unit project:nc)]
  ^-  ?
  =/  found  (~(get by members.p) peer.g)
  ?~  found  %.n
  ?&  (project-valid:project p)  (time-valid:project p now)
      =(our authority.spec.p)  =(our owner.g)
      =(project.g id.spec.p)  (source-current p g scope)
      =(law-version.g law-version.spec.p)  =(law-digest.g law-digest.spec.p)
      =(member.g u.found)
  ==
++  issue
  ::  Explicit owner action; current membership alone grants nothing.
  ::  issued is the owner's validity start. Transport crosses native events;
  ::  preserve that bound and exact replay bytes instead of demanding now.
  |=  [our=@p actor=@p now=@da p=project:mp held=grants:pa g=grant:pa]
  ^-  (each grants:pa @tas)
  (issue-scoped our actor now p held g ~)
++  issue-scoped
  |=  [our=@p actor=@p now=@da p=project:mp held=grants:pa g=grant:pa scope=(unit project:nc)]
  ^-  (each grants:pa @tas)
  ?.  =(our actor)  [%| %foreign-owner]
  ?.  &((grant-valid g) (member-scoped our now p g scope))  [%| %grant-invalid]
  ?.  (time-valid g now)  [%| %grant-time]
  =/  old  (~(get by held) [project.g peer.g])
  ?^  old
    ?:  &(=(g grant.u.old) !revoked.u.old)  [%& held]
    ?.  =(generation.g +(generation.grant.u.old))  [%| %generation-conflict]
    ?:  &(revoked.u.old (gte (live held project.g) project-limit))  [%| %grant-capacity]
    [%& (~(put by held) [project.g peer.g] [g %.n])]
  ?.  =(1 generation.g)  [%| %generation-conflict]
  ?:  (gte (live held project.g) project-limit)  [%| %grant-capacity]
  ?:  (gte ~(wyt by held) record-limit)  [%| %grant-capacity]
  [%& (~(put by held) [project.g peer.g] [g %.n])]
::  Limits sized for twelve people a project. A project may have this many
::  LIVE file grants (one per member; a project holds sixteen ships). Revoked
::  grants stay in the map for ever, because a later grant must carry the
::  next generation; they no longer use up the live limit. Before 2026-11-11
::  the map itself stopped at 32 entries, revoked ones included: twelve
::  people in three projects, or a few rounds of leaving and rejoining,
::  would have ended file sharing on the ship for good.
++  project-limit  16
++  record-limit  512
++  live
  |=  [held=grants:pa id=project-id:mp]
  ^-  @ud
  %-  lent
  %+  skim  ~(tap by held)
  |=  [key=[project-id:mp @p] e=entry:pa]
  &(=(id -.key) !revoked.e)
++  revoke
  |=  [our=@p actor=@p held=grants:pa key=[project-id:mp @p] generation=@ud]
  ^-  (each grants:pa @tas)
  ?.  =(our actor)  [%| %foreign-owner]
  =/  old  (~(get by held) key)
  ?~  old  [%| %grant-missing]
  ?.  &(=(our owner.grant.u.old) =(generation generation.grant.u.old))
    [%| %generation-conflict]
  [%& (~(put by held) key u.old(revoked %.y))]
++  authorize
  ::  Only %read/%compare law; no %inscribe, run, accept or model access.
  |=  [our=@p actor=@p now=@da p=project:mp held=grants:pa r=request:pa w=window:law]
  ^-  (each grant:pa @tas)
  (authorize-scoped our actor now p held r w ~)
++  authorize-scoped
  |=  [our=@p actor=@p now=@da p=project:mp held=grants:pa r=request:pa w=window:law scope=(unit project:nc)]
  ^-  (each grant:pa @tas)
  ?.  &(=(project.r id.spec.p) !=(0 nonce.r) (lte (met 0 nonce.r) 128))
    [%| %request-invalid]
  =/  old  (~(get by held) [project.r actor])
  ?~  old  [%| %grant-missing]
  =/  g=grant:pa  grant.u.old
  ?.  &(=(actor peer.g) (grant-valid g) (member-scoped our now p g scope))  [%| %membership-changed]
  ?:  revoked.u.old  [%| %grant-revoked]
  ?.  =(generation.r generation.g)  [%| %generation-conflict]
  ?.  (time-valid g now)  [%| %grant-expired]
  ?.  |(=(%view action.r) =(%suggest action.r))  [%| %action-refused]
  ?.  ?:(=(%view action.r) view.permissions.g suggest.permissions.g)
    [%| %permission-refused]
  =/  act=act:law  ?:(=(%view action.r) %read %compare)
  ?.  &((~(has in admissible.w) act) !(~(has in blocked.w) act))
    [%| %law-refused]
  [%& g]
++  basis-valid
  |=  b=basis:pa
  ^-  ?
  =/  paths=(set path)  ~(key by files.b)
  ?.  ?&  !=(0 at.b)  !=(0 root.b)  (paths-valid paths)
          (snapshot-valid:changes snapshot.b)
          =(paths ~(key by files.body.snapshot.b))
      ==  %.n
  =/  rows=(list [pax=path source=@t])  ~(tap by files.b)
  =/  bytes=@ud  0
  |-  ^-  ?
  ?~  rows  (lte bytes 65.536)
  =/  hash  (~(get by files.body.snapshot.b) pax.i.rows)
  ?~  hash  %.n
  ?.  &((text-valid:model source.i.rows) (lte (met 3 source.i.rows) 32.768) =(u.hash (shax source.i.rows)))
    %.n
  $(rows t.rows, bytes (add bytes (met 3 source.i.rows)))
++  perform
  ::  Replays are checked AFTER current authority, never after revocation.
  ::  Returning a plan is not disclosure: future hook persists then releases
  ::  only to actor in the same native event. Never expose these via raw scry.
  |=  [our=@p actor=@p now=@da p=project:mp held=grants:pa saved=records:pa r=request:pa b=basis:pa w=window:law]
  ^-  result:pa
  (perform-scoped our actor now p held saved r b w ~)
++  perform-scoped
  |=  [our=@p actor=@p now=@da p=project:mp held=grants:pa saved=records:pa r=request:pa b=basis:pa w=window:law scope=(unit project:nc)]
  ^-  result:pa
  =/  permitted  (authorize-scoped our actor now p held r w scope)
  ?:  ?=(%| -.permitted)  [%| p.permitted]
  =/  g=grant:pa  p.permitted
  =/  key=[project-id:mp @p @ud @ux]  [project.r actor generation.r nonce.r]
  =/  old  (~(get by saved) key)
  ?^  old
    ?.  &(=(r request.u.old) =((digest g) grant.u.old) =(our owner.u.old) =(actor peer.u.old))
      [%| %nonce-conflict]
    [%& [saved u.old]]
  ?.  ?&  (basis-valid b)  =(our owner.b)  =(now at.b)
          =(project.g project.body.snapshot.b)  =(desk.g base-desk.body.snapshot.b)
          =(paths.g ~(key by files.b))
      ==  [%| %basis-invalid]
  ?:  (gte ~(wyt by saved) 64)  [%| %receipt-capacity]
  =/  body=(each payload:pa @tas)
    ?:  =(%view action.r)
      ?.  &(?=(~ parent.r) ?=(~ pax.r) =(0 source.r))  [%| %request-invalid]
      [%& [%view b]]
    ?.  &((~(has in paths.g) pax.r) (text-valid:model source.r) (lte (met 3 source.r) 32.768))
      [%| %suggestion-path-or-size]
    ?~  parent.r  [%| %parent-missing]
    ?.  =(u.parent.r [root.b snapshot.b])  [%| %stale-parent]
    =/  before  (~(get by files.body.snapshot.b) pax.r)
    =/  change=change:mc  [%modify pax.r before `(shax source.r)]
    ?.  (change-valid:changes files.body.snapshot.b change)  [%| %change-invalid]
    =/  comparison  (compare-one:concurrency files.body.snapshot.b files.body.snapshot.b change)
    ?.  =(%clean verdict.comparison)  [%| %change-not-clean]
    [%& [%suggest u.parent.r change source.r]]
  ?:  ?=(%| -.body)  [%| p.body]
  =/  receipt=receipt:pa  [our actor now (digest g) r p.body]
  [%& [(~(put by saved) key receipt) receipt]]
--
