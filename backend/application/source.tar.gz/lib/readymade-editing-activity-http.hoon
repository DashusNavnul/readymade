::  Bounded owner HTTP codec only. Querying never announces editing or consent.
::  The app checks local Gall src, generates ids, and supplies filtered replies.
/+  server=readymade-editing-activity-owner, access=cantrip-project-access,
    mg=readymade-app-management, terminal=native-coding-terminal
|%
+$  command  [owner=@p project=@t action=action:server]
+$  selector  [owner=@p project=@t request=@uv]
++  project-valid
  |=  text=@t
  ^-  ?
  ?&  (gth (met 3 text) 0)  (lte (met 3 text) 128)
      (levy (trip text) |=(c=@t &((gte c 32) !=(c 127) !=(c ':'))))
  ==
++  ship
  |=  text=@t
  ^-  @p
  ?>  (lte (met 3 text) 128)
  =/  value=@p  (need (slaw %p text))
  ?>  &((lte (met 0 value) 128) =(text (scot %p value)))
  value
++  select
  |=  [owner=@t project=@t request=@t]
  ^-  selector
  ?>  (project-valid project)
  ?>  (lte (met 3 request) 64)
  =/  id=@uv  (need (slaw %uv request))
  ?>  &((gth id 0) (lte (met 0 id) 256) =(request (scot %uv id)))
  [(ship owner) project id]
++  decode
  |=  raw=@t
  ^-  command
  ?>  (lte (met 3 raw) 8.192)
  =/  value=json  (need (de:json:html raw))
  ?>  ?=(%o -.value)
  =/  obj=(map @t json)  p.value
  =/  fields=@ud  ~(wyt by obj)
  ::  Every accepted value is a string without a colon. This also rejects
  ::  duplicate keys (including escaped aliases), nested values and extras.
  ?>  =(fields (lent (skim (trip raw) |=(c=@t =(c ':')))))
  ?>  =('readymade-editing-activity-v1' (text-field:mg obj 'schema' 64))
  =/  owner=@p  (ship (text-field:mg obj 'owner' 128))
  =/  project=@t  (text-field:mg obj 'project' 128)
  ?>  (project-valid project)
  =/  operation=@t  (text-field:mg obj 'operation' 16)
  ?:  =('query' operation)
    ?>  =(4 fields)
    [owner project [%query ~]]
  ?>  |(=('update' operation) =('stop' operation))
  =/  text=@t  (text-field:mg obj 'epoch' 64)
  =/  epoch=@da  (need (slaw %da text))
  ?>  &((gth epoch 0) (lte (met 0 epoch) 128) =(text (scot %da epoch)))
  =/  text=@t  (text-field:mg obj 'sequence' 32)
  =/  sequence=@ud  (need (slaw %ud text))
  ?>  &((gth sequence 0) (lte (met 0 sequence) 64) =(text (scot %ud sequence)))
  ?:  =('stop' operation)
    ?>  =(6 fields)
    [owner project [%update [owner project epoch] [sequence ~]]]
  ?>  =(8 fields)
  =/  desk=@tas  (text-field:mg obj 'desk' 64)
  ?>  (desk-valid:mg desk)
  =/  text=@t  (text-field:mg obj 'path' 2.064)
  =/  pax=path  (path-of:terminal ~ text)
  ?>  &(=(text (spat pax)) (path-valid:access pax))
  [owner project [%update [owner project epoch] [sequence `[desk pax]]]]
++  parse
  |=  raw=@t
  ^-  (unit command)
  (mole |.((decode raw)))
++  post-request
  |=  req=inbound-request:eyre
  ^-  (unit command)
  ?.  &(authenticated.req =('POST' method.request.req))  ~
  =/  host  (header:mg header-list.request.req 'host')
  =/  origin  (header:mg header-list.request.req 'origin')
  =/  mime  (header:mg header-list.request.req 'content-type')
  ?~  host  ~
  ?~  origin  ~
  ?~  mime  ~
  ?.  ?&  =(u.origin (cat 3 ?:(secure.req 'https://' 'http://') u.host))
          |(=(u.mime 'application/json') =(u.mime 'application/json; charset=utf-8'))
          =(`'v1' (header:mg header-list.request.req 'x-readymade-editing-activity'))
      ==  ~
  ?~  body.request.req  ~
  =/  body  u.body.request.req
  ?.  &((lte p.body 8.192) =(p.body (met 3 q.body)))  ~
  (parse q.body)
++  result-request
  |=  req=inbound-request:eyre
  ^-  (unit selector)
  ?.  &(authenticated.req =('GET' method.request.req))  ~
  =/  owner  (header:mg header-list.request.req 'x-readymade-activity-owner')
  =/  project  (header:mg header-list.request.req 'x-readymade-project')
  =/  request  (header:mg header-list.request.req 'x-readymade-activity-request')
  ?~  owner  ~
  ?~  project  ~
  ?~  request  ~
  (mole |.((select u.owner u.project u.request)))
++  encode
  ::  Accept only client.result output, already filtered for this recipient.
  ::  No room, grant, request body or journal enters this encoder.
  |=  [key=selector reply=response:server]
  ^-  json
  ?>  &((project-valid project.key) (gth request.key 0) (lte (met 0 request.key) 256))
  ?>  (lte (met 0 owner.key) 128)
  ?>  &(=(request.key id.reply) =(project.key project.reply))
  =/  details=(list [@t json])
    ?.  ?=(%& -.result.reply)
      ?>  (lte (met 3 p.result.reply) 128)
      ~[['status' s+'refused'] ['reason' s+p.result.reply] ['epoch' ~] ['at' ~] ['rows' a+~] ['selfSequence' ~]]
    =/  s=snapshot:server  p.result.reply
    ?>  ?&  =(owner.key owner.address.s)  =(project.key project.address.s)
            !=(0 epoch.address.s)  (lte epoch.address.s at.s)
            (lte (met 0 at.s) 128)  (lte (lent rows.s) 32)
        ==
    =/  self=json
      ?~  self-sequence.s  ~
      ?>  &((gth u.self-sequence.s 0) (lte (met 0 u.self-sequence.s) 64))
      s+(scot %ud u.self-sequence.s)
    =/  rows=(list json)
      %+  turn  rows.s
      |=  row=[ship=@p file=[desk=@tas pax=path]]
      ?>  &((lte (met 0 ship.row) 128) (desk-valid:mg desk.file.row) (path-valid:access pax.file.row))
      (pairs:enjs:format ~[['ship' s+(scot %p ship.row)] ['desk' s+desk.file.row] ['path' s+(spat pax.file.row)]])
    ~[['status' s+'ready'] ['reason' ~] ['epoch' s+(scot %da epoch.address.s)] ['at' s+(scot %da at.s)] ['rows' a+rows] ['selfSequence' self]]
  =/  value=json
    %-  pairs:enjs:format
    %+  weld
      ^-  (list [@t json])
      :~  ['schema' s+'readymade-editing-activity-result-v1']
          ['owner' s+(scot %p owner.key)]  ['project' s+project.key]
          ['request' s+(scot %uv request.key)]  ['permissionGranted' b+%.n]
      ==
    details
  ?>  (lte (met 3 (en:json:html value)) 65.536)
  value
++  response
  |=  [key=selector reply=response:server]
  ^-  (unit json)
  (mole |.((encode key reply)))
--
