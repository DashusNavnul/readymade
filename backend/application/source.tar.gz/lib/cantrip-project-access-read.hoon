::  Private owner-side reads only. No peer scry/export endpoint is installed.
::  Future Cantrip owner hook supplies its current app-owned law window and
::  canonical retained grants/records; never scry Cantrip from inside itself.
/-  pa=cantrip-project-access, mp=multiplayer-project, nc=native-coding
/+  access=cantrip-project-access, changes=multiplayer-changeset,
    editor=pataphor-editor-read, model=pataphor-editor-model,
    dsr=desk-shell-read, law=cantrip-law-window, guard=viki-scry-guard
|%
++  catalog
  |=  [our=@p actor=@p at=@da id=project-id:mp]
  ^-  (each project:mp @tas)
  ?.  =(our actor)  [%| %foreign-owner]
  ?.  &(!=(0 at) !=(0 id) (lte (met 3 id) 128))  [%| %invalid-project]
  =/  found=(unit project:mp)
    .^((unit project:mp) %gx /(scot %p our)/multiplayer-runtime/(scot %da at)/catalog/[id]/noun)
  ?~  found  [%| %project-missing]
  ?.  &(=(our authority.spec.u.found) =(id id.spec.u.found))  [%| %foreign-project]
  [%& u.found]
++  scope
  ::  Resolve only the registered project working desk. Session clones are
  ::  separate scopes and are not inferred from a caller-supplied desk name.
  |=  [our=@p actor=@p at=@da p=project:mp g=grant:pa]
  ^-  (unit project:nc)
  ?.  &(=(our actor) =(our authority.spec.p) =(project.g id.spec.p))  ~
  ?:  =(desk.g base-desk.spec.p)  ~
  ?.  (agent-live:guard our at %viki)  ~
  =/  projects=(map @t project:nc)
    .^((map @t project:nc) %gx /(scot %p our)/viki/(scot %da at)/native-coding/projects/noun)
  =/  found  (~(get by projects) id.spec.p)
  ?.  (source-current:access p g found)  ~
  found
++  basis
  |=  [our=@p actor=@p at=@da g=grant:pa]
  ^-  (each basis:pa @tas)
  ?.  =(our actor)  [%| %foreign-owner]
  ?.  (grant-valid:access g)  [%| %grant-invalid]
  =/  p  (catalog our actor at project.g)
  ?:  ?=(%| -.p)  [%| p.p]
  ?.  (member-scoped:access our at p.p g (scope our actor at p.p g))  [%| %membership-changed]
  =/  desks=(set @tas)
    .^((set @tas) %cd ~[(scot %p our) '' (scot %da at)])
  ?.  (~(has in desks) desk.g)  [%| %desk-missing]
  ?.  (private-path:editor our at desk.g /)  [%| %desk-not-private]
  =/  revision=revision:model  (revision:editor our at desk.g)
  =/  remaining=(list path)  ~(tap in paths.g)
  =/  files=(map path @t)  ~
  =/  hashes=(map path @ux)  ~
  =/  bytes=@ud  0
  |-  ^-  (each basis:pa @tas)
  ?~  remaining
    =/  snapshot  (make-snapshot:changes [1 project.g desk.g number.revision hashes])
    =/  b=basis:pa  [our at `@ux`root.revision snapshot files]
    ?.  (basis-valid:access b)  [%| %basis-invalid]
    [%& b]
  =/  pax=path  i.remaining
  ?.  (private-path:editor our at desk.g pax)  [%| %path-not-private]
  =/  node=arch  .^(arch %cy (beam:dsr our at desk.g pax))
  ?~  fil.node  [%| %file-missing]
  =/  body=content:model
    (classify:model %hoon .^(* %cx (beam:dsr our at desk.g pax)))
  ?.  ?=(%text -.body)  [%| %unsupported-source]
  =/  size=@ud  (met 3 source.body)
  ?.  &((lte size 32.768) (lte (add bytes size) 65.536))  [%| %source-over-limit]
  $(remaining t.remaining, files (~(put by files) pax source.body), hashes (~(put by hashes) pax hash.body), bytes (add bytes size))
++  prepare
  ::  actor must be the local owner; peer must come from Gall src.bowl in
  ::  the future release handler, never a peer field trusted from a poke.
  ::  This returns a private plan only. No cards, file writes or disclosure.
  |=  [our=@p actor=@p peer=@p at=@da held=grants:pa saved=records:pa r=request:pa w=window:law]
  ^-  result:pa
  ?.  =(our actor)  [%| %foreign-owner]
  =/  p  (catalog our actor at project.r)
  ?:  ?=(%| -.p)  [%| p.p]
  =/  existing  (~(get by held) [project.r peer])
  ?~  existing  [%| %grant-missing]
  =/  current  (scope our actor at p.p grant.u.existing)
  =/  allowed  (authorize-scoped:access our peer at p.p held r w current)
  ?:  ?=(%| -.allowed)  [%| p.allowed]
  =/  b  (basis our actor at p.allowed)
  ?:  ?=(%| -.b)  [%| p.b]
  (perform-scoped:access our peer at p.p held saved r p.b w current)
--
