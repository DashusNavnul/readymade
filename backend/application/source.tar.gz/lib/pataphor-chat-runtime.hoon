::  Own private state: the conversation's asks, their polls and results.
::  The connected chats went with the Noltbook app (removed 2026-09-23); the
::  action type still names them for older callers, and they are refused here.
/-  pc=pataphor-chat, a=a2a
/+  store=pataphor-chat-store
|%
+$  card  card:agent:gall
++  mid
  |=  id=@ud
  ^-  @ta
  `@ta`(cat 3 'request-' (scot %ud id))
++  hc
  |_  [=bowl:gall st=state-0:pc]
  ++  arm
    |=  out=(quip card state-0:pc)
    ^-  (quip card state-0:pc)
    =/  next=state-0:pc  +.out
    ?^  poll-at.next  out
    ?.  ?=(^ active.next)  out
    =/  due=@da  (add now.bowl ~s5)
    =/  timer=card  [%pass /poll/(scot %da due) %arvo %b %wait due]
    [(snoc -.out timer) next(poll-at `due)]
  ++  boot
    ::  bind the page; a Noltbook results watch an older shape still holds is dropped
    ^-  (list card)
    =/  route=card
      [%pass /bind %arvo %e %connect [~ /apps/pataphor] dap.bowl]
    ?.  (~(has by wex.bowl) [/noltbook-results our.bowl %noltbook])  ~[route]
    ~[route [%pass /noltbook-results %agent [our.bowl %noltbook] %leave ~]]
  ++  act
    |=  command=action:pc
    ^-  (quip card state-0:pc)
    ?-  -.command
      %ask
        ?.  .^(? %gu /(scot %p our.bowl)/a2a/(scot %da now.bowl)/$)
          `st(error `'Pataphor task service is unavailable. Nothing was submitted.')
        =/  begun=(each state-0:pc @t)
          (begin:store now.bowl text.command st)
        ?:  ?=(%| -.begun)  `st(error `p.begun)
        =/  next=state-0:pc  p.begun
        ?>  ?=(^ active.next)
        =/  id=@ud  u.active.next
        =/  body=@t  (prompt:store id next)
        :_  next
        ~[[%pass /private/(scot %ud id) %agent [our.bowl %a2a] %poke %noun !>([%local-send (mid id) epoch.next body])]]
      %new  `(reset:store st)
      ::  the connected chats are gone with the Noltbook app: refused, and the
      ::  state they used is emptied rather than carried
      %connect  `st(error `'Connected chats are gone: the Noltbook app was removed on 2026-09-23.')
      %send  `st(error `'Connected chats are gone: the Noltbook app was removed on 2026-09-23.')
      %disconnect  `st(connected ~, pending ~, unconfirmed ~, shared-error ~)
      %stop-tracking  `st(pending ~, unconfirmed ~, shared-error ~)
    ==
  ++  poll-private
    ^-  state-0:pc
    ?~  active.st  st
    =/  id=@ud  u.active.st
    ?.  .^(? %gu /(scot %p our.bowl)/a2a/(scot %da now.bowl)/$)
      st(error `'Private request retained: task service unavailable; not resubmitting.')
    =/  read=(each * tang)
      %-  mule
      |.  .^(* %gx /(scot %p our.bowl)/a2a/(scot %da now.bowl)/local/task/[epoch.st]/(mid id)/noun)
    ?:  ?=(%| -.read)  st(error `'Private task read unavailable; not resubmitting.')
    =/  parsed=(unit (unit task:a))  ((soft (unit task:a)) p.read)
    ?~  parsed  st(error `'Private task returned an unexpected shape.')
    ?~  u.parsed  st
    =/  task=task:a  u.u.parsed
    (finish:store id state.task artifact.task st(error ~))
  ++  poll
    ^-  state-0:pc
    poll-private
  ++  tick
    |=  wire=wire
    ^-  (quip card state-0:pc)
    ::  Any /poll wake polls and re-arms. A wake whose wire no longer matches
    ::  poll-at (a timer set before a reload, an adoption from another agent)
    ::  used to be dropped on the floor, which left poll-at set to a timer
    ::  that would never come: the request stayed active, the page said
    ::  "refresh", and nothing ever refreshed. One timer at a time still holds.
    ?.  ?=([%poll *] wire)  `st
    =/  next=state-0:pc  st(poll-at ~)
    (arm [~ poll:~(. hc bowl next)])
  ++  sign
    |=  [wire=wire event=sign:agent:gall]
    ^-  (quip card state-0:pc)
    ?.  ?=(%poke-ack -.event)  `st
    ?~  p.event  `st
    ?:  ?=([%private @ ~] wire)
      ?~  active.st  `st
      ?.  =(i.t.wire (scot %ud u.active.st))  `st
      `(finish:store u.active.st %failed `'Pataphor refused the request. No successful execution is claimed.' st)
    `st
  --
--
