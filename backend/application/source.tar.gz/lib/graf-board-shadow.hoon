::  /lib/graf-board-shadow.hoon
::
::  Pure Board law for Graf's native Board host.  It runs the donor's own
::  kernel (lib/graf-board-kernel) over Graf's copy: guards, metered gates,
::  walker law, and receipts are preserved verbatim, and the kernel's own
::  bounded outbox retains every accepted territory event.  No card leaves:
::  since %siev gave up the Board (2026-10-20) Graf RECORDS each event itself,
::  under its %graf-board territory (+transition hands app/graf the event).
::
/-  gb=graf-board, gsv=graf-siev-shadow, graf-event
/+  gbk=graf-board-kernel
|%
++  initial
  ^-  board-shadow:gsv
  [initial-board-state:gbk %shadow ~]
::
++  shadow-valid
  |=  sh=board-shadow:gsv
  ^-  ?
  ?&  =(%shadow mode.sh)
      =(~ seal.sh)
      =(%8 -.board.sh)
  ==
::
::  Mirror of the donor's %graf-board-action arm minus authority and cards:
::  same ship gate inputs, same live-gate and lease-binding derivation, same
::  kernel transition.  The event is returned for Graf to record; outbox.board
::  also keeps it, bounded by the kernel's own cap.
++  apply
  |=  $:  sh=board-shadow:gsv
          act=board-action:gb
          actor=@p
          sovereign=@p
          =bowl:gall
      ==
  ^-  board-shadow:gsv
  sh:(transition sh act actor sovereign bowl)
::
++  transition
  |=  $:  sh=board-shadow:gsv
          act=board-action:gb
          actor=@p
          sovereign=@p
          =bowl:gall
      ==
  ^-  [sh=board-shadow:gsv event=(unit territory-event:graf-event)]
  ?.  (shadow-valid sh)  [sh ~]
  =/  live=(set @t)
    ?:  ?=(%advance-walker -.act)
      (live-gates:gbk bindings.board.sh bowl)
    ~
  =/  can-bind=?
    ?:  ?=(%bind-gate-lease -.act)
      (binding-live:gbk binding.act bowl)
    %.n
  =/  result=board-transition:gbk
    (apply-board-action:gbk board.sh act actor sovereign live can-bind)
  [sh(board state.result) event.result]
::
++  shadow-identity
  ^-  board-authority-identity:gb
  ['graf-board-shadow-v1' %graf %graf-board 0 %.n %.y %.n]
::
++  status-of
  |=  sh=board-shadow:gsv
  ^-  board-authority-status:gb
  :*  'graf-board-shadow-status-v1'
      %shadow
      (lent accepted-actions.board.sh)
      (mug board.sh)
      ~
      %.n
      %.y
      %.n
  ==
::
::  The donor's authority read surface, served over the shadow copy under
::  /x/graf-board/shadow/*.  The cutover flip renames shadow to authority
::  and retargets callers; the shapes are already the donor's.
++  peek-board-shadow
  |=  [sh=board-shadow:gsv pax=path =bowl:gall]
  ^-  (unit (unit cage))
  ?+  pax  ~
    [%identity ~]
      ``noun+!>(shadow-identity)
    [%status ~]
      ``noun+!>((status-of sh))
    [%state ~]
      ``noun+!>(board.sh)
    [%outbox ~]
      ``noun+!>(accepted-actions.board.sh)
    [%territory-outbox ~]
      ``noun+!>(outbox.board.sh)
    [%board %acts ~]
      ``noun+!>(acts.board.sh)
    [%board %edges @ ~]
      =/  aid  `@t`i.t.t.pax
      ``noun+!>((skim edges.board.sh |=(e=act-edge:gb =(from-act.e aid))))
    [%board %weights ~]
      ``noun+!>((weights-of:gbk edges.board.sh walkers.board.sh))
    [%board %last-fire ~]
      ``noun+!>(last-fire.board.sh)
    [%board %last-guard ~]
      ``noun+!>(last-guard.board.sh)
    [%walk @ ~]
      =/  wid  `@t`i.t.pax
      ``noun+!>((find-walker:gbk walkers.board.sh wid))
    [%walk @ %next ~]
      =/  wid  `@t`i.t.pax
      =/  live=(set @t)  (live-gates:gbk bindings.board.sh bowl)
      ``noun+!>((menu-of:gbk acts.board.sh edges.board.sh walkers.board.sh gates.board.sh bindings.board.sh regions.board.sh targets.board.sh live src.bowl our.bowl wid))
    [%dispatch %latest ~]
      ``noun+!>(last-receipt.board.sh)
  ==
--
