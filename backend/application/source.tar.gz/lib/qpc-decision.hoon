::  Immutable QPC decision lifecycle. The owning agent supplies canonical
::  work/evidence records and grants. Hashes bind content; they grant no trust.
/+  ct=qpc-ct-update, select=qpc-select
|%
+$  binding
  [project=@ux session=@ux source=@ux epoch=@ux manifest=@ux law=@ux authority=@ux]
+$  outcome  [verdict=?(%pass %fail %unknown) evidence=@ux]
+$  observation
  $:  id=@ux  step=@ud  work=@ux  source=@ux  epoch=@ux  segment=@ux  law=@ux
      confidence=report:ct  outcomes=(list outcome)
  ==
+$  proposal
  $:  id=@ux  effect=@  evidence=@ux  eligible=?  energy=ratio:select
  ==
+$  state
  $:  %qpc-decision-v1
      id=@ux  binding=binding  dimensions=@ud  width=@ud  gain=@ud
      live=(list observation)  reference=(list observation)
      reading=reading:ct  mixed-law=?
      proposals=(list proposal)  selection=(unit receipt:select)
      phase=?(%proposing %selected %released %closed)
      result=(unit [kind=?(%applied %failed %refused %cancelled %unknown) evidence=@ux])
  ==
++  identifier
  |=  id=@ux
  ?&((gth id 0) (lte (met 0 id) 256))
++  binding-valid
  |=  value=binding
  =/  ids=(list @ux)
    ~[project.value session.value source.value epoch.value manifest.value law.value authority.value]
  (levy ids identifier)
++  observations-valid
  |=  [epoch=@ux dimensions=@ud rows=(list observation)]
  ^-  ?
  ?:  =(0 (lent rows))  %.n
  =/  first=observation  (snag 0 rows)
  =/  segment=@ux  segment.first
  ?.  (identifier segment)  %.n
  =/  previous=(unit @ud)  ~
  =/  works=(set @ux)  ~
  =/  ids=(set @ux)  ~
  |-  ^-  ?
  ?~  rows  %.y
  =/  r=observation  i.rows
  ?.  ?&  (identifier id.r)  (identifier work.r)  (identifier source.r)
          (identifier law.r)  =(epoch epoch.r)  =(segment segment.r)
          (lte (met 0 step.r) 64)
          =((lent outcomes.r) dimensions)
          (levy outcomes.r |=(o=outcome ?:(=(%unknown verdict.o) =(0 evidence.o) (identifier evidence.o))))
          !(~(has in works) work.r)  !(~(has in ids) id.r)
          ?~(previous %.y =(step.r +(u.previous)))
      ==
    %.n
  $(rows t.rows, previous `step.r, works (~(put in works) work.r), ids (~(put in ids) id.r))
++  open
  |=  [binding=binding dimensions=@ud width=@ud gain=@ud live=(list observation) reference=(list observation)]
  ^-  (each state @tas)
  ?.  (binding-valid binding)  [%| %invalid-binding]
  ?.  ?&((gth gain 0) (lte gain 32.000.000))  [%| %invalid-gain]
  ::  Check report shape before traversing metadata or taking the last row.
  =/  measured=(each reading:ct @tas)
    (measure:ct dimensions width (turn live |=(r=observation confidence.r)) (turn reference |=(r=observation confidence.r)))
  ?:  ?=(%| -.measured)  [%| p.measured]
  ?.  ?&  (observations-valid epoch.binding dimensions live)
          (observations-valid epoch.binding dimensions reference)
      ==
    [%| %observation-discontinuity]
  ::  Reference overlap is checked by work identity as well as report identity.
  ?:  (lien live |=(r=observation (lien reference |=(s=observation ?|(=(id.r id.s) =(work.r work.s) =(step.r step.s))))))
    [%| %reference-overlap]
  =/  first=observation  (snag 0 live)
  =/  prior=observation  (snag width reference)
  ?.  (lth step.prior step.first)  [%| %reference-not-prior]
  =/  latest=observation  (snag width live)
  ?.  =(source.binding source.latest)  [%| %latest-source-mismatch]
  =/  mixed=?
    (lien live |=(r=observation !=(law.binding law.r)))
  =/  id=@ux
    (shax (jam [%qpc-decision-v1 binding dimensions width gain live reference p.measured]))
  [%& [%qpc-decision-v1 id binding dimensions width gain live reference p.measured mixed ~ ~ %proposing ~]]
++  offer
  |=  [held=state value=proposal source=@ux epoch=@ux]
  ^-  (each state @tas)
  ?.  =(%proposing phase.held)  [%| %pool-frozen]
  ?.  &(=(source source.binding.held) =(epoch epoch.binding.held))
    [%| %decision-stale]
  ?:  (gte (lent proposals.held) 4)  [%| %pool-full]
  ?.  ?&  (identifier id.value)  (identifier evidence.value)
          (gth (met 3 effect.value) 0)  (lte (met 3 effect.value) 1.048.576)
          (valid-ratio:select energy.value)
      ==
    [%| %proposal-invalid]
  ?:  (lien proposals.held |=(p=proposal =(id.value id.p)))
    [%| %proposal-id-reused]
  [%& held(proposals (weld proposals.held ~[value]))]
++  select-once
  |=  [held=state draw=@ud source=@ux epoch=@ux]
  ^-  (each state @tas)
  ?.  =(%proposing phase.held)  [%| %selection-already-closed]
  ?.  &(=(source source.binding.held) =(epoch epoch.binding.held))
    [%| %decision-stale]
  =/  candidates=(list candidate:select)
    %+  turn  proposals.held
    |=  p=proposal
    [`@ud`id.p `@ux`(shax effect.p) eligible.p energy.p]
  =/  chosen=(each receipt:select @tas)
    (choose:select attention.reading.held gain.held draw candidates)
  ?:  ?=(%| -.chosen)  [%| p.chosen]
  [%& held(selection `p.chosen, phase %selected)]
++  release
  ::  Consume before issuing a review card. This is not Cantrip admission.
  |=  [held=state candidate=@ux source=@ux epoch=@ux]
  ^-  (each state @tas)
  ?.  =(%selected phase.held)  [%| %selection-not-releasable]
  ?.  &(=(source source.binding.held) =(epoch epoch.binding.held))
    [%| %decision-stale]
  =/  chosen  selection.held
  ?~  chosen  [%| %selection-missing]
  ?.  =(candidate selected.u.chosen)  [%| %unselected-candidate]
  [%& held(phase %released)]
++  close
  ::  Unknown is retained as unknown; only observation may resolve it later.
  |=  [held=state kind=?(%applied %failed %refused %cancelled %unknown) evidence=@ux]
  ^-  (each state @tas)
  ?:  =(%closed phase.held)  [%| %decision-closed]
  ?.  (identifier evidence)  [%| %result-evidence-missing]
  ?.  ?|(=(%released phase.held) ?=(?(%cancelled %refused) kind))
    [%| %action-not-released]
  [%& held(phase %closed, result `[kind evidence])]
--
