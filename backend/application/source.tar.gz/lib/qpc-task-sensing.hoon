::  Task-relative substitution contract; pure validation, never authority.
::  V3 wire and historical manifests are unchanged. The future native owner
::  must authenticate these inputs and freeze them before the request.
/-  nc=native-coding
/+  obs=qpc-observation, q=qpc-native-outcome,
    project=native-coding-project, sessions=native-coding-session,
    successor=qpc-successor-policy
|%
+$  policy  ?(%first-17-reference-next-disjoint-17-live policy:successor)
+$  contract
  $:  %qpc-task-sensing-v1  instrument=@ux  law=@ux  manifest=@ux
      width=@ud  policy=policy
  ==
+$  task
  $:  %qpc-task-binding-v1  task=@t  objective=@ux  artifact=path
      source=revision:nc  configuration=@ux  cases=cases:q
      evidence=@t  horizon=@t
  ==
++  digest
  |=  value=*
  ^-  @ux
  (shax (jam [%qpc-task-sensing-commitment-v1 value]))
++  identifier
  |=  value=@ux
  &(!=(0 value) (lte (met 0 value) 256))
++  baseline-policy
  ^-  @t
  'W16: first eligible uninterrupted 17-report reference block, then first disjoint later eligible uninterrupted 17-report live block. Choose by chronology before inspecting outcomes. No gaps, pauses, alternatives or historical relabelling. This declaration admits no window.'
++  policy-of
  ::  The exact future manifest chooses its policy before inference. Existing
  ::  manifests keep the original text and never acquire successor semantics.
  |=  m=manifest:obs
  ^-  (unit policy)
  ?:  =(baseline-policy baseline-policy.m)
    `%first-17-reference-next-disjoint-17-live
  ?.  &(=(%qpc-observation-manifest-v4 version.m) =(text:successor baseline-policy.m))  ~
  `%first-17-reference-successive-disjoint-17-live
++  propositions
  |=  horizon=@t
  ^-  (list proposition:obs)
  :~  [%compatibility 'This proposed patch will satisfy the frozen compatibility checks named in this work commitment.' 'Exact registered compatibility target and named check, fixed before inference.' 'The independently returned named Hoon check is true; errors or unavailable results are unknown.' horizon]
      [%intended-behavior 'This proposed patch will satisfy the frozen intended-behavior checks named in this work commitment.' 'Exact registered intended-behavior target and named check, fixed before inference.' 'The independently returned named Hoon check is true; errors or unavailable results are unknown.' horizon]
  ==
++  substitutions
  ::  Show task/check identities, while hashes commit their complete nouns.
  ::  Full target expressions and dependencies must remain in the frozen
  ::  readable project context. This compact text alone is not disclosure
  ::  of those bytes, and this pure library cannot attest context/timing.
  |=  [c=contract t=task]
  ^-  @t
  =/  checks=(list json)
    %+  turn  rows.cases.t
    |=  row=case:q
    [%a ~[[%s `@t`proposition.row] [%s `@t`name.target.row] [%s `@t`check.row]]]
  %-  en:json:html
  [%a ~[[%s 'qpc-task-binding-v1'] [%s task.t] [%s (scot %ux objective.t)] [%s (spat artifact.t)] [%s (scot %ux configuration.t)] [%s (scot %ux (digest:q cases.t))] [%s (scot %ux (digest t))] [%s (scot %ux (digest c))] [%a checks]]]
++  checks-protected
  ::  Check code and declared helpers cannot be edited by the candidate.
  ::  The exact work artifact is the sole writable dependency exception.
  ::  These are registered declarations, not an import-closure inspection.
  |=  [p=project:nc artifact=path cs=cases:q]
  ^-  ?
  %+  levy  rows.cs
  |=  row=case:q
  ?&  (readable:project p entry.target.row)
      !(writable:project p entry.target.row)
      %+  levy  dependencies.target.row
      |=  dependency=path
      &((readable:project p dependency) |(=(artifact dependency) !(writable:project p dependency)))
  ==
++  validate
  ::  Instrument/law are per-enrollment commitments, not permission. A law
  ::  change can retain the sensing manifest; a future owner marks mixed law.
  ::  This proves no registration time, canonical provenance or continuity.
  |=  $:  c=contract  t=task  m=manifest:obs  w=work:obs
          p=project:nc  cs=cases:q  e=entry:sessions
      ==
  ^-  ?
  ?&  (levy `(list @ux)`~[instrument.c law.c manifest.c objective.t configuration.t] identifier)
      =(16 width.c)  =(16 width.m)
      ?:  =(%qpc-observation-manifest-v4 version.m)  =(%tool-bound-v4 prompt.m)
      &(=(%qpc-observation-manifest-v3 version.m) =(%tool-bound-v3 prompt.m))
      =(manifest.c (digest:obs m))  =(manifest.c manifest.w)
      =((policy-of m) `policy.c)
      (text-valid:obs task.t)  (lte (met 3 task.t) 128)
      (evidence-valid:obs evidence.t)  (text-valid:obs horizon.t)
      =((propositions horizon.t) propositions.m)
      (valid:project p)  (revision-valid:project source.t)
      (writable:project p artifact.t)
      =(working.p desk.source.t)
      =(objective.t (digest:obs objective.session.e))
      =(artifact.t artifact.w)  =(source.t source.w)
      =(configuration.t configuration.w)
      =(evidence.t available-evidence.w)
      =(cases.t cs)  =((digest:q cs) case-set.w)
      =((substitutions c t) substitutions.w)
      (matches:obs m w e)  (cases-valid:q m w p cs)
      (checks-protected p artifact.t cs)
      =(request.w (request-id:sessions session.w turn.e))
      ?=(~ pending.e)  ?=(~ calls.e)
      ?|(=(%ready phase.e) &(=(%paused phase.e) =(%ready resume.e)))
  ==
--
