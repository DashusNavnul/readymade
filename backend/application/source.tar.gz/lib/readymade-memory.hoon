::  Metadata only. Graf pages retain immutable fact identity, never bodies.
/+  h=readymade-history, gew=graf-evidence-window, mt=memory-tier
|%
+$  mode  ?(%catalog %facts)
+$  kind  ?(%operator-memory %operator-memory-ruling %operator-memory-retired)
+$  request  [view=mode family=kind offset=@ud query=@t]
+$  catalog-row  [name=@t type=@t description=@t hash=@t tier=tier:mt source=@t at=@da]
+$  row
  [id=@ux at=@da family=kind name=text:h type=text:h description=text:h hash=text:h tier=(unit tier:mt) source=text:h by=(unit @p)]
+$  snapshot
  $:  %readymade-memory-v1  request=request  source=@ux  rows=(list row)
      examined=@ud  matched=@ud  more=?  next=(unit @ud)  limited=?
  ==
+$  unavailable  [%readymade-memory-unavailable-v1 reason=?(%native-unavailable %incoherent)]
+$  observation  $%(snapshot unavailable)
++  valid-request
  |=  r=request
  &((lte offset.r 4.096) (lte (met 3 query.r) 128) |(=(%facts view.r) =(%operator-memory family.r)))
++  route
  |=  pax=path
  ^-  (unit request)
  ?.  ?=([%readymade %memory @ @ @ @ ~] pax)  ~
  ?.  &((lte (met 3 i.t.t.t.t.pax) 8) (lte (met 3 i.t.t.t.t.t.pax) 324))  ~
  =/  v=(unit mode)  ((soft mode) i.t.t.pax)
  ?~  v  ~
  =/  k=(unit kind)  ((soft kind) i.t.t.t.pax)
  ?~  k  ~
  =/  off=(unit @ud)  (slaw %ud i.t.t.t.t.pax)
  ?~  off  ~
  =/  q=(unit @ux)  (slaw %ux i.t.t.t.t.t.pax)
  ?~  q  ~
  =/  r=request  [u.v u.k u.off `@t`u.q]
  ?.  ?&  (valid-request r)
          =(i.t.t.t.t.pax (scot %ud u.off))
          =(i.t.t.t.t.t.pax (scot %ux u.q))
          |(=(%facts u.v) =(%operator-memory u.k))
      ==  ~
  `r
++  watch-path
  |=  r=request
  ^-  path
  /readymade/memory/[(scot %tas view.r)]/[(scot %tas family.r)]/[(scot %ud offset.r)]/[(scot %ux `@ux`query.r)]
++  memory-path
  |=  pax=path
  ?=([%readymade %memory *] pax)
++  matches
  |=  [r=request x=row]
  ^-  ?
  ?:  =('' query.r)  %.y
  =/  hay=@t  (crip "{(trip body.name.x)} {(trip body.type.x)} {(trip body.description.x)} {(trip body.source.x)}")
  !=(~ (find (trip query.r) (trip hay)))
++  order
  |=  [a=row b=row]
  ?:  =(at.a at.b)  (lth id.a id.b)
  (gth at.a at.b)
++  catalog-item
  |=  x=catalog-row
  ^-  row
  [(shax (jam x)) at.x %operator-memory (bounded:h name.x 256) (bounded:h type.x 128) (bounded:h description.x 200) (bounded:h hash.x 128) `tier.x (bounded:h source.x 256) ~]
++  fact-item
  |=  fact=*
  ^-  (unit row)
  =/  id=@ux  (shax (jam fact))
  =/  m=(unit [%operator-memory %1 value=mem:mt])
    ((soft ,[%operator-memory %1 value=mem:mt]) fact)
  ?^  m
    =/  x=mem:mt  value.u.m
    `[id at.x %operator-memory (bounded:h name.x 256) (bounded:h type.x 128) (bounded:h description.x 200) (bounded:h (hash-of:mt body.x) 128) ~ (bounded:h source.x 256) ~]
  =/  ruling=(unit [%operator-memory-ruling %1 value=ruling:mt])
    ((soft ,[%operator-memory-ruling %1 value=ruling:mt]) fact)
  ?^  ruling
    =/  x=ruling:mt  value.u.ruling
    `[id at.x %operator-memory-ruling (bounded:h name.x 256) (bounded:h 'ruling' 128) (bounded:h `@t`regime.x 200) (bounded:h hash.x 128) `verdict.x (bounded:h '' 256) `by.x]
  =/  retired=(unit [%operator-memory-retired %1 name=@t source=@t at=@da])
    ((soft ,[%operator-memory-retired %1 name=@t source=@t at=@da]) fact)
  ?~  retired  ~
  =/  x  u.retired
  `[id at.x %operator-memory-retired (bounded:h name.x 256) (bounded:h 'retired' 128) (bounded:h '' 200) (bounded:h '' 128) ~ (bounded:h source.x 256) ~]
++  catalog
  |=  [r=request values=(list catalog-row)]
  ^-  snapshot
  ?>  &((valid-request r) =(%catalog view.r))
  ::  Search is over the bounded native metadata catalog, never model context.
  =/  examined=(list catalog-row)  (scag 4.096 values)
  =/  rows=(list row)
    (sort (skim (turn examined catalog-item) |=(x=row (matches r x))) order)
  =/  selected=(list row)  (scag 64 (slag offset.r rows))
  =/  more=?  (gth (lent rows) (add offset.r 64))
  [%readymade-memory-v1 r (shax (jam examined)) selected (lent examined) (lent rows) more ?.(more ~ `(add offset.r 64)) (gth (lent values) 4.096)]
++  facts
  |=  [r=request page=kind-page:gew]
  ^-  snapshot
  ?>  &((valid-request r) =(%facts view.r))
  ?>  ?&  =(family.r kind.page)  =(offset.r offset.page)  =(64 limit.page)
          =(returned.page (lent items.page))  (lte returned.page 64)
          =(next-offset.page (add offset.r returned.page))
          |(!more.page =(64 returned.page))
      ==
  =/  projected=(list row)  (murn items.page fact-item)
  ?>  (levy projected |=(x=row =(family.r family.x)))
  =/  rows=(list row)  (sort (skim projected |=(x=row (matches r x))) order)
  =/  end=?  &(more.page (gth next-offset.page 4.096))
  [%readymade-memory-v1 r (shax (jam page)) rows returned.page (lent rows) more.page ?:(&(!end more.page) `next-offset.page ~) end]
--
