::  Mechanical acceleration of the exact retained GLS editor executable.
::  Identity is shax(jam(full tagged value)), including embedded globals.
::  Names only filter helpers. Unknown entries are refused; unknown helper
::  laws are interpreted. Source, state, bounds and decisions remain those of
::  the admitted NativeCodingTerminal.gls program.
/+  base=terminal-plan
|%
++  entries
  ^-  (map @ux @ud)
  %-  malt
  ^-  (list [@ux @ud])
  :~  [0xe4fd.faa3.34ca.6719.08fc.d537.c3cf.edb4.7f4d.ebc9.4677.7472.4478.3b56.b257.414d 0]
      [0x72ce.6bd9.67d9.dbf3.f47d.b43f.5aa6.dc5b.70d8.0856.d255.c4ce.3bee.1058.076e.2587 1]
      [0x2255.6a5a.1026.078a.85a1.1b05.8736.f3a7.6874.dbeb.3f13.c35c.50ea.c518.38c6.3bd0 2]
      [0x3e9e.11bb.25a5.d6a7.c952.d158.8e0a.544d.c022.b436.9fc3.59fb.5a64.f18d.9a47.0dff 1]
  ==
++  laws
  ^-  (map @tas [op=@tas arity=@ud digest=@ux])
  %-  malt
  ^-  (list [@tas [op=@tas arity=@ud digest=@ux]])
  :~  [%rev %rev 2 0xd1aa.af99.5921.dbd7.9c2b.003a.6e67.51fc.4115.48a9.25fd.d2a0.a4d6.996a.3880.abd9]
      [%bounded %bounded 2 0x47e4.bdcd.14f4.b8de.e565.acda.bcc0.8db5.8dab.e4bb.c741.0477.7098.500f.a33e.4538]
      [`@tas`'valid_line' %valid-line 1 0x85e4.782b.b030.40de.cf9c.a6ab.285b.ba1e.4b9e.35ab.da34.315e.1ad2.1e3f.119e.3fc4]
      [%scalar %scalar 1 0x876e.b507.f77a.887e.e41e.7ee0.39a4.79fc.b723.42ac.4b55.9469.b238.973e.3794.216f]
      [%eq %eq 2 0x2ff0.a614.9c96.33f5.2244.6829.ea1d.a0cf.07e5.8f8c.d695.d6bf.a0a8.a02b.e47e.ce91]
  ==
++  identity
  ^-  @ux
  ::  Demand order and per-task charging are part of this version contract.
  (shax (jam [%native-coding-editor-profile-v1 entries laws 2.000.000 1.048.576 %lazy-spine %original-fallback]))
++  admits
  |=  [entry=plan:base args=@ud]
  ^-  ?
  =/  found  (~(get by entries) (shax (jam entry)))
  ?&  ?=(^ found)
      =(args u.found)
      =([~ args] (arity:base entry))
  ==
++  lookup
  |=  value=plan:base
  ^-  [cost=@ud found=(unit @tas)]
  ?.  ?=(%law -.value)  [1 ~]
  ?.  ?=(%nat -.name.value)  [1 ~]
  =/  found  (~(get by laws) `@tas`value.name.value)
  ?~  found  [1 ~]
  =/  packed=@  (jam value)
  =/  cost=@ud  +((met 6 packed))
  ?.  &(=(arity.value arity.u.found) =(digest.u.found (shax packed)))  [cost ~]
  [cost `op.u.found]
++  scalar
  ::  Exact scalar law above: TAB/LF or printable Unicode outside C1 and
  ::  surrogate ranges. This arm is unreachable for a changed helper law.
  |=  c=@ud
  ^-  ?
  ?|  =(c 9)  =(c 10)
      ?&  (gte c 32)  (lte c 1.114.111)
          !&((gte c 127) (lte c 159))
          !&((gte c 55.296) (lte c 57.343))
      ==
  ==
--
