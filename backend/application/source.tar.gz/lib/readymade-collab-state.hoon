::  Pure parser for the guaranteed /x/state route. No scries or permissions.
::  A recognized refusal is data; callers never probe an unknown route.
/-  c=readymade-collab, a=readymade-artifact-collab
/+  kit=readymade-collab-saved, artifact=readymade-artifact-collab,
    execution=readymade-artifact-executor-types
|%
+$  view  [state=state:c artifacts=(unit state:a)]
+$  packet  [%readymade-collab-state-v4 state=state:c artifacts=state:a]
+$  executor-packet
  $:  %readymade-collab-state-v5
      previous=packet  capability=%native-artifact-executor-v1
      executions=journal:execution
  ==
+$  unavailable  [%readymade-collab-state-unavailable-v1 reason=@tas]
++  checked
  ::  Synthetic empty operational indexes validate only snapshot metadata.
  ::  The returned artifact index is observation, never execution admission.
  |=  [our=@p value=view]
  ^-  (each view @tas)
  =/  index=state:a  ?~(artifacts.value empty:artifact u.artifacts.value)
  =/  saved=saved:kit  [%readymade-collab-app-v4 state.value ~ ~ ~ index]
  ?.  (valid:kit our saved)  [%| %invalid-state-index]
  [%& value]
++  read-executor
  ::  This exact capability gates future executor access. It conveys metadata,
  ::  never a project/session/grant, approval, or permission to execute.
  |=  [our=@p raw=*]
  ^-  (each executor-packet @tas)
  =/  parsed=(unit executor-packet)  ((soft executor-packet) raw)
  ?~  parsed  [%| %executor-capability-unavailable]
  =/  value=executor-packet  u.parsed
  =/  previous  (checked our [state.previous.value `artifacts.previous.value])
  ?:  ?=(%| -.previous)  [%| p.previous]
  ?.  (valid:execution our executions.value)  [%| %invalid-executor-journal]
  [%& value]
++  read
  |=  [our=@p raw=*]
  ^-  (each view @tas)
  =/  refused=(unit unavailable)  ((soft unavailable) raw)
  ?^  refused
    ?:  &((gth (met 3 reason.u.refused) 0) (lte (met 3 reason.u.refused) 128))
      [%| reason.u.refused]
    [%| %invalid-refusal]
  ?:  ?=([%readymade-collab-state-v5 *] raw)
    =/  five  (read-executor our raw)
    ?:  ?=(%| -.five)  [%| p.five]
    (checked our [state.previous.p.five `artifacts.previous.p.five])
  =/  four=(unit packet)  ((soft packet) raw)
  ?^  four  (checked our [state.u.four `artifacts.u.four])
  =/  legacy=(unit state:c)  ((soft state:c) raw)
  ?~  legacy  [%| %invalid-state-packet]
  (checked our [u.legacy ~])
--
