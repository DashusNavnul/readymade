::  Finished receipts that leave the hot state together with their session.
::  Completion and reviewed-completion receipts are checked against their hot
::  session whenever Viki loads, so they cannot outlive it; a finished
::  completion review campaign would otherwise hold its lifetime 32 forever.
::  The archive record keeps every carried row whole. Pure; no IO, no cards.
/+  completion=native-coding-completion-runtime,
    campaigns=native-coding-completion-review-orchestration,
    reviewed=native-coding-reviewed-completion
|%
::  Same shape as issue:native-coding-session-archive; kept local so Viki's
::  app does not import the whole eligibility law.
+$  issue  [reason=@tas reference=@ux]
+$  carried
  $:  completions=state:completion
      campaigns=(map @ux campaign:campaigns)
      reviewed=state:reviewed
  ==
+$  organs
  [completions=state:completion campaigns=state:campaigns reviewed=state:reviewed]
++  select
  ::  Every row naming the session, whatever its state; settlement is judged
  ::  separately so nothing unfinished is silently left behind or carried.
  |=  [id=@ux o=organs]
  ^-  carried
  :+  %-  malt
      (skim ~(tap by completions.o) |=([k=@ux r=receipt:completion] =(id session.proposal.decision.r)))
    %-  malt
    (skim ~(tap by campaigns.campaigns.o) |=([k=@ux c=campaign:campaigns] =(id session.proposal.packet.c)))
  %-  malt
  (skim ~(tap by reviewed.o) |=([k=@ux r=receipt:reviewed] =(id session.proposal.packet.r)))
++  settled
  ::  A campaign may leave only once finished with every job observed.
  |=  c=campaign:campaigns
  ^-  ?
  &(done.c (levy ~(val by jobs.c) |=(j=job:campaigns ?=(^ event.j))))
++  issues
  ::  Completion and reviewed receipts are final decisions; only an
  ::  unfinished campaign blocks. Each blocker names its own row.
  |=  c=carried
  ^-  (list issue)
  %+  murn  ~(tap by campaigns.c)
  |=  [k=@ux e=campaign:campaigns]
  ^-  (unit issue)
  ?:((settled e) ~ `[%archive-completion-campaign-unsettled k])
++  valid
  ::  A stored record must name only its own session and finished campaigns.
  |=  [id=@ux c=carried]
  ^-  ?
  ?&  (lte ~(wyt by completions.c) 128)  (lte ~(wyt by campaigns.c) 32)
      (lte ~(wyt by reviewed.c) 128)
      =(c (select id [completions.c [%native-coding-completion-review-campaigns-v1 campaigns.c] reviewed.c]))
      =(~ (issues c))
  ==
++  strip
  ::  Remove exactly the carried rows; every other session's rows are kept.
  |=  [o=organs c=carried]
  ^-  organs
  :+  %-  malt
      (skip ~(tap by completions.o) |=([k=@ux *] (~(has by completions.c) k)))
    %=  campaigns.o
      campaigns
        %-  malt
        (skip ~(tap by campaigns.campaigns.o) |=([k=@ux *] (~(has by campaigns.c) k)))
    ==
  %-  malt
  (skip ~(tap by reviewed.o) |=([k=@ux *] (~(has by reviewed.c) k)))
--
