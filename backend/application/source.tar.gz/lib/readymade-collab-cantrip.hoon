::  Optional native watch observations only. Nothing here grants authority.
/-  c=readymade-collab, cp=cantrip-readymade-pact
/+  core=cantrip-readymade-pact
|%
+$  entry
  $:  basis=@ux
      status=?(%pending %observed %unavailable)
      at=@da
      observation=(unit observation:cp)
      reason=@tas
  ==
+$  model
  $:  peer=(unit @p)
      epoch=@ux
      phase=?(%idle %capability %observing %unavailable)
      records=(map @ux entry)
  ==
+$  transition  [model=model cards=(list card:agent:gall)]
++  initial  ^-(model [~ 0x0 %idle ~])
++  capability-wire
  |=  epoch=@ux
  ^-  wire
  /collab/law/(scot %ux epoch)/capability
++  pact-wire
  |=  [epoch=@ux id=@ux]
  ^-  wire
  /collab/law/(scot %ux epoch)/pact/(scot %ux id)
++  leave
  |=  [our=@p wire=wire]
  ^-  card:agent:gall
  [%pass wire %agent [our %cantrip] %leave ~]
++  cancel
  |=  [our=@p held=model]
  ^-  (list card:agent:gall)
  =/  cards=(list card:agent:gall)
    ?:(=(%capability phase.held) ~[(leave our (capability-wire epoch.held))] ~)
  ?.  =(%observing phase.held)  cards
  %+  weld  cards
  %+  murn  ~(tap by records.held)
  |=  row=[id=@ux entry=entry]
  ?.  =(%pending status.entry.row)  ~
  `(leave our (pact-wire epoch.held id.row))
++  begin
  |=  [our=@p peer=@p epoch=@ux at=@da state=state:c held=model]
  ^-  transition
  =/  rows=(list [@ux agreement:c])  ~(tap by pacts.state)
  =/  selected=(list [@ux agreement:c])
    %+  skim  rows
    |=  row=[id=@ux item=agreement:c]
    =/  checked  (binding:core our our id.row state)
    ?:(?=(%| -.checked) %.n =(peer peer.p.checked))
  =/  records=(map @ux entry)  ~
  =/  selected  (scag 32 selected)
  =.  records
    %+  roll  selected
    |=  [row=[id=@ux item=agreement:c] records=(map @ux entry)]
    (~(put by records) id.row [(shax (jam (need (~(get by pacts.state) id.row)))) %pending at ~ %awaiting-cantrip])
  =/  next=model  [`peer epoch %capability records]
  =/  cards=(list card:agent:gall)  (cancel our held)
  ?~  selected  [next(phase %idle) cards]
  [next [[%pass (capability-wire epoch) %agent [our %cantrip] %watch /law/readymade/capabilities] cards]]
++  unavailable
  |=  [at=@da held=model reason=@tas]
  ^-  model
  =/  rows=(list [@ux entry])  ~(tap by records.held)
  =/  records=(map @ux entry)  ~
  =.  records
    %+  roll  rows
    |=  [row=[id=@ux entry=entry] records=(map @ux entry)]
    (~(put by records) id.row entry.row(status %unavailable, at at, observation ~, reason reason))
  held(phase %unavailable, records records)
++  receive
  ::  Caller verifies Gall source; epoch/wire binds the exact local watch.
  |=  [our=@p at=@da state=state:c held=model wire=wire sign=sign:agent:gall]
  ^-  transition
  ?~  peer.held  [held ~]
  ?:  =(wire (capability-wire epoch.held))
    ?.  =(%capability phase.held)  [held ~]
    ?:  |(?=([%watch-ack ^] sign) ?=([%kick *] sign))
      [(unavailable at held %cantrip-watch-unavailable) ~[(leave our wire)]]
    ?.  ?=(%fact -.sign)  [held ~]
    =/  parsed
      ?.  =(%noun p.cage.sign)  ~
      ((soft ,[%cantrip-readymade-pact-capabilities-v1 owner=@p api=%readymade-pact-law-v1]) q.q.cage.sign)
    ?~  parsed
      [(unavailable at held %cantrip-capability-invalid) ~[(leave our wire)]]
    ?.  =(our owner.u.parsed)
      [(unavailable at held %cantrip-capability-invalid) ~[(leave our wire)]]
    =/  cards=(list card:agent:gall)
      %+  turn  ~(tap by records.held)
      |=  row=[id=@ux entry=entry]
      [%pass (pact-wire epoch.held id.row) %agent [our %cantrip] %watch /law/readymade/pact/(scot %ux id.row)]
    [held(phase %observing) [(leave our wire) cards]]
  ?.  ?=([%collab %law @ %pact @ ~] wire)  [held ~]
  =/  id=(unit @ux)  (slaw %ux i.t.t.t.t.wire)
  ?~  id  [held ~]
  ?.  =(wire (pact-wire epoch.held u.id))  [held ~]
  =/  old=(unit entry)  (~(get by records.held) u.id)
  ?~  old  [held ~]
  ?.  =(%pending status.u.old)  [held ~]
  ?:  |(?=([%watch-ack ^] sign) ?=([%kick *] sign))
    =/  next=entry  u.old(status %unavailable, at at, observation ~, reason %cantrip-watch-unavailable)
    [held(records (~(put by records.held) u.id next)) ~[(leave our wire)]]
  ?.  ?=(%fact -.sign)  [held ~]
  =/  parsed
    ?.  =(%noun p.cage.sign)  ~
    ((soft ,(each observation:cp @tas)) q.q.cage.sign)
  =/  checked  (binding:core our our u.id state)
  =/  observed=(unit observation:cp)
    ?~  parsed  ~
    ?.  ?=(%& -.u.parsed)  ~
    `p.u.parsed
  =/  accepted=?
    ?~  observed  %.n
    ?.  ?=(%& -.checked)  %.n
    ?&  =(binding.u.observed p.checked)
        =(peer.p.checked u.peer.held)
        !shared-execution.u.observed
        =(%coordinated-artifact-round-required reason.u.observed)
        !=(0 current-law.u.observed)
        (lte (met 0 current-law.u.observed) 256)
        =(basis.u.old (shax (jam (~(got by pacts.state) u.id))))
    ==
  =/  next=entry
    ?.  accepted  u.old(status %unavailable, at at, observation ~, reason %cantrip-observation-invalid)
    u.old(status %observed, at at, observation observed, reason %coordinated-artifact-round-required)
  [held(records (~(put by records.held) u.id next)) ~[(leave our wire)]]
++  json-view
  |=  [our=@p peer=@p id=@ux state=state:c held=model]
  ^-  json
  =/  missing=json
    (pairs:enjs:format ~[['status' s+'unavailable'] ['reason' s+'No canonical Cantrip receipt observed.'] ['sharedExecution' b+%.n]])
  ?.  =(peer.held `peer)  missing
  =/  found=(unit entry)  (~(get by records.held) id)
  ?~  found  missing
  =/  row=entry  u.found
  =/  checked  (binding:core our our id state)
  =/  same=?
    ?~  observation.row  %.n
    ?.  ?=(%& -.checked)  %.n
    =(binding.u.observation.row p.checked)
  =/  status=@t
    ?:  =(%observed status.row)  ?:(same 'observed' 'historical')
    (scot %tas status.row)
  =/  value=json
    %-  pairs:enjs:format
    :~  ['status' s+status]
        ['reason' s+(scot %tas reason.row)]
        ['observedAt' (numb:enjs:format ?:((lth at.row ~1970.1.1) 0 (div (sub at.row ~1970.1.1) ~s1)))]
        ['sharedExecution' b+%.n]
    ==
  ?~  observation.row  value
  =/  observed=observation:cp  u.observation.row
  ?>  ?=(%o -.value)
  =/  fields=(map @t json)  p.value
  =.  fields  (~(put by fields) 'owner' [%s (scot %p owner.binding.observed)])
  =.  fields  (~(put by fields) 'peer' [%s (scot %p peer.binding.observed)])
  =.  fields  (~(put by fields) 'pact' [%s (scot %ux id.binding.observed)])
  =.  fields  (~(put by fields) 'generation' [%s (scot %ud generation.binding.observed)])
  =.  fields  (~(put by fields) 'currentLaw' [%s (scot %ux current-law.observed)])
  =.  fields  (~(put by fields) 'consentActive' [%b active.binding.observed])
  [%o fields]
++  project
  |=  [our=@p peer=@p state=state:c held=model snapshot=json]
  ^-  json
  ?>  ?=(%o -.snapshot)
  =/  shown=json  (need (~(get by p.snapshot) 'pacts'))
  ?>  ?=(%a -.shown)
  =/  records=(list json)
    %+  turn  p.shown
    |=  row=json
    ?>  ?=(%o -.row)
    =/  raw=json  (need (~(get by p.row) 'id'))
    ?>  ?=(%s -.raw)
    =/  id=@ux  (need (slaw %ux p.raw))
    [%o (~(put by p.row) 'cantrip' (json-view our peer id state held))]
  [%o (~(put by p.snapshot) 'pacts' [%a records])]
--
