::  One frozen model response supplies inert alternatives. No review, judgment,
::  sampling or landing occurs here. Ordinary session records remain canonical.
/-  nc=native-coding, np=native-coding-provider
/+  sessions=native-coding-session, codec=native-coding-tool-codec
|%
++  tools
  ^-  (list tool:np)
  (skim tools:codec |=(t=tool:np =('patch' name.t)))
++  instructions
  ^-  @t
  'QPC proposal collection: return two to four alternative patch calls in one response. Each is an independent alternative against the same exact source, never a sequence of edits. Use only supplied native blob digests and exact old line bytes. No alternative will execute before selection and Cantrip admission. If evidence is insufficient, explain that instead of inventing a patch.'
++  sealed
  |=  e=entry:sessions
  ^-  ?
  %+  lien  records.e
  |=  r=record:sessions
  ?.(?=(%status -.body.r) %.n ?=(?(%qpc-pool-collected %qpc-pool-refused) reason.body.r))
++  patches
  |=  [e=entry:sessions r=reply:np]
  ^-  ?
  ?.  &(?=(%tools stop.r) (gte (lent calls.r) 2) (lte (lent calls.r) 4))  %.n
  =/  ctx=context:nc
    [project.session.e configuration.e id.session.e id.r owner.session.e working.session.e]
  %+  levy  calls.r
  |=  c=call:np
  =/  decoded  (decode:codec ctx working.session.e c)
  ?.(?=(%& -.decoded) %.n ?=(%patch -.arguments.p.decoded))
++  model
  |=  [at=@da e=entry:sessions r=reply:np]
  ^-  (each transition:sessions @tas)
  ?:  (sealed e)  [%| %qpc-pool-sealed]
  ::  Validate the complete reply and retain it with dispatch suppressed. An
  ::  invalid later call must not allow even the first patch to be materialized.
  =/  checked  (model:sessions at e(phase %paused) r)
  ?:  ?=(%| -.checked)  checked
  =/  next=transition:sessions  p.checked
  ?.  (patches e r)
    =/  stopped
      (append:sessions entry.next(calls ~, phase %paused, resume %paused) at [%status %paused %qpc-pool-refused])
    ?:  ?=(%| -.stopped)  stopped
    [%& p.stopped(effects (weld effects.next effects.p.stopped))]
  ?>  ?=(^ calls.r)
  =/  paused=?  =(%paused phase.e)
  =.  next  next(entry entry.next(phase ?:(paused %paused %tools), resume %tools))
  ?:  paused  [%& next]
  [%& next(effects (weld effects.next `(list effect:sessions)`~[[%tool id.session.e id.r i.calls.r]]))]
++  result
  |=  [at=@da e=entry:sessions r=tool-result:nc text=@t]
  ^-  (each transition:sessions @tas)
  =/  checked  (result:sessions at e r text)
  ?:  ?=(%| -.checked)  checked
  =/  next=transition:sessions  p.checked
  ?:  ?=(%unknown -.output.r)
    [%& ?:(=(%paused phase.e) next(entry entry.next(phase %paused)) next)]
  ?^  calls.entry.next  [%& next]
  ::  Even refused patches finish collection. Eligibility is established later
  ::  from canonical results, never inferred from the words "pool collected".
  =/  stopped
    (append:sessions entry.next(phase %paused, resume %paused) at [%status %paused %qpc-pool-collected])
  ?:  ?=(%| -.stopped)  stopped
  [%& p.stopped(effects (weld effects.next effects.p.stopped))]
--
