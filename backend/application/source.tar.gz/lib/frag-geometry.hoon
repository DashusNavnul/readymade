::  /lib/frag-geometry
::
::  Complete algebraic codec for all 46,440 SmolLM2 fine components.  It maps
::  every component to exact logical tensor rectangles without expanding any
::  component into scalar nouns and without reading the %weights desk.
::
/-  f=frag, g=frag-geometry
|%
++  layer-stride       1.548
++  fine-count         46.440
++  attention-heads   270
++  kv-groups         90
++  mlp-neurons       46.080
++  region-count       185.940
++  owned-region-count  138.960
++  shared-region-count  46.980
++  owned-value-count  106.168.320
++  embedding-count    28.311.552
++  layer-weight-count  3.540.096
++  final-norm-start    134.514.432
++  logical-weight-count  134.515.008
++  expected-revision
  '12fd25f77366fa6b3b4b768ec3050bf629380bac'
++  expected-arithmetic  %smollm2-fp32-canon-v2
++  expected-model-native
  `@uvI`0x518c.f85d.7af4.9821.077c.6aaa.f4d8.b65e.7e48.9001.94ec.e301.ac41.cdad.43ae.1da0
++  expected-model-clay
  `@uvI`0x353.7d70.43da.64ca.7218.629a.acfa.51d3.17c4.852a.151c.ef30.5c68.a6a7.9de5.b961
++  expected-tokenizer-native
  `@uvI`0xfce0.3e7c.465e.6495.50ed.9aa3.3c55.f842.3e93.afa7.a48b.ce2e.5a8f.aeda.890c.c46a
++  expected-atlas-certificate
  `@uvI`0xca8.9d50.caee.a79b.3bcc.2fb9.2ade.8b85.f1cd.5c2d.e56f.f526.3b2c.066a.9857.d722
::
++  component-valid
  |=  component=fine-component:f
  ^-  ?
  ?-  -.component
    %attn-head
      &((lth layer.component 30) (lth head.component 9))
    %kv-group
      &((lth layer.component 30) (lth group.component 3))
    %mlp-neuron
      &((lth layer.component 30) (lth neuron.component 1.536))
  ==
++  ordinal-for
  |=  component=fine-component:f
  ^-  (unit @ud)
  ?.  (component-valid component)  ~
  =/  base=@ud  (mul layer.component layer-stride)
  ?-  -.component
    %attn-head   `(add base head.component)
    %kv-group    `(add base (add 9 group.component))
    %mlp-neuron  `(add base (add 12 neuron.component))
  ==
++  component-for-ordinal
  |=  ordinal=@ud
  ^-  (unit fine-component:f)
  ?.  (lth ordinal fine-count)  ~
  =/  layer=@ud  (div ordinal layer-stride)
  =/  local=@ud  (mod ordinal layer-stride)
  ?:  (lth local 9)
    `[%attn-head layer local]
  ?:  (lth local 12)
    `[%kv-group layer (sub local 9)]
  `[%mlp-neuron layer (sub local 12)]
::
++  tensor-valid
  |=  id=tensor-id:g
  ^-  ?
  ?-  -.id
    %embedding   &
    %projection  (lth layer.id 30)
    %input-norm  (lth layer.id 30)
    %post-norm   (lth layer.id 30)
    %final-norm  &
  ==
++  logical-shape
  |=  id=tensor-id:g
  ^-  (list @ud)
  ?>  (tensor-valid id)
  ?-  -.id
    %embedding   ~[49.152 576]
    %projection
      ?-  kind.id
        %q     ~[576 576]
        %k     ~[192 576]
        %v     ~[192 576]
        %o     ~[576 576]
        %gate  ~[1.536 576]
        %up    ~[1.536 576]
        %down  ~[576 1.536]
      ==
    %input-norm  ~[576]
    %post-norm   ~[576]
    %final-norm  ~[576]
  ==
++  shape-product
  |=  dims=(list @ud)
  ^-  @ud
  =/  total=@ud  1
  |-
  ?~  dims  total
  $(dims t.dims, total (mul total i.dims))
++  projection-offset
  |=  kind=projection:g
  ^-  @ud
  ?-  kind
    %q     576
    %k     332.352
    %v     442.944
    %o     553.536
    %gate  885.888
    %up    1.770.624
    %down  2.655.360
  ==
++  tensor-start
  |=  id=tensor-id:g
  ^-  @ud
  ?>  (tensor-valid id)
  ?-  -.id
    %embedding   0
    %final-norm  final-norm-start
    %input-norm
      (add embedding-count (mul layer.id layer-weight-count))
    %post-norm
      (add embedding-count (add (mul layer.id layer-weight-count) 885.312))
    %projection
      (add embedding-count (add (mul layer.id layer-weight-count) (projection-offset kind.id)))
  ==
::
++  bounds-valid
  |=  [limits=(list @ud) origin=(list @ud) extent=(list @ud)]
  ^-  ?
  ?~  limits  ?&(=(~ origin) =(~ extent))
  ?~  origin  |
  ?~  extent  |
  ?&  (gth i.extent 0)
      (lte (add i.origin i.extent) i.limits)
      $(limits t.limits, origin t.origin, extent t.extent)
  ==
++  region-valid
  |=  region=logical-region:g
  ^-  ?
  ?.  (tensor-valid id.region)  |
  (bounds-valid (logical-shape id.region) origin.region extent.region)
++  regions-valid
  |=  regions=(list logical-region:g)
  ^-  ?
  ?~  regions  &
  &((region-valid i.regions) $(regions t.regions))
++  region-values
  |=  region=logical-region:g
  ^-  @ud
  ?>  (region-valid region)
  (shape-product extent.region)
::
++  regions-for
  |=  component=fine-component:f
  ^-  (list logical-region:g)
  ?>  (component-valid component)
  ?-  -.component
    %attn-head
      =/  offset=@ud  (mul head.component 64)
      =/  kv=@ud  (mul (div head.component 3) 64)
      :~  [%shared-dependency [%input-norm layer.component] ~[0] ~[576]]
          [%owned [%projection layer.component %q] ~[offset 0] ~[64 576]]
          [%shared-dependency [%projection layer.component %k] ~[kv 0] ~[64 576]]
          [%shared-dependency [%projection layer.component %v] ~[kv 0] ~[64 576]]
          [%owned [%projection layer.component %o] ~[0 offset] ~[576 64]]
      ==
    %kv-group
      =/  offset=@ud  (mul group.component 64)
      :~  [%shared-dependency [%input-norm layer.component] ~[0] ~[576]]
          [%owned [%projection layer.component %k] ~[offset 0] ~[64 576]]
          [%owned [%projection layer.component %v] ~[offset 0] ~[64 576]]
      ==
    %mlp-neuron
      :~  [%shared-dependency [%post-norm layer.component] ~[0] ~[576]]
          [%owned [%projection layer.component %gate] ~[neuron.component 0] ~[1 576]]
          [%owned [%projection layer.component %up] ~[neuron.component 0] ~[1 576]]
          [%owned [%projection layer.component %down] ~[0 neuron.component] ~[576 1]]
      ==
  ==
++  owned-values-for
  |=  component=fine-component:f
  ^-  @ud
  =/  regions=(list logical-region:g)  (regions-for component)
  =/  total=@ud  0
  |-
  ?~  regions  total
  =/  addend=@ud
    ?:(=(%owned role.i.regions) (region-values i.regions) 0)
  $(regions t.regions, total (add total addend))
++  scales-for
  |=  component=fine-component:f
  ^-  (list scale-coordinate:g)
  =/  regions=(list logical-region:g)  (regions-for component)
  =/  scales=(list scale-coordinate:g)  ~
  |-
  ?~  regions  (flop scales)
  ?:  ?=(%projection -.id.i.regions)
    $(regions t.regions, scales [[id.i.regions %scale] scales])
  $(regions t.regions)
++  semantics-for
  |=  component=fine-component:f
  ^-  component-semantics:g
  ?>  (component-valid component)
  ?-  -.component
    %attn-head   %structural-output-candidate
    %kv-group    %shared-parameter-owner
    %mlp-neuron  %structural-output-candidate
  ==
++  related-for
  |=  component=fine-component:f
  ^-  (list fine-component:f)
  ?>  (component-valid component)
  ?-  -.component
    %attn-head
      ~[[%kv-group layer.component (div head.component 3)]]
    %kv-group
      =/  first=@ud  (mul group.component 3)
      :~  [%attn-head layer.component first]
          [%attn-head layer.component +(first)]
          [%attn-head layer.component (add first 2)]
      ==
    %mlp-neuron  ~
  ==
::
++  local-index
  |=  [shape=(list @ud) indices=(list @ud)]
  ^-  (unit @ud)
  ?~  shape  ?:(?=(~ indices) `0 ~)
  ?~  indices  ~
  ?.  (lth i.indices i.shape)  ~
  =/  rest  $(shape t.shape, indices t.indices)
  ?~  rest  ~
  `(add (mul i.indices (shape-product t.shape)) u.rest)
++  coordinate-index
  |=  [id=tensor-id:g indices=(list @ud)]
  ^-  (unit @ud)
  ?.  (tensor-valid id)  ~
  =/  local  (local-index (logical-shape id) indices)
  ?~  local  ~
  `(add (tensor-start id) u.local)
++  anchor-index-for
  |=  component=fine-component:f
  ^-  (unit @ud)
  ?.  (component-valid component)  ~
  =/  regions=(list logical-region:g)  (regions-for component)
  |-
  ?~  regions  ~
  ?:  =(%shared-dependency role.i.regions)
    $(regions t.regions)
  (coordinate-index id.i.regions origin.i.regions)
++  structural-axis
  |=  index=@ud
  ^-  @
  ?>  (lth index logical-weight-count)
  (peg 8 (add (bex 28) index))
::
++  component-key-for
  |=  component=fine-component:f
  ^-  (unit component-key:g)
  ?.  (component-valid component)  ~
  =/  ordinal  (ordinal-for component)
  ?~  ordinal  ~
  =/  regions=(list logical-region:g)  (regions-for component)
  ?.  (regions-valid regions)  ~
  =/  anchor  (anchor-index-for component)
  ?~  anchor  ~
  =/  key=component-key:g
    :*  1
        expected-revision
        expected-model-native
        expected-model-clay
        expected-tokenizer-native
        expected-arithmetic
        component
        (semantics-for component)
        u.ordinal
        u.anchor
        (structural-axis u.anchor)
        (owned-values-for component)
        regions
        (scales-for component)
        (related-for component)
    ==
  `key
++  component-digest
  |=  key=component-key:g
  ^-  @uvI
  `@uvI`(shax (jam [%smollm2-fine-component-v1 key]))
++  view-for
  |=  component=fine-component:f
  ^-  (unit component-view:g)
  =/  key  (component-key-for component)
  ?~  key  ~
  `[u.key (component-digest u.key)]
++  view-valid
  |=  view=component-view:g
  ^-  ?
  =/  expected  (view-for component.key.view)
  ?~  expected  |
  =(view u.expected)
::
++  certificate-digest
  |=  key=component-certificate-key:g
  ^-  @uvI
  `@uvI`(shax (jam [%smollm2-fine-component-certificate-v2 key]))
++  certificate-for
  ^-  component-certificate:g
  =/  first=fine-component:f  [%attn-head 0 0]
  =/  last=fine-component:f  [%mlp-neuron 29 1.535]
  =/  first-view=component-view:g  (need (view-for first))
  =/  last-attn=component-view:g  (need (view-for [%attn-head 29 8]))
  =/  first-kv=component-view:g  (need (view-for [%kv-group 0 0]))
  =/  last-kv=component-view:g  (need (view-for [%kv-group 29 2]))
  =/  first-mlp=component-view:g  (need (view-for [%mlp-neuron 0 0]))
  =/  last-view=component-view:g  (need (view-for last))
  =/  chain-input=*
    :*  %smollm2-fine-component-total-codec-v2
        expected-atlas-certificate
        layer-stride
        fine-count
        attention-heads
        kv-groups
        mlp-neurons
        region-count
        owned-region-count
        shared-region-count
        owned-value-count
        digest.first-view
        digest.last-attn
        digest.first-kv
        digest.last-kv
        digest.first-mlp
        digest.last-view
    ==
  =/  chain=@uvI  `@uvI`(shax (jam chain-input))
  =/  key=component-certificate-key:g
    :*  2
        expected-revision
        expected-model-native
        expected-model-clay
        expected-tokenizer-native
        expected-arithmetic
        expected-atlas-certificate
        fine-count
        attention-heads
        kv-groups
        mlp-neurons
        region-count
        owned-region-count
        shared-region-count
        owned-value-count
        first
        last
        anchor-index.key.first-view
        anchor-index.key.last-view
        chain
    ==
  [key (certificate-digest key)]
++  certificate-valid
  |=  certificate=component-certificate:g
  ^-  ?
  =(certificate certificate-for)
++  expected-component-certificate
  ^-  @uvI
  `@uvI`0x8035.52e9.cb17.54a7.db39.3281.9963.5269.6e63.e4eb.4247.50fd.c0ef.c11b.661c.1d72
::
::  ---  layer commitments  ---
::
::  Graf's %machine-topology domain trunk.  +structural-axis is (peg 8 ...),
::  so this is the region every weight axis already lives under; it is one of
::  the domains /lib/graf-axis-law's +structural-region-axis-authorized
::  admits.
++  weight-region-axis  8
::  +layer-relative-axis: the uniform-depth index, before grafting under the
::  trunk.  (add (bex 28) index) is the standard no-prefix-of-another trick;
::  (peg weight-region-axis (layer-relative-axis i)) == (structural-axis i).
++  layer-relative-axis
  |=  index=@ud
  ^-  @ud
  ?>  (lth index logical-weight-count)
  (add (bex 28) index)
::  +layer-digest-for: a layer's commitment to its own components, in ordinal
::  order.  PURE — it reads no evidence and no Clay.  Every component-key is
::  a function of the component plus the pinned revision/arithmetic constants,
::  so the whole 46.440-component map is already determined; a campaign does
::  not discover it, it proves that a substrate independently recomputed it.
::  That is why the attestation belongs on this digest and not on structure.
++  layer-digest-for
  |=  layer=@ud
  ^-  (unit @uvI)
  ?.  (lth layer layer-count:f)  ~
  =/  base=@ud  (mul layer layer-stride)
  =|  acc=(list @uvI)
  =/  local=@ud  layer-stride
  |-  ^-  (unit @uvI)
  ?:  =(0 local)
    =/  d=@uvI  `@uvI`(shax (jam [%smollm2-layer-commitment-v1 layer acc]))
    `d
  =/  idx=@ud  (dec local)
  =/  cmp  (component-for-ordinal (add base idx))
  ?~  cmp  ~
  =/  vew  (view-for u.cmp)
  ?~  vew  ~
  $(local idx, acc [digest.u.vew acc])
::  +layer-commitment-for: the whole row Graf stores for one layer.  The
::  anchor is the layer's FIRST component, so the commitment sits at the
::  lowest weight axis the layer owns.
++  layer-commitment-for
  |=  layer=@ud
  ^-  (unit layer-commitment:g)
  ?.  (lth layer layer-count:f)  ~
  =/  cmp  (component-for-ordinal (mul layer layer-stride))
  ?~  cmp  ~
  =/  anchor  (anchor-index-for u.cmp)
  ?~  anchor  ~
  =/  dig  (layer-digest-for layer)
  ?~  dig  ~
  =/  commitment=layer-commitment:g
    :*  layer
        u.anchor
        weight-region-axis
        (layer-relative-axis u.anchor)
        (structural-axis u.anchor)
        layer-stride
        u.dig
    ==
  `commitment
::  +commitment-valid: recompute and compare.  Idempotency is structural —
::  the same layer always yields the same row, so a replayed commitment is
::  detectable without storing what was already written.
++  commitment-valid
  |=  commitment=layer-commitment:g
  ^-  ?
  =(`commitment (layer-commitment-for layer.commitment))
--
