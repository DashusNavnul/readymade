::  Pure terminal parser. No cards, reads, shell, permission or session state.
::  The caller supplies canonical directory/accepted revision and later binds
::  the returned proposal to owner, session, request and Cantrip admission.
::  NativeCodingTerminal.gls owns editing; its compiled bridge is not installed.
/-  nc=native-coding
/+  editor=pataphor-editor-model
|%
++  request-at
  ::  Viki and the HTTP receipt must identify the same source-pinned request.
  |=  [session=@ux nonce=@ux source=@ux input=@t]
  ^-  @ux
  (shax (jam [%native-coding-terminal-at-v1 session nonce source input]))
+$  action
  $%  [%help ~]  [%request text=@t]  [%tool arguments=tool-args:nc]
      [%interrupt ~]  [%pause ~]  [%reattach session=@ux]
  ==
++  help
  ^-  @t
  '''
  Ordinary text requests work from Viki. Only an explicit submit sends it.
  Tool commands begin with /. No quoting, pipes, expansion or host commands.
  Paths use Clay segments, e.g. /lib/example/hoon; . is the current directory.
  /list [path] [cursor] [limit]
  /read path [start-line] [line-count]
  /search text|filename|path directory cursor limit\0aquery
  /create path mark\0asource
  /replace path before-hash mark\0asource
  /patch path before-hash start remove expected-bytes\0aexpected+replacement
  /patches count\0a(path before-hash start remove expected-bytes replacement-bytes\0aexpected+replacement)...
  /move from to before-hash
  /delete path before-hash
  /diff [path] [cursor] [limit]
  /undo candidate-hash
  /compile target
  /check target
  /eval path fuel\0aexpression
  /inspect app path
  /jobs [cursor] [limit]
  /observe job-hash
  /cancel job-hash
  /interrupt | /pause | /reattach session-hash | /help
  Numbers are decimal; hashes are 0x hex. List/diff pages default to 64 (max 64).
  Read lines start at 1 and default to 200 (max 200; reduce count for long lines).
  Search scans at most 32 files; cursor counts files; query is at most 256 bytes.
  Job pages default to 100 (max 256), subject to the native job adapter.
  Patch start is a 1-based line, remove is a line count; expected includes LF.
  Patch's expected-bytes splits the exact UTF-8 body; neither part is trimmed.
  Patches carries 1-16 byte-framed items as ONE candidate, all on original blobs.
  Create, replace, patch and patches input is at most 64KiB including headers.
  Each patch text part is at most 32KiB; ordinary requests remain at most 8192 scalars.
  LF in input is data. The UI maps explicit submit separately from newline.
  Every action remains subject to native ownership and project permissions.
  '''
++  split
  |=  [delimiter=@ud text=@t]
  ^-  [head=@t tail=@t found=?]
  =/  chars=tape  (trip text)
  =/  kept=tape  ~
  |-  ^-  [head=@t tail=@t found=?]
  ?~  chars  [(crip (flop kept)) '' %.n]
  ?:  =(delimiter i.chars)  [(crip (flop kept)) (crip t.chars) %.y]
  $(chars t.chars, kept [i.chars kept])
++  words
  |=  text=@t
  ^-  (list @t)
  ?:  =('' text)  ~
  =/  part  (split 32 text)
  ?:  =('' head.part)  $(text tail.part)
  [head.part $(text tail.part)]
++  segments
  |=  text=@t
  ^-  path
  =/  part  (split 47 text)
  =/  name=@ta  head.part
  ?>  (segment-valid:editor name)
  [name ?:(found.part $(text tail.part) ~)]
++  path-of
  |=  [directory=path text=@t]
  ^-  path
  ?:  =('.' text)  directory
  ?:  =('/' text)  ~
  ?>  !=('' text)
  =/  absolute=?  =(47 (end [3 1] text))
  =/  relative  (segments ?:(absolute (rsh [3 1] text) text))
  =/  result=path  ?:(absolute relative (weld directory relative))
  ?>  (lte (lent result) 16)
  result
++  number
  |=  text=@t
  ^-  @ud
  ?>  &(!=('' text) (lte (met 3 text) 10))
  =/  chars=tape  (trip text)
  =/  value=@ud  0
  |-  ^-  @ud
  ?~  chars  value
  ?>  &((gte i.chars 48) (lte i.chars 57))
  =.  value  (add (mul value 10) (sub i.chars 48))
  ?>  (lte value 1.000.000.000)
  $(chars t.chars)
++  digest
  |=  text=@t
  ^-  @ux
  ?>  &((gte (met 3 text) 3) (lte (met 3 text) 82))
  =/  parsed  (slaw %ux text)
  ?>  ?=(^ parsed)
  ?>  &(!=(0 u.parsed) (lte (met 0 u.parsed) 256))
  u.parsed
++  name
  |=  text=@t
  ^-  @tas
  ?>  (segment-valid:editor text)
  text
++  valid-bounded
  ::  taft checks canonical UTF-8; normalize TAB only for its C0 check.
  |=  [text=@t max-bytes=@ud max-scalars=@ud]
  ^-  ?
  ?.  (lte (met 3 text) max-bytes)  %.n
  =/  normalized=tape  (turn (trip text) |=(c=@tD ^-(@tD ?:(=(9 c) ' ' c))))
  =/  decoded  (mule |.((tuba normalized)))
  ?:  ?=(%| -.decoded)  %.n
  ?&  (lte (lent p.decoded) max-scalars)
      %+  levy  p.decoded
      |=  c=@c
      ?&  (lte c 0x10.ffff)
          ?!  &((gte c 0xd800) (lte c 0xdfff))
          ?!  &((gte c 127) (lte c 159))
      ==
  ==
++  valid-text
  |=  text=@t
  ^-  ?
  (valid-bounded text 32.768 8.192)
++  patch-items
  ::  Exact byte framing preserves newlines and cannot hide a trailing command.
  |=  [body=@t count=@ud directory=path]
  ^-  (list patch-item:nc)
  ?>  (lte count 16)
  ?:  =(0 count)  ?>(=('' body) ~)
  =/  header  (split 10 body)
  ?>  found.header
  =/  fields  (words head.header)
  ?>  =(6 (lent fields))
  =/  field  |=(index=@ud ^-(@t (snag index fields)))
  =/  start=@ud  (number (field 2))
  =/  remove=@ud  (number (field 3))
  =/  old-size=@ud  (number (field 4))
  =/  new-size=@ud  (number (field 5))
  ?>  &((gte start 1) (lte old-size 32.768) (lte new-size 32.768))
  ?>  (lte (add old-size new-size) (met 3 tail.header))
  =/  expected=@t  (end [3 old-size] tail.header)
  =/  rest=@t  (rsh [3 old-size] tail.header)
  =/  replacement=@t  (end [3 new-size] rest)
  ?>  &((valid-bounded expected 32.768 32.768) (valid-bounded replacement 32.768 32.768))
  ?>  |(!=(0 remove) =('' expected))
  =/  pax=path  (path-of directory (field 0))
  ?>  ?=(^ pax)
  :-  [pax (digest (field 1)) start remove expected replacement]
  $(body (rsh [3 new-size] rest), count (dec count))
++  interpret
  ::  Internal gate may bail on malformed syntax; parse catches that bail.
  |=  [line=@t directory=path accepted=revision:nc]
  ^-  action
  ?:  !=(47 (end [3 1] line))  [%request line]
  =/  separated  (split 10 line)
  =/  header=@t
    (crip (turn (trip head.separated) |=(c=@tD ^-(@tD ?:(=(9 c) ' ' c)))))
  =/  tokens  (words header)
  ?>  ?=(^ tokens)
  =/  command=@t  i.tokens
  =/  args=(list @t)  t.tokens
  =/  count=@ud  (lent args)
  ?>  (lte count 5)
  =/  arg  |=(index=@ud ^-(@t (snag index args)))
  =/  num  |=([index=@ud default=@ud] ^-(@ud ?:((gte index count) default (number (arg index)))))
  =/  path-arg  |=(index=@ud (path-of directory (arg index)))
  =/  body=@t  tail.separated
  ::  Commands without a body reject extra lines, including a hidden second command.
  =/  needs-body=?
    ?|  =('/search' command)
        =('/create' command)
        =('/replace' command)
        =('/patch' command)
        =('/patches' command)
        =('/eval' command)
    ==
  ?>  |(?!(found.separated) needs-body)
  ?:  =('/help' command)  ?>(=(count 0) [%help ~])
  ?:  =('/interrupt' command)  ?>(=(count 0) [%interrupt ~])
  ?:  =('/pause' command)  ?>(=(count 0) [%pause ~])
  ?:  =('/reattach' command)  ?>(=(count 1) [%reattach (digest (arg 0))])
  ?:  |(=('/list' command) =('/diff' command))
    ?>  (lte count 3)
    =/  one-path=path  ?:(=(count 0) directory (path-arg 0))
    =/  cursor=@ud  ?:(=(count 0) 0 (num 1 0))
    =/  limit=@ud  ?:(=(count 0) 64 (num 2 64))
    ?>  &((gte limit 1) (lte limit 64))
    ?:  =('/list' command)  [%tool [%list one-path cursor limit]]
    [%tool [%diff accepted one-path cursor limit]]
  ?:  =('/read' command)
    ?>  &((gte count 1) (lte count 3))
    =/  start=@ud  (num 1 1)
    =/  amount=@ud  (num 2 200)
    ?>  &((gte start 1) (gte amount 1) (lte amount 200))
    [%tool [%read (path-arg 0) start amount]]
  ?:  =('/search' command)
    ?>  &(=(count 4) found.separated !=('' body) (lte (met 3 body) 256))
    =/  mode=@t  (arg 0)
    ?>  ?=(?(%text %filename %path) mode)
    =/  limit  (number (arg 3))
    ?>  &((gte limit 1) (lte limit 32))
    [%tool [%search mode body (path-arg 1) (number (arg 2)) limit]]
  ?:  =('/create' command)
    ?>  &(=(count 2) found.separated)
    [%tool [%create (path-arg 0) [(name (arg 1)) body]]]
  ?:  =('/replace' command)
    ?>  &(=(count 3) found.separated)
    [%tool [%replace (path-arg 0) (digest (arg 1)) [(name (arg 2)) body]]]
  ?:  =('/patch' command)
    ?>  &(=(count 5) found.separated)
    =/  bytes=@ud  (number (arg 4))
    ?>  (lte bytes (met 3 body))
    =/  expected=@t  (end [3 bytes] body)
    =/  replacement=@t  (rsh [3 bytes] body)
    ?>  &((valid-bounded expected 32.768 32.768) (valid-bounded replacement 32.768 32.768))
    =/  start=@ud  (number (arg 2))
    ?>  (gte start 1)
    [%tool [%patch (path-arg 0) (digest (arg 1)) start (number (arg 3)) expected replacement]]
  ?:  =('/patches' command)
    ?>  &(=(count 1) found.separated)
    =/  amount=@ud  (number (arg 0))
    ?>  &((gte amount 1) (lte amount 16))
    [%tool [%patches (patch-items body amount directory)]]
  ?:  =('/move' command)
    ?>  =(count 3)
    [%tool [%move (path-arg 0) (path-arg 1) (digest (arg 2))]]
  ?:  =('/delete' command)
    ?>  =(count 2)
    [%tool [%delete (path-arg 0) (digest (arg 1))]]
  ?:  =('/undo' command)  ?>(=(count 1) [%tool [%undo (digest (arg 0))]])
  ?:  |(=('/compile' command) =('/check' command))
    ?>  =(count 1)
    ?:  =('/compile' command)  [%tool [%compile (name (arg 0))]]
    [%tool [%check (name (arg 0))]]
  ?:  =('/eval' command)
    ?>  &(=(count 2) found.separated !=('' body))
    =/  fuel=@ud  (number (arg 1))
    ?>  &((gte fuel 1) (lte fuel 2.000.000))
    [%tool [%eval (path-arg 0) body fuel]]
  ?:  =('/inspect' command)
    ?>  =(count 2)
    [%tool [%inspect (name (arg 0)) (path-arg 1)]]
  ?:  =('/jobs' command)
    ?>  (lte count 2)
    =/  cursor=@ud  (num 0 0)
    =/  limit=@ud  ?:(=(count 0) 64 (num 1 64))
    ?>  &((gte limit 1) (lte limit 64))
    [%tool [%jobs cursor limit]]
  ?:  |(=('/observe' command) =('/cancel' command))
    ?>  =(count 1)
    ?:  =('/observe' command)  [%tool [%observe (digest (arg 0))]]
    [%tool [%cancel (digest (arg 0))]]
  !!
++  parse
  |=  [line=@t directory=path accepted=revision:nc]
  ^-  (each action @tas)
  ?.  (lte (met 3 line) 65.536)  [%| %terminal-text-invalid]
  ::  Source bodies need the file envelope, not the ordinary request limit.
  ::  Match the complete command so unknown prefixes cannot widen that limit.
  =/  header=@t  head:(split 10 line)
  =/  header=@t
    (crip (turn (trip header) |=(c=@tD ^-(@tD ?:(=(9 c) ' ' c)))))
  =/  command=@t  head:(split 32 header)
  =/  source-write=?
    |(=('/create' command) =('/replace' command) =('/patch' command) =('/patches' command))
  ?.  ?:(source-write (valid-bounded line 65.536 65.536) (valid-text line))
    [%| %terminal-text-invalid]
  ?.  (lien (trip line) |=(c=@t &(!=(9 c) !=(10 c) !=(32 c))))  [%| %terminal-empty]
  ?.  &((lte (lent directory) 16) (levy directory segment-valid:editor))
    [%| %terminal-directory-invalid]
  =/  parsed  (mule |.((interpret line directory accepted)))
  ?:  ?=(%| -.parsed)  [%| %terminal-command-invalid]
  [%& p.parsed]
--
