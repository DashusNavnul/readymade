::  Event-driven stage continuation. Only native before/after inner DATA is
::  inspected; no remote scry, new timer, public row command or reload scan.
/+  f=qpc-native-flow, owner=qpc-native-owner-binding,
    assessment=qpc-native-assessment, gate=qpc-session-gate
|%
++  read
  |=  [role=role:f inner=agent:gall b=bowl:gall]
  ^-  (unit snapshot:f)
  =/  path=path  ?:(=(%viki role) /x/qpc/owner /x/qpc/assessments)
  =/  raw  (payload:gate (on-peek:~(. inner b(src our.b)) path))
  ?~  raw  ~
  ?:  =(%viki role)
    =/  parsed  ((soft state:owner) u.raw)
    ?~  parsed  ~
    ?.  &(=(u.raw u.parsed) (valid:owner our.b u.parsed))  ~
    `[%viki u.parsed]
  =/  parsed  ((soft state:assessment) u.raw)
  ?~  parsed  ~
  ?.  &(=(u.raw u.parsed) (valid:assessment our.b u.parsed))  ~
  `[%cantrip u.parsed]
++  wire-for
  |=  n=notice:f
  /qpc-flow/[stage.n]/(scot %ux session.n)/(scot %ux after.n)
++  card
  |=  [our=@p n=notice:f]
  ^-  card:agent:gall
  =/  app=term  ?:(=(%assessment stage.n) %cantrip %viki)
  =/  payload=vase
    ?:  =(%assessment stage.n)  !>([%qpc-assess-v1 session.n])
    !>([%qpc-controller-start-v1 session.n])
  [%pass (wire-for n) %agent [our app] %poke %noun payload]
++  wrap
  |=  [role=role:f inner=agent:gall]
  =/  held=state:f  empty:f
  ^-  agent:gall
  |_  =bowl:gall
  +*  this  .
      ag  ~(. inner bowl)
      finish
        |=  [before=(unit snapshot:f) cards=(list card:agent:gall)]
        ^-  (quip card:agent:gall _this)
        ?~  before  [cards this]
        =/  after  (read role inner bowl)
        ?~  after  [cards this]
        =/  pending=(list notice:f)  (transitions:f our.bowl u.before u.after)
        =/  added=(list card:agent:gall)  ~
        |-  ^-  (quip card:agent:gall _this)
        ?~  pending  [(weld cards (flop added)) this]
        =/  next  (record:f held i.pending)
        ?:  ?=(%| -.next)  $(pending t.pending)
        =.  held  p.next
        $(pending t.pending, added [(card our.bowl i.pending) added])
  ++  on-init
    =^  cards  inner  on-init:ag
    [cards this]
  ++  on-save  !>([%qpc-flow-owner-v1 role held on-save:ag])
  ++  on-load
    |=  old=vase
    =/  saved=[role=role:f held=state:f inner=vase]
      ?.  ?=([%qpc-flow-owner-v1 *] q.old)  [role empty:f old]
      =/  prior  !<([%qpc-flow-owner-v1 role=role:f held=state:f inner=vase] old)
      +.prior
    ?>  &(=(role role.saved) (valid:f held.saved))
    =.  held  held.saved
    =^  cards  inner  (on-load:ag inner.saved)
    ::  Prior unobserved terminal rows are never retroactively enrolled.
    [cards this]
  ++  on-poke
    |=  [=mark =vase]
    =/  before  (read role inner bowl)
    =^  cards  inner  (on-poke:ag mark vase)
    (finish before cards)
  ++  on-agent
    |=  [=wire =sign:agent:gall]
    ?:  ?=([%qpc-flow *] wire)
      ?.  &(=(our.bowl src.bowl) ?=([%poke-ack ^] sign))  [~ this]
      =/  found=(list delivery:f)
        (skim ~(val by records.held) |=(v=delivery:f =(wire (wire-for notice.v))))
      ?~  found  [~ this]
      [~ this(held (failed:f held notice.i.found))]
    =/  before  (read role inner bowl)
    =^  cards  inner  (on-agent:ag wire sign)
    (finish before cards)
  ++  on-arvo
    |=  [=wire =sign-arvo]
    =/  before  (read role inner bowl)
    =^  cards  inner  (on-arvo:ag wire sign-arvo)
    (finish before cards)
  ++  on-peek
    |=  =path
    ?:  =(/x/qpc/flow path)
      ?.  =(our.bowl src.bowl)  ~
      ``noun+!>(held)
    (on-peek:ag path)
  ++  on-watch
    |=  =path
    =/  before  (read role inner bowl)
    =^  cards  inner  (on-watch:ag path)
    (finish before cards)
  ++  on-leave
    |=  =path
    =/  before  (read role inner bowl)
    =^  cards  inner  (on-leave:ag path)
    (finish before cards)
  ++  on-fail
    |=  [=term =tang]
    =/  before  (read role inner bowl)
    =^  cards  inner  (on-fail:ag term tang)
    (finish before cards)
  --
++  viki  |=(inner=agent:gall (wrap %viki inner))
++  cantrip  |=(inner=agent:gall (wrap %cantrip inner))
--
