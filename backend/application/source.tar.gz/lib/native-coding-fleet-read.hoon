::  Same-event canonical reads for fleet selection. Never peeks a remote ship.
::  Viki supplies its configured routes and legacy coding organ directly.
/-  nf=native-coding-fleet, nc=native-coding, vr=glass-moon-route,
    ws=workspace, ss=seat-session
/+  guard=viki-scry-guard, project=native-coding-project,
    seats=seat-session, workspace=workspace, routes=viki-route,
    allocation=viki-glass-route-allocation, loop=viki-glass-coding-loop
|%
+$  world
  $:  owner=@p  at=@da  seats=table:seats  configured=(list moon-route:vr)
      claims=(list claim:ws)  desks=(set @tas)
      legacy=usage:allocation  held=(list reservation:nc)  owned=(list *)
  ==
++  read
  ::  `held` comes from the owning native journals, never from a browser poke.
  |=  [our=@p actor=@p at=@da configured=(list moon-route:vr) legacy=organ:loop held=(list reservation:nc)]
  ^-  (each world @tas)
  ?.  =(our actor)  [%| %fleet-foreign-owner]
  ?.  &((lte (lent configured) 9) (lte (lent held) 256))  [%| %fleet-capacity]
  ?.  (levy `(list @tas)`~[%graf %seat-warden %multiplayer-session-coordinator %cantrip] |=(app=@tas (agent-live:guard our at app)))
    [%| %fleet-service-unavailable]
  =/  table=table:seats
    .^(table:seats %gx /(scot %p our)/seat-warden/(scot %da at)/table/noun)
  =/  rows=(list [fact=* ships=(set @p)])
    .^((list [* (set @p)]) %gx /(scot %p our)/graf/(scot %da at)/attested/noun)
  =/  owned=(list *)
    (murn rows |=([fact=* ships=(set @p)] ?:((~(has in ships) our) `fact ~)))
  =/  desks=(set @tas)
    .^((set @tas) %cd ~[(scot %p our) '' (scot %da at)])
  [%& [our at table configured (active:workspace (murn owned claim-of:workspace) desks) desks (history:allocation legacy) held owned]]
++  claim
  |=  [w=world moon=@p desk=@tas]
  ^-  (each claim:ws @tas)
  =/  found=(list claim:ws)
    (skim claims.w |=(c=claim:ws =(desk fork.c)))
  ?~  found  [%| %fleet-workspace-unclaimed]
  ?^  t.found  [%| %fleet-workspace-ambiguous]
  ?.  =(moon holder.i.found)  [%| %fleet-workspace-holder]
  [%& i.found]
++  source
  ::  Task has its own registered working desk. This reads both private Clay
  ::  revisions; a claim fact alone never establishes that the fork exists.
  |=  [w=world p=project:nc t=task:nf]
  ^-  (each ~ @tas)
  ?.  &((valid:project p) =(project.context.t id.spec.p) =(configuration.context.t (configuration:project p)) =(working.p desk.source.context.t) =(owner.w actor.context.t))
    [%| %fleet-project-context]
  ?.  (levy ~(tap in paths.t) |=(pax=path (writable:project p pax)))
    [%| %fleet-path-scope]
  =/  current  (current:project owner.w at.w p)
  ?:  ?=(%| -.current)  [%| p.current]
  ?.  &(=(accepted.t revision.accepted.p.current) =(source.context.t revision.working.p.current))
    [%| %fleet-source-changed]
  [%& ~]
++  route
  |=  [w=world r=moon-route:vr]
  ^-  ?
  &((lien configured.w |=(selected=moon-route:vr =(selected r))) (allowed:routes owner.w at.w seats.w r))
--
