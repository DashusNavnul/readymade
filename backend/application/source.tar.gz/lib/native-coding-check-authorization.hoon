::  One explicit Hoon check retry; original tool/acceptance grants never change.
/-  nc=native-coding
/+  accept=native-coding-accept, ct=cantrip-native-coding,
    project=native-coding-project
|%
+$  authorization
  $:  %native-coding-check-authorization-v1  id=@ux  at=@da
      original=record:accept  origin=grant:ct  maximum=@ud
  ==
+$  choice  [value=authorization revoked=(unit @da)]
+$  state  (map @ux choice)
+$  allowance  [maximum=@ud provenance=(unit @ux)]
+$  reader
  $-([our=@p at=@da jobs=organ:ct a=authorization r=record:accept] (each authorization @tas))
+$  command
  $%  [%native-coding-candidate-recheck-budget-v1 candidate=@ux expected=@ux maximum=@ud]
      [%native-coding-check-authorization-revoke-v1 candidate=@ux]
  ==
++  digest  |=(v=* ^-(@ux (shax (jam [%native-coding-check-authorization-v1 v]))))
++  frozen
  |=  r=record:accept
  [project.r candidate.r grant.r requested-at.r staging.r]
++  supported
  |=  ts=(list build-target:nc)
  (levy ts |=(t=build-target:nc =(%hoon kind.t)))
++  valid
  |=  [our=@p a=authorization]
  ^-  ?
  =/  r=record:accept  original.a
  ?&  =(id.a (digest a(id 0x0)))  !=(0 at.a)
      (valid:accept (~(put by *ledger:accept) id.candidate.r r))
      =(%unknown stage.r)  =(`%candidate-check-unconfirmed reason.r)
      ?=(^ staging.r)  =(~ report.r)  =(~ decision.r)  =(~ landed.r)
      (grant-valid:ct our origin.a)  =(grant.r id.origin.a)
      =(project.r project.origin.a)
      =(session.context.candidate.r session.origin.a)
      =(actor.context.candidate.r actor.origin.a)  =(our actor.origin.a)
      (~(has in operations.origin.a) %compile)
      (~(has in operations.origin.a) %check)
      (gth maximum.a max-eval-work.origin.a)  (lte maximum.a 2.000.000)
      (supported (required:accept project.r candidate.r))
  ==
++  transition
  ::  Only ordinary retry states may execute with the registered allowance.
  |=  [a=authorization r=record:accept]
  ^-  ?
  ?&  =((frozen original.a) (frozen r))
      =(%checking stage.r)  =(~ report.r)  =(~ decision.r)  =(~ landed.r)
      |(=(`%candidate-recheck-scheduled reason.r) =(`%candidate-recheck reason.r))
  ==
++  scopes
  |=  [our=@p jobs=organ:ct a=authorization]
  ^-  ?
  =/  origin  (~(get by grants.jobs) id.origin.a)
  ?~  origin  %.n
  &((valid our a) =(origin.a grant.u.origin) =(~ revoked.u.origin))
++  current
  |=  [our=@p at=@da jobs=organ:ct a=authorization r=record:accept]
  ^-  (each authorization @tas)
  ?.  (scopes our jobs a)  [%| %check-authorization-scope-invalid]
  ?.  =((frozen original.a) (frozen r))  [%| %check-authorization-candidate-changed]
  =/  allowed  (candidate-permission:ct our at jobs r)
  ?:  ?=(%| -.allowed)  [%| p.allowed]
  =/  catalog  (catalog:project our at project.r)
  ?:  ?=(%| -.catalog)  [%| p.catalog]
  ?.  &((member:project project.r p.catalog our %compile) (member:project project.r p.catalog our %check))
    [%| %check-authorization-membership-refused]
  =/  source  (current:project our at project.r)
  ?:  ?=(%| -.source)  [%| p.source]
  =/  stage  (staged:accept our at r)
  ?:  ?=(%| -.stage)  [%| p.stage]
  ?.  (source-matches r accepted.p.source working.p.source p.stage)
    [%| %check-authorization-source-changed]
  [%& a]
++  source-matches
  |=  [r=record:accept accepted=tree:nc working=tree:nc stage=tree:nc]
  &(=(basis.candidate.r working) =(accepted.candidate.r revision.accepted) =(`stage staging.r))
++  payload
  |=  value=(unit (unit cage))
  ^-  (unit *)
  ?~  value  ~
  ?~  u.value  ~
  ?.  =(%noun p.u.u.value)  ~
  `q.q.u.u.value
++  inputs
  |=  [inner=agent:gall b=bowl:gall id=@ux]
  ^-  [jobs=organ:ct candidate=(unit record:accept)]
  =/  ag  ~(. inner b(src our.b))
  =/  jobs  (payload (on-peek:ag /x/native-coding/tool-state))
  =/  candidate  (payload (on-peek:ag /x/native-coding/candidate/(scot %ux id)))
  ?>  &(?=(^ jobs) ?=(^ candidate))
  =/  parsed-jobs  ((soft organ:ct) u.jobs)
  =/  parsed-candidate  ((soft ,(unit record:accept)) u.candidate)
  ?>  &(?=(^ parsed-jobs) ?=(^ parsed-candidate))
  [u.parsed-jobs u.parsed-candidate]
++  lookup
  |=  [inner=agent:gall b=bowl:gall held=state id=@ux]
  ^-  (unit (each authorization @tas))
  =/  prior  (~(get by held) id)
  ?~  prior  ~
  ?^  revoked.u.prior  `[%| %check-authorization-revoked]
  =/  got  (inputs inner b id)
  ?~  candidate.got  `[%| %check-authorization-candidate-missing]
  =/  r=record:accept  u.candidate.got
  ?.  &(=(id id.candidate.r) (transition value.u.prior r) (check-dispatched:accept r))
    `[%| %check-authorization-not-dispatched]
  `(current our.b now.b jobs.got value.u.prior r)
++  effective
  ::  Only the canonical wrapper scry may select supplemental check authority.
  |=  [our=@p at=@da r=record:accept original=scope:ct]
  ^-  (each allowance @tas)
  =/  live=(unit scope:ct)
    .^((unit scope:ct) %gx /(scot %p our)/cantrip/(scot %da at)/native-coding/grant/(scot %ux grant.r)/noun)
  ?.  =(`original live)  [%| %check-original-scope-changed]
  ?.  =(~ revoked.original)  [%| %check-original-scope-revoked]
  =/  got=(unit (each authorization @tas))
    .^((unit (each authorization @tas)) %gx /(scot %p our)/cantrip/(scot %da at)/native-coding/check-authorization/(scot %ux id.candidate.r)/noun)
  (choose our r original got)
++  choose
  |=  [our=@p r=record:accept original=scope:ct got=(unit (each authorization @tas))]
  ^-  (each allowance @tas)
  ?~  got  [%& [max-eval-work.grant.original ~]]
  ?:  ?=(%| -.u.got)  [%| p.u.got]
  =/  a=authorization  p.u.got
  ?.  &((valid our a) (transition a r) =(origin.a grant.original))
    [%| %check-authorization-binding-mismatch]
  [%& [maximum.a `id.a]]
++  agent  |=(inner=agent:gall (agent-with current inner))
++  agent-with
  ::  The production composition fixes current; only the native proof supplies
  ::  an inert reader. No Gall command selects a reader or supplies authority.
  |=  [read=reader inner=agent:gall]
  =|  held=state
  ^-  agent:gall
  |_  =bowl:gall
  +*  this  .
      ag  ~(. inner bowl)
  ++  on-init
    =^  cards  inner  on-init:ag
    [cards this]
  ++  on-save  !>([%native-coding-check-authorizations-v1 held on-save:ag])
  ++  on-load
    |=  old=vase
    =/  saved=[state=state inner=vase]
      ?.  ?=([%native-coding-check-authorizations-v1 *] q.old)  [~ old]
      =/  value  !<([%native-coding-check-authorizations-v1 state=state inner=vase] old)
      +.value
    ?>  (lte ~(wyt by state.saved) 128)
    ?>  (levy ~(tap by state.saved) |=([id=@ux c=choice] &(=(id id.candidate.original.value.c) (valid our.bowl value.c))))
    =.  held  state.saved
    =^  cards  inner  (on-load:ag inner.saved)
    [cards this]
  ++  on-poke
    |=  [=mark =vase]
    ?.  &(=(%noun mark) ?=([?(%native-coding-candidate-recheck-budget-v1 %native-coding-check-authorization-revoke-v1) *] q.vase))
      =^  cards  inner  (on-poke:ag mark vase)
      [cards this]
    ?>  =(our.bowl src.bowl)
    =/  c=command  !<(command vase)
    =/  key=@ux
      ?-  -.c
        %native-coding-candidate-recheck-budget-v1  candidate.c
        %native-coding-check-authorization-revoke-v1  candidate.c
      ==
    =/  previous  (~(get by held) key)
    ?:  ?=(%native-coding-check-authorization-revoke-v1 -.c)
      ?>  ?=(^ previous)
      ?^  revoked.u.previous  [~ this]
      :_  this(held (~(put by held) candidate.c [value.u.previous `now.bowl]))
      ~[(evidence:ct our.bowl [%check-authorization-revoked id.value.u.previous now.bowl])]
    ?^  previous
      ?>  &(=(maximum.c maximum.value.u.previous) =(expected.c (shax (jam original.value.u.previous))))
      [~ this]
    ?>  (lth ~(wyt by held) 128)
    =/  got  (inputs inner bowl candidate.c)
    ?>  ?=(^ candidate.got)
    =/  r=record:accept  u.candidate.got
    ?>  &(=(candidate.c id.candidate.r) =(expected.c (shax (jam r))))
    =/  origin  (~(got by grants.jobs.got) grant.r)
    =/  a=authorization
      [%native-coding-check-authorization-v1 0x0 now.bowl r grant.origin maximum.c]
    =.  a  a(id (digest a))
    ~|  %check-authorization-unsupported-backend
    ?>  (supported (required:accept project.r candidate.r))
    ~|  %check-authorization-invalid
    ?>  (valid our.bowl a)
    =/  allowed  (read our.bowl now.bowl jobs.got a r)
    ?>  ?=(%& -.allowed)
    ::  Inner owner retains readiness, law, single retry and future Behn.
    =^  cards  inner
      (on-poke:ag %noun !>(`command:accept`[%native-coding-candidate-recheck-v1 candidate.c]))
    =/  after  (inputs inner bowl candidate.c)
    ?>  ?=(^ candidate.after)
    ?>  &(=(r(stage %checking, reason `%candidate-recheck-scheduled) u.candidate.after) (transition a u.candidate.after))
    :_  this(held (~(put by held) candidate.c [a ~]))
    ::  Evidence follows inner publication and timer in the returned order.
    (weld cards ~[(evidence:ct our.bowl [%check-authorization a])])
  ++  on-peek
    |=  =path
    ?:  =(/x/native-coding/check-authorizations path)
      ?.  =(our.bowl src.bowl)  ~
      ``noun+!>(held)
    ?:  ?=([%x %native-coding %check-authorization @ ~] path)
      ?.  =(our.bowl src.bowl)  ~
      =/  id  (slaw %ux i.t.t.t.path)
      ?~  id  [~ ~]
      ?.  =((scot %ux u.id) i.t.t.t.path)  [~ ~]
      ``noun+!>((lookup inner bowl held u.id))
    (on-peek:ag path)
  ++  on-watch
    |=  =path
    =^  cards  inner  (on-watch:ag path)
    [cards this]
  ++  on-leave
    |=  =path
    =^  cards  inner  (on-leave:ag path)
    [cards this]
  ++  on-agent
    |=  [=wire =sign:agent:gall]
    =^  cards  inner  (on-agent:ag wire sign)
    [cards this]
  ++  on-arvo
    |=  [=wire =sign-arvo]
    =^  cards  inner  (on-arvo:ag wire sign-arvo)
    [cards this]
  ++  on-fail
    |=  [=term =tang]
    =^  cards  inner  (on-fail:ag term tang)
    [cards this]
  --
--
