::  Full moon result joined to Viki's admitted goal and native coordinator.
::  The caller obtains the record from its authenticated coordinator watch;
::  these pure checks validate that record, not its transport origin.
/-  msc=glass-moon-coordinator, mse=glass-moon-executor,
    mb=model-bridge, cs=vibecoding-check-spec
/+  generation=cantrip-glass-generation, vgc=viki-glass-coding,
    route=viki-route, planner=plan, coordinator=glass-moon-coordinator,
    executor=glass-moon-executor, candidate=vibecoding-candidate,
    grok=grok-provider-receipt, codex=codex-provider-receipt,
    protocol=vibecoding-compile-protocol,
    image=vibecoding-local-image
|%
+$  result
  $:  %glass-coding-result-v1
      prepared=prepared:vgc  record=record:msc
      provider=provider-result:mse  source=@t  at=@da
  ==
+$  pending  [result=result order=order:protocol]
+$  judgment
  $:  %glass-coding-judgment-v1
      pending=pending  artifact=artifact:protocol
      checks=(list check:image)  decision=?(%approve-write %request-remediation)
      at=@da
  ==
+$  rejection
  $:  %glass-coding-rejection-v1  pending=pending
      refusal=[%refused request=@ux reason=@tas detail=@t]  at=@da
  ==
+$  failure
  $%  [%glass-coding-judgment-v1 pending=pending artifact=artifact:protocol checks=(list check:image) decision=?(%approve-write %request-remediation) at=@da]
      [%glass-coding-rejection-v1 pending=pending refusal=[%refused request=@ux reason=@tas detail=@t] at=@da]
  ==
++  action-for
  |=  p=prepared:vgc
  ^-  action:vgc
  =/  p=prepared-v1:vgc  (base:vgc p)
  =/  a=admission:generation  admission.p
  =/  e=evidence:generation  evidence.a
  :*  %viki-glass-coding-generate  nonce.a  gid.goal.e
        id.intent.intent.context.e  (pid:planner plan.e)
        (key-for:route route.e)  (commitment:route route.e)
        work.context.e  `@ux`(shax before.context.e)
        (digest:generation context.e)  (digest:generation approval.e)
        sender-session.input.p
  ==
++  prepared-valid
  |=  [our=@p prepared=prepared:vgc]
  ^-  ?
  =/  p=prepared-v1:vgc  (base:vgc prepared)
  =/  a=admission:generation  admission.p
  =/  e=evidence:generation  evidence.a
  =/  admitted  (admit:generation our our at.a nonce.a e)
  ?.  &(?=(%& -.admitted) =(p.admitted a) =(route.p route.e))  %.n
  =/  ordinary  (input-for:vgc (action-for p) a)
  ?.  ?=(%& -.ordinary)  %.n
  ?.  ?=([%glass-coding-prepared-v2 *] prepared)
    =(p.ordinary input.p)
  ::  Refine raw prior evidence only here. Reject another v2 before calling
  ::  any recursive validator: exactly one correction, never a proof chain.
  =/  parsed  ((soft ,failure) prior.prepared)
  ?~  parsed  %.n
  =/  j=failure  u.parsed
  =/  previous=pending  (failure-pending j)
  ?:  ?=([%glass-coding-prepared-v2 *] prepared.result.previous)  %.n
  ?.  (failure-rejected j)  %.n
  =/  original=prepared-v1:vgc  (base:vgc prepared.result.previous)
  ?.  ?&  =(our owner.order.previous)
          =(e evidence.admission.original)
          =(sender-session.input.p sender-session.input.original)
          =(nonce.a (correction-nonce:vgc j))
          !=(nonce.a nonce.admission.original)  (lte (failure-at j) at.a)
          =(guidance.prepared (failure-guidance j))
      ==  %.n
  =/  expected  (correction-input:vgc p guidance.prepared)
  &(?=(%& -.expected) =(p.expected input.p))
++  capture-provider
  |=  [our=@p actor=@p now=@da p=prepared:vgc r=record:msc]
  ^-  (each provider-result:mse @tas)
  ?.  =(our actor)  [%| %foreign-owner]
  ?.  (prepared-valid our p)  [%| %generation-invalid]
  =/  base=prepared-v1:vgc  (base:vgc p)
  ?.  =(input.base input.r)  [%| %coordinator-input-mismatch]
  =/  original=record:msc
    (make-record:coordinator our input.base sent-at.body.request.r)
  ?.  ?&  =(key.r key.original)  =(payload-digest.r payload-digest.original)
          =(request.r request.original)  =(deadline.r deadline.original)
          (lte at.admission.base sent-at.body.request.r)
          (lte sent-at.body.request.r now)
      ==  [%| %coordinator-request-mismatch]
  ?~  terminal.r  [%| %generation-pending]
  ?.  ?=(%completed -.u.terminal.r)  [%| %generation-not-completed]
  =/  response  response.u.terminal.r
  ?.  ?&  (lte sent-at.body.request.r sent-at.body.response)
          (lte sent-at.body.response now)  (lth sent-at.body.response deadline.r)
      ==  [%| %terminal-time-invalid]
  =/  returned  (decode-provider-result:executor request.r response)
  ?~  returned  [%| %provider-result-invalid]
  [%& u.returned]
++  terminal-error
  ::  Confirmed provider failure only. Lost delivery, timeout, protocol and
  ::  transport uncertainty retain the worker reservation.
  |=  [our=@p actor=@p now=@da p=prepared:vgc r=record:msc]
  ^-  (each provider-result:mse @tas)
  =/  checked  (capture-provider our actor now p r)
  ?:  ?=(%| -.checked)  checked
  =/  provider=provider-result:mse  p.checked
  ?.  ?=(%error -.terminal.provider)  [%| %provider-terminal-error-required]
  ?.  ?|  =(%not-ready code.error.terminal.provider)
          =(%invalid-request code.error.terminal.provider)
          =(%process code.error.terminal.provider)
      ==  [%| %provider-outcome-uncertain]
  checked
++  capture
  |=  [our=@p actor=@p now=@da p=prepared:vgc r=record:msc]
  ^-  (each result @tas)
  =/  returned  (capture-provider our actor now p r)
  ?:  ?=(%| -.returned)  [%| p.returned]
  =/  base=prepared-v1:vgc  (base:vgc p)
  =/  completed  (need terminal.r)
  ?>  ?=(%completed -.completed)
  =/  response  response.completed
  =/  provider=provider-result:mse  p.returned
  ?.  ?=(%result -.terminal.provider)  [%| %provider-not-successful]
  =/  output=model-bridge-result:mb  result.terminal.provider
  ?.  ?&  =(%ok status.output)  =('' error.output)
          =('[]' tool-calls-json.output)
      ==  [%| %provider-not-successful]
  =/  grok-valid=?
    ?.  =(%grok kind.provider.route.base)  %.y
    =/  checked  (inspect:grok spec.provider request.provider output)
    ?=(%& -.checked)
  ?.  grok-valid  [%| %grok-receipt-invalid]
  =/  codex-valid=?
    ?.  =(%codex kind.provider.route.base)  %.y
    =/  checked  (inspect:codex spec.provider request.provider output)
    ?=(%& -.checked)
  ?.  codex-valid  [%| %codex-receipt-invalid]
  =/  source  (source-of:candidate content.output)
  ?~  source  [%| %candidate-source-invalid]
  ?:  =(u.source before.context.evidence.admission.base)
    [%| %candidate-unchanged]
  ::  Stable authenticated response time, not the time of a repeated read.
  [%& [%glass-coding-result-v1 p r provider u.source sent-at.body.response]]
++  valid
  |=  r=result
  ^-  ?
  =/  p=prepared-v1:vgc  (base:vgc prepared.r)
  =/  our=@p  by.intent.intent.context.evidence.admission.p
  =/  checked  (capture our our at.r prepared.r record.r)
  &(?=(%& -.checked) =(p.checked r))
++  key
  |=  r=result
  ^-  @ux
  ::  Delivery acknowledgments may settle after the response. They remain in
  ::  the full receipt but cannot create a second proposed-write identity.
  =/  p=prepared-v1:vgc  (base:vgc prepared.r)
  =/  a=admission:generation  admission.p
  (digest:generation [%glass-coding-proposed-change-v1 nonce.a digest.a evidence.a route.p input.p request.record.r provider.r source.r])
++  order-for
  |=  [our=@p actor=@p now=@da compiler=@p r=result]
  ^-  (each pending @tas)
  ?.  =(our actor)  [%| %foreign-owner]
  =/  p=prepared-v1:vgc  (base:vgc prepared.r)
  ?.  ?&  (valid r)
          =(our by.intent.intent.context.evidence.admission.p)
          (lte at.r now)
      ==  [%| %candidate-invalid]
  =/  o=order:protocol
    [%vibecoding-compile-order-v1 our compiler (key r) source.r (shax source.r) now (add now ~m5)]
  ?.  (valid:protocol o)  [%| %compiler-not-owned]
  [%& [r o]]
++  pending-valid
  |=  p=pending
  ^-  ?
  =/  made
    (order-for owner.order.p owner.order.p at.order.p worker.order.p result.p)
  &(?=(%& -.made) =(p.made p))
++  evaluate
  |=  [p=pending artifact=artifact:protocol]
  ^-  (list check:image)
  =/  prepared=prepared-v1:vgc  (base:vgc prepared.result.p)
  %+  turn  cases.specification.approval.evidence.admission.prepared
  |=  example=example:cs
  =/  actual=evaluation:image  (run-with:image 500.000 gate.artifact input.example)
  [expected.example actual &(=(%ran status.actual) =(`expected.example output.actual))]
++  judgment-valid
  |=  j=judgment
  ^-  ?
  ?&  (pending-valid pending.j)
      (matches:protocol order.pending.j artifact.j)
      (lte at.compiler.artifact.j at.j)  (lth at.j expires.order.pending.j)
      =(checks.j (evaluate pending.j artifact.j))
      =(decision.j ?:((levy checks.j |=(c=check:image passed.c)) %approve-write %request-remediation))
  ==
++  rejection-valid
  ::  This validates the exact retained diagnostic, not its transport origin.
  ::  Unknown transport, expired orders and infrastructure refusals cannot retry.
  |=  r=rejection
  ^-  ?
  ?&  (pending-valid pending.r)
      =((digest:protocol order.pending.r) request.refusal.r)
      ?=(?(%compile-failed %interface-mismatch) reason.refusal.r)
      (gth (met 3 detail.refusal.r) 0)  (lte (met 3 detail.refusal.r) 2.048)
      (lte at.order.pending.r at.r)  (lth at.r expires.order.pending.r)
  ==
++  failure-pending
  |=  f=failure
  ^-  pending
  pending.f
++  failure-at
  |=  f=failure
  ^-  @da
  ?-  -.f
    %glass-coding-judgment-v1   at.f
    %glass-coding-rejection-v1  at.f
  ==
++  failure-valid
  |=  f=failure
  ^-  ?
  ?:(?=(%glass-coding-judgment-v1 -.f) (judgment-valid f) (rejection-valid f))
++  failure-rejected
  |=  f=failure
  ^-  ?
  ?.  (failure-valid f)  %.n
  ?:(?=(%glass-coding-judgment-v1 -.f) =(%request-remediation decision.f) %.y)
++  failure-fact
  |=  f=failure
  ^-  *
  =/  tag=@tas
    ?:(?=(%glass-coding-judgment-v1 -.f) %glass-coding-judgment %glass-coding-compiler-rejection)
  [tag (scot %ux (digest:generation f)) f]
++  failure-guidance
  |=  f=failure
  ^-  @t
  ?:  ?=(%glass-coding-judgment-v1 -.f)  (guidance f)
  =/  p=pending  pending.f
  =/  prepared=prepared-v1:vgc  (base:vgc prepared.result.p)
  =/  original=evidence:generation  evidence.admission.prepared
  %+  rap  3
  :~  'Correct the compiler-rejected candidate for this unchanged operator goal:\0a'
      text.goal.original
      '\0aOriginal generation: '  (scot %ux nonce.admission.prepared)
      '\0aOriginal intent: '  `@t`id.intent.intent.context.original
      '\0aOriginal source context: '  (scot %ux (digest:generation context.original))
      '\0aOriginal check approval: '  (scot %ux (digest:generation approval.original))
      '\0aUnchanged ordered examples [participants minutes expected]:\0a'
      (rap 3 (turn cases.specification.approval.original example-text:vgc))
      '\0aRejected candidate:\0a'  source.result.p
      '\0aCompiler rejection: '  `@t`reason.refusal.f
      '\0aExact compiler diagnostic:\0a'  detail.refusal.f
      '\0aChecks were not run because compilation failed. Keep the original goal, source basis, ordered examples, interface and permissions unchanged. Return corrected source for the same target; this guidance grants no execution or write authority.'
  ==
++  check-text
  |=  c=check:image
  ^-  @t
  =/  actual=@t
    ?~  output.actual.c  '<no value>'
    (scot %ud u.output.actual.c)
  %+  rap  3
  :~  'input ['  (scot %ud participants.input.actual.c)  ' '
      (scot %ud minutes.input.actual.c)  ']: expected '
      (scot %ud expected.c)  '; actual '  actual
      '; evaluation '  `@t`status.actual.c
      ?:(passed.c '; passed.\0a' '; FAILED.\0a')
  ==
++  guidance
  |=  j=judgment
  ^-  @t
  =/  p=pending  pending.j
  =/  prepared=prepared-v1:vgc  (base:vgc prepared.result.p)
  =/  original=evidence:generation  evidence.admission.prepared
  =/  failure=@t  (rap 3 (turn checks.j check-text))
  %+  rap  3
  :~  'Correct the failed candidate for this unchanged operator goal:\0a'
      text.goal.original
      '\0aOriginal generation: '  (scot %ux nonce.admission.prepared)
      '\0aOriginal intent: '  `@t`id.intent.intent.context.original
      '\0aOriginal source context: '  (scot %ux (digest:generation context.original))
      '\0aOriginal check approval: '  (scot %ux (digest:generation approval.original))
      '\0aUnchanged ordered examples [participants minutes expected]:\0a'
      (rap 3 (turn cases.specification.approval.original example-text:vgc))
      '\0aFailed candidate:\0a'  source.result.p
      '\0aExact failure evidence:\0a'  failure
      'Keep the original goal, source basis, ordered examples, interface and permissions unchanged. Fix the candidate; do not weaken checks or claim success without them. Return source as data for the same target; this guidance grants no execution or write authority.'
  ==
++  fact
  |=  r=result
  ^-  *
  [%glass-coding-result (scot %ux (key r)) r]
--
