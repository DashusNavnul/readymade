::  Pure package protocol. Native caller supplies authenticated actor/sender,
::  live Clay observations and canonical saved state. No cards or activation.
/-  rp=readymade-package
|%
++  commit
  |=  value=*
  ^-  digest:rp
  (shax (jam value))
++  digest-valid
  |=  value=digest:rp
  ^-  ?
  &(!=(0 value) (lte (met 0 value) 256))
++  source-file
  |=  [p=path bytes=@]
  ^-  file:rp
  [p (met 3 bytes) (shay (met 3 bytes) bytes)]
++  canonical
  |=  files=(list file:rp)
  ^-  (list file:rp)
  ~(tap in (silt files))
++  manifest
  |=  files=(list file:rp)
  ^-  digest:rp
  (commit [%readymade-package-manifest-v1 (canonical files)])
++  segment-valid
  ::  Bounded source names; no traversal, controls or path separators.
  |=  segment=@ta
  ^-  ?
  ?&  !=(0 segment)
      !=('.' segment)
      !=('..' segment)
      (lte (met 3 segment) 128)
      %+  levy  (trip segment)
      |=  c=@t
      |(&((gte c 'a') (lte c 'z')) &((gte c 'A') (lte c 'Z')) &((gte c '0') (lte c '9')) =(c '-') =(c '_') =(c '.'))
  ==
++  pin-valid
  |=  p=pin:rp
  ^-  ?
  &((segment-valid desk.p) (gth revision.p 0) !=(0 root.p))
++  path-valid
  |=  p=path
  ^-  ?
  ?&  (gte (lent p) 3)
      (lte (lent p) 16)
      (levy p segment-valid)
      !(lien `(list path)`~[/desk/bill /sys/kelvin] |=(q=path =(p q)))
      ?=(?(%app %lib %sur %mar %ted %ui) (snag 0 p))
      ?=(?(%hoon %js %css %html %svg %txt) (rear p))
  ==
++  files-valid
  |=  files=(list file:rp)
  ^-  ?
  =/  paths=(set path)  (silt (turn files |=(f=file:rp path.f)))
  ?&  (gte (lent files) 1)
      (lte (lent files) 256)
      =(files (canonical files))
      =((lent files) ~(wyt in paths))
      (lte (roll files |=([f=file:rp n=@ud] (add n size.f))) 16.777.216)
      (levy files |=(f=file:rp &((path-valid path.f) (lte size.f 1.048.576) (digest-valid hash.f))))
  ==
++  body-valid
  |=  b=body:rp
  ^-  ?
  ?&  !=(sender.b recipient.b)
      =(sender.b ship.source.b)
      (pin-valid source.b)
      (digest-valid graf-root.b)
      (files-valid files.b)
      (gte (met 3 instructions.b) 1)
      (lte (met 3 instructions.b) 4.096)
  ==
++  offer-digest
  |=  b=body:rp
  ^-  digest:rp
  (commit [%readymade-package-offer-v1 b])
++  valid
  |=  o=offer:rp
  ^-  ?
  &((body-valid body.o) =(digest.o (offer-digest body.o)))
++  make
  |=  b=body:rp
  ^-  offer:rp
  ?>  =((lent files.b) (lent (canonical files.b)))
  =/  b  b(files (canonical files.b))
  ?>  (body-valid b)
  [b (offer-digest b)]
++  receive
  ::  Prior is read from recipient-owned saved state, never the wire.
  |=  [our=@p sender=@p o=offer:rp prior=(unit state:rp)]
  ^-  outcome:rp
  ?.  (valid o)  [%| %invalid]
  ?.  =(sender sender.body.o)  [%| %sender]
  ?.  =(our recipient.body.o)  [%| %recipient]
  ?^  prior
    ?.  =(o offer.u.prior)  [%| %digest]
    [%& u.prior]
  [%& [o %received ~ ~ ~ ~]]
++  inspection-digest
  |=  o=offer:rp
  ^-  digest:rp
  (commit [%readymade-package-inspection-v1 digest.o source.body.o (manifest files.body.o)])
++  inspect
  ::  Read pinned Clay revision, hash actual bytes, then supply observation.
  |=  [s=state:rp observed=pin:rp files=(list file:rp)]
  ^-  outcome:rp
  ?.  (valid offer.s)  [%| %invalid]
  ?.  =(observed source.body.offer.s)  [%| %source]
  ?.  &((files-valid files) =(files files.body.offer.s))  [%| %manifest]
  ?:  =(inspection.s `(inspection-digest offer.s))  [%& s]
  ?.  =(%received stage.s)  [%| %stage]
  [%& s(stage %inspected, inspection `(inspection-digest offer.s))]
++  consent-digest
  |=  [o=offer:rp destination=@tas]
  ^-  digest:rp
  (commit [%readymade-package-consent-v1 recipient.body.o digest.o (inspection-digest o) destination])
++  decide
  ::  Only owner command. Explicit offered digest binds both accept/decline.
  ::  Existing destination desks are refused, including empty existing desks.
  |=  $:  our=@p
          actor=@p
          s=state:rp
          expected=digest:rp
          accept=?
          destination=@tas
          desks=(set @tas)
      ==
  ^-  outcome:rp
  ?.  =(our actor)  [%| %owner]
  ?.  =(our recipient.body.offer.s)  [%| %recipient]
  ?.  (valid offer.s)  [%| %invalid]
  ?.  =(expected digest.offer.s)  [%| %digest]
  ?:  &(!accept =(%declined stage.s))  [%& s]
  ?:  &(accept ?=(?(%accepted %built %failed) stage.s))
    ?~  destination.s  [%| %invalid]
    ?.  =(destination u.destination.s)  [%| %collision]
    ?.  =(consent.s `(consent-digest offer.s destination))  [%| %invalid]
    [%& s]
  ?.  accept
    ?.  ?=(?(%received %inspected) stage.s)  [%| %stage]
    [%& s(stage %declined)]
  ?.  =(%inspected stage.s)  [%| %stage]
  ?.  =(inspection.s `(inspection-digest offer.s))  [%| %invalid]
  ?.  &((segment-valid destination) !=(destination desk.source.body.offer.s))
    [%| %collision]
  ?:  (lien `(list @tas)`~[%base %germ %pataphor %$] |=(d=@tas =(d destination)))
    [%| %collision]
  ?:  (~(has in desks) destination)  [%| %collision]
  [%& s(stage %accepted, destination `destination, consent `(consent-digest offer.s destination))]
++  finish
  ::  Owner-local runner submits evidence; no result grants deployment.
  |=  [our=@p actor=@p s=state:rp observed=pin:rp r=result:rp]
  ^-  outcome:rp
  ?.  =(our actor)  [%| %owner]
  ?.  =(our recipient.body.offer.s)  [%| %recipient]
  ?.  (valid offer.s)  [%| %invalid]
  ?.  =(observed source.body.offer.s)  [%| %source]
  ?:  ?=(^ result.s)
    ?:  =(r u.result.s)  [%& s]
    [%| %result]
  ?.  =(%accepted stage.s)  [%| %stage]
  ?~  consent.s  [%| %invalid]
  ?~  destination.s  [%| %invalid]
  ?.  =((consent-digest offer.s u.destination.s) u.consent.s)  [%| %invalid]
  ?.  ?&  =(offer.r digest.offer.s)
          =(consent.r u.consent.s)
          =(source.r observed)
          =(manifest.r (manifest files.body.offer.s))
          (digest-valid proof.r)
          ?:  success.r
            ?~  artifact.r  %.n
            (digest-valid u.artifact.r)
          =(~ artifact.r)
      ==
    [%| %result]
  [%& s(stage ?:(success.r %built %failed), result `r)]
--
