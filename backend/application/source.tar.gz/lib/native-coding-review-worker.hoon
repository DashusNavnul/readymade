::  Durable moon review dispatch. Only this moon publishes its contribution;
::  a publication attempt is never presented as a retained/admitted vote.
/-  np=native-coding-provider, bx=boxy, jm=juggler-match
/+  review=native-coding-review-request, inference=native-coding-inference,
    boxy=boxy-law, guard=viki-scry-guard
|%
+$  phase  ?(%pending %unknown %submitted %refused %cancelled)
+$  job
  $:  config=config:review  request=request:review  inference=request:np
      phase=phase  cancelled=?  reason=@tas
      contribution=(unit contribution:jm)  receipt=@ux
  ==
+$  state
  [%native-coding-review-worker-v1 config=(unit config:review) generation=@ud jobs=(map @ux job) joins=(set @ux)]
+$  transition  [state=state cards=(list card:agent:gall)]
+$  event
  $:  %native-coding-review-event-v1  binding=@ux  generation=@ud
      request=@ux  id=@ux  phase=phase  contribution=(unit contribution:jm)
      reason=@tas  receipt=@ux
  ==
+$  inference-status
  $:  %native-coding-inference-status-v1
      controller=@tas
      credentials=@ud
      selections=@ud
      pending=@ud
      jobs=@ud
  ==
+$  command
  $%  [%native-coding-review-configure-v1 config=config:review]
      [%native-coding-review-controller-v1 ~]
      [%native-coding-review-disable-v1 ~]
      [%native-coding-review-request-v1 binding=@ux generation=@ud request=request:review]
      [%native-coding-review-join-v1 binding=@ux generation=@ud workspace=workspace-state:bx]
      [%native-coding-review-inspect-v1 binding=@ux generation=@ud nonce=@ux]
      [%native-coding-review-observe-v1 binding=@ux generation=@ud id=@ux request=@ux]
      [%native-coding-review-cancel-v1 binding=@ux generation=@ud id=@ux request=@ux]
  ==
++  empty  ^-  state  [%native-coding-review-worker-v1 ~ 0 ~ ~]
++  busy
  |=  s=state
  ^-  ?
  (lien ~(val by jobs.s) |=(j=job ?=(?(%pending %unknown) phase.j)))
++  valid
  |=  [our=@p s=state]
  ^-  ?
  ?&  (lte ~(wyt by jobs.s) 32)  (lte ~(wyt in joins.s) 64)
      ?~(config.s %.y &((config-valid:review our u.config.s) =(generation.s generation.u.config.s)))
      %+  levy  ~(tap by jobs.s)
      |=  [id=@ux j=job]
      =/  prepared  (inference:review our config.j request.j)
      ?.  ?=(%& -.prepared)  %.n
      ?&  =(id id.request.j)  =(id id.inference.j)
          (lte generation.config.j generation.s)
          =(p.prepared inference.j)
          ?:(=(%submitted phase.j) ?=(^ contribution.j) %.y)
      ==
  ==
++  local
  |=  [our=@p id=@ux command=command:inference]
  ^-  card:agent:gall
  [%pass /native-review/local/(scot %tas -.command)/(scot %ux id) %agent [our %codex-inference] %poke %noun !>(command)]
++  notice
  |=  j=job
  ^-  card:agent:gall
  =/  event=event
    [%native-coding-review-event-v1 (digest:review config.j) generation.config.j (digest:review request.j) id.request.j phase.j contribution.j reason.j receipt.j]
  [%pass /native-review/reply/(scot %ux id.request.j) %agent [parent.config.j %viki] %poke %noun !>(event)]
++  put
  |=  [s=state j=job cards=(list card:agent:gall)]
  ^-  transition
  [s(jobs (~(put by jobs.s) id.request.j j)) [(notice j) cards]]
++  ready
  |=  [our=@p at=@da]
  ^-  ?
  ?.  (agent-live:guard our at %codex-inference)  %.n
  =/  observed=*
    .^(* %gx /(scot %p our)/codex-inference/(scot %da at)/native-coding/status/noun)
  =/  parsed  ((soft inference-status) observed)
  ?~  parsed  %.n
  &(=(%native-coding-reviewer controller.u.parsed) =(0 pending.u.parsed))
++  handle
  |=  [our=@p src=@p at=@da s=state action=command]
  ^-  (each transition @tas)
  ?:  ?=(%native-coding-review-controller-v1 -.action)
    ?.  =(our src)  [%| %owner-required]
    [%& [s ~[(local our 0x0 [%native-coding-controller %native-coding-reviewer])]]]
  ?:  ?=(%native-coding-review-configure-v1 -.action)
    ?.  &(=(our src) (config-valid:review our config.action))  [%| %review-owner-config-required]
    ?:  =(`config.action config.s)  [%& [s ~]]
    ?:  (busy s)  [%| %review-outcome-unresolved]
    ?.  (gth generation.config.action generation.s)  [%| %review-generation-reused]
    [%& [s(config `config.action, generation generation.config.action) ~]]
  ?:  ?=(%native-coding-review-disable-v1 -.action)
    ?.  =(our src)  [%| %owner-required]
    ?:  (busy s)  [%| %review-outcome-unresolved]
    [%& [s(config ~) ~]]
  ?:  ?=(?(%native-coding-review-observe-v1 %native-coding-review-cancel-v1) -.action)
    =/  found  (~(get by jobs.s) id.action)
    ?~  found  [%| %review-request-missing]
    =/  j=job  u.found
    ?.  ?&  =(src parent.config.j)  =(binding.action (digest:review config.j))
            =(generation.action generation.config.j)  =(request.action (digest:review request.j))
        ==  [%| %review-correlation-mismatch]
    ?.  ?=(?(%pending %unknown) phase.j)  [%& [s ~[(notice j)]]]
    =/  cancel=?  ?=(%native-coding-review-cancel-v1 -.action)
    =/  op=command:inference  ?:(cancel [%native-coding-cancel id.action] [%native-coding-observe id.action])
    [%& (put s j(cancelled |(cancel cancelled.j)) ~[(local our id.action op)])]
  ?~  config.s  [%| %review-unconfigured]
  =/  c=config:review  u.config.s
  ?.  &(=(src parent.c) =(binding.action (digest:review c)) =(generation.action generation.c))
    [%| %review-parent-binding-mismatch]
  ?:  ?=(%native-coding-review-inspect-v1 -.action)
    =/  observed=*
      [%native-coding-review-inspection-v1 binding.action generation.action nonce.action (ready our at) (busy s) (label:review our model.selection.c)]
    [%& [s ~[[%pass /native-review/inspection/(scot %ux nonce.action) %agent [src %viki] %poke %noun !>(observed)]]]]
  ?:  ?=(%native-coding-review-join-v1 -.action)
    (join our s c workspace.action)
  ?>  ?=(%native-coding-review-request-v1 -.action)
  =/  r=request:review  request.action
  =/  found  (~(get by jobs.s) id.r)
  ?^  found
    ?.  &(=(c config.u.found) =(r request.u.found))  [%| %review-request-reused]
    [%& [s ~[(notice u.found)]]]
  ?:  (busy s)  [%| %review-inference-busy]
  ?:  (gte ~(wyt by jobs.s) 32)  [%| %review-history-full]
  =/  prepared  (inference:review our c r)
  ?:  ?=(%| -.prepared)  [%| p.prepared]
  =/  j=job  [c r p.prepared %pending %.n %awaiting-provider ~ 0x0]
  ?.  (ready our at)
    [%& (put s j(phase %refused, reason %review-controller-unavailable) ~)]
  [%& (put s j ~[(local our id.r [%native-coding-infer provider-key.c p.prepared])])]
++  join
  ::  The parent cannot assert a moon member. This moon accepts its own real
  ::  invitation, once per exact invitation snapshot; parent observes Boxy.
  |=  [our=@p s=state c=config:review w=workspace-state:bx]
  ^-  (each transition @tas)
  ?.  &((event-chain-valid:boxy w) ?=(^ events.w) =(event-seq.w (lent events.w)))
    [%| %review-workspace-invalid]
  =/  invited  (~(get by invitations.w) our)
  ?~  invited  [%| %review-invitation-missing]
  ?.  &(=(parent.c invited-by.u.invited) (~(has in capabilities.u.invited) %publish))
    [%| %review-invitation-invalid]
  =/  key=@ux  (digest:review [c w])
  ?:  (~(has in joins.s) key)  [%& [s ~]]
  ?:  (gte ~(wyt in joins.s) 64)  [%| %review-invitation-capacity]
  =/  command=command:bx  [%accept ~]
  =/  envelope=command-envelope:bx
    [id.w membership-epoch.w law-digest.w ?~(head.w ~ ~[u.head.w]) (payload-digest-for:boxy command) (cat 3 'ai-review-join:' (scot %ux key)) command]
  [%& [s(joins (~(put in joins.s) key)) ~[[%pass /native-review/join/(scot %ux key) %agent [parent.c %boxy] %poke %boxy-action !>(`action:bx`[%command envelope])]]]]
++  receive
  |=  [our=@p src=@p s=state event=event:inference]
  ^-  transition
  ?.  =(our src)  [s ~]
  =/  found  (~(get by jobs.s) id.event)
  ?~  found  [s ~]
  =/  j=job  u.found
  =/  current  phase.j
  ?.  ?=(?(%pending %unknown) current)  [s ~]
  ?.  |(=(session.event session.config.j) &(=(0 session.event) ?=(%missing -.outcome.event)))  [s ~]
  ?:  ?=(%pending -.outcome.event)  [s ~]
  ?:  ?=(?(%missing %conflict %unknown) -.outcome.event)
    (put s j(phase %unknown, reason %review-provider-outcome-unknown) ~)
  ?:  ?=(%cancelled -.outcome.event)
    (put s j(phase %cancelled, reason %review-provider-cancelled) ~)
  ?:  ?=(%failed -.outcome.event)
    (put s j(phase %refused, reason reason.error.outcome.event, receipt raw-digest.error.outcome.event) ~)
  ?:  ?=(%refused -.outcome.event)
    (put s j(phase %refused, reason reason.outcome.event) ~)
  ?>  ?=(%result -.outcome.event)
  =/  reply=reply:np  value.outcome.event
  =.  receipt.j  raw-digest.reply
  ?:  cancelled.j  (put s j(phase %refused, reason %review-publication-revoked) ~)
  =/  decoded  (decode:review config.j request.j reply)
  ?:  ?=(%| -.decoded)  (put s j(phase %refused, reason p.decoded) ~)
  =/  envelope=command-envelope:bx  (envelope:review request.j p.decoded)
  =.  j  j(phase %submitted, reason %awaiting-canonical-boxy, contribution `p.decoded)
  (put s j ~[[%pass /native-review/publish/(scot %ux id.event) %agent [parent.config.j %boxy] %poke %boxy-action !>(`action:bx`[%command envelope])]])
++  rejected
  |=  [s=state id=@ux operation=@tas]
  ^-  transition
  =/  found  (~(get by jobs.s) id)
  ?~  found  [s ~]
  =/  j=job  u.found
  ?:  =(%publish operation)
    ?.  =(%submitted phase.j)  [s ~]
    (put s j(reason %review-boxy-delivery-refused) ~)
  =/  current  phase.j
  ?.  ?=(?(%pending %unknown) current)  [s ~]
  ?:  =(%native-coding-infer operation)
    (put s j(phase %refused, reason %review-local-dispatch-refused) ~)
  (put s j(phase %unknown, reason %review-local-observation-refused) ~)
++  reload
  |=  [our=@p s=state]
  ^-  transition
  =/  cards=(list card:agent:gall)  ~
  =/  jobs=(list [@ux job])  ~(tap by jobs.s)
  |-  ^-  transition
  ?~  jobs  [s cards]
  =/  j=job  +.i.jobs
  ?.  ?=(?(%pending %unknown) phase.j)  $(jobs t.jobs)
  =.  j  j(phase %unknown, reason %review-reloaded-observing)
  $(jobs t.jobs, s s(jobs (~(put by jobs.s) id.request.j j)), cards (weld cards ~[(notice j) (local our id.request.j [%native-coding-observe id.request.j])]))
++  status
  |=  s=state
  ^-  *
  [%native-coding-reviewer-status-v1 ?~(config.s ~ `(digest:review u.config.s)) generation.s (busy s) ~(wyt by jobs.s)]
--
