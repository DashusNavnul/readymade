::  Viki wrapper: commit native marker, read immutable Cantrip admission,
::  retain one native draw/selection. No ordinary execution or retry card.
/+  c=qpc-native-controller, read=qpc-native-controller-read,
    admit=qpc-native-admission, a=qpc-native-assessment,
    d=qpc-native-decision, owner=qpc-native-owner,
    sessions=native-coding-session, observer=qpc-observer,
    note=qpc-native-controller-note, loop=native-coding-loop
|%
++  wrap
  |=  [inner=agent:gall fetch=reader:read receipt=receipts:read]
  =/  held=state:c  empty:c
  ^-  agent:gall
  |_  =bowl:gall
  +*  this  .
      ag  ~(. inner bowl)
      refuse
        |=  [id=@ux reason=@tas]
        ^-  (quip card:agent:gall _this)
        =.  held  (unavailable:c held id reason)
        [~[[%give %fact ~[/native-coding] %noun !>([%qpc-controller-unavailable-v1 id reason])]] this]
      append
        ::  Prepare inner privately and require the exact native journal
        ::  transition. Failure returns the old inner and emits no cards.
        |=  [v=view:read reason=?(%qpc-admission-requested %qpc-selection-attempted)]
        ^-  (each [cards=(list card:agent:gall) after=agent:gall event=record:sessions] @tas)
        =/  e=entry:sessions  entry.input.v
        ?~  head.e  [%| %qpc-controller-journal-empty]
        =/  wanted  (append:sessions e now.bowl [%status %paused reason])
        ?:  ?=(%| -.wanted)  [%| p.wanted]
        =/  command=command:note
          [%qpc-native-note-v1 id.session.e u.head.e working.session.e reason]
        =/  prepared  (on-poke:~(. inner bowl(src our.bowl)) %noun !>(command))
        =/  after=agent:gall  +.prepared
        =/  actual  (input:observer after bowl id.session.e)
        ?~  actual  [%| %qpc-controller-journal-unavailable]
        ?.  =(entry.p.wanted entry.u.actual)  [%| %qpc-controller-journal-not-appended]
        ::  The note gate emits only the native change fact and Graf retain.
        ::  Do not accidentally commit a tool, model or other app card here.
        =/  event=record:sessions  (rear records.entry.u.actual)
        =/  expected=(list card:agent:gall)
          ~[(changed:loop id.session.e sequence.entry.u.actual) (poke:loop our.bowl %graf /native-coding/retain [%attest [%native-coding-session-record-v1 id.session.e event]])]
        ?.  =(expected -.prepared)
          [%| %qpc-controller-unexpected-note-card]
        [%& [-.prepared after event]]
  ++  on-init
    =^  cards  inner  on-init:ag
    [cards this]
  ++  on-save  !>([%qpc-controller-owner-v1 held on-save:ag])
  ++  on-load
    |=  old=vase
    =/  saved=[held=state:c inner=vase]
      ?.  ?=([%qpc-controller-owner-v1 *] q.old)  [empty:c old]
      =/  prior  !<([%qpc-controller-owner-v1 held=state:c inner=vase] old)
      +.prior
    ?>  (valid:c held.saved)
    =.  held  (recover:c held.saved)
    =^  cards  inner  (on-load:ag inner.saved)
    [cards this]
  ++  on-poke
    |=  [=mark =vase]
    ?:  &(=(%noun mark) ?=([%qpc-controller-start-v1 @] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  id=@ux  +.q.vase
      ?:  |((~(has by records.held) id) (~(has by unavailable.held) id))  [~ this]
      ?.  (lth ~(wyt by records.held) 64)  (refuse id %qpc-controller-capacity)
      =/  got  (fetch inner bowl id)
      ?:  ?=(%| -.got)  (refuse id p.got)
      =/  v=view:read  p.got
      ?~  collection.origin.v  (refuse id %qpc-controller-pool-missing)
      ?.  =(head.entry.input.v `through.pool.u.collection.origin.v)
        (refuse id %qpc-controller-session-changed)
      =/  appended  (append v %qpc-admission-requested)
      ?:  ?=(%| -.appended)  (refuse id p.appended)
      =/  marker=marker:admit
        [%qpc-admission-request-v1 id.decision.origin.v id event.p.appended]
      =/  begun  (begin:c origin.v marker)
      ?:  ?=(%| -.begun)  (refuse id p.begun)
      =.  held  held(records (~(put by records.held) id p.begun))
      =.  inner  after.p.appended
      =/  requested=(list card:agent:gall)
        ~[[%pass /qpc/admission/(scot %ux id.event.marker) %agent [our.bowl %cantrip] %poke %noun !>([%qpc-admit-v1 id.event.marker])]]
      [(weld cards.p.appended requested) this]
    ?:  &(=(%noun mark) ?=([?(%qpc-controller-observe-v1 %qpc-admission-ready-v1) @] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  incoming=@ux  +.q.vase
      =/  target=(unit @ux)
        ?:  ?=(%qpc-controller-observe-v1 -.q.vase)  `incoming
        =/  matches=(list record:c)
          (skim ~(val by records.held) |=(r=record:c =(incoming id.event.marker.r)))
        ?.(=(1 (lent matches)) ~ `session.marker:(snag 0 matches))
      ?~  target  [~ this]
      =/  id=@ux  u.target
      =/  found  (~(get by records.held) id)
      ?~  found  (refuse id %qpc-controller-request-missing)
      =/  r=record:c  u.found
      ?.  =(%waiting phase.r)  [~ this]
      =/  got  (fetch inner bowl id)
      ?:  ?=(%| -.got)  (refuse id p.got)
      =/  v=view:read  p.got
      ?.  &(=(origin.r origin.v) =(head.entry.input.v `id.event.marker.r))
        (refuse id %qpc-controller-session-changed)
      =/  admitted  (receipt bowl id.event.marker.r)
      ?:  ?=(%| -.admitted)  (refuse id p.admitted)
      ?.  =(assessment.p.admitted (digest:a assessment.v))
        (refuse id %qpc-controller-assessment-changed)
      =/  appended  (append v %qpc-selection-attempted)
      ?:  ?=(%| -.appended)  (refuse id p.appended)
      =/  attempt=attempt:c  [event.p.appended (end [6 1] eny.bowl)]
      =/  selected  (select:c r p.admitted attempt current.v)
      ?:  ?=(%| -.selected)  (refuse id p.selected)
      =.  held  held(records (~(put by records.held) id p.selected))
      =.  inner  after.p.appended
      =/  notice=(list card:agent:gall)
        ~[[%give %fact ~[/native-coding] %noun !>([%qpc-selection-retained-v1 id phase.p.selected])]]
      [(weld cards.p.appended notice) this]
    =^  cards  inner  (on-poke:ag mark vase)
    [cards this]
  ++  on-peek
    |=  =path
    ?:  =(/x/qpc/controller path)
      ?.  =(our.bowl src.bowl)  ~
      ``noun+!>(held)
    ?:  ?=([%x %qpc %admission-request @ ~] path)
      ?.  =(our.bowl src.bowl)  ~
      =/  id  (slaw %ux i.t.t.t.path)
      ?~  id  [~ ~]
      =/  found=(list record:c)
        (skim ~(val by records.held) |=(r=record:c =(u.id id.event.marker.r)))
      =/  result=(unit marker:admit)  ?~(found ~ `marker.i.found)
      ``noun+!>(result)
    (on-peek:ag path)
  ++  on-watch
    |=  =path
    =^  cards  inner  (on-watch:ag path)
    [cards this]
  ++  on-leave
    |=  =path
    =^  cards  inner  (on-leave:ag path)
    [cards this]
  ++  on-agent
    |=  [=wire =sign:agent:gall]
    =^  cards  inner  (on-agent:ag wire sign)
    [cards this]
  ++  on-arvo
    |=  [=wire =sign-arvo]
    =^  cards  inner  (on-arvo:ag wire sign-arvo)
    [cards this]
  ++  on-fail
    |=  [=term =tang]
    =^  cards  inner  (on-fail:ag term tang)
    [cards this]
  --
++  agent  |=(inner=agent:gall (wrap inner read:read receipt:read))
--
