::  Self-only Cantrip ledger observation protocol. A snapshot is neither a
::  permission token nor a file-write acknowledgment. Old agents refuse its
::  watch before clients send an apply command; no speculative scry needed.
/+  land=cantrip-vibecoding-local-land
|%
+$  snapshot
  [%cantrip-local-land-state-v1 owner=@p at=@da judgment=@ux record=(unit record:land)]
++  path-for
  |=  key=@ux
  ^-  path
  /vibecoding/local-land/(scot %ux key)
++  key-for
  |=  at=path
  ^-  (unit @ux)
  ?.  ?=([%vibecoding %local-land @ ~] at)  ~
  =/  key=(unit @ux)  (slaw %ux i.t.t.at)
  ?~  key  ~
  ?.  &(!=(0 u.key) (lte (met 0 u.key) 256) =((path-for u.key) at))  ~
  key
++  valid
  |=  [our=@p key=@ux now=@da value=snapshot]
  ^-  ?
  ?.  &(=(our owner.value) =(key judgment.value) !=(0 key) (lte (met 0 key) 256) (lte at.value now))
    %.n
  =/  held  record.value
  ?~  held  %.y
  ?&  (record-valid:land u.held)  =(our actor.admission.u.held)
      =(key digest.judgment.admission.u.held)
      (lte at.admission.u.held at.value)
      ?~(observation.u.held %.y (lte at.u.observation.u.held at.value))
  ==
++  card-for
  |=  [our=@p now=@da key=@ux held=(unit record:land)]
  ^-  card:agent:gall
  =/  value=snapshot  [%cantrip-local-land-state-v1 our now key held]
  ?>  (valid our key now value)
  [%give %fact ~[(path-for key)] %noun !>(value)]
--
