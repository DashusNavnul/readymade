::  Transient observation transport. No source writes, authority or retries.
/-  view=cantrip-project-view
/+  runtime=cantrip-project-access-runtime
|%
+$  selector  [owner=@p query=query:view]
+$  command  [owner=@p project=@t generation=@ud]
+$  phase  ?(%pending %ready %refused %uncertain)
+$  entry
  $:  key=selector  deadline=@da  retained=@da  phase=phase
      reason=@tas  response=(unit response:view)
  ==
+$  journal  (map selector entry)
+$  change  [journal=journal cards=(list card:agent:gall)]
+$  start  [journal=journal cards=(list card:agent:gall) result=(each entry @tas)]
++  valid-key
  |=  k=selector
  ^-  ?
  &((lte (met 0 owner.k) 128) (request-valid:runtime (view-request:runtime query.k)))
++  wire-for
  |=  [k=selector deadline=@da]
  ^-  wire
  /collab/project-view/(scot %p owner.k)/(scot %ux project.query.k)/(scot %ud generation.query.k)/(scot %ux nonce.query.k)/(scot %da deadline)
++  parse-wire
  |=  wir=wire
  ^-  (unit [key=selector deadline=@da])
  ?.  &(?=([%collab %project-view @ @ @ @ @ ~] wir) (lte (met 3 (jam wir)) 4.096))  ~
  =/  owner  (slaw %p i.t.t.wir)
  =/  project  (slaw %ux i.t.t.t.wir)
  =/  generation  (slaw %ud i.t.t.t.t.wir)
  =/  nonce  (slaw %ux i.t.t.t.t.t.wir)
  =/  deadline  (slaw %da i.t.t.t.t.t.t.wir)
  ?~  owner  ~
  ?~  project  ~
  ?~  generation  ~
  ?~  nonce  ~
  ?~  deadline  ~
  =/  k=selector  [u.owner [`@t`u.project u.generation u.nonce]]
  ?.  ?&  (valid-key k)  (gth u.deadline 0)  (lte (met 0 u.deadline) 128)
          =(wir (wire-for k u.deadline))
      ==  ~
  `[k u.deadline]
++  cleanup
  |=  [k=selector deadline=@da]
  ^-  (list card:agent:gall)
  =/  wir=wire  (wire-for k deadline)
  :~  [%pass wir %agent [owner.k %cantrip] %leave ~]
      [%pass wir %arvo %b %rest deadline]
  ==
++  reload-cleanup
  ::  Gall preserves outgoing watches in bowl.wex, not in our saved DATA.
  ::  Only exact owned wire + authenticated dock + source route are admitted.
  |=  outgoing=boat:gall
  ^-  (list card:agent:gall)
  %-  zing
  %+  turn  ~(tap by outgoing)
  |=  item=[[wir=wire ship=@p app=@tas] [acked=? pax=path]]
  =/  parsed  (parse-wire wir.item)
  ?~  parsed  ~
  ?.  &(=(%cantrip app.item) =(ship.item owner.key.u.parsed))  ~
  ::  The route's peer is supplied separately by reload for exact binding.
  (cleanup key.u.parsed deadline.u.parsed)
++  reload
  |=  [our=@p outgoing=boat:gall]
  ^-  (list card:agent:gall)
  =/  owned=boat:gall
    %-  malt
    %+  skim  ~(tap by outgoing)
    |=  item=[[wir=wire ship=@p app=@tas] [acked=? pax=path]]
    =/  parsed  (parse-wire wir.item)
    ?~  parsed  %.n
    =(pax.item (view-route:runtime our query.key.u.parsed))
  (reload-cleanup owned)
++  prune
  ::  Never evict an active watch, including one awaiting a delayed wake.
  |=  [now=@da held=journal]
  ^-  journal
  %-  malt
  %+  skim  ~(tap by held)
  |=  item=[key=selector value=entry]
  |(=(%pending phase.value.item) (lth now retained.value.item))
++  begin
  |=  [our=@p now=@da k=selector held=journal]
  ^-  start
  =.  held  (prune now held)
  ?.  &((valid-key k) !=(our owner.k) (gth now 0))
    [held ~ [%| %view-selector-invalid]]
  ?:  (~(has by held) k)  [held ~ [%| %view-request-reused]]
  =/  active=@ud
    (lent (skim ~(val by held) |=(e=entry =(%pending phase.e))))
  ?:  |((gte active 8) (gte ~(wyt by held) 32))
    [held ~ [%| %view-capacity]]
  =/  deadline=@da  (add now ~s30)
  =/  e=entry  [k deadline (add deadline ~m5) %pending %awaiting-owner ~]
  =/  wir=wire  (wire-for k deadline)
  :*  (~(put by held) k e)
      :~  [%pass wir %arvo %b %wait deadline]
          [%pass wir %agent [owner.k %cantrip] %watch (view-route:runtime our query.k)]
      ==
      [%& e]
  ==
++  finish
  |=  [held=journal e=entry phase=phase reason=@tas response=(unit response:view)]
  ^-  change
  [(~(put by held) key.e e(phase phase, reason reason, response response)) (cleanup key.e deadline.e)]
++  receive
  |=  [our=@p src=@p now=@da held=journal wir=wire sign=sign:agent:gall]
  ^-  change
  =/  parsed  (parse-wire wir)
  ?~  parsed  [held ~]
  ?.  =(src owner.key.u.parsed)  [held ~]
  =/  found  (~(get by held) key.u.parsed)
  ?~  found  [held (cleanup key.u.parsed deadline.u.parsed)]
  =/  e=entry  u.found
  ?.  =(deadline.e deadline.u.parsed)
    [held (cleanup key.u.parsed deadline.u.parsed)]
  ?.  =(%pending phase.e)  [held ~]
  ?:  (gte now deadline.e)  (finish held e %uncertain %view-timeout ~)
  ?-  -.sign
    %watch-ack
      ?~  p.sign  [held ~]
      (finish held e %refused %watch-refused ~)
    %poke-ack  (finish held e %uncertain %unexpected-poke-ack ~)
    %kick  (finish held e %uncertain %closed-without-view ~)
    %fact
      ?.  &(=(%noun p.cage.sign) (lte (met 3 (jam q.q.cage.sign)) 131.072))
        (finish held e %uncertain %invalid-view ~)
      =/  event  ((soft ,event:view) q.q.cage.sign)
      ?~  event  (finish held e %uncertain %invalid-view ~)
      =/  r=response:view  response.u.event
      ?.  ?&  (view-valid:runtime r)  =(owner.key.e owner.r)
              =(our peer.r)  =(query.key.e query.r)
          ==  (finish held e %uncertain %view-mismatch ~)
      (finish held e %ready %observed `r)
  ==
++  wake
  |=  [now=@da held=journal wir=wire]
  ^-  change
  =/  parsed  (parse-wire wir)
  ?~  parsed  [held ~]
  =/  found  (~(get by held) key.u.parsed)
  ?~  found  [held (cleanup key.u.parsed deadline.u.parsed)]
  =/  e=entry  u.found
  ?.  ?&  =(deadline.e deadline.u.parsed)  =(%pending phase.e)
          (gte now deadline.e)
      ==  [held ~]
  (finish held e %uncertain %view-timeout ~)
++  result
  ::  Observation only. A delayed timer cannot make an overdue read pending.
  |=  [now=@da k=selector held=journal]
  ^-  (unit entry)
  =/  found  (~(get by held) k)
  ?~  found  ~
  ?:  (gte now retained.u.found)  ~
  ?:  &(=(%pending phase.u.found) (gte now deadline.u.found))
    `u.found(phase %uncertain, reason %view-timeout)
  found
--
