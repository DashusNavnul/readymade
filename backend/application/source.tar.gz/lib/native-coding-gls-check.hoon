::  Explicit trusted-executable candidate checks, separate from unchecked
::  compiler receipts. The owner policy chooses to trust this exact executable
::  for this project/target/profile; it does NOT certify source equivalence.
::  This pure law cannot establish policy or result origin. Cantrip must read
::  current authorization and retain only authenticated candidate-thread output.
/-  nc=native-coding
/+  accept=native-coding-accept, ct=cantrip-native-coding,
    compiler=native-coding-compiler, attachment=native-coding-compiler-attachment,
    exports=native-coding-compiler-exports, modules=native-coding-module-sources,
    decoder=native-coding-compiler-artifact, vm=native-coding-terminal-plan,
    tools=native-coding-tools, project=native-coding-project,
    files=native-coding-files, guard=viki-scry-guard
|%
+$  trust
  [%native-coding-gls-toolchain-trust-v1 selection=selection:exports attachment=@ux profile=@ux acknowledgment=%trust-executable-for-candidate-checks]
+$  input
  [%native-coding-gls-check-input-v1 trust=trust candidate=candidate:nc staging=tree:nc scope=scope:ct compiler=attachment:attachment job=job:compiler staged-selection=selection:exports maximum=@ud mapping=(unit manifest:modules)]
+$  check
  [name=@tas expression=@t outcome=(each [value=* packed=@ux] [reason=@tas detail=@t])]
+$  receipt
  [%native-coding-gls-check-receipt-v1 input=input output=result:attachment checks=(list check)]
++  input-limit  8.388.608
++  byte-limit  16.777.216
++  digest
  |=  value=*
  ^-  @ux
  (shax (jam [%native-coding-gls-check-v1 value]))
++  trust-valid
  |=  [our=@p t=trust a=attachment:attachment]
  ^-  ?
  ?&  (selection-valid:exports selection.t)
      =(our authority.spec.project.selection.t)
      =(acknowledgment.t %trust-executable-for-candidate-checks)
      =(profile.t profile-id-v2:attachment)
      =(attachment.t digest.a)  (valid:attachment a)
  ==
++  staged-project
  |=  [t=trust stage=tree:nc]
  ^-  project:nc
  project.selection.t(working desk.revision.stage)
++  job-for
  ::  An INTERNAL compiler input, not a new model request or admitted tool job.
  ::  Its synthetic context is derived wholly from the candidate and confirmed
  ::  staging namespace. Original module roots retain their exact meaning.
  |=  [t=trust c=candidate:nc stage=tree:nc mapping=(unit manifest:modules) sources=(list source:compiler)]
  ^-  (each job:compiler @tas)
  =/  p=project:nc  (staged-project t stage)
  =/  target=build-target:nc  target.selection.t
  =/  context=context:nc
    context.c(configuration (configuration:project p), source revision.stage, request (digest [id.c target revision.stage t]))
  =/  r=tool-request:nc
    [%native-coding-tool-request-v1 context 'candidate-check' [%check name.target]]
  ?~  mapping
    [%& [%native-coding-compiler-job-v1 r p target (module-name:compiler entry.target) sources]]
  ?.  (valid:modules project.selection.t u.mapping)
    [%| %gls-check-module-mapping-invalid]
  ?.  =(target target.u.mapping)  [%| %gls-check-module-target-mismatch]
  =/  mapped=manifest:modules  u.mapping(configuration (configuration:project p))
  =/  paths  (dependencies:compiler p target)
  ?:  ?=(%| -.paths)  [%| p.paths]
  =/  prepared  (prepare:modules p mapped context p.paths sources)
  ?:  ?=(%| -.prepared)  [%| p.prepared]
  [%& [%native-coding-compiler-job-v2 r p target module.p.prepared sources mapped]]
++  input-valid
  |=  i=input
  ^-  ?
  ?.  (lte (met 3 (jam i)) input-limit)  %.n
  =/  p=project:nc  project.selection.trust.i
  =/  c=candidate:nc  candidate.i
  =/  g=grant:ct  grant.scope.i
  =/  target=build-target:nc  target.selection.trust.i
  ?.  ?&  (trust-valid authority.spec.p trust.i compiler.i)
          (candidate-valid:files p c)  (tree-valid:project p staging.i)
          =(owner.source.context.c owner.revision.staging.i)
          =((staging-desk:accept id.c) desk.revision.staging.i)
          =(2 number.revision.staging.i)
          =((after-map:files c) files.body.snapshot.staging.i)
          (grant-valid:ct authority.spec.p g)  ?=(~ revoked.scope.i)
          =(p project.g)  =(session.context.c session.g)
          =(actor.context.c actor.g)
          (~(has in operations.g) %compile)  (~(has in operations.g) %check)
          (lien (required:accept p c) |=(v=build-target:nc =(target v)))
          =(maximum.i (max 1 (div max-eval-work.g (max 1 (lent (required:accept p c))))))
          =(staged-selection.i selection.trust.i(project (staged-project trust.i staging.i)))
      ==  %.n
  =/  srcs=(list source:compiler)  (job-sources:compiler job.i)
  =/  rebuilt  (job-for trust.i c staging.i mapping.i srcs)
  ?.  &(?=(%& -.rebuilt) =(p.rebuilt job.i))  %.n
  =/  ready  (inputs:attachment compiler.i job.i staged-selection.i)
  ?.  ?=(%& -.ready)  %.n
  %+  levy  srcs
  |=  s=source:compiler
  =(`blob.s (~(get by files.body.snapshot.staging.i) pax.s))
++  prepare
  ::  Candidate admission/membership and current policy are checked by the
  ::  caller. Independently reread Clay; never use the unchanged working desk.
  |=  [our=@p now=@da r=record:accept t=trust a=attachment:attachment scope=scope:ct maximum=@ud]
  ^-  (each input @tas)
  ?.  &((trust-valid our t a) ?=(?(%checking %review) stage.r) =(project.r project.selection.t) =(grant.r id.grant.scope) ?=(^ staging.r))  [%| %gls-check-admission-mismatch]
  =/  read  (staged:accept our now r)
  ?:  ?=(%| -.read)  [%| p.read]
  ?.  =(`p.read staging.r)  [%| %gls-check-staging-changed]
  =/  stage=tree:nc  p.read
  =/  reader=project:nc  (staged-project t stage)
  =/  target=build-target:nc  target.selection.t
  =/  paths  (dependencies:compiler reader target)
  ?:  ?=(%| -.paths)  [%| p.paths]
  ?.  (agent-live:guard our now %cantrip)  [%| %gls-check-mapping-unavailable]
  =/  configuration=@ux  (configuration:project project.r)
  =/  raw=*
    .^(* %gx /(scot %p our)/cantrip/(scot %da now)/native-coding/compiler-mapping/(scot %ux configuration)/(scot %tas name.target)/noun)
  =/  parsed  ((soft (unit (each manifest:modules @tas))) raw)
  ?~  parsed  [%| %gls-check-mapping-shape]
  ?.  =(u.parsed raw)  [%| %gls-check-mapping-shape]
  =/  held=(unit (each manifest:modules @tas))  u.parsed
  =/  resolved=(each (unit manifest:modules) @tas)
    ?~  held  [%& ~]
    ?:  ?=(%| -.u.held)  [%| p.u.held]
    [%& `p.u.held]
  ?:  ?=(%| -.resolved)  [%| p.resolved]
  =/  mapping=(unit manifest:modules)  p.resolved
  =/  todo=(list path)  p.paths
  =/  sources=(list source:compiler)  ~
  =/  size=@ud  0
  |-  ^-  (each input @tas)
  ?~  todo
    =/  job  (job-for t candidate.r stage mapping (flop sources))
    ?:  ?=(%| -.job)  [%| p.job]
    =/  input=input
      [%native-coding-gls-check-input-v1 t candidate.r stage scope a p.job selection.t(project reader) maximum mapping]
    ?:((input-valid input) [%& input] [%| %gls-check-input-invalid])
  =/  rest=(list path)  t.todo
  =/  content  (file:files reader stage i.todo)
  ?:  ?=(%| -.content)  [%| p.content]
  ?.  =(%gls mark.p.content)  [%| %gls-check-source-mark]
  =/  length=@ud  (met 3 source.p.content)
  ?.  (input-size-valid:modules reader size length)  [%| %gls-check-source-bound]
  =/  blob=@ux  (~(got by files.body.snapshot.stage) i.todo)
  $(todo rest, size (add size length), sources [[i.todo blob source.p.content] sources])
++  check-context
  ::  Owner Hoon expressions see real selected PLAN exports and a bounded
  ::  pure runner. No scry/effect handler or executable noun cast is provided.
  |=  bindings=(list binding:decoder)
  ^-  vase
  !>
    |%
    ++  exports  bindings
    ++  run
      |=  [name=@t args=(list plan:vm) fuel=@ud]
      ^-  result:vm
      =/  found=(list binding:decoder)
        (skim bindings |=(b=binding:decoder =(name name.b)))
      ?~  found  [%| %gls-check-export-missing]
      ?^  t.found  [%| %gls-check-export-missing]
      (run:vm fuel artifact.i.found args)
    --
++  run
  ::  Caller wraps the WHOLE gate in maximum microseconds of ~jinx. Per-check
  ::  bounds below are additional, not extra target allocations. No execution
  ::  occurs in validation or reload; only this gate invokes the compiler.
  |=  i=input
  ^-  receipt
  ?>  (input-valid i)
  =/  output=result:attachment
    (invoke-v2:attachment compiler.i job.i staged-selection.i fuel-v2:attachment)
  =/  checks=(list check)  ~
  =/  configured=(list [name=@tas expression=@t])  checks:(job-target:compiler job.i)
  =/  maximum=@ud  (max 1 (div maximum.i (max 1 (lent configured))))
  =/  subject=(unit vase)
    ?:  ?=(%| -.output)  ~
    `(check-context bindings.p.output)
  |-  ^-  receipt
  ?~  configured  [%native-coding-gls-check-receipt-v1 i output (flop checks)]
  =/  rest=(list [name=@tas expression=@t])  t.configured
  =/  result=(each [value=* packed=@ux] [reason=@tas detail=@t])
    ?~  subject  [%| %gls-compiler-refused 'Check not run because the selected trusted compiler returned no artifact.']
    (evaluate-detail:tools u.subject expression.i.configured maximum)
  $(configured rest, checks [[name.i.configured expression.i.configured result] checks])
++  receipt-valid
  ::  Structural/history joins only; authenticated native callback supplies
  ::  execution provenance. Validation does not authorize importing assertions.
  |=  r=receipt
  ^-  ?
  ?.  &((lte (met 3 (jam r)) byte-limit) (input-valid input.r) (output-for:attachment profile.trust.input.r role.compiler.input.r names.staged-selection.input.r fuel-v2:attachment output.r) =(checks:(job-target:compiler job.input.r) (turn checks.r |=(c=check [name.c expression.c]))))  %.n
  %+  levy  checks.r
  |=  c=check
  ?:  ?=(%| -.outcome.c)
    &(!=(0 reason.p.outcome.c) (lte (met 3 reason.p.outcome.c) 128) (lte (met 3 detail.p.outcome.c) 8.192))
  &(?=(%& -.output.r) =(packed.p.outcome.c (jam value.p.outcome.c)) (lte (met 3 packed.p.outcome.c) 8.192))
++  target-result
  |=  r=receipt
  ^-  target-result:accept
  ?>  (receipt-valid r)
  =/  source=revision:nc  revision.staging.input.r
  =/  evidence=(list @ux)  ~[(digest r) attachment.trust.input.r profile.trust.input.r]
  =/  compilation=diagnostic:nc
    [%compile ?=(%& -.output.r) ?:(?=(%| -.output.r) (cat 3 'Explicitly trusted compiler refused: ' reason.p.output.r) 'The explicitly trusted compiler executed on the exact staged source closure and returned validated PLAN exports. This records executable trust, not source-equivalence certification.') source evidence]
  =/  checks=(list diagnostic:nc)
    %+  turn  checks.r
    |=  c=check
    ^-  diagnostic:nc
    ?:  ?=(%| -.outcome.c)
      [name.c %.n detail.p.outcome.c source evidence]
    [name.c =(0 value.p.outcome.c) (cat 3 'Expected Hoon true (0); actual result digest: ' (scot %ux (shax packed.p.outcome.c))) source (weld evidence ~[(shax packed.p.outcome.c)])]
  [(job-target:compiler job.input.r) [compilation checks]]
--
