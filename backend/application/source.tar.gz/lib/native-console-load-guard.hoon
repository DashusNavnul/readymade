::  Pure console reload checks. The app owns decoding and editor validation.
::  The normalized save is captured directly after its existing v1/v2/v3
::  decode, before setup cards or transient connection changes are computed.
/+  editor=native-coding-terminal-state
|%
+$  snapshot  [%native-console-v3 legacy=* coding=* editor=*]
++  idle
  |=  [legacy=(map @ta *) coding=(map @ta *)]
  ^-  ?
  &(=(~ legacy) =(~ coding))
++  setup
  |=  our=@p
  ^-  (list card:agent:gall)
  :~  [%pass /bind %arvo %e %connect [~ /apps/pataphor-native] %pataphor-native-console]
      [%pass /viki %agent [our %viki] %leave ~]
      [%pass /viki %agent [our %viki] %watch /development/pataphor]
      [%pass /coding-viki %agent [our %viki] %leave ~]
      [%pass /coding-viki %agent [our %viki] %watch /native-coding]
  ==
++  check
  |=  [old=vase normalized=vase new=vase cards=(list card:agent:gall) our=@p]
  ^-  (each @tas @tas)
  ?.  =(cards (setup our))  [%| %console-reload-cards]
  =/  parsed  ((soft ,snapshot) q.normalized)
  ?~  parsed  [%| %console-reload-save-invalid]
  ?.  =(u.parsed q.normalized)  [%| %console-reload-save-invalid]
  =/  s=snapshot  u.parsed
  ?.  =(q.normalized q.new)  [%| %console-reload-data-changed]
  ?.  &((~(nest ut p.normalized) | p.new) (~(nest ut p.new) | p.normalized))
    [%| %console-reload-type-changed]
  ?@  q.old  [%| %console-reload-version]
  ?:  =(%native-console-v1 -.q.old)
    ?.  =(q.old legacy.s)  [%| %console-reload-legacy-changed]
    =/  coding  ((soft ,[token=@uv waiting=* delivery=@t]) coding.s)
    ?~  coding  [%| %console-reload-coding-default]
    ?.  &(=(u.coding coding.s) !=(0 token.u.coding) =(~ waiting.u.coding) =('' delivery.u.coding))
      [%| %console-reload-coding-default]
    ?.  =(empty:editor editor.s)  [%| %console-reload-editor-default]
    [%& %console-reload-checked]
  ?:  =(%native-console-v2 -.q.old)
    ?.  =(q.old [%native-console-v2 legacy.s coding.s])
      [%| %console-reload-legacy-changed]
    ?.  =(empty:editor editor.s)  [%| %console-reload-editor-default]
    [%& %console-reload-checked]
  ?.  =(%native-console-v3 -.q.old)  [%| %console-reload-version]
  ?.  =(q.old q.normalized)  [%| %console-reload-data-changed]
  ?.  &((~(nest ut p.old) | p.new) (~(nest ut p.new) | p.old))
    [%| %console-reload-type-changed]
  [%& %console-reload-checked]
--
