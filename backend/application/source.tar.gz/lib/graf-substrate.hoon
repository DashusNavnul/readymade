::  /lib/graf-substrate.hoon
::
::  Graf bedrock: the immutable, append-only FACT store -- the memory floor the
::  whole fleet writes into.
::
::  A fact is any noun, and the fact IS its own axis: the point and the fact are
::  the same noun (identity, no encoding). "The axis point itself is the
::  information." A fact's own bits are its path in the trie; the point existing
::  means the fact is lit. The store is the SET of lit points, which makes the
::  three bedrock invariants true by construction:
::    - content-addressed: the fact is literally its address (point-of = identity).
::    - idempotent:        lighting a fact twice is a no-op (set insert).
::    - append-only:       points only ever accrete; nothing moves or unlights.
::  The `set` is the finite/sparse realization of the conceptually infinite axis
::  space -- only lit points exist.
::
::  SEARCH (next phase) reads these lit facts as an Aho-Corasick trie: because a
::  fact's bits are its path, an AC automaton matches any number of query
::  patterns against the whole store in ONE simultaneous pass -- "fire all
::  combinations at once", adding patterns is free. That is graf's connective
::  power: cross-fact "how does this relate" is a single parallel match, not a
::  hand-coded join.
::
/-  graf=graf
|%
+$  fact   *                    ::  any noun
+$  point  fact                 ::  the axis IS the fact (identity)
+$  store  (set point)          ::  the lit points; grow-only
+$  graf-fact  graf-fact:graf
::
++  point-of                    ::  the fact is its own address
  |=  =fact
  ^-  point
  fact
::
++  fact-of                     ::  and the address is its own fact (identity, no decode)
  |=  =point
  ^-  fact
  point
::
++  light                       ::  assert a fact -- append-only + idempotent
  |=  [s=store =fact]
  ^-  store
  (~(put in s) `point`fact)
::
++  lit                         ::  is this fact present?
  |=  [s=store =fact]
  ^-  ?
  (~(has in s) `point`fact)
::
++  count  |=(s=store `@ud`~(wyt in s))
::
++  facts                       ::  enumerate every lit fact
  |=  s=store
  ^-  (list fact)
  ~(tap in s)
::
::  Family-tagged facts are the canonical durable form for Graf's legacy
::  record families.  The tag participates in the point identity; caches may
::  forget a value, but the substrate never does.
::
++  make-graf-fact
  |=  [family=graf-fact-family:graf value=*]
  ^-  graf-fact
  [%graf-fact-v1 family value]
::
++  graf-fact-digest
  |=  item=graf-fact
  ^-  @ux
  `@ux`(shax (jam item))
::
++  light-graf-fact
  |=  [s=store family=graf-fact-family:graf value=*]
  ^-  store
  (light s (make-graf-fact family value))
::
++  graf-fact-lit
  |=  [s=store family=graf-fact-family:graf value=*]
  ^-  ?
  (lit s (make-graf-fact family value))
::
++  graf-fact-of
  |=  =point
  ^-  (unit graf-fact)
  ((soft graf-fact) (fact-of point))
::
::  Pure migration/proof predicate.  Runtime query paths must use derived
::  bounded indexes rather than walking the whole store.
::
++  contains-all
  |=  [earlier=store later=store]
  ^-  ?
  %+  levy  (facts earlier)
  |=(item=fact (lit later item))
--
