::  /lib/graf-axis-layout.hoon
::
::  Graf's ASCII-addressed fragment law.  Large source chunks are split into
::  word and rune fragments.  A fragment's semantic coordinate is its cord
::  atom (little-endian ASCII), while its physical Nock path walks one
::  fixed-width byte branch per character below Hand's owner axis.
::
::  A byte b occupies relative axis 256+b.  Those 256 axes all have the same
::  eight-bit depth, so no byte is another byte's ancestor.  Axis 256 is also
::  the end-of-text marker; NUL is therefore rejected inside text.  This lets
::  `add` and `adder` share their a/d/d path without either fact overwriting the
::  other.  There are no ordinal slots and corpus growth never renumbers text.
::
|%
+$  fragment-kind  ?(%word %rune)
+$  token  [kind=fragment-kind text=@t]
+$  memory-address
  $:  text=@t
      ascii-atom=@ud
      ascii-axes=(list @ud)
      relative-axis=@ud
      absolute-axis=@ud
  ==
+$  fragment-occurrence
  $:  source=@t
      ordinal=@ud
      previous=(unit @ud)
      next=(unit @ud)
  ==
+$  fragment-node
  $:  kind=fragment-kind
      text=@t
      address=memory-address
      occurrences=(list fragment-occurrence)
  ==
+$  fragment-index  (map @ud fragment-node)
+$  memory-layout
  $:  owner-axis=@ud
      byte-axis-base=@ud
      terminator-axis=@ud
      fragment-kinds=(list fragment-kind)
  ==
::
++  memory-owner-axis  43
++  byte-axis-base  256
++  terminator-axis  256
::
++  layout-summary
  ^-  memory-layout
  [memory-owner-axis byte-axis-base terminator-axis ~[%word %rune]]
::
++  byte-axis
  |=  byte=@ud
  ^-  @ud
  ?>  (lth byte 256)
  (add byte-axis-base byte)
::
++  extend-axis-under-root
  |=  [base-axis=@ud relative-axis=@ud]
  ^-  @ud
  ?>  (gth base-axis 0)
  ?>  (gth relative-axis 0)
  (peg base-axis relative-axis)
::
++  valid-text
  |=  text=@t
  ^-  ?
  =/  bytes=(list @)  (rip 3 text)
  ?&  !=(~ bytes)
      (levy bytes |=(byte=@ &((gth byte 0) (lth byte 256))))
  ==
::
::  Walk the ASCII bytes in reading order, then append the terminal branch.
++  text-relative-axis
  |=  text=@t
  ^-  (unit @ud)
  ?.  (valid-text text)  ~
  =/  bytes=(list @)  (rip 3 text)
  =/  walked=@ud  1
  |-
  ?~  bytes  `(peg walked terminator-axis)
  $(bytes t.bytes, walked (peg walked (byte-axis i.bytes)))
::
++  address-for-text
  |=  text=@t
  ^-  (unit memory-address)
  =/  relative=(unit @ud)  (text-relative-axis text)
  ?~  relative  ~
  `[text `@ud`text (rip 3 text) u.relative (peg memory-owner-axis u.relative)]
::
++  lower-byte
  |=  byte=@
  ^-  @
  ?:  &((gte byte 'A') (lte byte 'Z'))
    (add byte 32)
  byte
::
++  word-byte
  |=  byte=@
  ^-  ?
  ?|  &((gte byte 'a') (lte byte 'z'))
      &((gte byte 'A') (lte byte 'Z'))
      &((gte byte '0') (lte byte '9'))
      =(byte '-')
      =(byte '_')
      =(byte 39)
  ==
::
++  whitespace-byte
  |=  byte=@
  ^-  ?
  ?|(=(byte 32) =(byte 9) =(byte 10) =(byte 13))
::
++  emit-token
  |=  [kind=fragment-kind reversed=(list @) out=(list token)]
  ^-  (list token)
  ?~  reversed  out
  [[kind (crip (flop reversed))] out]
::
::  Preserve source order.  Words are lowercased; contiguous non-whitespace
::  glyphs become rune fragments, so Hoon forms such as |=, =/, ++ and @t stay
::  walkable instead of disappearing during tokenization.
++  tokenize
  |=  raw=@t
  ^-  (list token)
  =/  bytes=(list @)  (rip 3 raw)
  =|  reversed=(list @)
  =/  mode=fragment-kind  %word
  =|  active=?
  =|  out=(list token)
  |-
  ?~  bytes
    (flop ?:(active (emit-token mode reversed out) out))
  =/  byte=@  i.bytes
  ?:  (whitespace-byte byte)
    %=  $
      bytes     t.bytes
      reversed  ~
      active    %.n
      out       ?:(active (emit-token mode reversed out) out)
    ==
  =/  next-mode=fragment-kind  ?:((word-byte byte) %word %rune)
  =/  kept=@  ?:(?=(%word next-mode) (lower-byte byte) byte)
  ?:  |(!active =(mode next-mode))
    $(bytes t.bytes, reversed [kept reversed], mode next-mode, active %.y)
  %=  $
    bytes     t.bytes
    reversed  ~[kept]
    mode      next-mode
    active    %.y
    out       (emit-token mode reversed out)
  ==
::
++  addressed-tokens
  |=  raw=@t
  ^-  (list [kind=fragment-kind address=memory-address])
  %+  murn  (tokenize raw)
  |=  item=token
  =/  address=(unit memory-address)  (address-for-text text.item)
  ?~  address  ~
  `[kind.item u.address]
::
::  Add one chunk to an index.  Repeated fragments converge on one ASCII node;
::  each occurrence retains source, order, and its previous/next fragment axes.
++  index-text
  |=  [index=fragment-index source=@t raw=@t]
  ^-  fragment-index
  =/  items=(list [kind=fragment-kind address=memory-address])
    (addressed-tokens raw)
  =|  previous=(unit @ud)
  =|  ordinal=@ud
  |-
  ?~  items  index
  =/  axis=@ud  absolute-axis.address.i.items
  =/  next=(unit @ud)
    ?~(t.items ~ `absolute-axis.address.i.t.items)
  =/  occurrence=fragment-occurrence
    [source ordinal previous next]
  =/  old=(unit fragment-node)  (~(get by index) axis)
  =/  node=fragment-node
    ?~  old
      [kind.i.items text.address.i.items address.i.items ~[occurrence]]
    u.old(occurrences [occurrence occurrences.u.old])
  %=  $
    items     t.items
    previous  `axis
    ordinal   +(ordinal)
    index     (~(put by index) axis node)
  ==
::
++  index-corpus
  |=  chunks=(list [source=@t text=@t])
  ^-  fragment-index
  =|  index=fragment-index
  |-
  ?~  chunks  index
  $(chunks t.chunks, index (index-text index source.i.chunks text.i.chunks))
::
++  in-subtree
  |=  [root=@ud axis=@ud]
  ^-  ?
  ?:  =(0 root)  %.n
  ?:  =(0 axis)  %.n
  |-
  ?:  =(root axis)  %.y
  ?:  (lte axis 1)  %.n
  ?:  (lth axis root)  %.n
  $(axis (div axis 2))
::
++  overlaps
  |=  [left=@ud right=@ud]
  ^-  ?
  |((in-subtree left right) (in-subtree right left))
::
++  valid-layout
  ^-  ?
  ?&  =(43 memory-owner-axis)
      =(256 byte-axis-base)
      =(256 terminator-axis)
      =(256 (byte-axis 0))
      =(353 (byte-axis 97))
      =(511 (byte-axis 255))
  ==
--
