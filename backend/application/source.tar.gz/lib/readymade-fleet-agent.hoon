::  Stateless owner-only publisher. Inner saves and effects pass through intact.
/-  nf=native-coding-fleet
/+  f=readymade-fleet, review=readymade-native-review
|%
+$  source  [fleet=organ:nf placements=placements:f]
+$  unavailable  [%readymade-fleet-unavailable-v1 reason=?(%native-unavailable %incoherent)]
+$  observation
  $%  snapshot:f
      unavailable
  ==
+$  pages  (map path observation)
++  route
  |=  pax=path
  ^-  (unit @ud)
  ?.  ?=([%readymade %fleet @ ~] pax)  ~
  =/  text=@t  i.t.t.pax
  ?.  (lte (met 3 text) 8)  ~
  =/  start=(unit @ud)  (slaw %ud text)
  ?~  start  ~
  ?.  &(=(text (scot %ud u.start)) (lte u.start 256))  ~
  start
++  fleet-path
  |=  pax=path
  ^-  ?
  ?=([%readymade %fleet *] pax)
++  paths
  |=  b=bowl:gall
  ^-  (list path)
  =/  wanted=(list path)
    %+  murn  ~(val by sup.b)
    |=  [who=@p pax=path]
    ^-  (unit path)
    ?.  =(who our.b)  ~
    ?~  (route pax)  ~
    `pax
  ~(tap in (silt wanted))
++  read
  |=  [inner=agent:gall b=bowl:gall]
  ^-  (unit source)
  ::  Callback senders may be foreign; observation uses the owner's read scope.
  ::  Catch pure inner reads, never execute cards or cast an executable noun.
  =/  got=(each (unit source) tang)
    %-  mule
    |.
    =/  ag  ~(. inner b(src our.b))
    =/  fleet=(unit (unit cage))  (on-peek:ag /x/native-coding/fleet)
    ?~  fleet  ~
    ?~  u.fleet  ~
    ?.  =(%noun p.u.u.fleet)  ~
    =/  decoded=(unit organ:nf)  ((soft organ:nf) q.q.u.u.fleet)
    ?~  decoded  ~
    =/  placements=(unit (unit cage))  (on-peek:ag /x/native-coding/fleet/placements)
    ?~  placements  ~
    ?~  u.placements  ~
    ?.  =(%noun p.u.u.placements)  ~
    =/  ps=(unit placements:f)  ((soft placements:f) q.q.u.u.placements)
    ?~  ps  ~
    `[u.decoded u.ps]
  ?:(?=(%& -.got) p.got ~)
++  project
  |=  [our=@p state=(unit source) start=@ud]
  ^-  observation
  ?~  state  [%readymade-fleet-unavailable-v1 %native-unavailable]
  =/  got=(each snapshot:f tang)
    (mule |.((project:f our fleet.u.state placements.u.state start)))
  ?:(?=(%& -.got) p.got [%readymade-fleet-unavailable-v1 %incoherent])
++  facts
  |=  [b=bowl:gall before=(unit source) after=(unit source) reseed=?]
  ^-  (list card:agent:gall)
  %+  murn  (paths b)
  |=  pax=path
  ^-  (unit card:agent:gall)
  =/  start=(unit @ud)  (route pax)
  ?~  start  ~
  =/  next=observation  (project our.b after u.start)
  ?:  &(!reseed =(next (project our.b before u.start)))  ~
  `[%give %fact ~[pax] %noun !>(next)]
++  session-for
  |=  [inner=agent:gall b=bowl:gall id=@ux]
  ^-  (unit public-session:f)
  =/  got=(each (unit public-session:f) tang)
    %-  mule
    |.
    =/  ag  ~(. inner b(src our.b))
    =/  value=(unit (unit cage))
      (on-peek:ag /x/native-coding/session/[(scot %ux id)])
    ?~  value  ~
    ?~  u.value  ~
    ?.  =(%noun p.u.u.value)  ~
    =/  parsed=(unit (unit public-session:f))
      ((soft ,(unit public-session:f)) q.q.u.u.value)
    ?~  parsed  ~
    u.parsed
  ?:(?=(%& -.got) p.got ~)
++  page
  |=  [inner=agent:gall b=bowl:gall state=(unit source) start=@ud]
  ^-  observation
  =/  base=observation  (project our.b state start)
  ?.  ?=(%readymade-fleet-v2 -.base)  base
  ?>  ?=(^ state)
  =/  sessions=(map @ux (unit public-session:f))
    =/  ids=(set @ux)  (silt (turn rows.base |=(r=row:f session.r)))
    %-  malt
    (turn ~(tap in ids) |=(id=@ux [id (session-for inner b id)]))
  =/  got=(each snapshot:f tang)
    (mule |.((enrich:f our.b fleet.u.state base sessions)))
  ?:(?=(%& -.got) p.got [%readymade-fleet-unavailable-v1 %incoherent])
++  capture
  |=  [inner=agent:gall b=bowl:gall]
  ^-  pages
  =/  wanted=(list path)  (paths b)
  ::  No observers means no native reads or projection work.
  ?~  wanted  ~
  =/  state=(unit source)  (read inner b)
  ?~  state
    (malt (turn `(list path)`wanted |=(pax=path [pax [%readymade-fleet-unavailable-v1 %native-unavailable]])))
  =/  ready=(each prepared:f tang)
    (mule |.((prepare:f our.b fleet.u.state placements.u.state)))
  ?.  ?=(%& -.ready)
    (malt (turn `(list path)`wanted |=(pax=path [pax [%readymade-fleet-unavailable-v1 %incoherent]])))
  =/  bases=pages
    %-  malt
    %+  turn  `(list path)`wanted
    |=  pax=path
    =/  got=(each snapshot:f tang)
      (mule |.((project-prepared:f p.ready (need (route pax)))))
    [pax ?:(?=(%& -.got) p.got [%readymade-fleet-unavailable-v1 %incoherent])]
  =/  sessions=(map @ux (unit public-session:f))
    %-  malt
    (turn (session-ids bases) |=(id=@ux [id (session-for inner b id)]))
  %-  malt
  %+  turn  ~(tap by bases)
  |=  [pax=path base=observation]
  ?.  ?=(%readymade-fleet-v2 -.base)  [pax base]
  =/  got=(each snapshot:f tang)
    (mule |.((enrich:f our.b fleet.u.state base sessions)))
  [pax ?:(?=(%& -.got) p.got [%readymade-fleet-unavailable-v1 %incoherent])]
++  session-ids
  |=  values=pages
  ^-  (list @ux)
  =/  ids=(set @ux)  ~
  =/  remaining=(list observation)  ~(val by values)
  |-  ^-  (list @ux)
  ?~  remaining  ~(tap in ids)
  =/  value=observation  i.remaining
  ?.  ?=(%readymade-fleet-v2 -.value)  $(remaining t.remaining)
  $(remaining t.remaining, ids (~(gas in ids) (turn rows.value |=(r=row:f session.r))))
++  updates
  |=  [before=pages after=pages reseed=?]
  ^-  (list card:agent:gall)
  %+  murn  ~(tap by after)
  |=  [pax=path value=observation]
  ^-  (unit card:agent:gall)
  ?:  &(!reseed =(`value (~(get by before) pax)))  ~
  `[%give %fact ~[pax] %noun !>(value)]
++  agent
  |=  inner=agent:gall
  ^-  agent:gall
  %-  agent:review
  |_  =bowl:gall
  +*  this  .
      ag  ~(. inner bowl)
  ++  on-init
    =^  cards  inner  on-init:ag
    [(weld cards (updates ~ (capture inner bowl) %.y)) this]
  ++  on-save  on-save:ag
  ++  on-load
    |=  old=vase
    =^  cards  inner  (on-load:ag old)
    [(weld cards (updates ~ (capture inner bowl) %.y)) this]
  ++  on-poke
    |=  [=mark =vase]
    =/  before=pages  (capture inner bowl)
    =^  cards  inner  (on-poke:ag mark vase)
    [(weld cards (updates before (capture inner bowl) %.n)) this]
  ++  on-watch
    |=  =path
    ?:  (fleet-path path)
      ?>  =(src.bowl our.bowl)
      =/  start=(unit @ud)  (route path)
      ?>  ?=(^ start)
      ?>  (lte (lent ~(tap in (silt [path (paths bowl)]))) 32)
      [~[[%give %fact ~[path] %noun !>((page inner bowl (read inner bowl) u.start))]] this]
    =/  before=pages  (capture inner bowl)
    =^  cards  inner  (on-watch:ag path)
    [(weld cards (updates before (capture inner bowl) %.n)) this]
  ++  on-leave
    |=  =path
    ?:  (fleet-path path)  [~ this]
    =/  before=pages  (capture inner bowl)
    =^  cards  inner  (on-leave:ag path)
    [(weld cards (updates before (capture inner bowl) %.n)) this]
  ++  on-peek
    |=  =path
    ?:  ?=([%x %readymade %fleet *] path)
      ?.  =(src.bowl our.bowl)  ~
      =/  start=(unit @ud)  (route t.path)
      ?~(start ~ ``noun+!>((page inner bowl (read inner bowl) u.start)))
    (on-peek:ag path)
  ++  on-agent
    |=  [=wire =sign:agent:gall]
    =/  before=pages  (capture inner bowl)
    =^  cards  inner  (on-agent:ag wire sign)
    [(weld cards (updates before (capture inner bowl) %.n)) this]
  ++  on-arvo
    |=  [=wire sign=sign-arvo]
    =/  before=pages  (capture inner bowl)
    =^  cards  inner  (on-arvo:ag wire sign)
    [(weld cards (updates before (capture inner bowl) %.n)) this]
  ++  on-fail
    |=  [=term =tang]
    =/  before=pages  (capture inner bowl)
    =^  cards  inner  (on-fail:ag term tang)
    [(weld cards (updates before (capture inner bowl) %.n)) this]
  --
--
