::  Prospective native ordering. Only the instrument owner calls these gates.
::  Old enrollment maps are never sorted into a fabricated event history.
/+  admission=qpc-measurement-admission, obs=qpc-observation,
    window=qpc-window
|%
+$  interruption  [evidence=@ux reason=@tas]
+$  item-body  $%([%work enrollment=@ux] [%gap interruption])
+$  item  [stream=@ux body=item-body]
+$  state
  $:  queue=(list item)  cursor=@ud  canceled=(map @ux interruption)
      windows=(map @ux state:window)  fault=(unit @tas)
  ==
++  open
  |=  [s=state b=binding:window]
  ^-  state
  ?>  &(!(~(has by windows.s) stream.b) (lth ~(wyt by windows.s) 64))
  =/  begun  (start:window b)
  ?>  ?=(%& -.begun)
  s(windows (~(put by windows.s) stream.b p.begun))
++  enqueue
  |=  [s=state value=item]
  ^-  state
  ::  Preserved v1 plans have no ordered history and remain outside windows.
  ?.  (~(has by windows.s) stream.value)  s
  ?>  &(?=(~ fault.s) (lth (lent queue.s) 512))
  s(queue (weld queue.s ~[value]))
++  reserve
  |=  [s=state r=enrollment:admission]
  ^-  state
  =/  found  (~(get by windows.s) stream.position.r)
  ?~  found  s
  =/  b=binding:window  binding.u.found
  ?>  &((enrollment-valid:admission r) =(instrument.b instrument.position.r) =(manifest.b manifest.contract.r))
  ?>  !(lien queue.s |=(x=item &(?=(%work -.body.x) =(id.r enrollment.body.x))))
  (enqueue s [stream.position.r [%work id.r]])
++  interrupt
  |=  [s=state stream=@ux value=interruption]
  ^-  state
  ?>  (interruption-valid value)
  (enqueue s [stream [%gap value]])
++  cancel
  ::  Only an undispatched ticket can call this; dispatched work must settle.
  |=  [s=state id=@ux value=interruption]
  ^-  state
  ?>  (interruption-valid value)
  =/  pending=(list item)  (slag cursor.s queue.s)
  ?.  (lien pending |=(x=item &(?=(%work -.body.x) =(id enrollment.body.x))))  s
  =/  prior  (~(get by canceled.s) id)
  ?^  prior
    ?>  =(value u.prior)
    s
  s(canceled (~(put by canceled.s) id value))
++  interruption-valid
  |=  value=interruption
  &((gth evidence.value 0) (lte (met 0 evidence.value) 256) !=(%$ reason.value))
++  body
  ::  No sender-supplied row: use the owner's retained admission and frame.
  |=  [s=state x=item admitted=state:admission observed=state:obs]
  ^-  (unit body:window)
  ?:  ?=(%gap -.body.x)  `[%gap +.body.x]
  =/  canceled  (~(get by canceled.s) enrollment.body.x)
  ?^  canceled  `[%gap u.canceled]
  =/  enrolled  (~(get by enrollments.admitted) enrollment.body.x)
  ?~  enrolled  ~
  =/  r=enrollment:admission  u.enrolled
  =/  frames=(list frame:obs)
    (skim ~(val by frames.observed) |=(f=frame:obs =(work.r work.f)))
  ?.  =(1 (lent frames))  ~
  =/  f=frame:obs  (snag 0 frames)
  ?:  ?=(%outside -.result.f)  `[%outside id.f]
  ?:  ?=(%| -.result.f)  `[%gap id.f p.result.f]
  ?.  =(1 (lent p.result.f))  `[%gap id.f %instrument-alternatives-refused]
  =/  sample  (~(get by samples.admitted) id.f)
  ?~  sample  ~
  =/  v=sample:admission  u.sample
  ?.  &(=(r enrollment.v) =(f frame.v) =(id.v (digest:admission v(id 0x0))))  ~
  =/  point=point:window
    [row.v (digest:admission source.work.r) id.settlement.v (digest:admission task.r) case-set.work.r]
  `[%row point]
++  advance
  |=  [s=state admitted=state:admission observed=state:obs limit=@ud]
  ^-  state
  |-  ^-  state
  ?:  |(?=(^ fault.s) (gte cursor.s limit) =(cursor.s (lent queue.s)))  s
  =/  x=item  (snag cursor.s queue.s)
  =/  ready  (body s x admitted observed)
  ?~  ready  s
  =/  held=state:window  (~(got by windows.s) stream.x)
  ::  Later provenance remains in the queue/stores; frozen membership is final.
  ?^  measured.held  $(s s(cursor +(cursor.s)))
  =/  next  (append:window held [next.held u.ready])
  ?:  ?=(%| -.next)  s(fault `p.next)
  $(s s(cursor +(cursor.s), windows (~(put by windows.s) stream.x p.next)))
++  valid
  |=  [s=state admitted=state:admission observed=state:obs]
  ^-  ?
  ?.  &((lte (lent queue.s) 512) (lte cursor.s (lent queue.s)) (lte ~(wyt by windows.s) 64))  %.n
  =/  works=(list @ux)
    (murn queue.s |=(x=item ?:(?=(%work -.body.x) `enrollment.body.x ~)))
  ?.  =((lent works) ~(wyt in (silt works)))  %.n
  ?.  (levy ~(tap by canceled.s) |=([id=@ux value=interruption] &((~(has in (silt works)) id) (interruption-valid value))))  %.n
  ?.  %+  levy  ~(tap by windows.s)
      |=  [id=@ux value=state:window]
      =/  begun  (start:window binding.value)
      &(=(id stream.binding.value) ?=(%& -.begun))
    %.n
  ?.  %+  levy  queue.s
      |=  x=item
      =/  win  (~(get by windows.s) stream.x)
      ?~  win  %.n
      ?:  ?=(%gap -.body.x)  (interruption-valid +.body.x)
      =/  enrolled  (~(get by enrollments.admitted) enrollment.body.x)
      ?~  enrolled  %.n
      =/  r=enrollment:admission  u.enrolled
      &((enrollment-valid:admission r) =(stream.x stream.position.r) =(instrument.binding.u.win instrument.position.r) =(manifest.binding.u.win manifest.contract.r))
    %.n
  =/  empty=(map @ux state:window)
    %-  malt
    %+  turn  ~(tap by windows.s)
    |=  [id=@ux value=state:window]
    =/  begun  (start:window binding.value)
    ?>  ?=(%& -.begun)
    [id p.begun]
  =/  replayed=state  (advance s(cursor 0, windows empty, fault ~) admitted observed cursor.s)
  ?.  &(=(cursor.s cursor.replayed) =(windows.s windows.replayed) ?=(~ fault.replayed))  %.n
  ?~  fault.s  %.y
  =/  failed=state  (advance replayed admitted observed +(cursor.s))
  =(s failed)
--
