::  Presentation adapter only. Owner authentication belongs to the native app.
/-  c=readymade-collab
/+  pact=readymade-pact
|%
++  status
  |=  [status=@t message=@t]
  ^-  json
  (pairs:enjs:format ~[['status' s+status] ['message' s+message]])
++  capability
  |=  [available=? reason=@t]
  ^-  json
  (pairs:enjs:format ~[['available' b+available] ['reason' s+reason]])
++  package-json
  |=  [our=@p id=@ux item=package:c]
  ^-  json
  =/  value  value.item
  =/  result=json
    ?~  result.value
      (pairs:enjs:format ~[['state' s+'not-run']])
    %-  pairs:enjs:format
    :~  ['state' s+?:(success.u.result.value 'built' 'failed')]
        ['receipt' s+(scot %ux proof.u.result.value)]
    ==
  %-  pairs:enjs:format
  :~  ['id' s+(scot %ux id)]
      ['title' s+title.item]
      ['summary' s+summary.item]
      ['reference' s+(scot %ux graf-root.body.offer.value)]
      ['digest' s+(scot %ux digest.offer.value)]
      ['direction' s+?:(=(our sender.body.offer.value) 'outgoing' 'incoming')]
      ['state' s+(scot %tas stage.value)]
      ['inspected' b+?=(^ inspection.value)]
      ['buildable' b+%.n]
      ['build' result]
  ==
++  pact-json
  |=  [our=@p item=agreement:c]
  ^-  json
  =/  value  value.item
  =/  hash=@t  (scot %ux (digest:pact terms.value))
  =/  sequence=@ud
    ?:(=(our left.terms.value) left-sequence.value right-sequence.value)
  =/  guard=@t
    (spat ~[(scot %ud generation.value) (scot %ud +(sequence))])
  =/  revoked=?
    &((gth generation.value 0) !left-consent.value !right-consent.value)
  =/  local=?
    ?:(=(our left.terms.value) left-consent.value right-consent.value)
  =/  remote=?
    ?:(=(our left.terms.value) right-consent.value left-consent.value)
  %-  pairs:enjs:format
  :~  ['id' s+hash]
      ['digest' s+hash]
      ['guard' s+guard]
      ['reference' s+reference.item]
      ['terms' s+text.item]
      ['state' s+?:(revoked 'revoked' ?:(&(local remote) 'active' 'proposed'))]
      ['localAccepted' b+local]
      ['peerAccepted' b+remote]
      ['revoked' b+revoked]
  ==
++  receipt-json
  |=  item=receipt:c
  ^-  json
  %-  pairs:enjs:format
  :~  ['id' s+id.item]
      ['request' s+id.item]
      ['op' s+op.item]
      ['state' s+(scot %tas state.item)]
      ['actor' s+(scot %p actor.item)]
      ['message' s+message.item]
  ==
++  snapshot
  |=  [our=@p peer=@p now=@da state=state:c]
  ^-  json
  =/  packages=(list [@ux package:c])
    %+  skim  ~(tap by packages.state)
    |=  row=[id=@ux item=package:c]
    =/  body  body.offer.value.item.row
    |(&(=(our sender.body) =(peer recipient.body)) &(=(peer sender.body) =(our recipient.body)))
  =/  pacts=(list [@ux agreement:c])
    %+  skim  ~(tap by pacts.state)
    |=  row=[id=@ux item=agreement:c]
    =/  terms  terms.value.item.row
    |(&(=(our left.terms) =(peer right.terms)) &(=(peer left.terms) =(our right.terms)))
  =/  caps=json
    %-  pairs:enjs:format
    :~  ['offer' (capability %.y 'Native owner validation required.')]
        ['propose' (capability %.y 'Both owners must accept identical terms.')]
        ['pact-accept' (capability %.y 'Native owner validation required.')]
        ['pact-revoke' (capability %.y 'Either owner may revoke.')]
        ['inspect' (capability %.n 'Native source readback is not connected.')]
        ['accept' (capability %.n 'Native source readback is not connected.')]
        ['decline' (capability %.n 'Native package decision adapter is not connected.')]
        ['build' (capability %.n 'Native local build runner is not connected.')]
    ==
  %-  pairs:enjs:format
  :~  ['schema' s+'readymade-collaboration-v1']
      ['owner' s+(scot %p our)]
      ['peer' s+(scot %p peer)]
      ['at' (numb:enjs:format ?:((lth now ~1970.1.1) 0 (div (sub now ~1970.1.1) ~s1)))]
      ['capabilities' caps]
      ['packages' a+(turn (scag 256 packages) |=([id=@ux item=package:c] (package-json our id item)))]
      ['pacts' a+(turn (scag 256 pacts) |=([id=@ux item=agreement:c] (pact-json our item)))]
      ['receipts' a+(turn (scag 256 receipts.state) receipt-json)]
  ==
++  text-field
  |=  [object=(map @t json) key=@t limit=@ud]
  ^-  @t
  =/  found=(unit json)  (~(get by object) key)
  ?~  found  ''
  ?>  ?=(%s -.u.found)
  =/  value=@t  p.u.found
  ?>  (lte (met 3 value) limit)
  value
++  decode
  |=  raw=@t
  ^-  command:c
  =/  parsed=json  (need (de:json:html raw))
  ?>  ?=(%o -.parsed)
  =/  object=(map @t json)  p.parsed
  ?>  %+  levy  ~(tap by object)
      |=  row=[key=@t value=json]
      (lien `(list @t)`~['op' 'owner' 'peer' 'request' 'title' 'reference' 'digest' 'summary' 'terms' 'id'] |=(key=@t =(key key.row)))
  =/  command=command:c
    :*  (text-field object 'op' 32)
        (text-field object 'owner' 128)
        (text-field object 'peer' 128)
        (text-field object 'request' 128)
        (text-field object 'title' 96)
        (text-field object 'reference' 512)
        (text-field object 'digest' 256)
        (text-field object 'summary' 2.000)
        (text-field object 'terms' 4.000)
        (text-field object 'id' 512)
    ==
  ?>  &(!=(0 op.command) !=(0 owner.command) !=(0 peer.command) !=(0 request.command))
  ?>  (lien `(list @t)`~['offer' 'propose' 'pact-accept' 'pact-revoke' 'inspect' 'accept' 'decline' 'build' 'artifact-import'] |=(op=@t =(op op.command)))
  command
++  parse
  |=  raw=@t
  ^-  (unit command:c)
  ?:  (gth (met 3 raw) 16.384)  ~
  (mole |.((decode raw)))
--
