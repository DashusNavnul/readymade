::  /lib/multiplayer-cockpit-review
::
::  Pure Steps 76-80 projection.  It revalidates the base cockpit, exposes
::  exact changeset rows, and binds every visible judgment button to one
::  content-addressed act.  Enabled remains display state, never authority.
::
/-  mc=multiplayer-changeset, mcr=multiplayer-cockpit-review,
    md=multiplayer-dispute, mpc=multiplayer-cockpit,
    mp=multiplayer-project
/+  mdl=multiplayer-dispute, mpcl=multiplayer-cockpit
|%
++  max-judgments  `@ud`64
++  max-diffs      `@ud`64
::
++  decision-act-digest
  |=  body=decision-act-body:mcr
  ^-  digest:mcr
  `@ux`(shax (jam [%multiplayer-cockpit-decision-act-v1 body]))
++  decision-act-for
  |=  $:  project=project-id:mp
          changeset=digest:mcr
          contradiction=digest:mcr
          contest=digest:mcr
          verdict=verdict:md
          actor=@p
      ==
  ^-  decision-act:mcr
  =/  body=decision-act-body:mcr
    [1 project changeset contradiction contest verdict actor]
  [body (decision-act-digest body)]
++  decision-act-valid
  |=  act=decision-act:mcr
  ^-  ?
  ?&  =(1 version.body.act)
      !=(0 project.body.act)
      !=(0 changeset.body.act)
      !=(0 contradiction.body.act)
      !=(0 contest.body.act)
      !=(0 actor.body.act)
      =((decision-act-digest body.act) digest.act)
  ==
::
++  can-judge
  |=  [source=project-source:mpc actor=@p]
  ^-  ?
  =/  member=(unit member:mp)  (~(get by members.project.source) actor)
  ?~  member  %.n
  ?|  =(%operator role.u.member)
      =(%maintainer role.u.member)
  ==
++  verdict-for-kind
  |=  kind=control-kind:mcr
  ^-  verdict:md
  ?-  kind
    %approve  %accept
    %refuse   %refuse
    %revise   %revise
    %split    %split
    %hold     %hold
  ==
::
++  judgment-valid
  |=  [source=project-source:mpc item=judgment-source:mcr]
  ^-  ?
  =/  contradiction=contradiction:md  contradiction.item
  =/  contest=contest:md  contest.item
  =/  project=project-id:mp  id.spec.project.source
  ?.  ?&  (contradiction-valid:mdl contradiction)
          (contest-valid:mdl contest)
          =(project project.body.contradiction)
          =(project project.body.contest)
          ?|  =(changeset.body.contest left.body.contradiction)
              =(changeset.body.contest right.body.contradiction)
          ==
          (~(has by changesets.source) changeset.body.contest)
      ==
    %.n
  ?~  ruling.item  %.y
  =/  ruling=ruling:md  u.ruling.item
  ?.  ?&  !=(0 law-digest.body.ruling)
          !=(0 ruled-at.body.ruling)
      ==
    %.n
  =/  expected=ruling:md
    (decide:mdl contradiction contest law-digest.body.ruling ruled-at.body.ruling)
  =(ruling expected)
++  duplicate-judgment
  |=  items=(list judgment-source:mcr)
  ^-  (unit digest:mcr)
  =/  seen=(set digest:mcr)  ~
  =/  rest=(list judgment-source:mcr)  items
  |-
  ?~  rest  ~
  =/  digest=digest:mcr  digest.contest.i.rest
  ?:  (~(has in seen) digest)  `digest
  $(rest t.rest, seen (~(put in seen) digest))
++  invalid-judgment
  |=  [source=project-source:mpc items=(list judgment-source:mcr)]
  ^-  (unit digest:mcr)
  ?~  items  ~
  ?.  (judgment-valid source i.items)  `digest.contest.i.items
  $(items t.items)
::
++  diff-row-for
  |=  item=change:mc
  ^-  diff-row:mcr
  [kind.item path.item before.item after.item]
++  why-link-for
  |=  $:  project=project-id:mp
          link=conversation-link:mpc
          changeset=changeset:mc
          change=change:mc
      ==
  ^-  why-link:mcr
  :*  'explain exact path through its verified conversation'
      [%why project digest.changeset path.change]
      actor.body.changeset
      messages.link
      receipt.link
  ==
++  inspection-for
  |=  [source=project-source:mpc link=conversation-link:mpc]
  ^-  changeset-inspection:mcr
  =/  stored=changeset-source:mpc
    (~(got by changesets.source) changeset.link)
  =/  changeset=changeset:mc  changeset.stored
  =/  project=project-id:mp  project.body.changeset
  =/  changes=(list change:mc)  changes.body.changeset
  :*  digest.changeset
      project
      task.body.changeset
      workspace.body.changeset
      actor.body.changeset
      base-revision.body.changeset
      snapshot-digest.body.changeset
      (turn changes diff-row-for)
      messages.link
      receipt.link
      (turn changes |=(change=change:mc (why-link-for project link changeset change)))
  ==
++  inspections-for
  |=  source=project-source:mpc
  ^-  (list changeset-inspection:mcr)
  (turn conversations.source |=(link=conversation-link:mpc (inspection-for source link)))
++  diff-overflow
  |=  inspections=(list changeset-inspection:mcr)
  ^-  (unit [digest:mcr @ud])
  ?~  inspections  ~
  =/  count=@ud  (lent diffs.i.inspections)
  ?:  (gth count max-diffs)  `[changeset.i.inspections count]
  $(inspections t.inspections)
::
++  control-for
  |=  $:  item=judgment-source:mcr
          actor=@p
          authorized=?
          kind=control-kind:mcr
      ==
  ^-  decision-control:mcr
  =/  contradiction=contradiction:md  contradiction.item
  =/  contest=contest:md  contest.item
  =/  verdict=verdict:md  (verdict-for-kind kind)
  =/  suggested=verdict:md  (derive-verdict:mdl contradiction contest)
  =/  act=decision-act:mcr
    %-  decision-act-for
    [project.body.contest changeset.body.contest digest.contradiction digest.contest verdict actor]
  ?~  ruling.item
    ?:  !authorized
      [kind act %disabled 'current member role cannot judge this project']
    ?:  =(verdict suggested)
      [kind act %enabled 'exact act matches the Cantrip-derived verdict']
    [kind act %disabled 'exact act differs from the Cantrip-derived verdict']
  =/  resolved=verdict:md  verdict.body.u.ruling.item
  ?:  =(verdict resolved)
    [kind act %resolved 'exact act is already recorded by the ruling']
  [kind act %disabled 'a different exact act is already recorded']
++  controls-for
  |=  [item=judgment-source:mcr actor=@p authorized=?]
  ^-  (list decision-control:mcr)
  :~  (control-for item actor authorized %approve)
      (control-for item actor authorized %refuse)
      (control-for item actor authorized %revise)
      (control-for item actor authorized %split)
      (control-for item actor authorized %hold)
  ==
++  judgment-row-for
  |=  [item=judgment-source:mcr actor=@p authorized=?]
  ^-  judgment-row:mcr
  =/  contradiction=contradiction:md  contradiction.item
  =/  contest=contest:md  contest.item
  :*  project.body.contest
      changeset.body.contest
      digest.contradiction
      digest.contest
      (derive-verdict:mdl contradiction contest)
      (controls-for item actor authorized)
      ruling.item
  ==
::
++  review
  |=  input=input:mcr
  ^-  result:mcr
  =/  projected=result:mpc  (project:mpcl base.input)
  ?-  -.projected
    %|  [%| [%cockpit-refused p.projected]]
    %&
      =/  cockpit=snapshot:mpc  p.projected
      ?~  active.base.input  [%| [%active-required ~]]
      =/  project=project-id:mp  u.active.base.input
      =/  source=(unit project-source:mpc)
        (source-at:mpcl projects.base.input project)
      ?~  source  [%| [%active-source-missing project]]
      ?:  (gth (lent judgments.input) max-judgments)
        [%| [%judgment-overflow (lent judgments.input)]]
      =/  duplicate=(unit digest:mcr)  (duplicate-judgment judgments.input)
      ?^  duplicate  [%| [%duplicate-judgment u.duplicate]]
      =/  invalid=(unit digest:mcr)
        (invalid-judgment u.source judgments.input)
      ?^  invalid  [%| [%invalid-judgment u.invalid]]
      =/  inspections=(list changeset-inspection:mcr)
        (inspections-for u.source)
      =/  overflow=(unit [digest:mcr @ud])  (diff-overflow inspections)
      ?^  overflow  [%| [%diff-overflow -.u.overflow +.u.overflow]]
      =/  actor=@p  actor.base.input
      =/  authorized=?  (can-judge u.source actor)
      =/  rows=(list judgment-row:mcr)
        (turn judgments.input |=(item=judgment-source:mcr (judgment-row-for item actor authorized)))
      =/  requires=(list judgment-row:mcr)
        ?:  authorized
          (skim rows |=(row=judgment-row:mcr ?=(~ ruling.row)))
        ~
      =/  resolved=(list judgment-row:mcr)
        (skim rows |=(row=judgment-row:mcr ?=(^ ruling.row)))
      =/  why=(list why-link:mcr)
        (zing (turn inspections |=(item=changeset-inspection:mcr why.item)))
      [%& [%multiplayer-cockpit-review-v1 cockpit inspections requires resolved why %.n]]
  ==
--
