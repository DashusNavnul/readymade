::  /lib/code-medium.hoon
::
::  THE CODE MEDIUM (Tier 1 #2) -- an entity that THINKS IN CODE, not
::  conversation. deepfates' Elixir/Code medium, done Urbit-native, and here the
::  ward stops being computed and becomes the THEOREM:
::
::    The subject is built from ONLY the granted capability arms. Source the
::    model emits is compiled against that subject. Source that references an
::    ungranted arm DOES NOT COMPILE -- it is unreachable at the Hoon level, not
::    refused by a runtime check. What is not in the subject cannot be named.
::
::  This is the %nock/%nick medium's safety property in miniature, realized with
::  scrivener (the compiler-as-oracle) as the judge. A green compile yields a
::  vase (the computed result); a red compile yields a rendered tang -- the
::  repair signal, or the proof that the capability was out of reach.
::
/+  scrivener
|%
+$  outcome  (each vase @t)                    ::  green vase | rendered tang (unreachable/error)
::  run source against a subject built from the granted capabilities.
++  run
  |=  [subject=vase src=@t]
  ^-  outcome
  (check:scrivener subject src)
++  reached  |=(o=outcome =(%& -.o))           ::  did the code compile+run (capability in reach)?
--
