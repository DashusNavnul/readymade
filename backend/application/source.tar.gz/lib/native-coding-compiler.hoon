::  Optional native self-host compiler attachment. There is intentionally no
::  default artifact. Install executable code only through an owner command.
::  Emission is NOT verified compilation: parser/resolver gaps remain visible,
::  and no outcome from this adapter can become positive Cantrip check evidence.
/-  nc=native-coding
/+  project=native-coding-project, files=native-coding-files,
    vm=native-coding-terminal-plan, scalar=terminal-plan,
    modules=native-coding-module-sources, guard=viki-scry-guard
|%
+$  witness  [module=@t digest=@ux bytes=@t]
+$  bundle
  $%  [%native-coding-compiler-bundle-v1 compiler-source=@ux bridge-source=@ux digest=@ux entry=plan:vm]
      ::  Common digest stays at v1's axis: third field after the version tag.
      [%native-coding-compiler-bundle-v2 source-digest=@ux sources=(list witness) digest=@ux entry=(unit plan:vm)]
  ==
+$  bundle-v1  $>(%native-coding-compiler-bundle-v1 bundle)
+$  bundle-v2  $>(%native-coding-compiler-bundle-v2 bundle)
+$  source  [pax=path blob=@ux text=@t]
+$  job
  $%  [%native-coding-compiler-job-v1 request=tool-request:nc project=project:nc target=build-target:nc module=@t sources=(list source)]
      [%native-coding-compiler-job-v2 request=tool-request:nc project=project:nc target=build-target:nc module=@t sources=(list source) mapping=manifest:modules]
  ==
+$  job-v1  $>(%native-coding-compiler-job-v1 job)
+$  job-v2  $>(%native-coding-compiler-job-v2 job)
++  job-request
  |=  j=job
  ^-  tool-request:nc
  ?-  -.j
    %native-coding-compiler-job-v1  request.j
    %native-coding-compiler-job-v2  request.j
  ==
++  job-project
  |=  j=job
  ^-  project:nc
  ?-  -.j
    %native-coding-compiler-job-v1  project.j
    %native-coding-compiler-job-v2  project.j
  ==
++  job-target
  |=  j=job
  ^-  build-target:nc
  ?-  -.j
    %native-coding-compiler-job-v1  target.j
    %native-coding-compiler-job-v2  target.j
  ==
++  job-module
  |=  j=job
  ^-  @t
  ?-  -.j
    %native-coding-compiler-job-v1  module.j
    %native-coding-compiler-job-v2  module.j
  ==
++  job-sources
  |=  j=job
  ^-  (list source)
  ?-  -.j
    %native-coding-compiler-job-v1  sources.j
    %native-coding-compiler-job-v2  sources.j
  ==
+$  emission  [size=@ud bytes=@t digest=@ux]
+$  outcome
  $:  %native-coding-compiler-outcome-v1
      job=@ux  compiler=(unit @ux)
      status=?(%unavailable %refused %unchecked)
      output=(unit emission)  diagnostics=(list @tas)
  ==
++  compiler-source
  0x61de.9826.aa84.bb7f.094d.9cd9.8841.cfb7.b7d5.6770.866f.40f6.4db0.6642.d25c.fe1e
++  bridge-source
  0x47cc.7ad6.de9b.de13.aee8.5e85.cbcb.2886.2e14.f04d.3e1a.d319.9203.5998.02d4.ee22
++  gaps
  ::  These never disappear merely because an artifact produced output.
  ^-  (list @tas)
  ~[%parser-fallbacks-unchecked %unresolved-names-unchecked %module-linking-unsupported %type-checking-unavailable]
++  linker-sources-initial
  ::  Preserve the exact initial v2 manifest for retained bundle compatibility.
  ^-  (list [@t @ux])
  :~  ['Compiler' 0x61de.9826.aa84.bb7f.094d.9cd9.8841.cfb7.b7d5.6770.866f.40f6.4db0.6642.d25c.fe1e]
      ['ModuleSource' 0xd4f.4a12.4f9f.08d1.a116.5d48.169d.f94a.8a45.3ffc.e2e2.b646.f2fe.aa11.f99c.0e33]
      ['ModuleScope' 0xbe56.f5e0.e4f0.9e37.d2ac.49ee.5a47.2227.d1e5.1299.ed81.8885.eb19.d2ea.116a.f5f6]
      ['ModuleLinker' 0xeeb7.93e4.36ae.131d.6eda.5603.dc67.aca7.cfde.71fd.5710.7a8c.8951.2abe.f3c3.471e]
      ['Runtime.NativeCodingCompiler' 0x6e3b.ef26.6ec5.ae91.a6d1.9937.ce37.05d0.6fa5.deda.1639.d9a9.9fdd.71ea.2c80.ce72]
  ==
++  linker-sources-records
  ::  Preserve the exact record/alias generation for retained attachments.
  ^-  (list [@t @ux])
  :~  ['Compiler' 0x61de.9826.aa84.bb7f.094d.9cd9.8841.cfb7.b7d5.6770.866f.40f6.4db0.6642.d25c.fe1e]
      ['ModuleSource' 0x32d9.faa3.b12b.5901.abcf.439b.18c2.53ef.39c2.5ba2.092e.0dd3.2332.9c1f.d7eb.3ce2]
      ['ModuleScope' 0xbac0.9794.3a3e.543f.7268.bcd9.e217.a71c.884d.8348.bbb6.33b2.4182.15c3.ed89.3c43]
      ['ModuleLinker' 0x58ea.7ace.54ce.f390.e97a.9c59.5004.a368.39c6.9b53.b5a1.1aa2.d9e7.c8b9.fc29.c649]
      ['ModulePrimitives' 0xfe53.9e75.170f.e72f.4386.9782.041f.990b.ef80.ced7.e193.4756.3071.b7df.87cb.148f]
      ['ModuleTypes' 0x2196.47cc.9eb5.4e20.9b0a.cf52.297b.26d2.b2e0.7938.b36c.1e2c.7b04.4c7b.614a.c0b5]
      ['ModuleRecords' 0xd16c.d2e6.4949.622b.4468.d69a.a8a0.ae1d.67ed.da62.07f2.82e6.bd0c.946e.d240.b3f7]
      ['ModuleRecordExpressions' 0x3f5e.dd65.75c3.df08.5437.d3e1.4740.61c2.9e4f.e52c.2349.bde6.8de4.7e71.9133.a290]
      ['Runtime.NativeCodingCompiler' 0x6e3b.ef26.6ec5.ae91.a6d1.9937.ce37.05d0.6fa5.deda.1639.d9a9.9fdd.71ea.2c80.ce72]
  ==
++  linker-sources-classes
  ::  Preserve the exact finite primitives/classes generation.
  ::  Compiler/Module* are compiler/src; Runtime bridge is src/Runtime.
  ^-  (list [@t @ux])
  :~  ['Compiler' 0x61de.9826.aa84.bb7f.094d.9cd9.8841.cfb7.b7d5.6770.866f.40f6.4db0.6642.d25c.fe1e]
      ['ModuleSource' 0x847e.11c7.763a.f38c.4281.8365.fe60.1db6.76b2.f419.92f0.9dab.a091.17b7.8aba.8506]
      ['ModuleScope' 0xa850.557a.4384.d0fc.59e8.d109.fc70.1e73.5ece.5128.111b.8358.3630.7fc8.6cc9.8e03]
      ['ModuleLinker' 0x6e82.ec45.b900.ba46.465b.00e2.6c0b.ddd5.1ab0.a009.cbd9.1279.465e.9c32.b83d.7be1]
      ['ModulePrimitives' 0x13d4.bb83.df9d.9306.62ec.319a.4f40.c6dd.07c4.dee9.2da0.24c9.9da0.10da.9dbc.402c]
      ['ModuleTypes' 0x2196.47cc.9eb5.4e20.9b0a.cf52.297b.26d2.b2e0.7938.b36c.1e2c.7b04.4c7b.614a.c0b5]
      ['ModuleRecords' 0xd16c.d2e6.4949.622b.4468.d69a.a8a0.ae1d.67ed.da62.07f2.82e6.bd0c.946e.d240.b3f7]
      ['ModuleRecordExpressions' 0x2471.0bdf.3c80.b04a.bf69.c8b9.0b96.3f7c.6034.9a80.c425.c4dc.c96c.02a2.351c.eb1a]
      ['ModuleClasses' 0xb4aa.63cd.1e44.c17a.9433.7c33.1440.c7aa.5769.ce24.48cb.86e0.a00c.8794.52d8.b406]
      ['ModuleInstances' 0x3a3c.c887.8389.a9bf.f775.c4f4.12e7.35ea.f970.dc14.60df.9ead.6c40.d3fb.4efa.2770]
      ['ModuleClassLowering' 0xdec5.9d74.6426.b4d7.07f6.8fba.fed9.8936.0f76.1f04.1ed2.9715.eb5f.cf75.2f29.143b]
      ['Runtime.NativeCodingCompiler' 0x6e3b.ef26.6ec5.ae91.a6d1.9937.ce37.05d0.6fa5.deda.1639.d9a9.9fdd.71ea.2c80.ce72]
  ==
++  linker-sources-exports
  ::  Preserve the first named-artifact source generation.
  ^-  (list [@t @ux])
  =/  previous=(list [@t @ux])
    %+  turn  linker-sources-classes
    |=  row=[module=@t digest=@ux]
    ?:  =('ModuleLinker' module.row)
      [module.row 0xff04.f97b.690c.39db.c88d.a816.bb2e.a553.a1d6.9b8b.1778.2cfd.64d0.76e7.9500.afec]
    ?:  =('Runtime.NativeCodingCompiler' module.row)
      [module.row 0x9e36.ae6f.807b.2967.e81a.a7ca.5d8d.7c3f.bf9c.b5ae.059f.ecaf.a069.ce82.95e5.614a]
    row
  ::  Insert ModuleArtifact before the final Runtime bridge witness.
  (weld (scag 11 previous) [['ModuleArtifact' 0x1963.5599.c115.0756.7fce.bc03.0c35.e89f.8f94.c05b.5d9f.f271.86bd.a8ba.7e51.2f78] (slag 11 previous)])
++  linker-sources
  ::  Bootstrap source correction: modules is a reserved GLS keyword.
  ^-  (list [@t @ux])
  %+  turn  linker-sources-exports
  |=  row=[module=@t digest=@ux]
  ?.  =('ModuleLinker' module.row)  row
  [module.row 0xb066.fdf4.8167.98bc.b7d8.e495.f9e5.9f83.2171.0266.484e.7a6b.d6d1.b584.83e5.f182]
++  bundle-gaps
  |=  b=(unit bundle)
  ^-  (list @tas)
  ?~  b  gaps
  ?:  ?=(%native-coding-compiler-bundle-v1 -.u.b)  gaps
  ~[%parser-fallbacks-unchecked %linked-resolution-unverified %type-checking-unavailable]
++  bundle-valid
  |=  b=bundle
  ^-  ?
  ?:  ?=(%native-coding-compiler-bundle-v1 -.b)
    ?&  =(compiler-source.b compiler-source)  =(bridge-source.b bridge-source)
        =(digest.b (shax (jam [compiler-source.b bridge-source.b entry.b])))
        (artifact-valid:scalar entry.b)
    ==
  ?.  (lte (lent sources.b) 13)  %.n
  =/  pins=(list [@t @ux])  (turn sources.b |=(w=witness [module.w digest.w]))
  ?.  |(=(pins linker-sources-initial) =(pins linker-sources-records) =(pins linker-sources-classes) =(pins linker-sources-exports) =(pins linker-sources))  %.n
  ::  Source pins use conventional displayed SHA-256 hex. shax instead packs
  ::  those digest bytes into a little-endian atom; reverse all 32 bytes here.
  ::  Native noun/bundle identities below keep their existing shax encoding.
  ?.  (levy sources.b |=(w=witness &((lte (met 3 bytes.w) 524.288) =(digest.w (rev 3 32 (shax bytes.w))))))  %.n
  ?&  (lte (roll sources.b |=([w=witness sum=@ud] (add sum (met 3 bytes.w)))) 2.097.152)
      =(source-digest.b (shax (jam [%native-coding-compiler-sources-v2 sources.b])))
      =(digest.b (shax (jam [%native-coding-compiler-bundle-v2 source-digest.b sources.b entry.b])))
      ?~(entry.b %.y (artifact-valid:scalar u.entry.b))
  ==
++  install
  ::  This installs no agent and emits no effects. Gall retains the result.
  |=  [our=@p actor=@p current=(unit bundle) incoming=bundle]
  ^-  (each (unit bundle) @tas)
  ?.  &(=(our actor) (bundle-valid incoming))  [%| %compiler-install-refused]
  ?^  current
    ?:  =(u.current incoming)  [%& current]
    ::  An explicitly installed source-only v2 may receive its artifact once.
    ::  Source changes and replacement of any executable entry stay refused.
    ?:  &(?=(%native-coding-compiler-bundle-v2 -.u.current) ?=(%native-coding-compiler-bundle-v2 -.incoming))
      ?.  &(?=(~ entry.u.current) ?=(^ entry.incoming) =(sources.u.current sources.incoming))
        [%| %compiler-already-installed]
      [%& `incoming]
    [%| %compiler-already-installed]
  [%& `incoming]
++  identity
  |=  j=job
  ^-  @ux
  (shax (jam j))
++  dependencies
  ::  Read the entire owner-declared dependency closure from the same revision.
  ::  Version one refuses linking; version two consumes this exact closure.
  |=  [p=project:nc target=build-target:nc]
  ^-  (each (list path) @tas)
  =/  pending=(list path)  [entry.target dependencies.target]
  =/  seen=(set path)  ~
  |-
  ?~  pending
    [%& [entry.target (skim ~(tap in seen) |=(pax=path !=(pax entry.target)))]]
  =/  pax=path  i.pending
  ?:  (~(has in seen) pax)  $(pending t.pending)
  ?:  (gte ~(wyt in seen) source-count-limit:modules)  [%| %compiler-dependency-bound]
  ?.  &((readable:project p pax) ?=(^ pax) =(%gls (rear pax)))
    [%| %compiler-source-path-refused]
  =/  next=(list path)  (~(gut by dependencies.p) pax ~)
  $(pending (weld next t.pending), seen (~(put in seen) pax))
++  module-name
  |=  entry=path
  ^-  @t
  =/  parts=(list @ta)  (flop (slag 1 (flop entry)))
  =/  out=@t  ''
  |-  ^-  @t
  ?~  parts  out
  $(parts t.parts, out ?:(=('' out) `@t`i.parts (cat 3 out (cat 3 '.' i.parts))))
++  prepare
  ::  The caller already owns the Cantrip job. This repeats canonical project
  ::  membership/source checks; it does not admit work or manufacture a grant.
  |=  [our=@p at=@da p=project:nc r=tool-request:nc]
  ^-  (each job @tas)
  ?.  ?=(?(%compile %check) -.arguments.r)  [%| %compiler-operation-refused]
  =/  catalog  (catalog:project our at p)
  ?:  ?=(%| -.catalog)  [%| p.catalog]
  =/  allowed  (authorize:project p p.catalog context.r -.arguments.r)
  ?:  ?=(%| -.allowed)  [%| p.allowed]
  =/  targets=(list build-target:nc)
    (skim targets.p |=(t=build-target:nc =(name.t target.arguments.r)))
  ?~  targets  [%| %compiler-target-missing]
  =/  target=build-target:nc  i.targets
  ?.  =(%gallowglass kind.target)  [%| %compiler-wrong-backend]
  =/  revision=revision:nc  source.context.r
  =/  tree  (tree-at:project our at p desk.revision number.revision)
  ?:  ?=(%| -.tree)  [%| p.tree]
  ?.  =(revision revision.p.tree)  [%| %compiler-source-mismatch]
  =/  paths  (dependencies p target)
  ?:  ?=(%| -.paths)  [%| p.paths]
  =/  module=@t  (module-name entry.target)
  =/  pending=(list path)  p.paths
  =/  sources=(list source)  ~
  =/  size=@ud  0
  |-  ^-  (each job @tas)
  ?~  pending
    ::  A retained revoked mapping is a refusal, never an invitation to use
    ::  the legacy path name. Names and source blobs remain separately bound.
    ?.  (agent-live:guard our at %cantrip)  [%| %compiler-mapping-unavailable]
    =/  configuration=@ux  (configuration:project p)
    =/  mapping=(unit (each manifest:modules @tas))
      .^((unit (each manifest:modules @tas)) %gx /(scot %p our)/cantrip/(scot %da at)/native-coding/compiler-mapping/(scot %ux configuration)/(scot %tas name.target)/noun)
    ?~  mapping
      ?.  &(!=('' module) (lte (met 3 module) 128))  [%| %compiler-module-bound]
      [%& [%native-coding-compiler-job-v1 r p target module (flop sources)]]
    ?:  ?=(%| -.u.mapping)  [%| p.u.mapping]
    =/  mapped  (prepare:modules p p.u.mapping context.r p.paths (flop sources))
    ?:  ?=(%| -.mapped)  [%| p.mapped]
    [%& [%native-coding-compiler-job-v2 r p target module.p.mapped (flop sources) p.u.mapping]]
  =/  content  (file:files p p.tree i.pending)
  ?:  ?=(%| -.content)  [%| p.content]
  =/  bytes=@ud  (met 3 source.p.content)
  ?.  (input-size-valid:modules p size bytes)  [%| %compiler-input-bound]
  =/  blob=@ux  (~(got by files.body.snapshot.p.tree) i.pending)
  $(pending t.pending, size (add size bytes), sources [[i.pending blob source.p.content] sources])
++  encode
  ::  Compiler.List byte constructors: Nil=0; Cons=1 with byte and tail.
  |=  text=@t
  ^-  plan:vm
  =/  bytes=(list @t)  (flop (trip text))
  =/  out=plan:vm  [%nat 0]
  |-  ^-  plan:vm
  ?~  bytes  out
  $(bytes t.bytes, out [%app [%app [%nat 1] [%nat `@ud`i.bytes]] out])
++  decode-bytes
  |=  value=plan:vm
  ^-  @t
  =/  bytes=(list @t)  ~
  =/  left=@ud  65.536
  |-  ^-  @t
  ?:  =([%nat 0] value)  (rap 3 (flop bytes))
  ?>  !=(0 left)
  ?>  ?=([%app [%app [%nat %1] [%nat @]] *] value)
  =/  byte=@ud  value.arg.fun.value
  ::  Assembly text cannot contain NUL; refuse it so atom conversion cannot
  ::  silently discard a trailing zero byte and invent a shorter emission.
  ?>  &(!=(0 byte) (lte byte 255))
  $(value arg.value, left (dec left), bytes [`@t`byte bytes])
++  mapped-input
  |=  j=job-v2
  ^-  (each prepared:modules @tas)
  =/  paths  (dependencies project.j target.j)
  ?:  ?=(%| -.paths)  [%| p.paths]
  =/  mapped  (prepare:modules project.j mapping.j context.request.j p.paths sources.j)
  ?:  ?=(%| -.mapped)  mapped
  ?.  &(=(target.j target.mapping.j) =(module.j module.p.mapped))
    [%| %compiler-module-mapping-mismatch]
  mapped
++  named-sources
  |=  j=job
  ^-  (each (list mapped:modules) @tas)
  ?:  ?=(%native-coding-compiler-job-v1 -.j)
    [%& (turn sources.j |=(s=source [(module-name pax.s) s]))]
  =/  mapped  (mapped-input j)
  ?:  ?=(%| -.mapped)  [%| p.mapped]
  [%& sources.p.mapped]
++  encode-sources
  ::  ModuleSource tag0(name byteList, source byteList), in Compiler.List.
  |=  sources=(list mapped:modules)
  ^-  plan:vm
  =/  todo=(list mapped:modules)  (flop sources)
  =/  out=plan:vm  [%nat 0]
  |-  ^-  plan:vm
  ?~  todo  out
  =/  item=plan:vm
    [%app [%app [%nat 0] (encode module.i.todo)] (encode text.source.i.todo)]
  $(todo t.todo, out [%app [%app [%nat 1] item] out])
++  linked-input-valid
  |=  j=job
  ^-  ?
  =/  sources=(list source)  (job-sources j)
  =/  project=project:nc  (job-project j)
  =/  module=@t  (job-module j)
  ?.  (sources-bounded:modules project sources)  %.n
  =/  named  (named-sources j)
  ?:  ?=(%| -.named)  %.n
  ?~  p.named  %.n
  =/  names=(list @t)  (turn p.named |=(s=mapped:modules module.s))
  ?~  names  %.n
  ?&  =(module i.names)
      =((lent names) ~(wyt in (silt `(list @t)`names)))
      %+  levy  `(list @t)`names
      |=(name=@t &(!=('' name) (lte (met 3 name) 128)))
  ==
++  refuse
  |=  [j=job b=(unit bundle) why=@tas]
  ^-  outcome
  [%native-coding-compiler-outcome-v1 (identity j) ?~(b ~ `digest.u.b) %refused ~ [why (bundle-gaps b)]]
++  linked-refusal
  |=  [j=job b=bundle out=plan:vm]
  ^-  outcome
  ?.  ?=([%app [%app [%nat %1] [%nat @]] [%app [%app [%nat %0] *] *]] out)
    (refuse j `b %compiler-response-invalid)
  =/  names=(unit [p=@t q=@t])
    %-  mole
    |.
    =/  module=@t  (decode-bytes arg.fun.arg.out)
    =/  symbol=@t  (decode-bytes arg.arg.out)
    ?>  &((lte (met 3 module) 128) (lte (met 3 symbol) 128))
    [module symbol]
  ?~  names  (refuse j `b %compiler-response-invalid)
  =/  reason=@tas
    ?+  value.arg.fun.out  %compiler-response-invalid
      %1  %compiler-input-bound
      %2  %compiler-lexer-error
      %4  %compiler-parser-sentinel
      %5  %compiler-output-bound
      %6  %compiler-module-missing
      %7  %compiler-module-duplicate
      %8  %compiler-export-missing
      %9  %compiler-name-ambiguous
      %10  %compiler-dependency-cycle
      %11  %compiler-external-opcode-refused
      %12  %compiler-name-unresolved
      %13  %compiler-syntax-unsupported
      %14  %compiler-pattern-arity
      %15  %compiler-type-erasure-unsupported
    ==
  =/  result=outcome  (refuse j `b reason)
  result(diagnostics (weld diagnostics.result ~[(cat 3 'module-' (scot %ux (shax p.u.names))) (cat 3 'symbol-' (scot %ux (shax q.u.names)))]))
++  invoke
  ::  Frozen exact inputs and code; no compilation output is executed here.
  ::  PLAN steps are bounded independently of the standing grant lifetime.
  |=  [b=(unit bundle) j=job fuel=@ud]
  ^-  outcome
  =/  sources=(list source)  (job-sources j)
  =/  project=project:nc  (job-project j)
  =/  module=@t  (job-module j)
  =/  target=build-target:nc  (job-target j)
  ?.  (sources-bounded:modules project sources)
    (refuse j b %compiler-job-invalid)
  ?~  sources  (refuse j b %compiler-job-invalid)
  =/  srcs=(list source)  sources
  ?.  =(entry.target pax.i.sources)  (refuse j b %compiler-entry-mismatch)
  ?.  (sources-valid:modules project srcs)
    (refuse j b %compiler-input-invalid)
  =/  linked=?  ?~(b %.n ?=(%native-coding-compiler-bundle-v2 -.u.b))
  ?:  &(!linked ?=(%native-coding-compiler-job-v2 -.j))
    (refuse j b %compiler-mapping-requires-linked-bundle)
  ?:  &(!linked ?=(^ t.sources))  (refuse j b %module-linking-unsupported)
  ?~  b
    [%native-coding-compiler-outcome-v1 (identity j) ~ %unavailable ~ [%compiler-artifact-unavailable gaps]]
  ?.  (bundle-valid u.b)  (refuse j b %compiler-artifact-invalid)
  ?.  &(!=('' module) (lte (met 3 module) 128))  (refuse j b %compiler-module-bound)
  ?:  &(linked =((linked-input-valid j) %.n))  (refuse j b %compiler-linked-input-bound)
  =/  entry=(unit plan:vm)
    ?:  ?=(%native-coding-compiler-bundle-v1 -.u.b)  `entry.u.b
    entry.u.b
  ?~  entry
    [%native-coding-compiler-outcome-v1 (identity j) `digest.u.b %unavailable ~ [%compiler-artifact-unavailable (bundle-gaps b)]]
  =/  named  (named-sources j)
  ?:  ?=(%| -.named)  (refuse j b p.named)
  =/  argument=plan:vm  ?:(linked (encode-sources p.named) (encode text.i.sources))
  =/  ran  (run:vm fuel u.entry ~[(encode module) argument])
  ?:  ?=(%| -.ran)  (refuse j b p.ran)
  =/  out=plan:vm  output.p.ran
  ?:  &(linked ?=([%app [%app [%nat %1] *] *] out))  (linked-refusal j u.b out)
  ?:  &(!linked ?=([%app [%nat %1] [%nat @]] out))
    =/  code=@ud  value.arg.out
    =/  why=@tas
      ?+  code  %compiler-response-invalid
        %1  %compiler-input-bound
        %2  %compiler-lexer-error
        %3  %module-linking-unsupported
        %4  %compiler-parser-sentinel
        %5  %compiler-output-bound
      ==
    (refuse j b why)
  ?.  ?=([%app [%nat %0] *] out)  (refuse j b %compiler-response-invalid)
  =/  text=(unit @t)  (mole |.((decode-bytes arg.out)))
  ?~  text  (refuse j b %compiler-output-invalid)
  ?:  =('' u.text)  (refuse j b %compiler-output-empty)
  =/  size=@ud  (met 3 u.text)
  =/  digest=@ux  (shax (jam [%unchecked-plan-assembly-v1 (identity j) digest.u.b size u.text]))
  [%native-coding-compiler-outcome-v1 (identity j) `digest.u.b %unchecked `[size u.text digest] (bundle-gaps b)]
++  report
  ::  Deliberately passed=false for EVERY status. Retained assembler can be
  ::  inspected but cannot satisfy native-coding-accept's successful checks.
  |=  [j=job out=outcome]
  ^-  tool-output:nc
  ?.  =((identity j) job.out)  [%refused %compiler-result-mismatch 'Compiler result belongs to another frozen request.']
  =/  codes=@t  (spat diagnostics.out)
  =/  detail=@t  (cat 3 'Gallowglass compiler attachment: ' (cat 3 `@t`status.out (cat 3 ' ' codes)))
  [%diagnostics ~[[%gallowglass %.n detail source.context:(job-request j) ?~(output.out ~ ~[digest.u.output.out])]]]
++  page
  ::  A source-bound noun for authorized Clay retention by the owning runtime.
  ::  This gate returns data, never an unchecked write card or a saved claim.
  |=  [j=job out=outcome]
  ^-  (each page:clay @tas)
  ?.  =((identity j) job.out)  [%| %compiler-result-mismatch]
  [%& [%noun [%native-coding-compiler-evidence-v1 j out]]]
--
