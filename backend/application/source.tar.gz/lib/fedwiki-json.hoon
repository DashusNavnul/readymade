::  /lib/fedwiki-json.hoon
::
::  Federated wiki's page JSON, both ways.  +de-page reads a page as
::  fedwiki serves it (GET /<slug>.json); +en-page writes one.  Nothing
::  is dropped: unknown item and action fields ride in `more` (see
::  sur/fedwiki), and a `"date": null` stays null, so a page read here
::  and written again is the same JSON value.
::
::  A page this core cannot read is refused with the reason, never half
::  read: +de-page and +de-request give the crash trace.  That includes
::  a top-level page field this core does not keep -- dropping it would
::  make the copy lie.
::
/-  fw=fedwiki
|%
::  +de-page: a page, or why not
::
++  de-page
  |=  jon=json
  ^-  (each page:fw tang)
  (mule |.((read-page jon)))
::  +de-request: one action as a client PUTs it (wiki-server lib/server.js
::  848-962).  The server strips two fields before it journals the action,
::  so they come out here apart from it: `fork`, the site of an implicit
::  fork (journalled separately by +put:fedwiki), and `forkPage`, the
::  page being forked, which becomes the page the action applies to.
::
++  de-request
  |=  jon=json
  ^-  (each [action:fw fork=(unit @t) fork-page=(unit page:fw)] tang)
  %-  mule  |.
  ~|  'a request is an object'
  ?>  ?=([%o *] jon)
  =/  m  p.jon
  =/  fork  (~(get by m) 'fork')
  =/  fp  (~(get by m) 'forkPage')
  =/  fork-page=(unit page:fw)
    ?~  fp  ~
    ~|  'a forkPage is a page'
    `(read-page u.fp)
  =.  m  (~(del by m) 'forkPage')
  ?.  ?=([~ %s *] fork)  [(read-action o+m) ~ fork-page]
  [(read-action o+(~(del by m) 'fork')) `p.u.fork fork-page]
::
++  read-page
  |=  jon=json
  ^-  page:fw
  ~|  'a page is an object'
  ?>  ?=([%o *] jon)
  =/  m  p.jon
  =/  extra=(list @t)
    (skip ~(tap in ~(key by m)) |=(k=@t ?=(?(%title %story %journal) k)))
  ~|  [%page-field-not-kept extra]
  ?>  =(~ extra)
  =/  title  (~(get by m) 'title')
  ~|  'a page title is a string'
  ?>  ?=([~ %s *] title)
  :+  p.u.title
    (turn (arr (~(get by m) 'story')) read-item)
  (turn (arr (~(get by m) 'journal')) read-action)
::  +arr: an absent list is empty, anything else must be an array
::
++  arr
  |=  jon=(unit json)
  ^-  (list json)
  ?~  jon  ~
  ~|  'expected an array'
  ?>  ?=([%a *] u.jon)
  p.u.jon
::
++  read-item
  |=  jon=json
  ^-  item:fw
  ~|  'a story item is an object'
  ?>  ?=([%o *] jon)
  =/  m  p.jon
  =/  id  (~(get by m) 'id')
  =/  kind  (~(get by m) 'type')
  ~|  'a story item has a string id and type'
  ?>  ?=([~ %s *] id)
  ?>  ?=([~ %s *] kind)
  =/  text  (~(get by m) 'text')
  =/  rest  (~(del by (~(del by m) 'id')) 'type')
  ?.  ?=([~ %s *] text)  [p.u.id p.u.kind ~ rest]
  [p.u.id p.u.kind `p.u.text (~(del by rest) 'text')]
::  +read-date: a whole number of milliseconds; null or absent is no date
::
++  read-date
  |=  jon=(unit json)
  ^-  (unit @ud)
  ?~  jon  ~
  ?~  u.jon  ~
  ~|  'a date is a whole number'
  ?>  ?=([%n *] u.jon)
  `(rash p.u.jon dem)
::
++  read-action
  |=  jon=json
  ^-  action:fw
  ~|  'a journal entry is an object'
  ?>  ?=([%o *] jon)
  =/  m  p.jon
  =/  kind  (~(get by m) 'type')
  ~|  'a journal entry has a string type'
  ?>  ?=([~ %s *] kind)
  =/  date  (read-date (~(get by m) 'date'))
  ::  a null date stays in `more`, so it is written back as null
  =/  more  (~(del by m) 'type')
  =?  more  ?=(^ date)  (~(del by more) 'date')
  =/  str
    |=  k=@t
    ^-  @t
    =/  v  (~(get by m) k)
    ~|  [%not-a-string k]
    ?>  ?=([~ %s *] v)
    p.u.v
  =/  item
    |=  k=@t
    ^-  item:fw
    =/  v  (~(get by m) k)
    ~|  [%missing k]
    ?>  ?=(^ v)
    (read-item u.v)
  ?+    p.u.kind  [%other date p.u.kind more]
      %create
    =/  had  (~(get by m) 'item')
    ?~  had  [%create date ~ ~ more]
    ~|  'a create item is an object'
    ?>  ?=([%o *] u.had)
    =/  im  p.u.had
    =/  title  (~(get by im) 'title')
    =/  story  (~(get by im) 'story')
    =?  im  ?=([~ %s *] title)  (~(del by im) 'title')
    =?  im  ?=(^ story)  (~(del by im) 'story')
    :*  %create  date
        ?.(?=([~ %s *] title) ~ `p.u.title)
        ?~(story ~ `(turn (arr story) read-item))
        (~(put by more) 'item' o+im)
    ==
  ::
      %add
    =/  after  (~(get by m) 'after')
    =/  rest  (~(del by (~(del by more) 'id')) 'item')
    =?  rest  ?=([~ %s *] after)  (~(del by rest) 'after')
    [%add date (str 'id') (item 'item') ?.(?=([~ %s *] after) ~ `p.u.after) rest]
  ::
      %edit
    [%edit date (str 'id') (item 'item') (~(del by (~(del by more) 'id')) 'item')]
  ::
      %move
    =/  order=(list @t)
      %+  turn  (arr (~(get by m) 'order'))
      |=  j=json
      ~|  'a move order holds item ids'
      ?>  ?=([%s *] j)
      p.j
    [%move date (str 'id') order (~(del by (~(del by more) 'id')) 'order')]
  ::
      %remove
    [%remove date (str 'id') (~(del by more) 'id')]
  ::
      %fork
    =/  site  (~(get by m) 'site')
    ?.  ?=([~ %s *] site)  [%fork date ~ more]
    [%fork date `p.u.site (~(del by more) 'site')]
  ==
::  +en-page: a page as fedwiki serves it
::
++  en-page
  |=  =page:fw
  ^-  json
  %-  pairs:enjs:format
  :~  ['title' s+title.page]
      ['story' a+(turn story.page en-item)]
      ['journal' a+(turn journal.page en-action)]
  ==
::
++  en-item
  |=  =item:fw
  ^-  json
  =/  m  (~(put by (~(put by more.item) 'id' s+id.item)) 'type' s+kind.item)
  o+?~(text.item m (~(put by m) 'text' s+u.text.item))
::
++  en-action
  |=  =action:fw
  ^-  json
  ::  `more` sits at a different axis in each kind of action, so each
  ::  branch reads it after ?- has refined the kind; `date` does not move
  =/  dated
    |=  m=(map @t json)
    ^-  (map @t json)
    ?~  date.action  m
    (~(put by m) 'date' (numb:enjs:format u.date.action))
  ?-    -.action
      %other   o+(~(put by (dated more.action)) 'type' s+kind.action)
      %remove  o+(~(gas by (dated more.action)) ~[['type' s+'remove'] ['id' s+id.action]])
  ::
      %fork
    =/  m  (~(put by (dated more.action)) 'type' s+'fork')
    o+?~(site.action m (~(put by m) 'site' s+u.site.action))
  ::
      %edit
    =/  m  (dated more.action)
    o+(~(gas by m) ~[['type' s+'edit'] ['id' s+id.action] ['item' (en-item item.action)]])
  ::
      %move
    =/  order=json  a+(turn order.action |=(i=@t s+i))
    o+(~(gas by (dated more.action)) ~[['type' s+'move'] ['id' s+id.action] ['order' order]])
  ::
      %add
    =/  m  (dated more.action)
    =.  m  (~(gas by m) ~[['type' s+'add'] ['id' s+id.action] ['item' (en-item item.action)]])
    o+?~(after.action m (~(put by m) 'after' s+u.after.action))
  ::
      %create
    =/  m  (~(put by (dated more.action)) 'type' s+'create')
    ::  the item was there if it held a title, a story or other fields
    =/  had  (~(get by m) 'item')
    =/  im=(unit (map @t json))
      ?:  ?=([~ %o *] had)  `p.u.had
      ?:  |(?=(^ title.action) ?=(^ story.action))  `~
      ~
    ?~  im  o+m
    =/  out  u.im
    =?  out  ?=(^ title.action)  (~(put by out) 'title' s+u.title.action)
    =?  out  ?=(^ story.action)
      (~(put by out) 'story' a+(turn u.story.action en-item))
    o+(~(put by m) 'item' o+out)
  ==
--
