::  Item 5: tell a collaborator when their exact suggestion lands.
::
::  "Lands" means the owner's governed path applied it: Cantrip holds an
::  %applied candidate for the same project whose landed tree (read back from
::  Clay before it was marked applied) holds every suggested file exactly
::  (Clay's own hash of the suggested text at each added or modified path, no
::  file at each deleted path), on the suggestion's own desk, at a later
::  revision than the one it was written against. A suggestion that changed
::  nothing never lands.
::  Single-file and multi-file suggestions are judged the same way.
::
::  Each landed suggestion becomes one %suggestion-landed notice through the
::  durable notice store, so it is announced once however often this runs.
/-  pa=cantrip-project-access, j=cantrip-project-suggestion-journal,
    mc=multiplayer-changeset, nc=native-coding
/+  accept=native-coding-accept, notes=readymade-collab-notices,
    io=cantrip-project-suggestion-archive-io, history=readymade-project-inbox-bundle-history
|%
::  want: Clay's hash of the suggested file at that path, or ~ for a deletion.
+$  want  [=path lobe=(unit @ux)]
+$  shape
  $:  project=@t  peer=@p  nonce=@ux  desk=@tas  base=@ud
      wants=(list want)
  ==
+$  hit  [=shape candidate=@ux revision=@ud]
++  page-cap  64
++  lobe
  ::  Clay's hash of a file: its page, the mark (last path element) and text.
  |=  [pax=path text=@t]
  ^-  @ux
  ?>  ?=(^ pax)
  (shax (jam [(rear pax) text]))
++  wants-of
  ::  Nothing if any change is a no-op or a written file has no text.
  |=  [changes=(list change:mc) sources=(map path @t)]
  ^-  (unit (list want))
  ?:  =(~ changes)  ~
  =|  out=(list want)
  |-  ^-  (unit (list want))
  ?~  changes  `(flop out)
  =/  c=change:mc  i.changes
  ?:  =(before.c after.c)  ~
  ?:  ?=(%delete kind.c)  $(changes t.changes, out [[path.c ~] out])
  =/  text  (~(get by sources) path.c)
  ?~  text  ~
  ?.  ?=(^ path.c)  ~
  $(changes t.changes, out [[path.c `(lobe path.c u.text)] out])
++  shape-of
  |=  e=entry:j
  ^-  (unit shape)
  ?-  -.e
      %legacy
    =/  r=receipt:pa  value.e
    ?.  ?=(%suggest -.payload.r)  ~
    =/  body  body.snapshot.parent.payload.r
    =/  ws  (wants-of ~[change.payload.r] (my ~[[path.change.payload.r source.payload.r]]))
    ?~  ws  ~
    `[project.request.r peer.r nonce.request.r base-desk.body base-revision.body u.ws]
  ::
      %bundle
    =/  b=bundle:pa  value.e
    =/  body  body.snapshot.parent.request.b
    =/  ws  (wants-of changes.request.b sources.request.b)
    ?~  ws  ~
    `[project.request.b peer.b nonce.request.b base-desk.body base-revision.body u.ws]
  ==
++  holds
  ::  The tree holds every suggested file exactly, or no file for a deletion.
  |=  [s=shape t=tree:nc]
  ^-  ?
  =/  files=(map path @ux)  files.body.snapshot.t
  ?&  =(desk.s desk.revision.t)
      (gth number.revision.t base.s)
      !=(~ wants.s)
      (levy wants.s |=(w=want =((~(get by files) path.w) lobe.w)))
  ==
++  applied
  ::  Applied candidates of one project with a retained landed tree, oldest first.
  |=  [held=ledger:accept project=@t]
  ^-  (list [id=@ux t=tree:nc])
  =/  rows=(list [id=@ux t=tree:nc])
    %+  murn  ~(tap by held)
    |=  [id=@ux r=record:accept]
    ^-  (unit [@ux tree:nc])
    ?.  &(?=(%applied stage.r) =(project id.spec.project.r))  ~
    ?~  landed.r  ~
    `[id u.landed.r]
  (sort rows |=([a=[id=@ux t=tree:nc] b=[id=@ux t=tree:nc]] (lth number.revision.t.a number.revision.t.b)))
++  landed
  ::  The first applied candidate that holds this suggestion exactly.
  |=  [s=shape trees=(list [id=@ux t=tree:nc])]
  ^-  (unit hit)
  ?~  trees  ~
  ?:  (holds s t.i.trees)  `[s id.i.trees number.revision.t.i.trees]
  $(trees t.trees)
++  hits
  |=  [entries=(list entry:j) held=ledger:accept project=@t]
  ^-  (list hit)
  =/  trees  (applied held project)
  %+  murn  entries
  |=  e=entry:j
  =/  s  (shape-of e)
  ?~  s  ~
  ?.  =(project project.u.s)  ~
  (landed u.s trees)
++  notice-for
  |=  [our=@p at=@da h=hit]
  ^-  notice:notes
  =/  detail=@t
    (rap 3 ~['Landed in ' desk.shape.h ' at revision ' (scot %ud revision.h) ' by candidate ' (scot %ux candidate.h) '.'])
  (make:notes our peer.shape.h project.shape.h %suggestion-landed nonce.shape.h at detail)
::  ---  owner reads (Cantrip scries; the caller wraps them in mole)
++  base  |=([our=@p at=@da] `path`/(scot %p our)/cantrip/(scot %da at))
++  owner-ready
  ::  Safe on any ship: the hosted Cantrip's desk is checked in Clay before
  ::  any of its scries is touched. A guest ship or an older Cantrip answers
  ::  no here instead of crashing the request.
  |=  [our=@p at=@da]
  ^-  ?
  ?.  .^(? %cu /(scot %p our)/host-cantrip/(scot %da at)/app/cantrip/hoon)  %.n
  (supported-v2:history our at)
++  ledger-now
  |=  [our=@p at=@da]
  ^-  ledger:accept
  .^(ledger:accept %gx (weld (base our at) /native-coding/candidate-ledger/noun))
++  hot
  |=  [our=@p at=@da]
  ^-  (list entry:j)
  =/  raw=*  .^(* %gx (weld (base our at) /project-access/journal-v2/noun))
  =/  got  ;;((each [%cantrip-project-journal-v2 %native-coding-patches-v1 records=journal:j] @tas) raw)
  ?>  ?=(%& -.got)
  %+  weld
    (turn ~(val by legacy.records.p.got) |=(r=receipt:pa `entry:j`[%legacy r]))
  (turn ~(val by bundles.records.p.got) |=(b=bundle:pa `entry:j`[%bundle b]))
++  archived
  ::  Every archived entry of one project, page by page from one pinned head.
  |=  [our=@p at=@da project=@t]
  ^-  (list entry:j)
  ?.  (supported-v2:history our at)  ~
  =/  revision=@ud  0
  =/  after=@ta  %start
  =|  out=(list entry:j)
  =/  pages=@ud  0
  |-  ^-  (list entry:j)
  ?>  (lth pages page-cap)
  =/  raw=*
    .^(* %gx (weld (base our at) /project-access/history/page-v2/(scot %ux project)/(scot %ud revision)/[after]/(scot %ud 8)/noun))
  =/  got  ;;((each page-v2:io @tas) raw)
  ?:  ?=(%| -.got)
    ?:(=(%receipt-archive-unconfigured p.got) out ~|(p.got !!))
  =.  out  (weld out receipts.p.got)
  ?.  more.p.got  out
  ?~  next.p.got  out
  $(revision number.head.p.got, after u.next.p.got, pages +(pages))
++  scan
  ::  Every exact landed suggestion of one project, as notices to send.
  |=  [our=@p at=@da project=@t]
  ^-  (list notice:notes)
  =/  entries=(list entry:j)  (weld (hot our at) (archived our at project))
  (turn (hits entries (ledger-now our at) project) |=(h=hit (notice-for our at h)))
++  send-all
  ::  Store and send each new notice once; a held or refused one sends nothing.
  |=  [our=@p at=@da ns=(list notice:notes)]
  ^-  [cards=(list card:agent:gall) sent=(list @ux)]
  =|  cards=(list card:agent:gall)
  =|  sent=(list @ux)
  |-  ^-  [cards=(list card:agent:gall) sent=(list @ux)]
  ?~  ns  [cards (flop sent)]
  =/  r  (send:notes our at i.ns)
  ?.  ?=(%& -.r)  $(ns t.ns)
  ?.  new.p.r  $(ns t.ns)
  $(ns t.ns, cards (weld cards cards.p.r), sent [id.i.ns sent])
++  project-of
  ::  The project of one applied candidate, if it is applied.
  |=  [our=@p at=@da id=@ux]
  ^-  (unit @t)
  =/  r  (~(get by (ledger-now our at)) id)
  ?~  r  ~
  ?.  ?=(%applied stage.u.r)  ~
  `id.spec.project.u.r
::  ---  item 30: each suggestion's authored, reviewed, landed and
::  acknowledged history together (owner view; read-only)
++  authored
  |=  e=entry:j
  ^-  [at=@da files=@ud kind=@t]
  ?-  -.e
    %legacy  [at.value.e 1 'single-file']
    %bundle  [at.value.e (lent changes.request.value.e) 'multi-file']
  ==
++  notice-json
  ::  The outcome of one notice this ship would have sent, if it did.
  |=  [our=@p at=@da sending=(set @ux) peer=@p project=@t =kind:notes subject=@ux]
  ^-  json
  =/  id  (id-for:notes our peer project kind subject)
  ?~  (read-notice:notes our at (out-path:notes id))  ~
  =/  done  (read-answer:notes our at id)
  %-  pairs:enjs:format
  :~  ['kind' s+kind]  ['id' s+(scot %ux id)]
      ['status' s+(status-of:notes done (~(has in sending) id))]
      ['acknowledgedAt' ?~(done ~ s+(scot %da at.u.done))]
  ==
++  suggestion-history
  ::  Newest first, at most 64 suggestions of one project.
  |=  [our=@p at=@da sending=(set @ux) project=@t]
  ^-  json
  =/  entries=(list entry:j)
    %+  skim  (weld (hot our at) (archived our at project))
    |=(e=entry:j =(`project (bind (shape-of e) |=(s=shape project.s))))
  =/  sorted=(list entry:j)
    (scag 64 (sort entries |=([a=entry:j b=entry:j] (gth at:(authored a) at:(authored b)))))
  =/  held=ledger:accept  (ledger-now our at)
  =/  trees  (applied held project)
  =/  store=?  (store:notes our at)
  =/  rows=(list json)
    %+  murn  sorted
    |=  e=entry:j
    ^-  (unit json)
    =/  s  (shape-of e)
    ?~  s  ~
    =/  a  (authored e)
    =/  hit  (landed u.s trees)
    =/  review=json
      ?~  hit  ~
      =/  r  (~(get by held) candidate.u.hit)
      ?~  r  ~
      ?~  decision.u.r  ~
      %-  pairs:enjs:format
      :~  ['candidate' s+(scot %ux candidate.u.hit)]  ['verdict' s+verdict.u.decision.u.r]
          ['at' s+(scot %da at.u.decision.u.r)]  ['stage' s+stage.u.r]
      ==
    =/  told
      |=  k=kind:notes
      ?.  store  ~
      (notice-json our at sending peer.u.s project k nonce.u.s)
    :-  ~
    %-  pairs:enjs:format
    :~  ['request' s+(scot %ux nonce.u.s)]  ['peer' s+(scot %p peer.u.s)]
        ['kind' s+kind.a]  ['files' (numb:enjs:format files.a)]
        ['authoredAt' s+(scot %da at.a)]  ['baseRevision' (numb:enjs:format base.u.s)]
        ['reviewed' review]
        :-  'landed'
        ?~  hit  ~
        (pairs:enjs:format ~[['candidate' s+(scot %ux candidate.u.hit)] ['revision' (numb:enjs:format revision.u.hit)] ['desk' s+desk.u.s]])
        ['answer' =/(t (told %suggestion-taken) ?.(=(~ t) t (told %suggestion-declined)))]
        ['landedNotice' (told %suggestion-landed)]
    ==
  %-  pairs:enjs:format
  :~  ['schema' s+'readymade-suggestion-history-v1']  ['owner' s+(scot %p our)]
      ['project' s+project]  ['observedAt' s+(scot %da at)]  ['noticeStore' b+store]
      ['suggestions' (numb:enjs:format (lent entries))]  ['shown' (numb:enjs:format (lent rows))]
      ['rows' a+rows]
  ==
++  history-project
  |=  req=inbound-request:eyre
  ^-  (unit @t)
  ?.  &(authenticated.req =('GET' method.request.req))  ~
  =/  p  (get-header:http 'x-readymade-project' header-list.request.req)
  ?~  p  ~
  ?.  &(!=(0 (met 3 u.p)) (lte (met 3 u.p) 128))  ~
  p
--
