::  Pure bounded project contract. Owning Viki must read current authority,
::  retain the complete manifest, and join compiler/Cantrip/Graf journals.
/-  pc=pataphor-project-coding
/+  save=cantrip-project-save, editor=pataphor-editor-model,
    correction=pataphor-project-correction
|%
++  project  'pataphor'
++  targets
  ^-  (list path)
  ~[/lib/pataphor-workspace-ui/hoon /lib/pataphor-noltbook/hoon]
++  hash
  |=  value=*
  ^-  @ux
  (shax (jam value))
++  manifest-id
  ::  Observation time is not source identity. Full original basis is still
  ::  retained; immutable commits, maps, roots and every source byte are bound.
  |=  m=manifest:pc
  ^-  @ux
  (hash m(basis basis.m(at `@da`0)))
++  result-id
  |=  r=result:pc
  ^-  @ux
  (hash r)
++  text-valid
  |=  text=@t
  ^-  ?
  &(!=('' text) (lte (met 3 text) 4.096) (text-valid:editor text))
++  manifest-valid
  |=  m=manifest:pc
  ^-  ?
  ?.  &((basis-valid:save basis.m) =(project id.project.basis.m) =(targets writable.m))  %.n
  =/  files=(map path @ux)  files.body.snapshot.working.basis.m
  ::  Desk metadata and marks remain committed in the complete basis. Only
  ::  app/lib/sur/ted Hoon sources enter the model's source closure.
  =/  closure=(set path)
    %-  silt
    %+  murn  ~(tap by files)
    |=  [pax=path blob=@ux]
    ?:((path-valid:save pax) `pax ~)
  ?.  =(~(key by sources.m) closure)  %.n
  ?&  (levy targets |=(pax=path (~(has by sources.m) pax)))
      (lte (roll ~(val by sources.m) |=([text=@t total=@ud] (add total (met 3 text)))) 65.536)
      %+  levy  ~(tap by sources.m)
      |=  [pax=path source=@t]
      ?&  (path-valid:save pax)  (text-valid:editor source)
          (lte (met 3 source) 32.768)
          =((~(got by files) pax) `@ux`(page-to-lobe:clay [%hoon source]))
      ==
  ==
++  request-valid
  |=  r=request:pc
  ^-  ?
  ?&  !=(0 nonce.r)  (lte (met 0 nonce.r) 128)
      =(project project.r)  !=(0 manifest.r)
      ?~(prior.r %.y !=(0 u.prior.r))
      =(%codex provider.r)  (text-valid text.r)
  ==
++  edits-valid
  |=  [m=manifest:pc edits=(list edit:save)]
  ^-  ?
  ?.  (manifest-valid m)  %.n
  =/  paths=(list path)  (turn edits |=(e=edit:save path.change.e))
  ?&  =(2 (lent edits))  =((silt paths) (silt writable.m))
      (lte (roll edits |=([e=edit:save total=@ud] (add total (met 3 source.e)))) 65.536)
      (levy edits |=(e=edit:save (edit-valid:save files.body.snapshot.working.basis.m e)))
  ==
++  result-valid
  ::  Shape and internal consistency only. Canonical provenance is the
  ::  owner's reader's job; a browser result can never authorize a write.
  |=  r=result:pc
  ^-  ?
  ?.  (request-valid request.r)  %.n
  ?.  ?&  (lte (lent edits.r) 2)  (lte (lent checks.r) 16)
          ?~(proposal.r %.y !=(0 u.proposal.r))
          ?~(receipt.r %.y !=(0 u.receipt.r))
          ?~(preview.r %.y (lte (met 3 body.u.preview.r) 65.536))
          (levy checks.r |=(c=check:pc &((path-valid:save pax.c) !=(0 name.c) (lte (met 3 detail.c) 2.048))))
          (levy edits.r |=(e=edit:save &((path-valid:save path.change.e) (text-valid:editor source.e) (lte (met 3 source.e) 32.768))))
      ==  %.n
  ?:  !=(%saved phase.r)
    |(&(=(~ saved.r) =(~ receipt.r)) (failed:correction r))
  ?&  ?=(^ saved.r)  ?=(^ receipt.r)  ?=(^ proposal.r)
      !=(0 desk.u.saved.r)  !=(0 number.u.saved.r)  !=(0 root.u.saved.r)
      =(2 (lent edits.r))  ?=(^ checks.r)
      (levy `(list check:pc)`checks.r |=(c=check:pc passed.c))  =(~ reason.r)
  ==
++  view-valid
  |=  v=view:pc
  ^-  ?
  ?&  =(project project.v)  (lte (lent results.v) 32)
      ?~  manifest.v  %.y
      &((manifest-valid u.manifest.v) =(owner.v owner.basis.u.manifest.v))
      (levy results.v result-valid)
      =((lent results.v) ~(wyt in (silt (turn results.v |=(r=result:pc nonce.request.r)))))
  ==
++  prepare-request
  |=  [our=@p actor=@p nonce=@ux m=manifest:pc prior=(unit result:pc) text=@t]
  ^-  (each request:pc @tas)
  ?.  =(our actor)  [%| %foreign-owner]
  ?.  &((manifest-valid m) =(our owner.basis.m))  [%| %manifest-invalid]
  =/  previous=(unit @ux)
    ?~  prior  ~
    `(result-id u.prior)
  =/  denial=(unit @tas)
    ?~  prior  ~
    ?.  (result-valid u.prior)  `%prior-not-saved
    ?:  (failed:correction u.prior)
      ?.  &(=(nonce (nonce:correction u.prior)) =(text text.request.u.prior))
        `%correction-request-mismatch
      ?.  (source-matches:correction m u.prior)  `%prior-source-changed
      ~
    ?.  =(%saved phase.u.prior)  `%prior-not-saved
    ?>  ?=(^ saved.u.prior)
    =/  w  working.basis.m
    ?.  =([base-desk.body.snapshot.w base-revision.body.snapshot.w root.w] u.saved.u.prior)
      `%prior-source-changed
    ?:  =(nonce nonce.request.u.prior)  `%nonce-conflict
    ~
  ?^  denial  [%| u.denial]
  =/  r=request:pc  [%pataphor-project-request-v1 nonce project (manifest-id m) previous %codex text]
  ?:((request-valid r) [%& r] [%| %request-invalid])
--
