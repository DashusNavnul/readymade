::  /lib/multiplayer-model-binding
::
::  Pure authority seam between multiplayer work and replaceable model organs.
::
/-  mb=model-bridge, mmb=multiplayer-model-binding,
    ms=multiplayer-seat, mw=multiplayer-work,
    vi=viki-inference, vr=viki-route
/+  mbs=model-bridge-state, msl=multiplayer-seat, mwl=multiplayer-work
|%
++  max-capabilities  `@ud`16
++  initial-state
  ^-  state:mmb
  [1 ~ ~]
::
++  spec-digest
  |=  spec=model-bridge-spec:mb
  ^-  digest:mmb
  `@ux`(shax (jam [%multiplayer-model-bridge-spec-v1 spec]))
++  identity-digest
  |=  identity=model-identity:mmb
  ^-  digest:mmb
  `@ux`(shax (jam [%multiplayer-model-identity-v1 identity]))
++  binding-digest
  |=  body=binding-body:mmb
  ^-  digest:mmb
  `@ux`(shax (jam [%multiplayer-model-binding-v1 body]))
++  approval-digest
  |=  body=approval-body:mmb
  ^-  digest:mmb
  `@ux`(shax (jam [%multiplayer-model-approval-v1 body]))
++  result-digest
  |=  result=model-bridge-result:mb
  ^-  digest:mmb
  `@ux`(shax (jam [%multiplayer-model-result-v1 result]))
++  attestation-digest
  |=  body=attestation-body:mmb
  ^-  digest:mmb
  `@ux`(shax (jam [%multiplayer-model-attestation-v1 body]))
::
++  identity-valid
  |=  [connected=connected-route:vr identity=model-identity:mmb]
  ^-  ?
  ?.  (connected-route-valid:vr connected)  %.n
  ?.  =(1 version.identity)  %.n
  ?.  =(%connected kind.backend.identity)  %.n
  =/  provider=(unit @tas)  (slaw %tas provider-id.spec.connected)
  ?~  provider  %.n
  =/  model=(unit @tas)  (slaw %tas model-id.spec.connected)
  ?~  model  %.n
  ?&  =(u.provider provider.backend.identity)
      =(u.model model.backend.identity)
      !=('' revision.backend.identity)
      (gth ~(wyt in capabilities.identity) 0)
      (lte ~(wyt in capabilities.identity) max-capabilities)
  ==
++  binding-valid
  |=  binding=binding:mmb
  ^-  ?
  =/  body=binding-body:mmb  body.binding
  ?.  ?&  =(1 version.body)
          !=(0 project.key.body)
          !=(0 task.key.body)
          !=(0 seat.key.body)
          !=(0 actor.body)
          !=(0 lease-generation.body)
          !=(0 role-epoch.body)
          !=(0 workspace-digest.body)
          !=(0 spec-digest.body)
          !=(0 declared-backend.body)
          !=(0 port.body)
          !=(0 queue-nonce.body)
          (gth timeout.body 0)
          (lte timeout.body ~m10)
          (gth expires-at.body issued-at.body)
          =((binding-digest body) digest.binding)
          =((spec-digest spec.connected.body) spec-digest.body)
          (identity-valid connected.body identity.body)
      ==
    %.n
  ?.  ?=(%local-session -.target.spec.connected.body)  %.n
  =(port.body port.target.spec.connected.body)
++  approval-valid
  |=  approval=approval:mmb
  ^-  ?
  =/  body=approval-body:mmb  body.approval
  ?&  =(1 version.body)
      !=(0 binding-digest.body)
      !=(0 approver.body)
      !=(0 nonce.body)
      (gth expires-at.body issued-at.body)
      =((approval-digest body) digest.approval)
  ==
++  attestation-valid
  |=  attestation=attestation:mmb
  ^-  ?
  =/  body=attestation-body:mmb  body.attestation
  ?&  =(1 version.body)
      !=(0 binding-digest.body)
      !=(0 request-key.body)
      !=(0 identity-digest.body)
      !=(0 result-digest.body)
      !=(0 declared-backend.body)
      !=(0 attested-at.body)
      =((attestation-digest body) digest.attestation)
  ==
++  route-state-valid
  |=  route=route-state:mmb
  ^-  ?
  ?&  (binding-valid binding.route)
      !=(0 approval-digest.route)
      %+  levy  ~(tap by attestations.route)
      |=  row=[@t attestation:mmb]
      ?&  =(-.row request-key.body.+.row)
          (attestation-valid +.row)
          =(digest.binding.route binding-digest.body.+.row)
      ==
  ==
++  state-valid
  |=  state=state:mmb
  ^-  ?
  ?&  =(1 version.state)
      %+  levy  ~(tap by routes.state)
      |=  row=[route-key:mmb route-state:mmb]
      ?&  =(-.row key.body.binding.+.row)
          (route-state-valid +.row)
          (~(has in used-approvals.state) approval-digest.+.row)
      ==
  ==
::
++  issue
  |=  $:  binding=binding:mmb
          authority-host=@p
          source=@p
          nonce=digest:mmb
          issued-at=@da
          expires-at=@da
      ==
  ^-  issue-result:mmb
  ?.  (binding-valid binding)  [%| [%invalid-binding ~]]
  ?.  =(authority-host source)
    [%| [%foreign-approver authority-host source]]
  ?.  ?&  !=(0 nonce)
          (gth expires-at issued-at)
          (lte expires-at expires-at.body.binding)
      ==
    [%| [%invalid-approval ~]]
  =/  body=approval-body:mmb
    [1 digest.binding source nonce issued-at expires-at]
  [%& [body (approval-digest body)]]
::
++  admit
  |=  $:  state=state:mmb
          plan=plan:mw
          registry=registry:ms
          lease=lease:ms
          binding=binding:mmb
          approval=approval:mmb
          authority-host=@p
          source=@p
          observed-at=@da
      ==
  ^-  admit-result:mmb
  ?.  (state-valid state)  [%| [%invalid-state ~]]
  ?.  (plan-valid:mwl plan)  [%| [%invalid-plan ~]]
  ?.  (registry-valid:msl registry)  [%| [%invalid-registry ~]]
  ?.  (binding-valid binding)  [%| [%invalid-binding ~]]
  ?.  (approval-valid approval)  [%| [%invalid-approval ~]]
  =/  body=binding-body:mmb  body.binding
  =/  key=route-key:mmb  key.body
  ?.  =(project.plan project.key)
    [%| [%project-mismatch project.plan project.key]]
  ?.  =(project.registry project.key)
    [%| [%project-mismatch project.registry project.key]]
  ?.  =(authority.plan authority-host)
    [%| [%foreign-approver authority.plan authority-host]]
  ?.  =(authority-host source)
    [%| [%foreign-approver authority-host source]]
  =/  found=(unit task-state:mw)  (~(get by tasks.plan) task.key)
  ?~  found  [%| [%task-missing task.key]]
  =/  task-state=task-state:mw  u.found
  ?~  workspace.task-state  [%| [%workspace-missing task.key]]
  =/  workspace=workspace-grant:mw  u.workspace.task-state
  ?.  ?&  =(project.key project.workspace)
          =(task.key task.workspace)
          =(seat.key seat.workspace)
          =(actor.body ship.workspace)
          =(workspace-digest.body digest.workspace)
      ==
    [%| [%workspace-mismatch ~]]
  ?.  (lease-valid:msl registry lease)  [%| [%lease-mismatch ~]]
  ?.  ?&  ?=(%active -.status.lease)
          =(project.key project.lease)
          =(seat.key seat.lease)
          =(actor.body holder.lease)
          =(lease-generation.body generation.lease)
          =(role-epoch.body role-epoch.lease)
      ==
    [%| [%lease-mismatch ~]]
  ?:  (lth observed-at issued-at.body)
    [%| [%not-yet-valid issued-at.body observed-at]]
  ?:  (gte observed-at expires-at.body)
    [%| [%stale expires-at.body observed-at]]
  =/  approval-body=approval-body:mmb  body.approval
  ?.  =(digest.binding binding-digest.approval-body)
    [%| [%approval-mismatch digest.binding binding-digest.approval-body]]
  ?.  =(authority-host approver.approval-body)
    [%| [%foreign-approver authority-host approver.approval-body]]
  ?:  (lth observed-at issued-at.approval-body)
    [%| [%not-yet-valid issued-at.approval-body observed-at]]
  ?:  (gte observed-at expires-at.approval-body)
    [%| [%stale expires-at.approval-body observed-at]]
  ?:  (~(has in used-approvals.state) digest.approval)
    [%| [%approval-spent digest.approval]]
  ?:  (~(has by routes.state) key)
    [%| [%route-exists key]]
  =/  route=route-state:mmb  [binding digest.approval ~]
  =/  next=state:mmb
    state(routes (~(put by routes.state) key route), used-approvals (~(put in used-approvals.state) digest.approval))
  [%& [next route]]
::
++  submit
  |=  $:  state=state:mmb
          key=route-key:mmb
          bridge=bridge-state-v2:mbs
          request=model-bridge-request:mb
          inference=request:vi
      ==
  ^-  (each [bridge=bridge-state-v2:mbs dispatch=model-bridge-dispatch:mb] refusal:mmb)
  ?.  (state-valid state)  [%| [%invalid-state ~]]
  =/  found=(unit route-state:mmb)  (~(get by routes.state) key)
  ?~  found  [%| [%route-missing key]]
  =/  binding=binding:mmb  binding.u.found
  =/  body=binding-body:mmb  body.binding
  ?.  (model-bridge-request-valid:mb request)  [%| [%invalid-request ~]]
  ?.  (request-bound:vi inference)  [%| [%invalid-inference ~]]
  ?.  ?=(%viki-inference-request-v2 -.inference)
    [%| [%invalid-inference ~]]
  ?.  ?&  =(backend.identity.body backend.inference)
          =(timeout.body timeout.inference)
          =(seat.key session-id.request)
      ==
    [%| [%invalid-inference ~]]
  =/  dispatch=model-bridge-dispatch:mb
    (prepare-model-dispatch:mb spec.connected.body request)
  ?.  (model-dispatch-allowed:mb dispatch)  [%| [%invalid-request ~]]
  =/  queued=transition:mbs  (submit:mbs bridge dispatch)
  ?.  =(%accepted status.queued)
    [%| [%queue-refused status.queued]]
  [%& [state.queued dispatch]]
::
++  attest
  |=  $:  state=state:mmb
          key=route-key:mmb
          request=model-bridge-request:mb
          result=model-bridge-result:mb
          observed-at=@da
      ==
  ^-  attest-result:mmb
  ?.  (state-valid state)  [%| [%invalid-state ~]]
  =/  found=(unit route-state:mmb)  (~(get by routes.state) key)
  ?~  found  [%| [%route-missing key]]
  =/  route=route-state:mmb  u.found
  =/  binding=binding:mmb  binding.route
  =/  body=binding-body:mmb  body.binding
  =/  request-key=@t  (model-bridge-request-key:mb request)
  ?:  (~(has by attestations.route) request-key)
    [%| [%attestation-exists request-key]]
  ?.  ?&  (model-result-accepted:mb result)
          (model-bridge-event-matches-request:mb spec.connected.body request [%result result])
      ==
    [%| [%invalid-request ~]]
  ?.  (backend-attested:mb result declared-backend.body)
    [%| [%backend-unattested declared-backend.body]]
  =/  attestation-body=attestation-body:mmb
    :*  1
        digest.binding
        request-key
        (identity-digest identity.body)
        (result-digest result)
        declared-backend.body
        observed-at
    ==
  =/  attestation=attestation:mmb
    [attestation-body (attestation-digest attestation-body)]
  =/  next-route=route-state:mmb
    route(attestations (~(put by attestations.route) request-key attestation))
  =/  next=state:mmb  state(routes (~(put by routes.state) key next-route))
  [%& [next attestation]]
--
