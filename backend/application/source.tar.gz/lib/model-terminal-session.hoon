::  /lib/model-terminal-session.hoon
::
::  Pure command parser for a linked provider-selectable model terminal.
::  Provider switches persist in the Gall owner; prefixes override one message.
::
/-  *sole
/-  mt=model-terminal
|%
+$  linked-input
  $%  [%show ~]
      [%switch provider=model-terminal-provider:mt]
      [%message provider=model-terminal-provider:mt task=@t]
  ==
+$  terminal-providers  (map sole-id model-terminal-provider:mt)
::
++  current-provider
  |=  [providers=terminal-providers id=sole-id]
  ^-  model-terminal-provider:mt
  =/  saved=(unit model-terminal-provider:mt)
    (~(get by providers) id)
  ?~(saved %qwen u.saved)
::
++  remember-provider
  |=  [providers=terminal-providers id=sole-id provider=model-terminal-provider:mt]
  ^-  terminal-providers
  (~(put by providers) id provider)
::
++  forget-provider
  |=  [providers=terminal-providers id=sole-id]
  ^-  terminal-providers
  (~(del by providers) id)
::
++  parse-linked-input
  |=  [fallback=model-terminal-provider:mt input=@t]
  ^-  linked-input
  ?:  =('/model' input)  [%show ~]
  ?:  ?|  =('/model codex' input)  =(':codex' input)  ==
    [%switch %codex]
  ?:  ?|  =('/model qwen' input)  =(':qwen' input)  ==
    [%switch %qwen]
  =/  codex-prefix=@t  'codex: '
  =/  qwen-prefix=@t   'qwen: '
  =/  codex-bytes=@ud  (met 3 codex-prefix)
  =/  qwen-bytes=@ud   (met 3 qwen-prefix)
  ?:  ?&  (gte (met 3 input) codex-bytes)
          =(codex-prefix (end [3 codex-bytes] input))
      ==
    [%message %codex (rsh [3 codex-bytes] input)]
  ?:  ?&  (gte (met 3 input) qwen-bytes)
          =(qwen-prefix (end [3 qwen-bytes] input))
      ==
    [%message %qwen (rsh [3 qwen-bytes] input)]
  [%message fallback input]
--
