::  Pure connected acceptance contract. Only Cantrip may authenticate the
::  supplied journals/current reads and save a reservation with its ONE card.
::  No imported judgment, Graf claim, callback or timeout proves acceptance.
/-  itn=intent
/+  judgment=viki-vibecoding-connected-judgment, checks=cantrip-connected-checks,
    editor=cantrip-editor-save, model=pataphor-editor-model,
    result=vibecoding-connected-result, law=cantrip-law-window,
    legacy=cantrip-vibecoding-local-land, demo=vibecoding-demo,
    vcl=vibecoding-candidate
|%
+$  command  [%cantrip-connected-land-v2 judgment=@ux digest=@ux]
+$  basis
  [working=basis:editor parent=@uv accepted=(map path lobe:clay) work=(map path lobe:clay)]
+$  admission
  $:  %cantrip-connected-land-admission-v2
      request=command  owner=@p  at=@da  selected=entry:judgment
      current=basis  window=window:law
  ==
+$  history
  $:  %cantrip-connected-land-history-v2
      owner=@p  at=@da  accepted=revision:model
      commit=commit:editor  files=(map path lobe:clay)
  ==
+$  recovery  [current=basis historical=(unit history)]
+$  record
  $:  %cantrip-connected-land-record-v2
      admission=admission  phase=?(%submitted %unknown %applied)
      observation=(unit recovery)
  ==
+$  ledger  (map @ux record)
+$  transition  [next=ledger record=record repeated=? cards=(list card:agent:gall)]
++  command-valid
  |=  c=command
  ^-  ?
  &((nonce-valid:judgment judgment.c) !=(0 digest.c) (lte (met 0 digest.c) 256))
++  permission
  |=  w=window:law
  ^-  ?
  &((~(has in admissible.w) %implement) !(~(has in blocked.w) %implement))
++  blob
  |=  l=lobe:clay
  ^-  @uv
  `@uv`(shax (jam [[~ l] `@uv`0]))
++  basis-valid
  |=  b=basis
  ^-  ?
  ?.  &((basis-valid:editor working.b) !=(0 parent.b))  %.n
  =/  s=snapshot:model  current.working.b
  ?.  ?=(%text -.body.s)  %.n
  =/  names=(set path)  (silt paths:demo)
  ?&  =(names ~(key by accepted.b))  =(names ~(key by work.b))
      =(`(page-to-lobe:clay [%hoon source.body.s]) (~(get by work.b) target:demo))
      =((source-blob:editor source.body.s) blob.s)
      =((~(del by accepted.b) target:demo) (~(del by work.b) target:demo))
      %+  levy  ~(tap by support.working.b)
      |=  [pax=path hash=@uv]
      =/  found  (~(get by work.b) pax)
      ?~(found %.n =(hash (blob u.found)))
  ==
++  select
  ::  The WHOLE ledger must come from Viki, not owner-attributed Graf rows.
  ::  An uncertain newer decision still blocks an older approval. Ties fail.
  |=  [our=@p at=@da held=ledger:judgment c=command]
  ^-  (each entry:judgment @tas)
  ?.  (command-valid c)  [%| %command-invalid]
  =/  valid  (restore:judgment our at held)
  ?:  ?=(%| -.valid)  [%| p.valid]
  =/  found  (~(get by held) judgment.c)
  ?~  found  [%| %judgment-missing]
  =/  e=entry:judgment  u.found
  =/  j=judgment:judgment  judgment.e
  ?.  =(digest.c digest.j)  [%| %judgment-conflict]
  ?.  =(%retained phase.e)  [%| %judgment-not-retained]
  ?.  =(%approve-landing decision.body.j)  [%| %not-approved]
  =/  others=(list entry:judgment)  ~(val by held)
  |-  ^-  (each entry:judgment @tas)
  ?~  others  [%& e]
  =/  other=judgment:judgment  judgment.i.others
  ?:  =(j other)  $(others t.others)
  ?.  =(write.request.record.body.j write.request.record.body.other)
    $(others t.others)
  ?:  (gte judged-at.other judged-at.j)  [%| %judgment-superseded]
  $(others t.others)
++  admission-valid
  |=  a=admission
  ^-  ?
  =/  e=entry:judgment  selected.a
  =/  j=judgment:judgment  judgment.e
  =/  r=record:checks  record.body.j
  =/  s=snapshot:model  current.working.current.a
  ?.  &((command-valid request.a) (entry-valid:judgment e))  %.n
  ?.  &((basis-valid current.a) ?=(%text -.body.s))  %.n
  ?&  =(owner.a operator.body.j)  =(owner.a owner.s)
      =(at.a at.s)  (lte judged-at.j at.a)
      ?~(observed-at.e %.n (lte u.observed-at.e at.a))
      =(%retained phase.e)  =(%approve-landing decision.body.j)
      =(judgment.request.a nonce.body.j)  =(digest.request.a digest.j)
      (passed:judgment r)  (permission window.a)
      =(law.run.r (digest:vcl window.a))
      =(source.order.snapshot.compilation.r source.body.s)
      !=(accepted.current.a work.current.a)
      (fresh-v2:result at.a receipt.snapshot.compilation.r [%& working.current.a])
  ==
++  judge
  ::  observed/stated/own are authenticated only by the owning read path.
  |=  $:  our=@p  actor=@p  at=@da  c=command  held=ledger:judgment
          own=record:checks  observed=observation:checks
          stated=(unit record:itn)  current=basis  window=window:law
      ==
  ^-  (each admission @tas)
  ?.  =(our actor)  [%| %foreign-actor]
  =/  selected  (select our at held c)
  ?:  ?=(%| -.selected)  [%| p.selected]
  =/  r=record:checks  record.body.judgment.p.selected
  ?.  &(=(r own) =(r record.observed))  [%| %checks-mismatch]
  ?.  &(fresh.observed =(~ reason.observed))  [%| %checks-stale]
  ?.  =(`intent.commitment.snapshot.compilation.r stated)  [%| %intent-changed]
  ?.  (permission window)  [%| %landing-not-admitted]
  =/  a=admission
    [%cantrip-connected-land-admission-v2 c our at p.selected current window]
  ?.  (admission-valid a)  [%| %landing-binding-invalid]
  [%& a]
++  historical-confirmed
  |=  [a=admission h=history]
  ^-  ?
  ?.  (admission-valid a)  %.n
  =/  s=snapshot:model  current.working.current.a
  ?&  =(owner.a owner.h)  (gth at.h at.a)
      (revision-valid:model accepted.h)  =(base:demo desk.accepted.h)
      =(+(number.base.s) number.accepted.h)  =(root.work.s root.accepted.h)
      !=(0 id.commit.h)  =(~[parent.current.a] parents.commit.h)
      =(at.a at.commit.h)  =(work.current.a files.h)
  ==
++  fence-valid
  ::  A later canonical read fences synchronous Clay %info; it does not say
  ::  that the write failed. It only permits a DIFFERENT freshly judged act.
  |=  [a=admission b=basis]
  ^-  ?
  =/  s=snapshot:model  current.working.b
  ?&  (basis-valid b)  =(owner.a owner.s)  (gth at.s at.a)
      (gte number.base.s number.base.current.working.current.a)
      (gte number.work.s number.work.current.working.current.a)
  ==
++  record-valid
  |=  r=record
  ^-  ?
  ?.  (admission-valid admission.r)  %.n
  ?~  observation.r  !=(%applied phase.r)
  ?.  (fence-valid admission.r current.u.observation.r)  %.n
  ?:  =(%submitted phase.r)  %.n
  ?~  historical.u.observation.r  =(%unknown phase.r)
  ?&  (historical-confirmed admission.r u.historical.u.observation.r)
      =(%applied phase.r)
      =(at.u.historical.u.observation.r at.current.working.current.u.observation.r)
  ==
++  released
  |=  [r=record at=@da]
  ^-  ?
  ?.  (record-valid r)  %.n
  ?:  =(%applied phase.r)  %.y
  ?~  observation.r  %.n
  &((fence-valid admission.r current.u.observation.r) (lte at.current.working.current.u.observation.r at))
++  ledger-valid
  |=  held=ledger
  ^-  ?
  ?&  (lte ~(wyt by held) 128)
      %+  levy  ~(tap by held)
      |=  [key=@ux r=record]
      &(=(key digest.request.admission.r) (record-valid r))
  ==
++  restore
  ::  Validation and local status only. No write, observation or resubmit.
  |=  [our=@p at=@da held=ledger]
  ^-  (each ledger @tas)
  ?.  (ledger-valid held)  [%| %landing-ledger-invalid]
  ?.  %+  levy  ~(val by held)
      |=  r=record
      ?&  =(our owner.admission.r)  (lte at.admission.r at)
          ?~  observation.r  %.y
          (lte at.current.working.current.u.observation.r at)
      ==
    [%| %landing-owner-or-time-invalid]
  [%& (~(run by held) |=(r=record ?:(=(%submitted phase.r) r(phase %unknown) r)))]
++  lookup
  |=  [our=@p actor=@p at=@da held=ledger c=command]
  ^-  (each (unit record) @tas)
  ?.  =(our actor)  [%| %foreign-actor]
  ?.  (command-valid c)  [%| %command-invalid]
  =/  checked  (restore our at held)
  ?:  ?=(%| -.checked)  [%| p.checked]
  =/  prior  (~(get by held) digest.c)
  ?~  prior  [%& ~]
  ?.  =(c request.admission.u.prior)  [%| %judgment-conflict]
  [%& prior]
++  legacy-ready
  ::  Required at the OLD app command boundary before its existing reserve.
  |=  [our=@p at=@da modern=ledger]
  ^-  ?
  =/  checked  (restore our at modern)
  ?:  ?=(%| -.checked)  %.n
  (levy ~(val by modern) |=(r=record (released r at)))
++  legacy-fenced
  ::  An existing legacy observation can fence a NEW connected landing.
  ::  It remains unknown; this does not alter old reserve/replay semantics.
  ::  Caller must persist the canonical legacy observation it supplies.
  |=  [our=@p at=@da b=basis r=record:legacy]
  ^-  ?
  ?.  &((record-valid:legacy r) =(our actor.admission.r))  %.n
  ?.  (lte at.admission.r at)  %.n
  ?.  ?~(observation.r %.y (lte at.u.observation.r at))  %.n
  ?:  =(%applied status.r)  %.y
  ?.  &((basis-valid b) =(%unknown status.r))  %.n
  ?~  observation.r  %.n
  =/  o=observation:legacy  u.observation.r
  =/  s=snapshot:model  current.working.b
  ?.  ?=(%text -.body.s)  %.n
  ?&  =(our owner.s)  =(at at.s)  =(at at.o)  (gth at.o at.admission.r)
      exists.accepted.current.o  exists.working.current.o
      private.accepted.current.o  private.working.current.o
      =(7 files.accepted.current.o)  =(7 files.working.current.o)
      =(base:demo desk.accepted.current.o)  =(work:demo desk.working.current.o)
      =(number.base.s accepted-number.current.o)  =(number.work.s work-number.current.o)
      =(`root.base.s root.accepted.current.o)  =(`root.work.s root.working.current.o)
      =(`source.body.s working-source.current.o)
      (gte number.base.s number.base.subject.body.judgment.admission.r)
  ==
++  reserve
  |=  [our=@p actor=@p at=@da held=ledger old=ledger:legacy a=admission]
  ^-  (each transition @tas)
  =/  prior  (lookup our actor at held request.a)
  ?:  ?=(%| -.prior)  [%| p.prior]
  ?^  p.prior  [%& [held u.p.prior %.y ~]]
  ?.  &(=(our owner.a) =(at at.a) (admission-valid a))
    [%| %admission-invalid]
  ?.  (ledger-valid:legacy old)  [%| %legacy-ledger-invalid]
  ?.  (levy ~(val by old) |=(r=record:legacy (legacy-fenced our at current.a r)))
    [%| %legacy-landing-unresolved]
  ?.  (legacy-ready our at held)  [%| %landing-unresolved]
  ?:  (gte ~(wyt by held) 128)  [%| %landing-capacity]
  =/  r=record  [%cantrip-connected-land-record-v2 a %submitted ~]
  =/  s=snapshot:model  current.working.current.a
  ?>  ?=(%text -.body.s)
  =/  card=card:agent:gall
    [%pass /connected-land-v2/(scot %ux digest.request.a) %arvo %c [%info base:demo %.y ~[[target:demo %mut %hoon !>(source.body.s)]]]]
  [%& [(~(put by held) digest.request.a r) r %.n ~[card]]]
++  observe
  ::  Historical receipts stay frozen even after both project heads advance.
  |=  [r=record o=recovery]
  ^-  record
  ?.  (record-valid r)  r
  ?:  =(%applied phase.r)  r
  ?.  (fence-valid admission.r current.o)  r
  =/  previous=(unit recovery)  observation.r
  ?:  ?~(previous %.n (lth at.current.working.current.o at.current.working.current.u.previous))  r
  =/  proven=(unit history)
    ?~  historical.o  ~
    ?.  (historical-confirmed admission.r u.historical.o)  ~
    ?.  =(at.u.historical.o at.current.working.current.o)  ~
    historical.o
  r(phase ?~(proven %unknown %applied), observation `o(historical proven))
--
