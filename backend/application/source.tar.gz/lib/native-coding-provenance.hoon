::  Item 35: follow one candidate back through its whole execution path and
::  report, stage by stage, whether the requester, project, source, scope and
::  request ID were carried unchanged. Read-only; every check names what it
::  compared, so a break says where it happened.
::
::  Path: grant (scope) -> tool call record (request) -> tool result ->
::  candidate -> acceptance record -> review decision -> landing.
/-  nc=native-coding
/+  contract=cantrip-native-coding-contract, accept=native-coding-accept,
    project=native-coding-project
|%
+$  check  [stage=@tas carried=? detail=@t]
+$  trail
  $:  candidate=@ux  stage=@tas
      requester=@p  project=@t  request=@ux  session=@ux  source=revision:nc
      grant=@ux  revoked=?
      checks=(list check)
  ==
++  origin
  ::  The tool call whose result produced this candidate, if retained.
  |=  [records=(map @ux record:contract) id=@ux]
  ^-  (unit [key=@ux r=record:contract])
  =/  hits=(list [key=@ux r=record:contract])
    %+  murn  ~(tap by records)
    |=  [k=@ux r=record:contract]
    ^-  (unit [key=@ux r=record:contract])
    ?~  result.r  ~
    =/  out=tool-output:nc  output.u.result.r
    ?.  ?=(%candidate -.out)  ~
    ?.  =(id id.value.out)  ~
    `[k r]
  ?~(hits ~ `i.hits)
++  note
  |=  [stage=@tas ok=? why=@t]
  ^-  check
  [stage ok ?:(ok 'carried' why)]
++  trace
  |=  [tools=organ:contract held=record:accept]
  ^-  trail
  =/  c=context:nc  context.candidate.held
  =/  scope=(unit scope:contract)  (~(get by grants.tools) grant.held)
  =/  from=(unit [key=@ux r=record:contract])  (origin records.tools id.candidate.held)
  =/  grant-checks=(list check)
    ?~  scope  ~[(note %grant %.n 'the grant is no longer retained')]
    =/  g=grant:contract  grant.u.scope
    :~  (note %grant-requester =(actor.g actor.c) 'the grant names another actor')
        (note %grant-session =(session.g session.c) 'the grant names another session')
        (note %grant-project =(id.spec.project.g project.c) 'the grant names another project')
        (note %grant-configuration =((configuration:project project.g) configuration.c) 'the request was made under another project configuration')
    ==
  =/  call-checks=(list check)
    ?~  from  ~[(note %tool-call %.n 'the producing tool call is no longer retained')]
    =/  r=record:contract  r.u.from
    =/  ops=(list operation:nc)  (operations:project arguments.request.r)
    =/  result-context=(unit context:nc)  ?~(result.r ~ `context.u.result.r)
    :~  (note %tool-call-grant =(grant.r grant.held) 'the call ran under another grant')
        (note %tool-call-request =(context.request.r c) 'the call context differs from the candidate context')
        (note %tool-call-key =(key.u.from (key:contract request.r)) 'the call is filed under another request key')
        (note %tool-result =(result-context `c) 'the result names another context')
        ?~  scope  (note %scope %.n 'no grant to compare the operation with')
        (note %scope (levy ops |=(o=operation:nc (~(has in operations.grant.u.scope) o))) 'the call used an operation outside its grant')
    ==
  =/  later-checks=(list check)
    :~  (note %acceptance-project =(id.spec.project.held project.c) 'the acceptance names another project')
        (note %candidate-source =(revision.basis.candidate.held source.c) 'the candidate was built on another source')
        ?~  decision.held  [%review %.y 'not reviewed yet']
        (note %review =(context.u.decision.held c) 'the review judged another context')
        ?.  ?=(%applied stage.held)  [%landing %.y 'not landed']
        (note %landing ?=(^ landed.held) 'applied without a retained landed tree')
    ==
  :*  id.candidate.held  stage.held
      actor.c  project.c  request.c  session.c  source.c
      grant.held  ?~(scope %.n ?=(^ revoked.u.scope))
      ;:(weld grant-checks call-checks later-checks)
  ==
++  broken
  |=  t=trail
  ^-  (list check)
  (skip checks.t |=(k=check carried.k))
::  ---  owner HTTP view
++  json-of
  |=  t=trail
  ^-  json
  %-  pairs:enjs:format
  :~  ['candidate' s+(scot %ux candidate.t)]  ['stage' s+stage.t]
      ['requester' s+(scot %p requester.t)]  ['project' s+project.t]
      ['request' s+(scot %ux request.t)]  ['session' s+(scot %ux session.t)]
      ['source' s+(rap 3 ~[(scot %p owner.source.t) '/' desk.source.t '/' (scot %ud number.source.t)])]
      ['grant' s+(scot %ux grant.t)]  ['grantRevoked' b+revoked.t]
      ['carried' b+=(~ (broken t))]
      :-  'checks'
      :-  %a
      %+  turn  checks.t
      |=(k=check (pairs:enjs:format ~[['stage' s+stage.k] ['carried' b+carried.k] ['detail' s+detail.k]]))
  ==
++  route
  |=  [our=@p src=@p now=@da url=@t]
  ^-  (unit json)
  =/  prefix=@t  '/apps/pataphor-native/coding/provenance'
  =/  n=@ud  (met 3 prefix)
  ?.  =(prefix (end [3 n] url))  ~
  =/  rest=@t  (rsh [3 n] url)
  ?.  |(=('' rest) =('/' (end [3 1] rest)))  ~
  ?.  =(our src)
    `(pairs:enjs:format ~[['schema' s+'native-provenance-v1'] ['available' b+%.n] ['error' s+'owner-required']])
  =/  base=path  /(scot %p our)/cantrip/(scot %da now)
  =/  tools=organ:contract  .^(organ:contract %gx (weld base /native-coding/tool-state/noun))
  =/  held=ledger:accept  .^(ledger:accept %gx (weld base /native-coding/candidate-ledger/noun))
  =/  wanted=(unit @ux)  ?:(=('' rest) ~ (slaw %ux (rsh [3 1] rest)))
  ?:  &(!=('' rest) ?=(~ wanted))
    `(pairs:enjs:format ~[['schema' s+'native-provenance-v1'] ['available' b+%.n] ['error' s+'candidate-invalid']])
  =/  rows=(list trail)
    %+  turn
      ?~  wanted  ~(val by held)
      =/  one  (~(get by held) u.wanted)
      ?~(one ~ ~[u.one])
    |=(r=record:accept (trace tools r))
  =/  intact=@ud  (lent (skim rows |=(t=trail =(~ (broken t)))))
  :-  ~
  %-  pairs:enjs:format
  :~  ['schema' s+'native-provenance-v1']  ['available' b+%.y]
      ['candidates' (numb:enjs:format (lent rows))]  ['carried' (numb:enjs:format intact)]
      ['trails' a+(turn rows json-of)]
  ==
--
