::  Structured boundary for compiled GLS data, using terminal-plan semantics.
::  Does not implement editor decisions. Executable values cannot escape seal.
::  Fuel, scope, memo, argument and returned-node bounds are explicit.
/+  base=terminal-plan, text=native-coding-text,
    profile=native-coding-compiler-profile,
    arithmetic=native-coding-compiler-arithmetic,
    editor-profile=native-coding-editor-profile
|%
+$  plan  plan:base
+$  scope  scope:base
+$  task
  $%  [%force ~]
      [%apply arg=plan]
      [%call args=(list plan)]
      [%match branches=(list plan)]
      [%inc ~]
      [%law-build name=plan body=plan]
      [%pin-build ~]
      [%judge self=plan args=(list plan)]
      [%gte-first right=plan]
      [%gte-last left=@ud]
      [%text-value op=?(%10 %12) left=(unit [size=@ud bytes=@ud]) right=(unit plan)]
      [%text-length op=?(%10 %12) left=(unit [size=@ud bytes=@ud]) right=(unit plan) content=plan]
      [%text-content op=?(%10 %12) left=(unit [size=@ud bytes=@ud]) right=(unit plan) size=@ud]
      [%remember key=[scope=@ud body=plan]]
      [%seal ~]
      [%seal-arg arg=plan]
      [%seal-app fun=plan]
      [%arithmetic op=@tas law=plan self=plan args=(list plan) first=(unit @ud)]
      [%editor stage=@tas law=plan self=plan args=(list plan) pending=plan accumulator=plan]
  ==
+$  result  (each [remaining=@ud output=plan] @tas)
++  compiler-mode
  ::  Versioned execution identity: argument count/shared nodes/atom bits,
  ::  fuel/output nodes, increment bits/word cost, primitive and law policy.
  ::  V3/V4 and prefix V2 bind lexical lets and the retained environment cap.
  [%native-coding-compiler-vm-v3 3 4.300.000 256 2.000.000 1.048.576 262.144 64 %inc %unprofiled %lexical-let 1.057]
++  compiler-fuel-v2  64.000.000
++  compiler-mode-v2
  ::  Entry admission and exact arithmetic-law identity are independent.
  ::  This descriptor binds the larger Nat/fuel/scope/memo limits as well.
  [%native-coding-compiler-vm-v4 3 4.300.000 256 compiler-fuel-v2 1.048.576 attachment-bits:arithmetic 64 %inc identity:profile 1.048.576 262.144 %lexical-let 1.057]
++  prefix-input-nodes  8.600.000
++  prefix-output-nodes  2.097.152
++  prefix-atom-bytes  16.777.216
++  prefix-mode
  ::  Checkpoint fields are constructor DATA, including represented PlanVal
  ::  trees. Actual executable %law/%pin/%delay values remain forbidden.
  [%native-coding-compiler-prefix-vm-v2 3 prefix-input-nodes prefix-output-nodes attachment-bits:arithmetic prefix-atom-bytes compiler-fuel-v2 64 %inc identity:profile 1.048.576 262.144 %lexical-let 1.057]
++  prefix-data-valid
  |=  todo=(list plan)
  ^-  ?
  =/  left=@ud  prefix-input-nodes
  =/  bytes=@ud  prefix-atom-bytes
  |-  ^-  ?
  ?~  todo  %.y
  ?:  =(0 left)  %.n
  =/  p=plan  i.todo
  ?:  ?=(%nat -.p)
    ?.  &((lte (met 0 value.p) attachment-bits:arithmetic) (lte (met 3 value.p) bytes))  %.n
    $(todo t.todo, left (dec left), bytes (sub bytes (met 3 value.p)))
  ?.  ?=(%app -.p)  %.n
  $(todo [fun.p arg.p t.todo], left (dec left))
++  data-valid
  |=  value=plan
  ^-  ?
  (data-list-valid 1.048.576 ~[value])
++  data-list-valid
  |=  [left=@ud todo=(list plan)]
  ^-  ?
  |-  ^-  ?
  ?~  todo  %.y
  ?:  =(0 left)  %.n
  =/  p=plan  i.todo
  ?:  ?=(%nat -.p)
    ?.  (lte (met 0 value.p) 256)  %.n
    $(todo t.todo, left (dec left))
  ?.  ?=(%app -.p)  %.n
  $(todo [fun.p arg.p t.todo], left (dec left))
++  run
  |=  [fuel=@ud artifact=plan args=(list plan)]
  ^-  result
  (run-with fuel artifact args %.n)
++  run-profile
  ::  Assembly alone selects this entry-pinned execution profile. No new
  ::  opcodes or acceleration are made available to arbitrary PLAN programs.
  |=  [fuel=@ud artifact=plan args=(list plan)]
  ^-  result
  (run-with fuel artifact args %.y)
++  run-with
  |=  [fuel=@ud artifact=plan args=(list plan) compiler=?]
  ^-  result
  (run-bound fuel artifact args compiler ~)
++  run-compiler
  ::  The native caller supplies the digest from its canonical owner-admitted
  ::  attachment and enforces the project/source byte limits. Equality here
  ::  proves only that entry join, not authority. Large-Nat increment is
  ::  bounded/charged; no arithmetic law profile or substitutions apply.
  |=  [fuel=@ud expected-entry=@ux artifact=plan args=(list plan)]
  ^-  result
  (run-bound fuel artifact args %.n `expected-entry)
++  run-bound
  |=  [fuel=@ud artifact=plan args=(list plan) compiler=? attachment=(unit @ux)]
  ^-  result
  (run-mode fuel artifact args compiler attachment %.n)
++  run-compiler-v2
  ::  The entry digest must still come from the canonical owner admission.
  ::  Only full tagged laws in the retained allowlist may be accelerated;
  ::  matching a law never asserts this is the old bootstrap compiler entry.
  |=  [fuel=@ud expected-entry=@ux artifact=plan args=(list plan)]
  ^-  result
  (run-mode fuel artifact args %.n `expected-entry %.y)
++  run-mode
  |=  [fuel=@ud artifact=plan args=(list plan) compiler=? attachment=(unit @ux) modern=?]
  ^-  result
  (run-mode-bound fuel artifact args compiler attachment modern %.n)
++  run-prefix
  ::  Native caller supplies only an admitted entry and an authenticated
  ::  retained checkpoint. This pure boundary establishes no provenance.
  |=  [fuel=@ud expected-entry=@ux artifact=plan args=(list plan)]
  ^-  result
  (run-mode-bound fuel artifact args %.n `expected-entry %.y %.y)
++  run-mode-bound
  |=  [fuel=@ud artifact=plan args=(list plan) compiler=? attachment=(unit @ux) modern=? prefix=?]
  ^-  result
  (run-mode-profile fuel artifact args compiler attachment modern prefix %.n)
++  run-editor
  ::  Only the four byte-exact retained entries may select these helper jets.
  ::  The owner-installed bundle and all saved editor nouns remain unchanged.
  |=  [fuel=@ud artifact=plan args=(list plan)]
  ^-  result
  (run-mode-profile fuel artifact args %.n ~ %.n %.n %.y)
++  editor-entry-valid
  ::  Profile policy only; installation and session authority stay native.
  |=  [artifact=plan count=@ud]
  ^-  ?
  (admits:editor-profile artifact count)
++  run-mode-profile
  |=  [fuel=@ud artifact=plan args=(list plan) compiler=? attachment=(unit @ux) modern=? prefix=? editor=?]
  ^-  result
  ?:  &(editor |(compiler ?=(^ attachment) modern prefix))  [%| %editor-profile-mode-refused]
  ?:  &(editor !(editor-entry-valid artifact (lent args)))  [%| %editor-profile-entry-refused]
  ?:  &(prefix !modern)  [%| %compiler-prefix-mode-refused]
  ?:  &(modern |(compiler ?=(~ attachment)))  [%| %compiler-attachment-refused]
  ?:  |(=(0 fuel) (gth fuel ?:(modern compiler-fuel-v2 2.000.000)))  [%| %fuel-bound]
  ?.  &((lte (lent args) 8) (artifact-valid:base artifact))  [%| %artifact-bound]
  =/  matched=?
    ?~  attachment  %.y
    ?&  !compiler
        !=(0 u.attachment)
        =(u.attachment (shax (jam artifact)))
        =([~ 3] (arity:base artifact))
    ==
  ?.  matched  [%| %compiler-attachment-refused]
  =/  bounded=?
    ?~  attachment  (levy args data-valid)
    &(=(3 (lent args)) ?:(prefix (prefix-data-valid args) (data-list-valid 4.300.000 args)))
  ?.  bounded  [%| %argument-bound]
  =/  enabled=(unit @ux)  ?:(modern `identity:profile ?:(compiler (prepare:profile artifact) ~))
  ?:  &(compiler ?=(~ enabled))  [%| %compiler-profile-entry-refused]
  =/  arithmetic-limit=@ud  ?:(modern attachment-bits:arithmetic bits:arithmetic)
  =/  accelerated=(map plan @tas)  ~
  =/  current=plan  artifact
  =/  tasks=(list task)
    %+  weld  `(list task)`~[[%force ~]]
    %+  weld  (turn args |=(p=plan ^-(task [%apply p])))
              `(list task)`~[[%seal ~]]
  =/  scopes=(map @ud scope)  ~
  =/  memo=(map [scope=@ud body=plan] plan)  ~
  =/  memo-writes=@ud  0
  =/  next=@ud  1
  =/  sealed=@ud  0
  =/  sealed-bytes=@ud  prefix-atom-bytes
  |-
  ?:  =(~ tasks)
    [%& fuel current]
  ?:  =(0 fuel)  [%| %fuel-exhausted]
  =.  fuel  (dec fuel)
  =/  todo  (snag 0 tasks)
  =.  tasks  (slag 1 tasks)
  ?-  -.todo
    %force
      ?+  -.current  $(tasks tasks)
        %app
          $(current fun.current, tasks [[%force ~] [%apply arg.current] tasks])
        %delay
          =/  key=[scope=@ud body=plan]  [scope.current body.current]
          =/  known  (~(get by memo) key)
          ?^  known  $(current u.known)
          =.  tasks  [[%remember key] tasks]
          =/  found  (~(get by scopes) scope.current)
          ?~  found  [%| %missing-scope]
          =/  body  body.current
          ?:  ?=(%nat -.body)
            ?:  (gth value.body count.u.found)
              $(current body)
            $(current (snag value.body values.u.found), tasks [[%force ~] tasks])
          ::  A local binding can occur inside a branch or argument too.
          ::  Extend its lexical scope; quoted data never enters this path.
          ?:  ?=([%app [%app [%nat %1] *] *] body)
            ?:  (gth next ?:(modern 1.048.576 131.072))  [%| %scope-bound]
            =/  split  (lets:base body)
            ?~  split  [%| %let-bound]
            =/  env=(list plan)
              (weld values.u.found (turn bindings.u.split |=(p=plan ^-(plan [%delay next p]))))
            ::  Existing laws admit 32 arguments plus 1,024 local bindings.
            ?:  (gth (lent env) 1.057)  [%| %environment-bound]
            =.  scopes  (~(put by scopes) next [(dec (lent env)) env])
            $(current [%delay next tail.u.split], next +(next), tasks [[%force ~] tasks])
          ?:  ?=([%app [%app [%nat %0] *] *] body)
            $(current [%delay scope.current arg.fun.body], tasks [[%force ~] [%apply [%delay scope.current arg.body]] tasks])
          ?:  ?=([%app [%nat %0] *] body)
            $(current arg.body, tasks [[%force ~] tasks])
          $(current body, tasks [[%force ~] tasks])
      ==
    %apply
      =/  a  (arity:base current)
      ?~  a  [%| %application-bound]
      ?:  =(1 u.a)  $(tasks [[%call ~[arg.todo]] tasks])
      $(current [%app current arg.todo])
    %call
      ?:  ?=(%app -.current)
        $(current fun.current, tasks [[%call [arg.current args.todo]] tasks])
      =/  head=plan  ?:(?=(%pin -.current) item.current current)
      ?:  ?=(%law -.head)
        ?:  !=(arity.head (lent args.todo))  [%| %law-arity]
        ?:  editor
          =/  known=(unit @tas)  (~(get by accelerated) head)
          ?~  known
            =/  looked  (lookup:editor-profile head)
            ?:  (lth fuel cost.looked)  [%| %fuel-exhausted]
            =.  fuel  (sub fuel cost.looked)
            ::  Cache misses too: the complete source has many plain laws.
            =/  selected=@tas  ?~(found.looked %none u.found.looked)
            =.  accelerated  (~(put by accelerated) head selected)
            $(tasks [[%call args.todo] tasks])
          ?:  =(%none u.known)
            $(current body.head, tasks [[%force ~] [%judge current args.todo] tasks])
          =/  op=@tas  u.known
          =/  first=@ud  ?:(=(op %bounded) 1 0)
          =/  pending=plan
            ?:  =(op %bounded)  (snag 0 args.todo)
            ?:  =(op %eq)  (snag 1 args.todo)
            [%nat 0]
          =/  accumulator=plan  ?:(=(op %rev) (snag 1 args.todo) [%nat 0])
          $(current (snag first args.todo), tasks [[%force ~] [%editor op head current args.todo pending accumulator] tasks])
        ?^  enabled
          =/  known=(unit @tas)  (~(get by accelerated) head)
          ?~  known
            =/  looked  (lookup:profile u.enabled head)
            ?:  (lth fuel cost.looked)  [%| %fuel-exhausted]
            =.  fuel  (sub fuel cost.looked)
            =/  selected=(unit @tas)  found.looked
            ?^  selected
              =.  accelerated  (~(put by accelerated) head u.selected)
              $(current (snag (first:arithmetic u.selected) args.todo), tasks [[%force ~] [%arithmetic u.selected head current args.todo ~] tasks])
            $(current body.head, tasks [[%force ~] [%judge current args.todo] tasks])
          $(current (snag (first:arithmetic u.known) args.todo), tasks [[%force ~] [%arithmetic u.known head current args.todo ~] tasks])
        $(current body.head, tasks [[%force ~] [%judge current args.todo] tasks])
      ?:  !&(?=(%pin -.current) ?=(%nat -.head))
        [%| %not-executable]
      =/  a  args.todo
      ?+  value.head  [%| %unknown-opcode]
        %0
          ?:  !=(1 (lent a))  [%| %opcode-arity]
          $(current (snag 0 a), tasks [[%force ~] [%pin-build ~] tasks])
        %4
          ?:  !=(1 (lent a))  [%| %opcode-arity]
          $(current (snag 0 a), tasks [[%force ~] [%pin-build ~] tasks])
        %1
          ?:  !=(3 (lent a))  [%| %opcode-arity]
          $(current (snag 1 a), tasks [[%force ~] [%law-build (snag 0 a) (snag 2 a)] tasks])
        %2
          ?:  !=(1 (lent a))  [%| %opcode-arity]
          $(current (snag 0 a), tasks [[%force ~] [%inc ~] tasks])
        %3
          ?:  !=(6 (lent a))  [%| %opcode-arity]
          $(current (snag 5 a), tasks [[%force ~] [%match a] tasks])
        ?(%10 %12)
          ?:  !=(2 (lent a))  [%| %opcode-arity]
          $(current (snag 0 a), tasks [[%force ~] [%text-value value.head ~ `(snag 1 a)] tasks])
        %11
          ?:  !=(2 (lent a))  [%| %opcode-arity]
          $(current (snag 0 a), tasks [[%force ~] [%gte-first (snag 1 a)] tasks])
      ==
    %judge
      ?:  (gth next ?:(modern 1.048.576 131.072))  [%| %scope-bound]
      =/  split  (lets:base current)
      ?~  split  [%| %let-bound]
      =/  env=(list plan)  [self.todo args.todo]
      =.  env
        (weld env (turn bindings.u.split |=(p=plan ^-(plan [%delay next p]))))
      =.  scopes  (~(put by scopes) next [(dec (lent env)) env])
      $(current [%delay next tail.u.split], next +(next), tasks [[%force ~] tasks])
    %pin-build
      $(current [%pin current])
    %remember
      ?:  (gte memo-writes ?:(modern 262.144 65.536))  $(tasks tasks)
      $(memo (~(put by memo) key.todo current), memo-writes +(memo-writes))
    %seal
      ?:  (gte sealed ?:(prefix prefix-output-nodes 1.048.576))  [%| %value-bound]
      =.  sealed  +(sealed)
      ?:  ?=(%nat -.current)
        ?:  (gth (met 0 value.current) ?:(prefix attachment-bits:arithmetic 256))
          [%| %value-bound]
        ?:  prefix
          =/  size=@ud  (met 3 value.current)
          ?:  (gth size sealed-bytes)  [%| %value-bound]
          =/  cost=@ud  +((met 6 value.current))
          ?:  (lth fuel cost)  [%| %fuel-exhausted]
          $(tasks tasks, fuel (sub fuel cost), sealed-bytes (sub sealed-bytes size))
        $(tasks tasks)
      ?.  ?=(%app -.current)  [%| %executable-result]
      $(current fun.current, tasks [[%force ~] [%seal ~] [%seal-arg arg.current] tasks])
    %seal-arg
      $(current arg.todo, tasks [[%force ~] [%seal ~] [%seal-app current] tasks])
    %seal-app
      $(current [%app fun.todo current])
    %inc
      =/  n=@ud  ?:(?=(%nat -.current) value.current 0)
      ::  Primitive increment's bounded mechanics are independent of the
      ::  exact-law acceleration table, which remains gated only by enabled.
      ?:  |(?=(^ attachment) ?=(^ enabled))
        =/  done  (run-bounded:arithmetic %inc n 0 fuel arithmetic-limit)
        ?:  ?=(%| -.done)  [%| p.done]
        $(current [%nat value.p.done], fuel remaining.p.done)
      ?:  (gte n 4.294.967.295)  [%| %scalar-bound]
      $(current [%nat +(n)])
    %arithmetic
      ::  Demand operands in source order; preserve short-circuit branches.
      ::  A non-Nat returns to the complete original law, never coerces to 0.
      ?>  ?=(%law -.law.todo)
      ?.  ?=(%nat -.current)
        $(current body.law.todo, tasks [[%force ~] [%judge self.todo args.todo] tasks])
      =/  position=@ud  (first:arithmetic op.todo)
      ?~  first.todo
        ?:  |((unary:arithmetic op.todo) (short:arithmetic op.todo value.current))
          =/  x=@ud  ?:(=(0 position) value.current 0)
          =/  y=@ud  ?:(=(1 position) value.current 0)
          =/  done  (run-bounded:arithmetic op.todo x y fuel arithmetic-limit)
          ?:  ?=(%| -.done)  [%| p.done]
          $(current [%nat value.p.done], fuel remaining.p.done)
        $(current (snag (sub 1 position) args.todo), tasks [[%force ~] [%arithmetic op.todo law.todo self.todo args.todo `value.current] tasks])
      =/  x=@ud  ?:(=(0 position) u.first.todo value.current)
      =/  y=@ud  ?:(=(1 position) u.first.todo value.current)
      =/  done  (run-bounded:arithmetic op.todo x y fuel arithmetic-limit)
      ?:  ?=(%| -.done)  [%| p.done]
      $(current [%nat value.p.done], fuel remaining.p.done)
    %editor
      ::  Helpers force only what their exact GLS law demands. In particular,
      ::  rev never evaluates element heads or its accumulator, bounded reads
      ::  the list before its count, and valid_line stops at the first refusal.
      ::  Unexpected shapes return to the complete original law and arguments.
      ?>  ?=(%law -.law.todo)
      ?+  stage.todo  !!
        %rev
          ?:  =([%nat 0] current)
            $(current accumulator.todo, tasks [[%force ~] tasks])
          ?.  ?=([%app [%app [%nat %1] *] *] current)
            $(current body.law.todo, tasks [[%force ~] [%judge self.todo args.todo] tasks])
          =/  reversed=plan  [%app [%app [%nat 1] arg.fun.current] accumulator.todo]
          $(current arg.current, tasks [[%force ~] todo(accumulator reversed) tasks])
        %bounded
          ?:  =([%nat 0] current)  $(current [%nat 1])
          ?.  ?=([%app [%app [%nat %1] *] *] current)
            $(current body.law.todo, tasks [[%force ~] [%judge self.todo args.todo] tasks])
          $(current pending.todo, tasks [[%force ~] todo(stage %count, pending arg.current) tasks])
        %count
          ?.  ?=(%nat -.current)
            $(current body.law.todo, tasks [[%force ~] [%judge self.todo args.todo] tasks])
          ?:  =(0 value.current)  $(current [%nat 0])
          $(current pending.todo, tasks [[%force ~] todo(stage %bounded, pending [%nat (dec value.current)]) tasks])
        %valid-line
          ?:  =([%nat 0] current)  $(current [%nat 1])
          ?.  ?=([%app [%app [%nat %1] *] *] current)
            $(current body.law.todo, tasks [[%force ~] [%judge self.todo args.todo] tasks])
          $(current arg.fun.current, tasks [[%force ~] todo(stage %valid-scalar, pending arg.current) tasks])
        %valid-scalar
          ?.  ?=(%nat -.current)
            $(current body.law.todo, tasks [[%force ~] [%judge self.todo args.todo] tasks])
          ?:  !(scalar:editor-profile value.current)  $(current [%nat 0])
          $(current pending.todo, tasks [[%force ~] todo(stage %valid-line) tasks])
        %scalar
          ?.  ?=(%nat -.current)
            $(current body.law.todo, tasks [[%force ~] [%judge self.todo args.todo] tasks])
          $(current [%nat ?:((scalar:editor-profile value.current) 1 0)])
        %eq
          ?.  ?=(%nat -.current)
            $(current body.law.todo, tasks [[%force ~] [%judge self.todo args.todo] tasks])
          $(current pending.todo, tasks [[%force ~] todo(stage %eq-last, accumulator current) tasks])
        %eq-last
          ?.  ?=(%nat -.current)
            $(current body.law.todo, tasks [[%force ~] [%judge self.todo args.todo] tasks])
          $(current [%nat ?:(=(current accumulator.todo) 1 0)])
      ==
    %gte-first
      =/  n=@ud  ?:(?=(%nat -.current) value.current 0)
      $(current right.todo, tasks [[%force ~] [%gte-last n] tasks])
    %gte-last
      =/  n=@ud  ?:(?=(%nat -.current) value.current 0)
      $(current [%nat ?:((gte left.todo n) 1 0)])
    %text-value
      ?.  ?=(%app -.current)  [%| %text-shape]
      $(current fun.current, tasks [[%force ~] [%text-length op.todo left.todo right.todo arg.current] tasks])
    %text-length
      ?.  ?=(%nat -.current)  [%| %text-shape]
      ?:  (gth value.current byte-limit:text)  [%| %text-bound]
      $(current content.todo, tasks [[%force ~] [%text-content op.todo left.todo right.todo value.current] tasks])
    %text-content
      ?.  ?=(%nat -.current)  [%| %text-shape]
      =/  part=[size=@ud bytes=@ud]  [size.todo value.current]
      ?.  (valid:text part)  [%| %text-bound]
      ?^  right.todo
        $(current u.right.todo, tasks [[%force ~] [%text-value op.todo `part ~] tasks])
      ?~  left.todo  [%| %text-shape]
      ::  Charge both byte spans before native concatenation/comparison.
      =/  cost=@ud  (add size.u.left.todo size.part)
      ?:  (lth fuel cost)  [%| %fuel-exhausted]
      =.  fuel  (sub fuel cost)
      =/  combined  (combine:text op.todo u.left.todo part)
      ?:  ?=(%| -.combined)  [%| p.combined]
      ?:  ?=(%boolean -.p.combined)
        $(current [%nat ?:(value.p.combined 1 0)])
      $(current [%app [%nat size.p.combined] [%nat bytes.p.combined]])
    %law-build
      =/  n=@ud  ?:(?=(%nat -.current) value.current 0)
      ?:  |(=(0 n) (gth n 32))  [%| %law-arity]
      $(current [%law n name.todo body.todo])
    %match
      =/  a  branches.todo
      ?-  -.current
        %nat
          ?:  =(0 value.current)
            $(current (snag 3 a), tasks [[%force ~] tasks])
          $(current (snag 4 a), tasks [[%force ~] [%apply [%nat (dec value.current)]] tasks])
        %pin
          $(current (snag 0 a), tasks [[%force ~] [%apply item.current] tasks])
        %law
          $(current (snag 1 a), tasks [[%force ~] [%apply [%nat arity.current]] [%apply name.current] [%apply body.current] tasks])
        %app
          $(current (snag 2 a), tasks [[%force ~] [%apply fun.current] [%apply arg.current] tasks])
        %delay  [%| %unforced-match]
      ==
  ==
--
