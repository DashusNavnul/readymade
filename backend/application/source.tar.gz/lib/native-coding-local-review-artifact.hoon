::  Canonical receiver snapshot for proposal review, never execution authority.
::  No provider credentials, executable cores, remote-online or future-law claims.
/-  nc=native-coding, rp=readymade-pact, r=readymade-artifact-round,
    pkg=readymade-package
/+  ex=readymade-artifact-executor, types=readymade-artifact-executor-types,
    pact=readymade-pact, round=readymade-artifact-round,
    package=readymade-package, build=readymade-package-build,
    project=native-coding-project, files=native-coding-files,
    sessions=native-coding-session
|%
+$  binding
  $:  %native-artifact-review-binding-v1
      observed-at=@da  execution=entry:ex  agreement=state:rp
      approvals=state:r  scope-text=@t  result=tool-result:nc
  ==
++  valid
  ::  Pure consistency over the native capture. Authentication is +capture.
  |=  [p=project:nc c=candidate:nc value=binding]
  ^-  ?
  =/  held=entry:ex  execution.value
  =/  cmd=command:ex  command.held
  =/  proposal=proposal:r  proposal.selection.held
  =/  receipt=receipt:build  receipt.selection.held
  ?.  ?=(%land -.target.proposal)  %.n
  ?.  ?=([* ~] edits.c)  %.n
  ?.  ?=([* ~] files.body.offer.plan.body.receipt)  %.n
  =/  edit=edit:nc  i.edits.c
  ?~  content.edit  %.n
  =/  file=file:pkg  i.files.body.offer.plan.body.receipt
  =/  current=state:rp  agreement.value
  ?&  !=(0 observed-at.value)  (lte (met 0 observed-at.value) 128)
      (lte (met 3 (jam value)) 131.072)
      (entry-valid:types owner.cmd held)
      ?=(?(%pending %uncertain) phase.held)
      ?~(candidate.held %.y =(id.c u.candidate.held))
      (gte observed-at.value at.held)
      !=('' scope-text.value)  (lte (met 3 scope-text.value) 16.384)
      =((shax scope-text.value) scope.terms.current)
      (ready:round approvals.value current selected.cmd)
      =(`proposal proposal.approvals.value)
      =(pact.cmd (digest:pact terms.current))
      =(package.proposal package.terms.current)
      =(project.context.c id.spec.p)
      =(configuration.context.c (configuration:project p))
      =(owner.cmd authority.spec.p)
      |(&(=(owner.cmd left.terms.current) =(peer.cmd right.terms.current)) &(=(owner.cmd right.terms.current) =(peer.cmd left.terms.current)))
      =(session.cmd session.context.c)
      =((key:ex cmd) request.context.c)
      =(owner.cmd actor.context.c)
      =(source.context.c revision.basis.c)
      =(owner.cmd owner.source.context.c)
      =(working.p desk.target.proposal)
      =(desk.target.proposal desk.source.context.c)
      =(revision.target.proposal number.source.context.c)
      =(`@`root.target.proposal `@`root.source.context.c)
      (candidate-valid:files p c)
      (candidate-result-matches:ex held c result.value)
      =(file.target.proposal path.change.edit)
      =(before.change.edit (~(get by files.body.snapshot.basis.c) path.change.edit))
      =(%hoon mark.u.content.edit)
      =(file (source-file:package path.file source.u.content.edit))
  ==
++  capture
  ::  Only a unique canonical candidate tool result can select V5. A marked
  ::  origin never falls back to V4 when a native join refuses or is missing.
  |=  [our=@p now=@da p=project:nc c=candidate:nc e=entry:sessions]
  ^-  (each (unit binding) @tas)
  =/  marked=?
    %+  lien  records.e
    |=  row=record:sessions
    ^-  ?
    ?.  ?=(%tool -.body.row)  %.n
    =/  result=tool-result:nc  result.body.row
    ?.  (marked:ex call-id.result)  %.n
    ?:  =(context.c context.result)  %.y
    ?.  ?=(%candidate -.output.result)  %.n
    =(id.c id.value.output.result)
  =/  native  (read-context:ex our now request.context.c)
  ?:  ?=(%| -.native)
    ?:  marked  [%| p.native]
    ?.  ?=(?(%collaboration-unavailable %executor-capability-unavailable %executor-request-missing) p.native)
      [%| p.native]
    [%& ~]
  =/  held=context:ex  p.native
  =/  causal  (candidate-evidence:ex entry.held c id.session.e owner.session.e sequence.e records.e)
  ?~  causal  [%| %local-review-artifact-causal-mismatch]
  =/  result=tool-result:nc  u.causal
  =/  chosen  (select:ex our command.entry.held previous.held)
  ?:  ?=(%| -.chosen)  [%| p.chosen]
  ?.  =(p.chosen selection.entry.held)  [%| %local-review-artifact-selection-changed]
  =/  current  (current:project our now p)
  ?:  ?=(%| -.current)  [%| p.current]
  ?.  =(basis.c working.p.current)  [%| %local-review-artifact-basis-changed]
  =/  expected  (tool-arguments:ex our now held p working.p.current)
  ?:  ?=(%| -.expected)  [%| p.expected]
  ?.  ?=([* ~] edits.c)  [%| %local-review-artifact-edits-mismatch]
  =/  edit=edit:nc  i.edits.c
  ?~  content.edit  [%| %local-review-artifact-content-missing]
  =/  actual=tool-args:nc
    ?~  before.change.edit  [%create path.change.edit u.content.edit]
    [%replace path.change.edit u.before.change.edit u.content.edit]
  ?.  =(actual p.expected)  [%| %local-review-artifact-body-mismatch]
  =/  cmd=command:ex  command.entry.held
  =/  agreement  (~(get by pacts.state.previous.held) pact.cmd)
  ?~  agreement  [%| %local-review-artifact-pact-missing]
  =/  approvals
    (~(get by rounds.artifacts.previous.held) [pact.cmd generation.value.u.agreement %land])
  ?~  approvals  [%| %local-review-artifact-round-missing]
  =/  value=binding
    [%native-artifact-review-binding-v1 now entry.held value.u.agreement u.approvals text.u.agreement result]
  ?.  (valid p c value)  [%| %local-review-artifact-binding-invalid]
  [%& `value]
++  ack-json
  |=  ack=(unit evidence:r)
  ^-  ^json
  ?~  ack  ~
  (pairs:enjs:format ~[['observedLaw' s+(scot %ux law.u.ack)] ['explicitOwnerAuthorization' s+(scot %ux authorization.u.ack)]])
++  json
  |=  value=binding
  ^-  ^json
  =/  held=entry:ex  execution.value
  =/  cmd=command:ex  command.held
  =/  proposal=proposal:r  proposal.selection.held
  =/  receipt=receipt:build  receipt.selection.held
  =/  terms=terms:rp  terms.agreement.value
  =/  plan=plan:build  plan.body.receipt
  =/  offer=offer:pkg  offer.plan
  =/  target=target:r  target.proposal
  ?>  ?=(%land -.target)
  ?>  ?=([* ~] files.body.offer)
  =/  file=file:pkg  i.files.body.offer
  =/  candidate=candidate:nc
    ?>  ?=(%candidate -.output.result.value)
    value.output.result.value
  =/  edit=edit:nc
    ?>  ?=([* ~] edits.candidate)
    i.edits.candidate
  %-  pairs:enjs:format
  :~  ['schema' s+'native-artifact-review-binding-v1']
      ['observedAt' s+(scot %da observed-at.value)]
      ['owner' s+(scot %p owner.cmd)]
      ['peer' s+(scot %p peer.cmd)]
      ['commandRequest' s+request.cmd]
      ['commandDigest' s+(scot %ux (key:ex cmd))]
      ['session' s+(scot %ux session.cmd)]
      ['callId' s+call-id.result.value]
      ['candidateResultDigest' s+(scot %ux (shax (jam result.value)))]
      ['pact' s+(scot %ux pact.cmd)]
      ['agreementText' s+scope-text.value]
      ['pactProject' s+project.terms]
      ['pactLeft' s+(scot %p left.terms)]
      ['pactRight' s+(scot %p right.terms)]
      ['pactPackage' s+(scot %ux package.terms)]
      ['pactGrafRoot' s+(scot %ux graf-root.terms)]
      ['pactScope' s+(scot %ux scope.terms)]
      ['pactPolicy' s+(scot %ux policy.terms)]
      ['pactNonce' s+(scot %ux nonce.terms)]
      ['storedLeftConsent' b+left-consent.agreement.value]
      ['storedRightConsent' b+right-consent.agreement.value]
      ['pactGeneration' (numb:enjs:format generation.agreement.value)]
      ['selectedProposal' s+(scot %ux selected.cmd)]
      ['round' (numb:enjs:format round.proposal)]
      ['roundGeneration' (numb:enjs:format generation.proposal)]
      ['leftAck' (ack-json left-ack.approvals.value)]
      ['rightAck' (ack-json right-ack.approvals.value)]
      ['leftClosed' b+left-close.approvals.value]
      ['rightClosed' b+right-close.approvals.value]
      ['package' s+(scot %ux package.proposal)]
      ['artifact' s+(scot %ux artifact.proposal)]
      ['receiverBuildProof' s+(scot %ux proof.receipt)]
      ['sender' s+(scot %p sender.body.offer)]
      ['senderSourceOwner' s+(scot %p ship.source.body.offer)]
      ['senderSourceDesk' s+(scot %tas desk.source.body.offer)]
      ['senderSourceRevision' (numb:enjs:format revision.source.body.offer)]
      ['senderSourceRoot' s+(scot %uv root.source.body.offer)]
      ['receiverBuildDesk' s+(scot %tas destination.plan)]
      ['receiverBuildRevision' (numb:enjs:format revision.plan)]
      ['receiverBuildRoot' s+(scot %uv root.plan)]
      ['targetShip' s+(scot %p ship.target)]
      ['targetDesk' s+(scot %tas desk.target)]
      ['targetRevision' (numb:enjs:format revision.target)]
      ['targetRoot' s+(scot %ux root.target)]
      ['targetFile' s+(spat file.target)]
      ['receivedFile' s+(spat path.file)]
      ['receivedFileHash' s+(scot %ux hash.file)]
      ['receivedFileBytes' (numb:enjs:format size.file)]
      ['candidate' s+(scot %ux id.candidate)]
      ['causalCandidateMatches' b+(candidate-result-matches:ex held candidate result.value)]
      ['bothStoredOwnerApprovalsMatch' b+(ready:round approvals.value agreement.value selected.cmd)]
      ['candidateAfterMatchesReceivedSource' b+?~(content.edit %.n =(file (source-file:package path.file source.u.content.edit)))]
      ['candidateBeforeMatchesBasis' b+=(before.change.edit (~(get by files.body.snapshot.basis.candidate) path.change.edit))]
      ['evidenceBoundary' s+'Captured from the receiver native executor journal, complete causal coding journal, current stored bilateral pact/round acknowledgments and canonical receiver build/source. The frozen artifact commits all typed values. Stored peer acknowledgments are receiver observations, not a claim that the peer is online now. This is proposal provenance only: current Cantrip law, standing grant, source/stage checks and landing/readback remain mandatory future guards.']
  ==
--
