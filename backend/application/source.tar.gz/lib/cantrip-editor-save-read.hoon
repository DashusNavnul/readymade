::  Canonical same-event reads for a future Cantrip owner-save handler.
::  No writes, caller-supplied permission, model receipts or Graf authority.
/+  save=cantrip-editor-save, editor=pataphor-editor-read,
    demo=vibecoding-demo, dsr=desk-shell-read
|%
++  support-at
  |=  [our=@p at=@da]
  ^-  support:save
  %-  ~(gas by *(map path @uv))
  %+  turn  `(list path)`[guard:demo support:demo]
  |=  pax=path
  [pax .^(@uv %cz (beam:dsr our at work:demo pax))]
++  read
  |=  [our=@p actor=@p at=@da]
  ^-  (each basis:save @tas)
  ?.  =(our actor)  [%| %foreign-actor]
  =/  current  (file:editor our actor at work:demo target:demo)
  ?:  ?=(%| -.current)  [%| p.current]
  =/  a=snapshot:demo  (read:demo our at base:demo)
  =/  w=snapshot:demo  (read:demo our at work:demo)
  ?.  &(exists.a exists.w private.a private.w =(7 files.a) =(7 files.w))
    [%| %project-not-private]
  =/  domes=cone:clay  .^(cone:clay %cx /(scot %p our)//(scot %da at)/domes)
  =/  domo=dome:clay  (need (~(get by domes) [our work:demo]))
  =/  parent=(unit tako:clay)  (~(get by hit.domo) let.domo)
  ?~  parent  [%| %parent-missing]
  =/  b=basis:save  [p.current (support-at our at) u.parent]
  ?.  (basis-valid:save b)  [%| %basis-invalid]
  [%& b]
++  observe
  |=  [our=@p actor=@p at=@da r=record:save]
  ^-  (unit recovery:save)
  ?.  &((record-valid:save r) =(our actor) =(our owner.change.admission.r))  ~
  =/  b  (read our actor at)
  ?:  ?=(%| -.b)  ~
  ?.  (fence-valid:save admission.r p.b)  ~
  `[p.b (history our at admission.r)]
++  pin
  |=  [our=@p number=@ud pax=path]
  ^-  path
  (weld ~[(scot %p our) work:demo (scot %ud number)] pax)
++  history
  ::  Called only after the owner's current private-project read succeeds.
  ::  Read immutable commit metadata and hashes, not old/tombstoned blobs.
  ::  The source bytes come from the admission and must match Clay's hash.
  |=  [our=@p at=@da a=admission:save]
  ^-  (unit historical:save)
  =/  domes=cone:clay  .^(cone:clay %cx /(scot %p our)//(scot %da at)/domes)
  =/  d=dome:clay  (need (~(get by domes) [our work:demo]))
  =/  number=@ud  +(number.work.current.basis.a)
  =/  selected=(unit tako:clay)  (~(get by hit.d) number)
  ?~  selected  ~
  =/  y=yaki:clay
    .^(yaki:clay %cs (beam:dsr our at work:demo /yaki/(scot %uv u.selected)))
  ?.  =((silt paths:demo) ~(key by q.y))  ~
  =/  hashes=support:save
    %-  ~(gas by *(map path @uv))
    %+  turn  `(list path)`[guard:demo support:demo]
    |=  pax=path
    [pax .^(@uv %cz (pin our number pax))]
  =/  h=historical:save
    :*  %cantrip-editor-save-history-v1
        our  at
        [work:demo number .^(@uv %cz (pin our number /))]
        target:demo  .^(@uv %cz (pin our number target:demo))
        [%text replacement.change.a (shax replacement.change.a)]
        hashes  [u.selected p.y t.y]  ~(key by q.y)
    ==
  ?.  (historical-confirmed:save a h)  ~
  `h
--
