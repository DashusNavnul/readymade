::  Cantrip-owned prefix programs and compiler receipts. Public owner commands
::  never contain checkpoint bytes or compiler results. Only the authenticated
::  native job-result adapter may call retain. Loading has no effects.
/-  nc=native-coding
/+  core=native-coding-compiler-prefix, compiler=native-coding-compiler,
    exports=native-coding-compiler-exports, old=native-coding-compiler-runtime,
    tools=cantrip-native-coding, project=native-coding-project,
    vm=native-coding-terminal-plan
|%
+$  key  [configuration=@ux target=@tas]
+$  choice  [selection=selection:exports program=@ux enabled=?]
+$  organ
  [%native-coding-compiler-prefix-state-v1 programs=(map @ux program:core) revoked=(set @ux) choices=(map key choice) results=(map @ux retained:core)]
+$  prepared  [request=request:core prior=(unit retained:core)]
+$  current  [job=job:compiler choice=choice scope=scope:tools]
+$  command
  $%  [%native-coding-compiler-prefix-admit-v1 value=program:core]
      [%native-coding-compiler-prefix-revoke-v1 id=@ux]
      [%native-coding-compiler-prefix-select-v1 selection=selection:exports program=@ux]
      [%native-coding-compiler-prefix-unselect-v1 configuration=@ux target=@tas]
  ==
++  empty  `organ`[%native-coding-compiler-prefix-state-v1 ~ ~ ~ ~]
++  capacity  32
++  byte-limit  134.217.728
++  bounded
  |=  s=organ
  ^-  ?
  &((lte ~(wyt by programs.s) 8) (lte ~(wyt in revoked.s) 8) (lte ~(wyt by choices.s) 128) (lte ~(wyt by results.s) capacity) (lte (met 3 (jam s)) byte-limit))
++  key-for
  |=  selection=selection:exports
  ^-  key
  [(configuration:project project.selection) name.target.selection]
++  lookup
  |=  [s=organ j=job:compiler]
  ^-  (unit (each choice @tas))
  =/  found  (~(get by choices.s) [(configuration:project project.j) name.target.j])
  ?~  found  ~
  ?.  enabled.u.found  `[%| %compiler-prefix-selection-revoked]
  ?:  (~(has in revoked.s) program.u.found)  `[%| %compiler-prefix-program-revoked]
  =/  program  (~(get by programs.s) program.u.found)
  ?~  program  `[%| %compiler-prefix-program-missing]
  ?.  &(=(project.j project.selection.u.found) =(target.j target.selection.u.found) =(program.u.found digest.u.program) (program-valid:core u.program))
    `[%| %compiler-prefix-selection-invalid]
  `[%& u.found]
++  prior
  ::  Resolve only the receipt frozen in a request. No recursive receipt
  ::  copies, owner-provided checkpoint data, or changing best-match lookup.
  |=  [s=organ jobs=organ:tools r=request:core]
  ^-  (each (unit retained:core) @tas)
  ?~  previous.r  [%& ~]
  ?.  (lte ~(wyt by results.s) capacity)  [%| %compiler-prefix-result-capacity]
  =/  matches=(list [@ux retained:core])
    (skim ~(tap by results.s) |=([id=@ux value=retained:core] =(receipt.u.previous.r (digest:core value))))
  ?.  =(1 (lent matches))  [%| %compiler-prefix-prior-missing-or-ambiguous]
  =/  [id=@ux value=retained:core]  (snag 0 matches)
  ?.  &(!=(id (key:tools request.job.r)) (linked:core jobs id value %.y) ?=(%& -.output.value))  [%| %compiler-prefix-prior-not-finished]
  ?.  &(=(program.r program.request.value) =(selection.r selection.request.value) =(module.job.r module.job.request.value) =(profile.r profile.request.value) =(checkpoint.u.previous.r (digest:core checkpoint.p.output.value)) =(prefix.u.previous.r prefix.p.output.value))
    [%| %compiler-prefix-prior-mismatch]
  [%& `value]
++  row-valid
  ::  Historical scope joins survive revocation. Pending/unknown tool results
  ::  may have a receipt; only linked(...finished=true) can seed later work.
  |=  [s=organ jobs=organ:tools id=@ux value=retained:core]
  ^-  ?
  ?.  (linked:core jobs id value %.n)  %.n
  =/  program  (~(get by programs.s) digest.program.request.value)
  =/  selected  (~(get by choices.s) (key-for selection.request.value))
  ?~  program  %.n
  ?~  selected  %.n
  ?.  &(=(u.program program.request.value) =(program.u.selected digest.u.program) =(selection.u.selected selection.request.value))  %.n
  =/  previous  (prior s jobs request.value)
  ?.  ?=(%& -.previous)  %.n
  =/  rebuilt
    (prepare:core u.program job.request.value selection.request.value scope.request.value fuel.request.value p.previous jobs)
  &(?=(%& -.rebuilt) =(p.rebuilt request.value))
++  valid
  |=  [our=@p s=organ jobs=organ:tools]
  ^-  ?
  ?.  (bounded s)  %.n
  ?&  (levy ~(tap by programs.s) |=([id=@ux p=program:core] &(=(id digest.p) (program-valid:core p))))
      (levy ~(tap in revoked.s) |=(id=@ux (~(has by programs.s) id)))
      (levy ~(tap by choices.s) |=([k=key c=choice] &((selection-valid:exports selection.c) =(k (key-for selection.c)) =(our authority.spec.project.selection.c) (~(has by programs.s) program.c))))
      (levy ~(tap by results.s) |=([id=@ux r=retained:core] (row-valid s jobs id r)))
  ==
++  current-read
  |=  [our=@p now=@da s=organ jobs=organ:tools id=@ux]
  ^-  (each (unit current) @tas)
  =/  found  (~(get by records.jobs) id)
  ?~  found  [%| %compiler-prefix-admission-missing]
  =/  r=tool-request:nc  request.u.found
  ?.  &(=(id (key:tools r)) ?=(?(%running %unknown) stage.u.found) ?=(?(%compile %check) -.arguments.r))
    [%| %compiler-prefix-admission-mismatch]
  ::  Absence alone preserves older compiler selection. An explicit disabled
  ::  or invalid choice always refuses before any fallback execution.
  ?.  (~(has by choices.s) [configuration.context.r target.arguments.r])  [%& ~]
  =/  scope  (~(get by grants.jobs) grant.u.found)
  ?~  scope  [%| %compiler-prefix-grant-missing]
  =/  permission  (allowed:tools our now u.scope r)
  ?:  ?=(%| -.permission)  [%| p.permission]
  ?.  (pending:tools our now r)  [%| %compiler-prefix-not-pending]
  =/  built  (prepare:compiler our now project.grant.u.scope r)
  ?:  ?=(%| -.built)  [%| p.built]
  =/  selected  (lookup s p.built)
  ?~  selected  [%| %compiler-prefix-selection-missing]
  ?:  ?=(%| -.u.selected)  [%| p.u.selected]
  [%& `[p.built p.u.selected u.scope]]
++  choose-prior
  ::  Prefer the longest compatible nonempty prefix. Stable map order breaks
  ::  ties. A changed dependency excludes that candidate; the new compiler
  ::  still runs fresh if no compatible receipt exists, never an older role.
  |=  [s=organ jobs=organ:tools c=current]
  ^-  (each (unit retained:core) @tas)
  =/  program=program:core  (~(got by programs.s) program.choice.c)
  =/  rows=(list [@ux retained:core])  ~(tap by results.s)
  =/  best=(unit retained:core)  ~
  =/  length=@ud  0
  |-  ^-  (each (unit retained:core) @tas)
  ?~  rows  [%& best]
  =/  [id=@ux r=retained:core]  i.rows
  ?.  &(!=(id (key:tools request.job.c)) =(program program.request.r) =(selection.choice.c selection.request.r))
    $(rows t.rows)
  ?.  (row-valid s jobs id r)  [%| %compiler-prefix-prior-invalid]
  ?.  ?=(%& -.output.r)  $(rows t.rows)
  =/  found  (~(get by records.jobs) id)
  ?~  found  [%| %compiler-prefix-prior-job-missing]
  ?.  =(%finished stage.u.found)  $(rows t.rows)
  ?.  (linked:core jobs id r %.y)  [%| %compiler-prefix-prior-report-mismatch]
  =/  size=@ud  (lent prefix.p.output.r)
  ?.  (gth size length)  $(rows t.rows)
  =/  candidate
    (prepare:core program job.c selection.choice.c (shax (jam scope.c)) compiler-fuel-v2:vm `r jobs)
  ?:  ?=(%| -.candidate)  $(rows t.rows)
  $(rows t.rows, best `r, length size)
++  prepare
  |=  [our=@p now=@da s=organ jobs=organ:tools id=@ux]
  ^-  (each (unit prepared) @tas)
  ?.  (bounded s)  [%| %compiler-prefix-state-capacity]
  =/  read  (current-read our now s jobs id)
  ?:  ?=(%| -.read)  [%| p.read]
  ?~  p.read  [%& ~]
  =/  c=current  u.p.read
  =/  program=program:core  (~(got by programs.s) program.choice.c)
  =/  same  (~(get by results.s) id)
  ?^  same
    ?.  (row-valid s jobs id u.same)  [%| %compiler-prefix-retained-invalid]
    ?.  &(=(job.c job.request.u.same) =(selection.choice.c selection.request.u.same) =(program program.request.u.same) =(scope.request.u.same (shax (jam scope.c))))
      [%| %compiler-prefix-retained-request-mismatch]
    =/  previous  (prior s jobs request.u.same)
    ?:  ?=(%| -.previous)  [%| p.previous]
    [%& `[request.u.same p.previous]]
  ?:  (gte ~(wyt by results.s) capacity)  [%| %compiler-prefix-result-capacity]
  ?:  (gte (met 3 (jam s)) byte-limit)  [%| %compiler-prefix-state-capacity]
  =/  previous  (choose-prior s jobs c)
  ?:  ?=(%| -.previous)  [%| p.previous]
  =/  built
    (prepare:core program job.c selection.choice.c (shax (jam scope.c)) compiler-fuel-v2:vm p.previous jobs)
  ?:  ?=(%| -.built)  [%| p.built]
  [%& `[p.built p.previous]]
++  retain
  ::  INTERNAL ONLY: the owning app must authenticate the exact Spider handle,
  ::  start/watch/source and terminal payload before invoking this gate.
  |=  [b=bowl:gall s=organ jobs=organ:tools id=@ux value=retained:core]
  ^-  (each organ @tas)
  ?.  =(our.b src.b)  [%| %compiler-prefix-native-source-required]
  =/  previous  (~(get by results.s) id)
  ?^  previous
    ?:  =(u.previous value)  [%& s]
    [%| %compiler-prefix-retention-conflict]
  ?:  (gte ~(wyt by results.s) capacity)  [%| %compiler-prefix-result-capacity]
  ?.  (retained-valid:core id value)  [%| %compiler-prefix-retained-invalid]
  =/  read  (current-read our.b now.b s jobs id)
  ?:  ?=(%| -.read)  [%| p.read]
  ?~  p.read  [%| %compiler-prefix-selection-missing]
  =/  c=current  u.p.read
  ?.  &(=(job.c job.request.value) =(selection.choice.c selection.request.value) =(program.choice.c digest.program.request.value) =(scope.request.value (shax (jam scope.c))))
    [%| %compiler-prefix-retained-request-mismatch]
  =/  prior  (prior s jobs request.value)
  ?:  ?=(%| -.prior)  [%| p.prior]
  =/  program=program:core  (~(got by programs.s) program.choice.c)
  =/  rebuilt
    (prepare:core program job.c selection.choice.c (shax (jam scope.c)) compiler-fuel-v2:vm p.prior jobs)
  ?.  &(?=(%& -.rebuilt) =(p.rebuilt request.value))
    [%| %compiler-prefix-retained-prior-mismatch]
  =/  next=organ  s(results (~(put by results.s) id value))
  ?.  (bounded next)  [%| %compiler-prefix-state-capacity]
  [%& next]
++  act
  |=  [b=bowl:gall s=organ jobs=organ:tools c=command]
  ^-  (each organ @tas)
  ?.  =(our.b src.b)  [%| %compiler-prefix-owner-required]
  ?:  ?=(%native-coding-compiler-prefix-admit-v1 -.c)
    ?.  (program-valid:core value.c)  [%| %compiler-prefix-program-invalid]
    =/  prior  (~(get by programs.s) digest.value.c)
    ?^  prior
      ?.  =(u.prior value.c)  [%| %compiler-prefix-program-conflict]
      ?:  (~(has in revoked.s) digest.value.c)  [%| %compiler-prefix-program-revoked]
      [%& s]
    =/  next=organ  s(programs (~(put by programs.s) digest.value.c value.c))
    ?:((bounded next) [%& next] [%| %compiler-prefix-state-capacity])
  ?:  ?=(%native-coding-compiler-prefix-revoke-v1 -.c)
    ?.  (~(has by programs.s) id.c)  [%| %compiler-prefix-program-missing]
    [%& s(revoked (~(put in revoked.s) id.c))]
  ?:  ?=(%native-coding-compiler-prefix-unselect-v1 -.c)
    =/  key=key  [configuration.c target.c]
    =/  prior  (~(get by choices.s) key)
    ?~  prior  [%| %compiler-prefix-selection-missing]
    [%& s(choices (~(put by choices.s) key u.prior(enabled %.n)))]
  ?.  &(=(our.b authority.spec.project.selection.c) (selection-valid:exports selection.c))
    [%| %compiler-prefix-selection-invalid]
  ?.  (~(has by programs.s) program.c)  [%| %compiler-prefix-program-missing]
  ?:  (~(has in revoked.s) program.c)  [%| %compiler-prefix-program-revoked]
  =/  key=key  (key-for selection.c)
  =/  incoming=choice  [selection.c program.c %.y]
  =/  prior  (~(get by choices.s) key)
  ?^  prior
    ?:  =(u.prior incoming)  [%& s]
    [%| %compiler-prefix-selection-immutable]
  ?:  (lien ~(val by records.jobs) |=(r=record:tools &(=(configuration.key configuration.context.request.r) ?=(?(%compile %check) -.arguments.request.r) ?=(?(%running %unknown) stage.r))))
    [%| %compiler-prefix-selection-busy]
  ?.  (registered:old our.b now.b project.selection.c)
    [%| %compiler-prefix-project-unregistered]
  =/  catalog  (catalog:project our.b now.b project.selection.c)
  ?:  ?=(%| -.catalog)  [%| p.catalog]
  =/  next=organ  s(choices (~(put by choices.s) key incoming))
  ?:((bounded next) [%& next] [%| %compiler-prefix-state-capacity])
--
