::  Dispatch provenance only. Collection, assessment and selection retain
::  their existing canonical owners. No polling, retry or state substitution.
/+  owner=qpc-native-owner-binding, assessment=qpc-native-assessment,
    ct=cantrip-native-coding
|%
+$  role  ?(%viki %cantrip)
+$  stage  ?(%assessment %selection)
+$  snapshot
  $%  [%viki value=state:owner]
      [%cantrip value=state:assessment]
  ==
+$  notice  [stage=stage session=@ux before=@ux after=@ux]
+$  delivery  [notice=notice phase=?(%sent %unknown)]
+$  state  [%qpc-native-flow-v1 records=(map @ux delivery)]
++  empty  ^-(state [%qpc-native-flow-v1 ~])
++  digest  |=(v=* ^-(@ux (shax (jam [%qpc-native-flow-v1 v]))))
++  key  |=(n=notice (digest [stage.n session.n]))
++  terminal
  |=  r=record:assessment
  &(!=(~ rows.r) (levy ~(val by rows.r) |=(v=row:assessment ?=(?(%checked %refused) phase.v))))
++  known
  |=  r=record:assessment
  !(lien ~(val by rows.r) |=(v=row:assessment =(%unknown phase.v)))
++  snapshot-valid
  |=  [our=@p s=snapshot]
  ?:  ?=(%viki -.s)  (valid:owner our value.s)
  (valid:assessment our value.s)
++  transitions
  ::  Native wrapper supplies the same inner's before/after callback DATA.
  ::  Missing, invalid, old terminal and unknown observations emit nothing.
  |=  [our=@p before=snapshot after=snapshot]
  ^-  (list notice)
  ?.  &((snapshot-valid our before) (snapshot-valid our after))  ~
  ?:  ?=(%viki -.before)
    ?.  ?=(%viki -.after)  ~
    %+  murn  ~(tap by tickets.value.after)
    |=  [id=@ux ticket=ticket:owner]
    ?.  =(%sealed phase.ticket)  ~
    =/  prior  (~(get by tickets.value.before) id)
    ?~  prior  ~
    ?.  =(%opened phase.u.prior)  ~
    =/  old  (~(get by records.journal.value.before) id)
    =/  new  (~(get by records.journal.value.after) id)
    ?~  old  ~
    ?~  new  ~
    ?.  &(?=(~ collection.u.old) ?=(^ collection.u.new))  ~
    ?.  =(u.old u.new(collection ~))  ~
    ?.  =(u.prior ticket(phase %opened, seal seal.u.prior))  ~
    `[%assessment id (digest:owner u.old) (digest:owner u.new)]
  ?.  ?=(%cantrip -.after)  ~
  %+  murn  ~(tap by records.value.after)
  |=  [id=@ux row=record:assessment]
  ?.  (terminal row)  ~
  =/  prior  (~(get by records.value.before) id)
  ?~  prior  ~
  ?:  (terminal u.prior)  ~
  ?.  (known u.prior)  ~
  ?.  =(row(rows rows.u.prior) u.prior)  ~
  `[%selection id (digest:assessment u.prior) (digest:assessment row)]
++  record
  ::  Returning the notice means its immutable dispatch is now in DATA.
  |=  [s=state n=notice]
  ^-  (each state @tas)
  =/  id=@ux  (key n)
  ?:  (~(has by records.s) id)  [%| %qpc-flow-already-sent]
  ?.  (lth ~(wyt by records.s) 128)  [%| %qpc-flow-capacity]
  ?.  (levy `(list @ux)`~[session.n before.n after.n] identifier:ct)
    [%| %qpc-flow-notice-invalid]
  [%& s(records (~(put by records.s) id [n %sent]))]
++  failed
  |=  [s=state n=notice]
  ^-  state
  =/  id=@ux  (key n)
  =/  found  (~(get by records.s) id)
  ?~  found  s
  ?.  =(n notice.u.found)  s
  s(records (~(put by records.s) id u.found(phase %unknown)))
++  valid
  |=  s=state
  ^-  ?
  ?&  (lte ~(wyt by records.s) 128)
      %+  levy  ~(tap by records.s)
      |=  [id=@ux d=delivery]
      &(=(id (key notice.d)) (levy `(list @ux)`~[session.notice.d before.notice.d after.notice.d] identifier:ct))
  ==
--
