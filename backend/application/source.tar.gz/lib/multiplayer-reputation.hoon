::  /lib/multiplayer-reputation
::
::  Deterministic verified-act, contextual-reputation, identity, and portable
::  proof projection over receipt-v3.  Nothing here can award reputation by
::  vote: the authority chain, exact actor, and exact outcome bytes are inputs.
::
/-  mr=multiplayer-receipt, mrp=multiplayer-reputation
/+  mrl=multiplayer-receipt
|%
++  export-cap  64
++  identity-for
  |=  ship=@p
  ^-  identity:mrp
  =/  clan=@tas  (clan:title ship)
  =/  tier=identity-tier:mrp
    ?+  clan  %comet
      %czar  %galaxy
      %king  %star
      %duke  %planet
      %earl  %moon
      %pawn  %comet
    ==
  =/  sponsor=(unit @p)
    ?:  =(%moon tier)  `(^sein:title ship)
    ~
  [ship tier sponsor]
++  identity-valid
  |=  item=identity:mrp
  ^-  ?
  =(item (identity-for ship.item))
++  outcome-valid
  |=  item=outcome-body:mrp
  ^-  ?
  ?&  !=(0 actor.item)
      !=(0 role.item)
      !=(0 language.item)
      !=(0 action-class.item)
      !=(0 evidence.item)
  ==
++  outcome-from
  |=  item=event:mr
  ^-  (unit outcome-body:mrp)
  ?.  ?=(%live -.origin.body.item)  ~
  ?~  actor.body.item  ~
  =/  parsed=(unit outcome-body:mrp)
    ((soft outcome-body:mrp) payload.body.item)
  ?~  parsed  ~
  ?.  (outcome-valid u.parsed)  ~
  =/  receipt-actor=actor:mr  u.actor.body.item
  ?.  =(ship.receipt-actor actor.u.parsed)  ~
  `u.parsed
++  act-from
  |=  item=event:mr
  ^-  (unit verified-act:mrp)
  =/  outcome=(unit outcome-body:mrp)  (outcome-from item)
  ?~  outcome  ~
  =/  body=outcome-body:mrp  u.outcome
  `[ digest.item
     host-sequence.body.item
     previous.body.item
     project.body.item
     authority-host.body.item
     (identity-for actor.body)
     role.body
     language.body
     action-class.body
     outcome.body
     evidence.body
     occurred-at.body.item
   ]
++  collect
  |=  [items=(list event:mr) out=(list verified-act:mrp)]
  ^-  (list verified-act:mrp)
  ?~  items  (flop out)
  =/  act=(unit verified-act:mrp)  (act-from i.items)
  ?~  act  $(items t.items)
  $(items t.items, out [u.act out])
++  ledger-from
  |=  chain=chain:mr
  ^-  (unit ledger:mrp)
  ?.  (valid:mrl chain)  ~
  ?:  (gth count.chain export-cap)  ~
  =/  acts=(list verified-act:mrp)  (collect (flop events.chain) ~)
  `[ project.chain
     authority-host.chain
     count.chain
     head.chain
     acts
   ]
++  ledger-digest
  |=  ledger=ledger:mrp
  ^-  digest:mr
  `@ux`(shax (jam [%multiplayer-verified-act-ledger-v1 ledger]))
++  context-for
  |=  act=verified-act:mrp
  ^-  context:mrp
  [project.act role.act language.act action-class.act]
++  zero-score
  ^-  score:mrp
  [0 0 0 0 0]
++  bump
  |=  [score=score:mrp outcome=outcome-kind:mrp]
  ^-  score:mrp
  ?-  outcome
    %accepted   score(accepted +(accepted.score))
    %reverted   score(reverted +(reverted.score))
    %contested  score(contested +(contested.score))
    %built      score(built +(built.score))
    %durable    score(durable +(durable.score))
  ==
++  contexts-for
  |=  acts=(list verified-act:mrp)
  ^-  (map context:mrp score:mrp)
  =/  out=(map context:mrp score:mrp)  ~
  |-
  ?~  acts  out
  =/  key=context:mrp  (context-for i.acts)
  =/  old=(unit score:mrp)  (~(get by out) key)
  =/  score=score:mrp  ?~(old zero-score u.old)
  %=  $
    acts  t.acts
    out   (~(put by out) key (bump score outcome.i.acts))
  ==
++  acts-for
  |=  [owner=@p acts=(list verified-act:mrp)]
  ^-  (list verified-act:mrp)
  (skim acts |=(act=verified-act:mrp =(owner ship.identity.act)))
++  profile-for
  |=  [ledger=ledger:mrp owner=@p]
  ^-  (unit profile:mrp)
  =/  acts=(list verified-act:mrp)  (acts-for owner acts.ledger)
  ?~  acts  ~
  `[owner (identity-for owner) (contexts-for acts) acts]
++  bundle-digest
  |=  body=bundle-body:mrp
  ^-  digest:mr
  `@ux`(shax (jam [%multiplayer-portable-proof-v1 body]))
++  bundle-for
  |=  [chain=chain:mr owner=@p]
  ^-  (unit bundle:mrp)
  =/  ledger=(unit ledger:mrp)  (ledger-from chain)
  ?~  ledger  ~
  =/  profile=(unit profile:mrp)  (profile-for u.ledger owner)
  ?~  profile  ~
  =/  body=bundle-body:mrp
    [1 owner chain u.profile (ledger-digest u.ledger)]
  `[%multiplayer-portable-proof-v1 body (bundle-digest body)]
++  bundle-valid
  |=  item=bundle:mrp
  ^-  ?
  ?.  =(1 version.body.item)  %.n
  ?.  =(digest.item (bundle-digest body.item))  %.n
  ?.  (identity-valid identity.profile.body.item)  %.n
  =/  rebuilt=(unit bundle:mrp)
    (bundle-for chain.body.item owner.body.item)
  ?~(rebuilt %.n =(item u.rebuilt))
++  score-at
  |=  [profile=profile:mrp context=context:mrp]
  ^-  score:mrp
  =/  found=(unit score:mrp)  (~(get by contexts.profile) context)
  ?~(found zero-score u.found)
--
