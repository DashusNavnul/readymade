::  Derived project view for the fresh ordinary selected session. This owns
::  no workspace, bootstrap, claim, grant or second project registry.
/-  nc=native-coding
/+  selected=qpc-native-selected, loop=native-coding-loop,
    workspace=native-coding-session-workspace, project=native-coding-project,
    sessions=native-coding-session, pool=qpc-native-pool
|%
+$  selected-reader  $-([our=@p at=@da] (each state:selected @tas))
+$  origin-reader
  $-([b=bowl:gall held=state:workspace projects=(map @t project:nc) session=@ux name=@t] (each project:nc @tas))
++  selected-read
  |=  [our=@p at=@da]
  ^-  (each state:selected @tas)
  =/  held=state:selected
    .^(state:selected %gx /(scot %p our)/viki/(scot %da at)/qpc/selected/noun)
  ?.  (valid:selected held)  [%| %qpc-selected-project-owner-invalid]
  [%& held]
++  origin-read
  |=  [b=bowl:gall held=state:workspace projects=(map @t project:nc) session=@ux name=@t]
  ^-  (each project:nc @tas)
  ::  Even unknown original workspace entries forbid a global fallback.
  ?:  (~(has by sessions.held) session)
    (ready-project:workspace b held projects session)
  =/  found  (~(get by projects) name)
  ?~  found  [%| %project-missing]
  ?.  (valid:project u.found)  [%| %project-invalid]
  [%& u.found]
++  available
  ::  A selected opening cannot take a pre-existing workspace session ID.
  |=  [held=state:workspace p=plan:selected]
  ^-  ?
  !(~(has by sessions.held) id.session.entry.p)
++  marked
  |=  e=entry:sessions
  ^-  ?
  ?.  (gte (lent records.e) 2)  %.n
  =([%status %paused %qpc-selected-execution] body:(snag 1 records.e))
++  resolve-with
  ::  Native proof seams only; no external command supplies a plan/project.
  |=  [b=bowl:gall coding=state:loop held=state:workspace id=@ux fetch=selected-reader origin=origin-reader]
  ^-  (unit (each project:nc @tas))
  ?.  =(our.b src.b)  `[%| %qpc-selected-project-owner-required]
  ::  Existing real workspace rows retain their normal authoritative path.
  ?:  (~(has by sessions.held) id)
    =/  e=entry:workspace  (~(got by sessions.held) id)
    `(origin b held projects.coding id project.request.e)
  =/  current  (~(get by sessions.coding) id)
  ?~  current  ~
  =/  e=entry:sessions  u.current
  ?.  (marked e)  ~
  ::  Opening itself never calls this gate. The plan and fresh entry commit
  ::  before their grant card; later tool/review/project reads see that commit.
  =/  got  (fetch our.b now.b)
  ?:  ?=(%| -.got)  `[%| p.got]
  ?.  (valid:selected p.got)  `[%| %qpc-selected-project-owner-invalid]
  =/  matches=(list record:selected)
    (skim ~(val by records.p.got) |=(r=record:selected =(id id.session.entry.plan.r)))
  ?.  =(1 (lent matches))  `[%| %qpc-selected-project-plan-missing]
  =/  p=plan:selected  plan:(snag 0 matches)
  =/  declared=project:nc  project.grant.p
  ?.  ?&  (plan-valid:selected p)  (chain:pool e)
          =(our.b owner.session.e)  =(project.session.e id.spec.declared)
          =(configuration.e (configuration:project declared))
          =(desk.working.session.e working.declared)
          =(records.entry.p (scag 2 records.e))
          =(`[key.p id.grant.p] (~(get by bindings.coding) id))
          (~(has by sessions.coding) collection.p)
      ==  `[%| %qpc-selected-project-session-changed]
  =/  base  (~(get by projects.coding) id.spec.declared)
  ?~  base  `[%| %project-missing]
  ?.  =(declared u.base(working working.declared))
    `[%| %qpc-selected-project-policy-changed]
  =/  original  (origin b held projects.coding collection.p id.spec.declared)
  ?:  ?=(%| -.original)  `[%| p.original]
  ?.  =(declared p.original)  `[%| %qpc-selected-project-origin-changed]
  `[%& declared]
++  resolve
  |=  [b=bowl:gall coding=state:loop held=state:workspace id=@ux]
  ^-  (unit (each project:nc @tas))
  (resolve-with b coding held id selected-read origin-read)
--
