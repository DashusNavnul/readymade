::  Viki-owned fleet adapter. Every assignment reads canonical route, seat,
::  workspace and Clay state. Waterwheel wakes; Viki alone chooses dispatch.
/-  nf=native-coding-fleet, nc=native-coding, vr=glass-moon-route,
    ss=seat-session, mse=glass-moon-executor, np=native-coding-provider
/+  fleet=native-coding-fleet, read=native-coding-fleet-read,
    relay=native-coding-moon-relay, sessions=native-coding-session,
    routes=viki-route, scoped=native-coding-session-project
|%
+$  card  card:agent:gall
+$  placement  [route=moon-route:vr config=config:relay]
+$  state
  [%native-coding-fleet-runtime-v1 fleet=organ:nf placements=(map @ux placement) consumed=@ud]
+$  action
  $%  [%bind route=moon-route:vr config=config:relay roles=(set role:nf)]
      [%enqueue task=task:nf]
      [%inspect seat=seat:ss]
      [%resume task=@ux]
      [%control task=@ux kind=?(%pause %unknown %observe %cancel)]
      [%settle settlement=settlement:nf]
  ==
++  empty  ^-  state  [%native-coding-fleet-runtime-v1 empty:fleet ~ 0]
++  send
  |=  [moon=@p id=@ux op=command:relay]
  ^-  card
  [%pass /native-fleet/remote/(scot %p moon)/(scot %ux id)/(scot %tas -.op) %agent [moon %multiplayer-session-executor] %poke %noun !>(op)]
++  wake-card
  |=  [our=@p revision=@ud]
  ^-  card
  [%pass /native-fleet/wake/(scot %ud revision) %agent [our %waterwheel] %poke %noun !>([%native-coding-fleet-wake-request-v1 revision])]
++  assigned
  |=  [s=state session=@ux]
  ^-  (unit entry:nf)
  =/  matches=(list entry:nf)
    (skim ~(val by tasks.fleet.s) |=(e=entry:nf &((held:fleet e) =(session session.context.task.e))))
  ?~  matches  ~
  ?^  t.matches  ~
  `i.matches
++  placement-valid
  |=  [our=@p selected=placement]
  ^-  ?
  =/  r=moon-route:vr  route.selected
  =/  c=config:relay  config.selected
  ?.  ?=([%multiplayer-session-executor-binding-v2 *] -.binding.c)  %.n
  ::  Parentage and the exact route binding establish this owner's placement.
  ?&  =(our parent.seat-session.r)
      (authorized-config:relay moon.seat-session.r c)
      =(our peer.binding.c)  =(session-id.r local-session.binding.c)
      =(route.binding.c (commitment:routes r))  =(selected.binding.c (spec-for:routes r))
  ==
++  valid
  |=  [our=@p s=state]
  ^-  ?
  ?&  (valid:fleet our fleet.s)  (lte consumed.s next.fleet.s)
      (lte ~(wyt by placements.s) 64)
      (levy ~(tap by placements.s) |=([id=@ux p=placement] &(=(id session.config.p) (placement-valid our p))))
  ==
++  request-card
  |=  [s=state e=entry:sessions kind=?(%infer %observe %cancel)]
  ^-  (each card @tas)
  =/  selected  (~(get by placements.s) id.session.e)
  ?~  selected  [%| %fleet-placement-missing]
  =/  task  (assigned s id.session.e)
  ?~  task  [%| %fleet-assignment-missing]
  ?>  ?=(^ assignment.u.task)
  =/  a=assignment:nf  u.assignment.u.task
  =/  p=placement  u.selected
  =/  c=config:relay  config.p
  ?.  ?&  =(worker.e moon.seat-session.route.p)  =(worker.a worker.e)
          =(generation.a generation.c)  =(route-value.a route.p)
          =(selection.e selection.c)  =(project.context.a project.session.e)
          =(configuration.context.a configuration.e)
      ==  [%| %fleet-assignment-mismatch]
  ?~  pending.e  [%| %fleet-request-missing]
  =/  r=request:np  u.pending.e
  ?.  &(=(session.r id.session.e) =(selection.r selection.c))  [%| %fleet-selection-mismatch]
  =/  op=command:relay
    ?-  kind
      %infer  [%native-coding-moon-infer (digest:relay c) generation.c r]
      %observe  [%native-coding-moon-observe (digest:relay c) generation.c id.r session.r (digest:relay r)]
      %cancel  [%native-coding-moon-cancel (digest:relay c) generation.c id.r session.r (digest:relay r)]
    ==
  [%& (send worker.e id.r op)]
++  effects
  |=  [our=@p s=state journal=organ:sessions next=transition:nf]
  ^-  (quip card state)
  =.  s  s(fleet organ.next)
  =/  out=(list card)  ~
  =/  todo=(list effect:nf)  effects.next
  |-  ^-  (quip card state)
  ?~  todo  [out s]
  =/  effect=effect:nf  i.todo
  =/  cards=(list card)
    ?-  -.effect
      %waterwheel-wake  ~[(wake-card our revision.effect)]
      %retain
        ~[[%pass /native-fleet/retain %agent [our %graf] %poke %graf-action !>([%attest fact.effect])]]
      %dispatch
        ~[[%pass /native-fleet/run %agent [our %viki] %poke %noun !>([%native-coding-action-v1 [%run session.context.task.effect]])]]
      %inspect-worker
        =/  matches=(list placement)
          (skim ~(val by placements.s) |=(p=placement &(=(worker.effect moon.seat-session.route.p) =(generation.effect generation.config.p))))
        ?~  matches  ~
        =/  c=config:relay  config.i.matches
        ~[(send worker.effect request.effect [%native-coding-moon-inspect (digest:relay c) generation.c request.effect])]
      %observe
        =/  found  (~(get by journal) session.context.assignment.effect)
        ?~  found  ~
        =/  card  (request-card s u.found %observe)
        ?:  ?=(%| -.card)  ~
        ~[p.card]
      %cancel
        ::  Route through the existing session pause law, including unknowns.
        ~[[%pass /native-fleet/cancel %agent [our %viki] %poke %noun !>([%native-coding-action-v1 [%pause session.context.assignment.effect %.y]])]]
    ==
  $(todo t.todo, out (weld out cards))
++  act
  |=  [b=bowl:gall s=state w=world:read journal=organ:sessions projects=(map @t project:nc) blocked=(set @tas) a=action]
  ^-  (each (quip card state) @tas)
  ?.  =(our.b src.b)  [%| %fleet-owner-required]
  ?:  ?=(%bind -.a)
    =/  p=placement  [route.a config.a]
    ?.  (placement-valid our.b p)  [%| %fleet-placement-invalid]
    =/  id=@ux  session.config.a
    =/  existing  (~(get by placements.s) id)
    ?:  &(=(~ existing) (gte ~(wyt by placements.s) 64))  [%| %fleet-placement-capacity]
    =/  live  (~(get by journal) id)
    ?.  ?~  live  %.y
        &(=(selection.u.live selection.config.a) =(worker.u.live moon.seat-session.route.a) ?=(~ pending.u.live) ?=(~ calls.u.live))
      [%| %fleet-session-busy]
    =/  next  (bind:fleet our.b src.b fleet.s w route.a binding.config.a roles.a)
    ?:  ?=(%| -.next)  [%| p.next]
    =/  worker=worker:nf  (~(got by workers.organ.p.next) seat.seat-session.route.a)
    ?.  =(generation.worker generation.config.a)  [%| %fleet-generation-mismatch]
    [%& (effects our.b s(placements (~(put by placements.s) id p)) journal p.next)]
  =/  next=(each transition:nf @tas)
    ?-  -.a
      %enqueue
        =/  previous  (~(get by tasks.fleet.s) id.task.a)
        ?^  previous
          ?:  =(task.a task.u.previous)  [%& [fleet.s ~]]
          [%| %fleet-task-id-conflict]
        =/  e  (~(get by journal) session.context.task.a)
        ?~  e  [%| %fleet-session-missing]
        =/  registered
          (resolve:scoped our.b now.b projects session.context.task.a project.context.task.a)
        ?:  ?=(%| -.registered)  [%| p.registered]
        ?:  (~(has in blocked) working.p.registered)  [%| %fleet-working-desk-busy]
        =/  selected  (~(get by placements.s) session.context.task.a)
        ?~  selected  [%| %fleet-placement-missing]
        ?.  ?&  =(worker.u.e moon.seat-session.route.u.selected)
                =(selection.u.e selection.config.u.selected)
                =(objective.task.a objective.session.u.e)
                =(source.context.task.a working.session.u.e)
                =(configuration.context.task.a configuration.u.e)
                =(request.context.task.a (request-id:sessions id.session.u.e turn.u.e))
                =(phase.u.e %ready)  ?=(~ pending.u.e)  ?=(~ calls.u.e)
            ==  [%| %fleet-task-session-mismatch]
        =/  exact  (source:read w p.registered task.a)
        ?:  ?=(%| -.exact)  [%| p.exact]
        (enqueue:fleet our.b src.b fleet.s task.a)
      %inspect  (inspect:fleet our.b src.b fleet.s seat.a)
      %control  (control:fleet our.b src.b fleet.s task.a kind.a)
      %resume  (resume:fleet our.b src.b fleet.s task.a)
      %settle  (settle:fleet our.b src.b fleet.s w settlement.a)
    ==
  ?:  ?=(%| -.next)  [%| p.next]
  =/  out  (effects our.b s journal p.next)
  =/  paused=(unit @ux)
    ?.  ?=(%control -.a)  ~
    ?.  =(%pause kind.a)  ~
    =/  e  (~(get by tasks.fleet.s) task.a)
    ?~  e  ~
    `session.context.task.u.e
  ?^  paused
    [%& [(weld -.out `(list card)`~[[%pass /native-fleet/pause %agent [our.b %viki] %poke %noun !>([%native-coding-action-v1 [%pause u.paused %.n]])]]) +.out]]
  ?.  ?=(%resume -.a)  [%& out]
  =/  e=entry:nf  (~(got by tasks.fleet.s) task.a)
  [%& [(weld -.out `(list card)`~[[%pass /native-fleet/resume %agent [our.b %viki] %poke %noun !>([%native-coding-action-v1 [%resume session.context.task.e]])]]) +.out]]
++  inspected
  |=  [b=bowl:gall s=state journal=organ:sessions report=inspection:relay]
  ^-  (each (quip card state) @tas)
  =/  matches=(list placement)
    (skim ~(val by placements.s) |=(p=placement &(=(src.b moon.seat-session.route.p) =(binding.report (digest:relay config.p)) =(generation.report generation.config.p))))
  ?~  matches  [%| %fleet-inspection-mismatch]
  ?^  t.matches  [%| %fleet-inspection-mismatch]
  =/  p=placement  i.matches
  ::  This status is the authenticated relay's actual binding/controller
  ::  observation, projected into the existing fleet inspection contract.
  =/  event=event:mse
    [%status request.report ready.report `binding.config.p ?:(busy.report 1 0) 0]
  =/  next  (confirm:fleet fleet.s src.b %multiplayer-session-executor seat.seat-session.route.p generation.report event)
  ?:  ?=(%| -.next)  [%| p.next]
  [%& (effects our.b s journal p.next)]
++  wake
  |=  [b=bowl:gall s=state w=world:read journal=organ:sessions projects=(map @t project:nc) blocked=(set @tas) revision=@ud]
  ^-  (quip card state)
  ?.  &(=(our.b src.b) =(revision next.fleet.s) (gth revision consumed.s))  [~ s]
  =.  s  s(consumed revision)
  =/  todo=(list entry:nf)  (ready:fleet fleet.s)
  |-  ^-  (quip card state)
  ?~  todo  [~ s]
  =/  task=task:nf  task.i.todo
  =/  selected  (~(get by placements.s) session.context.task)
  ?~  selected  $(todo t.todo)
  =/  registered
    (resolve:scoped our.b now.b projects session.context.task project.context.task)
  ?:  ?=(%| -.registered)  $(todo t.todo)
  ?:  (~(has in blocked) working.p.registered)  $(todo t.todo)
  =/  current  (~(get by journal) session.context.task)
  ?~  current  $(todo t.todo)
  ?.  &(=(%ready phase.u.current) ?=(~ pending.u.current) ?=(~ calls.u.current) =(request.context.task (request-id:sessions id.session.u.current turn.u.current)))
    $(todo t.todo)
  =/  next  (assign:fleet our.b src.b fleet.s w p.registered id.task seat.seat-session.route.u.selected)
  ?:  ?=(%| -.next)  $(todo t.todo)
  (effects our.b s journal p.next)
++  event-valid
  |=  [b=bowl:gall s=state e=entry:sessions received=event:relay]
  ^-  ?
  =/  selected  (~(get by placements.s) id.session.e)
  ?~  selected  %.n
  ?~  pending.e  %.n
  =/  a  (assigned s id.session.e)
  ?~  a  %.n
  ?>  ?=(^ assignment.u.a)
  =/  p=placement  u.selected
  ?&  =(src.b worker.e)  =(src.b moon.seat-session.route.p)
      =(src.b worker.u.assignment.u.a)
      =(binding.received (digest:relay config.p))
      =(generation.received generation.config.p)
      =(generation.received generation.u.assignment.u.a)
      =(request.received (digest:relay u.pending.e))
      =(id.event.received id.u.pending.e)  =(session.event.received id.session.e)
      =(selection.u.pending.e selection.config.p)
  ==
++  recovered
  |=  [our=@p s=state journal=organ:sessions]
  ^-  (quip card state)
  (effects our s journal [fleet.s (recover:fleet fleet.s)])
--
