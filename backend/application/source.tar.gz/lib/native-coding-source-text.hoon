::  Bounded UTF-8 source validation without expanding the atom into a list.
::  Callers retain their own nonempty, byte-count, hash, and authority guards.
|%
++  valid
  |=  body=@t
  ^-  ?
  =/  size=@ud  (met 3 body)
  ?.  (lte size 1.048.576)  %.n
  =/  offset=@ud  0
  =/  remaining=@ud  0
  =/  lower=@ud  128
  =/  upper=@ud  191
  |-  ^-  ?
  ?:  =(offset size)  =(remaining 0)
  =/  byte=@  (cut 3 [offset 1] body)
  ?:  (gth remaining 0)
    ?.  &((gte byte lower) (lte byte upper))  %.n
    $(offset +(offset), remaining (dec remaining), lower 128, upper 191)
  ?:  =(byte 0)  %.n
  ?:  (lte byte 127)  $(offset +(offset))
  ?:  &((gte byte 194) (lte byte 223))
    $(offset +(offset), remaining 1)
  ?:  =(byte 224)
    $(offset +(offset), remaining 2, lower 160)
  ?:  &((gte byte 225) (lte byte 236))
    $(offset +(offset), remaining 2)
  ?:  =(byte 237)
    $(offset +(offset), remaining 2, upper 159)
  ?:  &((gte byte 238) (lte byte 239))
    $(offset +(offset), remaining 2)
  ?:  =(byte 240)
    $(offset +(offset), remaining 3, lower 144)
  ?:  &((gte byte 241) (lte byte 243))
    $(offset +(offset), remaining 3)
  ?:  =(byte 244)
    $(offset +(offset), remaining 3, upper 143)
  %.n
--
