::  Explicit owner artifact negotiation. These records never authorize execution.
/-  c=readymade-collab, p=readymade-pact, a=readymade-artifact-collab,
    r=readymade-artifact-round
/+  saved=readymade-collab-saved, artifact=readymade-artifact-collab,
    round=readymade-artifact-round, pact=readymade-pact,
    package=readymade-package, law=cantrip-law-window,
    mg=readymade-app-management, native-guard=viki-scry-guard, flow=readymade-collab
|%
+$  operation  ?(%share-build-proof %propose-land %approve-land %close-land)
+$  command
  $:  op=operation
      owner=@p  peer=@p  request=@t  pact=@ux  guard=@ux  selected=@ux
      target=(unit target:r)
  ==
+$  prepared  [saved=saved:saved event=(unit envelope:a) duplicate=?]
++  fingerprint
  |=  cmd=command
  ^-  @ux
  (shax (jam [%readymade-artifact-owner-command-v1 cmd]))
++  guard
  |=  [our=@p peer=@p id=@ux value=saved:saved]
  ^-  @ux
  (shax (jam [%readymade-artifact-owner-guard-v1 our peer id (~(get by pacts.state.value) id) artifacts.value]))
++  text-field
  |=  [obj=(map @t json) key=@t limit=@ud]
  ^-  @t
  (text-field:mg obj key limit)
++  ux
  |=  raw=@t
  ^-  @ux
  =/  n  (need (slaw %ux raw))
  ?>  &((digest-valid:package n) =(raw (scot %ux n)))
  n
++  ud
  |=  raw=@t
  ^-  @ud
  =/  n  (need (slaw %ud raw))
  ?>  &((bounded-number:pact n) =(raw (scot %ud n)))
  n
++  decode
  |=  raw=@t
  ^-  command
  =/  value=json  (need (de:json:html raw))
  ?>  ?=(%o -.value)
  =/  obj=(map @t json)  p.value
  ?>  =('readymade-artifact-command-v1' (text-field obj 'schema' 64))
  =/  op=@t  (text-field obj 'op' 32)
  ?>  (lien `(list @t)`~['share-build-proof' 'propose-land' 'approve-land' 'close-land'] |=(name=@t =(name op)))
  =/  keys=(list @t)
    ?:  =('propose-land' op)
      ~['schema' 'op' 'owner' 'peer' 'request' 'pact' 'guard' 'selected' 'receiver' 'desk' 'revision' 'root' 'file']
    ~['schema' 'op' 'owner' 'peer' 'request' 'pact' 'guard' 'selected']
  ?>  =((silt keys) ~(key by obj))
  =/  owner-text=@t  (text-field obj 'owner' 128)
  =/  peer-text=@t  (text-field obj 'peer' 128)
  =/  owner=@p  (need (slaw %p owner-text))
  =/  peer=@p  (need (slaw %p peer-text))
  ?>  &(=(owner-text (scot %p owner)) =(peer-text (scot %p peer)) !=(owner peer))
  =/  request=@t  (text-field obj 'request' 36)
  ?>  (uuid:mg request)
  =/  target=(unit target:r)
    ?:  !=('propose-land' op)  ~
    =/  desk=@t  (text-field obj 'desk' 64)
    ?>  (ordinary:mg `@tas`desk)
    =/  file=@t  (text-field obj 'file' 512)
    =/  pax=path  (need (rush file stap))
    ?>  &((path-valid:package pax) =(file (spat pax)))
    =/  receiver-text=@t  (text-field obj 'receiver' 128)
    =/  receiver=@p  (need (slaw %p receiver-text))
    ?>  &(=(receiver-text (scot %p receiver)) |(=(receiver owner) =(receiver peer)))
    `[%land receiver `@tas`desk (ud (text-field obj 'revision' 64)) (ux (text-field obj 'root' 256)) pax]
  [(need ((soft operation) op)) owner peer request (ux (text-field obj 'pact' 256)) (ux (text-field obj 'guard' 256)) (ux (text-field obj 'selected' 256)) target]
++  parse
  |=  raw=@t
  ^-  (unit command)
  ?.  (lte (met 3 raw) 8.192)  ~
  (mole |.((decode raw)))
++  current-round
  |=  [current=state:p index=state:a id=@ux]
  ^-  (unit state:r)
  =/  existing  (~(get by rounds.index) [id generation.current %land])
  ?^  existing  existing
  (init:round current %land)
++  prepare
  ::  Runtime calls this only after authenticating its owner HTTP request.
  ::  The window/target result are independent native observations, never JSON.
  |=  [our=@p src=@p cmd=command value=saved:saved window=(unit window:law) local-target-ok=?]
  ^-  (each prepared @tas)
  ?.  &(=(our src) =(our owner.cmd) !=(our peer.cmd) (uuid:mg request.cmd))
    [%| %owner-required]
  ?.  (valid:saved our value)  [%| %invalid-canonical-state]
  =/  prior  (~(get by commands.value) request.cmd)
  ?^  prior
    ?.  =(u.prior (fingerprint cmd))  [%| %request-conflict]
    ::  A duplicate produces no envelope to resend; caller uses this flag.
    [%& [value ~ %.y]]
  ?.  =(guard.cmd (guard our peer.cmd pact.cmd value))  [%| %stale-guard]
  =/  held  (~(get by pacts.state.value) pact.cmd)
  ?~  held  [%| %unknown-pact]
  =/  current=state:p  value.u.held
  ?.  ?|  &(=(our left.terms.current) =(peer.cmd right.terms.current))
          &(=(our right.terms.current) =(peer.cmd left.terms.current))
      ==
    [%| %pact-peer]
  ?.  (active:pact current)  [%| %pact-inactive]
  =/  source  (~(get by packages.state.value) package.terms.current)
  ?~  source  [%| %unknown-package]
  ?.  &(=(pact.cmd (digest:pact terms.current)) (context-valid:artifact our our current value.u.source))
    [%| %package-binding]
  =/  closing=?  =(%close-land op.cmd)
  ?:  &(!closing (gte ~(wyt by commands.value) 4.096))  [%| %request-capacity]
  =/  payload=payload:a
    ?:  =(%share-build-proof op.cmd)
      =/  entry  (~(get by evidence.artifacts.value) selected.cmd)
      ?>  ?=(^ entry)
      ?>  &(=(our builder.u.entry) =(%local-canonical provenance.u.entry) (local-valid:artifact our value.u.source receipt.u.entry))
      [%build-evidence-for pact.cmd receipt.u.entry]
    =/  held-round=state:r  (need (current-round current artifacts.value pact.cmd))
    =/  sequence=@ud  +(?:(=(our left.terms.current) left-sequence.held-round right-sequence.held-round))
    =/  action=action:r
      ?:  =(%propose-land op.cmd)
        ?>  =(our left.terms.current)
        =/  entry  (need (~(get by evidence.artifacts.value) selected.cmd))
        ?>  (receipt-valid:artifact value.u.source builder.entry receipt.entry)
        ?>  ?=(^ target.cmd)
        ?>  local-target-ok
        =/  target=target:r  u.target.cmd
        ?>  &(?=(%land -.target) =(ship.target builder.entry) (ordinary:mg desk.target))
        =/  candidate=proposal:r
          [1 pact.cmd generation.current %land +(round.held-round) package.terms.current scope.terms.current artifact.body.receipt.entry builder.entry target selected.cmd]
        [%propose candidate]
      ?>  ?=(^ proposal.held-round)
      ?>  =(selected.cmd (digest:round u.proposal.held-round))
      ?:  closing  [%close selected.cmd]
      ?>  ?=(^ window)
      =/  w=window:law  u.window
      =/  law-ok=?  &((~(has in admissible.w) %implement) !(~(has in blocked.w) %implement))
      ?>  (local-ack-permitted:round held-round current our selected.cmd law-ok %.y)
      ?>  local-target-ok
      ::  Native owner gesture + exact selected round; no reusable grant.
      [%ack selected.cmd [(shax (jam w)) (shax (jam [%readymade-artifact-owner-approval-v1 our cmd]))]]
    [%artifact pact.cmd %land [generation.current sequence action]]
  =/  event=envelope:a  (envelope:artifact our payload)
  ::  Our canonical evidence is already recorded locally. Only the peer may
  ::  receive it as peer-assertion; never feed our own proof into that reducer.
  =/  changed=(each saved:saved @tas)
    ?:  =(%share-build-proof op.cmd)  [%& value]
    (receive-routed:saved value our our event)
  ?:  ?=(%| -.changed)  [%| p.changed]
  =/  next=saved:saved  p.changed
  =/  op=@t  `@t`op.cmd
  =/  receipt=receipt:c
    [request.cmd op %confirmed our 'Exact artifact negotiation recorded locally; peer observation and execution are separate.']
  =.  next  next(state (record:flow state.next receipt))
  =.  commands.next
    ?:  (gte ~(wyt by commands.next) 4.096)  commands.next
    (~(put by commands.next) request.cmd (fingerprint cmd))
  [%& [next `event %.n]]
++  target-private
  ::  Only the receiver can verify its own target. The opposite owner approves
  ::  the exact foreign tuple; receiver admission/execution rechecks locally.
  |=  [b=bowl:gall target=target:r]
  ^-  ?
  ?.  ?=(%land -.target)  %.n
  ?.  (ordinary:mg desk.target)  %.n
  ?:  !=(our.b ship.target)  %.y
  =/  domes=cone:clay  .^(cone:clay %cx /(scot %p our.b)//(scot %da now.b)/domes)
  =/  found  (~(get by domes) [our.b desk.target])
  ?~  found  %.n
  ?.  &(=(revision.target let.u.found) =(%dead liv.u.found) =(~ wic.u.found) =(~ ren.u.found))  %.n
  =/  prefix=path  ~[(scot %p our.b) desk.target (scot %ud revision.target)]
  ?.  =(root.target .^(@uv %cz prefix))  %.n
  ?.  =(~ .^(* %ge /(scot %p our.b)/[desk.target]/(scot %da now.b)/$))  %.n
  =/  permissions=[r=dict:clay w=dict:clay]  .^([r=dict:clay w=dict:clay] %cp prefix)
  ?.  &(=([%white ~ ~] rul.r.permissions) =([%white ~ ~] rul.w.permissions))  %.n
  =/  file-rules=[r=dict:clay w=dict:clay]  .^([r=dict:clay w=dict:clay] %cp (weld prefix file.target))
  &(=([%white ~ ~] rul.r.file-rules) =([%white ~ ~] rul.w.file-rules))
++  native
  |=  [b=bowl:gall cmd=command value=saved:saved]
  ^-  (each prepared @tas)
  =/  window=(unit window:law)  ~
  =/  target-ok=?  %.y
  ?.  &(=(our.b src.b) =(our.b owner.cmd))  (prepare our.b src.b cmd value window %.n)
  ?:  (~(has by commands.value) request.cmd)  (prepare our.b src.b cmd value window target-ok)
  =?  target-ok  =(%propose-land op.cmd)
    ?~(target.cmd %.n (target-private b u.target.cmd))
  ?:  !=(%approve-land op.cmd)  (prepare our.b src.b cmd value window target-ok)
  ?.  (agent-live:native-guard our.b now.b %cantrip)  [%| %cantrip-unavailable]
  =.  window
    ((soft window:law) .^(* %gx /(scot %p our.b)/cantrip/(scot %da now.b)/law/window/current/noun))
  ?~  window  [%| %current-law-unavailable]
  =/  held  (~(get by pacts.state.value) pact.cmd)
  ?~  held  [%| %unknown-pact]
  =/  held-round  (current-round value.u.held artifacts.value pact.cmd)
  ?~  held-round  [%| %inactive-pact]
  ?~  proposal.u.held-round  [%| %proposal-missing]
  =.  target-ok  (target-private b target.u.proposal.u.held-round)
  (prepare our.b src.b cmd value window target-ok)
++  ready-request
  |=  req=inbound-request:eyre
  ^-  ?
  =/  host  (header:mg header-list.request.req 'host')
  =/  origin  (header:mg header-list.request.req 'origin')
  =/  mime  (header:mg header-list.request.req 'content-type')
  ?~  host  %.n
  ?~  origin  %.n
  ?~  mime  %.n
  ?&  =(u.origin (cat 3 ?:(secure.req 'https://' 'http://') u.host))
      |(=(u.mime 'application/json') =(u.mime 'application/json; charset=utf-8'))
      =(`'artifact-v1' (header:mg header-list.request.req 'x-readymade-artifact'))
  ==
++  result-json
  |=  [our=@p cmd=command status=@t message=@t duplicate=?]
  ^-  json
  %-  pairs:enjs:format
  ^-  (list [@t json])
  :~  ['schema' s+'readymade-artifact-action-result-v1']
      ['status' s+status]
      ['owner' s+(scot %p our)]
      ['peer' s+(scot %p peer.cmd)]
      ['request' s+request.cmd]
      ['op' s+(scot %tas op.cmd)]
      ['pact' s+(scot %ux pact.cmd)]
      ['selected' s+(scot %ux selected.cmd)]
      ['guard' s+(scot %ux guard.cmd)]
      ['localRecorded' b+=('confirmed' status)]
      ['duplicate' b+duplicate]
      ['sharedExecution' b+%.n]
      ['message' s+message]
  ==
++  lookup
  |=  [our=@p cmd=command value=saved:saved]
  ^-  [code=@ud body=json]
  ?.  =(our owner.cmd)
    [403 (result-json our cmd 'refused' 'Owner mismatch.' %.n)]
  =/  found  (~(get by commands.value) request.cmd)
  ?~  found
    [404 (result-json our cmd 'uncertain' 'Request is not recorded; an in-flight POST may still arrive. Do not resubmit.' %.n)]
  ?.  =(u.found (fingerprint cmd))
    [409 (result-json our cmd 'refused' 'Request identifier conflict.' %.n)]
  [200 (result-json our cmd 'confirmed' 'Exact request recorded locally; peer delivery and execution are separate.' %.y)]
++  read-result-request
  |=  req=inbound-request:eyre
  ^-  (unit command)
  =/  raw  (header:mg header-list.request.req 'x-readymade-artifact-command')
  ?~  raw  ~
  (parse u.raw)
--
