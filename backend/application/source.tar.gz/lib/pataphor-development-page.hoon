::  Pataphor project presentation. Canonical Viki data supplies every outcome.
/-  pc=pataphor-project-coding
/+  coding=pataphor-project-coding, ui=pataphor-chat-page, save=cantrip-project-save,
    text=pataphor-glass-project-page
|%
+$  form  [manifest=@ux prior=(unit @ux) text=@t]
++  href
  |=  selected=(unit @ux)
  ^-  @t
  =/  base=@t  '/apps/pataphor-work?glass=1&project=pataphor'
  ?~  selected  base
  (rap 3 ~[base '&request=' (scot %ux u.selected)])
++  hex
  |=  raw=@t
  ^-  (unit @ux)
  =/  parsed  (slaw %ux raw)
  ?~  parsed  ~
  ?.  &(!=(0 u.parsed) (lte (met 0 u.parsed) 256))  ~
  ?.  =(raw (scot %ux u.parsed))  ~
  parsed
++  decode
  |=  [token=@uv body=@t]
  ^-  (unit form)
  ?.  &(!=(0 token) (lte (met 3 body) 16.384))  ~
  ?:  ?=(^ (find (trip '%00') (trip body)))  ~
  =/  parsed  (rush (cat 3 '?' body) yque:de-purl:html)
  ?~  parsed  ~
  ?.  =(6 (lent u.parsed))  ~
  =/  fields  (~(gas by *(map @t @t)) u.parsed)
  ?.  =(6 ~(wyt by fields))  ~
  ?.  ?&  =(`(scot %uv token) (~(get by fields) 'nonce'))
          =(`'develop' (~(get by fields) 'op'))
          =(`'pataphor' (~(get by fields) 'project'))
      ==  ~
  =/  manifest  (~(get by fields) 'manifest')
  =/  prior  (~(get by fields) 'prior')
  =/  content  (~(get by fields) 'text')
  ?.  ?&(?=(^ manifest) ?=(^ prior) ?=(^ content))  ~
  =/  digest  (hex u.manifest)
  =/  normalized  (normalize:text u.content)
  ?.  &(?=(^ digest) ?=(^ normalized))  ~
  ?.  (text-valid:coding u.normalized)  ~
  =/  parent=(unit @ux)  ?:  =('' u.prior)  ~
    (hex u.prior)
  ?:  &(!=('' u.prior) ?=(~ parent))  ~
  `[u.digest parent u.normalized]
++  nonce
  |=  [our=@p token=@uv item=form]
  ^-  @ux
  `@ux`(sham [%pataphor-development-form-v1 our token item])
++  field
  |=  [name=@t value=@t]
  ^-  @t
  (rap 3 ~['<dt>' (escape:ui name) '</dt><dd>' (escape:ui value) '</dd>'])
++  preview-html
  ::  Accept only the fixed native preview renderer's two text-node slots.
  ::  Entities remain text; no supplied markup enters either slot.
  |=  body=@t
  ^-  (unit @t)
  =/  prefix=@t
    '<section><h3>Native module preview</h3><p>Evaluated saved libraries; no browser or message action was run.</p><h4>Workspace welcome</h4><pre>'
  =/  middle=@t  '</pre><h4>Noltbook reply</h4><pre>'
  =/  suffix=@t  '</pre></section>'
  =/  size=@ud  (met 3 body)
  =/  head=@ud  (met 3 prefix)
  =/  tail=@ud  (met 3 suffix)
  ?.  &((lte size 65.536) (gte size (add head tail)))  ~
  ?.  &(=(prefix (cut 3 [0 head] body)) =(suffix (cut 3 [(sub size tail) tail] body)))  ~
  =/  inner=@t  (cut 3 [head (sub size (add head tail))] body)
  =/  split  (find (trip middle) (trip inner))
  ?~  split  ~
  =/  welcome=@t  (cut 3 [0 u.split] inner)
  =/  offset=@ud  (add u.split (met 3 middle))
  =/  reply=@t  (cut 3 [offset (sub (met 3 inner) offset)] inner)
  =/  fragments=(list @t)  ~[welcome reply]
  ?.  %+  levy  fragments
      |=  fragment=@t
      ?&  (lte (met 3 fragment) 24.576)
          (levy (trip fragment) |=(c=@tD &(!=('<' c) !=('>' c))))
      ==  ~
  `(rap 3 ~[prefix welcome middle reply suffix])
++  preview
  |=  p=preview:pc
  ^-  @t
  =/  rendered=(unit @t)
    ?:  ?=(%html -.p)  (preview-html body.p)
    ~
  ?^  rendered  u.rendered
  (rap 3 ~['<details><summary>Preview output</summary><pre>' (escape:ui body.p) '</pre></details>'])
++  result
  |=  r=result:pc
  ^-  @t
  %+  rap  3
  :~  '<article class="exchange"><h2>'
      (escape:ui text.request.r)
      '</h2><dl>'
      (field 'Status' `@t`phase.r)
      (field 'Request' (scot %ux nonce.request.r))
      (field 'Provider' 'Codex')
      (field 'Project basis' (scot %ux manifest.request.r))
      ?~(reason.r '' (field 'Reason' `@t`u.reason.r))
      ?~(receipt.r '' (field 'Saved receipt' (scot %ux u.receipt.r)))
      ?~(saved.r '' (field 'Saved revision' (scot %ud number.u.saved.r)))
      '</dl><h3>Changes</h3>'
      ?~  edits.r  '<p>No retained changes yet.</p>'
      %+  rap  3
      %+  turn  edits.r
      |=  e=edit:save
      (rap 3 ~['<details><summary>' (escape:ui (spat path.change.e)) '</summary><pre>' (escape:ui source.e) '</pre></details>'])
      '<h3>Checks</h3>'
      ?~  checks.r  '<p>No retained check results yet.</p>'
      %+  rap  3
      %+  turn  checks.r
      |=  c=check:pc
      (rap 3 ~['<p>' (escape:ui (spat pax.c)) ' · ' (escape:ui `@t`name.c) ': ' ?:(passed.c 'Passed' 'Failed') '</p><pre>' (escape:ui detail.c) '</pre>'])
      ?~  preview.r  '<p>No retained preview output yet.</p>'
      (preview u.preview.r)
      '</article>'
  ==
++  terminal
  ^-  @t
  %+  rap  3
  :~  '<section class="terminal-pane"><iframe name="pataphor-terminal" title="Interactive terminal" src="/apps/pataphor-terminal"></iframe>'
      '</section>'
  ==
++  page
  |=  [our=@p token=@uv selected=(unit @ux) current=(each view:pc @tas)]
  ^-  @t
  %+  rap  3
  :~  '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Pataphor Terminal</title><style>'
      css:ui  workspace-css:ui
      'html,body{height:100%;overflow:hidden}body{font:13px/1.4 system-ui,sans-serif}main{height:100vh;height:100dvh;max-width:none;margin:0;padding:0;display:flex;flex-direction:column}header{flex:none;height:40px;padding:0 14px;gap:12px;background:#202024}header h1{font-size:13px;letter-spacing:.3px;margin:0}nav.tools{flex:none;margin:0;padding:0 12px;min-height:36px;gap:18px;border-bottom:1px solid #333;background:#18181b}.tools a{padding:8px 0}.terminal-pane{flex:1;min-height:0;display:flex}.terminal-pane iframe{display:block;width:100%;height:100%;min-height:0;border:0}.project-history{flex:none;border-top:1px solid #333;background:#202024}.project-history>summary{padding:7px 14px;cursor:pointer}.history-body{max-height:40vh;overflow:auto;padding:12px 20px}dd{margin-inline-start:0;overflow-wrap:anywhere}@media(max-width:640px){header{height:36px;align-items:center}nav.tools{gap:12px;font-size:12px}main{padding:0}}'
      '</style></head><body><main>'
      '<header><h1>PATAPHOR / TERMINAL</h1><a href="/apps/pataphor" target="_top">Workspace</a></header>'
      '<nav class="tools" aria-label="Workspace panels"><a href="/apps/pataphor-terminal" target="pataphor-terminal">Terminal</a><a href="/apps/pataphor-native" target="pataphor-terminal">Viki coding</a><a href="/apps/pataphor-native/coding" target="pataphor-terminal">Native coding</a><a href="/portal" target="_blank" rel="noopener noreferrer">Portal</a><a href="/apps/pataphor-terminal" target="_blank" rel="noopener noreferrer">Open terminal</a></nav>'
      terminal
      ?~(selected '<details class="project-history">' '<details class="project-history" open>')
      '<summary>Saved work and checks</summary><div class="history-body">'
      ?:  ?=(%| -.current)
        (rap 3 ~['<p class="notice">Project unavailable: ' (escape:ui `@t`p.current) '. Refresh to observe saved progress.</p>'])
      =/  v=view:pc  p.current
      =/  found=(unit result:pc)
        ?~  selected  ~
        (find-result u.selected results.v)
      %+  rap  3
      :~  ?~  selected
            '<h2>Saved project work</h2>'
          ?~  found
            '<p class="notice">This request is not confirmed. Refresh this same address; do not submit it again.</p>'
          (result u.found)
          ?^  selected  ''
          %+  rap  3
          %+  turn  results.v
          |=  r=result:pc
          (rap 3 ~['<p><a href="' (escape:ui (href `nonce.request.r)) '">' (escape:ui text.request.r) '</a> · ' (escape:ui `@t`phase.r) '</p>'])
          '<p><a href="'
          (escape:ui (href selected))
          '">Refresh saved progress</a></p>'
      ==
      '</div></details></main></body></html>'
  ==
++  find-result
  |=  [key=@ux rows=(list result:pc)]
  ^-  (unit result:pc)
  ?~  rows  ~
  ?:  =(key nonce.request.i.rows)  `i.rows
  $(rows t.rows)
--
