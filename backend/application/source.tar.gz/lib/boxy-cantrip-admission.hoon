::  /lib/boxy-cantrip-admission.hoon
::
::  Pure Boxy-to-Cantrip admission law.  Requests carry no actor.  Gall shells
::  pass authenticated `our` and `src` separately, and Boxy applies a verdict
::  only on the exact resident-Cantrip watch duct.
::
/-  bx=boxy, ca=cantrip-action
/+  bl=boxy-law
|%
++  request-for
  |=  [workspace=workspace-state:bx motion-id=@t]
  ^-  (unit boxy-motion-admission-request:ca)
  =/  found=(unit stored-motion:bx)
    (~(get by motions.workspace) motion-id)
  ?~  found  ~
  =/  stored=stored-motion:bx  u.found
  ?:  executed.stored  ~
  ?:  ?&  ?=(^ admission.stored)
          (admission-valid-for:bl workspace stored u.admission.stored)
      ==
    ~
  ?.  (policy-satisfied:bl policy.workspace members.workspace votes.stored)
    ~
  `[(admission-binding-for:bl workspace stored) motion.stored]
::
++  request-valid
  |=  [workspace=workspace-state:bx request=boxy-motion-admission-request:ca]
  ^-  ?
  =/  found=(unit stored-motion:bx)
    (~(get by motions.workspace) motion-id.binding.request)
  ?~  found  %.n
  =/  stored=stored-motion:bx  u.found
  ?&  !executed.stored
      =(motion.request motion.stored)
      =(binding.request (admission-binding-for:bl workspace stored))
      (policy-satisfied:bl policy.workspace members.workspace votes.stored)
  ==
::
++  request-key-for
  |=  request=boxy-motion-admission-request:ca
  ^-  @ux
  (shax (jam request))
::
++  receipt-id-for
  |=  request=boxy-motion-admission-request:ca
  ^-  @t
  (cat 3 'boxy-motion-admission-' (scot %ux (request-key-for request)))
::
++  verdict-for
  |=  [workspace=workspace-state:bx request=boxy-motion-admission-request:ca]
  ^-  boxy-motion-admission-verdict:ca
  =/  receipt-id=@t  (receipt-id-for request)
  ?.  (request-valid workspace request)
    [binding.request receipt-id %.n 'cantrip-boxy-motion-v1' 'invalid-boxy-decision-binding']
  ?-  -.authorship.motion.request
    %human
      [binding.request receipt-id %.y 'cantrip-boxy-motion-v1' 'admitted-human-motion']
    %model-assisted
      [binding.request receipt-id %.y 'cantrip-boxy-motion-v1' 'admitted-assisted-motion']
    %model-proposed
      [binding.request receipt-id %.n 'cantrip-boxy-motion-v1' 'model-proposal-cannot-execute']
  ==
::
::  THE CONSENT LAW (ladder 9): the only verdict beyond the base form that
::  Boxy may apply is the principal-approved lift of a %model-proposed
::  refusal, and it collapses to the base form for every other authorship,
::  so approval can never widen what the base law already admits.  The
::  verdict still arrives only on the exact resident-Cantrip watch duct,
::  and Cantrip's ledger records the approved form solely through Hand's
::  principal-only consent lane.
++  verdict-approved-for
  |=  [workspace=workspace-state:bx request=boxy-motion-admission-request:ca]
  ^-  boxy-motion-admission-verdict:ca
  =/  base=boxy-motion-admission-verdict:ca  (verdict-for workspace request)
  ?.  ?=(%model-proposed -.authorship.motion.request)  base
  ?.  (request-valid workspace request)  base
  base(admitted %.y, reason 'admitted-principal-approved-motion')
::
++  verdict-valid
  |=  $:  workspace=workspace-state:bx
          request=boxy-motion-admission-request:ca
          verdict=boxy-motion-admission-verdict:ca
      ==
  ^-  ?
  ?&  (request-valid workspace request)
      ?|  =(verdict (verdict-for workspace request))
          =(verdict (verdict-approved-for workspace request))
      ==
  ==
::
++  apply-verdict
  |=  $:  state=state:bx
          our=@p
          src=@p
          request=boxy-motion-admission-request:ca
          verdict=boxy-motion-admission-verdict:ca
      ==
  ^-  result:bx
  ?.  =(our src)  (refuse:bl state %principal-source-required)
  =/  found=(unit workspace-state:bx)
    (~(get by workspaces.state) workspace.binding.request)
  ?~  found  (refuse:bl state %workspace-not-found)
  ?.  (verdict-valid u.found request verdict)
    (refuse:bl state %cantrip-verdict-invalid)
  (record-admission:bl state workspace.binding.request motion-id.binding.request verdict)
--
