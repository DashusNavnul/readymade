::  A bounded view of one retained Viki review. No new judgment or grant.
/-  nc=native-coding
/+  review=native-coding-review, accept=native-coding-accept,
    law=native-coding-project, files=native-coding-files, h=readymade-history,
    data=readymade-native-review-data, binding=readymade-git-review-binding,
    guard=viki-scry-guard
|%
+$  check  check:data
+$  edit  edit:data
+$  detail  detail:data
+$  snapshot  snapshot:data
++  token  token:data
++  empty
  |=  [our=@p id=@ux problem=(unit @tas)]
  ^-  snapshot
  [%readymade-native-review-v1 our id ~ problem]
++  project
  |=  [our=@p id=@ux entry=(unit entry:review)]
  ^-  snapshot
  ?~  entry  (empty our id ~)
  =/  e=entry:review  u.entry
  =/  c=candidate:nc  candidate.e
  ?.  ?&  =(id id.c)  =(our actor.context.c)  =(our owner.source.context.c)
          (revision-valid:law source.context.c)
          =(source.context.c revision.basis.c)
          =((candidate-digest:files c) id.c)
          (gte (lent edits.c) 1)  (lte (lent edits.c) 32)
          (levy edits.c |=(e=edit:nc (path-valid:law path.change.e)))
      ==  (empty our id `%source-mismatch)
  =/  value=detail
    :*  id  session.context.c  source.context.c  %requested
        (turn (scag 32 edits.c) |=(e=edit:nc [path.change.e kind.change.e before.change.e after.change.e]))
        (lent edits.c)  ~  0  ~  ~  ~  ~  ~
    ==
  ?~  observed.e
    ?^  decision.e  (empty our id `%decision-without-report)
    [%readymade-native-review-v1 our id `value ~]
  =/  record=record:accept  u.observed.e
  ?.  &(=(candidate.record c) (valid:accept (malt ~[[id record]])))
    (empty our id `%review-record-mismatch)
  =.  value  value(stage stage.record, reason reason.record)
  ?.  ?~  decision.e  %.y
        &((decision-valid:accept project.record c u.decision.e) =(report.record `report.u.decision.e))
    (empty our id `%decision-report-mismatch)
  =.  decision.value  ?~(decision.e ~ `verdict.u.decision.e)
  =.  landed.value  ?~(landed.record ~ `revision.u.landed.record)
  ?~  report.record  [%readymade-native-review-v1 our id `value ~]
  =/  report=report:accept  u.report.record
  =/  all=(list check)
    %-  zing
    %+  turn  targets.report
    |=  t=target-result:accept
    %+  turn  diagnostics.t
    |=  d=diagnostic:nc
    [name.target.t name.d passed.d source.d (bounded:h detail.d 512)]
  =.  value
    value(checks (scag 64 all), check-total (lent all), checked `revision.staging.report, passed `(passed:accept report))
  [%readymade-native-review-v1 our id `value ~]
++  route
  |=  pax=path
  ^-  (unit @ux)
  ?.  ?=([%readymade %native-review @ ~] pax)  ~
  (token i.t.t.pax)
++  review-path
  |=  pax=path
  ?=([%readymade %native-review *] pax)
++  paths
  |=  b=bowl:gall
  ^-  (list path)
  =/  wanted=(list path)
    %+  murn  ~(val by sup.b)
    |=  [who=@p pax=path]
    ^-  (unit path)
    ?.  &(=(our.b who) ?=(^ (route pax)))  ~
    `pax
  ~(tap in (silt wanted))
++  read
  ::  Pure calls into the retained core, never an external scry or effect.
  |=  [inner=agent:gall b=bowl:gall id=@ux]
  ^-  snapshot
  =/  got=(each snapshot tang)
    %-  mule
    |.
    =/  ag  ~(. inner b(src our.b))
    =/  raw=(unit (unit cage))
      (on-peek:ag /x/native-coding/review/[(scot %ux id)])
    ?~  raw  (empty our.b id `%native-unavailable)
    ?~  u.raw  (empty our.b id `%native-unavailable)
    ?.  =(%noun p.u.u.raw)  (empty our.b id `%incompatible-review)
    =/  entry=(unit (unit entry:review))  ((soft ,(unit entry:review)) q.q.u.u.raw)
    ?~  entry  (empty our.b id `%incompatible-review)
    (project our.b id u.entry)
  ?:(?=(%& -.got) p.got (empty our.b id `%incoherent-review))
++  git-source
  ::  Probe an existing path first: +mule cannot catch a missing Gall scry.
  |=  [our=@p at=@da selected=selection:binding]
  ^-  (each * @tas)
  ?.  (agent-live:guard our at %urgit)  [%| %git-agent-unavailable]
  =/  capability=*
    .^(* %gx /(scot %p our)/urgit/(scot %da at)/visibility/build/noun)
  ?.  =(marker:binding capability)  [%| %git-proposal-unsupported]
  =/  pax=path  (proposal-path:binding selected)
  [%& .^(* %gx (weld ~[(scot %p our) %urgit (scot %da at)] (weld pax /noun)))]
++  git-read-with
  ::  Injected reader is inert in proofs; production supplies only +git-source.
  |=  [inner=agent:gall b=bowl:gall selected=selection:binding source=$-([@p @da selection:binding] (each * @tas))]
  ^-  snapshot:binding
  ?.  (selection-valid:binding selected)  (empty:binding our.b selected %selection-invalid)
  =/  got=(each snapshot:binding tang)
    %-  mule
    |.
    =/  ag  ~(. inner b(src our.b))
    =/  raw=(unit (unit cage))
      (on-peek:ag /x/native-coding/candidate/[(scot %ux candidate.selected)])
    ?~  raw  (empty:binding our.b selected %native-candidate-unavailable)
    ?~  u.raw  (empty:binding our.b selected %native-candidate-unavailable)
    ?.  =(%noun p.u.u.raw)  (empty:binding our.b selected %native-candidate-incompatible)
    =/  c=(unit (unit candidate:nc))  ((soft ,(unit candidate:nc)) q.q.u.u.raw)
    ?~  c  (empty:binding our.b selected %native-candidate-incompatible)
    ?~  u.c  (empty:binding our.b selected %native-candidate-unavailable)
    =/  review-raw=(unit (unit cage))
      (on-peek:ag /x/native-coding/review/[(scot %ux candidate.selected)])
    ?~  review-raw  (empty:binding our.b selected %native-review-unavailable)
    ?~  u.review-raw  (empty:binding our.b selected %native-review-unavailable)
    ?.  =(%noun p.u.u.review-raw)  (empty:binding our.b selected %native-review-incompatible)
    =/  e=(unit (unit entry:review))  ((soft ,(unit entry:review)) q.q.u.u.review-raw)
    ?~  e  (empty:binding our.b selected %native-review-incompatible)
    ?~  u.e  (empty:binding our.b selected %native-review-unavailable)
    =/  git=(each * @tas)  (source our.b now.b selected)
    ?:  ?=(%| -.git)  (empty:binding our.b selected p.git)
    ::  Two full manifests have a finite transport budget, before decoding.
    ?.  (lte (met 3 (jam p.git)) 2.621.440)  (empty:binding our.b selected %git-receipt-over-limit)
    =/  parsed=(unit (each proposal:binding @tas))
      ((soft ,(each proposal:binding @tas)) p.git)
    ?~  parsed  (empty:binding our.b selected %git-receipt-incompatible)
    ?:  ?=(%| -.u.parsed)  (empty:binding our.b selected p.u.parsed)
    (project:binding our.b selected p.u.parsed u.u.c u.u.e)
  ?:(?=(%& -.got) p.got (empty:binding our.b selected %git-review-incoherent))
++  capture
  |=  [inner=agent:gall b=bowl:gall]
  ^-  (map path snapshot)
  %-  malt
  (turn (paths b) |=(pax=path [pax (read inner b (need (route pax)))]))
++  updates
  |=  [before=(map path snapshot) after=(map path snapshot) reseed=?]
  ^-  (list card:agent:gall)
  %+  murn  ~(tap by after)
  |=  [pax=path value=snapshot]
  ^-  (unit card:agent:gall)
  ?:  &(!reseed =(`value (~(get by before) pax)))  ~
  `[%give %fact ~[pax] %noun !>(value)]
++  agent-with
  ::  No state version or command surface. Preserve every inner effect/save.
  |=  [inner=agent:gall source=$-([@p @da selection:binding] (each * @tas))]
  ^-  agent:gall
  |_  =bowl:gall
  +*  this  .
      ag  ~(. inner bowl)
  ++  on-init
    =^  cards  inner  on-init:ag
    [(weld cards (updates ~ (capture inner bowl) %.y)) this]
  ++  on-save  on-save:ag
  ++  on-load
    |=  old=vase
    =^  cards  inner  (on-load:ag old)
    [(weld cards (updates ~ (capture inner bowl) %.y)) this]
  ++  on-poke
    |=  [=mark =vase]
    =/  before  (capture inner bowl)
    =^  cards  inner  (on-poke:ag mark vase)
    [(weld cards (updates before (capture inner bowl) %.n)) this]
  ++  on-watch
    |=  =path
    ?:  (review-path path)
      ?>  =(src.bowl our.bowl)
      ?~  id=(route path)  !!
      ?>  (lte (lent ~(tap in (silt [path (paths bowl)]))) 16)
      [~[[%give %fact ~[path] %noun !>((read inner bowl u.id))]] this]
    =/  before  (capture inner bowl)
    =^  cards  inner  (on-watch:ag path)
    [(weld cards (updates before (capture inner bowl) %.n)) this]
  ++  on-leave
    |=  =path
    ?:  (review-path path)  [~ this]
    =/  before  (capture inner bowl)
    =^  cards  inner  (on-leave:ag path)
    [(weld cards (updates before (capture inner bowl) %.n)) this]
  ++  on-peek
    |=  =path
    ?:  ?=([%x %readymade %git-review *] path)
      ?.  =(src.bowl our.bowl)  ~
      ?~  selected=(route:binding path)
        ``noun+!>((empty:binding our.bowl *selection:binding %selection-invalid))
      ``noun+!>((git-read-with inner bowl u.selected source))
    ?:  ?=([%x %readymade %native-review *] path)
      ?.  =(src.bowl our.bowl)  ~
      ?~  id=(route t.path)  ~
      ``noun+!>((read inner bowl u.id))
    (on-peek:ag path)
  ++  on-agent
    |=  [=wire =sign:agent:gall]
    =/  before  (capture inner bowl)
    =^  cards  inner  (on-agent:ag wire sign)
    [(weld cards (updates before (capture inner bowl) %.n)) this]
  ++  on-arvo
    |=  [=wire sign=sign-arvo]
    =/  before  (capture inner bowl)
    =^  cards  inner  (on-arvo:ag wire sign)
    [(weld cards (updates before (capture inner bowl) %.n)) this]
  ++  on-fail
    |=  [=term =tang]
    =/  before  (capture inner bowl)
    =^  cards  inner  (on-fail:ag term tang)
    [(weld cards (updates before (capture inner bowl) %.n)) this]
  --
++  agent
  |=  inner=agent:gall
  ^-  agent:gall
  (agent-with inner git-source)
--
