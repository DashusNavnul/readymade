::  /lib/graf-ac.hoon
::
::  the aho-corasick engine graf-search promised: a batch of noun
::  patterns (facts with holes) compiles into ONE automaton, and every
::  fact is judged in a single bottom-up pass that fires all patterns
::  simultaneously.  adding patterns to the batch is free; the store
::  can grow without recall slowing per-pattern.
::
::  the contract is graf-search's, verbatim: a pattern is %any (a
::  hole), %is (this exact noun), or %cell (head and tail patterns).
::  ++search-fast must equal the reference scan { f | some p matches }
::  — same meaning, different mechanism.  ted/ph/graf-ac-proof holds
::  the two against each other.
::
::  mechanism: hash-cons the batch's pattern nodes into an id space;
::  for each fact compute, bottom-up, the SET of node-ids each subtree
::  satisfies (%any everywhere, %is by exact-noun table lookup, %cell
::  where the head set holds l and the tail set holds r).  a fact
::  matches pattern P iff P's root id lands in the fact's root set.
::  ++mentions asks the unanchored question: does ANY subtree fire.
::
|%
+$  pat
  $~  [%any ~]
  $%  [%any ~]
      [%is p=*]
      [%cell l=pat r=pat]
  ==
::
+$  engine
  $:  any-ids=(set @ud)
      is-table=(map * (set @ud))
      cell-nodes=(list [id=@ud l=@ud r=@ud])
      roots=(list [index=@ud id=@ud])
      next-id=@ud
  ==
::
+$  intern-state
  $:  seen=(map pat @ud)
      eng=engine
  ==
::
++  intern
  |=  [st=intern-state =pat]
  ^-  [@ud intern-state]
  =/  hit  (~(get by seen.st) pat)
  ?^  hit  [u.hit st]
  ?-    -.pat
      %any
    =/  id  next-id.eng.st
    =.  eng.st
      %=  eng.st
        next-id  +(id)
        any-ids  (~(put in any-ids.eng.st) id)
      ==
    =.  seen.st  (~(put by seen.st) pat id)
    [id st]
  ::
      %is
    =/  id  next-id.eng.st
    =/  cur=(set @ud)  (~(gut by is-table.eng.st) p.pat *(set @ud))
    =.  eng.st
      %=  eng.st
        next-id   +(id)
        is-table  (~(put by is-table.eng.st) p.pat (~(put in cur) id))
      ==
    =.  seen.st  (~(put by seen.st) pat id)
    [id st]
  ::
      %cell
    =^  lid=@ud  st  $(pat l.pat)
    =^  rid=@ud  st  $(pat r.pat)
    =/  id  next-id.eng.st
    =.  eng.st
      %=  eng.st
        next-id     +(id)
        cell-nodes  [[id lid rid] cell-nodes.eng.st]
      ==
    =.  seen.st  (~(put by seen.st) pat id)
    [id st]
  ==
::
++  compile
  |=  pats=(list pat)
  ^-  engine
  =/  st=intern-state  [~ *engine]
  =/  index  0
  |-  ^-  engine
  ?~  pats  eng.st
  =^  id=@ud  st  (intern st i.pats)
  =.  roots.eng.st  [[index id] roots.eng.st]
  $(pats t.pats, index +(index))
::
::  the set of pattern-node ids this noun satisfies, bottom-up
::
++  node-sets
  |=  [eng=engine n=*]
  ^-  (set @ud)
  =/  base=(set @ud)
    =/  hit  (~(get by is-table.eng) n)
    ?~  hit  any-ids.eng
    (~(uni in any-ids.eng) u.hit)
  ?@  n  base
  =/  ls  $(n -.n)
  =/  rs  $(n +.n)
  %-  ~(gas in base)
  %+  murn  cell-nodes.eng
  |=  [id=@ud l=@ud r=@ud]
  ^-  (unit @ud)
  ?:  &((~(has in ls) l) (~(has in rs) r))
    `id
  ~
::
::  anchored: does any pattern in the batch match this fact at root
::
++  fires
  |=  [eng=engine n=*]
  ^-  ?
  =/  hits  (node-sets eng n)
  (lien roots.eng |=([index=@ud id=@ud] (~(has in hits) id)))
::
::  unanchored: does any pattern match ANY subtree of this fact.
::  HONESTY NOTE: this recomputes node-sets at every subtree — O(n^2)
::  on deep facts.  fine for judging single facts against a batch;
::  do not put it in a hot loop over a large store (the string lane
::  and ++leaf-mentions are the linear recall lanes).
::
++  mentions
  |=  [eng=engine n=*]
  ^-  ?
  ?:  (fires eng n)  &
  ?@  n  |
  ?|($(n -.n) $(n +.n))
::
::  the one-pass batch search: contract-equal to the reference below
::
++  search-fast
  |=  [facts=(list *) pats=(list pat)]
  ^-  (list *)
  =/  eng  (compile pats)
  (skim facts |=(n=* (fires eng n)))
::
::  the string automaton: classic aho-corasick over term BYTES, with
::  failure links, so "does any term occur inside this cord" is one
::  scan of the text regardless of how many terms are in the batch.
::  this is the recall lane: a fact mentions a term when any atom leaf
::  contains it as a substring.
::
+$  str-ac
  $:  go=(map [n=@ud b=@tD] @ud)
      fail=(map @ud @ud)
      out=(set @ud)
      next=@ud
  ==
::
++  str-insert
  |=  [ac=str-ac term=@t]
  ^-  str-ac
  ?:  =('' term)  ac
  =/  bytes  (rip 3 term)
  =/  node  0
  |-  ^-  str-ac
  ?~  bytes
    ac(out (~(put in out.ac) node))
  =/  nx  (~(get by go.ac) [node i.bytes])
  ?^  nx
    $(bytes t.bytes, node u.nx)
  =/  new  ?:(=(0 next.ac) 1 next.ac)
  %=  $
    bytes  t.bytes
    node   new
    ac     ac(next +(new), go (~(put by go.ac) [node i.bytes] new))
  ==
::
++  str-step
  |=  [ac=str-ac node=@ud byte=@tD]
  ^-  @ud
  =/  nx  (~(get by go.ac) [node byte])
  ?^  nx  u.nx
  ?:  =(0 node)  0
  $(node (~(gut by fail.ac) node 0))
::
++  build-str
  |=  terms=(list @t)
  ^-  str-ac
  =/  ac=str-ac  [~ ~ ~ 1]
  =.  ac  (roll terms |=([t=@t a=_ac] (str-insert a t)))
  ::  breadth-first failure links: a child's fail is where its parent's
  ::  fail would go on the same byte; outputs propagate down fail links
  =/  kids=(map @ud (list [b=@tD c=@ud]))
    %+  roll  ~(tap by go.ac)
    |=  [[[n=@ud b=@tD] c=@ud] m=(map @ud (list [b=@tD c=@ud]))]
    (~(put by m) n [[b c] (~(gut by m) n ~)])
  =/  queue=(list @ud)
    (turn (~(gut by kids) 0 ~) |=([b=@tD c=@ud] c))
  |-  ^-  str-ac
  ?~  queue  ac
  =/  node=@ud  i.queue
  =/  nf=@ud  (~(gut by fail.ac) node 0)
  =/  children  (~(gut by kids) node ~)
  =/  inner
    |-  ^-  [ac=str-ac add=(list @ud)]
    ?~  children  [ac ~]
    =/  [b=@tD c=@ud]  i.children
    =/  f=@ud  (str-step ac nf b)
    =/  f=@ud  ?:(=(f c) 0 f)
    =.  fail.ac  (~(put by fail.ac) c f)
    =?  out.ac  (~(has in out.ac) f)  (~(put in out.ac) c)
    =/  rec  $(children t.children)
    [ac.rec [c add.rec]]
  =.  ac  ac.inner
  $(queue (weld t.queue add.inner))
::
++  str-finds
  |=  [ac=str-ac t=@]
  ^-  ?
  =/  bytes  (rip 3 t)
  =/  node  0
  |-  ^-  ?
  ?~  bytes  |
  =/  nx  (str-step ac node i.bytes)
  ?:  (~(has in out.ac) nx)  &
  $(bytes t.bytes, node nx)
::
::  a leaf is scanned as text only if it LOOKS like text: nonzero and
::  every byte printable ascii.  without this gate, numbers collide —
::  the @ud 25.960 IS the cord 'he' — and dates/hashes match short
::  terms at percent-level rates.  residual risk: an atom that happens
::  to be all-printable bytes still scans; erased nouns carry no types.
::
++  texty
  |=  n=@
  ^-  ?
  ?:  =(0 n)  |
  (levy (rip 3 n) |=(b=@ &((gte b 32) (lte b 126))))
::
::  recall: does any TEXT leaf of this fact contain any term
::
++  term-mentions
  |=  [ac=str-ac n=*]
  ^-  ?
  ?@  n  &((texty n) (str-finds ac n))
  ?|($(n -.n) $(n +.n))
::
::  exact recall: does any leaf EQUAL any term (linear walk, no
::  automaton needed — this is the %exact tree-kind lane)
::
++  leaf-mentions
  |=  [terms=(set @t) n=*]
  ^-  ?
  ?@  n  (~(has in terms) n)
  ?|($(n -.n) $(n +.n))
::
::  the reference (graf-search's ++match/++search semantics, verbatim):
::  kept here so the proof can hold engine and meaning together
::
++  match
  |=  [=pat n=*]
  ^-  ?
  ?-  -.pat
    %any   &
    %is    =(p.pat n)
    %cell  ?@  n  |
           ?&  $(pat l.pat, n -.n)
               $(pat r.pat, n +.n)
           ==
  ==
::
++  search-ref
  |=  [facts=(list *) pats=(list pat)]
  ^-  (list *)
  (skim facts |=(n=* (lien pats |=(=pat (match pat n)))))
--
