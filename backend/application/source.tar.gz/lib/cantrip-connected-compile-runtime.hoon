::  Future Cantrip Gall hooks supply their own bowl, journals and current law.
::  No command accepts an admission, compiler status, or receipt as authority.
/+  core=cantrip-connected-compile, read=cantrip-connected-compile-read,
    ledger=cantrip-connected-compile-ledger, protocol=vibecoding-compile-protocol,
    worker=vibecoding-compiler-runtime, write=cantrip-connected-write,
    editor=cantrip-editor-save, law=cantrip-law-window,
    cflect=cantrip-compile-flect, shadow=cantrip-shadow
|%
++  owned
  |=  [writes=ledger:write saves=ledger:editor key=@ux]
  ^-  owned:read
  [(~(get by writes) key) (~(get by saves) key)]
++  start
  |=  [b=bowl:gall held=ledger:ledger writes=ledger:write saves=ledger:editor c=command:ledger window=window:law]
  ^-  result:ledger
  ?.  =(our.b src.b)  [%| %foreign-actor]
  ?.  (linked:ledger our.b held writes saves)  [%| %journal-invalid]
  =/  prior  (lookup:ledger our.b held c)
  ?:  ?=(%| -.prior)  [%| p.prior]
  ::  An exact replay is an observation, even after the original deadline.
  ?^  p.prior  [%& [held ~[(publish:ledger held nonce.c)]]]
  ?:  (gte ~(wyt by held) 32)  [%| %capacity]
  ?:  (lien ~(val by held) pending:ledger)  [%| %compile-in-progress]
  =/  frozen
    (read:read our.b src.b now.b nonce.c binding.c (owned writes saves nonce.c) window)
  ?:  ?=(%| -.frozen)  [%| p.frozen]
  (reserve:ledger our.b now.b held c p.frozen)
++  observe
  ::  Local observation never contacts the worker or sends an order.
  |=  [our=@p actor=@p held=ledger:ledger key=@ux]
  ^-  (each status:ledger @tas)
  ?.  =(our actor)  [%| %foreign-actor]
  ?.  &(!=(0 key) (lte (met 0 key) 128) (valid:ledger our held))  [%| %request-or-journal-invalid]
  [%& (read:ledger held key)]
++  event
  |=  [b=bowl:gall held=ledger:ledger writes=ledger:write saves=ledger:editor w=wire sign=sign:agent:gall window=window:law]
  ^-  transition:ledger
  =/  unchanged=transition:ledger  [held ~]
  =/  key  (key-for:ledger w)
  ?~  key  unchanged
  =/  found  (~(get by held) u.key)
  ?~  found  unchanged
  =/  e=entry:ledger  u.found
  =/  s=snapshot:core  snapshot.e
  ?.  &((linked:ledger our.b held writes saves) (pending:ledger e) =(src.b worker.order.s))  unchanged
  ?.  (lte at.order.s now.b)  unchanged
  =/  stop
    |=  reason=@tas
    (stop:ledger our.b now.b held u.key reason)
  ::  Gall removes wex before negative acknowledgments and kicks. They may
  ::  close an exact pending wire, but cannot grant authority or send work.
  ?:  ?=(%kick -.sign)  (stop %watch-kicked)
  ?:  &(?=(%watch-ack -.sign) ?=(^ p.sign))  (stop %watch-rejected)
  =/  subscribed  (~(get by wex.b) [w worker.order.s %vibecoding-compiler])
  ?.  =(subscribed `[%.y /result/(scot %ux (digest:protocol order.s))])  unchanged
  ?:  (gte now.b expires.order.s)  (stop %compiler-deadline)
  ?:  ?=(%watch-ack -.sign)
    ?.  =(%watching phase.e)  unchanged
    ::  No asynchronous boundary between current law/source/approval reads,
    ::  retaining sent=now, and the single unchanged worker order card.
    =/  [judged=decision:core ev=(unit evidence:read)]
      (admit-evidence:read our.b our.b now.b s (owned writes saves u.key) window)
    ::  A refusal before the judge ran (no act read) is the read's own.
    ?~  ev
      =/  sent  (send:ledger our.b now.b held u.key judged)
      ?:(?=(%& -.sent) p.sent (stop p.sent))
    ::  GEOMETRY DECIDES (phase 10 cut-over, 2026-09-27): the compile act
    ::  against the compile law (lib/cantrip-compile-flect, proven to agree
    ::  with the judge on every fixture, verdict and reason).  The judge is
    ::  the CONTROL: a disagreement in either direction stops the entry as
    ::  %law-control-disagrees; a refusal carries the law's reason.  The
    ::  receipt -- both verdicts -- is an append-only graf fact either way.
    =/  a=act:cflect  [s view.u.ev stated.u.ev]
    =/  e=env:cflect  [our.b src.b now.b window]
    =/  sh  (shadow-with:shadow %connected-compile compile-law:cflect !>(`act:cflect`a) e judged)
    =/  fit=?  fit.verdict.receipt.sh
    =/  admitted=decision:core
      ?.  =(fit ?=(%& -.judged))  [%| %law-control-disagrees]
      ?.  fit  [%| (fall (reason:cflect receipt.sh a e) %law-refused)]
      judged
    =/  sent  (send:ledger our.b now.b held u.key admitted)
    ?.  ?=(%& -.sent)  (stop p.sent)
    =/  receipt-card=card:agent:gall
      [%pass /connected-compile-evidence %agent [our.b %graf] %poke %graf-action !>([%attest (fact:shadow sh)])]
    p.sent(cards (snoc cards.p.sent receipt-card))
  ?.  ?=(%fact -.sign)  unchanged
  ?.  =(%running phase.e)  unchanged
  ?.  =(%noun p.cage.sign)  (stop %wrong-mark)
  =/  raw=*  q.q.cage.sign
  ?:  (gth (met 3 (jam raw)) 2.100.000)  (stop %worker-output-over-limit)
  =/  status  ((soft ,status:worker) raw)
  ?~  status  (stop %worker-status-invalid)
  =/  received  (receive:ledger our.b src.b now.b held u.key u.status)
  ?:(?=(%& -.received) p.received (stop p.received))
++  poke-ack
  ::  An error on the order's distinct wire closes an uncertain submission;
  ::  success is not compilation, and neither path can dispatch another order.
  |=  [b=bowl:gall held=ledger:ledger w=wire sign=sign:agent:gall]
  ^-  transition:ledger
  =/  unchanged=transition:ledger  [held ~]
  ?.  &((valid:ledger our.b held) ?=(%poke-ack -.sign))  unchanged
  ?~  p.sign  unchanged
  =/  rows  ~(tap by held)
  |-  ^-  transition:ledger
  ?~  rows  unchanged
  =/  e=entry:ledger  q.i.rows
  =/  s=snapshot:core  snapshot.e
  ?.  ?&  =(%running phase.e)  =(src.b worker.order.s)
          =(w /connected-compiler-order/(scot %ux (digest:protocol order.s)))
      ==  $(rows t.rows)
  (stop:ledger our.b now.b held p.i.rows %dispatch-unconfirmed)
++  wake
  |=  [b=bowl:gall held=ledger:ledger w=wire sign=sign-arvo]
  ^-  transition:ledger
  ?.  ?=([%behn %wake *] sign)  [held ~]
  =/  key  (key-for:ledger w)
  ?~  key  [held ~]
  =/  found  (~(get by held) u.key)
  ?~  found  [held ~]
  ?.  (gte now.b expires.order.snapshot.u.found)  [held ~]
  (stop:ledger our.b now.b held u.key %compiler-deadline)
++  reload
  ::  Completed entries are byte-preserved. Interrupted attempts never resend.
  |=  [our=@p now=@da held=ledger:ledger writes=ledger:write saves=ledger:editor]
  ^-  transition:ledger
  ?>  (linked:ledger our held writes saves)
  =/  rows  ~(tap by held)
  =|  cards=(list card:agent:gall)
  |-  ^-  transition:ledger
  ?~  rows  [held cards]
  =/  e=entry:ledger  q.i.rows
  ?>  (lte at.order.snapshot.e now)
  ?.  (pending:ledger e)  $(rows t.rows)
  =/  stopped  (stop:ledger our now held p.i.rows %reload-unconfirmed)
  $(rows t.rows, held next.stopped, cards (weld cards cards.stopped))
++  shared
  |=  [our=@p legacy=ledger:ledger modern=ledger-v2:ledger old-writes=ledger:write writes=ledger-v2:write saves=ledger:editor]
  ^-  ?
  ?&  (compatible:ledger our legacy modern)
      (compatible:write old-writes writes saves)
      (linked:ledger our legacy old-writes saves)
      (linked-v2:ledger our modern writes saves)
  ==
++  owned-v2
  |=  [writes=ledger-v2:write saves=ledger:editor key=@ux]
  ^-  owned-v2:read
  [(~(get by writes) key) (~(get by saves) key)]
++  start-v1-shared
  ::  The future v2 app replaces its v1 start call with this shared guard.
  |=  [b=bowl:gall held=ledger:ledger modern=ledger-v2:ledger old-writes=ledger:write writes=ledger-v2:write saves=ledger:editor c=command:ledger window=window:law]
  ^-  result:ledger
  ?.  =(our.b src.b)  [%| %foreign-actor]
  ?.  (shared our.b held modern old-writes writes saves)  [%| %journal-invalid]
  =/  prior  (lookup-v1-shared:ledger our.b held modern c)
  ?:  ?=(%| -.prior)  [%| p.prior]
  ?^  p.prior  [%& [held ~[(publish:ledger held nonce.c)]]]
  ?:  (gte (add ~(wyt by held) ~(wyt by modern)) 32)  [%| %capacity]
  ?:  (lien ~(val by modern) pending-v2:ledger)  [%| %compile-in-progress]
  (start b held old-writes saves c window)
++  event-v1-shared
  |=  [b=bowl:gall held=ledger:ledger modern=ledger-v2:ledger old-writes=ledger:write writes=ledger-v2:write saves=ledger:editor w=wire sign=sign:agent:gall window=window:law]
  ^-  transition:ledger
  ?.  (shared our.b held modern old-writes writes saves)  [held ~]
  (event b held old-writes saves w sign window)
++  start-v2
  |=  [b=bowl:gall legacy=ledger:ledger held=ledger-v2:ledger old-writes=ledger:write writes=ledger-v2:write saves=ledger:editor c=command-v2:ledger window=window:law]
  ^-  result-v2:ledger
  ?.  =(our.b src.b)  [%| %foreign-actor]
  ?.  (shared our.b legacy held old-writes writes saves)  [%| %journal-invalid]
  =/  prior  (lookup-v2:ledger our.b legacy held c)
  ?:  ?=(%| -.prior)  [%| p.prior]
  ?^  p.prior  [%& [held ~[(publish-v2:ledger held nonce.c)]]]
  ?:  (gte (add ~(wyt by legacy) ~(wyt by held)) 32)  [%| %capacity]
  ?:  |((lien ~(val by legacy) pending:ledger) (lien ~(val by held) pending-v2:ledger))  [%| %compile-in-progress]
  =/  frozen
    (read-v2:read our.b src.b now.b nonce.c binding.c (owned-v2 writes saves nonce.c) window)
  ?:  ?=(%| -.frozen)  [%| p.frozen]
  (reserve-v2:ledger our.b now.b legacy held c p.frozen)
++  observe-v2
  |=  [our=@p actor=@p held=ledger-v2:ledger key=@ux]
  ^-  (each status-v2:ledger @tas)
  ?.  =(our actor)  [%| %foreign-actor]
  ?.  &(!=(0 key) (lte (met 0 key) 128) (valid-v2:ledger our held))  [%| %request-or-journal-invalid]
  [%& (read-v2:ledger held key)]
++  event-v2
  |=  [b=bowl:gall legacy=ledger:ledger held=ledger-v2:ledger old-writes=ledger:write writes=ledger-v2:write saves=ledger:editor w=wire sign=sign:agent:gall window=window:law]
  ^-  transition-v2:ledger
  =/  unchanged=transition-v2:ledger  [held ~]
  =/  key  (key-for-v2:ledger w)
  ?~  key  unchanged
  =/  found  (~(get by held) u.key)
  ?~  found  unchanged
  =/  e=entry-v2:ledger  u.found
  =/  s=snapshot-v2:core  snapshot.e
  ?.  &((pending-v2:ledger e) =(src.b worker.order.s))  unchanged
  ?.  (shared our.b legacy held old-writes writes saves)  unchanged
  ?.  (lte at.order.s now.b)  unchanged
  =/  stop
    |=  reason=@tas
    (stop-v2:ledger our.b now.b held u.key reason)
  ?:  ?=(%kick -.sign)  (stop %watch-kicked)
  ?:  &(?=(%watch-ack -.sign) ?=(^ p.sign))  (stop %watch-rejected)
  =/  subscribed  (~(get by wex.b) [w worker.order.s %vibecoding-compiler])
  ?.  =(subscribed `[%.y /result/(scot %ux (digest:protocol order.s))])  unchanged
  ?:  (gte now.b expires.order.s)  (stop %compiler-deadline)
  ?:  ?=(%watch-ack -.sign)
    ?.  =(%watching phase.e)  unchanged
    =/  admitted
      (admit-v2:read our.b our.b now.b s (owned-v2 writes saves u.key) window)
    =/  sent  (send-v2:ledger our.b now.b legacy held u.key admitted)
    ?:(?=(%& -.sent) p.sent (stop p.sent))
  ?.  ?=(%fact -.sign)  unchanged
  ?.  =(%running phase.e)  unchanged
  ?.  =(%noun p.cage.sign)  (stop %wrong-mark)
  =/  raw=*  q.q.cage.sign
  ?:  (gth (met 3 (jam raw)) 2.100.000)  (stop %worker-output-over-limit)
  =/  status  ((soft ,status:worker) raw)
  ?~  status  (stop %worker-status-invalid)
  =/  received  (receive-v2:ledger our.b src.b now.b held u.key u.status)
  ?:(?=(%& -.received) p.received (stop p.received))
++  poke-ack-v2
  |=  [b=bowl:gall legacy=ledger:ledger held=ledger-v2:ledger w=wire sign=sign:agent:gall]
  ^-  transition-v2:ledger
  =/  unchanged=transition-v2:ledger  [held ~]
  ?.  &((compatible:ledger our.b legacy held) ?=(%poke-ack -.sign))  unchanged
  ?~  p.sign  unchanged
  =/  rows  ~(tap by held)
  |-  ^-  transition-v2:ledger
  ?~  rows  unchanged
  =/  e=entry-v2:ledger  q.i.rows
  =/  s=snapshot-v2:core  snapshot.e
  ?.  ?&  =(%running phase.e)  =(src.b worker.order.s)
          =(w /connected-compiler-order-v2/(scot %ux (digest:protocol order.s)))
      ==  $(rows t.rows)
  (stop-v2:ledger our.b now.b held p.i.rows %dispatch-unconfirmed)
++  wake-v2
  |=  [b=bowl:gall legacy=ledger:ledger held=ledger-v2:ledger w=wire sign=sign-arvo]
  ^-  transition-v2:ledger
  ?.  &((compatible:ledger our.b legacy held) ?=([%behn %wake *] sign))  [held ~]
  =/  key  (key-for-v2:ledger w)
  ?~  key  [held ~]
  =/  found  (~(get by held) u.key)
  ?~  found  [held ~]
  ?.  (gte now.b expires.order.snapshot.u.found)  [held ~]
  (stop-v2:ledger our.b now.b held u.key %compiler-deadline)
++  reload-v2
  |=  [our=@p now=@da legacy=ledger:ledger held=ledger-v2:ledger old-writes=ledger:write writes=ledger-v2:write saves=ledger:editor]
  ^-  transition-v2:ledger
  ?>  (shared our legacy held old-writes writes saves)
  =/  rows  ~(tap by held)
  =|  cards=(list card:agent:gall)
  |-  ^-  transition-v2:ledger
  ?~  rows  [held cards]
  =/  e=entry-v2:ledger  q.i.rows
  ?>  (lte at.order.snapshot.e now)
  ?.  (pending-v2:ledger e)  $(rows t.rows)
  =/  stopped  (stop-v2:ledger our now held p.i.rows %reload-unconfirmed)
  $(rows t.rows, held next.stopped, cards (weld cards cards.stopped))
--
