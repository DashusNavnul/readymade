::  Ordinary tools keep their real Spider handle. This wrapper owns only the
::  authenticated moon order; a key-only request never supplies authority.
/-  x=native-coding-worker-work-v3, v2=native-coding-worker-work,
    br=native-coding-build-reference, w=native-coding-worker,
    r=native-coding-worker-runtime, nc=native-coding, b=boks
/+  work=native-coding-worker-work-v3, prior=native-coding-worker-work,
    v3-source=native-coding-worker-tool-source-v3, law=native-coding-worker,
    parent=native-coding-worker-owner-runtime, read=native-coding-worker-owner-read,
    source=native-coding-worker-tool-source, peer=native-coding-worker-runtime,
    ct=cantrip-native-coding, archive=native-coding-hoon-artifact,
    allowance=native-coding-check-authorization
|%
+$  tool-order  $%(tool-order:v2 tool-order:x)
+$  tool-result  $%(tool-result:v2 tool-result:x)
+$  negotiation
  [epoch=@ud pair=pairing:w pin=execution-pin:parent receipt=(unit capabilities:r)]
+$  capability-state  [selected=? epoch=@ud pending=(unit negotiation)]
+$  pin-reader  $-(bowl:gall (each execution-pin:parent @tas))
+$  row
  [request=tool-request:nc order=(unit tool-order) export=(unit revision:nc) sent=? result=(unit tool-result) failure=(unit [unknown=? reason=@tas])]
+$  state  [%native-coding-worker-tool-owner-v1 rows=(map @ux row)]
+$  tool-state  state
+$  facts  [pair=pairing:w record=record:ct scope=scope:ct input=input:archive]
+$  reader  $-([inner=agent:gall b=bowl:gall id=@ux] (each facts @tas))
+$  cleaner  $-([our=@p now=@da o=tool-order:v2] (list card:agent:gall))
+$  cleaner-all  $-([our=@p now=@da o=tool-order] (list card:agent:gall))
+$  execution-reader  $-(bowl:gall (each bear:khan @tas))
++  empty  ^-(state [%native-coding-worker-tool-owner-v1 ~])
++  wire-for  |=([id=@ux kind=@tas] ^-(wire /native-worker-tool/(scot %ux id)/[kind]))
++  result-path  |=(id=@ux ^-(path /native-coding/worker/tool-result/(scot %ux id)))
++  wake
  |=  [id=@ux kind=@tas at=@da]
  ^-  card:agent:gall
  [%pass (wire-for id kind) %arvo %b %wait at]
++  publish
  |=  [id=@ux value=row]
  ^-  card:agent:gall
  [%give %fact ~[(result-path id)] %noun !>(`value)]
++  terminal  |=(v=row |(?=(^ result.v) ?=(^ failure.v)))
++  busy
  |=(v=row &(?=(~ result.v) ?~(failure.v %.y &(sent.v unknown.u.failure.v))))
++  row-capacity  512
++  room
  |=  [s=state id=@ux]
  ^-  ?
  &(|((~(has by rows.s) id) (lth ~(wyt by rows.s) row-capacity)) !(lien ~(tap by rows.s) |=([key=@ux v=row] &(!=(key id) (busy v)))))
++  candidate-busy
  |=  s=state:parent
  ^-  ?
  ?:  (lien ~(val by journal.owner.s) |=(r=record:w ?=(~ result.r)))  %.y
  %+  lien  ~(tap by pending.s)
  |=  [ticket=@ux id=@ux]
  &(!(~(has by failures.s) ticket) !(lien ~(val by journal.owner.s) |=(r=record:w =(ticket ticket.order.r))))
++  valid
  |=  [our=@p s=state]
  ^-  ?
  ?&  (lte ~(wyt by rows.s) row-capacity)
      %+  levy  ~(tap by rows.s)
      |=  [id=@ux v=row]
      ?&  =(id (key:ct request.v))  =(our actor.context.request.v)
          ?=(?(%compile %check %eval) -.arguments.request.v)
          ?~  order.v
            &(!sent.v ?=(~ export.v) ?=(~ result.v))
          ?&  (order-valid:work u.order.v)
              =(id ticket.u.order.v)  =(request.v request.purpose.u.order.v)
              ?~(result.v %.y &(sent.v (result-matches:work u.order.v u.result.v)))
              |(!sent.v ?=(^ export.v))
          ==
      ==
  ==
++  selected
  |=  [inner=agent:gall b=bowl:gall]
  ^-  state:parent
  =/  ag  ~(. inner b(src our.b))
  =/  raw  (payload:allowance (on-peek:ag /x/native-coding/worker/state))
  ?>  ?=(^ raw)
  ;;(state:parent u.raw)
++  authority-selection
  ::  Capacity is admission policy, not revocation of existing work.
  |=  chosen=state:parent
  ^-  (each pairing:w @tas)
  ?.  engaged.chosen  [%| %worker-not-engaged]
  ?~  pairing.owner.chosen  [%| %worker-not-selected]
  [%& u.pairing.owner.chosen]
++  admission-room
  |=  [s=state chosen=state:parent id=@ux]
  ^-  ?
  &((room s id) |((~(has by rows.s) id) !(candidate-busy chosen)))
++  current
  |=  [inner=agent:gall b=bowl:gall id=@ux]
  ^-  (each facts @tas)
  =/  chosen  (selected inner b)
  =/  selection  (authority-selection chosen)
  ?:  ?=(%| -.selection)  [%| p.selection]
  =/  ag  ~(. inner b(src our.b))
  =/  raw  (payload:allowance (on-peek:ag /x/native-coding/job/(scot %ux id)))
  ?~  raw  [%| %worker-tool-job-missing]
  =/  row  ((soft ,(unit record:ct)) u.raw)
  ?~  row  [%| %worker-tool-job-incompatible]
  ?.  =(u.raw u.row)  [%| %worker-tool-job-incompatible]
  ?~  u.row  [%| %worker-tool-job-missing]
  =/  record=record:ct  u.u.row
  ?.  &(=(%running stage.record) =(~ result.record) =(id (key:ct request.record)))
    [%| %worker-tool-job-not-running]
  =/  raw  (payload:allowance (on-peek:ag /x/native-coding/grant/(scot %ux grant.record)))
  ?~  raw  [%| %worker-tool-grant-missing]
  =/  scope  ((soft ,(unit scope:ct)) u.raw)
  ?~  scope  [%| %worker-tool-grant-incompatible]
  ?.  =(u.raw u.scope)  [%| %worker-tool-grant-incompatible]
  ?~  u.scope  [%| %worker-tool-grant-missing]
  =/  permitted  (allowed:ct our.b now.b u.u.scope request.record)
  ?:  ?=(%| -.permitted)  [%| p.permitted]
  ?.  (pending:ct our.b now.b request.record)  [%| %worker-tool-not-pending]
  =/  prepared  (prepare:archive our.b now.b project.grant.u.u.scope request.record)
  ?:  ?=(%| -.prepared)  [%| p.prepared]
  [%& [p.selection record u.u.scope p.prepared]]
++  capability-wire
  |=  wanted=negotiation
  ^-  wire
  /native-worker-tool-capabilities/(scot %ux (shax (jam [epoch.wanted pair.wanted pin.wanted])))
++  capability-empty  ^-(capability-state [%.n 0 ~])
++  v3-pin
  |=  b=bowl:gall
  ^-  (each execution-pin:parent @tas)
  =/  chosen=execution-state:parent
    .^(execution-state:parent %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/worker/execution/noun)
  ?.  &(selected.chosen ?=(^ source.chosen))  [%| %worker-v3-execution-not-selected]
  =/  checked  (execution-source-with:parent b chosen)
  ?:  ?=(%| -.checked)  [%| p.checked]
  ?>  ?=(^ source.chosen)
  =/  pin=execution-pin:parent  u.source.chosen
  ?.  .^(? %cu /(scot %p our.b)/[desk.pin]/(scot %ud revision.pin)/ted/ph/native-coding-worker-tool-export-v3/hoon)
    [%| %worker-v3-execution-unavailable]
  [%& pin]
++  capability-matches
  |=  [pair=pairing:w cap=capabilities:r]
  ^-  ?
  ?&  =(`pair pairing.cap)  =(`toolchain.pair toolchain.cap)
      (~(has in protocols.cap) %native-coding-worker-v3)
      (lte ~(wyt in protocols.cap) 8)  (lte (met 3 (jam cap)) 4.096)
  ==
++  needs-budget
  ::  Checks and evaluations run untrusted expressions under a soft budget.
  |=  r=tool-request:nc
  ^-  ?
  ?=(?(%check %eval) -.arguments.r)
++  worker-can-evaluate
  ::  The negotiated receipt says whether the paired worker's runtime has it.
  |=  c=capability-state
  ^-  ?
  ?~  pending.c  %.n
  ?~  receipt.u.pending.c  %.n
  (~(has in protocols.u.receipt.u.pending.c) %bounded-evaluation-v1)
++  capability-valid
  |=  c=capability-state
  ^-  ?
  ?&  (lte epoch.c 18.446.744.073.709.551.615)
      ?~  pending.c  %.y
      ?&  selected.c  =(epoch.c epoch.u.pending.c)
          (pairing-valid:law pair.u.pending.c)
          (execution-valid:parent [%native-coding-worker-execution-v1 %.y `pin.u.pending.c])
          ?~(receipt.u.pending.c %.y (capability-matches pair.u.pending.c u.receipt.u.pending.c))
      ==
  ==
++  invalidate-capability
  |=  [leave=? wanted=negotiation c=capability-state]
  ^-  [(list card:agent:gall) capability-state]
  =/  cards=(list card:agent:gall)
    ?.  leave  ~
    ~[[%pass (capability-wire wanted) %agent [worker.pair.wanted %native-coding-worker] %leave ~]]
  [cards c(pending ~)]
++  order-authorized
  |=  [o=tool-order f=facts]
  ^-  ?
  ?:  ?=(%native-coding-worker-order-v3 -.o)
    (tool-authorized:work o pair.f record.f scope.f input.f)
  (tool-authorized:prior o pair.f record.f scope.f input.f)
++  export-desk
  |=  o=tool-order
  ^-  @tas
  ?:  ?=(%native-coding-worker-order-v3 -.o)  (export-desk:v3-source o)
  (export-desk:source o)
++  export-valid
  |=  [our=@p now=@da o=tool-order revision=revision:nc]
  ^-  ?
  ?:  ?=(%native-coding-worker-order-v3 -.o)  (export-valid:v3-source our now o revision)
  (export-valid:source our now o revision)
++  revoke-export
  |=  [our=@p now=@da o=tool-order]
  ^-  (list card:agent:gall)
  ?:  ?=(%native-coding-worker-order-v3 -.o)  (revoke-export:v3-source our now o)
  (revoke-export:source our now o)
++  offer-path
  |=  o=tool-order
  ^-  path
  ?:  ?=(%native-coding-worker-order-v3 -.o)
    /native-coding/worker/tool-order-v3/(scot %ux (digest:work o))
  (tool-offer-path:peer (digest:work o))
++  build-reference
  |=  v=row
  ^-  (unit reference:br)
  ?~  order.v  ~
  ?~  result.v  ~
  ?.  ?&  ?=(%native-coding-worker-order-v3 -.u.order.v)
          ?=(%native-coding-worker-result-v3 -.u.result.v)
          (result-matches:work u.order.v u.result.v)
      ==  ~
  ?.  ?=(%tool -.outcome.u.result.v)  ~
  reference.outcome.u.result.v
++  agent
  |=(inner=agent:gall (agent-with-readers current revoke-export execution-bear:parent v3-pin inner))
++  agent-with
  ::  Existing inert event fixtures retain their explicitly legacy source.
  |=  [inspect=reader cleanup-export=cleaner inner=agent:gall]
  (agent-with-source inspect cleanup-export |=(b=bowl:gall ^-((each bear:khan @tas) [%& q.byk.b])) inner)
++  agent-with-source
  ::  Native proof may replace readers; no runtime command can do so.
  |=  [inspect=reader cleanup-export=cleaner execution=execution-reader inner=agent:gall]
  =/  cleanup-all=cleaner-all
    |=  [our=@p now=@da o=tool-order]
    ?:  ?=(%native-coding-worker-order-v3 -.o)  ~
    (cleanup-export our now o)
  (agent-with-readers inspect cleanup-all execution |=(b=bowl:gall ^-((each execution-pin:parent @tas) [%| %fixture-v3-unavailable])) inner)
++  agent-with-readers
  |=  [inspect=reader cleanup-export=cleaner-all execution=execution-reader pin-source=pin-reader inner=agent:gall]
  =/  state=state  empty
  =/  capability=capability-state  capability-empty
  ^-  agent:gall
  |_  =bowl:gall
  +*  this  .
      ag  ~(. inner bowl)
      ready-v3
        |=  chosen=capability-state
        ^-  ?
        ?.  selected.chosen  %.n
        ?~  pending.chosen  %.n
        =/  wanted=negotiation  u.pending.chosen
        ?~  receipt.wanted  %.n
        =/  selection  (authority-selection (selected inner bowl))
        ?:  ?=(%| -.selection)  %.n
        =/  pin  (pin-source bowl)
        ?:  ?=(%| -.pin)  %.n
        ?&  =(pair.wanted p.selection)  =(pin.wanted p.pin)
            (capability-matches p.selection u.receipt.wanted)
            (held:peer bowl (capability-wire wanted) worker.p.selection %native-coding-worker /capabilities)
        ==
      cleanup
        |=  v=row
        ^-  (list card:agent:gall)
        ?~  order.v  ~
        :_  (cleanup-export our.bowl now.bowl u.order.v)
        [%give %kick ~[(offer-path u.order.v)] ~]
      fail
        |=  [id=@ux v=row unknown=? reason=@tas]
        ^-  (quip card:agent:gall _this)
        ?:  (terminal v)  `this
        =/  next=row  v(failure `[unknown reason])
        [(weld ~[(publish id next)] (cleanup v)) this(state state(rows (~(put by rows.state) id next)))]
      authorized
        |=  [id=@ux v=row]
        ^-  ?
        ?~  order.v  %.n
        ?.  ?:(?=(%native-coding-worker-order-v3 -.u.order.v) (ready-v3 capability) %.y)  %.n
        =/  f  (inspect inner bowl id)
        ?:  ?=(%| -.f)  %.n
        (order-authorized u.order.v p.f)
      exporting
        |=  key=@ux
        ^-  (unit tool-order)
        =/  matches=(list [@ux row])
          (skim ~(tap by rows.state) |=([id=@ux v=row] ?~(order.v %.n =((digest:work u.order.v) key))))
        ?.  ?=([* ~] matches)  ~
        =/  [id=@ux v=row]  i.matches
        ?~  order.v  ~
        ?.  &(!sent.v !(terminal v) (lte issued.u.order.v now.bowl) (lth now.bowl deadline.u.order.v) (authorized id v))  ~
        order.v
      reconcile
        |=  cards=(list card:agent:gall)
        ^-  (quip card:agent:gall _this)
        =/  todo=(list [@ux row])  ~(tap by rows.state)
        |-  ^-  (quip card:agent:gall _this)
        ?~  todo  [cards this]
        =/  [id=@ux v=row]  i.todo
        ?:  |((terminal v) ?=(~ order.v))  $(todo t.todo)
        ?:  (authorized id v)  $(todo t.todo)
        =/  next=row  v(failure `[%.y %worker-tool-authority-changed])
        =.  state  state(rows (~(put by rows.state) id next))
        $(todo t.todo, cards (weld cards [(publish id next) (cleanup v)]))
  ++  on-init
    =^  cards  inner  on-init:ag
    [cards this]
  ++  on-save  !>([%native-coding-worker-tool-save-v2 state capability on-save:ag])
  ++  on-load
    |=  old=vase
    =/  saved=[state=tool-state capability=capability-state inner=vase]
      ?:  ?=([%native-coding-worker-tool-save-v2 *] q.old)
        =/  value  !<([%native-coding-worker-tool-save-v2 state=tool-state capability=capability-state inner=vase] old)
        +.value
      ?.  ?=([%native-coding-worker-tool-save-v1 *] q.old)  [empty capability-empty old]
      =/  value  !<([%native-coding-worker-tool-save-v1 state=tool-state inner=vase] old)
      [state.value capability-empty inner.value]
    ?>  (capability-valid capability.saved)
    =.  capability  capability.saved
    ?>  (valid our.bowl state.saved)
    =.  state  state.saved
    =^  cards  inner  (on-load:ag inner.saved)
    =/  todo=(list [@ux row])  ~(tap by rows.state)
    |-  ^-  (quip card:agent:gall _this)
    ?~  todo  [cards this]
    =/  [id=@ux v=row]  i.todo
    ?:  (terminal v)  $(todo t.todo)
    =/  next=row  v(failure `[%.y %worker-tool-reload-unconfirmed])
    =.  state  state(rows (~(put by rows.state) id next))
    $(todo t.todo, cards (weld cards ~[(publish id next)]))
  ++  on-poke
    |=  [=mark =vase]
    ?:  &(?=(%noun mark) =([%native-coding-worker-tool-negotiate-v3 ~] q.vase))
      ?>  =(our.bowl src.bowl)
      ?>  !(lien ~(val by rows.state) busy)
      =/  chosen  (selected inner bowl)
      ?>  !(candidate-busy chosen)
      =/  pair  (authority-selection chosen)
      ?>  ?=(%& -.pair)
      =/  pin  (pin-source bowl)
      ?>  ?=(%& -.pin)
      ?:  (ready-v3 capability)  `this
      ?:  ?&  ?=(^ pending.capability)
              =(p.pair pair.u.pending.capability)  =(p.pin pin.u.pending.capability)
              (~(has by wex.bowl) [(capability-wire u.pending.capability) worker.p.pair %native-coding-worker])
          ==  `this
      ?>  (lth epoch.capability 18.446.744.073.709.551.615)
      =/  next-epoch=@ud  +(epoch.capability)
      =/  wanted=negotiation  [next-epoch p.pair p.pin ~]
      =/  wire=wire  (capability-wire wanted)
      =/  leave=(list card:agent:gall)
        ?~  pending.capability  ~
        =/  old=negotiation  u.pending.capability
        ?.  (~(has by wex.bowl) [(capability-wire old) worker.pair.old %native-coding-worker])  ~
        ~[[%pass (capability-wire old) %agent [worker.pair.old %native-coding-worker] %leave ~]]
      :_  this(capability [%.y next-epoch `wanted])
      (weld leave `(list card:agent:gall)`~[[%pass wire %agent [worker.p.pair %native-coding-worker] %watch /capabilities]])
    ?:  &(?=(%noun mark) ?=([?(%native-coding-worker-tool-start-v1 %native-coding-worker-tool-start-v3) @] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  v3=?  =(%native-coding-worker-tool-start-v3 -.q.vase)
      =/  id=@ux  +.q.vase
      ?>  (identifier:law id)
      ?:  (~(has by rows.state) id)  `this
      ?>  (admission-room state (selected inner bowl) id)
      =/  f  (inspect inner bowl id)
      ?>  ?=(%& -.f)
      =/  v=row  [request.record.p.f ~ ~ %.n ~ ~]
      ?.  ?:(v3 (ready-v3 capability) !selected.capability)
        =/  next=row  v(failure `[%.n %worker-v3-not-ready])
        [~[(publish id next)] this(state state(rows (~(put by rows.state) id next)))]
      [~[(wake id ?:(v3 %start-v3 %start) (add now.bowl ~s1))] this(state state(rows (~(put by rows.state) id v)))]
    =/  reset-capability=?
      &(?=(%noun mark) ?=([?(%native-coding-worker-execution-select-v1 %native-coding-worker-parent-configure-v1) *] q.vase))
    =^  cards  inner  (on-poke:ag mark vase)
    ?.  reset-capability  (reconcile cards)
    :: The inner owner accepted this exact configuration event. Invalidate
    :: synchronously; self-scry would still see the pre-event selection.
    =/  leave=(list card:agent:gall)
      ?~  pending.capability  ~
      =/  old=negotiation  u.pending.capability
      ?.  (~(has by wex.bowl) [(capability-wire old) worker.pair.old %native-coding-worker])  ~
      ~[[%pass (capability-wire old) %agent [worker.pair.old %native-coding-worker] %leave ~]]
    =.  capability  capability(pending ~)
    (reconcile (weld cards leave))
  ++  on-watch
    |=  =path
    ?:  ?=([%native-coding %worker %tool-result @ ~] path)
      ?>  =(our.bowl src.bowl)
      =/  id  (key:read i.t.t.t.path)
      ?>  ?=(^ id)
      [~[[%give %fact ~ %noun !>((~(get by rows.state) u.id))]] this]
    ?.  ?=([%native-coding %worker ?(%tool-order %tool-order-v3) @ ~] path)
      =^  cards  inner  (on-watch:ag path)
      [cards this]
    =/  key  (key:read i.t.t.t.path)
    ?>  ?=(^ key)
    =/  matches=(list [@ux row])
      (skim ~(tap by rows.state) |=([id=@ux v=row] ?~(order.v %.n =((digest:work u.order.v) u.key))))
    ?>  ?=([* ~] matches)
    =/  [id=@ux v=row]  i.matches
    ?>  &(?=(^ order.v) ?=(^ export.v) sent.v !(terminal v))
    ?>  =(worker.pairing.u.order.v src.bowl)
    ?>  (authorized id v)
    ?:  ?=(%native-coding-worker-order-v3 -.u.order.v)
      ?>  =(%tool-order-v3 i.t.t.path)
      =/  o=tool-order:x  u.order.v
      =/  offer=tool-offer-v3:r
        [%native-coding-worker-offer-v3 o u.export.v [%admitted admission.o u.key deadline.o]]
      [~[[%give %fact ~ %noun !>(offer)]] this]
    ?>  =(%tool-order i.t.t.path)
    =/  o=tool-order:v2  u.order.v
    =/  offer=tool-offer:r
      [%native-coding-worker-offer-v2 o u.export.v [%admitted admission.o u.key deadline.o]]
    [~[[%give %fact ~ %noun !>(offer)]] this]
  ++  on-peek
    |=  =path
    ?:  &(=(our.bowl src.bowl) |(=(path /x/native-coding/reserved-desks) ?=([%x %native-coding %reserved-desks %except-worker-export @ ~] path)))
      =/  raw  (payload:allowance (on-peek:ag path))
      ?>  ?=(^ raw)
      =/  held  ;;((set @tas) u.raw)
      =/  omitted=(unit @ux)
        ?:  =(path /x/native-coding/reserved-desks)  ~
        ?>  ?=([%x %native-coding %reserved-desks %except-worker-export @ ~] path)
        =/  matches=(list [@ux row])
          (skim ~(tap by rows.state) |=([id=@ux v=row] ?~(order.v %.n =(i.t.t.t.t.path (export-desk u.order.v)))))
        ?.  ?=([* ~] matches)  ~
        =/  [id=@ux v=row]  i.matches
        ?>  ?=(^ order.v)
        ?~((exporting (digest:work u.order.v)) ~ `id)
      =/  kept=(list [@ux row])
        (skim ~(tap by rows.state) |=([id=@ux v=row] !=(`id omitted)))
      =/  names=(list @tas)
        (murn kept |=([id=@ux v=row] ?~(order.v ~ `(export-desk u.order.v))))
      ``noun+!>((~(gas in held) names))
    ?:  &(=(our.bowl src.bowl) =(path /x/native-coding/worker/tool-busy))
      ``noun+!>((lien ~(val by rows.state) busy))
    ?:  &(=(our.bowl src.bowl) =(path /x/native-coding/worker/tool-state))
      ``noun+!>(state)
    ?:  &(=(our.bowl src.bowl) ?=([%x %native-coding %worker %tool-room @ ~] path))
      =/  key  (key:read i.t.t.t.t.path)
      ?~  key  [~ ~]
      ``noun+!>((admission-room state (selected inner bowl) u.key))
    ?:  &(=(our.bowl src.bowl) =(path /x/native-coding/worker/tool-v3-selection))
      ``noun+!>(capability)
    ?:  &(=(our.bowl src.bowl) =(path /x/native-coding/worker/tool-v3-ready))
      ``noun+!>((ready-v3 capability))
    ?:  ?=([%x %native-coding %worker %tool-build-reference @ ~] path)
      ?.  =(our.bowl src.bowl)  [~ ~]
      =/  key  (key:read i.t.t.t.t.path)
      ?~  key  [~ ~]
      =/  found  (~(get by rows.state) u.key)
      ``noun+!>(?~(found ~ (build-reference u.found)))
    ?:  &(=(our.bowl src.bowl) ?=([%x %native-coding %worker ?(%tool-export %tool-export-v3) @ ~] path))
      =/  key  (key:read i.t.t.t.t.path)
      ?~  key  [~ ~]
      =/  pending  (exporting u.key)
      ?~  pending  ``noun+!>(~)
      ?:  ?=(%native-coding-worker-order-v3 -.u.pending)
        ?.  =(%tool-export-v3 i.t.t.t.path)  ``noun+!>(~)
        ``noun+!>(`u.pending)
      ?.  =(%tool-export i.t.t.t.path)  ``noun+!>(~)
      ``noun+!>(`u.pending)
    (on-peek:ag path)
  ++  on-agent
    |=  [=wire =sign:agent:gall]
    ?:  ?=([%native-worker-tool-capabilities @ ~] wire)
      =/  chosen=capability-state  capability
      ?~  pending.chosen  `this
      =/  wanted=negotiation  u.pending.chosen
      ?.  =(wire (capability-wire wanted))  `this
      ?.  &(=(src.bowl worker.pair.wanted) (held:peer bowl wire src.bowl %native-coding-worker /capabilities))  `this
      ?:  |(?=(%kick -.sign) &(?=(%watch-ack -.sign) ?=(^ p.sign)))
        =^  cards  capability  (invalidate-capability %.n wanted capability)
        [cards this]
      ?.  ?=(%fact -.sign)  `this
      ?.  =(%noun p.cage.sign)
        =^  cards  capability  (invalidate-capability %.y wanted capability)
        [cards this]
      =/  raw=*  q.q.cage.sign
      ?.  (lte (met 3 (jam raw)) 4.096)
        =^  cards  capability  (invalidate-capability %.y wanted capability)
        [cards this]
      =/  parsed  ((soft ,capabilities:r) raw)
      ?~  parsed
        =^  cards  capability  (invalidate-capability %.y wanted capability)
        [cards this]
      ?.  &(=(raw u.parsed) (capability-matches pair.wanted u.parsed))
        =^  cards  capability  (invalidate-capability %.y wanted capability)
        [cards this]
      =/  next=capability-state  capability(pending `wanted(receipt `u.parsed))
      ?.  (ready-v3 next)
        =^  cards  capability  (invalidate-capability %.y wanted capability)
        [cards this]
      `this(capability next)
    ?.  ?=([%native-worker-tool @ %result ~] wire)
      =^  cards  inner  (on-agent:ag wire sign)
      (reconcile cards)
    =/  id  (key:read i.t.wire)
    ?~  id  `this
    =/  found  (~(get by rows.state) u.id)
    ?~  found  `this
    =/  v=row  u.found
    ?.  &(?=(~ result.v) sent.v ?=(^ order.v))  `this
    =/  o=tool-order  u.order.v
    ?.  =(src.bowl worker.pairing.o)  `this
    ?:  |(?=(%kick -.sign) &(?=(%watch-ack -.sign) ?=(^ p.sign)))
      (fail u.id v %.y %worker-tool-result-unconfirmed)
    ?.  &(?=(%fact -.sign) =(%noun p.cage.sign) (held:peer bowl wire src.bowl %native-coding-worker (result-path:peer (digest:work o))))  `this
    =/  raw=*  q.q.cage.sign
    ?.  (lte (met 3 (jam raw)) ?:(?=(%native-coding-worker-order-v3 -.o) 262.144 8.388.608))  (fail u.id v %.y %worker-tool-result-too-large)
    =/  parsed  ((soft ,(unit tool-result)) raw)
    ?~  parsed  (fail u.id v %.y %worker-tool-result-invalid)
    ?.  =(raw u.parsed)  (fail u.id v %.y %worker-tool-result-invalid)
    ?~  u.parsed  `this
    ?.  (result-matches:work o u.u.parsed)  (fail u.id v %.y %worker-tool-result-mismatch)
    ::  Authenticated late terminal evidence resolves busy status only. A
    ::  previously reported unknown remains unknown and is never republished.
    =/  failure=(unit [unknown=? reason=@tas])
      ?^  failure.v  failure.v
      ?:((authorized u.id v) ~ `[%.y %worker-tool-authority-changed])
    =/  next=row  v(result `u.u.parsed, failure failure)
    =/  cards=(list card:agent:gall)
      ?~(failure.v ~[(publish u.id next)] ~)
    [(weld cards (cleanup v)) this(state state(rows (~(put by rows.state) u.id next)))]
  ++  on-arvo
    |=  [=wire =sign-arvo]
    ?.  ?=([%native-worker-tool @ @ ~] wire)
      =^  cards  inner  (on-arvo:ag wire sign-arvo)
      (reconcile cards)
    ?.  =(our.bowl src.bowl)  `this
    =/  id  (key:read i.t.wire)
    ?~  id  `this
    =/  found  (~(get by rows.state) u.id)
    ?~  found  `this
    =/  v=row  u.found
    ?:  (terminal v)  `this
    =/  kind=@tas  i.t.t.wire
    ?:  ?=(?(%start %start-v3) kind)
      ?.  &(?=([%behn %wake ~] sign-arvo) ?=(~ order.v))  `this
      =/  v3=?  =(%start-v3 kind)
      ?.  ?:(v3 (ready-v3 capability) !selected.capability)  (fail u.id v %.n %worker-v3-not-ready)
      =/  executor=(each bear:khan @tas)
        ?.  v3  (execution bowl)
        =/  pin  (pin-source bowl)
        ?:  ?=(%| -.pin)  [%| p.pin]
        [%& [our.bowl desk.p.pin ud+revision.p.pin]]
      ?:  ?=(%| -.executor)  (fail u.id v %.n p.executor)
      =/  f  (inspect inner bowl u.id)
      ?:  ?=(%| -.f)  (fail u.id v %.n p.f)
      ::  Refuse here, readably, rather than let a worker without the soft
      ::  budget refuse after dispatch. Compiles need no budget.
      ?:  &(v3 (needs-budget request.record.p.f) !(worker-can-evaluate capability))
        (fail u.id v %.n %worker-runtime-no-bounded-evaluation)
      =/  made=(each tool-order @tas)
        ?:  v3  (make-tool:work pair.p.f record.p.f scope.p.f input.p.f now.bowl (add now.bowl ~m20))
        (make-tool:prior pair.p.f record.p.f scope.p.f input.p.f now.bowl (add now.bowl ~m20))
      ?:  ?=(%| -.made)  (fail u.id v %.n p.made)
      =/  o=tool-order  p.made
      =/  next=row  v(order `o)
      :_  this(state state(rows (~(put by rows.state) u.id next)))
      :~  [%pass (wire-for u.id %export) %arvo %k %fard p.executor ?:(v3 %ph-native-coding-worker-tool-export-v3 %ph-native-coding-worker-tool-export) %noun !>(`(digest:work o))]
          (wake u.id %deadline deadline.o)
      ==
    ?~  order.v  `this
    =/  o=tool-order  u.order.v
    ?:  =(%deadline kind)
      ?.  ?=([%behn %wake *] sign-arvo)  `this
      (fail u.id v %.y %worker-tool-deadline)
    ?.  &(=(%export kind) ?=([%khan %arow *] sign-arvo) !sent.v)  `this
    ?.  ?=(%& -.p.sign-arvo)  (fail u.id v %.y %worker-tool-export-unconfirmed)
    =/  raw=*  q.q.p.p.sign-arvo
    =/  parsed  ((soft ,(each revision:nc @tas)) raw)
    ?~  parsed  (fail u.id v %.y %worker-tool-export-invalid)
    ?.  &(=(raw u.parsed) ?=(%& -.u.parsed))  (fail u.id v %.y %worker-tool-export-unconfirmed)
    ?.  &((authorized u.id v) (export-valid our.bowl now.bowl o p.u.parsed))
      (fail u.id v %.y %worker-tool-export-changed)
    =/  next=row  v(export `p.u.parsed, sent %.y)
    :_  this(state state(rows (~(put by rows.state) u.id next)))
    :~  [%pass (wire-for u.id %result) %agent [worker.pairing.o %native-coding-worker] %watch (result-path:peer (digest:work o))]
        [%pass (wire-for u.id %send) %agent [our.bowl %boks] %poke %noun !>(`local-action:b`[%send (envelope:work o)])]
    ==
  ++  on-leave
    |=  =path
    ?:  ?=([%native-coding %worker ?(%tool-order %tool-order-v3 %tool-result) @ ~] path)  `this
    =^  cards  inner  (on-leave:ag path)
    [cards this]
  ++  on-fail
    |=  [=term =tang]
    =^  cards  inner  (on-fail:ag term tang)
    [cards this]
  --
--
