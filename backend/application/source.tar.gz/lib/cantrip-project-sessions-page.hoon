::  Peer discovery pages count examined grants, not rows which survive current
::  authorization. An empty filtered page can therefore make forward progress.
::  grant-catalog binds standing grants and policy, not an atomic session view;
::  each page separately observes current session availability/source/phase.
/-  ps=cantrip-project-sessions, nc=native-coding, mp=multiplayer-project
/+  core=cantrip-project-sessions, tools=cantrip-native-coding,
    project=native-coding-project, cursor=readymade-session-catalog,
    law=cantrip-law-window
|%
+$  selection
  [grant-catalog=@ux total=@ud examined=@ud next=(unit @ud) held=scopes:core]
++  query-valid
  |=  q=page-query:ps
  ^-  ?
  ?&  (query-valid:core [project.q nonce.q])
      (lth offset.q grant-capacity:tools)
      ?~(expected.q =(0 offset.q) (identifier:tools u.expected.q))
  ==
++  route
  |=  [peer=@p q=page-query:ps]
  ^-  path
  /project-sessions-v2/(scot %ux project.q)/(scot %p peer)/(scot %ux nonce.q)/(scot %ud offset.q)/(scot %ux ?~(expected.q 0x0 u.expected.q))
++  parse
  |=  pax=path
  ^-  (unit [peer=@p query=page-query:ps])
  ?.  &(?=([%project-sessions-v2 @ @ @ @ @ ~] pax) (lte (met 3 (jam pax)) 4.096))  ~
  =/  project  (slaw %ux i.t.pax)
  =/  peer  (slaw %p i.t.t.pax)
  =/  nonce  (slaw %ux i.t.t.t.pax)
  ?~  project  ~
  ?~  peer  ~
  ?~  nonce  ~
  =/  version=(unit @t)
    ?:(=('0x0' i.t.t.t.t.t.pax) ~ `i.t.t.t.t.t.pax)
  =/  query  (parse-query:cursor i.t.t.t.t.pax version)
  ?~  query  ~
  =/  q=page-query:ps  [`@t`u.project u.nonce offset.u.query expected.u.query]
  ?.  &((lte (met 0 u.peer) 128) (query-valid q) =(pax (route u.peer q)))  ~
  `[u.peer q]
++  authority
  |=  [our=@p peer=@p q=page-query:ps w=window:law catalog=project:mp base=project:nc]
  ^-  (each ~ @tas)
  ?.  (query-valid q)  [%| %sessions-query-invalid]
  =/  admitted  (admitted:core [project.q nonce.q] w)
  ?:  ?=(%| -.admitted)  [%| p.admitted]
  ?.  ?&  =(our authority.spec.catalog)  =(project.q id.spec.catalog)
          (observer:project base catalog peer)
      ==
    [%| %sessions-member-refused]
  [%& ~]
++  select
  |=  [our=@p peer=@p q=page-query:ps held=scopes:core w=window:law catalog=project:mp base=project:nc]
  ^-  (each selection @tas)
  =/  admitted  (authority our peer q w catalog base)
  ?:  ?=(%| -.admitted)  [%| p.admitted]
  ?.  (lte ~(wyt by held) grant-capacity:tools)  [%| %sessions-catalog-capacity]
  ::  Never include another peer or project's grant even in the cursor digest.
  ::  Keep revoked/stale grants in the examined order, so filtering cannot stall.
  =/  scoped=(list [id=@ux scope=scope:tools])
    (skim ~(tap by held) |=([id=@ux scope=scope:tools] &(=(peer actor.grant.scope) =(project.q id.spec.project.grant.scope))))
  ?.  (levy scoped |=([id=@ux scope=scope:tools] &(=(id id.grant.scope) (identifier:tools id))))
    [%| %sessions-catalog-invalid]
  =/  ordered=(list [id=@ux scope=scope:tools])
    (sort scoped |=([a=[id=@ux scope=scope:tools] b=[id=@ux scope=scope:tools]] (lth id.a id.b)))
  =/  total=@ud  (lent ordered)
  ?.  |(&(=(0 total) =(0 offset.q)) (lth offset.q total))  [%| %sessions-catalog-cursor]
  =/  digest=@ux
    (shax (jam [%cantrip-project-sessions-catalog-v2 our peer project.q (~(get by members.catalog) peer) base w ordered]))
  ?.  (identifier:tools digest)  [%| %sessions-catalog-invalid]
  ?:  ?~(expected.q %.n !=(u.expected.q digest))  [%| %sessions-catalog-stale]
  =/  picked  (scag limit:core (slag offset.q ordered))
  =/  examined=@ud  (lent picked)
  =/  end=@ud  (add offset.q examined)
  [%& [digest total examined ?:(=(end total) ~ `end) (malt picked)]]
++  response-valid
  |=  r=page-response:ps
  ^-  ?
  ?&  (query-valid query.r)  (identifier:tools grant-catalog.r)
      (lte total.r grant-capacity:tools)  (lte examined.r limit:core)
      (lte (lent rows.r) examined.r)
      |(&(=(0 total.r) =(0 offset.query.r)) (lth offset.query.r total.r))
      =(examined.r (min limit:core (sub total.r offset.query.r)))
      =(next.r ?:(=((add offset.query.r examined.r) total.r) ~ `(add offset.query.r examined.r)))
      ?~(expected.query.r %.y =(grant-catalog.r u.expected.query.r))
      (response-valid:core [owner.r peer.r [project.query.r nonce.query.r] at.r rows.r %.n])
      =((lent rows.r) ~(wyt in (silt (turn rows.r |=(row=row:ps inspection.row)))))
  ==
++  observe
  |=  [our=@p peer=@p now=@da q=page-query:ps held=scopes:core w=window:law catalog=project:mp base=project:nc solved=resolved:core raw=*]
  ^-  (each page-response:ps @tas)
  =/  picked  (select our peer q held w catalog base)
  ?:  ?=(%| -.picked)  [%| p.picked]
  =/  observed  (observe:core our peer now [project.q nonce.q] held.p.picked w catalog base solved raw)
  ?:  ?=(%| -.observed)  [%| p.observed]
  =/  r=page-response:ps
    [our peer q now grant-catalog.p.picked total.p.picked examined.p.picked next.p.picked rows.p.observed]
  ?.  (response-valid r)  [%| %sessions-catalog-invalid]
  [%& r]
++  cards
  |=  [pax=path r=page-response:ps]
  ^-  (list card:agent:gall)
  ?>  &((response-valid r) =(pax (route peer.r query.r)))
  :~  [%give %fact ~[pax] %noun !>(`page-event:ps`[%cantrip-project-sessions-v2 r])]
      [%give %kick ~[pax] ~]
  ==
--
