::  Inspect the existing Codex stdout adapter's actual, limited evidence.
::  Exit/sandbox metadata are host reports, not CLI event or effect proofs.
/-  mb=model-bridge
/+  json-fields=vibecoding-provider, inference=codex-inference,
    responses=codex-responses
|%
+$  receipt
  $:  %codex-provider-receipt-v1  text=@t  metadata=@t
      identity=%unreported  sandbox=%host-reported-read-only
      completion=%host-reported-exit-zero  cli-terminal=%unobserved
      tools=%unknown  effects=%unverified  usage=%unreported
  ==
+$  native-receipt
  $:  %codex-provider-receipt-v2  text=@t  metadata=@t
      reported-model=@t  response-id=@t  raw-digest=@ux  raw-bytes=@ud
      transport=%urbit-iris  completion=%response-completed  tools=%disabled
      usage=[input=@ud output=@ud total=@ud]
  ==
+$  inspected  $?(receipt native-receipt)
++  inspect
  |=  [spec=model-bridge-spec:mb request=model-bridge-request:mb reply=model-bridge-result:mb]
  ^-  (each inspected @tas)
  ?:  (spec-valid:inference spec)  (inspect-native spec request reply)
  (inspect-cli spec request reply)
++  inspect-native
  ::  Pure consistency only. The executor must authenticate the selected
  ::  native agent event and route; JSON metadata alone proves no transport.
  |=  [spec=model-bridge-spec:mb request=model-bridge-request:mb reply=model-bridge-result:mb]
  ^-  (each native-receipt @tas)
  =/  prepared  (prepare:inference spec request)
  ?.  ?&  ?=(%& -.prepared)
          (model-bridge-event-matches-request:mb spec request [%result reply])
          =(%ok status.reply)  =('' error.reply)  =('[]' tool-calls-json.reply)
      ==  [%| %codex-native-result-mismatch]
  =/  meta  (object:json-fields provider-metadata-json.reply)
  ?~  meta  [%| %codex-native-metadata-invalid]
  ?.  ?&  =(`'codex-inference' (string:json-fields u.meta 'backend'))
          =(`'urbit-iris' (string:json-fields u.meta 'transport'))
          =(`'response.completed' (string:json-fields u.meta 'completion'))
          =(`'disabled' (string:json-fields u.meta 'tools'))
          =(`model-id.spec (string:json-fields u.meta 'reported_model'))
          =(`turn-handle.reply (string:json-fields u.meta 'response_id'))
          (bounded:responses turn-handle.reply 256)
          =(8 ~(wyt by u.meta))
      ==  [%| %codex-native-metadata-invalid]
  =/  digest  (string:json-fields u.meta 'raw_digest')
  ?~  digest  [%| %codex-native-raw-invalid]
  =/  hash  (slaw %ux u.digest)
  ?~  hash  [%| %codex-native-raw-invalid]
  =/  bytes  (natural:responses (~(get by u.meta) 'raw_bytes'))
  ?~  bytes  [%| %codex-native-raw-invalid]
  ?.  ?&  !=(0 u.hash)  (lte (met 0 u.hash) 256)
          =(u.digest (scot %ux u.hash))
          (gth u.bytes 0)  (lte u.bytes body-limit:responses)
      ==  [%| %codex-native-raw-invalid]
  =/  usage  (de:json:html usage-json.reply)
  ?~  usage  [%| %codex-native-usage-invalid]
  =/  in  (natural:responses (field:responses u.usage 'input_tokens'))
  =/  out  (natural:responses (field:responses u.usage 'output_tokens'))
  =/  total  (natural:responses (field:responses u.usage 'total_tokens'))
  ?~  in  [%| %codex-native-usage-invalid]
  ?~  out  [%| %codex-native-usage-invalid]
  ?~  total  [%| %codex-native-usage-invalid]
  ?.  =((add u.in u.out) u.total)  [%| %codex-native-usage-invalid]
  [%& [%codex-provider-receipt-v2 content.reply provider-metadata-json.reply model-id.spec turn-handle.reply u.hash u.bytes %urbit-iris %response-completed %disabled [u.in u.out u.total]]]
++  inspect-cli
  |=  [spec=model-bridge-spec:mb request=model-bridge-request:mb reply=model-bridge-result:mb]
  ^-  (each receipt @tas)
  ?.  ?&  |(=('codex' provider-id.spec) =('codex-cli' provider-id.spec))
          =('model-unreported' model-id.spec)
          (model-bridge-spec-valid:mb spec)
          (model-bridge-request-valid:mb request)
          (model-bridge-event-matches-request:mb spec request [%result reply])
          =(%ok status.reply)  =('' error.reply)
          =('[]' tool-calls-json.reply)
      ==  [%| %codex-result-mismatch]
  =/  policy  (object:json-fields (model-bridge-request-policy:mb request))
  ?~  policy  [%| %codex-policy-invalid]
  ?.  ?&  =(`[%b %.n] (~(get by u.policy) 'allow-mutations'))
          =(`[%a ~] (~(get by u.policy) 'write-roots'))
          =(`session-id.request (string:json-fields u.policy 'workspace'))
      ==  [%| %codex-policy-invalid]
  =/  meta  (object:json-fields provider-metadata-json.reply)
  ?~  meta  [%| %codex-metadata-invalid]
  ?.  ?&  =(`'codex-cli' (string:json-fields u.meta 'backend'))
          =(`[%n '0'] (~(get by u.meta) 'exit_code'))
          =(`'read-only' (string:json-fields u.meta 'sandbox'))
          =(`session-id.request (string:json-fields u.meta 'workspace'))
          =(`[%n '0'] (~(get by u.meta) 'unrepresentable_count'))
          =(`[%a ~] (~(get by u.meta) 'unrepresentable'))
      ==  [%| %codex-metadata-invalid]
  ?~  (object:json-fields usage-json.reply)  [%| %codex-usage-invalid]
  ::  The adapter's empty tools and zero token counters are placeholders.
  ::  They must never become claims of no tool use or measured zero usage.
  [%& [%codex-provider-receipt-v1 content.reply provider-metadata-json.reply %unreported %host-reported-read-only %host-reported-exit-zero %unobserved %unknown %unverified %unreported]]
--
