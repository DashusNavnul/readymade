::  Cantrip's bounded project inscription journal. Owner ratification permits
::  one isolated work commit; it is NOT a compiler or landing judgment.
::  Canonical ownership, desk isolation and read freshness belong to the reader.
/-  mc=multiplayer-changeset, mp=multiplayer-project
/+  changes=multiplayer-changeset, concurrency=multiplayer-concurrency,
    model=pataphor-editor-model, law=cantrip-law-window,
    editor=cantrip-editor-save, connected=cantrip-connected-write
|%
+$  tree  [snapshot=snapshot:mc root=@uv commit=commit:editor]
+$  basis  [owner=@p at=@da project=project-spec:mp accepted=tree working=tree]
+$  edit  [change=change:mc source=@t]
+$  request
  $:  %cantrip-project-save-v1
      nonce=@ux  basis=basis  edits=(list edit)  expires=@da
  ==
+$  admission  [request=request at=@da window=window:law]
+$  history  [owner=@p at=@da accepted=tree working=tree]
+$  record
  $:  %cantrip-project-save-record-v1
      admission=admission  status=?(%submitted %unknown %applied)
      fence=(unit basis)  history=(unit history)
  ==
+$  ledger  (map @ux record)
+$  transition  [next=ledger record=record card=card:agent:gall]
+$  status  [%cantrip-project-save-status-v1 nonce=@ux record=(unit record)]
++  digest
  |=  value=*
  ^-  @ux
  `@ux`(shax (jam [%cantrip-project-save-v1 value]))
++  path-valid
  |=  pax=path
  ^-  ?
  ?.  (path-valid:model pax)  %.n
  ?.  ?=(^ pax)  %.n
  ?&  ?=(?(%app %lib %sur %ted) i.pax)
      (gte (lent pax) 3)
      =(%hoon (rear `path`pax))
  ==
++  tree-valid
  |=  t=tree
  ^-  ?
  ?&  (snapshot-valid:changes snapshot.t)
      !=(0 root.t)  !=(0 id.commit.t)  !=(0 at.commit.t)
      (lte ~(wyt by files.body.snapshot.t) 512)
  ==
++  basis-valid
  |=  b=basis
  ^-  ?
  ?&  !=(0 at.b)  =(1 version.project.b)
      =(owner.b authority.project.b)
      (tree-valid accepted.b)  (tree-valid working.b)
      !(~(has by files.body.snapshot.working.b) /desk/bill)
      =(id.project.b project.body.snapshot.accepted.b)
      =(id.project.b project.body.snapshot.working.b)
      =(base-desk.project.b base-desk.body.snapshot.accepted.b)
      !=(base-desk.body.snapshot.accepted.b base-desk.body.snapshot.working.b)
      (lte at.commit.accepted.b at.b)  (lte at.commit.working.b at.b)
  ==
++  edit-valid
  |=  [files=(map path @ux) e=edit]
  ^-  ?
  ?.  &((path-valid path.change.e) (text-valid:model source.e))  %.n
  ?&  (lte (met 3 source.e) 32.768)
      !?=(%delete kind.change.e)
      (change-valid:changes files change.e)
      =(``@ux`(page-to-lobe:clay [%hoon source.e]) after.change.e)
      =(%clean verdict:(compare-one:concurrency files files change.e))
  ==
++  request-valid
  |=  r=request
  ^-  ?
  ?.  (basis-valid basis.r)  %.n
  =/  es=(list edit)  edits.r
  =/  paths=(list path)  (turn es |=(e=edit path.change.e))
  ?&  !=(0 nonce.r)  (lte (met 0 nonce.r) 256)
      (gte (lent es) 2)  (lte (lent es) 8)
      =((lent es) ~(wyt in (silt paths)))
      |(=(0 expires.r) &((gth expires.r at.basis.r) (lte expires.r (add at.basis.r ~m5))))
      (lte (roll es |=([e=edit total=@ud] (add total (met 3 source.e)))) 65.536)
      (levy es |=(e=edit (edit-valid files.body.snapshot.working.basis.r e)))
  ==
++  after-map
  ::  Seed with the complete namespace, preserving every unchanged import.
  |=  r=request
  ^-  (map path @ux)
  =/  fold
    |=  [e=edit files=(map path @ux)]
    ^-  (map path @ux)
    (~(put by files) path.change.e `@ux`(page-to-lobe:clay [%hoon source.e]))
  (roll edits.r fold(+<+ files.body.snapshot.working.basis.r))
++  judge
  |=  [our=@p actor=@p now=@da r=request current=basis w=window:law]
  ^-  (each admission @tas)
  ?.  =(our actor)  [%| %foreign-owner]
  ?.  &((request-valid r) =(our owner.basis.r))  [%| %request-invalid]
  ?.  &((lte at.basis.r now) |(=(0 expires.r) (lth now expires.r)))  [%| %request-expired]
  ?.  &((basis-valid current) =(now at.current) =(basis.r current(at at.basis.r)))
    [%| %project-changed]
  ?.  (permission:editor w)  [%| %inscribe-blocked]
  ?.  (lte ~(wyt by (after-map r)) 512)  [%| %namespace-over-limit]
  [%& [r now w]]
++  admission-valid
  |=  a=admission
  ^-  ?
  =/  r=request  request.a
  =((judge owner.basis.r owner.basis.r at.a r basis.r(at at.a) window.a) [%& a])
++  fence-valid
  ::  Clay can complete in the admission event. At equal time, require the
  ::  working revision to advance before releasing the reservation fence.
  |=  [a=admission b=basis]
  ^-  ?
  ?&  (basis-valid b)  =(owner.basis.request.a owner.b)
      =(base-desk.body.snapshot.working.basis.request.a base-desk.body.snapshot.working.b)
      |((gth at.b at.a) &(=(at.b at.a) (gth base-revision.body.snapshot.working.b base-revision.body.snapshot.working.basis.request.a)))
      (gte base-revision.body.snapshot.working.b base-revision.body.snapshot.working.basis.request.a)
  ==
++  confirmed
  |=  [a=admission h=history]
  ^-  ?
  =/  b=basis  basis.request.a
  =/  t=tree  working.h
  ?&  (admission-valid a)  (tree-valid t)
      =(owner.b owner.h)  (gte at.h at.a)
      =(accepted.b accepted.h)
      =(project.body.snapshot.working.b project.body.snapshot.t)
      =(base-desk.body.snapshot.working.b base-desk.body.snapshot.t)
      =(+(base-revision.body.snapshot.working.b) base-revision.body.snapshot.t)
      =(files.body.snapshot.t (after-map request.a))
      =(~[id.commit.working.b] parents.commit.t)
      =(at.a at.commit.t)  !=(root.working.b root.t)
  ==
++  record-valid
  |=  r=record
  ^-  ?
  ?.  (admission-valid admission.r)  %.n
  ?.  ?~(fence.r %.y (fence-valid admission.r u.fence.r))  %.n
  ?.  ?~(history.r %.y (confirmed admission.r u.history.r))  %.n
  ?-  status.r
    %submitted  &(=(~ fence.r) =(~ history.r))
    %unknown    &(?=(^ fence.r) =(~ history.r))
    %applied    &(?=(^ fence.r) ?=(^ history.r))
  ==
++  valid
  |=  held=ledger
  ^-  ?
  ?&  (lte ~(wyt by held) 128)
      %+  levy  ~(tap by held)
      |=  [key=@ux r=record]
      &((record-valid r) =(key nonce.request.admission.r))
  ==
++  ready
  |=  [held=ledger now=@da]
  ^-  ?
  ?&  (valid held)
      %+  levy  ~(val by held)
      |=  r=record
      ?~  fence.r  %.n
      (lte at.u.fence.r now)
  ==
++  old-ready
  |=  [saves=ledger:editor old=ledger:connected modern=ledger-v2:connected now=@da]
  ^-  ?
  ?&  (compatible:connected old modern saves)
      !(lien ~(val by old) pending:connected)
      !(lien ~(val by modern) pending-v2:connected)
      %+  levy  ~(val by saves)
      |=  r=record:editor
      ?:  =(%applied status.r)  %.y
      ?.  =(%unknown status.r)  %.n
      ?~  fence.r  %.n
      &((fence-valid:editor admission.r u.fence.r) (lte at.current.u.fence.r now))
  ==
++  lookup
  |=  [held=ledger r=request]
  ^-  (each (unit record) @tas)
  ?.  &((valid held) (request-valid r))  [%| %request-invalid]
  =/  found  (~(get by held) nonce.r)
  ?~  found  [%& ~]
  ?.  =(r request.admission.u.found)  [%| %nonce-conflict]
  [%& found]
++  reserve
  |=  [our=@p now=@da held=ledger a=admission]
  ^-  (each transition @tas)
  ?.  &(=(our owner.basis.request.a) =(now at.a) (admission-valid a))
    [%| %admission-invalid]
  =/  found  (lookup held request.a)
  ?:  ?=(%| -.found)  [%| p.found]
  ?^  p.found  [%| %already-submitted]
  ?.  (ready held now)  [%| %save-unresolved]
  ?:  (gte ~(wyt by held) 128)  [%| %capacity]
  =/  r=record  [%cantrip-project-save-record-v1 a %submitted ~ ~]
  =/  edits=(list [path miso:clay])
    %+  turn  edits.request.a
    |=  e=edit
    :-  path.change.e
    ?~  before.change.e
      [%ins %hoon !>(source.e)]
    [%mut %hoon !>(source.e)]
  =/  c=card:agent:gall
    [%pass /project-save/(scot %ux nonce.request.a) %arvo %c [%info base-desk.body.snapshot.working.basis.request.a %.y edits]]
  [%& [(~(put by held) nonce.request.a r) r c]]
++  observe
  |=  [r=record b=basis h=(unit history)]
  ^-  record
  ?:  =(%applied status.r)  r
  ?.  (fence-valid admission.r b)  r
  =/  proven=(unit history)
    ?~  h  ~
    ?:((confirmed admission.r u.h) h ~)
  r(status ?~(proven %unknown %applied), fence `b, history proven)
++  key-for
  |=  pax=path
  ^-  (unit @ux)
  ?.  ?=([%project-save @ ~] pax)  ~
  =/  key  (slaw %ux i.t.pax)
  ?~  key  ~
  ?.  &(!=(0 u.key) (lte (met 0 u.key) 256) =((scot %ux u.key) i.t.pax))  ~
  key
++  report
  |=  [key=@ux found=(unit record)]
  ^-  card:agent:gall
  =/  value=status  [%cantrip-project-save-status-v1 key found]
  [%give %fact ~[/project-save/(scot %ux key)] %noun !>(value)]
++  completion-wire
  |=  r=record
  ^-  wire
  /project-save-ready/(scot %ux nonce.request.admission.r)
++  completion
  ::  %info has no completion ACK. Read the exact next revision; Clay keeps
  ::  this local subscription until that revision exists. No clock is used.
  |=  [our=@p r=record]
  ^-  card:agent:gall
  =/  original=basis  basis.request.admission.r
  =/  desk=@tas  base-desk.body.snapshot.working.original
  =/  next=@ud  +(base-revision.body.snapshot.working.original)
  [%pass (completion-wire r) %arvo %c %warp our desk ~ %sing %z [%ud next] /]
++  completion-matches
  ::  A matching Clay response permits a canonical observation, not success.
  |=  [r=record w=wire sign=sign-arvo]
  ^-  ?
  ?.  &((record-valid r) =(w (completion-wire r)))  %.n
  =/  parsed  ((soft ,[%clay %writ data=riot:clay]) sign)
  ?~  parsed  %.n
  ?~  data.u.parsed  %.n
  =/  reply=rant:clay  u.data.u.parsed
  =/  original=basis  basis.request.admission.r
  ?&  =(%z p.p.reply)
      =([%ud +(base-revision.body.snapshot.working.original)] q.p.reply)
      =(base-desk.body.snapshot.working.original r.p.reply)
      =(/ q.reply)
  ==
--
