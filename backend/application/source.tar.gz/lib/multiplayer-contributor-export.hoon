::  /lib/multiplayer-contributor-export
::
::  Pure authorization and bundle construction for contributor-owned exports.
::  The Gall shell must supply the authenticated source and authority host.
::
/-  mce=multiplayer-contributor-export, mp=multiplayer-project,
    mr=multiplayer-receipt, mrp=multiplayer-reputation,
    mrt=multiplayer-runtime
/+  mpl=multiplayer-project, mrpl=multiplayer-reputation
|%
++  project-for
  |=  [state=state:mrt project=@t]
  ^-  (unit project:mp)
  (~(get by catalog.state) project)
++  member
  |=  [state=state:mrt project=@t source=@p]
  ^-  ?
  =/  item=(unit project:mp)  (project-for state project)
  ?~  item  %.n
  ?=(^ (role-for:mpl u.item source))
++  invited
  |=  [state=state:mrt project=@t source=@p]
  ^-  ?
  =/  item=(unit project:mp)  (project-for state project)
  ?~  item  %.n
  ?=(^ (~(get by pending.u.item) source))
++  may-observe-action
  |=  [state=state:mrt project=@t source=@p]
  ^-  ?
  ?|  (member state project source)
      (invited state project source)
  ==
++  may-export
  |=  [state=state:mrt project=@t source=@p]
  ^-  ?
  (member state project source)
++  export
  |=  [state=state:mrt host=@p source=@p project=@t]
  ^-  result:mce
  =/  item=(unit project:mp)  (project-for state project)
  ?~  item
    [%refused source [%project-missing project]]
  ?.  ?=(^ (role-for:mpl u.item source))
    [%refused source [%project-member-missing project]]
  =/  chain=(unit chain:mr)
    (~(get by chains.state) [project host])
  ?~  chain
    [%refused source [%project-chain-missing project]]
  ?:  (gth count.u.chain export-cap:mrpl)
    [%refused source [%export-cap-exceeded project count.u.chain export-cap:mrpl]]
  =/  bundle=(unit bundle:mrp)  (bundle-for:mrpl u.chain source)
  ?~  bundle
    [%refused source [%contributor-has-no-verified-acts project]]
  ?.  ?&  =(source owner.body.u.bundle)
          (bundle-valid:mrpl u.bundle)
      ==
    [%refused source [%invalid-canonical-bundle project]]
  [%accepted project source u.bundle]
--
