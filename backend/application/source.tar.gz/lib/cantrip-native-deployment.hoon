::  Cantrip adapter. The app supplies its canonical acceptance journal and
::  current law window; no command supplies a callback, factory or permission.
/+  deploy=native-coding-deployment, accept=native-coding-accept,
    editor=cantrip-editor-save, law=cantrip-law-window
|%
+$  command
  $%  [%native-coding-deployment-grant-v1 value=grant:deploy]
      [%native-coding-deployment-revoke-v1 id=@ux]
      $>(%native-coding-deploy-v1 request:deploy)
      [%native-coding-deployment-observe-v1 id=@ux]
      [%native-coding-deployment-activate-v1 id=@ux]
      [%native-coding-deployment-cancel-v1 id=@ux]
  ==
++  act
  |=  [b=bowl:gall s=organ:deploy accepted=ledger:accept c=command window=window:law idle=?]
  ^-  change:deploy
  ?>  =(our.b src.b)
  ?:  ?=(%native-coding-deployment-grant-v1 -.c)
    ?>  (grant-valid:deploy our.b value.c)
    =/  old  (~(get by grants.s) id.value.c)
    ?^  old
      ?>  =(value.c grant.u.old)
      [s ~]
    ?>  (lth ~(wyt by grants.s) 128)
    =/  next=organ:deploy  s(grants (~(put by grants.s) id.value.c [value.c ~]))
    [next ~[(attest our.b [%grant value.c])]]
  ?:  ?=(%native-coding-deployment-revoke-v1 -.c)
    =/  old  (~(get by grants.s) id.c)
    ?~  old  [s ~]
    ?^  revoked.u.old  [s ~]
    =/  next=organ:deploy  s(grants (~(put by grants.s) id.c u.old(revoked `now.b)))
    [next ~[(attest our.b [%revoke id.c now.b])]]
  ?:  ?=(%native-coding-deploy-v1 -.c)
    =/  old  (~(get by records.s) id.c)
    ?^  old
      ?>  =(c request.u.old)
      [s (publish:deploy our.b u.old)]
    ?>  &(idle (permission:editor window))
    =/  candidate  (~(get by accepted) candidate.c)
    ?>  ?=(^ candidate)
    (begin:deploy b s c u.candidate)
  =/  old  (~(get by records.s) id.c)
  ?~  old  [s ~]
  ?:  ?=(%native-coding-deployment-cancel-v1 -.c)
    ::  Refusal is a reported capability, never a claim the submitted native
    ::  write stopped. The retained deployment remains reserved.
    [s ~[[%pass /native-deployment-status %agent [our.b %viki] %poke %noun !>([%native-coding-deployment-cancel-refused-v1 id.c (cancellation:deploy u.old)])]]]
  ?:  ?=(%native-coding-deployment-activate-v1 -.c)
    ?>  &(idle (permission:editor window))
    (activate:deploy b s id.c)
  ?:  =(%activating phase.u.old)  (verify:deploy b s id.c)
  ?.  ?=(?(%cloning %overrides) phase.u.old)  [s (publish:deploy our.b u.old)]
  ?.  &(idle (permission:editor window))  [s (publish:deploy our.b u.old)]
  (observe:deploy b s id.c)
++  attest
  |=  [our=@p value=*]
  ^-  card:agent:gall
  [%pass /native-deployment-evidence %agent [our %graf] %poke %graf-action !>([%attest [%native-coding-deployment-authority-v1 (digest:deploy value) value]])]
++  arvo
  |=  [b=bowl:gall s=organ:deploy accepted=ledger:accept w=wire sign=sign-arvo window=window:law idle=?]
  ^-  change:deploy
  ?.  &(=(our.b src.b) ?=([%native-deployment @ @ ~] w))  [s ~]
  =/  parsed  (slaw %ux i.t.w)
  ?~  parsed  [s ~]
  =/  id=@ux  u.parsed
  ?.  =(w (wire-for:deploy id i.t.t.w))  [s ~]
  =/  old  (~(get by records.s) id)
  ?~  old  [s ~]
  =/  r=record:deploy  u.old
  ?:  =(w (wire-for:deploy id %prepare))
    ?.  &(=(%checking phase.r) ?=([%khan %arow *] sign))  [s ~]
    ?.  ?=(%& -.p.sign)
      (put:deploy our.b s r(phase %unknown, reason `%deployment-preparation-unconfirmed) ~)
    =/  result  ((soft ,rehearsal:deploy) q.q.p.p.sign)
    ?~  result
      (put:deploy our.b s r(phase %unknown, reason `%deployment-preparation-invalid) ~)
    (prepared:deploy our.b s id u.result)
  ?:  &(=(w (wire-for:deploy id %clone)) ?=([%clay %mere *] sign))
    ?.  &(=(%cloning phase.r) ?=(%| -.p.sign))  [s ~]
    (put:deploy our.b s r(phase %refused, reason `%deployment-clone-refused) ~)
  ?.  ?=([%clay %writ *] sign)  [s ~]
  (act b s accepted [%native-coding-deployment-observe-v1 id] window idle)
--

