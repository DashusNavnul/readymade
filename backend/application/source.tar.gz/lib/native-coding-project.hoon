::  Generic project/source law. Caller supplies its registered project config;
::  canonical catalog membership is read here. Candidates are not save grants.
/-  nc=native-coding, mp=multiplayer-project
/+  projects=multiplayer-project, changes=multiplayer-changeset,
    source-import=native-coding-source-reservation,
    guard=viki-scry-guard, dsr=desk-shell-read
|%
++  max-files  4.096
++  file-byte-limit  1.048.576
++  configuration
  |=  p=project:nc
  ^-  @ux
  (shax (jam [%native-coding-configuration-v1 p]))
++  path-valid
  |=  pax=path
  ^-  ?
  &((lte (lent pax) 16) (levy pax segment-valid))
++  segment-valid
  |=  segment=@ta
  ^-  ?
  ?&  !=(0 segment)  !=('.' segment)  !=('..' segment)
      (lte (met 3 segment) 128)
      %+  levy  (trip segment)
      |=  c=@t
      |(&((gte c 'a') (lte c 'z')) &((gte c 'A') (lte c 'Z')) &((gte c '0') (lte c '9')) =(c '-') =(c '_') =(c '.'))
  ==
++  under
  |=  [root=path pax=path]
  ^-  ?
  &((lte (lent root) (lent pax)) =(root (scag (lent root) pax)))
++  covered
  |=  [roots=(set path) pax=path]
  ^-  ?
  (lien ~(tap in roots) |=(root=path (under root pax)))
++  readable
  |=  [p=project:nc pax=path]
  ^-  ?
  &((path-valid pax) (covered readable.policy.p pax))
++  writable
  |=  [p=project:nc pax=path]
  ^-  ?
  ?&  ?=(^ pax)  (readable p pax)
      (covered writable.policy.p pax)  !(covered protected.policy.p pax)
  ==
++  mutating
  |=  op=operation:nc
  ^-  ?
  ?=(?(%create %replace %patch %move %delete %undo %batch %patches %writes) op)
++  operations
  ::  Batch grants derive from each actual edit, never a blanket batch grant.
  ::  A multi-file patch proposal is the ordinary %patch operation; each edit
  ::  path is still checked for writability when the candidate is validated.
  |=  args=tool-args:nc
  ^-  (list operation:nc)
  ?:  ?=(%writes -.args)
    ::  No blanket write grant: every requested create/replace is admitted.
    ?.  &((gth (lent items.args) 0) (lte (lent items.args) 16))  ~
    (turn items.args |=(i=write-item:nc ?~(before.i %create %replace)))
  ?:  ?=(%patches -.args)
    ?.  &((gth (lent items.args) 0) (lte (lent items.args) 16))  ~
    ~[%patch]
  ?.  ?=(%batch -.args)  ~[-.args]
  ?.  &((gth (lent edits.args) 0) (lte (lent edits.args) 32))  ~
  %+  turn  edits.args
  |=  e=edit:nc
  ?-  kind.change.e
    %add  %create
    %modify  %replace
    %delete  %delete
  ==
++  valid
  |=  p=project:nc
  ^-  ?
  ?&  (spec-valid:projects spec.p)  !=(0 working.p)
      !=(base-desk.spec.p working.p)
      (lte (met 3 id.spec.p) 128)
      (lte (met 3 instructions.p) 16.384)  (lte (met 3 conventions.p) 8.192)
      (gte max-file-bytes.policy.p 1)  (lte max-file-bytes.policy.p file-byte-limit)
      (gte max-candidate-bytes.policy.p max-file-bytes.policy.p)
      (lte max-candidate-bytes.policy.p 1.048.576)
      (lte ~(wyt in readable.policy.p) 64)
      (lte ~(wyt in writable.policy.p) 64)
      (lte ~(wyt in protected.policy.p) 64)
      (levy ~(tap in readable.policy.p) path-valid)
      (levy ~(tap in writable.policy.p) path-valid)
      (levy ~(tap in protected.policy.p) path-valid)
      (lte ~(wyt by file-types.p) 32)  (lte ~(wyt by dependencies.p) max-files)
      (levy ~(tap by file-types.p) |=([suffix=@tas mark=@tas] &(!=(0 suffix) =(suffix mark))))
      %+  levy  ~(tap by dependencies.p)
      |=  [pax=path imports=(list path)]
      &((readable p pax) (lte (lent imports) 128) (levy imports |=(x=path (readable p x))))
      (lte (lent targets.p) 32)
      =((lent targets.p) ~(wyt in (silt (turn targets.p |=(t=build-target:nc name.t)))))
      %+  levy  targets.p
      |=  t=build-target:nc
      ?&  !=(0 name.t)  (readable p entry.t)
          (lte (lent dependencies.t) 128)  (levy dependencies.t |=(x=path (readable p x)))
          (lte (lent checks.t) 32)
          (levy checks.t |=([name=@tas expression=@t] &(!=(0 name) (lte (met 3 expression) 8.192))))
      ==
  ==
++  revision-valid
  |=  r=revision:nc
  ^-  ?
  &(!=(0 desk.r) (gth number.r 0) !=(0 root.r) !=(0 commit.r))
++  tree-valid
  |=  [p=project:nc t=tree:nc]
  ^-  ?
  ?&  (revision-valid revision.t)  (snapshot-valid:changes snapshot.t)
      =(authority.spec.p owner.revision.t)
      =(id.spec.p project.body.snapshot.t)
      =(desk.revision.t base-desk.body.snapshot.t)
      =(number.revision.t base-revision.body.snapshot.t)
      (lte ~(wyt by files.body.snapshot.t) max-files)
  ==
++  member
  |=  [p=project:nc catalog=project:mp actor=@p op=operation:nc]
  ^-  ?
  ?.  &((valid p) (project-valid:projects catalog) =(spec.p spec.catalog))  %.n
  ?.  (~(has in operations.policy.p) op)  %.n
  =/  found  (~(get by members.catalog) actor)
  ?~  found  %.n
  ?:  (mutating op)  ?=(?(%operator %maintainer %contributor) role.u.found)
  ?:(?=(?(%compile %check %eval %inspect %cancel) op) ?=(?(%operator %maintainer %contributor) role.u.found) %.y)
++  authorize
  |=  [p=project:nc catalog=project:mp c=context:nc op=operation:nc]
  ^-  (each ~ @tas)
  ?.  (member p catalog actor.c op)  [%| %project-operation-refused]
  ?.  ?&  =(id.spec.p project.c)  =((configuration p) configuration.c)
          !=(0 session.c)  !=(0 request.c)
          (lte (met 0 session.c) 256)  (lte (met 0 request.c) 256)
          (revision-valid source.c)  =(authority.spec.p owner.source.c)
          |(=(working.p desk.source.c) =(base-desk.spec.p desk.source.c))
      ==  [%| %context-mismatch]
  ?:  &((mutating op) !=(working.p desk.source.c))  [%| %accepted-source-protected]
  [%& ~]
++  catalog
  |=  [our=@p at=@da p=project:nc]
  ^-  (each project:mp @tas)
  ?.  &((valid p) =(our authority.spec.p))  [%| %project-invalid]
  ?.  (agent-live:guard our at %multiplayer-runtime)  [%| %catalog-unavailable]
  =/  id=@t  id.spec.p
  =/  found=(unit project:mp)
    .^((unit project:mp) %gx /(scot %p our)/multiplayer-runtime/(scot %da at)/catalog/[id]/noun)
  ?~  found  [%| %project-missing]
  ?.  &((project-valid:projects u.found) =(spec.p spec.u.found))  [%| %catalog-mismatch]
  [%& u.found]
++  tree-at
  ::  Numbered revisions use the direct dome revision index, never %cv.
  |=  [our=@p at=@da p=project:nc desk=@tas number=@ud]
  ^-  (each tree:nc @tas)
  =/  available  (free:source-import our at desk)
  ?:  ?=(%| -.available)  [%| p.available]
  ?.  &(=(our authority.spec.p) |(=(working.p desk) =(base-desk.spec.p desk)))
    [%| %foreign-source]
  =/  domes=cone:clay  .^(cone:clay %cx /(scot %p our)//(scot %da at)/domes)
  =/  dome=(unit dome:clay)  (~(get by domes) [our desk])
  ?~  dome  [%| %desk-missing]
  =/  commit=(unit tako:clay)  (~(get by hit.u.dome) number)
  ?~  commit  [%| %revision-missing]
  =/  y=yaki:clay
    .^(yaki:clay %cs (beam:dsr our at desk /yaki/(scot %uv u.commit)))
  ?.  (lte ~(wyt by q.y) max-files)  [%| %namespace-over-limit]
  =/  files=(map path @ux)  (~(run by q.y) |=(hash=lobe:clay `@ux`hash))
  =/  root=@uv  .^(@uv %cz (beam-at:dsr our desk (scot %ud number) /))
  =/  t=tree:nc
    [[our desk number root u.commit] (make-snapshot:changes [1 id.spec.p desk number files])]
  ?:((tree-valid p t) [%& t] [%| %source-invalid])
++  current
  ::  This is a read of private accepted/work desks, not permission to land.
  |=  [our=@p at=@da p=project:nc]
  ^-  (each [accepted=tree:nc working=tree:nc] @tas)
  ?.  &((valid p) =(our authority.spec.p))  [%| %project-invalid]
  =/  domes=cone:clay  .^(cone:clay %cx /(scot %p our)//(scot %da at)/domes)
  =/  a  (~(get by domes) [our base-desk.spec.p])
  =/  w  (~(get by domes) [our working.p])
  ?~  a  [%| %accepted-missing]
  ?~  w  [%| %working-missing]
  ?.  &(=(%dead liv.u.w) =(~ ren.u.w) =(~ wic.u.w))  [%| %work-not-isolated]
  ?.  &((private-path:dsr our at base-desk.spec.p /) (private-path:dsr our at working.p /))
    [%| %project-not-private]
  =/  accepted  (tree-at our at p base-desk.spec.p let.u.a)
  ?:  ?=(%| -.accepted)  [%| p.accepted]
  =/  working  (tree-at our at p working.p let.u.w)
  ?:  ?=(%| -.working)  [%| p.working]
  [%& [p.accepted p.working]]
++  conflicts
  ::  A held working desk is exclusive to its session, as in fleet admission.
  ::  Equal project-relative paths on separate private desks do not conflict.
  ::  Canonical persistence and owner revocation belong to Viki/Cantrip.
  |=  [c=candidate:nc held=(list reservation:nc)]
  ^-  (set path)
  =/  paths=(set path)  (silt (turn edits.c |=(e=edit:nc path.change.e)))
  |-  ^-  (set path)
  ?~  held  ~
  =/  r=reservation:nc  i.held
  ?.  ?&  =(%held status.r)  !=(session.context.c session.context.r)
          =(owner.source.context.c owner.source.context.r)
          =(desk.source.context.c desk.source.context.r)
      ==
    $(held t.held)
  paths
--
