::  Portable subscription policy. No saved grants or named administrators.
::  HTTP response ducts are handled separately by Graf's authenticated handler.
|%
++  watch
  |=  [our=@p src=@p =path]
  ^-  ?
  ?:  |(=(our src) =(our (^sein:title src)))  %.y
  ?.  |(?=([%fedwiki %page @ ~] path) ?=([%fedwiki %site @ %page @ ~] path))
    %.n
  =(src (^sein:title our))
--
