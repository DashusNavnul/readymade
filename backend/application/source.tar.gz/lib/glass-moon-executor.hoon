::  Isolated selected-provider imports; protocol nouns and agent names stay unchanged.
::  /lib/glass-moon-executor
::
::  Pure admission, model-dispatch, and response construction for the native
::  Dashus/Baldur command lane.
::
/-  cmt=cantrip-multiplayer-task, mb=model-bridge,
    ms=multiplayer-session, mse=glass-moon-executor,
    vp=vibecoding-proposal, cpg=cantrip-peer-grant
/+  cmtl=cantrip-multiplayer-task, msl=multiplayer-session,
    cpa=cantrip-peer-admission, clw=cantrip-law-window, native=codex-inference
|%
++  max-jobs  `@ud`32
++  max-completed  `@ud`128
++  max-retries  `@ud`0
++  max-task-paths  `@ud`32
++  max-task-tools  `@ud`16
++  max-task-evidence  `@ud`16
++  max-task-intent-bytes  `@ud`8.192
++  max-task-path-bytes  `@ud`512
++  min-review-output  `@ud`256
++  model-timeout  `@dr`~m5
++  delivery-timeout  `@dr`~m1
++  overall-timeout  `@dr`~m7
++  earlier
  |=  [a=@da b=@da]
  ^-  @da
  ?:((lte a b) a b)
++  job-capacity-available
  |=  count=@ud
  ^-  ?
  (lth count max-jobs)
++  binding-valid
  |=  binding=binding:mse
  ^-  ?
  ?&  ?:  ?=([%multiplayer-session-executor-binding-v2 *] -.binding)
        ?&  (model-bridge-spec-valid:mb selected.binding)
            =(backend.binding provider-id.selected.binding)
            ?:  (spec-valid:native selected.binding)
              ::  Inert v2 identity fields, not a physical Lick endpoint.
              =([%codex-inference %model-bridge-action] [port.binding protocol.binding])
            =([%local-session port.binding protocol.binding] target.selected.binding)
            !=(0 route.binding)
        ==
      %.y
      (bounded-text:mb local-session.binding max-identifier-bytes:mb)
      (bounded-text:mb peer-session.binding max-identifier-bytes:mb)
      (bounded-text:mb workspace.binding max-identifier-bytes:mb)
      (bounded-text:mb backend.binding max-identifier-bytes:mb)
      (bounded-text:mb `@t`port.binding max-identifier-bytes:mb)
      (bounded-text:mb `@t`protocol.binding max-protocol-bytes:mb)
  ==
++  binding-status-confirmed
  |=  $:  expected-request=@ux
          expected-binding=binding:mse
          actual-request=@ux
          enabled=?
          actual-binding=(unit binding:mse)
      ==
  ^-  ?
  ?&  =(expected-request actual-request)
      enabled
      ?=(^ actual-binding)
      =(expected-binding u.actual-binding)
  ==
++  encode-task
  |=  task=task-request:mse
  ^-  @t
  (scot %uw (jam task))
++  select-task
  |=  [task=task-request-v1:mse expected=model-bridge-spec:mb route=@ux]
  ^-  task-request:mse
  [[%multiplayer-task-request-v2 expected route] +.task]
++  selected-task
  |=  task=task-request:mse
  ^-  ?
  ?=([%multiplayer-task-request-v2 *] -.task)
++  selection-matches
  |=  [binding=binding:mse task=task-request:mse]
  ^-  ?
  ?:  ?=([%multiplayer-task-request-v2 *] -.task)
    ?&  ?=([%multiplayer-session-executor-binding-v2 *] -.binding)
        =(expected.task selected.binding)
        =(route.task route.binding)
    ==
  ?=(%multiplayer-session-executor-binding-v1 -.binding)
++  review-requested
  |=  task=task-request:mse
  ^-  ?
  %+  lien  expected-evidence.task
  |=(evidence=@tas =(%structured-review-v1 evidence))
++  model-input
  |=  task=task-request:mse
  ^-  @t
  ?.  (review-requested task)  intent.task
  %+  rap  3
  :~  intent.task
      ' Return exactly one JSON object and no other text: {"type":"MULTIPLAYER_REVIEW_V1","verdict":"accept","findings":"0x00"}. Set verdict to accept, revise, or reject. Set findings to one 8-bit hexadecimal mask using the bit meanings in the task.'
  ==
++  decode-task-text
  |=  text=@t
  ^-  (unit task-request:mse)
  =/  decoded=(unit *)
    (mole |.((cue (slav %uw text))))
  ?~  decoded  ~
  ((soft task-request:mse) u.decoded)
++  decode-task
  |=  item=message:ms
  ^-  (unit task-request:mse)
  (decode-task-text text.body.item)
::  THE SECOND CEILING.  task-admissible was one constant; this was the same
::  constant in a second place, and a Cantrip grant could not admit a write
::  while this still read write-roots=~ and allow-mutations=%.n.  Write
::  authority here derives from the GRANT now.  With no grant it is empty,
::  which is exactly what it always was.
++  task-ceiling-for
  |=  $:  issuer=@p
          peer=@p
          peer-session=@t
          local-session=@t
          workspace=@t
          grant=(unit peer-grant:cpg)
          accepted-at=@da
      ==
  ^-  ceiling:cmt
  =/  writes=(list @t)
    ?~  grant  ~
    ?.  =(%reversible tier-ceiling.u.grant)  ~
    ~[(cat 3 'desk/' fork.u.grant)]
  =/  body=ceiling-body:cmt
    :*  %cantrip-multiplayer-task-ceiling-v1
        issuer
        peer
        peer-session
        local-session
        workspace
        ~['.']
        writes
        ~[%read %search %inspect]
        ?=(^ writes)
        model-timeout
        max-text-bytes:msl
        (add accepted-at overall-timeout)
    ==
  [body (ceiling-digest:cmtl body)]
++  task-ceiling
  |=  $:  binding=binding:mse
          grant=(unit peer-grant:cpg)
          item=message:ms
          accepted-at=@da
      ==
  ^-  ceiling:cmt
  %-  task-ceiling-for
  :*  recipient.body.item
      sender.body.item
      sender-session.body.item
      recipient-session.body.item
      workspace.binding
      grant
      accepted-at
  ==
++  task-authorization
  |=  $:  our=@p
          binding=binding:mse
          grant=(unit peer-grant:cpg)
          item=message:ms
          task=task-request:mse
          accepted-at=@da
      ==
  ^-  authorization:cmt
  %-  authorize:cmtl
  :*  (task-ceiling binding grant item accepted-at)
      authority.task
      accepted-at
      our
      sender.body.item
      sender-session.body.item
      recipient-session.body.item
      workspace.binding
  ==
++  task-authorized
  |=  $:  our=@p
          binding=binding:mse
          grant=(unit peer-grant:cpg)
          item=message:ms
          task=task-request:mse
          accepted-at=@da
      ==
  ^-  ?
  =/  decision=authorization:cmt
    (task-authorization our binding grant item task accepted-at)
  ?=(%& -.decision)
++  policy-hash-for
  |=  $:  item=message:ms
          task=task-request:mse
          workspace=@t
          accepted-at=@da
      ==
  ^-  @t
  ::  DELIBERATELY UNGRANTED, but NOT for the reason first given here.  That
  ::  said the hash "is recomputed later by job-valid, so it must not move
  ::  when a grant is issued or revoked mid-flight".  job-valid is called in
  ::  ted/ph/multiplayer-session-executor-proof and NOWHERE in app/ -- so the
  ::  hash is computed and never re-checked in production, and a justification
  ::  resting on a check that does not run is not a justification.
  ::
  ::  The real reason to keep it ungranted is narrower: it is a commitment to
  ::  what the PEER asked for, taken at admission, and that is a useful thing
  ::  to have stable even though nothing currently verifies it.  The honest
  ::  consequence is unchanged -- the hash commits to the BASE ceiling, not
  ::  the granted one -- and the missing piece is not a migration but a
  ::  CALLER: nothing re-checks job integrity at all.
  =/  ceiling=ceiling:cmt
    %-  task-ceiling-for
    :*  recipient.body.item
        sender.body.item
        sender-session.body.item
        recipient-session.body.item
        workspace
        ~
        accepted-at
    ==
  (scot %ux (shax (jam [digest.ceiling authority.task])))
++  policy-hash
  |=  [binding=binding:mse item=message:ms task=task-request:mse accepted-at=@da]
  ^-  @t
  (policy-hash-for item task workspace.binding accepted-at)
++  fields-bounded
  |=  [values=(list @t) count=@ud bytes=@ud]
  ^-  ?
  ?&  (lte (lent values) count)
      (levy values |=(value=@t ?&((gth (met 3 value) 0) (lte (met 3 value) bytes))))
  ==
++  tools-valid
  |=  tools=(list @tas)
  ^-  ?
  ?&  (gth (lent tools) 0)
      (lte (lent tools) max-task-tools)
      %+  levy  tools
      |=  tool=@tas
      ?|  =(%read tool)  =(%search tool)  =(%inspect tool)  ==
  ==
++  task-valid
  |=  task=task-request:mse
  ^-  ?
  ?&  ?:  ?=([%multiplayer-task-request-v2 *] -.task)
        ?&  (model-bridge-spec-valid:mb expected.task)
            |(?=(%local-session -.target.expected.task) (spec-valid:native expected.task))
            !=(0 route.task)
            !allow-mutations.authority.task
            ?=(~ write-paths.authority.task)
            (gte max-output.authority.task 256)
            !(review-requested task)
            (~(has in (silt expected-evidence.task)) %moon-provider-result-v2)
            (~(has in (silt expected-evidence.task)) %candidate-source)
        ==
      %.y
      =(%multiplayer-task-authority-v1 -.authority.task)
      (bounded-text:mb task-id.task max-identifier-bytes:mb)
      ?&  (gth (met 3 intent.task) 0)
          (lte (met 3 intent.task) max-task-intent-bytes)
      ==
      (fields-bounded read-paths.authority.task max-task-paths max-task-path-bytes)
      (fields-bounded write-paths.authority.task max-task-paths max-task-path-bytes)
      (tools-valid tools.authority.task)
      ?&  (lte (lent expected-evidence.task) max-task-evidence)
          %+  levy  expected-evidence.task
          |=(item=@tas (bounded-text:mb `@t`item max-identifier-bytes:mb))
      ==
      (gte max-runtime.authority.task ~s1)
      (lte max-runtime.authority.task model-timeout)
      (gth max-output.authority.task 0)
      (lte max-output.authority.task max-text-bytes:msl)
      ?:  (review-requested task)
        (gte max-output.authority.task min-review-output)
      %.y
      (lte (met 3 (encode-task task)) max-text-bytes:msl)
  ==
::  The act a task amounts to, so the ceiling can be read as Cantrip law
::  rather than as two booleans.  A task that asks to mutate anything is an
::  %inscribe, and %inscribe has no peer tier at all.
++  task-act
  |=  [task=task-request:mse fork=@tas]
  ^-  proposed-act:vp
  ::  A task claiming any write intent is a %branch -- work inside a fork --
  ::  not an %inscribe.  %inscribe has no peer tier at all, so mapping it
  ::  there would make the grant machinery decorative: no grant could ever
  ::  admit a write.  %branch is %reversible, so it needs a %reversible grant
  ::  AND the fork containment below, and it still cannot land: the executor
  ::  returns a digest-only release and the host does the promoting.
  =/  kind=act:clw
    ?:  ?|  allow-mutations.authority.task
            (gth (lent write-paths.authority.task) 0)
        ==
      %branch
    %read
  [1 kind [%clay fork ~] ~ ~]
::
::  Containment on the DECLARED paths, not just on the act.  The act target is
::  the fork by construction, so checking it alone would be tautological.
::
::  WHAT THIS ACTUALLY BUYS, because the prefix match below promises more than
::  the system delivers.  eligibility runs this in the same conjunction as
::  task-authorized, and authorize compares write-paths to the ceiling with
::  text-subset -- EXACT string membership (lib/cantrip-multiplayer-task :56).
::  task-ceiling-for emits exactly one write root, 'desk/<fork>'.  So the
::  binding rule is equality, not containment: 'desk/scratch' is admitted and
::  'desk/scratch/lib/thing' is REFUSED, even though it is plainly inside the
::  fork and the prefix test below passes it.
::
::  This arm is therefore not the gate -- it is dominated by the stricter one.
::  It is kept because it fires FIRST and yields %outside-fork, which tells a
::  peer what it did wrong, where the ceiling path yields only a generic
::  refusal.  A better reason for the same denial.
::
::  DESIGN GAP, named rather than papered over: write-paths is typed
::  (list @t) but can only ever hold one admissible value, so it is a boolean
::  wearing a list.  Real per-path authority needs the ceiling comparison to
::  be prefix-aware for write roots -- which is a change to the SHARED
::  cantrip-multiplayer-task law and so belongs in the merge with Dashus, not
::  in a unilateral landing.
++  writes-inside-fork
  |=  [task=task-request:mse fork=@tas]
  ^-  ?
  =/  pre=tape  (weld "desk/" (trip fork))
  %+  levy  write-paths.authority.task
  |=  path=@t
  ^-  ?
  =/  t=tape  (trip path)
  ?&  =((lent pre) (lent (scag (lent pre) t)))
      =(pre (scag (lent pre) t))
  ==
::
::  THE CEILING NAMES A FORK; THE EXECUTOR RUNS IN A WORKSPACE.  task-ceiling-for
::  derives its single write root from the GRANT's fork -- 'desk/<fork>' -- while
::  the request's session, which is what the host resolves its working directory
::  from, is workspace.binding.  Nothing tied those two together.  A grant for
::  fork 'scratch' issued against a binding whose workspace is 'codex-baldur'
::  therefore published a ceiling authorising writes to desk/scratch and sent the
::  host to write in codex-baldur, with the ship's authority behind it.  The host
::  docstring names that exact hazard and does not guard it, because the fork
::  never reaches the host: policy-json ships write-roots and the host reads only
::  allow-mutations.
::
::  So the agreement has to be established here, where both halves are in scope.
::  A %safe grant emits no write root at all, so there is nothing it can
::  disagree with and nothing to refuse.
++  fork-agrees-with-workspace
  |=  [g=peer-grant:cpg binding=binding:mse]
  ^-  ?
  ?.  =(%reversible tier-ceiling.g)  %.y
  =(fork.g workspace.binding)
::
::  With no grant the ship falls back to its own default: %safe, read-only.
::  That is exactly the ceiling this lane always enforced, so an ungranted
::  executor is no more permissive than it was, and a granted one is
::  permissive only as far as the grant says.
++  default-grant
  |=  [binding=binding:mse at=@da]
  ^-  peer-grant:cpg
  :*  %cantrip-peer-grant-v1
      peer.binding
      peer-session.binding
      'executor-default'
      %pataphor
      %safe
      (~(gas in *(set @t)) ~['read-file'])
      (add at ~d1)
  ==
::
::  The full verdict.  src, the lease clock and the fork reach the gate here.
++  task-verdict
  |=  $:  source=@p
          grant=(unit peer-grant:cpg)
          binding=binding:mse
          task=task-request:mse
          at=@da
      ==
  ^-  peer-verdict:cpg
  ?.  (task-valid task)  [%| %act-not-admissible]
  =/  g=peer-grant:cpg  ?^(grant u.grant (default-grant binding at))
  ?.  (writes-inside-fork task fork.g)  [%| %outside-fork]
  ::  This was emitted as %outside-fork for three cycles, on the stated reason
  ::  that peer-refusal is a CLOSED union in a shared sur and adding a term
  ::  would diverge a type both ships build against. **Checked 2026-08-28, and
  ::  that reason does not hold.** Nothing on this desk switches on the union:
  ::  its only consumer is +refuse in cantrip-peer-admission, a pure wrapper
  ::  that puts the value in [%| why] without inspecting it, and there is no
  ::  exhaustive ?- on a refusal anywhere. And the value never crosses Ames --
  ::  a denied peer receives TEXT, 'REMOTE-COMMAND-REFUSED: ' welded to a scot
  ::  of the reason, so the far ship never decodes this type at all.
  ::
  ::  So the term was addable all along, and the refusal can say what it means.
  ?.  (fork-agrees-with-workspace g binding)  [%| %fork-not-workspace]
  =/  request=peer-request:cpg
    [%cantrip-peer-request-v1 peer-session.binding (task-act task fork.g)]
  (admit:cpa source `g request at)
::
::  The ceiling used to be a constant in this file, which made it a real gate
::  with no path by which a peer could ever be granted more.  It is Cantrip's
::  act-to-tier mapping now: a read is %safe and admissible.
::
::  WHAT REFUSES A MUTATION HERE, precisely, because the earlier version of
::  this comment got it wrong.  It said a mutation "is inadmissible by the
::  TYPE rather than by a line here".  That WAS true when task-act mapped
::  write-intent to %inscribe, which has no peer tier.  It stopped being true
::  the moment task-act started mapping it to %branch so a grant could admit
::  it: %branch HAS a tier (%reversible), so the `?~ tier` arm below is
::  unreachable for writes and the only thing refusing them is the literal
::  `=(%safe u.tier)` comparison.  A comparison, not a type.  The type-level
::  claim still holds one level up -- %inscribe/%promote/%implement/%reduce
::  have no peer tier at all -- but it is not what this arm relies on.
::
::  STALE COMMENT REMOVED, 2026-08-27.  It said src.bowl, the lease clock and
::  the fork were "still missing".  They are not: they reach the gate through
::  `eligibility` -> `task-verdict`, which is what the RECEIVE path uses.
::
::  What this arm is, precisely, so nobody mistakes it for the gate again:
::  it is the grant-free SHAPE check, and its only remaining caller is the
::  SEND path (lib/multiplayer-session-coordinator :22), which is asking "is
::  this task well formed enough to send", not "may this peer do it".  There
::  is no grant on the send side and there should not be -- the sender does
::  not get to decide what the receiver will allow.  Keep it %safe-only: a
::  sender that composes a mutating task learns immediately rather than
::  discovering it in a refusal from across Ames.
++  task-admissible
  |=  task=task-request:mse
  ^-  ?
  ?.  (task-valid task)  %.n
  =/  act  (task-act task %pataphor)
  =/  tier  (peer-tier-of:cpa kind.act)
  ?~  tier  %.n
  =(%safe u.tier)
++  legacy-task
  |=  [task-id=@t intent=@t]
  ^-  task-request:mse
  :*  %multiplayer-task-request-v1
      task-id
      intent
      :*  %multiplayer-task-authority-v1
          ~['.']
          ~
          ~[%read %search %inspect]
          %.n
          model-timeout
          max-text-bytes:msl
      ==
      ~[%summary]
  ==
::  A DENIAL IS NOT SILENCE.  These two were one boolean, so the app answered
::  `this to both, and a peer refused BY POLICY got exactly what a peer whose
::  message was addressed elsewhere got: nothing.  The typed reason computed
::  at admission was discarded on the way out.
::
::  %not-mine must stay silent -- it is traffic that is not ours, and
::  answering it is how you build a loop.  %denied deserves an answer and a
::  record.
+$  ruling
  $%  [%not-mine ~]
      [%denied reason=@tas]
      [%ok ~]
  ==
++  eligibility
  |=  $:  our=@p
          binding=binding:mse
          grant=(unit peer-grant:cpg)
          item=message:ms
          accepted-at=@da
      ==
  ^-  ruling
  =/  task=(unit task-request:mse)  (decode-task item)
  ?~  task  [%not-mine ~]
  ::  addressing first: anything failing here is not ours to answer
  ?.  ?&  (binding-valid binding)
          (message-valid:msl item)
          =(task-id.u.task thread.body.item)
          =(%request kind.body.item)
          ?=(~ reply-to.body.item)
          =(our recipient.body.item)
          =(peer.binding sender.body.item)
          =(local-session.binding recipient-session.body.item)
          =(peer-session.binding sender-session.body.item)
      ==
    [%not-mine ~]
  ::  the sender is what Ames authenticated; the verdict checks it against
  ::  the grant.  From here on a refusal is OURS and gets said out loud.
  ?.  (selection-matches binding u.task)  [%denied %provider-selection-mismatch]
  =/  verdict
    (task-verdict sender.body.item grant binding u.task accepted-at)
  ?.  ?=(%& -.verdict)  [%denied refusal.verdict]
  ?.  (task-authorized our binding grant item u.task accepted-at)
    [%denied %ceiling-refused]
  [%ok ~]
::  kept so every existing caller and proof line stays exactly as it was
++  eligible
  |=  $:  our=@p
          binding=binding:mse
          grant=(unit peer-grant:cpg)
          item=message:ms
          accepted-at=@da
      ==
  ^-  ?
  =/  r  (eligibility our binding grant item accepted-at)
  ?=(%ok -.r)
++  request-id
  |=  item=message:ms
  ^-  @t
  (scot %ux digest.item)
++  agent-for
  ::  Select only from the frozen validated spec, never from task text.
  |=  spec=model-bridge-spec:mb
  ^-  @tas
  ?:  (spec-valid:native spec)  %codex-inference
  ?>  &((model-bridge-spec-valid:mb spec) ?=(%local-session -.target.spec))
  %model-bridge
++  make-spec
  |=  binding=binding:mse
  ^-  model-bridge-spec:mb
  ?:  ?=([%multiplayer-session-executor-binding-v2 *] -.binding)
    selected.binding
  :*  %1
      backend.binding
      backend.binding
      'model-unreported'
      'codex-exec-jsonl-request-v1'
      'codex-exec-jsonl-response-v1'
      [%local-session port.binding protocol.binding]
      no-auth:mb
  ==
::  THE AUTHORITY HAS TO CROSS THIS LINE.  It used to not: body-json carried
::  {"input": <free text>} and nothing else, so read-paths, write-paths, tools
::  and allow-mutations gated ADMISSION and then reached neither %model-bridge
::  nor the host.  A grant saying "this peer may write inside desk/scratch"
::  admitted the task and then told the thing doing the writing nothing at all.
::  Containment at execution came from workspace.binding and the host sandbox
::  flag, neither of which knows about the grant.
::
::  The ceiling travels as a sibling key in the JSON body the ship already
::  sends: no type change, no wire arity change, no migration, and a host that
::  reads only "input" is unaffected.  It carries the GRANTED ceiling, never
::  the peer's declared authority -- the peer describes itself, the ship
::  decides, and only the decision is transmitted.
::
::  HONEST STATUS, and read this before trusting it.  The ceiling is now in
::  body-json, which means it is in the request record, in the job, and under
::  the policy-hash commitment.  It does NOT reach the host: sur/model-bridge
::  model-bridge-request-prompt (:247-257) pulls out 'input' and DISCARDS every
::  other key, and app/model-bridge (:162) spits only that prompt down the Lick
::  wire.  So today this is an AUDITABLE COMMITMENT, not enforcement.
::
::  Making it enforcement needs two more things, and neither is done:
::    1. a model-bridge-request-policy extractor beside the prompt one, and a
::       fourth element on the %dispatch command carrying it;
::    2. the host acting on it -- CodexClient.chat selecting --sandbox
::       read-only, Claude/Grok forcing --permission-mode plan, whenever
::       allow-mutations is false.
::  That is a live cross-boundary protocol change and it is deliberately not
::  bundled here.  Until it lands, containment at EXECUTION comes from
::  workspace.binding and the host's own sandbox flag, neither of which knows
::  about the grant.
++  policy-json
  |=  ceiling=ceiling:cmt
  ^-  json
  =/  b=ceiling-body:cmt  body.ceiling
  %-  pairs:enjs:format
  :~  ['allow-mutations' b+allow-mutations.b]
      ['write-roots' a+(turn write-roots.b |=(t=@t s+t))]
      ['max-output' (numb:enjs:format max-output.b)]
      ['workspace' s+workspace.b]
      ['ceiling-digest' s+(scot %ux digest.ceiling)]
  ==
++  make-request
  |=  $:  binding=binding:mse
          grant=(unit peer-grant:cpg)
          item=message:ms
          accepted-at=@da
      ==
  ^-  model-bridge-request:mb
  (make-request-guided binding grant item accepted-at '')
::  GUIDED DISPATCH.  The seiv packet's preamble is prepended to the model
::  input ON THE SHIP.  The host keeps only 'input' (sur/model-bridge's prompt
::  extractor discards every sibling key), so a guidance key beside it would
::  vanish silently and the record would then say guidance was in force when
::  the model never saw it.  Prepending is the only shape where "%guidance-
::  issued in graf" and "guidance in the prompt" cannot disagree.
++  guided-input
  |=  [task=task-request:mse preamble=@t]
  ^-  @t
  ?:  |((selected-task task) =('' preamble))  (model-input task)
  (rap 3 ~[preamble '\0a\0a' (model-input task)])
++  make-request-guided
  |=  $:  binding=binding:mse
          grant=(unit peer-grant:cpg)
          item=message:ms
          accepted-at=@da
          preamble=@t
      ==
  ^-  model-bridge-request:mb
  =/  task=task-request:mse  (need (decode-task item))
  =/  ceiling=ceiling:cmt  (task-ceiling binding grant item accepted-at)
  =/  ceiling=ceiling:cmt
    ?.  (selected-task task)  ceiling
    =/  body=ceiling-body:cmt
      body.ceiling(write-roots ~, allow-mutations %.n)
    [body (ceiling-digest:cmtl body)]
  =/  body=@t
    %-  en:json:html
    %-  pairs:enjs:format
    :~  ['input' s+(guided-input task preamble)]
        ['policy' (policy-json ceiling)]
    ==
  :*  %1
      (request-id item)
      workspace.binding
      ''
      body
      (scot %ux digest.item)
      ?:  (selected-task task)
        (selected-policy task body)
      (policy-hash binding item task accepted-at)
  ==
++  selected-policy
  |=  [task=task-request:mse body=@t]
  ^-  @t
  (scot %ux (shax (jam [%moon-provider-policy-v2 task body])))
++  provider-result-valid
  ::  Data validation only. Authority comes from the authenticated moon message.
  |=  [original=message:ms value=provider-result:mse]
  ^-  ?
  =/  decoded=(unit task-request:mse)  (decode-task original)
  ?~  decoded  %.n
  =/  task=task-request:mse  u.decoded
  ?.  ?=([%multiplayer-task-request-v2 *] -.task)  %.n
  ?&  (message-valid:msl original)
      (task-valid task)
      =(digest.original original.value)
      =(route.task route.value)
      =(expected.task spec.value)
      =(request-id.request.value (request-id original))
      =(context-commitment.request.value (scot %ux digest.original))
      =(policy-hash.request.value (selected-policy task body-json.request.value))
      =(`intent.task (model-bridge-request-prompt:mb request.value))
      (model-bridge-request-valid:mb request.value)
      ?|  ?=(%result -.terminal.value)
          ?=(%error -.terminal.value)
          ?=(%cancelled -.terminal.value)
      ==
      (model-bridge-event-matches-request:mb spec.value request.value terminal.value)
  ==
++  receipt-limit
  ::  Opt-in affects only the complete correlated receipt on the wire.
  ::  max-output remains the candidate content cap and stays <=16 KiB.
  |=  task=task-request:mse
  ^-  @ud
  ?.  &((selected-task task) (~(has in (silt expected-evidence.task)) %provider-envelope-64k-v1))
    max-output.authority.task
  max-provider-envelope-bytes:msl
++  provider-event-text
  |=  [job=job:mse event=model-bridge-event:mb]
  ^-  (unit @t)
  =/  task=task-request:mse  (need (decode-task request.job))
  ?.  ?=([%multiplayer-task-request-v2 *] -.task)  ~
  ?.  ?|(?=(%result -.event) ?=(%error -.event) ?=(%cancelled -.event))  ~
  =/  value=provider-result:mse
    [%moon-provider-result-v2 digest.request.job route.task spec.job bridge-request.job event]
  ?.  (provider-result-valid request.job value)  ~
  ?:  &(?=(%result -.event) (gth (met 3 content.result.event) max-output.authority.task))
    `'REMOTE-COMMAND-REFUSED: candidate content exceeds output bound'
  =/  encoded=@t  (scot %uw (jam value))
  ?:  (gth (met 3 encoded) (receipt-limit task))
    `'REMOTE-COMMAND-REFUSED: complete provider evidence exceeds output bound'
  `encoded
++  decode-provider-result
  |=  [original=message:ms response=message:ms]
  ^-  (unit provider-result:mse)
  =/  task  (decode-task original)
  ?~  task  ~
  ?.  (lte (met 3 text.body.response) (receipt-limit u.task))  ~
  ?.  ?&  (message-valid:msl response)
          =(%response kind.body.response)
          =(`digest.original reply-to.body.response)
          =(thread.body.original thread.body.response)
          =(sender.body.original recipient.body.response)
          =(recipient.body.original sender.body.response)
          =(sender-session.body.original recipient-session.body.response)
          =(recipient-session.body.original sender-session.body.response)
      ==
    ~
  =/  raw=(unit *)  (mole |.((cue (slav %uw text.body.response))))
  ?~  raw  ~
  =/  value=(unit provider-result:mse)  ((soft provider-result:mse) u.raw)
  ?~  value  ~
  ?.  (provider-result-valid original u.value)  ~
  value
++  make-job
  |=  $:  binding=binding:mse
          grant=(unit peer-grant:cpg)
          item=message:ms
          at=@da
      ==
  ^-  job:mse
  (make-job-guided binding grant item at '')
++  make-job-guided
  |=  $:  binding=binding:mse
          grant=(unit peer-grant:cpg)
          item=message:ms
          at=@da
          preamble=@t
      ==
  ^-  job:mse
  =/  spec=model-bridge-spec:mb  (make-spec binding)
  =/  bridge-request=model-bridge-request:mb
    (make-request-guided binding grant item at preamble)
  =/  task=task-request:mse  (need (decode-task item))
  :*  item
      spec
      bridge-request
      at
      (add at max-runtime.authority.task)
      (add at overall-timeout)
      ~
      ~
      %dispatching
  ==
++  clip-text
  |=  [text=@t limit=@ud]
  ^-  @t
  ?:((lte (met 3 text) limit) text `@t`(end [3 limit] text))
++  make-response
  |=  [our=@p original=message:ms text=@t at=@da]
  ^-  message:ms
  =/  task=(unit task-request:mse)  (decode-task original)
  =/  limit=@ud
    ?~(task max-text-bytes:msl (receipt-limit u.task))
  =/  body=message-body:ms
    :*  %multiplayer-session-message-v1
        thread.body.original
        our
        sender.body.original
        recipient-session.body.original
        sender-session.body.original
        %response
        `digest.original
        (clip-text text limit)
        at
    ==
  (make-message:msl body)
++  delivery-at
  |=  [job=job:mse at=@da]
  ^-  @da
  (earlier (add at delivery-timeout) overall-deadline.job)
++  begin-delivery
  |=  [job=job:mse response=message:ms at=@da]
  ^-  job:mse
  =/  deadline=@da  (delivery-at job at)
  job(response `response, phase %responding, delivery-deadline `deadline)
++  migrate-job-1
  |=  [old=job-1:mse at=@da]
  ^-  job:mse
  =/  task=(unit task-request:mse)  (decode-task request.old)
  =/  bridge-request=model-bridge-request:mb
    ?~  task  bridge-request.old
    :*  %1
        request-id.bridge-request.old
        session-id.bridge-request.old
        parent-turn-handle.bridge-request.old
        body-json.bridge-request.old
        context-commitment.bridge-request.old
        (policy-hash-for request.old u.task session-id.bridge-request.old at)
    ==
  =/  base=job:mse
    :*  request.old
        spec.old
        bridge-request
        at
        (add at model-timeout)
        (add at overall-timeout)
        ~
        response.old
        phase.old
    ==
  ?:  =(%dispatching phase.old)  base
  ?~  response.old  base(phase %dispatching)
  (begin-delivery base u.response.old at)
++  migrate-1
  |=  [old=state-1:mse at=@da]
  ^-  state:mse
  =/  jobs=(map @t job:mse)
    %-  ~(run by jobs.old)
    |=(job=job-1:mse (migrate-job-1 job at))
  [%multiplayer-session-executor-v3 binding.old ~ jobs completed.old]
::  v2 -> v3: the grant starts EMPTY, which is the default %safe ceiling.
::  Nothing is inherited as authority; a migration must never widen one.
++  migrate-2
  |=  old=state-2:mse
  ^-  state:mse
  [%multiplayer-session-executor-v3 binding.old ~ jobs.old completed.old]
++  migrate-3
  |=  old=state:mse
  ^-  current-state:mse
  [%multiplayer-session-executor-v4 binding.old grant.old jobs.old completed.old]
++  job-valid
  |=  job=job:mse
  ^-  ?
  =/  task=(unit task-request:mse)  (decode-task request.job)
  =/  task-clock-valid=?
    ?~  task
      =((add accepted-at.job model-timeout) model-deadline.job)
    ?&  (task-admissible u.task)
        =((add accepted-at.job max-runtime.authority.u.task) model-deadline.job)
        ?:  (selected-task u.task)
          ?&  ?=([%multiplayer-task-request-v2 *] -.u.task)
              =(expected.u.task spec.job)
              =((selected-policy u.task body-json.bridge-request.job) policy-hash.bridge-request.job)
          ==
        =((policy-hash-for request.job u.task session-id.bridge-request.job accepted-at.job) policy-hash.bridge-request.job)
    ==
  ?&  (message-valid:msl request.job)
      (model-bridge-spec-valid:mb spec.job)
      (model-bridge-request-valid:mb bridge-request.job)
      =((request-id request.job) request-id.bridge-request.job)
      ?~(response.job %.y (message-valid:msl u.response.job))
      task-clock-valid
      (lte accepted-at.job model-deadline.job)
      (lte model-deadline.job overall-deadline.job)
      ?:  =(%dispatching phase.job)
        ?&  ?=(~ response.job)  ?=(~ delivery-deadline.job)  ==
      ?&  ?=(^ response.job)
          ?=(^ delivery-deadline.job)
          (lte accepted-at.job u.delivery-deadline.job)
          (lte u.delivery-deadline.job overall-deadline.job)
      ==
  ==
++  remember
  |=  [id=digest:ms completed=(list digest:ms)]
  ^-  (list digest:ms)
  (scag max-completed `(list digest:ms)`[id completed])
++  current-valid
  |=  saved=current-state:mse
  ^-  ?
  ?~  binding.saved  =(0 ~(wyt by jobs.saved))
  ?.  (binding-valid u.binding.saved)  %.n
  %+  levy  ~(tap by jobs.saved)
  |=  [key=@t value=job:mse]
  ^-  ?
  =/  task=(unit task-request:mse)  (decode-task request.value)
  ?~  task  %.y
  ?.  (selected-task u.task)  %.y
  ?&  =(key (request-id request.value))
      (selection-matches u.binding.saved u.task)
      (job-valid value)
      =(`intent.u.task (model-bridge-request-prompt:mb bridge-request.value))
      =(context-commitment.bridge-request.value (scot %ux digest.request.value))
  ==
--
