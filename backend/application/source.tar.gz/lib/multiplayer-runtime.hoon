::  /lib/multiplayer-runtime
::
::  Pure transition law for the Urbit-native multiplayer authority receiver.
::
/-  mch=multiplayer-cockpit-http, mcr=multiplayer-cockpit-review,
    md=multiplayer-dispute, ml=multiplayer-landing, mp=multiplayer-project,
    me=multiplayer-evidence, mpo=multiplayer-portability, mr=multiplayer-receipt,
    mrp=multiplayer-reputation, mrt=multiplayer-runtime,
    ms=multiplayer-seat
/+  mchl=multiplayer-cockpit-http, mdl=multiplayer-dispute,
    mcrl=multiplayer-cockpit-review, mpl=multiplayer-project,
    mprl=multiplayer-project-role,
    mpol=multiplayer-portability, mrl=multiplayer-receipt,
    msl=multiplayer-seat
|%
++  initial-state  ^-(state:mrt [%multiplayer-runtime-v7 ~ ~ ~ ~ ~ ~ ~ ~ ~])
++  max-projects               128
++  max-catalog-projects       128
++  max-landings               512
++  max-reviewers-per-project  32
++  max-judgments-per-project  256
++  max-inspections-per-review  256
++  max-rows-per-review        256
++  ingress-window-duration    ~m1
++  max-ingress-sources        64
++  max-ingress-per-window     128
++  low-priority-limit         96
++  max-transfers              128
++  migrate-1
  |=  old=state-1:mrt
  ^-  state-2:mrt
  =/  projects=(map project-id:mp project-state:mrt)
    %-  ~(run by projects.old)
    |=  project=project-state-1:mrt
    [authority.project law-digest.project reviewers.project judgments.project ~]
  [%multiplayer-runtime-v2 projects rulings.old]
++  migrate-2-to-3
  |=  old=state-2:mrt
  ^-  state-3:mrt
  [%multiplayer-runtime-v3 projects.old rulings.old ~ ~ ~]
++  migrate-3-to-4
  |=  old=state-3:mrt
  ^-  state-4:mrt
  [%multiplayer-runtime-v4 projects.old rulings.old catalog.old active.old landings.old ~]
++  migrate-4-to-5
  |=  old=state-4:mrt
  ^-  state-5:mrt
  [%multiplayer-runtime-v5 projects.old rulings.old catalog.old active.old landings.old ingress.old ~]
++  migrate-5-to-6
  |=  old=state-5:mrt
  ^-  state-6:mrt
  [%multiplayer-runtime-v6 projects.old rulings.old catalog.old active.old landings.old ingress.old seats.old ~]
++  migrate-6
  |=  old=state-6:mrt
  ^-  state:mrt
  [%multiplayer-runtime-v7 projects.old rulings.old catalog.old active.old landings.old ingress.old seats.old transfers.old ~]
++  migrate-5
  |=  old=state-5:mrt
  ^-  state:mrt
  (migrate-6 (migrate-5-to-6 old))
++  migrate-4
  |=  old=state-4:mrt
  ^-  state:mrt
  (migrate-5 (migrate-4-to-5 old))
++  migrate-3
  |=  old=state-3:mrt
  ^-  state:mrt
  (migrate-4 (migrate-3-to-4 old))
++  migrate-2
  |=  old=state-2:mrt
  ^-  state:mrt
  (migrate-3 (migrate-2-to-3 old))
++  migrate
  |=  old=state-1:mrt
  ^-  state:mrt
  (migrate-2 (migrate-1 old))
++  ingress-priority
  |=  action=action:mrt
  ^-  ingress-priority:mrt
  ?+  -.action  %normal
    %publish-review  %low
  ==
++  ingress-window-active
  |=  [window=ingress-window:mrt now=@da]
  ^-  ?
  ?|  (lth now started-at.window)
      (lth now (add started-at.window ingress-window-duration))
  ==
++  prune-ingress
  |=  [ingress=(map @p ingress-window:mrt) now=@da]
  ^-  (map @p ingress-window:mrt)
  =/  rows=(list [@p ingress-window:mrt])  ~(tap by ingress)
  =/  kept=(map @p ingress-window:mrt)  ~
  |-
  ?~  rows  kept
  =/  row=[@p ingress-window:mrt]  i.rows
  =/  next=(map @p ingress-window:mrt)
    ?:  (ingress-window-active +.row now)
      (~(put by kept) -.row +.row)
    kept
  $(rows t.rows, kept next)
++  admit
  |=  [state=state:mrt source=@p now=@da action=action:mrt]
  ^-  admission:mrt
  =/  cleaned=(map @p ingress-window:mrt)
    (prune-ingress ingress.state now)
  =/  base=state:mrt  state(ingress cleaned)
  =/  found=(unit ingress-window:mrt)  (~(get by cleaned) source)
  =/  source-new=?  ?=(~ found)
  ?:  ?&  source-new
          (gte ~(wyt by cleaned) max-ingress-sources)
      ==
    [base `[%ingress-source-capacity ~(wyt by cleaned) max-ingress-sources]]
  =/  window=ingress-window:mrt
    ?~  found
      [now 0]
    u.found
  =/  priority=ingress-priority:mrt  (ingress-priority action)
  ?:  ?&  =(%low priority)
          (gte accepted.window low-priority-limit)
      ==
    [base `[%ingress-shed source accepted.window low-priority-limit]]
  ?:  (gte accepted.window max-ingress-per-window)
    [base `[%ingress-rate-limited source started-at.window accepted.window max-ingress-per-window]]
  =/  next=ingress-window:mrt  window(accepted +(accepted.window))
  [base(ingress (~(put by cleaned) source next)) ~]
++  digest-action
  |=  action=action:mrt
  ^-  digest:mrt
  `@ux`(shax (jam action))
++  project-for
  |=  [state=state:mrt action=action:mrt]
  ^-  (unit project-id:mp)
  ?-  -.action
    %configure           `project.action
    %publish-review      `project.action
    %submit              `project.body.act.action
    %open                `project.action
    %install-catalog     `id.spec.item.action
    %invite-member       `project.action
    %decline-invitation  `project.action
    %revoke-invitation   `project.action
    %expire-invitation   `project.action
    %join                `project.action
    %record-evidence     `project.action
    %leave               `project.action
    %remove-member       `project.action
    %switch              `project.action
    %land                `project.action
    %assign-seats        `project.action
    %renew-seat          `project.action
    %authority-offer     `project.action
    %authority-stage     `project.body.checkpoint.action
    %authority-finalize
      =/  found=(unit transfer:mpo)
        (~(get by transfers.state) checkpoint.action)
      ?~(found ~ `project.body.point.u.found)
    %authority-activate
      =/  found=(unit transfer:mpo)
        (~(get by transfers.state) checkpoint.action)
      ?~(found ~ `project.body.point.u.found)
    %authority-rollback
      =/  found=(unit transfer:mpo)
        (~(get by transfers.state) checkpoint.action)
      ?~(found ~ `project.body.point.u.found)
  ==
++  outcome-for
  |=  code=code:mrt
  ^-  outcome-kind:mrp
  ?+  code  %accepted
    %review-published        %contested
    %review-replayed         %durable
    %ruled                   %contested
    %changeset-landed        %built
    %seat-renewed            %durable
    %authority-rolled-back   %reverted
  ==
++  role-for
  |=  code=code:mrt
  ^-  @tas
  ?+  code  %contributor
    %configured              %authority
    %project-opened          %authority
    %catalog-installed       %authority
    %seats-assigned          %authority
    %authority-offered       %authority
    %authority-staged        %authority
    %authority-finalized     %authority
    %authority-activated     %authority
    %authority-rolled-back   %authority
    %review-published        %reviewer
    %review-replayed         %reviewer
    %ruled                   %reviewer
  ==
++  record-receipt
  |=  $:  state=state:mrt
          project=project-id:mp
          host=@p
          source=@p
          now=@da
          action=action:mrt
          result=result:mrt
      ==
  ^-  receipt-recording:mrt
  =/  key=[project-id:mp @p]  [project host]
  =/  found=(unit chain:mr)  (~(get by chains.state) key)
  =/  opened=(unit chain:mr)
    ?~  found
      (init:mrl project host)
    found
  ?~  opened  [state `[%invalid-chain ~]]
  =/  chain=chain:mr  u.opened
  =/  source-head=(unit source-head:mr)
    (~(get by source-heads.chain) source)
  =/  source-sequence=@ud
    ?~(source-head 1 +(sequence.u.source-head))
  =/  action-digest=digest:mrt  (digest-action action)
  =/  kind=@tas
    ?-  -.result
      %|  %refused
      %&
        ?+  -.action  code.p.result
          %record-evidence  kind.action
        ==
    ==
  =/  payload=*
    ?-  -.result
      %|  [%refused action-digest p.result]
      %&
        ?+  -.action
          :*  %multiplayer-verified-outcome-v1
              source
              (role-for code.p.result)
              %noun
              code.p.result
              (outcome-for code.p.result)
              action-digest
          ==
          %record-evidence
          =/  attestation=attestation:me
            :*  %multiplayer-adoption-attestation-v1
                project
                source
                kind.action
                evidence.action
            ==
          attestation
        ==
    ==
  =/  item=event:mr
    %:  make-live:mrl
      project
      host
      +(count.chain)
      head.chain
      source
      source-sequence
      kind
      [source ~ ~]
      payload
      now
      ~
    ==
  =/  appended=result:mr  (append:mrl chain item now)
  ?-  -.appended
    %|  [state `p.appended]
    %&  [state(chains (~(put by chains.state) key p.appended)) ~]
  ==
++  process
  |=  [state=state:mrt host=@p source=@p now=@da action=action:mrt]
  ^-  handled:mrt
  =/  admitted=admission:mrt  (admit state source now action)
  ?^  refusal.admitted
    =/  result=result:mrt  [%| u.refusal.admitted]
    =/  project=(unit project-id:mp)  (project-for state.admitted action)
    ?~  project  [state.admitted result]
    =/  recorded=receipt-recording:mrt
      (record-receipt state.admitted u.project host source now action result)
    ?^  refusal.recorded
      [state.admitted [%| [%receipt-chain-refused u.project u.refusal.recorded]]]
    [state.recorded result]
  =/  result=result:mrt  (apply state.admitted host source now action)
  =/  project=(unit project-id:mp)  (project-for state.admitted action)
  ?~  project
    ^-  handled:mrt
    ?-  -.result
      %|  [state.admitted result]
      %&  [state.p.result result]
    ==
  =/  candidate=state:mrt
    ?-  -.result
      %|  state.admitted
      %&  state.p.result
    ==
  =/  recorded=receipt-recording:mrt
    (record-receipt candidate u.project host source now action result)
  ?^  refusal.recorded
    [state.admitted [%| [%receipt-chain-refused u.project u.refusal.recorded]]]
  ?-  -.result
    %|  [state.recorded result]
    %&
      =/  accepted=outcome:mrt  p.result
      =/  updated=outcome:mrt  accepted(state state.recorded)
      [state.recorded [%& updated]]
  ==
++  judgments-valid
  |=  [project=project-id:mp judgments=(list judgment-source:mcr)]
  ^-  ?
  ?~  judgments  %.y
  =/  item=judgment-source:mcr  i.judgments
  =/  contradiction=contradiction:md  contradiction.item
  =/  contest=contest:md  contest.item
  ?.  ?&  (contradiction-valid:mdl contradiction)
          (contest-valid:mdl contest)
          =(project project.body.contradiction)
          =(project project.body.contest)
          ?|  =(changeset.body.contest left.body.contradiction)
              =(changeset.body.contest right.body.contradiction)
          ==
          ?=(~ ruling.item)
      ==
    %.n
  $(judgments t.judgments)
++  configuration-valid
  |=  [project=project-id:mp law=@ux reviewers=(list @p) judgments=(list judgment-source:mcr)]
  ^-  ?
  ?.  ?&  !=(0 project)
          !=(0 law)
          ?=(^ reviewers)
          ?=(^ judgments)
      ==
    %.n
  =/  reviewer-set=(set @p)  (silt reviewers)
  ?.  =((lent reviewers) ~(wyt in reviewer-set))  %.n
  ?&  ?=(~ (duplicate-judgment:mcrl judgments))
      (judgments-valid project judgments)
  ==
++  judgments-map
  |=  judgments=(list judgment-source:mcr)
  ^-  (map @ux judgment-source:mcr)
  =/  out=(map @ux judgment-source:mcr)  ~
  |-
  ?~  judgments  out
  $(judgments t.judgments, out (~(put by out) digest.contest.i.judgments i.judgments))
++  controls-valid
  |=  $:  project=project-id:mp
          actor=@p
          row=judgment-row:mcr
          controls=(list decision-control:mcr)
      ==
  ^-  ?
  ?~  controls  %.y
  =/  act=decision-act:mcr  act.i.controls
  ?.  ?&  (decision-act-valid:mcrl act)
          =(project project.body.act)
          =(changeset.row changeset.body.act)
          =(contradiction.row contradiction.body.act)
          =(contest.row contest.body.act)
          =(actor actor.body.act)
      ==
    %.n
  $(controls t.controls)
++  row-valid
  |=  $:  project=project-id:mp
          configured=project-state:mrt
          actor=@p
          row=judgment-row:mcr
      ==
  ^-  ?
  ?.  =(project project.row)  %.n
  =/  item=(unit judgment-source:mcr)
    (~(get by judgments.configured) contest.row)
  ?~  item  %.n
  =/  contradiction=contradiction:md  contradiction.u.item
  =/  contest=contest:md  contest.u.item
  ?&  =(changeset.row changeset.body.contest)
      =(contradiction.row digest.contradiction)
      =(contest.row digest.contest)
      =(ruling.row ruling.u.item)
      =((derive-verdict:mdl contradiction contest) suggested.row)
      (controls-valid project actor row controls.row)
  ==
++  rows-valid
  |=  $:  project=project-id:mp
          configured=project-state:mrt
          actor=@p
          rows=(list judgment-row:mcr)
      ==
  ^-  ?
  ?~  rows  %.y
  ?.  (row-valid project configured actor i.rows)  %.n
  $(rows t.rows)
++  inspections-valid
  |=  [project=project-id:mp rows=(list changeset-inspection:mcr)]
  ^-  ?
  ?~  rows  %.y
  ?.  =(project project.i.rows)  %.n
  $(rows t.rows)
++  review-valid
  |=  $:  project=project-id:mp
          configured=project-state:mrt
          source=@p
          review=snapshot:mcr
      ==
  ^-  ?
  =/  rendered=result:mch  (render:mchl review)
  ?.  ?=(%& -.rendered)  %.n
  =/  actor=@p  actor.cockpit.review
  ?&  =(source actor)
      (~(has in reviewers.configured) actor)
      (inspections-valid project inspections.review)
      (rows-valid project configured actor requires-you.review)
      (rows-valid project configured actor resolved.review)
  ==
++  without-contest
  |=  [contest=@ux rows=(list judgment-row:mcr)]
  ^-  (list judgment-row:mcr)
  ?~  rows  ~
  ?:  =(contest contest.i.rows)  $(rows t.rows)
  [i.rows $(rows t.rows)]
++  resolve-review
  |=  [review=snapshot:mcr item=judgment-source:mcr]
  ^-  snapshot:mcr
  =/  actor=@p  actor.cockpit.review
  =/  row=judgment-row:mcr
    (judgment-row-for:mcrl item actor %.y)
  review(requires-you (without-contest digest.contest.item requires-you.review), resolved [row resolved.review])
++  replay-review
  |=  [state=state:mrt configured=project-state:mrt incoming=snapshot:mcr]
  ^-  (unit result:mrt)
  ?~  review.configured  ~
  ?:  =(u.review.configured incoming)
    `[%& [state %review-replayed ~]]
  =/  current=@da  observed-at.cockpit.u.review.configured
  =/  incoming-at=@da  observed-at.cockpit.incoming
  ?:  (gte current incoming-at)
    `[%| [%stale-review current incoming-at]]
  ~
++  final-landing-valid
  |=  plan=landing:ml
  ^-  ?
  =/  paths=(list path)  (weld land.plan skip.plan)
  ?&  !=(0 changeset.plan)
      ?=(^ land.plan)
      ?=(~ retain.plan)
      =(accounted.plan (lent paths))
      =((lent paths) ~(wyt in (silt paths)))
  ==
++  install-landing
  |=  [state=state:mrt candidate=landing-candidate:mrt]
  ^-  result:mrt
  =/  changeset=@ux  changeset.plan.candidate
  ?.  (final-landing-valid plan.candidate)
    [%| [%invalid-landing changeset]]
  ?:  (~(has by landings.state) changeset)
    [%| [%landing-replayed changeset]]
  =/  count=@ud  ~(wyt by landings.state)
  ?:  (gte count max-landings)
    [%| [%capacity-exceeded %landings +(count) max-landings]]
  =/  item=landing-state:mrt  [candidate ~ ~]
  =/  next=state:mrt
    state(landings (~(put by landings.state) changeset item))
  [%& [next %catalog-installed ~]]
++  catalog-member
  |=  [project=project:mp actor=@p]
  ^-  ?
  ?=(^ (role-for:mpl project actor))
++  external-evidence-kind
  |=  kind=evidence-kind:me
  ^-  ?
  ?|(=(%outside-acceptance kind) =(%independent-operation kind))
++  duplicate-seat
  |=  assignments=(list seat-assignment:mrt)
  ^-  (unit @tas)
  =/  seen=(set @tas)  ~
  |-
  ?~  assignments  ~
  ?:  (~(has in seen) seat.i.assignments)  `seat.i.assignments
  $(assignments t.assignments, seen (~(put in seen) seat.i.assignments))
++  duplicate-holder
  |=  assignments=(list seat-assignment:mrt)
  ^-  (unit @p)
  =/  seen=(set @p)  ~
  |-
  ?~  assignments  ~
  ?:  (~(has in seen) holder.i.assignments)  `holder.i.assignments
  $(assignments t.assignments, seen (~(put in seen) holder.i.assignments))
++  grant-seat-assignments
  |=  $:  registry=registry:ms
          assignments=(list seat-assignment:mrt)
          actor=@p
          observed-at=@da
          expires-at=@da
      ==
  ^-  result:ms
  ?~  assignments  [%& registry]
  =/  granted=result:ms
    %+  grant-seat:msl  registry
    :*  actor
        seat.i.assignments
        holder.i.assignments
        observed-at
        expires-at
    ==
  ?-  -.granted
    %|  granted
    %&  $(registry p.granted, assignments t.assignments)
  ==
++  landings-for
  |=  [all=(map @ux landing-state:mrt) project=project-id:mp]
  ^-  (map @ux landing-state:mrt)
  =/  rows=(list [@ux landing-state:mrt])  ~(tap by all)
  =/  out=(map @ux landing-state:mrt)  ~
  |-
  ?~  rows  out
  =/  row=[@ux landing-state:mrt]  i.rows
  =/  next=(map @ux landing-state:mrt)
    ?:  =(project project.candidate.+.row)
      (~(put by out) -.row +.row)
    out
  $(rows t.rows, out next)
++  without-project-landings
  |=  [all=(map @ux landing-state:mrt) project=project-id:mp]
  ^-  (map @ux landing-state:mrt)
  =/  rows=(list [@ux landing-state:mrt])  ~(tap by all)
  =/  out=(map @ux landing-state:mrt)  ~
  |-
  ?~  rows  out
  =/  row=[@ux landing-state:mrt]  i.rows
  =/  next=(map @ux landing-state:mrt)
    ?:  !=(project project.candidate.+.row)
      (~(put by out) -.row +.row)
    out
  $(rows t.rows, out next)
++  merge-landings
  |=  [left=(map @ux landing-state:mrt) right=(map @ux landing-state:mrt)]
  ^-  (map @ux landing-state:mrt)
  =/  rows=(list [@ux landing-state:mrt])  ~(tap by right)
  |-
  ?~  rows  left
  $(rows t.rows, left (~(put by left) -.i.rows +.i.rows))
++  payload-for
  |=  [state=state:mrt project=project-id:mp]
  ^-  transfer-payload:mrt
  :*  %multiplayer-runtime-transfer-v1
      (~(get by projects.state) project)
      (landings-for landings.state project)
      (~(get by seats.state) project)
  ==
++  payload-valid
  |=  [payload=transfer-payload:mrt project=project-id:mp authority=@p]
  ^-  ?
  ?&  ?~(configured.payload %.y =(authority authority.u.configured.payload))
      %+  levy  ~(tap by landings.payload)
      |=  row=[@ux landing-state:mrt]
      =(project project.candidate.+.row)
      ?~  seats.payload
        %.y
      ?&  =(project project.u.seats.payload)
          =(authority authority.u.seats.payload)
          (registry-valid:msl u.seats.payload)
      ==
  ==
++  transfer-refused
  |=  reason=refusal:mpo
  ^-  result:mrt
  [%| [%authority-transfer-refused reason]]
++  apply
  |=  [state=state:mrt host=@p source=@p now=@da action=action:mrt]
  ^-  result:mrt
  ?-  -.action
    %configure
      ?.  =(host source)  [%| [%foreign-configurator host source]]
      ?:  (~(has by projects.state) project.action)
        [%| [%duplicate-project project.action]]
      =/  project-count=@ud  ~(wyt by projects.state)
      ?:  (gte project-count max-projects)
        [%| [%capacity-exceeded %projects +(project-count) max-projects]]
      =/  reviewer-count=@ud  (lent reviewers.action)
      ?:  (gth reviewer-count max-reviewers-per-project)
        [%| [%capacity-exceeded %reviewers reviewer-count max-reviewers-per-project]]
      =/  judgment-count=@ud  (lent judgments.action)
      ?:  (gth judgment-count max-judgments-per-project)
        [%| [%capacity-exceeded %judgments judgment-count max-judgments-per-project]]
      ?.  (configuration-valid project.action law-digest.action reviewers.action judgments.action)
        [%| [%invalid-configuration project.action]]
      =/  configured=project-state:mrt
        [host law-digest.action (silt reviewers.action) (judgments-map judgments.action) ~]
      =/  next=state:mrt
        state(projects (~(put by projects.state) project.action configured))
      [%& [next %configured ~]]
    %publish-review
      ?.  =(host source)  [%| [%foreign-configurator host source]]
      =/  configured=(unit project-state:mrt)
        (~(get by projects.state) project.action)
      ?~  configured  [%| [%project-missing project.action]]
      =/  inspection-count=@ud  (lent inspections.review.action)
      ?:  (gth inspection-count max-inspections-per-review)
        [%| [%capacity-exceeded %inspections inspection-count max-inspections-per-review]]
      =/  row-count=@ud
        (add (lent requires-you.review.action) (lent resolved.review.action))
      ?:  (gth row-count max-rows-per-review)
        [%| [%capacity-exceeded %review-rows row-count max-rows-per-review]]
      =/  replay=(unit result:mrt)
        (replay-review state u.configured review.action)
      ?^  replay  u.replay
      ?.  (review-valid project.action u.configured source review.action)
        [%| [%invalid-review project.action]]
      =/  next-project=project-state:mrt
        u.configured(review `review.action)
      =/  next=state:mrt
        state(projects (~(put by projects.state) project.action next-project))
      [%& [next %review-published ~]]
    %submit
      =/  act=decision-act:mcr  act.action
      ?.  (decision-act-valid:mcrl act)  [%| [%invalid-act digest.act]]
      ?.  =(source actor.body.act)
        [%| [%actor-mismatch actor.body.act source]]
      =/  project=(unit project-state:mrt)
        (~(get by projects.state) project.body.act)
      ?~  project  [%| [%project-missing project.body.act]]
      ?.  (~(has in reviewers.u.project) source)
        [%| [%reviewer-refused source]]
      =/  item=(unit judgment-source:mcr)
        (~(get by judgments.u.project) contest.body.act)
      ?~  item  [%| [%judgment-missing contest.body.act]]
      =/  contradiction=contradiction:md  contradiction.u.item
      =/  contest=contest:md  contest.u.item
      ?.  ?&  =(project.body.act project.body.contest)
              =(changeset.body.act changeset.body.contest)
              =(contradiction.body.act digest.contradiction)
              =(contest.body.act digest.contest)
          ==
        [%| [%coordinate-mismatch contest.body.act]]
      =/  expected=verdict:md  (derive-verdict:mdl contradiction contest)
      ?.  =(expected verdict.body.act)
        [%| [%verdict-mismatch expected verdict.body.act]]
      ?:  (~(has by rulings.state) digest.contest)
        [%| [%already-ruled digest.contest]]
      =/  ruling=ruling:md
        (decide:mdl contradiction contest law-digest.u.project now)
      =/  judged=judgment-source:mcr  u.item(ruling `ruling)
      =/  next-review=(unit snapshot:mcr)
        ?~  review.u.project  ~
        `(resolve-review u.review.u.project judged)
      =/  next-project=project-state:mrt
        u.project(judgments (~(put by judgments.u.project) digest.contest judged), review next-review)
      =/  next=state:mrt
        state(projects (~(put by projects.state) project.body.act next-project), rulings (~(put by rulings.state) digest.contest ruling))
      [%& [next %ruled `ruling]]
    %open
      ?.  =(host source)  [%| [%foreign-configurator host source]]
      ?:  (~(has by catalog.state) project.action)
        [%| [%catalog-project-duplicate project.action]]
      =/  count=@ud  ~(wyt by catalog.state)
      ?:  (gte count max-catalog-projects)
        [%| [%capacity-exceeded %catalog +(count) max-catalog-projects]]
      =/  spec=project-spec:mp
        :*  1
            project.action
            title.action
            source
            base-desk.action
            law-version.action
            law-digest.action
            now
        ==
      =/  opened=result:mp  (open:mpl spec source)
      ?-  -.opened
        %|  [%| [%project-law-refused project.action p.opened]]
        %&
          =/  next=state:mrt
            state(catalog (~(put by catalog.state) project.action p.opened), active `project.action)
          [%& [next %project-opened ~]]
      ==
    %install-catalog
      ?.  =(host source)  [%| [%foreign-configurator host source]]
      =/  project=project-id:mp  id.spec.item.action
      ?:  (~(has by catalog.state) project)
        [%| [%catalog-project-duplicate project]]
      ?.  (project-valid:mpl item.action)
        [%| [%invalid-catalog-project project]]
      =/  count=@ud  ~(wyt by catalog.state)
      ?:  (gte count max-catalog-projects)
        [%| [%capacity-exceeded %catalog +(count) max-catalog-projects]]
      =/  installed=state:mrt
        state(catalog (~(put by catalog.state) project item.action))
      ?~  landing.action
        [%& [installed %catalog-installed ~]]
      ?.  =(project project.u.landing.action)
        [%| [%landing-project-mismatch project project.u.landing.action]]
      (install-landing installed u.landing.action)
    %invite-member
      ::  Only the canonical project host may issue invitations. The actor's
      ::  actual ship and role are checked by the existing project law.
      ::  An invitation to an existing member at another role is the
      ::  operator's role offer (lib/multiplayer-project-role); the member's
      ::  %join of it applies the new role.
      =/  item=(unit project:mp)  (~(get by catalog.state) project.action)
      ?~  item  [%| [%catalog-project-missing project.action]]
      ?.  =(host authority.spec.u.item)
        [%| [%project-law-refused project.action [%foreign-authority authority.spec.u.item host]]]
      =/  invited=result:mp
        (invite:mprl u.item source target.action role.action now expires-at.action nonce.action)
      ?-  -.invited
        %|  [%| [%project-law-refused project.action p.invited]]
        %&
          =/  next=state:mrt
            state(catalog (~(put by catalog.state) project.action p.invited))
          [%& [next %project-invited ~]]
      ==
    ?(%decline-invitation %revoke-invitation %expire-invitation)
      =/  item=(unit project:mp)  (~(get by catalog.state) project.action)
      ?~  item  [%| [%catalog-project-missing project.action]]
      ?.  =(host authority.spec.u.item)
        [%| [%project-law-refused project.action [%foreign-authority authority.spec.u.item host]]]
      =/  resolved=result:mp
        ?-  -.action
          %decline-invitation  (decline:mpl u.item source invitation.action now)
          %revoke-invitation   (revoke:mpl u.item source invitation.action now)
          %expire-invitation   (expire:mpl u.item source invitation.action now)
        ==
      ?-  -.resolved
        %|  [%| [%project-law-refused project.action p.resolved]]
        %&
          =/  next=state:mrt
            state(catalog (~(put by catalog.state) project.action p.resolved))
          =/  code=code:mrt
            ?-  -.action
              %decline-invitation  %invitation-declined
              %revoke-invitation   %invitation-revoked
              %expire-invitation   %invitation-expired
            ==
          [%& [next code ~]]
      ==
    %join
      =/  item=(unit project:mp)  (~(get by catalog.state) project.action)
      ?~  item  [%| [%catalog-project-missing project.action]]
      ?.  =(host authority.spec.u.item)
        [%| [%project-law-refused project.action [%foreign-authority authority.spec.u.item host]]]
      =/  joined=result:mp
        (accept:mprl u.item source invitation.action now)
      ?-  -.joined
        %|  [%| [%project-law-refused project.action p.joined]]
        %&
          =/  next=state:mrt
            state(catalog (~(put by catalog.state) project.action p.joined))
          [%& [next %project-joined ~]]
      ==
    %record-evidence
      =/  item=(unit project:mp)  (~(get by catalog.state) project.action)
      ?~  item  [%| [%catalog-project-missing project.action]]
      ?.  (catalog-member u.item source)
        [%| [%project-law-refused project.action [%member-missing source]]]
      ?.  !=(0 evidence.action)
        [%| [%adoption-evidence-invalid kind.action evidence.action]]
      ?:  ?&  =(host source)
              (external-evidence-kind kind.action)
          ==
        [%| [%adoption-evidence-host-refused kind.action]]
      [%& [state %evidence-recorded ~]]
    %leave
      ::  The active project is this ship's own working context: only the
      ::  ship itself is held to it. A remote member may leave a project the
      ::  host happens to have active.
      ?:  &(=(host source) =(active.state `project.action))
        [%| [%active-project-cannot-leave project.action]]
      =/  item=(unit project:mp)  (~(get by catalog.state) project.action)
      ?~  item  [%| [%catalog-project-missing project.action]]
      =/  left=result:mp  (leave:mpl u.item source now)
      ?-  -.left
        %|  [%| [%project-law-refused project.action p.left]]
        %&
          =/  next=state:mrt
            state(catalog (~(put by catalog.state) project.action p.left))
          [%& [next %project-left ~]]
      ==
    %remove-member
      ::  Only the canonical project host removes a member; the project law
      ::  checks the actor's role and protects the authority ship.
      =/  item=(unit project:mp)  (~(get by catalog.state) project.action)
      ?~  item  [%| [%catalog-project-missing project.action]]
      ?.  =(host authority.spec.u.item)
        [%| [%project-law-refused project.action [%foreign-authority authority.spec.u.item host]]]
      =/  removed=result:mp  (remove:mpl u.item source target.action now)
      ?-  -.removed
        %|  [%| [%project-law-refused project.action p.removed]]
        %&
          =/  next=state:mrt
            state(catalog (~(put by catalog.state) project.action p.removed))
          [%& [next %project-left ~]]
      ==
    %switch
      =/  item=(unit project:mp)  (~(get by catalog.state) project.action)
      ?~  item  [%| [%catalog-project-missing project.action]]
      ?.  (catalog-member u.item source)
        [%| [%project-law-refused project.action [%member-missing source]]]
      [%& [state(active `project.action) %project-switched ~]]
    %land
      ?.  =(active.state `project.action)
        [%| [%active-project-mismatch project.action active.state]]
      =/  item=(unit project:mp)  (~(get by catalog.state) project.action)
      ?~  item  [%| [%catalog-project-missing project.action]]
      ?.  (catalog-member u.item source)
        [%| [%project-law-refused project.action [%member-missing source]]]
      =/  landing=(unit landing-state:mrt)
        (~(get by landings.state) changeset.action)
      ?~  landing  [%| [%landing-missing changeset.action]]
      ?.  =(project.action project.candidate.u.landing)
        [%| [%landing-project-mismatch project.action project.candidate.u.landing]]
      ?^  landed-by.u.landing  [%| [%landing-replayed changeset.action]]
      ?.  (final-landing-valid plan.candidate.u.landing)
        [%| [%invalid-landing changeset.action]]
      =/  landed=landing-state:mrt
        u.landing(landed-by `source, landed-at `now)
      =/  next=state:mrt
        state(landings (~(put by landings.state) changeset.action landed))
      [%& [next %changeset-landed ~]]
    %assign-seats
      ?.  =(host source)  [%| [%foreign-configurator host source]]
      =/  count=@ud  (lent assignments.action)
      ?.  ?|(=(2 count) =(3 count) =(9 count))
        [%| [%seat-count-invalid count]]
      ?:  (~(has by seats.state) project.action)
        [%| [%seat-registry-exists project.action]]
      =/  repeated-seat=(unit @tas)  (duplicate-seat assignments.action)
      ?^  repeated-seat  [%| [%duplicate-seat u.repeated-seat]]
      =/  repeated-holder=(unit @p)  (duplicate-holder assignments.action)
      ?^  repeated-holder  [%| [%duplicate-assigned-ship u.repeated-holder]]
      =/  item=(unit project:mp)  (~(get by catalog.state) project.action)
      ?~  item  [%| [%catalog-project-missing project.action]]
      ?.  =(host authority.spec.u.item)
        [%| [%foreign-configurator authority.spec.u.item host]]
      =/  registry=(unit registry:ms)  (init:msl u.item)
      ?~  registry
        [%| [%seat-law-refused project.action [%invalid-project ~]]]
      =/  assigned=result:ms
        (grant-seat-assignments u.registry assignments.action host now expires-at.action)
      ?-  -.assigned
        %|  [%| [%seat-law-refused project.action p.assigned]]
        %&
          =/  next=state:mrt
            state(seats (~(put by seats.state) project.action p.assigned))
          [%& [next %seats-assigned ~]]
      ==
    %renew-seat
      =/  registry=(unit registry:ms)
        (~(get by seats.state) project.action)
      ?~  registry
        [%| [%seat-registry-missing project.action]]
      =/  renewed=result:ms
        (renew:msl u.registry source seat.action now expires-at.action)
      ?-  -.renewed
        %|  [%| [%seat-law-refused project.action p.renewed]]
        %&
          =/  next=state:mrt
            state(seats (~(put by seats.state) project.action p.renewed))
          [%& [next %seat-renewed ~]]
      ==
    %authority-offer
      =/  project=project-id:mp  project.action
      =/  item=(unit project:mp)  (~(get by catalog.state) project)
      ?~  item  [%| [%catalog-project-missing project]]
      =/  transfer-count=@ud  ~(wyt by transfers.state)
      ?:  (gte transfer-count max-transfers)
        [%| [%capacity-exceeded %transfers +(transfer-count) max-transfers]]
      =/  payload=transfer-payload:mrt  (payload-for state project)
      ?.  (payload-valid payload project host)
        [%| [%authority-payload-invalid 0x0]]
      =/  offered=result:mpo
        %:  offer:mpol
          u.item
          bundle.action
          payload
          host
          source
          to.action
          now
          expires-at.action
          nonce.action
        ==
      ?-  -.offered
        %|  (transfer-refused p.offered)
        %&
          =/  transfer=transfer:mpo  p.offered
          =/  key=@ux  digest.point.transfer
          ?:  (~(has by transfers.state) key)
            [%| [%authority-transfer-exists key]]
          =/  next=state:mrt
            %=  state
              projects   (~(del by projects.state) project)
              catalog    (~(del by catalog.state) project)
              active     ?:(=(active.state `project) ~ active.state)
              landings   (without-project-landings landings.state project)
              seats      (~(del by seats.state) project)
              transfers  (~(put by transfers.state) key transfer)
            ==
          [%& [next %authority-offered ~]]
      ==
    %authority-stage
      =/  checkpoint=checkpoint:mpo  checkpoint.action
      =/  key=@ux  digest.checkpoint
      ?:  (~(has by transfers.state) key)
        [%| [%authority-transfer-exists key]]
      =/  project=project-id:mp  project.body.checkpoint
      ?:  (~(has by catalog.state) project)
        [%| [%authority-project-busy project]]
      =/  payload=(unit transfer-payload:mrt)
        ((soft transfer-payload:mrt) payload.body.checkpoint)
      ?~  payload  [%| [%authority-payload-invalid key]]
      ?.  (payload-valid u.payload project from.body.checkpoint)
        [%| [%authority-payload-invalid key]]
      =/  offered=transfer:mpo  [checkpoint %offered ~ ~ ~]
      =/  staged=result:mpo  (stage:mpol offered host source now)
      ?-  -.staged
        %|  (transfer-refused p.staged)
        %&
          =/  next=state:mrt
            state(transfers (~(put by transfers.state) key p.staged))
          [%& [next %authority-staged ~]]
      ==
    %authority-finalize
      =/  key=@ux  checkpoint.action
      =/  found=(unit transfer:mpo)  (~(get by transfers.state) key)
      ?~  found  [%| [%authority-transfer-missing key]]
      =/  finalized=result:mpo
        (finalize:mpol u.found acceptance.action host source now)
      ?-  -.finalized
        %|  (transfer-refused p.finalized)
        %&
          =/  next=state:mrt
            state(transfers (~(put by transfers.state) key p.finalized))
          [%& [next %authority-finalized ~]]
      ==
    %authority-activate
      =/  key=@ux  checkpoint.action
      =/  found=(unit transfer:mpo)  (~(get by transfers.state) key)
      ?~  found  [%| [%authority-transfer-missing key]]
      =/  activated=result:mpo
        (activate:mpol u.found finalization.action host source now)
      ?-  -.activated
        %|  (transfer-refused p.activated)
        %&
          =/  transfer=transfer:mpo  p.activated
          =/  checkpoint=checkpoint:mpo  point.transfer
          =/  project=project-id:mp  project.body.checkpoint
          ?:  (~(has by catalog.state) project)
            [%| [%authority-project-busy project]]
          =/  payload=(unit transfer-payload:mrt)
            ((soft transfer-payload:mrt) payload.body.checkpoint)
          ?~  payload  [%| [%authority-payload-invalid key]]
          ?.  (payload-valid u.payload project from.body.checkpoint)
            [%| [%authority-payload-invalid key]]
          =/  rehomed=(unit project:mp)
            (rehome:mpol archived.body.checkpoint host offered-at.body.checkpoint)
          ?~  rehomed  [%| [%authority-payload-invalid key]]
          =/  next-projects=(map project-id:mp project-state:mrt)
            ?~  configured.u.payload
              projects.state
            (~(put by projects.state) project u.configured.u.payload(authority host))
          =/  next=state:mrt
            %=  state
              projects   next-projects
              catalog    (~(put by catalog.state) project u.rehomed)
              active     `project
              landings   (merge-landings landings.state landings.u.payload)
              transfers  (~(put by transfers.state) key transfer)
            ==
          [%& [next %authority-activated ~]]
      ==
    %authority-rollback
      =/  key=@ux  checkpoint.action
      =/  found=(unit transfer:mpo)  (~(get by transfers.state) key)
      ?~  found  [%| [%authority-transfer-missing key]]
      =/  rolled=result:mpo  (rollback:mpol u.found host source now)
      ?-  -.rolled
        %|  (transfer-refused p.rolled)
        %&
          =/  transfer=transfer:mpo  p.rolled
          =/  checkpoint=checkpoint:mpo  point.transfer
          =/  project=project-id:mp  project.body.checkpoint
          ?:  (~(has by catalog.state) project)
            [%| [%authority-project-busy project]]
          =/  payload=(unit transfer-payload:mrt)
            ((soft transfer-payload:mrt) payload.body.checkpoint)
          ?~  payload  [%| [%authority-payload-invalid key]]
          ?.  (payload-valid u.payload project host)
            [%| [%authority-payload-invalid key]]
          =/  next-projects=(map project-id:mp project-state:mrt)
            ?~  configured.u.payload
              projects.state
            (~(put by projects.state) project u.configured.u.payload)
          =/  next-seats=(map project-id:mp registry:ms)
            ?~  seats.u.payload
              seats.state
            (~(put by seats.state) project u.seats.u.payload)
          =/  next=state:mrt
            %=  state
              projects   next-projects
              catalog    (~(put by catalog.state) project archived.body.checkpoint)
              active     `project
              landings   (merge-landings landings.state landings.u.payload)
              seats      next-seats
              transfers  (~(put by transfers.state) key transfer)
            ==
          [%& [next %authority-rolled-back ~]]
      ==
  ==
--
