::  Native Cantrip integration. Current app state and Gall bowl are the only
::  authority inputs; returned cards and journals commit in the SAME event.
/-  pa=cantrip-project-access, mp=multiplayer-project,
    mc=multiplayer-changeset, view=cantrip-project-view
/+  core=cantrip-project-access, read=cantrip-project-access-read,
    changes=multiplayer-changeset, model=pataphor-editor-model,
    law=cantrip-law-window
|%
+$  transition  [grants=grants:pa records=records:pa cards=(list card:agent:gall)]
++  request-valid
  |=  r=request:pa
  ^-  ?
  ?&  !=(0 project.r)  (lte (met 3 project.r) 128)
      (gth generation.r 0)  (lte (met 0 generation.r) 64)
      !=(0 nonce.r)  (lte (met 0 nonce.r) 128)
      |(=(%view action.r) =(%suggest action.r))
  ==
++  route
  |=  [peer=@p r=request:pa]
  ^-  path
  /project-access/(scot %ux project.r)/(scot %p peer)/(scot %ud generation.r)/[action.r]/(scot %ux nonce.r)
++  parse
  |=  path=path
  ^-  (unit [peer=@p request=request:pa])
  ?.  ?=([%project-access @ @ @ @ @ ~] path)  ~
  =/  project  (slaw %ux i.t.path)
  =/  peer  (slaw %p i.t.t.path)
  =/  generation  (slaw %ud i.t.t.t.path)
  =/  nonce  (slaw %ux i.t.t.t.t.t.path)
  ?~  project  ~
  ?~  peer  ~
  ?~  generation  ~
  ?~  nonce  ~
  =/  r=request:pa
    [`@t`u.project u.generation u.nonce i.t.t.t.t.path ~ ~ `@t`0]
  ?.  &((request-valid r) =(path (route u.peer r)))  ~
  `[u.peer r]
++  receipt-valid
  |=  r=receipt:pa
  ^-  ?
  =/  q=request:pa  request.r
  ?.  &((request-valid q) !=(0 at.r) !=(0 grant.r) (lte (met 0 grant.r) 256))  %.n
  ?-  -.payload.r
    %view
      =/  b=basis:pa  basis.payload.r
      ?&  =(%view action.q)  ?=(~ parent.q)  ?=(~ pax.q)  =(0 source.q)
          (basis-valid:core b)  =(owner.r owner.b)  =(at.r at.b)
          =(project.q project.body.snapshot.b)
      ==
    %suggest
      ?~  parent.q  %.n
      =/  p=parent:pa  parent.payload.r
      =/  c=change:mc  change.payload.r
      ?&  =(%suggest action.q)  =(u.parent.q p)  !=(0 root.p)
          (snapshot-valid:changes snapshot.p)
          =(project.q project.body.snapshot.p)
          (paths-valid:core ~(key by files.body.snapshot.p))
          =(source.q source.payload.r)  (text-valid:model source.q)
          (lte (met 3 source.q) 32.768)
          =(%modify kind.c)  =(pax.q path.c)
          (change-valid:changes files.body.snapshot.p c)
          =(after.c `(shax source.q))
      ==
  ==
++  valid
  |=  [our=@p grants=grants:pa records=records:pa]
  ^-  ?
  ?.  &((lte ~(wyt by grants) record-limit:core) (lte ~(wyt by records) 64))  %.n
  ?.  %+  levy  ~(tap by grants)
      |=  [key=[project-id:mp @p] entry=entry:pa]
      &((grant-valid:core grant.entry) =(our owner.grant.entry) =(key [project.grant.entry peer.grant.entry]))
    %.n
  %+  levy  ~(tap by records)
  |=  [key=[project-id:mp @p @ud @ux] r=receipt:pa]
  =/  g  (~(get by grants) [project.request.r peer.r])
  ?~  g  %.n
  ?&  (receipt-valid r)  =(our owner.r)
      =(key [project.request.r peer.r generation.request.r nonce.request.r])
      (lte generation.request.r generation.grant.u.g)
      ?|  (lth generation.request.r generation.grant.u.g)
          =((digest:core grant.u.g) grant.r)
      ==
  ==
++  preflight
  ::  Reject ungranted, foreign, malformed or expired requests before scries.
  |=  [b=bowl:gall grants=grants:pa r=request:pa]
  ^-  (each grant:pa @tas)
  ?.  (request-valid r)  [%| %request-invalid]
  =/  found  (~(get by grants) [project.r src.b])
  ?~  found  [%| %grant-missing]
  =/  g=grant:pa  grant.u.found
  ?.  &((grant-valid:core g) =(our.b owner.g) =(src.b peer.g))  [%| %grant-invalid]
  ?:  revoked.u.found  [%| %grant-revoked]
  ?.  =(generation.r generation.g)  [%| %generation-conflict]
  ?.  (time-valid:core g now.b)  [%| %grant-expired]
  ?.  ?:(=(%view action.r) view.permissions.g suggest.permissions.g)
    [%| %permission-refused]
  [%& g]
++  subscribed
  |=  [b=bowl:gall r=request:pa]
  ^-  ?
  =/  wanted=path  (route src.b r)
  %+  lien  ~(val by sup.b)
  |=  [peer=@p path=path]
  &(=(peer src.b) =(path wanted))
++  kicks
  ::  Existing Gall subscriptions are sufficient; no duplicate watcher state.
  |=  [b=bowl:gall key=(unit [project-id:mp @p])]
  ^-  (list card:agent:gall)
  =/  paths=(set path)
    %-  silt
    %+  murn  ~(val by sup.b)
    |=  [peer=@p pax=path]
    ^-  (unit path)
    =/  parsed  (parse pax)
    ?~  parsed  ~
    ?.  =(peer peer.u.parsed)  ~
    ?^  key
      ?.  =(u.key [project.request.u.parsed peer])  ~
      `pax
    `pax
  %+  turn  ~(tap in paths)
  |=  path=path
  `card:agent:gall`[%give %kick ~[path] ~]
++  admit-watch
  ::  Shared current authority gate; no receipt lookup or insertion.
  |=  [b=bowl:gall grants=grants:pa r=request:pa w=window:law]
  ^-  (each grant:pa @tas)
  =/  initial  (preflight b grants r)
  ?:  ?=(%| -.initial)  [%| p.initial]
  =/  p  (catalog:read our.b our.b now.b project.r)
  ?:  ?=(%| -.p)  [%| p.p]
  =/  current  (scope:read our.b our.b now.b p.p p.initial)
  (authorize-scoped:core our.b src.b now.b p.p grants r w current)
++  watch
  |=  [b=bowl:gall grants=grants:pa path=path w=window:law]
  ^-  (each (list card:agent:gall) @tas)
  =/  parsed  (parse path)
  ?~  parsed  [%| %path-invalid]
  ?.  =(src.b peer.u.parsed)  [%| %foreign-peer]
  =/  checked  (admit-watch b grants request.u.parsed w)
  ?:  ?=(%| -.checked)  [%| p.checked]
  =/  event=event:pa  [%cantrip-project-ready-v1 our.b src.b (digest:core p.checked)]
  [%& ~[[%give %fact ~ %noun !>(event)]]]
++  view-request
  |=  q=query:view
  ^-  request:pa
  [project.q generation.q nonce.q %view ~ ~ `@t`0]
++  view-route
  |=  [peer=@p q=query:view]
  ^-  path
  /project-view/(scot %ux project.q)/(scot %p peer)/(scot %ud generation.q)/(scot %ux nonce.q)
++  view-parse
  |=  path=path
  ^-  (unit [peer=@p query=query:view])
  ?.  &(?=([%project-view @ @ @ @ ~] path) (lte (met 3 (jam path)) 4.096))  ~
  =/  project  (slaw %ux i.t.path)
  =/  peer  (slaw %p i.t.t.path)
  =/  generation  (slaw %ud i.t.t.t.path)
  =/  nonce  (slaw %ux i.t.t.t.t.path)
  ?~  project  ~
  ?~  peer  ~
  ?~  generation  ~
  ?~  nonce  ~
  =/  q=query:view  [`@t`u.project u.generation u.nonce]
  ?.  ?&  (lte (met 0 u.peer) 128)
          (request-valid (view-request q))
          =(path (view-route u.peer q))
      ==  ~
  `[u.peer q]
++  view-valid
  |=  r=response:view
  ^-  ?
  ?&  (lte (met 0 owner.r) 128)  (lte (met 0 peer.r) 128)
      (receipt-valid [owner.r peer.r at.basis.r grant.r (view-request query.r) [%view basis.r]])
  ==
++  view-cards
  ::  Exact admitted path only; completion closes the subscription.
  |=  [path=path r=response:view]
  ^-  (list card:agent:gall)
  ?>  (view-valid r)
  ?>  =(path (view-route peer.r query.r))
  :~  [%give %fact ~[path] %noun !>(`event:view`[%cantrip-project-view-v1 r])]
      [%give %kick ~[path] ~]
  ==
++  watch-view
  ::  Every watch observes NOW, even with a reused nonce. No journal access.
  |=  [b=bowl:gall grants=grants:pa path=path w=window:law]
  ^-  (each (list card:agent:gall) @tas)
  =/  parsed  (view-parse path)
  ?~  parsed  [%| %path-invalid]
  ?.  =(src.b peer.u.parsed)  [%| %foreign-peer]
  =/  q=query:view  query.u.parsed
  =/  checked  (admit-watch b grants (view-request q) w)
  ?:  ?=(%| -.checked)  [%| p.checked]
  =/  observed  (basis:read our.b our.b now.b p.checked)
  ?:  ?=(%| -.observed)  [%| p.observed]
  =/  r=response:view  [our.b src.b q (digest:core p.checked) p.observed]
  [%& (view-cards path r)]
++  act
  |=  [b=bowl:gall grants=grants:pa records=records:pa action=action:pa w=window:law]
  ^-  (each transition @tas)
  ?.  (valid our.b grants records)  [%| %journal-invalid]
  ?-  -.action
    %cantrip-project-grant-v1
      ?.  =(our.b src.b)  [%| %foreign-owner]
      =/  g=grant:pa  grant.action
      ?.  (grant-valid:core g)  [%| %grant-invalid]
      =/  p  (catalog:read our.b our.b now.b project.g)
      ?:  ?=(%| -.p)  [%| p.p]
      =/  current  (scope:read our.b our.b now.b p.p g)
      =/  granted  (issue-scoped:core our.b src.b now.b p.p grants g current)
      ?:  ?=(%| -.granted)  [%| p.granted]
      =/  cards=(list card:agent:gall)
        ?:(=(grants p.granted) ~ (kicks b `[project.g peer.g]))
      [%& [p.granted records cards]]
    %cantrip-project-revoke-v1
      =/  key=[project-id:mp @p]  [project.action peer.action]
      =/  revoked  (revoke:core our.b src.b grants key generation.action)
      ?:  ?=(%| -.revoked)  [%| p.revoked]
      [%& [p.revoked records (kicks b `key)]]
    %cantrip-project-request-v1
      =/  r=request:pa  request.action
      =/  initial  (preflight b grants r)
      ?:  ?=(%| -.initial)  [%| p.initial]
      ?.  (subscribed b r)  [%| %watch-required]
      =/  prepared  (prepare:read our.b our.b src.b now.b grants records r w)
      ?:  ?=(%| -.prepared)  [%| p.prepared]
      =/  event=event:pa  [%cantrip-project-receipt-v1 receipt.p.prepared]
      =/  cards=(list card:agent:gall)
        ~[[%give %fact ~[(route src.b r)] %noun !>(event)]]
      [%& [grants next.p.prepared cards]]
  ==
--
