::  Pure judgment of unchanged work through an actual delegated Boxy match.
::  Inputs must be freshly read from Viki/Cantrip/Boxy by the owning runtime.
::  This validates their joins, not their origin, and never makes an owner
::  decision or grants an effect. Revalidate completion before applying it.
/-  bx=boxy, jm=juggler-match, protocol=native-coding-completion-review
/+  review=native-coding-completion-review-request,
    admission=cantrip-native-completion-review, kernel=native-coding-completion,
    boxy=boxy-law, match=boxy-match, juggler=juggler-match,
    candidate=native-coding-judgment, cr=codex-responses
|%
+$  proof
  $:  %native-coding-completion-review-proof-v1
      proposal=@ux
      campaign=@ux
      scope=@ux
      workspace=@t
      head=@ux
      projection=@ux
      target=@ud
      admissions=(list @ux)
  ==
+$  outcome
  $%  [%complete proof=proof]
      [%negative proof=proof move=@ud reason=@t]
  ==
++  joined
  ::  Check just this move's unique retained admission, not unrelated history.
  ::  A matching law string alone is never an admission receipt.
  |=  [our=@p packet=packet:review scope=scope:protocol workspace=workspace-state:bx move=move:jm ledger=ledger:admission]
  ^-  (each [campaign=@ux identity=@ux] @tas)
  ?.  &(accepted.admission.move =(law:review law.admission.move))
    [%| %completion-review-mixed-admission-law]
  =/  rows=(list [key:admission retained:admission])
    %+  skim  ~(tap by ledger)
    |=  [key=key:admission row=retained:admission]
    =(proposal-id.contribution.move proposal-id.admission.verdict.row)
  ?.  =(1 (lent rows))  [%| %completion-review-admission-missing-or-ambiguous]
  =/  [k=key:admission r=retained:admission]  (snag 0 rows)
  ?.  (row-valid:admission our k r)  [%| %completion-review-admission-invalid]
  =/  c=context:protocol  context.r
  =/  reviewer=config:review  (config:admission c)
  ?.  ?&  =(scope scope.c)  =(packet packet.request.c)
          =(admission.move admission.verdict.r)  =(actor.move worker.c)
          =(contribution.result.c `contribution.move)
          =(human.move (label:review worker.c model.selection.reviewer))
          =(id.workspace id.queued.r)
          =(law-digest.workspace law-digest.queued.r)
          =(membership-epoch.workspace membership-epoch.queued.r)
          =(members.workspace members.queued.r)
          (lte (lent events.queued.r) (lent events.workspace))
      ==  [%| %completion-review-admission-context-mismatch]
  ?.  =(events.queued.r (slag (sub (lent events.workspace) (lent events.queued.r)) events.workspace))
    [%| %completion-review-queue-not-in-history]
  [%& [campaign.c (identity:admission c)]]
++  evaluate
  |=  [our=@p packet=packet:review scope=scope:protocol workspace=workspace-state:bx admissions=ledger:admission]
  ^-  (each outcome @tas)
  ?.  &((packet-valid:review our packet) enabled.scope =(project.scope project.proposal.packet) !=(ship.left.scope ship.right.scope) (config-valid:review ship.left.scope config.left.scope) (config-valid:review ship.right.scope config.right.scope) =(our parent.config.left.scope) =(our parent.config.right.scope))
    [%| %completion-review-scope-or-packet-invalid]
  ?.  &((lte (met 3 (jam workspace)) request-limit:review) (lte ~(wyt by admissions) capacity:admission) (event-chain-valid:boxy workspace) =(event-seq.workspace (lent events.workspace)) ?=(^ head.workspace) ?=(^ events.workspace))
    [%| %completion-review-history-incomplete-or-large]
  =/  projected  (project-workspace:match workspace)
  =/  m=match-state:jm  match.projected
  ?.  &(=(0 refused.projected) ?=(^ config.m) ?=(~ pending.m))
    [%| %completion-review-awaiting-settlement]
  =/  config=match-config:jm  u.config.m
  ?.  ?&  =(our host.config)
          =(id.workspace match-id.config)
          =(objective.proposal.packet objective.config)
          =(ship.left.scope ship.left.config)
          =(ship.right.scope ship.right.config)
          =((label:review ship.left.scope model.selection.config.left.scope) human.left.config)
          =((label:review ship.right.scope model.selection.config.right.scope) human.right.config)
          (has-capability:boxy workspace ship.left.scope %publish)
          (has-capability:boxy workspace ship.right.scope %publish)
          ?=(^ moves.m)
          (lte (lent `(list move:jm)`moves.m) 256)
      ==  [%| %completion-review-match-mismatch]
  =/  moves=(list move:jm)  moves.m
  =/  targets=(list move:jm)
    (skim moves |=(v=move:jm ?=(%propose kind.contribution.v)))
  ?~  targets  [%| %completion-review-target-missing-or-ambiguous]
  ?.  ?=(~ t.targets)  [%| %completion-review-target-missing-or-ambiguous]
  =/  target=move:jm  i.targets
  =/  bound=@t
    (cat 3 'native-coding-completion:' (scot %ux (digest:kernel proposal.packet)))
  ?.  =(bound body.contribution.target)  [%| %completion-review-target-mismatch]
  =/  rows=(list move:jm)  moves
  =/  campaign=(unit @ux)  ~
  =/  identities=(list @ux)  ~
  |-  ^-  (each outcome @tas)
  =/  rest=(list move:jm)  rows
  ?^  rest
    =/  checked  (joined our packet scope workspace i.rest admissions)
    ?:  ?=(%| -.checked)  [%| p.checked]
    ?.  ?~(campaign %.y =(u.campaign campaign.p.checked))
      [%| %completion-review-campaign-mismatch]
    ?:  (lien identities |=(id=@ux =(id identity.p.checked)))
      [%| %completion-review-admission-reused]
    $(rows t.rest, campaign `campaign.p.checked, identities [identity.p.checked identities])
  ?~  campaign  [%| %completion-review-admission-missing]
  =/  p=proof
    [%native-coding-completion-review-proof-v1 (digest:kernel proposal.packet) u.campaign (digest:review scope) id.workspace u.head.workspace (digest:review m) id.target (flop identities)]
  =/  negatives=(list move:jm)
    (skim moves |=(v=move:jm &(?=(%refuse kind.contribution.v) =(target.contribution.v `id.target))))
  ?^  negatives
    ::  This is an admitted semantic refusal, not a provider/transport error.
    =/  refused=move:jm  i.negatives
    =/  parsed  (de:json:html body.contribution.refused)
    ?~  parsed  [%| %completion-review-refusal-reason-invalid]
    =/  reason  (string:cr u.parsed 'reason')
    ?~  reason  [%| %completion-review-refusal-reason-invalid]
    ?.  (text-valid:kernel u.reason 4.096)
      [%| %completion-review-refusal-reason-invalid]
    [%& [%negative p id.refused u.reason]]
  ?.  &(=(%closed status.m) ?=(^ closure.m) =(target.u.closure.m id.target) =(artifact.u.closure.m bound) (challenged:candidate m target) (dual-accept:juggler m id.target))
    [%| %completion-review-awaiting-resolution]
  =/  closes=(list move:jm)
    (skim moves |=(v=move:jm &(?=(%close kind.contribution.v) =(target.contribution.v `id.target) =(artifact.contribution.v `bound))))
  ?.  =(1 (lent closes))  [%| %completion-review-closure-mismatch]
  [%& [%complete p]]
--
