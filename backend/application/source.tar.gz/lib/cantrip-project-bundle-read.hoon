::  Canonical owner-side inputs for the common scalar/bundle transport.
::  No card, archive append, project edit or app migration is performed.
/-  pa=cantrip-project-access, j=cantrip-project-suggestion-journal,
    mp=multiplayer-project, nc=native-coding
/+  access=cantrip-project-access, runtime=cantrip-project-access-runtime,
    read=cantrip-project-access-read, journal=cantrip-project-suggestion-journal,
    archive=cantrip-project-receipt-archive, law=cantrip-law-window,
    names=native-coding-provider, guard=viki-scry-guard
|%
+$  authority  [project=project:mp scope=(unit project:nc)]
+$  observation
  [authority=authority basis=basis:pa cold=observed:j]
++  beam
  |=  [our=@p h=head:archive pax=path]
  ^-  path
  (weld ~[(scot %p our) desk.h (scot %ud number.h)] pax)
++  private
  |=  [our=@p at=@da desk=@tas pax=path]
  ^-  ?
  =/  rules=[r=dict:clay w=dict:clay]
    .^([r=dict:clay w=dict:clay] %cp (weld ~[(scot %p our) desk (scot %da at)] pax))
  &(=([%white ~ ~] rul.r.rules) =([%white ~ ~] rul.w.rules))
++  current-head
  |=  [our=@p at=@da h=head:archive]
  ^-  ?
  ?.  ?&  (name-valid:names desk.h)  !=(%base desk.h)
          (gth number.h 0)  !=(0 commit.h)  (lte (met 0 commit.h) 256)
      ==  %.n
  =/  domes=cone:clay  .^(cone:clay %cx /(scot %p our)//(scot %da at)/domes)
  =/  found  (~(get by domes) [our desk.h])
  ?~  found  %.n
  =/  d=dome:clay  u.found
  ?&  =(%dead liv.d)  =(~ ren.d)  =(~ wic.d)
      =(number.h let.d)  =(`commit.h (~(get by hit.d) number.h))
      (private our at desk.h /)
      (private our at desk.h /project-access-history)
  ==
++  noun-at
  ::  The caller has established this exact current numbered private head.
  |=  [our=@p h=head:archive pax=path]
  ^-  raw:archive
  =/  node=arch  .^(arch %cy (beam our h pax))
  ?~  fil.node  [%& ~]
  [%& `.^(* %cx (beam our h pax))]
++  join
  ::  Pure decode seam. Both indices and the complete raw noun stay exact.
  |=  [our=@p actor=@p k=key:j index=raw:archive body=raw:archive]
  ^-  observed:j
  =/  pointer  (decode-pointer:archive our actor k index)
  ?:  ?=(%| -.pointer)  [%| p.pointer]
  ?~  p.pointer
    ?:  ?=(%| -.body)  [%| p.body]
    ?~  p.body  [%& ~]
    [%| %receipt-archive-index-missing]
  =/  got  (shared-decode:archive our actor hash.u.p.pointer body)
  (shared-join:archive our actor k pointer got)
++  cold
  ::  History must be app-owned, never supplied by the peer command. An absent
  ::  observation is unknown. A known never-configured state can mean no cold
  ::  history only after its native saved-DATA migration has established that
  ::  provenance; this library cannot fabricate it or reset a configured head.
  |=  [our=@p actor=@p at=@da history=(unit shared-state:archive) grants=grants:pa records=journal:j k=key:j]
  ^-  observed:j
  ?.  =(our actor)  [%| %receipt-archive-owner-required]
  ?~  history  [%| %receipt-history-unobserved]
  =/  s=shared-state:archive  u.history
  ?.  (shared-valid:archive our s grants records)  [%| %receipt-archive-state-invalid]
  ?^  writing.s  [%| %receipt-archive-pending]
  ?~  head.s  [%& ~]
  =/  h=head:archive  u.head.s
  ?.  (current-head our at h)  [%| %receipt-archive-head-unavailable]
  =/  index-path=path  (nonce-path:archive k)
  ?.  (private our at desk.h index-path)  [%| %receipt-archive-not-private]
  =/  index=raw:archive  (noun-at our h index-path)
  =/  pointer  (decode-pointer:archive our actor k index)
  ?:  ?=(%| -.pointer)  [%| p.pointer]
  ?~  p.pointer  (join our actor k index [%& ~])
  =/  pax=path  (path-for:archive hash.u.p.pointer)
  ?.  (private our at desk.h pax)  [%| %receipt-archive-not-private]
  (join our actor k index (noun-at our h pax))
++  authorize
  ::  The actual Gall sender selects the grant. Canonical catalog and working
  ::  scope are read as the local owner, then the existing law admits the peer.
  |=  [b=bowl:gall grants=grants:pa q=request:pa w=window:law]
  ^-  (each authority @tas)
  =/  initial  (preflight:runtime b grants q)
  ?:  ?=(%| -.initial)  [%| p.initial]
  ?.  (agent-live:guard our.b now.b %multiplayer-runtime)  [%| %project-catalog-unavailable]
  =/  p  (catalog:read our.b our.b now.b project.q)
  ?:  ?=(%| -.p)  [%| p.p]
  =/  scoped=(unit project:nc)  (scope:read our.b our.b now.b p.p p.initial)
  =/  admitted  (authorize-scoped:access our.b src.b now.b p.p grants q w scoped)
  ?:  ?=(%| -.admitted)  [%| p.admitted]
  [%& [p.p scoped]]
++  observe
  |=  [b=bowl:gall grants=grants:pa records=journal:j r=request:j history=(unit shared-state:archive) w=window:law]
  ^-  (each observation @tas)
  =/  q=request:pa  (envelope:journal r)
  =/  allowed  (authorize b grants q w)
  ?:  ?=(%| -.allowed)  [%| p.allowed]
  =/  g  (~(get by grants) [project.q src.b])
  ?~  g  [%| %grant-missing]
  =/  bnow  (basis:read our.b our.b now.b grant.u.g)
  ?:  ?=(%| -.bnow)  [%| p.bnow]
  =/  saved
    (cold our.b our.b now.b history grants records [project.q src.b generation.q nonce.q])
  [%& [p.allowed p.bnow saved]]
--
