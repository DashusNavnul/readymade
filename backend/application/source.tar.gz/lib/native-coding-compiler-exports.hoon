::  General selected-export compilation; no editor-specific source/name pins.
::  Existing assembly seed binds the exact compiler witnesses and executable.
::  Caller prepares the job canonically; this pure layer proves only joins.
/-  nc=native-coding
/+  compiler=native-coding-compiler, assembly=native-coding-terminal-assembly,
    decoder=native-coding-compiler-artifact, project=native-coding-project,
    modules=native-coding-module-sources,
    vm=native-coding-terminal-plan, scalar=terminal-plan,
    profile=native-coding-compiler-profile
|%
+$  selection  [project=project:nc target=build-target:nc names=(list @t)]
+$  artifact
  [%native-coding-compiler-exports-v1 job=@ux seed=@ux selection=@ux profile=@ux bindings=(list binding:decoder) remaining=@ud digest=@ux unchecked=%unchecked]
+$  result  (each artifact refusal:decoder)
++  byte-limit  2.097.152
++  selection-id
  |=  s=selection
  ^-  @ux
  (shax (jam [%native-coding-compiler-export-selection-v1 s]))
++  selection-valid
  |=  s=selection
  ^-  ?
  ?&  (valid:project project.s)  =(%gallowglass kind.target.s)
      =(~[target.s] (skim targets.project.s |=(t=build-target:nc =(name.t name.target.s))))
      (gte (lent names.s) 1)  (lte (lent names.s) 8)
      =((lent names.s) ~(wyt in (silt names.s)))
      (levy names.s name-valid:decoder)
  ==
++  inputs
  |=  [j=job:compiler s=selection]
  ^-  (each (list mapped:modules) @tas)
  =/  p=project:nc  (job-project:compiler j)
  =/  r=tool-request:nc  (job-request:compiler j)
  =/  tgt=build-target:nc  (job-target:compiler j)
  =/  mod=@t  (job-module:compiler j)
  =/  srcs=(list source:compiler)  (job-sources:compiler j)
  =/  c=context:nc  context.r
  ?.  &((selection-valid s) =(project.s p) =(target.s tgt) ?=(?(%compile %check) -.arguments.r) (linked-input-valid:compiler j))
    [%| %compiler-export-job-invalid]
  ?.  ?&  =(id.spec.p project.c)  =(configuration.c (configuration:project p))
          =(actor.c authority.spec.p)  =(owner.source.c authority.spec.p)
          (revision-valid:project source.c)
          |(=(working.p desk.source.c) =(base-desk.spec.p desk.source.c))
          !=(0 session.c)  !=(0 request.c)
          (lte (met 0 session.c) 256)  (lte (met 0 request.c) 256)
          !=(0 call-id.r)  (lte (met 3 call-id.r) 128)
      ==
    [%| %compiler-export-context-invalid]
  ?>  ?=(?(%compile %check) -.arguments.r)
  ?.  =(target.arguments.r name.tgt)  [%| %compiler-export-target-mismatch]
  =/  closure  (dependencies:compiler p tgt)
  ?:  ?=(%| -.closure)  [%| p.closure]
  ?.  =(p.closure (turn srcs |=(v=source:compiler pax.v)))
    [%| %compiler-export-closure-mismatch]
  ?.  (sources-valid:modules p srcs)
    [%| %compiler-export-source-invalid]
  =/  prefix=@t  (cat 3 mod '.')
  ?.  (levy names.s |=(name=@t &(=(prefix (end [3 (met 3 prefix)] name)) (gth (met 3 name) (met 3 prefix)))))
    [%| %compiler-export-root-required]
  (named-sources:compiler j)
++  digest
  |=  a=artifact
  ^-  @ux
  (shax (jam a(digest 0x0)))
++  supported
  ::  Retention repeats the decoder's shared expanded-node/depth/pin limits;
  ::  a structurally valid opaque numeric pin is not a supported primitive.
  |=  bindings=(list binding:decoder)
  ^-  ?
  =/  todo=(list [value=plan:vm depth=@ud])
    (turn bindings |=(b=binding:decoder [artifact.b 1]))
  =/  remaining=@ud  node-cap:decoder
  |-  ^-  ?
  ?~  todo  %.y
  ?.  &(!=(0 remaining) (lte depth.i.todo depth-cap:decoder))  %.n
  =/  p=plan:vm  value.i.todo
  =/  depth=@ud  +(depth.i.todo)
  =/  rest=(list [value=plan:vm depth=@ud])  t.todo
  =/  left=@ud  (dec remaining)
  ?-  -.p
    %nat  &((lte (met 0 value.p) 4.096) $(todo rest, remaining left))
    %app  $(todo [[fun.p depth] [arg.p depth] rest], remaining left)
    %pin
      ?.  ?:(?=(%nat -.item.p) |((lte value.item.p 4) ?=(?(%10 %11 %12) value.item.p)) %.y)  %.n
      $(todo [[item.p depth] rest], remaining left)
    %law
      ?.  &(=(%nat -.name.p) (gte arity.p 1) (lte arity.p 32))  %.n
      $(todo [[name.p depth] [body.p depth] rest], remaining left)
    %delay  %.n
  ==
++  artifact-valid
  |=  [j=job:compiler s=selection seed=@ux fuel=@ud a=artifact]
  ^-  ?
  ?&  (selection-valid s)  =((identity:compiler j) job.a)  =(seed seed.a)
      =((selection-id s) selection.a)  =(profile.a identity:profile)
      =(names.s (turn bindings.a |=(b=binding:decoder name.b)))
      (lte remaining.a fuel)  (lte (met 3 (jam a)) byte-limit)
      =(%unchecked unchecked.a)  =(digest.a (digest a))
      (supported bindings.a)
      (levy bindings.a |=(b=binding:decoder (artifact-valid:scalar artifact.b)))
  ==
++  wanted
  |=  names=(list @t)
  ^-  plan:vm
  =/  todo=(list @t)  (flop names)
  =/  out=plan:vm  [%nat 0]
  |-  ^-  plan:vm
  =/  rest=(list @t)  todo
  ?~  rest  out
  $(todo t.rest, out [%app [%app [%nat 1] (encode:compiler i.rest)] out])
++  attempt
  |=  [seed=seed:assembly j=job:compiler s=selection fuel=@ud]
  ^-  result
  ?.  &((seed-valid:assembly seed) (profiled-seed:assembly seed))
    [%| %compiler-export-seed-invalid 0 '' '']
  =/  sources  (inputs j s)
  ?:  ?=(%| -.sources)  [%| p.sources 0 '' '']
  =/  ran
    (run-profile:vm fuel entry.seed ~[(encode:compiler (job-module:compiler j)) (wanted names.s) (encode-sources:compiler p.sources)])
  ?:  ?=(%| -.ran)  [%| p.ran 0 '' '']
  =/  decoded  (decode:decoder output.p.ran names.s)
  ?:  ?=(%| -.decoded)  [%| p.decoded]
  =/  a=artifact
    [%native-coding-compiler-exports-v1 (identity:compiler j) digest.seed (selection-id s) identity:profile p.decoded remaining.p.ran 0x0 %unchecked]
  =.  a  a(digest (digest a))
  ?.  (artifact-valid j s digest.seed fuel a)
    [%| %compiler-export-artifact-invalid 0 '' '']
  [%& a]
++  invoke
  |=  [seed=seed:assembly j=job:compiler s=selection fuel=@ud]
  ^-  result
  =/  tried  (mole |.((attempt seed j s fuel)))
  ?~  tried  [%| %compiler-export-unconfirmed 0 '' '']
  u.tried
--
