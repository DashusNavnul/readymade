::  Native collection and measurement owner. A stream is session-local unless
::  pooled: then sessions share it one at a time, each continuing the last.
::  Enrollment and ordered history persist before a separate dispatch.
/-  nc=native-coding
/+  admission=qpc-measurement-admission, sensing=qpc-task-sensing,
    contract=qpc-instrument-contract, read-contract=qpc-instrument-read-contract,
    obs=qpc-observation, observer=qpc-observer, q=qpc-native-outcome,
    outcomes=qpc-outcome-store, settlement=qpc-work-settlement,
    sessions=native-coding-session,
    legacy=qpc-observation-stream, source=qpc-instrument-source,
    project=native-coding-project, history=qpc-instrument-history,
    pool=qpc-native-pool, recurring=qpc-successor-history,
    successor=qpc-successor-window, selected-history=qpc-selected-history,
    selected-measurement=qpc-selected-measurement,
    selected-reader=qpc-selected-measurement-read,
    review=qpc-native-review-state, acceptance=native-coding-accept
|%
+$  plan  plan:read-contract
+$  ticket  ticket:read-contract
+$  record  record:read-contract
+$  binding  binding:read-contract
+$  law-context  law-context:read-contract
+$  laws  laws:read-contract
+$  state  state:read-contract
+$  stores
  [observed=state:obs checked=state:outcomes settled=state:settlement required=(set @ux) legacy=state:legacy]
+$  reserve-command
  [%qpc-selected-reserve-v1 member=@ux law=@ux work=work:obs]
+$  reader
  $-([our=@p at=@da p=project:nc revision=revision:nc artifact=path cases=cases:q] (each receipt:source @tas))
+$  snapshot
  $:  %qpc-instrument-snapshot-v1  status=?(%collecting %unavailable)
      epoch=%unavailable  window=%unavailable  width=@ud
      reference-required=@ud  live-required=@ud  samples=@ud  gaps=@ud
      outside=@ud  pending=@ud  plans=(map @ux record)
  ==
++  snapshot-of
  |=  s=state
  ^-  snapshot
  :*  %qpc-instrument-snapshot-v1
      ?:((lien ~(val by plans.s) |=(r=record &(active.r ?=(~ reason.r)))) %collecting %unavailable)
      %unavailable  %unavailable  16  17  17  ~(wyt by samples.admitted.s)
      (lent (skim ~(val by events.s) |=(r=result:obs ?:(?=(%& -.r) !=(1 (lent p.r)) ?=(%| -.r)))))
      (lent (skim ~(val by events.s) |=(r=result:obs ?=(%outside -.r))))
      (lent (skim ~(val by plans.s) |=(r=record ?=(^ awaiting.r))))  plans.s
  ==
++  raw  raw:contract
++  stores-read
  |=  [inner=agent:gall b=bowl:gall]
  ^-  (unit stores)
  =/  a  (raw inner b /x/qpc/observations)
  =/  c  (raw inner b /x/qpc/outcome-state)
  =/  s  (raw inner b /x/qpc/settlements)
  =/  r  (raw inner b /x/qpc/required-sessions)
  =/  l  (raw inner b /x/qpc/streams)
  ?~  a  ~
  ?~  c  ~
  ?~  s  ~
  ?~  r  ~
  ?~  l  ~
  =/  aa  ((soft state:obs) u.a)
  =/  cc  ((soft state:outcomes) u.c)
  =/  ss  ((soft state:settlement) u.s)
  =/  rr  ((soft ,[%qpc-session-gate-v1 %viki ids=(set @ux)]) u.r)
  =/  ll  ((soft state:legacy) u.l)
  ?~  aa  ~
  ?~  cc  ~
  ?~  ss  ~
  ?~  rr  ~
  ?~  ll  ~
  `[u.aa u.cc u.ss ids.u.rr u.ll]
++  project-read  project-read:read-contract
++  plan-valid  plan-valid:contract
++  successor-plan  successor-plan:read-contract
++  successor-binding
  |=  p=plan
  ^-  binding:successor
  [instrument.p stream.p (digest:obs manifest.p) %first-17-reference-successive-disjoint-17-live %qpc-ct-update-v1]
++  histories-valid
  ::  New policy membership cannot be loaded under a historical envelope or
  ::  attached to an existing v1 stream. Historical v1 plans stay untouched.
  |=  [held=state ordered=state:history next=state:recurring]
  ^-  ?
  ?&  %+  levy  ~(val by plans.held)
      |=  r=record
      ?.  (successor-plan plan.r)  !(~(has by windows.next) stream.plan.r)
      =/  w  (~(get by windows.next) stream.plan.r)
      ?~  w  %.n
      &(!(~(has by windows.ordered) stream.plan.r) =(binding.u.w (successor-binding plan.r)) =(manifest.u.w manifest.plan.r))
      %+  levy  ~(tap by windows.next)
      |=  [id=@ux w=state:successor]
      (lien ~(val by plans.held) |=(r=record &((successor-plan plan.r) =(stream.plan.r id))))
  ==
::  One binding per enrollment and one event per observed frame, both kept
::  forever; on-load asserts these, so they track the admission limits.
++  event-limit  4.096
++  plan-limit  256
++  valid
  |=  [our=@p s=state]
  ?&  (lte ~(wyt by plans.s) plan-limit)  (lte ~(wyt by bindings.s) enrollment-limit:admission)
      (lte ~(wyt by events.s) event-limit)  (lte ~(wyt by enrollments.admitted.s) enrollment-limit:admission)
      (lte ~(wyt by samples.admitted.s) sample-limit:admission)
      (pooled-valid ~(val by plans.s))
      (levy ~(tap by plans.s) |=([id=@ux r=record] &(=(id session.plan.r) (plan-valid our plan.r) (identifier:sensing segment.r) (lte (met 0 step.r) 64) ?~(ticket.r %.y &(active.r =(awaiting.r `enrollment.u.ticket.r))))))
      (levy ~(tap by enrollments.admitted.s) |=([id=@ux r=enrollment:admission] &(=(id id.r) =(our owner.r) (enrollment-valid:admission r) (~(has by bindings.s) id))))
      (levy ~(tap by samples.admitted.s) |=([id=@ux v=sample:admission] &(=(id id.frame.v) =(id.v (digest:admission v(id 0x0))) (row-valid:admission row.v))))
      %+  levy  ~(tap by bindings.s)
      |=  [id=@ux b=binding]
      =/  enrolled  (~(get by enrollments.admitted.s) id)
      ?~  enrolled  %.n
      &((valid:project project.b) =(project.u.enrolled (digest:admission project.b)) =(source.work.u.enrolled source.source.b) =(available-evidence.work.u.enrolled evidence.source.b))
  ==
++  pooled-valid
  ::  Plans may share a stream (a pool) only with one instrument, law and
  ::  manifest, and at most one of them active at a time.
  |=  rs=(list record)
  ^-  ?
  %+  levy  rs
  |=  r=record
  =/  mates=(list record)  (skim rs |=(o=record =(stream.plan.o stream.plan.r)))
  ?&  %+  levy  mates
      |=  o=record
      ?&  =(instrument.plan.o instrument.plan.r)  =(law.plan.o law.plan.r)
          =((digest:obs manifest.plan.o) (digest:obs manifest.plan.r))
      ==
      (lte (lent (skim mates |=(o=record active.o))) 1)
  ==
++  join
  ::  Admit a new plan onto an existing pooled stream. The latest member must
  ::  have finished (or been stopped, which already recorded its gap); nothing
  ::  of the stream may be pending. The newcomer continues its step and
  ::  segment, so a finished handover is not a gap. Members retire.
  |=  [held=state ordered=state:history p=plan finished=?]
  ^-  (each [r=record plans=(map @ux record)] @tas)
  =/  mates=(list record)  (skim ~(val by plans.held) |=(o=record =(stream.p stream.plan.o)))
  ?~  mates  [%| %pool-stream-missing]
  ?.  %+  levy  `(list record)`mates
      |=  o=record
      ?&  =(instrument.p instrument.plan.o)  =(law.p law.plan.o)
          =((digest:obs manifest.p) (digest:obs manifest.plan.o))
      ==
    [%| %pool-binding-mismatch]
  ?:  (lien `(list record)`mates |=(o=record |(?=(^ ticket.o) ?=(^ awaiting.o))))
    [%| %pool-member-busy]
  ?:  (lien (slag cursor.ordered queue.ordered) |=(x=item:history =(stream.p stream.x)))
    [%| %pool-stream-pending]
  =/  window  (~(get by windows.ordered) stream.p)
  ?~  window  [%| %pool-window-missing]
  ?.  =(binding.u.window [instrument.p stream.p (digest:obs manifest.p) %first-17-reference-next-disjoint-17-live %qpc-ct-update-v1])
    [%| %pool-window-mismatch]
  =/  last=record
    %+  roll  `(list record)`t.mates
    |=([o=record best=_i.mates] ?:((gth step.o step.best) o best))
  ?:  &(!finished (lien `(list record)`mates |=(o=record active.o)))
    [%| %pool-member-unfinished]
  =/  retired=(map @ux record)
    %+  roll  `(list record)`mates
    |=  [o=record m=_plans.held]
    (~(put by m) session.plan.o o(active %.n, reason ?:(active.o `%pool-handover reason.o)))
  [%& [[p %.y step.last segment.last ~ ~ ~] (~(put by retired) session.p [p %.y step.last segment.last ~ ~ ~])]]
++  continuity
  ::  A row may only continue an active segment from the source the previous
  ::  row produced; otherwise the window would fault. Read only when nothing of
  ::  the stream is pending, so the window is current.
  |=  [ordered=state:history stream=@ux source=revision:nc]
  ^-  ?
  ?:  (lien (slag cursor.ordered queue.ordered) |=(x=item:history =(stream stream.x)))  %.y
  =/  window  (~(get by windows.ordered) stream)
  ?~  window  %.y
  ?~  segment.u.window  %.y
  =(source.u.window `(digest:admission source))
++  join-successor
  |=  [held=state ordered=state:recurring p=plan finished=?]
  ^-  (each [r=record plans=(map @ux record)] @tas)
  =/  mates=(list record)  (skim ~(val by plans.held) |=(o=record =(stream.p stream.plan.o)))
  ?~  mates  [%| %pool-stream-missing]
  ?.  %+  levy  `(list record)`mates
      |=  o=record
      ?&  =(instrument.p instrument.plan.o)  =(law.p law.plan.o)
          =((digest:obs manifest.p) (digest:obs manifest.plan.o))
      ==
    [%| %pool-binding-mismatch]
  ?:  (lien `(list record)`mates |=(o=record |(?=(^ ticket.o) ?=(^ awaiting.o))))
    [%| %pool-member-busy]
  ?:  (pending:recurring ordered stream.p)  [%| %pool-stream-pending]
  =/  window  (~(get by windows.ordered) stream.p)
  ?~  window  [%| %pool-window-missing]
  ?.  =(binding.u.window (successor-binding p))  [%| %pool-window-mismatch]
  =/  last=record
    %+  roll  `(list record)`t.mates
    |=([o=record best=_i.mates] ?:((gth step.o step.best) o best))
  ?:  &(!finished (lien `(list record)`mates |=(o=record active.o)))
    [%| %pool-member-unfinished]
  =/  retired=(map @ux record)
    %+  roll  `(list record)`mates
    |=  [o=record m=_plans.held]
    (~(put by m) session.plan.o o(active %.n, reason ?:(active.o `%pool-handover reason.o)))
  ::  A selected settlement advances this same native window without changing
  ::  the historical ordinary member. Continue from the settled chronology,
  ::  retaining the member's next fresh segment only after an actual gap.
  =/  step=@ud  ordinal.u.window
  =/  segment=@ux  (fall segment.u.window segment.last)
  [%& [[p %.y step segment ~ ~ ~] (~(put by retired) session.p [p %.y step segment ~ ~ ~])]]
++  successor-continuity
  |=  [ordered=state:recurring stream=@ux source=revision:nc]
  ^-  ?
  ?:  (pending:recurring ordered stream)  %.y
  =/  window  (~(get by windows.ordered) stream)
  ?~  window  %.y
  ?~  segment.u.window  %.y
  =(source.u.window `(digest:admission source))
++  align-successor
  ::  Selected rows advance the shared chronology without rewriting an
  ::  ordinary member's history. Only its next prospective cursor moves.
  |=  [r=record ordered=state:recurring]
  ^-  (each record @tas)
  ?.  (successor-plan plan.r)  [%& r]
  ?^  fault.ordered  [%| u.fault.ordered]
  ?:  (pending:recurring ordered stream.plan.r)  [%| %pool-stream-pending]
  ?:  |(?=(^ awaiting.r) ?=(^ ticket.r))  [%| %pool-member-busy]
  =/  window  (~(get by windows.ordered) stream.plan.r)
  ?~  window  [%| %pool-window-missing]
  ?.  =(binding.u.window (successor-binding plan.r))  [%| %pool-window-mismatch]
  ?.  (gte ordinal.u.window step.r)  [%| %pool-member-ahead]
  [%& r(step ordinal.u.window, segment (fall segment.u.window segment.r))]
++  selected-handover
  ::  Private owner protocol: only an already consumed authentic selected
  ::  application retires its parked member. No session or history is edited.
  |=  [held=state ordered=state:recurring selected=state:selected-history member=@ux enrollment=@ux receipt=@ux]
  ^-  (each state @tas)
  ?.  (selected-valid held selected)  [%| %qpc-selected-binding-invalid]
  =/  row  (~(get by reservations.selected) enrollment)
  =/  done  (~(get by receipts.selected) enrollment)
  =/  found  (~(get by plans.held) member)
  ?~  row  [%| %qpc-selected-reservation-missing]
  ?~  done  [%| %qpc-selected-receipt-missing]
  ?~  found  [%| %qpc-selected-member-missing]
  ?.  &(=(member member.u.row) =(receipt id.u.done) =(%applied status.u.done))
    [%| %qpc-selected-handover-mismatch]
  ?.  (consumed:recurring ordered stream.position.enrollment.reservation.u.row enrollment)
    [%| %qpc-selected-settlement-pending]
  =/  aligned  (align-successor u.found ordered)
  ?:  ?=(%| -.aligned)  [%| p.aligned]
  [%& held(plans (~(put by plans.held) member p.aligned(active %.n, reason `%selected-task-applied)))]
++  successor-current
  ::  Read-only readiness is bound to actual current Clay, not a stored source
  ::  supplied by a command. Partial/unresolved history cannot return a reading.
  |=  [held=state ordered=state:recurring inner=agent:gall b=bowl:gall stream=@ux]
  ^-  (each reading:successor @tas)
  ?^  fault.ordered  [%| u.fault.ordered]
  ?:  (pending:recurring ordered stream)  [%| %qpc-successor-work-unresolved]
  =/  mates=(list record)  (skim ~(val by plans.held) |=(r=record =(stream stream.plan.r)))
  ?~  mates  [%| %qpc-successor-stream-missing]
  =/  active=(list record)  (skim `(list record)`mates |=(r=record active.r))
  =/  chosen=record
    ?^  active  i.active
    %+  roll  `(list record)`t.mates
    |=([r=record best=_i.mates] ?:((gth step.r step.best) r best))
  =/  config  (project-read inner b session.plan.chosen project.manifest.plan.chosen)
  ?:  ?=(%| -.config)  [%| p.config]
  =/  now  (current:project our.b now.b p.config)
  ?:  ?=(%| -.now)  [%| p.now]
  (current:recurring ordered stream (digest:admission revision.working.p.now))
++  laws-valid
  |=  [current=laws held=state]
  ?&  (lte ~(wyt by current) 64)
      %+  levy  ~(tap by current)
      |=  [session=@ux context=law-context]
      =/  r  (~(get by plans.held) session)
      ?~  r  %.n
      &(=(instrument.context instrument.plan.u.r) (identifier:sensing law.context))
  ==
++  self-card
  |=  [our=@p value=*]
  ^-  card:agent:gall
  [%pass /qpc/instrument %agent [our %viki] %poke %noun !>(value)]
++  ticket-wire
  |=  [id=@ux t=ticket]
  ^-  wire
  /qpc-instrument-wake/[(scot %ux id)]/[(scot %ux enrollment.t)]/[(scot %ux snapshot.t)]/[(scot %da due.t)]
++  wait-card
  |=  [id=@ux t=ticket]
  ^-  card:agent:gall
  [%pass (ticket-wire id t) %arvo %b %wait due.t]
++  unavailable
  |=  [s=state id=@ux reason=@tas]
  ^-  state
  =/  r=record  (~(got by plans.s) id)
  s(plans (~(put by plans.s) id r(reason `reason)))
++  boundary
  ::  Only canonical interruptions after this owner's consumed frames count.
  ::  The caller persists this prospective cursor only with enrollment.
  |=  [r=record e=entry:sessions observed=state:obs events=(map @ux result:obs)]
  ^-  record
  =/  after=@ud
    %+  roll  ~(val by frames.observed)
    |=  [f=frame:obs n=@ud]
    ?.  &(=(session.plan.r session.work.f) (~(has by events) id.f))  n
    (max n +(journal.f))
  ?.  (interrupted:obs after e)  r
  r(step +(step.r), segment (digest:admission [%interruption segment.r head.e]))
++  refused-call
  ::  A single prediction with no stored outcome whose call Cantrip finished
  ::  and refused can never be admitted. Returns that refusal's evidence.
  |=  [b=bowl:gall in=input:pool stores=stores f=frame:obs]
  ^-  (unit @ux)
  ?.  ?=(%& -.result.f)  ~
  ?.  =(1 (lent p.result.f))  ~
  =/  call=@t  call:(snag 0 p.result.f)
  ?:  (~(has by outcomes.checked.stores) [id.f call])  ~
  =/  m  (~(get by manifests.observed.stores) manifest.work.f)
  ?~  m  ~
  (refused:outcomes b in u.m f call)
++  reconcile
    |=  [held=state inner=agent:gall b=bowl:gall]
    ^-  state
    =/  stores  (stores-read inner b)
    ?~  stores  held
    =/  s=state  held
    =/  todo=(list [@ux record])  ~(tap by plans.s)
    |-  ^-  state
    ?~  todo  s
    =/  [id=@ux r=record]  i.todo
    ?~  awaiting.r  $(todo t.todo)
    =/  registration  (~(get by enrollments.admitted.s) u.awaiting.r)
    ?~  registration  $(todo t.todo)
    =/  e=enrollment:admission  u.registration
    =/  frames=(list frame:obs)
      (skim ~(val by frames.observed.u.stores) |=(f=frame:obs =(work.e work.f)))
    ?.  =(1 (lent frames))  $(todo t.todo)
    =/  f=frame:obs  (snag 0 frames)
    =/  next=record
      ?:  ?=(%outside -.result.f)  r(awaiting ~, reason ~)
      ?:  ?=(%| -.result.f)
        r(awaiting ~, step +(step.r), segment (digest:admission [%gap segment.r id.f]), reason `p.result.f)
      ?.  =(1 (lent p.result.f))
        r(awaiting ~, step +(step.r), segment (digest:admission [%alternatives segment.r id.f]), reason `%instrument-alternatives-refused)
      r
    =.  s  s(events (~(put by events.s) id.f result.f))
    ?^  awaiting.next
      =/  input  (input:observer inner b id)
      ?~  input  $(todo t.todo)
      =/  bound  (~(get by bindings.s) id.e)
      ?~  bound  $(todo t.todo)
      =/  got  (admit:admission admitted.s our.b id.e id.f observed.u.stores checked.u.stores settled.u.stores project.u.bound entry.u.input required.u.stores)
      ?:  ?=(%| -.got)
        =/  refusal  (refused-call b u.input u.stores f)
        ?~  refusal
          $(todo t.todo, s s(plans (~(put by plans.s) id r(reason `p.got))))
        ::  No candidate exists, so no outcome can ever arrive: release the
        ::  plan as a gap bound to Cantrip's refusal, never as a sample.
        =/  sealed=@ux  (digest:admission [%refused-call segment.r id.f u.refusal])
        $(todo t.todo, s s(plans (~(put by plans.s) id r(awaiting ~, step +(step.r), segment sealed, reason `%instrument-call-refused))))
      =.  s  s(admitted -.p.got)
      $(todo t.todo, s s(plans (~(put by plans.s) id r(awaiting ~, step +(step.r), reason ~))))
    $(todo t.todo, s s(plans (~(put by plans.s) id next)))
++  unsent
  ::  The enrollment precedes the dispatch, and the session can refuse that
  ::  dispatch (2026-11-01, `line-column`). Still ready on the enrolled request
  ::  with nothing pending, it was never sent: no frame can ever come, so a stop
  ::  treats it as a ticket that has not fired. A session terminally %unknown has
  ::  no outcome left to settle either (2026-11-01: a check past its deadline), and
  ::  the unknown stays recorded as a gap, never resent. Anything else stays retained.
  |=  [r=record e=entry:sessions session=@ux enrolled=(unit enrollment:admission)]
  ^-  (unit @ux)
  ?~  awaiting.r  ~
  ?^  ticket.r  ~
  ?~  enrolled  ~
  ?.  &(?=(~ pending.e) ?=(~ calls.e))  ~
  ?:  =(%unknown phase.e)  awaiting.r
  ?.  ?&  =(%ready phase.e)
          =(request.work.u.enrolled (request-id:sessions session turn.e))
      ==
    ~
  awaiting.r
++  agent
  |=  inner=agent:gall
  (wrap inner read:source)
++  refresh-history
  |=  [ordered=state:history held=state inner=agent:gall b=bowl:gall]
  ^-  state:history
  =/  stores  (stores-read inner b)
  ?~  stores  ordered
  =/  next  (advance:history ordered admitted.held observed.u.stores 512)
  ::  Dispatched work whose call Cantrip refused cannot settle. Its queued
  ::  slot becomes a gap bound to that refusal, then ordering resumes.
  ?:  |(?=(^ fault.next) =(cursor.next (lent queue.next)))  next
  =/  x=item:history  (snag cursor.next queue.next)
  ?.  ?=(%work -.body.x)  next
  =/  enrolled  (~(get by enrollments.admitted.held) enrollment.body.x)
  ?~  enrolled  next
  =/  frames=(list frame:obs)
    (skim ~(val by frames.observed.u.stores) |=(f=frame:obs =(work.u.enrolled work.f)))
  ?.  =(1 (lent frames))  next
  =/  input  (input:observer inner b session.work.u.enrolled)
  ?~  input  next
  =/  refusal  (refused-call b u.input u.stores (snag 0 frames))
  ?~  refusal  next
  =/  gap=interruption:history  [u.refusal %instrument-call-refused]
  (advance:history (cancel:history next enrollment.body.x gap) admitted.held observed.u.stores 512)
++  successor-refusals
  ::  Inspect each stream's first unresolved slot. Only an authenticated
  ::  refused ordinary call becomes a gap; unknown and selected work stay held.
  |=  [ordered=state:recurring reserved=(set @ux) held=state inner=agent:gall b=bowl:gall stores=stores]
  ^-  state:recurring
  =/  todo=(list item:recurring)  (heads:recurring ordered)
  |-  ^-  state:recurring
  ?~  todo  ordered
  =/  x=item:recurring  i.todo
  ?.  ?=(%work -.body.x)  $(todo t.todo)
  ?:  (~(has in reserved) enrollment.body.x)  $(todo t.todo)
  =/  enrolled  (~(get by enrollments.admitted.held) enrollment.body.x)
  ?~  enrolled  $(todo t.todo)
  =/  frames=(list frame:obs)
    (skim ~(val by frames.observed.stores) |=(f=frame:obs =(work.u.enrolled work.f)))
  ?.  =(1 (lent frames))  $(todo t.todo)
  =/  input  (input:observer inner b session.work.u.enrolled)
  ?~  input  $(todo t.todo)
  =/  refusal  (refused-call b u.input stores (snag 0 frames))
  ?~  refusal  $(todo t.todo)
  =/  gap=interruption:recurring  [u.refusal %instrument-call-refused]
  $(todo t.todo, ordered (cancel:recurring ordered enrollment.body.x gap))
++  refresh-successors
  |=  [ordered=state:recurring held=state inner=agent:gall b=bowl:gall]
  ^-  state:recurring
  ?:  =(ordered *state:recurring)  ordered
  =/  stores  (stores-read inner b)
  ?~  stores  ordered
  |-  ^-  state:recurring
  =/  next  (advance:recurring ordered admitted.held observed.u.stores 512)
  ?^  fault.next  next
  =/  cleared  (successor-refusals next ~ held inner b u.stores)
  ?:  =(next cleared)  next
  ::  Each pass adds a new authentic cancellation; the queue is bounded at 512.
  $(ordered cleared)
++  selected-valid
  |=  [held=state selected=state:selected-history]
  ^-  ?
  ::  Selected enrollment cannot survive removal of its v5 reservation map.
  ::  Ordinary native enrollment always retains its original plan.
  ?.  %+  levy  ~(tap by enrollments.admitted.held)
      |=  [id=@ux e=enrollment:admission]
      |((~(has by plans.held) session.work.e) (~(has by reservations.selected) id))
    %.n
  %+  levy  ~(val by reservations.selected)
  |=  r=registration:selected-history
  =/  member  (~(get by plans.held) member.r)
  ?~  member  %.n
  =/  p=plan  plan.u.member
  =/  e=enrollment:admission  enrollment.reservation.r
  ?&  (successor-plan p)  =(instrument.p instrument.position.e)
      =(stream.p stream.position.e)  =((digest:obs manifest.p) manifest.contract.e)
      =(artifact.p artifact.work.e)  =(cases.p case-set.work.e)
      =(task.p task.task.e)  =(objective.p objective.task.e)
      !(~(has by plans.held) session.work.e)
  ==
++  reserve-selected
  ::  Called only by the outer prospective owner after its canonical registry,
  ::  current source and law read. That wrapper rejects this private command
  ::  at its external boundary. Rejoin local stores and numbered source here.
  |=  $:  held=state  successors=state:recurring  selected=state:selected-history
          laws=laws  inner=agent:gall  b=bowl:gall  read-source=reader  c=reserve-command
      ==
  ^-  (each [held=state successors=state:recurring selected=state:selected-history] @tas)
  =/  found  (~(get by plans.held) member.c)
  ?~  found  [%| %qpc-selected-member-missing]
  =/  p=plan  plan.u.found
  ?.  &((successor-plan p) !(~(has by plans.held) session.work.c))
    [%| %qpc-selected-managed-plan-required]
  ?.  =(`[instrument.p law.c] (~(get by laws) member.c))
    [%| %qpc-selected-law-changed]
  =/  stores  (stores-read inner b)
  ?~  stores  [%| %qpc-selected-stores-unavailable]
  ?.  &((~(has in required.u.stores) session.work.c) !(~(has by legacy.u.stores) session.work.c))
    [%| %qpc-selected-managed-session-required]
  =/  input  (input:observer inner b session.work.c)
  ?~  input  [%| %qpc-selected-session-missing]
  =/  config  (project-read inner b session.work.c project.manifest.p)
  ?:  ?=(%| -.config)  [%| p.config]
  =/  cases  (~(get by cases.checked.u.stores) cases.p)
  ?~  cases  [%| %qpc-selected-cases-missing]
  =/  pinned  (read-source our.b now.b p.config source.work.c artifact.p u.cases)
  ?:  ?=(%| -.pinned)  [%| p.pinned]
  =/  contract=contract:sensing
    [%qpc-task-sensing-v1 instrument.p law.c (digest:obs manifest.p) 16 %first-17-reference-successive-disjoint-17-live]
  =/  task=task:sensing
    [%qpc-task-binding-v1 task.p objective.p artifact.p source.work.c (configuration:project p.config) u.cases evidence.p.pinned horizon.p]
  =/  win  (~(get by windows.successors) stream.p)
  ?~  win  [%| %qpc-selected-window-missing]
  ?~  segment.u.win  [%| %qpc-selected-segment-unavailable]
  =/  enrolled
    (register:admission admitted.held our.b now.b [instrument.p stream.p u.segment.u.win ordinal.u.win] contract task manifest.p work.c p.config u.cases entry.u.input)
  ?:  ?=(%| -.enrolled)  [%| p.enrolled]
  =/  enrollment=enrollment:admission
    (need (lien-find (digest:obs work.c) ~(val by enrollments.p.enrolled)))
  =/  reserved  (reserve:selected-measurement enrollment u.win)
  ?:  ?=(%| -.reserved)  [%| p.reserved]
  =/  queued  (reserve:selected-history successors selected member.c p.reserved)
  ?:  ?=(%| -.queued)  [%| p.queued]
  [%& [held(admitted p.enrolled, bindings (~(put by bindings.held) id.enrollment [p.config p.pinned])) history.p.queued selected.p.queued]]
++  refresh-selected
  |=  [ordered=state:recurring selected=state:selected-history held=state inner=agent:gall b=bowl:gall]
  ^-  state:recurring
  ?:  =(selected *state:selected-history)  (refresh-successors ordered held inner b)
  =/  stores  (stores-read inner b)
  ?~  stores  ordered
  ::  The separate native settlement reader must fill selected receipts.
  ::  Never feed reserved alternatives through the ordinary gap/refusal path.
  |-  ^-  state:recurring
  =/  next  (advance:selected-history ordered selected admitted.held observed.u.stores 512)
  ?^  fault.next  next
  =/  cleared  (successor-refusals next ~(key by reservations.selected) held inner b u.stores)
  ?:  =(next cleared)  next
  $(ordered cleared)
++  reviews-read
  |=  [inner=agent:gall b=bowl:gall]
  ^-  (unit state:review)
  =/  value  (raw inner b /x/native-coding/reviews)
  ?~  value  ~
  =/  parsed  ((soft state:review) u.value)
  ?~  parsed  ~
  ?.  &(=(u.value u.parsed) (lte ~(wyt by u.parsed) 128))  ~
  parsed
++  selected-wire
  |=  [candidate=@ux t=ticket:selected-history]
  ^-  wire
  /qpc-selected-settlement/(scot %ux candidate)/(scot %ux id.t)/(scot %da due.t)
++  schedule-selected
  ::  Local returned-inner DATA only. Never a scry or a caller's status row.
  |=  [s=state:selected-history before=(unit state:review) after=(unit state:review) at=@da]
  ^-  [selected=state:selected-history cards=(list card:agent:gall)]
  ?~  before  [s ~]
  ?~  after  [s ~]
  =/  todo=(list [@ux entry:review])  ~(tap by u.after)
  =/  cards=(list card:agent:gall)  ~
  |-  ^-  [selected=state:selected-history cards=(list card:agent:gall)]
  ?~  todo  [s cards]
  =/  [id=@ux row=entry:review]  i.todo
  ?:  |((~(has by reads.s) id) (gte ~(wyt by reads.s) 128))  $(todo t.todo)
  ?~  observed.row  $(todo t.todo)
  =/  old  (~(get by u.before) id)
  ?:  ?~(old %.n =(observed.u.old observed.row))  $(todo t.todo)
  =/  a=record:acceptance  u.observed.row
  ?.  &(?=(?(%applied %refused) stage.a) ?=(^ decision.a))  $(todo t.todo)
  ?.  &(=(id id.candidate.a) =(candidate.row candidate.a) (valid:acceptance (malt ~[[id a]])))
    $(todo t.todo)
  ::  Bound the local scheduling surface to held source/configuration scope.
  ::  The delayed canonical mapping join still proves the exact selection.
  ?.  %+  lien  ~(val by reservations.s)
      |=  r=registration:selected-history
      =/  w=work:obs  work.enrollment.reservation.r
      &(!(~(has by receipts.s) id.enrollment.reservation.r) =(source.w source.context.candidate.a) =(configuration.w configuration.context.candidate.a))
    $(todo t.todo)
  =/  session=@ux  session.context.candidate.a
  =/  decision=@ux  (digest:acceptance u.decision.a)
  =/  commitment=@ux  (digest:acceptance a)
  =/  t=ticket:selected-history
    [(read-id:selected-history id session decision commitment) session decision commitment (add at ~s1) %scheduled ~]
  =.  s  s(reads (~(put by reads.s) id t))
  =/  wake=card:agent:gall  [%pass (selected-wire id t) %arvo %b %wait due.t]
  $(todo t.todo, cards (snoc cards wake))
++  read-selected
  ::  A terminal read is consumed once. Failure cannot reopen its ticket.
  |=  [s=state:selected-history our=@p at=@da candidate=@ux fetch=reader:selected-reader]
  ^-  state:selected-history
  =/  found  (~(get by reads.s) candidate)
  ?~  found  s
  =/  t=ticket:selected-history  u.found
  ?.  &(=(%scheduled phase.t) (gte at due.t))  s
  =/  result  (fetch our at candidate acceptance.t)
  =/  checked=(each state:selected-history @tas)
    ?:  ?=(%| -.result)  [%| p.result]
    =/  a=record:acceptance  acceptance.p.result
    ?~  decision.a  [%| %qpc-selected-read-decision-missing]
    ?.  ?&  =(candidate id.candidate.a)  =(session.t session.context.candidate.a)
            =(acceptance.t (digest:acceptance a))
            =(decision.t (digest:acceptance u.decision.a))
        ==  [%| %qpc-selected-read-commitment-changed]
    (collect:selected-history s p.result)
  ?:  ?=(%| -.checked)
    s(reads (~(put by reads.s) candidate t(phase %unknown, reason `p.checked)))
  p.checked(reads (~(put by reads.p.checked) candidate t(phase %settled)))
++  wrap
  |=  [inner=agent:gall read-source=reader]
  ^-  agent:gall
  (wrap-with inner read-source read:selected-reader)
++  wrap-with
  ::  Reader injection is a native proof seam, never an external command.
  |=  [inner=agent:gall read-source=reader read-terminal=reader:selected-reader]
  =|  held=state
  =|  ordered=state:history
  =|  successors=state:recurring
  =|  refresh=(unit @da)
  =|  selected=state:selected-history
  =|  current-laws=laws
  =-
    =/  owner  -
    ^-  agent:gall
    |_  =bowl:gall
    +*  this  .
        owned  ~(. owner bowl)
        publish
          |=  [cards=(list card:agent:gall) next=_owned]
          ^-  (quip card:agent:gall _this)
          =/  before=state:history  ordered:owned
          =/  after=state:history  ordered.next
          =/  prior=state:recurring  successors:owned
          =/  later=state:recurring  successors.next
          ?:  &(=(windows.before windows.after) =(windows.prior windows.later))
            [cards this(owner next)]
          =/  facts=(list *)
            ?:  =(windows.before windows.after)  ~
            =/  todo  ~(tap by windows.before)
            =/  out=(list *)  ~
            |-  ^-  (list *)
            ?~  todo  out
            =/  old  q.i.todo
            =/  found  (~(get by windows.after) p.i.todo)
            ?~  found  $(todo t.todo)
            =/  fresh  u.found
            ?:  =(old fresh)  $(todo t.todo)
            =.  out
              ?^  reference.old  out
              ?~  reference.fresh  out
              (snoc out [%qpc-instrument-epoch-attestation-v1 our.bowl u.reference.fresh])
            =.  out
              ?^  measured.old  out
              ?~  measured.fresh  out
              (snoc out [%qpc-instrument-reading-attestation-v1 our.bowl binding.fresh u.measured.fresh])
            $(todo t.todo)
          =.  facts
            ?:  =(windows.prior windows.later)  facts
            =/  todo  ~(tap by windows.prior)
            =/  out=(list *)  facts
            |-  ^-  (list *)
            ?~  todo  out
            =/  old  q.i.todo
            =/  found  (~(get by windows.later) p.i.todo)
            ?~  found  $(todo t.todo)
            =/  fresh  u.found
            ?:  =(old fresh)  $(todo t.todo)
            =.  out
              ?^  reference.old  out
              ?~  reference.fresh  out
              (snoc out [%qpc-instrument-epoch-attestation-v1 our.bowl u.reference.fresh])
            =.  out
              ?:  =(readings.old readings.fresh)  out
              =/  rows  ~(tap by readings.fresh)
              |-  ^-  (list *)
              ?~  rows  out
              ?:  (~(has by readings.old) p.i.rows)
                $(rows t.rows)
              $(rows t.rows, out (snoc out [%qpc-instrument-reading-attestation-v1 our.bowl binding.fresh q.i.rows]))
            $(todo t.todo)
          =/  emitted=(list card:agent:gall)
            %+  turn  facts
            |=  fact=*
            ^-  card:agent:gall
            [%pass /qpc/instrument/attest/(scot %ux (shax (jam fact))) %agent [our.bowl %graf] %poke %graf-action !>([%attest fact])]
          [(weld emitted cards) this(owner next)]
    ++  on-init
      =^  cards  owner  on-init:owned
      [cards this]
    ++  on-save  on-save:owned
    ++  on-load
      |=  old=vase
      =^  cards  owner  (on-load:owned old)
      [cards this]
    ++  on-poke
      |=  [=mark =vase]
      (publish (on-poke:owned mark vase))
    ++  on-peek  on-peek:owned
    ++  on-watch
      |=  =path
      (publish (on-watch:owned path))
    ++  on-leave
      |=  =path
      (publish (on-leave:owned path))
    ++  on-agent
      |=  [=wire =sign:agent:gall]
      ?:  &(?=([%qpc %instrument %attest @ ~] wire) ?=(%poke-ack -.sign))
        [~ this]
      (publish (on-agent:owned wire sign))
    ++  on-arvo
      |=  [=wire =sign-arvo]
      (publish (on-arvo:owned wire sign-arvo))
    ++  on-fail
      |=  [=term =tang]
      (publish (on-fail:owned term tang))
    --
  |_  =bowl:gall
  +*  this  .
      ag  ~(. inner bowl)
      finish
        ::  In successor mode, native evidence reads run after the actual
        ::  callback DATA and ordinary cards commit, never inside that callback.
        |=  cards=(list card:agent:gall)
        ^-  (quip card:agent:gall _this)
        ?:  =(successors *state:recurring)
          =.  held  (reconcile held inner bowl)
          =.  ordered  (refresh-history ordered held inner bowl)
          [cards this]
        ?.  =(~ refresh)  [cards this]
        =/  due=@da  (add now.bowl ~s1)
        =.  refresh  `due
        =/  wake=(list card:agent:gall)
          ~[[%pass /qpc-successor-refresh/(scot %da due) %arvo %b %wait due]]
        [(weld cards wake) this]
  ++  on-init
    =^  cards  inner  on-init:ag
    [cards this]
  ++  on-save
    ::  No new envelope for operators who never explicitly register this policy.
    ?:  !=(selected *state:selected-history)
      !>([%qpc-instrument-v5 held ordered current-laws successors refresh selected on-save:ag])
    ?:  =(successors *state:recurring)
      !>([%qpc-instrument-v3 held ordered current-laws on-save:ag])
    !>([%qpc-instrument-v4 held ordered current-laws successors refresh on-save:ag])
  ++  on-load
    |=  old=vase
    =/  saved=[held=state ordered=state:history laws=laws successors=state:recurring refresh=(unit @da) selected=state:selected-history inner=vase]
      ?:  ?=([%qpc-instrument-v5 *] q.old)
        =/  prior  !<([%qpc-instrument-v5 held=state ordered=state:history laws=laws successors=state:recurring refresh=(unit @da) selected=state:selected-history inner=vase] old)
        +.prior
      ?:  ?=([%qpc-instrument-v4 *] q.old)
        =/  prior  !<([%qpc-instrument-v4 held=state ordered=state:history laws=laws successors=state:recurring refresh=(unit @da) inner=vase] old)
        [held.prior ordered.prior laws.prior successors.prior refresh.prior *state:selected-history inner.prior]
      ?:  ?=([%qpc-instrument-v3 *] q.old)
        =/  prior  !<([%qpc-instrument-v3 held=state ordered=state:history laws=laws inner=vase] old)
        [held.prior ordered.prior laws.prior *state:recurring ~ *state:selected-history inner.prior]
      ?:  ?=([%qpc-instrument-v2 *] q.old)
        =/  prior  !<([%qpc-instrument-v2 held=state ordered=state:history inner=vase] old)
        [held.prior ordered.prior *laws *state:recurring ~ *state:selected-history inner.prior]
      ?.  ?=([%qpc-instrument-v1 *] q.old)  [*state *state:history *laws *state:recurring ~ *state:selected-history old]
      =/  prior  !<([%qpc-instrument-v1 held=state inner=vase] old)
      [held.prior *state:history *laws *state:recurring ~ *state:selected-history inner.prior]
    ?>  (valid our.bowl held.saved)
    ?>  (laws-valid laws.saved held.saved)
    ?>  (histories-valid held.saved ordered.saved successors.saved)
    ?>  (selected-valid held.saved selected.saved)
    ?>  ?~(refresh.saved %.y &(!=(successors.saved *state:recurring) (gth u.refresh.saved 0)))
    =.  held  held.saved
    =.  ordered  ordered.saved
    =.  successors  successors.saved
    =.  refresh  refresh.saved
    =.  selected  selected.saved
    =.  current-laws  laws.saved
    =^  cards  inner  (on-load:ag inner.saved)
    =/  stores  (stores-read inner bowl)
    ?>  ?=(^ stores)
    ?>  (valid:history ordered admitted.held observed.u.stores)
    ?>  (valid:selected-history successors selected admitted.held observed.u.stores)
    [cards this]
  ++  on-poke
    |=  [=mark =vase]
    ?:  &(=(%noun mark) ?=([%qpc-instrument-dispatch-v1 @] q.vase))
      ::  Readiness owner only: dispatch the ticket enrolled in THIS event so
      ::  charge, reservation and inference commit together. Else a no-op.
      ?>  =(our.bowl src.bowl)
      =/  id=@ux  ;;(@ux +.q.vase)
      =/  found  (~(get by plans.held) id)
      ?~  found  [~ this]
      ?~  ticket.u.found  [~ this]
      =/  t=ticket  u.ticket.u.found
      ?.  &(active.u.found =(due.t (add now.bowl ~s1)))  [~ this]
      (on-arvo (ticket-wire id t) [%behn %wake ~])
    ?:  &(=(%noun mark) ?=([%qpc-campaign-handover-v1 @ @ @] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  c  !<([%qpc-campaign-handover-v1 member=@ux enrollment=@ux receipt=@ux] vase)
      =/  got  (selected-handover held successors selected member.c enrollment.c receipt.c)
      ?>  ?=(%& -.got)
      [~ this(held p.got)]
    ?:  &(=(%noun mark) ?=([%qpc-selected-reserve-v1 *] q.vase))
      ?>  =(our.bowl src.bowl)
      ?>  =(~ refresh)
      =/  command  !<(reserve-command vase)
      =/  got  (reserve-selected held successors selected current-laws inner bowl read-source command)
      ~|  ?:(?=(%| -.got) p.got %qpc-selected-reserved)
      ?>  ?=(%& -.got)
      [~ this(held held.p.got, successors successors.p.got, selected selected.p.got)]
    ::  Only the outer law owner may project this context. It rejects the
    ::  protocol at its public boundary, even for owner-authenticated pokes.
    ?:  &(=(%noun mark) ?=([%qpc-instrument-law-context-v1 *] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  context  ;;([%qpc-instrument-law-context-v1 laws=laws] q.vase)
      ?>  (laws-valid laws.context held)
      [~ this(current-laws laws.context)]
    ?:  &(=(%noun mark) ?=([?(%qpc-instrument-plan-v1 %qpc-instrument-successor-plan-v1) *] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  explicit=?  ?=([%qpc-instrument-successor-plan-v1 *] q.vase)
      =/  p=plan
        ?.  explicit  ;;(plan q.vase)
        =/  command  !<([%qpc-instrument-successor-plan-v1 value=plan] vase)
        value.command
      ?>  (plan-valid our.bowl p)
      ?>  =(explicit (successor-plan p))
      ?>  &(!(~(has by plans.held) session.p) (lth ~(wyt by plans.held) plan-limit))
      =/  existing  (raw inner bowl /x/native-coding/session/(scot %ux session.p))
      ?>  ?=(^ existing)
      ?>  =(`~ ((soft ,(unit *)) u.existing))
      =/  stores  (stores-read inner bowl)
      ?>  ?=(^ stores)
      ?>  !(~(has by legacy.u.stores) session.p)
      ?>  !(~(has in required.u.stores) session.p)
      ?>  !(lien ~(val by frames.observed.u.stores) |=(f=frame:obs =(session.p session.work.f)))
      =/  cases  (~(get by cases.checked.u.stores) cases.p)
      ?>  &(?=(^ cases) (cases-valid:outcomes u.cases))
      ?:  (lien ~(val by plans.held) |=(r=record =(stream.p stream.plan.r)))
        =/  last=(list record)  (skim ~(val by plans.held) |=(r=record &(active.r =(stream.p stream.plan.r))))
        =/  finished=?
          ?~  last  %.y
          =/  seen  (raw inner bowl /x/native-coding/session/(scot %ux session.plan.i.last))
          ?~  seen  %.n
          =/  public  ((soft ,(unit [* phase=@tas *])) u.seen)
          ?~  public  %.n
          ?~  u.public  %.n
          =(%complete phase.u.u.public)
        =/  joined
          ?:(explicit (join-successor held successors p finished) (join held ordered p finished))
        ~|  ?:(?=(%| -.joined) p.joined %pool-joined)
        ?>  ?=(%& -.joined)
        [~ this(plans.held plans.p.joined)]
      =/  r=record  [p %.y 0 (digest:admission [%instrument-segment p now.bowl]) ~ ~ ~]
      ?:  explicit
        ?>  !(~(has by windows.ordered) stream.p)
        =.  successors  (open:recurring successors (successor-binding p) manifest.p)
        [~ this(plans.held (~(put by plans.held) session.p r))]
      =.  ordered  (open:history ordered [instrument.p stream.p (digest:obs manifest.p) %first-17-reference-next-disjoint-17-live %qpc-ct-update-v1])
      [~ this(plans.held (~(put by plans.held) session.p r))]
    ?:  &(=(%noun mark) ?=([?(%qpc-instrument-stop-v1 %qpc-instrument-retry-v1 %qpc-instrument-reobserve-v1) @] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  id=@ux  `@ux`+.q.vase
      =.  held  (reconcile held inner bowl)
      =.  ordered  (refresh-history ordered held inner bowl)
      =.  successors  (refresh-selected successors selected held inner bowl)
      =.  refresh  ~
      =/  r=record  (~(got by plans.held) id)
      ?:  =(%qpc-instrument-reobserve-v1 -.q.vase)  [~ this]
      ?:  =(%qpc-instrument-retry-v1 -.q.vase)
        ?.  active.r  [~ this]
        ?~  ticket.r
          [~[(self-card our.bowl [%native-coding-action-v1 [%run id]])] this]
        =/  next=ticket  u.ticket.r(due (add (max now.bowl due.u.ticket.r) ~s1))
        [~[(wait-card id next)] this(held held(plans (~(put by plans.held) id r(ticket `next, reason ~))))]
      ?.  active.r  [~ this]
      =/  stop=interruption:history  [(digest:admission [%stop id now.bowl r]) %operator-stopped]
      =/  input  (input:observer inner bowl id)
      =/  unfired=(unit @ux)
        ?^  ticket.r  `enrollment.u.ticket.r
        ?~  input  ~
        %^  unsent  r  entry.u.input
        :-  id
        ?~(awaiting.r ~ (~(get by enrollments.admitted.held) u.awaiting.r))
      =.  ordered
        ?~  unfired  (interrupt:history ordered stream.plan.r stop)
        (cancel:history ordered u.unfired stop)
      =.  successors
        ?~  unfired  (interrupt:recurring successors stream.plan.r stop)
        (cancel:recurring successors u.unfired stop)
      ::  A dispatched commitment still owns its eventual frame/settlement.
      ?:  &(?=(~ unfired) ?=(^ awaiting.r))
        [~ this(held held(plans (~(put by plans.held) id r(active %.n, step +(step.r), segment evidence.stop, reason `%operator-stopped))))]
      =.  held  held(plans (~(put by plans.held) id r(active %.n, ticket ~, awaiting ~, step +(step.r), segment (digest:admission [%stop segment.r now.bowl]), reason `%operator-stopped)))
      =^  cards  inner  (on-poke:ag %noun !>([%qpc-observe-disarm-v1 id]))
      =.  ordered  (refresh-history ordered held inner bowl)
      =.  successors  (refresh-selected successors selected held inner bowl)
      [cards this]
    ?:  &(=(%noun mark) ?=([%native-coding-action-v1 %run @] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  command  ;;([%native-coding-action-v1 [%run id=@ux]] q.vase)
      =.  held  (reconcile held inner bowl)
      =.  ordered  (refresh-history ordered held inner bowl)
      =.  successors  (refresh-selected successors selected held inner bowl)
      =.  refresh  ~
      =/  found  (~(get by plans.held) id.command)
      ?~  found
        =^  cards  inner  (on-poke:ag mark vase)
        [cards this]
      =/  r=record  u.found
      ?^  awaiting.r  [~ this]
      ?.  active.r
        =^  cards  inner  (on-poke:ag mark vase)
        [cards this]
      ?:  (pending:selected-history successors selected stream.plan.r)
        [~ this(held (unavailable held id.command %qpc-selected-stream-pending))]
      =/  input  (input:observer inner bowl id.command)
      ?~  input  [~ this(held (unavailable held id.command %instrument-session-unavailable))]
      =/  e=entry:sessions  entry.u.input
      ?.  &(?=(~ pending.e) ?=(~ calls.e) =(%ready phase.e))
        =^  cards  inner  (on-poke:ag mark vase)
        [cards this]
      =/  p=plan  plan.r
      =/  context  (~(get by current-laws) session.p)
      ?~  context  [~ this(held (unavailable held id.command %instrument-law-unavailable))]
      =/  stores  (stores-read inner bowl)
      ?~  stores  [~ this(held (unavailable held id.command %instrument-stores-unavailable))]
      ?.  &(!(~(has by legacy.u.stores) id.command) !(~(has in required.u.stores) id.command))
        [~ this(held (unavailable held id.command %instrument-exclusive-ordinary-session-required))]
      =/  config  (project-read inner bowl id.command project.manifest.p)
      ?:  ?=(%| -.config)  [~ this(held (unavailable held id.command p.config))]
      =/  cases  (~(get by cases.checked.u.stores) cases.p)
      ?~  cases  [~ this(held (unavailable held id.command %instrument-cases-missing))]
      =/  pinned  (read-source our.bowl now.bowl p.config working.session.e artifact.p u.cases)
      ?:  ?=(%| -.pinned)  [~ this(held (unavailable held id.command p.pinned))]
      =/  c=contract:sensing  [%qpc-task-sensing-v1 instrument.p law.u.context (digest:obs manifest.p) 16 (need (policy-of:sensing manifest.p))]
      =/  t=task:sensing
        [%qpc-task-binding-v1 task.p objective.p artifact.p working.session.e (configuration:project p.config) u.cases evidence.p.pinned horizon.p]
      =/  request=@ux  (request-id:sessions id.command turn.e)
      =/  w=work:obs
        [%qpc-observation-work-v1 manifest.c (digest:admission [p request]) id.command request configuration.t source.t artifact.t cases.p (substitutions:sensing c t) evidence.t]
      =/  aligned  (align-successor r successors)
      ?:  ?=(%| -.aligned)  [~ this(held (unavailable held id.command p.aligned))]
      =.  r  r(step step.p.aligned, segment segment.p.aligned)
      =/  boundary-cursor=record  (boundary r e observed.u.stores events.held)
      ::  A pooled stream continues only from the last row's resulting source.
      =/  continuous=?
        ?:  (successor-plan p)
          (successor-continuity successors stream.p source.w)
        (continuity ordered stream.p source.w)
      =/  broken=?  &(=(step.r step.boundary-cursor) !continuous)
      =/  cursor=record
        ?.  broken  boundary-cursor
        boundary-cursor(step +(step.boundary-cursor), segment (digest:admission [%pool-source segment.boundary-cursor source.w]))
      =/  enrolled  (register:admission admitted.held our.bowl now.bowl [instrument.p stream.p segment.cursor step.cursor] c t manifest.p w p.config u.cases e)
      ?:  ?=(%| -.enrolled)  [~ this(held (unavailable held id.command p.enrolled))]
      =/  registration=enrollment:admission
        (need (lien-find (digest:obs w) ~(val by enrollments.p.enrolled)))
      =.  ordered
        ?:  =(step.r step.cursor)  ordered
        (interrupt:history ordered stream.p [(digest:admission [%interruption id.command head.e cursor]) ?:(broken %pool-source-discontinuity %session-interrupted)])
      =.  ordered  (reserve:history ordered registration)
      =.  successors
        ?:  =(step.r step.cursor)  successors
        (interrupt:recurring successors stream.p [(digest:admission [%interruption id.command head.e cursor]) ?:(broken %pool-source-discontinuity %session-interrupted)])
      =.  successors  (reserve:recurring successors registration)
      =.  held  held(admitted p.enrolled, bindings (~(put by bindings.held) id.registration [p.config p.pinned]))
      =^  cards  inner  (on-poke:ag %noun !>([%qpc-observe-arm-v1 manifest.p w]))
      =/  ticket=ticket  [id.registration (digest:obs e) (add now.bowl ~s1)]
      =.  held  held(plans (~(put by plans.held) id.command cursor(ticket `ticket, awaiting `id.registration, reason ~)))
      [(weld cards ~[(wait-card id.command ticket)]) this]
    ::  No legacy/manual enrollment can steal an active instrument session.
    ?:  &(=(%noun mark) ?=([%qpc-stream-plan-v1 *] q.vase))
      =/  p=plan:legacy  ;;(plan:legacy q.vase)
      ?>  !(~(has by plans.held) session.template.p)
      =^  cards  inner  (on-poke:ag mark vase)
      [cards this]
    ?:  &(=(%noun mark) ?=([%qpc-observe-arm-v1 *] q.vase))
      =/  p  ;;([%qpc-observe-arm-v1 manifest=manifest:obs work=work:obs] q.vase)
      ?>  !(~(has by plans.held) session.work.p)
      ?.  =(`%first-17-reference-successive-disjoint-17-live (policy-of:sensing manifest.p))
        =^  cards  inner  (on-poke:ag mark vase)
        [cards this]
      =/  stores  (stores-read inner bowl)
      ?>  ?=(^ stores)
      ?:  (~(has in required.u.stores) session.work.p)
        =/  reserved=(list registration:selected-history)
          (skim ~(val by reservations.selected) |=(r=registration:selected-history =(work.p work.enrollment.reservation.r)))
        ?>  =(1 (lent reserved))
        =/  r=registration:selected-history  (snag 0 reserved)
        =/  reopened  (reopen:selected-history successors selected member.r work.p source.work.p)
        ?>  &(?=(%& -.reopened) =(manifest.p manifest.p.reopened))
        =^  cards  inner  (on-poke:ag mark vase)
        [cards this]
      =^  cards  inner  (on-poke:ag mark vase)
      [cards this]
    ?:  &(=(%noun mark) ?=([%qpc-observe-disarm-v1 @] q.vase))
      ?>  !(~(has by plans.held) `@ux`+.q.vase)
      =^  cards  inner  (on-poke:ag mark vase)
      [cards this]
    =/  before=(unit state:review)
      ?:(=(reservations.selected ~) ~ (reviews-read inner bowl))
    =^  cards  inner  (on-poke:ag mark vase)
    =/  after=(unit state:review)
      ?:(=(reservations.selected ~) ~ (reviews-read inner bowl))
    =/  queued  (schedule-selected selected before after now.bowl)
    =.  selected  selected.queued
    (finish (weld cards cards.queued))
  ++  on-peek
    |=  =path
    ?:  =(/x/qpc/instrument/selected path)
      ?.  =(our.bowl src.bowl)  ~
      ``noun+!>([%qpc-instrument-selected-v1 selected])
    ?:  =(/x/qpc/instrument/successors path)
      ?.  =(our.bowl src.bowl)  ~
      ``noun+!>([%qpc-instrument-successors-v1 successors refresh])
    ?:  ?=([%x %qpc %instrument %successor @ %current ~] path)
      ?.  =(our.bowl src.bowl)  ~
      =/  stream  (slaw %ux i.t.t.t.t.path)
      ?~  stream  ~
      =/  result=(each reading:successor @tas)
        ?^  refresh  [%| %qpc-successor-refresh-unconfirmed]
        (successor-current held successors inner bowl u.stream)
      ``noun+!>(result)
    ?:  =(/x/qpc/instrument/measurements path)
      ?.  =(our.bowl src.bowl)  ~
      ``noun+!>([%qpc-instrument-measurements-v1 ordered])
    ?:  =(/x/qpc/instrument/state path)
      ?.  =(our.bowl src.bowl)  ~
      ``noun+!>(held)
    ?:  =(/x/qpc/instrument/snapshot path)
      ?.  =(our.bowl src.bowl)  ~
      ``noun+!>((snapshot-of held))
    (on-peek:ag path)
  ++  on-watch
    |=  =path
    ?:  |(=(successors *state:recurring) !=(~ refresh))
      =^  cards  inner  (on-watch:ag path)
      [cards this]
    =/  before  (stores-read inner bowl(src our.bowl))
    =^  cards  inner  (on-watch:ag path)
    =/  after  (stores-read inner bowl(src our.bowl))
    ?~  before  (finish cards)
    ?~  after  (finish cards)
    ?:  =(u.before u.after)  [cards this]
    (finish cards)
  ++  on-leave
    |=  =path
    ?:  |(=(successors *state:recurring) !=(~ refresh))
      =^  cards  inner  (on-leave:ag path)
      [cards this]
    =/  before  (stores-read inner bowl(src our.bowl))
    =^  cards  inner  (on-leave:ag path)
    =/  after  (stores-read inner bowl(src our.bowl))
    ?~  before  (finish cards)
    ?~  after  (finish cards)
    ?:  =(u.before u.after)  [cards this]
    (finish cards)
  ++  on-agent
    |=  [=wire =sign:agent:gall]
    =^  cards  inner  (on-agent:ag wire sign)
    (finish cards)
  ++  on-arvo
    |=  [=wire =sign-arvo]
    ?:  ?=([%qpc-selected-settlement *] wire)
      ?.  &(=(our.bowl src.bowl) ?=([%qpc-selected-settlement @ @ @ ~] wire))  [~ this]
      =/  parsed  (slaw %ux i.t.wire)
      ?~  parsed  [~ this]
      =/  candidate=@ux  u.parsed
      =/  found  (~(get by reads.selected) candidate)
      ?~  found  [~ this]
      =/  t=ticket:selected-history  u.found
      ?.  &(=(%scheduled phase.t) =(wire (selected-wire candidate t)))  [~ this]
      ?.  ?=([%behn %wake ~] sign-arvo)
        [~ this(reads.selected (~(put by reads.selected) candidate t(phase %unknown, reason `%qpc-selected-read-timer-failed)))]
      ?.  (gte now.bowl due.t)  [~ this]
      ::  Only this already-issued Behn read may join committed outer owners.
      ::  A native scry failure cannot roll back the prior ordinary callback.
      =.  selected  (read-selected selected our.bowl now.bowl candidate read-terminal)
      =/  stores  (stores-read inner bowl)
      ?~  stores  [~ this]
      =.  successors  (advance:selected-history successors selected admitted.held observed.u.stores 512)
      [~ this]
    ?:  ?=([%qpc-successor-refresh *] wire)
      ?.  &(=(our.bowl src.bowl) ?=([%qpc-successor-refresh @ ~] wire))  [~ this]
      ?~  refresh  [~ this]
      ?.  =(wire /qpc-successor-refresh/(scot %da u.refresh))  [~ this]
      ?.  &(?=([%behn %wake ~] sign-arvo) (gte now.bowl u.refresh))  [~ this]
      ::  A native scry failure leaves this retained read ticket unresolved.
      ::  The prior callback has already committed; there is no automatic retry.
      =.  held  (reconcile held inner bowl)
      =.  ordered  (refresh-history ordered held inner bowl)
      =.  successors  (refresh-selected successors selected held inner bowl)
      [~ this(refresh ~)]
    ?:  ?=([%qpc-instrument-wake *] wire)
      ?.  ?=([%qpc-instrument-wake @ @ @ @ ~] wire)  [~ this]
      ?.  ?=([%behn %wake *] sign-arvo)  [~ this]
      =/  parsed  (slaw %ux i.t.wire)
      ?~  parsed  [~ this]
      =/  id=@ux  u.parsed
      =/  found  (~(get by plans.held) id)
      ?~  found  [~ this]
      =/  r=record  u.found
      ?~  ticket.r  [~ this]
      =/  t=ticket  u.ticket.r
      ?.  &(active.r =(wire (ticket-wire id t)))  [~ this]
      ?.  ?=([%behn %wake ~] sign-arvo)
        [~ this(held (unavailable held id %instrument-timer-failed))]
      ?:  =(`%instrument-timer-failed reason.r)  [~ this]
      ::  A ticket enrolled in this same event (due = now + 1s) fires only via
      ::  the readiness owner's composed dispatch; no Behn wake arrives early.
      ?.  |((gte now.bowl due.t) =(due.t (add now.bowl ~s1)))  [~ this]
      =/  input  (input:observer inner bowl id)
      =/  stores  (stores-read inner bowl)
      =/  bound  (~(get by bindings.held) enrollment.t)
      =/  enrolled  (~(get by enrollments.admitted.held) enrollment.t)
      =/  context  (~(get by current-laws) id)
      =/  config  (project-read inner bowl id project.manifest.plan.r)
      =/  ready=?
        ?~  input  %.n
        ?~  stores  %.n
        ?~  bound  %.n
        ?~  enrolled  %.n
        ?~  context  %.n
        ?.  =(u.context [instrument.contract.u.enrolled law.contract.u.enrolled])  %.n
        ?.  ?=(%& -.config)  %.n
        =/  armed  (~(get by arms.observed.u.stores) id)
        ?~  armed  %.n
        =/  pinned  (read-source our.bowl now.bowl p.config source.work.u.enrolled artifact.work.u.enrolled cases.task.u.enrolled)
        ?.  ?=(%& -.pinned)  %.n
        ?&  =(snapshot.t (digest:obs entry.u.input))
            =(p.config project.u.bound)  active.u.armed  =(work.u.enrolled work.u.armed)
            =(p.pinned source.u.bound)
            !(~(has by legacy.u.stores) id)  !(~(has in required.u.stores) id)
        ==
      =.  held  held(plans (~(put by plans.held) id r(ticket ~)))
      ?.  ready
        =.  ordered  (cancel:history ordered enrollment.t [(digest:admission [%stale id t now.bowl]) %instrument-ticket-stale])
        =.  successors  (cancel:recurring successors enrollment.t [(digest:admission [%stale id t now.bowl]) %instrument-ticket-stale])
        =.  held  held(plans (~(put by plans.held) id r(active %.n, ticket ~, awaiting ~, reason `%instrument-ticket-stale)))
        =^  cards  inner  (on-poke:ag %noun !>([%qpc-observe-disarm-v1 id]))
        =.  ordered  (refresh-history ordered held inner bowl)
        =.  successors  (refresh-selected successors selected held inner bowl)
        [cards this]
      =^  cards  inner  (on-poke:ag %noun !>([%native-coding-action-v1 [%run id]]))
      [cards this]
    =^  cards  inner  (on-arvo:ag wire sign-arvo)
    (finish cards)
  ++  on-fail
    |=  [=term =tang]
    =^  cards  inner  (on-fail:ag term tang)
    ?:(=(successors *state:recurring) [cards this] (finish cards))
  --
++  lien-find
  |=  [work=@ux rows=(list enrollment:admission)]
  ^-  (unit enrollment:admission)
  ?~  rows  ~
  ?:  =(work (digest:obs work.i.rows))  `i.rows
  $(rows t.rows)
--
