::  Pure journal mechanics, not an admission or callback authority surface.
::  The owning Gall runtime supplies canonical state and emits cards atomically.
/+  core=cantrip-connected-compile, protocol=vibecoding-compile-protocol,
    worker=vibecoding-compiler-runtime, write=cantrip-connected-write,
    editor=cantrip-editor-save
|%
+$  command  [%cantrip-connected-compile-v1 nonce=@ux result=@ux binding=@ux]
+$  phase  ?(%watching %running %compiled %refused %unknown)
+$  entry
  $:  command=command  snapshot=snapshot:core  phase=phase
      sent=(unit @da)  record=(unit record:core)  error=(unit @tas)
  ==
+$  ledger  (map @ux entry)
+$  transition  [next=ledger cards=(list card:agent:gall)]
+$  result  (each transition @tas)
+$  status  [%cantrip-connected-compile-status-v1 nonce=@ux entry=(unit entry)]
++  command-valid
  |=  c=command
  ^-  ?
  ?&  !=(0 nonce.c)  (lte (met 0 nonce.c) 128)
      !=(0 result.c)  (lte (met 0 result.c) 256)
      !=(0 binding.c)  (lte (met 0 binding.c) 256)
  ==
++  pending
  |=(e=entry |(=(%watching phase.e) =(%running phase.e)))
++  route
  |=(nonce=@ux /connected-compile/(scot %ux nonce))
++  key-for
  |=  w=wire
  ^-  (unit @ux)
  ?.  ?=([%connected-compile @ ~] w)  ~
  =/  key  (slaw %ux i.t.w)
  ?~  key  ~
  ?.  &(!=(0 u.key) (lte (met 0 u.key) 128) =(w (route u.key)))  ~
  key
++  read
  |=([held=ledger key=@ux] [%cantrip-connected-compile-status-v1 key (~(get by held) key)])
++  publish
  |=  [held=ledger key=@ux]
  ^-  card:agent:gall
  [%give %fact ~[/vibecoding/connected-compile/(scot %ux key)] %noun !>((read held key))]
++  close
  |=  e=entry
  ^-  (list card:agent:gall)
  :~  [%pass (route nonce.command.e) %agent [worker.order.snapshot.e %vibecoding-compiler] %leave ~]
      [%pass (route nonce.command.e) %arvo %b %rest expires.order.snapshot.e]
  ==
++  entry-valid
  |=  e=entry
  ^-  ?
  =/  s=snapshot:core  snapshot.e
  ?.  ?&  (command-valid command.e)  (valid:core s)
          =(nonce.command.e nonce.commitment.s)
          =(result.command.e result.commitment.s)
          =(binding.command.e (digest:protocol binding.commitment.s))
          ?~(sent.e %.y &((lte at.order.s u.sent.e) (lth u.sent.e expires.order.s)))
          ?~(error.e %.y &(!=(0 u.error.e) (lte (met 3 u.error.e) 128)))
      ==  %.n
  ?-  phase.e
    %watching  &(=(~ sent.e) =(~ record.e) =(~ error.e))
    %running  &(?=(^ sent.e) =(~ record.e) =(~ error.e))
    %compiled
      ?~  sent.e  %.n
      ?~  record.e  %.n
      ?&  =(~ error.e)  (record-valid:core u.record.e)
          =(s snapshot.u.record.e)  (lte u.sent.e received.u.record.e)
          (lte u.sent.e p.r.beak.compiler.artifact.u.record.e)
      ==
    %refused  &(?=(^ sent.e) =(~ record.e) ?=(^ error.e))
    %unknown  &(=(~ record.e) ?=(^ error.e))
  ==
++  valid
  |=  [our=@p held=ledger]
  ^-  ?
  ?&  (lte ~(wyt by held) 32)
      (lte (lent (skim ~(val by held) pending)) 1)
      %+  levy  ~(tap by held)
      |=  [key=@ux e=entry]
      &(=(key nonce.command.e) =(our owner.order.snapshot.e) (entry-valid e))
  ==
++  linked
  ::  Saved compilation authority must still join the exact owner journals.
  |=  [our=@p held=ledger writes=ledger:write saves=ledger:editor]
  ^-  ?
  ?&  (valid our held)  (valid:write writes saves)
      %+  levy  ~(val by held)
      |=  e=entry
      =/  r  receipt.snapshot.e
      ?&  =(`entry.r (~(get by writes) nonce.command.e))
          =(`saved.r (~(get by saves) nonce.command.e))
      ==
  ==
++  lookup
  |=  [our=@p held=ledger c=command]
  ^-  (each (unit entry) @tas)
  ?.  &((command-valid c) (valid our held))  [%| %request-or-journal-invalid]
  =/  old  (~(get by held) nonce.c)
  ?~  old  [%& ~]
  ?.  =(c command.u.old)  [%| %nonce-conflict]
  [%& old]
++  reserve
  |=  [our=@p now=@da held=ledger c=command s=snapshot:core]
  ^-  result
  =/  prior  (lookup our held c)
  ?:  ?=(%| -.prior)  [%| p.prior]
  ?^  p.prior  [%& [held ~[(publish held nonce.c)]]]
  ?:  (gte ~(wyt by held) 32)  [%| %capacity]
  ?:  (lien ~(val by held) pending)  [%| %compile-in-progress]
  =/  e=entry  [c s %watching ~ ~ ~]
  ?.  &((entry-valid e) =(our owner.order.s) =(now at.order.s))  [%| %snapshot-mismatch]
  =/  next=ledger  (~(put by held) nonce.c e)
  =/  cards=(list card:agent:gall)
    :~  [%pass (route nonce.c) %agent [worker.order.s %vibecoding-compiler] %watch /result/(scot %ux (digest:protocol order.s))]
        [%pass (route nonce.c) %arvo %b %wait expires.order.s]
        (publish next nonce.c)
    ==
  [%& [next cards]]
++  finish
  |=  [held=ledger e=entry next=entry]
  ^-  transition
  ?>  &(=(command.e command.next) =(snapshot.e snapshot.next) (entry-valid next))
  =/  saved=ledger  (~(put by held) nonce.command.e next)
  [saved (weld (close e) ~[(publish saved nonce.command.e)])]
++  stop
  |=  [our=@p now=@da held=ledger key=@ux reason=@tas]
  ^-  transition
  =/  found  (~(get by held) key)
  ?~  found  [held ~]
  =/  e=entry  u.found
  ?.  &((valid our held) (pending e) (lte at.order.snapshot.e now))  [held ~]
  (finish held e e(phase %unknown, record ~, error `reason))
++  send
  ::  Only runtime's exact positive watch ack obtains this current admission.
  |=  [our=@p now=@da held=ledger key=@ux admitted=decision:core]
  ^-  result
  ?.  (valid our held)  [%| %journal-invalid]
  =/  found  (~(get by held) key)
  ?~  found  [%| %missing]
  =/  e=entry  u.found
  ?.  =(%watching phase.e)  [%| %already-dispatched-or-closed]
  ?:  ?=(%| -.admitted)  [%& (stop our now held key p.admitted)]
  ?.  =(snapshot.e snapshot.p.admitted)  [%| %admission-mismatch]
  =/  card  (dispatch:core our now p.admitted)
  ?~  card  [%| %admission-expired]
  =/  next=ledger  (~(put by held) key e(phase %running, sent `now))
  [%& [next ~[u.card (publish next key)]]]
++  receive
  ::  Structural validation only; runtime authenticates Gall source and wex.
  |=  [our=@p src=@p now=@da held=ledger key=@ux status=status:worker]
  ^-  result
  ?.  (valid our held)  [%| %journal-invalid]
  =/  found  (~(get by held) key)
  ?~  found  [%| %missing]
  =/  e=entry  u.found
  =/  s=snapshot:core  snapshot.e
  ?.  &(=(%running phase.e) =(src worker.order.s))  [%| %not-running-or-foreign]
  ?~  sent.e  [%| %not-sent]
  ?.  (lte u.sent.e now)  [%| %future-dispatch]
  ?.  &((lte at.order.s now) (lth now expires.order.s))  [%| %expired]
  ?.  =((digest:protocol order.s) key.status)  [%| %worker-key-mismatch]
  ?~  result.status
    ?:  |(=(%absent phase.status) =(%watching phase.status) =(%running phase.status))
      ?.  =(~ error.status)  [%| %worker-error]
      [%& [held ~]]
    [%| %worker-outcome-unconfirmed]
  =/  out=outcome:protocol  u.result.status
  ?.  =(phase.status -.out)  [%| %worker-phase-mismatch]
  ?:  ?=(%refused -.out)
    ?.  &(!=(0 reason.out) (lte (met 3 reason.out) 128) (lte (met 3 detail.out) 2.048) =(key.status request.out))
      [%| %worker-refusal-invalid]
    [%& (finish held e e(phase %refused, error `reason.out))]
  ?.  =(~ error.status)  [%| %worker-error]
  ?.  ?=(%da -.r.beak.compiler.artifact.out)  [%| %worker-beak-invalid]
  ?.  (lte u.sent.e p.r.beak.compiler.artifact.out)  [%| %worker-before-dispatch]
  =/  compiled  (receive:core our src now s artifact.out)
  ?:  ?=(%| -.compiled)  [%| p.compiled]
  [%& (finish held e e(phase %compiled, record `p.compiled))]
+$  command-v2  [%cantrip-connected-compile-v2 nonce=@ux result=@ux binding=@ux]
+$  entry-v2
  $:  command=command-v2  snapshot=snapshot-v2:core  phase=phase
      sent=(unit @da)  record=(unit record-v2:core)  error=(unit @tas)
  ==
+$  ledger-v2  (map @ux entry-v2)
+$  transition-v2  [next=ledger-v2 cards=(list card:agent:gall)]
+$  result-v2  (each transition-v2 @tas)
+$  status-v2  [%cantrip-connected-compile-status-v2 nonce=@ux entry=(unit entry-v2)]
++  command-valid-v2
  |=  c=command-v2
  (command-valid [%cantrip-connected-compile-v1 nonce.c result.c binding.c])
++  pending-v2
  |=(e=entry-v2 |(=(%watching phase.e) =(%running phase.e)))
++  route-v2
  |=(nonce=@ux /connected-compile-v2/(scot %ux nonce))
++  key-for-v2
  |=  w=wire
  ^-  (unit @ux)
  ?.  ?=([%connected-compile-v2 @ ~] w)  ~
  (key-for [%connected-compile t.w])
++  read-v2
  |=([held=ledger-v2 key=@ux] [%cantrip-connected-compile-status-v2 key (~(get by held) key)])
++  publish-v2
  |=  [held=ledger-v2 key=@ux]
  ^-  card:agent:gall
  [%give %fact ~[/vibecoding/connected-compile-v2/(scot %ux key)] %noun !>((read-v2 held key))]
++  close-v2
  |=  e=entry-v2
  ^-  (list card:agent:gall)
  :~  [%pass (route-v2 nonce.command.e) %agent [worker.order.snapshot.e %vibecoding-compiler] %leave ~]
      [%pass (route-v2 nonce.command.e) %arvo %b %rest expires.order.snapshot.e]
  ==
++  entry-valid-v2
  |=  e=entry-v2
  ^-  ?
  =/  s=snapshot-v2:core  snapshot.e
  ?.  ?&  (command-valid-v2 command.e)  (valid-v2:core s)
          =(nonce.command.e nonce.commitment.s)
          =(result.command.e result.commitment.s)
          =(binding.command.e (digest:protocol binding.commitment.s))
          ?~(sent.e %.y &((lte at.order.s u.sent.e) (lth u.sent.e expires.order.s)))
          ?~(error.e %.y &(!=(0 u.error.e) (lte (met 3 u.error.e) 128)))
      ==  %.n
  ?-  phase.e
    %watching  &(=(~ sent.e) =(~ record.e) =(~ error.e))
    %running  &(?=(^ sent.e) =(~ record.e) =(~ error.e))
    %compiled
      ?~  sent.e  %.n
      ?~  record.e  %.n
      ?&  =(~ error.e)  (record-valid-v2:core u.record.e)
          =(s snapshot.u.record.e)  (lte u.sent.e received.u.record.e)
          (lte u.sent.e p.r.beak.compiler.artifact.u.record.e)
      ==
    %refused  &(?=(^ sent.e) =(~ record.e) ?=(^ error.e))
    %unknown  &(=(~ record.e) ?=(^ error.e))
  ==
++  valid-v2
  |=  [our=@p held=ledger-v2]
  ^-  ?
  ?&  (lte ~(wyt by held) 32)
      (lte (lent (skim ~(val by held) pending-v2)) 1)
      %+  levy  ~(tap by held)
      |=  [key=@ux e=entry-v2]
      &(=(key nonce.command.e) =(our owner.order.snapshot.e) (entry-valid-v2 e))
  ==
++  linked-v2
  |=  [our=@p held=ledger-v2 writes=ledger-v2:write saves=ledger:editor]
  ^-  ?
  ?&  (valid-v2 our held)  (valid-v2:write writes saves)
      %+  levy  ~(val by held)
      |=  e=entry-v2
      =/  r  receipt.snapshot.e
      ?&  =(`entry.r (~(get by writes) nonce.command.e))
          =(`saved.r (~(get by saves) nonce.command.e))
      ==
  ==
++  compatible
  ::  One shared budget and pending slot, even though persisted molds differ.
  |=  [our=@p legacy=ledger modern=ledger-v2]
  ^-  ?
  ?&  (valid our legacy)  (valid-v2 our modern)
      (lte (add ~(wyt by legacy) ~(wyt by modern)) 32)
      (lte (add (lent (skim ~(val by legacy) pending)) (lent (skim ~(val by modern) pending-v2))) 1)
      %+  levy  ~(tap by modern)
      |=  [key=@ux e=entry-v2]
      !(~(has by legacy) key)
  ==
++  lookup-v1-shared
  |=  [our=@p held=ledger modern=ledger-v2 c=command]
  ^-  (each (unit entry) @tas)
  ?.  (compatible our held modern)  [%| %journal-conflict]
  ?:  (~(has by modern) nonce.c)  [%| %version-nonce-used]
  (lookup our held c)
++  lookup-v2
  |=  [our=@p legacy=ledger held=ledger-v2 c=command-v2]
  ^-  (each (unit entry-v2) @tas)
  ?.  &((command-valid-v2 c) (compatible our legacy held))  [%| %request-or-journal-invalid]
  ?:  (~(has by legacy) nonce.c)  [%| %version-nonce-used]
  =/  old  (~(get by held) nonce.c)
  ?~  old  [%& ~]
  ?.  =(c command.u.old)  [%| %nonce-conflict]
  [%& old]
++  reserve-v1-shared
  |=  [our=@p now=@da held=ledger modern=ledger-v2 c=command s=snapshot:core]
  ^-  result
  =/  prior  (lookup-v1-shared our held modern c)
  ?:  ?=(%| -.prior)  [%| p.prior]
  ?^  p.prior  [%& [held ~[(publish held nonce.c)]]]
  ?:  (gte (add ~(wyt by held) ~(wyt by modern)) 32)  [%| %capacity]
  ?:  (lien ~(val by modern) pending-v2)  [%| %compile-in-progress]
  (reserve our now held c s)
++  reserve-v2
  |=  [our=@p now=@da legacy=ledger held=ledger-v2 c=command-v2 s=snapshot-v2:core]
  ^-  result-v2
  =/  prior  (lookup-v2 our legacy held c)
  ?:  ?=(%| -.prior)  [%| p.prior]
  ?^  p.prior  [%& [held ~[(publish-v2 held nonce.c)]]]
  ?:  (gte (add ~(wyt by legacy) ~(wyt by held)) 32)  [%| %capacity]
  ?:  |((lien ~(val by legacy) pending) (lien ~(val by held) pending-v2))  [%| %compile-in-progress]
  =/  e=entry-v2  [c s %watching ~ ~ ~]
  ?.  &((entry-valid-v2 e) =(our owner.order.s) =(now at.order.s))  [%| %snapshot-mismatch]
  =/  next=ledger-v2  (~(put by held) nonce.c e)
  =/  cards=(list card:agent:gall)
    :~  [%pass (route-v2 nonce.c) %agent [worker.order.s %vibecoding-compiler] %watch /result/(scot %ux (digest:protocol order.s))]
        [%pass (route-v2 nonce.c) %arvo %b %wait expires.order.s]
        (publish-v2 next nonce.c)
    ==
  [%& [next cards]]
++  finish-v2
  |=  [held=ledger-v2 e=entry-v2 next=entry-v2]
  ^-  transition-v2
  ?>  &(=(command.e command.next) =(snapshot.e snapshot.next) (entry-valid-v2 next))
  =/  saved=ledger-v2  (~(put by held) nonce.command.e next)
  [saved (weld (close-v2 e) ~[(publish-v2 saved nonce.command.e)])]
++  stop-v2
  |=  [our=@p now=@da held=ledger-v2 key=@ux reason=@tas]
  ^-  transition-v2
  =/  found  (~(get by held) key)
  ?~  found  [held ~]
  =/  e=entry-v2  u.found
  ?.  &((valid-v2 our held) (pending-v2 e) (lte at.order.snapshot.e now))  [held ~]
  (finish-v2 held e e(phase %unknown, record ~, error `reason))
++  send-v2
  |=  [our=@p now=@da legacy=ledger held=ledger-v2 key=@ux admitted=decision-v2:core]
  ^-  result-v2
  ?.  (compatible our legacy held)  [%| %journal-invalid]
  =/  found  (~(get by held) key)
  ?~  found  [%| %missing]
  =/  e=entry-v2  u.found
  ?.  =(%watching phase.e)  [%| %already-dispatched-or-closed]
  ?:  ?=(%| -.admitted)  [%& (stop-v2 our now held key p.admitted)]
  ?.  =(snapshot.e snapshot.p.admitted)  [%| %admission-mismatch]
  =/  card  (dispatch-v2:core our now p.admitted)
  ?~  card  [%| %admission-expired]
  =/  next=ledger-v2  (~(put by held) key e(phase %running, sent `now))
  [%& [next ~[u.card (publish-v2 next key)]]]
++  receive-v2
  |=  [our=@p src=@p now=@da held=ledger-v2 key=@ux status=status:worker]
  ^-  result-v2
  ?.  (valid-v2 our held)  [%| %journal-invalid]
  =/  found  (~(get by held) key)
  ?~  found  [%| %missing]
  =/  e=entry-v2  u.found
  =/  s=snapshot-v2:core  snapshot.e
  ?.  &(=(%running phase.e) =(src worker.order.s))  [%| %not-running-or-foreign]
  ?~  sent.e  [%| %not-sent]
  ?.  (lte u.sent.e now)  [%| %future-dispatch]
  ?.  &((lte at.order.s now) (lth now expires.order.s))  [%| %expired]
  ?.  =((digest:protocol order.s) key.status)  [%| %worker-key-mismatch]
  ?~  result.status
    ?:  |(=(%absent phase.status) =(%watching phase.status) =(%running phase.status))
      ?.  =(~ error.status)  [%| %worker-error]
      [%& [held ~]]
    [%| %worker-outcome-unconfirmed]
  =/  out=outcome:protocol  u.result.status
  ?.  =(phase.status -.out)  [%| %worker-phase-mismatch]
  ?:  ?=(%refused -.out)
    ?.  &(!=(0 reason.out) (lte (met 3 reason.out) 128) (lte (met 3 detail.out) 2.048) =(key.status request.out))
      [%| %worker-refusal-invalid]
    [%& (finish-v2 held e e(phase %refused, error `reason.out))]
  ?.  =(~ error.status)  [%| %worker-error]
  ?.  ?=(%da -.r.beak.compiler.artifact.out)  [%| %worker-beak-invalid]
  ?.  (lte u.sent.e p.r.beak.compiler.artifact.out)  [%| %worker-before-dispatch]
  =/  compiled  (receive-v2:core our src now s artifact.out)
  ?:  ?=(%| -.compiled)  [%| p.compiled]
  [%& (finish-v2 held e e(phase %compiled, record `p.compiled))]
--
