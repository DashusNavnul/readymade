::  Deterministic first-reference/first-live transitions, not evidence admission.
::  The native owner must supply a complete canonical event prefix, stopping
::  at unresolved work. Never sort settlements by arrival or omit a gap.
/+  admission=qpc-measurement-contract, ct=qpc-ct-update,
    decision=qpc-decision
|%
+$  binding
  $:  instrument=@ux  stream=@ux  manifest=@ux
      policy=%first-17-reference-next-disjoint-17-live
      arithmetic=%qpc-ct-update-v1
  ==
+$  point
  [row=measurement-row:admission prediction=@ux settlement=@ux task=@ux checks=@ux]
+$  body
  $%  [%row value=point]
      [%gap evidence=@ux reason=@tas]
      [%outside evidence=@ux]
  ==
+$  event  [order=@ud body=body]
+$  covariance  [denominator=@ud entries=matrix:ct]
+$  epoch
  $:  %qpc-measurement-epoch-v1  id=@ux  binding=binding
      reference=(list point)  covariance=covariance
  ==
+$  comparison
  $:  reference-known=@ud  reference-pass=@ud
      live-known=@ud  live-pass=@ud
      reference-varies=?  live-varies=?  confidence-varies=?
      model=(unit ratio:ct)  constant=(unit ratio:ct)
      judgment=?(%unavailable %uninformative %negative %improved)
  ==
+$  reading
  $:  %qpc-measured-window-v1  id=@ux  epoch=@ux  live=(list point)
      tensor=reading:ct  shape=(unit normalized-shape:ct)
      reference-mixed-law=?  live-mixed-law=?
      comparison=(list comparison)
  ==
+$  state
  $:  %qpc-window-state-v1  binding=binding  next=@ud  ordinal=@ud
      segment=(unit @ux)  segments=(set @ux)  source=(unit @ux)
      events=(map @ud event)  ids=(set @ux)  works=(set @ux)
      buffer=(list point)  reference=(unit epoch)  measured=(unit reading)
  ==
++  digest  |=(v=* ^-(@ux (shax (jam [%qpc-window-v1 v]))))
++  start
  |=  b=binding
  ^-  (each state @tas)
  ?.  (levy `(list @ux)`~[instrument.b stream.b manifest.b] identifier:decision)
    [%| %window-binding-invalid]
  =/  s=state  *state
  [%& s(binding b)]
++  point-valid
  |=  p=point
  &((row-valid:admission row.p) (levy `(list @ux)`~[prediction.p settlement.p task.p checks.p] identifier:decision))
++  reports
  |=(rows=(list point) ^-(window:ct (turn rows |=(p=point confidence.row.p))))
++  mixed-law
  |=  rows=(list point)
  ^-  ?
  ?~  rows  %.n
  (lien `(list point)`rows |=(p=point !=(law.row.p law.row.i.rows)))
++  seal
  ::  Only +append's first uninterrupted 17-row block reaches this gate.
  |=  [b=binding rows=(list point)]
  ^-  epoch
  =/  ps=window:ct  (reports rows)
  ?>  (valid:ct 2 16 ps)
  =/  axes=(list @ud)  ~[0 1]
  =/  entries=matrix:ct
    %+  turn  axes
    |=  a=@ud
    %+  turn  axes
    |=  z=@ud
    (pro:si --2 (numerator:ct ps a z))
  ::  K_reference = 2 * raw numerator / (W^2 * confidence-scale^2).
  =/  k=covariance  [(mul 256 (mul scale:ct scale:ct)) entries]
  =/  value=epoch  [%qpc-measurement-epoch-v1 0x0 b rows k]
  value(id (digest value))
++  score
  |=  [reference=(list point) live=(list point) axis=@ud]
  ^-  comparison
  =/  known
    |=  rows=(list point)
    ^-  (list [confidence=@ud passed=?])
    %+  murn  rows
    |=  p=point
    =/  o=outcome:decision  (snag axis outcomes.row.p)
    ?:  =(%unknown verdict.o)  ~
    `[(snag axis confidence.row.p) =(%pass verdict.o)]
  =/  prior=(list [confidence=@ud passed=?])  (known reference)
  =/  now=(list [confidence=@ud passed=?])  (known live)
  =/  rc=@ud  (lent prior)
  =/  lc=@ud  (lent now)
  =/  rp=@ud  (lent (skim prior |=(v=[confidence=@ud passed=?] passed.v)))
  =/  lp=@ud  (lent (skim now |=(v=[confidence=@ud passed=?] passed.v)))
  =/  varying=?
    ?~  now  %.n
    (lien `(list [confidence=@ud passed=?])`now |=(v=[confidence=@ud passed=?] !=(confidence.v confidence.i.now)))
  =/  model=(unit ratio:ct)
    ?:  =(0 lc)  ~
    =/  sum=@ud
      %+  roll  now
      |=  [v=[confidence=@ud passed=?] total=@ud]
      =/  error=@ud
        (abs:si (dif:si (sun:si confidence.v) (sun:si ?:(passed.v scale:ct 0))))
      (add total (mul error error))
    `[sum (mul lc (mul scale:ct scale:ct))]
  =/  constant=(unit ratio:ct)
    ?:  |(=(0 rc) =(0 lc))  ~
    `[(add (mul lp (mul (sub rc rp) (sub rc rp))) (mul (sub lc lp) (mul rp rp))) (mul lc (mul rc rc))]
  =/  rv=?  &((gth rp 0) (lth rp rc))
  =/  lv=?  &((gth lp 0) (lth lp lc))
  =/  judgment=?(%unavailable %uninformative %negative %improved)
    ?~  model  %unavailable
    ?~  constant  %unavailable
    ?.  &(rv lv varying)  %uninformative
    ?:  (lth (mul num.u.model den.u.constant) (mul num.u.constant den.u.model))
      %improved
    %negative
  [rc rp lc lp rv lv varying model constant judgment]
++  measure
  |=  [e=epoch live=(list point)]
  ^-  reading
  =/  computed  (measure:ct 2 16 (reports live) (reports reference.e))
  ?>  ?=(%& -.computed)
  =/  compared=(list comparison)
    (turn `(list @ud)`~[0 1] |=(axis=@ud (score reference.e live axis)))
  =/  value=reading
    [%qpc-measured-window-v1 0x0 id.e live p.computed (shape:ct p.computed) (mixed-law reference.e) (mixed-law live) compared]
  value(id (digest value))
++  append
  ::  State comes from +start/+append, or must pass +valid after loading.
  ::  There is no command that admits sender-supplied rows as observations.
  |=  [s=state e=event]
  ^-  (each state @tas)
  =/  old  (~(get by events.s) order.e)
  ?^  old  ?:(=(e u.old) [%& s] [%| %window-event-conflict])
  ?.  =(order.e next.s)  [%| %window-event-order]
  ?^  measured.s  [%| %window-complete]
  ?:  (gte next.s 256)  [%| %window-capacity]
  =/  next=state  s(next +(next.s), events (~(put by events.s) order.e e))
  ?:  ?=(%outside -.body.e)
    ?.  (identifier:decision evidence.body.e)  [%| %window-evidence-invalid]
    [%& next]
  ?:  ?=(%gap -.body.e)
    ?.  &((identifier:decision evidence.body.e) !=(%$ reason.body.e))
      [%| %window-evidence-invalid]
    [%& next(ordinal +(ordinal.s), buffer ~, segment ~, source ~)]
  =/  p=point  value.body.e
  ?.  (point-valid p)  [%| %window-point-invalid]
  ?.  =(ordinal.s step.row.p)  [%| %window-report-order]
  ?:  |((~(has in ids.s) id.row.p) (~(has in works.s) work.row.p))
    [%| %window-report-reused]
  ?^  segment.s
    ?.  &(=(u.segment.s segment.row.p) =(source.s `prediction.p))
      [%| %window-continuity]
    (record next p)
  ?:  (~(has in segments.s) segment.row.p)  [%| %window-segment-reused]
  (record next p)
++  record
  |=  [s=state p=point]
  ^-  (each state @tas)
  =/  buffer=(list point)  (weld buffer.s ~[p])
  =.  s
    s(ordinal +(ordinal.s), segment `segment.row.p, source `resulting-source.row.p, segments (~(put in segments.s) segment.row.p), ids (~(put in ids.s) id.row.p), works (~(put in works.s) work.row.p), buffer buffer)
  ?:  (lth (lent buffer) 17)  [%& s]
  ?>  =(17 (lent buffer))
  ?~  reference.s
    [%& s(reference `(seal binding.s buffer), buffer ~)]
  [%& s(measured `(measure u.reference.s buffer), buffer ~)]
++  replay
  |=  [b=binding events=(list event)]
  ^-  (each state @tas)
  =/  begun  (start b)
  ?:  ?=(%| -.begun)  begun
  =/  held=state  p.begun
  |-  ^-  (each state @tas)
  ?~  events  [%& held]
  =/  next  (append held i.events)
  ?:  ?=(%| -.next)  next
  $(held p.next, events t.events)
++  valid
  |=  s=state
  ^-  ?
  ?.  &((lte next.s 256) =(next.s ~(wyt by events.s)))  %.n
  =/  events=(list event)
    (sort ~(val by events.s) |=([a=event b=event] (lth order.a order.b)))
  =/  got  (replay binding.s events)
  =([%& s] got)
--
