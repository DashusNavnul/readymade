::  Eyre JSON decoder. Capability permits only claiming/submitting proposals.
/-  c=cli-inference
/+  law=cli-inference, cr=codex-responses
|%
++  transport
  |=  [local=? req=inbound-request:eyre]
  ^-  ?
  ?:  secure.req  %.y
  ?.  local  %.n
  ?-  -.address.req
    %ipv4  =(.127.0.0.1 +.address.req)
    %ipv6  =(1 +.address.req)
  ==
++  text
  |=  [object=json key=@t maximum=@ud]
  ^-  @t
  =/  value=@t  (need (string:cr object key))
  ?>  (lte (met 3 value) maximum)
  value
++  number
  |=  [object=json key=@t aura=?(%uv %ux)]
  ^-  @
  =/  value=@t  (text object key 128)
  =/  parsed=@  (need (slaw aura value))
  ?>  &(!=(0 parsed) (lte (met 0 parsed) 256) =(value (scot aura parsed)))
  parsed
++  control
  |=  s=state:c
  ^-  json
  =/  bindings=(list json)
    %+  turn  ~(val by bindings.s)
    |=  b=binding:c
    (pairs:enjs:format ~[['key' s+key.b] ['backend' s+backend.b] ['connector' s+connector.b] ['active' b+active.b]])
  =/  setup=(list json)
    :~  s+'Download the source JSON from this ship while signed in as its owner. Validate its manifest, paths, byte counts and hashes; save files into a new empty directory without overwriting files or following symlinks.'
        s+'On your Mac with Rust installed, run cargo build --locked --release --bin pataphor-connect in that directory. Cargo downloads the locked public dependencies separately.'
        s+'Sign in to Codex or Claude Code with your existing subscription. Run target/release/pataphor-connect --help, then pair using --pair, your actual ship HTTPS origin and a private --login-code-file. Keep credentials and connector state outside the empty proposal workspace.'
        s+'After pairing, run a finite connector command for an owner-approved native coding request. CLI output proposes changes; Urbit validates permissions and performs native tools. Setup does not grant deployment authority.'
    ==
  %-  pairs:enjs:format
  :~  ['protocol' s+'pataphor-cli-v1']
      ['nonce' s+(scot %uv nonce.s)]
      ['bindings' a+bindings]
      ['authority' s+'Urbit owns native tools. CLI proposes JSON only.']
      ['source' s+'/apps/pataphor-cli/source']
      ['platform' s+'macOS locally proved; Windows, Linux and independent-planet acceptance remain unverified.']
      ['requirements' s+'Rust/cargo and an existing Codex or Claude Code subscription login. No provider API key or copied OAuth token.']
      ['setup' a+setup]
  ==
++  handle
  ::  App supplies native owner authentication and fresh native random atoms.
  |=  [s=state:c owner=? endpoint=@t raw=@t capability=@uv next=@uv]
  ^-  change:c
  ?:  (gth (met 3 raw) 4.194.304)  (refused:law s %body-too-large)
  =/  parsed
    %-  mole
    |.
    =/  object=json  (need (de:json:html raw))
    ?>  ?=(%o -.object)
    ?:  =('/apps/pataphor-cli/pair' endpoint)
      ?>  =(4 ~(wyt by p.object))
      =/  backend=@t  (text object 'backend' 16)
      ?>  ?=(backend:c backend)
      (pair:law s owner (number object 'nonce' %uv) (text object 'key' 64) backend (text object 'connector' 64) capability next)
    ?:  =('/apps/pataphor-cli/revoke' endpoint)
      ?>  =(2 ~(wyt by p.object))
      (revoke:law s owner (number object 'nonce' %uv) (text object 'key' 64) next)
    =/  connector=@t  (text object 'connector' 64)
    =/  cap=@uv  (number object 'capability' %uv)
    ?:  =('/apps/pataphor-cli/claim' endpoint)
      ?>  =(3 ~(wyt by p.object))
      (claim:law s connector cap (number object 'nonce' %ux))
    =/  id=@ux  (number object 'request' %ux)
    =/  token=@ux  (number object 'claim' %ux)
    ?:  =('/apps/pataphor-cli/result' endpoint)
      ?>  =(5 ~(wyt by p.object))
      (result:law s connector cap id token (text object 'output' 2.097.152))
    ?>  =('/apps/pataphor-cli/failure' endpoint)
    ?>  =(5 ~(wyt by p.object))
    =/  reason=@t  (text object 'reason' 32)
    ?>  ?=(failure:c reason)
    (failure:law s connector cap id token reason)
  ?~  parsed  (refused:law s %malformed-request)
  u.parsed
++  ready-input
  :: New endpoints accept identifiers only, never caller authority or clocks.
  |=  raw=@t
  ^-  (unit ready-input:c)
  %-  mole
  |.
  ?>  (lte (met 3 raw) 4.096)
  =/  object=json  (need (de:json:html raw))
  ?>  &(?=(%o -.object) =(5 ~(wyt by p.object)))
  [(text object 'connector' 64) (number object 'capability' %uv) (number object 'intent' %ux) (number object 'window' %ux) (number object 'nonce' %ux)]
++  next-input
  |=  raw=@t
  ^-  (unit next-input:c)
  %-  mole
  |.
  ?>  (lte (met 3 raw) 4.096)
  =/  object=json  (need (de:json:html raw))
  ?>  &(?=(%o -.object) =(3 ~(wyt by p.object)))
  [(text object 'connector' 64) (number object 'capability' %uv) (number object 'window' %ux)]
++  claim-input
  |=  raw=@t
  ^-  (unit claim-input:c)
  %-  mole
  |.
  ?>  (lte (met 3 raw) 4.096)
  =/  object=json  (need (de:json:html raw))
  ?>  &(?=(%o -.object) =(3 ~(wyt by p.object)))
  [(text object 'connector' 64) (number object 'capability' %uv) (number object 'nonce' %ux)]
++  exact-input
  |=  raw=@t
  ^-  (unit exact-input:c)
  %-  mole
  |.
  ?>  (lte (met 3 raw) 4.096)
  =/  object=json  (need (de:json:html raw))
  ?>  &(?=(%o -.object) =(6 ~(wyt by p.object)))
  [(text object 'connector' 64) (number object 'capability' %uv) (number object 'intent' %ux) (number object 'request' %ux) (number object 'readiness' %ux) (number object 'nonce' %ux)]
--
