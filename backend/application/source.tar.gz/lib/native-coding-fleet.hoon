::  Viki-owned queue transitions with canonical source reads at assignment.
::  Persist the returned
::  organ atomically before interpreting effects. Reload emits no dispatch.
::  No timers: unknown/paused assignments keep their seat, desk and paths.
/-  nf=native-coding-fleet, nc=native-coding, vr=glass-moon-route,
    ss=seat-session, mse=glass-moon-executor, ws=workspace
/+  read=native-coding-fleet-read, routes=viki-route, executor=glass-moon-executor,
    allocation=viki-glass-route-allocation, project=native-coding-project,
    native-route=native-coding-route
|%
++  empty  ^-  organ:nf  [%native-coding-fleet-v1 0 ~ ~]
++  digest
  |=  noun=*
  ^-  @ux
  (shax (jam [%native-coding-fleet-v1 noun]))
++  held
  |=  e=entry:nf
  ^-  ?
  &(?=(^ assignment.e) !released.e)
++  occupied
  |=  [o=organ:nf moon=@p]
  ^-  ?
  %+  lien  ~(val by tasks.o)
  |=  e=entry:nf
  ?.  (held e)  %.n
  ?>  ?=(^ assignment.e)
  =(moon worker.u.assignment.e)
++  changed
  |=  [o=organ:nf effects=(list effect:nf)]
  ^-  transition:nf
  [o(next +(next.o)) (weld effects `(list effect:nf)`~[[%waterwheel-wake +(next.o)]])]
++  task-valid
  |=  [our=@p t=task:nf]
  ^-  ?
  ?&  !=(0 id.t)  (lte (met 0 id.t) 256)
      =(our actor.context.t)  =(our owner.source.context.t)  =(our owner.accepted.t)
      !=(0 session.context.t)  !=(0 request.context.t)  !=(0 configuration.context.t)
      (lte (met 0 session.context.t) 256)  (lte (met 0 request.context.t) 256)
      !=('' project.context.t)  (lte (met 3 project.context.t) 128)
      (revision-valid:project source.context.t)  (revision-valid:project accepted.t)
      !=(desk.source.context.t desk.accepted.t)
      !=('' objective.t)  (lte (met 3 objective.t) 8.192)
      (lte ~(wyt in dependencies.t) 32)  !(~(has in dependencies.t) id.t)
      (lte ~(wyt in paths.t) 64)
      (levy ~(tap in paths.t) |=(p=path &(?=(^ p) (path-valid:project p))))
  ==
++  enqueue
  ::  Dependencies must already exist and cannot be edited: ordering is a DAG
  ::  by construction. A repeated exact enqueue does not wake or resend work.
  |=  [our=@p actor=@p o=organ:nf t=task:nf]
  ^-  (each transition:nf @tas)
  ?.  &(=(our actor) (task-valid our t))  [%| %fleet-task-invalid]
  =/  prior  (~(get by tasks.o) id.t)
  ?^  prior
    ?:  =(t task.u.prior)  [%& [o ~]]
    [%| %fleet-task-id-conflict]
  ?:  (gte ~(wyt by tasks.o) 256)  [%| %fleet-task-capacity]
  ?.  %+  levy  ~(tap in dependencies.t)
      |=  id=@ux
      =/  found  (~(get by tasks.o) id)
      ?~  found  %.n
      =(project.context.t project.context.task.u.found)
    [%| %fleet-dependency-missing]
  ::  Request identity is never reused under another task id.
  ?:  (lien ~(val by tasks.o) |=(e=entry:nf &(=(session.context.t session.context.task.e) =(request.context.t request.context.task.e))))
    [%| %fleet-request-reused]
  =/  e=entry:nf  [t next.o %queued ~ ~ ~ %.n]
  [%& (changed o(tasks (~(put by tasks.o) id.t e)) ~[[%retain [%native-coding-fleet-enqueued-v1 t]]])]
++  worker-matches
  |=  [our=@p r=moon-route:vr b=binding:mse]
  ^-  ?
  ?.  (binding-valid:native-route b)  %.n
  ?.  ?=([%multiplayer-session-executor-binding-v2 *] -.b)  %.n
  ?&  =(our peer.b)  =(session-id.r local-session.b)
      =(selected.b (spec-for:routes r))  =(route.b (commitment:routes r))
  ==
++  bind
  ::  Existing session/route law remains strict. No provider label establishes
  ::  readiness. A fresh exact native executor inspection is required.
  |=  [our=@p actor=@p o=organ:nf w=world:read r=moon-route:vr b=binding:mse roles=(set role:nf)]
  ^-  (each transition:nf @tas)
  ?.  &(=(our actor) =(our owner.w) (route:read w r) (worker-matches our r b) ?=(^ roles))
    [%| %fleet-binding-invalid]
  =/  seat=seat:ss  seat.seat-session.r
  =/  moon=@p  moon.seat-session.r
  =/  old  (~(get by workers.o) seat)
  =/  unchanged=?
    ?~  old  %.n
    &(=(r route.u.old) =(b binding.u.old) =(roles roles.u.old))
  ?:  unchanged  [%& [o ~]]
  ?:  (occupied o moon)  [%| %fleet-worker-occupied]
  =/  prior-occupied=?
    ?~  old  %.n
    (occupied o moon.seat-session.route.u.old)
  ?:  prior-occupied  [%| %fleet-seat-occupied]
  ?:  (lien ~(tap by workers.o) |=([key=seat:ss value=worker:nf] &(=(moon moon.seat-session.route.value) !=(seat key))))
    [%| %fleet-moon-already-bound]
  =/  generation=@ud  ?~(old 1 +(generation.u.old))
  =/  request=@ux  (digest [%inspect next.o seat generation r b])
  =/  worker=worker:nf  [r b generation roles 1 request ~]
  [%& (changed o(workers (~(put by workers.o) seat worker)) ~[[%inspect-worker seat moon generation request]])]
++  inspect
  ::  Explicit refresh after release or an unavailable observation. There is
  ::  no polling loop; each new nonce invalidates all older status replies.
  |=  [our=@p actor=@p o=organ:nf seat=seat:ss]
  ^-  (each transition:nf @tas)
  ?.  =(our actor)  [%| %fleet-foreign-owner]
  =/  found  (~(get by workers.o) seat)
  ?~  found  [%| %fleet-worker-missing]
  =/  worker=worker:nf  u.found
  =/  moon=@p  moon.seat-session.route.worker
  ?:  (occupied o moon)  [%| %fleet-worker-occupied]
  =/  request=@ux  (digest [%inspect next.o seat generation.worker route.worker binding.worker])
  =/  wide114=worker:nf  worker
  =/  worker=worker:nf  wide114(inspection request, observed ~)
  [%& (changed o(workers (~(put by workers.o) seat worker)) ~[[%inspect-worker seat moon generation.worker request]])]
++  confirm
  ::  App must also bind the Gall wire and source app to this exact inspection.
  |=  [o=organ:nf src=@p app=@tas seat=seat:ss generation=@ud response=event:mse]
  ^-  (each transition:nf @tas)
  =/  found  (~(get by workers.o) seat)
  ?~  found  [%| %fleet-worker-missing]
  =/  worker=worker:nf  u.found
  ?.  &(=(src moon.seat-session.route.worker) =(%multiplayer-session-executor app) =(generation generation.worker) !=(0 inspection.worker) =(request.response inspection.worker))
    [%| %fleet-inspection-mismatch]
  ?:  ?=(^ observed.worker)  [%| %fleet-inspection-already-used]
  =/  wide126=worker:nf  worker
  =/  worker=worker:nf  wide126(observed `response)
  [%& (changed o(workers (~(put by workers.o) seat worker)) ~)]
++  observed-free
  |=  worker=worker:nf
  ^-  ?
  ?~  observed.worker  %.n
  =/  event=event:mse  u.observed.worker
  &((binding-status-confirmed:executor inspection.worker binding.worker request.event enabled.event binding.event) =(0 jobs.event) =(1 capacity.worker))
++  dependencies-done
  |=  [o=organ:nf t=task:nf]
  ^-  ?
  %+  levy  ~(tap in dependencies.t)
  |=  id=@ux
  =/  found  (~(get by tasks.o) id)
  ?~  found  %.n
  &(=(%completed phase.u.found) released.u.found)
++  ready
  ::  Stable enqueue order among tasks whose dependencies actually completed.
  |=  o=organ:nf
  ^-  (list entry:nf)
  =/  pending=(list entry:nf)
    (skim ~(val by tasks.o) |=(e=entry:nf &(=(%queued phase.e) (dependencies-done o task.e))))
  (sort pending |=([a=entry:nf b=entry:nf] (lth ordinal.a ordinal.b)))
++  order-workers
  ::  Reuse Viki's allocation policy, including occupied legacy assignments.
  |=  [o=organ:nf w=world:read t=task:nf]
  ^-  (each (list moon-route:vr) @tas)
  =/  usage=usage:allocation
    =/  entries=(list entry:nf)  ~(val by tasks.o)
    =/  u=usage:allocation  legacy.w
    |-  ^-  usage:allocation
    ?~  entries  u
    =/  e=entry:nf  i.entries
    ?~  assignment.e  $(entries t.entries)
    $(entries t.entries, u (observe:allocation u worker.u.assignment.e released.e))
  =/  choices=(list moon-route:vr)
    %+  murn  ~(val by workers.o)
    |=  worker=worker:nf
    ?.  &((observed-free worker) (~(has in roles.worker) role.t) (route:read w route.worker))  ~
    =/  claimed  (claim:read w moon.seat-session.route.worker desk.source.context.t)
    ?:  ?=(%| -.claimed)  ~
    `route.worker
  (order:allocation choices usage)
++  conflict
  ::  Whole working desks are exclusive while held, including unknowns.
  ::  Separate private desks may reserve the same project-relative paths.
  ::  Landing serialization and exact accepted-revision checks remain Cantrip's.
  |=  [t=task:nf reservations=(list reservation:nc)]
  ^-  ?
  %+  lien  reservations
  |=  r=reservation:nc
  ?&  =(%held status.r)
      =(owner.source.context.t owner.source.context.r)
      =(desk.source.context.t desk.source.context.r)
  ==
++  reservations
  |=  o=organ:nf
  ^-  (list reservation:nc)
  %+  murn  ~(val by tasks.o)
  |=  e=entry:nf
  ?.  (held e)  ~
  ?>  ?=(^ assignment.e)
  `reservation.u.assignment.e
++  assign
  ::  Source was read at this event by read:source. This gate calls that native
  ::  read itself; a claimed desk or readiness field cannot stand in for it.
  |=  [our=@p actor=@p o=organ:nf w=world:read p=project:nc id=@ux seat=seat:ss]
  ^-  (each transition:nf @tas)
  ?.  &(=(our actor) =(our owner.w))  [%| %fleet-foreign-owner]
  =/  task  (~(get by tasks.o) id)
  =/  chosen  (~(get by workers.o) seat)
  ?~  task  [%| %fleet-task-missing]
  ?~  chosen  [%| %fleet-worker-missing]
  =/  e=entry:nf  u.task
  =/  worker=worker:nf  u.chosen
  =/  t=task:nf  task.e
  =/  moon=@p  moon.seat-session.route.worker
  ?.  &(=(%queued phase.e) ?=(~ assignment.e) (dependencies-done o t))
    [%| %fleet-task-not-dispatchable]
  ?.  &((route:read w route.worker) (observed-free worker) (~(has in roles.worker) role.t))
    [%| %fleet-worker-not-observed]
  ?:  |((occupied o moon) (~(has in occupied.legacy.w) moon))  [%| %fleet-worker-occupied]
  =/  source  (source:read w p t)
  ?:  ?=(%| -.source)  [%| p.source]
  =/  claim  (claim:read w moon desk.source.context.t)
  ?:  ?=(%| -.claim)  [%| p.claim]
  ?.  =(base.p.claim desk.accepted.t)  [%| %fleet-workspace-base]
  ?:  (conflict t (weld (reservations o) held.w))  [%| %fleet-file-claimed]
  =/  reservation=reservation:nc  [%native-coding-reservation-v1 context.t p.claim paths.t %held]
  =/  key=@ux  (digest [%assignment id context.t seat moon generation.worker (commitment:routes route.worker) inspection.worker reservation])
  =/  a=assignment:nf
    [id context.t seat moon generation.worker (commitment:routes route.worker) route.worker request.context.t inspection.worker reservation key]
  =/  wide=entry:nf  e
  =/  e=entry:nf  wide(phase %assigned, assignment `a)
  =/  wide220=worker:nf  worker
  =/  worker=worker:nf  wide220(inspection 0x0, observed ~)
  =.  o  o(tasks (~(put by tasks.o) id e), workers (~(put by workers.o) seat worker))
  [%& (changed o ~[[%retain [%native-coding-fleet-assigned-v1 a]] [%dispatch a t route.worker]])]
++  started
  |=  [o=organ:nf src=@p a=assignment:nf]
  ^-  (each transition:nf @tas)
  =/  found  (~(get by tasks.o) task.a)
  ?~  found  [%| %fleet-task-missing]
  =/  e=entry:nf  u.found
  ?.  &(=(src worker.a) =(`a assignment.e) (held e) =(%assigned phase.e))
    [%| %fleet-start-mismatch]
  =/  wide231=entry:nf  e
  =/  e=entry:nf  wide231(phase %running)
  [%& (changed o(tasks (~(put by tasks.o) task.a e)) ~)]
++  report
  ::  Peer evidence can request review, never complete a task or release claims.
  |=  [o=organ:nf src=@p a=assignment:nf candidate=(unit @ux) evidence=(list @ux)]
  ^-  (each transition:nf @tas)
  =/  found  (~(get by tasks.o) task.a)
  ?~  found  [%| %fleet-task-missing]
  =/  e=entry:nf  u.found
  ?.  &(=(src worker.a) =(`a assignment.e) (held e) (lte (lent evidence) 64))
    [%| %fleet-result-mismatch]
  ?.  ?=(?(%assigned %running %unknown %paused) phase.e)  [%| %fleet-result-already-retained]
  =/  wide=entry:nf  e
  =/  e=entry:nf  wide(phase %review, candidate candidate, evidence evidence)
  [%& (changed o(tasks (~(put by tasks.o) task.a e)) ~[[%retain [%native-coding-fleet-result-v1 a candidate evidence]]])]
++  control
  |=  [our=@p actor=@p o=organ:nf id=@ux kind=?(%pause %unknown %observe %cancel)]
  ^-  (each transition:nf @tas)
  ?.  =(our actor)  [%| %fleet-foreign-owner]
  =/  found  (~(get by tasks.o) id)
  ?~  found  [%| %fleet-task-missing]
  =/  e=entry:nf  u.found
  ?:  &(=(%queued phase.e) =(%cancel kind))
    [%& (changed o(tasks (~(put by tasks.o) id e(phase %cancelled, released %.y))) ~)]
  ?.  (held e)  [%| %fleet-task-not-assigned]
  ?>  ?=(^ assignment.e)
  =/  a=assignment:nf  u.assignment.e
  ?:  =(%observe kind)  [%& [o ~[[%observe a]]]]
  =/  wide259=entry:nf  e
  =/  e=entry:nf  wide259(phase ?:(=(%pause kind) %paused %unknown))
  =/  effects=(list effect:nf)  ?:(=(%cancel kind) ~[[%cancel a]] ~)
  [%& (changed o(tasks (~(put by tasks.o) id e)) effects)]
++  resume
  ::  Explicit owner continuation only. Unknown outcomes cannot be resumed.
  |=  [our=@p actor=@p o=organ:nf id=@ux]
  ^-  (each transition:nf @tas)
  ?.  =(our actor)  [%| %fleet-foreign-owner]
  =/  found  (~(get by tasks.o) id)
  ?~  found  [%| %fleet-task-missing]
  =/  e=entry:nf  u.found
  ?.  &((held e) =(%paused phase.e))  [%| %fleet-task-not-paused]
  [%& (changed o(tasks (~(put by tasks.o) id e(phase %running))) ~)]
++  continue-reviewed
  ::  Only Viki's canonical review adapter calls this after a retained native
  ::  continuation. Keep the exact assignment and every reservation unchanged.
  |=  [our=@p actor=@p o=organ:nf a=assignment:nf evidence=@ux]
  ^-  (each transition:nf @tas)
  ?.  &(=(our actor) !=(0 evidence))  [%| %fleet-continuation-invalid]
  =/  found  (~(get by tasks.o) task.a)
  ?~  found  [%| %fleet-task-missing]
  =/  e=entry:nf  u.found
  ?.  &((held e) =(`a assignment.e) =(%review phase.e))
    [%| %fleet-continuation-not-reviewed]
  =/  wide283=entry:nf  e
  =/  e=entry:nf  wide283(phase %running)
  [%& (changed o(tasks (~(put by tasks.o) task.a e)) ~[[%retain [%native-coding-fleet-continued-v1 a evidence]]])]
++  settle
  ::  Viki's exact settlement must already be owner-attributed in Graf.
  ::  Unknown is never interpreted as cancellation or permission to rebind.
  |=  [our=@p actor=@p o=organ:nf w=world:read s=settlement:nf]
  ^-  (each transition:nf @tas)
  ?.  &(=(our actor) =(our owner.w))  [%| %fleet-foreign-owner]
  =/  found  (~(get by tasks.o) task.s)
  ?~  found  [%| %fleet-task-missing]
  =/  e=entry:nf  u.found
  ?.  (held e)  [%| %fleet-task-not-held]
  ?>  ?=(^ assignment.e)
  ?.  &(=(id.u.assignment.e assignment.s) ?=(^ evidence.s) (lte (lent evidence.s) 64))
    [%| %fleet-settlement-mismatch]
  ?.  (lien owned.w |=(fact=* =(fact [%native-coding-fleet-settlement-v1 s])))
    [%| %fleet-settlement-unretained]
  ?:  &(=(%completed verdict.s) !=(%review phase.e))  [%| %fleet-result-not-reviewed]
  =/  phase=phase:nf
    ?-  verdict.s
      %completed  %completed
      %refused  %refused
      %cancelled  %cancelled
      %not-dispatched  %refused
    ==
  =/  a=assignment:nf  u.assignment.e
  =/  wide309=entry:nf  e
  =/  e=entry:nf  wide309(phase phase, released %.y, evidence evidence.s)
  [%& (changed o(tasks (~(put by tasks.o) task.s e)) ~[[%retain [%native-coding-fleet-released-v1 a reservation.a(status %released) s]]])]
++  recover
  ::  After reload, observe retained assignments; never rebuild dispatch cards.
  |=  o=organ:nf
  ^-  (list effect:nf)
  %+  murn  ~(val by tasks.o)
  |=  e=entry:nf
  ?.  (held e)  ~
  ?>  ?=(^ assignment.e)
  `[%observe u.assignment.e]
++  valid
  ::  Restore gate for Viki's new versioned organ. No liveness claim here;
  ::  current routes, grants and Clay source are re-read before assignment.
  |=  [our=@p o=organ:nf]
  ^-  ?
  ?.  &((lte ~(wyt by workers.o) 9) (lte ~(wyt by tasks.o) 256))  %.n
  ?.  %+  levy  ~(tap by workers.o)
      |=  [key=seat:ss worker=worker:nf]
      ?&  =(key seat.seat-session.route.worker)  =(our parent.seat-session.route.worker)
          (worker-matches our route.worker binding.worker)
          (gth generation.worker 0)  =(1 capacity.worker)  ?=(^ roles.worker)
          ?~  observed.worker  %.y
          &(!=(0 inspection.worker) =(request.u.observed.worker inspection.worker))
      ==
    %.n
  =/  entries=(list entry:nf)  ~(val by tasks.o)
  =/  identities=(set [@ux @ux])
    (silt (turn entries |=(e=entry:nf [session.context.task.e request.context.task.e])))
  ?.  =(~(wyt in identities) (lent entries))  %.n
  %+  levy  ~(tap by tasks.o)
  |=  [key=@ux e=entry:nf]
  ?.  &(=(key id.task.e) (task-valid our task.e) (lth ordinal.e next.o) (lte (lent evidence.e) 64))  %.n
  ?.  %+  levy  ~(tap in dependencies.task.e)
      |=  id=@ux
      =/  dependency  (~(get by tasks.o) id)
      ?~  dependency  %.n
      &((lth ordinal.u.dependency ordinal.e) =(project.context.task.e project.context.task.u.dependency))
    %.n
  ?~  assignment.e
    |(&(=(%queued phase.e) !released.e) &(=(%cancelled phase.e) released.e))
  =/  a=assignment:nf  u.assignment.e
  ?.  ?&  =(task.a key)  =(context.a context.task.e)  =(request.a request.context.a)
          =(route.a (commitment:routes route-value.a))
          =(seat.a seat.seat-session.route-value.a)  =(worker.a moon.seat-session.route-value.a)
          =(context.a context.reservation.a)  =(paths.task.e paths.reservation.a)
          =(worker.a holder.workspace.reservation.a)
          =(desk.source.context.a fork.workspace.reservation.a)
          =(desk.accepted.task.e base.workspace.reservation.a)
          =(id.a (digest [%assignment key context.a seat.a worker.a generation.a route.a inspection.a reservation.a]))
      ==  %.n
  ?:  released.e  ?=(?(%completed %refused %cancelled) phase.e)
  ?.  ?=(?(%assigned %running %review %unknown %paused) phase.e)  %.n
  =/  current  (~(get by workers.o) seat.a)
  ?~  current  %.n
  ?.  &(=(generation.a generation.u.current) =(route-value.a route.u.current))  %.n
  =/  others=(list reservation:nc)
    %+  murn  entries
    |=  other=entry:nf
    ?.  &(!=(id.task.other key) (held other))  ~
    ?>  ?=(^ assignment.other)
    `reservation.u.assignment.other
  !(conflict task.e others)
--
