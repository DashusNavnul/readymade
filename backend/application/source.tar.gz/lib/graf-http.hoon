::  /lib/graf-http.hoon
::
::  Bounded HTTP projection for graf.  The root is constant work.  Kind reads
::  retain deterministic set order but render at most eight facts per event;
::  callers continue with /by-kind/<kind>/<offset>/<limit>.  This keeps a large
::  fact floor from monopolizing Arvo while preserving explicit deeper reads.
::
/+  graf-substrate, graf-search
=,  graf-substrate
=,  graf-search
|%
++  max-page-items  8
::
++  fact-json
  |=  fact=*
  ^-  json
  s+(crip "{<fact>}")
::
++  root-json
  ^-  json
  %-  pairs:enjs:format
  :~  ['ok' b+%.y]
      ['surface' s+'graf-http-v2']
      ['status' s+'live']
      ['by-kind-path' s+'/graf/by-kind/<kind>/<offset>/<limit>']
      ['default-page-items' (numb:enjs:format max-page-items)]
      ['max-page-items' (numb:enjs:format max-page-items)]
  ==
::
++  error-json
  |=  message=@t
  ^-  json
  %-  pairs:enjs:format
  :~  ['ok' b+%.n]
      ['surface' s+'graf-http-v2']
      ['error' s+message]
      ['by-kind-path' s+'/graf/by-kind/<kind>/<offset>/<limit>']
      ['max-page-items' (numb:enjs:format max-page-items)]
  ==
::
++  kind-hits
  |=  [s=store kind=@tas]
  ^-  (list fact)
  =/  pattern=pat  (tup ~[(is kind) any any])
  (skim (facts s) |=(item=* (match pattern item)))
::
++  page-json
  |=  [s=store kind=@tas offset=@ud requested=@ud]
  ^-  json
  =/  applied=@ud  ?:((lte requested max-page-items) requested max-page-items)
  =/  hits=(list fact)  (kind-hits s kind)
  =/  total=@ud  (lent hits)
  =/  page=(list fact)  (scag applied (slag offset hits))
  =/  next=@ud  (add offset (lent page))
  =/  more=?  (lth next total)
  %-  pairs:enjs:format
  :~  ['ok' b+%.y]
      ['surface' s+'graf-http-v2']
      ['kind' s+(scot %tas kind)]
      ['offset' (numb:enjs:format offset)]
      ['requested-limit' (numb:enjs:format requested)]
      ['applied-limit' (numb:enjs:format applied)]
      ['returned' (numb:enjs:format (lent page))]
      ['total' (numb:enjs:format total)]
      ['has-more' b+more]
      ['next-offset' ?:(more (numb:enjs:format next) ~)]
      ['items' a+(turn page fact-json)]
  ==
::
++  handle
  |=  [s=store =path]
  ^-  json
  ?+  path  (error-json 'unknown graf HTTP path')
    ~
      root-json
    [%by-kind @ ~]
      (page-json s i.t.path 0 max-page-items)
    [%by-kind @ @ @ ~]
      =/  maybe-offset=(unit @ud)  (slaw %ud i.t.t.path)
      =/  maybe-limit=(unit @ud)  (slaw %ud i.t.t.t.path)
      ?~  maybe-offset
        (error-json 'offset and limit must be unsigned decimal integers')
      ?~  maybe-limit
        (error-json 'offset and limit must be unsigned decimal integers')
      ?:  =(0 u.maybe-limit)
        (error-json 'limit must be greater than zero')
      (page-json s i.t.path u.maybe-offset u.maybe-limit)
  ==
--
