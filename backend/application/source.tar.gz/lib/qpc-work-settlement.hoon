::  Work settlement for ordinary single-proposal observation collection.
::  Alternatives require the forthcoming canonical QPC release receipt.
/-  nc=native-coding
/+  obs=qpc-observation, q=qpc-native-outcome, outcomes=qpc-outcome-store,
    accept=native-coding-accept, project=native-coding-project,
    guard=viki-scry-guard
|%
+$  receipt
  $:  %qpc-work-settlement-v1  id=@ux  frame=@ux  outcome=@ux
      candidate=@ux  acceptance=@ux  decision=@ux  at=@da
      status=?(%applied %refused)
      prediction=revision:nc  resulting=revision:nc
  ==
+$  state  (map @ux receipt)
++  digest  |=(value=* ^-(@ux (shax (jam [%qpc-work-settlement-v1 value]))))
++  assemble
  ::  The owning reader supplies canonical records, never the command sender.
  ::  A check receipt can precede the terminal acceptance stage. Its report
  ::  and adjudications must still match; only its acceptance hash may differ.
  |=  [at=@da m=manifest:obs f=frame:obs cs=cases:q v=linked:q r=record:accept current=revision:nc]
  ^-  (each receipt @tas)
  ?.  ?=(%& -.result.f)  [%| %qpc-settlement-report-gap]
  ?.  =(1 (lent p.result.f))
    [%| %qpc-settlement-selection-required]
  =/  row  (snag 0 p.result.f)
  ?.  ?&  =(id.f (digest:obs f(id 0x0)))  =(id.f frame.v)
          =(call.v call.row)  =(values.row confidence.v)
          =(owner.m owner.f)  (work-valid:obs m work.f)
          (lte at.f at)  (gte requested-at.r at.f)
          (lte requested-at.r at)
      ==  [%| %qpc-settlement-frame-mismatch]
  =/  checked  (adjudicate:q m work.f cs r)
  ?:  ?=(%| -.checked)  [%| p.checked]
  ?.  =(p.checked result.v(acceptance (digest:accept r)))
    [%| %qpc-settlement-checks-changed]
  ?.  ?=(?(%applied %refused) stage.r)  [%| %qpc-settlement-unresolved]
  =/  decision  decision.r
  ?~  decision  [%| %qpc-settlement-decision-missing]
  ?.  &((gte at.u.decision at.f) (lte at.u.decision at))
    [%| %qpc-settlement-decision-time]
  =/  resulting=revision:nc
    ?:  =(%applied stage.r)
      ?>  ?=(^ landed.r)
      revision.u.landed.r
    source.context.candidate.r
  ?.  =(current resulting)  [%| %qpc-settlement-source-changed]
  ?:  =(%refused stage.r)
    ?.  &(?=(?(%revise %refuse) verdict.u.decision) ?=(~ landed.r) =(`verdict.u.decision reason.r))
      [%| %qpc-settlement-refusal-invalid]
    (make at f v r resulting)
  (make at f v r resulting)
++  make
  |=  [at=@da f=frame:obs v=linked:q r=record:accept resulting=revision:nc]
  ^-  (each receipt @tas)
  ?>  &(?=(?(%applied %refused) stage.r) ?=(^ decision.r))
  =/  value=receipt
    :*  %qpc-work-settlement-v1  0x0  id.f  (digest:q v)
        id.candidate.r  (digest:accept r)  (digest:accept u.decision.r)  at
        stage.r  source.work.f  resulting
    ==
  [%& value(id (digest value))]
++  linked-valid
  |=  [observed=state:obs checked=state:outcomes v=receipt]
  ^-  ?
  =/  f  (~(get by frames.observed) frame.v)
  ?~  f  %.n
  ?.  ?=(%& -.result.u.f)  %.n
  ?.  =(1 (lent p.result.u.f))  %.n
  =/  row  (snag 0 p.result.u.f)
  =/  out  (~(get by outcomes.checked) [frame.v call.row])
  ?~  out  %.n
  ?&  =(id.v (digest v(id 0x0)))  =(outcome.v (digest:q u.out))
      =(candidate.v candidate.result.u.out)  =(prediction.v source.work.u.f)
      (gte at.v at.u.f)  !=(0 acceptance.v)  !=(0 decision.v)
      =(owner.prediction.v owner.resulting.v)  =(desk.prediction.v desk.resulting.v)
      ?:  =(%applied status.v)
        =(+(number.prediction.v) number.resulting.v)
      =(prediction.v resulting.v)
  ==
++  valid
  |=  [observed=state:obs checked=state:outcomes s=state]
  ^-  ?
  &((lte ~(wyt by s) 256) (levy ~(tap by s) |=([id=@ux v=receipt] &(=(id frame.v) (linked-valid observed checked v)))))
++  retain
  |=  [observed=state:obs checked=state:outcomes s=state v=receipt]
  ^-  (each state @tas)
  ?.  (linked-valid observed checked v)  [%| %qpc-settlement-link-invalid]
  =/  old  (~(get by s) frame.v)
  ?^  old  ?:(=(v u.old) [%& s] [%| %qpc-settlement-already-retained])
  ?.  (lth ~(wyt by s) 256)  [%| %qpc-settlement-capacity]
  [%& (~(put by s) frame.v v)]
++  read
  ::  No writes or candidate checks are executed here. Managed sessions must
  ::  supply future selected-release evidence through a separate adapter.
  |=  [b=bowl:gall required=(set @ux) m=manifest:obs f=frame:obs cs=cases:q v=linked:q]
  ^-  (each receipt @tas)
  ?.  &(=(our.b src.b) =(our.b owner.f) =(our.b owner.m))
    [%| %qpc-settlement-owner-mismatch]
  ?:  (~(has in required) session.work.f)  [%| %qpc-settlement-selection-required]
  ?.  (agent-live:guard our.b now.b %cantrip)  [%| %qpc-cantrip-unavailable]
  =/  id=@ux  candidate.result.v
  =/  raw=*
    .^(* %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/candidate/(scot %ux id)/noun)
  =/  parsed  ((soft ,(unit record:accept)) raw)
  ?~  parsed  [%| %qpc-settlement-acceptance-invalid]
  ?~  u.parsed  [%| %qpc-settlement-acceptance-missing]
  =/  r=record:accept  u.u.parsed
  =/  current  (current:project our.b now.b project.r)
  ?:  ?=(%| -.current)  [%| p.current]
  (assemble now.b m f cs v r revision.working.p.current)
--
