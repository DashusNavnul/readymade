::  Presentation of the same native JSON as ARK. No calculation or mutation.
|%
++  field
  |=  [j=json key=@t]
  ^-  json
  ?>  ?=([%o *] j)
  (~(got by p.j) key)
++  rows
  |=  j=json
  ^-  (list json)
  ?>  ?=([%a *] j)
  p.j
++  safe
  |=  text=@t
  ^-  @t
  (crip (turn (trip text) |=(c=@tD ^-(@tD ?:(&((gte c 32) (lte c 126)) c '?')))))
++  scalar
  |=  j=json
  ^-  @t
  ?:  ?=(~ j)  'unavailable'
  (safe ?:(?=(%s -.j) p.j (en:json:html j)))
++  line
  |=  [label=@t j=json]
  ^-  @t
  (rap 3 ~[label ': ' (scalar j) '\0a'])
++  fields
  |=  [j=json names=(list @t)]
  ^-  @t
  (rap 3 (turn names |=(key=@t (line key (field j key)))))
++  matrix
  |=  [label=@t j=json]
  ^-  @t
  ?:  ?=(~ j)  (line label j)
  (rap 3 ~[label ' = ' (scalar (field j 'entries')) ' / ' (scalar (field j 'denominator')) '\0a'])
++  ratio
  |=  [label=@t j=json]
  ^-  @t
  ?:  ?=(~ j)  (line label j)
  (rap 3 ~[label ' = ' (scalar (field j 'numerator')) '/' (scalar (field j 'denominator')) '\0a'])
++  stream
  |=  j=json
  ^-  @t
  =/  reference=json  (field j 'reference')
  =/  reading=json  (field j 'reading')
  %+  rap  3
  :~  (fields j ~['instrument' 'stream' 'manifest' 'status' 'referenceCount' 'liveCount' 'unconsumed' 'gaps' 'outside'])
      ?:  ?=(~ reference)  'Reference: unavailable\0a'
      (cat 3 (line 'Reference epoch' (field reference 'id')) (matrix 'Reference covariance' (field reference 'covariance')))
      ?:  ?=(~ reading)  'Reading: unavailable; collecting.\0a'
      =/  shape=json  (field reading 'shape')
      %+  rap  3
      :~  (fields reading ~['id' 'epoch' 'referenceMixedLaw' 'liveMixedLaw'])
          (matrix 'C' (field reading 'tensor'))
          (ratio 'A = ||C||^2' (field reading 'attentionSquared'))
          ?:  ?=(~ shape)  'Shape: undefined at zero A.\0a'
          (cat 3 'Normalized shape (separate from A):\0a' (fields shape ~['denominator' 'state' 'update']))
          'Comparisons in coordinate order:\0a'
          (rap 3 (turn (rows (field reading 'comparison')) |=(c=json (rap 3 ~[(fields c ~['referenceKnown' 'referencePass' 'liveKnown' 'livePass' 'referenceVaries' 'liveVaries' 'confidenceVaries' 'judgment']) (ratio 'Model Brier' (field c 'modelBrier')) (ratio 'Baseline Brier' (field c 'baselineBrier'))]))))
      ==
      'Counts describe retained native history. Current source and native gates determine admission. Full membership and evidence are in ARK.\0a'
  ==
++  candidates
  |=  view=json
  ^-  @t
  ?>  ?=([%o *] view)
  =/  c  (~(get by p.view) 'candidates')
  ?~  c  'Candidates: unavailable from this native version.\0a'
  ?>  =([%s 'qpc-candidate-view-v1'] (field u.c 'schema'))
  %+  rap  3
  :~  'Candidates (the same sealed native pools as ARK):\0a'
      (fields u.c ~['status' 'managedSessions' 'sealedPools' 'energy' 'selection'])
      (rap 3 (turn (scag 4 (rows (field u.c 'pools'))) |=(p=json (fields p ~['pool' 'session' 'candidates' 'hardRefusals']))))
  ==
++  distributions
  |=  view=json
  ^-  @t
  ?>  ?=([%o *] view)
  =/  d  (~(get by p.view) 'distributions')
  ?~  d  'Distributions: unavailable from this native version.\0a'
  ?>  =([%s 'qpc-distribution-view-v1'] (field u.d 'schema'))
  =/  pools=(list json)  (rows (field u.d 'pools'))
  ?~  pools  'Distributions: no sealed pool.\0a'
  %+  rap  3
  :-  'Distributions per law revision (the same frozen pools as ARK):\0a'
  %+  turn  (scag 4 `(list json)`pools)
  |=  p=json
  %+  rap  3
  :-  (fields p ~['pool' 'attention'])
  %+  turn  (scag 4 (rows (field p 'laws')))
  |=(l=json (fields l ~['revision' 'gain' 'status' 'reason' 'contrast' 'total']))
++  receipt-record
  |=  j=json
  ^-  @t
  =/  admitted=json  (field j 'admission')
  =/  draw=json  (field j 'draw')
  =/  selected=json  (field j 'selection')
  =/  execution=json  (field j 'execution')
  =/  outcomes=(list json)  (rows (field j 'outcomes'))
  %+  rap  3
  :~  (fields j ~['collection' 'decision' 'controller' 'stream' 'law' 'epoch' 'pool' 'phase' 'reason'])
      ?:  ?=(~ admitted)  'Selection admission: unavailable\0a'
      (cat 3 'Selection admission:\0a' (fields admitted ~['receiptDigest' 'marker' 'assessment']))
      ?:  ?=(~ draw)  'Draw: unavailable\0a'
      (cat 3 'Draw:\0a' (fields draw ~['event' 'value' 'at']))
      ?:  ?=(~ selected)  'Selection: unavailable; an attempt is not a chosen action.\0a'
      (rap 3 ~['Recorded selection:\0a' (fields selected ~['selected' 'gain' 'attention' 'total']) (rap 3 (turn (scag 4 (rows (field selected 'weights'))) |=(w=json (fields w ~['candidate' 'effect' 'energy' 'weight']))))])
      ?:  ?=(~ execution)  'Execution: unavailable\0a'
      =/  mapping=json  (field execution 'mapping')
      (rap 3 ~['Execution:\0a' (fields execution ~['record' 'phase' 'reason' 'admissionMarker']) ?:(?=(~ mapping) 'Mapping: unavailable\0a' (cat 3 (line 'mapping id' (field mapping 'id')) (fields mapping ~['candidate' 'effect' 'admission' 'tool' 'request'])))])
      ?:  ?=(~ outcomes)  'No independently joined outcome is retained. Sent is not applied.\0a'
      (rap 3 (turn (scag 2 `(list json)`outcomes) |=(o=json (cat 3 'Independent outcome:\0a' (fields o ~['status' 'receipt' 'mapping' 'release' 'acceptance' 'independentDecision' 'predictionSource' 'resultingSource'])))))
  ==
++  receipts
  |=  [view=json key=(unit @ux)]
  ^-  @t
  ?>  ?=(%o -.view)
  =/  data  (~(get by p.view) 'executionEvidence')
  ?~  data  'Execution evidence: unavailable from this native version.\0a'
  ?>  =([%s 'qpc-native-evidence-view-v1'] (field u.data 'schema'))
  ?.  =([%s 'available'] (field u.data 'status'))
    'Execution evidence: unavailable. No selection or application inferred.\0a'
  =/  records=(list json)  (rows (field u.data 'records'))
  =/  found=(list json)
    ?~  key  records
    (skim records |=(j=json =([%s (scot %ux u.key)] (field j 'stream'))))
  %+  rap  3
  :~  'Retained selection and execution (first 2; all identities in ARK):\0a'
      (line 'Meaning' (field u.data 'meaning'))
      (line 'Receipt records' (numb:enjs:format (lent found)))
      (rap 3 (turn (scag 2 `(list json)`found) receipt-record))
  ==
++  report
  |=  [our=@p key=(unit @ux) view=json]
  ^-  @t
  ?>  =([%s 'qpc-ark-law-v1'] (field view 'schema'))
  ?>  =([%s (scot %p our)] (field view 'owner'))
  =/  measured=json  (field view 'measurements')
  ?>  =([%s 'qpc-measurement-view-v1'] (field measured 'schema'))
  =/  laws=(list json)  (rows (field view 'laws'))
  =/  streams=(list json)  (rows (field measured 'streams'))
  ?>  ?=(%o -.view)
  =/  successor  (~(get by p.view) 'successorMeasurements')
  =/  added=(list json)
    ?~  successor  ~
    ?>  =([%s 'qpc-successor-measurement-view-v1'] (field u.successor 'schema'))
    (rows (field u.successor 'streams'))
  =.  streams  (weld streams added)
  =/  heading=@t
    (rap 3 ~['ARK native reading\0a' (fields view ~['measurement' 'selection' 'application']) (fields measured ~['coordinates' 'queueTotal' 'queueConsumed' 'unconsumed' 'fault']) ?~(successor '' (cat 3 'Successor history:\0a' (fields u.successor ~['queueTotal' 'queueConsumed' 'unconsumed' 'fault' 'refresh' 'availability']))) (candidates view) (distributions view) (receipts view key)])
  ?~  key
    %+  rap  3
    :~  heading
        'Laws (first 16; all are visible in ARK):\0a'
        (rap 3 (turn (scag 16 laws) |=(j=json (fields j ~['instrument' 'revision' 'gain']))))
        'Streams (first 16; use ark <stream> for an exact reading):\0a'
        (rap 3 (turn (scag 16 streams) |=(j=json (fields j ~['stream' 'status']))))
        (line 'Total streams' (numb:enjs:format (lent streams)))
    ==
  =/  found=(list json)
    (skim streams |=(j=json =([%s (scot %ux u.key)] (field j 'stream'))))
  ?.  =(1 (lent found))  (cat 3 heading 'Stream missing or ambiguous. No reading inferred.\0a')
  =/  chosen=json  (snag 0 found)
  =/  law=(list json)
    (skim laws |=(j=json =((field chosen 'instrument') (field j 'instrument'))))
  %+  rap  3
  :~  heading
      ?.  =(1 (lent law))  'Current law: unavailable or ambiguous.\0a'
      (fields (snag 0 law) ~['instrument' 'revision' 'gain' 'reason'])
      (stream chosen)
  ==
++  render
  |=  [our=@p key=(unit @ux) view=(unit json)]
  ^-  @t
  ?~  view  'ARK native view unavailable. No reading inferred.'
  =/  text=(unit @t)  (mole |.((report our key u.view)))
  ?~  text  'Invalid native ARK view. No reading inferred.'
  ?.  (lte (met 3 u.text) 8.192)
    'Reading exceeds the terminal display limit. Inspect the exact native values in ARK.'
  u.text
--
