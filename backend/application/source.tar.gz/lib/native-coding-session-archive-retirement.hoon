::  Pure final retirement after the caller has qualified current authority
::  and supplied the exact record read back from Clay. No IO or activation.
/+  loop=native-coding-loop, sessions=native-coding-session,
    openings=viki-native-opening, carried=native-coding-session-archive-carried
|%
+$  input  [session=@ux input=@t]
+$  binding  [provider-key=@tas grant=@ux]
+$  receipt
  ::  v2 keeps the finished receipts that leave with the session. No v1
  ::  record was ever written, so none needs reading.
  $:  %native-coding-session-archive-receipt-v2
      owner=@p  session=@ux  at=@da  evidence=@ux
      entry=entry:sessions  binding=binding
      opening=record:openings
      inputs=(map @ux input)  input-ledger=@ux
      carried=carried:carried
  ==
+$  retirement  [coding=state:loop openings=ledger:openings organs=organs:carried]
++  same-material
  ::  Each receipt must be independently qualified by the caller. Evidence
  ::  fingerprints differ when the archive records its own pending write.
  |=  [a=receipt b=receipt]
  ^-  ?
  ?&  =(owner.a owner.b)  =(session.a session.b)  =(at.a at.b)
      =(entry.a entry.b)  =(binding.a binding.b)  =(opening.a opening.b)
      =(inputs.a inputs.b)  =(input-ledger.a input-ledger.b)
      =(carried.a carried.b)
  ==
++  valid-receipt
  |=  [our=@p e=receipt]
  ^-  ?
  ?&  !=(0 session.e)  !=(0 at.e)  !=(0 evidence.e)  !=(0 input-ledger.e)
      =(our owner.e)  =(our owner.session.entry.e)
      =(session.e id.session.entry.e)  =(session.e id.request.opening.e)
      =(grant.binding.e id.grant.opening.e)  =(our actor.grant.opening.e)
      =(%opened phase.opening.e)
      ?=(?(%complete %refused) phase.entry.e)
      =(~ pending.entry.e)  =(~ calls.entry.e)
      (lte ~(wyt by inputs.e) 4.096)
      (levy ~(val by inputs.e) |=(row=input =(session.e session.row)))
      (valid:carried session.e carried.e)
  ==
++  retire
  ::  Eligibility, authority and Clay readback must already be established by
  ::  the caller. This arm cannot itself authenticate a caller-supplied noun.
  ::  It never removes the binding or input ledger, preserving both dedup keys.
  |=  [our=@p actor=@p expected=receipt coding=state:loop openings=ledger:openings organs=organs:carried stored=(unit receipt)]
  ^-  (each retirement @tas)
  ?.  &(=(our actor) =(our owner.expected))  [%| %archive-owner-required]
  ?~  stored  [%| %archive-readback-unavailable]
  ?.  =(u.stored expected)  [%| %archive-readback-mismatch]
  ?.  (valid-receipt our expected)  [%| %archive-receipt-invalid]
  ?.  =(`binding.expected (~(get by bindings.coding) session.expected))
    [%| %archive-binding-changed]
  ?.  =(`entry.expected (~(get by sessions.coding) session.expected))
    [%| %archive-session-changed]
  ?.  =(`opening.expected (~(get by openings) session.expected))
    [%| %archive-opening-changed]
  ?.  =(input-ledger.expected (shax (jam inputs.coding)))
    [%| %archive-inputs-changed]
  =/  selected=(map @ux input)
    %-  malt
    %+  skim  ~(tap by inputs.coding)
    |=  [nonce=@ux row=input]
    =(session.expected session.row)
  ?.  =(selected inputs.expected)  [%| %archive-inputs-changed]
  ::  Exactly the recorded rows still name the session: none added, none lost.
  ?.  =(carried.expected (select:carried session.expected organs))
    [%| %archive-carried-changed]
  :-  %&
  :+  coding(sessions (~(del by sessions.coding) session.expected))
    (~(del by openings) session.expected)
  (strip:carried organs carried.expected)
--
