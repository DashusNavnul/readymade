::  Issued command identities and retained tool results. No read/write authority.
/-  nc=native-coding
/+  journal=native-coding-session, files=native-coding-files,
    git=readymade-git-proposal, terminal=native-coding-terminal
|%
++  command-receipt
  |=  [delivery=@ux target=@tas selected=@ux payload=*]
  ^-  json
  ?.  =(%viki target)  ~
  =/  decoded=(unit [session=@ux request=@ux source=(unit @ux)])
    ?+  payload  ~
      [%native-coding-action-v1 [%terminal @ @ @]]
        =/  [session=@ux request=@ux input=@t]  +.+.payload
        `[session request ~]
      [%native-coding-action-v1 [%terminal-at @ @ @ @]]
        =/  [session=@ux nonce=@ux source=@ux input=@t]  +.+.payload
        `[session (request-at:terminal session nonce source input) `source]
      [%native-coding-action-v1 [%git-proposal @ @ @ [@ @ @ @]]]
        =/  [session=@ux nonce=@ux source=@ux chosen=source-selection:git]  +.+.payload
        `[session (candidate-identity:git chosen nonce source) `source]
    ==
  ?~  decoded  ~
  =/  [session=@ux request=@ux expected=(unit @ux)]  u.decoded
  ?.  &(=(selected session) !=(0 request))  ~
  =/  source=json
    ?~  expected  ~
    s+(scot %ux u.expected)
  (pairs:enjs:format ~[['version' s+'native-coding-command-receipt-v1'] ['delivery' s+(scot %ux delivery)] ['target' s+'viki'] ['session' s+(scot %ux session)] ['request' s+(scot %ux request)] ['source' source]])
++  revision
  |=  r=revision:nc
  ^-  json
  (pairs:enjs:format ~[['id' s+(scot %ux (shax (jam r)))] ['owner' s+(scot %p owner.r)] ['desk' s+(scot %tas desk.r)] ['number' (numb:enjs:format number.r)] ['root' s+(scot %uv root.r)] ['commit' s+(scot %uv commit.r)]])
++  record
  |=  r=record:journal
  ^-  json
  ?.  ?=(%tool -.body.r)  ~
  =/  result=tool-result:nc  result.body.r
  =/  output=tool-output:nc  output.result
  ?:  ?=(%diagnostics -.output)
    =/  ctx=context:nc  context.result
    =/  ds=(list diagnostic:nc)  values.output
    ?.  ?&  !=(0 session.ctx)  !=(0 request.ctx)
            !=(0 configuration.ctx)  !=('' project.ctx)
            !=('' call-id.result)  (lte (met 3 call-id.result) 256)
            !=(~ ds)  (lte (lent ds) 64)
        ==  ~
    ?:  (lien ds |=(d=diagnostic:nc |(!=(source.d source.ctx) (gth (met 3 detail.d) 8.192) (gth (lent artifacts.d) 16))))  ~
    ?.  (lte (roll ds |=([d=diagnostic:nc total=@ud] (add total (met 3 detail.d)))) 16.384)  ~
    =/  rows=(list json)
      %+  turn  ds
      |=  d=diagnostic:nc
      (pairs:enjs:format ~[['name' s+name.d] ['passed' b+passed.d] ['detail' s+detail.d] ['source' (revision source.d)] ['artifacts' a+(turn artifacts.d |=(id=@ux s+(scot %ux id)))]])
    (pairs:enjs:format ~[['version' s+'native-coding-problems-v1'] ['kind' s+'diagnostics'] ['project' s+project.ctx] ['configuration' s+(scot %ux configuration.ctx)] ['recordedAt' s+(scot %da at.r)] ['session' s+(scot %ux session.ctx)] ['request' s+(scot %ux request.ctx)] ['callId' s+call-id.result] ['source' (revision source.ctx)] ['value' (pairs:enjs:format ~[['values' a+rows]])]])
  ?.  ?=(?(%read %list) -.output)  ~
  =/  data=json
    ?:  ?=(%read -.output)
      =/  f=file-read:nc  value.output
      (pairs:enjs:format ~[['path' s+(spat pax.f)] ['mark' s+(scot %tas (rear pax.f))] ['blob' s+(scot %ux blob.f)] ['start' (numb:enjs:format start.f)] ['total' (numb:enjs:format total.f)] ['text' s+text.f] ['lines' (numb:enjs:format (lent (lines:files text.f)))] ['bytes' (numb:enjs:format (met 3 text.f))] ['next' ?~(next.f ~ (numb:enjs:format u.next.f))]])
    =/  l=listing:nc  value.output
    =/  rows=(list json)
      (turn entries.l |=(f=file-entry:nc (pairs:enjs:format ~[['path' s+(spat pax.f)] ['mark' s+(scot %tas mark.f)] ['blob' s+(scot %ux blob.f)]])))
    (pairs:enjs:format ~[['entries' a+rows] ['next' ?~(next.l ~ (numb:enjs:format u.next.l))]])
  (pairs:enjs:format ~[['kind' s+-.output] ['session' s+(scot %ux session.context.result)] ['request' s+(scot %ux request.context.result)] ['callId' s+call-id.result] ['source' (revision source.context.result)] ['value' data]])
--
