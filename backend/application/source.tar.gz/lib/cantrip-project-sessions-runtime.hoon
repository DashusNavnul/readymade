::  One authenticated Ames watch, one bounded native observation, then close.
::  Every watch rechecks authority; no cache, journal, timer or retry exists.
::  Reads are ordered cheapest first: a stranger costs one catalog lookup.
/-  ps=cantrip-project-sessions, nc=native-coding, mp=multiplayer-project
/+  core=cantrip-project-sessions, scoped=native-coding-session-project,
    tools=cantrip-native-coding, guard=viki-scry-guard, law=cantrip-law-window
|%
++  catalog
  ::  A missing project, a foreign authority and a stopped runtime look the
  ::  same to the asker: non-members get no project-existence oracle.
  |=  [b=bowl:gall id=project-id:mp]
  ^-  (unit project:mp)
  ?.  (agent-live:guard our.b now.b %multiplayer-runtime)  ~
  =/  found=(unit project:mp)
    .^((unit project:mp) %gx /(scot %p our.b)/multiplayer-runtime/(scot %da now.b)/catalog/[id]/noun)
  ?~  found  ~
  ?.  &(=(our.b authority.spec.u.found) =(id id.spec.u.found))  ~
  found
++  observe
  |=  [b=bowl:gall held=scopes:core q=query:ps w=window:law]
  ^-  (each response:ps @tas)
  =/  ok  (admitted:core q w)
  ?:  ?=(%| -.ok)  [%| p.ok]
  =/  found  (catalog b project.q)
  ?~  found  [%| %sessions-member-refused]
  ?.  (~(has by members.u.found) src.b)  [%| %sessions-member-refused]
  ?.  (agent-live:guard our.b now.b %viki)  [%| %viki-unavailable]
  =/  registered=(map @t project:nc)
    .^((map @t project:nc) %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/projects/noun)
  =/  base  (~(get by registered) project.q)
  ?~  base  [%| %sessions-member-refused]
  =/  picked  (candidates:core our.b src.b q held)
  =/  solved=resolved:core
    %-  malt
    ^-  (list [@ux (each project:nc @tas)])
    %+  turn  grants.picked
    |=  g=grant:tools
    [session.g (resolve:scoped our.b now.b registered session.g project.q)]
  ::  With no eligible grant there is nothing to read from Viki.
  =/  raw=*
    ?~  grants.picked  ~
    .^(* %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/sessions/noun)
  (observe:core our.b src.b now.b q held w u.found u.base solved raw)
++  watch
  |=  [b=bowl:gall held=scopes:core pax=path w=window:law]
  ^-  (each (list card:agent:gall) @tas)
  =/  parsed  (parse:core pax)
  ?~  parsed  [%| %path-invalid]
  ?.  =(src.b peer.u.parsed)  [%| %foreign-peer]
  =/  result  (observe b held query.u.parsed w)
  ?:  ?=(%| -.result)  [%| p.result]
  [%& (cards:core pax p.result)]
--
