::  Explicit owner archive of unverified compiler attachment results.
::  Shares ONE cache desk/current with the Hoon and legacy GLS writers.
::  Caller saves state/cache/compiled together before sending these cards.
/-  nc=native-coding
/+  runtime=native-coding-compiler-attachment-runtime,
    cache=native-coding-compiler-store, hoon=native-coding-hoon-store,
    tools=cantrip-native-coding, project=native-coding-project,
    dsr=desk-shell-read, core=native-coding-compiler-attachment,
    exports=native-coding-compiler-exports,
    legacy=native-coding-compiler-exports-store,
    derivation=native-coding-compiler-derivation
|%
+$  reference
  [job=@ux receipt=@ux product=@ux source=revision:nc scope=@ux attachment=@ux selection=@ux role=role:core]
+$  entry
  [ref=reference before=revision:nc before-tree=@ux expected-tree=@ux pax=path blob=lobe:clay phase=?(%submitted %confirmed %unknown) saved=(unit revision:nc) retired=? reason=@tas]
+$  organ  [%native-coding-compiler-attachment-store-v1 records=(map @ux entry)]
+$  change
  [state=organ cache=organ:cache compiled=organ:runtime cards=(list card:agent:gall)]
+$  command
  $%  [%native-coding-compiler-attachment-store-v1 id=@ux]
      [%native-coding-compiler-attachment-store-observe-v1 id=@ux]
      [%native-coding-compiler-attachment-retire-v1 id=@ux]
  ==
++  empty  `organ`[%native-coding-compiler-attachment-store-v1 ~]
++  capacity  128
++  reference-of
  |=  r=retained:runtime
  ^-  reference
  ::  Refused outcomes are archivable too; they never become artifact success.
  [(key:tools request.input.r) (shax (jam r)) (shax (jam output.r)) source.context.request.input.r scope.r attachment.r (selection-id:exports selection.r) role.r]
++  path-for
  |=  r=reference
  ^-  path
  /native-coding/compiler-attachments/(scot %ux receipt.r)/noun
++  wire-for
  |=  id=@ux
  ^-  wire
  /native-compiler-attachment-store/(scot %ux id)
++  ready
  |=  s=organ
  ^-  ?
  !(lien ~(val by records.s) |=(e=entry !=(%confirmed phase.e)))
++  associated
  ::  Historical joins ignore revocation, but never lose exact entry/role/source.
  |=  [compiled=organ:runtime jobs=organ:tools id=@ux r=retained:runtime]
  ^-  ?
  ?.  (linked:runtime jobs id r)  %.n
  =/  parent  (~(get by attachments.compiled) attachment.r)
  =/  chosen  (~(get by choices.compiled) (key-for:runtime selection.r))
  ?~  parent  %.n
  ?~  chosen  %.n
  ?.  ?&  (valid:core u.parent)  =(digest.u.parent attachment.r)
          =(role.u.parent role.r)  =(attachment.u.chosen attachment.r)
          =(selection.u.chosen selection.r)
      ==  %.n
  =/  input  (inputs:core u.parent input.r selection.r)
  ?=(%& -.input)
++  linked
  |=  [compiled=organ:runtime jobs=organ:tools ref=reference r=retained:runtime]
  ^-  ?
  ?.  (associated compiled jobs job.ref r)  %.n
  =(ref (reference-of r))
++  exact
  ::  Returned noun stays data. This read works after explicit retirement.
  |=  [our=@p now=@da e=entry compiled=organ:runtime jobs=organ:tools]
  ^-  (each retained:runtime @tas)
  ?.  (valid:runtime our compiled jobs)  [%| %compiler-attachment-state-invalid]
  ?~  saved.e  [%| %compiler-attachment-archive-not-observed]
  =/  before  (at:cache our now desk.before.e number.before.e)
  ?~  before  [%| %compiler-attachment-archive-before-unavailable]
  ?.  &(=(before.e revision.u.before) =(before-tree.e (shax (jam files.u.before))) !(~(has by files.u.before) pax.e))
    [%| %compiler-attachment-archive-before-mismatch]
  =/  location=revision:nc  u.saved.e
  ?.  &(=(our owner.location) =(desk.before.e desk.location) =(+(number.before.e) number.location))
    [%| %compiler-attachment-archive-revision-mismatch]
  =/  actual  (at:cache our now desk.location number.location)
  ?~  actual  [%| %compiler-attachment-archive-unavailable]
  =/  expected=(map path lobe:clay)  (~(put by files.u.before) pax.e blob.e)
  ?.  &(=(location revision.u.actual) =(expected files.u.actual) =(expected-tree.e (shax (jam expected))) =(parents.u.actual ~[commit.before.e]))
    [%| %compiler-attachment-archive-tree-mismatch]
  =/  raw=*  .^(* %cx (beam-at:dsr our desk.location (scot %ud number.location) pax.e))
  =/  decoded  ((soft retained:runtime) raw)
  ?~  decoded  [%| %compiler-attachment-archive-page-invalid]
  ?.  &(=(raw u.decoded) (linked compiled jobs ref.e u.decoded) =(blob.e (page-to-lobe:clay [%noun u.decoded])))
    [%| %compiler-attachment-archive-evidence-mismatch]
  [%& u.decoded]
++  put
  |=  [s=organ shared=organ:cache compiled=organ:runtime e=entry cards=(list card:agent:gall)]
  ^-  change
  [s(records (~(put by records.s) job.ref.e e)) shared compiled cards]
++  observe
  |=  [b=bowl:gall s=organ shared=organ:cache compiled=organ:runtime jobs=organ:tools other=organ:hoon older=organ:legacy id=@ux]
  ^-  change
  =/  found  (~(get by records.s) id)
  ?~  found  [s shared compiled ~]
  =/  e=entry  u.found
  ?:  =(%confirmed phase.e)  [s shared compiled ~]
  =/  unknown
    |=  reason=@tas
    (put s shared compiled e(phase %unknown, reason reason) ~)
  ?~  config.shared  (unknown %compiler-attachment-archive-config-missing)
  ?.  &(=(current.u.config.shared before.e) (ready:cache shared) (ready:hoon other) (ready:legacy older))
    (unknown %compiler-attachment-archive-shared-conflict)
  =/  current  (current:cache our.b now.b desk.before.e)
  ?~  current  (unknown %compiler-attachment-archive-unavailable)
  ?:  =(revision.u.current before.e)
    (put s shared compiled e(reason %compiler-attachment-archive-unconfirmed) ~)
  ?.  =(number.revision.u.current +(number.before.e))
    (unknown %compiler-attachment-archive-revision-conflict)
  =/  candidate=entry  e(saved `revision.u.current)
  =/  checked  (exact our.b now.b candidate compiled jobs)
  ?:  ?=(%| -.checked)  (unknown p.checked)
  =.  shared  shared(config `u.config.shared(current revision.u.current))
  (put s shared compiled candidate(phase %confirmed, reason %compiler-attachment-archive-confirmed) ~)
++  act
  |=  [b=bowl:gall s=organ shared=organ:cache compiled=organ:runtime jobs=organ:tools other=organ:hoon older=organ:legacy proofs=organ:derivation c=command idle=?]
  ^-  (each change @tas)
  ?.  =(our.b src.b)  [%| %compiler-attachment-archive-owner-required]
  ?:  ?=(%native-coding-compiler-attachment-store-observe-v1 -.c)
    [%& (observe b s shared compiled jobs other older id.c)]
  =/  held  (~(get by records.s) id.c)
  ?:  ?=(%native-coding-compiler-attachment-retire-v1 -.c)
    ?:  (lien ~(val by records.proofs) |=(r=reference:derivation =(job.r id.c)))
      [%| %compiler-attachment-derivation-anchor]
    ?~  held  [%| %compiler-attachment-archive-missing]
    ?.  =(%confirmed phase.u.held)  [%| %compiler-attachment-archive-not-confirmed]
    =/  checked  (exact our.b now.b u.held compiled jobs)
    ?:  ?=(%| -.checked)  [%| p.checked]
    =/  retained  (~(get by results.compiled) id.c)
    ?:  retired.u.held
      ?^  retained  [%| %compiler-attachment-retirement-conflict]
      [%& [s shared compiled ~]]
    ?~  retained  [%| %compiler-attachment-retained-missing]
    ?.  =(u.retained p.checked)  [%| %compiler-attachment-retained-mismatch]
    =/  job  (~(get by records.jobs) id.c)
    ?~  job  [%| %compiler-attachment-archive-job-missing]
    ?:  ?=(?(%running %unknown) stage.u.job)  [%| %compiler-attachment-job-unsettled]
    =.  compiled  compiled(results (~(del by results.compiled) id.c))
    [%& (put s shared compiled u.held(retired %.y, reason %compiler-attachment-artifact-retired) ~)]
  ?^  held  [%& [s shared compiled ~]]
  ?.  &(idle (ready s) (ready:cache shared) (ready:hoon other) (ready:legacy older))
    [%| %compiler-attachment-archive-writer-busy]
  ?:  (gte ~(wyt by records.s) capacity)  [%| %compiler-attachment-archive-capacity]
  ?~  config.shared  [%| %compiler-attachment-archive-config-missing]
  ?.  enabled.u.config.shared  [%| %compiler-attachment-archive-disabled]
  =/  retained  (~(get by results.compiled) id.c)
  ?~  retained  [%| %compiler-attachment-artifact-missing]
  =/  r=retained:runtime  u.retained
  ?.  &((valid:runtime our.b compiled jobs) (associated compiled jobs id.c r))
    [%| %compiler-attachment-artifact-invalid]
  =/  ref=reference  (reference-of r)
  =/  location=revision:nc  current.u.config.shared
  ?.  &(=(our.b owner.location) (project-free:cache our.b now.b desk.location))
    [%| %compiler-attachment-archive-desk-refused]
  =/  before  (current:cache our.b now.b desk.location)
  ?~  before  [%| %compiler-attachment-archive-desk-unavailable]
  ?.  &(=(location revision.u.before) (lth ~(wyt by files.u.before) 4.096))
    [%| %compiler-attachment-archive-current-mismatch]
  =/  pax=path  (path-for ref)
  ?:  (~(has by files.u.before) pax)  [%| %compiler-attachment-archive-path-exists]
  =/  blob=lobe:clay  (page-to-lobe:clay [%noun r])
  =/  expected=(map path lobe:clay)  (~(put by files.u.before) pax blob)
  =/  e=entry
    [ref location (shax (jam files.u.before)) (shax (jam expected)) pax blob %submitted ~ %.n %compiler-attachment-archive-submitted]
  ::  Exactly one write; observe, reload and retirement cannot resend it.
  [%& (put s shared compiled e ~[[%pass (wire-for id.c) %arvo %c %info desk.location [%& [[pax %ins %noun !>(r)] ~]]] [%pass (wire-for id.c) %arvo %c %warp our.b desk.location ~ %sing %z [%ud +(number.location)] /]])]
++  arvo
  |=  [b=bowl:gall s=organ shared=organ:cache compiled=organ:runtime jobs=organ:tools other=organ:hoon older=organ:legacy w=wire sign=sign-arvo]
  ^-  change
  ?.  &(=(our.b src.b) ?=([%native-compiler-attachment-store @ ~] w) ?=([%clay %writ *] sign))
    [s shared compiled ~]
  =/  id  (slaw %ux i.t.w)
  ?~  id  [s shared compiled ~]
  ?.  =(w (wire-for u.id))  [s shared compiled ~]
  (observe b s shared compiled jobs other older u.id)
++  valid
  |=  [our=@p s=organ shared=organ:cache compiled=organ:runtime jobs=organ:tools other=organ:hoon older=organ:legacy proofs=organ:derivation]
  ^-  ?
  ?.  (lte ~(wyt by records.s) capacity)  %.n
  ?.  (valid:runtime our compiled jobs)  %.n
  ?~  config.shared  =(~ records.s)
  ?.  (lte (lent (skim ~(val by records.s) |=(e=entry !=(%confirmed phase.e)))) 1)  %.n
  =/  writers=@ud
    (add ?:((ready s) 0 1) (add ?:((ready:cache shared) 0 1) (add ?:((ready:hoon other) 0 1) ?:((ready:legacy older) 0 1))))
  ?.  (lte writers 1)  %.n
  %+  levy  ~(tap by records.s)
  |=  [id=@ux e=entry]
  ?.  ?&  =(id job.ref.e)  (identifier:tools id)  (identifier:tools receipt.ref.e)
          (identifier:tools product.ref.e)  (lte (met 0 scope.ref.e) 256)
          (identifier:tools attachment.ref.e)  (lte (met 0 selection.ref.e) 256)
          (lte (met 0 before-tree.e) 256)  (lte (met 0 expected-tree.e) 256)
          (lte (met 0 blob.e) 256)  (lte (met 3 reason.e) 128)
          =(pax.e (path-for ref.e))  (revision-valid:project before.e)
          (revision-valid:project source.ref.e)  =(our owner.before.e)
          =(desk.before.e desk.current.u.config.shared)
          (gte number.before.e number.origin.u.config.shared)
      ==  %.n
  =/  parent  (~(get by attachments.compiled) attachment.ref.e)
  ?~  parent  %.n
  ?.  &(=(digest.u.parent attachment.ref.e) =(role.u.parent role.ref.e) (valid:core u.parent))  %.n
  =/  job  (~(get by records.jobs) id)
  ?~  job  %.n
  ?.  =(source.ref.e source.context.request.u.job)  %.n
  =/  args=tool-args:nc  arguments.request.u.job
  ?.  ?=(?(%compile %check) -.args)  %.n
  =/  chosen
    (~(get by choices.compiled) [configuration.context.request.u.job target.args])
  ?~  chosen  %.n
  ?.  &(=(attachment.u.chosen attachment.ref.e) =((selection-id:exports selection.u.chosen) selection.ref.e) =(project.context.request.u.job id.spec.project.selection.u.chosen))  %.n
  =/  scope  (~(get by grants.jobs) grant.u.job)
  ?~  scope  %.n
  ?.  &(=(scope.ref.e (scope-digest:runtime u.scope(revoked ~))) =(project.grant.u.scope project.selection.u.chosen) =(our authority.spec.project.grant.u.scope) =(our owner.source.ref.e))  %.n
  ?.  ?:  =(%confirmed phase.e)
        ?~  saved.e  %.n
        &((revision-valid:project u.saved.e) =(our owner.u.saved.e) =(desk.before.e desk.u.saved.e) =(+(number.before.e) number.u.saved.e) (lte number.u.saved.e number.current.u.config.shared))
      &(?=(~ saved.e) !retired.e =(before.e current.u.config.shared))
    %.n
  =/  retained  (~(get by results.compiled) id)
  ?:  retired.e
    &(?=(~ retained) !?=(?(%running %unknown) stage.u.job) !(lien ~(val by records.proofs) |=(r=reference:derivation =(job.r id))))
  ?~  retained  %.n
  &((linked compiled jobs ref.e u.retained) =(blob.e (page-to-lobe:clay [%noun u.retained])))
--
