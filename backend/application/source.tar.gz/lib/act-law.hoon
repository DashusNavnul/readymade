::  /lib/act-law.hoon
::
::  THE ACT LAW, GOVERNED.  The operator forbids or allows cantrip's acts
::  (lib/cantrip-law-window's twelve: read .. implement promote .. done) as
::  append-only graf facts, [%forbid-act %1 verb act who at]; later facts
::  win, %allow lifts a forbid.  cantrip applies the result to the window
::  every reader scries (+restrict), so a forbidden act is refused wherever
::  the window is consulted -- %implement forbidden means no landing and no
::  seat writes its fork.  It only narrows what the regime admits; it never
::  admits an act the regime blocks.
::
::  FAILS CLOSED.  If graf is not running the forbids cannot be read, so the
::  irreversible acts (never-auto: %implement, %promote) are held until it
::  is.  Read like the governed words (lib/render-law): graf's
::  /by-kind-page, folded by the time each fact was RECORDED, not the order
::  graf hands them back.
::
/+  clw=cantrip-law-window, gew=graf-evidence-window
|%
+$  act-fact  [%forbid-act %1 verb=?(%forbid %allow) =act:clw who=@p at=@da]
++  fact-of
  |=  [verb=?(%forbid %allow) a=act:clw who=@p at=@da]
  ^-  act-fact
  [%forbid-act %1 verb a who at]
::  +canon-acts: the acts forbidden now, from the facts in recorded order
++  canon-acts
  |=  facts=(list *)
  ^-  (set act:clw)
  =/  good=(list act-fact)
    %+  murn  facts
    |=(f=* ((soft act-fact) f))
  =.  good  (sort good |=([a=act-fact b=act-fact] (lth at.a at.b)))
  =|  out=(set act:clw)
  |-  ^-  (set act:clw)
  ?~  good  out
  %=  $
    good  t.good
    out   ?-(verb.i.good %forbid (~(put in out) act.i.good), %allow (~(del in out) act.i.good))
  ==
::  +forbidden-acts: the operator's act law on this ship, now
++  forbidden-acts
  |=  [our=@p now=@da]
  ^-  (set act:clw)
  ?.  .^(? %gu /(scot %p our)/graf/(scot %da now)/$)  never-auto-acts:clw
  =/  most=@ud  max-page-items:gew
  =|  facts=(list *)
  =/  offset=@ud  0
  |-  ^-  (set act:clw)
  =/  page=kind-page:gew
    .^  kind-page:gew  %gx
        /(scot %p our)/graf/(scot %da now)/by-kind-page/forbid-act/(scot %ud offset)/(scot %ud most)/noun
    ==
  =.  facts  (weld facts items.page)
  ?:  &(more.page (lth offset (mul 8 most)))  $(offset (add offset most))
  (canon-acts facts)
--
