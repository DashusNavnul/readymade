::  /lib/graf-attic.hoon
::
::  retention law for graf's bounded rings: eviction becomes archaeology,
::  not amnesia.  graf stores every family as a newest-first ring with a
::  hard cap, so the 129th proof bundle silently erases the 1st.  this
::  library catches what falls off the end.
::
::  dropped records are staged per family; once a family's staging holds
::  epoch-size records they are jammed into one compact epoch atom.  the
::  epochs list is APPEND-ONLY by operator ruling (graf is immutable:
::  facts append, cursors move, nothing is destroyed).  jammed epochs
::  are kilobyte-scale, so loom headroom is decades at current write
::  rates; exporting old epochs to clay is a permitted future layer.
::
::  records inside an epoch are newest-dropped-first, matching ring order.
::  unpack cues an epoch back into its record list; the caller re-casts
::  to the family's record type, since the attic stores erased nouns.
::
|%
+$  attic-family  @tas
::
+$  attic-epoch
  $:  seq=@ud
      family=attic-family
      count=@ud
      blob=@
  ==
::
+$  attic
  $:  next-seq=@ud
      staging=(map attic-family (list *))
      epochs=(list attic-epoch)
  ==
::
+$  attic-record
  $:  family=attic-family
      value=*
  ==
::
+$  attic-page
  $:  records=(list attic-record)
      record-count=@ud
      work-count=@ud
      exhausted=?
      safe=?
  ==
::
+$  attic-page-part
  $:  records=(list attic-record)
      work-count=@ud
      complete=?
      safe=?
  ==
::
++  epoch-size  64
++  max-page-families  16
::
::  one-record primitive.  keeping every sealed epoch at epoch-size is
::  what lets the live reader reject hostile oversized blobs before cue.
::
++  stash-one
  |=  [att=attic family=attic-family drop=*]
  ^-  attic
  =/  staged=(list *)  (~(gut by staging.att) family ~)
  =/  staged-full=(list *)  [drop staged]
  ?:  (lth (lent staged-full) epoch-size)
    att(staging (~(put by staging.att) family staged-full))
  =/  epoch=attic-epoch
    :*  seq=next-seq.att
        family=family
        count=(lent staged-full)
        blob=(jam staged-full)
    ==
  %=  att
    next-seq  +(next-seq.att)
    staging   (~(put by staging.att) family ~)
    epochs    (weld ~[epoch] epochs.att)
  ==
::
::  stash dropped records for a family.  batches are replayed oldest to
::  newest through stash-one, preserving newest-first recall while ensuring
::  even an oversized caller batch can never create an oversized epoch.
::
++  stash
  |=  [att=attic family=attic-family drops=(list *)]
  ^-  attic
  =/  queue=(list *)  (flop drops)
  |-
  ?~  queue  att
  $(att (stash-one att family i.queue), queue t.queue)
::
++  find-epoch
  |=  [att=attic seq=@ud]
  ^-  (unit attic-epoch)
  =/  epochs  epochs.att
  |-
  ?~  epochs  ~
  ?:  =(seq.i.epochs seq)
    `i.epochs
  $(epochs t.epochs)
::
++  unpack
  |=  epoch=attic-epoch
  ^-  (list *)
  ((list *) (cue blob.epoch))

::  live reads never cue an epoch unless its declared size is bounded, the
::  jam cues successfully, the payload is a list, and the count agrees.
::
++  unpack-safe
  |=  epoch=attic-epoch
  ^-  (unit (list *))
  ?.  (lte count.epoch epoch-size)  ~
  =/  decoded  (mule |.((cue blob.epoch)))
  ?:  ?=(%| -.decoded)  ~
  =/  records=(unit (list *))  ((soft (list *)) p.decoded)
  ?~  records  ~
  ?.  =(count.epoch (lent u.records))  ~
  records

::  consume records under a hard work budget.  No recursive call is made
::  after the budget is spent, so callers can safely point this at a long
::  staging list restored from legacy state.
::
++  take-records
  |=  [family=attic-family source=(list *) budget=@ud]
  ^-  attic-page-part
  =/  records=(list attic-record)  ~
  =/  work-count=@ud  0
  |-
  ?:  =(work-count budget)
    [records work-count =(~ source) %.y]
  ?~  source
    [records work-count %.y %.y]
  %=  $
    source      t.source
    records     (weld records ~[[family i.source]])
    work-count  +(work-count)
  ==

::  bounded staging pass over an already-bounded family selector.
::
++  staging-page
  |=  [att=attic families=(list attic-family) budget=@ud]
  ^-  attic-page-part
  ?~  families  [~ 0 %.y %.y]
  =/  staged=(list *)  (~(gut by staging.att) i.families ~)
  =/  part  (take-records i.families staged budget)
  ?.  complete.part  part
  =/  rest  (staging-page att t.families (sub budget work-count.part))
  :*  (weld records.part records.rest)
      (add work-count.part work-count.rest)
      complete.rest
      &(safe.part safe.rest)
  ==

++  family-selected
  |=  [families=(list attic-family) family=attic-family]
  ^-  ?
  (lien families |=(candidate=attic-family =(candidate family)))

::  epochs are newest-first.  Inspecting an epoch header costs one work unit;
::  each returned record costs another.  Non-selected epochs therefore cannot
::  induce an unbounded walk, and malformed/legacy-oversized epochs stop the
::  page fail-closed without being cued.
::
++  epoch-page
  |=  [epochs=(list attic-epoch) families=(list attic-family) budget=@ud]
  ^-  attic-page-part
  ?~  epochs  [~ 0 %.y %.y]
  ?:  =(budget 0)  [~ 0 %.n %.y]
  =/  remaining=@ud  (dec budget)
  ?.  (family-selected families family.i.epochs)
    =/  rest  (epoch-page t.epochs families remaining)
    [records.rest +(work-count.rest) complete.rest safe.rest]
  =/  decoded  (unpack-safe i.epochs)
  ?~  decoded  [~ 1 %.n %.n]
  =/  part  (take-records family.i.epochs u.decoded remaining)
  ?.  complete.part
    [records.part +(work-count.part) %.n safe.part]
  =/  rest
    (epoch-page t.epochs families (sub remaining work-count.part))
  :*  (weld records.part records.rest)
      (add 1 (add work-count.part work-count.rest))
      complete.rest
      &(safe.part safe.rest)
  ==

::  strict-budget archive page used by Graf's live search gate.  The selector
::  itself is capped, staging is read before sealed epochs, and work-count can
::  never exceed budget.  exhausted only means every relevant archive record
::  was examined; safe is false on malformed storage or selector overflow.
::
++  page
  |=  [att=attic families=(list attic-family) budget=@ud]
  ^-  attic-page
  ?.  =(~ (slag max-page-families families))
    [~ 0 0 %.n %.n]
  ?~  families  [~ 0 0 %.y %.y]
  =/  staged  (staging-page att families budget)
  ?.  complete.staged
    [records.staged (lent records.staged) work-count.staged %.n safe.staged]
  =/  sealed
    (epoch-page epochs.att families (sub budget work-count.staged))
  =/  records  (weld records.staged records.sealed)
  :*  records
      (lent records)
      (add work-count.staged work-count.sealed)
      complete.sealed
      &(safe.staged safe.sealed)
  ==

::  Unbounded compatibility reader for operator/debug surfaces.  Live query
::  execution must use page above.
++  records-for
  |=  [att=attic family=attic-family]
  ^-  (list *)
  =/  staged=(list *)  (~(gut by staging.att) family ~)
  =/  epochs  epochs.att
  =/  archived=(list *)  ~
  |-
  ?~  epochs
    (weld staged archived)
  ?.  =(family.i.epochs family)
    $(epochs t.epochs)
  $(epochs t.epochs, archived (weld archived (unpack i.epochs)))
::
::  per-family accounting for the summary scry: sealed epochs, archived
::  record count, and records still staged short of an epoch.
::
+$  attic-family-summary
  $:  family=attic-family
      epoch-count=@ud
      archived-count=@ud
      staged-count=@ud
  ==
::
++  family-summary
  |=  [att=attic family=attic-family]
  ^-  attic-family-summary
  =/  staged=(list *)  (~(gut by staging.att) family ~)
  =/  epochs  epochs.att
  =/  epoch-count=@ud  0
  =/  archived-count=@ud  0
  |-
  ?~  epochs
    :*  family=family
        epoch-count=epoch-count
        archived-count=archived-count
        staged-count=(lent staged)
    ==
  ?.  =(family.i.epochs family)
    $(epochs t.epochs)
  %=  $
    epochs          t.epochs
    epoch-count     +(epoch-count)
    archived-count  (add archived-count count.i.epochs)
  ==
::
++  families
  |=  att=attic
  ^-  (list attic-family)
  =/  staged-families  ~(tap in ~(key by staging.att))
  =/  epochs  epochs.att
  |-
  ?~  epochs  staged-families
  ?:  (lien staged-families |=(f=attic-family =(f family.i.epochs)))
    $(epochs t.epochs)
  %=  $
    epochs           t.epochs
    staged-families  [family.i.epochs staged-families]
  ==
::
++  summary
  |=  att=attic
  ^-  (list attic-family-summary)
  %+  turn  (families att)
  |=(f=attic-family (family-summary att f))
--
