::  Explicit Spider handles for newly admitted native tools only.
::  Stop is a request, not completion or rollback. No mutation is replayed.
/-  nc=native-coding, spider
/+  tools=cantrip-native-coding, guard=viki-scry-guard,
    worker=native-coding-worker-owner-runtime
|%
+$  fact  [mark=?(%thread-done %thread-fail) value=*]
+$  handle
  $:  request=tool-request:nc
      source=beak
      salt=@ux
      tid=tid:spider
      phase=?(%watching %starting %running %stopping %unknown %finished %cancelled)
      start=?(%unsent %sent %accepted %refused)
      cancel=?
      stop=?
      terminal=(unit fact)
      reason=@tas
  ==
+$  state  (map @ux handle)
+$  change  [state=state tools=organ:tools cards=(list card:agent:gall)]
++  tid-for
  |=  [our=@p id=@ux r=tool-request:nc source=beak salt=@ux]
  ^-  tid:spider
  (cat 3 'native-coding-job-' (scot %ux (shax (jam [%native-coding-job-handle-v1 our id r source salt]))))
++  wire-for
  |=  [id=@ux kind=@tas]
  ^-  wire
  /native-job/(scot %ux id)/[kind]
++  leave-result
  |=  [our=@p id=@ux]
  ^-  card:agent:gall
  [%pass (wire-for id %result) %agent [our %spider] %leave ~]
++  result-path
  |=  e=handle
  ^-  path
  /thread-result/[tid.e]
++  put
  |=  [our=@p s=state jobs=organ:tools id=@ux e=handle cards=(list card:agent:gall)]
  ^-  change
  =/  out=(list card:agent:gall)
    [(evidence:tools our [%native-coding-job-handle-v1 id e]) cards]
  [(~(put by s) id e) jobs out]
++  unknown
  |=  [b=bowl:gall s=state jobs=organ:tools id=@ux e=handle reason=@tas]
  ^-  change
  =/  r=record:tools  (~(got by records.jobs) id)
  =/  result=tool-result:nc
    [%native-coding-tool-result-v1 context.request.r call-id.request.r [%unknown reason 'Native job outcome remains unconfirmed; no start or stop was repeated.']]
  =.  jobs  jobs(records (~(put by records.jobs) id r(stage %unknown, result `result)))
  (put our.b s jobs id e(phase %unknown, reason reason) ~[(report:tools our.b result)])
++  cancelled-before
  |=  r=tool-request:nc
  ^-  tool-result:nc
  (refusal:tools r %cancelled-before-dispatch 'Cancelled before the native thread was dispatched. No start or stop was sent.')
++  cancelled-after
  |=  r=tool-request:nc
  ^-  tool-result:nc
  (refusal:tools r %native-job-cancelled 'Spider confirmed this thread stopped. Previously emitted effects and retained artifacts were not rolled back.')
++  stopped
  |=  [b=bowl:gall s=state jobs=organ:tools id=@ux e=handle]
  ^-  change
  =/  r=record:tools  (~(got by records.jobs) id)
  =/  before=?  =(%unsent start.e)
  =/  result  ?:(before (cancelled-before request.r) (cancelled-after request.r))
  =.  jobs  jobs(records (~(put by records.jobs) id r(stage %cancelled, result `result)))
  (put our.b s jobs id e(phase %cancelled, reason ?:(before %cancelled-before-dispatch %native-job-cancelled)) ~[(report:tools our.b result) (leave-result our.b id)])
++  advance
  |=  [b=bowl:gall s=state jobs=organ:tools id=@ux e=handle]
  ^-  change
  ?.  =(%accepted start.e)  [s jobs ~]
  ?:  ?=(?(%finished %cancelled) phase.e)  [s jobs ~]
  ?^  terminal.e
    =/  f=fact  u.terminal.e
    ?:  =(%thread-fail mark.f)
      =/  parsed  ((soft ,[term tang]) value.f)
      ?~  parsed  (unknown b s jobs id e %native-failure-invalid)
      ?.  =(u.parsed value.f)  (unknown b s jobs id e %native-failure-invalid)
      =/  why=@tas  -.u.parsed
      ::  A retained %thread-fail on the result path is Spider's own proof
      ::  that this strand ended (a pre-start refusal, our stop, or Spider
      ::  killing every strand after its own crash). Owner cancellation
      ::  acknowledges that proof; no start or stop request is invented.
      ::  Without an owner cancellation the outcome stays unknown.
      ?:  cancel.e
        (stopped b s jobs id e)
      (unknown b s jobs id e %native-thread-failed)
    =/  parsed  ((soft tool-result:nc) value.f)
    ?~  parsed  (unknown b s jobs id e %native-result-invalid)
    ?.  &(=(u.parsed value.f) =(context.request.e context.u.parsed) =(call-id.request.e call-id.u.parsed))
      (unknown b s jobs id e %native-result-mismatch)
    =/  r=record:tools  (~(got by records.jobs) id)
    =/  completed  (finish:tools our.b jobs id r u.parsed)
    (put our.b s next.completed id e(phase %finished, reason %native-job-finished) (weld cards.completed ~[(leave-result our.b id)]))
  ?.  &(cancel.e !stop.e)  [s jobs ~]
  ?.  (agent-live:guard our.b now.b %spider)
    (unknown b s jobs id e %native-spider-unavailable)
  (put our.b s jobs id e(stop %.y, phase %stopping, reason %native-stop-pending) ~[[%pass (wire-for id %stop) %agent [our.b %spider] %poke %spider-stop !>(`[tid:spider ?]`[tid.e %.n])]])
++  cancel
  ::  This internal gate is reached only by an owner command or admitted tool.
  |=  [b=bowl:gall s=state jobs=organ:tools id=@ux]
  ^-  (each change @tas)
  ?.  =(our.b src.b)  [%| %native-cancel-owner-required]
  =/  found  (~(get by s) id)
  ?~  found  [%| %legacy-job-handle-unavailable]
  =/  e=handle  u.found
  =/  job  (~(get by records.jobs) id)
  ?~  job  [%| %native-job-missing]
  ?.  &(=(request.e request.u.job) =(our.b actor.context.request.e))
    [%| %native-job-owner-mismatch]
  ?:  ?=(?(%finished %cancelled) phase.e)  [%& [s jobs ~]]
  ?:  |(cancel.e =(%refused start.e))
    [%| ?:(cancel.e %native-stop-already-requested %native-start-unconfirmed)]
  =/  kept  (put our.b s jobs id e(cancel %.y, reason %native-cancel-requested) ~)
  =/  next
    ?:  =(%unsent start.e)
      (stopped b state.kept tools.kept id (~(got by state.kept) id))
    (advance b state.kept tools.kept id (~(got by state.kept) id))
  [%& [state.next tools.next (weld cards.kept cards.next)]]
++  launch
  |=  [b=bowl:gall s=state jobs=organ:tools id=@ux]
  ^-  change
  =/  r=record:tools  (~(got by records.jobs) id)
  =/  picked  (execution-source:worker b)
  ?:  ?=(%| -.picked)
    =/  refused  (finish:tools our.b jobs id r (refusal:tools request.r p.picked 'The selected native execution source is unavailable. No thread was started.'))
    [s next.refused cards.refused]
  =/  salt=@ux  `@ux`eny.b
  ::  Gall's installation date can predate the running hosted brain's types.
  ::  Freeze today's thread closure once; keep retained jobs at their old beak.
  =/  source=beak  p.picked
  =/  e=handle
    [request.r source salt (tid-for our.b id request.r source salt) %watching %unsent %.n %.n ~ %native-watch-pending]
  ?.  (agent-live:guard our.b now.b %spider)
    (unknown b s jobs id e %native-spider-unavailable)
  (put our.b s jobs id e ~[[%pass (wire-for id %result) %agent [our.b %spider] %watch (result-path e)]])
++  act
  |=  [b=bowl:gall s=state jobs=organ:tools c=command:tools]
  ^-  change
  ?>  =(our.b src.b)
  ?:  ?=(%native-coding-cancel-v1 -.c)
    =/  stopped  (cancel b s jobs id.c)
    ?:  ?=(%& -.stopped)  p.stopped
    [s jobs ~[(evidence:tools our.b [%native-cancel-refused id.c p.stopped])]]
  =/  previous=organ:tools  jobs
  =/  applied  (act:tools b jobs c)
  =.  jobs  next.applied
  ?.  ?=(%native-coding-execute-v1 -.c)  [s jobs cards.applied]
  =/  id=@ux  (key:tools request.c)
  ?:  (~(has by records.previous) id)  [s jobs cards.applied]
  =/  admitted  (~(get by records.jobs) id)
  ?~  admitted  [s jobs cards.applied]
  ?.  =(%running stage.u.admitted)  [s jobs cards.applied]
  ?:  (executable:tools -.arguments.request.c)
    =/  started  (launch b s jobs id)
    [state.started tools.started (weld cards.applied cards.started)]
  ?>  ?=(%cancel -.arguments.request.c)
  =/  target  (~(get by records.jobs) job.arguments.request.c)
  =/  attempt=(each change @tas)
    ?~  target  [%| %native-job-missing]
    ?.  &(=(session.context.request.c session.context.request.u.target) =(actor.context.request.c actor.context.request.u.target))
      [%| %foreign-job]
    (cancel b s jobs job.arguments.request.c)
  =/  output=tool-output:nc
    ?:  ?=(%| -.attempt)  [%refused p.attempt 'No cancellation was confirmed or resubmitted.']
    [%job (public-job:tools job.arguments.request.c (~(got by records.tools.p.attempt) job.arguments.request.c))]
  =/  changed=change  ?:(?=(%& -.attempt) p.attempt [s jobs ~])
  =/  result=tool-result:nc
    [%native-coding-tool-result-v1 context.request.c call-id.request.c output]
  =/  completed  (finish:tools our.b tools.changed id u.admitted result)
  [state.changed next.completed (weld cards.applied (weld cards.changed cards.completed))]
++  on-agent
  |=  [b=bowl:gall s=state jobs=organ:tools w=wire sign=sign:agent:gall]
  ^-  change
  ?.  &(=(our.b src.b) ?=([%native-job @ @ ~] w))  [s jobs ~]
  =/  parsed  (slaw %ux i.t.w)
  ?~  parsed  [s jobs ~]
  =/  id=@ux  u.parsed
  =/  found  (~(get by s) id)
  ?~  found  [s jobs ~]
  =/  e=handle  u.found
  ?.  =(w (wire-for id i.t.t.w))  [s jobs ~]
  ?:  ?=(?(%finished %cancelled) phase.e)  [s jobs ~]
  ?:  &(?=(%watch-ack -.sign) =(%result i.t.t.w))
    ?.  &(=(%watching phase.e) =(%unsent start.e))  [s jobs ~]
    ?^  p.sign  (unknown b s jobs id e %native-watch-refused)
    =/  r=record:tools  (~(got by records.jobs) id)
    =/  scope  (~(get by grants.jobs) grant.r)
    ?~  scope  (unknown b s jobs id e %native-grant-missing)
    =/  allowed  (allowed:tools our.b now.b u.scope request.e)
    ?.  &(?=(%& -.allowed) (pending:tools our.b now.b request.e))
      (unknown b s jobs id e %native-start-authority-changed)
    (put our.b s jobs id e(start %sent, phase %starting, reason %native-start-pending) ~[[%pass (wire-for id %start) %agent [our.b %spider] %poke %spider-start !>(`start-args:spider`[~ `tid.e source.e %ph-native-coding-tool !>(`id)])]])
  ?:  &(?=(%poke-ack -.sign) =(%start i.t.t.w))
    ?.  =(%sent start.e)  [s jobs ~]
    ?^  p.sign
      (unknown b s jobs id e(start %refused, terminal ~) %native-start-refused)
    =/  kept  (put our.b s jobs id e(start %accepted, phase %running, reason %native-running) ~)
    =/  next  (advance b state.kept tools.kept id (~(got by state.kept) id))
    [state.next tools.next (weld cards.kept cards.next)]
  ?:  &(?=(%poke-ack -.sign) =(%stop i.t.t.w))
    ?.  stop.e  [s jobs ~]
    ?~  p.sign  [s jobs ~]
    (unknown b s jobs id e %native-stop-unconfirmed)
  ?:  &(?=(%kick -.sign) =(%result i.t.t.w))
    ?^  terminal.e  [s jobs ~]
    (unknown b s jobs id e %native-result-watch-ended)
  ?.  &(?=(%fact -.sign) =(%result i.t.t.w) ?=(?(%sent %accepted) start.e))  [s jobs ~]
  ?.  =(`[%& (result-path e)] (~(get by wex.b) [w our.b %spider]))  [s jobs ~]
  ?.  ?=(?(%thread-done %thread-fail) p.cage.sign)  [s jobs ~]
  =/  f=fact  [p.cage.sign q.q.cage.sign]
  ?.  (lte (met 3 (jam f)) 262.144)
    (unknown b s jobs id e %native-terminal-too-large)
  ?^  terminal.e  [s jobs ~]
  =/  kept  (put our.b s jobs id e(terminal `f) ~)
  =/  next  (advance b state.kept tools.kept id (~(got by state.kept) id))
  [state.next tools.next (weld cards.kept cards.next)]
++  view
  |=  [s=state id=@ux]
  ^-  (unit [@ux tid:spider @tas ? ? @tas ?(%unsent %sent %accepted %refused)])
  =/  e  (~(get by s) id)
  ?~  e  ~
  `[id tid.u.e phase.u.e cancel.u.e stop.u.e reason.u.e start.u.e]
++  cancelled-terminal
  |=  [e=handle result=tool-result:nc]
  ^-  ?
  ?-  start.e
      %unsent
    &(!stop.e ?=(~ terminal.e) =(%cancelled-before-dispatch reason.e) =(result (cancelled-before request.e)))
      %accepted
    ?.  =(%native-job-cancelled reason.e)  %.n
    ?~  terminal.e  %.n
    ?.  =(%thread-fail mark.u.terminal.e)  %.n
    =/  parsed  ((soft ,[term tang]) value.u.terminal.e)
    ?~  parsed  %.n
    =/  why=@tas  -.u.parsed
    ?.  =(u.parsed value.u.terminal.e)  %.n
    ?.  =(result (cancelled-after request.e))  %.n
    ::  Any retained failure term is terminal; the owner's cancellation
    ::  (required by +terminal-valid) is what settled it.
    |(stop.e cancel.e !=(0 (met 3 why)))
      %sent  %.n
      %refused  %.n
  ==
++  finished-terminal
  |=  [e=handle result=tool-result:nc]
  ^-  ?
  ?.  &(=(%accepted start.e) =(%native-job-finished reason.e))  %.n
  ?~  terminal.e  %.n
  ?.  =(%thread-done mark.u.terminal.e)  %.n
  =/  parsed  ((soft tool-result:nc) value.u.terminal.e)
  ?~  parsed  %.n
  &(=(u.parsed value.u.terminal.e) =(u.parsed result) =(context.request.e context.u.parsed) =(call-id.request.e call-id.u.parsed))
++  terminal-valid
  |=  [e=handle r=record:tools]
  ^-  ?
  ?.  =(phase.e stage.r)  %.n
  ?~  result.r  %.n
  ?-  phase.e
      %cancelled  &(cancel.e (cancelled-terminal e u.result.r))
      %finished  (finished-terminal e u.result.r)
      %watching  %.n
      %starting  %.n
      %running  %.n
      %stopping  %.n
      %unknown  %.n
  ==
++  valid
  |=  [our=@p s=state jobs=organ:tools]
  ^-  ?
  ?&  (lte ~(wyt by s) capacity:tools)
      =((lent ~(val by s)) ~(wyt in (silt (turn ~(val by s) |=(e=handle tid.e)))))
      %+  levy  ~(tap by s)
      |=  [id=@ux e=handle]
      =/  job  (~(get by records.jobs) id)
      ?~  job  %.n
      ?&  =(id (key:tools request.e))  =(request.e request.u.job)
          (executable:tools -.arguments.request.e)
          =(our actor.context.request.e)  =(our p.source.e)
          =(tid.e (tid-for our id request.e source.e salt.e))
          |(!stop.e &(cancel.e =(%accepted start.e)))
          ?~(terminal.e %.y &(?=(?(%sent %accepted) start.e) (lte (met 3 (jam u.terminal.e)) 262.144)))
          ?:  ?=(?(%finished %cancelled) phase.e)
            (terminal-valid e u.job)
          ?=(?(%running %unknown) stage.u.job)
      ==
  ==
--
