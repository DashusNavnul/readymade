::  Capability-authenticated past contact and connector-reported login only.
::  This library neither dispatches jobs nor grants readiness or model access.
/-  d=cli-inference-diagnostics, cli=cli-inference
/+  law=cli-inference, web=cli-inference-http
|%
++  report-valid
  |=  r=report:d
  ^-  ?
  ?&  (gth generation.r 0)  (lte generation.r 0xffff.ffff)
      (gth sequence.r 0)  (lte sequence.r 0xffff.ffff.ffff.ffff)
      !=(0 nonce.r)  (lte (met 0 nonce.r) 128)
      !=(0 instance.r)  (lte (met 0 instance.r) 128)
  ==
++  valid
  |=  [s=runtime:cli latest=latest:d]
  ^-  ?
  ?.  &((runtime-valid:law s) (lte ~(wyt by latest) 32))  %.n
  %+  levy  ~(tap by latest)
  |=  [key=@tas r=receipt:d]
  =/  generation  (~(get by generations.extra.s) key)
  ?~  generation  %.n
  ?&  =(key key.r)  (label:law key)  (label:law connector.r)
      !=(0 received.r)  (report-valid report.r)
      (lte generation.report.r u.generation)
      |((lth generation.report.r u.generation) (current s r))
  ==
++  save
  |=  [s=runtime:cli latest=latest:d]
  ^-  saved:d
  [%cli-inference-diagnostics-save-v1 s latest]
++  restore
  :: Exact old runtime DATA is retained; no diagnostics are inferred from jobs.
  |=  raw=*
  ^-  (unit saved:d)
  =/  wrapped  ((soft saved:d) raw)
  ?^  wrapped
    ?.  &(=(raw u.wrapped) (valid runtime.u.wrapped latest.u.wrapped))  ~
    wrapped
  =/  previous  (restore:law raw)
  ?~  previous  ~
  `(save u.previous ~)
++  current
  |=  [s=runtime:cli r=receipt:d]
  ^-  ?
  =/  b  (~(get by bindings.legacy.s) key.r)
  =/  g  (~(get by generations.extra.s) key.r)
  ?~  b  %.n
  ?~  g  %.n
  &(=([backend.r connector.r] [backend.u.b connector.u.b]) =(generation.report.r u.g))
++  admit
  :: Nonce identity is scoped to [key generation sequence]. Superseded
  :: sequences always refuse, so a delayed receipt cannot refresh its time.
  :: Diagnostics never mutate the runtime or consume a claim nonce.
  |=  [s=runtime:cli latest=latest:d at=@da input=input:d]
  ^-  (each admitted:d @tas)
  =/  paired  (authenticated:law legacy.s connector.input capability.input)
  ?~  paired  [%| %capability]
  =/  b=binding:cli  u.paired
  =/  generation  (~(get by generations.extra.s) key.b)
  ?~  generation  [%| %pairing-generation-unavailable]
  =/  r=report:d  report.input
  ?.  &(!=(0 at) (report-valid r))  [%| %diagnostic-invalid]
  ?.  =(generation.r u.generation)  [%| %pairing-generation-mismatch]
  =/  old  (~(get by latest) key.b)
  =/  prior=(unit receipt:d)
    ?~(old ~ ?:(=(generation.report.u.old u.generation) old ~))
  ?^  prior
    ?.  (current s u.prior)  [%| %diagnostic-binding-mismatch]
    ?:  =(sequence.r sequence.report.u.prior)
      ?.  =(r report.u.prior)  [%| %diagnostic-sequence-conflict]
      [%& [latest u.prior %.y]]
    ?:  (lth sequence.r sequence.report.u.prior)  [%| %diagnostic-stale]
    ?.  =(sequence.r +(sequence.report.u.prior))  [%| %diagnostic-sequence-gap]
    ?.  (lte received.u.prior at)  [%| %diagnostic-time-regression]
    [%& [(~(put by latest) key.b [key.b backend.b connector.b at r]) [key.b backend.b connector.b at r] %.n]]
  ?.  =(1 sequence.r)  [%| %diagnostic-sequence-gap]
  :: The map is bounded by the existing 32 pairing keys; ordinary job paths
  :: never consult this check. A new generation replaces its key's old row.
  ?:  &(=(~ old) (gte ~(wyt by latest) 32))  [%| %diagnostic-capacity]
  =/  receipt=receipt:d  [key.b backend.b connector.b at r]
  [%& [(~(put by latest) key.b receipt) receipt %.n]]
++  receipt-json
  |=  r=receipt:d
  ^-  json
  (pairs:enjs:format ~[['key' s+key.r] ['backend' s+backend.r] ['connector' s+connector.r] ['receivedAt' s+(scot %da received.r)] ['generation' s+(scot %ud generation.report.r)] ['sequence' s+(scot %ud sequence.report.r)] ['nonce' s+(scot %ux nonce.report.r)] ['instance' s+(scot %ux instance.report.r)] ['reportedAuthentication' s+authentication.report.r] ['liveness' s+'unobserved'] ['quota' s+'unobserved']])
++  inspect
  :: Caller supplies owner authentication or an exact active capability.
  :: Receipt time is past native contact, never proof of a currently live CLI.
  |=  [s=runtime:cli latest=latest:d key=@tas]
  ^-  json
  =/  b  (~(get by bindings.legacy.s) key)
  =/  g  (~(get by generations.extra.s) key)
  ?~  b  (status:law 'pairing-missing')
  ?~  g  (status:law 'pairing-generation-unavailable')
  =/  old  (~(get by latest) key)
  (pairs:enjs:format ~[['schema' s+'cli-inference-diagnostic-view-v1'] ['key' s+key] ['backend' s+backend.u.b] ['connector' s+connector.u.b] ['active' b+active.u.b] ['generation' s+(scot %ud u.g)] ['latest' ?~(old ~ (receipt-json u.old))] ['currentPairing' b+?~(old %.n (current s u.old))] ['liveness' s+'unobserved'] ['quota' s+'unobserved']])
++  decimal
  |=  [object=json key=@t]
  ^-  @ud
  =/  text=@t  (text:web object key 32)
  =/  number=@ud  (need (slaw %ud text))
  ?>  &(!=(0 number) (lte number 0xffff.ffff.ffff.ffff) =(text (scot %ud number)))
  number
++  decode
  |=  raw=@t
  ^-  (unit input:d)
  %-  mole
  |.
  ?>  (lte (met 3 raw) 4.096)
  =/  obj=json  (need (de:json:html raw))
  ?>  &(?=(%o -.obj) =(7 ~(wyt by p.obj)))
  =/  auth=@t  (text:web obj 'authentication' 32)
  ?>  ?=(authentication:d auth)
  =/  r=report:d
    [(decimal obj 'generation') (decimal obj 'sequence') (number:web obj 'nonce' %ux) (number:web obj 'instance' %ux) auth]
  ?>  (report-valid r)
  [(text:web obj 'connector' 64) (number:web obj 'capability' %uv) r]
++  credentials
  |=  raw=@t
  ^-  (unit [connector=@t capability=@uv])
  %-  mole
  |.
  ?>  (lte (met 3 raw) 1.024)
  =/  obj=json  (need (de:json:html raw))
  ?>  &(?=(%o -.obj) =(2 ~(wyt by p.obj)))
  [(text:web obj 'connector' 64) (number:web obj 'capability' %uv)]
++  refused
  |=  reason=@tas
  ^-  json
  (pairs:enjs:format ~[['status' s+'refused'] ['reason' s+reason]])
++  handle
  |=  [s=runtime:cli latest=latest:d at=@da observe=? raw=@t]
  ^-  [latest=latest:d response=json]
  ?:  observe
    =/  input  (credentials raw)
    ?~  input  [latest (refused %malformed-request)]
    =/  b  (authenticated:law legacy.s connector.u.input capability.u.input)
    ?~  b  [latest (refused %capability)]
    [latest (inspect s latest key.u.b)]
  =/  input  (decode raw)
  ?~  input  [latest (refused %malformed-request)]
  =/  moved  (admit s latest at u.input)
  ?:  ?=(%| -.moved)  [latest (refused p.moved)]
  [latest.p.moved (pairs:enjs:format ~[['status' s+?:(duplicate.p.moved 'duplicate' 'accepted')] ['receipt' (receipt-json receipt.p.moved)]])]
--
