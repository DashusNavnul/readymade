::  Literal prospective reports only. This codec authenticates neither the
::  provider nor timing; the owning observer must bind both before dispatch.
/+  responses=codex-responses
|%
+$  row  [call=@t values=(list @ud)]
++  identifier
  |=  id=@ux
  &((gth id 0) (lte (met 0 id) 256))
++  bounded-json
  ::  Bound parser depth before invoking JSON. Objects are never in this wire
  ::  format. Brackets inside strings, including escaped quotes, are inert.
  |=  text=@t
  ^-  ?
  ?.  (bounded:responses text 8.192)  %.n
  =/  chars=tape  (trip text)
  =/  depth=@ud  0
  =/  quoted=?  %.n
  =/  escaped=?  %.n
  |-  ^-  ?
  ?~  chars  &(=(0 depth) !quoted !escaped)
  =/  c=@t  i.chars
  ?:  quoted
    ?:  escaped  $(chars t.chars, escaped %.n)
    ?:  =(c 92)  $(chars t.chars, escaped %.y)
    $(chars t.chars, quoted !=(c 34))
  ?:  =(c 34)  $(chars t.chars, quoted %.y)
  ?:  |(=(c 123) =(c 125))  %.n
  ?:  =(c 91)
    ?.  (lth depth 4)  %.n
    $(chars t.chars, depth +(depth))
  ?:  =(c 93)
    ?:  =(0 depth)  %.n
    $(chars t.chars, depth (dec depth))
  $(chars t.chars)
++  values
  |=  [dimensions=@ud value=json]
  ^-  (unit (list @ud))
  ?.  ?=([%a *] value)  ~
  ?.  =((lent p.value) dimensions)  ~
  =/  rest=(list json)  p.value
  =/  out=(list @ud)  ~
  |-  ^-  (unit (list @ud))
  ?~  rest  `(flop out)
  =/  n  (natural:responses `i.rest)
  ?~  n  ~
  ?.  (lte u.n 1.000.000)  ~
  $(rest t.rest, out [u.n out])
++  decode
  ::  Calls must be the bounded, authenticated patch call IDs in reply order.
  ::  Four alternatives in one reply are one boundary, not four time steps.
  |=  [manifest=@ux dimensions=@ud calls=(list @t) text=@t]
  ^-  (each (list row) @tas)
  ?.  ?&  (identifier manifest)
          (gte dimensions 2)  (lte dimensions 16)
          (gte (lent calls) 1)  (lte (lent calls) 4)
          =((lent calls) ~(wyt in (~(gas in *(set @t)) calls)))
          (levy calls |=(c=@t (bounded:responses c 256)))
      ==  [%| %qpc-report-binding-invalid]
  ?:  =(0 text)  [%| %qpc-report-missing]
  ?.  (bounded-json text)  [%| %qpc-report-wire-invalid]
  =/  parsed  (de:json:html text)
  ?~  parsed  [%| %qpc-report-json-invalid]
  ?.  ?=([%a *] u.parsed)  [%| %qpc-report-shape-invalid]
  =/  parts=(list json)  p.u.parsed
  ?.  =(3 (lent parts))  [%| %qpc-report-shape-invalid]
  ?.  =([%s 'qpc-prospective-report-v1'] (snag 0 parts))
    [%| %qpc-report-version-mismatch]
  ?.  =([%s (scot %ux manifest)] (snag 1 parts))
    [%| %qpc-report-manifest-mismatch]
  =/  entries=json  (snag 2 parts)
  ?.  ?=([%a *] entries)  [%| %qpc-report-rows-invalid]
  =/  rest=(list json)  p.entries
  ?.  =((lent rest) (lent calls))  [%| %qpc-report-call-mismatch]
  =/  out=(list row)  ~
  |-  ^-  (each (list row) @tas)
  ?~  calls  [%& (flop out)]
  ?~  rest  [%| %qpc-report-call-mismatch]
  ?.  ?=([%a *] i.rest)  [%| %qpc-report-row-invalid]
  =/  fields=(list json)  p.i.rest
  ?.  =(2 (lent fields))  [%| %qpc-report-row-invalid]
  ?.  =([%s i.calls] (snag 0 fields))  [%| %qpc-report-call-mismatch]
  =/  confidence  (values dimensions (snag 1 fields))
  ?~  confidence  [%| %qpc-report-values-invalid]
  $(calls t.calls, rest t.rest, out [[i.calls u.confidence] out])
++  decode-ordered
  ::  V2 text carries vectors, not provider-assigned call IDs. The caller
  ::  supplies IDs from the authenticated reply in its immutable call order.
  ::  This codec does not choose a sampling boundary or authenticate origin.
  |=  [manifest=@ux dimensions=@ud calls=(list @t) text=@t]
  ^-  (each (list row) @tas)
  ?.  ?&  (identifier manifest)
          (gte dimensions 2)  (lte dimensions 16)
          (gte (lent calls) 1)  (lte (lent calls) 4)
          =((lent calls) ~(wyt in (~(gas in *(set @t)) calls)))
          (levy calls |=(c=@t (bounded:responses c 256)))
      ==  [%| %qpc-report-binding-invalid]
  ?:  =(0 text)  [%| %qpc-report-missing]
  ?.  (bounded-json text)  [%| %qpc-report-wire-invalid]
  =/  parsed  (de:json:html text)
  ?~  parsed  [%| %qpc-report-json-invalid]
  ?.  ?=([%a *] u.parsed)  [%| %qpc-report-shape-invalid]
  =/  parts=(list json)  p.u.parsed
  ?.  =(3 (lent parts))  [%| %qpc-report-shape-invalid]
  ?.  =([%s 'qpc-prospective-report-v2'] (snag 0 parts))
    [%| %qpc-report-version-mismatch]
  ?.  =([%s (scot %ux manifest)] (snag 1 parts))
    [%| %qpc-report-manifest-mismatch]
  =/  entries=json  (snag 2 parts)
  ?.  ?=([%a *] entries)  [%| %qpc-report-rows-invalid]
  =/  rest=(list json)  p.entries
  ?.  =((lent rest) (lent calls))  [%| %qpc-report-call-mismatch]
  =/  out=(list row)  ~
  |-  ^-  (each (list row) @tas)
  ?~  calls  [%& (flop out)]
  ?~  rest  [%| %qpc-report-call-mismatch]
  =/  confidence  (values dimensions i.rest)
  ?~  confidence  [%| %qpc-report-values-invalid]
  $(calls t.calls, rest t.rest, out [[i.calls u.confidence] out])
--
