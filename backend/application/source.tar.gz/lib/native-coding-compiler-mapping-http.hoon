::  Owner HTTP adapter for exact compiler module-root manifests. No inferred
::  roots, model configuration, compiler execution or permission grants.
/-  nc=native-coding
/+  runtime=native-coding-compiler-runtime, modules=native-coding-module-sources,
    loop=native-coding-loop, scoped=native-coding-session-project,
    project=native-coding-project, guard=viki-scry-guard,
    input=native-coding-onboarding-http, terminal=native-coding-terminal
|%
++  selected
  |=  [our=@p now=@da session=@ux]
  ^-  (each [project=project:nc ready=?] @tas)
  ?.  (agent-live:guard our now %viki)  [%| %mapping-viki-unavailable]
  =/  entry=(unit public-session:loop)
    .^((unit public-session:loop) %gx /(scot %p our)/viki/(scot %da now)/native-coding/session/(scot %ux session)/noun)
  ?~  entry  [%| %mapping-session-missing]
  ?.  =(our owner.session.u.entry)  [%| %mapping-session-owner]
  =/  projects=(map @t project:nc)
    .^((map @t project:nc) %gx /(scot %p our)/viki/(scot %da now)/native-coding/projects/noun)
  =/  p  (resolve:scoped our now projects session project.session.u.entry)
  ?:  ?=(%| -.p)  [%| p.p]
  ?.  =(working.p.p desk.working.session.u.entry)  [%| %mapping-session-workspace-changed]
  [%& [p.p =(%ready phase.u.entry)]]
++  read
  |=  [our=@p now=@da]
  ^-  (unit (map mapping-key:runtime mapping-record:runtime))
  ?.  (agent-live:guard our now %cantrip)  ~
  =/  held=(map mapping-key:runtime mapping-record:runtime)
    .^((map mapping-key:runtime mapping-record:runtime) %gx /(scot %p our)/cantrip/(scot %da now)/native-coding/compiler-mappings/noun)
  `held
++  target-json
  |=  [p=project:nc held=(map mapping-key:runtime mapping-record:runtime) t=build-target:nc]
  ^-  json
  =/  old  (~(get by held) [(configuration:project p) name.t])
  =/  exact=?  ?~(old %.y &(=(project.u.old p) =(target.mapping.u.old t)))
  =/  status=@t
    ?.  exact  'conflict'
    ?~  old  'legacy'
    ?:(enabled.u.old 'configured' 'revoked')
  (pairs:enjs:format ~[['name' s+name.t] ['entry' s+(spat entry.t)] ['targetDigest' s+(scot %ux (digest:modules t))] ['dependencies' a+(turn dependencies.t |=(pax=path s+(spat pax)))] ['status' s+status] ['configured' b+?=(^ old)] ['enabled' b+?~(old %.n &(exact enabled.u.old))] ['roots' a+?~(old ~ (turn roots.mapping.u.old |=(pax=path s+(spat pax))))]])
++  view
  |=  [our=@p now=@da session=@ux]
  ^-  json
  =/  found  (selected our now session)
  =/  held  (read our now)
  =/  reason=@tas
    ?:  ?=(%| -.found)  p.found
    ?~  held  %mapping-cantrip-unavailable
    %mapping-observed
  =/  targets=(list json)
    ?.  ?=(%& -.found)  ~
    ?~  held  ~
    =/  p=project:nc  project.p.found
    (turn (skim targets.p |=(t=build-target:nc =(%gallowglass kind.t))) |=(t=build-target:nc (target-json p u.held t)))
  (pairs:enjs:format ~[['available' b+&(?=(%& -.found) ?=(^ held))] ['reason' s+reason] ['session' s+(scot %ux session)] ['project' s+?:(?=(%& -.found) id.spec.project.p.found '')] ['configuration' s+?:(?=(%& -.found) (scot %ux (configuration:project project.p.found)) '')] ['ready' b+?:(?=(%& -.found) ready.p.found %.n)] ['targets' a+targets] ['rootLimit' (numb:enjs:format 16)]])
++  route
  ::  Caller authenticates Eyre owner before invoking any projection.
  |=  [our=@p now=@da url=@t]
  ^-  (unit json)
  =/  prefix=@t  '/apps/pataphor-native/coding/compiler-mapping?'
  ?.  &(=(prefix (cut 3 [0 (met 3 prefix)] url)) (lte (met 3 url) 180))  ~
  =/  text=@t  (rsh [3 (met 3 prefix)] url)
  =/  session  (slaw %ux text)
  ?~  session  ~
  ?.  &((lte (met 0 u.session) 256) =(text (scot %ux u.session)))  ~
  `(view our now u.session)
++  decode
  ::  Owner and CSRF checks precede this gate. The posted configuration/target
  ::  digest must match a fresh canonical projection, never browser policy.
  |=  [our=@p now=@da object=json]
  ^-  command:runtime
  =/  kind=@t  (text:input object 'kind' 40 %.y)
  =/  session=@ux  (digest:terminal (text:input object 'session' 82 %.y))
  =/  found  (selected our now session)
  ?>  ?=(%& -.found)
  =/  p=project:nc  project.p.found
  =/  configuration=@ux  (digest:terminal (text:input object 'configuration' 82 %.y))
  ?>  =(configuration (configuration:project p))
  =/  name=@tas  (name:terminal (text:input object 'target' 64 %.y))
  =/  matches=(list build-target:nc)  (skim targets.p |=(t=build-target:nc =(name name.t)))
  ?>  =(1 (lent matches))
  =/  target=build-target:nc  (snag 0 matches)
  ?>  &(!=(0 session) =(%gallowglass kind.target))
  ?>  =((digest:modules target) (digest:terminal (text:input object 'targetDigest' 82 %.y)))
  =/  held  (need (read our now))
  =/  old  (~(get by held) [configuration name])
  ?:  =('compiler-mapping-revoke' kind)
    ?>  ?=(^ old)
    ?>  &(=(project.u.old p) =(target.mapping.u.old target))
    [%native-coding-compiler-mapping-revoke-v1 configuration name]
  ?>  =(kind 'compiler-mapping-configure')
  ?>  ready.p.found
  =/  roots=(list path)
    %+  turn  (strings:input object 'roots' 16)
    |=  text=@t
    =/  pax=path  (path-of:terminal / text)
    ?>  &(=(text (spat pax)) (path-valid:project pax))
    pax
  =/  value=manifest:modules  [%native-coding-module-sources-v1 configuration target roots]
  ?>  (valid:modules p value)
  ?>  ?~(old %.y &(enabled.u.old =(project.u.old p) =(mapping.u.old value)))
  [%native-coding-compiler-mapping-configure-v1 p value]
--
