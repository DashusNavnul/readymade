::  A moon's bounded completion-review work. Configuration, controller and
::  Boxy invitations remain owned by the existing reviewer app. This helper
::  never grants review scope, completes a session, or invents an admitted vote.
/-  np=native-coding-provider, bx=boxy, jm=juggler-match
/+  review=native-coding-completion-review-request,
    legacy=native-coding-review-worker, inference=native-coding-inference
|%
+$  phase  ?(%pending %unknown %submitted %refused %cancelled)
+$  job
  $:  config=config:review  request=request:review  inference=request:np
      phase=phase  cancelled=?  reason=@tas
      contribution=(unit contribution:jm)  receipt=@ux
  ==
+$  state  [%native-coding-completion-review-worker-v1 jobs=(map @ux job)]
+$  transition  [state=state cards=(list card:agent:gall)]
+$  event
  $:  %native-coding-completion-review-event-v1
      binding=@ux
      generation=@ud
      request=@ux
      id=@ux
      phase=phase
      contribution=(unit contribution:jm)
      reason=@tas
      receipt=@ux
  ==
+$  command
  $%  [%native-coding-completion-review-request-v1 binding=@ux generation=@ud request=request:review]
      [%native-coding-completion-review-observe-v1 binding=@ux generation=@ud id=@ux request=@ux]
      [%native-coding-completion-review-cancel-v1 binding=@ux generation=@ud id=@ux request=@ux]
  ==
++  empty  ^-  state  [%native-coding-completion-review-worker-v1 ~]
++  busy
  |=  s=state
  ^-  ?
  (lien ~(val by jobs.s) |=(j=job ?=(?(%pending %unknown) phase.j)))
++  valid
  ::  Historical configuration remains frozen per job. The app separately
  ::  enforces exclusive IDs/capacity/busy state across all reviewer lanes.
  |=  [our=@p s=state]
  ^-  ?
  ?&  (lte ~(wyt by jobs.s) 32)
      (lte (lent (skim ~(val by jobs.s) |=(j=job ?=(?(%pending %unknown) phase.j)))) 1)
      %+  levy  ~(tap by jobs.s)
      |=  [id=@ux j=job]
      =/  prepared  (inference:review our config.j request.j)
      ?:  ?=(%| -.prepared)  %.n
      ?.  &(=(id id.request.j) =(id id.inference.j) =(p.prepared inference.j) (lte (met 3 reason.j) 128) (lte (met 0 receipt.j) 256))  %.n
      ?:  =(%submitted phase.j)
        ?~  contribution.j  %.n
        &(!cancelled.j (contribution-valid:review config.j request.j u.contribution.j receipt.j))
      ?.  ?=(~ contribution.j)  %.n
      ?:  ?=(?(%pending %unknown) phase.j)  =(0 receipt.j)
      %.y
  ==
++  local
  |=  [our=@p id=@ux command=command:inference]
  ^-  card:agent:gall
  [%pass /native-completion-review/local/(scot %tas -.command)/(scot %ux id) %agent [our %codex-inference] %poke %noun !>(command)]
++  notice
  |=  j=job
  ^-  card:agent:gall
  =/  value=event
    [%native-coding-completion-review-event-v1 (digest:review config.j) generation.config.j (digest:review request.j) id.request.j phase.j contribution.j reason.j receipt.j]
  [%pass /native-completion-review/reply/(scot %ux id.request.j) %agent [parent.config.j %viki] %poke %noun !>(value)]
++  put
  |=  [s=state j=job cards=(list card:agent:gall)]
  ^-  transition
  [s(jobs (~(put by jobs.s) id.request.j j)) [(notice j) cards]]
++  handle
  ::  The current owner configuration is supplied by the existing reviewer.
  ::  Observe/cancel use the historical job's binding even after reconfiguration.
  |=  [our=@p src=@p at=@da s=state configured=(unit config:review) action=command]
  ^-  (each transition @tas)
  ?.  ?=(%native-coding-completion-review-request-v1 -.action)
    =/  found  (~(get by jobs.s) id.action)
    ?~  found  [%| %completion-review-request-missing]
    =/  j=job  u.found
    ?.  ?&  =(src parent.config.j)  =(binding.action (digest:review config.j))
            =(generation.action generation.config.j)
            =(request.action (digest:review request.j))
        ==  [%| %completion-review-correlation-mismatch]
    ?.  ?=(?(%pending %unknown) phase.j)  [%& [s ~[(notice j)]]]
    =/  cancel=?  ?=(%native-coding-completion-review-cancel-v1 -.action)
    ::  A second cancellation observes the existing intent, never reissues it.
    =/  op=command:inference
      ?:(&(cancel !cancelled.j) [%native-coding-cancel id.action] [%native-coding-observe id.action])
    [%& (put s j(cancelled |(cancel cancelled.j)) ~[(local our id.action op)])]
  ?>  ?=(%native-coding-completion-review-request-v1 -.action)
  ?~  configured  [%| %completion-review-unconfigured]
  =/  c=config:review  u.configured
  ?.  &((config-valid:review our c) =(src parent.c) =(binding.action (digest:review c)) =(generation.action generation.c))
    [%| %completion-review-parent-binding-mismatch]
  =/  r=request:review  request.action
  =/  found  (~(get by jobs.s) id.r)
  ?^  found
    ?.  &(=(c config.u.found) =(r request.u.found))
      [%| %completion-review-request-reused]
    [%& [s ~[(notice u.found)]]]
  ?:  (busy s)  [%| %completion-review-inference-busy]
  ?:  (gte ~(wyt by jobs.s) 32)  [%| %completion-review-history-full]
  =/  prepared  (inference:review our c r)
  ?:  ?=(%| -.prepared)  [%| p.prepared]
  =/  j=job  [c r p.prepared %pending %.n %awaiting-provider ~ 0x0]
  ?.  (ready:legacy our at)
    [%& (put s j(phase %refused, reason %completion-review-controller-unavailable) ~)]
  [%& (put s j ~[(local our id.r [%native-coding-infer provider-key.c p.prepared])])]
++  receive
  ::  Publication is this moon's own authenticated Boxy poke. The returned
  ::  submitted phase describes an attempt; the parent must observe admission.
  |=  [our=@p src=@p s=state value=event:inference]
  ^-  transition
  ?.  =(our src)  [s ~]
  =/  found  (~(get by jobs.s) id.value)
  ?~  found  [s ~]
  =/  j=job  u.found
  =/  current  phase.j
  ?.  ?=(?(%pending %unknown) current)  [s ~]
  ?.  |(=(session.value session.config.j) &(=(0 session.value) ?=(%missing -.outcome.value)))  [s ~]
  ?:  ?=(%pending -.outcome.value)  [s ~]
  ?:  ?=(?(%missing %conflict %unknown) -.outcome.value)
    (put s j(phase %unknown, reason %completion-review-provider-unknown) ~)
  ?:  ?=(%cancelled -.outcome.value)
    (put s j(phase %cancelled, reason %completion-review-provider-cancelled) ~)
  ?:  ?=(%failed -.outcome.value)
    (put s j(phase %refused, reason reason.error.outcome.value, receipt raw-digest.error.outcome.value) ~)
  ?:  ?=(%refused -.outcome.value)
    (put s j(phase %refused, reason reason.outcome.value) ~)
  ?>  ?=(%result -.outcome.value)
  =/  reply=reply:np  value.outcome.value
  =.  receipt.j  raw-digest.reply
  ?:  cancelled.j
    (put s j(phase %refused, reason %completion-review-publication-revoked) ~)
  =/  decoded  (decode:review config.j request.j reply)
  ?:  ?=(%| -.decoded)  (put s j(phase %refused, reason p.decoded) ~)
  =/  envelope=command-envelope:bx  (envelope:review request.j p.decoded)
  =.  j  j(phase %submitted, reason %awaiting-canonical-boxy, contribution `p.decoded)
  (put s j ~[[%pass /native-completion-review/publish/(scot %ux id.value) %agent [parent.config.j %boxy] %poke %boxy-action !>(`action:bx`[%command envelope])]])
++  rejected
  ::  The app calls this only for a negative ACK on this helper's exact wire.
  |=  [s=state id=@ux operation=@tas]
  ^-  transition
  =/  found  (~(get by jobs.s) id)
  ?~  found  [s ~]
  =/  j=job  u.found
  ?:  =(%publish operation)
    ?.  =(%submitted phase.j)  [s ~]
    (put s j(reason %completion-review-boxy-delivery-refused) ~)
  =/  current  phase.j
  ?.  ?=(?(%pending %unknown) current)  [s ~]
  ?:  =(%native-coding-infer operation)
    (put s j(phase %refused, reason %completion-review-local-dispatch-refused) ~)
  ?.  ?=(?(%native-coding-observe %native-coding-cancel) operation)  [s ~]
  (put s j(phase %unknown, reason %completion-review-local-observation-refused) ~)
++  reload
  ::  One read after load, no automatic inference/cancel/publication replay.
  |=  [our=@p s=state]
  ^-  transition
  =/  cards=(list card:agent:gall)  ~
  =/  rows=(list job)  ~(val by jobs.s)
  |-  ^-  transition
  =/  rest=(list job)  rows
  ?~  rest  [s cards]
  =/  j=job  i.rest
  =/  current  phase.j
  ?.  ?=(?(%pending %unknown) current)  $(rows t.rest)
  =.  j  j(phase %unknown, reason %completion-review-reloaded-observing)
  $(rows t.rest, s s(jobs (~(put by jobs.s) id.request.j j)), cards (weld cards ~[(notice j) (local our id.request.j [%native-coding-observe id.request.j])]))
++  status
  |=  s=state
  ^-  *
  [%native-coding-completion-review-status-v1 (busy s) ~(wyt by jobs.s)]
--
