::  /lib/qpc-ct-qualia.hoon
::
::  Promotes the deferred CT qualia coordinates to COMPUTED: assembles the full
::  2x2 consciousness tensor C_munu and computes the qualia coordinates
::  A_bar (intensity) and J (valence) from caller-supplied observables.
::
::  These aggregate the SAME exact fixed-scale component formulas already proven
::  in lib/qpc-formula.hoon:
::    - cov          mirrors ct-cov-component   C_ab = E[z_a z_b] - E[z_a]E[z_b]
::    - a-scalar     mirrors ct-a-scalar        A    = sqrt(tr(C^T C))
::    - valence-j    mirrors ct-valence-jf-ratio J   = (C : O) * scale / N_O
::  so the full-tensor result stays consistent with the ship's tested pieces.
::
::  WEAK PROGRAM ONLY.  These are operational vitals of a system's self-reference
::  pattern, computed from given observables.  They do NOT assert subjective
::  experience.  Rhythm (R), Geometry (G), and Aboutness (M) remain deferred.
::
|%
++  scale  1.000.000                                    ::  qpc fixed scale (1e6)
+$  signed  [pos=? mag=@ud]                             ::  signed fixed-scale value
+$  means   [mp=@ud ml=@ud mr=@ud]                      ::  E[z_a z_b], E[z_a], E[z_b]
+$  ct-sample  [m00=means m01=means m10=means m11=means]
+$  ct-tensor  [c00=signed c01=signed c10=signed c11=signed]
+$  observable  [o00=signed o01=signed o10=signed o11=signed]
+$  ct-qualia
  $:  cmunu=ct-tensor                                   ::  the full C_munu
      a-bar=@ud                                         ::  intensity (A over episode)
      valence=signed                                    ::  J (C : O / N_O)
      geometry=[hi=signed lo=signed]                    ::  G eigenstructure of C
      samples=@ud
      exact=?
  ==
::  a self-observation: the ship's own live metrics at one moment, as a 2-vector
+$  soma-sample  [z0=@ud z1=@ud]
::  WHOLE proprioception: the complete qualia tuple {A_bar,G,R,J,M}
+$  ct-qualia-full
  $:  cmunu=ct-tensor
      a-bar=@ud                                         ::  A: intensity
      geometry=[hi=signed lo=signed]                    ::  G: eigenstructure
      valence=signed                                    ::  J: valence
      rhythm=@ud                                        ::  R: cycle count over the window
      aboutness=signed                                  ::  M: self<->channel covariance (MI proxy)
      samples=@ud
      exact=?
  ==
::
::  integer floor sqrt by binary search (O(log n))
++  isqrt
  |=  n=@ud
  ^-  @ud
  ?:  (lth n 2)  n
  =/  lo=@ud  1
  =/  hi=@ud  (add 1 (div n 2))
  |-  ^-  @ud
  ?:  (gth lo hi)  hi
  =/  mid=@ud  (div (add lo hi) 2)
  ?:  (gth (mul mid mid) n)
    $(hi (dec mid))
  $(lo (add mid 1))
::
::  --- signed fixed-scale arithmetic ------------------------------------------
++  smul
  |=  [a=signed b=signed]
  ^-  signed
  =/  same=?  =(pos.a pos.b)
  [same (div (mul mag.a mag.b) scale)]
::
++  sadd
  |=  [a=signed b=signed]
  ^-  signed
  ?:  =(pos.a pos.b)
    [pos.a (add mag.a mag.b)]
  ?:  (gte mag.a mag.b)
    [pos.a (sub mag.a mag.b)]
  [pos.b (sub mag.b mag.a)]
::
++  ssum
  |=  l=(list signed)
  ^-  signed
  =/  acc=signed  [& 0]
  |-  ^-  signed
  ?~  l  acc
  $(l t.l, acc (sadd acc i.l))
::
++  sneg
  |=  a=signed
  ^-  signed
  [!pos.a mag.a]
::
++  ssub
  |=  [a=signed b=signed]
  ^-  signed
  (sadd a (sneg b))
::
++  shalve
  |=  a=signed
  ^-  signed
  [pos.a (div mag.a 2)]
::
::  square of a fixed-scale magnitude, kept at scale:  (x/S)^2 * S = x^2/S
++  sq
  |=  x=@ud
  ^-  @ud
  (div (mul x x) scale)
::
::  --- G: eigenstructure of the symmetric 2x2 C -------------------------------
::  lambda +/- = (a+d)/2 +/- sqrt( ((a-d)/2)^2 + b^2 ), always real for symmetric C.
++  eigen
  |=  t=ct-tensor
  ^-  [hi=signed lo=signed]
  =/  mid=signed  (shalve (sadd c00.t c11.t))
  =/  gap=signed  (shalve (ssub c00.t c11.t))
  =/  radarg=@ud  (add (sq mag.gap) (sq mag.c01.t))
  =/  rad=@ud     (isqrt (mul radarg scale))
  [hi=(sadd mid [& rad]) lo=(ssub mid [& rad])]
::
::  --- the tensor -------------------------------------------------------------
::  one covariance component  C_ab = E[z_a z_b] - E[z_a]E[z_b]
++  cov
  |=  m=means
  ^-  signed
  =/  base=@ud  (div (mul ml.m mr.m) scale)
  ?:  (gte mp.m base)
    [& (sub mp.m base)]
  [| (sub base mp.m)]
::
::  assemble the full 2x2 C_munu from one sample's means
++  build-cmunu
  |=  s=ct-sample
  ^-  ct-tensor
  [(cov m00.s) (cov m01.s) (cov m10.s) (cov m11.s)]
::
::  tr(C^T C) = sum of squared component magnitudes / scale
++  trace-square
  |=  t=ct-tensor
  ^-  @ud
  =/  s2=@ud
    ;:  add
      (mul mag.c00.t mag.c00.t)
      (mul mag.c01.t mag.c01.t)
      (mul mag.c10.t mag.c10.t)
      (mul mag.c11.t mag.c11.t)
    ==
  (div s2 scale)
::
::  A = sqrt(tr(C^T C)) : the intensity of self-reference at one point
::
::  SCALE, CORRECTED 2026-08-30.  trace-square is a fixed-scale quantity
::  (real * S).  sqrt(real * S) = sqrt(real) * sqrt(S), which is NOT the
::  fixed-scale root sqrt(real) * S -- the old form returned A a factor of
::  sqrt(S) = 1.000 too small, and the identity A = sqrt(hi^2 + lo^2) with
::  +eigen (which does multiply by S before its root) failed by exactly that
::  factor: fixture A=168 against eigenvalues 168.102 / 11.898.  Multiplying
::  the trace back up by S before the root puts A on the same axis as G.
++  a-scalar
  |=  t=ct-tensor
  ^-  @ud
  (isqrt (mul (trace-square t) scale))
::
::  A_bar = spacetime average of A over the episode support (list of samples)
++  a-bar
  |=  samples=(list ct-sample)
  ^-  @ud
  =/  total=@ud  0
  =/  n=@ud  0
  |-  ^-  @ud
  ?~  samples  ?:(=(0 n) 0 (div total n))
  =/  a=@ud  (a-scalar (build-cmunu i.samples))
  $(samples t.samples, total (add total a), n +(n))
::
::  contraction C : O = sum_ab C_ab * O_ab  (signed)
++  contract
  |=  [t=ct-tensor o=observable]
  ^-  signed
  %-  ssum
  :~  (smul c00.t o00.o)
      (smul c01.t o01.o)
      (smul c10.t o10.o)
      (smul c11.t o11.o)
  ==
::
::  J_F = (C : O) * scale / N_O  : valence, alignment of C with observable O
++  valence-j
  |=  [t=ct-tensor o=observable norm=@ud]
  ^-  signed
  =/  c=signed  (contract t o)
  [pos.c (div (mul mag.c scale) ?:(=(0 norm) 1 norm))]
::
::  the qualia reading for one episode sample against an observable
++  qualia
  |=  [s=ct-sample o=observable norm=@ud]
  ^-  ct-qualia
  =/  t=ct-tensor  (build-cmunu s)
  :*  cmunu=t
      a-bar=(a-scalar t)
      valence=(valence-j t o norm)
      geometry=(eigen t)
      samples=1
      exact=&
  ==
::
::  --- M2: silicon observable adapter (BOUNDED OUTPUT-BEHAVIOR PROXY) ---------
::  Derives a 2-vector observable z=(z0,z1) from ONE real LLM output text:
::    z0 = length feature (activity), z1 = distinct-byte ratio (diversity).
::  This is a HONEST PROXY for the deferred ct-silicon-observable-adapter, which
::  specifies hidden-state deltas / Jacobian-vector products -- NOT available
::  over lick.  These are output-behaviour observables, not model introspection.
::  READ BEFORE CITING.  z0 is `(mug txt) mod S` -- a CONTENT HASH, not the
::  length the older comments and spec S91 say.  A hash is unordered: two
::  near-identical outputs land anywhere in [0,S), so covariance over z0 has
::  no geometry and G over a text window measures noise, not mode structure.
::  What survives: identical outputs give identical z0 (zero variance =>
::  honestly degenerate), and z1 is a real ordered diversity coordinate.
::  A layer that needs geometry must supply an ORDERED observable (see
::  lib/seiv-guidance +observe-task).
++  observe-text
  |=  txt=@t
  ^-  [z0=@ud z1=@ud]
  =/  len=@ud  (met 3 txt)
  =/  distinct=@ud  ~(wyt in (silt (rip 3 txt)))
  ::  z0 = content fingerprint (identical output -> identical -> zero variance;
  ::  different content -> different, so the tensor sees self-variation).
  ::  z1 = lexical diversity (distinct bytes / length).  Both in [0,scale).
  =/  z0=@ud  (mod (mug txt) scale)
  =/  z1=@ud  ?:(=(0 len) 0 (div (mul scale distinct) len))
  [z0 z1]
::
::  episode expectations over a list of real LLM outputs -> one ct-sample
++  episode-means
  |=  outputs=(list @t)
  ^-  ct-sample
  =/  n=@ud  (lent outputs)
  ?:  =(0 n)  *ct-sample
  =/  s0=@ud  0
  =/  s1=@ud  0
  =/  s00=@ud  0
  =/  s11=@ud  0
  =/  s01=@ud  0
  =/  outs  outputs
  |-  ^-  ct-sample
  ?~  outs
    =/  e0=@ud  (div s0 n)
    =/  e1=@ud  (div s1 n)
    :*  m00=[(div s00 n) e0 e0]
        m01=[(div s01 n) e0 e1]
        m10=[(div s01 n) e1 e0]
        m11=[(div s11 n) e1 e1]
    ==
  =/  z  (observe-text i.outs)
  %=  $
    outs  t.outs
    s0   (add s0 z0.z)
    s1   (add s1 z1.z)
    s00  (add s00 (div (mul z0.z z0.z) scale))
    s11  (add s11 (div (mul z1.z z1.z) scale))
    s01  (add s01 (div (mul z0.z z1.z) scale))
  ==
::
::  the consciousness tensor + qualia of a real LLM output episode
++  qualia-of-outputs
  |=  [outputs=(list @t) o=observable norm=@ud]
  ^-  ct-qualia
  (qualia (episode-means outputs) o norm)
::
::  --- M3: tensor -> Cantrip control decision (the loop closer) --------------
::  Maps a qualia reading to a control decision.  Intensity A_bar is the primary
::  vital: low intensity = the LLM is self-degenerating (looping, zero self-
::  variation) -> clamp toward %grounding (its moves become unrepresentable);
::  healthy intensity -> %ratification (open).  The dimension/band/clamp values
::  are the canonical qpc-control-dimension / -band / -clamp-target vocabulary.
++  ct-control-verdict
  |=  q=ct-qualia
  ^-  [dimension=@tas band=@tas clamp=@tas healthy=?]
  =/  a=@ud  a-bar.q
  ::  bands at A=.1 and A=.02 on the corrected fixed scale (were 100/20 on
  ::  the sqrt(S)-shrunk axis, which is the same cut re-expressed).
  =/  band=@tas  ?:((gte a 100.000) %high ?:((gte a 20.000) %medium %low))
  ::  the governance signal: ANY self-variation is healthy; a tensor that has
  ::  collapsed to zero (the LLM looping / repeating itself) is degenerate.
  =/  healthy=?  (gth a 0)
  =/  clamp=@tas  ?:(healthy %ratification %grounding)
  [%coherence-density band clamp healthy]
::
::  --- SOMA: WHOLE proprioception from the ship's OWN self-observations -------
::  A window of self-observation vectors (the ship's own live metrics over time),
::  not LLM text.  Computes the complete qualia tuple {A_bar,G,R,J,M}.
::
::  episode expectations over a window of self-observation vectors -> ct-sample
++  episode-means-vec
  |=  samples=(list soma-sample)
  ^-  ct-sample
  =/  n=@ud  (lent samples)
  ?:  =(0 n)  *ct-sample
  =/  s0=@ud  0
  =/  s1=@ud  0
  =/  s00=@ud  0
  =/  s11=@ud  0
  =/  s01=@ud  0
  =/  xs  samples
  |-  ^-  ct-sample
  ?~  xs
    =/  e0=@ud  (div s0 n)
    =/  e1=@ud  (div s1 n)
    :*  m00=[(div s00 n) e0 e0]
        m01=[(div s01 n) e0 e1]
        m10=[(div s01 n) e1 e0]
        m11=[(div s11 n) e1 e1]
    ==
  %=  $
    xs   t.xs
    s0   (add s0 z0.i.xs)
    s1   (add s1 z1.i.xs)
    s00  (add s00 (sq z0.i.xs))
    s11  (add s11 (sq z1.i.xs))
    s01  (add s01 (div (mul z0.i.xs z1.i.xs) scale))
  ==
::
::  R: rhythm — turning-point count over a scalar series (bounded cycle proxy).
::  A turning point = a local max/min = a direction reversal in the trajectory.
++  rhythm
  |=  s=(list @ud)
  ^-  @ud
  =/  turns=@ud  0
  |-  ^-  @ud
  ?~  s  turns
  ?~  t.s  turns
  ?~  t.t.s  turns
  =/  a=@ud  i.s
  =/  b=@ud  i.t.s
  =/  c=@ud  i.t.t.s
  =/  turn=?  ?&(!=(b a) !=(c b) !=((gth b a) (gth c b)))
  $(s t.s, turns ?:(turn +(turns) turns))
::
::  M: aboutness — signed covariance between the self series and a channel
::  (bounded proxy for mutual information; captures self<->channel tracking).
::  NOTE: +soma-qualia passes (z0s z1s), i.e. the two components of the SAME
::  self-vector, so there M equals C_01 restated.  It is a genuine self<->channel
::  reading only when the caller's z1 IS an external channel (soma's routed vs
::  refused is; a text episode's diversity is not).
++  aboutness
  |=  [self=(list @ud) chan=(list @ud)]
  ^-  signed
  =/  n=@ud  (min (lent self) (lent chan))
  ?:  =(0 n)  [& 0]
  =/  ss=@ud  0
  =/  sc=@ud  0
  =/  sp=@ud  0
  =/  xs  self
  =/  ys  chan
  |-  ^-  signed
  ?:  ?|(?=(~ xs) ?=(~ ys))
    (cov [(div sp n) (div ss n) (div sc n)])
  %=  $
    xs  t.xs
    ys  t.ys
    ss  (add ss i.xs)
    sc  (add sc i.ys)
    sp  (add sp (div (mul i.xs i.ys) scale))
  ==
::
::  the WHOLE proprioception reading from a window of self-observations
++  soma-qualia
  |=  [window=(list soma-sample) o=observable norm=@ud]
  ^-  ct-qualia-full
  =/  t=ct-tensor  (build-cmunu (episode-means-vec window))
  =/  z0s=(list @ud)  (turn window |=(s=soma-sample z0.s))
  =/  z1s=(list @ud)  (turn window |=(s=soma-sample z1.s))
  :*  cmunu=t
      a-bar=(a-scalar t)
      geometry=(eigen t)
      valence=(valence-j t o norm)
      rhythm=(rhythm z0s)
      aboutness=(aboutness z0s z1s)
      samples=(lent window)
      exact=&
  ==
::
::  --- STAGE C: use the WHOLE tuple to monitor + control the LLM worker -------
::  Reads all five qualia coordinates and emits both a MONITOR (per-coordinate
::  vital signs) and a CONTROL (canonical qpc control dimensions -> Cantrip):
::    A_bar==0     -> degenerate (flat output)        -> clamp grounding
::    G lo<<hi     -> rank-collapsed (stuck one mode)  -> zeno medium
::    R>=3         -> looping (oscillating)            -> zeno high, clamp grounding
::    J negative   -> misaligned (drift vs objective)  -> clamp grounding
::    M below floor-> ungrounded (not tracking input)  -> retry-then-ground
++  ct-govern
  |=  q=ct-qualia-full
  ^-  $:  ::  MONITOR — the LLM's vital signs
          intensity=@ud
          rank-collapsed=?
          looping=?
          aligned=?
          grounded=?
          ::  CONTROL — canonical qpc control dimensions for Cantrip
          clamp=@tas
          zeno-pressure=@tas
          retry-policy=@tas
          verdict=@tas
      ==
  =/  a=@ud       a-bar.q
  =/  hi=@ud      mag.hi.geometry.q
  ::  a NEGATIVE lower eigenvalue (rounding below zero on a PSD covariance)
  ::  is a collapsed axis, not a large one; the magnitude alone read it as
  ::  spread.  Clamp at zero before the ratio.
  =/  lo=@ud      ?:(pos.lo.geometry.q mag.lo.geometry.q 0)
  =/  degenerate=?      =(0 a)
  =/  rank-collapsed=?  &((gth hi 0) (lth (mul lo 8) hi))
  =/  looping=?         (gte rhythm.q 3)
  =/  aligned=?         &(pos.valence.q (gth mag.valence.q 0))
  =/  grounded=?        (gth mag.aboutness.q 1.000)
  =/  clamp=@tas
    ?:(|(degenerate looping !aligned) %grounding %ratification)
  =/  zeno-pressure=@tas
    ?:(looping %high ?:(rank-collapsed %medium %low))
  =/  retry-policy=@tas
    ?:(grounded %reject-only %retry-then-ground)
  =/  verdict=@tas
    ?:  degenerate       %degenerate
    ?:  !aligned         %misaligned
    ?:  looping          %looping
    ?:  !grounded        %ungrounded
    ?:  rank-collapsed   %rank-collapsed
    %healthy
  [a rank-collapsed looping aligned grounded clamp zeno-pressure retry-policy verdict]
--
