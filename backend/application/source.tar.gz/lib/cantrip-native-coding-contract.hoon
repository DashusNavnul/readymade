::  Native tool journal types and request commitment, without dispatch.
::  These molds do not validate grants or authorize an operation.
/-  nc=native-coding
|%
++  key
  |=  r=tool-request:nc
  ^-  @ux
  (shax (jam [%native-coding-tool-v1 r]))
+$  grant
  $:  id=@ux  session=@ux  actor=@p  project=project:nc
      operations=(set operation:nc)
      inspections=(set [app=@tas pax=path])  max-eval-work=@ud
  ==
+$  scope  [grant=grant revoked=(unit @da)]
+$  record
  $:  grant=@ux  request=tool-request:nc  at=@da
      stage=?(%running %finished %unknown %cancelled %rejected)
      result=(unit tool-result:nc)
  ==
+$  organ  [grants=(map @ux scope) records=(map @ux record)]
--
