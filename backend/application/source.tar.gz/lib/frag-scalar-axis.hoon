::  /lib/frag-scalar-axis
::
::  Reversible structural addresses for every logical SmolLM2 scalar.  This is
::  pure pinned geometry: no weights, inference, Graf facts, or Clay reads.
::  Scalar meaning is structural only; causal evidence remains component-grain.
::
/-  f=frag, g=frag-geometry
/+  fg=frag-geometry
|%
+$  coordinate  [id=tensor-id:g indices=(list @ud)]
+$  owner
  $%  [%component component=fine-component:f]
      [%shared id=tensor-id:g]
  ==
+$  scalar-role
  ?(%token-embedding %input-normalization %query-projection %key-projection %value-projection %output-projection %post-normalization %gate-projection %up-projection %down-projection %final-normalization)
+$  scalar-address
  $:  coordinate=coordinate
      index=@ud
      axis=@
      owner=owner
      role=scalar-role
  ==
::
::  Canonical forward-pass tensor order.  The 30 layers each own nine logical
::  intervals; tied output projection aliases the embedding and is not doubled.
++  layer-tensors
  |=  layer=@ud
  ^-  (list tensor-id:g)
  ?>  (lth layer layer-count:f)
  :~  [%input-norm layer]
      [%projection layer %q]
      [%projection layer %k]
      [%projection layer %v]
      [%projection layer %o]
      [%post-norm layer]
      [%projection layer %gate]
      [%projection layer %up]
      [%projection layer %down]
  ==
::  Decode one model-wide logical index to its tensor interval in O(1).
++  tensor-for-index
  |=  index=@ud
  ^-  (unit tensor-id:g)
  ?.  (lth index logical-weight-count:fg)  ~
  ?:  (lth index embedding-count:fg)
    `[%embedding ~]
  ?:  (gte index final-norm-start:fg)
    `[%final-norm ~]
  =/  layer-local=@ud  (sub index embedding-count:fg)
  =/  layer=@ud  (div layer-local layer-weight-count:fg)
  =/  local=@ud  (mod layer-local layer-weight-count:fg)
  ?:  (lth local (projection-offset:fg %q))
    `[%input-norm layer]
  ?:  (lth local (projection-offset:fg %k))
    `[%projection layer %q]
  ?:  (lth local (projection-offset:fg %v))
    `[%projection layer %k]
  ?:  (lth local (projection-offset:fg %o))
    `[%projection layer %v]
  ?:  (lth local (sub (projection-offset:fg %gate) 576))
    `[%projection layer %o]
  ?:  (lth local (projection-offset:fg %gate))
    `[%post-norm layer]
  ?:  (lth local (projection-offset:fg %up))
    `[%projection layer %gate]
  ?:  (lth local (projection-offset:fg %down))
    `[%projection layer %up]
  `[%projection layer %down]
::
::  All pinned tensors are rank one or two.  Decode row-major local position
::  without a recursive shape walker, keeping Ford's type surface flat.
++  coordinate-for-id
  |=  [id=tensor-id:g index=@ud]
  ^-  (unit coordinate)
  ?.  (tensor-valid:fg id)  ~
  =/  start=@ud  (tensor-start:fg id)
  =/  size=@ud  (shape-product:fg (logical-shape:fg id))
  ?.  ?&  (lte start index)
          (lth index (add start size))
      ==
    ~
  =/  local=@ud  (sub index start)
  ?-  -.id
    %embedding
      `[id ~[(div local 576) (mod local 576)]]
    %input-norm  `[id ~[local]]
    %post-norm   `[id ~[local]]
    %final-norm  `[id ~[local]]
    %projection
      =/  width=@ud  ?:(=(%down kind.id) 1.536 576)
      `[id ~[(div local width) (mod local width)]]
  ==
++  coordinate-for-index
  |=  index=@ud
  ^-  (unit coordinate)
  =/  id  (tensor-for-index index)
  ?~  id  ~
  (coordinate-for-id u.id index)
::
++  role-for
  |=  coordinate=coordinate
  ^-  scalar-role
  =/  id=tensor-id:g  id.coordinate
  ?-  -.id
    %embedding   %token-embedding
    %input-norm  %input-normalization
    %post-norm   %post-normalization
    %final-norm  %final-normalization
    %projection
      ?-  kind.id
        %q     %query-projection
        %k     %key-projection
        %v     %value-projection
        %o     %output-projection
        %gate  %gate-projection
        %up    %up-projection
        %down  %down-projection
      ==
  ==
++  owner-for
  |=  coordinate=coordinate
  ^-  owner
  =/  id=tensor-id:g  id.coordinate
  =/  index=@ud  (need (coordinate-index:fg id indices.coordinate))
  =/  local=@ud  (sub index (tensor-start:fg id))
  ?-  -.id
    %embedding   [%shared id]
    %input-norm  [%shared id]
    %post-norm   [%shared id]
    %final-norm  [%shared id]
    %projection
      =/  width=@ud  ?:(=(%down kind.id) 1.536 576)
      =/  first=@ud  (div local width)
      =/  second=@ud  (mod local width)
      ?-  kind.id
        %q     [%component [%attn-head layer.id (div first 64)]]
        %k     [%component [%kv-group layer.id (div first 64)]]
        %v     [%component [%kv-group layer.id (div first 64)]]
        %o     [%component [%attn-head layer.id (div second 64)]]
        %gate  [%component [%mlp-neuron layer.id first]]
        %up    [%component [%mlp-neuron layer.id first]]
        %down  [%component [%mlp-neuron layer.id second]]
      ==
  ==
::
++  address-for-coordinate
  |=  coordinate=coordinate
  ^-  (unit scalar-address)
  =/  index  (coordinate-index:fg id.coordinate indices.coordinate)
  ?~  index  ~
  =/  address=scalar-address
    :*  coordinate
        u.index
        (structural-axis:fg u.index)
        (owner-for coordinate)
        (role-for coordinate)
    ==
  `address
++  address-for-index
  |=  index=@ud
  ^-  (unit scalar-address)
  =/  coordinate  (coordinate-for-index index)
  ?~  coordinate  ~
  (address-for-coordinate u.coordinate)
::
::  structural-axis is peg(8, 2^28 + index), so its reserved subtree begins at
::  binary 1000 followed by 28 zero bits.  Equality against the forward gate
::  prevents an atom merely near that interval from being accepted.
++  axis-base  (peg 8 (bex 28))
++  index-for-axis
  |=  axis=@
  ^-  (unit @ud)
  ?.  (lte axis-base axis)  ~
  =/  index=@ud  (sub axis axis-base)
  ?.  (lth index logical-weight-count:fg)  ~
  ?.  =((structural-axis:fg index) axis)  ~
  `index
++  address-for-axis
  |=  axis=@
  ^-  (unit scalar-address)
  =/  index  (index-for-axis axis)
  ?~  index  ~
  (address-for-index u.index)
--
