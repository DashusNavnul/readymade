::  lib/jock-run.hoon
::
::  The bounded execution law (program steps 46-49).  A fuel-metered
::  Nock 4K interpreter: every +neval entry costs one fuel, so any
::  formula -- including a divergent one -- terminates in at most
::  `fuel` steps with ~ instead of hanging the serf.  Crashes (bad
::  axis, increment of a cell, malformed formula, non-loobean 6) are
::  also ~: the gate's only positive answer is a computed product.
::
::  CONFORMANCE: on terminating, non-crashing formulas +neval agrees
::  with vere's .* exactly (asserted by ted/ph/jock-run-proof against
::  a live minted Jock program).  Slow by construction -- this is the
::  law, not the lane; a jet may never change its answers.
::
::  Status (honesty lattice): %computed -- evaluator + proof.
|%
++  status  %computed
::  +slot: axis fragment, ~ on miss.
++  slot
  |=  [axe=@ n=*]
  ^-  (unit *)
  ?:  =(0 axe)  ~
  |-  ^-  (unit *)
  ?:  =(1 axe)  `n
  ?@  n  ~
  =/  d  (cap axe)
  $(axe (mas axe), n ?:(=(%2 d) -.n +.n))
::  +dent: replace the fragment at axis, ~ on miss.
++  dent
  |=  [axe=@ new=* n=*]
  ^-  (unit *)
  ?:  =(0 axe)  ~
  ?:  =(1 axe)  `new
  ?@  n  ~
  =/  d  (cap axe)
  =/  inner  $(axe (mas axe), n ?:(=(%2 d) -.n +.n))
  ?~  inner  ~
  `?:(=(%2 d) [u.inner +.n] [-.n u.inner])
::  +neval: fueled Nock.  Returns [remaining-fuel product]; out=~ is
::  crash OR fuel exhaustion -- both are lawful refusals.
++  neval
  |=  [fuel=@ud sub=* fol=*]
  ^-  [fuel=@ud out=(unit *)]
  ?:  =(0 fuel)  [0 ~]
  =.  fuel  (dec fuel)
  ?@  fol  [fuel ~]
  ?:  ?=([^ *] fol)                    ::  autocons
    =/  l  $(fol -.fol)
    ?~  out.l  [fuel.l ~]
    =/  r  $(fuel fuel.l, fol +.fol)
    ?~  out.r  [fuel.r ~]
    [fuel.r `[u.out.l u.out.r]]
  ?+    fol  [fuel ~]
      [%0 b=@]
    [fuel (slot b.fol sub)]
  ::
      [%1 b=*]
    [fuel `b.fol]
  ::
      [%2 b=* c=*]
    =/  s  $(fol b.fol)
    ?~  out.s  [fuel.s ~]
    =/  f  $(fuel fuel.s, fol c.fol)
    ?~  out.f  [fuel.f ~]
    $(fuel fuel.f, sub u.out.s, fol u.out.f)
  ::
      [%3 b=*]
    =/  r  $(fol b.fol)
    ?~  out.r  [fuel.r ~]
    [fuel.r `?@(u.out.r 1 0)]
  ::
      [%4 b=*]
    =/  r  $(fol b.fol)
    ?~  out.r  [fuel.r ~]
    ?^  u.out.r  [fuel.r ~]
    [fuel.r `+(;;(@ u.out.r))]
  ::
      [%5 b=* c=*]
    =/  l  $(fol b.fol)
    ?~  out.l  [fuel.l ~]
    =/  r  $(fuel fuel.l, fol c.fol)
    ?~  out.r  [fuel.r ~]
    [fuel.r `?:(=(u.out.l u.out.r) 0 1)]
  ::
      [%6 b=* c=* d=*]
    =/  t  $(fol b.fol)
    ?~  out.t  [fuel.t ~]
    ?:  =(0 u.out.t)  $(fuel fuel.t, fol c.fol)
    ?:  =(1 u.out.t)  $(fuel fuel.t, fol d.fol)
    [fuel.t ~]
  ::
      [%7 b=* c=*]
    =/  s  $(fol b.fol)
    ?~  out.s  [fuel.s ~]
    $(fuel fuel.s, sub u.out.s, fol c.fol)
  ::
      [%8 b=* c=*]
    =/  p  $(fol b.fol)
    ?~  out.p  [fuel.p ~]
    $(fuel fuel.p, sub [u.out.p sub], fol c.fol)
  ::
      [%9 b=@ c=*]
    =/  cor  $(fol c.fol)
    ?~  out.cor  [fuel.cor ~]
    =/  arm  (slot b.fol u.out.cor)
    ?~  arm  [fuel.cor ~]
    $(fuel fuel.cor, sub u.out.cor, fol u.arm)
  ::
      [%10 [b=@ c=*] d=*]
    =/  new  $(fol c.fol)
    ?~  out.new  [fuel.new ~]
    =/  tgt  $(fuel fuel.new, fol d.fol)
    ?~  out.tgt  [fuel.tgt ~]
    [fuel.tgt (dent b.fol u.out.new u.out.tgt)]
  ::
      [%11 [b=* c=*] d=*]                ::  dynamic hint: clue is
    =/  clu  $(fol c.fol)                ::  computed (crashes count),
    ?~  out.clu  [fuel.clu ~]            ::  then discarded
    $(fuel fuel.clu, fol d.fol)
  ::
      [%11 b=@ c=*]                      ::  static hint
    $(fol c.fol)
  ==
::  +run-bounded: the gate surface.  ~ = refused (crash or fuel).
++  run-bounded
  |=  [fuel=@ud sub=* fol=*]
  ^-  (unit *)
  out:(neval fuel sub fol)
--
