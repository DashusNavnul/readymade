::  /lib/desk-shell
::
::  Which files two agents are fighting over, computed rather than merged.
::
::  PURE, and deliberately so: the caller reads hashes out of Clay and hands
::  them in, so a proof can drive every branch with no live desk, no mount,
::  and no ship.  The seat-nesting bug survived for months because its gate
::  lived inside a 5.000-line agent nothing could import.  Not again.
::
::  It also keeps the scry discipline at the edge, which is not a style
::  preference: `.^` on a missing path bails and +mule does not catch it, so
::  the reading has to happen somewhere that can survive a miss.  Nothing in
::  this file can bail.
::
/-  ds=desk-shell
|%
::  every path any desk in the workspace knows about.
++  all-paths
  |=  [base=held:ds forks=(list fork:ds)]
  ^-  (set path)
  =/  rest=(list fork:ds)  forks
  =/  out=(set path)  ~(key by base)
  |-  ^-  (set path)
  ?~  rest  out
  $(rest t.rest, out (~(uni in out) ~(key by held.i.rest)))
::
::  what one desk holds at one path.
::
::  "the caller did not read this path" and "the desk does not have it"
::  collapse to the same answer, ~, and that is deliberate: the caller reads
::  a whole desk at once, so absence from the reading IS absence from the
::  desk.  Where that assumption does not hold -- a partial reading -- the
::  caller must say so, because this cannot tell.
++  look
  |=  [h=held:ds pax=path]
  ^-  blob:ds
  =/  got=(unit blob:ds)  (~(get by h) pax)
  ?~  got  ~
  u.got
::
::  THE VERDICT ON ONE PATH.  The only place a status is decided.
++  judge
  |=  [base=blob:ds forks=(list at-fork:ds)]
  ^-  verdict:ds
  =/  diff=(list at-fork:ds)
    (skim forks |=(f=at-fork:ds !=(blob.f base)))
  ?~  diff
    :*  status=%same
        divergent=~
        duplicated=%.n
        why=(rap 3 'all ' (scot %ud (lent forks)) ' forks match base' ~)
    ==
  =/  head=blob:ds  blob.i.diff
  ::  RE-WIDEN before the wet gates.  `diff` is a lest here, and a
  ::  ?~-refined lest meeting +turn / +levy nest-fails at desk build -- a
  ::  failure this codebase has already paid for once.
  =/  dl=(list at-fork:ds)  diff
  =/  names=(list desk-id:ds)  (turn dl |=(f=at-fork:ds desk-id.f))
  ::  do the divergent forks agree with EACH OTHER?
  =/  agree=?  (levy dl |=(f=at-fork:ds =(blob.f head)))
  ?.  agree
    :*  status=%contested
        divergent=names
        duplicated=%.n
        why=(rap 3 (scot %ud (lent names)) ' forks changed this and do not agree' ~)
    ==
  ::  they agree.  More than one agreeing fork is the same work done twice.
  =/  dup=?  (gth (lent names) 1)
  ::  base=~ means nobody had it and somebody added it.  head=~ means
  ::  everyone who touched it deleted it.  Both cannot hold: a fork equal
  ::  to base is not in `diff` at all.
  =/  kind=status:ds
    ?~  base  %added
    ?~  head  %removed
    %edited
  =/  note=@t
    ?:  dup
      %+  rap  3
      :~  (scot %ud (lent names))
          ' forks made the SAME change: duplicated work, not conflict'
      ==
    %+  rap  3
    :~  'changed by '
        (scot %ud (lent names))
        ' of '
        (scot %ud (lent forks))
        ' forks'
    ==
  :*  status=kind
      divergent=names
      duplicated=dup
      why=note
  ==
::
++  tally-of
  |=  rows=(list entry:ds)
  ^-  tally:ds
  %+  roll  rows
  |=  [e=entry:ds acc=tally:ds]
  ^-  tally:ds
  =.  acc
    ?-  status.verdict.e
      %same       acc(same +(same.acc))
      %added      acc(added +(added.acc))
      %removed    acc(removed +(removed.acc))
      %edited     acc(edited +(edited.acc))
      %contested  acc(contested +(contested.acc))
    ==
  ?.  duplicated.verdict.e  acc
  acc(duplicated +(duplicated.acc))
::
::  THE WHOLE WORKSPACE.  base against every fork, path by path.
++  compare
  |=  [base=fork:ds forks=(list fork:ds) at=@da]
  ^-  survey:ds
  =/  paths=(list path)  ~(tap in (all-paths held.base forks))
  =/  rows=(list entry:ds)
    %+  turn  paths
    |=  pax=path
    ^-  entry:ds
    =/  cells=(list at-fork:ds)
      %+  turn  forks
      |=  f=fork:ds
      ^-  at-fork:ds
      [desk-id.f (look held.f pax)]
    [pax (judge (look held.base pax) cells)]
  :*  %1
      base=desk-id.base
      forks=(turn forks |=(f=fork:ds desk-id.f))
      at=at
      entries=rows
      tally=(tally-of rows)
  ==
::
::  ---- views: the same survey, asked different questions ----
::
::  the problems pane.  What two agents are actually fighting over.
++  contested
  |=  s=survey:ds
  ^-  (list entry:ds)
  (skim entries.s |=(e=entry:ds ?=(%contested status.verdict.e)))
::
::  the waste pane.  Not conflict -- overlap.  Nobody else reports this.
++  duplicated
  |=  s=survey:ds
  ^-  (list entry:ds)
  (skim entries.s |=(e=entry:ds duplicated.verdict.e))
::
::  the source-control pane for ONE agent: what this fork changed.
++  by-fork
  |=  [s=survey:ds who=desk-id:ds]
  ^-  (list entry:ds)
  %+  skim  entries.s
  |=  e=entry:ds
  (lien divergent.verdict.e |=(d=desk-id:ds =(d who)))
::
::  who else is touching what this fork touched.  The question an agent
::  should ask BEFORE it starts, and the reason the region leases exist.
++  overlap
  |=  [s=survey:ds who=desk-id:ds]
  ^-  (list [pax=path others=(list desk-id:ds)])
  %+  murn  (by-fork s who)
  |=  e=entry:ds
  ^-  (unit [path (list desk-id:ds)])
  =/  others=(list desk-id:ds)
    (skip divergent.verdict.e |=(d=desk-id:ds =(d who)))
  ?~  others  ~
  `[pax.e others]
--
