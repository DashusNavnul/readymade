::  Pinned readable check sources. No compilation, mutation or inference.
::  The supported Ford header subset is explicit: /- and /+ names only.
/-  nc=native-coding
/+  project=native-coding-project, files=native-coding-files,
    q=qpc-native-outcome, obs=qpc-observation
|%
+$  receipt  [source=revision:nc files=(map path @ux) evidence=@t]
+$  reader  $-(path (each replacement:nc @tas))
++  space  |=(c=@tD |(=(32 c) =(9 c)))
++  trim
  |=  text=tape
  ^-  tape
  ?~  text  ~
  ?:  (space i.text)  $(text t.text)
  text
++  word-valid
  |=  text=tape
  ^-  ?
  ?&  !=(~ text)  (lte (lent text) 128)
      %+  levy  text
      |=  c=@tD
      |(&((gte c 'a') (lte c 'z')) &((gte c '0') (lte c '9')) =('-' c))
  ==
++  import-path
  |=  [kind=@tas token=tape]
  ^-  path
  ?>  !=(~ token)
  =/  equal=(unit @ud)  (find "=" token)
  =/  name=tape
    ?~  equal  token
    ?>  (word-valid (scag u.equal token))
    (slag +(u.equal) token)
  =.  name  ?:(&((gth (lent name) 0) =('*' (snag 0 name))) (slag 1 name) name)
  ?>  (word-valid name)
  =/  leaf=@ta  `@ta`(crip name)
  /[kind]/[leaf]/hoon
++  names
  |=  [kind=@tas text=tape]
  ^-  (list path)
  =/  comment=(unit @ud)  (find "::" text)
  =.  text  ?~(comment text (scag u.comment text))
  =/  token=tape  ~
  =/  out=(list path)  ~
  |-
  ?~  text
    (flop ?~(token out [(import-path kind (flop token)) out]))
  ?:  |((space i.text) =(',' i.text))
    $(text t.text, token ~, out ?~(token out [(import-path kind (flop token)) out]))
  $(text t.text, token [i.text token])
++  parse-imports
  ::  Stop at the first body expression. Indentation cannot turn a body
  ::  rune into an import continuation; unfamiliar Ford runes fail closed.
  |=  source=@t
  ^-  (list path)
  =/  lines=(list @t)  (to-wain:format source)
  =/  kind=@tas  %none
  =/  out=(list path)  ~
  |-
  ?~  lines  out
  =/  original=tape  (trip i.lines)
  =/  line=tape  (trim original)
  ?:  =(0 (lent line))  $(lines t.lines)
  ?:  =("::" (scag 2 line))  $(lines t.lines)
  =/  first=@tD  (snag 0 line)
  ::  Debug prologues are outside this supported header subset. Never
  ::  treat one as an end marker while accepting unexamined later imports.
  ?>  !=("!:" (scag 2 line))
  ?:  =('/' first)
    ?>  =(original line)
    ?>  (gte (lent line) 3)
    ?>  |(=("/+" (scag 2 line)) =("/-" (scag 2 line)))
    ?>  (space (snag 2 line))
    =/  next=@tas  ?:(=('+' (snag 1 line)) %lib %sur)
    =/  added=(list path)  (names next (slag 2 line))
    ?>  !=(~ added)
    $(lines t.lines, kind next, out (weld out added))
  ?:  ?&  !=(%none kind)  !=(original line)
          |(&((gte first 'a') (lte first 'z')) =('*' first))
      ==
    =/  added=(list path)  (names kind line)
    ?>  !=(~ added)
    $(lines t.lines, out (weld out added))
  ::  Parse the complete remaining Hoon expression, including literals.
  ::  A later Ford import cannot hide beyond a claimed body boundary.
  =/  body=@t
    (crip (zing (turn lines |=(l=@t (weld (trip l) "\0a")))))
  ?>  ?=(^ (mole |.((ream body))))
  out
++  imports
  |=  source=@t
  ^-  (each (list path) @tas)
  =/  parsed  (mole |.((parse-imports source)))
  ?~  parsed  [%| %qpc-source-import-syntax-unsupported]
  [%& u.parsed]
++  shared-suffix
  ::  Share ASCII bytes only: neither JSON string can split a UTF-8 character.
  |=  [left=@t right=@t]
  ^-  @t
  =/  a=tape  (flop (trip left))
  =/  b=tape  (flop (trip right))
  =/  suffix=tape  ~
  |-
  ?~  a  (crip suffix)
  ?~  b  (crip suffix)
  ?.  &(=(i.a i.b) (gth i.a 0) (lth i.a 128))  (crip suffix)
  $(a t.a, b t.b, suffix [i.a suffix])
++  check-expression
  |=  row=case:q
  ^-  (each @t @tas)
  =/  selected=(list [name=@tas expression=@t])
    (skim checks.target.row |=([name=@tas expression=@t] =(name check.row)))
  ?.  =(1 (lent selected))  [%| %qpc-source-check-ambiguous]
  [%& expression:(snag 0 selected)]
++  shared-disclosure
  ::  Lossless versioned fallback. Complete expressions remain present as
  ::  row prefix + shared suffix; no hashes or excerpts substitute for bytes.
  |=  [source=revision:nc artifact=path cs=cases:q closure=(map path @ux)]
  ^-  (each @t @tas)
  ?.  =(2 (lent rows.cs))  [%| %qpc-source-disclosure-bound]
  =/  first  (check-expression (snag 0 rows.cs))
  =/  second  (check-expression (snag 1 rows.cs))
  ?:  ?=(%| -.first)  [%| p.first]
  ?:  ?=(%| -.second)  [%| p.second]
  =/  suffix=@t  (shared-suffix p.first p.second)
  ?:  =(0 (met 3 suffix))  [%| %qpc-source-disclosure-bound]
  =/  rows=(list json)  ~
  =/  todo=(list case:q)  rows.cs
  |-
  ?~  todo
    =/  context=json
      [%a ~[s+'Frozen named checks; source is readable through native tools' s+(scot %p owner.source) s+(scot %tas desk.source) s+(scot %ud number.source) s+(scot %uv root.source) s+(scot %uv commit.source) s+(spat artifact) s+(scot %ux (shax (jam closure)))]]
    =/  text=@t
      %-  en:json:html
      [%a ~[s+'qpc-source-disclosure-v2' s+'Each row is [proposition,target,entry,check,prefix,sha256,bytes]. Its full expression is prefix + shared suffix, with no separator.' context s+suffix [%a (flop rows)]]]
    ?.  (obs-text text)  [%| %qpc-source-disclosure-bound]
    [%& text]
  =/  row=case:q  i.todo
  =/  chosen  (check-expression row)
  ?:  ?=(%| -.chosen)  [%| p.chosen]
  =/  expression=@t  p.chosen
  =/  prefix=@t
    (crip (scag (sub (met 3 expression) (met 3 suffix)) (trip expression)))
  ?>  =(expression (cat 3 prefix suffix))
  =/  value=json
    [%a ~[s+(scot %tas proposition.row) s+(scot %tas name.target.row) s+(spat entry.target.row) s+(scot %tas check.row) s+prefix s+(scot %ux (shax expression)) s+(scot %ud (met 3 expression))]]
  $(todo t.todo, rows [value rows])
++  disclosure
  |=  [source=revision:nc artifact=path cs=cases:q closure=(map path @ux)]
  ^-  (each @t @tas)
  =/  rows=(list json)  ~
  =/  todo=(list case:q)  rows.cs
  |-
  ?~  todo
    =/  text=@t
      %-  en:json:html
      [%a ~[s+'Frozen named checks; source is readable through native tools' s+(scot %p owner.source) s+(scot %tas desk.source) s+(scot %ud number.source) s+(scot %uv root.source) s+(scot %uv commit.source) s+(spat artifact) s+(scot %ux (shax (jam closure))) [%a (flop rows)]]]
    ?:  (obs-text text)  [%& text]
    (shared-disclosure source artifact cs closure)
  =/  row=case:q  i.todo
  =/  chosen  (check-expression row)
  ?:  ?=(%| -.chosen)  [%| p.chosen]
  =/  value=json
    [%a ~[s+(scot %tas proposition.row) s+(scot %tas name.target.row) s+(spat entry.target.row) s+(scot %tas check.row) s+p.chosen]]
  $(todo t.todo, rows [value rows])
++  obs-text  |=(value=@t (evidence-valid:obs value))
++  inspect
  |=  [p=project:nc source=revision:nc artifact=path cs=cases:q fetch=reader]
  ^-  (each receipt @tas)
  ?.  ?&  (valid:project p)  (revision-valid:project source)
          =(authority.spec.p owner.source)  =(working.p desk.source)
          (writable:project p artifact)  =(2 (lent rows.cs))
          =((turn rows.cs |=(r=case:q proposition.r)) ~[%compatibility %intended-behavior])
          (lte (met 3 (jam cs)) 32.768)
      ==  [%| %qpc-source-input-invalid]
  =/  pending=(list path)  ~[artifact]
  =/  cases=(list case:q)  rows.cs
  =/  seeds=(each (list path) @tas)
    |-  ^-  (each (list path) @tas)
    ?~  cases  [%& pending]
    =/  c=case:q  i.cases
    ?.  ?&  =(%hoon kind.target.c)  !=(%compile check.c)
            (lien targets.p |=(t=build-target:nc =(t target.c)))
            !(writable:project p entry.target.c)
            =((lent checks.target.c) ~(wyt in (silt (turn checks.target.c |=([name=@tas expression=@t] name)))))
        ==  [%| %qpc-source-check-invalid]
    $(cases t.cases, pending (weld [entry.target.c dependencies.target.c] pending))
  ?:  ?=(%| -.seeds)  [%| p.seeds]
  =.  pending  p.seeds
  =/  held=(map path @ux)  ~
  =/  bytes=@ud  0
  |-
  ?~  pending
    =/  shown  (disclosure source artifact cs held)
    ?:  ?=(%| -.shown)  [%| p.shown]
    [%& [source held p.shown]]
  =/  pax=path  i.pending
  ?:  (~(has by held) pax)  $(pending t.pending)
  ?.  ?&  (lth ~(wyt by held) 256)  (readable:project p pax)
          ?=(^ pax)  =(%hoon (rear pax))
          |(=(pax artifact) !(writable:project p pax))
      ==  [%| %qpc-source-closure-refused]
  =/  got  (fetch pax)
  ?:  ?=(%| -.got)  [%| p.got]
  =/  body=replacement:nc  p.got
  ?.  &((content-valid:files p pax body) (lte (met 3 source.body) 262.144))
    [%| %qpc-source-file-invalid]
  =.  bytes  (add bytes (met 3 source.body))
  ?.  (lte bytes 2.097.152)  [%| %qpc-source-closure-bound]
  =/  found  (imports source.body)
  ?:  ?=(%| -.found)  [%| p.found]
  =/  declared=(list path)  (~(gut by dependencies.p) pax ~)
  %=  $
    pending  (weld p.found (weld declared t.pending))
    held  (~(put by held) pax `@ux`(page-to-lobe:clay [mark.body source.body]))
  ==
++  verify
  ::  Pure witness entry point. An injected map never authenticates a ship.
  |=  [p=project:nc source=revision:nc artifact=path cs=cases:q bodies=(map path replacement:nc)]
  ^-  (each receipt @tas)
  =/  fetch=reader
    |=  pax=path
    ^-  (each replacement:nc @tas)
    =/  got  (~(get by bodies) pax)
    ?~(got [%| %qpc-source-file-missing] [%& u.got])
  (inspect p source artifact cs fetch)
++  read
  ::  Every byte and lobe is read from the full pinned revision. No current
  ::  filesystem, declared-only closure, or caller file map supplies authority.
  |=  [our=@p at=@da p=project:nc source=revision:nc artifact=path cs=cases:q]
  ^-  (each receipt @tas)
  ?.  &((valid:project p) =(our owner.source) =(our authority.spec.p))
    [%| %qpc-source-owner-mismatch]
  =/  got  (current:project our at p)
  ?:  ?=(%| -.got)  [%| p.got]
  ?.  =(source revision.working.p.got)  [%| %qpc-source-revision-mismatch]
  =/  tree=tree:nc  working.p.got
  =/  fetch=reader  |=(pax=path (file:files p tree pax))
  (inspect p source artifact cs fetch)
--
