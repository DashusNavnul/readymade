::  QPC probabilities for one frozen sealed pool under every retained law
::  revision. Pure recomputation from retained inputs (pool, exact candidate
::  requests, frozen A, law history); nothing is drawn, selected or executed.
::  Missing A pauses the controller (contract 5.3): no default A, ever.
/-  nc=native-coding
/+  select=qpc-select, energy=qpc-energy, measurements=qpc-measurement-view,
    pool=qpc-native-pool, tools=cantrip-native-coding
|%
+$  revision  [id=@ux gain=@ud footprint=@ud indirection=@ud saved=?]
+$  row  [call=@t candidate=(unit @ux) effect=(unit @ux) args=(unit tool-args:nc)]
+$  input
  $:  pool=@ux  session=@ux  rows=(list row)
      attention=(each ratio:select @tas)  laws=(list revision)
  ==
+$  scored  [row=row energy=(unit energy:energy)]
++  inputs
  ::  Join each sealed pool with its exact candidate requests (Cantrip's tool
  ::  ledger, keyed by the row's tool key), its session's law history (newest
  ::  first) and its frozen A. A missing ledger entry leaves the footprint unknown.
  |=  $:  pools=(list pool:pool)  ledger=(unit organ:tools)
          laws=(map @ux (list revision))  attention=(map @ux (each ratio:select @tas))
      ==
  ^-  (list input)
  %+  turn  pools
  |=  p=pool:pool
  ^-  input
  :*  id.p  session.p
      %+  turn  rows.p
      |=  r=row:pool
      ^-  row
      =/  kept  ?~(ledger ~ (~(get by records.u.ledger) tool.r))
      [call.r candidate.r effect.r ?~(kept ~ `arguments.request.u.kept)]
      (~(gut by attention) session.p [%| %attention-unavailable])
      (~(gut by laws) session.p ~)
  ==
++  score
  |=  [rows=(list row) r=revision]
  ^-  (list scored)
  %+  turn  rows
  |=  x=row
  ?~  candidate.x  [x ~]
  =/  e  (measure:energy args.x [footprint.r indirection.r])
  [x ?:(?=(%& -.e) `p.e ~)]
++  candidates
  ::  Hard refusals and unscored rows stay out of the kernel entirely.
  |=  rows=(list scored)
  ^-  (list candidate:select)
  %+  murn  rows
  |=  s=scored
  ^-  (unit candidate:select)
  ?~  candidate.row.s  ~
  ?~  effect.row.s  ~
  ?~  energy.s  ~
  `[`@ud`u.candidate.row.s u.effect.row.s %.y value.u.energy.s]
++  distribution
  |=  [in=input r=revision]
  ^-  (each receipt:select @tas)
  ?:  ?=(%| -.attention.in)  [%| p.attention.in]
  =/  kernel  (candidates (score rows.in r))
  ?~  kernel  [%| %no-eligible-candidate]
  ::  The draw only picks; weights and total do not depend on it.
  (choose:select p.attention.in gain.r 0 kernel)
++  ratio
  |=  r=ratio:select
  ^-  json
  (pairs:enjs:format ~[['numerator' [%s (decimal:measurements num.r)]] ['denominator' [%s (decimal:measurements den.r)]]])
++  energy-json
  |=  e=(unit energy:energy)
  ^-  json
  ?~  e  [%~]
  %-  pairs:enjs:format
  :~  ['value' (ratio value.u.e)]
      ['changedLines' ?~(changed.u.e [%~] (numb:enjs:format u.changed.u.e))]
      ['footprintLoss' (ratio value.footprint.u.e)]
      ['footprintKnown' [%b known.footprint.u.e]]
      ['indirectionLoss' (ratio value.indirection.u.e)]
      ['indirectionKnown' [%b known.indirection.u.e]]
  ==
++  law
  |=  [in=input r=revision]
  ^-  json
  =/  d  (distribution in r)
  =/  each-energy=(list scored)  (score rows.in r)
  %-  pairs:enjs:format
  :~  ['revision' [%s (scot %ux id.r)]]
      ['saved' [%b saved.r]]
      ['gain' (numb:enjs:format gain.r)]
      ['criterionWeights' [%a ~[(numb:enjs:format footprint.r) (numb:enjs:format indirection.r)]]]
      ['energies' [%a (turn each-energy |=(s=scored (pairs:enjs:format ~[['call' [%s call.row.s]] ['energy' (energy-json energy.s)]])))]]
      ['status' [%s ?:(?=(%| -.d) 'paused' 'computed')]]
      ['reason' ?:(?=(%| -.d) [%s (scot %tas p.d)] [%~])]
      ['contrast' ?:(?=(%| -.d) [%~] [%b contrast.p.d])]
      ['total' ?:(?=(%| -.d) [%~] [%s (decimal:measurements total.p.d)])]
      :-  'kernelWeights'
      ?:  ?=(%| -.d)  [%a ~]
      :-  %a
      %+  turn  weights.p.d
      |=  w=weighted:select
      (pairs:enjs:format ~[['candidate' [%s (scot %ux `@ux`id.choice.w)]] ['weight' [%s (decimal:measurements weight.w)]]])
  ==
++  render
  |=  pools=(list input)
  ^-  json
  %-  pairs:enjs:format
  :~  ['schema' [%s 'qpc-distribution-view-v1']]
      ['kernel' [%s 'P_i = q_i / sum q, q_i = exp(-(1+A) g (E_i - E_min) / chi_v1), chi_v1 = 5083204/1000000']]
      ['energy' [%s 'E = (wf*footprint + wi*indirection)/(wf+wi); indirection has no evaluator (loss 1, unknown)']]
      ['limits' [%s 'Recomputed from retained inputs per law revision. Whether A was frozen before the pool was sealed is not yet verified.']]
      :-  'pools'
      :-  %a
      %+  turn  pools
      |=  in=input
      %-  pairs:enjs:format
      :~  ['pool' [%s (scot %ux pool.in)]]
          ['session' [%s (scot %ux session.in)]]
          ['attention' ?:(?=(%| -.attention.in) [%~] (ratio p.attention.in))]
          ['laws' [%a (turn laws.in |=(r=revision (law in r)))]]
      ==
  ==
--
