::  One owner-authenticated peer page. Recheck membership, policy, law and
::  every exact grant; fetch only currently eligible sessions in this page.
/-  ps=cantrip-project-sessions, nc=native-coding
/+  page=cantrip-project-sessions-page, core=cantrip-project-sessions,
    previous=cantrip-project-sessions-runtime, tools=cantrip-native-coding,
    scoped=native-coding-session-project, guard=viki-scry-guard,
    law=cantrip-law-window
|%
++  observe
  |=  [b=bowl:gall held=scopes:core q=page-query:ps w=window:law]
  ^-  (each page-response:ps @tas)
  ?.  (query-valid:page q)  [%| %sessions-query-invalid]
  =/  admitted  (admitted:core [project.q nonce.q] w)
  ?:  ?=(%| -.admitted)  [%| p.admitted]
  =/  found  (catalog:previous b project.q)
  ?~  found  [%| %sessions-member-refused]
  ?.  (~(has by members.u.found) src.b)  [%| %sessions-member-refused]
  ?.  (agent-live:guard our.b now.b %viki)  [%| %viki-unavailable]
  =/  registered=(map @t project:nc)
    .^((map @t project:nc) %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/projects/noun)
  =/  base  (~(get by registered) project.q)
  ?~  base  [%| %sessions-member-refused]
  =/  picked  (select:page our.b src.b q held w u.found u.base)
  ?:  ?=(%| -.picked)  [%| p.picked]
  =/  eligible  (candidates:core our.b src.b [project.q nonce.q] held.p.picked)
  =/  solved=resolved:core
    %-  malt
    ^-  (list [@ux (each project:nc @tas)])
    %+  turn  grants.eligible
    |=  g=grant:tools
    [session.g (resolve:scoped our.b now.b registered session.g project.q)]
  =/  views=(list session-view:core)
    %+  murn  grants.eligible
    |=  g=grant:tools
    ^-  (unit session-view:core)
    .^((unit session-view:core) %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/session/(scot %ux session.g)/noun)
  (observe:page our.b src.b now.b q held w u.found u.base solved views)
++  watch
  |=  [b=bowl:gall held=scopes:core pax=path w=window:law]
  ^-  (each (list card:agent:gall) @tas)
  =/  parsed  (parse:page pax)
  ?~  parsed  [%| %path-invalid]
  ?.  =(src.b peer.u.parsed)  [%| %foreign-peer]
  =/  result  (observe b held query.u.parsed w)
  ?:  ?=(%| -.result)  [%| p.result]
  [%& (cards:page pax p.result)]
--
