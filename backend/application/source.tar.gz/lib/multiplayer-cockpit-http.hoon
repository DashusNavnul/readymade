::  /lib/multiplayer-cockpit-http
::
::  Pure browser-wire adapter.  It computes no project fact and grants no
::  authority.  Every decision control and /why link retains exact coordinates.
::
/-  mc=multiplayer-changeset, mch=multiplayer-cockpit-http,
    mcr=multiplayer-cockpit-review, mpc=multiplayer-cockpit,
    md=multiplayer-dispute
/+  mcrl=multiplayer-cockpit-review
=,  dejs:format
|%
++  digest-json
  |=  value=@ux
  ^-  json
  s+(scot %ux value)
++  unit-digest-json
  |=  value=(unit @ux)
  ^-  json
  ?~(value ~ (digest-json u.value))
++  path-json
  |=  value=path
  ^-  json
  s+(crip (spud value))
::
++  diff-json
  |=  row=diff-row:mcr
  ^-  json
  %-  pairs:enjs:format
  :~  ['kind' s+(scot %tas kind.row)]
      ['path' (path-json path.row)]
      ['before' (unit-digest-json before.row)]
      ['after' (unit-digest-json after.row)]
  ==
++  why-route-json
  |=  route=why-route:mcr
  ^-  json
  %-  pairs:enjs:format
  :~  ['kind' s+'why']
      ['project' s+project.route]
      ['changeset' (digest-json changeset.route)]
      ['path' (path-json path.route)]
  ==
++  why-link-json
  |=  link=why-link:mcr
  ^-  json
  %-  pairs:enjs:format
  :~  ['label' s+label.link]
      ['route' (why-route-json route.link)]
      ['actor' s+(scot %p actor.link)]
      ['messages' a+(turn messages.link digest-json)]
      ['receipt' (digest-json receipt.link)]
  ==
++  inspection-json
  |=  row=changeset-inspection:mcr
  ^-  json
  %-  pairs:enjs:format
  :~  ['changeset' (digest-json changeset.row)]
      ['project' s+project.row]
      ['task' s+task.row]
      ['workspace' s+(scot %tas workspace.row)]
      ['actor' s+(scot %p actor.row)]
      ['base-revision' (numb:enjs:format base-revision.row)]
      ['snapshot-digest' (digest-json snapshot-digest.row)]
      ['diffs' a+(turn diffs.row diff-json)]
      ['messages' a+(turn messages.row digest-json)]
      ['receipt' (digest-json receipt.row)]
      ['why' a+(turn why.row why-link-json)]
  ==
::
++  act-json
  |=  act=decision-act:mcr
  ^-  json
  %-  pairs:enjs:format
  :~  ['version' (numb:enjs:format version.body.act)]
      ['project' s+project.body.act]
      ['changeset' (digest-json changeset.body.act)]
      ['contradiction' (digest-json contradiction.body.act)]
      ['contest' (digest-json contest.body.act)]
      ['verdict' s+(scot %tas verdict.body.act)]
      ['actor' s+(scot %p actor.body.act)]
      ['digest' (digest-json digest.act)]
  ==
++  ux-of
  |=  value=json
  ^-  @ux
  (need (slaw %ux (so value)))
++  ship-of
  |=  value=json
  ^-  @p
  (need (slaw %p (so value)))
++  verdict-of
  |=  value=json
  ^-  verdict:md
  ?+  `@tas`(so value)  !!
    %accept  %accept
    %refuse  %refuse
    %revise  %revise
    %split   %split
    %hold    %hold
  ==
++  act-of
  ^-  $-(json wire-act:mch)
  %-  ot
  :~  version+ni
      project+so
      changeset+ux-of
      contradiction+ux-of
      contest+ux-of
      verdict+verdict-of
      actor+ship-of
      digest+ux-of
  ==
++  parse-submission
  |=  text=@t
  ^-  submission-result:mch
  =/  parsed=(unit json)  (de:json:html text)
  ?~  parsed  [%| %malformed-json]
  =/  decoded  (mule |.((act-of u.parsed)))
  ?-  -.decoded
    %|  [%| %out-of-grammar]
    %&
      =/  wire=wire-act:mch  p.decoded
      =/  act=decision-act:mcr
        [[version.wire project.wire changeset.wire contradiction.wire contest.wire verdict.wire actor.wire] digest.wire]
      ?.  (decision-act-valid:mcrl act)  [%| %invalid-act]
      [%& act]
  ==
++  control-json
  |=  control=decision-control:mcr
  ^-  json
  %-  pairs:enjs:format
  :~  ['kind' s+(scot %tas kind.control)]
      ['state' s+(scot %tas state.control)]
      ['why' s+why.control]
      ['act' (act-json act.control)]
  ==
++  ruling-json
  |=  ruling=(unit ruling:md)
  ^-  json
  ?~  ruling  ~
  %-  pairs:enjs:format
  :~  ['verdict' s+(scot %tas verdict.body.u.ruling)]
      ['law-digest' (digest-json law-digest.body.u.ruling)]
      ['ruled-at' s+(scot %da ruled-at.body.u.ruling)]
      ['digest' (digest-json digest.u.ruling)]
  ==
++  judgment-json
  |=  row=judgment-row:mcr
  ^-  json
  %-  pairs:enjs:format
  :~  ['project' s+project.row]
      ['changeset' (digest-json changeset.row)]
      ['contradiction' (digest-json contradiction.row)]
      ['contest' (digest-json contest.row)]
      ['suggested' s+(scot %tas suggested.row)]
      ['controls' a+(turn controls.row control-json)]
      ['ruling' (ruling-json ruling.row)]
  ==
::
++  invalid-control
  |=  controls=(list decision-control:mcr)
  ^-  (unit @ux)
  ?~  controls  ~
  ?.  (decision-act-valid:mcrl act.i.controls)  `digest.act.i.controls
  $(controls t.controls)
++  first-invalid-control
  |=  rows=(list judgment-row:mcr)
  ^-  (unit @ux)
  ?~  rows  ~
  =/  invalid=(unit @ux)  (invalid-control controls.i.rows)
  ?^  invalid  invalid
  $(rows t.rows)
++  snapshot-json
  |=  view=snapshot:mcr
  ^-  json
  =/  cockpit=snapshot:mpc  cockpit.view
  %-  pairs:enjs:format
  :~  ['type' s+'MULTIPLAYER_COCKPIT_REVIEW_V1']
      ['actor' s+(scot %p actor.cockpit)]
      ['observed-at' s+(scot %da observed-at.cockpit)]
      ['cockpit-digest' (digest-json `@ux`(shax (jam cockpit)))]
      ['inspections' a+(turn inspections.view inspection-json)]
      ['requires-you' a+(turn requires-you.view judgment-json)]
      ['resolved' a+(turn resolved.view judgment-json)]
      ['why-links' a+(turn why-links.view why-link-json)]
      ['authority-granted' b+%.n]
  ==
++  render
  |=  view=snapshot:mcr
  ^-  result:mch
  ?:  ?|(authority-granted.view authority-granted.cockpit.view)
    [%| [%authority-claim ~]]
  =/  invalid=(unit @ux)
    (first-invalid-control (weld requires-you.view resolved.view))
  ?^  invalid  [%| [%invalid-control u.invalid]]
  [%& (snapshot-json view)]
--
