::  Validate the installed Grok Messages stream without inventing evidence.
::  A local host report is not independent model identity or effect attestation.
/-  mb=model-bridge
/+  old=vibecoding-provider
|%
+$  fields  (map @t json)
+$  receipt
  $:  %grok-provider-receipt-v1  session=@t
      reported-model=(unit @t)  identity=?(%host-reported %unreported)
      text=@t  usage=@t  metadata=@t
      tools=%none-observed  effects=%unverified  usage-completeness=%unknown
  ==
++  object
  |=  value=(unit json)
  ^-  (unit fields)
  ?~  value  ~
  ?.  ?=([%o *] u.value)  ~
  `p.u.value
++  string
  |=  [value=fields key=@t]
  ^-  (unit @t)
  (string:old value key)
++  blocks
  |=  value=(unit json)
  ^-  (unit @t)
  ?~  value  ~
  ?.  ?=([%a *] u.value)  ~
  ?.  &((gte (lent p.u.value) 1) (lte (lent p.u.value) 16))  ~
  =/  rest=(list json)  p.u.value
  =/  said=@t  ''
  |-  ^-  (unit @t)
  ?~  rest  `said
  =/  block  (object `i.rest)
  ?~  block  ~
  =/  kind  (string u.block 'type')
  ?:  =(`'text' kind)
    =/  part  (~(get by u.block) 'text')
    ?~  part  ~
    ?.  ?=([%s *] u.part)  ~
    $(rest t.rest, said (cat 3 said p.u.part))
  ?.  =(`'thinking' kind)  ~
  =/  thought  (~(get by u.block) 'thinking')
  ?~  thought  ~
  ?.  ?=([%s *] u.thought)  ~
  $(rest t.rest)
++  inspect
  |=  [spec=model-bridge-spec:mb request=model-bridge-request:mb reply=model-bridge-result:mb]
  ^-  (each receipt @tas)
  ?.  ?&  |(=('grok' provider-id.spec) =('grok-cli' provider-id.spec))
          =('model-unreported' model-id.spec)
          (model-bridge-event-matches-request:mb spec request [%result reply])
          =('[]' tool-calls-json.reply)
      ==  [%| %grok-result-mismatch]
  =/  parsed  (de:json:html provider-metadata-json.reply)
  =/  meta  (object parsed)
  ?~  meta  [%| %grok-metadata-invalid]
  ?.  ?&  =(`'grok-messages-receipt-v1' (string u.meta 'schema'))
          =(`'grok-cli' (string u.meta 'backend'))
          =(`[%n '0'] (~(get by u.meta) 'exit_code'))
          =(`'none-observed' (string u.meta 'tools'))
          =(`'unverified' (string u.meta 'effects'))
          =(`'unknown' (string u.meta 'usage_completeness'))
      ==  [%| %grok-metadata-invalid]
  =/  stream  (~(get by u.meta) 'events')
  ?~  stream  [%| %grok-events-missing]
  ?.  ?=([%a *] u.stream)  [%| %grok-events-invalid]
  =/  events=(list json)  p.u.stream
  ?~  events  [%| %grok-events-invalid]
  =/  init  (object `i.events)
  ?~  t.events  [%| %grok-events-invalid]
  =/  assistant  (object `i.t.events)
  ?~  t.t.events  [%| %grok-events-invalid]
  =/  terminal  (object `i.t.t.events)
  ?.  =(~ t.t.t.events)  [%| %grok-events-invalid]
  ?~  init  [%| %grok-events-invalid]
  ?~  assistant  [%| %grok-events-invalid]
  ?~  terminal  [%| %grok-events-invalid]
  =/  session  (string u.meta 'cli_session')
  ?~  session  [%| %grok-session-invalid]
  ?.  ?&  (bounded-text:mb u.session 128)
          =(u.session turn-handle.reply)
          =(session (string u.init 'session_id'))
          =(session (string u.assistant 'session_id'))
          =(session (string u.terminal 'session_id'))
      ==  [%| %grok-session-invalid]
  ?.  ?&  =(`'system' (string u.init 'type'))
          =(`'init' (string u.init 'subtype'))
          =(`'plan' (string u.init 'permissionMode'))
          =(`'assistant' (string u.assistant 'type'))
          =(`~ (~(get by u.assistant) 'parent_tool_use_id'))
          =(`'result' (string u.terminal 'type'))
          =(`'success' (string u.terminal 'subtype'))
          =(`[%b %.n] (~(get by u.terminal) 'is_error'))
          =(`'end_turn' (string u.terminal 'stop_reason'))
      ==  [%| %grok-terminal-invalid]
  =/  errors  (~(get by u.terminal) 'errors')
  ?.  |(=(~ errors) =(`[%a ~] errors))  [%| %grok-terminal-invalid]
  =/  message  (object (~(get by u.assistant) 'message'))
  ?~  message  [%| %grok-message-invalid]
  ?.  ?&  =(`'message' (string u.message 'type'))
          =(`'assistant' (string u.message 'role'))
          =(`'end_turn' (string u.message 'stop_reason'))
          =(`~ (~(get by u.message) 'stop_sequence'))
      ==  [%| %grok-message-invalid]
  =/  said  (blocks (~(get by u.message) 'content'))
  ?.  ?&  =(`content.reply said)
          =(`content.reply (string u.terminal 'result'))
      ==  [%| %grok-content-invalid]
  =/  model  (string u.message 'model')
  ?~  model  [%| %grok-identity-invalid]
  ?.  &((bounded-text:mb u.model 128) =(model (string u.init 'model')))
    [%| %grok-identity-invalid]
  =/  unknown=?  =('unknown' u.model)
  =/  reported=(unit @t)  ?:(unknown ~ model)
  ?.  ?&  =((~(get by u.meta) 'reported_model') ?~(reported `~ `[%s u.reported]))
          =((string u.meta 'model_provenance') `?:(unknown 'unreported' 'host-reported'))
      ==  [%| %grok-identity-invalid]
  =/  usage  (object (de:json:html usage-json.reply))
  ?~  usage  [%| %grok-usage-invalid]
  =/  original-usage=(unit json)  (~(get by u.terminal) 'usage')
  ?.  ?&  =(`'unknown' (string u.usage 'completeness'))
          =((~(get by u.usage) 'reported') ?~(original-usage `~ original-usage))
      ==  [%| %grok-usage-invalid]
  [%& [%grok-provider-receipt-v1 u.session reported ?:(unknown %unreported %host-reported) content.reply usage-json.reply provider-metadata-json.reply %none-observed %unverified %unknown]]
--
