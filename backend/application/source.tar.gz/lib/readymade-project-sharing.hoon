::  Owner sharing commands. Retain once before dispatch; ACK is not outcome.
/-  pa=cantrip-project-access, mp=multiplayer-project, nc=native-coding
/+  access=cantrip-project-access, mg=readymade-app-management
|%
+$  selection
  $%  [%grant desk=@tas paths=(set path) permissions=permissions:pa]
      [%revoke generation=@ud]
  ==
+$  command
  [request=@t owner=@p project=@t peer=@p expected=@ux selection=selection]
+$  observation
  [owner=@p at=@da catalog=project:mp scope=(unit project:nc) held=grants:pa]
+$  record  [command=command intent=@ux action=action:pa]
+$  journal  (map @t record)
+$  decision  [journal=journal record=record dispatch=?]
++  valid
  |=  c=command
  ^-  ?
  ?&  (uuid:mg request.c)
      &((gth (met 3 project.c) 0) (lte (met 3 project.c) 128))
      &((gth expected.c 0) (lte (met 0 expected.c) 256))
      ?:  ?=(%revoke -.selection.c)
        &((gth generation.selection.c 0) (lte (met 0 generation.selection.c) 64))
      ?&  !=(0 desk.selection.c)  (access-paths selection.c)
          |(view.permissions.selection.c suggest.permissions.selection.c)
      ==
  ==
++  access-paths
  |=  s=[%grant desk=@tas paths=(set path) permissions=permissions:pa]
  ^-  ?
  (paths-valid:access paths.s)
++  intent
  |=  c=command
  ^-  @ux
  (shax (jam [%readymade-project-sharing-intent-v1 c(request '')]))
++  stamp
  |=  o=observation
  ^-  @ux
  ::  Time is checked by the grant law; it must not invalidate every form.
  (shax (jam [%readymade-project-sharing-view-v1 owner.o catalog.o scope.o held.o]))
++  record-valid
  |=  r=record
  ^-  ?
  =/  c=command  command.r
  ?.  &((valid c) =((intent c) intent.r))  %.n
  ?:  ?=(%revoke -.selection.c)
    =(action.r [%cantrip-project-revoke-v1 project.c peer.c generation.selection.c])
  ?.  ?=(%cantrip-project-grant-v1 -.action.r)  %.n
  =/  g=grant:pa  grant.action.r
  ?&  (grant-valid:access g)  =(owner.c owner.g)
      =(project.c project.g)  =(peer.c peer.g)  =(0 expires.g)
      =(desk.selection.c desk.g)  =(paths.selection.c paths.g)
      =(permissions.selection.c permissions.g)
  ==
++  restore
  ::  Reject malformed retained state; never drop or replay a saved request.
  |=  raw=*
  ^-  (unit journal)
  =/  parsed  ((soft ,journal) raw)
  ?~  parsed  ~
  =/  j=journal  u.parsed
  ?.  (lte ~(wyt by j) 512)  ~
  =/  rows=(list [key=@t value=record])  ~(tap by j)
  ?.  =(j (~(gas by *journal) rows))  ~
  =|  seen=(map @ux record)
  |-  ^-  (unit journal)
  ?~  rows  `j
  =/  r=record  value.i.rows
  ?.  &((record-valid r) =(key.i.rows request.command.r))  ~
  =/  prior  (~(get by seen) intent.r)
  ?.  ?~  prior
        %.y
      =/  current=command  command.r
      =/  previous=command  command.u.prior
      ?&  =(current(request '') previous(request ''))
          =(action.r action.u.prior)
      ==
    ~
  $(rows t.rows, seen (~(put by seen) intent.r r))
++  prepare
  |=  [our=@p actor=@p o=observation j=journal c=command]
  ^-  (each decision @tas)
  ?.  &(=(our actor) =(our owner.c) =(our owner.o))  [%| %foreign-owner]
  ?.  (valid c)  [%| %sharing-command-invalid]
  =/  old  (~(get by j) request.c)
  ?^  old
    ?.  =(c command.u.old)  [%| %sharing-request-conflict]
    [%& [j u.old %.n]]
  ?:  (gte ~(wyt by j) 512)  [%| %sharing-journal-full]
  =/  digest=@ux  (intent c)
  =/  duplicate
    (skim ~(val by j) |=(r=record =(digest intent.r)))
  ?^  duplicate
    ::  Keep this client's ID recoverable without sending another native card.
    =/  prior=record  i.duplicate
    =/  previous=command  command.prior
    ?.  =(c(request '') previous(request ''))
      [%| %sharing-request-conflict]
    =/  alias=record  prior(command c)
    [%& [(~(put by j) request.c alias) alias %.n]]
  ?.  &(=(project.c id.spec.catalog.o) =(our authority.spec.catalog.o))
    [%| %sharing-project-changed]
  ?.  =(expected.c (stamp o))  [%| %sharing-view-stale]
  =/  action=(each action:pa @tas)
    ?:  ?=(%revoke -.selection.c)
      =/  next  (revoke:access our actor held.o [project.c peer.c] generation.selection.c)
      ?:  ?=(%| -.next)  [%| p.next]
      [%& [%cantrip-project-revoke-v1 project.c peer.c generation.selection.c]]
    =/  member  (~(get by members.catalog.o) peer.c)
    ?~  member  [%| %sharing-member-missing]
    =/  prior  (~(get by held.o) [project.c peer.c])
    =/  g=grant:pa
      :*  our  project.c  peer.c  u.member  desk.selection.c
          law-version.spec.catalog.o  law-digest.spec.catalog.o
          ?~(prior 1 +(generation.grant.u.prior))  at.o  `@da`0
          paths.selection.c  permissions.selection.c
      ==
    =/  next  (issue-scoped:access our actor at.o catalog.o held.o g scope.o)
    ?:  ?=(%| -.next)  [%| p.next]
    [%& [%cantrip-project-grant-v1 g]]
  ?:  ?=(%| -.action)  [%| p.action]
  =/  r=record  [c digest p.action]
  [%& [(~(put by j) request.c r) r %.y]]
++  outcome
  ::  GET observes canonical Cantrip state and never redispatches a command.
  |=  [o=observation r=record]
  ^-  @tas
  =/  c=command  command.r
  ?.  &(=(owner.o owner.c) =(project.c id.spec.catalog.o))  %unavailable
  =/  found  (~(get by held.o) [project.c peer.c])
  ?~  found  %unconfirmed
  =/  g=grant:pa  grant.u.found
  ?:  ?=(%cantrip-project-revoke-v1 -.action.r)
    ?:  (gth generation.g generation.action.r)  %superseded
    ?:  &(=(generation.g generation.action.r) revoked.u.found)  %confirmed
    %unconfirmed
  ?.  ?=(%cantrip-project-grant-v1 -.action.r)  %unavailable
  =/  wanted=grant:pa  grant.action.r
  ?:  (gth generation.g generation.wanted)  %superseded
  ?.  =(g wanted)  %unconfirmed
  ?:  revoked.u.found  %revoked
  ?.  &((member-scoped:access owner.o at.o catalog.o g scope.o) (time-valid:access g at.o))
    %unavailable
  %confirmed
--
