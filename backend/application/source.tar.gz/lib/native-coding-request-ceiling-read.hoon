::  Owner-local attachment before a CLI claim. Reads never dispatch a job.
/-  nc=native-coding, cli=cli-inference
/+  ceiling=native-coding-request-ceiling, sessions=native-coding-session,
    tools=cantrip-native-coding, project=native-coding-project,
    guard=viki-scry-guard
|%
++  join
  |=  $:  our=@p  r=request:ceiling  e=entry:sessions  key=@tas
          grant=@ux  job=job:cli  binding=public-binding:cli
      ==
  ^-  (unit record:ceiling)
  ?.  ?&  =(our owner.session.e)  =(session.r id.session.e)
          =(grant.r grant)  =(request.r id.request.job)
          =(session.r session.request.job)
          =(%inference phase.e)  ?=(^ pending.e)
          =(pending.e `request.job)
          =(source.r working.session.e)
          =(%queued phase.job)  =(~ claim.job)  =(~ raw.job)
          =(~ reply.job)  =(~ reason.job)
          active.binding  =(key key.binding)  =(key key.job)
          =(backend.binding backend.job)  =(connector.binding connector.job)
      ==  ~
  =/  proposed=record:ceiling
    [our session.r request.r grant.r project.session.e configuration.e source.r (shax (jam request.job)) operations.r]
  ?:((valid:ceiling our proposed) `proposed ~)
++  read
  |=  [b=bowl:gall held=organ:tools r=request:ceiling]
  ^-  (each record:ceiling @tas)
  ?.  =(our.b src.b)  [%| %request-ceiling-owner-only]
  ?.  &((agent-live:guard our.b now.b %viki) (agent-live:guard our.b now.b %cli-inference))
    [%| %request-ceiling-agent-unavailable]
  =/  scope  (~(get by grants.held) grant.r)
  ?~  scope  [%| %request-ceiling-grant-missing]
  ?.  &((grant-valid:tools our.b grant.u.scope) =(~ revoked.u.scope))
    [%| %request-ceiling-grant-refused]
  =/  input=(unit [entry=entry:sessions key=@tas grant=@ux])
    .^((unit [entry=entry:sessions key=@tas grant=@ux]) %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/qpc-input/(scot %ux session.r)/noun)
  ?~  input  [%| %request-ceiling-session-missing]
  =/  job=(unit job:cli)
    .^((unit job:cli) %gx /(scot %p our.b)/cli-inference/(scot %da now.b)/job/(scot %ux request.r)/noun)
  ?~  job  [%| %request-ceiling-job-missing]
  =/  binding=(unit public-binding:cli)
    .^((unit public-binding:cli) %gx /(scot %p our.b)/cli-inference/(scot %da now.b)/binding/(scot %tas key.u.input)/noun)
  ?~  binding  [%| %request-ceiling-binding-missing]
  =/  proposed  (join our.b r entry.u.input key.u.input grant.u.input u.job u.binding)
  ?~  proposed  [%| %request-ceiling-not-unclaimed-current]
  =/  singleton=ledger:ceiling  (~(put by *ledger:ceiling) request.r u.proposed)
  ?.  (bound:ceiling our.b singleton held)  [%| %request-ceiling-scope-mismatch]
  ?:  (lien ~(val by records.held) |=(item=record:tools =(request.r request.context.request.item)))
    [%| %request-ceiling-already-executed]
  =/  current  (current:project our.b now.b project.grant.u.scope)
  ?:  ?=(%| -.current)  [%| p.current]
  ?.  =(source.r revision.working.p.current)  [%| %request-ceiling-source-changed]
  [%& u.proposed]
--
