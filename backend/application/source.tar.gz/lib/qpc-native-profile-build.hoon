::  Inline Khan strand compiled with the registry. No desk thread lookup,
::  mark conversion, external manifest, source writes or evaluator execution.
/-  spider, nc=native-coding
/+  io=strandio, flat=native-coding-flat-build,
    declaration=qpc-native-declaration, project=native-coding-project
|%
++  source-page
  |=  r=revision:nc
  ^-  (each [lobe=@ux hash=@ux] @tas)
  =/  at=path  /(scot %p owner.r)/[desk.r]/(scot %ud number.r)
  =/  commit=tako:clay  .^(tako:clay %cs (weld at /tako/now))
  =/  root=@uv  .^(@uv %cz at)
  ?.  &(=(commit.r commit) =(root.r root))
    [%| %qpc-profile-source-pin-mismatch]
  =/  tree=yaki:clay  .^(yaki:clay %cs (weld at /yaki/(scot %uv commit)))
  =/  found  (~(get by q.tree) profile-path:declaration)
  ?~  found  [%| %qpc-profile-source-missing]
  =/  page=page:clay  .^(page:clay %cs (weld at /blob/(scot %uv u.found)))
  ?.  &(?=(%hoon p.page) ?=(@ q.page))
    [%| %qpc-profile-source-not-hoon]
  =/  text=@t  q.page
  ?.  &((gth (met 3 text) 0) (lte (met 3 text) 131.072))
    [%| %qpc-profile-source-bound]
  ?.  =(u.found (page-to-lobe:clay [%hoon text]))
    [%| %qpc-profile-source-lobe-mismatch]
  [%& [`@ux`u.found (shax text)]]
++  run
  |=  [owner=@p ticket=@ux r=revision:nc]
  =/  m  (strand:spider ,vase)
  ^-  form:m
  ;<  b=bowl:spider  bind:m  get-bowl:io
  ?.  &(=(owner our.b) =(owner src.b) =(owner owner.r) (revision-valid:project r))
    (pure:m !>(`(each build:declaration @tas)`[%| %qpc-profile-build-owner-mismatch]))
  =/  checked  (mule |.((source-page r)))
  ?:  ?=(%| -.checked)
    (pure:m !>(`(each build:declaration @tas)`[%| %qpc-profile-source-unavailable]))
  ?:  ?=(%| -.p.checked)
    (pure:m !>(`(each build:declaration @tas)`[%| p.p.checked]))
  =/  page=[lobe=@ux hash=@ux]  p.p.checked
  =/  target=beak  [owner.r desk.r ud+number.r]
  ;<  made=result:flat  bind:m  (attempt:flat target profile-path:declaration)
  ?.  ?=(%built -.made)
    ?:  ?=(%unsupported -.made)
      (pure:m !>(`(each build:declaration @tas)`[%| reason.made]))
    (pure:m !>(`(each build:declaration @tas)`[%| reason.made]))
  =/  result=build:declaration
    [%qpc-profile-build-v1 ticket r profile-path:declaration lobe.page hash.page q.product.made files.made bytes.made]
  (pure:m !>(`(each build:declaration @tas)`[%& result]))
--
