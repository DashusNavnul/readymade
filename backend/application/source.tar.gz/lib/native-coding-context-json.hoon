::  Owner HTTP projection of frozen evidence; never reconstruct old context.
/-  frozen=native-coding-context
/+  gep=graf-evidence-packet
|%
++  prepared
  |=  value=prepared:frozen
  ^-  json
  %-  pairs:enjs:format
  :~  ['digest' s+(scot %ux digest.value)]
      ['selection' s+selection.value]
      ['query' s+query.value]
      ['instructions' s+text.packet.value]
      ['source' (pairs:enjs:format ~[['owner' s+(scot %p owner.source.packet.value)] ['desk' s+desk.source.packet.value] ['revision' (numb:enjs:format number.source.packet.value)] ['root' s+(scot %uv root.source.packet.value)]])]
      ['files' a+(turn sources.value file)]
      ['memories' a+(turn memories.value memory)]
      ['recall' ?~(recall.packet.value ~ (pairs:enjs:format ~[['digest' s+(scot %ux digest.u.recall.packet.value)] ['exact' b+exact.u.recall.packet.value] ['behind' (numb:enjs:format behind.u.recall.packet.value)] ['at' s+(scot %da at.u.recall.packet.value)]]))]
      ['provenance' a+(turn provenance.packet.value |=(g=provenance-ref:gep (pairs:enjs:format ~[['handle' s+handle.g] ['action' s+action.g] ['source' s+(scot %p source.g)] ['legacyHandle' ?~(legacy-handle.g ~ s+u.legacy-handle.g)]])))]
      ['contradictions' a+(turn contradictions.packet.value |=(g=contradiction-ref:gep (pairs:enjs:format ~[['handle' s+handle.g] ['ship' s+(scot %p ship.g)]])))]
      ['relations' a+(turn relations.packet.value |=(g=relation-ref:gep (pairs:enjs:format ~[['tier' s+tier.g] ['kind' s+kind.g] ['source' s+src.g] ['destination' s+dst.g]])))]
      ['gaps' a+(turn gaps.packet.value |=(g=gap:gep (pairs:enjs:format ~[['kind' s+kind.g] ['handle' ?~(handle.g ~ s+u.handle.g)] ['detail' (numb:enjs:format detail.g)]])))]
  ==
++  file
  |=  value=source-excerpt:frozen
  ^-  json
  (pairs:enjs:format ~[['path' s+(spat pax.value)] ['blob' ?~(blob.value ~ s+(scot %ux u.blob.value))] ['start' (numb:enjs:format start.value)] ['total' (numb:enjs:format total.value)] ['text' s+text.value] ['more' b+more.value] ['unavailable' ?~(reason.value ~ s+u.reason.value)]])
++  memory
  |=  value=memory-excerpt:frozen
  ^-  json
  (pairs:enjs:format ~[['handle' s+handle.value] ['digest' s+(scot %ux digest.value)] ['text' s+text.value] ['handleComplete' b+handle-complete.value] ['textComplete' b+text-complete.value]])
++  full-receipt
  |=  value=receipt:frozen
  ^-  json
  %-  pairs:enjs:format
  :~  ['version' s+'native-coding-dispatched-context-v1']
      ['owner' s+(scot %p owner.value)]
      ['session' s+(scot %ux session.value)]
      ['request' s+(scot %ux request.value)]
      ['worker' s+(scot %p worker.value)]
      ['scope' s+?:(=(owner.value worker.value) 'owner-prepared-local-request' 'parent-prepared-remote-payload')]
      ['providerReceipt' s+'unavailable-in-this-record']
      ['provider' s+provider.value]
      ['model' s+model.value]
      ['requestDigest' s+(scot %ux request-digest.value)]
      ['historyDigest' s+(scot %ux history-digest.value)]
      ['toolsDigest' s+(scot %ux tools-digest.value)]
      ['context' (prepared prepared.value)]
  ==
++  receipt
  |=  value=binding:frozen
  ^-  json
  (pairs:enjs:format ~[['version' s+'native-coding-context-binding-v1'] ['owner' s+(scot %p owner.value)] ['session' s+(scot %ux session.value)] ['request' s+(scot %ux request.value)] ['worker' s+(scot %p worker.value)] ['provider' s+provider.value] ['model' s+model.value] ['receiptDigest' s+(scot %ux receipt-digest.value)] ['preparedDigest' s+(scot %ux prepared-digest.value)] ['retention' s+'unconfirmed-until-exact-graf-read']])
--
