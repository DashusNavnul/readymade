::  Shared instrument data and private read projections. No stored state,
::  dispatch or scheduling owner. The instrument facade delegates here so
::  data readers need not compile the complete measurement-owner wrapper.
/-  nc=native-coding
/+  contract=qpc-instrument-contract, admission=qpc-measurement-admission,
    source=qpc-instrument-source, obs=qpc-observation,
    project=native-coding-project, sensing=qpc-task-sensing
|%
+$  plan  plan:contract
+$  ticket  [enrollment=@ux snapshot=@ux due=@da]
+$  record
  [plan=plan active=? step=@ud segment=@ux ticket=(unit ticket) awaiting=(unit @ux) reason=(unit @tas)]
+$  binding  [project=project:nc source=receipt:source]
+$  law-context  [instrument=@ux law=@ux]
+$  laws  (map @ux law-context)
+$  state
  $:  plans=(map @ux record)  admitted=state:admission
      bindings=(map @ux binding)  events=(map @ux result:obs)
  ==
++  raw  raw:contract
++  plan-valid  plan-valid:contract
++  binding-of  binding-of:contract
++  project-read
  |=  [inner=agent:gall b=bowl:gall id=@ux name=@t]
  ^-  (each project:nc @tas)
  =/  base  (raw inner b /x/native-coding/projects)
  =/  scoped  (raw inner b /x/native-coding/session-project/(scot %ux id))
  ?~  base  [%| %instrument-project-unavailable]
  ?~  scoped  [%| %instrument-workspace-unavailable]
  =/  parsed  ((soft ,(map @t project:nc)) u.base)
  =/  override  ((soft ,(unit (each project:nc @tas))) u.scoped)
  ?~  parsed  [%| %instrument-project-invalid]
  ?~  override  [%| %instrument-workspace-invalid]
  =/  p  (~(get by u.parsed) name)
  ?~  p  [%| %instrument-project-missing]
  ?~  u.override  [%& u.p]
  ?:  ?=(%| -.u.u.override)  u.u.override
  =/  selected=project:nc  p.u.u.override
  ?.  &((valid:project selected) =(selected u.p(working working.selected)))
    [%| %instrument-workspace-project-changed]
  [%& selected]
++  successor-plan
  |=  p=plan
  =(`%first-17-reference-successive-disjoint-17-live (policy-of:sensing manifest.p))
--
