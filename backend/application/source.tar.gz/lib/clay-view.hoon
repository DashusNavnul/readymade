::  /lib/clay-view.hoon
::
::  The review pane's reads and its one write (ui/review.js): this ship's
::  desks, a desk's files, a file's text, and a save into a bachelor's fork.
::  Served by %pataphor-page under /apps/pataphor/clay/, signed in only.
::
::  Every read is Ford-free and history-free: %cd the desks, %cs /late a
::  desk's revision, %cs its commit and that commit's path->lobe map, %cu
::  then %cq a file's raw page. %cx would build the file's mark through Ford
::  -- the build that stalls this ship. %cw and %cv run tako-to-aeon, which
::  walks every revision's ancestry: one %cw on %pataphor (rev 2799) held
::  dashus 42.8 s (measured 2026-10-01); %cs /late answered in 0.11 s.
::  Comparing desks is the browser's job: two trees, same path, different
::  lobe.
::
::  THE SAVE. POST /clay/save/<desk>/<path> changes one existing text file
::  on a bachelor's fork -- the bride's copy, which bench carries to the
::  seat's host on its next turn and lands only through the land law. Never
::  %repo or any desk that is not a seat's, never a live desk (a live commit
::  stalls the ship), never a new or deleted file. The editor names the lobe
::  it started from (x-clay-base); a file a turn changed since is refused,
::  not overwritten. A save needs the x-pataphor-save header, which no form
::  from another site can send, and an Origin, when there is one, of this
::  host.
::
::  WHO TYPED IT. A fork's files land under the seat's name, so every save
::  also lights a graf fact, [%operator-edit %1 desk path before sham who at]:
::  the fork, the file, the lobe the editor started from, the sham of the
::  text saved, the ship that saved it and when -- so a landing can say which
::  of its lines the operator wrote.
::
/-  graf-sur=graf
|%
+$  want
  $%  [%desks ~]
      [%tree =desk]
      [%file =desk =path]
      [%save =desk =path]
      [%bad ~]
  ==
::  the bachelors' forks: the only desks a save may touch
++  seats
  ^-  (set desk)
  %-  silt
  ^-  (list desk)
  ~[%flunky %busboy %policeman %gendarme %undertaker %priest %delivery-boy %cuirassier %stationmaster]
++  root  |=([our=@p now=@da d=desk] `path`/(scot %p our)/[d]/(scot %da now))
::  the latest revision: clay's +aver answers /late at any %ud case straight
::  from its dome
++  rev  |=([our=@p d=desk] ud:.^(cass:clay %cs /(scot %p our)/[d]/(scot %ud 0)/late))
++  tree
  |=  [our=@p now=@da d=desk]
  ^-  [at=@ud files=(map path lobe:clay)]
  =/  at=@ud  (rev our d)
  :-  at
  ?:  =(0 at)  ~
  ::  read-s answers /tako with the case's commit and ignores the rest of
  ::  the path, which must still be there
  =/  commit=tako:clay  .^(tako:clay %cs (weld (root our now d) /tako/now))
  q:.^(yaki:clay %cs (weld (root our now d) /yaki/(scot %uv commit)))
::  +clay-path: is this request line one of ours (query ignored)
::
++  clay-path
  |=  url=@t
  ^-  (unit want)
  =/  prefix=@t  '/apps/pataphor/clay/'
  =/  size=@ud  (met 3 prefix)
  ?.  &((gte (met 3 url) size) =(prefix (end [3 size] url)))  ~
  =/  t=tape  (trip (rsh [3 (dec size)] url))
  =/  q  (find "?" t)
  =?  t  ?=(^ q)  (scag u.q t)
  =/  p=(unit path)  (rush (crip t) stap)
  ?~  p  `[%bad ~]
  ?+  u.p  `[%bad ~]
    [%desks ~]  `[%desks ~]
    [%tree @ ~]  ?.(((sane %tas) i.t.u.p) `[%bad ~] `[%tree i.t.u.p])
    [%file @ ^]  ?.(((sane %tas) i.t.u.p) `[%bad ~] `[%file i.t.u.p t.t.u.p])
    [%save @ ^]  ?.(((sane %tas) i.t.u.p) `[%bad ~] `[%save i.t.u.p t.t.u.p])
  ==
::  +serve: [status content-type body] for one read
::
++  serve
  |=  [our=@p now=@da =want]
  ^-  [status=@ud type=@t body=@t]
  =/  desks=(set desk)  .^((set desk) %cd ~[(scot %p our) '' (scot %da now)])
  =/  json-type=@t  'application/json; charset=utf-8'
  =/  text-type=@t  'text/plain; charset=utf-8'
  ?-    -.want
      %bad
    [400 text-type 'Use /clay/desks, /clay/tree/<desk>, /clay/file/<desk>/<path> or POST /clay/save/<desk>/<path>.']
  ::
      %save
    [405 text-type 'A save is a POST.']
  ::
      %desks
    :+  200  json-type
    %-  en:json:html
    %-  pairs:enjs:format
    :_  ~
    :-  'desks'
    :-  %a
    %+  turn  (sort ~(tap in desks) aor)
    |=  d=desk
    %-  pairs:enjs:format
    :~  ['desk' s+d]
        ['rev' (numb:enjs:format (rev our d))]
    ==
  ::
      %tree
    ?.  (~(has in desks) desk.want)  [404 text-type 'No such desk.']
    =/  t  (tree our now desk.want)
    ?:  (gth ~(wyt by files.t) 20.000)  [413 text-type 'Desk over 20000 files.']
    :+  200  json-type
    %-  en:json:html
    %-  pairs:enjs:format
    :~  ['desk' s+desk.want]
        ['rev' (numb:enjs:format at.t)]
        :-  'files'
        :-  %o
        %-  malt
        %+  turn  ~(tap by files.t)
        |=([p=path l=lobe:clay] [(spat p) s+(scot %uv l)])
    ==
  ::
      %file
    ?.  (~(has in desks) desk.want)  [404 text-type 'No such desk.']
    =/  at=path  (weld (root our now desk.want) path.want)
    ?.  .^(? %cu at)  [404 text-type 'No such file on this desk.']
    ::  the page's own noun, typed * so no mold can mismatch
    =/  data=*  .^(* %cq at)
    =/  text=(unit @t)
      ?@  data  `data
      (bind ((soft wain) data) of-wain:format)
    ?~  text  [415 text-type 'Not a text file.']
    ?:  (gth (met 3 u.text) 2.097.152)  [413 text-type 'File over 2 MiB.']
    [200 text-type u.text]
  ==
::  +save: one file on a bachelor's fork, or why not
::
++  text-lines
  |=  text=@t
  ^-  wain
  ?:  =('' text)  ~
  ::  The native to-wain jet drops a final empty line. A non-LF sentinel
  ::  keeps that line present; remove only the sentinel from the last cord.
  =/  lines=wain  (to-wain:format (cat 3 text 'x'))
  =/  last=@t  (rear lines)
  (snoc (scag (dec (lent lines)) lines) (end [3 (dec (met 3 last))] last))
++  save
  |=  [our=@p now=@da =desk =path headers=(list [key=@t value=@t]) body=(unit octs)]
  ^-  [status=@ud type=@t body=@t cards=(list card:agent:gall)]
  =/  text-type=@t  'text/plain; charset=utf-8'
  =/  no  |=([s=@ud why=@t] [s text-type why ~])
  =/  hed=(map @t @t)  (malt headers)
  ?.  =(`'1' (~(get by hed) 'x-pataphor-save'))
    (no 403 'A save comes from the review pane (x-pataphor-save).')
  =/  origin=(unit @t)  (~(get by hed) 'origin')
  =/  host=@t  (fall (~(get by hed) 'host') '')
  ?.  |(?=(~ origin) =(u.origin (cat 3 'http://' host)) =(u.origin (cat 3 'https://' host)))
    (no 403 'A save from another site is refused.')
  ?.  (~(has in seats) desk)
    (no 403 'Only a bachelor\'s fork can be edited here. %repo changes only through a landing.')
  ?.  (~(has in .^((set ^desk) %cd ~[(scot %p our) '' (scot %da now)])) desk)
    (no 404 'No such desk.')
  =/  dom=(unit dome:clay)  (~(get by .^(cone:clay %cx /(scot %p our)//(scot %da now)/domes)) [our desk])
  ?.  =(`%dead (bind dom |=(d=dome:clay liv.d)))
    (no 409 'This fork is live; a commit to a live desk can stall the ship, so the save is refused.')
  =/  at=^path  (weld (root our now desk) path)
  ?.  .^(? %cu at)
    (no 404 'No such file on this fork; the editor changes existing files only.')
  =/  base=(unit @uv)  (biff (~(get by hed) 'x-clay-base') (cury slaw %uv))
  ?~  base  (no 400 'The save names no starting version (x-clay-base).')
  ?.  =(`u.base (~(get by files:(tree our now desk)) path))
    (no 409 'This file changed on the fork since you opened it (a turn?). Your text is kept in the editor; reopen the file to see the change.')
  ?~  body  (no 400 'Empty save.')
  ?:  (gth p.u.body 2.097.152)  (no 413 'File over 2 MiB.')
  =/  text=@t  `@t`q.u.body
  ?.  =(p.u.body (met 3 text))  (no 415 'Text ending in a zero byte cannot be saved exactly.')
  ::  the new text in the file's own noun: a cord stays a cord, lines stay lines
  =/  old=*  .^(* %cq at)
  =/  new=(unit *)
    ?@  old  `text
    ?.  ?=(^ ((soft wain) old))  ~
    =/  lines=wain  (text-lines text)
    ?.  =(text (of-wain:format lines))  ~
    `lines
  ?~  new  (no 415 'Not a text file.')
  =/  =cage  [(rear path) !>(u.new)]
  =/  who=*  [%operator-edit %1 desk path u.base (sham text) our now]
  :*  200  text-type  'Saved to the fork.'
      :~  [%pass /clay-save/[desk] %arvo %c %info desk %& ~[[path %mut cage]]]
          [%pass /clay-save-who/[desk] %agent [our %graf] %poke %graf-action !>(`graf-action:graf-sur`[%light who])]
      ==
  ==
++  prove-text-lines
  ?>  =('' (of-wain:format (text-lines '')))
  ?>  =('one\0atwo' (of-wain:format (text-lines 'one\0atwo')))
  ?>  =('one\0atwo\0a' (of-wain:format (text-lines 'one\0atwo\0a')))
  ?>  =('\0a\0a' (of-wain:format (text-lines '\0a\0a')))
  ?>  =('🧩\0d\0a' (of-wain:format (text-lines '🧩\0d\0a')))
  %clay-view-exact-text-proof-v1
--
