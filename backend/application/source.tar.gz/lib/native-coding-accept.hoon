::  Exact candidate checking and guarded landing. Cantrip admits lifecycle
::  calls and authenticates native replies and canonical Viki decisions.
/-  nc=native-coding, worker=native-coding-worker
/+  files=native-coding-files, project=native-coding-project, dsr=desk-shell-read,
    worker-law=native-coding-worker
|%
+$  target-result
  [target=build-target:nc diagnostics=(list diagnostic:nc)]
+$  report
  [%native-coding-candidate-report-v1 candidate=@ux staging=tree:nc targets=(list target-result)]
+$  challenge
  $:  %native-coding-challenge-v1  candidate=@ux  report=@ux
      outcome=?(%passed %failed)  evidence=(list @ux)  reason=@t
  ==
+$  decision
  $:  %native-coding-decision-v1  candidate=@ux  context=context:nc
      basis=tree:nc  report=report  challenge=challenge
      verdict=?(%approve %revise %refuse)  expected=revision:nc  at=@da
  ==
+$  record
  $:  %native-coding-acceptance-v1
      project=project:nc  candidate=candidate:nc  grant=@ux  requested-at=@da
      stage=?(%cloning %staging %checking %review %landing %applied %refused %unknown)
      staging=(unit tree:nc)  report=(unit report)  decision=(unit decision)
      landed=(unit tree:nc)  reason=(unit @tas)
  ==
+$  ledger  (map @ux record)
+$  command
  $%  [%native-coding-review-v1 candidate=@ux]
      [%native-coding-decide-v1 candidate=@ux]
      [%native-coding-candidate-observe-v1 candidate=@ux]
      [%native-coding-candidate-recheck-v1 candidate=@ux]
  ==
+$  change  [next=ledger cards=(list card:agent:gall)]
++  digest
  |=  value=*
  ^-  @ux
  (shax (jam [%native-coding-acceptance-v1 value]))
++  staging-desk
  |=  id=@ux
  ^-  @tas
  `@tas`(cat 3 'nc-' (crip (skip (slag 2 (trip (scot %ux id))) |=(c=@t =(c '.')))))
++  report-valid
  |=  [p=project:nc c=candidate:nc r=report]
  ^-  ?
  ?.  ?&  (candidate-valid:files p c)  =(id.c candidate.r)
          (tree-valid:project p staging.r)
          =(owner.source.context.c owner.revision.staging.r)
          =((staging-desk id.c) desk.revision.staging.r)
          =(2 number.revision.staging.r)
          =((after-map:files c) files.body.snapshot.staging.r)
          =((required p c) (turn targets.r |=(v=target-result target.v)))
          (gte (lent targets.r) 1)
          (lien targets.p |=(t=build-target:nc ?=(^ checks.t)))
      ==  %.n
  %+  levy  targets.r
  |=  v=target-result
  =/  names=(list @tas)  [%compile (turn checks.target.v |=([name=@tas expression=@t] name))]
  ?&  =(names (turn diagnostics.v |=(d=diagnostic:nc name.d)))
      (levy diagnostics.v |=(d=diagnostic:nc &(=(revision.staging.r source.d) (lte (met 3 detail.d) 32.768) (lte (lent artifacts.d) 4))))
  ==
++  required
  ::  Compile every changed Hoon file, including an otherwise unimported one.
  |=  [p=project:nc c=candidate:nc]
  ^-  (list build-target:nc)
  =/  extra=(list build-target:nc)
    %+  murn  edits.c
    |=  e=edit:nc
    ^-  (unit build-target:nc)
    ?~  content.e  ~
    ?.  =(%hoon mark.u.content.e)  ~
    ?:  (lien targets.p |=(t=build-target:nc =(entry.t path.change.e)))  ~
    `[(staging-desk (digest path.change.e)) %hoon path.change.e ~ ~]
  (weld targets.p extra)
++  passed
  |=  r=report
  ^-  ?
  (levy targets.r |=(t=target-result (levy diagnostics.t |=(d=diagnostic:nc passed.d))))
++  decision-valid
  |=  [p=project:nc c=candidate:nc d=decision]
  ^-  ?
  ?&  =(id.c candidate.d)  =(context.c context.d)  =(basis.c basis.d)
      =(source.context.c expected.d)  !=(0 at.d)
      (report-valid p c report.d)
      =(id.c candidate.challenge.d)  =((digest report.d) report.challenge.d)
      (gte (lent evidence.challenge.d) 1)  (lte (lent evidence.challenge.d) 32)
      (gte (met 3 reason.challenge.d) 1)  (lte (met 3 reason.challenge.d) 8.192)
      ?:  =(%approve verdict.d)
        &((passed report.d) =(%passed outcome.challenge.d))
      %.y
  ==
++  capacity  512
++  valid
  |=  held=ledger
  ^-  ?
  ?&  (lte ~(wyt by held) capacity)
      %+  levy  ~(tap by held)
      |=  [id=@ux r=record]
      ?&  =(id id.candidate.r)  (candidate-valid:files project.r candidate.r)
          ?~(report.r %.y (report-valid project.r candidate.r u.report.r))
          ?~(decision.r %.y (decision-valid project.r candidate.r u.decision.r))
          ?~(report.r %.y =(staging.r `staging.u.report.r))
          ?~(decision.r %.y =(report.r `report.u.decision.r))
          ?:  =(%applied stage.r)
            ?&  ?=(^ landed.r)  ?=(^ decision.r)  =(%approve verdict.u.decision.r)
                (tree-valid:project project.r u.landed.r)
                =(owner.source.context.candidate.r owner.revision.u.landed.r)
                =(desk.source.context.candidate.r desk.revision.u.landed.r)
                =(+(number.source.context.candidate.r) number.revision.u.landed.r)
                =((after-map:files candidate.r) files.body.snapshot.u.landed.r)
            ==
          %.y
      ==
  ==
++  ready
  |=  held=ledger
  ^-  ?
  (ready-with held ~)
++  ready-with
  ::  A released slot is not a successful check or a changed candidate row.
  |=  [held=ledger released=(set @ux)]
  ^-  ?
  !(lien ~(val by held) |=(r=record |(?=(?(%cloning %staging %checking %landing) stage.r) &(?=(%unknown stage.r) !(~(has in released) id.candidate.r)))))
++  released-check
  ::  Only the authenticated parent journal can supply this terminal receipt.
  ::  Reconstruct the sent check ticket; never reinterpret an unknown write.
  |=  [our=@p at=@da r=record key=@ux job=record:worker]
  ^-  ?
  ::  A deadline and a fence both leave a sent check unknown; either way the
  ::  worker's terminal receipt is what frees the slot, never silence.
  ?.  ?&  =(%unknown stage.r)  |(=(`%worker-deadline reason.r) =(`%worker-source-changed reason.r))
          ?=(^ staging.r)  ?=(~ report.r)  ?=(~ decision.r)  ?=(~ landed.r)
          sent.job  ?=(^ result.job)
      ==  %.n
  =/  o=order:worker  order.job
  =/  result=result:worker  u.result.job
  =/  normal=@ux
    (digest [%native-coding-check-ticket-v1 r(stage %checking, reason ~)])
  =/  retry=@ux
    (digest [%native-coding-check-ticket-v1 r(stage %checking, reason `%candidate-recheck)])
  ?&  =(our owner.pairing.o)  =(our owner.source.context.candidate.r)
      =((digest:worker-law o) key)  (result-matches:worker-law o result)
      ?=(%refused -.outcome.result)
      =(%worker-deadline-unconfirmed reason.outcome.result)
      (lte deadline.o finished.result)  (lte finished.result at)
      =(id.candidate.r candidate.o)  =(grant.r grant.o)
      =(context.candidate.r context.o)
      =(revision.u.staging.r source.o)
      =((namespace-digest:worker-law files.body.snapshot.u.staging.r) namespace.o)
      =((required project.r candidate.r) targets.o)
      |(=(normal ticket.o) =(retry ticket.o))
  ==
++  released-checks
  |=  [our=@p at=@da held=ledger jobs=journal:worker pending=(map @ux @ux)]
  ^-  (set @ux)
  %-  silt
  %+  murn  ~(tap by held)
  |=  [id=@ux r=record]
  ?.  &(=(id id.candidate.r) =(%unknown stage.r))  ~
  ?.  %+  lien  ~(tap by jobs)
      |=  [key=@ux job=record:worker]
      ?&  (released-check our at r key job)
          =(`id (~(get by pending) ticket.order.job))
      ==
    ~
  `id
++  released-at
  ::  Canonical private parent state, never an argument supplied by a client.
  |=  [our=@p at=@da held=ledger]
  ^-  (set @ux)
  ?:  (ready held)  ~
  ?.  (lien ~(val by held) |=(r=record &(=(%unknown stage.r) |(=(`%worker-deadline reason.r) =(`%worker-source-changed reason.r)))))  ~
  =/  parent
    ;;([%native-coding-worker-parent-v1 engaged=? owner=[tag=@tas pairing=(unit pairing:worker) journal=journal:worker offers=(map @ux *)] pending=(map @ux @ux) failures=(map @ux @tas)] .^(* %gx /(scot %p our)/cantrip/(scot %da at)/native-coding/worker/state/noun))
  ?.  engaged.parent  ~
  (released-checks our at held journal.owner.parent pending.parent)
++  ready-at
  |=  [our=@p at=@da held=ledger]
  ^-  ?
  (ready-with held (released-at our at held))
++  wire-for
  |=  [id=@ux phase=@tas]
  ^-  wire
  /native-candidate/(scot %ux id)/[phase]
++  check-scheduled
  |=  r=record
  ^-  ?
  &(!=(~ staging.r) =(%checking stage.r) |(=(`%candidate-check-scheduled reason.r) =(`%candidate-recheck-scheduled reason.r)))
++  check-dispatched
  |=  r=record
  ^-  ?
  &(!=(~ staging.r) =(%checking stage.r) |(=(~ reason.r) =(`%candidate-recheck reason.r)))
++  check-wire
  ::  The complete saved record is the ticket; no second queue owns it.
  |=  r=record
  ^-  wire
  =/  id=@ux  (digest [%native-coding-check-ticket-v1 r])
  =/  phase=@tas
    `@tas`(cat 3 'cw-' (crip (skip (slag 2 (trip (scot %ux id))) |=(c=@t =(c '.')))))
  (wire-for id.candidate.r phase)
++  schedule-check
  |=  [b=bowl:gall held=ledger r=record retry=?]
  ^-  change
  =.  r  r(stage %checking, reason `?:(retry %candidate-recheck-scheduled %candidate-check-scheduled))
  ::  Behn returns through a new runtime event. A Gall self-poke does not.
  (put our.b held r ~[[%pass (check-wire r) %arvo %b %wait (add now.b ~s1)]])
++  check-source-ready
  |=  [r=record held=ledger accepted=tree:nc working=tree:nc stage=tree:nc]
  ^-  ?
  (check-source-ready-with r held accepted working stage ~)
++  check-source-ready-with
  |=  [r=record held=ledger accepted=tree:nc working=tree:nc stage=tree:nc released=(set @ux)]
  ^-  ?
  ?&  ?=(~ report.r)  ?=(~ decision.r)  ?=(~ landed.r)
      =(`stage staging.r)  =(2 number.revision.stage)
      =((staging-desk id.candidate.r) desk.revision.stage)
      =((after-map:files candidate.r) files.body.snapshot.stage)
      =(basis.candidate.r working)  =(accepted.candidate.r revision.accepted)
      (ready-with (~(del by held) id.candidate.r) released)
  ==
++  start-check
  ::  Cantrip re-admits authority first; these exact live trees fence dispatch.
  |=  [b=bowl:gall held=ledger r=record accepted=tree:nc working=tree:nc stage=tree:nc]
  ^-  change
  ?.  &((check-scheduled r) =(`r (~(get by held) id.candidate.r)))  [held ~]
  ?.  (check-source-ready-with r held accepted working stage (released-at our.b now.b held))
    (put our.b held r(stage %unknown, reason `%candidate-check-source-changed) ~)
  =/  retry=?  =(`%candidate-recheck-scheduled reason.r)
  =/  id=@ux  id.candidate.r
  =.  r  r(reason ?:(retry `%candidate-recheck ~))
  (put our.b held r ~[[%pass (wire-for id ?:(retry %checks-retry %checks)) %arvo %k %fard q.byk.b %ph-native-coding-candidate %noun !>(`id)]])
++  watch
  |=  [our=@p id=@ux phase=@tas desk=@tas number=@ud]
  ^-  card:agent:gall
  [%pass (wire-for id phase) %arvo %c %warp our desk ~ %sing %z [%ud number] /]
++  edits
  |=  c=candidate:nc
  ^-  (list [path miso:clay])
  %+  turn  edits.c
  |=  e=edit:nc
  :-  path.change.e
  ?~  content.e  [%del ~]
  ?:  ?=(%add kind.change.e)
    [%ins mark.u.content.e !>(source.u.content.e)]
  [%mut mark.u.content.e !>(source.u.content.e)]
++  publish
  |=  [our=@p r=record]
  ^-  (list card:agent:gall)
  :~  [%pass /native-candidate-evidence %agent [our %graf] %poke %graf-action !>([%attest [%native-coding-acceptance-v1 (digest r) r]])]
      [%pass /native-candidate-status %agent [our %viki] %poke %noun !>([%native-coding-candidate-status-v1 id.candidate.r r])]
  ==
++  put
  |=  [our=@p held=ledger r=record cards=(list card:agent:gall)]
  ^-  change
  [(~(put by held) id.candidate.r r) (weld (publish our r) cards)]
++  staged
  ::  Read only our deterministic private candidate desk. Calling project
  ::  tree-at with that reader config does not create or grant a workspace.
  |=  [our=@p at=@da r=record]
  ^-  (each tree:nc @tas)
  =/  desk=@tas  (staging-desk id.candidate.r)
  =/  domes=cone:clay  .^(cone:clay %cx /(scot %p our)//(scot %da at)/domes)
  =/  found  (~(get by domes) [our desk])
  ?~  found  [%| %candidate-desk-pending]
  ?.  &(=(%dead liv.u.found) =(~ ren.u.found) =(~ wic.u.found))
    [%| %candidate-desk-not-isolated]
  ?.  (private-path:dsr our at desk /)  [%| %candidate-desk-not-private]
  =/  p=project:nc  project.r(working desk)
  (tree-at:project our at p desk let.u.found)
++  begin
  ::  Called only after Cantrip re-admits its retained candidate's tool scope.
  |=  [b=bowl:gall held=ledger p=project:nc c=candidate:nc grant=@ux]
  ^-  change
  ?>  &(=(our.b src.b) (candidate-valid:files p c))
  ?:  (~(has by held) id.c)  [held ~]
  ?>  &((ready-at our.b now.b held) (lth ~(wyt by held) capacity) (gth (lent targets.p) 0) (lien targets.p |=(t=build-target:nc ?=(^ checks.t))))
  =/  now  (current:project our.b now.b p)
  ?>  ?=(%& -.now)
  ?>  &(=(basis.c working.p.now) =(accepted.c revision.accepted.p.now))
  =/  desk=@tas  (staging-desk id.c)
  =/  domes=cone:clay  .^(cone:clay %cx /(scot %p our.b)//(scot %da now.b)/domes)
  ?>  !(~(has by domes) [our.b desk])
  =/  r=record
    [%native-coding-acceptance-v1 p c grant now.b %cloning ~ ~ ~ ~ ~]
  %-  put
  :*  our.b  held  r
      :~  [%pass (wire-for id.c %clone) %arvo %c %merg desk our.b desk.source.context.c [%ud number.source.context.c] %init]
          (watch our.b id.c %clone-ready desk 1)
      ==
  ==
++  observe
  ::  Submitted writes are observed, never repeated. Only the next phase's
  ::  first effect can be emitted when its exact predecessor is canonical.
  |=  [b=bowl:gall held=ledger id=@ux]
  ^-  change
  =/  found  (~(get by held) id)
  ?~  found  [held ~]
  =/  r=record  u.found
  =/  c=candidate:nc  candidate.r
  ?:  ?=(?(%review %applied %refused %unknown %checking) stage.r)
    [held (publish our.b r)]
  ?:  =(%landing stage.r)
    =/  current  (current:project our.b now.b project.r)
    ?:  ?=(%| -.current)  [held (publish our.b r)]
    =/  w=tree:nc  working.p.current
    ?:  =(revision.basis.c revision.w)  [held (publish our.b r)]
    ?.  &(=(accepted.c revision.accepted.p.current) =(+(number.source.context.c) number.revision.w) =((after-map:files c) files.body.snapshot.w))
      (put our.b held r(stage %unknown, reason `%landing-source-conflict) ~)
    =/  commit=yaki:clay
      .^(yaki:clay %cs (beam:dsr our.b now.b desk.revision.w /yaki/(scot %uv commit.revision.w)))
    ?.  =(~[commit.source.context.c] p.commit)
      (put our.b held r(stage %unknown, reason `%landing-parent-conflict) ~)
    (put our.b held r(stage %applied, landed `w, reason ~) ~)
  =/  snapshot  (staged our.b now.b r)
  ?:  ?=(%| -.snapshot)  [held (publish our.b r)]
  =/  t=tree:nc  p.snapshot
  ?:  =(%cloning stage.r)
    ?.  &(=(1 number.revision.t) =(commit.source.context.c commit.revision.t) =(root.source.context.c root.revision.t) =(files.body.snapshot.basis.c files.body.snapshot.t))
      (put our.b held r(stage %unknown, reason `%clone-source-conflict) ~)
    %-  put
    :*  our.b  held  r(stage %staging, staging `t)
        :~  [%pass (wire-for id %stage) %arvo %c %info desk.revision.t %.y (edits c)]
            (watch our.b id %stage-ready desk.revision.t 2)
        ==
    ==
  ?.  =(%staging stage.r)  [held ~]
  ?:  =(1 number.revision.t)  [held (publish our.b r)]
  ?.  &(=(2 number.revision.t) =((after-map:files c) files.body.snapshot.t))
    (put our.b held r(stage %unknown, reason `%staged-source-conflict) ~)
  =/  commit=yaki:clay
    .^(yaki:clay %cs (beam:dsr our.b now.b desk.revision.t /yaki/(scot %uv commit.revision.t)))
  ?.  =(~[commit.source.context.c] p.commit)
    (put our.b held r(stage %unknown, reason `%staged-parent-conflict) ~)
  (schedule-check b held r(staging `t) %.n)
++  recheck-ready
  ::  One retry of a terminal failed check, never an unknown Clay write.
  ::  Permission is independently re-admitted by Cantrip before this gate.
  |=  [r=record held=ledger accepted=tree:nc working=tree:nc stage=tree:nc]
  ^-  ?
  &(?=(%unknown stage.r) =(`%candidate-check-unconfirmed reason.r) (check-source-ready r held accepted working stage))
++  recheck
  |=  [b=bowl:gall held=ledger id=@ux]
  ^-  change
  ?>  =(our.b src.b)
  =/  found  (~(get by held) id)
  ?~  found  [held ~]
  =/  r=record  u.found
  ?.  &(=(%unknown stage.r) =(`%candidate-check-unconfirmed reason.r))
    [held ~]
  =/  current  (current:project our.b now.b project.r)
  ?:  ?=(%| -.current)  [held ~]
  =/  stage  (staged our.b now.b r)
  ?:  ?=(%| -.stage)  [held ~]
  ?.  (recheck-ready r held accepted.p.current working.p.current p.stage)
    [held ~]
  (schedule-check b held r %.y)
++  checked
  |=  [our=@p held=ledger id=@ux result=report]
  ^-  change
  =/  found  (~(get by held) id)
  ?~  found  [held ~]
  =/  r=record  u.found
  ?.  &(=(%checking stage.r) ?=(^ staging.r))  [held ~]
  ?.  &((report-valid project.r candidate.r result) =(u.staging.r staging.result))
    (put our held r(stage %unknown, reason `%native-check-report-mismatch) ~)
  (put our held r(stage %review, report `result, reason ~) ~)
++  decide
  ::  Viki decision was read canonically by Cantrip, after fresh grant checks.
  |=  [b=bowl:gall held=ledger id=@ux d=decision]
  ^-  change
  =/  found  (~(get by held) id)
  ?~  found  [held ~]
  =/  r=record  u.found
  ?.  &(=(%review stage.r) ?=(^ report.r))  [held ~]
  ?>  &((decision-valid project.r candidate.r d) =(u.report.r report.d) (lte at.d now.b))
  ?.  =(%approve verdict.d)
    (put our.b held r(stage %refused, decision `d, reason `verdict.d) ~)
  =/  current  (current:project our.b now.b project.r)
  ?>  ?=(%& -.current)
  ?>  &(=(basis.candidate.r working.p.current) =(accepted.candidate.r revision.accepted.p.current))
  %-  put
  :*  our.b  held  r(stage %landing, decision `d)
      :~  [%pass (wire-for id %land) %arvo %c %info desk.expected.d %.y (edits candidate.r)]
          (watch our.b id %land-ready desk.expected.d +(number.expected.d))
      ==
  ==
--
