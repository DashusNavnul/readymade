::  Owner-only capacity page: every lifetime wall with used, limit, remaining
::  and the settled records that still occupy it. Read-only; a figure that
::  cannot be read is reported unknown with its reason, never guessed.
/+  guard=viki-scry-guard
|%
+$  figure
  $%  [%known name=@t used=@ud limit=@ud settled=(unit @ud) note=@t]
      [%unknown name=@t reason=@tas]
  ==
++  base
  |=  [our=@p now=@da app=@tas]
  ^-  path
  ~[(scot %p our) app (scot %da now)]
++  live
  |=  [our=@p now=@da app=@tas]
  ^-  ?
  (agent-live:guard our now app)
++  count
  ::  Entries of a map without typing its values.
  |=  raw=*
  ^-  (unit @ud)
  =/  m  ((soft (map * *)) raw)
  ?~(m ~ `~(wyt by u.m))
++  receipts
  ::  Cantrip's hot suggestion journal; the archive drains it above 48.
  |=  [our=@p now=@da]
  ^-  figure
  =/  name=@t  'Suggestion receipts (hot)'
  ?.  (live our now %cantrip)  [%unknown name %cantrip-not-running]
  =/  raw=*  .^(* %gx (weld (base our now %cantrip) /project-access/journal-v2/noun))
  =/  got  ((soft ,[%& %cantrip-project-journal-v2 %native-coding-patches-v1 legacy=* bundles=*]) raw)
  ?~  got  [%unknown name %journal-unreadable]
  =/  a  (count legacy.u.got)
  =/  b  (count bundles.u.got)
  ?.  &(?=(^ a) ?=(^ b))  [%unknown name %journal-unreadable]
  [%known name (add u.a u.b) 64 ~ 'Settled receipts move to the archive above 48; 64 is the hard wall.']
++  grants
  |=  [our=@p now=@da]
  ^-  figure
  =/  name=@t  'Coding grants'
  ?.  (live our now %cantrip)  [%unknown name %cantrip-not-running]
  =/  raw=*  .^(* %gx (weld (base our now %cantrip) /native-coding/grants/noun))
  =/  got  ((soft ,(map @ux [grant=* revoked=(unit @da)])) raw)
  ?~  got  [%unknown name %grants-unreadable]
  ::  Settled grants (revoked, every call ended, no open candidate) can move
  ::  to the grant archive; an older Cantrip without the archive counts revoked.
  =/  archive  ((soft ,[store=? settled=@ud grants=@ud records=@ud]) .^(* %gx (weld (base our now %cantrip) /grant-archive/status/noun)))
  ?^  archive
    [%known name ~(wyt by u.got) 512 `settled.u.archive ?:(store.u.archive 'Settled grants can be archived to free a slot; [%cantrip-grant-archive-v1 ~] moves them, then drops them after readback.' 'Settled grants could be archived once the %native-grant-history store exists.')]
  =/  revoked=@ud  (lent (skim ~(val by u.got) |=(g=[grant=* revoked=(unit @da)] ?=(^ revoked.g))))
  [%known name ~(wyt by u.got) 512 `revoked 'Revoked grants are kept and still count toward 512.']
++  ceilings
  |=  [our=@p now=@da]
  ^-  figure
  =/  name=@t  'Coding request ceilings'
  ?.  (live our now %cantrip)  [%unknown name %cantrip-not-running]
  =/  got  (count .^(* %gx (weld (base our now %cantrip) /native-coding/request-ceilings/noun)))
  ?~  got  [%unknown name %ceilings-unreadable]
  [%known name u.got 512 `u.got 'Every historical request ceiling is kept and counts.']
++  sessions
  |=  [our=@p now=@da]
  ^-  figure
  =/  name=@t  'Coding sessions (hot)'
  ?.  (live our now %viki)  [%unknown name %viki-not-running]
  =/  got  ((soft (list *)) .^(* %gx (weld (base our now %viki) /native-coding/sessions/noun)))
  ?~  got  [%unknown name %sessions-unreadable]
  [%known name (lent u.got) 512 ~ 'Finished sessions can be archived to free a slot.']
++  openings
  |=  [our=@p now=@da]
  ^-  figure
  =/  name=@t  'Session openings'
  ?.  (live our now %viki)  [%unknown name %viki-not-running]
  =/  got  ((soft ,[@tas (list *)]) .^(* %gx (weld (base our now %viki) /native-coding/openings/noun)))
  ?~  got  [%unknown name %openings-unreadable]
  [%known name (lent +.u.got) 512 ~ 'An archived session releases its opening.']
++  completions
  |=  [our=@p now=@da]
  ^-  figure
  =/  name=@t  'Completion receipts'
  ?.  (live our now %viki)  [%unknown name %viki-not-running]
  =/  got  (count .^(* %gx (weld (base our now %viki) /native-coding/completions/noun)))
  ?~  got  [%unknown name %completions-unreadable]
  [%known name u.got 128 ~ 'They leave with their session when it is archived.']
++  invitations
  ::  Only a readymade-collab that serves the count is asked (shell >= 7);
  ::  an unknown path would crash this read rather than return unknown.
  |=  [our=@p now=@da]
  ^-  figure
  =/  name=@t  'Project invitations'
  ?.  (live our now %readymade-collab)  [%unknown name %collab-not-running]
  =/  status  ((soft ,[rev=@ud loaded=? fault=*]) .^(* %gx (weld (base our now %readymade-collab) /brain-shell/status/noun)))
  ?~  status  [%unknown name %collab-status-unreadable]
  ?.  (gte rev.u.status 7)  [%unknown name %collab-too-old]
  =/  got  ((soft ,[used=@ud limit=@ud settled=@ud]) .^(* %gx (weld (base our now %readymade-collab) /invitations/capacity/noun)))
  ?~  got  [%unknown name %invitations-unreadable]
  [%known name used.u.got limit.u.got `settled.u.got 'Settled invitation records are trimmed oldest first when the journal is full.']
++  figure-json
  |=  f=figure
  ^-  json
  ?:  ?=(%unknown -.f)
    (pairs:enjs:format ~[['name' s+name.f] ['available' b+%.n] ['reason' s+(scot %tas reason.f)]])
  %-  pairs:enjs:format
  :~  ['name' s+name.f]  ['available' b+%.y]  ['used' (numb:enjs:format used.f)]
      ['limit' (numb:enjs:format limit.f)]  ['remaining' (numb:enjs:format ?:((gth used.f limit.f) 0 (sub limit.f used.f)))]
      ['settled' ?~(settled.f ~ (numb:enjs:format u.settled.f))]  ['note' s+note.f]
  ==
++  route
  |=  [our=@p src=@p now=@da url=@t]
  ^-  (unit json)
  ?.  =('/apps/pataphor-native/coding/capacity' url)  ~
  ?.  =(our src)
    `(pairs:enjs:format ~[['schema' s+'native-capacity-v1'] ['available' b+%.n] ['error' s+'owner-required']])
  =/  rows=(list figure)
    :~  (receipts our now)  (sessions our now)  (openings our now)  (completions our now)
        (grants our now)  (ceilings our now)  (invitations our now)
    ==
  :-  ~
  %-  pairs:enjs:format
  :~  ['schema' s+'native-capacity-v1']  ['owner' s+(scot %p our)]  ['available' b+%.y]
      ['figures' a+(turn rows figure-json)]
  ==
--
