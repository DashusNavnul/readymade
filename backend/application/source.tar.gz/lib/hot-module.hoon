::  Hot modules: replace a compiled default with a gate Clay builds from a
::  hot desk, without rebuilding or reloading the agent. Clay rebuilds only
::  the changed module's closure and hands the agent the new vase.
::
::  The type check happens ONCE, at install: the built gate must accept the
::  caller's argument type and return a type that nests under the caller's
::  result type. After that every call is untyped (+slum) and the result is
::  re-typed with the caller's own type at no cost in the state's size. A
::  module that does not fit is refused and the previous one keeps running.
::  A change to a saved state's shape is not a hot change: it does not fit.
|%
+$  slot
  $:  path=path               ::  module file on the hot desk
      gate=(unit vase)        ::  installed gate; ~ = compiled default runs
      digest=@ux              ::  of the installed gate's noun, 0x0 if none
      fault=(unit tang)       ::  why the newest build was refused
  ==
++  admit
  |=  [built=vase arg=type res=type]
  ^-  (each vase tang)
  =/  product  (mule |.((slit p.built arg)))
  ?:  ?=(%| -.product)
    [%| [leaf+"hot module does not accept the caller's argument type" p.product]]
  ?.  (~(nest ut res) | p.product)
    [%| ~[leaf+"hot module's result type does not fit the caller's"]]
  [%& built]
++  install
  ::  A refused build leaves the running gate in place and says why.
  |=  [s=slot built=vase arg=type res=type]
  ^-  slot
  =/  got  (admit built arg res)
  ?:  ?=(%| -.got)  s(fault `p.got)
  s(gate `p.got, digest (shax (jam q.p.got)), fault ~)
++  run
  ::  Call an admitted gate; the caller passes its own result mold.
  |*  [res=mold gate=vase arg=*]
  !<(res [-:!>(*res) (slum q.gate arg)])
++  watch
  ::  Clay answers once now and again whenever the build really changes.
  |=  [our=@p now=@da desk=@tas pax=path]
  ^-  card:agent:gall
  [%pass [%hot-module desk pax] %arvo %c %warp our desk `[%next %a da+now pax]]
++  ask
  |=  [our=@p now=@da desk=@tas pax=path]
  ^-  card:agent:gall
  [%pass [%hot-module desk pax] %arvo %c %warp our desk `[%sing %a da+now pax]]
--
