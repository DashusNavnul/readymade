::  /lib/cantrip-flect.hoon
::
::  Cantrip's acts as shapes.  A submission and a verdict result keep
::  their types; this library derives from those types what the flect
::  language needs: the shape (grown by Nock axis), the tag (the noun's
::  sham as sixteen suffix letters), the law the type itself is (its
::  act enum a one-of demand, its text slots words), and the receipt of
::  the act fitting that law, which any ship recomputes from the noun.
::
::  These are the geometric twins of the text-shaped verdicts; nothing
::  here changes what Cantrip decides.  The shadow judge (phase 5) and
::  the receipt facts (phase 6) build on these arms.
::
/-  cantrip-sur=cantrip
/+  flect, flect-law, law=cantrip-law-window
|%
::  +submission-law: the act-submission type as a law
++  submission-law
  ^-  law:flect-law
  (law-of:flect-law -:!>(*act-submission:cantrip-sur))
++  submission-shape
  |=  sub=act-submission:cantrip-sur
  ^-  shape:flect
  (grow:flect !>(sub))
++  submission-tag
  |=  sub=act-submission:cantrip-sur
  ^-  flect:flect
  (tag:flect sub)
++  submission-receipt
  |=  sub=act-submission:cantrip-sur
  ^-  receipt:flect-law
  (judge:flect-law submission-law !>(sub))
::  +verdict-law: the act-verdict-result type as a law
++  verdict-law
  ^-  law:flect-law
  (law-of:flect-law -:!>(*act-verdict-result:cantrip-sur))
++  verdict-shape
  |=  v=act-verdict-result:cantrip-sur
  ^-  shape:flect
  (grow:flect !>(v))
++  verdict-tag
  |=  v=act-verdict-result:cantrip-sur
  ^-  flect:flect
  (tag:flect v)
++  verdict-receipt
  |=  v=act-verdict-result:cantrip-sur
  ^-  receipt:flect-law
  (judge:flect-law verdict-law !>(v))
::
::  The residue as tags.  The law's residue keeps acts by move-id text and
::  codes by name; this one keeps acts by TAG (a reference the ship
::  resolves, never a copy) and codes as words.  +apply follows the law's
::  own rules for each verdict; +window-residue projects the counts the
::  live window engine consumes.
::
+$  residue
  $:  turn=@ud
      last-accepted=(unit flect:flect)            ::  tag of the accepted act
      last-rejected=(unit flect:flect)            ::  tag of the rejected act
      contraindications=(list (list flect:flect)) ::  codes, as words
      rivals=(list flect:flect)                   ::  tags of rival acts
      branches=(list flect:flect)                 ::  tags of branch acts
      blockers=(list (list flect:flect))          ::  codes, as words
      retries=@ud
  ==
++  code-word
  |=  code=@tas
  ^-  (list flect:flect)
  (word:flect code)
++  apply
  |=  $:  res=residue
          v=act-verdict-result:cantrip-sur
          sub=act-submission:cantrip-sur
          code=waterwheel-rejection-code:cantrip-sur
      ==
  ^-  residue
  =/  t  (submission-tag sub)
  =.  turn.res  turn.v
  ?-    verdict.v
      %accept  res(last-accepted `t, retries 0)
      %rival   res(rivals (snoc rivals.res t))
      %branch  res(branches (snoc branches.res t))
      %retry   (add-code res(last-rejected `t, retries +(retries.res)) code)
      %reject
    =.  res  res(last-rejected `t, retries 0)
    =?  contraindications.res  ?=(%implement act.sub)
      (snoc contraindications.res (code-word %no-implement-without-evidence))
    (add-code res code)
  ==
++  add-code
  |=  [res=residue code=waterwheel-rejection-code:cantrip-sur]
  ^-  residue
  ?:  ?=(%none code)  res
  =/  w  (code-word code)
  =/  has  |=(l=(list (list flect:flect)) (lien l |=(x=(list flect:flect) =(x w))))
  ?:  ?|(?=(%act-forbidden code) ?=(%fail-closed code))
    ?:  (has contraindications.res)  res
    res(contraindications (snoc contraindications.res w))
  ::  the rest -- act-not-allowed, memory-ref-unbound, glyph-handle-unbound,
  ::  formula-ref-unbound -- are blockers (an exhaustive else: a test here
  ::  could never fail, and the compiler refuses one)
  ?:  (has blockers.res)  res
  res(blockers (snoc blockers.res w))
++  window-residue
  |=  res=residue
  ^-  [turn=@ud contraindications=@ud rivals=@ud blockers=@ud]
  [turn.res (lent contraindications.res) (lent rivals.res) (lent blockers.res)]
::
::  Regimes as law-sets.  The window engine (/lib/cantrip-law-window) is
::  computed law; here each regime is a law with one gate over the state
::  [bands residue], and the transition is which regime's law the state
::  fits (exactly one).  Admission under the window is a law over the act
::  whose gate asks the window's admissible set.  The residue ratchet is a
::  demand at the residue's own axis.  Readiness is a fit verdict.
::
++  regimes
  ^-  (list regime:law)
  ~[%grounding %opening %vectoring %ratification]
++  state-of
  |=  state=*
  ^-  [bands=bands:law residue=residue:law]
  ;;([bands=bands:law residue=residue:law] state)
++  regime-gate
  |=  reg=regime:law
  ^-  *
  |=  [state=* env=*]
  =/  st  (state-of state)
  =((derive-regime:law bands.st residue.st) reg)
++  regime-law
  |=  reg=regime:law
  ^-  law:flect-law
  ~[[1 %run (regime-gate reg)]]
::  +regime-of: the one regime whose law the state fits
++  regime-of
  |=  [b=bands:law r=residue:law]
  ^-  regime:law
  =/  state=*  [b r]
  =/  sh  (grow:flect !>([b r]))
  =/  fitting=(list regime:law)
    %+  skim  regimes
    |=(reg=regime:law fit:(fits-with:flect-law (regime-law reg) sh `state ~))
  ?>  ?=([* ~] fitting)
  i.fitting
::  +window-law: the act (at axis 2, its name) must be admissible under the
::  window of the environment's [bands residue]
++  window-gate
  ^-  *
  |=  [act=* env=*]
  =/  st  (state-of env)
  =/  name=*  .*(act [0 2])
  ?>  ?=(@ name)
  ::  the set is widened to @tas: has:in is wet, and against a set of a
  ::  constants-fork it refuses any key that is not itself a constant
  (~(has in `(set @tas)`(admissible:law bands.st residue.st)) `@tas`name)
++  window-law
  ^-  law:flect-law
  ~[[2 %run window-gate]]
::  +ratchet-law: at the residue's axis, contraindications must not have
::  reached the count that forces grounding
++  ratchet-gate
  ^-  *
  |=  [state=* env=*]
  (lth contraindications.residue:(state-of state) 3)
++  ratchet-law
  ^-  law:flect-law
  ~[[3 %run ratchet-gate]]
::  +ready-law: ratification readiness as a fit -- implement admissible, the
::  turns and the verified streak the readiness projection requires (its
::  constants mirrored here and pinned to it by proof)
++  required-turns   ^-(@ud 1)
++  required-streak  ^-(@ud 2)
++  ready-gate
  ^-  *
  |=  [state=* env=*]
  =/  st  (state-of state)
  ?>  ?=(@ env)
  =/  streak=@ud  env
  ?&  (~(has in (admissible:law bands.st residue.st)) %implement)
      (gte turn.residue.st required-turns)
      (gte streak required-streak)
  ==
++  ready-law
  ^-  law:flect-law
  ~[[1 %run ready-gate]]
::
::  Contention as shape.  A rival or branch verdict makes a two-act shape
::  -- the act that contends and the act contended, grown together -- with
::  its own tag.  The verdict opens it as a fact; a ruling resolves it by
::  naming the act that stands.  The open contentions are what the delay
::  shows as the breach; +open-contentions folds them from the facts.
::
+$  contention
  $:  kind=?(%rival %branch)
      a=flect:flect                       ::  tag of the act that contends
      b=flect:flect                       ::  tag of the act contended
      =shape:flect                        ::  the two acts, grown together
      tag=flect:flect                     ::  tag of the two-act noun
  ==
+$  contention-fact
  $:  %cantrip-contention
      %1
      verb=?(%open %resolve)
      id=@t
      =contention
      winner=(unit flect:flect)           ::  on resolve, the act that stands
      who=@p
      at=@da
  ==
++  contention-of
  |=  $:  v=act-verdict-result:cantrip-sur
          new=act-submission:cantrip-sur
          prior=act-submission:cantrip-sur
      ==
  ^-  (unit contention)
  ?.  ?=(?(%rival %branch) verdict.v)  ~
  :-  ~
  :*  verdict.v
      (submission-tag new)
      (submission-tag prior)
      (grow:flect !>([new prior]))
      (tag:flect [new prior])
  ==
::  +contention-id: the two-act sham, recovered from the tag's letters
++  contention-id
  |=  c=contention
  ^-  @t
  (scot %uv (rep 3 (turn tag.c |=(l=@ (sub l 0x1.d900)))))
++  open-fact
  |=  [c=contention who=@p at=@da]
  ^-  contention-fact
  [%cantrip-contention %1 %open (contention-id c) c ~ who at]
++  resolve-fact
  |=  [c=contention winner=flect:flect who=@p at=@da]
  ^-  contention-fact
  [%cantrip-contention %1 %resolve (contention-id c) c `winner who at]
++  open-contentions
  |=  facts=(list *)
  ^-  (list contention)
  =|  open=(list contention)
  |-  ^-  (list contention)
  ?~  facts  open
  =/  f  ((soft contention-fact) i.facts)
  ?~  f  $(facts t.facts)
  =/  without  (skip open |=(c=contention =(tag.c tag.contention.u.f)))
  ?-  verb.u.f
    %resolve  $(facts t.facts, open without)
    %open     $(facts t.facts, open (snoc without contention.u.f))
  ==
--
