::  /lib/multiplayer-receipt
::
::  Pure receipt-v3 construction and verification.  This library proves the
::  protocol law; the live host agent remains responsible for authenticating
::  src.bowl and supplying the next host/source coordinates.
::
/-  mr=multiplayer-receipt
|%
++  payload-digest
  |=  payload=*
  ^-  digest:mr
  `@ux`(shax (jam payload))
::
++  digest-for
  |=  body=body:mr
  ^-  digest:mr
  `@ux`(shax (jam [%multiplayer-receipt-v3 body]))
::
++  make-live
  |=  $:  project=project-id:mr
          authority-host=@p
          host-sequence=@ud
          previous=(unit digest:mr)
          source=@p
          source-sequence=@ud
          kind=@tas
          actor=actor:mr
          payload=*
          occurred-at=@da
          valid-until=(unit @da)
      ==
  ^-  event:mr
  =/  body=body:mr
    :*  project
        authority-host
        host-sequence
        previous
        [%live source source-sequence]
        kind
        `actor
        payload
        (payload-digest payload)
        occurred-at
        valid-until
    ==
  [%multiplayer-receipt-v3 body (digest-for body)]
::
++  make-legacy
  |=  $:  project=project-id:mr
          authority-host=@p
          host-sequence=@ud
          previous=(unit digest:mr)
          format=@tas
          claimed-source=(unit @p)
          kind=@tas
          payload=*
          occurred-at=@da
      ==
  ^-  event:mr
  =/  body=body:mr
    :*  project
        authority-host
        host-sequence
        previous
        [%legacy format claimed-source]
        kind
        ~
        payload
        (payload-digest payload)
        occurred-at
        ~
    ==
  [%multiplayer-receipt-v3 body (digest-for body)]
::
++  valid-event
  |=  item=event:mr
  ^-  ?
  ?&  !=(0 host-sequence.body.item)
      !=(0 project.body.item)
      =((payload-digest payload.body.item) payload-digest.body.item)
      =(digest.item (digest-for body.item))
      ?~  valid-until.body.item
        %.y
      (gth u.valid-until.body.item occurred-at.body.item)
      ?-  -.origin.body.item
        %live
          ?&  !=(0 sequence.origin.body.item)
              ?=(^ actor.body.item)
          ==
        %legacy
          ?&  !=(%$ format.origin.body.item)
              ?=(~ actor.body.item)
          ==
      ==
  ==
::
++  init
  |=  [project=project-id:mr authority-host=@p]
  ^-  (unit chain:mr)
  ?:  =(0 project)  ~
  `[project authority-host 0 ~ ~ ~ ~ ~]
::
++  advance-source
  |=  $:  heads=(map @p source-head:mr)
          seen=(map [@p @ud] digest:mr)
          item=event:mr
      ==
  ^-  (unit [heads=(map @p source-head:mr) seen=(map [@p @ud] digest:mr)])
  ?-  -.origin.body.item
    %legacy
      `[heads seen]
    %live
      =/  source=@p  source.origin.body.item
      =/  sequence=@ud  sequence.origin.body.item
      =/  old=(unit source-head:mr)  (~(get by heads) source)
      =/  expected=@ud  ?~(old 1 +(sequence.u.old))
      ?.  =(expected sequence)  ~
      ?:  (~(has by seen) [source sequence])  ~
      =/  next-heads=(map @p source-head:mr)
        (~(put by heads) source [sequence digest.item])
      =/  next-seen=(map [@p @ud] digest:mr)
        (~(put by seen) [source sequence] digest.item)
      `[next-heads next-seen]
  ==
::
++  valid-forward
  |=  $:  pending=(list event:mr)
          expected=@ud
          previous=(unit digest:mr)
          hosts=(map @ud event:mr)
          heads=(map @p source-head:mr)
          seen=(map [@p @ud] digest:mr)
          target=chain:mr
      ==
  ^-  ?
  ?~  pending
    ?&  =(+(count.target) expected)
        =(previous head.target)
        =(hosts host-events.target)
        =(heads source-heads.target)
        =(seen source-events.target)
    ==
  =/  item=event:mr  i.pending
  ?.  (valid-event item)  %.n
  ?.  =(project.target project.body.item)  %.n
  ?.  =(authority-host.target authority-host.body.item)  %.n
  ?.  =(expected host-sequence.body.item)  %.n
  ?.  =(previous previous.body.item)  %.n
  ?:  (~(has by hosts) expected)  %.n
  =/  next-hosts=(map @ud event:mr)  (~(put by hosts) expected item)
  =/  advanced=(unit [heads=(map @p source-head:mr) seen=(map [@p @ud] digest:mr)])
    (advance-source heads seen item)
  ?~  advanced  %.n
  %=  $
    pending   t.pending
    expected  +(expected)
    previous  `digest.item
    hosts     next-hosts
    heads     heads.u.advanced
    seen      seen.u.advanced
  ==
::
++  valid
  |=  target=chain:mr
  ^-  ?
  ?:  !=(count.target (lent events.target))  %.n
  ?~  events.target
    ?&  =(0 count.target)
        ?=(~ head.target)
        =(~ host-events.target)
        =(~ source-heads.target)
        =(~ source-events.target)
    ==
  ?:  =(0 count.target)  %.n
  ?~  head.target  %.n
  ?.  =(count.target host-sequence.body.i.events.target)  %.n
  ?.  =(u.head.target digest.i.events.target)  %.n
  (valid-forward (flop events.target) 1 ~ ~ ~ ~ target)
::
++  live-source
  |=  item=event:mr
  ^-  (unit [source=@p sequence=@ud])
  ?-  -.origin.body.item
    %legacy  ~
    %live  `[source.origin.body.item sequence.origin.body.item]
  ==
::
++  append
  |=  [target=chain:mr item=event:mr observed-at=@da]
  ^-  result:mr
  ?.  (valid target)  [%| [%invalid-chain ~]]
  ?.  (valid-event item)  [%| [%invalid-event ~]]
  ?.  =(project.target project.body.item)
    [%| [%wrong-project project.target project.body.item]]
  ?.  =(authority-host.target authority-host.body.item)
    [%| [%wrong-host authority-host.target authority-host.body.item]]
  ?:  ?&  ?=(^ valid-until.body.item)
          (gte observed-at u.valid-until.body.item)
      ==
    [%| [%stale u.valid-until.body.item observed-at]]
  =/  expected-host=@ud  +(count.target)
  ?:  =(host-sequence.body.item count.target)
    ?~  events.target  [%| [%invalid-chain ~]]
    ?:  =(digest.i.events.target digest.item)
      [%| [%duplicate digest.item]]
    [%| [%forked-host host-sequence.body.item `digest.i.events.target `digest.item]]
  ?:  (lth host-sequence.body.item expected-host)
    =/  known=(unit event:mr)
      (~(get by host-events.target) host-sequence.body.item)
    ?~  known  [%| [%invalid-chain ~]]
    ?:  =(digest.u.known digest.item)
      =/  source=(unit [source=@p sequence=@ud])  (live-source item)
      ?~  source
        [%| [%replayed ~ host-sequence.body.item digest.item]]
      [%| [%replayed `source.u.source sequence.u.source digest.item]]
    [%| [%forked-host host-sequence.body.item `digest.u.known `digest.item]]
  ?:  (gth host-sequence.body.item expected-host)
    [%| [%missing-host expected-host host-sequence.body.item]]
  ?.  =(head.target previous.body.item)
    [%| [%forked-host expected-host head.target previous.body.item]]
  =/  live=(unit [source=@p sequence=@ud])  (live-source item)
  =/  source-refusal=(unit refusal:mr)
    ?~  live  ~
    =/  source=@p  source.u.live
    =/  sequence=@ud  sequence.u.live
    =/  old=(unit source-head:mr)  (~(get by source-heads.target) source)
    =/  expected-source=@ud  ?~(old 1 +(sequence.u.old))
    ?:  (gth sequence expected-source)
      `[%missing-source source expected-source sequence]
    ?:  (lth sequence expected-source)
      =/  known=(unit digest:mr)
        (~(get by source-events.target) [source sequence])
      ?~  known  `[%invalid-chain ~]
      ?:  =(u.known digest.item)
        `[%replayed `source sequence digest.item]
      `[%forked-source source sequence u.known digest.item]
    ~
  ?^  source-refusal  [%| u.source-refusal]
  =/  advanced=(unit [heads=(map @p source-head:mr) seen=(map [@p @ud] digest:mr)])
    (advance-source source-heads.target source-events.target item)
  ?~  advanced  [%| [%invalid-chain ~]]
  =/  next=chain:mr
    :*  project.target
        authority-host.target
        expected-host
        `digest.item
        [item events.target]
        (~(put by host-events.target) expected-host item)
        heads.u.advanced
        seen.u.advanced
    ==
  [%& next]
--
