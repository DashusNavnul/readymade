::  Positive finite QPC kernel. Arithmetic only; never dispatches an act.
::  Caller binds canonical act digests, evidence, frozen law and Cantrip checks.
|%
+$  ratio  [num=@ud den=@ud]
+$  candidate  [id=@ud digest=@ux eligible=? energy=ratio]
+$  weighted  [choice=candidate weight=@ud]
+$  receipt
  $:  %qpc-select-v1
      attention=ratio  gain=@ud  draw=@ud
      candidates=(list candidate)  weights=(list weighted)
      total=@ud  selected=@ud  contrast=?
  ==
++  scale  1.000.000.000.000.000.000
++  draws  18.446.744.073.709.551.616
++  valid-ratio
  |=  value=ratio
  ?&  (gth den.value 0)  (lte num.value den.value)
      (lte (met 0 den.value) 256)
  ==
++  lower
  |=  [a=ratio b=ratio]
  (lth (mul num.a den.b) (mul num.b den.a))
++  same-energy
  |=  [a=ratio b=ratio]
  =((mul num.a den.b) (mul num.b den.a))
++  decay
  ::  x is in 10^18 units, 0 <= x < 16. Range reduce by 16,
  ::  alternating Taylor through degree 18, then four fixed-point squares.
  |=  x=@ud
  ^-  @ud
  ?>  (lth x (mul 16 scale))
  =/  y=@ud  (div x 16)
  =/  term=@ud  scale
  =/  total=@ud  scale
  =/  k=@ud  1
  =/  base=@ud
    |-  ^-  @ud
    ?:  (gth k 18)  total
    =/  next=@ud  (div (mul term y) (mul scale k))
    =/  sum=@ud  ?:(=(0 (mod k 2)) (add total next) (sub total next))
    $(k +(k), term next, total sum)
  =/  squares=@ud  4
  |-  ^-  @ud
  ?:  =(squares 0)  base
  $(squares (dec squares), base (div (mul base base) scale))
++  choose
  |=  [attention=ratio gain=@ud draw=@ud candidates=(list candidate)]
  ^-  (each receipt @tas)
  ?.  (valid-ratio attention)  [%| %invalid-attention]
  ?.  ?&((gth gain 0) (lte gain 32.000.000))  [%| %invalid-gain]
  ?.  (lth draw draws)  [%| %invalid-draw]
  ?.  ?&((gth (lent candidates) 0) (lte (lent candidates) 4))
    [%| %candidate-count]
  ?.  (levy candidates |=(c=candidate ?&((gth id.c 0) (lte (met 0 id.c) 256) (gth digest.c 0) (lte (met 0 digest.c) 256) (valid-ratio energy.c))))
    [%| %invalid-candidate]
  =/  ordered=(list candidate)
    (sort candidates |=([a=candidate b=candidate] (lth id.a id.b)))
  ::  Same ID is ambiguous. Same act is one outcome, with identical eligibility
  ::  and rational energy required; smallest ID is its deterministic label.
  =/  canonical=(each (list candidate) @tas)
    =/  todo=(list candidate)  ordered
    =/  kept=(list candidate)  ~
    |-  ^-  (each (list candidate) @tas)
    ?~  todo  [%& (flop kept)]
    =/  c=candidate  i.todo
    ?:  (lien t.todo |=(other=candidate =(id.c id.other)))
      [%| %duplicate-id]
    =/  copies=(list candidate)
      (skim kept |=(other=candidate =(digest.c digest.other)))
    ?.  (levy copies |=(other=candidate ?&(=(eligible.c eligible.other) (same-energy energy.c energy.other))))
      [%| %conflicting-duplicate]
    $(todo t.todo, kept ?~(copies [c kept] kept))
  ?:  ?=(%| -.canonical)  [%| p.canonical]
  =/  admitted=(list candidate)
    (skim p.canonical |=(c=candidate eligible.c))
  ?:  =(0 (lent admitted))  [%| %no-eligible-candidate]
  =/  minimum=ratio
    =/  remaining=(list candidate)  admitted
    =/  best=ratio  [1 1]
    |-  ^-  ratio
    ?~  remaining  best
    $(remaining t.remaining, best ?:((lower energy.i.remaining best) energy.i.remaining best))
  =/  weights=(list weighted)
    %+  turn  admitted
    |=  c=candidate
    ^-  weighted
    ::  gain is in millionths; chi=5083204/1000000 cancels that scale.
    =/  delta=@ud
      (sub (mul num.energy.c den.minimum) (mul num.minimum den.energy.c))
    =/  top=@ud  (mul scale (mul (add den.attention num.attention) (mul gain delta)))
    =/  bottom=@ud  (mul 5.083.204 (mul den.attention (mul den.energy.c den.minimum)))
    [c (decay (div top bottom))]
  =/  total=@ud  (roll weights |=([w=weighted n=@ud] (add weight.w n)))
  =/  target=@ud  (div (mul draw total) draws)
  =/  selected=@ud
    =/  remaining=(list weighted)  weights
    =/  cumulative=@ud  0
    |-  ^-  @ud
    ?~  remaining  !!
    =/  next=@ud  (add cumulative weight.i.remaining)
    ?:  (lth target next)  id.choice.i.remaining
    $(remaining t.remaining, cumulative next)
  =/  contrast=?
    (lien admitted |=(c=candidate !(same-energy minimum energy.c)))
  [%& [%qpc-select-v1 attention gain draw ordered weights total selected contrast]]
--
