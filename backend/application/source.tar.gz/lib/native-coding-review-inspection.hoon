::  Pure page inspection law. Complete coverage is not semantic approval.
/-  ri=native-coding-review-inspection, np=native-coding-provider
/+  project=native-coding-project, provider=native-coding-provider,
    review=native-coding-review-request, cr=codex-responses,
    attestation=native-coding-provider-attestation
|%
++  source-valid
  |=  s=source:ri
  ^-  ?
  ?&  (path-valid:project pax.s)  ?=(^ pax.s)
      =(mark.s (rear pax.s))  !=(0 blob.s)  !=(0 sha256.s)
      (lte bytes.s file-byte-limit:project)
  ==
++  source-matches
  |=  [s=source:ri text=@t]
  ^-  ?
  ?&  (source-valid s)  (text-valid:ri text file-byte-limit:project)
      =(bytes.s (met 3 text))  =(sha256.s (shax text))
      =(blob.s `@ux`(page-to-lobe:clay [mark.s text]))
  ==
++  valid
  |=  m=manifest:ri
  ^-  ?
  ?.  ?&  !=(0 candidate.m)  !=(0 report.m)  !=(0 configuration.m)
          !=(0 session.m)  !=(0 request.m)
          (revision-valid:project before.m)  (revision-valid:project staged.m)
          =(owner.before.m owner.staged.m)
          (text-valid:ri artifact.m 4.096)  !=(0 artifact.m)
          (text-valid:ri objective.m 8.192)  !=(0 objective.m)
          (text-valid:ri instructions.m 8.192)
          (text-valid:ri conventions.m 4.096)
          (gte (lent sources.m) 1)  (lte (lent sources.m) 16)
          (levy sources.m source-valid)
          =((lent sources.m) ~(wyt in (silt (turn sources.m |=(s=source:ri [side.s pax.s])))))
          (gte (lent pages.m) 1)  (lte (lent pages.m) page-limit:ri)
          (lte (met 3 (jam m)) 131.072)
      ==  %.n
  =/  rows=(list page:ri)  pages.m
  =/  file=@ud  0
  =/  offset=@ud  0
  |-  ^-  ?
  ?~  rows  &(=(file (lent sources.m)) =(0 offset))
  ?.  (lth file (lent sources.m))  %.n
  =/  s=source:ri  (snag file sources.m)
  =/  p=page:ri  i.rows
  ?.  ?&  =(file source.p)  =(offset offset.p)  !=(0 sha256.p)
          (lte bytes.p page-bytes:ri)
          |((gth bytes.p 0) &(=(0 bytes.s) =(0 offset)))
          (lte (add offset bytes.p) bytes.s)
      ==  %.n
  =/  end=@ud  (add offset bytes.p)
  ?:  =(end bytes.s)  $(rows t.rows, file +(file), offset 0)
  $(rows t.rows, offset end)
++  page-valid
  |=  [m=manifest:ri index=@ud text=@t]
  ^-  ?
  ?.  (lth index (lent pages.m))  %.n
  =/  p=page:ri  (snag index pages.m)
  ?&  (text-valid:ri text page-bytes:ri)
      =(bytes.p (met 3 text))  =(sha256.p (shax text))
      (lte (met 3 (en:json:html s+text)) page-json-bytes:ri)
  ==
++  prefix
  ::  Bound JSON expansion and keep multibyte UTF-8 codepoints intact.
  |=  text=@t
  ^-  @t
  =/  bytes=@ud  (min page-bytes:ri (met 3 text))
  |-  ^-  @t
  ?:  =(0 bytes)  ''
  =/  part=@t  (end [3 bytes] text)
  ?.  (text-valid:ri part page-bytes:ri)  $(bytes (dec bytes))
  ?:  (lte (met 3 (en:json:html s+part)) page-json-bytes:ri)  part
  $(bytes (div bytes 2))
++  partition
  ::  Parent uses this after canonical Clay reads. No source authority here.
  |=  [index=@ud s=source:ri text=@t]
  ^-  (each [pages=(list page:ri) texts=(list @t)] @tas)
  ?.  (source-matches s text)  [%| %inspection-source-mismatch]
  =/  offset=@ud  0
  =/  pages=(list page:ri)  ~
  =/  texts=(list @t)  ~
  |-  ^-  (each [pages=(list page:ri) texts=(list @t)] @tas)
  ?:  (gte (lent pages) page-limit:ri)  [%| %inspection-page-capacity]
  =/  remaining=@t  (rsh [3 offset] text)
  =/  part=@t  (prefix remaining)
  =/  bytes=@ud  (met 3 part)
  ?:  &(=(0 bytes) !=(0 remaining))  [%| %inspection-page-encoding]
  =.  pages  [[index offset bytes (shax part)] pages]
  =.  texts  [part texts]
  =/  next=@ud  (add offset bytes)
  ?:  =(next bytes.s)  [%& [(flop pages) (flop texts)]]
  $(offset next)
++  prompt
  |=  [m=manifest:ri index=@ud text=@t]
  ^-  @t
  =/  p=page:ri  (snag index pages.m)
  =/  s=source:ri  (snag source.p sources.m)
  %-  en:json:html
  %-  pairs:enjs:format
  :~  ['inspection' s+(scot %ux (key:ri m))]
      ['page' s+(scot %ud index)]
      ['artifact' s+artifact.m]
      ['objective' s+objective.m]
      ['instructions' s+instructions.m]
      ['conventions' s+conventions.m]
      ['scope' s+scope-text:ri]
      ['side' s+side.s]  ['path' s+(spat pax.s)]
      ['source' s+(scot %ux (source-id:ri s))]
      ['revision' s+(scot %ux (digest:ri ?:(=(%before side.s) before.m staged.m)))]
      ['offset' (numb:enjs:format offset.p)]
      ['bytes' (numb:enjs:format bytes.p)]
      ['total' (numb:enjs:format bytes.s)]
      ['pageDigest' s+(scot %ux sha256.p)]
      ['text' s+text]
  ==
++  inference
  |=  [our=@p c=config:review m=manifest:ri index=@ud text=@t]
  ^-  (each request:np @tas)
  ?.  &((config-valid:review our c) (valid m) =(parent.c owner.before.m) (page-valid m index text))  [%| %inspection-context-invalid]
  =/  body=@t  (prompt m index text)
  ?.  (lte (met 3 body) 61.440)  [%| %inspection-context-too-large]
  ::  Page receipts need complete JSON; login backends require SSE transport.
  =/  r=request:np
    [%native-coding-inference-v1 (call-id:ri (digest:ri c) (key:ri m) index) session.c selection.c instruction-text:ri ~[[%user ~[[%text body]]]] ~ 1.024 |(=(%codex provider.selection.c) &(=(%xai provider.selection.c) =(endpoint.selection.c xai-session-endpoint:np)))]
  ?:((request-valid:provider r) [%& r] [%| %inspection-provider-request-invalid])
++  decode
  |=  [c=config:review m=manifest:ri index=@ud r=reply:np]
  ^-  (each [gap=? reason=@t] @tas)
  ?.  &((lte (met 3 raw.r) raw-reply-limit:ri) =(raw-digest.r (shax raw.r)))  [%| %inspection-reply-invalid]
  (decode-result c m index (publish:provider r))
++  decode-receipt
  ::  The caller authenticates the moon journal/watch. A self digest alone
  ::  cannot establish where an attestation originated.
  |=  [our=@p c=config:review m=manifest:ri index=@ud text=@t r=inspection-reply:ri]
  ^-  (each [gap=? reason=@t] @tas)
  ?:  ?=(%native-coding-reply-v1 -.r)  (decode c m index r)
  ?.  (compact-valid:attestation our r)  [%| %inspection-attestation-invalid]
  =/  expected  (inference our c m index text)
  ?:  ?=(%| -.expected)  [%| p.expected]
  ?.  &(=(job.r id.p.expected) =(selection.r provider-key.c) =(request.r (value-digest:attestation p.expected)))
    [%| %inspection-attestation-request-mismatch]
  (decode-result c m index result.r)
++  decode-result
  |=  [c=config:review m=manifest:ri index=@ud r=public-reply:np]
  ^-  (each [gap=? reason=@t] @tas)
  ?.  ?&  =(id.r (call-id:ri (digest:ri c) (key:ri m) index))
          (model-matches:provider selection.c provider.r model.r)
          =(%complete stop.r)  ?=(~ calls.r)
          !=(0 raw-digest.r)
          (text-valid:ri text.r 8.192)
      ==  [%| %inspection-reply-invalid]
  =/  parsed  (de:json:html text.r)
  ?~  parsed  [%| %inspection-json-invalid]
  ?.  ?=(%o -.u.parsed)  [%| %inspection-json-invalid]
  ?.  =((silt ~['inspection' 'page' 'decision' 'reason']) ~(key by p.u.parsed))
    [%| %inspection-schema-invalid]
  ?.  &(=(`(scot %ux (key:ri m)) (string:cr u.parsed 'inspection')) =(`(scot %ud index) (string:cr u.parsed 'page')))
    [%| %inspection-reply-correlation]
  =/  decision  (string:cr u.parsed 'decision')
  =/  reason  (string:cr u.parsed 'reason')
  ?~  decision  [%| %inspection-decision-missing]
  ?~  reason  [%| %inspection-reason-missing]
  ?.  &(|(=('inspected' u.decision) =('gap' u.decision)) !=(0 u.reason) (text-valid:ri u.reason 2.048))
    [%| %inspection-finding-invalid]
  [%& [=('gap' u.decision) u.reason]]
++  covered
  ::  Reassemble every supplied file and independently recheck its Clay lobe.
  |=  e=entry:ri
  ^-  ?
  ?.  &((valid manifest.e) =((lent pages.manifest.e) (lent receipts.e)))  %.n
  ?.  =((gulf 0 (dec (lent pages.manifest.e))) (turn receipts.e |=(r=receipt:ri page.r)))  %.n
  ?.  (levy receipts.e |=(r=receipt:ri (page-valid manifest.e page.r text.r)))  %.n
  =/  sources=(list source:ri)  sources.manifest.e
  =/  index=@ud  0
  |-  ^-  ?
  ?~  sources  %.y
  =/  parts=(list @t)
    %+  murn  receipts.e
    |=  r=receipt:ri
    =/  p=page:ri  (snag page.r pages.manifest.e)
    ?:(=(index source.p) `text.r ~)
  ?.  (source-matches i.sources (rap 3 parts))  %.n
  $(sources t.sources, index +(index))
++  entry-valid
  |=  [our=@p e=entry:ri]
  ^-  ?
  ?.  &((config-valid:review our config.e) (valid manifest.e) =(parent.config.e owner.before.manifest.e) =(next.e (lent receipts.e)) (lte next.e (lent pages.manifest.e)))  %.n
  ?.  (lte (add (met 3 (prompt manifest.e 0 '')) page-json-bytes:ri) 61.440)  %.n
  =/  rows=(list receipt:ri)  receipts.e
  =/  index=@ud  0
  =/  receipts-valid=?
    |-  ^-  ?
    ?~  rows  %.y
    =/  r=receipt:ri  i.rows
    =/  decoded  (decode-receipt our config.e manifest.e index text.r reply.r)
    ?.  &(?=(%& -.decoded) =(index page.r) (page-valid manifest.e index text.r))  %.n
    ?.  =([gap.r reason.r] p.decoded)  %.n
    $(rows t.rows, index +(index))
  ?.  receipts-valid  %.n
  ?.  ?~(pending.e %.y (page-valid manifest.e next.e u.pending.e))  %.n
  ?-  phase.e
    %ready  &(?=(~ pending.e) (lth next.e (lent pages.manifest.e)) !cancelled.e)
    %pending  &(?=(^ pending.e) !cancelled.e)
    %unknown  ?=(^ pending.e)
    %complete  &(?=(~ pending.e) !cancelled.e (covered e))
    %refused  %.y
    %cancelled  &(?=(~ pending.e) cancelled.e)
  ==
++  coverage
  |=  e=entry:ri
  ^-  @ux
  ?.  =(%complete phase.e)  0x0
  =/  tag=@tas
    ?:  (lien receipts.e |=(r=receipt:ri ?=(%native-coding-provider-attestation-v1 -.reply.r)))
      %native-coding-review-inspection-coverage-v2
    %native-coding-review-inspection-coverage-v1
  (digest:ri [tag (digest:ri config.e) (key:ri manifest.e) (turn receipts.e |=(r=receipt:ri [page.r (shax text.r) (receipt-digest:ri reply.r) gap.r reason.r]))])
--
