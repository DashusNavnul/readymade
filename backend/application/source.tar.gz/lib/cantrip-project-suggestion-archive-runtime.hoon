::  Prospective app hooks. Commit every returned field together.
::  No activation here. Owner qualification requires a separate actual
::  prior-source/DATA proof; fingerprints alone never establish provenance.
/-  pa=cantrip-project-access, j=cantrip-project-suggestion-journal,
    mp=multiplayer-project, nc=native-coding, view=cantrip-project-view,
    bw=cantrip-project-bundle
/+  owner=cantrip-project-bundle-owner-state,
    io=cantrip-project-suggestion-archive-io,
    journal=cantrip-project-suggestion-journal,
    archive=cantrip-project-receipt-archive, law=cantrip-law-window,
    scalar=cantrip-project-access-runtime, receipt=cantrip-project-receipt,
    transport=cantrip-project-bundle-runtime, read=cantrip-project-bundle-read,
    access=cantrip-project-access
|%
+$  transition
  [scalar=records:pa extra=supplement:owner cards=(list card:agent:gall)]
+$  supplement  supplement:owner
+$  origin  [type=@ux data=@ux]
+$  action-result
  [grants=grants:pa scalar=records:pa extra=supplement cards=(list card:agent:gall)]
+$  manual-command
  $%  [%cantrip-project-history-one-v1 key=key:j expected=@ux]
      [%cantrip-project-history-observe-v1 ~]
  ==
+$  automatic-command
  [%cantrip-project-history-advance-v1 head=head:archive key=key:j expected=@ux]
+$  hot-journal-result
  [%cantrip-project-journal-v2 format=%native-coding-patches-v1 records=journal:j]
++  unknown  unknown:owner
++  valid  valid:owner
++  manual-check
  ::  Owner command boundary before any native reads. The selected receipt
  ::  comes only from the current hot map, never from an operator payload.
  |=  [b=bowl:gall grants=grants:pa scalar=records:pa extra=supplement raw=*]
  ^-  (each manual-command @tas)
  ?.  =(our.b src.b)  [%| %receipt-archive-owner-required]
  =/  decoded  ((soft manual-command) raw)
  ?~  decoded  [%| %receipt-archive-command-invalid]
  ?.  =(raw u.decoded)  [%| %receipt-archive-command-invalid]
  ?.  (valid our.b grants scalar extra)  [%| %journal-invalid]
  ?~  history.extra  [%| %receipt-history-unobserved]
  =/  command=manual-command  u.decoded
  ?:  ?=(%cantrip-project-history-observe-v1 -.command)  [%& command]
  =/  history=shared-state:archive  u.history.extra
  ?~  head.history  [%| %receipt-archive-unconfigured]
  ?^  writing.history  [%| %receipt-archive-pending]
  =/  held  (lookup:journal (joined:owner scalar extra) key.command)
  ?~  held  [%| %receipt-archive-record-missing]
  ?.  ?=(%legacy -.u.held)  [%| %scalar-receipt-required]
  ?.  =(expected.command (hash:journal u.held))  [%| %receipt-archive-record-mismatch]
  [%& command]
++  manual
  ::  No advance call: one request submits one receipt, or only observes.
  |=  [b=bowl:gall grants=grants:pa scalar=records:pa extra=supplement raw=*]
  ^-  (each transition @tas)
  =/  checked  (manual-check b grants scalar extra raw)
  ?:  ?=(%| -.checked)  [%| p.checked]
  =/  command=manual-command  p.checked
  ?-  -.command
    %cantrip-project-history-one-v1
      (one b grants scalar extra key.command expected.command)
    %cantrip-project-history-observe-v1
      (observe b grants scalar extra)
  ==
++  qualify
  ::  Bounded owner migration instruction only, after the operator packet has
  ::  qualified actual prior source/DATA as never configured. Fingerprints
  ::  bind that instruction; they are not a proof or a peer-supplied authority.
  ::  No default, replay, missing observation or load calls this constructor.
  |=  [our=@p actor=@p extra=supplement held=(unit origin) expected=origin current=@ux expected-current=@ux]
  ^-  (each supplement @tas)
  ?.  =(our actor)  [%| %receipt-archive-owner-required]
  ?^  history.extra  [%| %receipt-history-already-qualified]
  ?.  &(=(held `expected) !=(0 type.expected) !=(0 data.expected) !=(0 expected-current) =(current expected-current))
    [%| %receipt-history-qualification-mismatch]
  [%& extra(history `*shared-state:archive)]
++  reload
  ::  Preserve the exact pending intent; no read, retry, append or retirement.
  |=  [our=@p grants=grants:pa scalar=records:pa extra=supplement:owner]
  ^-  (each transition @tas)
  ?.  (valid:owner our grants scalar extra)  [%| %journal-invalid]
  [%& scalar extra ~]
++  finish
  |=  [extra=supplement:owner got=(each change:io @tas)]
  ^-  (each transition @tas)
  ?:  ?=(%| -.got)  [%| p.got]
  =/  moved=change:io  p.got
  [%& legacy.records.moved extra(bundles bundles.records.moved, history `history.moved) cards.moved]
++  configure
  |=  [b=bowl:gall grants=grants:pa scalar=records:pa extra=supplement:owner desk=@tas]
  ^-  (each transition @tas)
  ?.  (valid:owner our.b grants scalar extra)  [%| %journal-invalid]
  ?~  history.extra  [%| %receipt-history-unobserved]
  =/  got  (configure:io b u.history.extra desk)
  ?:  ?=(%| -.got)  [%| p.got]
  [%& scalar extra(history `p.got) ~]
++  one-with
  ::  Pure seam. Supplied observations cannot repair UNKNOWN saved history.
  |=  [b=bowl:gall grants=grants:pa scalar=records:pa extra=supplement:owner k=key:j expected=@ux delivery=delivery:archive index=indexed:archive body=observed:j]
  ^-  (each transition @tas)
  ?.  (valid:owner our.b grants scalar extra)  [%| %journal-invalid]
  ?~  history.extra  [%| %receipt-history-unobserved]
  (finish extra (one-with:io b u.history.extra grants (joined:owner scalar extra) k expected delivery index body))
++  one
  |=  [b=bowl:gall grants=grants:pa scalar=records:pa extra=supplement:owner k=key:j expected=@ux]
  ^-  (each transition @tas)
  ?.  (valid:owner our.b grants scalar extra)  [%| %journal-invalid]
  ?~  history.extra  [%| %receipt-history-unobserved]
  (finish extra (one:io b u.history.extra grants (joined:owner scalar extra) k expected))
++  advance
  |=  [b=bowl:gall grants=grants:pa scalar=records:pa extra=supplement:owner]
  ^-  (each transition @tas)
  ?.  (valid:owner our.b grants scalar extra)  [%| %journal-invalid]
  ?~  history.extra  [%| %receipt-history-unobserved]
  (finish extra (advance:io b u.history.extra grants (joined:owner scalar extra)))
++  observe
  |=  [b=bowl:gall grants=grants:pa scalar=records:pa extra=supplement:owner]
  ^-  (each transition @tas)
  ?.  (valid:owner our.b grants scalar extra)  [%| %journal-invalid]
  ?~  history.extra  [%| %receipt-history-unobserved]
  (finish extra (observe:io b u.history.extra grants (joined:owner scalar extra)))
++  callback
  |=  [b=bowl:gall wire=wire sign=sign-arvo]
  ^-  ?
  &(=(our.b src.b) =(wire /project-suggestion-archive) ?=([%clay %writ *] sign))
++  arvo
  ::  The app routes only this exact callback. Observation emits no
  ::  cards; a callback cannot start another archival or submit an old request.
  |=  [b=bowl:gall grants=grants:pa scalar=records:pa extra=supplement:owner wire=wire sign=sign-arvo]
  ^-  (each transition @tas)
  ?.  (callback b wire sign)
    (reload our.b grants scalar extra)
  (observe b grants scalar extra)
++  lookup
  ::  Canonical cold nonce identity for future authenticated dedup/recovery.
  |=  [b=bowl:gall grants=grants:pa scalar=records:pa extra=supplement:owner k=key:j]
  ^-  observed:j
  ?.  (valid:owner our.b grants scalar extra)  [%| %journal-invalid]
  ?~  history.extra  [%| %receipt-history-unobserved]
  (lookup:io b u.history.extra grants (joined:owner scalar extra) k)
++  lookup-hash
  ::  Canonical full old noun/hash for future owner inbox detail/history.
  |=  [b=bowl:gall grants=grants:pa scalar=records:pa extra=supplement:owner digest=@ux]
  ^-  observed:j
  ?.  (valid:owner our.b grants scalar extra)  [%| %journal-invalid]
  ?~  history.extra  [%| %receipt-history-unobserved]
  (lookup-hash:io b u.history.extra grants (joined:owner scalar extra) digest)
++  admit-with
  ::  Existing common admission law includes current grant/member/source and
  ::  exact hot/cold nonce checks. This seam emits no receipt or project cards.
  |=  [our=@p actor=@p at=@da p=project:mp grants=grants:pa scalar=records:pa extra=supplement:owner r=request:j basis=basis:pa w=window:law scope=(unit project:nc) cold=observed:j]
  ^-  result:j
  =/  got  (history-observation:owner extra cold)
  (admit:journal our actor at p grants (joined:owner scalar extra) r basis w scope got)
++  recovery-kicks
  |=  [b=bowl:gall key=(unit [@t @p])]
  ^-  (list card:agent:gall)
  =/  paths=(set path)
    %-  silt
    %+  murn  ~(val by sup.b)
    |=  [peer=@p pax=path]
    ^-  (unit path)
    =/  parsed  (parse:receipt pax)
    ?~  parsed  ~
    ?.  =(peer peer.u.parsed)  ~
    ?^  key
      ?.  =(u.key [project.query.u.parsed peer])  ~
      `pax
    `pax
  (turn ~(tap in paths) |=(pax=path `card:agent:gall`[%give %kick ~[pax] ~]))
++  bundle-kicks
  |=  [b=bowl:gall key=(unit [@t @p])]
  ^-  (list card:agent:gall)
  =/  paths=(set path)
    %-  silt
    %+  murn  ~(val by sup.b)
    |=  [peer=@p pax=path]
    ^-  (unit path)
    =/  parsed  (parse:transport pax)
    ?~  parsed  ~
    ?.  =(peer peer.u.parsed)  ~
    ?^  key
      ?.  =(u.key [project.query.u.parsed peer])  ~
      `pax
    `pax
  (turn ~(tap in paths) |=(pax=path `card:agent:gall`[%give %kick ~[pax] ~]))
++  act
  ::  One canonical writer replaces the old scalar insertion path. Original
  ::  v1 event/path bytes are constructed by the already qualified transport.
  |=  [b=bowl:gall grants=grants:pa records=records:pa extra=supplement action=action:pa w=window:law]
  ^-  (each action-result @tas)
  ?.  (valid:owner our.b grants records extra)  [%| %journal-invalid]
  ?:  ?=(%cantrip-project-request-v1 -.action)
    =/  moved  (act:transport b grants (joined:owner records extra) [%legacy request.action] history.extra w)
    ?:  ?=(%| -.moved)  [%| p.moved]
    =/  next  p.moved
    =/  notified=(list card:agent:gall)
      (automatic-notify b grants (joined:owner records extra) records.next extra receipt.next)
    [%& grants legacy.records.next extra(bundles bundles.records.next) (weld cards.next notified)]
  ::  Revocation never depends on cold availability or qualification.
  =/  moved  (act:scalar b grants records action w)
  ?:  ?=(%| -.moved)  [%| p.moved]
  =/  key=[@t @p]
    ?:  ?=(%cantrip-project-grant-v1 -.action)  [project.grant.action peer.grant.action]
    [project.action peer.action]
  =/  closed=(list card:agent:gall)
    ?:(=(grants grants.p.moved) ~ (weld (recovery-kicks b `key) (bundle-kicks b `key)))
  [%& grants.p.moved records.p.moved extra (weld cards.p.moved closed)]
++  hot-journal
  ::  Owner-only hot receipt detail, including complete bundle sources. This
  ::  token advertises the executor format, never permission to use it.
  |=  [our=@p actor=@p grants=grants:pa scalar=records:pa extra=supplement]
  ^-  (each hot-journal-result @tas)
  ?.  =(our actor)  [%| %receipt-archive-owner-required]
  ?.  (valid:owner our grants scalar extra)  [%| %journal-invalid]
  [%& [%cantrip-project-journal-v2 %native-coding-patches-v1 (joined:owner scalar extra)]]
++  finish-bundle-hot
  ::  Pure seam: commit the qualified transport result. No history mutation,
  ::  source write or further submission; bundle-submit-hot adds the kick.
  |=  [grants=grants:pa extra=supplement got=(each transition:transport @tas)]
  ^-  (each action-result @tas)
  ?:  ?=(%| -.got)  [%| p.got]
  =/  next=transition:transport  p.got
  [%& grants legacy.records.next extra(bundles bundles.records.next) cards.next]
++  bundle-submit-hot
  ::  Bundles share the scalar 48/64 law: an exact new insertion above hot
  ::  pressure schedules the same one owner-local archive kick.
  |=  [b=bowl:gall grants=grants:pa records=records:pa extra=supplement action=action:bw w=window:law]
  ^-  (each action-result @tas)
  ?.  (valid:owner our.b grants records extra)  [%| %journal-invalid]
  =/  before=journal:j  (joined:owner records extra)
  =/  moved  (act:transport b grants before [%bundle request.action] history.extra w)
  =/  done  (finish-bundle-hot grants extra moved)
  ?:  ?=(%| -.done)  done
  ?>  ?=(%& -.moved)
  =/  kick  (automatic-notify b grants before records.p.moved extra receipt.p.moved)
  [%& p.done(cards (weld cards.p.done kick))]
++  bundle-refused
  ::  A typed refusal on the requester's own watch path instead of a bare nack,
  ::  only when that exact path is subscribed. No state, receipt or archive change.
  |=  [b=bowl:gall action=action:bw reason=@tas]
  ^-  (unit (list card:agent:gall))
  =/  r=bundle-request:pa  request.action
  =/  q=query:view  [project.r generation.r nonce.r]
  =/  pax=path  (route:transport src.b q %.n)
  ?.  (lien ~(val by sup.b) |=([peer=@p p=path] &(=(src.b peer) =(pax p))))  ~
  =/  told=event:bw  [%cantrip-project-bundle-refused-v1 our.b src.b q reason]
  `~[[%give %fact ~[pax] %noun !>(told)] [%give %kick ~[pax] ~]]
++  bundle-watch-hot
  |=  [b=bowl:gall grants=grants:pa records=records:pa extra=supplement pax=path w=window:law]
  ^-  (each (list card:agent:gall) @tas)
  ?.  (valid:owner our.b grants records extra)  [%| %journal-invalid]
  (watch:transport b grants (joined:owner records extra) pax history.extra w)
++  automatic-notify
  ::  Only an exact new insertion schedules owner-local work. Replay,
  ::  cold recovery and grant actions never enter this lane. No IO here.
  |=  [b=bowl:gall grants=grants:pa before=journal:j after=journal:j extra=supplement e=entry:j]
  ^-  (list card:agent:gall)
  ?.  (valid:owner our.b grants legacy.before extra)  ~
  ?~  history.extra  ~
  =/  h=shared-state:archive  u.history.extra
  ?~  head.h  ~
  ?^  writing.h  ~
  =/  k=key:j  (key-for:journal e)
  ?^  (lookup:journal before k)  ~
  =/  expected=journal:j
    ?-  -.e
      %legacy  before(legacy (~(put by legacy.before) k value.e))
      %bundle  before(bundles (~(put by bundles.before) k value.e))
    ==
  ?.  =(after expected)  ~
  ?.  (gth (count:journal after) hot-limit:archive)  ~
  =/  command=automatic-command
    [%cantrip-project-history-advance-v1 u.head.h k (hash:journal e)]
  ~[[%pass /project-suggestion-archive-start %agent [our.b %cantrip] %poke %noun !>(command)]]
++  automatic-selection
  ::  Only actual owner-local events may reach native IO. Never retag src.
  |=  [b=bowl:gall grants=grants:pa scalar=records:pa extra=supplement delivery=delivery:archive]
  ^-  observed:j
  ?.  =(our.b src.b)  [%| %receipt-archive-owner-required]
  ?.  (valid:owner our.b grants scalar extra)  [%| %journal-invalid]
  ?~  history.extra  [%| %receipt-history-unobserved]
  =/  h=shared-state:archive  u.history.extra
  ?~  head.h  [%| %receipt-archive-unconfigured]
  ?^  writing.h  [%| %receipt-archive-pending]
  (choose:io our.b src.b grants (joined:owner scalar extra) delivery)
++  automatic-start
  ::  A refusal keeps the admitted receipt/confirmed retirement. No retry is
  ::  scheduled and no returned card is dispatched until the app commits it.
  |=  [b=bowl:gall grants=grants:pa scalar=records:pa extra=supplement]
  ^-  transition
  =/  unchanged=transition  [scalar extra ~]
  =/  chosen  (automatic-selection b grants scalar extra `(shared-delivery-keys:archive b))
  ?:  ?=(%| -.chosen)  unchanged
  ?~  p.chosen  unchanged
  =/  got
    %-  mole
    |.  (finish extra (automatic-one:io b (need history.extra) grants (joined:owner scalar extra) (key-for:journal u.p.chosen) (hash:journal u.p.chosen)))
  ?~  got  unchanged
  ?:  ?=(%| -.u.got)  unchanged
  p.u.got
++  automatic-check
  |=  [b=bowl:gall grants=grants:pa scalar=records:pa extra=supplement raw=*]
  ^-  ?
  ?.  =(our.b src.b)  %.n
  =/  parsed  ((soft automatic-command) raw)
  ?~  parsed  %.n
  ?.  =(raw u.parsed)  %.n
  ?.  (valid:owner our.b grants scalar extra)  %.n
  ?~  history.extra  %.n
  =/  h=shared-state:archive  u.history.extra
  ?.  &(=(head.h `head.u.parsed) =(~ writing.h))  %.n
  =/  held  (lookup:journal (joined:owner scalar extra) key.u.parsed)
  ?~  held  %.n
  =(expected.u.parsed (hash:journal u.held))
++  automatic
  ::  The owner may also issue this exact head/key/hash kick at hard64 after
  ::  reload. Load never calls it; it cannot replace or retry a pending write.
  |=  [b=bowl:gall grants=grants:pa scalar=records:pa extra=supplement raw=*]
  ^-  transition
  ?.  (automatic-check b grants scalar extra raw)  [scalar extra ~]
  (automatic-start b grants scalar extra)
++  automatic-callback
  ::  Exact next revision AND pending receipt hash fence old callbacks.
  |=  [b=bowl:gall extra=supplement wire=wire sign=sign-arvo]
  ^-  ?
  ?.  &(=(our.b src.b) ?=([%clay %writ *] sign))  %.n
  ?~  history.extra  %.n
  =/  h=shared-state:archive  u.history.extra
  ?~  head.h  %.n
  ?~  writing.h  %.n
  =(wire (auto-wire:io u.head.h u.writing.h))
++  automatic-arvo
  ::  Only confirmed automatic work can continue. Unknown/error preserves
  ::  pending intent. Each confirmed revision yields at most one next append.
  |=  [b=bowl:gall grants=grants:pa scalar=records:pa extra=supplement wire=wire sign=sign-arvo]
  ^-  transition
  ?.  (automatic-callback b extra wire sign)  [scalar extra ~]
  =/  got  (observe b grants scalar extra)
  ?:  ?=(%| -.got)  [scalar extra ~]
  =/  confirmed=transition  p.got
  (automatic-start b grants scalar.confirmed extra.confirmed)
++  recover-with
  |=  [our=@p peer=@p q=query:view grant=@ux records=journal:j cold=observed:j]
  ^-  (each (unit receipt:pa) @tas)
  ?:  ?=(%| -.cold)  [%| p.cold]
  =/  k=key:j  [project.q peer generation.q nonce.q]
  =/  hot  (lookup:journal records k)
  ?:  &(?=(^ hot) ?=(^ p.cold) !=(u.hot u.p.cold))  [%| %receipt-history-conflict]
  =/  found=(unit entry:j)  ?~(hot p.cold hot)
  ?~  found  [%& ~]
  =/  e=entry:j  u.found
  ?.  &((entry-valid:journal our e) =(k (key-for:journal e)) =(grant (grant:journal e)))
    [%| %receipt-archive-invalid]
  ?.  ?=(%legacy -.e)  [%| %nonce-conflict]
  ?.  ?=(%suggest -.payload.value.e)  [%& ~]
  [%& `value.e]
++  watch-with
  |=  [b=bowl:gall grants=grants:pa records=records:pa extra=supplement pax=path current=authority:read cold=observed:j w=window:law]
  ^-  (each (list card:agent:gall) @tas)
  =/  parsed  (parse:receipt pax)
  ?~  parsed  [%| %path-invalid]
  ?.  =(src.b peer.u.parsed)  [%| %foreign-peer]
  =/  q=query:view  query.u.parsed
  =/  request=request:pa  [project.q generation.q nonce.q %suggest ~ ~ `@t`0]
  =/  allowed  (authorized:transport b grants request current w)
  ?:  ?=(%| -.allowed)  [%| p.allowed]
  ?.  (valid:owner our.b grants records extra)  [%| %journal-invalid]
  =/  got  (recover-with our.b src.b q (digest:access p.allowed) (joined:owner records extra) (history-observation:owner extra cold))
  ?:  ?=(%| -.got)  [%| p.got]
  [%& (cards:receipt pax p.got)]
++  watch
  |=  [b=bowl:gall grants=grants:pa records=records:pa extra=supplement pax=path w=window:law]
  ^-  (each (list card:agent:gall) @tas)
  =/  parsed  (parse:receipt pax)
  ?~  parsed  [%| %path-invalid]
  ?.  =(src.b peer.u.parsed)  [%| %foreign-peer]
  =/  q=query:view  query.u.parsed
  =/  request=request:pa  [project.q generation.q nonce.q %suggest ~ ~ `@t`0]
  =/  current  (authorize:read b grants request w)
  ?:  ?=(%| -.current)  [%| p.current]
  =/  cold  (cold:read our.b our.b now.b history.extra grants (joined:owner records extra) [project.q src.b generation.q nonce.q])
  (watch-with b grants records extra pax p.current cold w)
++  detail-with
  ::  One exact owner historical receipt, for BOTH inbox detail and Tell.
  ::  Unknown cold history remains an error even when the hot scan is empty.
  |=  [our=@p actor=@p grants=grants:pa records=records:pa extra=supplement digest=@ux cold=observed:j]
  ^-  (each (unit receipt:pa) @tas)
  ?.  =(our actor)  [%| %receipt-archive-owner-required]
  ?.  (valid:owner our grants records extra)  [%| %journal-invalid]
  =/  got  (history-observation:owner extra cold)
  ?:  ?=(%| -.got)  [%| p.got]
  =/  hot=(list receipt:pa)
    (skim ~(val by records) |=(r=receipt:pa =(digest (hash:archive r))))
  ?.  (lte (lent hot) 1)  [%| %receipt-history-conflict]
  =/  found=(unit receipt:pa)  ?~(hot ~ `i.hot)
  ?^  p.got
    =/  e=entry:j  u.p.got
    ?.  &((entry-valid:journal our e) =(digest (hash:journal e)) ?=(%legacy -.e))
      [%| %receipt-archive-invalid]
    ?^  found
      ?.  =(u.found value.e)  [%| %receipt-history-conflict]
      [%& found]
    [%& `value.e]
  [%& found]
++  detail
  |=  [b=bowl:gall grants=grants:pa records=records:pa extra=supplement digest=@ux]
  ^-  (each (unit receipt:pa) @tas)
  (detail-with our.b src.b grants records extra digest (lookup-hash b grants records extra digest))
++  detail-entry-with
  ::  Versioned owner detail retains the exact scalar or bundle noun.
  |=  [our=@p actor=@p grants=grants:pa records=records:pa extra=supplement digest=@ux cold=observed:j]
  ^-  observed:j
  ?.  =(our actor)  [%| %receipt-archive-owner-required]
  ?.  (valid:owner our grants records extra)  [%| %journal-invalid]
  =/  got  (history-observation:owner extra cold)
  ?:  ?=(%| -.got)  got
  =/  hot=(list entry:j)
    (skim (entries:journal (joined:owner records extra)) |=(e=entry:j =(digest (hash:journal e))))
  ?.  (lte (lent hot) 1)  [%| %receipt-history-conflict]
  =/  found=(unit entry:j)  ?~(hot ~ `i.hot)
  ?^  p.got
    =/  e=entry:j  u.p.got
    ?.  &((entry-valid:journal our e) =(digest (hash:journal e)))
      [%| %receipt-archive-invalid]
    ?^  found
      ?.  =(u.found e)  [%| %receipt-history-conflict]
      [%& found]
    [%& `e]
  [%& found]
++  detail-entry
  |=  [b=bowl:gall grants=grants:pa records=records:pa extra=supplement digest=@ux]
  ^-  observed:j
  (detail-entry-with our.b src.b grants records extra digest (lookup-hash b grants records extra digest))
++  page
  |=  [b=bowl:gall grants=grants:pa records=records:pa extra=supplement project=@t revision=@ud after=@ta limit=@ud]
  ^-  (each page:io @tas)
  ?.  (valid:owner our.b grants records extra)  [%| %journal-invalid]
  ?~  history.extra  [%| %receipt-history-unobserved]
  (page-read:io b u.history.extra grants (joined:owner records extra) project revision after limit)
++  page-v2
  |=  [b=bowl:gall grants=grants:pa records=records:pa extra=supplement project=@t revision=@ud after=@ta limit=@ud]
  ^-  (each page-v2:io @tas)
  ?.  (valid:owner our.b grants records extra)  [%| %journal-invalid]
  ?~  history.extra  [%| %receipt-history-unobserved]
  (page-read-v2:io b u.history.extra grants (joined:owner records extra) project revision after limit)
--
