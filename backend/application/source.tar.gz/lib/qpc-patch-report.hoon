::  V3 predictions travel inside the same authenticated patch call. This
::  codec supplies neither provenance nor permission; owners establish both.
/-  np=native-coding-provider
/+  report=qpc-report, responses=codex-responses
|%
++  tool-name  'qpc_patch_v3'
++  tool-name-patches  'qpc_patches_v3'
++  prediction-key  'qpc_prediction'
++  bases
  ::  The two candidate tools a tool-bound enrollment decorates: one-file
  ::  patch and the atomic multi-file patches proposal.
  ^-  (list @t)
  ~['patch' 'patches']
++  alias
  |=  base=@t
  ^-  @t
  ?>  |(=('patch' base) =('patches' base))
  ?:(=('patch' base) tool-name tool-name-patches)
++  base-of
  |=  name=@t
  ^-  (unit @t)
  ?:  =(tool-name name)  `'patch'
  ?:  =(tool-name-patches name)  `'patches'
  ~
++  fixed-string
  |=  text=@t
  ^-  json
  (pairs:enjs:format ~[['type' s+'string'] ['enum' a+~[s+text]]])
++  decorate
  |=  [manifest=@ux work=@ux dimensions=@ud base=tool:np]
  ^-  tool:np
  ?>  &((identifier:report manifest) (identifier:report work))
  ?>  &((gte dimensions 2) (lte dimensions 16))
  ?>  |(=('patch' name.base) =('patches' name.base))
  =/  args=json  parameters.base
  ?>  ?=([%o *] args)
  =/  props=json  (need (field:responses args 'properties'))
  =/  required=json  (need (field:responses args 'required'))
  ?>  &(?=([%o *] props) ?=([%a *] required))
  ?>  !(~(has by p.props) prediction-key)
  =/  scalar=json
    (pairs:enjs:format ~[['type' s+'integer'] ['minimum' n+'0'] ['maximum' n+'1000000']])
  =/  vector=json
    (pairs:enjs:format ~[['type' s+'array'] ['items' scalar] ['minItems' (numb:enjs:format dimensions)] ['maxItems' (numb:enjs:format dimensions)]])
  =/  prediction=json
    %-  pairs:enjs:format
    :~  ['type' s+'object']
        ['properties' (pairs:enjs:format ~[['manifest' (fixed-string (scot %ux manifest))] ['work' (fixed-string (scot %ux work))] ['confidence' vector]])]
        ['required' a+~[s+'manifest' s+'work' s+'confidence']]
        ['additionalProperties' b+%.n]
    ==
  =.  props  [%o (~(put by p.props) prediction-key prediction)]
  =/  added=(list json)  ~[[%s prediction-key]]
  =.  required  [%a (weld p.required added)]
  =.  args  [%o (~(put by (~(put by p.args) 'properties' props)) 'required' required)]
  :*  (alias name.base)
      (cat 3 description.base ' Include qpc_prediction in this same call, before checks. Confidence uses integer millionths in the frozen proposition order. It is a prediction, not permission or a check result.')
      args
  ==
++  normalize
  ::  Only the explicit alias loses its sensing field. Missing/bad sensing
  ::  still becomes a gap; it never creates new authority over ordinary work.
  ::  The caller must run the ordinary exact patch decoder on this result.
  |=  c=call:np
  ^-  call:np
  =/  base  (base-of name.c)
  ?.  &(?=(^ base) ?=([%o *] arguments.c))  c
  c(name u.base, arguments [%o (~(del by p.arguments.c) prediction-key)])
++  prediction
  ::  The owner separately authenticates the reply, checks temporal binding,
  ::  and validates the normalized patch's exact source and permitted scope.
  |=  [manifest=@ux work=@ux dimensions=@ud c=call:np]
  ^-  (each row:report @tas)
  ?.  ?&  (identifier:report manifest)  (identifier:report work)
          (gte dimensions 2)  (lte dimensions 16)
          (bounded:responses id.c 256)
      ==  [%| %qpc-report-binding-invalid]
  ?.  &(?=(^ (base-of name.c)) ?=([%o *] arguments.c))
    [%| %qpc-report-tool-mismatch]
  =/  value  (field:responses arguments.c prediction-key)
  ?~  value  [%| %qpc-report-missing]
  ?.  ?=([%o *] u.value)  [%| %qpc-report-shape-invalid]
  ?.  =((silt ~['manifest' 'work' 'confidence']) ~(key by p.u.value))
    [%| %qpc-report-shape-invalid]
  ?.  =(`[%s (scot %ux manifest)] (field:responses u.value 'manifest'))
    [%| %qpc-report-manifest-mismatch]
  ?.  =(`[%s (scot %ux work)] (field:responses u.value 'work'))
    [%| %qpc-report-work-mismatch]
  =/  vector  (field:responses u.value 'confidence')
  ?~  vector  [%| %qpc-report-values-invalid]
  =/  got  (values:report dimensions u.vector)
  ?~  got  [%| %qpc-report-values-invalid]
  [%& [id.c u.got]]
++  predictions
  |=  [manifest=@ux work=@ux dimensions=@ud calls=(list call:np)]
  ^-  (each (list row:report) @tas)
  ?.  &((gte (lent calls) 1) (lte (lent calls) 4))
    [%| %qpc-report-binding-invalid]
  ?.  =((lent calls) ~(wyt in (silt (turn calls |=(c=call:np id.c)))))
    [%| %qpc-report-call-mismatch]
  =/  out=(list row:report)  ~
  |-  ^-  (each (list row:report) @tas)
  ?~  calls  [%& (flop out)]
  =/  row  (prediction manifest work dimensions i.calls)
  ?:  ?=(%| -.row)  [%| p.row]
  $(calls t.calls, out [p.row out])
--
