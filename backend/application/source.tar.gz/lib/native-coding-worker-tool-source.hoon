::  Ordinary-tool transport. Canonical current authority admits an immutable
::  working/accepted revision; only its detached full snapshot leaves the owner.
/-  x=native-coding-worker-work, r=native-coding-worker-runtime, nc=native-coding
/+  work=native-coding-worker-work, old=native-coding-worker-source,
    law=native-coding-worker, ct=cantrip-native-coding,
    archive=native-coding-hoon-artifact, guard=viki-scry-guard
|%
++  name
  |=  [prefix=@tas o=tool-order:x]
  ^-  @tas
  (cat 3 prefix (crip (skip (trip (scot %ux (digest:work o))) |=(c=@t =(c '.')))))
++  export-desk  |=(o=tool-order:x (name %ncwte- o))
++  import-desk  |=(o=tool-order:x (name %ncwti- o))
++  current
  ::  Re-read the actual standing grant and Viki request before any export
  ::  effect. Re-derive the complete prepared input; a cached order is not proof.
  |=  [our=@p now=@da o=tool-order:x]
  ^-  (each input:archive @tas)
  ?.  ?&  (tool-order-valid:work o)  =(our owner.pairing.o)
          (lte issued.o now)  (lth now deadline.o)
      ==  [%| %worker-tool-order-invalid]
  ?.  (agent-live:guard our now %cantrip)  [%| %worker-owner-unavailable]
  =/  raw=*
    .^(* %gx /(scot %p our)/cantrip/(scot %da now)/native-coding/job/(scot %ux ticket.o)/noun)
  =/  row  ((soft ,(unit record:ct)) raw)
  ?~  row  [%| %worker-tool-job-incompatible]
  ?.  =(raw u.row)  [%| %worker-tool-job-incompatible]
  ?~  u.row  [%| %worker-tool-job-missing]
  =/  record=record:ct  u.u.row
  ?.  &(=(%running stage.record) =(~ result.record) =(grant.o grant.record) =(request.purpose.o request.record))
    [%| %worker-tool-job-changed]
  =/  raw=*
    .^(* %gx /(scot %p our)/cantrip/(scot %da now)/native-coding/grant/(scot %ux grant.o)/noun)
  =/  scope  ((soft ,(unit scope:ct)) raw)
  ?~  scope  [%| %worker-tool-grant-incompatible]
  ?.  =(raw u.scope)  [%| %worker-tool-grant-incompatible]
  ?~  u.scope  [%| %worker-tool-grant-missing]
  =/  permission  (allowed:ct our now u.u.scope request.record)
  ?:  ?=(%| -.permission)  [%| p.permission]
  ?.  (pending:ct our now request.record)  [%| %worker-tool-no-longer-pending]
  =/  prepared  (prepare:archive our now project.grant.u.u.scope request.record)
  ?:  ?=(%| -.prepared)  [%| p.prepared]
  ?.  (tool-authorized:work o pairing.o record u.u.scope p.prepared)
    [%| %worker-tool-authority-changed]
  [%& p.prepared]
++  pending-export
  |=  [our=@p now=@da key=@ux]
  ^-  (each tool-order:x @tas)
  ?.  (agent-live:guard our now %cantrip)  [%| %worker-owner-unavailable]
  =/  raw=*
    .^(* %gx /(scot %p our)/cantrip/(scot %da now)/native-coding/worker/tool-export/(scot %ux key)/noun)
  =/  parsed  ((soft ,(unit tool-order:x)) raw)
  ?~  parsed  [%| %worker-tool-export-incompatible]
  ?.  =(raw u.parsed)  [%| %worker-tool-export-incompatible]
  ?~  u.parsed  [%| %worker-tool-export-not-authorized]
  =/  o=tool-order:x  u.u.parsed
  ?.  =(key (digest:work o))  [%| %worker-tool-export-not-authorized]
  =/  allowed  (current our now o)
  ?:  ?=(%| -.allowed)  [%| p.allowed]
  [%& o]
++  original-match
  ::  Pure source identity only. Callers must obtain i from current above;
  ::  this predicate alone does not grant access to an active/private desk.
  |=  [o=tool-order:x i=input:archive v=view:old]
  ^-  ?
  ?&  (tool-order-valid:work o)  (input-valid:archive i)
      =(request.purpose.o request.i)  =(input.purpose.o (input-digest:work i))
      =(source.o revision.i)  =(source.o revision.v)
      =(namespace.i (hashes:old files.v))
      =((namespace-digest:law namespace.i) namespace.o)
  ==
++  original
  |=  [our=@p now=@da o=tool-order:x]
  ^-  (each view:old @tas)
  =/  pending  (pending-export our now (digest:work o))
  ?.  =([%& o] pending)  [%| %worker-tool-export-not-authorized]
  =/  prepared  (current our now o)
  ?:  ?=(%| -.prepared)  [%| p.prepared]
  =/  source  (snapshot:old our now desk.source.o number.source.o)
  ?:  ?=(%| -.source)  source
  ?.  (original-match o p.prepared p.source)  [%| %worker-tool-source-changed]
  [%& p.source]
++  detached
  |=  [o=tool-order:x v=view:old desk=@tas owner=@p]
  ^-  ?
  ?&  =(owner owner.revision.v)  =(desk desk.revision.v)
      =(1 number.revision.v)  =(1 latest.v)  =(1 history.v)
      =(~ parents.v)  inactive.v
      =(root.source.o root.revision.v)
      =((namespace-digest:law (hashes:old files.v)) namespace.o)
  ==
++  export-valid
  |=  [our=@p now=@da o=tool-order:x revision=revision:nc]
  ^-  ?
  =/  source  (original our now o)
  ?:  ?=(%| -.source)  %.n
  =/  exported  (snapshot:old our now (export-desk o) 1)
  ?:  ?=(%| -.exported)  %.n
  =/  v=view:old  p.exported
  ?&  =(revision revision.v)  (detached o v (export-desk o) our)
      =(files.p.source files.v)  =((shared:old worker.pairing.o) permissions.v)
  ==
++  import-valid
  |=  [our=@p now=@da offer=tool-offer:r]
  ^-  (each revision:nc @tas)
  =/  o=tool-order:x  order.offer
  =/  imported  (snapshot:old our now (import-desk o) 1)
  ?:  ?=(%| -.imported)  [%| p.imported]
  =/  v=view:old  p.imported
  ?.  ?&  =(our worker.pairing.o)  (detached o v (import-desk o) our)
          =(private:old permissions.v)  =(commit.export.offer commit.revision.v)
          =(root.export.offer root.revision.v)
          (source-ready:work o revision.v (hashes:old files.v))
      ==  [%| %worker-tool-import-mismatch]
  [%& revision.v]
++  pending-import
  |=  [our=@p now=@da key=@ux]
  ^-  (each tool-offer:r @tas)
  ?.  (agent-live:guard our now %native-coding-worker)
    [%| %worker-source-unavailable]
  =/  raw=*
    .^(* %gx /(scot %p our)/native-coding-worker/(scot %da now)/tool-import/(scot %ux key)/noun)
  =/  parsed  ((soft ,(unit tool-offer:r)) raw)
  ?~  parsed  [%| %worker-tool-import-incompatible]
  ?.  =(raw u.parsed)  [%| %worker-tool-import-incompatible]
  ?~  u.parsed  [%| %worker-tool-import-not-authorized]
  =/  offered=tool-offer:r  u.u.parsed
  =/  o=tool-order:x  order.offered
  ?.  ?&  (tool-order-valid:work o)  =((digest:work o) key)
          =(our worker.pairing.o)  (lte issued.o now)  (lth now deadline.o)
          =(owner.pairing.o owner.export.offered)
          =((export-desk o) desk.export.offered)  =(1 number.export.offered)
          =(root.source.o root.export.offered)
          =([%admitted admission.o key deadline.o] admission.offered)
      ==  [%| %worker-tool-import-not-authorized]
  [%& offered]
++  revoke-export
  ::  Revocation removes only the selected moon's dedicated export read rule.
  |=  [our=@p now=@da o=tool-order:x]
  ^-  (list card:agent:gall)
  ?.  &((tool-order-valid:work o) =(our owner.pairing.o))  ~
  =/  held  (snapshot:old our now (export-desk o) 1)
  ?:  ?=(%| -.held)  ~
  ?.  &((detached o p.held (export-desk o) our) =((shared:old worker.pairing.o) permissions.p.held))  ~
  ~[[%pass /native-worker/tool-export-close/(scot %ux (digest:work o)) %arvo %c %perm (export-desk o) / [%r `[%white ~]]]]
--
