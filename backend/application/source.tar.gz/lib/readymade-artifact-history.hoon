::  Pure owner-native retained metadata. No observations, effects or permissions.
/-  c=readymade-collab, j=readymade-collab-jobs, r=readymade-artifact-round, pkg=readymade-package
/+  execution=readymade-artifact-executor-types, build=readymade-package-build,
    pkg-kit=readymade-package, flow=readymade-collab,
    mg=readymade-app-management
|%
+$  command  [owner=@p peer=@p offset=@ud snapshot=(unit @ux)]
+$  catalogue  [snapshot=@ux rows=(list json)]
++  decimal
  |=  number=@ud
  ^-  @t
  (crip (skip (trip (scot %ud number)) |=(char=@t =(char '.'))))
++  object
  |=  fields=(list [@t json])
  ^-  json
  (pairs:enjs:format fields)
++  put
  |=  [value=json key=@t item=json]
  ^-  json
  ?>  ?=(%o -.value)
  [%o (~(put by p.value) key item)]
++  decode
  |=  raw=@t
  ^-  command
  =/  value=json  (need (de:json:html raw))
  ?>  ?=(%o -.value)
  =/  obj=(map @t json)  p.value
  ?>  =((silt `(list @t)`~['schema' 'owner' 'peer' 'offset' 'snapshot']) ~(key by obj))
  ?>  =('readymade-artifact-history-command-v1' (text-field:mg obj 'schema' 64))
  =/  own=@t  (text-field:mg obj 'owner' 128)
  =/  other=@t  (text-field:mg obj 'peer' 128)
  =/  owner=@p  (need (slaw %p own))
  =/  peer=@p  (need (slaw %p other))
  ?>  &(=(own (scot %p owner)) =(other (scot %p peer)) !=(owner peer))
  ?>  &((lte (met 0 owner) 128) (lte (met 0 peer) 128))
  =/  number=@t  (text-field:mg obj 'offset' 8)
  =/  offset=@ud  (need (rush number dem))
  ?>  &(=(number (decimal offset)) (lte offset 1.280))
  =/  raw-snapshot=json  (need (~(get by obj) 'snapshot'))
  =/  snapshot=(unit @ux)
    ?:  =(~ raw-snapshot)  ~
    ?>  ?=(%s -.raw-snapshot)
    =/  digest=@ux  (need (slaw %ux p.raw-snapshot))
    ?>  &((digest-valid:pkg-kit digest) =(p.raw-snapshot (scot %ux digest)))
    `digest
  ?>  |(=(0 offset) ?=(^ snapshot))
  [owner peer offset snapshot]
++  parse
  |=  raw=@t
  ^-  (unit command)
  ?.  (lte (met 3 raw) 2.048)  ~
  (mole |.((decode raw)))
++  read-request
  |=  req=inbound-request:eyre
  ^-  (unit command)
  =/  raw  (header:mg header-list.request.req 'x-readymade-history-command')
  ?~  raw  ~
  (parse u.raw)
++  source-json
  |=  source=pin:pkg
  ^-  json
  (object ~[['ship' s+(scot %p ship.source)] ['desk' s+(scot %tas desk.source)] ['revision' s+(decimal revision.source)] ['root' s+(scot %ux `@ux`root.source)]])
++  target-json
  |=  target=target:r
  ^-  json
  ?>  ?=(%land -.target)
  (object ~[['kind' s+'land'] ['ship' s+(scot %p ship.target)] ['desk' s+(scot %tas desk.target)] ['revision' s+(decimal revision.target)] ['root' s+(scot %ux root.target)] ['file' s+(spat file.target)]])
++  base-row
  |=  [kind=@t our=@p peer=@p request=@t nonce=@ux package=@ux phase=@tas hash=@ux]
  ^-  json
  (object ~[['kind' s+kind] ['owner' s+(scot %p our)] ['peer' s+(scot %p peer)] ['request' s+request] ['nonce' s+(scot %ux nonce)] ['tid' ~] ['status' s+(scot %tas phase)] ['journalPhase' s+(scot %tas phase)] ['candidate' ~] ['package' s+(scot %ux package)] ['artifact' ~] ['buildProof' ~] ['receiver' s+(scot %p our)] ['target' ~] ['source' ~] ['reason' s+'native-result-not-retained'] ['recordedAt' ~] ['command' ~] ['resultHash' s+(scot %ux hash)] ['failureFile' ~] ['callbackStatus' ~] ['retainedOnly' b+%.y] ['currentWorkspaceVerified' b+%.n] ['executionAuthorized' b+%.n]])
++  execution-row
  |=  [our=@p held=entry:execution]
  ^-  json
  =/  cmd=command:execution  command.held
  =/  proposal=proposal:r  proposal.selection.held
  =/  receipt=receipt:build  receipt.selection.held
  =/  result=json
    (base-row 'execution' our peer.cmd request.cmd (key:execution cmd) package.proposal phase.held (shax (jam [cmd at.held phase.held candidate.held reason.held proof.receipt])))
  =.  result  (put result 'candidate' ?~(candidate.held ~ s+(scot %ux u.candidate.held)))
  =.  result  (put result 'artifact' s+(scot %ux artifact.proposal))
  =.  result  (put result 'buildProof' s+(scot %ux build-proof.proposal))
  =.  result  (put result 'target' (target-json target.proposal))
  =.  result  (put result 'source' (source-json source.body.offer.plan.body.receipt))
  =.  result  (put result 'reason' s+(scot %tas reason.held))
  =.  result  (put result 'recordedAt' s+(scot %da at.held))
  (put result 'command' (object ~[['schema' s+'readymade-artifact-execute-v1'] ['owner' s+(scot %p owner.cmd)] ['peer' s+(scot %p peer.cmd)] ['request' s+request.cmd] ['pact' s+(scot %ux pact.cmd)] ['selected' s+(scot %ux selected.cmd)] ['guard' s+(scot %ux guard.cmd)] ['session' s+(scot %ux session.cmd)]]))
++  build-row
  ::  Identity comes from this exact retained job, never a current package scan.
  |=  [our=@p peer=@p tid=@ta work=job:j]
  ^-  (each json @tas)
  =/  cmd=command:c  command.work
  ?.  ?&  =(%build kind.work)  =('build' op.cmd)
          =(owner.cmd (scot %p our))  =(peer.cmd (scot %p peer))
          (identifier:flow request.cmd)  (digest-valid:pkg-kit nonce.work)
          =(tid `@ta`(cat 3 'collab-' (scot %ux nonce.work)))
          ?=(^ offer.work)
      ==
    [%| %history-build-binding]
  =/  package=@ux  (need offer.work)
  ?.  &((digest-valid:pkg-kit package) =(id.cmd (scot %ux package)) =(digest.cmd id.cmd))
    [%| %history-build-binding]
  ?^  result.work
    ?.  (lte (met 3 (jam u.result.work)) 131.072)  [%| %history-build-result-bytes]
    =/  callback
      ((soft ,[%readymade-package-build-v1 offer=@ux nonce=@ux answer=result:build]) u.result.work)
    ?~  callback  [%| %history-build-result-invalid]
    ?.  &(=(package offer.u.callback) =(nonce.work nonce.u.callback))
      [%| %history-build-result-binding]
    =/  answer=result:build  answer.u.callback
    =/  row=json
      (put (base-row 'build' our peer request.cmd nonce.work package phase.work (shax (jam u.result.work))) 'tid' s+`@t`tid)
    =.  row  (put row 'callbackStatus' s+(scot %tas -.answer))
    ?:  ?=(%confirmed -.answer)
      =/  receipt=receipt:build  receipt.answer
      ?.  ?&  =(%confirmed phase.work)  (valid:build our receipt)
              =(package digest.offer.plan.body.receipt)
              =(nonce.work nonce.plan.body.receipt)
              =(peer sender.body.offer.plan.body.receipt)
          ==
        [%| %history-build-receipt-binding]
      =.  row  (put row 'status' s+'compiled')
      =.  row  (put row 'artifact' s+(scot %ux artifact.body.receipt))
      =.  row  (put row 'buildProof' s+(scot %ux proof.receipt))
      =.  row  (put row 'source' (source-json source.body.offer.plan.body.receipt))
      [%& (put row 'reason' s+'native-ford-compile-retained')]
    =/  reason=@tas
      ?-  -.answer
        %refused    reason.answer
        %failed     reason.answer
        %uncertain  reason.answer
      ==
    ?.  &(=(phase.work ?:(?=(%failed -.answer) %confirmed -.answer)) (lte (met 3 reason) 128))
      [%| %history-build-phase-binding]
    ?.  ?=(%refused -.answer)
      ?.  (path-valid:pkg-kit path.answer)  [%| %history-build-path]
      =.  row  (put row 'failureFile' s+(spat path.answer))
      [%& (put (put row 'status' s+(scot %tas -.answer)) 'reason' s+(scot %tas reason))]
    [%& (put row 'reason' s+(scot %tas reason))]
  ?:  =(%confirmed phase.work)  [%| %history-build-result-missing]
  [%& (put (base-row 'build' our peer request.cmd nonce.work package phase.work (shax (jam [tid request.cmd nonce.work package phase.work]))) 'tid' s+`@t`tid)]
++  project
  |=  [our=@p peer=@p ledger=ledger:j executions=journal:execution]
  ^-  (each catalogue @tas)
  ?.  &(!=(our peer) (lte ~(wyt by ledger) 1.024) (valid:execution our executions))
    [%| %history-journal-invalid]
  =/  selected=(list [tid=@ta work=job:j])
    (skim ~(tap by ledger) |=([tid=@ta work=job:j] &(=(%build kind.work) =(owner.command.work (scot %p our)) =(peer.command.work (scot %p peer)))))
  ?.  =((lent selected) ~(wyt in (silt (turn selected |=([tid=@ta work=job:j] request.command.work)))))
    [%| %history-build-request-conflict]
  =/  rows=(list json)  ~
  =/  todo=(list [tid=@ta work=job:j])  selected
  |-
  ?~  todo
    =/  kept=(list entry:execution)
      (skim ~(val by executions) |=(held=entry:execution =(peer peer.command.held)))
    =/  rows=(list json)
      (weld (turn kept |=(held=entry:execution (execution-row our held))) (flop rows))
    [%& [(shax (jam [%readymade-artifact-history-snapshot-v1 our peer rows])) rows]]
  =/  next  (build-row our peer tid.i.todo work.i.todo)
  ?:  ?=(%| -.next)  [%| p.next]
  $(todo t.todo, rows [p.next rows])
++  page-json
  |=  [cmd=command all=catalogue shown=(list json)]
  ^-  json
  =/  end=@ud  (add offset.cmd (lent shown))
  =/  next=json
    ?:  =(end (lent rows.all))  ~
    (object ~[['offset' s+(decimal end)] ['snapshot' s+(scot %ux snapshot.all)]])
  (object ~[['schema' s+'readymade-artifact-history-v1'] ['owner' s+(scot %p owner.cmd)] ['peer' s+(scot %p peer.cmd)] ['snapshot' s+(scot %ux snapshot.all)] ['offset' s+(decimal offset.cmd)] ['pageSize' n+'16'] ['total' s+(decimal (lent rows.all))] ['next' next] ['rows' a+shown] ['retainedOnly' b+%.y] ['currentWorkspaceVerified' b+%.n] ['executionAuthorized' b+%.n] ['notice' s+'Retained owner records, not current workspace contents, permission, delivery or functional-test evidence. No request was observed or resent.']])
++  read
  |=  [our=@p src=@p cmd=command ledger=ledger:j executions=journal:execution]
  ^-  (each json @tas)
  ?.  &(=(our src) =(our owner.cmd))  [%| %history-owner]
  ?.  &(!=(our peer.cmd) (lte offset.cmd 1.280) |(=(0 offset.cmd) ?=(^ snapshot.cmd)))
    [%| %history-command]
  =/  projected  (project our peer.cmd ledger executions)
  ?:  ?=(%| -.projected)  [%| p.projected]
  =/  all=catalogue  p.projected
  ?^  snapshot.cmd
    ?.  =(u.snapshot.cmd snapshot.all)  [%| %history-snapshot-changed]
    (page cmd all)
  (page cmd all)
++  page
  |=  [cmd=command all=catalogue]
  ^-  (each json @tas)
  ?.  (lte offset.cmd (lent rows.all))  [%| %history-offset]
  =/  shown=(list json)  (scag 16 (slag offset.cmd rows.all))
  |-
  =/  body=json  (page-json cmd all shown)
  ?:  (lte (met 3 (en:json:html body)) 65.536)  [%& body]
  ?:  (lte (lent shown) 1)  [%| %history-response-bytes]
  $(shown (scag (dec (lent shown)) shown))
--
