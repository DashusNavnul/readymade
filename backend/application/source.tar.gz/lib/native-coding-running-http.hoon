::  Explicit owner read: current Gall applications and their actual Eyre routes.
::  A deployment receipt alone is never a present-running observation.
/+  deploy=native-coding-deployment,
    selected=native-coding-compiler-mapping-http, guard=viki-scry-guard
|%
++  unavailable
  |=  [session=@ux deployment=@ux reason=@tas]
  ^-  json
  (pairs:enjs:format ~[['available' b+%.n] ['session' s+(scot %ux session)] ['deployment' s+(scot %ux deployment)] ['reason' s+reason] ['apps' a+~]])
++  view
  |=  [our=@p now=@da session=@ux deployment=@ux]
  ^-  json
  =/  selected  (selected:selected our now session)
  ?.  ?=(%& -.selected)  (unavailable session deployment %session-unavailable)
  ?.  (agent-live:guard our now %cantrip)
    (unavailable session deployment %cantrip-unavailable)
  =/  held=(unit record:deploy)
    .^((unit record:deploy) %gx /(scot %p our)/cantrip/(scot %da now)/native-coding/deployment/(scot %ux deployment)/noun)
  ?~  held  (unavailable session deployment %deployment-missing)
  =/  r=record:deploy  u.held
  ?.  &(=(project.p.selected project.grant.r) =(session session.context.candidate.accepted.r))
    (unavailable session deployment %different-session)
  ?.  &(=(%applied phase.r) ?=(^ runtime.r) (lte ~(wyt in apps.grant.r) 8))
    (unavailable session deployment %deployment-not-applied)
  =/  expected  (need runtime.r)
  =/  exact=?  =(runtime.r (runtime:deploy our now r))
  =/  bindings=(list [binding=binding:eyre =duct action=action:eyre])
    .^((list [binding=binding:eyre =duct action=action:eyre]) %e /(scot %p our)/bindings/(scot %da now)/$)
  =/  rows=(list json)
    %+  turn  (sort ~(tap in apps.grant.r) aor)
    |=  name=@tas
    =/  live=?  (agent-live:guard our now name)
    =/  desk=@tas
      ?.  live  %none
      .^(desk %gd /(scot %p our)/[name]/(scot %da now)/$)
    =/  matches=?  &(exact live =(desk desk.revision.expected))
    =/  routes=(list @t)
      ?.  matches  ~
      %+  murn  bindings
      |=  row=[binding=binding:eyre =duct action=action:eyre]
      ?.  ?=(%app -.action.row)  ~
      ?.  &(=(name app.action.row) =(~ site.binding.row))  ~
      `(spat path.binding.row)
    (pairs:enjs:format ~[['name' s+name] ['running' b+live] ['matches' b+matches] ['desk' s+?:(live desk '')] ['routes' a+(turn (scag 16 routes) |=(route=@t s+route))] ['truncated' b+(gth (lent routes) 16)]])
  (pairs:enjs:format ~[['available' b+%.y] ['session' s+(scot %ux session)] ['deployment' s+(scot %ux deployment)] ['candidate' s+(scot %ux candidate.request.r)] ['observed' (sect:enjs:format now)] ['sourceMatches' b+exact] ['runtime' s+desk.revision.expected] ['apps' a+rows]])
++  route
  ::  The enclosing native console authenticates the owner before this read.
  |=  [our=@p now=@da url=@t]
  ^-  (unit json)
  =/  prefix=@t  '/apps/pataphor-native/coding/running?'
  ?.  &(=(prefix (cut 3 [0 (met 3 prefix)] url)) (lte (met 3 url) 220))  ~
  =/  text=tape  (trip (rsh [3 (met 3 prefix)] url))
  =/  split  (find "&" text)
  ?~  split  ~
  =/  left=@t  (crip (scag u.split text))
  =/  right=@t  (crip (slag +(u.split) text))
  =/  session  (slaw %ux left)
  =/  deployment  (slaw %ux right)
  ?~  session  ~
  ?~  deployment  ~
  ?.  ?&  !=(0 u.session)  !=(0 u.deployment)
          (lte (met 0 u.session) 256)  (lte (met 0 u.deployment) 256)
          =(left (scot %ux u.session))  =(right (scot %ux u.deployment))
      ==
    ~
  `(view our now u.session u.deployment)
--
