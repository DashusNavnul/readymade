::  Automated Viki judgment is distinct from explicit owner completion. Keep
::  exact frozen native review evidence; hashes alone do not establish origin.
::  Reload checks history only. Fresh inspection precedes fleet continuation
::  or Graf-confirmed release; provider errors never become semantic refusals.
/-  bx=boxy, protocol=native-coding-completion-review, np=native-coding-provider
/+  kernel=native-coding-completion, completion=native-coding-completion-runtime,
    request=native-coding-completion-review-request,
    campaign=native-coding-completion-review-orchestration,
    judgment=native-coding-completion-judgment,
    admission=cantrip-native-completion-review, session=native-coding-session,
    loop=native-coding-loop, provider=native-coding-provider, guard=viki-scry-guard
|%
+$  receipt
  [campaign=@ux packet=packet:request scope=scope:protocol workspace=workspace-state:bx admissions=ledger:admission outcome=outcome:judgment judgment=@ux]
+$  state  (map @ux receipt)
+$  command  [%native-coding-completion-review-finish-v1 campaign=@ux]
+$  change  [state=state coding=state:loop cards=(list card:agent:gall)]
++  key
  |=  r=receipt
  ^-  @ux
  (shax (jam [%native-coding-reviewed-completion-v1 campaign.r packet.r scope.r workspace.r admissions.r outcome.r]))
++  reason
  |=  r=receipt
  ^-  @t
  ?:  ?=(%complete -.outcome.r)
    'Viki confirmed completion through the delegated native review match.'
  (cat 3 'Viki delegated review requires further work: ' reason.outcome.r)
++  proof-of
  |=  o=outcome:judgment
  ^-  proof:judgment
  ?-  -.o
    %complete  proof.o
    %negative  proof.o
  ==
++  transition
  |=  [r=receipt at=@da]
  ^-  (each transition:session @tas)
  =/  e=entry:session  entry.packet.r
  ?~  records.e  [%| %reviewed-completion-history-missing]
  =/  last=record:session  (rear records.e)
  ?:  (lth at at.last)  [%| %reviewed-completion-time-regressed]
  =/  text=@t  (reason r)
  =/  verdict=?(%complete %continue)
    ?:(?=(%complete -.outcome.r) %complete %continue)
  =/  next  (judge:session at e verdict ~[(key r)] text)
  ?:  ?=(%| -.next)  [%| p.next]
  ?:  =(%complete verdict)  next
  =/  history=(list message:np)
    (weld history.e `(list message:np)`~[[%user ~[[%text text]]]])
  ?.  (history-valid:provider history)  [%| %reviewed-completion-feedback-capacity]
  [%& p.next(entry entry.p.next(history history))]
++  evidence-valid
  |=  [our=@p r=receipt]
  ^-  ?
  ?.  &((lte (met 3 (jam r)) 4.194.304) (identifier:kernel campaign.r) =(campaign.r (digest:request [proposal.packet.r scope.r])))  %.n
  =/  checked  (evaluate:judgment our packet.r scope.r workspace.r admissions.r)
  =/  proof=proof:judgment  (proof-of outcome.r)
  ?&  ?=(%& -.checked)  =(p.checked outcome.r)
      =(campaign.r campaign.proof)
      =(~(wyt by admissions.r) (lent admissions.proof))
      (levy ~(val by admissions.r) |=(row=retained:admission (lien admissions.proof |=(id=@ux =(id (identity:admission context.row))))))
  ==
++  row-valid
  ::  Later instructions and scope revocation preserve a historical receipt.
  ::  Recreate its exact journal append, without reading current authority.
  |=  [our=@p s=state:loop id=@ux r=receipt]
  ^-  ?
  ?.  &((evidence-valid our r) =(id (key r)) (identifier:kernel judgment.r))  %.n
  =/  p=proposal:kernel  proposal.packet.r
  =/  found  (~(get by sessions.s) session.p)
  ?~  found  %.n
  =/  e=entry:session  u.found
  ?.  &(=(our owner.session.e) =(project.p project.session.e) (journal-valid:kernel e) (lth sequence.p (lent records.e)))  %.n
  =/  record=record:session  (snag sequence.p records.e)
  =/  next  (transition r at.record)
  ?.  ?=(%& -.next)  %.n
  &(=(head.entry.p.next `judgment.r) =(records.entry.p.next (scag +(sequence.p) records.e)))
++  valid
  |=  [our=@p s=state coding=state:loop]
  ^-  ?
  ?&  (lte ~(wyt by s) 128)  (lte (met 3 (jam s)) 16.777.216)
      (levy ~(tap by s) |=([id=@ux r=receipt] (row-valid our coding id r)))
      =((lent ~(val by s)) ~(wyt in (silt (turn ~(val by s) |=(r=receipt campaign.r)))))
  ==
++  selected
  |=  [s=state e=entry:session]
  ^-  (unit @ux)
  =/  rows=(list record:session)
    (flop (skim records.e |=(r=record:session ?=(%judgment -.body.r))))
  ?~  rows  ~
  =/  r=record:session  i.rows
  ?>  ?=(%judgment -.body.r)
  ?~  evidence.body.r  ~
  =/  id=@ux  i.evidence.body.r
  ?:((~(has by s) id) `id ~)
++  canonical
  ::  Scry the real campaign, scope, queue and admissions before reconstructing
  ::  the exact current native tool/source packet. Unrelated rows are omitted.
  |=  [b=bowl:gall coding=state:loop scopes=(map @t scope:protocol) id=@ux]
  ^-  (each receipt @tas)
  ?.  &(=(our.b src.b) (agent-live:guard our.b now.b %viki) (agent-live:guard our.b now.b %cantrip) (agent-live:guard our.b now.b %boxy))
    [%| %reviewed-completion-agents-unavailable]
  =/  rows=(map @ux campaign:campaign)
    .^((map @ux campaign:campaign) %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/completion-review-campaigns/noun)
  =/  found  (~(get by rows) id)
  ?~  found  [%| %reviewed-completion-campaign-missing]
  =/  c=campaign:campaign  u.found
  ?.  &(done.c enabled.scope.c =(id (digest:request [proposal.packet.c scope.c])) =(`scope.c (~(get by scopes) project.scope.c)))
    [%| %reviewed-completion-campaign-or-scope-changed]
  =/  actual=(map @t scope:protocol)
    .^((map @t scope:protocol) %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/review-scopes/noun)
  ?.  =(`scope.c (~(get by actual) project.scope.c))
    [%| %reviewed-completion-scope-not-retained]
  =/  current  (read:completion b coding session.proposal.packet.c)
  ?:  ?=(%| -.current)  [%| p.current]
  =/  captured  (capture:request our.b p.current)
  ?:  ?=(%| -.captured)  [%| p.captured]
  ?.  =(p.captured packet.c)  [%| %reviewed-completion-packet-changed]
  =/  box=state:bx
    .^(state:bx %gx /(scot %p our.b)/boxy/(scot %da now.b)/state/noun)
  =/  workspace  (~(get by workspaces.box) workspace.c)
  ?~  workspace  [%| %reviewed-completion-workspace-missing]
  =/  held=ledger:admission
    .^(ledger:admission %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/completion-review-admissions/noun)
  =.  held  (my (skim ~(tap by held) |=([k=key:admission r=retained:admission] =(campaign.k id))))
  =/  checked  (evaluate:judgment our.b packet.c scope.c u.workspace held)
  ?:  ?=(%| -.checked)  [%| p.checked]
  =/  outcome=outcome:judgment  p.checked
  =/  proof=proof:judgment  (proof-of outcome)
  =.  held  (my (skim ~(tap by held) |=([k=key:admission r=retained:admission] (lien admissions.proof |=(v=@ux =(v (identity:admission context.r)))))))
  =/  r=receipt  [id packet.c scope.c u.workspace held outcome 0x0]
  ?:((evidence-valid our.b r) [%& r] [%| %reviewed-completion-evidence-invalid-or-large])
++  notice
  |=  r=receipt
  ^-  card:agent:gall
  [%give %fact ~[/native-coding] %noun !>([%native-coding-reviewed-completion-retained-v1 (key r) campaign.r session.proposal.packet.r judgment.r -.outcome.r])]
++  inspect
  ::  Only the most recent unchanged judgment is eligible for fleet action.
  ::  Restore its exact captured entry, including history before Viki feedback.
  |=  [b=bowl:gall s=state coding=state:loop id=@ux]
  ^-  (each [key=@ux receipt=receipt] @tas)
  ?.  &(=(our.b src.b) (agent-live:guard our.b now.b %viki))
    [%| %reviewed-completion-viki-unavailable]
  =/  found  (~(get by sessions.coding) id)
  ?~  found  [%| %reviewed-completion-session-missing]
  =/  e=entry:session  u.found
  =/  chosen  (selected s e)
  ?~  chosen  [%| %reviewed-completion-receipt-missing]
  =/  r=receipt  (~(got by s) u.chosen)
  ?.  (row-valid our.b coding u.chosen r)  [%| %reviewed-completion-receipt-invalid]
  =/  actual=(unit public-session:loop)
    .^((unit public-session:loop) %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/session/(scot %ux id)/noun)
  ?.  =(actual `(public:loop e))  [%| %reviewed-completion-session-not-retained]
  =/  retained=(unit receipt)
    .^((unit receipt) %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/reviewed-completion/(scot %ux u.chosen)/noun)
  ?.  =(`r retained)  [%| %reviewed-completion-receipt-not-retained]
  =/  last=record:session  (rear records.e)
  =/  next  (transition r at.last)
  ?.  &(?=(%& -.next) =(e entry.p.next))  [%| %reviewed-completion-not-current]
  =/  previous=entry:session  entry.packet.r
  =/  scopes=(map @t scope:protocol)
    (~(put by *(map @t scope:protocol)) project.scope.r scope.r)
  =/  fresh
    (canonical b coding(sessions (~(put by sessions.coding) id previous)) scopes campaign.r)
  ?:  ?=(%| -.fresh)  [%| p.fresh]
  ?.  =(r(judgment 0) p.fresh)  [%| %reviewed-completion-evidence-changed]
  [%& [u.chosen r]]
++  finish
  |=  [b=bowl:gall s=state coding=state:loop scopes=(map @t scope:protocol) campaign=@ux]
  ^-  change
  ?.  =(our.b src.b)  [s coding ~]
  =/  previous=(list receipt)
    (skim ~(val by s) |=(r=receipt =(campaign campaign.r)))
  ?^  previous  [s coding ~[(notice i.previous)]]
  =/  checked  (canonical b coding scopes campaign)
  ?:  ?=(%| -.checked)  [s coding ~[(refused:loop campaign p.checked)]]
  =/  r=receipt  p.checked
  =/  id=@ux  session.proposal.packet.r
  =/  e=entry:session  entry.packet.r
  =/  actual=(unit public-session:loop)
    .^((unit public-session:loop) %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/session/(scot %ux id)/noun)
  ?.  =(actual `(public:loop e))
    [s coding ~[(refused:loop id %reviewed-completion-session-not-retained)]]
  =/  next  (transition r now.b)
  ?:  ?=(%| -.next)  [s coding ~[(refused:loop id p.next)]]
  =.  r  r(judgment (need head.entry.p.next))
  =/  stored=state  (~(put by s) (key r) r)
  ?:  |((gth (met 3 (jam r)) 4.194.304) (gth ~(wyt by stored) 128) (gth (met 3 (jam stored)) 16.777.216))
    [s coding ~[(refused:loop id %reviewed-completion-capacity)]]
  =/  moved  (apply:loop b coding p.next)
  =/  follow=card:agent:gall
    ?:  &(=(our.b worker.e) ?=(%negative -.outcome.r))  (run-card:loop our.b id)
    (poke:loop our.b %viki /native-fleet-progress [%native-coding-fleet-progress-v1 id])
  =/  cards=(list card:agent:gall)
    ~[(notice r) (poke:loop our.b %graf /native-coding/reviewed-completion-retain [%attest [%native-coding-reviewed-completion-retained-v1 (key r) r]]) follow]
  [stored +.moved (weld -.moved cards)]
++  peek
  |=  [s=state path=path]
  ^-  (unit (unit cage))
  ?:  =(/x/native-coding/reviewed-completions path)  ``noun+!>(s)
  ?:  ?=([%x %native-coding %reviewed-completion-campaign @ ~] path)
    =/  id  (slaw %ux i.t.t.t.path)
    ?~  id  [~ ~]
    ?.  =(i.t.t.t.path (scot %ux u.id))  [~ ~]
    =/  found=(list @ux)
      (murn ~(tap by s) |=([k=@ux r=receipt] ?:(=(u.id campaign.r) `k ~)))
    =/  result=(unit @ux)  ?~(found ~ `i.found)
    ``noun+!>(result)
  ?.  ?=([%x %native-coding %reviewed-completion @ ~] path)  ~
  =/  id  (slaw %ux i.t.t.t.path)
  ?~  id  [~ ~]
  ?.  =(i.t.t.t.path (scot %ux u.id))  [~ ~]
  ``noun+!>((~(get by s) u.id))
--
