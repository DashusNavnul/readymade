::  /lib/flect.hoon
::
::  The flect language, printed form (spec v2: rulings 1-22, 2026-09-26).
::
::  A FLECT is one 4x4 square of sigil letters, filled row-major from
::  the top-left; unused cells hold the blank U+2800.  The letters are
::  the 512 Urbit syllables as characters: prefix byte b at U+1D800+b,
::  suffix byte b at U+1D900+b (the Sutton SignWriting block: assigned,
::  one cell wide, never used in code, and never deleted by a chat
::  sanitizer the way private-use characters are).
::
::  Letter class alone tells the three kinds of flect apart:
::    word  prefix letters only   any atom, its bytes low to high
::    tag   suffix letters only   the 128-bit sham of a noun
::    ship  mixed, in a name form  galaxy 1, star 2, planet 2x2,
::                                 moon two rows; comets are refused
::  A word can never spell a ship (every name holds a suffix letter);
::  a tag can never spell a ship (16 suffix letters fit no name form).
::
::  A SHAPE is a typed noun grown into flects by axis: the head of the
::  cell at n is 2n, the tail 2n+1, so a flect's axis is its Nock
::  address.  Only an atom typed @p grows into a ship.
::
|%
+$  letter  @c                              ::  one cell: a sigil or blank
+$  flect   (list letter)                   ::  exactly 16 cells, row-major
+$  kind    ?(%word %tag %ship)
+$  grown   [axis=@ud =kind flects=(list flect)]
+$  shape   (list grown)
::
++  blank   ^-(letter `@`0x2800)
++  pre     |=(b=@ ^-(letter (add 0x1.d800 (end 3 b))))
++  suf     |=(b=@ ^-(letter (add 0x1.d900 (end 3 b))))
++  is-pre  |=(l=letter &((gte l 0x1.d800) (lth l 0x1.d900)))
++  is-suf  |=(l=letter &((gte l 0x1.d900) (lth l 0x1.da00)))
::  +pad: fill the rest of a flect with blank cells
++  pad
  |=  cells=(list letter)
  ^-  flect
  ?>  (lte (lent cells) 16)
  (weld cells (reap (sub 16 (lent cells)) blank))
::  +word: an atom's bytes, low to high, as prefix letters; 0 is one letter
++  word
  |=  a=@
  ^-  (list flect)
  =/  bytes=(list @)  ?:(=(0 a) ~[0] (rip 3 a))
  |-  ^-  (list flect)
  ?~  bytes  ~
  :-  (pad (turn (scag 16 `(list @)`bytes) pre))    ::  cast back: ?~ refined it
  $(bytes (slag 16 `(list @)`bytes))
::  +ship: a real ship's letters in its name form; comets are refused
++  ship
  |=  p=@p
  ^-  flect
  =/  s=@  (fein:ob p)                      ::  the scrambled form a name spells
  =/  byte  |=(i=@ (cut 3 [i 1] s))
  ?:  (lth p 0x100)                         ::  galaxy: one suffix letter
    (pad ~[(suf (byte 0))])
  ?:  (lth p 0x1.0000)                      ::  star: prefix suffix
    (pad ~[(pre (byte 1)) (suf (byte 0))])
  ?:  (lth p 0x1.0000.0000)                 ::  planet: the 2x2
    (pad ~[(pre (byte 3)) (suf (byte 2)) blank blank (pre (byte 1)) (suf (byte 0))])
  ?>  (lth p 0x1.0000.0000.0000.0000)       ::  moon: its own part over its planet
  %-  pad
  :~  (pre (byte 7))  (suf (byte 6))  (pre (byte 5))  (suf (byte 4))
      (pre (byte 3))  (suf (byte 2))  (pre (byte 1))  (suf (byte 0))
  ==
::  +letters: an atom's flects -- its bytes as words up to +max-word-bytes,
::  beyond that its tag alone.  A big atom's shape is its name, not its
::  spelling (the zero-copy rule): a law's constants are always short, and
::  growing a megabyte of text letter by letter is how a loom fills.
++  max-word-bytes  `@ud`64
++  letters
  |=  a=@
  ^-  (list flect)
  ?:  (gth (met 3 a) max-word-bytes)  ~[(tag a)]
  (word a)
::  +tag: the 128-bit sham of a noun as 16 suffix letters, low byte first
++  tag
  |=  n=*
  ^-  flect
  =/  h  (sham n)
  %+  turn  (gulf 0 15)
  |=(i=@ (suf (cut 3 [i 1] h)))
::  +grow: a typed noun into flects by axis
++  grow
  |=  v=vase
  ^-  shape
  =/  axis=@ud  1
  |-  ^-  shape
  =/  t=type  (norm p.v)
  ?:  ?=([%cell *] t)
    ?>  ?=(^ q.v)
    %+  weld
      $(v [p.t -.q.v], axis (mul 2 axis))
    $(v [q.t +.q.v], axis (add 1 (mul 2 axis)))
  ?:  ?=([%atom *] t)
    ?>  ?=(@ q.v)
    ?:  =(%p p.t)
      [axis %ship ~[(ship q.v)]]~
    [axis %word (letters q.v)]~
  ::  untyped (%noun, forks): grow by the noun alone; nothing is a ship
  ?@  q.v  [axis %word (letters q.v)]~
  %+  weld
    $(v [%noun -.q.v], axis (mul 2 axis))
  $(v [%noun +.q.v], axis (add 1 (mul 2 axis)))
::  +norm: see through faces, hints and holds
++  norm
  |=  t=type
  ^-  type
  |-
  ?+  t  t
    [%face *]  $(t q.t)
    [%hint *]  $(t q.t)
    [%hold *]  $(t ~(repo ut t))
  ==
::  +print: a shape as four rows of text, flects left to right
++  print
  |=  s=shape
  ^-  wall
  =/  fs=(list flect)
    |-  ^-  (list flect)
    ?~  s  ~
    (weld flects.i.s $(s t.s))
  =/  sep=tape  "   "
  %+  turn  (gulf 0 3)
  |=  r=@
  ^-  tape
  |-  ^-  tape
  ?~  fs  ~
  %+  weld  sep
  %+  weld  (cells (scag 4 (slag (mul 4 r) i.fs)))
  $(fs t.fs)
::  +cells: letters as UTF-8 text
++  cells
  |=  l=(list letter)
  ^-  tape
  ?~  l  ~
  (weld (trip (tuft i.l)) $(l t.l))
--
