::  /lib/cantrip-compile-flect.hoon
::
::  The connected-compile judge as law geometry (phase 10 of cantrip x
::  flect).  The lane's act is [snapshot view stated]: the frozen compile
::  snapshot, the connected result view it was frozen from, and the stated
::  intent.  The type-law says only that the act has the right shape; this
::  law adds one %run gate per predicate of +admit:cantrip-connected-compile,
::  at the axis of the field it reads, in the judge's order, with the
::  environment [our actor at window].  The first miss names the judge's
::  own reason.  Nothing here scries: the gates run in mock, so any ship
::  recomputes them from the nouns.
::
/-  itn=intent
/+  flect, flect-law, core=cantrip-connected-compile,
    result=vibecoding-connected-result, protocol=vibecoding-compile-protocol,
    clw=cantrip-law-window
|%
+$  act  [s=snapshot:core view=view:result stated=(unit record:itn)]
+$  env  [our=@p actor=@p at=@da w=window:clw]
::  the act's type, fixed here so every receipt cites the one law
++  act-type  ^-  type  -:!>(*act)
::
::  Axes: the snapshot = 2 and its order = 23; [view stated] = 3; the
::  whole act = 1.  A gate is called with [act-noun env], answers a loobean.
++  actor-gate
  ^-  *
  |=  [a=* e=*]
  =/  n  ;;(env e)
  =(our.n actor.n)
++  snapshot-gate
  ^-  *
  |=  [a=* e=*]
  =/  x  ;;(act a)
  =/  n  ;;(env e)
  &((valid:core s.x) =(our.n owner.order.s.x))
++  expiry-gate
  ^-  *
  |=  [a=* e=*]
  =/  x  ;;(act a)
  =/  n  ;;(env e)
  &((lte at.order.s.x at.n) (lth at.n expires.order.s.x))
++  freeze-gate
  ^-  *
  |=  [a=* e=*]
  =/  x  ;;(act a)
  =/  n  ;;(env e)
  =/  f  (freeze:core our.n actor.n at.n binding.commitment.s.x view.x stated.x w.n)
  ?=(%& -.f)
++  frozen-gate
  ^-  *
  |=  [a=* e=*]
  =/  x  ;;(act a)
  =/  n  ;;(env e)
  =/  f  (freeze:core our.n actor.n at.n binding.commitment.s.x view.x stated.x w.n)
  ?.  ?=(%& -.f)  %.n
  =/  expected=order:protocol  order.p.f(at at.order.s.x, expires expires.order.s.x)
  =(s.x p.f(order expected))
++  gates
  ^-  law:flect-law
  :~  [23 %run actor-gate]
      [2 %run snapshot-gate]
      [23 %run expiry-gate]
      [3 %run freeze-gate]
      [1 %run frozen-gate]
  ==
++  compile-law
  ^-  law:flect-law
  (weld (law-of:flect-law act-type) gates)
++  compile-receipt
  |=  [a=act e=env]
  ^-  receipt:flect-law
  (judge-with:flect-law compile-law !>(`act`a) e)
::  +reason: the first miss, as the judge would have said it
++  reason
  |=  [r=receipt:flect-law a=act e=env]
  ^-  (unit @tas)
  ?~  misses.verdict.r  ~
  =/  d  demand.i.misses.verdict.r
  ?.  ?=(%run -.d)  `%act-ill-shaped
  ?:  =(gate.d actor-gate)  `%foreign-actor
  ?:  =(gate.d snapshot-gate)  `%snapshot-invalid
  ?:  =(gate.d expiry-gate)  `%expired-request
  ?:  =(gate.d freeze-gate)
    =/  f  (freeze:core our.e actor.e at.e binding.commitment.s.a view.a stated.a w.e)
    ?:(?=(%| -.f) `p.f `%frozen)
  ?:  =(gate.d frozen-gate)  `%frozen-context-changed
  `%unknown-gate
--
