::  Owner-only execution observations. One viewer-scoped native refresh timer.
/-  pc=pataphor-chat, a=a2a, ct=cantrip
/+  ex=readymade-execution, rt=pataphor-chat-runtime, store=pataphor-chat-store
|%
+$  request  [epoch=@ta entry=@ud]
+$  cache  (map path snapshot:ex)
+$  query  [care=?(%gu %gx) pax=path]
+$  reader  $-(query *)
+$  memo  (map query *)
+$  health
  $:  %a2a-status-v1  bound=?  publish=?  principals=@ud  tasks=@ud
      trusted=(list @t)  jobs=@ud  bridge-ready=?  ceiling=@tas
  ==
++  capacity  64
++  route
  |=  pax=path
  ^-  (unit request)
  ?.  ?=([%conversation %execution @ @ ~] pax)  ~
  ?.  (lte (met 3 i.t.t.t.pax) 32)  ~
  =/  parsed=(unit @ud)  (slaw %ud i.t.t.t.pax)
  ?~  parsed  ~
  ?.  =(i.t.t.t.pax (scot %ud u.parsed))  ~
  ?.  (target-valid:ex i.t.t.pax u.parsed)  ~
  `[i.t.t.pax u.parsed]
++  retained
  |=  [r=request chat=state-0:pc]
  ^-  ?
  &(=(epoch.r epoch.chat) (lien entries.chat |=(e=entry:pc =(entry.r id.e))))
++  paths
  |=  [our=@p subs=bitt:gall]
  ^-  (list path)
  =/  wanted=(list path)
    %+  murn  ~(val by subs)
    |=  [who=@p pax=path]
    ^-  (unit path)
    ?.  =(our who)  ~
    ?~  (route pax)  ~
    `pax
  ~(tap in (silt wanted))
++  admit
  |=  [pax=path wanted=(list path)]
  ^-  ?
  ?~  (route pax)  %.n
  ::  Gall's on-watch bowl already includes the arriving subscription.
  (lte (lent ~(tap in (silt [pax wanted]))) capacity)
++  prune
  |=  [known=cache wanted=(list path)]
  ^-  cache
  =|  kept=cache
  |-  ^-  cache
  ?~  wanted  kept
  =/  old=(unit snapshot:ex)  (~(get by known) i.wanted)
  $(wanted t.wanted, kept ?~(old kept (~(put by kept) i.wanted u.old)))
++  different
  |=  [old=snapshot:ex next=snapshot:ex]
  ^-  ?
  !=(old(revision 0) next(revision 0))
++  timer-wire
  |=  due=@da
  ^-  wire
  /readymade-execution/[(scot %da due)]
++  arm
  |=  [now=@da poll=(unit @da) wanted=?]
  ^-  [(list card:rt) (unit @da)]
  ?.  wanted  [~ ~]
  ?^  poll  [~ poll]
  =/  due=@da  (add now ~s5)
  [~[[%pass (timer-wire due) %arvo %b %wait due]] `due]
++  wake
  |=  [=wire poll=(unit @da)]
  ^-  ?
  ?~  poll  %.n
  =(wire (timer-wire u.poll))
++  project
  |=  [b=bowl:gall r=request chat=state-0:pc]
  ^-  snapshot:ex
  -:(project-with b r chat native ~)
++  native
  ^-  reader
  |=  q=query
  ?:  =(%gu care.q)  .^(? %gu pax.q)
  .^(* %gx pax.q)
++  read
  |=  [source=reader seen=memo q=query]
  ^-  [* memo]
  =/  found=(unit *)  (~(get by seen) q)
  ?^  found  [u.found seen]
  =/  value=*  (source q)
  [value (~(put by seen) q value)]
++  project-with
  |=  [b=bowl:gall r=request chat=state-0:pc source=reader seen=memo]
  ^-  [snapshot:ex memo]
  =/  empty=snapshot:ex  (from-task:ex epoch.r entry.r act.b ~)
  ?.  (retained r chat)
    [empty(problem `'This exchange is not retained in the current private conversation.') seen]
  =^  running=*  seen
    (read source seen [%gu /(scot %p our.b)/a2a/(scot %da now.b)/$])
  ?.  =(%.y running)
    [empty(observation %unavailable, problem `'The native A2A publisher is not running.') seen]
  ::  Read as a noun before checking the mold; schema drift must not block Gall.
  =^  raw-task=*  seen
    (read source seen [%gx /(scot %p our.b)/a2a/(scot %da now.b)/local/task/[epoch.r]/[(mid:rt entry.r)]/noun])
  =/  task=(unit (unit task:a))
    ((soft (unit task:a)) raw-task)
  =/  current=snapshot:ex
    ?~  task
      empty(observation %unavailable, problem `'The native A2A task has an incompatible shape.')
    (from-task:ex epoch.r entry.r act.b u.task)
  =^  raw-status=*  seen
    (read source seen [%gx /(scot %p our.b)/a2a/(scot %da now.b)/status/noun])
  =/  status=(unit health)  ((soft health) raw-status)
  ?^  status
    ?:  &((gth (met 3 ceiling.u.status) 0) (lte (met 3 ceiling.u.status) 40))
      =.  diagnostic.current  `[bridge-ready.u.status ceiling.u.status]
      (move-with b current source seen)
    (move-with b current source seen)
  (move-with b current source seen)
++  move
  |=  [b=bowl:gall current=snapshot:ex]
  ^-  snapshot:ex
  -:(move-with b current native ~)
++  move-with
  |=  [b=bowl:gall current=snapshot:ex source=reader seen=memo]
  ^-  [snapshot:ex memo]
  =/  task=(unit task-view:ex)  task.current
  ?~  task  [current seen]
  =^  running=*  seen
    (read source seen [%gu /(scot %p our.b)/cantrip/(scot %da now.b)/$])
  ?.  =(%.y running)
    [current(observation %unavailable, judgment ~, problem `'The native Cantrip publisher is not running.') seen]
  =^  raw-move=*  seen
    (read source seen [%gx /(scot %p our.b)/cantrip/(scot %da now.b)/multiplayer/move/[`@ta`move.u.task]/noun])
  =/  value=(unit (unit mp-inbox-entry:ct))
    ((soft (unit mp-inbox-entry:ct)) raw-move)
  ?~  value
    [current(observation %unavailable, judgment ~, problem `'The native Cantrip move has an incompatible shape.') seen]
  [(from-move:ex our.b current u.value) seen]
++  refresh
  |=  [b=bowl:gall chat=state-0:pc wanted=(list path) known=cache]
  ^-  [(list card:rt) cache]
  =/  out  (refresh-with b chat wanted known native)
  [cards.out next.out]
++  refresh-with
  |=  [b=bowl:gall chat=state-0:pc wanted=(list path) known=cache source=reader]
  ^-  [cards=(list card:rt) next=cache reads=memo]
  ?>  (lte (lent wanted) capacity)
  ::  This memo is discarded after one refresh. Settled rows still read anew.
  =|  seen=memo
  =|  cards=(list card:rt)
  =/  next=cache  (prune known wanted)
  |-  ^-  [cards=(list card:rt) next=cache reads=memo]
  ?~  wanted  [(flop cards) next seen]
  =/  pax=path  i.wanted
  =/  r=(unit request)  (route pax)
  ?>  ?=(^ r)
  =^  value=snapshot:ex  seen  (project-with b u.r chat source seen)
  =/  old=(unit snapshot:ex)  (~(get by next) pax)
  ?:  ?~(old %.n !(different u.old value))
    $(wanted t.wanted)
  $(wanted t.wanted, next (~(put by next) pax value), cards [[%give %fact ~[pax] %noun !>(value)] cards])
++  reconcile
  ::  Reuse this refresh's bounded native reads. No timer, resubmission or
  ::  hidden history scan; a held task stays revisitable while it is viewed.
  |=  [b=bowl:gall chat=state-0:pc wanted=(list path) known=cache seen=memo]
  ^-  state-0:pc
  ?>  (lte (lent wanted) capacity)
  |-  ^-  state-0:pc
  ?~  wanted  chat
  =/  r=(unit request)  (route i.wanted)
  ?~  r  $(wanted t.wanted)
  ?.  (retained u.r chat)  $(wanted t.wanted)
  =/  observed=(unit snapshot:ex)  (~(get by known) i.wanted)
  ?~  observed  $(wanted t.wanted)
  ?.  =(%known observation.u.observed)  $(wanted t.wanted)
  =/  raw=(unit *)
    (~(get by seen) [%gx /(scot %p our.b)/a2a/(scot %da now.b)/local/task/[epoch.u.r]/[(mid:rt entry.u.r)]/noun])
  ?~  raw  $(wanted t.wanted)
  =/  parsed=(unit (unit task:a))  ((soft (unit task:a)) u.raw)
  ?~  parsed  $(wanted t.wanted)
  ?~  u.parsed  $(wanted t.wanted)
  =/  value=task:a  u.u.parsed
  =/  checked=snapshot:ex  (from-task:ex epoch.u.r entry.u.r act.b `value)
  ?.  &((valid:ex u.observed) =(%known observation.checked) =(task.checked task.u.observed))
    $(wanted t.wanted)
  $(wanted t.wanted, chat (observe:store entry.u.r state.value artifact.value chat))
++  coalesce
  ::  One event has one Gall revision. Replace superseded explicit routes,
  ::  retaining unrelated routes, implicit watch replies and every effect.
  |=  [earlier=(list card:rt) final=(list card:rt)]
  ^-  (list card:rt)
  =/  replaced=(set path)
    =/  remaining=(list card:rt)  final
    =|  found=(set path)
    |-  ^-  (set path)
    ?~  remaining  found
    =/  c=card:rt  i.remaining
    ?.  ?=([%give %fact *] c)  $(remaining t.remaining)
    $(remaining t.remaining, found (~(gas in found) paths.p.c))
  =/  kept=(list card:rt)
    %+  murn  earlier
    |=  c=card:rt
    ^-  (unit card:rt)
    ?.  ?=([%give %fact *] c)  `c
    ?~  paths.p.c  `c
    =/  remaining=(list path)
      (skip `(list path)`paths.p.c |=(pax=path (~(has in replaced) pax)))
    ?~  remaining  ~
    `[%give %fact remaining cage.p.c]
  (weld kept final)
++  update
  |=  [b=bowl:gall chat=state-0:pc known=cache poll=(unit @da)]
  ^-  [(list card:rt) cache (unit @da) state-0:pc]
  =/  wanted=(list path)  (paths our.b sup.b)
  =/  out  (refresh-with b chat wanted known native)
  =/  settled=state-0:pc  (reconcile b chat wanted next.out reads.out)
  =/  timer  (arm now.b poll ?=(^ wanted))
  [(weld cards.out -.timer) next.out +.timer settled]
++  prove
  =/  pax=path  /conversation/execution/proof/2
  ?>  =(`[%proof 2] (route pax))
  ?>  =(`[%proof 18.446.744.073.709.551.615] (route /conversation/execution/proof/18.446.744.073.709.551.615))
  ?>  =(~ (route /conversation/execution/proof/0))
  ?>  =(~ (route ~[%conversation %execution %proof `@ta`'02']))
  ?>  =(~ (route /conversation/execution/proof/2/extra))
  ?>  =(~ (route /conversation/execution/proof/18.446.744.073.709.551.616))
  =/  all=(list path)
    (turn (gulf 1 capacity) |=(id=@ud /conversation/execution/proof/[(scot %ud id)]))
  ?>  (admit pax all)
  ?>  !(admit /conversation/execution/proof/65 all)
  ?>  !(admit /conversation/execution/proof/65 [/conversation/execution/proof/65 all])
  ?>  (admit /conversation/execution/proof/65 (slag 1 all))
  =/  subs=bitt:gall
    (~(gas by *bitt:gall) ~[[~[/a] [~zod pax]] [~[/b] [~zod pax]] [~[/c] [~nec /conversation/execution/proof/3]] [~[/d] [~zod /conversation/history/0/16]]])
  ?>  =(~[pax] (paths ~zod subs))
  =/  value=snapshot:ex  (from-task:ex %proof 2 7 ~)
  =/  known=cache  (~(put by *cache) pax value)
  ?>  =(known (prune known ~[pax]))
  ?>  =(*cache (prune known ~))
  ?>  !(different value value(revision 8))
  ?>  (different value value(problem `'Changed native observation.'))
  =/  first  (arm ~2026.10.2 ~ %.y)
  ?>  =(1 (lent -.first))
  ?>  ?=(^ +.first)
  =/  due=@da  u.+.first
  ?>  (wake (timer-wire due) +.first)
  ?>  !(wake (timer-wire (add due ~s1)) +.first)
  ?>  !(wake (timer-wire due) ~)
  ?>  =([~ +.first] (arm ~2026.10.2 +.first %.y))
  ?>  =([~ ~] (arm ~2026.10.2 +.first %.n))
  %readymade-execution-publisher-proof-v1
--
