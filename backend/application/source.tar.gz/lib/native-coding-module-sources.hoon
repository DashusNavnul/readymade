::  Explicit owner module roots for one exact project configuration/target.
::  Pure naming only: the Cantrip owner retains the manifest; compiler.prepare
::  supplies canonical same-revision files and the declared dependency closure.
::  No roots are inferred from permission scopes, import prose, or host paths.
/-  nc=native-coding
/+  project=native-coding-project, files=native-coding-files
|%
+$  manifest
  [%native-coding-module-sources-v1 configuration=@ux target=build-target:nc roots=(list path)]
+$  source  [pax=path blob=@ux text=@t]
+$  mapped  [module=@t source=source]
+$  prepared
  [%native-coding-mapped-sources-v1 context=context:nc mapping=manifest module=@t sources=(list mapped)]
++  source-count-limit  32
++  source-byte-limit  524.288
++  input-byte-limit  1.048.576
++  input-size-valid
  ::  Compiler-only bounds, further restricted by the exact owner project.
  ::  These do not change file paging, model context or execution fuel.
  |=  [p=project:nc prior=@ud bytes=@ud]
  ^-  ?
  &((lte bytes (min source-byte-limit max-file-bytes.policy.p)) (lte (add prior bytes) input-byte-limit))
++  sources-bounded
  |=  [p=project:nc sources=(list source)]
  ^-  ?
  ?.  &((valid:project p) ?=(^ sources) (lte (lent sources) source-count-limit))  %.n
  =/  todo=(list source)  sources
  =/  size=@ud  0
  |-  ^-  ?
  ?~  todo  %.y
  =/  bytes=@ud  (met 3 text.i.todo)
  ?.  (input-size-valid p size bytes)  %.n
  $(todo t.todo, size (add size bytes))
++  source-valid
  |=  [p=project:nc s=source]
  ^-  ?
  ?&  (input-size-valid p 0 (met 3 text.s))
      (readable:project p pax.s)  ?=(^ pax.s)  =(%gls (rear pax.s))
      (text-valid:files p text.s)
      =(blob.s `@ux`(page-to-lobe:clay [%gls text.s]))
  ==
++  sources-valid
  |=  [p=project:nc sources=(list source)]
  ^-  ?
  &((sources-bounded p sources) (levy sources |=(s=source (source-valid p s))))
++  digest
  |=  value=*
  ^-  @ux
  (shax (jam [%native-coding-module-sources-identity-v1 value]))
++  alpha
  |=  c=@t
  ^-  ?
  |(&((gte c 'A') (lte c 'Z')) &((gte c 'a') (lte c 'z')))
++  component
  ::  Matches ModuleSource.checked_name component grammar, preserving case.
  |=  text=@ta
  ^-  ?
  =/  chars=(list @t)  (trip text)
  ?~  chars  %.n
  ?&  (lte (lent chars) 128)  (alpha i.chars)
      (levy t.chars |=(c=@t |((alpha c) &((gte c '0') (lte c '9')) =(c '_'))))
  ==
++  roots-valid
  |=  roots=(list path)
  ^-  ?
  ?&  (gte (lent roots) 1)  (lte (lent roots) 16)
      (levy roots path-valid:project)
      ::  Nested or duplicate roots require an owner correction. There is no
      ::  longest-prefix precedence that could silently rename an import.
      %+  levy  roots
      |=  root=path
      =(1 (lent (skim roots |=(other=path |((under:project root other) (under:project other root))))))
  ==
++  valid
  |=  [p=project:nc m=manifest]
  ^-  ?
  ?&  (valid:project p)  =(configuration.m (configuration:project p))
      =(%gallowglass kind.target.m)  (roots-valid roots.m)
      =(~[target.m] (skim targets.p |=(t=build-target:nc =(name.t name.target.m))))
  ==
++  name
  |=  [m=manifest pax=path]
  ^-  (each @t @tas)
  ?.  &((roots-valid roots.m) (path-valid:project pax) (gte (lent pax) 2))
    [%| %compiler-module-path-invalid]
  ?.  =(%gls (rear pax))  [%| %compiler-module-mark-invalid]
  =/  roots=(list path)  (skim roots.m |=(root=path (under:project root pax)))
  ?.  =(1 (lent roots))  [%| %compiler-module-root-uncovered]
  =/  root=path  (snag 0 roots)
  =/  stem=path  (scag (dec (lent pax)) pax)
  ?.  (lth (lent root) (lent stem))  [%| %compiler-module-name-empty]
  =/  parts=(list @ta)  (slag (lent root) stem)
  ?.  (levy parts component)  [%| %compiler-module-name-invalid]
  =/  module=@t
    %+  roll  parts
    |=  [part=@ta prefix=@t]
    ?:(=(0 prefix) part (cat 3 prefix (cat 3 '.' part)))
  ?.  (lte (met 3 module) 128)  [%| %compiler-module-name-bound]
  [%& module]
++  prepare
  ::  expected is compiler.dependencies' exact ordered closure, not a second
  ::  authority input. Path/blob/text witnesses are retained byte-for-byte.
  |=  [p=project:nc m=manifest context=context:nc expected=(list path) sources=(list source)]
  ^-  (each prepared @tas)
  ?.  (valid p m)  [%| %compiler-module-manifest-invalid]
  ?.  ?&  =(configuration.context configuration.m)
          =(project.context id.spec.p)  =(actor.context authority.spec.p)
          =(owner.source.context authority.spec.p)  =(desk.source.context working.p)
          (revision-valid:project source.context)
      ==
    [%| %compiler-module-context-mismatch]
  ?.  &((gte (lent expected) 1) (lte (lent expected) source-count-limit) =((lent expected) ~(wyt in (silt expected))) =(expected (turn sources |=(s=source pax.s))))
    [%| %compiler-module-closure-mismatch]
  ?.  =(entry.target.m (snag 0 expected))  [%| %compiler-module-entry-mismatch]
  ?.  (sources-bounded p sources)
    [%| %compiler-module-source-bound]
  =/  root  (name m entry.target.m)
  ?:  ?=(%| -.root)  [%| p.root]
  =/  todo=(list source)  sources
  =/  result=(list mapped)  ~
  =/  names=(set @t)  ~
  |-  ^-  (each prepared @tas)
  ?~  todo
    [%& [%native-coding-mapped-sources-v1 context m p.root (flop result)]]
  =/  s=source  i.todo
  ?.  (source-valid p s)
    [%| %compiler-module-source-invalid]
  =/  module  (name m pax.s)
  ?:  ?=(%| -.module)  [%| p.module]
  ?:  (~(has in names) p.module)  [%| %compiler-module-name-duplicate]
  $(todo t.todo, result [[p.module s] result], names (~(put in names) p.module))
--
