::  Viki app gates. A fresh paused ordinary entry and exact pending/direct
::  request are created without %open, inference or a fabricated model reply.
/-  nc=native-coding
/+  selected=qpc-native-selected, c=qpc-native-controller,
    d=qpc-native-decision, admit=qpc-native-admission,
    loop=native-coding-loop, pool=qpc-native-pool,
    sessions=native-coding-session, ct=cantrip-native-coding,
    project=native-coding-project, resolve=native-coding-session-project
|%
+$  command
  $%  [%qpc-selected-open-v1 plan=plan:selected]
      [%qpc-selected-pending-v1 id=@ux mapping=mapping:d]
  ==
++  choice
  |=  [b=bowl:gall id=@ux]
  ^-  (unit record:c)
  =/  held=state:c
    .^(state:c %gx /(scot %p our.b)/viki/(scot %da now.b)/qpc/controller/noun)
  ?.  (valid:c held)  ~
  =/  rows=(list record:c)
    (skim ~(val by records.held) |=(r=record:c &(=(id id.decision.r) =(%chosen phase.r))))
  ?.(=(1 (lent rows)) ~ `(snag 0 rows))
++  original
  |=  [b=bowl:gall held=state:loop p=plan:selected]
  ^-  (unit record:c)
  =/  chosen  (choice b id.p)
  ?~  chosen  ~
  =/  e  (~(get by sessions.held) collection.p)
  =/  binding  (~(get by bindings.held) collection.p)
  ?~  e  ~
  ?~  binding  ~
  =/  rebuilt  (make:selected u.chosen [u.e provider-key.u.binding grant.u.binding] at.p nonce.p)
  ?.  &(?=(%& -.rebuilt) =(p p.rebuilt))  ~
  =/  config  (resolve:resolve our.b now.b projects.held collection.p project.session.u.e)
  ?:  ?=(%| -.config)  ~
  ?.  =(p.config project.grant.p)  ~
  =/  current  (current:project our.b now.b p.config)
  ?:  ?=(%| -.current)  ~
  ?.  =(working.session.entry.p revision.working.p.current)  ~
  =/  catalog  (catalog:project our.b now.b p.config)
  ?:  ?=(%| -.catalog)  ~
  ?.  (levy ~(tap in operations.grant.p) |=(op=operation:nc (member:project p.config p.catalog our.b op)))  ~
  chosen
++  open-entry
  ::  Pure transition after +original/current native authorization. No grant,
  ::  tool, model, source write or review card is emitted here.
  |=  [b=bowl:gall held=state:loop p=plan:selected]
  ^-  (quip card:agent:gall state:loop)
  ?.  (plan-valid:selected p)  [~ held]
  =/  e=entry:sessions  entry.p
  =/  id=@ux  id.session.e
  ?:  |((~(has by sessions.held) id) (~(has by bindings.held) id))  [~ held]
  ?.  (lth ~(wyt by sessions.held) session-limit:sessions)  [~ held]
  =.  held
    held(sessions (~(put by sessions.held) id e), bindings (~(put by bindings.held) id [key.p id.grant.p]))
  =/  cards=(list card:agent:gall)
    %+  turn  records.e
    |=  r=record:sessions
    (poke:loop our.b %graf /native-coding/retain [%attest [%native-coding-session-record-v1 id r]])
  [[(changed:loop id sequence.e) cards] held]
++  pending
  ::  Pure exact registration after canonical consumption/current grant join.
  |=  [b=bowl:gall held=state:loop p=plan:selected m=mapping:d]
  ^-  (quip card:agent:gall state:loop)
  ?.  &(=(request.p request.m) =(id.grant.p grant.m) =(tool.m (key:ct request.p)))  [~ held]
  =/  id=@ux  id.session.entry.p
  =/  found  (~(get by sessions.held) id)
  =/  binding  (~(get by bindings.held) id)
  ?.  &(=(found `entry.p) =(binding `[key.p id.grant.p]))  [~ held]
  =/  key=@ux  (key:ct request.p)
  ?:  |((~(has by pending.held) key) (~(has by direct.held) key))  [~ held]
  =/  appended  (append:sessions entry.p(phase %tools, resume %paused) now.b [%status %tools %qpc-selected-tool])
  ?:  ?=(%| -.appended)  [~ held]
  =.  held  held(pending (~(put by pending.held) key request.p), direct (~(put by direct.held) key id))
  (apply:loop b held p.appended)
++  apply
  |=  [b=bowl:gall held=state:loop command=command]
  ^-  (quip card:agent:gall state:loop)
  ?.  =(our.b src.b)  [~ held]
  ?:  ?=(%qpc-selected-open-v1 -.command)
    =/  p=plan:selected  plan.command
    =/  e=entry:sessions  entry.p
    =/  id=@ux  id.session.e
    ?:  (qpc-required:loop b id)  [~ held]
    ?~  (original b held p)  [~ held]
    ?.  (selection-bound:loop our.b held id selection.e our.b key.p)  [~ held]
    (open-entry b held p)
  =/  saved=(unit record:selected)
    .^((unit record:selected) %gx /(scot %p our.b)/viki/(scot %da now.b)/qpc/selected/(scot %ux id.command)/noun)
  ?~  saved  [~ held]
  =/  r=record:selected  u.saved
  ?.  &(=(%admitting phase.r) ?=(^ marker.r))  [~ held]
  =/  p=plan:selected  plan.r
  =/  chosen  (original b held p)
  ?~  chosen  [~ held]
  =/  scope=(unit scope:ct)
    .^((unit scope:ct) %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/grant/(scot %ux id.grant.p)/noun)
  ?~  scope  [~ held]
  ?.  =(u.scope [grant.p ~])  [~ held]
  =/  allowed  (allowed:ct our.b now.b u.scope request.p)
  ?:  ?=(%| -.allowed)  [~ held]
  =/  receipt=(unit receipt:admit)
    .^((unit receipt:admit) %gx /(scot %p our.b)/cantrip/(scot %da now.b)/qpc/admissions/(scot %ux id.event.u.marker.r)/noun)
  ?~  receipt  [~ held]
  =/  frozen=opening:d  frozen.decision.u.chosen
  =/  current=current:d  [source.frozen epoch.binding.core.decision.u.chosen authority.frozen]
  =/  consumed  (consume:selected r u.chosen u.receipt current)
  ?.  &(?=(%& -.consumed) =(`mapping.command mapping.p.consumed))  [~ held]
  ?:  (qpc-required:loop b id.session.entry.p)  [~ held]
  ?.  (tool-claimed:loop our.b now.b held entry.p request.p)  [~ held]
  (pending b held p mapping.command)
--
