::  Called inside Cantrip, with its real current ship-window. No authority cache.
/-  c=readymade-collab, cp=cantrip-readymade-pact
/+  core=cantrip-readymade-pact, guard=viki-scry-guard, law=cantrip-law-window,
    reader=readymade-collab-state
|%
++  artifact-key
  ::  Canonical exact observation key; parsing grants no authority.
  |=  =path
  ^-  (unit [id=@ux generation=@ud purpose=purpose:cp selected=@ux])
  ?.  ?=([%law %readymade %artifact @ @ ?(%land %publish) @ ~] path)  ~
  =/  id=(unit @ux)  (slaw %ux i.t.t.t.path)
  =/  generation=(unit @ud)  (slaw %ud i.t.t.t.t.path)
  =/  selected=(unit @ux)  (slaw %ux i.t.t.t.t.t.t.path)
  ?~  id  ~
  ?~  generation  ~
  ?~  selected  ~
  ?.  ?&  =(i.t.t.t.path (scot %ux u.id))
          =(i.t.t.t.t.path (scot %ud u.generation))
          =(i.t.t.t.t.t.t.path (scot %ux u.selected))
      ==
    ~
  `[u.id u.generation i.t.t.t.t.t.path u.selected]
++  source-view
  |=  [our=@p actor=@p at=@da]
  ^-  (each view:reader @tas)
  ?.  =(our actor)  [%| %foreign-owner]
  ?.  (agent-live:guard our at %readymade-collab)
    [%| %workflow-unavailable]
  =/  raw=*  .^(* %gx /(scot %p our)/readymade-collab/(scot %da at)/state/noun)
  (read:reader our raw)
++  source
  ::  Preserve the V1 result and invalid-state reason; v4 is read additively.
  |=  [our=@p actor=@p at=@da]
  ^-  (each state:c @tas)
  =/  found  (source-view our actor at)
  ?:  ?=(%& -.found)  [%& state.p.found]
  ?:  |(=(%foreign-owner p.found) =(%workflow-unavailable p.found))
    [%| p.found]
  [%| %workflow-state-invalid]
++  observe
  |=  [our=@p actor=@p at=@da id=@ux window=window:law]
  ^-  (each observation:cp @tas)
  =/  read  (source our actor at)
  ?:  ?=(%| -.read)  [%| p.read]
  (observe:core our actor id p.read window)
++  judge
  |=  [our=@p actor=@p at=@da id=@ux purpose=purpose:cp artifact=@ux window=window:law]
  ^-  (each judgment:cp @tas)
  =/  read  (source our actor at)
  ?:  ?=(%| -.read)  [%| p.read]
  (judge:core our actor id purpose artifact p.read window)
++  observe-artifact
  |=  [our=@p actor=@p at=@da id=@ux generation=@ud purpose=purpose:cp selected=@ux window=window:law]
  ^-  (each artifact-observation:cp @tas)
  =/  found  (source-view our actor at)
  ?:  ?=(%| -.found)  [%| p.found]
  ?~  artifacts.p.found  [%| %artifact-index-unavailable]
  (observe-artifact:core our actor id generation purpose selected state.p.found u.artifacts.p.found window)
--
