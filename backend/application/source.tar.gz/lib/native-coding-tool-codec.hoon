::  Model proposal <-> native tool data. This module grants no authority.
::  Viki supplies both exact revisions; model JSON cannot replace context.
::  Paths are absolute within the project, not operating-system paths.
/-  nc=native-coding, provider=native-coding-provider
/+  cr=codex-responses, law=native-coding-provider, bound=qpc-patch-report,
    project=native-coding-project, terminal=native-coding-terminal
|%
++  text-schema
  |=  [description=@t minimum=@ud maximum=@ud]
  ^-  json
  (pairs:enjs:format ~[['type' s+'string'] ['description' s+description] ['minLength' (numb:enjs:format minimum)] ['maxLength' (numb:enjs:format maximum)]])
++  number-schema
  |=  [minimum=@ud maximum=@ud]
  ^-  json
  (pairs:enjs:format ~[['type' s+'integer'] ['minimum' (numb:enjs:format minimum)] ['maximum' (numb:enjs:format maximum)]])
++  path-schema
  ^-  json
  (text-schema 'Absolute project path such as /lib/example/hoon; / means the project root. No traversal or empty components.' 1 2.064)
++  digest-schema
  ^-  json
  (text-schema 'Exact nonzero 0x hexadecimal digest returned by a prior native read/result. Do not invent or recalculate it.' 3 82)
++  source-schema
  ^-  json
  (text-schema 'Exact UTF-8 source, preserving tabs, spaces and newlines. Byte limits also apply.' 0 65.536)
++  target-schema
  ^-  json
  (text-schema 'An exact registered project target or app name; no shell command or provider instruction.' 1 128)
++  names
  ^-  (list @t)
  ~['list' 'read' 'search' 'create' 'replace' 'patch' 'patches' 'writes' 'move' 'delete' 'diff' 'undo' 'compile' 'check' 'eval' 'inspect' 'jobs' 'observe' 'cancel']
++  write-fields
  ^-  (list [@t json])
  =/  before=json
    (pairs:enjs:format ~[['anyOf' a+~[digest-schema (pairs:enjs:format ~[['type' s+'null']])]]])
  ~[['path' path-schema] ['before' before] ['mark' target-schema] ['source' source-schema]]
++  writes-schema
  ^-  json
  =/  item=json
    (pairs:enjs:format ~[['type' s+'object'] ['properties' (pairs:enjs:format write-fields)] ['required' a+(turn write-fields |=([key=@t schema=json] s+key))] ['additionalProperties' b+%.n]])
  (pairs:enjs:format ~[['type' s+'array'] ['items' item] ['minItems' (numb:enjs:format 1)] ['maxItems' (numb:enjs:format 16)]])
++  patch-fields
  ^-  (list [@t json])
  ~[['path' path-schema] ['before' digest-schema] ['start' (number-schema 1 1.000.000.000)] ['remove' (number-schema 0 1.000.000.000)] ['expected' source-schema] ['replacement' source-schema]]
++  patches-schema
  ::  One atomic multi-file candidate: 1..16 exact line patches, each naming
  ::  the current blob of its file; starts address the original text.
  ^-  json
  =/  item=json
    (pairs:enjs:format ~[['type' s+'object'] ['properties' (pairs:enjs:format patch-fields)] ['required' a+(turn patch-fields |=([key=@t schema=json] s+key))] ['additionalProperties' b+%.n]])
  (pairs:enjs:format ~[['type' s+'array'] ['items' item] ['minItems' (numb:enjs:format 1)] ['maxItems' (numb:enjs:format 16)]])
++  definition
  |=  name=@t
  ^-  [description=@t fields=(list [@t json])]
  ?:  |(=('list' name) =('diff' name))
    [?:(=('list' name) 'List readable project files at the exact current source revision.' 'Compare current working files with the trusted accepted revision; no revision argument is accepted.') ~[['directory' path-schema] ['cursor' (number-schema 0 1.000.000.000)] ['limit' (number-schema 1 64)]]]
  ?:  =('read' name)
    ['Read exact file text and its blob digest. Lines are 1-based; lower count if the byte limit is reached.' ~[['path' path-schema] ['start' (number-schema 1 1.000.000.000)] ['count' (number-schema 1 200)]]]
  ?:  =('search' name)
    =/  mode=json  (pairs:enjs:format ~[['type' s+'string'] ['enum' a+~[s+'text' s+'filename' s+'path']]])
    ['Search permitted files. Cursor advances across scanned files, including nonmatches.' ~[['mode' mode] ['query' (text-schema 'Literal search text.' 1 256)] ['directory' path-schema] ['cursor' (number-schema 0 1.000.000.000)] ['limit' (number-schema 1 32)]]]
  ?:  |(=('create' name) =('replace' name))
    =/  fields=(list [@t json])  ~[['path' path-schema] ['mark' target-schema] ['source' source-schema]]
    [?:(=('create' name) 'Propose a new file. A candidate is not an approved write.' 'Propose complete replacement against the exact current blob digest.') ?:(=('create' name) fields [['before' digest-schema] fields])]
  ?:  =('patch' name)
    ['Propose exact line replacement. start is 1-based; remove counts lines. expected must exactly include the old LF bytes. remove=0 inserts with empty expected.' patch-fields]
  ?:  =('patches' name)
    ['Propose ONE candidate from several exact line patches, across one or more files, in a single call. Each item names its file and that file\'s current blob digest; start/remove address the original file and patches on one file must not overlap. Use this when a change needs more than one file.' ~[['items' patches-schema]]]
  ?:  =('writes' name)
    ['Propose ONE atomic candidate containing complete source for 1..16 distinct files. Use writes for related new and existing files so the whole change is checked together. Every item requires path, before, mark, source: before is null ONLY for an absent new file, otherwise the exact nonzero digest from a native read. A candidate still requires permission and acceptance.' ~[['items' writes-schema]]]
  ?:  =('move' name)
    ['Propose moving a file with the exact before digest. Destination must not already exist.' ~[['from' path-schema] ['to' path-schema] ['before' digest-schema]]]
  ?:  =('delete' name)
    ['Propose deleting an exact current blob. Permission and acceptance are still required.' ~[['path' path-schema] ['before' digest-schema]]]
  ?:  =('undo' name)
    ['Propose an inverse candidate from a retained candidate ID. This creates a new revision; it does not reset history.' ~[['candidate' digest-schema]]]
  ?:  |(=('compile' name) =('check' name))
    [?:(=('compile' name) 'Compile a registered native project target at the trusted current source.' 'Run the checks registered for a native project target.') ~[['target' target-schema]]]
  ?:  =('eval' name)
    ['Propose native Hoon evaluation bounded to at most 2,000,000 microseconds and further capped by the standing grant. No operating-system shell is available.' ~[['path' path-schema] ['expression' (text-schema 'Hoon expression; still subject to native admission and fuel limits.' 1 8.192)] ['fuel' (number-schema 1 2.000.000)]]]
  ?:  =('inspect' name)
    ['Request governed inspection of an allowed native Gall app/path.' ~[['app' target-schema] ['path' path-schema]]]
  ?:  =('jobs' name)
    ['List retained native jobs and their evidence identifiers.' ~[['cursor' (number-schema 0 1.000.000.000)] ['limit' (number-schema 1 256)]]]
  ?>  |(=('observe' name) =('cancel' name))
  [?:(=('observe' name) 'Observe a retained job without resubmitting it.' 'Request cancellation of an admitted native job; never retry its effects.') ~[['job' digest-schema]]]
++  tools
  ^-  (list tool:provider)
  %+  turn  names
  |=  name=@t
  =/  spec  (definition name)
  =/  parameters=json
    (pairs:enjs:format ~[['type' s+'object'] ['properties' (pairs:enjs:format fields.spec)] ['required' a+(turn fields.spec |=([key=@t schema=json] s+key))] ['additionalProperties' b+%.n]])
  [name description.spec parameters]
++  text
  |=  [args=json key=@t minimum=@ud maximum=@ud]
  ^-  @t
  =/  value=@t  (need (string:cr args key))
  ?>  &((gte (met 3 value) minimum) (lte (met 3 value) maximum))
  ?>  !(lien (trip value) |=(c=@t =(0 c)))
  ::  taft rejects TAB/CR; validate a temporary normalized copy, preserving
  ::  the original bytes returned to the file tools.
  =/  normalized=@t
    (crip (turn (trip value) |=(c=@tD ^-(@tD ?:(|(=(9 c) =(13 c)) ' ' c)))))
  =/  decoded=@c  (taft normalized)
  ?>  =(normalized (tuft decoded))
  ?>  %+  levy  (rip 5 decoded)
      |=  c=@c
      &((lte c 0x10.ffff) |((lth c 0xd800) (gth c 0xdfff)))
  value
++  number
  |=  [args=json key=@t minimum=@ud maximum=@ud]
  ^-  @ud
  =/  value=@ud  (need (natural:cr (field:cr args key)))
  ?>  &((gte value minimum) (lte value maximum))
  value
++  path-arg
  |=  [args=json key=@t root=?]
  ^-  path
  =/  value=@t  (text args key 1 2.064)
  ?>  =('/' (cut 3 [0 1] value))
  =/  pax=path  (path-of:terminal ~ value)
  ?>  &((path-valid:project pax) |(root ?=(^ pax)))
  pax
++  term
  |=  [args=json key=@t]
  ^-  @tas
  (name:terminal (text args key 1 128))
++  digest
  |=  [args=json key=@t]
  ^-  @ux
  (digest:terminal (text args key 3 82))
++  replacement
  |=  [args=json pax=path]
  ^-  replacement:nc
  =/  mark=@tas  (term args 'mark')
  ?>  &(?=(^ pax) =(mark (rear pax)))
  [mark (text args 'source' 0 65.536)]
++  interpret
  |=  [context=context:nc accepted=revision:nc proposal=call:provider]
  ^-  tool-request:nc
  ?>  (call-valid:law proposal)
  =.  proposal  (normalize:bound proposal)
  ?>  (lien names |=(value=@t =(value name.proposal)))
  =/  spec  (definition name.proposal)
  =/  args=json  arguments.proposal
  ?>  ?=([%o *] args)
  ::  Required keys are exact; context, owner, permissions, model and revision
  ::  are absent from every schema and therefore always rejected here.
  ?>  =((silt (turn fields.spec |=([key=@t schema=json] key))) ~(key by p.args))
  =/  name=@t  name.proposal
  =/  tool=tool-args:nc
    ?:  |(=('list' name) =('diff' name))
      =/  directory=path  (path-arg args 'directory' %.y)
      =/  cursor=@ud  (number args 'cursor' 0 1.000.000.000)
      =/  limit=@ud  (number args 'limit' 1 64)
      ?:  =('list' name)  [%list directory cursor limit]
      [%diff accepted directory cursor limit]
    ?:  =('read' name)
      [%read (path-arg args 'path' %.n) (number args 'start' 1 1.000.000.000) (number args 'count' 1 200)]
    ?:  =('search' name)
      =/  mode=@t  (text args 'mode' 1 8)
      ?>  ?=(?(%text %filename %path) mode)
      [%search mode (text args 'query' 1 256) (path-arg args 'directory' %.y) (number args 'cursor' 0 1.000.000.000) (number args 'limit' 1 32)]
    ?:  |(=('create' name) =('replace' name))
      =/  pax=path  (path-arg args 'path' %.n)
      =/  content=replacement:nc  (replacement args pax)
      ?:  =('create' name)  [%create pax content]
      [%replace pax (digest args 'before') content]
    ?:  =('patch' name)
      =/  remove=@ud  (number args 'remove' 0 1.000.000.000)
      =/  expected=@t  (text args 'expected' 0 65.536)
      ?>  ?:(=(0 remove) =('' expected) %.y)
      [%patch (path-arg args 'path' %.n) (digest args 'before') (number args 'start' 1 1.000.000.000) remove expected (text args 'replacement' 0 65.536)]
    ?:  =('patches' name)
      =/  raw=json  (need (field:cr args 'items'))
      ?>  ?=([%a *] raw)
      ?>  &((gte (lent p.raw) 1) (lte (lent p.raw) 16))
      :-  %patches
      %+  turn  p.raw
      |=  item=json
      ^-  patch-item:nc
      ?>  ?=([%o *] item)
      ?>  =((silt (turn patch-fields |=([key=@t schema=json] key))) ~(key by p.item))
      =/  remove=@ud  (number item 'remove' 0 1.000.000.000)
      =/  expected=@t  (text item 'expected' 0 65.536)
      ?>  ?:(=(0 remove) =('' expected) %.y)
      [(path-arg item 'path' %.n) (digest item 'before') (number item 'start' 1 1.000.000.000) remove expected (text item 'replacement' 0 65.536)]
    ?:  =('writes' name)
      =/  raw=json  (need (field:cr args 'items'))
      ?>  ?=([%a *] raw)
      ?>  &((gte (lent p.raw) 1) (lte (lent p.raw) 16))
      =/  items=(list write-item:nc)
        %+  turn  p.raw
        |=  item=json
        ^-  write-item:nc
        ?>  ?=([%o *] item)
        ?>  =((silt (turn write-fields |=([key=@t schema=json] key))) ~(key by p.item))
        =/  pax=path  (path-arg item 'path' %.n)
        =/  raw-before=json  (need (field:cr item 'before'))
        =/  before=(unit digest:nc)  ?~(raw-before ~ `(digest item 'before'))
        [pax before (replacement item pax)]
      ?>  =((lent items) ~(wyt in (silt (turn items |=(i=write-item:nc pax.i)))))
      [%writes items]
    ?:  =('move' name)
      =/  from=path  (path-arg args 'from' %.n)
      =/  to=path  (path-arg args 'to' %.n)
      ?>  !=(from to)
      [%move from to (digest args 'before')]
    ?:  =('delete' name)  [%delete (path-arg args 'path' %.n) (digest args 'before')]
    ?:  =('undo' name)  [%undo (digest args 'candidate')]
    ?:  |(=('compile' name) =('check' name))
      =/  target=@tas  (term args 'target')
      ?:  =('compile' name)  [%compile target]
      [%check target]
    ?:  =('eval' name)
      [%eval (path-arg args 'path' %.n) (text args 'expression' 1 8.192) (number args 'fuel' 1 2.000.000)]
    ?:  =('inspect' name)  [%inspect (term args 'app') (path-arg args 'path' %.y)]
    ?:  =('jobs' name)  [%jobs (number args 'cursor' 0 1.000.000.000) (number args 'limit' 1 256)]
    ?:  =('observe' name)  [%observe (digest args 'job')]
    [%cancel (digest args 'job')]
  [%native-coding-tool-request-v1 context id.proposal tool]
++  decode
  |=  [context=context:nc accepted=revision:nc proposal=call:provider]
  ^-  (each tool-request:nc @tas)
  ?.  ?&  !=(0 session.context)  !=(0 request.context)
          !=(0 configuration.context)  !=('' project.context)
          (revision-valid:project source.context)
          (revision-valid:project accepted)
          =(owner.source.context owner.accepted)
      ==  [%| %trusted-context-invalid]
  =/  parsed  (mole |.((interpret context accepted proposal)))
  ?~  parsed  [%| %tool-arguments-invalid]
  [%& u.parsed]
++  maybe-number
  |=  value=(unit @ud)
  ^-  json
  ?~(value ~ (numb:enjs:format u.value))
++  maybe-digest
  |=  value=(unit @ux)
  ^-  json
  ?~(value ~ [%s (scot %ux u.value)])
++  revision
  |=  r=revision:nc
  ^-  json
  (pairs:enjs:format ~[['owner' s+(scot %p owner.r)] ['desk' s+desk.r] ['number' (numb:enjs:format number.r)] ['root' s+(scot %uv root.r)] ['commit' s+(scot %uv commit.r)]])
++  context-json
  |=  c=context:nc
  ^-  json
  (pairs:enjs:format ~[['project' s+project.c] ['configuration' s+(scot %ux configuration.c)] ['session' s+(scot %ux session.c)] ['request' s+(scot %ux request.c)] ['actor' s+(scot %p actor.c)] ['source' (revision source.c)]])
++  job-json
  |=  j=job:nc
  ^-  json
  (pairs:enjs:format ~[['id' s+(scot %ux id.j)] ['context' (context-json context.j)] ['status' s+status.j] ['evidence' a+(turn evidence.j |=(id=@ux s+(scot %ux id)))]])
++  output-json
  |=  out=tool-output:nc
  ^-  json
  =/  fields=(list [@t json])
    ?-  -.out
      %list
        =/  entries=(list json)
          %+  turn  entries.value.out
          |=  e=file-entry:nc
          (pairs:enjs:format ~[['path' s+(spat pax.e)] ['mark' s+mark.e] ['blob' s+(scot %ux blob.e)] ['bytes' (maybe-number bytes.e)]])
        ~[['entries' a+entries] ['next' (maybe-number next.value.out)]]
      %read
        =/  r=file-read:nc  value.out
        ~[['path' s+(spat pax.r)] ['blob' s+(scot %ux blob.r)] ['start' (numb:enjs:format start.r)] ['total' (numb:enjs:format total.r)] ['text' s+text.r] ['next' (maybe-number next.r)]]
      %search
        =/  matches=(list json)
          %+  turn  matches.value.out
          |=  m=match:nc
          (pairs:enjs:format ~[['path' s+(spat pax.m)] ['line' (maybe-number line.m)] ['text' s+text.m]])
        ~[['matches' a+matches] ['next' (maybe-number next.value.out)]]
      %candidate
        ::  Full replacement bytes remain in the native candidate journal.
        ::  Model history receives source witnesses, not whole-file echoes.
        =/  c=candidate:nc  value.out
        =/  edits=(list json)
          %+  turn  edits.c
          |=  e=edit:nc
          =/  content=json
            ?~  content.e  ~
            %-  pairs:enjs:format
            :~  ['mark' s+mark.u.content.e]
                ['bytes' (numb:enjs:format (met 3 source.u.content.e))]
                ['digest' s+(scot %ux (shax source.u.content.e))]
                ['sourceOmitted' b+%.y]
            ==
          (pairs:enjs:format ~[['kind' s+kind.change.e] ['path' s+(spat path.change.e)] ['before' (maybe-digest before.change.e)] ['after' (maybe-digest after.change.e)] ['content' content]])
        ~[['id' s+(scot %ux id.c)] ['context' (context-json context.c)] ['basis' (revision revision.basis.c)] ['accepted' (revision accepted.c)] ['previous' (maybe-digest previous.c)] ['edits' a+edits]]
      %diff
        =/  entries=(list json)
          %+  turn  entries.value.out
          |=  d=difference:nc
          (pairs:enjs:format ~[['path' s+(spat pax.d)] ['before' (maybe-digest before.d)] ['after' (maybe-digest after.d)]])
        ~[['entries' a+entries] ['next' (maybe-number next.value.out)]]
      %diagnostics
        =/  values=(list json)
          %+  turn  values.out
          |=  d=diagnostic:nc
          (pairs:enjs:format ~[['name' s+name.d] ['passed' b+passed.d] ['detail' s+detail.d] ['source' (revision source.d)] ['artifacts' a+(turn artifacts.d |=(id=@ux s+(scot %ux id)))]])
        ~[['values' a+values]]
      %jobs  ~[['values' a+(turn values.out job-json)] ['next' (maybe-number next.out)]]
      %job  ~[['value' (job-json value.out)]]
      %refused  ~[['reason' s+reason.out] ['detail' s+detail.out]]
      %unknown  ~[['reason' s+reason.out] ['detail' s+detail.out]]
    ==
  (pairs:enjs:format [['kind' s+-.out] fields])
++  result-text
  |=  result=tool-result:nc
  ^-  (each @t @tas)
  =/  encoded
    %-  mole
    |.
    %-  en:json:html
    %-  pairs:enjs:format
    :~  ['version' s+'native-coding-tool-result-v1']
        ['call_id' s+call-id.result]
        ['context' (context-json context.result)]
        ['output' (output-json output.result)]
    ==
  ?~  encoded  [%| %tool-result-invalid]
  ?.  (lte (met 3 u.encoded) text-limit:provider)  [%| %tool-result-too-large]
  [%& u.encoded]
--
