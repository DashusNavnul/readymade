::  Detached source transport. Only native Clay content crosses this boundary.
/-  w=native-coding-worker, r=native-coding-worker-runtime, nc=native-coding
/+  law=native-coding-worker, guard=viki-scry-guard, dsr=desk-shell-read
|%
+$  view
  $:  revision=revision:nc  files=(map path lobe:clay)
      parents=(list tako:clay)  latest=@ud  history=@ud
      inactive=?  permissions=[dict:clay dict:clay]
  ==
++  name
  |=  [prefix=@tas o=order:w]
  ^-  @tas
  (cat 3 prefix (crip (skip (trip (scot %ux (digest:law o))) |=(c=@t =(c '.')))))
++  export-desk  |=(o=order:w (name %ncwe- o))
++  import-desk  |=(o=order:w (name %ncwi- o))
++  hashes
  |=(files=(map path lobe:clay) (~(run by files) |=(h=lobe:clay `@ux`h)))
++  private
  ^-  [dict:clay dict:clay]
  [[~ %white ~ ~] [~ %white ~ ~]]
++  shared
  |=  worker=@p
  ^-  [dict:clay dict:clay]
  [[~ %white (silt `(list @p)`~[worker]) ~] [~ %white ~ ~]]
++  snapshot
  ::  Numbered direct indices; never scan historical ancestors with %cv.
  |=  [our=@p now=@da desk=@tas number=@ud]
  ^-  (each view @tas)
  =/  ds=cone:clay  .^(cone:clay %cx /(scot %p our)//(scot %da now)/domes)
  =/  found  (~(get by ds) [our desk])
  ?~  found  [%| %worker-source-missing]
  =/  d=dome:clay  u.found
  =/  commit  (~(get by hit.d) number)
  ?~  commit  [%| %worker-revision-missing]
  =/  at=path  (beam-at:dsr our desk (scot %ud number) /)
  =/  y=yaki:clay  .^(yaki:clay %cs (weld at /yaki/(scot %uv u.commit)))
  =/  v=view
    :*  [our desk number .^(@uv %cz at) u.commit]
        q.y  p.y  let.d  ~(wyt by hit.d)
        &(=(%dead liv.d) =(~ ren.d) =(~ wic.d))
        .^([dict:clay dict:clay] %cp at)
    ==
  [%& v]
++  original
  |=  [our=@p now=@da o=order:w]
  ^-  (each view @tas)
  ?.  &((order-valid:law o) =(our owner.pairing.o))
    [%| %worker-order-invalid]
  =/  source  (snapshot our now desk.source.o number.source.o)
  ?:  ?=(%| -.source)  source
  =/  v=view  p.source
  ?.  ?&  =(source.o revision.v)  =(number.source.o latest.v)
          inactive.v  =(private permissions.v)
          =((namespace-digest:law (hashes files.v)) namespace.o)
      ==  [%| %worker-source-changed]
  [%& v]
++  detached
  |=  [o=order:w v=view desk=@tas owner=@p]
  ^-  ?
  ?&  =(owner owner.revision.v)  =(desk desk.revision.v)
      =(1 number.revision.v)  =(1 latest.v)  =(1 history.v)
      =(~ parents.v)  inactive.v
      =(root.source.o root.revision.v)
      =((namespace-digest:law (hashes files.v)) namespace.o)
  ==
++  export-valid
  |=  [our=@p now=@da o=order:w revision=revision:nc]
  ^-  ?
  =/  source  (original our now o)
  ?:  ?=(%| -.source)  %.n
  =/  exported  (snapshot our now (export-desk o) 1)
  ?:  ?=(%| -.exported)  %.n
  =/  v=view  p.exported
  ?&  =(revision revision.v)  (detached o v (export-desk o) our)
      =(files.p.source files.v)  =((shared worker.pairing.o) permissions.v)
  ==
++  import-valid
  |=  [our=@p now=@da offer=offer:r]
  ^-  (each revision:nc @tas)
  =/  o=order:w  order.offer
  =/  imported  (snapshot our now (import-desk o) 1)
  ?:  ?=(%| -.imported)  [%| p.imported]
  =/  v=view  p.imported
  ?.  ?&  =(our worker.pairing.o)  (detached o v (import-desk o) our)
          =(private permissions.v)  =(commit.export.offer commit.revision.v)
          =(root.export.offer root.revision.v)
          (source-ready:law o revision.v (hashes files.v))
      ==  [%| %worker-import-mismatch]
  [%& revision.v]
++  absent
  |=  [our=@p now=@da desk=@tas]
  ^-  ?
  =/  ds=cone:clay  .^(cone:clay %cx /(scot %p our)//(scot %da now)/domes)
  !(~(has by ds) [our desk])
++  unreserved
  ::  Exclude only an exact authorized pending export at its owning wrapper.
  ::  Every overlapping reservation from other owners remains in the union.
  |=  [our=@p now=@da desk=@tas]
  ^-  ?
  =/  owners=(list [app=@tas pax=path])
    ~[[%native-coding-source-import /reservations/noun] [%viki /native-coding/reserved-desks/except-worker-export/[desk]/noun]]
  %+  levy  owners
  |=  [app=@tas pax=path]
  ?.  (agent-live:guard our now app)  %.y
  =/  held=(set @tas)
    .^((set @tas) %gx (weld /(scot %p our)/[app]/(scot %da now) pax))
  !(~(has in held) desk)
++  import-unreserved
  |=  [our=@p now=@da desk=@tas]
  ^-  ?
  ?.  (unreserved our now desk)  %.n
  ?.  (agent-live:guard our now %cantrip)  %.y
  =/  held=(set @tas)
    .^((set @tas) %gx /(scot %p our)/cantrip/(scot %da now)/native-coding/reserved-desks/noun)
  !(~(has in held) desk)
++  pending-export
  |=  [our=@p now=@da key=@ux]
  ^-  (each order:w @tas)
  ?.  (agent-live:guard our now %cantrip)  [%| %worker-owner-unavailable]
  =/  raw=*
    .^(* %gx /(scot %p our)/cantrip/(scot %da now)/native-coding/worker/export/(scot %ux key)/noun)
  =/  parsed  ((soft ,(unit order:w)) raw)
  ?~  parsed  [%| %worker-export-incompatible]
  ?.  =(raw u.parsed)  [%| %worker-export-incompatible]
  ?~  u.parsed  [%| %worker-export-not-authorized]
  =/  o=order:w  u.u.parsed
  ?.  ?&  (order-valid:law o)  =((digest:law o) key)
          =(our owner.pairing.o)  (lte issued.o now)  (lth now deadline.o)
      ==  [%| %worker-export-not-authorized]
  [%& o]
++  pending-import
  |=  [our=@p now=@da key=@ux]
  ^-  (each offer:r @tas)
  ?.  (agent-live:guard our now %native-coding-worker)
    [%| %worker-source-unavailable]
  =/  raw=*
    .^(* %gx /(scot %p our)/native-coding-worker/(scot %da now)/import/(scot %ux key)/noun)
  =/  parsed  ((soft ,(unit offer:r)) raw)
  ?~  parsed  [%| %worker-import-incompatible]
  ?.  =(raw u.parsed)  [%| %worker-import-incompatible]
  ?~  u.parsed  [%| %worker-import-not-authorized]
  =/  offered=offer:r  u.u.parsed
  =/  o=order:w  order.offered
  ?.  ?&  (order-valid:law o)  =((digest:law o) key)
          =(our worker.pairing.o)  (lte issued.o now)  (lth now deadline.o)
          =(owner.pairing.o owner.export.offered)
          =((export-desk o) desk.export.offered)  =(1 number.export.offered)
          =(root.source.o root.export.offered)
          =([%admitted decision.o key deadline.o] admission.offered)
      ==  [%| %worker-import-not-authorized]
  [%& offered]
++  revoke-export
  ::  Cleanup is safe after expiry/revocation, but only for this exact export.
  |=  [our=@p now=@da o=order:w]
  ^-  (list card:agent:gall)
  ?.  &((order-valid:law o) =(our owner.pairing.o))  ~
  =/  held  (snapshot our now (export-desk o) 1)
  ?:  ?=(%| -.held)  ~
  ?.  &((detached o p.held (export-desk o) our) =((shared worker.pairing.o) permissions.p.held))  ~
  ~[[%pass /native-worker/export-close/(scot %ux (digest:law o)) %arvo %c %perm (export-desk o) / [%r `[%white ~]]]]
--
