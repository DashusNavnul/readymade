::  Bounded editor read and manual-change data contracts. No write admission.
::  First project only: private pataphor-demo and pataphor-demo-work desks.
|%
+$  revision  [desk=@tas number=@ud root=@uv]
+$  content
  $%  [%text source=@t hash=@ux]
      [%unsupported-mark mark=@tas]
      [%over-limit bytes=@ud]
      [%unsupported-text ~]
  ==
+$  snapshot
  $:  %pataphor-editor-read-v1
      owner=@p  at=@da  selected=@tas  base=revision  work=revision
      pax=path  blob=@uv  body=content
  ==
+$  change
  $:  %pataphor-editor-change-v1
      owner=@p  nonce=@ux  basis=snapshot  replacement=@t
  ==
++  max-bytes  `@ud`65.536
++  max-children  `@ud`64
++  desk-valid
  |=  desk=@tas
  ^-  ?
  |(=(%pataphor-demo desk) =(%pataphor-demo-work desk))
++  segment-valid
  |=  part=@ta
  ^-  ?
  ?.  &((gth (met 3 part) 0) (lte (met 3 part) 63))  %.n
  %+  levy  (trip `@t`part)
  |=  c=@t
  |(&((gte c 'a') (lte c 'z')) &((gte c '0') (lte c '9')) =(c '-'))
++  path-valid
  ::  Root is a directory request. Reject encoded, dotted and slash-bearing
  ::  components before any Clay read. Metadata is outside this editor scope.
  |=  pax=path
  ^-  ?
  =/  left=@ud  8
  |-  ^-  ?
  ?~  pax  %.y
  ?:  &(=(8 left) |(=(%mar i.pax) =(%sys i.pax) =(%desk i.pax)))
    %.n
  ?.  &((gth left 0) (segment-valid i.pax))  %.n
  $(pax t.pax, left (dec left))
++  text-valid
  ::  This initial editor supports ASCII text, tabs and line endings. Other
  ::  encodings are reported as unsupported, never coerced or displayed as text.
  |=  source=@t
  ^-  ?
  ?.  (lte (met 3 source) max-bytes)  %.n
  %+  levy  (trip source)
  |=  c=@t
  |(=(c 9) =(c 10) =(c 13) &((gte c 32) (lte c 126)))
++  classify
  |=  [mark=@tas raw=*]
  ^-  content
  ?.  |(=(%hoon mark) =(%txt mark))  [%unsupported-mark mark]
  =/  parsed  ((soft ,@t) raw)
  ?~  parsed  [%unsupported-text ~]
  =/  bytes=@ud  (met 3 u.parsed)
  ?:  (gth bytes max-bytes)  [%over-limit bytes]
  ?.  (text-valid u.parsed)  [%unsupported-text ~]
  [%text u.parsed (shax u.parsed)]
++  revision-valid
  |=  r=revision
  ^-  ?
  &((desk-valid desk.r) (gth number.r 0) !=(0 root.r))
++  snapshot-valid
  |=  s=snapshot
  ^-  ?
  ?.  ?&  !=(0 at.s)  (desk-valid selected.s)
          (revision-valid base.s)  (revision-valid work.s)
          =(%pataphor-demo desk.base.s)  =(%pataphor-demo-work desk.work.s)
          ?=(^ pax.s)  (path-valid pax.s)  !=(0 blob.s)
      ==  %.n
  ?-  -.body.s
    %text
      &((text-valid source.body.s) =(hash.body.s (shax source.body.s)))
    %unsupported-mark
      &(!=(%hoon mark.body.s) !=(%txt mark.body.s))
    %over-limit  (gth bytes.body.s max-bytes)
    %unsupported-text  %.y
  ==
++  change-valid
  ::  This is a well-formed proposal, not permission to save it. The initial
  ::  manual-change scope preserves the demo's support files and guard.
  |=  c=change
  ^-  ?
  ?&  !=(0 nonce.c)  (lte (met 0 nonce.c) 256)
      =(owner.c owner.basis.c)  (snapshot-valid basis.c)
      =(%pataphor-demo-work selected.basis.c)
      =(/lib/session-estimate/hoon pax.basis.c)
      ?=(%text -.body.basis.c)  (text-valid replacement.c)
  ==
++  compare-change
  ::  Pure stale-save check only. A future Cantrip gate must separately admit
  ::  an exact write and retain its outcome; this arm supplies no effects.
  |=  [our=@p actor=@p at=@da request=change current=snapshot]
  ^-  (each change @tas)
  ?.  &(=(our actor) =(our owner.request) =(our owner.current))
    [%| %foreign-actor]
  ?.  &((change-valid request) (snapshot-valid current))
    [%| %invalid-change]
  ?.  &(=(at at.current) (lte at.basis.request at))
    [%| %stale-observation]
  ?.  =(basis.request(at at.current) current)
    [%| %stale-source]
  [%& request]
++  children
  ::  Inspect at most 64 immediate names, including hidden metadata. No
  ::  recursive traversal or full map-to-list conversion for a large directory.
  |=  [parent=path names=(map @ta ~)]
  ^-  (each (list path) @tas)
  ?.  (path-valid parent)  [%| %invalid-path]
  =/  pending=(list (map @ta ~))  ~[names]
  =|  out=(list path)
  =/  left=@ud  max-children
  |-  ^-  (each (list path) @tas)
  ?~  pending  [%& (flop out)]
  =/  node=(map @ta ~)  i.pending
  ?~  node  $(pending t.pending)
  ?:  =(0 left)  [%| %directory-over-limit]
  =/  pax=path  (weld parent ~[p.n.node])
  $(pending [l.node r.node t.pending], left (dec left), out ?:((path-valid pax) [pax out] out))
--
