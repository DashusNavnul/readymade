::  The owner's standing policy, stored natively OUTSIDE any Gall state: each
::  version is one immutable Clay file on the private dead desk
::  %owner-standing-policy, /standing-policy/<n>/noun, chained by the digest of
::  the version before it. A revocation is a new version with no body, so the
::  whole history stays readable and nothing is erased. Cantrip validates and
::  writes; any agent may read. No agent state migrates when this changes.
/-  nc=native-coding
|%
++  desk  %owner-standing-policy
++  limits  [objectives=16 objective-bytes=1.024 paths=256 escalation-bytes=2.048 versions=4.096]
+$  resources
  [max-turns=@ud max-seconds=@ud max-eval-work=@ud max-admissions=@ud]
+$  body
  $:  project=@t
      objectives=(list @t)
      paths=(set path)
      tools=(set operation:nc)
      resources=resources
      escalation=@t
  ==
+$  record
  $:  %cantrip-standing-policy-v1
      version=@ud  at=@da  issuer=@p
      body=(unit body)
      previous=(unit @ux)
  ==
+$  command
  $%  [%cantrip-standing-policy-set-v1 body=body]
      [%cantrip-standing-policy-revoke-v1 ~]
  ==
++  digest
  |=  r=record
  ^-  @ux
  (shax (jam r))
++  text-ok
  |=  [t=@t max=@ud]
  ^-  ?
  &(!=(0 (met 3 t)) (lte (met 3 t) max) ((sane %t) t))
++  body-valid
  |=  b=body
  ^-  ?
  ?&  !=(0 (met 3 project.b))  (lte (met 3 project.b) 128)
      !=(~ objectives.b)  (lte (lent objectives.b) objectives:limits)
      (levy objectives.b |=(t=@t (text-ok t objective-bytes:limits)))
      (lte ~(wyt in paths.b) paths:limits)
      (levy ~(tap in paths.b) |=(p=path &(?=(^ p) (lte (lent p) 16))))
      !=(~ tools.b)
      !=(0 max-turns.resources.b)  !=(0 max-seconds.resources.b)
      !=(0 max-eval-work.resources.b)  !=(0 max-admissions.resources.b)
      (text-ok escalation.b escalation-bytes:limits)
  ==
++  record-valid
  |=  [our=@p r=record]
  ^-  ?
  ?&  =(our issuer.r)  !=(0 version.r)  (lte version.r versions:limits)
      !=(0 at.r)
      =(=(1 version.r) ?=(~ previous.r))
      ?~(body.r %.y (body-valid u.body.r))
  ==
++  active
  ::  The policy in force: the newest version's body, or nothing if revoked.
  |=  r=(unit record)
  ^-  (unit body)
  ?~(r ~ body.u.r)
++  next
  ::  Owner only. A set needs a valid body; a revoke needs a policy in force.
  ::  Each version names the exact digest of the one before it.
  |=  [our=@p src=@p now=@da prev=(unit record) cmd=command]
  ^-  (each record @tas)
  ?.  =(our src)  [%| %standing-policy-owner-required]
  ?:  &(?=(^ prev) !(record-valid our u.prev))  [%| %standing-policy-history-invalid]
  ?:  &(?=(^ prev) (lth now at.u.prev))  [%| %standing-policy-clock-behind]
  =/  version=@ud  ?~(prev 1 +(version.u.prev))
  ?:  (gth version versions:limits)  [%| %standing-policy-history-full]
  =/  link=(unit @ux)  ?~(prev ~ `(digest u.prev))
  ?-  -.cmd
      %cantrip-standing-policy-set-v1
    ?.  (body-valid body.cmd)  [%| %standing-policy-invalid]
    ?:  =(`body.cmd (active prev))  [%| %standing-policy-unchanged]
    [%& [%cantrip-standing-policy-v1 version now our `body.cmd link]]
  ::
      %cantrip-standing-policy-revoke-v1
    ?~  (active prev)  [%| %standing-policy-not-in-force]
    [%& [%cantrip-standing-policy-v1 version now our ~ link]]
  ==
++  chain-valid
  ::  Versions 1..n in order, each linked to the digest of its predecessor.
  |=  [our=@p rows=(list record)]
  ^-  ?
  =|  prev=(unit record)
  |-  ^-  ?
  ?~  rows  %.y
  ?.  (record-valid our i.rows)  %.n
  ?.  =(version.i.rows ?~(prev 1 +(version.u.prev)))  %.n
  ?.  =(previous.i.rows ?~(prev ~ `(digest u.prev)))  %.n
  $(rows t.rows, prev `i.rows)
::  ---  Clay layout and reads (no writes here; the app emits the one card)
++  path-for
  |=  version=@ud
  ^-  path
  /standing-policy/(scot %ud version)/noun
++  private
  |=  [our=@p at=@da pax=path]
  ^-  ?
  =/  rules=[r=dict:clay w=dict:clay]
    .^([r=dict:clay w=dict:clay] %cp (weld ~[(scot %p our) desk (scot %da at)] pax))
  &(=([%white ~ ~] rul.r.rules) =([%white ~ ~] rul.w.rules))
++  store
  ::  The store desk must exist, be dead, private, and have no reins/watches.
  |=  [our=@p at=@da]
  ^-  (each @ud @tas)
  =/  domes=cone:clay  .^(cone:clay %cx /(scot %p our)//(scot %da at)/domes)
  =/  d  (~(get by domes) [our desk])
  ?~  d  [%| %standing-policy-store-missing]
  ?.  &(=(%dead liv.u.d) =(~ ren.u.d) =(~ wic.u.d))  [%| %standing-policy-store-not-dead]
  ?.  &((private our at /) (private our at /standing-policy))  [%| %standing-policy-store-not-private]
  [%& let.u.d]
++  versions
  ::  Every stored version number, ascending.
  |=  [our=@p at=@da let=@ud]
  ^-  (list @ud)
  =/  top=arch  .^(arch %cy /(scot %p our)/[desk]/(scot %ud let))
  ?.  (~(has by dir.top) %standing-policy)  ~
  =/  dir=arch  .^(arch %cy /(scot %p our)/[desk]/(scot %ud let)/standing-policy)
  (sort (murn ~(tap in ~(key by dir.dir)) |=(k=@ta (slaw %ud k))) lth)
++  read
  |=  [our=@p at=@da let=@ud version=@ud]
  ^-  (each record @tas)
  =/  pax=path  (weld /(scot %p our)/[desk]/(scot %ud let) (path-for version))
  ?.  .^(? %cu pax)  [%| %standing-policy-version-missing]
  =/  raw=*  .^(* %cx pax)
  =/  r  ((soft record) raw)
  ?~  r  [%| %standing-policy-version-invalid]
  ?.  &(=(raw u.r) =(version version.u.r) (record-valid our u.r))  [%| %standing-policy-version-invalid]
  [%& u.r]
++  current
  ::  The newest version, after checking the whole chain to it.
  |=  [our=@p at=@da]
  ^-  (each (unit record) @tas)
  =/  s  (store our at)
  ?:  ?=(%| -.s)  [%| p.s]
  =/  nums=(list @ud)  (versions our at p.s)
  ::  An empty store has no versions; gulf would refuse 1..0.
  ?.  |(=(~ nums) =(nums (gulf 1 (lent nums))))  [%| %standing-policy-history-gap]
  ::  A version that cannot be read is answered with its reason; it used to
  ::  crash here, which turned the whole policy page into a failed request.
  =|  rows=(list record)
  |-  ^-  (each (unit record) @tas)
  ?^  nums
    =/  got  (read our at p.s i.nums)
    ?:  ?=(%| -.got)  [%| p.got]
    $(nums t.nums, rows [p.got rows])
  =.  rows  (flop rows)
  ?.  (chain-valid our rows)  [%| %standing-policy-history-invalid]
  [%& ?~(rows ~ `(rear rows))]
++  write
  ::  The single Clay card that stores one validated version (insert only).
  |=  r=record
  ^-  card:agent:gall
  [%pass /standing-policy/(scot %ud version.r) %arvo %c [%info desk %& ~[[(path-for version.r) %ins %noun !>(r)]]]]
--
