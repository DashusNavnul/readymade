::  Separate retained selection journal. The prospective owner stays exact.
::  Native readers authenticate origin/current authority; this core only
::  checks consistency. Selected candidates are not execution or application.
/+  d=qpc-native-decision, owner=qpc-native-owner,
    admit=qpc-native-admission, sessions=native-coding-session
|%
+$  attempt  [event=record:sessions draw=@ud]
+$  record
  $:  origin=record:owner  marker=marker:admit
      admission=(unit receipt:admit)  attempt=(unit attempt)
      decision=state:d  phase=?(%waiting %chosen %refused %unknown)
      reason=(unit @tas)
  ==
+$  state  [%qpc-native-controller-v1 records=(map @ux record) unavailable=(map @ux @tas)]
++  empty  ^-(state [%qpc-native-controller-v1 ~ ~])
++  event-valid
  |=  [session=@ux event=record:sessions prior=@ux position=@ud reason=@tas]
  ^-  ?
  ?&  =(previous.event `prior)  =(sequence.event +(position))
      =(body.event [%status %paused reason])
      =(id.event (event-id:sessions session sequence.event previous.event at.event body.event))
  ==
++  begin
  |=  [origin=record:owner marker=marker:admit]
  ^-  (each record @tas)
  ?^  closed.origin  [%| %qpc-controller-owner-closed]
  ?~  collection.origin  [%| %qpc-controller-pool-missing]
  =/  c=collection:owner  u.collection.origin
  =/  f=opening:d  frozen.decision.origin
  =/  opened  (open:d f)
  ?.  &(?=(%& -.opened) =(p.opened decision.origin))
    [%| %qpc-controller-owner-not-prospective]
  ?.  ?&  =(opening.marker id.decision.origin)  =(session.marker session.f)
          (event-valid session.f event.marker through.pool.c position.c %qpc-admission-requested)
      ==  [%| %qpc-controller-marker-mismatch]
  [%& [origin marker ~ ~ decision.origin %waiting ~]]
++  select
  ::  One persisted attempt, including native event entropy and refusals.
  ::  Caller must have appended the exact event in the same Gall transaction.
  |=  [r=record receipt=receipt:admit attempt=attempt current=current:d]
  ^-  (each record @tas)
  ?.  =(%waiting phase.r)  [%| %qpc-controller-already-attempted]
  ?.  (fresh:d decision.r current)  [%| %qpc-controller-source-or-authority-changed]
  ?.  =(marker.r request.receipt)  [%| %qpc-controller-receipt-mismatch]
  ?.  (event-valid session.marker.r event.attempt id.event.marker.r sequence.event.marker.r %qpc-selection-attempted)
    [%| %qpc-controller-choice-event-mismatch]
  =/  c=collection:owner  (need collection.origin.r)
  =/  next=record  r(admission `receipt, attempt `attempt)
  =/  bound  (bind:d decision.r pool.c generation.c position.c offered.receipt current)
  ?:  ?=(%| -.bound)  [%& next(phase %refused, reason `p.bound)]
  =.  next  next(decision p.bound)
  =/  chosen  (choose:d p.bound draw.attempt sequence.event.attempt current)
  ?:  ?=(%| -.chosen)  [%& next(phase %refused, reason `p.chosen)]
  [%& next(decision p.chosen, phase %chosen)]
++  unavailable
  |=  [s=state id=@ux reason=@tas]
  ^-  state
  ?.  |((~(has by unavailable.s) id) (lth ~(wyt by unavailable.s) 128))  s
  s(unavailable (~(put by unavailable.s) id reason))
++  recover
  ::  No re-dispatch, new draw, source read or renewal after reload.
  |=  s=state
  ^-  state
  s(records (~(run by records.s) |=(r=record ?:(=(%waiting phase.r) r(phase %unknown, reason `%qpc-controller-reload-unconfirmed) r))))
++  valid
  |=  s=state
  ^-  ?
  ?&  (lte ~(wyt by records.s) 64)  (lte ~(wyt by unavailable.s) 128)
      (levy ~(tap by unavailable.s) |=([id=@ux reason=@tas] &(!=(0 id) !=(%$ reason))))
      %+  levy  ~(tap by records.s)
      |=  [id=@ux r=record]
      =/  opened  (begin origin.r marker.r)
      ?.  &(?=(%& -.opened) =(id session.marker.r))  %.n
      ?:  =(%waiting phase.r)  =(p.opened r)
      ?:  =(%unknown phase.r)
        =(p.opened(phase %unknown, reason `%qpc-controller-reload-unconfirmed) r)
      ?~  admission.r  %.n
      ?~  attempt.r  %.n
      =/  f=opening:d  frozen.decision.origin.r
      =/  now=current:d  [source.f epoch.binding.core.decision.origin.r authority.f]
      =/  replay  (select p.opened u.admission.r u.attempt.r now)
      &(?=(%& -.replay) =(p.replay r))
  ==
--
