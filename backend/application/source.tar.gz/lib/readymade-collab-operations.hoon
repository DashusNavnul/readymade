::  Owner-local finite operation admission. Return saved pending state and
::  effects together; the Gall caller installs that state before emitting cards.
/-  c=readymade-collab, j=readymade-collab-jobs, pkg=readymade-package, spider
/+  flow=readymade-collab, package=readymade-package,
    release=readymade-package-release, guard=viki-scry-guard,
    compiler=readymade-package-build
|%
+$  transition
  $:  state=state:c
      ledger=ledger:j
      cards=(list card:agent:gall)
      message=@t
  ==
++  capacity
  |=  ledger=ledger:j
  ^-  ?
  (lth ~(wyt by ledger) 1.024)
++  eligible
  ::  Pure admission before any scry, useful to reject foreign/duplicate input.
  |=  [our=@p source=@p ledger=ledger:j cmd=command:c]
  ^-  (unit @p)
  ?.  ?&  =(our source)
          =(owner.cmd (scot %p our))
          (identifier:flow request.cmd)
          (bounded-text:flow peer.cmd 128)
          (lte ~(wyt by ledger) 1.024)
          (bounded-text:flow title.cmd 96)
          (bounded-text:flow reference.cmd 512)
          (bounded-text:flow digest.cmd 256)
          (bounded-text:flow summary.cmd 2.000)
          (bounded-text:flow terms.cmd 4.000)
          (bounded-text:flow id.cmd 512)
          (lien `(list @t)`~['offer' 'inspect' 'accept' 'decline' 'build'] |=(op=@t =(op op.cmd)))
      ==
    ~
  =/  peer=(unit @p)  (slaw %p peer.cmd)
  ?~  peer  ~
  ?.  &(!=(our u.peer) =(peer.cmd (scot %p u.peer)))  ~
  ?:  (lien ~(val by ledger) |=(job=job:j =(request.cmd request.command.job)))  ~
  peer
++  offer-valid
  |=  cmd=command:c
  ^-  ?
  =/  graf=(unit @ux)  (slaw %ux digest.cmd)
  ?&  =('offer' op.cmd)
      (identifier:flow title.cmd)
      !=('' summary.cmd)
      (bounded-text:flow summary.cmd 2.000)
      ?=(^ (select:release reference.cmd))
      ?~(graf %.n (digest-valid:package u.graf))
  ==
++  incoming
  |=  [our=@p peer=@p state=state:c cmd=command:c]
  ^-  (unit package:c)
  =/  id=(unit @ux)  (slaw %ux id.cmd)
  ?~  id  ~
  ?.  &(=(id.cmd (scot %ux u.id)) =(digest.cmd id.cmd))  ~
  =/  item=(unit package:c)  (~(get by packages.state) u.id)
  ?~  item  ~
  =/  offer=offer:pkg  offer.value.u.item
  ?.  ?&  (valid:package offer)
          =(u.id digest.offer)
          =(our recipient.body.offer)
          =(peer sender.body.offer)
      ==
    ~
  item
++  pending-offer
  |=  [ledger=ledger:j offer=@ux]
  ^-  ?
  (lien ~(val by ledger) |=(job=job:j &(=(%pending phase.job) =(offer.job `offer))))
++  workspace
  |=  [our=@p offer=@ux]
  ^-  @tas
  =/  hash=@ux  (end [0 64] (shax (jam [%readymade-workspace-v1 our offer])))
  =/  digits=@t  (crip (skip (trip (scot %ux hash)) |=(char=@t =(char '.'))))
  `@tas`(cat 3 'work-' digits)
++  build-plan
  ::  Provisional admission only: launch retains the actual fresh job nonce.
  |=  [our=@p state=state:c ledger=ledger:j cmd=command:c]
  ^-  (unit plan:compiler)
  ?.  &((capacity ledger) =('build' op.cmd))  ~
  =/  peer=(unit @p)  (eligible our our ledger cmd)
  ?~  peer  ~
  =/  item=(unit package:c)  (incoming our u.peer state cmd)
  ?~  item  ~
  =/  id=@ux  digest.offer.value.u.item
  ?:  (pending-offer ledger id)  ~
  ::  Uncertain Ford work must be observed, never automatically retried.
  ?:  %+  lien  ~(val by ledger)
      |=  prior=job:j
      &(=(%build kind.prior) |(=(offer.prior `id) ?=(?(%pending %uncertain) phase.prior)))
    ~
  ?:  (~(has by ledger) %readymade-build-admission)  ~
  =/  job=job:j  [cmd 0x1 %build %pending `id ~]
  =/  prepared
    (ready:compiler our state (~(put by ledger) %readymade-build-admission job) id 0x1)
  ?.  ?=(%& -.prepared)  ~
  `p.prepared
++  thread-source
  |=  [b=bowl:gall file=@tas]
  ^-  (unit @tas)
  ?.  =(our.b p.byk.b)  ~
  =/  desks=(set @tas)
    .^((set @tas) %cd ~[(scot %p our.b) '' (scot %da now.b)])
  ?:  (~(has in desks) %host-readymade-collab)
    ?:  .^(? %cu /(scot %p our.b)/host-readymade-collab/(scot %da now.b)/ted/[file]/hoon)
      `%host-readymade-collab
    ?.  (~(has in desks) q.byk.b)  ~
    ?.  .^(? %cu /(scot %p our.b)/[q.byk.b]/(scot %da now.b)/ted/[file]/hoon)  ~
    `q.byk.b
  ?.  (~(has in desks) q.byk.b)  ~
  ?.  .^(? %cu /(scot %p our.b)/[q.byk.b]/(scot %da now.b)/ted/[file]/hoon)  ~
  `q.byk.b
++  launch
  |=  [b=bowl:gall state=state:c ledger=ledger:j cmd=command:c kind=kind:j offer=(unit @ux) file=@tas]
  ^-  (unit transition)
  ?.  (capacity ledger)  ~
  ?.  (agent-live:guard our.b now.b %spider)  ~
  =/  desk=(unit @tas)  (thread-source b file)
  ?~  desk  ~
  =/  nonce=@ux  (shax (jam [%readymade-job-v1 eny.b now.b our.b cmd kind]))
  ?.  (digest-valid:package nonce)  ~
  =/  tid=@ta  `@ta`(cat 3 'collab-' (scot %ux nonce))
  ?:  (~(has by ledger) tid)  ~
  =/  job=job:j  [cmd nonce kind %pending offer ~]
  =/  input=vase
    ?:  =(%release kind)  !>(`request.cmd)
    ?~  offer  !>(~)
    !>(`[u.offer nonce])
  =/  args=start-args:spider
    [~ `tid [our.b u.desk %da now.b] file input]
  =/  wire=wire  /collab/job/[tid]
  =/  cards=(list card:agent:gall)
    :~  [%pass wire %agent [our.b %spider] %watch /thread-result/[tid]]
        [%pass wire %agent [our.b %spider] %poke %spider-start !>(args)]
    ==
  =/  message=@t  'Native operation pending; completion is not yet observed.'
  =/  receipt=receipt:c  [request.cmd op.cmd %uncertain our.b message]
  `[(record:flow state receipt) (~(put by ledger) tid job) cards message]
++  reserved
  ::  These canonical local sets are mandatory; no absent-agent scry is tried.
  |=  b=bowl:gall
  ^-  (unit (set @tas))
  ?.  ?&  (agent-live:guard our.b now.b %viki)
          (agent-live:guard our.b now.b %cantrip)
          (agent-live:guard our.b now.b %native-coding-source-import)
      ==
    ~
  =/  desks=(set @tas)
    .^((set @tas) %cd ~[(scot %p our.b) '' (scot %da now.b)])
  =/  projects=(set @tas)
    ;;((set @tas) .^(* %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/reserved-desks/noun))
  =/  tools=(set @tas)
    ;;((set @tas) .^(* %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/reserved-desks/noun))
  =/  imports=(set @tas)
    ;;((set @tas) .^(* %gx /(scot %p our.b)/native-coding-source-import/(scot %da now.b)/reservations/noun))
  ?.  ?&  (lte ~(wyt in desks) 4.096)
          (lte ~(wyt in projects) 4.096)
          (lte ~(wyt in tools) 4.096)
          (lte ~(wyt in imports) 4.096)
      ==
    ~
  `(~(uni in (~(uni in desks) projects)) (~(uni in tools) imports))
++  start
  |=  [b=bowl:gall state=state:c ledger=ledger:j cmd=command:c]
  ^-  (unit transition)
  =/  peer=(unit @p)  (eligible our.b src.b ledger cmd)
  ?~  peer  ~
  ?:  =('offer' op.cmd)
    ?.  (offer-valid cmd)  ~
    (launch b state ledger cmd %release ~ %readymade-package-release)
  =/  found=(unit package:c)  (incoming our.b u.peer state cmd)
  ?~  found  ~
  =/  item=package:c  u.found
  =/  id=@ux  digest.offer.value.item
  ?:  =('decline' op.cmd)
    =/  moved  (decide:package our.b src.b value.item id %.n %$ *(set @tas))
    ?.  ?=(%& -.moved)  ~
    =/  next=state:c  state(packages (~(put by packages.state) id item(value p.moved)))
    =/  receipt=receipt:c  [request.cmd op.cmd %confirmed our.b 'Package declined locally; no source was executed.']
    `[(record:flow next receipt) ledger ~ 'Package declined locally.']
  ?:  (pending-offer ledger id)  ~
  ?:  =('build' op.cmd)
    =/  plan=(unit plan:compiler)  (build-plan our.b state ledger cmd)
    ?~  plan  ~
    =/  permission  (current-law:compiler our.b now.b)
    ?.  ?=(%& -.permission)  ~
    ?^  (verify-workspace:compiler our.b now.b u.plan)  ~
    (launch b state ledger cmd %build `id %readymade-package-build)
  ?:  =('inspect' op.cmd)
    ?.  ?=(?(%received %inspected) stage.value.item)  ~
    (launch b state ledger cmd %inspect `id %readymade-package-inspect)
  ?.  =('accept' op.cmd)  ~
  ?.  =(%inspected stage.value.item)  ~
  ?.  (capacity ledger)  ~
  =/  blocked=(unit (set @tas))  (reserved b)
  ?~  blocked  ~
  =/  destination=@tas  (workspace our.b id)
  =/  moved  (decide:package our.b src.b value.item id %.y destination u.blocked)
  ?.  ?=(%& -.moved)  ~
  =/  next=state:c  state(packages (~(put by packages.state) id item(value p.moved)))
  (launch b next ledger cmd %stage `id %readymade-package-stage)
--
