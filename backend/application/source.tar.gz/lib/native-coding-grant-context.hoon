::  Observed grant scope for one request; never authorization or a grant update.
/-  nc=native-coding
/+  law=cantrip-native-coding, project=native-coding-project
|%
++  observe
  |=  [our=@p id=@ux session=@ux actor=@p configuration=@ux raw=*]
  ^-  (each @t @tas)
  =/  parsed  ((soft ,(unit scope:law)) raw)
  ?~  parsed  [%| %grant-context-malformed]
  ?.  =(raw u.parsed)  [%| %grant-context-malformed]
  (describe our id session actor configuration u.parsed)
++  describe
  |=  [our=@p id=@ux session=@ux actor=@p configuration=@ux current=(unit scope:law)]
  ^-  (each @t @tas)
  ?~  current  [%| %grant-context-missing]
  =/  scoped=scope:law  u.current
  =/  g=grant:law  grant.scoped
  ?.  &(=(~ revoked.scoped) (grant-valid:law our g))
    [%| %grant-context-inactive]
  ?.  &(=(id id.g) =(session session.g) =(actor actor.g) =(configuration (configuration:project project.g)))
    [%| %grant-context-mismatch]
  =/  operations=(list operation:nc)  (sort ~(tap in operations.g) aor)
  =/  data=json
    (pairs:enjs:format ~[['grant' s+(scot %ux id)] ['session' s+(scot %ux session)] ['actor' s+(scot %p actor)] ['configuration' s+(scot %ux configuration)] ['operations' a+(turn operations |=(op=operation:nc s+op))]])
  [%& (rap 3 ~['\0aObserved active session grant: ' (en:json:html data) '\0aPropose only operation classes listed here. Tool availability and project policy do not widen this grant. Each call still requires current Cantrip admission.\0a'])]
--
