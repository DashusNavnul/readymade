::  /lib/memory-tier
::
::  THE TIERS OF THE OPERATOR'S MEMORY (2026-09-28).  A memory a model wrote
::  is ADVISORY: the model's claim, served, never law.  It becomes CANON only
::  by the operator's ruling, made where a human is present (the page, over
::  Eyre) and only while cantrip admits %promote -- the never-automatic act.
::  A ruling can also REFUSE a memory: it is then kept but never served.
::
::  A ruling names the exact VERSION it rules on (the first four bytes of the
::  body's hash), so editing a canon memory makes the new version advisory
::  until it is ruled again: canon can never be changed by the pen that wrote
::  it.
::
::    [%operator-memory-ruling %1 name hash verdict regime sap by at]
::
|%
+$  mem     [name=@t description=@t type=@t body=@t source=@t at=@da]
+$  tier    ?(%canon %advisory %refused)
+$  ruling  [name=@t hash=@t verdict=tier regime=@tas sap=path by=@p at=@da]
++  hash-of
  |=  body=@t
  ^-  @t
  (crip ((x-co:co 8) (end [3 4] (sham body))))
++  facts-of
  |=  [our=@p now=@da kind=@tas]
  ^-  (list *)
  .^((list *) %gx /(scot %p our)/graf/(scot %da now)/by-kind/[kind]/noun)
::  the newest live version of every name
++  live
  |=  [our=@p now=@da]
  ^-  (list mem)
  =/  vs=(list mem)
    %+  murn  (facts-of our now %operator-memory)
    |=(f=* ?.(?=([%operator-memory %1 *] f) ~ ((soft mem) +>.f)))
  =/  gone=(map @t @da)
    %+  roll  (facts-of our now %operator-memory-retired)
    |=  [f=* acc=(map @t @da)]
    =/  r  ((soft ,[%operator-memory-retired %1 name=@t source=@t at=@da]) f)
    ?~  r  acc
    ?:  (gth (~(gut by acc) name.u.r *@da) at.u.r)  acc
    (~(put by acc) name.u.r at.u.r)
  =/  best=(map @t mem)
    %+  roll  vs
    |=  [m=mem acc=(map @t mem)]
    =/  old  (~(get by acc) name.m)
    ?:  &(?=(^ old) (gte at.u.old at.m))  acc
    (~(put by acc) name.m m)
  %+  sort
    %+  skim  ~(val by best)
    |=(m=mem (gth at.m (~(gut by gone) name.m *@da)))
  |=([a=mem b=mem] (lth name.a name.b))
++  rulings
  |=  [our=@p now=@da]
  ^-  (list ruling)
  %+  murn  (facts-of our now %operator-memory-ruling)
  |=(f=* ?.(?=([%operator-memory-ruling %1 *] f) ~ ((soft ruling) +>.f)))
::  a version's tier: the newest ruling on exactly this version, else advisory
++  tier-of
  |=  [rs=(list ruling) name=@t hash=@t]
  ^-  tier
  =/  best=(unit ruling)
    %+  roll  rs
    |=  [r=ruling acc=(unit ruling)]
    ?.  &(=(name name.r) =(hash hash.r))  acc
    ?:  &(?=(^ acc) (gte at.u.acc at.r))  acc
    `r
  ?~(best %advisory verdict.u.best)
::  the live memories with their tiers, canon first
++  tiered
  |=  [our=@p now=@da]
  ^-  (list [m=mem hash=@t =tier])
  =/  rs  (rulings our now)
  =/  all
    %+  turn  (live our now)
    |=(m=mem =/(h (hash-of body.m) [m h (tier-of rs name.m h)]))
  %+  sort  all
  |=  [a=[m=mem hash=@t =tier] b=[m=mem hash=@t =tier]]
  ?:  =(tier.a tier.b)  (lth name.m.a name.m.b)
  =(%canon tier.a)
--
