::  Owner HTTP boundary for standing review scope and retained campaigns.
::  Project/source witnesses, model receipts and credentials remain private.
/-  protocol=native-coding-review, np=native-coding-provider,
    nf=native-coding-fleet, nc=native-coding
/+  campaign=native-coding-review-orchestration, request=native-coding-review-request,
    guard=viki-scry-guard, cr=codex-responses
|%
++  scopes
  |=  [our=@p now=@da]
  ^-  (map @t scope:protocol)
  ?>  (agent-live:guard our now %viki)
  .^((map @t scope:protocol) %gx /(scot %p our)/viki/(scot %da now)/native-coding/review-scopes/noun)
++  reviewer-json
  |=  r=reviewer:protocol
  ^-  json
  =/  c=config:request  config.r
  =/  s=selection:np  selection.c
  (pairs:enjs:format ~[['ship' s+(scot %p ship.r)] ['generation' s+(scot %ud generation.c)] ['session' s+(scot %ux session.c)] ['providerKey' s+provider-key.c] ['binding' s+(scot %ux (digest:request c))] ['provider' s+provider.s] ['model' s+model.s] ['endpoint' s+endpoint.s] ['format' s+format.s] ['credential' s+credential.s] ['streaming' b+streaming.capabilities.s] ['tools' b+tools.capabilities.s] ['parallel' b+parallel.capabilities.s]])
++  scope-json
  |=  s=scope:protocol
  ^-  json
  (pairs:enjs:format ~[['project' s+project.s] ['enabled' b+enabled.s] ['digest' s+(scot %ux (digest:request s))] ['left' (reviewer-json left.s)] ['right' (reviewer-json right.s)]])
++  job-json
  |=  [id=@ux j=job:campaign]
  ^-  json
  (pairs:enjs:format ~[['id' s+(scot %ux id)] ['reviewer' (reviewer-json [worker.j config.j])] ['mode' s+mode.request.j] ['phase' s+?~(event.j 'awaiting-response' phase.u.event.j)] ['reason' s+?~(event.j '' reason.u.event.j)] ['receivedGeneration' ?~(event.j ~ s+(scot %ud generation.u.event.j))] ['receipt' ?~(event.j ~ s+(scot %ux receipt.u.event.j))]])
++  view
  |=  [our=@p now=@da]
  ^-  json
  ?.  (agent-live:guard our now %viki)
    (pairs:enjs:format ~[['available' b+%.n] ['scopes' a+~] ['campaigns' a+~]])
  =/  held=(map @t scope:protocol)  (scopes our now)
  =/  rows=(map @ux campaign:campaign)
    .^((map @ux campaign:campaign) %gx /(scot %p our)/viki/(scot %da now)/native-coding/review-campaigns/noun)
  =/  public=(list json)
    %+  turn  (scag 32 ~(tap by rows))
    |=  [id=@ux e=campaign:campaign]
    (pairs:enjs:format ~[['id' s+(scot %ux id)] ['project' s+project.scope.e] ['candidate' s+(scot %ux id.candidate.record.e)] ['workspace' s+workspace.e] ['done' b+done.e] ['reason' s+reason.e] ['scopeCurrent' b+=(`scope.e (~(get by held) project.scope.e))] ['scope' (scope-json scope.e)] ['jobs' a+(turn (scag 5 ~(tap by jobs.e)) job-json)]])
  (pairs:enjs:format ~[['available' b+%.y] ['scopes' a+(turn (scag 32 ~(val by held)) scope-json)] ['campaigns' a+public]])
++  boolean
  |=  [o=json key=@t]
  ^-  ?
  =/  value=json  (need (field:cr o key))
  ?>  ?=(%b -.value)
  p.value
++  hex
  |=  [o=json key=@t]
  ^-  @ux
  =/  text=@t  (need (string:cr o key))
  =/  value=@ux  (need (slaw %ux text))
  ?>  &(!=(0 value) (lte (met 0 value) 256) =(text (scot %ux value)))
  value
++  reviewer
  |=  [our=@p o=json]
  ^-  reviewer:protocol
  ?>  ?=(%o -.o)
  ?>  =((silt ~['ship' 'generation' 'session' 'providerKey' 'provider' 'model' 'endpoint' 'format' 'credential' 'streaming' 'tools' 'parallel']) ~(key by p.o))
  =/  ship-text=@t  (need (string:cr o 'ship'))
  =/  ship=@p  (need (slaw %p ship-text))
  ?>  =(ship-text (scot %p ship))
  =/  generation-text=@t  (need (string:cr o 'generation'))
  =/  generation=@ud  (need (slaw %ud generation-text))
  ?>  &(=(generation-text (scot %ud generation)) (lte (met 0 generation) 64))
  =/  provider=@t  (need (string:cr o 'provider'))
  =/  format=@t  (need (string:cr o 'format'))
  ?>  &(?=(provider:np provider) ?=(wire-format:np format))
  =/  selection=selection:np
    [%native-coding-provider-v1 provider (need (string:cr o 'model')) (need (string:cr o 'endpoint')) format [(boolean o 'streaming') (boolean o 'tools') (boolean o 'parallel')] (need (string:cr o 'credential'))]
  =/  c=config:request
    [our generation (hex o 'session') (need (string:cr o 'providerKey')) selection]
  ?>  (config-valid:request ship c)
  [ship c]
++  registered
  |=  [fleet=organ:nf ship=@p]
  ^-  ?
  (lien ~(val by workers.fleet) |=(w=worker:nf =(ship moon.seat-session.route.w)))
++  action
  |=  [our=@p now=@da kind=@t o=json]
  ^-  action:campaign
  ?>  (agent-live:guard our now %viki)
  ?:  =('campaign-observe' kind)
    [%observe (hex o 'campaign')]
  =/  project=@t  (need (string:cr o 'project'))
  =/  held=(map @t scope:protocol)  (scopes our now)
  ?:  =('campaign-disable' kind)
    =/  current=scope:protocol  (~(got by held) project)
    =/  expected=@ux  (hex o 'scope')
    ?>  =(expected (digest:request current))
    [%scope-if `expected current(enabled %.n)]
  ?>  =('campaign-scope' kind)
  ::  Check the displayed scope here, and carry its digest for the atomic
  ::  comparison when Viki actually handles this command.
  =/  expected=json  (need (field:cr o 'previous'))
  =/  previous=(unit scope:protocol)  (~(get by held) project)
  ?>  ?~(previous =(~ expected) =(s+(scot %ux (digest:request u.previous)) expected))
  ?>  (boolean o 'consent')
  =/  projects=(map @t project:nc)
    .^((map @t project:nc) %gx /(scot %p our)/viki/(scot %da now)/native-coding/projects/noun)
  ?>  (~(has by projects) project)
  =/  chosen=scope:protocol
    [project (reviewer our (need (field:cr o 'left'))) (reviewer our (need (field:cr o 'right'))) %.y]
  ?>  (scope-valid:campaign our chosen)
  =/  fleet=organ:nf
    .^(organ:nf %gx /(scot %p our)/viki/(scot %da now)/native-coding/fleet/noun)
  ?>  &((registered fleet ship.left.chosen) (registered fleet ship.right.chosen))
  [%scope-if ?~(previous ~ `(digest:request u.previous)) chosen]
--
