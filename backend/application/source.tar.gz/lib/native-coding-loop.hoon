::  Native coding integration owned and persisted by %viki. Every tool proposal
::  is registered before its Cantrip poke. Inference transports own no session law.
/-  nc=native-coding, np=native-coding-provider, vr=glass-moon-route, nf=native-coding-fleet,
    frozen=native-coding-context, clisur=cli-inference
/+  sessions=native-coding-session, projects=native-coding-project,
    codec=native-coding-tool-codec, inference=native-coding-inference,
    guard=viki-scry-guard, terminal=native-coding-terminal, context-read=native-coding-context,
    fleet=native-coding-fleet-runtime, fleet-read=native-coding-fleet-read,
    fleet-law=native-coding-fleet, relay=native-coding-moon-relay, legacy=viki-glass-coding-loop,
    session-project=native-coding-session-project, observation=native-coding-observation,
    acceptance=native-coding-accept, tool-law=cantrip-native-coding,
    git=readymade-git-proposal, git-read=readymade-git-candidate-read,
    qpc=qpc-native-collection, qpc-evidence=qpc-native-evidence,
    qpc-pool=qpc-native-pool, qpc-observation=qpc-observation,
    provider-request=native-coding-provider-request, provider=native-coding-provider,
    loop-law=native-coding-loop-law, artifact=readymade-artifact-executor,
    paused-open=native-coding-paused-open, submission=native-coding-submission-receipt,
    grant-context=native-coding-grant-context
|%
+$  card  card:agent:gall
+$  binding  [provider-key=@tas grant=@ux]
+$  state-1
  $:  %native-coding-loop-v1
      projects=(map @t project:nc)  sessions=organ:sessions
      bindings=(map @ux binding)  pending=(map @ux tool-request:nc)
      candidates=(map @ux candidate:nc)
      direct=(map @ux @ux)  inputs=(map @ux [session=@ux input=@t])
  ==
+$  state
  $:  %native-coding-loop-v2
      projects=(map @t project:nc)  sessions=organ:sessions
      bindings=(map @ux binding)  pending=(map @ux tool-request:nc)
      candidates=(map @ux candidate:nc)
      direct=(map @ux @ux)  inputs=(map @ux [session=@ux input=@t])
      fleet=state:fleet
  ==
++  empty
  ^-  state
  [%native-coding-loop-v2 ~ ~ ~ ~ ~ ~ ~ empty:fleet]
++  migrate
  |=  old=state-1
  ^-  state
  [%native-coding-loop-v2 projects.old sessions.old bindings.old pending.old candidates.old direct.old inputs.old empty:fleet]
+$  action
  $%  [%register project=project:nc]
      [%open id=@ux project=@t objective=@t selection=selection:np key=@tas grant=@ux worker=@p]
      [%open-paused id=@ux project=@t objective=@t selection=selection:np key=@tas grant=@ux worker=@p expected=revision:nc]
      [%instruct id=@ux text=@t]
      [%run id=@ux]
      [%pause id=@ux cancel=?]
      [%resume id=@ux]
      [%select id=@ux selection=selection:np key=@tas worker=@p]
      [%observe id=@ux]
      [%terminal id=@ux nonce=@ux input=@t]
      [%terminal-at id=@ux nonce=@ux source=@ux input=@t]
      [%workspace-at-v1 id=@ux nonce=@ux source=@ux input=@t baseline=@ud head=(unit @ux)]
      [%git-proposal id=@ux nonce=@ux source=@ux selected=source-selection:git]
      [%artifact-proposal id=@ux nonce=@ux]
  ==
+$  public-session
  [session=session:nc phase=phase:sessions selection=selection:np worker=@p records=(list record:sessions) summary=@t sequence=@ud]
+$  enqueue-request
  [%native-coding-fleet-enqueue-session-v1 session=@ux nonce=@ux role=role:nf paths=(set path) dependencies=(set @ux)]
++  tool-key
  |=  r=tool-request:nc
  ^-  @ux
  (shax (jam [%native-coding-tool-v1 r]))
++  qpc-required
  ::  This library is hosted by Viki's QPC wrapper, including when the set is
  ::  empty. Missing/malformed wrapper state must not silently disable its law.
  |=  [b=bowl:gall id=@ux]
  ^-  ?
  =/  raw=*
    .^(* %gx /(scot %p our.b)/viki/(scot %da now.b)/qpc/required-sessions/noun)
  =/  saved
    (need ((soft ,[%qpc-session-gate-v1 %viki required=(set @ux)]) raw))
  (~(has in required.saved) id)
++  qpc-result-known
  ::  A same-ship poke alone is not proof of a tool result. Join Cantrip's
  ::  retained request and result before adding an alternative to the pool.
  |=  [b=bowl:gall key=@ux wanted=tool-request:nc r=tool-result:nc]
  ^-  ?
  ?.  (agent-live:guard our.b now.b %cantrip)  %.n
  =/  raw=*
    .^(* %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/tool-state/noun)
  =/  state  ((soft organ:tool-law) raw)
  ?~  state  %.n
  =/  record  (~(get by records.u.state) key)
  ?~  record  %.n
  &(=(wanted request.u.record) =(`r result.u.record))
++  public
  |=  e=entry:sessions
  ^-  public-session
  [session.e phase.e selection.e worker.e records.e summary.e sequence.e]
++  changed
  |=  [id=@ux sequence=@ud]
  ^-  card
  [%give %fact ~[/native-coding] %noun !>([%native-coding-changed-v1 id sequence])]
++  refused
  |=  [id=@ux reason=@tas]
  ^-  card
  [%give %fact ~[/native-coding] %noun !>([%native-coding-refused-v1 id reason])]
++  poke
  |=  [our=@p target=@tas wire=wire value=*]
  ^-  card
  [%pass wire %agent [our target] %poke ?:(=(%graf target) %graf-action %noun) !>(value)]
++  run-card
  |=  [our=@p id=@ux]
  ^-  card
  (poke our %viki /native-coding/run [%native-coding-action-v1 [%run id]])
++  context
  |=  [e=entry:sessions request=@ux]
  ^-  context:nc
  [project.session.e configuration.e id.session.e request owner.session.e working.session.e]
++  apply
  |=  [b=bowl:gall held=state next=transition:sessions]
  ^-  (quip card state)
  =/  e=entry:sessions  entry.next
  =/  id=@ux  id.session.e
  =.  held  held(sessions (~(put by sessions.held) id e))
  =/  cards=(list card)  ~[(changed id sequence.e)]
  =/  effects=(list effect:sessions)  effects.next
  |-  ^-  (quip card state)
  ?~  effects  [cards held]
  =/  effect=effect:sessions  i.effects
  =/  added=(list card)
    ?-  -.effect
      %retain
        ~[(poke our.b %graf /native-coding/retain [%attest [%native-coding-session-record-v1 session.effect record.effect]])]
      %retain-context
        ~[(poke our.b %graf /native-coding/prepared-context [%attest (receipt-fact:frozen value.effect)])]
      %infer
        =/  bound  (~(get by bindings.held) id)
        ?~  bound  ~[(refused id %provider-binding-missing)]
        ::  Every provider call gets a loop-law deadline (see +deadline).
        =/  limit=@dr  request-timeout.pol:(law:loop-law our.b now.b %host-law)
        =/  timer=(list card)
          ?:  =(~s0 limit)  ~
          ~[[%pass /native-coding/deadline/(scot %ux id)/(scot %ux id.request.effect) %arvo %b %wait (add now.b limit)]]
        ?.  =(our.b worker.effect)
          =/  card  (request-card:fleet fleet.held e %infer)
          ?:  ?=(%| -.card)  ~[(refused id p.card)]
          [p.card timer]
        [(poke our.b (transport:provider selection.request.effect) /native-coding/infer [%native-coding-infer provider-key.u.bound request.effect]) timer]
      %cancel
        ?.  =(our.b worker.effect)
          =/  card  (request-card:fleet fleet.held e %cancel)
          ?:  ?=(%| -.card)  ~[(refused id p.card)]
          ~[p.card]
        ~[(poke our.b (transport:provider selection.e) /native-coding/cancel [%native-coding-cancel request.effect])]
      %judge
        ::  A model's completion is only a request for native judgment.
        :~  (poke our.b %graf /native-coding/judgment [%attest [%native-coding-judgment-required-v1 session.effect request.effect evidence.effect]])
            (poke our.b %viki /native-coding/judge [%native-coding-judge-v1 session.effect request.effect])
        ==
      %tool  ~
    ==
  ?.  ?=(%tool -.effect)
    $(effects t.effects, cards (weld cards added))
  =/  config  (resolve:session-project our.b now.b projects.held id project.session.e)
  =/  bound  (~(get by bindings.held) id)
  ?:  ?=(%| -.config)  [(weld cards ~[(refused id p.config)]) held]
  ?~  bound  [(weld cards ~[(refused id %grant-binding-missing)]) held]
  =/  source  (current:projects our.b now.b p.config)
  ?:  ?=(%| -.source)  [(weld cards ~[(refused id p.source)]) held]
  ?.  =(working.session.e revision.working.p.source)
    [(weld cards ~[(refused id %source-changed)]) held]
  =/  decoded
    (decode:codec (context e request.effect) revision.accepted.p.source call.effect)
  ?:  ?=(%| -.decoded)
    =/  result=tool-result:nc
      [%native-coding-tool-result-v1 (context e request.effect) id.call.effect [%refused p.decoded 'Malformed native tool proposal']]
    =/  failed
      ?:  (qpc-required b id)  (result:qpc now.b e result 'Malformed native tool proposal; use the advertised schema.')
      (result:sessions now.b e result 'Malformed native tool proposal; use the advertised schema.')
    ?:  ?=(%| -.failed)  [(weld cards ~[(refused id p.failed)]) held]
    =/  advanced  (apply b held p.failed)
    [(weld cards -.advanced) +.advanced]
  =/  request=tool-request:nc  p.decoded
  ?.  (tool-claimed our.b now.b held e request)
    =/  denial=tool-result:nc
      [%native-coding-tool-result-v1 context.request call-id.request [%refused %fleet-file-not-reserved 'The task does not reserve this exact file.']]
    =/  denied
      ?:  (qpc-required b id)  (result:qpc now.b e denial 'Refused: file is outside the task reservation.')
      (result:sessions now.b e denial 'Refused: file is outside the task reservation.')
    ?:  ?=(%| -.denied)  [(weld cards ~[(refused id p.denied)]) held]
    =/  out  (apply b held p.denied)
    [(weld cards -.out) +.out]
  =/  key=@ux  (tool-key request)
  =.  held  held(pending (~(put by pending.held) key request))
  =/  card=card
    (poke our.b %cantrip /native-coding/tool/(scot %ux key) [%native-coding-execute-v1 grant.u.bound request])
  $(effects t.effects, cards (weld cards ~[card]))
++  act
  |=  [b=bowl:gall held=state a=action]
  ^-  (quip card state)
  ?.  =(our.b src.b)  [~ held]
  ?:  ?=(%workspace-at-v1 -.a)
    (workspace-command b held id.a nonce.a source.a input.a baseline.a head.a)
  ?:  ?=(%artifact-proposal -.a)  (artifact-command b held id.a nonce.a)
  ?:  ?=(%git-proposal -.a)  (git-command b held id.a nonce.a source.a selected.a)
  ?:  ?=(%terminal -.a)  (terminal-command b held id.a nonce.a input.a)
  ?:  ?=(%terminal-at -.a)
    =/  found  (~(get by sessions.held) id.a)
    ?~  found  [~[(refused id.a %session-missing)] held]
    ::  Check the read's entire revision here, inside Viki's event, before the
    ::  existing tool path rereads Clay and binds the proposal to that revision.
    ?.  =(source.a (shax (jam working.session.u.found)))
      [~[(refused id.a %source-changed)] held]
    =/  nonce=@ux  (request-at:terminal id.a nonce.a source.a input.a)
    (terminal-command b held id.a nonce input.a)
  ?:  ?=(%register -.a)
    ?.  &((valid:projects project.a) =(our.b authority.spec.project.a))
      [~[(refused 0x0 %project-invalid)] held]
    =/  catalog  (catalog:projects our.b now.b project.a)
    ?:  ?=(%| -.catalog)  [~[(refused 0x0 p.catalog)] held]
    =/  source  (current:projects our.b now.b project.a)
    ?:  ?=(%| -.source)  [~[(refused 0x0 p.source)] held]
    [~[(changed 0x0 0)] held(projects (~(put by projects.held) id.spec.project.a project.a))]
  ?:  ?=(?(%open %open-paused) -.a)
    =/  expected=(unit revision:nc)
      ?.  ?=(%open-paused -.a)  ~
      `expected.a
    ::  Keep the original opening layout; its final worker has a different
    ::  axis in the extended command. The optional pin selects paused start.
    =/  a=[%open id=@ux project=@t objective=@t selection=selection:np key=@tas grant=@ux worker=@p]
      ?:  ?=(%open -.a)  a
      [%open id.a project.a objective.a selection.a key.a grant.a worker.a]
    ?:  (~(has by sessions.held) id.a)  [~[(refused id.a %session-exists)] held]
    ?:  (gte ~(wyt by sessions.held) session-limit:sessions)  [~[(refused id.a %session-capacity)] held]
    ?.  (selection-bound our.b held id.a selection.a worker.a key.a)
      [~[(refused id.a %fleet-placement-mismatch)] held]
    =/  config  (resolve:session-project our.b now.b projects.held id.a project.a)
    ?:  ?=(%| -.config)  [~[(refused id.a p.config)] held]
    =/  catalog  (catalog:projects our.b now.b p.config)
    ?:  ?=(%| -.catalog)  [~[(refused id.a p.catalog)] held]
    ?.  (member:projects p.config p.catalog src.b %read)  [~[(refused id.a %project-access-refused)] held]
    =/  source  (current:projects our.b now.b p.config)
    ?:  ?=(%| -.source)  [~[(refused id.a p.source)] held]
    =/  issue=(unit @tas)
      ?~  expected  ~
      ?.  =(our.b worker.a)  `%paused-open-local-only
      (read:paused-open b id.a grant.a p.config u.expected revision.working.p.source)
    ?^  issue  [~[(refused id.a u.issue)] held]
    =/  s=session:nc
      [%native-coding-session-v1 id.a project.a our.b revision.working.p.source ~ objective.a ~]
    =/  context=@t
      (rap 3 ~['Project: ' project.a '\0aInstructions: ' instructions.p.config '\0aConventions: ' conventions.p.config '\0aUse native tools to read exact source. Working desk: ' (scot %tas working.p.config) '\0aRevision: ' (scot %ud number.working.s) '\0aRoot: ' (scot %uv root.working.s)])
    =/  opened
      ?^  expected
        (begin:paused-open our.b src.b now.b s (configuration:projects p.config) selection.a context)
      (begin:sessions our.b src.b now.b s (configuration:projects p.config) selection.a worker.a context)
    ?:  ?=(%| -.opened)  [~[(refused id.a p.opened)] held]
    =.  held  held(bindings (~(put by bindings.held) id.a [key.a grant.a]))
    =/  accepted  (apply b held p.opened)
    ?:  |(?=(^ expected) !=(worker.a our.b))  accepted
    [(weld -.accepted ~[(run-card our.b id.a)]) +.accepted]
  =/  sid=@ux
    ?-  -.a
      %instruct  id.a
      %run  id.a
      %pause  id.a
      %resume  id.a
      %select  id.a
      %observe  id.a
    ==
  =/  found  (~(get by sessions.held) sid)
  ?~  found  [~[(refused sid %session-missing)] held]
  =/  e=entry:sessions  u.found
  ?:  ?=(%observe -.a)
    ?.  =(our.b owner.session.e)  [~[(refused sid %owner-required)] held]
    =/  tools=(list card)
      %+  murn  ~(tap by pending.held)
      |=  [key=@ux request=tool-request:nc]
      ?.  (scoped:observation our.b sid request)  ~
      =/  observed  (read:observation our.b now.b sid key request)
      ?:  ?=(%| -.observed)  `(refused sid p.observed)
      `(card:observation our.b key)
    =/  cards=(list card)  [(changed sid sequence.e) tools]
    ?~  pending.e  [cards held]
    ?:  =(our.b worker.e)
      =/  target=@tas  (transport:provider selection.u.pending.e)
      ?.  (agent-live:guard our.b now.b target)
        [(weld cards ~[(refused sid %provider-unavailable)]) held]
      [(weld cards ~[(poke our.b target /native-coding/observe-provider/(scot %ux id.u.pending.e) [%native-coding-observe id.u.pending.e])]) held]
    =/  card  (request-card:fleet fleet.held e %observe)
    ?:  ?=(%| -.card)  [(weld cards ~[(refused sid p.card)]) held]
    [(weld cards ~[p.card]) held]
  ?:  ?=(%select -.a)
    ?.  (selection-bound our.b held sid selection.a worker.a key.a)
      [~[(refused sid %fleet-placement-mismatch)] held]
    (advance-action b held a)
  ?:  &(?=(%run -.a) !=(our.b worker.e))
    =/  assigned  (assigned:fleet fleet.held sid)
    ?~  assigned  [~[(refused sid %fleet-task-not-assigned)] held]
    ?:  =(%review phase.u.assigned)
      ::  The later Viki event joins the retained review/Cantrip decision before
      ::  resuming this assignment. Ordinary assigned/running turns stay direct.
      [~[(poke our.b %viki /native-fleet-progress [%native-coding-fleet-progress-v1 sid])] held]
    ?.  ?=(?(%assigned %running) phase.u.assigned)
      [~[(refused sid %fleet-task-paused)] held]
    (advance-action b held a)
  (advance-action b held a)
++  instruction-ready
  ::  A queued/missing review is unresolved too. Never bypass its Clay effects.
  |=  [b=bowl:gall held=state id=@ux]
  ^-  (each ~ @tas)
  ?.  =(our.b src.b)  [%| %owner-required]
  ?:  (lien ~(val by pending.held) |=(r=tool-request:nc =(id session.context.r)))
    [%| %instruction-tool-pending]
  =/  session  (~(get by sessions.held) id)
  ?~  session  [%| %session-missing]
  =/  candidates=(list candidate:nc)
    (skim ~(val by candidates.held) |=(c=candidate:nc =(id session.context.c)))
  |-  ^-  (each ~ @tas)
  ?~  candidates  [%& ~]
  ?.  (agent-live:guard our.b now.b %cantrip)  [%| %instruction-review-unavailable]
  =/  c=candidate:nc  i.candidates
  =/  canonical=(unit record:acceptance)
    .^((unit record:acceptance) %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/candidate/(scot %ux id.c)/noun)
  ?~  canonical  [%| %instruction-review-unconfirmed]
  ?.  =(c candidate.u.canonical)  [%| %instruction-review-mismatch]
  ?.  ?=(?(%applied %refused) stage.u.canonical)
    [%| %instruction-review-pending]
  ::  Cantrip completion alone is insufficient: Viki must already have
  ::  consumed that exact row, advancing source or recording the revision.
  =/  receipt=@ux  (digest:acceptance u.canonical)
  ?.  (lien records.u.session |=(r=record:sessions ?.(?=(%judgment -.body.r) %.n &(=(%continue verdict.body.r) (~(has in (silt evidence.body.r)) receipt)))))
    [%| %instruction-review-not-settled]
  $(candidates t.candidates)
++  advance-action
  |=  [b=bowl:gall held=state a=action]
  ^-  (quip card state)
  ?>  ?=(?(%instruct %pause %resume %select %run) -.a)
  ?:  ?=(%run -.a)  (prepare-run b held id.a)
  =/  aid=@ux
    ?-  -.a
      %instruct  id.a
      %pause  id.a
      %resume  id.a
      %select  id.a
    ==
  =/  e=entry:sessions  (~(got by sessions.held) aid)
  =/  permission=(each ~ @tas)
    ?.  &(?=(%instruct -.a) |(=(%judgment phase.e) =(%judgment resume.e)))  [%& ~]
    (instruction-ready b held aid)
  ?:  ?=(%| -.permission)
    ?>  ?=(%instruct -.a)
    ?.  &(=(our.b src.b) =(our.b owner.session.e) (text-valid:sessions text.a))
      [~[(refused aid %instruction-invalid)] held]
    ::  Keep the submitted text visible, but do not change the objective that
    ::  an outstanding review still must settle. This is not an instruction.
    =/  denied  (append:sessions e now.b [%terminal text.a 'Instruction not applied: observe candidate review, then submit this instruction again.'])
    ?:  ?=(%| -.denied)  [~[(refused aid p.denied)] held]
    =/  out  (apply b held p.denied)
    [(weld -.out ~[(refused aid p.permission)]) +.out]
  =/  next=(each transition:sessions @tas)
    ?-  -.a
      %instruct  (instruct:sessions our.b src.b now.b e text.a)
      %pause  (pause:sessions our.b src.b now.b e cancel.a)
      %resume  (resume:sessions our.b src.b now.b e)
      %select  (select:sessions our.b src.b now.b e selection.a worker.a)
    ==
  ?:  ?=(%| -.next)  [~[(refused aid p.next)] held]
  =/  continuation=[value=transition:sessions reason=(unit @tas)]
    ?.  &(?=(%instruct -.a) =(%paused phase.entry.p.next) =(%judgment resume.entry.p.next) ?=(~ pending.entry.p.next) ?=(~ calls.entry.p.next))  [p.next ~]
    =/  continued  (continue-instruction:sessions our.b src.b now.b p.next)
    ?:  ?=(%| -.continued)  [p.next `p.continued]
    [p.continued ~]
  =.  next  [%& value.continuation]
  =.  held
    ?.  ?=(%select -.a)  held
    =/  bound  (~(get by bindings.held) aid)
    ?~  bound  held
    held(bindings (~(put by bindings.held) aid u.bound(provider-key key.a)))
  =/  fleet-cards=(list card)  ~
  =/  assigned  (assigned:fleet fleet.held aid)
  =/  fleet-next=(each transition:nf @tas)
    ?~  assigned  [%| %local-session]
    ?:  ?=(%pause -.a)
      (control:fleet-law our.b src.b fleet.fleet.held id.task.u.assigned %pause)
    ?:  ?=(%resume -.a)
      ?:  !=(%paused phase.u.assigned)  [%| %fleet-already-resumed]
      (resume:fleet-law our.b src.b fleet.fleet.held id.task.u.assigned)
    [%| %no-fleet-change]
  =/  moved=(quip card state:fleet)
    ?:  ?=(%| -.fleet-next)  [~ fleet.held]
    (effects:fleet our.b fleet.held sessions.held p.fleet-next)
  =.  held  held(fleet +.moved)
  =.  fleet-cards  -.moved
  =/  out  (apply b held p.next)
  =.  out  [(weld fleet-cards -.out) +.out]
  =.  out
    ?~  reason.continuation  out
    [(weld -.out ~[(refused aid u.reason.continuation)]) +.out]
  ?:  ?=(%pause -.a)
    ?:  cancel.a  (interrupt-tools b out aid)
    out
  =/  resumed=entry:sessions  (~(got by sessions.+.out) aid)
  ?:  =(%ready phase.resumed)  [(weld -.out ~[(run-card our.b aid)]) +.out]
  out
++  interrupt-tools
  ::  Interrupt preserves the pause and original pending requests. The same
  ::  canonical handle check used by /cancel admits each local cancellation.
  |=  [b=bowl:gall out=(quip card state) id=@ux]
  ^-  (quip card state)
  =/  rows=(list [@ux tool-request:nc])
    (skim ~(tap by pending.+.out) |=([key=@ux request=tool-request:nc] =(id session.context.request)))
  |-  ^-  (quip card state)
  ?~  rows  out
  =/  observed  (cancel:observation our.b now.b id -.i.rows +.i.rows)
  =/  text=@t
    ?:  ?=(%& -.observed)  text.p.observed
    (rap 3 ~[(scot %ux -.i.rows) ' · Cancellation refused: ' p.observed '. Session remains paused; the original request is retained for observation.\0a'])
  =/  held=state  +.out
  =/  e=entry:sessions  (~(got by sessions.held) id)
  =/  next  (append:sessions e now.b [%terminal '/interrupt' text])
  ?:  ?=(%| -.next)
    $(rows t.rows, out [(weld -.out ~[(refused id p.next)]) held])
  =/  kept  (apply b held p.next)
  =/  added=(list card)
    ?:  ?=(%| -.observed)  ~[(refused id p.observed)]
    cards.p.observed
  $(rows t.rows, out [(weld -.out (weld -.kept added)) +.kept])
++  prepare-run
  ::  Refresh bounded exact-source context before each request. Compression
  ::  replaces only provider context; the complete journal stays retained.
  |=  [b=bowl:gall held=state id=@ux]
  ^-  (quip card state)
  =/  e=entry:sessions  (~(got by sessions.held) id)
  =/  managed=?  (qpc-required b id)
  ?:  &(managed (sealed:qpc e))  [~[(refused id %qpc-pool-sealed)] held]
  ?:  &(managed !=(our.b worker.e))  [~[(refused id %qpc-local-model-required)] held]
  ?.  &(=(%ready phase.e) ?=(~ pending.e) ?=(~ calls.e))  [~[(refused id %session-not-ready)] held]
  =/  config  (resolve:session-project our.b now.b projects.held id project.session.e)
  ?:  ?=(%| -.config)  [~[(refused id p.config)] held]
  =/  bound  (~(get by bindings.held) id)
  ?~  bound  [~[(refused id %grant-binding-missing)] held]
  ?.  (agent-live:guard our.b now.b %cantrip)  [~[(refused id %grant-context-unavailable)] held]
  ?.  =(configuration.e (configuration:projects p.config))
    [~[(refused id %grant-context-mismatch)] held]
  =/  raw-grant=*
    .^(* %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/grant/(scot %ux grant.u.bound)/noun)
  =/  granted  (observe:grant-context our.b grant.u.bound id owner.session.e configuration.e raw-grant)
  ?:  ?=(%| -.granted)  [~[(refused id p.granted)] held]
  ::  Reserve the actual one-request prefix before admitting source pages.
  =/  prefix=@t
    ?:  managed  instructions:qpc
    'Viki directs this coding session. Tool calls are proposals governed by Cantrip. Never invent tool results or permissions.'
  =.  prefix  (cat 3 prefix p.granted)
  =/  request=[prefix=@t tools=(list tool:np)]
    ::  Owner-only one-request enrollment. Its exact instructions are frozen
    ::  with its tools by the context receipt before inference is dispatched.
    =/  base=(list tool:np)  ?:(managed tools:qpc tools:codec)
    =/  raw=*
      .^(* %gx /(scot %p our.b)/viki/(scot %da now.b)/qpc/observation-plan/(scot %ux id)/noun)
    =/  plan  (need ((soft ,(unit [manifest=manifest:qpc-observation armed=armed:qpc-observation])) raw))
    ?~  plan  [prefix base]
    =/  observation-state=state:qpc-observation
      [(malt ~[[(digest:qpc-observation manifest.u.plan) manifest.u.plan]]) (malt ~[[id armed.u.plan]]) ~]
    [(prefix:qpc-observation observation-state e prefix) (request-tools:qpc-observation observation-state e base)]
  ::  The context law lives in %host-law, a desk with no agents, so a law
  ::  commit never runs an agent rebuild check (measured 11 min on host-viki).
  =/  law=law-state:context-read  (law:context-read our.b now.b %host-law)
  =/  detailed  (prepare-for:context-read law our.b now.b p.config session.e ~ project.session.e prefix.request)
  ?:  ?=(%| -.detailed)  [~[(refused id p.detailed)] held]
  =/  packet=packet:context-read  packet.p.detailed
  =.  e  e(source-context text.packet)
  =/  cards=(list card)
    ~[(poke our.b %graf /native-coding/context [%attest [%native-coding-context-v1 id packet]])]
  =/  prepared=(quip card state)
    ?:  &((lth (lent history.e) 160) (lth (wire-bytes:provider-request selection.e history.e) prepared-limit.lim.law))
      [~ held(sessions (~(put by sessions.held) id e))]
    =/  compact  (compress:context-read law our.b now.b p.config e)
    ?:  ?=(%| -.compact)  [~[(refused id p.compact)] held]
    =/  checkpoint  (checkpoint:sessions our.b our.b now.b e text.p.compact through.p.compact history.p.compact)
    ?:  ?=(%| -.checkpoint)  [~[(refused id p.checkpoint)] held]
    =/  out  (apply b held p.checkpoint)
    [(weld -.out ~[(poke our.b %graf /native-coding/continuation [%attest [%native-coding-continuation-v1 id p.compact]])]) +.out]
  =/  ready=entry:sessions  (~(got by sessions.+.prepared) id)
  ::  A refused checkpoint leaves the old history intact and cannot dispatch.
  ?:  |((gte (lent history.ready) 160) (gte (wire-bytes:provider-request selection.ready history.ready) prepared-limit.lim.law))  [(weld cards -.prepared) +.prepared]
  =/  next  (dispatch:sessions now.b ready tools.request prefix.request 16.384)
  ?:  ?=(%| -.next)  [(weld cards (weld -.prepared ~[(refused id p.next)])) +.prepared]
  ?>  ?=(^ pending.entry.p.next)
  =/  receipt  (freeze:context-read lim.law our.b worker.ready session.ready p.detailed u.pending.entry.p.next prefix.request)
  ?:  ?=(%| -.receipt)  [(weld cards (weld -.prepared ~[(refused id p.receipt)])) +.prepared]
  =/  retained  (retain-context:sessions now.b p.next p.receipt)
  ?:  ?=(%| -.retained)  [(weld cards (weld -.prepared ~[(refused id p.retained)])) +.prepared]
  =/  out  (apply b +.prepared p.retained)
  [(weld cards (weld -.prepared -.out)) +.out]
++  model-event
  |=  [b=bowl:gall held=state id=@ux session=@ux outcome=outcome:inference]
  ^-  (quip card state)
  ?.  =(our.b src.b)  [~ held]
  =/  found  (~(get by sessions.held) session)
  ?~  found  [~ held]
  =/  e=entry:sessions  u.found
  ?.  &(?=(^ pending.e) =(id id.u.pending.e))  [~ held]
  ?:  ?=(%pending -.outcome)  [~ held]
  =/  managed=?  (qpc-required b session)
  =/  cli=?  ?=(^ (cli-backend:provider selection.u.pending.e))
  =/  issue=(unit @tas)
    ?.  &(|(managed cli) ?=(%result -.outcome))  ~
    =/  binding  (~(get by bindings.held) session)
    ?~  binding  `%qpc-provider-binding-missing
    ?.  =(our.b worker.e)  `%qpc-local-model-required
    (confirm:qpc-evidence our.b now.b u.pending.e provider-key.u.binding value.outcome)
  ?^  issue  [~[(refused session u.issue)] held]
  =/  next=(each transition:sessions @tas)
    ?:  ?=(%result -.outcome)
      ?:  managed  (model:qpc now.b e value.outcome)
      (model:sessions now.b e value.outcome)
    ?:  ?=(%refused -.outcome)
      (append:sessions e(pending ~, phase %refused, resume %ready) now.b [%status %refused reason.outcome])
    ?:  ?=(%failed -.outcome)
      ?:  cli
        (append:sessions e(pending ~, phase %refused, resume %ready) now.b [%status %refused reason.error.outcome])
      ::  A transient provider failure (statuses and limit are loop law, read
      ::  from %host-law now) is not a refusal: return to ready, or stay
      ::  paused, and redispatch below; the journal records each retry.
      ?:  (retry:loop-law pol:(law:loop-law our.b now.b %host-law) error.outcome (gateway-retries:sessions e))
        =/  paused=?  =(%paused phase.e)
        (append:sessions e(pending ~, phase ?:(paused %paused %ready), resume %ready) now.b [%status %ready %provider-gateway-retry])
      (append:sessions e(pending ~, phase %refused, resume %ready) now.b [%status %refused reason.error.outcome])
    ?:  ?=(%cancelled -.outcome)
      ?:  cli
        (append:sessions e(pending ~, phase %paused, resume %ready) now.b [%status %paused %cancelled])
      ::  A cancellation the deadline asked for is a transient provider
      ::  failure (same retry budget); an owner's interrupt still pauses.
      ?.  (noted:sessions e %provider-deadline)
        (append:sessions e(pending ~, phase %paused, resume %ready) now.b [%status %paused %cancelled])
      ?:  (lth (gateway-retries:sessions e) retry-limit.pol:(law:loop-law our.b now.b %host-law))
        =/  paused=?  =(%paused phase.e)
        (append:sessions e(pending ~, phase ?:(paused %paused %ready), resume %ready) now.b [%status %ready %provider-gateway-retry])
      (append:sessions e(pending ~, phase %refused, resume %ready) now.b [%status %refused %provider-deadline])
    (uncertain:sessions now.b e id -.outcome)
  ?:  ?=(%| -.next)  [~[(refused session p.next)] held]
  =/  out  (apply b held p.next)
  ?.  &(?=(?(%failed %cancelled) -.outcome) =(%ready phase.entry.p.next))  out
  [(weld -.out ~[(run-card our.b session)]) +.out]
++  deadline
  ::  A provider call still pending at its loop-law deadline is cancelled.
  ::  The journal note first, so the cancellation is retried (model-event)
  ::  rather than read as an owner's interrupt. A finished call is a no-op.
  |=  [b=bowl:gall held=state session=@ux request=@ux]
  ^-  (quip card state)
  =/  found  (~(get by sessions.held) session)
  ?~  found  [~ held]
  =/  e=entry:sessions  u.found
  =/  pending  pending.e
  ?~  pending  [~ held]
  ?.  =(request id.u.pending)  [~ held]
  ::  A CLI-routed request that no connector has claimed yet is still waiting
  ::  for a worker, not for a model: wait another law timeout (bounded by the
  ::  law's unclaimed-waits) instead of cancelling it (ptf-5822, 2026-10-31).
  ::  The journal records every wait; the connector's claim ends the waiting.
  =/  pol  pol:(law:loop-law our.b now.b %host-law)
  ?:  ?&  (unclaimed-by-cli our.b now.b u.pending)
          (lth (unclaimed-waits:sessions e) unclaimed-waits.pol)
          !=(~s0 request-timeout.pol)
      ==
    =/  waited  (append:sessions e now.b [%status phase.e %provider-unclaimed-wait])
    ?:  ?=(%| -.waited)  [~ held]
    =/  out  (apply b held p.waited)
    =/  timer=(list card)
      ~[[%pass /native-coding/deadline/(scot %ux session)/(scot %ux request) %arvo %b %wait (add now.b request-timeout.pol)]]
    [(weld -.out timer) +.out]
  =/  next  (append:sessions e now.b [%status phase.e %provider-deadline])
  ?:  ?=(%| -.next)  [~ held]
  (apply b held p.next(effects (weld effects.p.next `(list effect:sessions)`~[[%cancel worker.e request]])))
++  unclaimed-by-cli
  ::  True only when the request rides the CLI route and its CLI job is read
  ::  back as queued with no claim. Any other state, or no readable CLI brain,
  ::  means the ordinary deadline applies.
  |=  [our=@p now=@da pending=request:np]
  ^-  ?
  ?~  (cli-backend:provider selection.pending)  %.n
  ?.  (agent-live:guard our now %cli-inference)  %.n
  =/  job=(unit job:clisur)
    .^((unit job:clisur) %gx /(scot %p our)/cli-inference/(scot %da now)/job/(scot %ux id.pending)/noun)
  ?~  job  %.n
  &(=(%queued phase.u.job) ?=(~ claim.u.job))
++  tool-release-wake
  ::  A newly freed desk is a queue event, never a retry of a consumed wake.
  ::  Compare before/after pending maps after apply, which may queue another
  ::  tool immediately. Unknown outcomes keep their key and cannot wake work.
  |=  [our=@p key=@ux previous=(map @ux tool-request:nc) out=(quip card state)]
  ^-  (quip card state)
  =/  released  (~(get by previous) key)
  ?~  released  out
  ?.  =(our owner.source.context.u.released)  out
  =/  held=state  +.out
  ?:  (~(has by pending.held) key)  out
  =/  desk=@tas  desk.source.context.u.released
  ?:  (~(has in (blocked-desks held)) desk)  out
  ?.  %+  lien  (ready:fleet-law fleet.fleet.held)
      |=  queued=entry:nf
      &(=(our owner.source.context.task.queued) =(desk desk.source.context.task.queued))
    out
  =/  moved
    (effects:fleet our fleet.held sessions.held (changed:fleet-law fleet.fleet.held ~))
  [(weld -.out -.moved) held(fleet +.moved)]
++  tool-event
  |=  [b=bowl:gall held=state r=tool-result:nc]
  ^-  (quip card state)
  ?.  =(our.b src.b)  [~ held]
  =/  matches=(list [@ux tool-request:nc])
    (skim ~(tap by pending.held) |=([key=@ux wanted=tool-request:nc] &(=(context.wanted context.r) =(call-id.wanted call-id.r))))
  ?~  matches  [~ held]
  ?^  t.matches  [~ held]
  =/  key=@ux  -.i.matches
  =/  previous=(map @ux tool-request:nc)  pending.held
  =/  found  (~(get by sessions.held) session.context.r)
  ?~  found  [~ held]
  =/  managed=?  (qpc-required b session.context.r)
  ?:  &(managed !(qpc-result-known b key +.i.matches r))
    [~[(refused session.context.r %qpc-tool-result-unconfirmed)] held]
  =/  text  (result-text:codec r)
  ?:  ?=(%| -.text)  [~[(refused session.context.r p.text)] held]
  ?:  (~(has by direct.held) key)  (direct-result b held key r p.text)
  =/  proposed=?  ?=(%candidate -.output.r)
  =/  original=entry:sessions  u.found
  =/  next
    ?:  managed  (result:qpc now.b original r p.text)
    (result:sessions now.b ?:(proposed original(phase %paused) original) r p.text)
  ?:  ?=(%| -.next)  [~[(refused session.context.r p.next)] held]
  =.  next
    ?:  managed  next
    ?:  proposed
      next(p p.next(entry entry.p.next(phase ?:(=(%paused phase.original) %paused %judgment), resume %judgment)))
    ::  Unconfirmed cancellation must not erase the owner's pause and allow
    ::  a later confirmed result to restart the remaining model tool calls.
    ?:  &(=(%paused phase.original) ?=(%unknown -.output.r))
      next(p p.next(entry entry.p.next(phase %paused)))
    next
  =.  held
    ?:  ?=(%unknown -.output.r)  held
    held(pending (~(del by pending.held) key))
  =.  held
    ?:  ?=(%candidate -.output.r)  held(candidates (~(put by candidates.held) id.value.output.r value.output.r))
    held
  =/  out  (tool-release-wake our.b key previous (apply b held p.next))
  =/  e=entry:sessions  entry.p.next
  ?:  managed
    ?.  (sealed:qpc e)  out
    [(weld -.out ~[(poke our.b %viki /qpc/seal [%qpc-pool-seal-v1 id.session.e])]) +.out]
  ?:  ?=(%candidate -.output.r)
    [(weld -.out ~[(poke our.b %viki /native-coding/review-start [%native-coding-review-action-v1 [%start id.value.output.r]])]) +.out]
  ?:  =(%ready phase.e)  [(weld -.out ~[(run-card our.b id.session.e)]) +.out]
  out
++  artifact-command
  ::  No source effect here. Existing Cantrip standing scope, candidate checks,
  ::  current Viki review decision and final landing gates remain mandatory.
  |=  [b=bowl:gall held=state id=@ux nonce=@ux]
  ^-  (quip card state)
  ?.  &(=(our.b src.b) (identifier:tool-law nonce))  [~[(refused id %artifact-identity)] held]
  =/  input=@t  (call-id:artifact nonce)
  =/  prior  (~(get by inputs.held) nonce)
  ?^  prior
    ?.  =(u.prior [id input])  [~[(refused id %artifact-request-conflict)] held]
    [~[(changed id 0)] held]
  ?:  (gte ~(wyt by inputs.held) 4.096)  [~[(refused id %terminal-history-capacity)] held]
  =/  found  (~(get by sessions.held) id)
  ?~  found  [~[(refused id %session-missing)] held]
  =/  e=entry:sessions  u.found
  ?.  =(our.b owner.session.e)  [~[(refused id %owner-required)] held]
  =/  reject
    |=  reason=@tas
    ^-  (quip card state)
    =/  next  (append:sessions e now.b [%terminal input (cat 3 'Artifact proposal refused: ' reason)])
    ?:  ?=(%| -.next)  [~[(refused id p.next)] held]
    =/  out  (apply b held(inputs (~(put by inputs.held) nonce [id input])) p.next)
    [(weld -.out ~[(refused id reason)]) +.out]
  ?:  |(=(%judgment phase.e) =(%judgment resume.e))  (reject %candidate-review-pending)
  ?.  &(?=(~ pending.e) ?=(~ calls.e))  (reject %turn-still-pending)
  ?:  (lien ~(val by pending.held) |=(r=tool-request:nc =(id session.context.r)))
    (reject %tool-still-pending)
  =/  config  (resolve:session-project our.b now.b projects.held id project.session.e)
  ?:  ?=(%| -.config)  (reject p.config)
  =/  current  (current:projects our.b now.b p.config)
  ?:  ?=(%| -.current)  (reject p.current)
  ?.  =(working.session.e revision.working.p.current)  (reject %source-changed)
  =/  captured  (read-context:artifact our.b now.b nonce)
  ?:  ?=(%| -.captured)  (reject p.captured)
  ?.  =(id session.command.entry.p.captured)  (reject %artifact-session-mismatch)
  =/  arguments  (tool-arguments:artifact our.b now.b p.captured p.config working.p.current)
  ?:  ?=(%| -.arguments)  (reject p.arguments)
  =/  bound  (~(get by bindings.held) id)
  ?~  bound  (reject %grant-binding-missing)
  =/  request=tool-request:nc
    [%native-coding-tool-request-v1 (context e nonce) input p.arguments]
  ?.  (tool-claimed our.b now.b held e request)  (reject %fleet-file-not-reserved)
  =/  next  (append:sessions e(phase %tools, resume phase.e) now.b [%terminal input 'Native tool submitted.'])
  ?:  ?=(%| -.next)  [~[(refused id p.next)] held]
  =/  key=@ux  (tool-key request)
  =.  held
    held(inputs (~(put by inputs.held) nonce [id input]), pending (~(put by pending.held) key request), direct (~(put by direct.held) key id))
  =/  out  (apply b held p.next)
  [(weld -.out ~[(poke our.b %cantrip /native-coding/tool/(scot %ux key) [%native-coding-execute-v1 grant.u.bound request])]) +.out]
++  git-command
  ::  Owner identities only. Persist one request before dispatch; never replay it.
  |=  [b=bowl:gall held=state id=@ux nonce=@ux source=@ux selected=source-selection:git]
  ^-  (quip card state)
  ?.  &(=(our.b src.b) !=(0 nonce) !=(0 source) (lte (met 0 nonce) 256) (lte (met 0 source) 256))
    [~[(refused id %proposal-identity-invalid)] held]
  =/  request-id=@ux  (candidate-identity:git selected nonce source)
  =/  input=@t  (command-input:git (candidate-origin:git selected source) request-id)
  =/  prior  (~(get by inputs.held) request-id)
  ?^  prior
    ?.  =(u.prior [id input])  [~[(refused id %proposal-request-conflict)] held]
    [~[(changed id 0)] held]
  ?:  (gte ~(wyt by inputs.held) 4.096)  [~[(refused id %terminal-history-capacity)] held]
  =/  found  (~(get by sessions.held) id)
  ?~  found  [~[(refused id %session-missing)] held]
  =/  e=entry:sessions  u.found
  ?.  =(our.b owner.session.e)  [~[(refused id %owner-required)] held]
  =/  reject
    |=  reason=@tas
    ^-  (quip card state)
    =/  next  (append:sessions e now.b [%terminal input (cat 3 'Git proposal refused: ' reason)])
    ?:  ?=(%| -.next)  [~[(refused id p.next)] held]
    =/  out  (apply b held(inputs (~(put by inputs.held) request-id [id input])) p.next)
    [(weld -.out ~[(refused id reason)]) +.out]
  ?.  =(source (shax (jam working.session.e)))  (reject %source-changed)
  ?:  |(=(%judgment phase.e) =(%judgment resume.e))  (reject %candidate-review-pending)
  ?.  &(?=(~ pending.e) ?=(~ calls.e))  (reject %turn-still-pending)
  ?:  (lien ~(val by pending.held) |=(r=tool-request:nc =(id session.context.r)))
    (reject %tool-still-pending)
  =/  config  (resolve:session-project our.b now.b projects.held id project.session.e)
  ?:  ?=(%| -.config)  (reject p.config)
  =/  bound  (~(get by bindings.held) id)
  ?~  bound  (reject %grant-binding-missing)
  =/  plan  (read:git-read our.b now.b p.config (context e request-id) selected)
  ?:  ?=(%| -.plan)  (reject p.plan)
  =/  origin=proposal-origin:nc
    [repository.selected number.selected base.selected head.selected receipt.p.plan]
  =/  request=tool-request:nc
    [%native-coding-tool-request-v1 context.candidate.p.plan (scot %ux request-id) [%batch origin edits.candidate.p.plan]]
  ?.  (tool-claimed our.b now.b held e request)  (reject %fleet-file-not-reserved)
  =/  next  (append:sessions e(phase %tools, resume phase.e) now.b [%terminal input 'Native tool submitted.'])
  ?:  ?=(%| -.next)  [~[(refused id p.next)] held]
  =/  key=@ux  (tool-key request)
  =.  held
    held(inputs (~(put by inputs.held) request-id [id input]), pending (~(put by pending.held) key request), direct (~(put by direct.held) key id))
  =/  out  (apply b held p.next)
  [(weld -.out ~[(poke our.b %cantrip /native-coding/tool/(scot %ux key) [%native-coding-execute-v1 grant.u.bound request])]) +.out]
++  git-status
  |=  [held=state id=@ux request=@ux]
  ^-  candidate-status:git
  =/  out=candidate-status:git  [%native-coding-git-proposal-status-v1 id request %missing ~ ~]
  =/  input  (~(get by inputs.held) request)
  =/  found  (~(get by sessions.held) id)
  ?~  input  out
  ?~  found  out
  ?.  =(id session.u.input)  out
  =.  out  out(state %unknown)
  =/  rows=(list record:sessions)  records.u.found
  |-  ^-  candidate-status:git
  ?~  rows  out
  =/  row=record:sessions  i.rows
  ?:  ?=(%terminal -.body.row)
    ?.  =(input.u.input input.body.row)  $(rows t.rows)
    =/  submitted=?  =('Native tool submitted.' output.body.row)
    $(rows t.rows, out out(state ?:(submitted %pending %refused), reason ?:(submitted ~ `output.body.row)))
  ?.  ?=(%tool -.body.row)  $(rows t.rows)
  =/  result=tool-result:nc  result.body.row
  ?.  &(=(id session.context.result) =(request request.context.result))  $(rows t.rows)
  ?:  ?=(%candidate -.output.result)
    $(rows t.rows, out out(state %candidate, candidate `id.value.output.result, reason ~))
  ?:  ?=(%refused -.output.result)
    $(rows t.rows, out out(state %refused, reason `reason.output.result))
  $(rows t.rows, out out(state %unknown))
++  git-lookup
  |=  [held=state id=@ux origin=@ux]
  ^-  candidate-lookup:git
  =/  matching=(list @ux)
    %+  murn  ~(tap by inputs.held)
    |=  [request=@ux row=[session=@ux input=@t]]
    ?:(&(=(id session.row) =(input.row (command-input:git origin request))) `request ~)
  [%native-coding-git-proposal-lookup-v1 id origin (turn (scag 16 matching) |=(request=@ux (git-status held id request))) (lent matching)]
++  workspace-command
  ::  Opt-in request receipt; normal terminal actions retain their behavior.
  |=  [b=bowl:gall held=state id=@ux nonce=@ux source=@ux input=@t baseline=@ud head=(unit @ux)]
  ^-  (quip card state)
  ?.  &(=(our.b src.b) !=(0 nonce) (lte (met 0 nonce) 256) (lte (met 3 input) 65.536))
    [~[(refused id %workspace-input-invalid)] held]
  =/  found  (~(get by sessions.held) id)
  ?~  found  [~[(refused id %session-missing)] held]
  =/  before=entry:sessions  u.found
  ?.  =(our.b owner.session.before)  [~[(refused id %owner-required)] held]
  =/  request=@ux  (request-at:terminal id nonce source input)
  =/  prior  (lookup:submission before request)
  ?^  prior  [~[(changed id sequence.before)] held]
  ::  Older/unknown submissions are observation-only, even without a receipt.
  ?:  (~(has by inputs.held) request)  [~[(refused id %workspace-outcome-unknown)] held]
  =/  preflight=(unit @tas)
    ?.  &(=(baseline sequence.before) =(head head.before))  `%workspace-baseline-changed
    ?.  =(source (shax (jam working.session.before)))  `%source-changed
    ?:  ?|  ?=(^ pending.before)  ?=(^ calls.before)
            |(=(%judgment phase.before) =(%judgment resume.before))
            (lien ~(val by pending.held) |=(r=tool-request:nc =(id session.context.r)))
        ==  `%workspace-session-busy
    =/  parsed  (parse:terminal input directory.session.before working.session.before)
    ?:  ?=(%| -.parsed)  `%workspace-instruction-required
    ?.  ?=(%request -.p.parsed)  `%workspace-instruction-required
    =/  config  (resolve:session-project our.b now.b projects.held id project.session.before)
    ?:  ?=(%| -.config)  `p.config
    =/  actual  (current:projects our.b now.b p.config)
    ?:  ?=(%| -.actual)  `p.actual
    ?.  =(working.session.before revision.working.p.actual)  `%source-changed
    ~
  =/  out=(quip card state)
    ?^  preflight  [~[(refused id u.preflight)] held]
    (act b held [%terminal-at id nonce source input])
  =/  refusals=(list @tas)
    %+  murn  -.out
    |=  card=card
    =/  fact  ((soft ,[%give %fact paths=(list path) %noun payload=vase]) card)
    ?~  fact  ~
    =/  value  ((soft ,[%native-coding-refused-v1 session=@ux reason=@tas]) q.payload.u.fact)
    ?~  value  ~
    ?.  =(id session.u.value)  ~
    `reason.u.value
  =/  refusal=(unit @tas)  ?~(refusals ~ `i.refusals)
  =/  after=entry:sessions  (~(got by sessions.+.out) id)
  =/  receipt  (classify:submission request input before after refusal)
  =/  recorded  (append:sessions after now.b [%terminal '' (encode:submission receipt)])
  ::  Roll back this pure transition if its durable receipt cannot be retained.
  ?:  ?=(%| -.recorded)  [~[(refused id %workspace-receipt-capacity)] held]
  =/  final  (apply b +.out p.recorded)
  [(weld -.out -.final) +.final]
++  terminal-command
  |=  [b=bowl:gall held=state id=@ux nonce=@ux input=@t]
  ^-  (quip card state)
  ?.  &(=(our.b src.b) !=(0 nonce) (lte (met 3 input) 65.536))  [~[(refused id %terminal-input-invalid)] held]
  =/  prior  (~(get by inputs.held) nonce)
  ?^  prior
    ?.  =(u.prior [id input])  [~[(refused id %terminal-input-conflict)] held]
    [~[(changed id 0)] held]
  ?:  (gte ~(wyt by inputs.held) 4.096)  [~[(refused id %terminal-history-capacity)] held]
  =/  found  (~(get by sessions.held) id)
  ?~  found  [~[(refused id %session-missing)] held]
  =/  e=entry:sessions  u.found
  ?.  =(our.b owner.session.e)  [~[(refused id %owner-required)] held]
  =/  busy=?
    |(?=(^ pending.e) ?=(^ calls.e) (lien ~(val by pending.held) |=(r=tool-request:nc =(id session.context.r))))
  ::  Pending observation uses the frozen request source, not a replacement
  ::  tool context. Other terminal commands still use the canonical Clay read.
  =/  control=(unit tool-args:nc)
    ?.  busy  ~
    =/  parsed  (parse:terminal input directory.session.e working.session.e)
    ?:  ?=(%| -.parsed)  ~
    ?.  ?=(%tool -.p.parsed)  ~
    ?.  ?=(?(%jobs %observe %cancel) -.arguments.p.parsed)  ~
    `arguments.p.parsed
  ?^  control
    =/  observed  (command:observation our.b now.b id pending.held u.control)
    ?:  ?=(%| -.observed)  [~[(refused id p.observed)] held]
    =/  prepared=(each transition:sessions @tas)
      ?:  ?=(%cancel -.u.control)  (pause:sessions our.b src.b now.b e %.n)
      [%& e ~]
    ?:  ?=(%| -.prepared)  [~[(refused id p.prepared)] held]
    =/  next  (append:sessions entry.p.prepared now.b [%terminal input text.p.observed])
    ?:  ?=(%| -.next)  [~[(refused id p.next)] held]
    =.  held  held(inputs (~(put by inputs.held) nonce [id input]))
    =/  out  (apply b held p.next)
    [(weld -.out cards.p.observed) +.out]
  =/  config  (resolve:session-project our.b now.b projects.held id project.session.e)
  ?:  ?=(%| -.config)  [~[(refused id p.config)] held]
  =/  source  (current:projects our.b now.b p.config)
  ?:  ?=(%| -.source)  [~[(refused id p.source)] held]
  =/  parsed  (parse:terminal input directory.session.e revision.accepted.p.source)
  ?:  ?=(%| -.parsed)  [~[(refused id p.parsed)] held]
  =.  held  held(inputs (~(put by inputs.held) nonce [id input]))
  =/  command=action:terminal  p.parsed
  ?:  ?=(%request -.command)  (act b held [%instruct id text.command])
  ?:  ?=(%pause -.command)  (act b held [%pause id %.n])
  ?:  ?=(%interrupt -.command)  (act b held [%pause id %.y])
  ?:  ?=(%reattach -.command)  (act b held [%observe session.command])
  ?:  ?=(%help -.command)
    =/  next  (append:sessions e now.b [%terminal input help:terminal])
    ?:  ?=(%| -.next)  [~[(refused id p.next)] held]
    (apply b held p.next)
  ?:  |(=(%judgment phase.e) =(%judgment resume.e))  [~[(refused id %candidate-review-pending)] held]
  ?.  &(?=(~ pending.e) ?=(~ calls.e))  [~[(refused id %turn-still-pending)] held]
  ?:  (lien ~(val by pending.held) |=(r=tool-request:nc =(id session.context.r)))
    [~[(refused id %tool-still-pending)] held]
  ?.  =(working.session.e revision.working.p.source)  [~[(refused id %source-changed)] held]
  =/  bound  (~(get by bindings.held) id)
  ?~  bound  [~[(refused id %grant-binding-missing)] held]
  =/  request=tool-request:nc
    [%native-coding-tool-request-v1 (context e nonce) (scot %ux nonce) arguments.command]
  ?:  &((qpc-required b id) (executable:tool-law -.arguments.request))
    [~[(refused id %qpc-selection-required)] held]
  ?.  (tool-claimed our.b now.b held e request)  [~[(refused id %fleet-file-not-reserved)] held]
  =/  key=@ux  (tool-key request)
  =/  next  (append:sessions e(phase %tools, resume phase.e) now.b [%terminal input 'Native tool submitted.'])
  ?:  ?=(%| -.next)  [~[(refused id p.next)] held]
  =.  held
    held(pending (~(put by pending.held) key request), direct (~(put by direct.held) key id))
  =/  out  (apply b held p.next)
  :_  +.out
  (weld -.out ~[(poke our.b %cantrip /native-coding/tool/(scot %ux key) [%native-coding-execute-v1 grant.u.bound request])])
++  direct-result
  |=  [b=bowl:gall held=state key=@ux r=tool-result:nc text=@t]
  ^-  (quip card state)
  =/  id=@ux  (~(got by direct.held) key)
  =/  previous=(map @ux tool-request:nc)  pending.held
  =/  e=entry:sessions  (~(got by sessions.held) id)
  =/  unknown=?  ?=(%unknown -.output.r)
  =/  next  (append:sessions e(phase ?:(unknown %unknown %paused)) now.b [%tool r])
  ?:  ?=(%| -.next)  [~[(refused id p.next)] held]
  =.  held
    ?:  unknown  held
    held(pending (~(del by pending.held) key), direct (~(del by direct.held) key))
  =.  held
    ?:  ?=(%candidate -.output.r)  held(candidates (~(put by candidates.held) id.value.output.r value.output.r))
    held
  =/  out  (tool-release-wake our.b key previous (apply b held p.next))
  ?:  (qpc-required b id)  out
  ?:  ?=(%candidate -.output.r)
    [(weld -.out ~[(poke our.b %viki /native-coding/review-start [%native-coding-review-action-v1 [%start id.value.output.r]])]) +.out]
  out
++  tool-claimed
  |=  [our=@p now=@da held=state e=entry:sessions r=tool-request:nc]
  ^-  ?
  =/  reservations=(list reservation:nc)  (reservations:fleet-law fleet.fleet.held)
  =/  foreign=(list reservation:nc)
    (skim reservations |=(reservation=reservation:nc &(=(desk.source.context.r desk.source.context.reservation) !=(session.context.r session.context.reservation))))
  ?:  ?=(^ foreign)  %.n
  ?:  =(our worker.e)  %.y
  =/  task  (assigned:fleet fleet.held id.session.e)
  ?~  task  %.n
  =/  args=tool-args:nc  arguments.r
  =/  allowed=(set path)  paths.task.u.task
  ?+  -.args  %.y
    %create  (~(has in allowed) pax.args)
    %replace  (~(has in allowed) pax.args)
    %patch  (~(has in allowed) pax.args)
    %delete  (~(has in allowed) pax.args)
    %move  &((~(has in allowed) from.args) (~(has in allowed) to.args))
    %batch
      &((gth (lent edits.args) 0) (lte (lent edits.args) 32) (levy edits.args |=(e=edit:nc (~(has in allowed) path.change.e))))
    %patches
      &((gth (lent items.args) 0) (lte (lent items.args) 16) (levy items.args |=(i=patch-item:nc (~(has in allowed) pax.i))))
    %writes
      &((gth (lent items.args) 0) (lte (lent items.args) 16) (levy items.args |=(i=write-item:nc (~(has in allowed) pax.i))))
    %undo
      ::  The inverse touches exactly the parent's edit paths. Resolve that
      ::  parent independently in Cantrip and Viki before dispatching a tool;
      ::  files.undo and the usual candidate review still govern any landing.
      ?~  assignment.u.task  %.n
      =/  a=assignment:nf  u.assignment.u.task
      ?.  &(=(worker.a worker.e) =(context.a context.task.u.task) =(session.context.a session.context.r) =(project.context.a project.context.r) =(configuration.context.a configuration.context.r) =(actor.context.a actor.context.r) =(owner.source.context.a owner.source.context.r) =(desk.source.context.a desk.source.context.r) =(%held status.reservation.a) =(context.reservation.a context.a) =(paths.reservation.a allowed) =(holder.workspace.reservation.a worker.e) =(fork.workspace.reservation.a desk.source.context.r) =(base.workspace.reservation.a desk.accepted.task.u.task))  %.n
      =/  bound  (~(get by bindings.held) id.session.e)
      ?~  bound  %.n
      ?.  (agent-live:guard our now %cantrip)  %.n
      =/  tools=organ:tool-law
        .^(organ:tool-law %gx /(scot %p our)/cantrip/(scot %da now)/native-coding/tool-state/noun)
      =/  scope  (~(get by grants.tools) grant.u.bound)
      ?~  scope  %.n
      =/  permission  (allowed:tool-law our now u.scope r)
      ?:  ?=(%| -.permission)  %.n
      =/  parent  (undo-parent:tool-law tools grant.u.bound r)
      ?~  parent  %.n
      ?.  =(parent (~(get by candidates.held) candidate.args))  %.n
      (levy edits.u.parent |=(edit=edit:nc (~(has in allowed) path.change.edit)))
  ==
++  selection-bound
  |=  [our=@p held=state id=@ux selected=selection:np worker=@p key=@tas]
  ^-  ?
  =/  p  (~(get by placements.fleet.held) id)
  ?:  =(our worker)  ?=(~ p)
  ?~  p  %.n
  &(=(worker moon.seat-session.route.u.p) =(selected selection.config.u.p) =(key provider-key.config.u.p))
++  blocked-desks
  ::  A pre-existing Cantrip request may still write. Do not reserve its desk
  ::  for another task merely because that request has not replied yet.
  |=  held=state
  ^-  (set @tas)
  (silt (turn ~(val by pending.held) |=(r=tool-request:nc desk.source.context.r)))
++  enqueue-session
  ::  The operator supplies task identity and scope, never a fabricated source,
  ::  inference request or readiness assertion. Existing fleet law dispatches.
  |=  [b=bowl:gall held=state configured=(list moon-route:vr) old=organ:legacy request=enqueue-request]
  ^-  (quip card state)
  ?.  =(our.b src.b)  [~ held]
  =/  id=@ux  session.request
  ?.  &(!=(0 nonce.request) (lte (met 0 nonce.request) 256) (lte ~(wyt in paths.request) 64) (lte ~(wyt in dependencies.request) 32))
    [~[(refused id %fleet-enqueue-invalid)] held]
  =/  prior  (~(get by tasks.fleet.fleet.held) nonce.request)
  ?^  prior
    =/  task=task:nf  task.u.prior
    ?.  &(=(id session.context.task) =(role.request role.task) =(paths.request paths.task) =(dependencies.request dependencies.task))
      [~[(refused id %fleet-task-id-conflict)] held]
    ::  Observe the original task; changed session turns cannot turn a repeated
    ::  queue nonce into a fresh model request.
    (fleet-action b held configured old [%enqueue task])
  =/  found  (~(get by sessions.held) id)
  ?~  found  [~[(refused id %fleet-session-missing)] held]
  =/  e=entry:sessions  u.found
  =/  registered  (resolve:session-project our.b now.b projects.held id project.session.e)
  ?:  ?=(%| -.registered)  [~[(refused id p.registered)] held]
  ?.  &(=(our.b owner.session.e) !=(our.b worker.e) =(configuration.e (configuration:projects p.registered)))
    [~[(refused id %fleet-session-mismatch)] held]
  =/  current  (current:projects our.b now.b p.registered)
  ?:  ?=(%| -.current)  [~[(refused id p.current)] held]
  ?.  =(working.session.e revision.working.p.current)
    [~[(refused id %fleet-source-changed)] held]
  =/  task=task:nf
    [%native-coding-fleet-task-v1 nonce.request (context e (request-id:sessions id turn.e)) revision.accepted.p.current dependencies.request role.request objective.session.e paths.request]
  (fleet-action b held configured old [%enqueue task])
++  fleet-action
  |=  [b=bowl:gall held=state configured=(list moon-route:vr) old=organ:legacy a=action:fleet]
  ^-  (quip card state)
  ?.  =(our.b src.b)  [~ held]
  =/  world  (read:fleet-read our.b src.b now.b configured old ~)
  ?:  ?=(%| -.world)  [~[(refused 0x0 p.world)] held]
  =/  next  (act:fleet b fleet.held p.world sessions.held projects.held (blocked-desks held) a)
  ?:  ?=(%| -.next)  [~[(refused 0x0 p.next)] held]
  =/  out=(quip card state:fleet)  p.next
  [-.out held(fleet +.out)]
++  fleet-wake
  |=  [b=bowl:gall held=state configured=(list moon-route:vr) old=organ:legacy revision=@ud]
  ^-  (quip card state)
  ?.  &(=(our.b src.b) =(revision next.fleet.fleet.held) (gth revision consumed.fleet.held))  [~ held]
  =/  world  (read:fleet-read our.b src.b now.b configured old ~)
  ?:  ?=(%| -.world)  [~[(refused 0x0 p.world)] held]
  =/  out  (wake:fleet b fleet.held p.world sessions.held projects.held (blocked-desks held) revision)
  [-.out held(fleet +.out)]
++  fleet-inspection
  |=  [b=bowl:gall held=state report=inspection:relay]
  ^-  (quip card state)
  =/  next  (inspected:fleet b fleet.held sessions.held report)
  ?:  ?=(%| -.next)  [~ held]
  =/  out=(quip card state:fleet)  p.next
  [-.out held(fleet +.out)]
++  moon-event
  |=  [b=bowl:gall held=state received=event:relay]
  ^-  (quip card state)
  =/  found  (~(get by sessions.held) session.event.received)
  ?~  found  [~ held]
  ?.  (event-valid:fleet b fleet.held u.found received)  [~ held]
  =/  task  (assigned:fleet fleet.held id.session.u.found)
  ?~  task  [~ held]
  ?>  ?=(^ assignment.u.task)
  =/  a=assignment:nf  u.assignment.u.task
  =/  cards=(list card)  ~
  =/  started  (started:fleet-law fleet.fleet.held src.b a)
  =/  start=(quip card state:fleet)
    ?:  ?=(%| -.started)  [~ fleet.held]
    (effects:fleet our.b fleet.held sessions.held p.started)
  =.  cards  -.start
  =.  held  held(fleet +.start)
  ?:  ?=(%pending -.outcome.event.received)  [cards held]
  =/  out  (model-event b(src our.b) held id.event.received session.event.received outcome.event.received)
  =.  out  [(weld cards -.out) +.out]
  =/  held=state  +.out
  =/  e=entry:sessions  (~(got by sessions.held) id.session.u.found)
  =/  next=(each transition:nf @tas)
    ?:  ?=(?(%unknown %paused) phase.e)
      (control:fleet-law our.b our.b fleet.fleet.held task.a ?:(=(%paused phase.e) %pause %unknown))
    ?:  ?=(?(%judgment %refused) phase.e)
      (report:fleet-law fleet.fleet.held src.b a ~ ?~(head.e ~ ~[u.head.e]))
    [%| %fleet-turn-continues]
  ?:  ?=(%| -.next)  out
  =/  moved  (effects:fleet our.b fleet.held sessions.held p.next)
  [(weld -.out -.moved) held(fleet +.moved)]
++  fleet-ack
  |=  [b=bowl:gall held=state wire=wire sign=sign:agent:gall]
  ^-  (quip card state)
  ?.  ?=(%poke-ack -.sign)  [~ held]
  ?~  p.sign  [~ held]
  ?.  ?=([%native-fleet %remote @ @ %native-coding-moon-infer ~] wire)
    [~[(refused 0x0 %fleet-delivery-refused)] held]
  =/  moon  (slaw %p i.t.t.wire)
  =/  request  (slaw %ux i.t.t.t.wire)
  ?~  moon  [~ held]
  ?~  request  [~ held]
  =/  matches=(list entry:sessions)
    (skim ~(val by sessions.held) |=(e=entry:sessions ?~(pending.e %.n &(=(u.moon worker.e) =(u.request id.u.pending.e)))))
  ?~  matches  [~ held]
  ?^  t.matches  [~ held]
  =/  e=entry:sessions  i.matches
  =/  task  (assigned:fleet fleet.held id.session.e)
  ?~  task  [~ held]
  =/  next  (control:fleet-law our.b our.b fleet.fleet.held id.task.u.task %unknown)
  =/  out  (model-event b(src our.b) held u.request id.session.e [%unknown ~])
  ?:  ?=(%| -.next)  out
  =/  moved  (effects:fleet our.b fleet.+.out sessions.+.out p.next)
  =/  next-held=state  +.out
  [(weld -.out -.moved) next-held(fleet +.moved)]
++  recover
  |=  [our=@p held=state]
  ^-  (quip card state)
  ?>  (valid:fleet our fleet.held)
  =/  out  (recovered:fleet our fleet.held sessions.held)
  [-.out held(fleet +.out)]
++  peek
  |=  [held=state path=path]
  ^-  (unit (unit cage))
  ?:  =(/x/native-coding/fleet/placements path)  ``noun+!>(placements.fleet.held)
  ?:  =(/x/native-coding/fleet/revision path)  ``noun+!>([next.fleet.fleet.held consumed.fleet.held])
  ?:  =(/x/native-coding/fleet path)  ``noun+!>(fleet.fleet.held)
  ?:  =(/x/native-coding/projects path)  ``noun+!>(projects.held)
  ?:  =(/x/native-coding/sessions path)  ``noun+!>((turn ~(val by sessions.held) public))
  ?:  ?=([%x %native-coding %workspace-receipt @ @ ~] path)
    ?~  id=(slaw %ux i.t.t.t.path)  [~ ~]
    ?~  request=(slaw %ux i.t.t.t.t.path)  [~ ~]
    =/  found  (~(get by sessions.held) u.id)
    =/  value=(unit receipt:submission)
      ?~(found ~ (lookup:submission u.found u.request))
    ``noun+!>(value)
  ?:  ?=([%x %native-coding ?(%git-proposal %git-proposals) @ @ ~] path)
    ?~  id=(slaw %ux i.t.t.t.path)  [~ ~]
    ?~  request=(slaw %ux i.t.t.t.t.path)  [~ ~]
    ?:  =(%git-proposal i.t.t.path)  ``noun+!>((git-status held u.id u.request))
    ``noun+!>((git-lookup held u.id u.request))
  ?.  ?=([%x %native-coding @ @ ~] path)  [~ ~]
  =/  key  (slaw %ux i.t.t.t.path)
  ?~  key  [~ ~]
  ?:  =(%tool i.t.t.path)  ``noun+!>((~(get by pending.held) u.key))
  ?:  =(%candidate i.t.t.path)  ``noun+!>((~(get by candidates.held) u.key))
  ?:  =(%qpc-input i.t.t.path)
    ::  Viki's outer on-peek admits only the owner to native-coding paths.
    =/  e  (~(get by sessions.held) u.key)
    =/  b  (~(get by bindings.held) u.key)
    =/  value=(unit input:qpc-pool)
      ?~  e  ~
      ?~  b  ~
      `[u.e provider-key.u.b grant.u.b]
    ``noun+!>(value)
  ?.  =(%session i.t.t.path)  [~ ~]
  =/  e  (~(get by sessions.held) u.key)
  ``noun+!>(?~(e ~ `(public u.e)))
--
