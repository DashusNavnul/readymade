::  Landscape's installed-app catalog, projected without copying authority.
::  Docket /charges returns light charges (glob content stripped). Keep the
::  glob payload opaque: this view needs metadata, never application assets.
|%
+$  href
  $%  [%glob base=@tas hash=@uvH location=$%([%http url=@t] [%ames ship=@p])]
      [%site path=path]
  ==
+$  docket
  $:  %1  title=@t  info=@t  color=@ux  href=href  image=(unit @t)
      version=[major=@ud minor=@ud patch=@ud]  website=@t  license=@t
  ==
+$  charge
  [docket=docket chad=$%([%glob body=*] [%site ~] [%install ~] [%suspend body=*] [%hung error=@t])]
::  Only ordinary same-ship app paths can be launched from this catalog.
::  Reject URL metacharacters and dot traversal before rendering a link.
++  segment
  |=  value=@ta
  ^-  ?
  ?:  |(=(%$ value) =('.' value) =('..' value))  %.n
  ?.  (lte (met 3 value) 128)  %.n
  %+  levy  (trip value)
  |=  c=@tD
  ?|  &((gte c 'a') (lte c 'z'))
      &((gte c 'A') (lte c 'Z'))
      &((gte c '0') (lte c '9'))
      =(c '-')  =(c '_')  =(c '.')  =(c '~')
  ==
++  target
  |=  destination=href
  ^-  (unit @t)
  =/  route=path
    ?:(?=(%site -.destination) path.destination ~[%apps base.destination])
  ?.  |(?=([%apps @ *] route) =(/hawk route))  ~
  ?.  (levy `path`route segment)  ~
  `?:(?=(%glob -.destination) (cat 3 (spat route) '/') (spat route))
++  row
  |=  [desk=@tas item=charge]
  ^-  json
  =/  url=(unit @t)  (target href.docket.item)
  =/  status=@t
    ?-  -.chad.item
      %glob  'available'
      %site  'available'
      %install  'installing'
      %suspend  'suspended'
      %hung  'error'
    ==
  %-  pairs:enjs:format
  :~  ['desk' s+desk]
      ['name' s+title.docket.item]
      ['url' ?~(url ~ s+u.url)]
      ['status' s+status]
      ['launchMessage' s+?~(url 'This app does not declare a supported ship-app launch path.' '')]
  ==
++  unavailable
  |=  message=@t
  ^-  json
  %-  pairs:enjs:format
  :~  ['schema' s+'readymade-installed-apps-v1']
      ['available' b+%.n]
      ['apps' a+~]
      ['message' s+message]
      ['landscapeUrl' s+'/apps/landscape/']
  ==
++  view
  |=  observed=*
  ^-  json
  =/  initial=(unit [%initial apps=(map @tas charge)])
    ((soft ,[%initial apps=(map @tas charge)]) observed)
  ?~  initial  (unavailable 'Landscape returned an unsupported app catalog.')
  %-  pairs:enjs:format
  :~  ['schema' s+'readymade-installed-apps-v1']
      ['available' b+%.y]
      ['apps' a+(turn ~(tap by apps.u.initial) row)]
      ['message' s+'App status comes from Landscape; opening an app checks its own interface.']
      ['landscapeUrl' s+'/apps/landscape/']
  ==
++  native
  |=  b=bowl:gall
  ^-  json
  ?.  .^(? %gu /(scot %p our.b)/docket/(scot %da now.b)/$)
    (unavailable 'Landscape app catalog is unavailable because Docket is stopped.')
  (view .^(* %gx /(scot %p our.b)/docket/(scot %da now.b)/charges/noun))
--
