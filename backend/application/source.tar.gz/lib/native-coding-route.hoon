::  Admission for the generalized native inference relay only. This does not
::  extend the old model-bridge request protocol or select an execution agent.
/-  mb=model-bridge, mse=glass-moon-executor, vr=glass-moon-route,
    np=native-coding-provider
/+  provider=native-coding-provider, codex=codex-inference
|%
++  codec  'native-coding-v1'
++  spec-valid
  |=  spec=model-bridge-spec:mb
  ^-  ?
  ?.  (model-bridge-spec-valid:mb spec)  %.n
  ::  Keep the already selected Codex route noun valid without rewriting it.
  ?:  (spec-valid:codex spec)  %.y
  ?&  =([%gall-agent %codex-inference %model-bridge-action] target.spec)
      (model-auth-absent:mb auth.spec)
      =(codec request-codec.spec)  =(codec response-codec.spec)
      ?|  =('codex' provider-id.spec)  =('openai' provider-id.spec)
          =('anthropic' provider-id.spec)  =('xai' provider-id.spec)
          =('compatible' provider-id.spec)
      ==
      !=('model-unreported' model-id.spec)  !=('unreported' model-id.spec)
      !=('unknown' model-id.spec)
  ==
++  kind-for
  |=  provider=provider:np
  ^-  ?(%codex %claude %grok %open)
  ?-  provider
    %codex  %codex
    %openai  %codex
    %anthropic  %claude
    %xai  %grok
    %compatible  %open
  ==
++  provider-valid
  |=  p=moon-provider:vr
  ^-  ?
  ?.  (spec-valid spec.p)  %.n
  =/  name=@t  provider-id.spec.p
  =/  selected=?
    ?-  kind.p
      %codex  |(=('codex' name) =('openai' name))
      %claude  =('anthropic' name)
      %grok  =('xai' name)
      %open  =('compatible' name)
    ==
  ?.  selected  %.n
  ?:  !=(%open kind.p)  =([%unreported ~] weights.p)
  ?-  -.weights.p
    %unreported  %.y
    %declared  !=(0 digest.weights.p)
  ==
++  binding-valid
  |=  b=binding:mse
  ^-  ?
  ?.  ?=([%multiplayer-session-executor-binding-v2 *] -.b)  %.n
  ?&  (spec-valid selected.b)
      =(backend.b provider-id.selected.b)
      =([%codex-inference %model-bridge-action] [port.b protocol.b])
      !=(0 route.b)  (lte (met 0 route.b) 256)
      (bounded-text:mb local-session.b max-identifier-bytes:mb)
      (bounded-text:mb peer-session.b max-identifier-bytes:mb)
      (bounded-text:mb workspace.b max-identifier-bytes:mb)
  ==
++  selection-matches
  |=  [spec=model-bridge-spec:mb selected=selection:np]
  ^-  ?
  ?&  (spec-valid spec)  (selection-valid:provider selected)
      =(provider-id.spec `@t`provider.selected)  =(model-id.spec model.selected)
  ==
++  make-spec
  ::  Endpoint, capabilities and credential reference are frozen separately
  ::  in the relay's full selection. No credential value enters this noun.
  |=  [bridge=@t selected=selection:np]
  ^-  (each model-bridge-spec:mb @tas)
  =/  spec=model-bridge-spec:mb
    [%1 bridge `@t`provider.selected model.selected codec codec [%gall-agent %codex-inference %model-bridge-action] no-auth:mb]
  ?:  (selection-matches spec selected)  [%& spec]
  [%| %native-route-selection-invalid]
++  make-binding
  ::  The legacy rebinder intentionally rejects this codec. This constructor
  ::  emits its existing binding mold for the native relay without routing a
  ::  generic request into the old model-bridge handler.
  |=  [r=moon-route:vr peer-session=@t workspace=@t]
  ^-  (each binding:mse @tas)
  ?.  (provider-valid provider.r)  [%| %native-route-provider-invalid]
  =/  b=binding:mse
    [[%multiplayer-session-executor-binding-v2 spec.provider.r (shax (jam r))] session-id.r parent.seat-session.r peer-session workspace provider-id.spec.provider.r %codex-inference %model-bridge-action]
  ?:  (binding-valid b)  [%& b]
  [%| %native-route-binding-invalid]
--
