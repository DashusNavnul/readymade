::  Private Cantrip compiler attachment and retained unchecked emissions.
::  No Clay writes, compiler retries, candidate approval or model authority.
/-  nc=native-coding
/+  compiler=native-coding-compiler, tools=cantrip-native-coding,
    project=native-coding-project, modules=native-coding-module-sources,
    guard=viki-scry-guard
|%
+$  retained-v1  [input=job-v1:compiler output=outcome:compiler]
+$  retained  [input=job:compiler output=outcome:compiler]
+$  organ-v1
  [%native-coding-compiler-state-v1 bundle=(unit bundle:compiler) emissions=(map @ux retained-v1)]
+$  mapping-key  [configuration=@ux target=@tas]
+$  mapping-record  [project=project:nc mapping=manifest:modules enabled=?]
+$  organ
  [%native-coding-compiler-state-v2 bundle=(unit bundle:compiler) emissions=(map @ux retained) mappings=(map mapping-key mapping-record)]
+$  command
  $%  [%native-coding-compiler-install-v1 value=bundle:compiler]
      [%native-coding-compiler-retain-v1 id=@ux input=job:compiler output=outcome:compiler]
      [%native-coding-compiler-mapping-configure-v1 project=project:nc value=manifest:modules]
      [%native-coding-compiler-mapping-revoke-v1 configuration=@ux target=@tas]
  ==
++  migrate
  |=  old=organ-v1
  ^-  organ
  [%native-coding-compiler-state-v2 bundle.old emissions.old ~]
++  legacy
  |=  s=organ
  ^-  organ-v1
  =/  rows=(list [@ux retained-v1])
    %+  murn  ~(tap by emissions.s)
    |=  [id=@ux r=retained]
    ?:  ?=(%native-coding-compiler-job-v2 -.input.r)  ~
    `[id [input.r output.r]]
  [%native-coding-compiler-state-v1 bundle.s (malt rows)]
++  mapping
  |=  [s=organ configuration=@ux target=@tas]
  ^-  (unit (each manifest:modules @tas))
  =/  found  (~(get by mappings.s) [configuration target])
  ?~  found  ~
  ?.  enabled.u.found  `[%| %compiler-module-mapping-revoked]
  `[%& mapping.u.found]
++  registered
  |=  [our=@p now=@da p=project:nc]
  ^-  ?
  ?.  &(=(our authority.spec.p) (agent-live:guard our now %viki))  %.n
  =/  projects=(map @t project:nc)
    .^((map @t project:nc) %gx /(scot %p our)/viki/(scot %da now)/native-coding/projects/noun)
  =/  global  (~(get by projects) id.spec.p)
  ?:  =(`p global)  %.y
  ?.  (agent-live:guard our now %viki)  %.n
  =/  scoped=(map @ux project:nc)
    .^((map @ux project:nc) %gx /(scot %p our)/viki/(scot %da now)/native-coding/session-projects/noun)
  (lien ~(val by scoped) |=(held=project:nc =(p held)))
++  mapping-act
  |=  [b=bowl:gall s=organ jobs=organ:tools c=command]
  ^-  (each organ @tas)
  ?.  =(our.b src.b)  [%| %compiler-owner-required]
  ?:  ?=(%native-coding-compiler-mapping-revoke-v1 -.c)
    =/  key=mapping-key  [configuration.c target.c]
    =/  old  (~(get by mappings.s) key)
    ?~  old  [%| %compiler-module-mapping-missing]
    [%& s(mappings (~(put by mappings.s) key u.old(enabled %.n)))]
  ?.  ?=(%native-coding-compiler-mapping-configure-v1 -.c)  [%| %compiler-mapping-command-invalid]
  ?.  (valid:modules project.c value.c)  [%| %compiler-module-manifest-invalid]
  =/  key=mapping-key  [configuration.value.c name.target.value.c]
  =/  old  (~(get by mappings.s) key)
  ?^  old
    ?.  &(enabled.u.old =(project.c project.u.old) =(value.c mapping.u.old))
      [%| %compiler-module-mapping-already-retained]
    [%& s]
  ?:  (gte ~(wyt by mappings.s) 128)  [%| %compiler-module-mapping-capacity]
  ?:  (lien ~(val by records.jobs) |=(r=record:tools &(=(configuration.value.c configuration.context.request.r) ?=(?(%compile %check) -.arguments.request.r) ?=(?(%running %unknown) stage.r))))
    [%| %compiler-module-mapping-busy]
  ?.  (registered our.b now.b project.c)  [%| %compiler-module-project-unregistered]
  =/  catalog  (catalog:project our.b now.b project.c)
  ?:  ?=(%| -.catalog)  [%| p.catalog]
  [%& s(mappings (~(put by mappings.s) key [project.c value.c %.y]))]
++  retained-valid
  |=  [id=@ux r=retained]
  ^-  ?
  =/  j=job:compiler  input.r
  =/  out=outcome:compiler  output.r
  =/  tgt=build-target:nc  (job-target:compiler j)
  =/  srcs=(list source:compiler)  (job-sources:compiler j)
  ?&  =(id (key:tools (job-request:compiler j)))  =((identity:compiler j) job.out)
      (sources-bounded:modules (job-project:compiler j) srcs)
      ?=(^ srcs)
      =(entry.tgt pax.i.srcs)
      (lte (met 3 (job-module:compiler j)) 128)
      (lte (lent diagnostics.out) 8)
      (levy diagnostics.out |=(v=@tas (lte (met 3 v) 128)))
      ?:  ?=(%native-coding-compiler-job-v2 -.j)
        =/  mapped  (mapped-input:compiler j)
        ?=(%& -.mapped)
      %.y
      ?:  !=(%unchecked status.out)  ?=(~ output.out)
      ?~  output.out  %.n
      ?~  compiler.out  %.n
      =/  e=emission:compiler  u.output.out
      ?&  =(size.e (met 3 bytes.e))  (gte size.e 1)  (lte size.e 65.536)
          =(digest.e (shax (jam [%unchecked-plan-assembly-v1 job.out u.compiler.out size.e bytes.e])))
      ==
  ==
++  valid
  |=  s=organ
  ^-  ?
  ?&  ?~(bundle.s %.y (bundle-valid:compiler u.bundle.s))
      (lte ~(wyt by emissions.s) 32)
      (levy ~(tap by emissions.s) retained-valid)
      (lte ~(wyt by mappings.s) 128)
      (levy ~(tap by mappings.s) |=([key=mapping-key r=mapping-record] &(=(key [configuration.mapping.r name.target.mapping.r]) (valid:modules project.r mapping.r))))
      %+  levy  ~(val by emissions.s)
      |=  r=retained
      ?.  ?=(%native-coding-compiler-job-v2 -.input.r)  %.y
      =/  held  (~(get by mappings.s) [configuration.context.request.input.r name.target.input.r])
      ?~  held  %.n
      &(=(project.input.r project.u.held) =(mapping.input.r mapping.u.held))
  ==
++  act
  |=  [b=bowl:gall s=organ jobs=organ:tools c=command]
  ^-  (each organ @tas)
  ?.  =(our.b src.b)  [%| %compiler-owner-required]
  ?:  ?=(?(%native-coding-compiler-mapping-configure-v1 %native-coding-compiler-mapping-revoke-v1) -.c)
    (mapping-act b s jobs c)
  ?:  ?=(%native-coding-compiler-install-v1 -.c)
    =/  installed  (install:compiler our.b src.b bundle.s value.c)
    ?:  ?=(%| -.installed)  [%| p.installed]
    [%& s(bundle p.installed)]
  =/  incoming=retained  [input.c output.c]
  ?.  (retained-valid id.c incoming)  [%| %compiler-evidence-invalid]
  =/  prior  (~(get by emissions.s) id.c)
  ?^  prior
    ?:  =(u.prior incoming)  [%& s]
    [%| %compiler-evidence-conflict]
  ?:  (gte ~(wyt by emissions.s) 32)  [%| %compiler-evidence-capacity]
  =/  admitted  (~(get by records.jobs) id.c)
  ?~  admitted  [%| %compiler-admission-missing]
  ?.  &(=(%running stage.u.admitted) =(request.input.c request.u.admitted))
    [%| %compiler-admission-mismatch]
  =/  scope  (~(get by grants.jobs) grant.u.admitted)
  ?~  scope  [%| %compiler-grant-missing]
  ?.  =(project.input.c project.grant.u.scope)  [%| %compiler-project-mismatch]
  =/  allowed  (allowed:tools our.b now.b u.scope request.input.c)
  ?:  ?=(%| -.allowed)  [%| p.allowed]
  ?.  (pending:tools our.b now.b request.input.c)  [%| %compiler-request-not-pending]
  ::  Re-read exact source/closure before retention; no caller-supplied file
  ::  stamp is treated as canonical just because the receipt is same-ship.
  =/  exact  (prepare:compiler our.b now.b project.input.c request.input.c)
  ?:  ?=(%| -.exact)  [%| p.exact]
  ?.  =(p.exact input.c)  [%| %compiler-frozen-source-mismatch]
  ?.  =(compiler.output.c ?~(bundle.s ~ `digest.u.bundle.s))
    [%| %compiler-bundle-mismatch]
  [%& s(emissions (~(put by emissions.s) id.c incoming))]
--
