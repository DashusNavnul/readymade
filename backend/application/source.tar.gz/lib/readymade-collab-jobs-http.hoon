::  Native journal presentation. This projection performs no source or build work.
/-  c=readymade-collab, j=readymade-collab-jobs, rp=readymade-package
/+  web=readymade-collab-http, kit=readymade-package, release=readymade-package-release, build=readymade-package-build
|%
++  put
  |=  [value=json key=@t entry=json]
  ^-  json
  ?>  ?=(%o -.value)
  [%o (~(put by p.value) key entry)]
++  inspection-text
  |=  item=package:c
  ^-  @t
  =/  offer  offer.value.item
  =/  source  source.body.offer
  =/  entries=(list @t)
    %+  turn  files.body.offer
    |=  entry=file:rp
    (rap 3 ~[(spat path.entry) ' bytes=' (scot %ud size.entry) ' hash=' (scot %ux hash.entry) '\0a'])
  (rap 3 (weld ~['Pinned source: ' (scot %p ship.source) '/' (scot %tas desk.source) '/' (scot %ud revision.source) ' root=' (scot %uv root.source) '\0aManifest: ' (scot %ux (manifest:kit files.body.offer)) '\0a'] entries))
++  pin-json
  |=  source=pin:rp
  ^-  json
  %-  pairs:enjs:format
  :~  ['ship' s+(scot %p ship.source)]
      ['desk' s+(scot %tas desk.source)]
      ['revision' s+(scot %ud revision.source)]
      ['root' s+(scot %uv root.source)]
  ==
++  original-source
  |=  [our=@p peer=@p item=package:c ledger=ledger:j]
  ^-  (unit pin:rp)
  =/  works=(list [request=@ta work=job:j])  ~(tap by ledger)
  |-  ^-  (unit pin:rp)
  ?~  works  ~
  =/  work=job:j  work.i.works
  ?.  &(=(kind.work %release) =(phase.work %confirmed) =(owner.command.work (scot %p our)) =(peer.command.work (scot %p peer)))
    $(works t.works)
  ?~  result.work  $(works t.works)
  =/  parsed=(unit result:release)  ((soft result:release) u.result.work)
  ?~  parsed  $(works t.works)
  ?.  ?=(%readymade-package-released -.u.parsed)  $(works t.works)
  =/  answer  u.parsed
  =/  selected=(unit selection:release)  (select:release reference.command.work)
  ?~  selected  $(works t.works)
  =/  body  body.offer.value.item
  ?.  ?&  =(request.answer request.command.work)
          =(our sender.body)
          =(peer recipient.body)
          =(release.answer source.body)
          =(files.answer files.body)
          =(our ship.original.answer)
          =(desk.original.answer desk.u.selected)
          =(revision.original.answer revision.u.selected)
          (pin-valid:kit original.answer)
          ?=([* ~] files.answer)
      ==
    $(works t.works)
  ?.  =(path.i.files.answer path.u.selected)  $(works t.works)
  ?.  =(desk.release.answer (name:release our peer request.command.work original.answer i.files.answer))
    $(works t.works)
  `original.answer
++  bound-job
  |=  [our=@p peer=@p id=@ux item=package:c work=job:j]
  ^-  ?
  ?&  =(owner.command.work (scot %p our))
      =(peer.command.work (scot %p peer))
      =(id.command.work (scot %ux id))
      =(offer.work `digest.offer.value.item)
      =(id digest.offer.value.item)
      =(our recipient.body.offer.value.item)
      =(peer sender.body.offer.value.item)
      (valid:kit offer.value.item)
  ==
++  staged
  |=  [our=@p id=@ux item=package:c work=job:j]
  ^-  ?
  ?.  &(=(kind.work %stage) =(phase.work %confirmed))  %.n
  ?~  result.work  %.n
  =/  parsed
    ((soft ,[tag=@tas offer=@ux nonce=@ux result=stage-result:j]) u.result.work)
  ?~  parsed  %.n
  =/  callback  u.parsed
  ?.  &(=(tag.callback %readymade-package-stage-v1) =(offer.callback id) =(nonce.callback nonce.work))  %.n
  ?.  ?=(%confirmed -.result.callback)  %.n
  =/  state  value.item
  ?.  &(?=(?(%accepted %built %failed) stage.state) =(our recipient.body.offer.state))  %.n
  ?~  destination.state  %.n
  ?~  consent.state  %.n
  ?&  =('accept' op.command.work)
      =(digest.command.work id.command.work)
      =(inspection.state `(inspection-digest:kit offer.state))
      (digest-valid:kit nonce.work)
      =(destination.result.callback u.destination.state)
      =(u.consent.state (consent-digest:kit offer.state u.destination.state))
      =(1 revision.result.callback)
      !=(0 root.result.callback)
      (lte (met 0 root.result.callback) 256)
      (digest-valid:kit proof.result.callback)
      (digest-valid:kit source-proof.result.callback)
  ==
++  workspace
  |=  [our=@p peer=@p id=@ux item=package:c ledger=ledger:j]
  ^-  json
  =/  works=(list [request=@ta work=job:j])  ~(tap by ledger)
  =/  matched=(list [request=@ta work=job:j])
    %+  skim  works
    |=  row=[request=@ta work=job:j]
    (bound-job our peer id item work.row)
  =/  confirmed=(list [request=@ta work=job:j])
    %+  skim  matched
    |=  row=[request=@ta work=job:j]
    (staged our id item work.row)
  =/  destination=@t
    ?~(destination.value.item 'Not assigned' (scot %tas u.destination.value.item))
  ?^  confirmed
    =/  callback
      (need ((soft ,[tag=@tas offer=@ux nonce=@ux result=stage-result:j]) (need result.work.i.confirmed)))
    ?>  ?=(%confirmed -.result.callback)
    %-  pairs:enjs:format
    :~  ['state' s+'source-staged']
        ['destination' s+destination]
        ['revision' s+(scot %ud revision.result.callback)]
        ['root' s+(scot %uv root.result.callback)]
        ['message' s+'Authenticated native source-stage receipt; compilation is reported separately.']
    ==
  =/  pending=(list [request=@ta work=job:j])
    %+  skim  matched
    |=  row=[request=@ta work=job:j]
    &(=(phase.work.row %pending) ?=(?(%inspect %stage) kind.work.row))
  %-  pairs:enjs:format
  :~  ['state' s+?~(pending 'not-staged' ?:(=(kind.work.i.pending %stage) 'stage-pending' 'inspection-pending'))]
      ['destination' s+destination]
      ['message' s+?~(pending 'No verified current source-stage receipt.' 'Native operation pending; source materialization is not confirmed.')]
  ==
++  build-plan
  |=  [our=@p peer=@p id=@ux item=package:c ledger=ledger:j]
  ^-  (each plan:build @tas)
  =/  works=(list job:j)  ~(val by ledger)
  ?:  (lien works |=(work=job:j &((bound-job our peer id item work) |(=(kind.work %build) ?=(?(%pending %uncertain) phase.work)))))
    [%| %existing-operation-requires-observation]
  ?.  &((lte (lent files.body.offer.value.item) 8) (levy files.body.offer.value.item source-supported:build))
    [%| %unsupported-source-use-hoon]
  =/  nonce=@ux  0x1
  =/  label=@ta  (scot %ux (shax (jam [%readymade-build-presentation-v1 id])))
  ?:  (~(has by ledger) label)  [%| %projection-key-collision]
  =/  hash=@t  (scot %ux id)
  =/  command=command:c  ['build' (scot %p our) (scot %p peer) 'projection-only' '' '' hash '' '' hash]
  =/  pending=job:j  [command nonce %build %pending `id ~]
  =/  state=state:c  [%readymade-collab-v1 ~ ~ ~ ~]
  =/  state  state(packages (~(put by packages.state) id item))
  (ready:build our state (~(put by ledger) label pending) id nonce)
++  completed-plan
  ::  Reconstruct the pure pre-completion check without mutating saved state.
  |=  [our=@p id=@ux item=package:c ledger=ledger:j selected=job:j]
  ^-  (each plan:build @tas)
  =/  entries=(list [request=@ta work=job:j])
    (skim ~(tap by ledger) |=(row=[request=@ta work=job:j] =(selected work.row)))
  ?.  ?=([* ~] entries)  [%| %build-job-not-unique]
  =/  before=package:c  item(value value.item(stage %accepted, result ~))
  =/  state=state:c  [%readymade-collab-v1 ~ ~ ~ ~]
  =/  state  state(packages (~(put by packages.state) id before))
  (ready:build our state (~(put by ledger) request.i.entries selected(phase %pending, result ~)) id nonce.selected)
++  build-json
  |=  [our=@p peer=@p id=@ux item=package:c ledger=ledger:j]
  ^-  json
  =/  works=(list job:j)
    (skim ~(val by ledger) |=(work=job:j &((bound-job our peer id item work) =(%build kind.work))))
  ?~  works  (pairs:enjs:format ~[['state' s+'not-run'] ['mode' s+'ford-hoon-compile']])
  =/  work=job:j  i.works
  ?.  =(%confirmed phase.work)
    (pairs:enjs:format ~[['state' s+(scot %tas phase.work)] ['mode' s+'ford-hoon-compile']])
  =/  unverified=json
    (pairs:enjs:format ~[['state' s+'unverified'] ['mode' s+'ford-hoon-compile'] ['message' s+'Native build receipt does not match current canonical package.']])
  ?~  result.work  unverified
  =/  parsed
    ((soft ,[%readymade-package-build-v1 offer=@ux nonce=@ux answer=result:build]) u.result.work)
  ?~  parsed  unverified
  =/  callback  u.parsed
  ?.  &(=(id offer.callback) =(nonce.work nonce.callback))  unverified
  =/  prepared  (completed-plan our id item ledger work)
  ?.  ?=(%& -.prepared)  unverified
  =/  plan=plan:build  p.prepared
  ?:  ?=(%failed -.answer.callback)
    ?.  (lien files.body.offer.plan |=(f=file:rp =(path.f path.answer.callback)))  unverified
    =/  proof=@ux  (shax (jam [%readymade-package-build-failure-v1 our plan answer.callback]))
    ?.  &(=(stage.value.item %failed) =(result.value.item `[id consent.plan source.body.offer.plan (manifest:kit files.body.offer.plan) %.n ~ proof]))  unverified
    %-  pairs:enjs:format
    :~  ['state' s+'failed']
        ['mode' s+'ford-hoon-compile']
        ['receipt' s+(scot %ux proof)]
        ['message' s+(rap 3 ~['Native Ford compile failed at ' (spat path.answer.callback) ': ' (scot %tas reason.answer.callback) '. Functional tests have not run.'])]
    ==
  ?.  ?=(%confirmed -.answer.callback)  unverified
  =/  receipt=receipt:build  receipt.answer.callback
  ?.  ?&  (valid:build our receipt)
          =(offer.plan offer.value.item)
          =(plan plan.body.receipt)
          =(nonce.plan nonce.work)
          =(%built stage.value.item)
          =(result.value.item `[id consent.plan source.body.offer.plan manifest.body.receipt %.y `artifact.body.receipt proof.receipt])
      ==
    unverified
  %-  pairs:enjs:format
  :~  ['state' s+'compiled']
      ['mode' s+'ford-hoon-compile']
      ['artifact' s+(scot %ux artifact.body.receipt)]
      ['receipt' s+(scot %ux proof.receipt)]
      ['message' s+'Native Ford compilation only; functional tests have not run.']
  ==
++  package-json
  |=  [our=@p peer=@p id=@ux item=package:c ledger=ledger:j]
  ^-  json
  =/  value=json  (package-json:web our id item)
  =/  value  (put value 'inspection' [%s (inspection-text item)])
  =/  files=(list file:rp)  files.body.offer.value.item
  =/  reference=@t
    ?~  files  ''
    (spat (weld ~[(scot %tas desk.source.body.offer.value.item) (scot %ud revision.source.body.offer.value.item)] path.i.files))
  =/  value  (put value 'reference' [%s reference])
  =/  value  (put value 'releaseSource' (pin-json source.body.offer.value.item))
  =/  original=(unit pin:rp)  (original-source our peer item ledger)
  =/  value
    ?~  original  value
    (put value 'originalSource' (pin-json u.original))
  =/  admission  (build-plan our peer id item ledger)
  =/  value  (put value 'buildable' [%b ?=(%& -.admission)])
  =/  value  (put value 'buildReason' [%s ?:(?=(%& -.admission) 'Native current Cantrip validation still required.' (scot %tas p.admission))])
  =/  value  (put value 'build' (build-json our peer id item ledger))
  (put value 'workspace' (workspace our peer id item ledger))
++  snapshot
  |=  [our=@p peer=@p now=@da state=state:c ledger=ledger:j]
  ^-  json
  =/  value=json  (snapshot:web our peer now state)
  ?>  ?=(%o -.value)
  =/  caps=json  (need (~(get by p.value) 'capabilities'))
  =/  caps  (put caps 'inspect' (capability:web %.y 'Native owner and exact pinned source validation required.'))
  =/  caps  (put caps 'accept' (capability:web %.y 'Native inspection, owner consent and collision checks required.'))
  =/  caps  (put caps 'decline' (capability:web %.y 'Native owner validation required.'))
  =/  caps  (put caps 'build' (capability:web %.y 'Native Ford compile adapter; current Cantrip permission and workspace readback required.'))
  =/  value  (put value 'capabilities' caps)
  =/  all=(list [@ux package:c])  ~(tap by packages.state)
  =/  packages=(list [@ux package:c])
    %+  skim  all
    |=  row=[id=@ux item=package:c]
    =/  body  body.offer.value.item.row
    |(&(=(our sender.body) =(peer recipient.body)) &(=(peer sender.body) =(our recipient.body)))
  =/  shown=(list json)
    %+  turn  (scag 256 packages)
    |=  row=[id=@ux item=package:c]
    (package-json our peer id.row item.row ledger)
  (put value 'packages' [%a shown])
--
