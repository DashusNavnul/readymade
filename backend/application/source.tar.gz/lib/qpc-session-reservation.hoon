::  Session no-reuse, short of the one grant prepared for that session.
::  Any tool record, any Viki use, a revoked grant or a second grant spends
::  the identity. Nothing here releases a reservation or grants authority.
/+  contract=cantrip-native-coding-contract
|%
++  spare
  ::  ~ when spent; [~ ~] when untouched; [~ ~ id] when held only by grant id.
  |=  [ledger=organ:contract local=(set @ux) session=@ux]
  ^-  (unit (unit @ux))
  ?:  (~(has in local) session)  ~
  ?:  (lien ~(val by records.ledger) |=(r=record:contract =(session session.context.request.r)))  ~
  =/  holders=(list [id=@ux v=scope:contract])
    (skim ~(tap by grants.ledger) |=([id=@ux v=scope:contract] =(session session.grant.v)))
  ?~  holders  [~ ~]
  ?.  &(=(~ t.holders) =(~ revoked.v.i.holders))  ~
  [~ `id.i.holders]
--
