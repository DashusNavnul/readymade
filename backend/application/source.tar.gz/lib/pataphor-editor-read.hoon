::  Owner-only canonical editor reads. No grants, writes or worker dispatch.
::  All reads share the caller's event time and bind both project revisions.
/+  model=pataphor-editor-model, dsr=desk-shell-read
|%
+$  project  [base=revision:model work=revision:model]
+$  entry  [pax=path file=? directory=?]
+$  listing
  [owner=@p at=@da selected=@tas context=project pax=path entries=(list entry)]
++  private-path
  private-path:dsr
++  revision
  |=  [our=@p at=@da desk=@tas]
  ^-  revision:model
  =/  domes=cone:clay  .^(cone:clay %cx /(scot %p our)//(scot %da at)/domes)
  =/  d=dome:clay  (need (~(get by domes) [our desk]))
  [desk let.d .^(@uv %cz (beam:dsr our at desk /))]
++  project-at
  |=  [our=@p actor=@p at=@da]
  ^-  (each project @tas)
  ?.  =(our actor)  [%| %foreign-actor]
  =/  desks=(set @tas)
    .^((set @tas) %cd ~[(scot %p our) '' (scot %da at)])
  ?.  &((~(has in desks) %pataphor-demo) (~(has in desks) %pataphor-demo-work))
    [%| %project-missing]
  ?.  &((private-path our at %pataphor-demo /) (private-path our at %pataphor-demo-work /))
    [%| %project-not-private]
  =/  context=project
    [(revision our at %pataphor-demo) (revision our at %pataphor-demo-work)]
  ?.  &((revision-valid:model base.context) (revision-valid:model work.context))
    [%| %revision-unavailable]
  [%& context]
++  file
  |=  [our=@p actor=@p at=@da desk=@tas pax=path]
  ^-  (each snapshot:model @tas)
  ?.  =(our actor)  [%| %foreign-actor]
  ?.  &((desk-valid:model desk) ?=(^ pax) (path-valid:model pax))
    [%| %invalid-path]
  =/  context  (project-at our actor at)
  ?:  ?=(%| -.context)  [%| p.context]
  =/  node=arch  .^(arch %cy (beam:dsr our at desk pax))
  ?~  fil.node  [%| %file-missing]
  ?.  (private-path our at desk pax)  [%| %path-not-private]
  =/  mark=@tas  (rear pax)
  =/  body=content:model
    ?.  |(=(%hoon mark) =(%txt mark))  [%unsupported-mark mark]
    (classify:model mark .^(* %cx (beam:dsr our at desk pax)))
  =/  s=snapshot:model
    [%pataphor-editor-read-v1 our at desk base.p.context work.p.context pax .^(@uv %cz (beam:dsr our at desk pax)) body]
  ?.  (snapshot-valid:model s)  [%| %snapshot-invalid]
  [%& s]
++  directory
  |=  [our=@p actor=@p at=@da desk=@tas pax=path]
  ^-  (each listing @tas)
  ?.  =(our actor)  [%| %foreign-actor]
  ?.  &((desk-valid:model desk) (path-valid:model pax))
    [%| %invalid-path]
  =/  context  (project-at our actor at)
  ?:  ?=(%| -.context)  [%| p.context]
  =/  node=arch  .^(arch %cy (beam:dsr our at desk pax))
  ?:  &(=(~ dir.node) ?=(^ pax))  [%| %directory-missing]
  ?.  (private-path our at desk pax)  [%| %path-not-private]
  =/  paths  (children:model pax dir.node)
  ?:  ?=(%| -.paths)  [%| p.paths]
  =/  entries=(list entry)
    %+  murn  p.paths
    |=  child=path
    ^-  (unit entry)
    ?.  (private-path our at desk child)  ~
    =/  child-node=arch  .^(arch %cy (beam:dsr our at desk child))
    `[child ?=(^ fil.child-node) ?=(^ dir.child-node)]
  [%& [our at desk p.context pax entries]]
--
