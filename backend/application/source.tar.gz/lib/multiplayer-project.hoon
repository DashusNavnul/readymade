::  /lib/multiplayer-project
::
::  Pure project and invitation law.  A live Gall shell must pass src.bowl as
::  actor; no invitation or command carries an asserted caller identity.
::
/-  mp=multiplayer-project
|%
++  event-history-limit  `@ud`1.024
::
++  spec-valid
  |=  spec=project-spec:mp
  ^-  ?
  ?&  =(1 version.spec)
      !=(0 id.spec)
      !=(0 title.spec)
      !=(0 base-desk.spec)
      (gth law-version.spec 0)
      !=(0 law-digest.spec)
      !=(0 created-at.spec)
  ==
::
++  invitation-digest
  |=  body=invitation-body:mp
  ^-  digest:mp
  `@ux`(shax (jam [%multiplayer-project-invitation-v1 body]))
++  invitation-valid
  |=  invitation=invitation:mp
  ^-  ?
  ?&  =(1 version.body.invitation)
      !=(0 project.body.invitation)
      (gth law-version.body.invitation 0)
      !=(0 law-digest.body.invitation)
      !=(0 nonce.body.invitation)
      (gth expires-at.body.invitation issued-at.body.invitation)
      =((invitation-digest body.invitation) digest.invitation)
      ?-  -.status.invitation
        %pending   %.y
        %accepted
          ?&  =(target.body.invitation by.status.invitation)
              (gte at.status.invitation issued-at.body.invitation)
              (lth at.status.invitation expires-at.body.invitation)
          ==
        %declined
          ?&  =(target.body.invitation by.status.invitation)
              (gte at.status.invitation issued-at.body.invitation)
              (lth at.status.invitation expires-at.body.invitation)
          ==
        %expired
          ?&  =(authority.body.invitation by.status.invitation)
              (gte at.status.invitation expires-at.body.invitation)
          ==
        %revoked
          (gte at.status.invitation issued-at.body.invitation)
      ==
  ==
::
++  event-digest
  |=  body=event-body:mp
  ^-  digest:mp
  `@ux`(shax (jam [%multiplayer-project-event-v1 body]))
++  event-valid
  |=  event=event:mp
  ^-  ?
  ?&  =(1 version.body.event)
      !=(0 project.body.event)
      !=(0 sequence.body.event)
      =((event-digest body.event) digest.event)
  ==
++  event-list-valid
  |=  [events=(list event:mp) spec=project-spec:mp]
  ^-  ?
  ?~  events  %.y
  =/  event=event:mp  i.events
  ?.  ?&  (event-valid event)
          =(id.spec project.body.event)
          =(authority.spec authority.body.event)
      ==
    %.n
  ?~  t.events
    ?&  =(1 sequence.body.event)
        ?=(~ previous.body.event)
        ?=(%project-opened -.action.body.event)
        =(authority.spec actor.body.event)
        =(created-at.spec occurred-at.body.event)
    ==
  ?&  !?=(%project-opened -.action.body.event)
      =(previous.body.event `digest.i.t.events)
      =(sequence.body.event +(sequence.body.i.t.events))
      (gte occurred-at.body.event occurred-at.body.i.t.events)
      $(events t.events)
  ==
::
++  member-valid
  |=  member=member:mp
  ^-  ?
  !=(0 joined-at.member)
++  members-valid
  |=  members=(map @p member:mp)
  ^-  ?
  (levy ~(tap by members) |=(row=[@p member:mp] (member-valid +.row)))
++  invitations-valid
  |=  [spec=project-spec:mp invitations=(map digest:mp invitation:mp)]
  ^-  ?
  %+  levy  ~(tap by invitations)
  |=  row=[digest:mp invitation:mp]
  =/  invitation=invitation:mp  +.row
  ?&  =(-.row digest.invitation)
      (invitation-valid invitation)
      =(id.spec project.body.invitation)
      =(authority.spec authority.body.invitation)
      =(law-version.spec law-version.body.invitation)
      =(law-digest.spec law-digest.body.invitation)
  ==
++  pending-index-valid
  |=  [invitations=(map digest:mp invitation:mp) pending=(map @p digest:mp)]
  ^-  ?
  %+  levy  ~(tap by pending)
  |=  row=[@p digest:mp]
  =/  found=(unit invitation:mp)  (~(get by invitations) +.row)
  ?~  found  %.n
  ?&  =(-.row target.body.u.found)
      ?=(%pending -.status.u.found)
  ==
++  pending-invitations-indexed
  |=  [invitations=(map digest:mp invitation:mp) pending=(map @p digest:mp)]
  ^-  ?
  %+  levy  ~(tap by invitations)
  |=  row=[digest:mp invitation:mp]
  =/  invitation=invitation:mp  +.row
  ?-  -.status.invitation
    %pending
      =(`-.row (~(get by pending) target.body.invitation))
    %accepted  %.y
    %declined  %.y
    %expired   %.y
    %revoked   %.y
  ==
::
++  project-valid
  |=  project=project:mp
  ^-  ?
  ?.  (spec-valid spec.project)  %.n
  =/  authority-member=(unit member:mp)
    (~(get by members.project) authority.spec.project)
  ?~  authority-member  %.n
  ?.  =(%operator role.u.authority-member)  %.n
  ?.  (members-valid members.project)  %.n
  ?.  (invitations-valid spec.project invitations.project)  %.n
  ?.  (pending-index-valid invitations.project pending.project)  %.n
  ?.  (pending-invitations-indexed invitations.project pending.project)  %.n
  ?~  events.project  %.n
  ?&  =(event-sequence.project sequence.body.i.events.project)
      =(head.project `digest.i.events.project)
      (event-list-valid events.project spec.project)
  ==
::
++  append-event
  |=  [project=project:mp actor=@p action=event-action:mp occurred-at=@da]
  ^-  project:mp
  =/  sequence=@ud  +(event-sequence.project)
  =/  body=event-body:mp
    :*  1
        id.spec.project
        authority.spec.project
        sequence
        head.project
        actor
        action
        occurred-at
    ==
  =/  event=event:mp  [body (event-digest body)]
  %=  project
    event-sequence  sequence
    head            `digest.event
    events          (scag event-history-limit ^+(events.project [event events.project]))
  ==
::
++  reject
  |=  refusal=refusal:mp
  ^-  result:mp
  [%| refusal]
++  open
  |=  [spec=project-spec:mp actor=@p]
  ^-  result:mp
  ?.  (spec-valid spec)  (reject [%invalid-spec ~])
  ?.  =(authority.spec actor)
    (reject [%foreign-authority authority.spec actor])
  =/  founder=member:mp  [%operator created-at.spec ~]
  =/  project=project:mp
    :*  spec
        (~(put by *(map @p member:mp)) actor founder)
        *(map digest:mp invitation:mp)
        *(map @p digest:mp)
        0
        ~
        ~
    ==
  [%& (append-event project actor [%project-opened ~] created-at.spec)]
::
++  role-for
  |=  [project=project:mp actor=@p]
  ^-  (unit role:mp)
  =/  found=(unit member:mp)  (~(get by members.project) actor)
  ?~(found ~ `role.u.found)
++  time-valid
  |=  [project=project:mp observed-at=@da]
  ^-  ?
  (gte observed-at (latest-time project))
++  latest-time
  |=  project=project:mp
  ^-  @da
  ?~(events.project created-at.spec.project occurred-at.body.i.events.project)
++  can-invite
  |=  [current=role:mp requested=role:mp]
  ^-  ?
  ?-  current
    %operator    !=(%operator requested)
    %maintainer  ?|  =(%contributor requested)
                      =(%observer requested)
                      =(%model requested)
                  ==
    %contributor  %.n
    %observer     %.n
    %model        %.n
  ==
++  invitation-for
  |=  $:  project=project:mp
          actor=@p
          target=@p
          role=role:mp
          issued-at=@da
          expires-at=@da
          nonce=digest:mp
      ==
  ^-  invitation:mp
  =/  body=invitation-body:mp
    :*  1
        id.spec.project
        authority.spec.project
        target
        role
        actor
        issued-at
        expires-at
        law-version.spec.project
        law-digest.spec.project
        nonce
    ==
  [body (invitation-digest body) [%pending ~]]
::
++  invite
  |=  $:  project=project:mp
          actor=@p
          target=@p
          role=role:mp
          issued-at=@da
          expires-at=@da
          nonce=digest:mp
      ==
  ^-  result:mp
  ?.  (project-valid project)  (reject [%invalid-project ~])
  ?.  (time-valid project issued-at)
    (reject [%event-before-head (latest-time project) issued-at])
  =/  actor-role=(unit role:mp)  (role-for project actor)
  ?.  ?&  ?=(^ actor-role)
          (can-invite u.actor-role role)
      ==
    (reject [%not-authorized actor actor-role])
  ?:  (~(has by members.project) target)  (reject [%already-member target])
  =/  pending-id=(unit digest:mp)  (~(get by pending.project) target)
  ?^  pending-id  (reject [%invitation-exists target u.pending-id])
  =/  invitation=invitation:mp
    (invitation-for project actor target role issued-at expires-at nonce)
  ?.  (invitation-valid invitation)  (reject [%invalid-invitation ~])
  ?:  (~(has by invitations.project) digest.invitation)
    (reject [%invitation-exists target digest.invitation])
  =/  next=project:mp
    %=  project
      invitations  (~(put by invitations.project) digest.invitation invitation)
      pending      (~(put by pending.project) target digest.invitation)
    ==
  [%& (append-event next actor [%invitation-issued digest.invitation target role] issued-at)]
::
++  accept
  |=  [project=project:mp actor=@p invitation-id=digest:mp observed-at=@da]
  ^-  result:mp
  ?.  (project-valid project)  (reject [%invalid-project ~])
  ?.  (time-valid project observed-at)
    (reject [%event-before-head (latest-time project) observed-at])
  =/  found=(unit invitation:mp)
    (~(get by invitations.project) invitation-id)
  ?~  found  (reject [%invitation-missing invitation-id])
  =/  invitation=invitation:mp  u.found
  ?.  ?=(%pending -.status.invitation)
    (reject [%invitation-closed status.invitation])
  ?.  =(target.body.invitation actor)
    (reject [%invitation-target target.body.invitation actor])
  ?:  (gte observed-at expires-at.body.invitation)
    (reject [%invitation-expired expires-at.body.invitation observed-at])
  ?:  (~(has by members.project) actor)  (reject [%already-member actor])
  =/  admitted=member:mp  [role.body.invitation observed-at `invitation-id]
  =/  resolved=invitation:mp
    invitation(status [%accepted actor observed-at])
  =/  next=project:mp
    %=  project
      members      (~(put by members.project) actor admitted)
      invitations  (~(put by invitations.project) invitation-id resolved)
      pending      (~(del by pending.project) actor)
    ==
  [%& (append-event next actor [%invitation-accepted invitation-id] observed-at)]
::
++  decline
  |=  [project=project:mp actor=@p invitation-id=digest:mp observed-at=@da]
  ^-  result:mp
  ?.  (project-valid project)  (reject [%invalid-project ~])
  ?.  (time-valid project observed-at)
    (reject [%event-before-head (latest-time project) observed-at])
  =/  found=(unit invitation:mp)
    (~(get by invitations.project) invitation-id)
  ?~  found  (reject [%invitation-missing invitation-id])
  =/  invitation=invitation:mp  u.found
  ?.  ?=(%pending -.status.invitation)
    (reject [%invitation-closed status.invitation])
  ?.  =(target.body.invitation actor)
    (reject [%invitation-target target.body.invitation actor])
  ?:  (gte observed-at expires-at.body.invitation)
    (reject [%invitation-expired expires-at.body.invitation observed-at])
  =/  resolved=invitation:mp
    invitation(status [%declined actor observed-at])
  =/  next=project:mp
    %=  project
      invitations  (~(put by invitations.project) invitation-id resolved)
      pending      (~(del by pending.project) actor)
    ==
  [%& (append-event next actor [%invitation-declined invitation-id] observed-at)]
::
++  revoke
  |=  [project=project:mp actor=@p invitation-id=digest:mp observed-at=@da]
  ^-  result:mp
  ?.  (project-valid project)  (reject [%invalid-project ~])
  ?.  (time-valid project observed-at)
    (reject [%event-before-head (latest-time project) observed-at])
  =/  found=(unit invitation:mp)
    (~(get by invitations.project) invitation-id)
  ?~  found  (reject [%invitation-missing invitation-id])
  =/  invitation=invitation:mp  u.found
  ?.  ?=(%pending -.status.invitation)
    (reject [%invitation-closed status.invitation])
  ?:  (gte observed-at expires-at.body.invitation)
    (reject [%invitation-expired expires-at.body.invitation observed-at])
  =/  actor-role=(unit role:mp)  (role-for project actor)
  ?.  ?&  ?=(^ actor-role)
          (can-invite u.actor-role role.body.invitation)
      ==
    (reject [%not-authorized actor actor-role])
  =/  resolved=invitation:mp
    invitation(status [%revoked actor observed-at])
  =/  next=project:mp
    %=  project
      invitations  (~(put by invitations.project) invitation-id resolved)
      pending      (~(del by pending.project) target.body.invitation)
    ==
  [%& (append-event next actor [%invitation-revoked invitation-id] observed-at)]
::
++  expire
  |=  [project=project:mp actor=@p invitation-id=digest:mp observed-at=@da]
  ^-  result:mp
  ?.  (project-valid project)  (reject [%invalid-project ~])
  ?.  (time-valid project observed-at)
    (reject [%event-before-head (latest-time project) observed-at])
  ?.  =(authority.spec.project actor)
    (reject [%foreign-authority authority.spec.project actor])
  =/  found=(unit invitation:mp)
    (~(get by invitations.project) invitation-id)
  ?~  found  (reject [%invitation-missing invitation-id])
  =/  invitation=invitation:mp  u.found
  ?.  ?=(%pending -.status.invitation)
    (reject [%invitation-closed status.invitation])
  ?.  (gte observed-at expires-at.body.invitation)
    (reject [%invitation-not-expired expires-at.body.invitation observed-at])
  =/  resolved=invitation:mp
    invitation(status [%expired actor observed-at])
  =/  next=project:mp
    %=  project
      invitations  (~(put by invitations.project) invitation-id resolved)
      pending      (~(del by pending.project) target.body.invitation)
    ==
  [%& (append-event next actor [%invitation-expired invitation-id] observed-at)]
::
++  leave
  |=  [project=project:mp actor=@p observed-at=@da]
  ^-  result:mp
  ?.  (project-valid project)  (reject [%invalid-project ~])
  ?.  (time-valid project observed-at)
    (reject [%event-before-head (latest-time project) observed-at])
  ?:  =(authority.spec.project actor)
    (reject [%authority-cannot-leave actor])
  ?.  (~(has by members.project) actor)
    (reject [%member-missing actor])
  =/  next=project:mp
    project(members (~(del by members.project) actor))
  [%& (append-event next actor [%member-left actor] observed-at)]
::
::  Owner-side removal. Recorded as %member-left whose event actor is the
::  operator, not the member, so no event, member or refusal type changes.
++  remove
  |=  [project=project:mp actor=@p target=@p observed-at=@da]
  ^-  result:mp
  ?.  (project-valid project)  (reject [%invalid-project ~])
  ?.  (time-valid project observed-at)
    (reject [%event-before-head (latest-time project) observed-at])
  =/  actor-role=(unit role:mp)  (role-for project actor)
  ?.  ?&  ?=(^ actor-role)
          =(%operator u.actor-role)
      ==
    (reject [%not-authorized actor actor-role])
  ?:  =(authority.spec.project target)
    (reject [%authority-cannot-leave target])
  ?:  =(actor target)  (reject [%not-authorized actor actor-role])
  ?.  (~(has by members.project) target)
    (reject [%member-missing target])
  =/  next=project:mp
    project(members (~(del by members.project) target))
  [%& (append-event next actor [%member-left target] observed-at)]
--
