::  Owner-only discovery from complete saved Viki DATA. The catalog contains
::  metadata only; only the explicitly selected session exposes public records.
/-  nc=native-coding
/+  catalog=native-coding-session-catalog, cursor=readymade-session-catalog,
    loop=native-coding-loop, sessions=native-coding-session,
    saved=qpc-native-app-state, guard=viki-scry-guard,
    terminal=native-coding-terminal
|%
+$  observation
  $:  projects=(map @t project:nc)  rows=(list row:catalog)
      selected=(unit public-session:loop)  catalog=json  complete=?
      read-reason=(unit @tas)
  ==
++  endpoint  '/apps/pataphor-native/coding/sessions?offset=0'
++  file-read-reason
  ::  Observation of the native busy gates, not a reservation or permission.
  |=  [our=@p chosen=@ux held=state:loop]
  ^-  (unit @tas)
  =/  found  (~(get by sessions.held) chosen)
  ?~  found  ~
  =/  e=entry:sessions  u.found
  ?.  =(our owner.session.e)  `%owner-required
  ?:  |(=(%judgment phase.e) =(%judgment resume.e))  `%candidate-review-pending
  ?.  &(?=(~ pending.e) ?=(~ calls.e))  `%turn-still-pending
  ?:  (lien ~(val by pending.held) |=(r=tool-request:nc =(chosen session.context.r)))
    `%tool-still-pending
  ?.  (~(has by bindings.held) chosen)  `%grant-binding-missing
  `%ready
++  inner
  |=  raw=*
  ^-  state:loop
  =/  tags=(list @tas)
    ~[%viki-familiar-state-v32 %viki-familiar-state-v31 %viki-familiar-state-v30 %viki-familiar-state-v29 %viki-familiar-state-v28 %viki-familiar-state-v27 %viki-familiar-state-v26 %viki-familiar-state-v25 %viki-familiar-state-v24 %viki-familiar-state-v23 %viki-familiar-state-v22 %viki-familiar-state-v21 %viki-familiar-state-v20 %viki-familiar-state-v19]
  =/  started=?  %.n
  |-  ^-  state:loop
  ?~  tags
    =/  decoded  (need ((soft ,[%viki-familiar-state-v18 legacy=* coding=state:loop]) raw))
    ?>  =(raw decoded)
    coding.decoded
  ?>  ?=(^ raw)
  ?.  =(i.tags -.raw)
    ?>  !started
    $(tags t.tags)
  =/  layer  (need ((soft ,[tag=@tas legacy=* tail=*]) raw))
  ?>  =(raw layer)
  ?:  =(%viki-familiar-state-v32 tag.layer)
    =/  archive  (need ((soft ,[head=(unit [desk=@tas number=@ud commit=@uv]) writing=(unit *)]) tail.layer))
    ?>  =(tail.layer archive)
    ?>  ?~(head.archive ?=(~ writing.archive) %.y)
    $(raw legacy.layer, tags t.tags, started %.y)
  ?:  ?=(?(%viki-familiar-state-v31 %viki-familiar-state-v30) tag.layer)
    ?>  =(~ tail.layer)
    $(raw legacy.layer, tags t.tags, started %.y)
  $(raw legacy.layer, tags t.tags, started %.y)
++  decode
  |=  original=vase
  ^-  state:loop
  =/  parts  (viki:saved original)
  =/  found  (skim parts |=(p=part:saved =(%inner tag.p)))
  ?>  ?=([* ~] found)
  (inner data.i.found)
++  read
  |=  [our=@p src=@p at=@da]
  ^-  (unit state:loop)
  ::  Never ask an old Viki for a potentially missing application scry.
  ?.  &(=(our src) (agent-live:guard our at %viki))  ~
  =/  egg=egg-any:gall  .^(egg-any:gall %gv /(scot %p our)/viki/(scot %da at)/$)
  ?.  ?=(%20 -.egg)  ~
  =/  current=egg:gall  +.egg
  ?.  ?=(%live -.current)  ~
  =/  original=vase  +.old-state.current
  (mole |.((decode original)))
++  failure
  |=  [our=@p reason=@tas]
  ^-  json
  (pairs:enjs:format ~[['schema' s+'native-coding-session-catalog-v2'] ['owner' s+(scot %p our)] ['available' b+%.n] ['complete' b+%.n] ['error' s+reason] ['endpoint' s+endpoint] ['permissionGranted' b+%.n]])
++  page
  |=  [our=@p request=query:cursor held=state:loop]
  ^-  json
  =/  result  (select:catalog our request sessions.held)
  ?:  ?=(%| -.result)  (failure our p.result)
  =/  body=json  (page-json:catalog p.result)
  ?>  ?=(%o -.body)
  [%o (~(put by (~(put by p.body) 'owner' s+(scot %p our))) 'available' b+%.y)]
++  observe
  |=  [our=@p chosen=@ux held=state:loop]
  ^-  (each observation @tas)
  =/  projected  (project:catalog our sessions.held)
  ?:  ?=(%| -.projected)  [%| p.projected]
  =/  first  (select:catalog our [0 ~] sessions.held)
  ?:  ?=(%| -.first)  [%| p.first]
  =/  all=(list row:catalog)  p.projected
  ::  Legacy clients receive the entire catalog or an explicit upgrade error.
  ::  Never mistake a page for the complete set. Stop sizing once over budget.
  =/  complete=?
    =/  remaining  all
    =/  bytes=@ud  65.536
    |-  ^-  ?
    ?:  (gth bytes byte-limit:catalog)  %.n
    ?~  remaining  %.y
    $(remaining t.remaining, bytes (add bytes +((met 3 (en:json:html (row-json:catalog i.remaining))))))
  =/  selected=(unit public-session:loop)
    =/  found  (~(get by sessions.held) chosen)
    ?~(found ~ `(public:loop u.found))
  =/  metadata=json
    (pairs:enjs:format ~[['schema' s+'native-coding-session-catalog-v2'] ['owner' s+(scot %p our)] ['available' b+%.y] ['complete' b+complete] ['digest' s+(scot %ux digest.p.first)] ['total' (numb:enjs:format total.p.first)] ['endpoint' s+endpoint] ['error' ?:(complete ~ s+'coding-catalog-upgrade-required')] ['permissionGranted' b+%.n]])
  [%& [projects.held all selected metadata complete (file-read-reason our chosen held)]]
++  query
  |=  text=@t
  ^-  (unit query:cursor)
  ?.  (lte (met 3 text) 130)  ~
  =/  first  (split:terminal 38 text)
  =/  offset  (split:terminal 61 head.first)
  ?.  &(found.offset =('offset' head.offset))  ~
  ?.  found.first  (parse-query:cursor tail.offset ~)
  =/  version  (split:terminal 61 tail.first)
  ?.  &(found.version =('catalog' head.version))  ~
  (parse-query:cursor tail.offset `tail.version)
++  route
  |=  [our=@p src=@p at=@da url=@t]
  ^-  (unit json)
  =/  prefix=@t  '/apps/pataphor-native/coding/sessions?'
  ?.  =(prefix (cut 3 [0 (met 3 prefix)] url))  ~
  ?.  =(our src)  `(failure our %coding-catalog-owner)
  =/  request  (query (rsh [3 (met 3 prefix)] url))
  ?~  request  `(failure our %coding-catalog-cursor)
  =/  current  (read our src at)
  ?~  current  `(failure our %coding-catalog-unavailable)
  `(page our u.request u.current)
--
