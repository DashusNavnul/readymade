::  Prepare a COMPLETE typed Gall loadout; this library sends no cards.
::  %gy supplies factory nouns, not %gv's deliberately cleared code field.
::  Rebuild every factory at its owning beak and compare the ENTIRE noun.
::  Never normalize opaque nouns with Gall's function-valued agent mold.
/-  spider
/+  strandio
=,  strand=strand:spider
|%
+$  migration  ?(%same %cantrip-v19)
+$  change  [name=@tas target=beak migration=migration]
+$  plan  [ship=@p expected=(set @tas) changes=(list change)]
+$  yoke
  $:  %live  control=duct  run=@t  sub=@ud  stats=stats:gall
      incoming=bitt:gall  outgoing=boat:gall  boar=*
      code=*  running=[live=? value=*]  source=beak
      marks=*  sky=farm:gall  rest=*
  ==
+$  inventory  (map @tas yoke)
+$  built  [source=beak factory=agent:gall]
+$  factories  (map @tas built)
+$  evidence
  $:  name=@tas  source=beak  target=beak  migration=migration
      bowl=bowl:gall  previous=vase  normalized=vase  candidate=vase
      cards=(list card:agent:gall)
  ==
+$  prepared
  $:  plan=plan  at=@da  identity=(map @tas [beak *])
      load=load:gall  evidence=(list evidence)
  ==
++  valid
  |=  [our=@p actor=@p p=plan]
  ^-  ?
  =/  names=(list @tas)  (turn changes.p |=(c=change name.c))
  ?&  =(our actor)  =(our ship.p)
      (gte ~(wyt in expected.p) 1)  (lte ~(wyt in expected.p) 128)
      (gte (lent names) 1)  (lte (lent names) 2)
      =((lent names) ~(wyt in (silt names)))
      %+  levy  changes.p
      |=  c=change
      ?&  (~(has in expected.p) name.c)
          =(our p.target.c)  !=(0 q.target.c)
          ?=(?(%ud %da) -.r.target.c)  !=(0 p.r.target.c)
      ==
  ==
++  identity
  |=  rows=inventory
  ^-  (map @tas [beak *])
  (~(run by rows) |=(y=yoke [source.y code.y]))
++  capture
  |=  [our=@p actor=@p at=@da]
  ^-  inventory
  ?>  =(our actor)
  =/  raw=(map @tas *)
    .^((map @tas *) %gy /(scot %p our)//(scot %da at)/$)
  (active our raw)
++  active
  |=  [our=@p raw=(map @tas *)]
  ^-  inventory
  ?>  (lte ~(wyt by raw) 256)
  =/  out=inventory  ~
  =/  todo  ~(tap by raw)
  |-  ^-  inventory
  ?~  todo  out
  ::  Current %gy filters tombstones already. Validate the complete known
  ::  shape if one is present; malformed/future rows never become omissions.
  =/  tombstone
    ((soft ,[%nuke sky=(map path @ud) cop=(map path hutch:gall)]) q.i.todo)
  ?^  tombstone  $(todo t.todo)
  =/  parsed  ((soft ,yoke) q.i.todo)
  ?>  ?=(^ parsed)
  =/  y=yoke  u.parsed
  ?.  live.running.y  $(todo t.todo)
  ?>  &(=(our p.source.y) !=(0 code.y))
  $(todo t.todo, out (~(put by out) p.i.todo y))
++  migration-valid
  |=  [kind=migration before=vase after=vase]
  ^-  ?
  ?:  =(%same kind)  =(q.before q.after)
  ?.  ?=([%cantrip-judge-state-v18 *] q.before)  %.n
  =/  parsed  ((soft ,[%cantrip-judge-state-v19 legacy=* journal=*]) q.after)
  ?~  parsed  %.n
  &(=(q.before legacy.u.parsed) =(~ journal.u.parsed))
++  selected
  |=  [name=@tas changes=(list change)]
  ^-  (unit change)
  ?~  changes  ~
  ?:  =(name name.i.changes)  `i.changes
  $(changes t.changes)
++  assemble
  ::  A typed loadout cannot omit, duplicate, add, or replace another app.
  |=  [our=@p actor=@p p=plan rows=inventory old=factories next=factories]
  ^-  load:gall
  ?>  (valid our actor p)
  ?>  =(expected.p ~(key by rows))
  ?>  &(=(expected.p ~(key by old)) =(expected.p ~(key by next)))
  %+  turn  ~(tap in expected.p)
  |=  name=@tas
  =/  y  (~(got by rows) name)
  =/  was  (~(got by old) name)
  =/  now  (~(got by next) name)
  ?>  &(=(source.y source.was) =(code.y factory.was))
  =/  changed=(unit change)
    (selected name changes.p)
  ?~  changed
    ?>  =(was now)
    [name source.was factory.was]
  ?>  =(target.u.changed source.now)
  [name source.now factory.now]
++  rehearse
  ::  Both normalizers receive this same complete current saved vase/bowl.
  ::  This is an inert rehearsal, not a prediction of a later event's bowl.
  |=  [c=change previous=vase b=bowl:gall old=agent:gall next=agent:gall]
  ^-  evidence
  =/  before  (~(on-load old b) previous)
  =/  after  (~(on-load next b) previous)
  ?>  =(-.before -.after)
  =/  normalized=vase  ~(on-save +.before b)
  =/  candidate=vase  ~(on-save +.after b)
  ?>  (migration-valid migration.c normalized candidate)
  [name.c byk.b target.c migration.c b previous normalized candidate -.after]
++  prepare
  |=  p=plan
  =/  m  (strand ,prepared)
  ^-  form:m
  ;<  b=bowl:spider  bind:m  get-bowl:strandio
  ?>  (valid our.b src.b p)
  =/  before=inventory  (capture our.b src.b now.b)
  ?>  =(expected.p ~(key by before))
  =/  old=factories  ~
  =/  next=factories  ~
  =/  todo  ~(tap by before)
  =<  loop
  |%
  ++  loop
    ^-  form:m
    ?~  todo  finish
    =/  name=@tas  p.i.todo
    =/  y=yoke  q.i.todo
    ;<  prior=vase  bind:m  (build-file-hard:strandio source.y /app/[name]/hoon)
    =/  factory=agent:gall  !<(agent:gall prior)
    ?>  =(code.y factory)
    =.  old  (~(put by old) name [source.y factory])
    =/  changed=(unit change)  (selected name changes.p)
    ?~  changed
      loop(todo t.todo, next (~(put by next) name [source.y factory]))
    ;<  fresh=vase  bind:m  (build-file-hard:strandio target.u.changed /app/[name]/hoon)
    =/  replacement=agent:gall  !<(agent:gall fresh)
    loop(todo t.todo, next (~(put by next) name [target.u.changed replacement]))
  ++  finish
    ^-  form:m
    ;<  current=bowl:spider  bind:m  get-bowl:strandio
    =/  rows=inventory  (capture our.current src.current now.current)
    ?>  =((identity before) (identity rows))
    =/  load=load:gall  (assemble our.current src.current p rows old next)
    =/  proofs=(list evidence)
      %+  turn  changes.p
      |=  c=change
      =/  y=yoke  (~(got by rows) name.c)
      =/  exported
        .^([version=$?(%16 %20) %live control=* run=* sub=* stats=* incoming=* outgoing=* boar=* code=* saved=[%| value=vase] source=beak rest=*] %gv /(scot %p our.current)/[name.c]/(scot %da now.current)/$)
      ?>  =(source.y source.exported)
      =/  bol=bowl:gall
        :*  [our.current our.current name.c /gall-loadout-update]
            [outgoing.y incoming.y (~(run-plot of-farm:gall sky.y) (bake tail ,plot:gall))]
            [+(change.stats.y) eny.current now.current target.c]
        ==
      =/  was  (~(got by old) name.c)
      =/  fresh  (~(got by next) name.c)
      =/  proof=evidence
        (rehearse c value.saved.exported bol factory.was factory.fresh)
      proof(source source.y)
    (pure:m [p now.current (identity rows) load proofs])
  --
++  effect
  |=  prepared=prepared
  ^-  card:agent:gall
  [%pass /gall-loadout-update %arvo %g %load load.prepared]
--
