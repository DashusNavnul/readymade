::  Supplemental owner DATA only. Not an app, migration authority or archive IO.
::  The canonical scalar map remains ONCE in the complete prior app vase.
::  A missing history observation is unknown, never never-configured evidence.
/-  pa=cantrip-project-access, j=cantrip-project-suggestion-journal
/+  journal=cantrip-project-suggestion-journal,
    archive=cantrip-project-receipt-archive
|%
+$  supplement  [bundles=bundles:j history=(unit shared-state:archive)]
+$  saved
  [%cantrip-project-bundle-owner-save-v1 prior=vase extra=supplement]
+$  legacy  [grants=grants:pa scalar=records:pa]
+$  restored  [prior=vase extra=supplement]
++  unknown  *supplement
++  joined
  |=  [scalar=records:pa extra=supplement]
  ^-  journal:j
  [scalar bundles.extra]
++  history-observation
  ::  Even the pure seam cannot supply known absence for UNKNOWN history.
  ::  A configured head still requires the runtime's exact physical read.
  |=  [extra=supplement got=observed:j]
  ^-  observed:j
  ?~  history.extra  [%| %receipt-history-unobserved]
  =/  h=shared-state:archive  u.history.extra
  ?^  writing.h  [%| %receipt-archive-pending]
  ?:  ?=(%| -.got)  got
  ?^  head.h  got
  ?^  p.got  [%| %receipt-history-conflict]
  got
++  valid
  |=  [our=@p grants=grants:pa scalar=records:pa extra=supplement]
  ^-  ?
  =/  records=journal:j  (joined scalar extra)
  ?.  (valid:journal our grants records)  %.n
  ?~  history.extra  %.y
  (shared-valid:archive our u.history.extra grants records)
++  legacy-data
  ::  Decode only the qualified v41 routing to v13. Everything else in this
  ::  full vase stays opaque and exact; this is not global app validation.
  |=  prior=vase
  ^-  legacy
  =/  raw=*  q.prior
  =/  tags=(list @tas)
    ~[%cantrip-judge-state-v41 %cantrip-judge-state-v40 %cantrip-judge-state-v39 %cantrip-judge-state-v38 %cantrip-judge-state-v37 %cantrip-judge-state-v36 %cantrip-judge-state-v35 %cantrip-judge-state-v34 %cantrip-judge-state-v33 %cantrip-judge-state-v32 %cantrip-judge-state-v31 %cantrip-judge-state-v30 %cantrip-judge-state-v29 %cantrip-judge-state-v28 %cantrip-judge-state-v27 %cantrip-judge-state-v26 %cantrip-judge-state-v25 %cantrip-judge-state-v24 %cantrip-judge-state-v23 %cantrip-judge-state-v22 %cantrip-judge-state-v21 %cantrip-judge-state-v20 %cantrip-judge-state-v19 %cantrip-judge-state-v18 %cantrip-judge-state-v17 %cantrip-judge-state-v16 %cantrip-judge-state-v15 %cantrip-judge-state-v14]
  =.  raw
    |-  ^-  *
    ?~  tags  raw
    =/  layer  (need ((soft ,[tag=@tas prior=* tail=*]) raw))
    ?>  &(=(raw layer) =(i.tags tag.layer))
    $(raw prior.layer, tags t.tags)
  =/  old
    (need ((soft ,[%cantrip-judge-state-v13 prior=* grants=grants:pa scalar=records:pa]) raw))
  ?>  =(raw old)
  [grants.old scalar.old]
++  unpack
  |=  [our=@p original=vase]
  ^-  restored
  =/  wrapped=?  ?=([%cantrip-project-bundle-owner-save-v1 *] q.original)
  =/  held=restored
    ?.  wrapped  [original unknown]
    =/  parsed  (need ((soft saved) q.original))
    ?>  =(q.original parsed)
    [prior.parsed extra.parsed]
  =/  old=legacy  (legacy-data prior.held)
  ?>  (valid our grants.old scalar.old extra.held)
  held
++  restore
  ::  Old supported saves acquire UNKNOWN history only. A future actual-DATA
  ::  qualification must establish never-configured provenance separately.
  |=  [our=@p original=vase]
  ^-  (each restored @tas)
  =/  got  (mole |.((unpack our original)))
  ?~  got  [%| %bundle-owner-save-invalid]
  [%& u.got]
++  save
  ::  The future app first saves its current scalar map in its own v13. No
  ::  scalar copy is retained in extra; no prior saved type is reconstructed.
  |=  [our=@p prior=vase extra=supplement]
  ^-  (each vase @tas)
  =/  old  (mole |.((legacy-data prior)))
  ?~  old  [%| %bundle-owner-legacy-invalid]
  ?.  (valid our grants.u.old scalar.u.old extra)
    [%| %bundle-owner-state-invalid]
  [%& !>(`saved`[%cantrip-project-bundle-owner-save-v1 prior extra])]
--
