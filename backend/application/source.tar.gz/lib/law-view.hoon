::  /lib/law-view.hoon
::
::  THE LAW PANEL's reads (ui/law.js), as JSON.  /law/words: bench's
::  governed forbid words and the fixed law's size (bench /x/forbid, read
::  here so the panel never waits on the conversation's board, which a
::  hidden window does not refresh).  /law/acts: cantrip's act window --
::  the regime, and for every act whether it is admissible now,
::  blocked, or never runs on its own (needs the principal's ratification).
::  The window is cantrip's (lib/cantrip-law-window, %x /law/window/current)
::  and its readers are the ones that obey it: the landing court refuses
::  unless %implement is admissible, bench writes a seat's fork only then,
::  viki weighs every act by it.  This only renders it.  The refusals the
::  panel reads from graf (%render-refusal) itself.
::
::  Cantrip down is an answer, not a crash: 503, and nothing is admissible
::  -- every reader above fails closed the same way.
::
::  THE ACT LAW'S ONE WRITE.  POST /law/act/<forbid|allow>/<act> lights the
::  operator's [%forbid-act ...] fact in graf (lib/act-law); cantrip applies
::  it to the window every reader scries.  Same guard as a fork save: the
::  x-pataphor-save header no other site's form can send, and an Origin, if
::  any, of this host.  The fact's author is this ship, never the payload.
::
/-  graf-sur=graf
/+  clw=cantrip-law-window, al=act-law
|%
++  law-path
  |=  url=@t
  ^-  (unit $@(?(%acts %words) [%act verb=?(%forbid %allow) =act:clw]))
  =/  t=tape  (trip url)
  =/  p=tape  (scag (fall (find "?" t) (lent t)) t)
  ?:  =("/apps/pataphor/law/acts" p)  `%acts
  ?:  =("/apps/pataphor/law/words" p)  `%words
  =/  q=(unit path)  (rush (crip p) stap)
  ?.  ?=([~ %apps %pataphor %law %act @ @ ~] q)  ~
  =/  verb  ((soft ?(%forbid %allow)) i.t.t.t.t.u.q)
  =/  a  ((soft act:clw) i.t.t.t.t.t.u.q)
  ?:  |(?=(~ verb) ?=(~ a))  ~
  `[%act u.verb u.a]
::  +act: the operator forbids or allows one act, or why not
++  act
  |=  [our=@p now=@da verb=?(%forbid %allow) a=act:clw headers=(list [key=@t value=@t])]
  ^-  [status=@ud body=@t cards=(list card:agent:gall)]
  =/  hed=(map @t @t)  (malt headers)
  =/  no  |=([s=@ud why=@t] =/(r (say s why) [status.r body.r ~]))
  ?.  =(`'1' (~(get by hed) 'x-pataphor-save'))  (no 403 'An act is forbidden from the law panel (x-pataphor-save).')
  =/  origin=(unit @t)  (~(get by hed) 'origin')
  =/  host=@t  (fall (~(get by hed) 'host') '')
  ?.  |(?=(~ origin) =(u.origin (cat 3 'http://' host)) =(u.origin (cat 3 'https://' host)))
    (no 403 'A change to the law from another site is refused.')
  ?.  .^(? %gu /(scot %p our)/graf/(scot %da now)/$)
    (no 503 'graf is not running, so the act law cannot be recorded (and the irreversible acts are held meanwhile).')
  =/  fact  (fact-of:al verb a our now)
  :*  200
      (en:json:html (pairs:enjs:format ~[['act' s+a] ['verb' s+verb]]))
      ~[[%pass /law-act %agent [our %graf] %poke %graf-action !>(`graf-action:graf-sur`[%light fact])]]
  ==
::  an answer that says why there is none
++  say
  |=  [s=@ud why=@t]
  ^-  [status=@ud body=@t]
  [s (en:json:html (pairs:enjs:format ~[['error' s+why]]))]
++  words
  |=  [our=@p now=@da]
  ^-  [status=@ud body=@t]
  ?.  .^(? %gu /(scot %p our)/bench/(scot %da now)/$)
    (say 503 'bench is not running: the governed words cannot be read (the fixed law still holds)')
  =/  f  ((soft ,[governed=(list [id=@t word=@t]) fixed=@ud]) .^(* %gx /(scot %p our)/bench/(scot %da now)/forbid/noun))
  ?~  f  (say 502 'bench answered something that is not the forbid law')
  :-  200
  %-  en:json:html
  %-  pairs:enjs:format
  :~  ['fixed' (numb:enjs:format fixed.u.f)]
      :-  'governed'
      :-  %a
      %+  turn  governed.u.f
      |=([id=@t word=@t] (pairs:enjs:format ~[['id' s+id] ['word' s+word]]))
  ==
++  acts
  |=  [our=@p now=@da]
  ^-  [status=@ud body=@t]
  ?.  .^(? %gu /(scot %p our)/cantrip/(scot %da now)/$)
    (say 503 'cantrip is not running: no act is admissible (every reader fails closed)')
  =/  w=(unit window:clw)
    ((soft window:clw) .^(* %gx /(scot %p our)/cantrip/(scot %da now)/law/window/current/noun))
  ?~  w  (say 502 'cantrip answered something that is not an act window')
  =/  yours=(set act:clw)  (forbidden-acts:al our now)
  :-  200
  %-  en:json:html
  %-  pairs:enjs:format
  :~  ['regime' s+regime.u.w]
      ['omega' s+omega.u.w]
      ['coherence' s+coherence.u.w]
      ['zeno' s+zeno.u.w]
      ['theta' s+theta.u.w]
      :-  'acts'
      :-  %a
      %+  turn  all-acts:clw
      |=  a=act:clw
      %-  pairs:enjs:format
      :~  ['act' s+a]
          ['admissible' b+(~(has in admissible.u.w) a)]
          ['blocked' b+(~(has in blocked.u.w) a)]
          ['neverAuto' b+(~(has in never-auto.u.w) a)]
          ['forbidden' b+(~(has in yours) a)]
      ==
  ==
--
