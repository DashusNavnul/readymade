::  Ordinary prospective work under the explicitly registered successor policy.
::  A separate typed selected-settlement adapter is required for alternatives;
::  this queue does not accept rows, outcomes or caller-authored receipts.
/+  prior=qpc-instrument-history, admission=qpc-measurement-admission,
    obs=qpc-observation, window=qpc-successor-window
|%
+$  item  item:prior
+$  interruption  interruption:prior
+$  state
  $:  %qpc-successor-history-v1
      queue=(list item)  cursor=@ud  canceled=(map @ux interruption)
      windows=(map @ux state:window)  fault=(unit @tas)
  ==
+$  step  $-([held=state:window value=item] (unit (each state:window @tas)))
++  open
  |=  [s=state b=binding:window m=manifest:obs]
  ^-  state
  ?>  &(!(~(has by windows.s) stream.b) (lth ~(wyt by windows.s) 64))
  =/  begun  (start:window b m)
  ?>  ?=(%& -.begun)
  s(windows (~(put by windows.s) stream.b p.begun))
++  enqueue
  |=  [s=state value=item]
  ^-  state
  ?.  (~(has by windows.s) stream.value)  s
  ?>  &(?=(~ fault.s) (lth (lent queue.s) 512))
  s(queue (weld queue.s ~[value]))
++  reserve
  |=  [s=state r=enrollment:admission]
  ^-  state
  =/  found  (~(get by windows.s) stream.position.r)
  ?~  found  s
  =/  b=binding:window  binding.u.found
  ?>  ?&  (enrollment-valid:admission r)
          =(instrument.b instrument.position.r)  =(manifest.b manifest.contract.r)
          =(policy.b policy.contract.r)
      ==
  ?>  !(lien queue.s |=(x=item &(?=(%work -.body.x) =(id.r enrollment.body.x))))
  (enqueue s [stream.position.r [%work id.r]])
++  interrupt
  |=  [s=state stream=@ux value=interruption]
  ^-  state
  ?>  (interruption-valid:prior value)
  (enqueue s [stream [%gap value]])
++  cancel
  |=  [s=state id=@ux value=interruption]
  ^-  state
  ?>  (interruption-valid:prior value)
  =/  matching=(list item)
    (skim queue.s |=(x=item &(?=(%work -.body.x) =(id enrollment.body.x))))
  ?~  matching  s
  ?:  (consumed s stream.i.matching id)  s
  =/  old  (~(get by canceled.s) id)
  ?^  old
    ?>  =(value u.old)
    s
  s(canceled (~(put by canceled.s) id value))
++  body
  ::  Reuse exactly the ordinary evidence join, including alternatives/gaps.
  ::  Only its canceled map is used; no synthetic v1 window is constructed.
  |=  [s=state x=item admitted=state:admission observed=state:obs]
  ^-  (unit body:window)
  =/  projection=state:prior  *state:prior
  (body:prior projection(canceled canceled.s) x admitted observed)
++  pending-items
  |=  [s=state stream=@ux]
  ^-  (list item)
  =/  rows=(list item)  (skim queue.s |=(x=item =(stream stream.x)))
  =/  held  (~(get by windows.s) stream)
  ?~  held  rows
  (slag next.u.held rows)
++  pending-count
  |=  [s=state stream=@ux]
  (lent (pending-items s stream))
++  pending
  |=  [s=state stream=@ux]
  ?=(^ (pending-items s stream))
++  consumed
  ::  The global cursor is only a contiguous prefix, not every stream's head.
  |=  [s=state stream=@ux enrollment=@ux]
  ^-  ?
  =/  held  (~(get by windows.s) stream)
  ?~  held  %.n
  =/  rows=(list item)  (skim queue.s |=(x=item =(stream stream.x)))
  %+  lien  (scag next.u.held rows)
  |=(x=item &(?=(%work -.body.x) =(enrollment enrollment.body.x)))
++  consumed-count
  |=  s=state
  ^-  @ud
  (roll ~(val by windows.s) |=([w=state:window total=@ud] (add next.w total)))
++  heads
  ::  One unprocessed head per stream, ordered by its original queue position.
  |=  s=state
  ^-  (list item)
  =/  todo=(list item)  queue.s
  =/  seen=(map @ux @ud)  ~
  =/  out=(list item)  ~
  |-  ^-  (list item)
  ?~  todo  (flop out)
  =/  x=item  i.todo
  =/  position=@ud  (~(gut by seen) stream.x 0)
  =.  seen  (~(put by seen) stream.x +(position))
  =/  held  (~(get by windows.s) stream.x)
  ?~  held  $(todo t.todo)
  $(todo t.todo, out ?:(=(position next.u.held) [x out] out))
++  prefix
  ::  Preserve the saved cursor's meaning: longest fully processed prefix.
  |=  s=state
  ^-  @ud
  =/  todo=(list item)  queue.s
  =/  seen=(map @ux @ud)  ~
  =/  position=@ud  0
  |-  ^-  @ud
  ?~  todo  position
  =/  x=item  i.todo
  =/  ordinal=@ud  (~(gut by seen) stream.x 0)
  =/  held  (~(get by windows.s) stream.x)
  ?~  held  position
  ?:  (gte ordinal next.u.held)  position
  $(todo t.todo, seen (~(put by seen) stream.x +(ordinal)), position +(position))
++  current
  |=  [s=state stream=@ux source=@ux]
  ^-  (each reading:window @tas)
  ?^  fault.s  [%| u.fault.s]
  ?:  (pending s stream)  [%| %qpc-successor-work-unresolved]
  =/  found  (~(get by windows.s) stream)
  ?~  found  [%| %qpc-successor-stream-missing]
  (current:window u.found source)
++  advance-with
  ::  Unknown work blocks its own stream. No event passes an earlier event
  ::  of that same stream, and neither its queue slot nor outcome is changed.
  ::  limit remains an absolute global queue frontier, as in earlier owners.
  |=  [s=state limit=@ud run=step]
  ^-  state
  ?^  fault.s  s
  =/  todo=(list item)  (scag limit queue.s)
  =/  seen=(map @ux @ud)  ~
  |-  ^-  state
  ?~  todo  s(cursor (prefix s))
  =/  x=item  i.todo
  =/  position=@ud  (~(gut by seen) stream.x 0)
  =.  seen  (~(put by seen) stream.x +(position))
  =/  held=state:window  (~(got by windows.s) stream.x)
  ?.  =(position next.held)  $(todo t.todo)
  =/  ready  (run held x)
  ?~  ready  $(todo t.todo)
  =/  next=(each state:window @tas)  u.ready
  ?:  ?=(%| -.next)  s(cursor (prefix s), fault `p.next)
  $(todo t.todo, s s(windows (~(put by windows.s) stream.x p.next)))
++  process
  |=  [s=state admitted=state:admission observed=state:obs]
  ^-  step
  |=  [held=state:window value=item]
  ^-  (unit (each state:window @tas))
  =/  ready  (body s value admitted observed)
  ?~  ready  ~
  [~ (append:window held [next.held u.ready])]
++  advance
  |=  [s=state admitted=state:admission observed=state:obs limit=@ud]
  ^-  state
  (advance-with s limit (process s admitted observed))
++  valid-progress
  ::  Rebuild each recorded stream prefix, not every presently ready event.
  ::  Later independent evidence must not invalidate an older saved prefix.
  |=  [s=state run=step]
  ^-  ?
  =/  target=(map @ux state:window)  windows.s
  =/  empty=(map @ux state:window)
    %-  malt
    %+  turn  ~(tap by target)
    |=  [id=@ux value=state:window]
    =/  begun  (start:window binding.value manifest.value)
    ?:(?=(%& -.begun) [id p.begun] !!)
  =/  bounded=step
    |=  [held=state:window value=item]
    ^-  (unit (each state:window @tas))
    =/  expected=state:window  (~(got by target) stream.value)
    ?:  (gte next.held next.expected)  ~
    (run held value)
  =/  rebuilt=state
    (advance-with s(cursor 0, windows empty, fault ~) (lent queue.s) bounded)
  ?.  &(=(cursor.s cursor.rebuilt) =(windows.s windows.rebuilt) ?=(~ fault.rebuilt))  %.n
  ?~  fault.s  %.y
  ::  A global freeze still requires a real error at an unprocessed stream
  ::  head. Preserve old faults without demanding other streams settle first.
  %+  lien  (heads s)
  |=  value=item
  =/  held=state:window  (~(got by windows.s) stream.value)
  =/  attempted  (run held value)
  ?~  attempted  %.n
  =/  result=(each state:window @tas)  u.attempted
  ?:(?=(%| -.result) =(u.fault.s p.result) %.n)
++  valid
  |=  [s=state admitted=state:admission observed=state:obs]
  ^-  ?
  ?.  &((lte (lent queue.s) 512) (lte cursor.s (lent queue.s)) (lte ~(wyt by windows.s) 64))  %.n
  =/  works=(list @ux)
    (murn queue.s |=(x=item ?:(?=(%work -.body.x) `enrollment.body.x ~)))
  ?.  =((lent works) ~(wyt in (silt works)))  %.n
  ?.  (levy ~(tap by canceled.s) |=([id=@ux value=interruption] &((~(has in (silt works)) id) (interruption-valid:prior value))))  %.n
  ?.  %+  levy  ~(tap by windows.s)
      |=  [id=@ux value=state:window]
      =/  begun  (start:window binding.value manifest.value)
      &(=(id stream.binding.value) ?=(%& -.begun))
    %.n
  ?.  %+  levy  queue.s
      |=  x=item
      =/  win  (~(get by windows.s) stream.x)
      ?~  win  %.n
      ?:  ?=(%gap -.body.x)  (interruption-valid:prior +.body.x)
      =/  enrolled  (~(get by enrollments.admitted) enrollment.body.x)
      ?~  enrolled  %.n
      =/  r=enrollment:admission  u.enrolled
      ?&  (enrollment-valid:admission r)  =(stream.x stream.position.r)
          =(instrument.binding.u.win instrument.position.r)
          =(manifest.binding.u.win manifest.contract.r)
          =(policy.binding.u.win policy.contract.r)
      ==
    %.n
  (valid-progress s (process s admitted observed))
--
