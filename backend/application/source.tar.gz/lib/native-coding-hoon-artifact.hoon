::  Private retention of native Ford's complete typed build result.
::  Retrieval/page construction never executes or installs the stored vase.
::  Reuse stays with strandio.build-file and Clay/Ford's dependency cache;
::  this journal does not bind a running compiler identity to old artifacts.
/-  nc=native-coding
/+  project=native-coding-project, tools=cantrip-native-coding,
    build=native-coding-tools
|%
+$  input
  [request=tool-request:nc project=project:nc entry=path revision=revision:nc namespace=(map path @ux) declared=(list [pax=path blob=@ux])]
+$  opaque  [p=* q=*]
+$  artifact
  [%native-coding-hoon-artifact-v1 input=input scope=@ux built=opaque digest=@ux product=@ux runtime=%unbound]
+$  organ
  [%native-coding-hoon-artifacts-v1 records=(map @ux artifact)]
+$  command
  [%native-coding-hoon-artifact-retain-v1 id=@ux value=artifact]
++  empty
  ^-  organ
  [%native-coding-hoon-artifacts-v1 ~]
++  capacity  16
++  byte-limit  8.388.608
++  scope-digest
  |=  value=scope:tools
  ^-  @ux
  (shax (jam value))
++  dependencies
  ::  Owner-declared transitive paths, not a fabricated Ford dependency trace.
  |=  [p=project:nc r=tool-request:nc]
  ^-  (each (list path) @tas)
  =/  selected  (select:build p r)
  ?:  ?=(%| -.selected)  [%| p.selected]
  ?.  =(%hoon backend.p.selected)  [%| %hoon-artifact-backend-required]
  =/  entry=path  entry.p.selected
  ?.  &(?=(^ entry) =(%hoon (rear entry)))  [%| %hoon-artifact-entry-required]
  =/  direct=(list path)
    ?:  ?=(%eval -.arguments.r)  ~
    ?>  ?=(?(%compile %check) -.arguments.r)
    =/  targets=(list build-target:nc)
      (skim targets.p |=(t=build-target:nc =(name.t target.arguments.r)))
    ?>  ?=(^ targets)
    dependencies.i.targets
  =/  todo=(list path)  [entry direct]
  =/  seen=(set path)  ~
  |-  ^-  (each (list path) @tas)
  ?~  todo
    [%& [entry (skim ~(tap in seen) |=(pax=path !=(pax entry)))]]
  =/  pax=path  i.todo
  ?:  (~(has in seen) pax)  $(todo t.todo)
  ?.  &((lth ~(wyt in seen) 128) (readable:project p pax) ?=(^ pax) (path-valid:project pax))
    [%| %hoon-artifact-dependency-bound]
  =/  next=(list path)  (~(gut by dependencies.p) pax ~)
  $(todo (weld next t.todo), seen (~(put in seen) pax))
++  input-valid
  |=  i=input
  ^-  ?
  =/  p=project:nc  project.i
  =/  r=tool-request:nc  request.i
  =/  c=context:nc  context.r
  ?.  ?&  (valid:project p)  (revision-valid:project revision.i)
          =(revision.i source.c)  =(project.c id.spec.p)
          =(configuration.c (configuration:project p))
          =(actor.c authority.spec.p)  =(owner.revision.i authority.spec.p)
          |(=(desk.revision.i working.p) =(desk.revision.i base-desk.spec.p))
          (identifier:tools session.c)  (identifier:tools request.c)
          !=(0 call-id.r)  (lte (met 3 call-id.r) 256)
          (lte ~(wyt by namespace.i) max-files:project)
          (lte (lent declared.i) 128)
      ==
    %.n
  ?.  %+  levy  ~(tap by namespace.i)
      |=  [pax=path blob=@ux]
      &(?=(^ pax) (path-valid:project pax) (lte (met 0 blob) 256))
    %.n
  =/  paths  (dependencies p r)
  ?:  ?=(%| -.paths)  %.n
  ?.  &(=(entry.i (snag 0 p.paths)) =(p.paths (turn declared.i |=(d=[pax=path blob=@ux] pax.d))))
    %.n
  %+  levy  declared.i
  |=  d=[pax=path blob=@ux]
  =(`blob.d (~(get by namespace.i) pax.d))
++  prepare
  ::  No caller-supplied namespace is accepted as a canonical read.
  |=  [our=@p now=@da p=project:nc r=tool-request:nc]
  ^-  (each input @tas)
  =/  catalog  (catalog:project our now p)
  ?:  ?=(%| -.catalog)  [%| p.catalog]
  =/  allowed  (authorize:project p p.catalog context.r -.arguments.r)
  ?:  ?=(%| -.allowed)  [%| p.allowed]
  =/  paths  (dependencies p r)
  ?:  ?=(%| -.paths)  [%| p.paths]
  =/  source=revision:nc  source.context.r
  =/  tree  (tree-at:project our now p desk.source number.source)
  ?:  ?=(%| -.tree)  [%| p.tree]
  ?.  =(source revision.p.tree)  [%| %hoon-artifact-source-mismatch]
  =/  namespace=(map path @ux)  files.body.snapshot.p.tree
  ?.  (levy p.paths |=(pax=path (~(has by namespace) pax)))
    [%| %hoon-artifact-dependency-missing]
  =/  declared=(list [pax=path blob=@ux])
    (turn p.paths |=(pax=path [pax (~(got by namespace) pax)]))
  =/  value=input  [r p (snag 0 p.paths) source namespace declared]
  ?.  (input-valid value)  [%| %hoon-artifact-input-invalid]
  [%& value]
++  digest
  |=  a=artifact
  ^-  @ux
  (shax (jam [%native-coding-hoon-artifact-v1 input.a scope.a built.a product.a runtime.a]))
++  artifact-valid
  |=  [id=@ux a=artifact]
  ^-  ?
  ?&  =(id (key:tools request.input.a))
      (identifier:tools id)  (lte (met 0 scope.a) 256)
      (lte (met 3 (jam a)) byte-limit)  (input-valid input.a)
      =(product.a (shax (jam q.built.a)))  =(digest.a (digest a))
      =(%unbound runtime.a)
  ==
++  make
  ::  A typed candidate for retention, not admission or a build certificate.
  |=  [i=input scope=@ux built=vase]
  ^-  (each artifact @tas)
  (make-data i scope [p.built q.built])
++  make-data
  ::  Remote results remain opaque DATA. The authenticated caller must bind
  ::  them to its current input and scope; this constructor grants nothing.
  ::  Never reconstruct a vase or execute either stored field here.
  |=  [i=input scope=@ux built=opaque]
  ^-  (each artifact @tas)
  =/  a=artifact
    [%native-coding-hoon-artifact-v1 i scope built 0x0 (shax (jam q.built)) %unbound]
  =.  digest.a  (digest a)
  ?.  (artifact-valid (key:tools request.i) a)  [%| %hoon-artifact-invalid]
  [%& a]
++  valid
  |=  s=organ
  ^-  ?
  &((lte ~(wyt by records.s) capacity) (levy ~(tap by records.s) artifact-valid))
++  get
  |=  [s=organ id=@ux]
  ^-  (unit artifact)
  (~(get by records.s) id)
++  act
  |=  [b=bowl:gall s=organ jobs=organ:tools c=command]
  ^-  (each organ @tas)
  ?.  =(our.b src.b)  [%| %hoon-artifact-owner-required]
  =/  prior  (get s id.c)
  ?^  prior
    ?:  =(u.prior value.c)  [%& s]
    [%| %hoon-artifact-retention-conflict]
  ?:  (gte ~(wyt by records.s) capacity)  [%| %hoon-artifact-capacity]
  ?.  (artifact-valid id.c value.c)  [%| %hoon-artifact-invalid]
  =/  admitted  (~(get by records.jobs) id.c)
  ?~  admitted  [%| %hoon-artifact-admission-missing]
  ?.  &(=(%running stage.u.admitted) =(request.input.value.c request.u.admitted))
    [%| %hoon-artifact-admission-mismatch]
  =/  scope  (~(get by grants.jobs) grant.u.admitted)
  ?~  scope  [%| %hoon-artifact-grant-missing]
  ?.  &(=(scope.value.c (scope-digest u.scope)) =(project.input.value.c project.grant.u.scope))
    [%| %hoon-artifact-scope-mismatch]
  =/  permission  (allowed:tools our.b now.b u.scope request.input.value.c)
  ?:  ?=(%| -.permission)  [%| p.permission]
  ?.  (pending:tools our.b now.b request.input.value.c)
    [%| %hoon-artifact-request-not-pending]
  =/  exact  (prepare our.b now.b project.input.value.c request.input.value.c)
  ?:  ?=(%| -.exact)  [%| p.exact]
  ?.  =(p.exact input.value.c)  [%| %hoon-artifact-frozen-source-mismatch]
  [%& s(records (~(put by records.s) id.c value.c))]
++  path-for
  |=  a=artifact
  ^-  path
  /native-coding/hoon/(scot %ux digest.a)/noun
++  page
  ::  DATA only. A private Clay write still needs its own exact before-image,
  ::  durable submitted journal, one info card and canonical observation.
  |=  a=artifact
  ^-  (each page:clay @tas)
  ?.  (artifact-valid (key:tools request.input.a) a)  [%| %hoon-artifact-invalid]
  [%& [%noun a]]
--
