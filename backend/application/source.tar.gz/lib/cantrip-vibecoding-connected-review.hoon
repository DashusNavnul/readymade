::  Native bounded inspection of exact source DATA and opaque provider claims.
::  No derivation, write card, compiler, evaluator, or acceptance capability.
::  Canonical callers supply attribution/current evidence; pure inputs cannot
::  authenticate themselves. Transport stays unverified until native intake.
/-  cr=vibecoding-connected-review, vc=vibecoding-candidate,
    cs=vibecoding-check-spec, itn=intent
/+  vcl=vibecoding-candidate, provider=vibecoding-provider,
    selected=vibecoding-selected-approval, clw=cantrip-law-window,
    project=vibecoding-project-read, demo=vibecoding-demo
|%
++  file-hash
  |=  source=@t
  ^-  @ux
  `@ux`(shax (jam [[~ (page-to-lobe:clay [%hoon source])] `@uv`0]))
++  source-valid
  |=  source=@t
  ^-  ?
  ?&  (gth (met 3 source) 0)  (lte (met 3 source) 4.096)
      (levy (trip source) |=(c=@t |(=(c 10) &((gte c 32) (lte c 126)))))
  ==
++  build
  |=  [our=@p at=@da candidate=candidate:vc window=window:clw]
  ^-  result:cr
  =/  packet=packet:vc  packet.candidate
  ?.  ?=([%vibecoding-candidate-packet-v5 *] -.packet)
    [%| %selected-packet-required]
  =/  context=context:vc  context.packet
  ?.  =(our by.intent.intent.context)  [%| %foreign-actor]
  ?.  &((gte at at.candidate) (lte frozen-at.version.packet at.candidate))
    [%| %time-invalid]
  ?.  &(=(0 wgt.oracle.ask.want.inference.packet) (packet-valid:vcl packet))
    [%| %packet-invalid]
  =/  inspected
    (inspect:vcl packet request.candidate reply.candidate base.context work.context at.candidate)
  ?.  =([%& candidate] inspected)  [%| %candidate-invalid]
  =/  receipt
    (inspect:provider choice.version.packet spec.packet request.candidate reply.candidate)
  ?:  ?=(%| -.receipt)  [%| p.receipt]
  ?.  (source-valid source.candidate)  [%| %source-invalid]
  ?.  =(law.context (digest:vcl window))  [%| %law-changed]
  ?.  ?&  (~(has in admissible.window) %inspect)
          (~(has in admissible.window) %compare)
          !(~(has in blocked.window) %inspect)
          !(~(has in blocked.window) %compare)
          !(~(has in never-auto.window) %inspect)
          !(~(has in never-auto.window) %compare)
      ==
    [%| %review-not-admitted]
  =/  binding=binding:cr
    :*  (digest:vcl packet)  (digest:vcl context)
        (digest:vcl approval.version.packet)  selection.p.receipt
        (digest:vcl request.candidate)  (digest:vcl reply.candidate)
        (digest:vcl source.candidate)
    ==
  =/  body=body:cr
    :*  our  at  candidate  p.receipt  binding  window
        target:demo  (file-hash before.context)  (file-hash source.candidate)
        %unknown  %unverified  %unverified  %none  %unverified
        %review-only  %not-run  %not-approved
    ==
  [%& [%vibecoding-connected-review-v1 body (digest:vcl body)]]
++  judge
  |=  $:  our=@p  actor=@p  at=@da  candidate=candidate:vc
          rows=(list attested:cs)  intent=(unit record:itn)
          baseline=(unit snapshot:project)  window=window:clw
      ==
  ^-  result:cr
  ?.  =(our actor)  [%| %foreign-actor]
  =/  packet=packet:vc  packet.candidate
  ?.  ?=([%vibecoding-candidate-packet-v5 *] -.packet)
    [%| %selected-packet-required]
  =/  authenticated  (authenticate:selected our actor at packet rows)
  ?:  ?=(%| -.authenticated)  [%| p.authenticated]
  ?.  =(`intent.context.packet intent)  [%| %intent-changed]
  ?.  (matches:project context.packet baseline)  [%| %project-changed]
  (build our at candidate window)
++  valid
  |=  r=record:cr
  ^-  ?
  =([%& r] (build owner.body.r at.body.r candidate.body.r window.body.r))
++  fact
  |=  r=record:cr
  ^-  *
  [%vibecoding-connected-review (scot %ux digest.r) r]
++  build-v2
  ::  Pure reconstruction. Attribution/current evidence belongs to judge-v2;
  ::  native replay and a downstream write consumer remain separate gates.
  |=  [our=@p at=@da candidate=candidate-v4:vc window=window:clw]
  ^-  result-v2:cr
  =/  packet=selected-v2:vc  packet.candidate
  =/  context=context:vc  context.packet
  ?.  =(our by.intent.intent.context)  [%| %foreign-actor]
  ?.  &((gte at at.candidate) (lte frozen-at.version.packet at.candidate))
    [%| %time-invalid]
  ?.  =(0 wgt.oracle.ask.want.inference.packet)  [%| %packet-invalid]
  =/  inspected
    (inspect-v2:vcl packet request.candidate reply.candidate base.context work.context at.candidate)
  ?:  ?=(%| -.inspected)  [%| p.inspected]
  ?.  =(candidate candidate.p.inspected)  [%| %candidate-invalid]
  ?.  (source-valid source.candidate)  [%| %source-invalid]
  ?.  =(law.context (digest:vcl window))  [%| %law-changed]
  ?.  ?&  (~(has in admissible.window) %inspect)
          (~(has in admissible.window) %compare)
          !(~(has in blocked.window) %inspect)
          !(~(has in blocked.window) %compare)
          !(~(has in never-auto.window) %inspect)
          !(~(has in never-auto.window) %compare)
      ==
    [%| %review-not-admitted]
  =/  binding=binding:cr
    :*  (digest:vcl packet)  (digest:vcl context)
        (digest:vcl approval.version.packet)  selection.provider.p.inspected
        (digest:vcl request.candidate)  (digest:vcl reply.candidate)
        (digest:vcl source.candidate)
    ==
  =/  body=body-v2:cr
    :*  our  at  candidate  provider.p.inspected  binding  window
        target:demo  (file-hash before.context)  (file-hash source.candidate)
        %unknown  %unverified  %unverified  %none  %unverified
        %review-only  %not-run  %not-approved
    ==
  [%& [%vibecoding-connected-review-v2 body (digest:vcl body)]]
++  valid-v2
  |=  r=record-v2:cr
  ^-  ?
  =([%& r] (build-v2 owner.body.r at.body.r candidate.body.r window.body.r))
++  judge-v2
  |=  $:  our=@p  actor=@p  at=@da  candidate=candidate-v4:vc
          rows=(list attested:cs)  intent=(unit record:itn)
          baseline=(unit snapshot:project)  window=window:clw
      ==
  ^-  result-v2:cr
  ?.  =(our actor)  [%| %foreign-actor]
  =/  packet=selected-v2:vc  packet.candidate
  =/  authenticated  (authenticate-v2:selected our actor at packet rows)
  ?:  ?=(%| -.authenticated)  [%| p.authenticated]
  ?.  =(`intent.context.packet intent)  [%| %intent-changed]
  ?.  (matches:project context.packet baseline)  [%| %project-changed]
  (build-v2 our at candidate window)
--
