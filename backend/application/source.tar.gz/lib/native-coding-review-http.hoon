::  Presentation of Viki's retained candidate reviews and Cantrip grants.
::  No credentials, executable artifacts, judgments or grants are accepted here.
/-  nc=native-coding
/+  review=native-coding-review, judge=native-coding-judgment,
    tools=cantrip-native-coding, guard=viki-scry-guard, context=native-coding-context,
    files=native-coding-files-http
|%
++  landed
  |=  observed=(unit record:accept:review)
  ^-  json
  ?~  observed  ~
  ?.  =(%applied stage.u.observed)  ~
  ?~  landed.u.observed  ~
  (revision:files revision.u.landed.u.observed)
++  reviews
  |=  [our=@p at=@da session=@ux]
  ^-  json
  ?.  (agent-live:guard our at %viki)  a+~
  =/  all=state:review
    .^(state:review %gx /(scot %p our)/viki/(scot %da at)/native-coding/reviews/noun)
  =/  rows=(list [@ux entry:review])
    (skim ~(tap by all) |=([id=@ux e=entry:review] =(session session.context.candidate.e)))
  :-  %a
  %+  turn  (scag 8 rows)
  |=  [id=@ux e=entry:review]
  =/  c=candidate:nc  candidate.e
  =/  stage=@t  ?~(observed.e 'requested' stage.u.observed.e)
  =/  checks=(list json)
    ?~  observed.e  ~
    ?~  report.u.observed.e  ~
    %-  zing
    %+  turn  targets.u.report.u.observed.e
    |=  result=target-result:accept:review
    %+  turn  diagnostics.result
    |=  d=diagnostic:nc
    (pairs:enjs:format ~[['target' s+name.target.result] ['check' s+name.d] ['passed' b+passed.d] ['detail' s+(clipped:context detail.d 512)]])
  =/  edits=(list json)
    %+  turn  edits.c
    |=  e=edit:nc
    (pairs:enjs:format ~[['path' s+(spat path.change.e)] ['kind' s+kind.change.e] ['before' s+?~(before.change.e '' (scot %ux u.before.change.e))] ['after' s+?~(after.change.e '' (scot %ux u.after.change.e))]])
  =/  artifact=@t
    ?~  observed.e  ''
    ?~  report.u.observed.e  ''
    (artifact:judge c u.report.u.observed.e objective.e)
  (pairs:enjs:format ~[['id' s+(scot %ux id)] ['session' s+(scot %ux session.context.c)] ['request' s+(scot %ux request.context.c)] ['actor' s+(scot %p actor.context.c)] ['sourceId' s+(scot %ux (shax (jam source.context.c)))] ['stage' s+stage] ['workspace' s+?~(workspace.e '' u.workspace.e)] ['artifact' s+artifact] ['decision' s+?~(decision.e 'pending' verdict.u.decision.e)] ['source' s+(scot %ud number.source.context.c)] ['basis' (revision:files source.context.c)] ['landed' (landed observed.e)] ['reason' s+?~(observed.e '' ?~(reason.u.observed.e '' (scot %tas u.reason.u.observed.e)))] ['edits' a+edits] ['checkCount' (numb:enjs:format (lent checks))] ['checks' a+(scag 8 checks)]])
++  grants
  |=  [our=@p at=@da session=@ux]
  ^-  json
  ?.  (agent-live:guard our at %cantrip)  a+~
  =/  all=(map @ux scope:tools)
    .^((map @ux scope:tools) %gx /(scot %p our)/cantrip/(scot %da at)/native-coding/grants/noun)
  =/  rows=(list [@ux scope:tools])
    (skim ~(tap by all) |=([id=@ux g=scope:tools] =(session session.grant.g)))
  :-  %a
  %+  turn  (scag 32 rows)
  |=  [id=@ux g=scope:tools]
  (pairs:enjs:format ~[['id' s+(scot %ux id)] ['revoked' b+?=(^ revoked.g)] ['operations' a+(turn ~(tap in operations.grant.g) |=(o=operation:nc s+o))] ['inspections' a+(turn ~(tap in inspections.grant.g) |=([app=@tas pax=path] (pairs:enjs:format ~[['app' s+app] ['path' s+(spat pax)]])))] ['readable' a+(turn ~(tap in readable.policy.project.grant.g) |=(p=path s+(spat p)))] ['writable' a+(turn ~(tap in writable.policy.project.grant.g) |=(p=path s+(spat p)))] ['protected' a+(turn ~(tap in protected.policy.project.grant.g) |=(p=path s+(spat p)))]])
--
