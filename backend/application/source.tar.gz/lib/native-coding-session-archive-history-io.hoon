::  One-write private Clay adapter. It does not activate an app or retire a
::  session. Callers must derive receipts from current qualified owner data.
/+  history=native-coding-session-archive-history,
    receipt=native-coding-session-archive-retirement,
    listing=native-coding-session-archive-list
|%
+$  found  (each (unit receipt:receipt) @tas)
+$  change  [state=state:history cards=(list card:agent:gall)]
++  beam
  |=  [our=@p h=head:history pax=path]
  ^-  path
  (weld ~[(scot %p our) desk.h (scot %ud number.h)] pax)
++  private
  |=  [our=@p at=@da desk=@tas pax=path]
  ^-  ?
  =/  rules=[r=dict:clay w=dict:clay]
    .^([r=dict:clay w=dict:clay] %cp (weld ~[(scot %p our) desk (scot %da at)] pax))
  &(=([%white ~ ~] rul.r.rules) =([%white ~ ~] rul.w.rules))
++  safe-with
  ::  Only the two standard Clay metadata watches are allowed. Project or
  ::  importer reservations and every app watch make the desk unavailable.
  |=  [our=@p desk=@tas v=(set @tas) c=(set @tas) i=(set @tas) watchers=(set [@p rave:clay])]
  ^-  ?
  ?.  &(!(~(has in v) desk) !(~(has in c) desk) !(~(has in i) desk))  %.n
  %+  levy  ~(tap in watchers)
  |=  [who=@p request=rave:clay]
  ?.  =(our who)  %.n
  ?:  ?=([%next %z * ~] request)  %.y
  ?:(?=(%next -.request) &(=(%z care.mood.request) =(/desk/docket-0 path.mood.request)) %.n)
++  safe
  |=  [our=@p at=@da desk=@tas]
  ^-  ?
  ?.  .^(? %gu /(scot %p our)/viki/(scot %da at)/$)  %.n
  ?.  .^(? %gu /(scot %p our)/cantrip/(scot %da at)/$)  %.n
  ?.  .^(? %gu /(scot %p our)/native-coding-source-import/(scot %da at)/$)  %.n
  =/  v=(set @tas)  .^((set @tas) %gx /(scot %p our)/viki/(scot %da at)/native-coding/reserved-desks/except-session-history/[desk]/noun)
  =/  c=(set @tas)  .^((set @tas) %gx /(scot %p our)/cantrip/(scot %da at)/native-coding/reserved-desks/noun)
  =/  i=(set @tas)  .^((set @tas) %gx /(scot %p our)/native-coding-source-import/(scot %da at)/reservations/noun)
  =/  raw=*  .^(* %cx /(scot %p our)//(scot %da at)/cult/[desk])
  =/  watchers  ((soft ,(set [@p rave:clay])) raw)
  ?~  watchers  %.n
  (safe-with our desk v c i u.watchers)
++  current
  |=  [our=@p at=@da desk=@tas]
  ^-  (unit head:history)
  =/  domes=cone:clay  .^(cone:clay %cx /(scot %p our)//(scot %da at)/domes)
  =/  d  (~(get by domes) [our desk])
  ?~  d  ~
  ?.  &(=(%dead liv.u.d) =(~ ren.u.d) =(~ wic.u.d))  ~
  ?.  (safe our at desk)  ~
  ?.  &((private our at desk /) (private our at desk /native-coding-session-history))  ~
  =/  commit  (~(get by hit.u.d) let.u.d)
  ?~  commit  ~
  =/  h=head:history  [desk let.u.d u.commit]
  ?:  (valid-head:history h)  `h
  ~
++  configure
  |=  [b=bowl:gall s=state:history desk=@tas]
  ^-  (each state:history @tas)
  ?.  =(our.b src.b)  [%| %archive-owner-required]
  ?^  head.s  [%| %archive-history-already-configured]
  ?^  writing.s  [%| %archive-write-pending]
  =/  h  (current our.b now.b desk)
  ?~  h  [%| %archive-history-unavailable]
  =/  root=arch  .^(arch %cy (beam our.b u.h /native-coding-session-history))
  ?.  &(=(~ fil.root) =(~ dir.root))  [%| %archive-history-not-empty]
  [%& [`u.h ~]]
++  lookup
  |=  [our=@p at=@da h=head:history id=@ux]
  ^-  found
  ?.  =(`h (current our at desk.h))  [%| %archive-history-unavailable]
  =/  pax=path  (path-for:history id)
  ?.  (private our at desk.h pax)  [%| %archive-history-not-private]
  =/  path=path  (beam our h pax)
  ::  This is the exact file path, not a directory: Clay %u checks its
  ::  content directly without scanning the archive's directory tree.
  ?.  .^(? %cu path)  [%& ~]
  =/  raw=*  .^(* %cx path)
  =/  parsed  ((soft receipt:receipt) raw)
  ?~  parsed  [%| %archive-receipt-invalid]
  ?.  &(=(raw u.parsed) =(id session.u.parsed) (valid-receipt:receipt our u.parsed))
    [%| %archive-receipt-invalid]
  [%& parsed]
++  history-page
  ::  Later pages bind the exact first-page head, so a concurrent write is
  ::  reported as stale instead of silently skipping or repeating sessions.
  |=  [b=bowl:gall s=state:history expected=(unit head:history) offset=@ud limit=@ud]
  ^-  (each page:listing @tas)
  ?.  =(our.b src.b)  [%| %archive-owner-required]
  ?~  head.s  [%| %archive-history-unconfigured]
  ?.  &((gte limit 1) (lte limit 64))  [%| %archive-page-limit-invalid]
  ?.  ?~(expected =(0 offset) %.y)  [%| %archive-page-head-required]
  ?.  ?~(expected %.y =(u.expected u.head.s))  [%| %archive-history-changed]
  ?.  =(head.s (current our.b now.b desk.u.head.s))  [%| %archive-history-unavailable]
  ?.  (private our.b now.b desk.u.head.s /native-coding-session-history/by-session)
    [%| %archive-history-not-private]
  =/  node=arch  .^(arch %cy (beam our.b u.head.s /native-coding-session-history/by-session))
  (select:listing u.head.s dir.node offset limit)
++  wire-for
  |=  [h=head:history e=receipt:receipt]
  ^-  wire
  /native-coding-session-archive/(scot %ud +(number.h))/(scot %ux (shax (jam e)))
++  append-with
  ::  Current head and known absence come from native observations. Unknown
  ::  is never treated as absence. Pending is returned with the one write.
  |=  [b=bowl:gall s=state:history e=receipt:receipt now-head=(unit head:history) previous=found]
  ^-  (each change @tas)
  ?.  =(our.b src.b)  [%| %archive-owner-required]
  ?~  head.s  [%| %archive-history-unconfigured]
  ?.  =(head.s now-head)  [%| %archive-history-changed]
  ?:  ?=(%| -.previous)  [%| %archive-history-unavailable]
  ?^  p.previous  [%| %archive-session-already-recorded]
  =/  started  (begin:history our.b src.b s e)
  ?:  ?=(%| -.started)  [%| p.started]
  =/  h=head:history  u.head.s
  =/  wire=wire  (wire-for h e)
  =/  cards=(list card:agent:gall)
    :~
      [%pass wire %arvo %c %info desk.h [%& [[(path-for:history session.e) %ins %noun !>(e)] ~]]]
      [%pass wire %arvo %c %warp our.b desk.h ~ %sing %z [%ud +(number.h)] /]
    ==
  [%& [p.started cards]]
++  append
  |=  [b=bowl:gall s=state:history e=receipt:receipt]
  ^-  (each change @tas)
  ?~  head.s  [%| %archive-history-unconfigured]
  =/  h=head:history  u.head.s
  (append-with b s e (current our.b now.b desk.h) (lookup our.b now.b h session.e))
++  observe-with
  ::  The adapter supplies exact numbered Clay commits and record readback.
  |=  [b=bowl:gall s=state:history after=head:history old=yaki:clay new=yaki:clay cold=found]
  ^-  (each confirmed:history @tas)
  ?:  ?=(%| -.cold)  [%| %archive-history-unavailable]
  (confirm:history our.b src.b s after old new p.cold)
++  observe
  |=  [b=bowl:gall s=state:history]
  ^-  (each confirmed:history @tas)
  ?.  =(our.b src.b)  [%| %archive-owner-required]
  ?~  head.s  [%| %archive-history-unconfigured]
  ?~  writing.s  [%| %archive-write-not-pending]
  =/  before=head:history  u.head.s
  =/  after  (current our.b now.b desk.before)
  ?~  after  [%| %archive-history-unavailable]
  =/  old=yaki:clay
    .^(yaki:clay %cs /(scot %p our.b)/[desk.before]/(scot %da now.b)/yaki/(scot %uv commit.before))
  =/  new=yaki:clay
    .^(yaki:clay %cs /(scot %p our.b)/[desk.before]/(scot %da now.b)/yaki/(scot %uv commit.u.after))
  (observe-with b s u.after old new (lookup our.b now.b u.after session.u.writing.s))
++  callback
  |=  [b=bowl:gall s=state:history w=wire sign=sign-arvo]
  ^-  (each confirmed:history @tas)
  ?.  &(=(our.b src.b) ?=([%clay %writ *] sign))  [%| %archive-callback-invalid]
  ?~  head.s  [%| %archive-history-unconfigured]
  ?~  writing.s  [%| %archive-write-not-pending]
  ?.  =(w (wire-for u.head.s u.writing.s))  [%| %archive-callback-invalid]
  (observe b s)
--
