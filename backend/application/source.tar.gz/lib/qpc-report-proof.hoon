::  Codec fixtures are not observations and must never populate a baseline.
/+  report=qpc-report
|%
++  wire
  |=  [manifest=@ux rows=(list json)]
  ^-  @t
  (en:json:html [%a ~[[%s 'qpc-prospective-report-v1'] [%s (scot %ux manifest)] [%a rows]]])
++  item
  |=  [call=@t values=(list json)]
  ^-  json
  [%a ~[[%s call] [%a values]]]
++  refused
  |=  [manifest=@ux dimensions=@ud calls=(list @t) text=@t]
  =/  decoded  (decode:report manifest dimensions calls text)
  ?=(%| -.decoded)
++  prove
  =/  a=json  (item 'call_a' ~[[%n '0'] [%n '1000000']])
  =/  b=json  (item 'call_b' ~[[%n '750000'] [%n '600000']])
  =/  good=@t  (wire 0x1234 ~[a b])
  =/  read  (decode:report 0x1234 2 ~['call_a' 'call_b'] good)
  ?>  ?=(%& -.read)
  ?>  =(`(list row:report)`~[['call_a' ~[0 1.000.000]] ['call_b' ~[750.000 600.000]]] p.read)
  ::  Malformed numbers cannot silently become clamped, rounded, or zero.
  =/  bad=(list json)
    ~[[%n '-1'] [%n '1000001'] [%n '0.5'] [%n '1e6'] [%s '750000'] [%b %.y] ~]
  ?>  %+  levy  bad
      |=  number=json
      =/  encoded=@t  (wire 0x1234 ~[(item 'call_a' ~[number [%n '0']])])
      =/  decoded  (decode:report 0x1234 2 ~['call_a'] encoded)
      ?=(%| -.decoded)
  ?>  (refused 0x1234 3 ~['call_a' 'call_b'] good)
  ?>  (refused 0x1234 1 ~['call_a' 'call_b'] good)
  ?>  (refused 0x1234 17 ~['call_a' 'call_b'] good)
  ?>  (refused 0x9999 2 ~['call_a' 'call_b'] good)
  ?>  (refused 0x0 2 ~['call_a' 'call_b'] good)
  ?>  (refused 0x1234 2 ~['call_b' 'call_a'] good)
  ?>  (refused 0x1234 2 ~['call_a' 'call_a'] (wire 0x1234 ~[a a]))
  ?>  (refused 0x1234 2 ~['call_a' 'call_b'] (wire 0x1234 ~[a a]))
  ?>  (refused 0x1234 2 ~['call_a'] good)
  ?>  (refused 0x1234 2 ~['call_a' 'call_b'] (wire 0x1234 ~[a]))
  ?>  (refused 0x1234 2 ~['call_a'] '')
  ?>  (refused 0x1234 2 ~['call_a'] 'I am 90% confident.')
  ?>  (refused 0x1234 2 ~['call_a'] '["qpc-prospective-report-v1","0x1234",[["call_a",[0,1]]]] trailing')
  ?>  (refused 0x1234 2 ~['call_a'] '{"call_a":[0,1],"call_a":[1,0]}')
  ?>  !(bounded-json:report '[[[[[0]]]]]')
  ?>  !(bounded-json:report '[[0]')
  ?>  !(bounded-json:report ']')
  ::  Inert string characters must not trip the depth preflight.
  =/  odd=@t  'call_[{}]"\\'
  =/  one=@t  (wire 0x1234 ~[(item odd ~[[%n '1'] [%n '2']])])
  =/  escaped  (decode:report 0x1234 2 ~[odd] one)
  ?>  ?=(%& -.escaped)
  =/  oversized=@t  (crip (reap 8.193 ' '))
  ?>  (refused 0x1234 2 ~['call_a'] oversized)
  [%qpc-report-proof-v1 %literal-millionths %exact-call-binding %bounded-wire]
--
