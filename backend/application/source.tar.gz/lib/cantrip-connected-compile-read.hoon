::  Future Cantrip hooks supply their OWN retained nonce entries and CURRENT
::  law window. Caller-provided copies are not authority. No self-scry of
::  Cantrip journals or law; external reads are Graf, Viki and private Clay.
/-  vc=vibecoding-candidate, itn=intent
/+  core=cantrip-connected-compile, old=cantrip-vibecoding-compile,
    old-read=cantrip-vibecoding-compile-read,
    result=vibecoding-connected-result, write=cantrip-connected-write,
    editor=cantrip-editor-save, editor-read=cantrip-editor-save-read,
    history=vibecoding-check-context-read, vcl=vibecoding-candidate,
    clw=cantrip-law-window
|%
+$  owned  [entry=(unit entry:write) saved=(unit record:editor)]
+$  evidence  [binding=binding:old view=view:result stated=(unit record:itn)]
++  context
  |=  [our=@p actor=@p at=@da nonce=@ux binding-key=@ux own=owned]
  ^-  (each evidence @tas)
  ?.  =(our actor)  [%| %foreign-actor]
  ?.  &(!=(0 nonce) (lte (met 0 nonce) 128))  [%| %nonce-invalid]
  ?~  entry.own  [%| %journal-missing]
  =/  e=entry:write  u.entry.own
  ?.  &(=(our owner.e) =(nonce nonce.request.e))  [%| %journal-mismatch]
  ?.  ?=(%submitted -.state.e)  [%| %write-not-submitted]
  ?~  saved.own  [%| %editor-record-missing]
  =/  receipt=receipt:result  [%vibecoding-connected-write-readback-v1 e u.saved.own]
  ?.  (linked:result our at receipt)  [%| %result-invalid]
  =/  rows  (history:history our actor at)
  ?:  ?=(%| -.rows)  [%| p.rows]
  =/  binding  (binding:old-read our (owned:old-read our at) binding-key)
  ?:  ?=(%| -.binding)  [%| p.binding]
  =/  packet=packet:vc  packet.candidate.body.review.body.intake.state.e
  ?.  .^(? %gx /(scot %p our)/graf/(scot %da at)/contains/(scot %uw (jam (packet-fact:vcl packet)))/noun)
    [%| %packet-not-retained]
  =/  current  (read:editor-read our actor at)
  ?:  ?=(%| -.current)  [%| p.current]
  =/  view  (build:result our actor at nonce entry.own saved.own p.rows current)
  ?:  ?=(%| -.view)  [%| p.view]
  =/  context  (context-of:vcl packet)
  [%& [p.binding p.view (intent:history our at id.intent.intent.context)]]
++  read
  |=  [our=@p actor=@p at=@da nonce=@ux binding-key=@ux own=owned window=window:clw]
  ^-  (each snapshot:core @tas)
  =/  found  (mule |.((context our actor at nonce binding-key own)))
  ?:  ?=(%| -.found)  [%| %read-unavailable]
  ?:  ?=(%| -.p.found)  [%| p.p.found]
  =/  e=evidence  p.p.found
  (freeze:core our actor at binding.e view.e stated.e window)
++  admit
  |=  [our=@p actor=@p at=@da s=snapshot:core own=owned window=window:clw]
  ^-  decision:core
  -:(admit-evidence our actor at s own window)
::  +admit-evidence: the decision with the evidence it was judged on, so the
::  caller can keep a receipt of the judgment (lib/cantrip-compile-flect)
::  without reading Clay twice.  No evidence when the read itself failed.
++  admit-evidence
  |=  [our=@p actor=@p at=@da s=snapshot:core own=owned window=window:clw]
  ^-  [decision:core (unit evidence)]
  ?.  =(our actor)  [[%| %foreign-actor] ~]
  ?.  &((valid:core s) =(our owner.order.s))  [[%| %snapshot-invalid] ~]
  =/  found
    %-  mule
    |.  (context our actor at nonce.commitment.s (digest:vcl binding.commitment.s) own)
  ?:  ?=(%| -.found)  [[%| %read-unavailable] ~]
  ?:  ?=(%| -.p.found)  [[%| p.p.found] ~]
  =/  e=evidence  p.p.found
  ::  a changed binding is the READ's refusal, not the judge's: no evidence
  ?.  =(binding.e binding.commitment.s)  [[%| %compiler-binding-changed] ~]
  [(admit:core our actor at s view.e stated.e window) `e]
+$  owned-v2  [entry=(unit entry-v2:write) saved=(unit record:editor)]
+$  evidence-v2  [binding=binding:old view=view-v2:result stated=(unit record:itn)]
++  context-v2
  ::  Only the future owning hook supplies these retained Cantrip entries.
  |=  [our=@p actor=@p at=@da nonce=@ux binding-key=@ux own=owned-v2]
  ^-  (each evidence-v2 @tas)
  =/  found  (source-context-v2 our actor at nonce binding-key own)
  ?:  ?=(%| -.found)  [%| p.found]
  =/  e=evidence-v2  p.found
  =/  written  entry.receipt.view.e
  ?>  ?=(%submitted -.state.written)
  =/  packet=selected-v2:vc  packet.candidate.body.review.body.intake.state.written
  [%& e(stated (intent:history our at id.intent.intent.context.packet))]
++  source-context-v2
  ::  Exact canonical source/binding evidence, with NO Viki intent scry.
  ::  Viki's owning hook supplies its current organ record after this read.
  |=  [our=@p actor=@p at=@da nonce=@ux binding-key=@ux own=owned-v2]
  ^-  (each evidence-v2 @tas)
  ?.  =(our actor)  [%| %foreign-actor]
  ?.  &(!=(0 nonce) (lte (met 0 nonce) 128))  [%| %nonce-invalid]
  ?~  entry.own  [%| %journal-missing]
  =/  e=entry-v2:write  u.entry.own
  ?.  &(=(our owner.e) =(nonce nonce.request.e))  [%| %journal-mismatch]
  ?.  ?=(%submitted -.state.e)  [%| %write-not-submitted]
  ?~  saved.own  [%| %editor-record-missing]
  =/  receipt=receipt-v2:result  [%vibecoding-connected-write-readback-v2 e u.saved.own]
  ?.  (linked-v2:result our at receipt)  [%| %result-invalid]
  =/  rows  (history:history our actor at)
  ?:  ?=(%| -.rows)  [%| p.rows]
  =/  binding  (binding:old-read our (owned:old-read our at) binding-key)
  ?:  ?=(%| -.binding)  [%| p.binding]
  =/  packet=selected-v2:vc  packet.candidate.body.review.body.intake.state.e
  ?.  .^(? %gx /(scot %p our)/graf/(scot %da at)/contains/(scot %uw (jam (packet-fact-v2:result packet)))/noun)
    [%| %packet-not-retained]
  =/  current  (read:editor-read our actor at)
  ?:  ?=(%| -.current)  [%| p.current]
  =/  view  (build-v2:result our actor at nonce entry.own saved.own p.rows current)
  ?:  ?=(%| -.view)  [%| p.view]
  [%& [p.binding p.view ~]]
++  context-v2-with-intent
  |=  [our=@p actor=@p at=@da nonce=@ux binding-key=@ux own=owned-v2 stated=(unit record:itn)]
  ^-  (each evidence-v2 @tas)
  =/  found  (source-context-v2 our actor at nonce binding-key own)
  ?:  ?=(%| -.found)  [%| p.found]
  [%& p.found(stated stated)]
++  read-v2
  |=  [our=@p actor=@p at=@da nonce=@ux binding-key=@ux own=owned-v2 window=window:clw]
  ^-  (each snapshot-v2:core @tas)
  =/  found  (mule |.((context-v2 our actor at nonce binding-key own)))
  ?:  ?=(%| -.found)  [%| %read-unavailable]
  ?:  ?=(%| -.p.found)  [%| p.p.found]
  =/  e=evidence-v2  p.p.found
  (freeze-v2:core our actor at binding.e view.e stated.e window)
++  admit-v2
  |=  [our=@p actor=@p at=@da s=snapshot-v2:core own=owned-v2 window=window:clw]
  ^-  decision-v2:core
  ?.  =(our actor)  [%| %foreign-actor]
  ?.  &((valid-v2:core s) =(our owner.order.s))  [%| %snapshot-invalid]
  =/  found
    %-  mule
    |.  (context-v2 our actor at nonce.commitment.s (digest:vcl binding.commitment.s) own)
  ?:  ?=(%| -.found)  [%| %read-unavailable]
  ?:  ?=(%| -.p.found)  [%| p.p.found]
  =/  e=evidence-v2  p.p.found
  ?.  =(binding.e binding.commitment.s)  [%| %compiler-binding-changed]
  (admit-v2:core our actor at s view.e stated.e window)
--
