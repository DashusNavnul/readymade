::  Private execution metadata only. Native owners supply actual records.
/-  a=a2a, ct=cantrip
/+  al=a2a, rt=pataphor-chat-runtime, h=readymade-history
|%
+$  task-view  [id=@t move=@t state=task-state:a status-at=@da]
+$  judgment-view  [state=mp-inbox-status:ct reason=(unit @t)]
+$  diagnostic-view  [bridge-ready=? ceiling=@tas]
+$  snapshot
  $:  %readymade-execution-v1  epoch=@ta  entry=@ud  message=@ta
      revision=@ud  observation=?(%known %missing %unavailable %mismatch)
      task=(unit task-view)  judgment=(unit judgment-view)
      diagnostic=(unit diagnostic-view)  problem=(unit @t)
  ==
++  target-valid
  |=  [epoch=@ta entry=@ud]
  ^-  ?
  ?&  (gth (met 3 epoch) 0)  (lte (met 3 epoch) 128)
      (gth entry 0)  (lte (met 0 entry) 64)
  ==
++  id-valid
  |=  value=@t
  ^-  ?
  &((gth (met 3 value) 0) (lte (met 3 value) 256))
++  expected-move
  ::  A comparison key from A2A's own law; never an observed task/move id.
  |=  [epoch=@ta entry=@ud]
  ^-  @t
  (key-text:al (dedupe-key:al 'noltbook' epoch (mid:rt entry)))
++  valid
  |=  current=snapshot
  ^-  ?
  ?.  &((target-valid epoch.current entry.current) =((mid:rt entry.current) message.current))  %.n
  ?.  ?~(problem.current %.y (lte (met 3 u.problem.current) 512))  %.n
  ?.  ?~(diagnostic.current %.y &((gth (met 3 ceiling.u.diagnostic.current) 0) (lte (met 3 ceiling.u.diagnostic.current) 40)))  %.n
  ?~  task.current
    &(!=(%known observation.current) =(~ judgment.current))
  ?.  ?&  (id-valid id.u.task.current)  (id-valid move.u.task.current)
          =((expected-move epoch.current entry.current) move.u.task.current)
      ==  %.n
  ?~  judgment.current  %.y
  &(?=(%known observation.current) ?~(reason.u.judgment.current %.y (lte (met 3 u.reason.u.judgment.current) 512)))
++  from-task
  |=  [epoch=@ta entry=@ud revision=@ud value=(unit task:a)]
  ^-  snapshot
  ?>  (target-valid epoch entry)
  =/  base=snapshot
    [%readymade-execution-v1 epoch entry (mid:rt entry) revision %missing ~ ~ ~ ~]
  ?~  value  base(problem `'No matching native A2A task was found.')
  ?.  ?&  =('noltbook' principal.u.value)  =(epoch context-id.u.value)
          (id-valid task-id.u.value)  (id-valid move-id.u.value)
          =((expected-move epoch entry) move-id.u.value)
      ==
    base(observation %mismatch, problem `'The native A2A task does not match this exchange.')
  base(observation %known, task `[task-id.u.value move-id.u.value state.u.value status-at.u.value])
++  from-move
  |=  [our=@p current=snapshot value=(unit mp-inbox-entry:ct)]
  ^-  snapshot
  ?>  (valid current)
  ?~  task.current  current
  ?~  value
    current(observation %missing, judgment ~, problem `'The matching native Cantrip move was not found.')
  =/  move=mp-move:ct  move.u.value
  ?.  ?&  =(our source-ship.u.value)
          =(move.u.task.current move-id.move)
          =(`epoch.current session-id.move)
          =(`'a2a:noltbook' origin.move)
          =(%task-share kind.move)
      ==
    current(observation %mismatch, judgment ~, problem `'The native Cantrip move does not match this exchange.')
  ?.  ?=(%task-share -.payload.move)
    current(observation %mismatch, judgment ~, problem `'The native Cantrip payload is incompatible with this task.')
  =/  shared=task-share-payload:ct  +.payload.move
  ?.  =(id.u.task.current task-id.shared)
    current(observation %mismatch, judgment ~, problem `'The native Cantrip payload identifies a different task.')
  =/  reason=(unit @t)
    ?~  refuse-reason.u.value  ~
    `(prefix:h u.refuse-reason.u.value 512)
  =/  clipped=?
    ?~  refuse-reason.u.value  %.n
    (gth (met 3 u.refuse-reason.u.value) 512)
  %=  current
    observation  %known
    judgment  `[status.u.value reason]
    problem  ?:(clipped `'The native Cantrip reason was truncated to 512 bytes.' ~)
  ==
--
