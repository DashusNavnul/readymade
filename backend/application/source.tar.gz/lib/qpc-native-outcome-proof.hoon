::  Bounded producer/consumer witnesses, never prospective work history.
/-  nc=native-coding, np=native-coding-provider, frozen=native-coding-context
/+  q=qpc-native-outcome, obs=qpc-observation, tools=native-coding-tools,
    accept=native-coding-accept, project=native-coding-project,
    files=native-coding-files, changes=multiplayer-changeset,
    sessions=native-coding-session, provider=native-coding-provider,
    ct=cantrip-native-coding, codec=native-coding-tool-codec,
    calls=qpc-native-collection-proof, wire=qpc-report-proof
|%
++  fixture
  =/  at=@da  ~2026.10.10
  =/  target=build-target:nc
    [%example %hoon /lib/example/hoon ~ ~[[%holds '0'] [%fails '1'] [%crashes '!!']]]
  =/  p=project:nc  *project:nc
  =.  p
    p(spec [1 'fixture' 'Outcome fixture' ~zod %accepted 1 0x1 at], working %work, readable.policy (silt ~[/lib]), writable.policy (silt ~[/lib]), max-file-bytes.policy 1.024, max-candidate-bytes.policy 2.048, file-types (~(put by file-types.p) %hoon %hoon), targets ~[target])
  ?>  (valid:project p)
  =/  selected=selection:np
    [%native-coding-provider-v1 %compatible 'fixture' 'https://example.invalid' %chat [%.n %.y %.y] %key]
  =/  props=(list proposition:obs)
    ~[[%holds 'Named hold check returns true.' 'native result' 'holds check' 'first candidate check'] [%fails 'Named fail check returns true.' 'native result' 'fails check' 'first candidate check']]
  =/  m=manifest:obs
    [%qpc-observation-manifest-v1 ~zod 'fixture' selected %literal-v1 'frozen context' ~[/lib/example/hoon] props 16 'first compatible window']
  =/  cs=cases:q
    [%qpc-hoon-cases-v1 ~[[%holds target %holds] [%fails target %fails]]]
  =/  source=revision:nc  [~zod %work 1 0v1 0v2]
  =/  w=work:obs
    [%qpc-observation-work-v1 (digest:obs m) 0x1 0x11 0x12 (configuration:project p) source /lib/example/hoon (digest:q cs) 'fixed example' 'source and named checks']
  ?>  (cases-valid:q m w p cs)
  =/  ctx=context:nc  ['fixture' configuration.w session.w request.w ~zod source]
  =/  basis=tree:nc
    [source (make-snapshot:changes [1 'fixture' %work 1 ~])]
  =/  content=replacement:nc  [%hoon '|=  a=@  a\0a']
  =/  edit=edit:nc
    [[%add /lib/example/hoon ~ ``@ux`(page-to-lobe:clay [%hoon source.content])] `content]
  =/  c=candidate:nc
    [%native-coding-candidate-v1 0x0 ctx basis [~zod %accepted 1 0v3 0v4] ~[edit] ~]
  =.  c  c(id (candidate-digest:files c))
  ?>  (candidate-valid:files p c)
  =/  desk=@tas  (staging-desk:accept id.c)
  =/  stage=tree:nc
    [[~zod desk 2 0v5 0v6] (make-snapshot:changes [1 'fixture' desk 2 (after-map:files c)])]
  =/  diagnostics=target-result:accept
    (candidate-target:tools target revision.stage `!>(0) 300.000)
  =/  report=report:accept
    [%native-coding-candidate-report-v1 id.c stage ~[diagnostics]]
  =/  r=record:accept
    [%native-coding-acceptance-v1 p c 0x91 at %review `stage `report ~ ~ ~]
  ?>  (valid:accept (~(put by *ledger:accept) id.c r))
  [m w cs r]
++  prove
  =/  [m=manifest:obs w=work:obs cs=cases:q r=record:accept]  fixture
  =/  report=report:accept  (need report.r)
  =/  t=target-result:accept  (snag 0 targets.report)
  =/  source=revision:nc  revision.staging.report
  =/  passed  (assess:q (snag 0 rows.cs) source t)
  =/  failed  (assess:q (snag 1 rows.cs) source t)
  =/  crashed  (assess:q [%crashes target.t %crashes] source t)
  ?>  &(?=(%& -.passed) ?=(%& -.failed) ?=(%& -.crashed))
  ?>  =(%pass verdict.p.passed)
  ?>  =(%fail verdict.p.failed)
  ?>  =(%unknown verdict.p.crashed)
  ?>  =(%no-returned-value reason.p.crashed)
  =/  unbuilt=target-result:accept
    (candidate-target:tools target.t source ~ 300.000)
  =/  absent  (assess:q (snag 0 rows.cs) source unbuilt)
  ?>  ?=(%& -.absent)
  ?>  &(=(%unknown verdict.p.absent) =(%not-compiled reason.p.absent))
  ::  Reject missing, reordered, stale, cross-artifact and contradictory rows.
  =/  reordered  (assess:q (snag 0 rows.cs) source t(diagnostics (flop diagnostics.t)))
  ?>  ?=(%| -.reordered)
  =/  stale  (assess:q (snag 0 rows.cs) source(number 3) t)
  ?>  ?=(%| -.stale)
  =/  d=diagnostic:nc  (snag 1 diagnostics.t)
  =/  forged=target-result:accept
    t(diagnostics [(snag 0 diagnostics.t) [d(artifacts ~[0xdead (shax (jam 0))]) (slag 2 diagnostics.t)]])
  =/  swapped  (assess:q (snag 0 rows.cs) source forged)
  ?>  ?=(%| -.swapped)
  =.  forged  t(diagnostics [(snag 0 diagnostics.t) [d(passed %.n) (slag 2 diagnostics.t)]])
  =/  contradicted  (assess:q (snag 0 rows.cs) source forged)
  ?>  ?=(%| -.contradicted)
  =/  checked  (adjudicate:q m w cs r)
  ?>  ?=(%& -.checked)
  ?>  =(~[%pass %fail] (turn outcomes.p.checked |=(o=assessment:q verdict.o)))
  ?>  &(=(source.w prediction.p.checked) =(source checked.p.checked))
  ?>  !(cases-valid:q m w project.r cs(rows (flop rows.cs)))
  =/  wrong-work  (adjudicate:q m w(request 0x999) cs r)
  ?>  ?=(%| -.wrong-work)
  =/  no-report  (adjudicate:q m w cs r(report ~))
  ?>  ?=(%| -.no-report)
  ::  A frame must join the exact public model record and native tool result.
  =/  at=@da  ~2026.10.10
  =/  e=entry:sessions  *entry:sessions
  =.  e  e(id.session session.w, owner.session owner.m)
  =/  b=binding:frozen
    [%native-coding-context-binding-v1 owner.m session.w request.w owner.m source.w %compatible 'fixture' 0x1 0x2 0x3 0x4 0x5]
  =/  context  (append:sessions e at [%context b])
  ?>  ?=(%& -.context)
  =.  e  entry.p.context
  =/  reply=reply:np  *reply:np
  =.  reply
    reply(id request.w, provider %compatible, model 'fixture', stop %tools, calls ~[(patch:calls 'a' 'new\0a')], text (wire:wire manifest.w ~[(item:wire 'a' ~[[%n '750000'] [%n '600000']])]))
  =/  public=public-reply:np  (publish:provider reply)
  =/  f=frame:obs
    [%qpc-observation-frame-v1 0x0 owner.m w 0 0x10 at sequence.e (need head.e) (digest:obs public) [%& ~[['a' ~[750.000 600.000]]]]]
  =.  f  f(id (digest:obs f))
  =/  modeled  (append:sessions e at [%model public])
  ?>  ?=(%& -.modeled)
  =.  e  entry.p.modeled
  =/  request  (decode:codec context.candidate.r source.w (snag 0 calls.reply))
  ?>  ?=(%& -.request)
  =/  result=tool-result:nc
    [%native-coding-tool-result-v1 context.candidate.r 'a' [%candidate candidate.r]]
  =/  tool=record:ct  [grant.r p.request at %finished `result]
  =/  completed  (append:sessions e at [%tool result])
  ?>  ?=(%& -.completed)
  =.  e  entry.p.completed
  =/  joined  (link:q m f cs e tool r)
  ?>  ?=(%& -.joined)
  ?>  &(=(id.f frame.p.joined) =(~[750.000 600.000] confidence.p.joined))
  =/  swapped-tool  (link:q m f cs e tool(request p.request(call-id 'b')) r)
  ?>  ?=(%| -.swapped-tool)
  =/  wrong-frame=frame:obs  f(id 0x0, result [%& ~[['a' ~[1 2]]]])
  =.  wrong-frame  wrong-frame(id (digest:obs wrong-frame))
  =/  rewritten  (link:q m wrong-frame cs e tool r)
  ?>  =([%| %qpc-outcome-predictions-mismatch] rewritten)
  =/  missing-result  (link:q m f cs entry.p.modeled tool r)
  ?>  =([%| %qpc-outcome-tool-journal-missing] missing-result)
  [%qpc-native-outcome-proof-v1 %returned-pass-fail %errors-unknown %work-bound %frame-linked]
--
