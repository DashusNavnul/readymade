::  Canonical inert workspace foundations. Callers read their own native base.
::  This helper establishes shape and bounds, never origin, consent or execution.
/+  utf8=native-coding-source-text
|%
++  marks
  ^-  (set @tas)
  (silt `(list @tas)`~[%hoon %txt %txt-diff %noun %bill %kelvin %js %css %html %mime])
++  paths
  ^-  (set path)
  (silt (turn ~(tap in marks) |=(mark=@tas /mar/[mark]/hoon)))
++  support-paths
  ^-  (set path)
  (~(uni in paths) (silt `(list path)`~[/desk/bill /sys/kelvin]))
++  valid
  |=  sources=(map @tas @t)
  ^-  ?
  ?&  =(marks ~(key by sources))
      %+  levy  ~(tap by sources)
      |=  row=[mark=@tas source=@t]
      &((gth (met 3 source.row) 0) (lte (met 3 source.row) 262.144) (valid:utf8 source.row))
  ==
++  pages
  |=  sources=(map @tas @t)
  ^-  (map path page:clay)
  ?>  (valid sources)
  =/  rows=(list [path page:clay])
    %+  turn  ~(tap by sources)
    |=  row=[mark=@tas source=@t]
    ^-  [path page:clay]
    [/mar/[mark.row]/hoon [%hoon source.row]]
  (malt rows)
--
