::  Read-only projection of native-coding-review's retained entry and map.
::  No second store, lifecycle, callback or review authority lives here.
::  qpc-native-review-state-proof requires exact native mold parity and
::  nonempty returned-inner readback before this interface can be adopted.
/-  nc=native-coding
/+  accept=native-coding-accept
|%
+$  entry
  $:  candidate=candidate:nc  objective=@t  model=@t
      workspace=(unit @tas)  observed=(unit record:accept)
      decision=(unit decision:accept)  advanced=?
  ==
+$  state  (map @ux entry)
--
