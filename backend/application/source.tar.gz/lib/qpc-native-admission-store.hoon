::  Immutable Cantrip receipt retention, never a payload admission endpoint.
::  +receipt-valid checks consistency; the reader alone authenticates origin.
/-  nc=native-coding
/+  admit=qpc-native-admission, d=qpc-native-decision,
    tools=cantrip-native-coding, sessions=native-coding-session
|%
+$  delivery
  [receipt=receipt:admit due=@da notice=?(%scheduled %sent %unknown)]
+$  state
  [%qpc-native-admission-store-v1 records=(map @ux delivery) unavailable=(map @ux @tas)]
++  empty  ^-(state [%qpc-native-admission-store-v1 ~ ~])
++  receipt-valid
  |=  r=receipt:admit
  ^-  ?
  =/  m=marker:admit  request.r
  =/  e=record:sessions  event.m
  ?&  (identifier:tools opening.m)  (identifier:tools session.m)
      (identifier:tools assessment.r)  (gth at.r 0)  (gte at.r at.e)
      (lte (met 0 sequence.e) 64)  (gth sequence.e 0)  ?=(^ previous.e)
      =(body.e [%status %paused %qpc-admission-requested])
      =(id.e (event-id:sessions session.m sequence.e previous.e at.e body.e))
      (lte (lent offered.r) 4)
      =((lent offered.r) ~(wyt in (silt (turn offered.r |=(v=offered:d candidate.admission.v)))))
      %+  levy  offered.r
      |=  v=offered:d
      =/  a=admission-receipt:d  admission.v
      =/  t=record:tools  tool.v
      ?~  result.t  %.n
      =/  result=tool-result:nc  u.result.t
      ?.  ?=(%candidate -.output.result)  %.n
      =/  candidate=candidate:nc  value.output.result
      =/  names=(list @tas)  (turn checks.a |=(check=check:d name.check))
      ?&  =(id.a (digest:d a(id 0x0)))  =(opening.a opening.m)
          =(position.a sequence.e)  =(source.a source.context.candidate)
          =(session.m session.context.candidate)  (identifier:tools authority.a)
          =(candidate.a id.candidate)  =(effect.a (effect:d candidate))
          =(context.request.t context.result)  =(context.result context.candidate)
          =(call-id.request.t call-id.result)  =(%finished stage.t)
          ?=(%patch -.arguments.request.t)  (identifier:tools grant.t)
          (gte (lent names) 2)  (lte (lent names) 16)
          =(%compile (snag 0 names))  =(%project-constraints (rear names))
          =((lent names) ~(wyt in (silt names)))
          %+  levy  checks.a
          |=  check=check:d
          ?:  =(%unknown verdict.outcome.check)  =(0 evidence.outcome.check)
          (identifier:tools evidence.outcome.check)
      ==
  ==
++  retain
  |=  [s=state id=@ux r=receipt:admit due=@da]
  ^-  (each state @tas)
  ?:  (~(has by records.s) id)  [%| %qpc-admission-already-retained]
  ?:  (~(has by unavailable.s) id)  [%| %qpc-admission-already-refused]
  ?.  (lth ~(wyt by records.s) 128)  [%| %qpc-admission-capacity]
  ?.  &((receipt-valid r) =(id id.event.request.r) (gth due at.r))
    [%| %qpc-admission-retention-invalid]
  [%& s(records (~(put by records.s) id [r due %scheduled]))]
++  refuse
  |=  [s=state id=@ux reason=@tas]
  ^-  state
  ?:  (~(has by records.s) id)  s
  ?.  |((~(has by unavailable.s) id) (lth ~(wyt by unavailable.s) 128))  s
  s(unavailable (~(put by unavailable.s) id reason))
++  wire-for
  |=  [id=@ux r=delivery]
  ^-  wire
  /qpc-admission-notify/(scot %ux id)/(scot %da due.r)
++  recover
  |=  s=state
  ^-  state
  s(records (~(run by records.s) |=(r=delivery ?:(=(%scheduled notice.r) r(notice %unknown) r))))
++  valid
  |=  s=state
  ^-  ?
  ?&  (lte ~(wyt by records.s) 128)  (lte ~(wyt by unavailable.s) 128)
      (levy ~(tap by unavailable.s) |=([id=@ux reason=@tas] &((identifier:tools id) !=(%$ reason) !(~(has by records.s) id))))
      %+  levy  ~(tap by records.s)
      |=  [id=@ux r=delivery]
      &((receipt-valid receipt.r) =(id id.event.request.receipt.r) (gth due.r at.receipt.r))
  ==
--
