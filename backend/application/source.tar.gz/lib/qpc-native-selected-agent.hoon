::  Viki execution owner. Choice belongs only to the controller. This wrapper
::  consumes one exact mapping, then delegates normal result/review handling.
/-  nc=native-coding
/+  s=qpc-native-selected, read=qpc-native-selected-read,
    c=qpc-native-controller, controller-read=qpc-native-controller-read,
    d=qpc-native-decision, admit=qpc-native-admission,
    sessions=native-coding-session, observer=qpc-observer,
    instrument=qpc-instrument-contract, ct=cantrip-native-coding,
    loop=native-coding-loop, note=qpc-native-selected-note
|%
++  wrap
  |=  [inner=agent:gall fetch=reader:read fresh=fresh-reader:read receipt=receipts:controller-read]
  =/  held=state:s  empty:s
  ^-  agent:gall
  |_  =bowl:gall
  +*  this  .
      ag  ~(. inner bowl)
      refuse
        |=  [id=@ux reason=@tas]
        ^-  (quip card:agent:gall _this)
        =/  found  (~(get by records.held) id)
        =.  held
          ?~  found  held
          ?.  ?=(?(%opening %admitting) phase.u.found)  held
          held(records (~(put by records.held) id u.found(phase %unknown, reason `reason)))
        =.  held  (unavailable:s held id reason)
        [~[[%give %fact ~[/native-coding] %noun !>([%qpc-selected-unavailable-v1 id reason])]] this]
      observe
        |=  id=@ux
        ^-  (quip card:agent:gall _this)
        =/  found  (~(get by records.held) id)
        ?~  found  (refuse id %qpc-selected-intent-missing)
        =/  r=record:s  u.found
        ?.  ?=(?(%opening %admitting) phase.r)  [~ this]
        =/  got  (fresh inner bowl plan.r)
        ?:  ?=(%| -.got)  (refuse id p.got)
        =/  v=view:read  p.got
        =/  p=plan:s  plan.r
        ?:  =(%opening phase.r)
          ::  Grant ACK is a trigger only: +fresh read the exact canonical
          ::  grant and original source/law before this marker is appended.
          =/  e=entry:sessions  entry.input.v
          ?~  head.e  (refuse id %qpc-selected-journal-empty)
          =/  wanted  (append:sessions e now.bowl [%status %paused %qpc-admission-requested])
          ?:  ?=(%| -.wanted)  (refuse id p.wanted)
          =/  prepared
            (on-poke:~(. inner bowl(src our.bowl)) %noun !>([%qpc-native-note-v1 collection.p u.head.e working.session.e %qpc-admission-requested]))
          =/  after=agent:gall  +.prepared
          =/  actual  (input:observer after bowl collection.p)
          ?~  actual  (refuse id %qpc-selected-marker-unavailable)
          ?.  =(entry.p.wanted entry.u.actual)  (refuse id %qpc-selected-marker-not-appended)
          =/  event=record:sessions  (rear records.entry.u.actual)
          =/  expected=(list card:agent:gall)
            ~[(changed:loop collection.p sequence.entry.u.actual) (poke:loop our.bowl %graf /native-coding/retain [%attest [%native-coding-session-record-v1 collection.p event]])]
          ?.  =(expected -.prepared)  (refuse id %qpc-selected-unexpected-marker-card)
          =/  marker=marker:admit  [%qpc-admission-request-v1 id collection.p event]
          =/  marked  (admitted:s r marker)
          ?:  ?=(%| -.marked)  (refuse id p.marked)
          =.  held  held(records (~(put by records.held) id p.marked))
          =.  inner  after
          =/  requested=(list card:agent:gall)
            ~[(poke:loop our.bowl %cantrip /qpc/selected-admission/(scot %ux id.event.marker) [%qpc-admit-v1 id.event.marker])]
          :_  this
          (weld -.prepared requested)
        ?~  marker.r  (refuse id %qpc-selected-marker-missing)
        =/  checked  (receipt bowl id.event.u.marker.r)
        ?:  ?=(%| -.checked)  (refuse id p.checked)
        =/  consumed  (consume:s r choice.v p.checked current.v)
        ?:  ?=(%| -.consumed)  (refuse id p.consumed)
        =/  next=record:s  p.consumed
        =/  mapping=mapping:d  (need mapping.next)
        =/  prepared
          (on-poke:~(. inner bowl(src our.bowl)) %noun !>([%qpc-selected-pending-v1 id mapping]))
        =/  after=agent:gall  +.prepared
        =/  pending  (raw:instrument after bowl /x/native-coding/tool/(scot %ux tool.mapping))
        ?.  =(pending ``request.p)  (refuse id %qpc-selected-pending-unconfirmed)
        =/  actual  (input:observer after bowl id.session.entry.p)
        ?~  actual  (refuse id %qpc-selected-session-unavailable)
        =/  wanted  (append:sessions entry.p(phase %tools, resume %paused) now.bowl [%status %tools %qpc-selected-tool])
        ?:  ?=(%| -.wanted)  (refuse id p.wanted)
        ?.  =(entry.p.wanted entry.u.actual)  (refuse id %qpc-selected-tool-journal-mismatch)
        =/  event=record:sessions  (rear records.entry.u.actual)
        =/  expected=(list card:agent:gall)
          ~[(changed:loop id.session.entry.p sequence.entry.u.actual) (poke:loop our.bowl %graf /native-coding/retain [%attest [%native-coding-session-record-v1 id.session.entry.p event]])]
        ?.  =(expected -.prepared)  (refuse id %qpc-selected-unexpected-pending-card)
        ::  Gall commits consumed mapping and exact pending/direct DATA before
        ::  releasing this sole execute card. A later watch cannot repeat it.
        =.  held  held(records (~(put by records.held) id next))
        =.  inner  after
        =/  requested=(list card:agent:gall)
          ~[(poke:loop our.bowl %cantrip /native-coding/tool/(scot %ux tool.mapping) [%native-coding-execute-v1 id.grant.p request.p])]
        :_  this
        (weld -.prepared requested)
  ++  on-init
    =^  cards  inner  on-init:ag
    [cards this]
  ++  on-save  !>([%qpc-selected-owner-v1 held on-save:ag])
  ++  on-load
    |=  old=vase
    =/  saved=[held=state:s inner=vase]
      ?.  ?=([%qpc-selected-owner-v1 *] q.old)  [empty:s old]
      =/  prior  !<([%qpc-selected-owner-v1 held=state:s inner=vase] old)
      +.prior
    ?>  (valid:s held.saved)
    =.  held  (recover:s held.saved)
    =^  cards  inner  (on-load:ag inner.saved)
    [cards this]
  ++  on-poke
    |=  [=mark =vase]
    ?:  &(=(%noun mark) ?=([%qpc-selected-observe-v1 @] q.vase))
      ?>  =(our.bowl src.bowl)
      (observe `@ux`+.q.vase)
    ?:  &(=(%noun mark) ?=([%qpc-selected-start-v1 @] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  id=@ux  +.q.vase
      ?:  |((~(has by records.held) id) (~(has by unavailable.held) id))  [~ this]
      =/  got  (fetch inner bowl id)
      ?:  ?=(%| -.got)  (refuse id p.got)
      =/  made  (make:s choice.p.got input.p.got now.bowl (digest:s [id now.bowl eny.bowl]))
      ?:  ?=(%| -.made)  (refuse id p.made)
      =/  p=plan:s  p.made
      =/  begun  (begin:s held p)
      ?:  ?=(%| -.begun)  (refuse id p.begun)
      =/  prepared  (on-poke:~(. inner bowl(src our.bowl)) %noun !>([%qpc-selected-open-v1 p]))
      =/  after=agent:gall  +.prepared
      =/  actual  (input:observer after bowl id.session.entry.p)
      ?.  =(actual `[entry.p key.p id.grant.p])  (refuse id %qpc-selected-fresh-session-not-opened)
      =/  retains=(list card:agent:gall)
        (turn records.entry.p |=(r=record:sessions (poke:loop our.bowl %graf /native-coding/retain [%attest [%native-coding-session-record-v1 id.session.entry.p r]])))
      ?.  =(-.prepared [(changed:loop id.session.entry.p sequence.entry.p) retains])
        (refuse id %qpc-selected-unexpected-open-card)
      =.  held  p.begun
      =.  inner  after
      =/  requested=(list card:agent:gall)
        ~[(poke:loop our.bowl %cantrip /qpc-selected-grant/(scot %ux id) [%native-coding-grant-v1 grant.p])]
      :_  this
      (weld -.prepared requested)
    ?:  &(=(%noun mark) ?=([?(%qpc-controller-observe-v1 %qpc-admission-ready-v1) @] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  incoming=@ux  +.q.vase
      =/  notified=?  ?=(%qpc-admission-ready-v1 -.q.vase)
      =/  active=(list record:s)
        ?.  notified  ~
        (skim ~(val by records.held) |=(r=record:s ?~(marker.r %.n =(incoming id.event.u.marker.r))))
      ?:  =(1 (lent active))  (observe id.plan:(snag 0 active))
      ::  A first-marker notice can only reach its controller. It cannot
      ::  trigger the selected execution's distinct second-marker receipt.
      =/  before  (choices:read inner bowl)
      =/  target=(unit @ux)
        ?.  notified  `incoming
        ?~  before  ~
        =/  matches=(list record:c)
          (skim ~(val by records.u.before) |=(r=record:c =(incoming id.event.marker.r)))
        ?.(=(1 (lent matches)) ~ `session.marker:(snag 0 matches))
      ?~  target  [~ this]
      =/  session=@ux  u.target
      ::  Commit the controller callback before any selected execution read.
      ::  Both an exact receipt notice and explicit owner observation may
      ::  cause the one new waiting→chosen transition and native self poke.
      =^  cards  inner  (on-poke:ag mark vase)
      =/  after  (choices:read inner bowl)
      ?~  before  [cards this]
      ?~  after  [cards this]
      =/  old  (~(get by records.u.before) session)
      =/  new  (~(get by records.u.after) session)
      ?~  old  [cards this]
      ?~  new  [cards this]
      ?.  &(=(%waiting phase.u.old) =(%chosen phase.u.new))  [cards this]
      =/  requested=(list card:agent:gall)
        ~[(poke:loop our.bowl %viki /qpc-selected/start [%qpc-selected-start-v1 id.decision.u.new])]
      :_  this
      (weld cards requested)
    =^  cards  inner  (on-poke:ag mark vase)
    [cards this]
  ++  on-agent
    |=  [=wire =sign:agent:gall]
    ?:  ?=([%qpc-selected-grant @ ~] wire)
      ?.  =(our.bowl src.bowl)  [~ this]
      =/  id  (slaw %ux i.t.wire)
      ?~  id  [~ this]
      =/  found  (~(get by records.held) u.id)
      ?~  found  [~ this]
      ?.  =(%opening phase.u.found)  [~ this]
      ?.  ?=([%poke-ack ~] sign)  (refuse u.id %qpc-selected-grant-unconfirmed)
      (observe u.id)
    =^  cards  inner  (on-agent:ag wire sign)
    [cards this]
  ++  on-peek
    |=  =path
    ?:  =(/x/qpc/selected path)
      ?.  =(our.bowl src.bowl)  ~
      ``noun+!>(held)
    ?:  ?=([%x %qpc %selected @ ~] path)
      ?.  =(our.bowl src.bowl)  ~
      =/  id  (slaw %ux i.t.t.t.path)
      ?~  id  [~ ~]
      ``noun+!>((~(get by records.held) u.id))
    ?:  ?=([%x %qpc %admission-request @ ~] path)
      ?.  =(our.bowl src.bowl)  ~
      =/  id  (slaw %ux i.t.t.t.path)
      ?~  id  [~ ~]
      =/  found=(list marker:admit)
        (murn ~(val by records.held) |=(r=record:s ?~(marker.r ~ ?:(=(u.id id.event.u.marker.r) marker.r ~))))
      ?^  found  ``noun+!>(`i.found)
      (on-peek:ag path)
    (on-peek:ag path)
  ++  on-watch
    |=  =path
    =^  cards  inner  (on-watch:ag path)
    [cards this]
  ++  on-leave
    |=  =path
    =^  cards  inner  (on-leave:ag path)
    [cards this]
  ++  on-arvo
    |=  [=wire =sign-arvo]
    =^  cards  inner  (on-arvo:ag wire sign-arvo)
    [cards this]
  ++  on-fail
    |=  [=term =tang]
    =^  cards  inner  (on-fail:ag term tang)
    [cards this]
  --
++  agent  |=(inner=agent:gall (wrap inner read:read fresh:read receipt:read))
--
