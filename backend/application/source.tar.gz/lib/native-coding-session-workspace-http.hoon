::  Owner HTTP projection only. Viki rechecks canonical source and reservation
::  authority before preparing a private workspace; no host-supplied claim.
/-  nc=native-coding, ws=workspace
/+  setup=native-coding-session-workspace, bootstrap=native-coding-bootstrap,
    project=native-coding-project, workspace=workspace, guard=viki-scry-guard,
    input=native-coding-onboarding-http, terminal=native-coding-terminal,
    files=native-coding-files-http, cr=codex-responses
|%
+$  row
  [id=@ux project=@t working=@tas phase=?(%preparing %ready %unknown) reason=@tas configuration=@ux]
+$  command  [%native-coding-session-workspace-action-v1 action=command:setup]
++  read
  |=  [our=@p now=@da]
  ^-  (unit (list row))
  ?.  (agent-live:guard our now %viki)  ~
  =/  held=[%native-coding-session-workspaces-v1 rows=(list row)]
    .^([%native-coding-session-workspaces-v1 rows=(list row)] %gx /(scot %p our)/viki/(scot %da now)/native-coding/session-workspaces/noun)
  `rows.held
++  entry
  |=  [our=@p now=@da id=@ux]
  ^-  (unit entry:setup)
  ?.  (agent-live:guard our now %viki)  ~
  .^((unit entry:setup) %gx /(scot %p our)/viki/(scot %da now)/native-coding/session-workspace/(scot %ux id)/noun)
++  selected
  |=  [our=@p now=@da id=@ux]
  ^-  (unit (each project:nc @tas))
  ?.  (agent-live:guard our now %viki)  `[%| %session-workspace-unavailable]
  .^((unit (each project:nc @tas)) %gx /(scot %p our)/viki/(scot %da now)/native-coding/session-project/(scot %ux id)/noun)
++  row-json
  |=  r=row
  ^-  json
  (pairs:enjs:format ~[['id' s+(scot %ux id.r)] ['project' s+project.r] ['working' s+working.r] ['phase' s+phase.r] ['reason' s+reason.r] ['configuration' s+(scot %ux configuration.r)]])
++  detail
  |=  [our=@p now=@da id=@ux]
  ^-  json
  =/  held  (entry our now id)
  ?~  held  ~
  =/  e=entry:setup  u.held
  =/  scoped  (selected our now id)
  =/  reason=@tas
    ?~  scoped  %session-workspace-unavailable
    ?:  ?=(%| -.u.scoped)  p.u.scoped
    ?.  =(p.u.scoped (scoped:setup e))  %session-workspace-project-changed
    %session-workspace-ready
  (pairs:enjs:format ~[['id' s+(scot %ux id)] ['project' s+project.request.e] ['working' s+working.request.e] ['phase' s+phase.e] ['reason' s+reason.e] ['configuration' s+(scot %ux configuration.e)] ['mode' s+mode.request.e] ['holder' s+(scot %p holder.request.e)] ['accepted' (revision:files accepted.request.e)] ['ready' b+=(reason %session-workspace-ready)] ['readiness' s+reason]])
++  view
  |=  [our=@p now=@da rows=(unit (list row)) id=@ux]
  ^-  json
  (pairs:enjs:format ~[['available' b+?=(^ rows)] ['rows' a+?~(rows ~ (turn (scag 64 u.rows) row-json))] ['selected' ?:(=(0 id) ~ (detail our now id))]])
++  route
  ::  Enclosing Eyre handler authenticates the owner before this read route.
  |=  [our=@p now=@da url=@t]
  ^-  (unit json)
  ?:  =('/apps/pataphor-native/coding/workspaces' url)
    `(view our now (read our now) 0x0)
  =/  prefix=@t  '/apps/pataphor-native/coding/workspace?'
  ?.  &(=(prefix (cut 3 [0 (met 3 prefix)] url)) (lte (met 3 url) 160))  ~
  =/  text=@t  (rsh [3 (met 3 prefix)] url)
  =/  id  (slaw %ux text)
  ?~  id  ~
  ?.  &(!=(0 u.id) (lte (met 0 u.id) 256) =(text (scot %ux u.id)))  ~
  `(view our now (read our now) u.id)
++  claim
  |=  [our=@p now=@da base=@tas fork=@tas holder=@p]
  ^-  claim:ws
  ?>  (agent-live:guard our now %graf)
  =/  facts=(list [fact=* ships=(set @p)])
    .^((list [fact=* ships=(set @p)]) %gx /(scot %p our)/graf/(scot %da now)/attested/noun)
  =/  matches=(list claim:ws)
    %+  murn  facts
    |=  [fact=* ships=(set @p)]
    ?.  (~(has in ships) our)  ~
    =/  found  (claim-of:workspace fact)
    ?~  found  ~
    ?:(=(fork fork.u.found) found ~)
  ?>  =(1 (lent matches))
  =/  c=claim:ws  (snag 0 matches)
  ?>  &(=(base base.c) =(holder holder.c))
  c
++  decode
  |=  [our=@p now=@da object=json]
  ^-  command
  =/  kind=@t  (text:input object 'kind' 32 %.y)
  =/  id=@ux  (digest:terminal (text:input object 'session' 82 %.y))
  ?:  =('workspace-observe' kind)
    [%native-coding-session-workspace-action-v1 [%observe id]]
  ?>  =('workspace-prepare' kind)
  =/  name=@t  (text:input object 'project' 128 %.y)
  =/  working=@tas  (name:terminal (text:input object 'workingDesk' 64 %.y))
  =/  mode=@t  (text:input object 'mode' 8 %.y)
  ?>  ?=(?(%clone %adopt) mode)
  =/  supplied  (string:cr object 'worker')
  =/  holder=@p
    ?~  supplied  our
    ?>  (lte (met 3 u.supplied) 64)
    =/  ship=@p  (need (slaw %p u.supplied))
    ?>  =(u.supplied (scot %p ship))
    ship
  ?>  (agent-live:guard our now %viki)
  =/  projects=(map @t project:nc)
    .^((map @t project:nc) %gx /(scot %p our)/viki/(scot %da now)/native-coding/projects/noun)
  =/  p=project:nc  (~(got by projects) name)
  ?>  &((valid:project p) =(our authority.spec.p) !=(working working.p))
  =/  source  (current:project our now p)
  ?>  ?=(%& -.source)
  =/  existing=(unit existing:bootstrap)
    ?:  =(%clone mode)  ~
    =/  target  (current:project our now p(working working))
    ?>  ?=(%& -.target)
    `[revision.working.p.target (claim our now base-desk.spec.p working holder)]
  =/  q=request:setup
    [%native-coding-session-workspace-v1 id name revision.accepted.p.source working holder `?(%clone %adopt)`mode existing]
  =/  e=entry:setup
    [q p (configuration:project p) (nonce:setup q p) %preparing %session-workspace-requested]
  ?>  (request-valid:bootstrap our (request-for:setup e))
  [%native-coding-session-workspace-action-v1 [%prepare q]]
++  open-ready
  ::  A retained preparation or explicit workspace selection forbids fallback.
  |=  [our=@p now=@da id=@ux object=json]
  ^-  ?
  ?.  (agent-live:guard our now %viki)  %.n
  =/  expected  (string:cr object 'workspace')
  ?.  ?~(expected =((field:cr object 'workspace') ~) =(u.expected (scot %ux id)))  %.n
  =/  held  (entry our now id)
  ?~  held  ?=(~ expected)
  =/  worker=@t  (fall (string:cr object 'worker') (scot %p our))
  ?.  =(worker (scot %p holder.request.u.held))  %.n
  =/  scoped  (selected our now id)
  ?~  scoped  %.n
  ?:  ?=(%| -.u.scoped)  %.n
  &(=(p.u.scoped (scoped:setup u.held)) =(`project.request.u.held (string:cr object 'project')))
--
