::  Exact native compile receipts, never activation or a substitute for tests.
/-  c=readymade-collab, j=readymade-collab-jobs, pkg=readymade-package
/+  package=readymade-package, transfer=readymade-package-transfer,
    clw=cantrip-law-window, guard=viki-scry-guard
|%
+$  plan
  $:  offer=offer:pkg
      nonce=@ux
      consent=@ux
      destination=@tas
      revision=@ud
      root=@uv
      stage-proof=@ux
      source-proof=@ux
  ==
+$  artifact  [path=path source=@ux type=@ux code=@ux bytes=@ud law=@ux]
+$  body
  $:  %readymade-package-build-receipt-v1
      plan=plan
      mode=%ford-hoon-compile
      manifest=@ux
      artifacts=(list artifact)
      artifact=@ux
      apps=@ux
      routes=@ux
      law=@ux
  ==
+$  receipt  [body=body proof=@ux]
+$  result
  $%  [%confirmed receipt=receipt]
      [%refused reason=@tas]
      [%failed path=path reason=@tas]
      [%uncertain path=path reason=@tas]
  ==
++  compile-permitted
  ::  The existing cantrip-vibecoding-compile +permission gate: compiling
  ::  is a probe/comparison, never a landing or authority to implement.
  |=  window=window:clw
  ^-  ?
  %+  levy  `(list act:clw)`~[%probe %compare]
  |=  act=act:clw
  ?&  (~(has in admissible.window) act)
      !(~(has in blocked.window) act)
      !(~(has in never-auto.window) act)
  ==
++  current-law
  ::  Native current judgment, not the pact's historical policy commitment.
  |=  [our=@p now=@da]
  ^-  (each @ux @tas)
  ?.  &((agent-live:guard our now %cantrip) (agent-live:guard our now %graf))
    [%| %current-law-unavailable]
  =/  raw=*  .^(* %gx /(scot %p our)/cantrip/(scot %da now)/law/window/current/noun)
  =/  parsed=(unit window:clw)  ((soft window:clw) raw)
  ?~  parsed  [%| %current-law-invalid]
  ?.  (compile-permitted u.parsed)  [%| %probe-not-admitted]
  [%& (shax (jam u.parsed))]
++  source-supported
  |=  f=file:pkg
  ^-  ?
  &((path-valid:package path.f) =(%hoon (rear path.f)) (gth size.f 0) (lte size.f 262.144))
++  plan-valid
  |=  [our=@p p=plan]
  ^-  ?
  ?&  (valid:package offer.p)
      =(our recipient.body.offer.p)
      (digest-valid:package nonce.p)
      (digest-valid:package stage-proof.p)
      (digest-valid:package source-proof.p)
      =(consent.p (consent-digest:package offer.p destination.p))
      (segment-valid:package destination.p)
      !(lien `(list @tas)`~[%base %germ %pataphor %$] |=(d=@tas =(d destination.p)))
      !=(destination.p desk.source.body.offer.p)
      =(1 revision.p)
      !=(0 root.p)
      (lte (met 0 root.p) 256)
      (lte (lent files.body.offer.p) 8)
      (levy files.body.offer.p source-supported)
  ==
++  ready
  ::  Journal and state must both be native receiver-owned observations.
  |=  [our=@p state=state:c ledger=ledger:j id=@ux nonce=@ux]
  ^-  (each plan @tas)
  ?.  (lte ~(wyt by ledger) 1.024)  [%| %job-capacity]
  =/  builds=(list job:j)
    (skim ~(val by ledger) |=(job=job:j &(=(%build kind.job) =(%pending phase.job) =(nonce nonce.job) =(offer.job `id))))
  ?.  ?=([* ~] builds)  [%| %pending-build-required]
  =/  job=job:j  i.builds
  ?.  ?&  =('build' op.command.job)
          =(owner.command.job (scot %p our))
          =(id.command.job (scot %ux id))
          =(digest.command.job id.command.job)
      ==
    [%| %build-owner]
  =/  old=(unit package:c)  (~(get by packages.state) id)
  ?~  old  [%| %unknown-package]
  =/  value=state:pkg  value.u.old
  ?.  ?&  =(%accepted stage.value)
          ?=(^ destination.value)
          ?=(^ consent.value)
          =(id digest.offer.value)
          =(inspection.value `(inspection-digest:package offer.value))
          =(peer.command.job (scot %p sender.body.offer.value))
      ==
    [%| %canonical-consent-required]
  =/  stages=(list job:j)
    (skim ~(val by ledger) |=(prior=job:j &(=(%stage kind.prior) =(%confirmed phase.prior) =(offer.prior `id))))
  ?.  ?=([* ~] stages)  [%| %confirmed-stage-required]
  =/  prior=job:j  i.stages
  ?.  ?&  =(owner.command.prior (scot %p our))
          =('accept' op.command.prior)
          =(peer.command.prior peer.command.job)
          =(id.command.prior (scot %ux id))
          =(digest.command.prior id.command.prior)
      ==
    [%| %stage-owner]
  ?~  result.prior  [%| %stage-receipt-required]
  =/  parsed
    ((soft ,[%readymade-package-stage-v1 offer=@ux nonce=@ux answer=stage-result:j]) u.result.prior)
  ?~  parsed  [%| %stage-receipt-invalid]
  =/  callback  u.parsed
  ?.  ?=(%confirmed -.answer.callback)  [%| %stage-not-confirmed]
  ?.  ?&  =(id offer.callback)
          =(nonce.prior nonce.callback)
          =(destination.answer.callback u.destination.value)
      ==
    [%| %stage-binding-mismatch]
  =/  p=plan
    [offer.value nonce u.consent.value u.destination.value revision.answer.callback root.answer.callback proof.answer.callback source-proof.answer.callback]
  ?.  (plan-valid our p)  [%| %unsupported-build-source]
  [%& p]
++  artifact-digest
  |=  [p=plan artifacts=(list artifact)]
  ^-  @ux
  (shax (jam [%readymade-package-artifact-v1 digest.offer.p consent.p destination.p revision.p root.p artifacts]))
++  receipt-digest
  |=  b=body
  ^-  @ux
  (shax (jam [%readymade-package-build-proof-v1 b]))
++  summarize
  ::  Native Ford already selected the %vase mark. Only require its outer
  ::  pair here: recursive TYPE and value remain opaque, inert hash inputs.
  ::  This does not validate a type, evaluate code or attest functional tests.
  |=  raw=*
  ^-  (each [type=@ux code=@ux bytes=@ud] @tas)
  ?@  raw  [%| %ford-result-type]
  =/  size=@ud  (met 3 (jam raw))
  ?:  (gth size 2.097.152)  [%| %artifact-too-large]
  [%& [(shax (jam -.raw)) (shax (jam +.raw)) size]]
++  artifact-valid
  |=  a=artifact
  ^-  ?
  &((path-valid:package path.a) (digest-valid:package source.a) (digest-valid:package type.a) (digest-valid:package code.a) (gth bytes.a 0) (lte bytes.a 2.097.152) (digest-valid:package law.a))
++  valid
  |=  [our=@p r=receipt]
  ^-  ?
  =/  b=body  body.r
  ?&  (plan-valid our plan.b)
      =(manifest.b (manifest:package files.body.offer.plan.b))
      =((turn artifacts.b |=(a=artifact [path.a source.a])) (turn files.body.offer.plan.b |=(f=file:pkg [path.f hash.f])))
      (levy artifacts.b artifact-valid)
      =(artifact.b (artifact-digest plan.b artifacts.b))
      (digest-valid:package apps.b)
      (digest-valid:package routes.b)
      (digest-valid:package law.b)
      =(proof.r (receipt-digest b))
  ==
++  seal
  |=  [our=@p p=plan artifacts=(list artifact) apps=@ux routes=@ux law=@ux]
  ^-  receipt
  =/  b=body
    [%readymade-package-build-receipt-v1 p %ford-hoon-compile (manifest:package files.body.offer.p) artifacts (artifact-digest p artifacts) apps routes law]
  =/  r=receipt  [b (receipt-digest b)]
  ?>  (valid our r)
  r
++  verify-workspace
  ::  Native readback only; neither a missing desk nor stale root is a probe.
  |=  [our=@p now=@da p=plan]
  ^-  (unit @tas)
  ?.  (plan-valid our p)  `%invalid-plan
  =/  domes=cone:clay  .^(cone:clay %cx /(scot %p our)//(scot %da now)/domes)
  =/  dome=(unit dome:clay)  (~(get by domes) [our destination.p])
  ?~  dome  `%workspace-missing
  ?.  &(=(revision.p let.u.dome) =(%dead liv.u.dome) =(~ ren.u.dome) =(~ wic.u.dome))
    `%workspace-changed
  =/  prefix=path  ~[(scot %p our) destination.p (scot %ud revision.p)]
  ?.  =(root.p .^(@uv %cz prefix))  `%workspace-root-mismatch
  =/  rules=[r=dict:clay w=dict:clay]  .^([r=dict:clay w=dict:clay] %cp prefix)
  ?.  &(=([%white ~ ~] rul.r.rules) =([%white ~ ~] rul.w.rules))
    `%workspace-not-private
  =/  paths=(list path)  .^((list path) %ct prefix)
  =/  expected=(set path)
    (~(uni in support-paths:transfer) (silt (turn files.body.offer.p |=(f=file:pkg path.f))))
  ?.  =((silt paths) expected)  `%workspace-paths-mismatch
  ?.  %+  levy  files.body.offer.p
      |=  f=file:pkg
      =/  raw=(unit @t)  ((soft @t) .^(* %cq (weld prefix path.f)))
      ?~  raw  %.n
      =(f (source-file:package path.f u.raw))
    `%workspace-source-mismatch
  ?.  =(~ .^(* %cq (weld prefix /desk/bill)))  `%workspace-bill-mismatch
  =/  kernel=*  .^(* %cq (weld prefix /sys/kelvin))
  ?.  =(kernel .^(* %cq /(scot %p our)/base/(scot %da now)/sys/kelvin))
    `%workspace-kelvin-mismatch
  ~
--
