::  Parent-owned immutable orders, detached export offers and result joins.
::  Native readers must supply fresh authority/source facts before these gates.
/-  w=native-coding-worker, wr=native-coding-worker-runtime, nc=native-coding
/+  worker=native-coding-worker, journal=native-coding-worker-journal,
    ct=cantrip-native-coding, accept=native-coding-accept,
    allowance=native-coding-check-authorization, project=native-coding-project
|%
+$  state
  [%native-coding-worker-owner-v1 pairing=(unit pairing:w) journal=journal:w offers=(map @ux offer:wr)]
+$  effect  $%([%export order=order:w] [%dispatch order=order:w])
+$  change  [state=state effects=(list effect)]
++  empty  `state`[%native-coding-worker-owner-v1 ~ ~ ~]
++  authority
  |=  [r=record:accept grant=scope:ct allowed=allowance:allowance]
  (digest:worker [%candidate-worker-authority-v1 (frozen:allowance r) grant allowed])
++  scope
  |=  [pairing=pairing:w r=record:accept grant=scope:ct allowed=allowance:allowance]
  ^-  scope:w
  =/  a=@ux  (authority r grant allowed)
  [pairing id.grant.grant a (digest:worker [%candidate-worker-admission-v1 a]) ?=(^ revoked.grant)]
++  ticket
  |=(r=record:accept ^-(@ux (digest:accept [%native-coding-check-ticket-v1 r])))
++  make-order
  ::  The current reader additionally checks candidate-permission, membership,
  ::  the live law window and exact accepted/working/staged Clay revisions.
  |=  [now=@da deadline=@da pairing=pairing:w r=record:accept grant=scope:ct allowed=allowance:allowance]
  ^-  (each order:w @tas)
  ?.  &((pairing-valid:worker pairing) =(owner.pairing actor.context.candidate.r))
    [%| %worker-pairing-refused]
  ?.  &((valid:accept (my ~[[id.candidate.r r]])) ?=(^ staging.r) |((check-scheduled:accept r) (check-dispatched:accept r)))
    [%| %worker-candidate-not-checking]
  ?.  ?&  (grant-valid:ct owner.pairing grant.grant)  ?=(~ revoked.grant)
          =(grant.r id.grant.grant)  =(project.r project.grant.grant)
          =(session.context.candidate.r session.grant.grant)
          =(actor.context.candidate.r actor.grant.grant)
          (~(has in operations.grant.grant) %compile)
          (~(has in operations.grant.grant) %check)
      ==  [%| %worker-grant-refused]
  =/  auth=scope:w  (scope pairing r grant allowed)
  =/  o=order:w
    :*  %native-coding-worker-order-v1
        (ticket r)
        pairing  grant.auth  authority.auth  decision.auth
        context.candidate.r  id.candidate.r  revision.u.staging.r
        (namespace-digest:worker files.body.snapshot.u.staging.r)
        (required:accept project.r candidate.r)  maximum.allowed  now  deadline
    ==
  ?.  (order-valid:worker o)  [%| %worker-order-invalid]
  [%& o]
++  revoke-pending
  |=  held=journal:w
  ^-  journal:w
  %-  ~(run by held)
  |=  r=record:w
  ?:  ?=(?(%checked %refused %revoked) phase.r)  r
  r(phase %revoked, reason `%worker-pairing-changed)
++  configure
  |=  [our=@p src=@p s=state pairing=(unit pairing:w)]
  ^-  (each state @tas)
  ?.  =(our src)  [%| %worker-owner-required]
  ?^  pairing
    ?.  &((pairing-valid:worker u.pairing) =(our owner.u.pairing))
      [%| %worker-pairing-refused]
    ?:  =(pairing pairing.s)  [%& s]
    [%& s(pairing pairing, journal (revoke-pending journal.s))]
  [%& s(pairing ~, journal (revoke-pending journal.s))]
++  reserve
  |=  [our=@p src=@p now=@da s=state auth=scope:w o=order:w]
  ^-  (each change @tas)
  ?.  =(`pairing.o pairing.s)  [%| %worker-not-selected]
  =/  key=@ux  (digest:worker o)
  =/  prior  (~(get by journal.s) key)
  =/  next  (reserve:journal our src now journal.s auth o)
  ?:  ?=(%| -.next)  [%| p.next]
  [%& [s(journal state.p.next) ?~(prior ~[[%export o]] ~)]]
++  begin
  ::  Find the saved ticket BEFORE choosing issued/deadline or an order hash.
  ::  An identical later start never creates a new order or repeats export.
  |=  [our=@p src=@p now=@da deadline=@da s=state r=record:accept grant=scope:ct allowed=allowance:allowance]
  ^-  (each change @tas)
  ?.  =(our src)  [%| %worker-owner-required]
  ?~  pairing.s  [%| %worker-not-selected]
  =/  auth=scope:w  (scope u.pairing.s r grant allowed)
  =/  prior=(list record:w)
    (skim ~(val by journal.s) |=(v=record:w =((ticket r) ticket.order.v)))
  ?^  prior
    ?.  &(?=([* ~] prior) (authorized:worker auth order.i.prior))
      [%| %worker-start-authority-changed]
    [%& [s ~]]
  =/  made  (make-order now deadline u.pairing.s r grant allowed)
  ?:  ?=(%| -.made)  [%| p.made]
  (reserve our src now s auth p.made)
++  exported
  ::  Caller authenticates the one outstanding Khan export response and reads
  ::  this complete map/parent set from canonical Clay, never from the payload.
  |=  [our=@p s=state key=@ux revision=revision:nc files=(map path @ux) parents=(list @uv)]
  ^-  (each state @tas)
  =/  found  (~(get by journal.s) key)
  ?~  found  [%| %worker-order-missing]
  =/  o=order:w  order.u.found
  ?.  ?&  =(our owner.pairing.o)  (revision-valid:project revision)
          =(our owner.revision)  =(1 number.revision)  ?=(~ parents)
          !=(desk.source.o desk.revision)
          =((namespace-digest:worker files) namespace.o)
      ==  [%| %worker-export-mismatch]
  =/  offer=offer:wr
    [%native-coding-worker-offer-v1 o revision [%admitted decision.o key deadline.o]]
  =/  prior  (~(get by offers.s) key)
  ?^  prior
    ?.  =(offer u.prior)  [%| %worker-export-conflict]
    [%& s]
  ?.  &(!sent.u.found =(%reserved phase.u.found))  [%| %worker-export-not-pending]
  [%& s(offers (~(put by offers.s) key offer))]
++  dispatch
  |=  [our=@p src=@p now=@da s=state auth=scope:w key=@ux]
  ^-  (each change @tas)
  =/  offer  (~(get by offers.s) key)
  ?~  offer  [%| %worker-export-not-confirmed]
  ?.  =(`pairing.order.u.offer pairing.s)  [%| %worker-not-selected]
  =/  next  (dispatch:journal our src now journal.s auth key)
  ?:  ?=(%| -.next)  [%| p.next]
  [%& [s(journal state.p.next) effects.p.next]]
++  offered
  ::  Current authority/source must be re-read before calling this reader.
  |=  [our=@p src=@p now=@da s=state auth=scope:w key=@ux]
  ^-  (unit offer:wr)
  =/  found  (~(get by journal.s) key)
  ?~  found  ~
  =/  r=record:w  u.found
  ?.  ?&  =(our owner.pairing.order.r)
          |(=(our src) =(worker.pairing.order.r src))
          =(`pairing.order.r pairing.s)  sent.r
          ?=(?(%dispatched %unknown) phase.r)
          (authorized:worker auth order.r)  (lth now deadline.order.r)
      ==  ~
  (~(get by offers.s) key)
++  receive
  |=  [our=@p src=@p app=@tas authenticated=? now=@da s=state auth=scope:w result=result:w]
  ^-  (each change @tas)
  ?.  authenticated  [%| %worker-subscription-required]
  =/  next  (receive:journal our src app now journal.s auth result)
  ?:  ?=(%| -.next)  [%| p.next]
  [%& [s(journal state.p.next) ~]]
++  report
  ::  Keep the original local-revision receipt in the journal. Only its
  ::  diagnostic source references are translated into the retained candidate.
  |=  [s=state auth=scope:w key=@ux candidate=record:accept]
  ^-  (each report:accept @tas)
  =/  found  (~(get by journal.s) key)
  ?~  found  [%| %worker-order-missing]
  =/  r=record:w  u.found
  =/  o=order:w  order.r
  ?.  &(?=(^ result.r) =(%checked phase.r) (authorized:worker auth o) =(`pairing.o pairing.s))
    [%| %worker-result-not-current]
  =/  result=result:w  u.result.r
  ?.  &(?=(%checked -.outcome.result) ?=(^ staging.candidate))
    [%| %worker-result-not-checked]
  ?.  ?&  =(candidate.o id.candidate.candidate)
          =(context.o context.candidate.candidate)  =(grant.o grant.candidate)
          =(source.o revision.u.staging.candidate)
          =(namespace.o (namespace-digest:worker files.body.snapshot.u.staging.candidate))
          =(targets.o (required:accept project.candidate candidate.candidate))
      ==  [%| %worker-candidate-mismatch]
  =/  rows=(list target-result:accept)
    %+  turn  rows.outcome.result
    |=  row=row:w
    [target.row (turn diagnostics.row |=(d=diagnostic:nc d(source source.o)))]
  =/  report=report:accept
    [%native-coding-candidate-report-v1 candidate.o u.staging.candidate rows]
  ?.  (report-valid:accept project.candidate candidate.candidate report)
    [%| %worker-report-invalid]
  [%& report]
++  recover
  |=  s=state
  ^-  change
  [s(journal state:(recover:journal journal.s)) ~]
++  valid
  |=  [our=@p s=state]
  ^-  ?
  ?&  ?~(pairing.s %.y &((pairing-valid:worker u.pairing.s) =(our owner.u.pairing.s)))
      (valid:journal our journal.s)  (lte ~(wyt by offers.s) capacity:journal)
      %+  levy  ~(tap by offers.s)
      |=  [key=@ux offer=offer:wr]
      =/  found  (~(get by journal.s) key)
      ?~  found  %.n
      ?&  =(order.u.found order.offer)  =((digest:worker order.offer) key)
          (revision-valid:project export.offer)  =(our owner.export.offer)
          =(1 number.export.offer)  !=(desk.source.order.offer desk.export.offer)
          =(admission.offer [%admitted decision.order.offer key deadline.order.offer])
      ==
  ==
--
