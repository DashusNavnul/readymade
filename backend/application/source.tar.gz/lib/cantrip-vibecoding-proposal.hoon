::  /lib/cantrip-vibecoding-proposal
::
::  Pure Cantrip-side simulation for Viki's inert vibecoding proposal.  The
::  complete rejection list is the decision; empty means review-admitted.
::  Nothing in this core emits cards or grants execution authority.
::
/-  dvn=derivation, itn=intent, vi=viki-inference, vp=vibecoding-proposal
/+  clw=cantrip-law-window
|%
++  max-acts         `@ud`32
++  max-files        `@ud`64
++  max-surfaces     `@ud`32
++  max-evidence     `@ud`64
++  max-obligations  `@ud`32
++  max-path-parts    `@ud`32
++  max-summary-bytes  16.384
++  max-rationale-bytes  16.384
::
::  These are the only digest sites for this contract.
++  proposal-digest
  |=  body=body:vp
  ^-  @ux
  `@ux`(shax (jam body))
++  law-digest
  |=  [version=@ud window=window:clw]
  ^-  @ux
  `@ux`(shax (jam [version window]))
++  result-digest
  |=  result=result-v2:vi
  ^-  @ux
  `@ux`(shax (jam result))
++  record-digest
  |=  body=record-body:vp
  ^-  @ux
  `@ux`(shax (jam body))
++  record-for
  |=  [proposal=proposal:vp verdict=verdict:vp recorded-at=@da]
  ^-  record:vp
  =/  body=record-body:vp  [proposal verdict]
  [%vibecoding-proposal-record-v1 body (record-digest body) recorded-at]
++  record-valid
  |=  record=record:vp
  =/  law-stale=?
    !=(law-digest.body.proposal.body.record law-digest.verdict.body.record)
  =/  has-law-stale=?
    %+  lien  reasons.verdict.body.record
    |=(reason=rejection:vp =(%proposal-law-stale -.reason))
  ^-  ?
  ?&  =((record-digest body.record) digest.record)
      =((proposal-digest body.proposal.body.record) digest.proposal.body.record)
      =(digest.proposal.body.record proposal-digest.verdict.body.record)
      =(law-stale has-law-stale)
      =(?=(~ reasons.verdict.body.record) review-admitted.verdict.body.record)
      !execution-admitted.verdict.body.record
  ==
++  fact
  |=  record=record:vp
  ^-  *
  [%vibecoding-proposal-record (scot %ux digest.record) record]
++  find-record
  |=  [rows=(list *) digest=@ux]
  ^-  (unit record:vp)
  ?~  rows  ~
  =/  parsed=(unit [kind=@tas id=@t item=record:vp])
    ((soft ,[@tas @t record:vp]) i.rows)
  ?^  parsed
    ?:  ?&  =(%vibecoding-proposal-record kind.u.parsed)
            =(digest digest.item.u.parsed)
            (record-valid item.u.parsed)
        ==
      `item.u.parsed
    $(rows t.rows)
  $(rows t.rows)
++  find-proposal-record
  |=  [rows=(list *) proposal-digest=@ux]
  ^-  (unit record:vp)
  ?~  rows  ~
  =/  parsed=(unit [kind=@tas id=@t item=record:vp])
    ((soft ,[@tas @t record:vp]) i.rows)
  ?^  parsed
    ?:  ?&  =(%vibecoding-proposal-record kind.u.parsed)
            =(proposal-digest digest.proposal.body.item.u.parsed)
            (record-valid item.u.parsed)
        ==
      `item.u.parsed
    $(rows t.rows)
  $(rows t.rows)
++  proposal-for
  |=  [body=body:vp proposed-at=@da]
  ^-  proposal:vp
  [%vibecoding-proposal-v1 body (proposal-digest body) proposed-at]
++  law-binding-for
  |=  [version=@ud window=window:clw]
  ^-  law-binding:vp
  [version window (law-digest version window)]
++  model-binding-for
  |=  [request=request-v2:vi result=result-v2:vi]
  ^-  model-binding:vp
  :*  request-id.request
      backend.request
      oracle.ask.want.request
      digest.constraint.request
      (result-digest result)
  ==
::
++  path-parts-valid
  |=  parts=(list @tas)
  ^-  ?
  ?~  parts  %.y
  =/  rest=(list @tas)  t.parts
  ?&  !=(0 i.parts)
      (path-parts-valid rest)
  ==
++  path-valid
  |=  parts=(list @tas)
  ^-  ?
  ?&  !=(~ parts)
      (lte (lent parts) max-path-parts)
      (path-parts-valid parts)
  ==
++  surface-valid
  |=  item=surface:vp
  ^-  ?
  ?-  -.item
    %clay
      ?&  !=(0 desk.item)
          (path-valid path.item)
      ==
    %thread
      ?&  !=(0 desk.item)
          !=(0 name.item)
      ==
    %graf
      !=('' handle.item)
    %gall
      ?&  !=(0 agent.item)
          (path-valid route.item)
      ==
  ==
++  file-valid
  |=  item=file-ref:vp
  ^-  ?
  ?&  !=(0 desk.item)
      (path-valid path.item)
      ?|(?=(^ before.item) ?=(^ after.item))
  ==
++  unique-digests
  |=  items=(list @ux)
  ^-  ?
  ?~  items  %.y
  =/  rest=(list @ux)  t.items
  ?&  !(lien rest |=(item=@ux =(i.items item)))
      (unique-digests rest)
  ==
++  surfaces-unique
  |=  items=(list surface:vp)
  ^-  ?
  (unique-digests (turn items |=(item=surface:vp `@ux`(shax (jam item)))))
++  files-unique
  |=  items=(list file-ref:vp)
  ^-  ?
  (unique-digests (turn items |=(item=file-ref:vp `@ux`(shax (jam [desk.item path.item])))))
++  evidence-unique
  |=  items=(list @t)
  ^-  ?
  ?~  items  %.y
  =/  rest=(list @t)  t.items
  ?&  !(lien rest |=(item=@t =(i.items item)))
      (evidence-unique rest)
  ==
++  act-sequence-valid
  |=  [want=@ud acts=(list proposed-act:vp)]
  ^-  ?
  ?~  acts  %.y
  ?&  =(want sequence.i.acts)
      (act-sequence-valid +(want) t.acts)
  ==
++  act-shape-valid
  |=  item=proposed-act:vp
  ^-  ?
  ?-  kind.item
    %read         =([before.item after.item] [~ ~])
    %inspect      =([before.item after.item] [~ ~])
    %compare      =([before.item after.item] [~ ~])
    %hypothesize  =([before.item after.item] [~ ~])
    %probe        =([before.item after.item] [~ ~])
    %summarize    =([before.item after.item] [~ ~])
    %done         =([before.item after.item] [~ ~])
    %inscribe     !=([before.item after.item] [~ ~])
    %implement    !=([before.item after.item] [~ ~])
    %promote      !=([before.item after.item] [~ ~])
    %branch       !=([before.item after.item] [~ ~])
    %reduce       !=([before.item after.item] [~ ~])
  ==
++  origin-matches
  |=  [origin=origin:vp intent=intent:itn]
  ^-  ?
  ?&  =(intent-id.origin id.intent)
      =(convo.origin convo.intent)
      =(from-seq.origin from-seq.intent)
      =(operator.origin by.intent)
  ==
++  act-rejections
  |=  [item=proposed-act:vp surfaces=(list surface:vp) law=law-binding:vp]
  ^-  (list rejection:vp)
  =/  reasons=(list rejection:vp)  ~
  =?  reasons  !(surface-valid target.item)
    [[%act-target-invalid sequence.item] reasons]
  =?  reasons  !(act-shape-valid item)
    [[%act-shape-invalid sequence.item kind.item] reasons]
  =?  reasons  !(lien surfaces |=(surface=surface:vp =(target.item surface)))
    [[%act-surface-undeclared sequence.item] reasons]
  =?  reasons  !(~(has in admissible.window.law) kind.item)
    [[%act-blocked sequence.item kind.item] reasons]
  =?  reasons  (~(has in never-auto.window.law) kind.item)
    [[%act-needs-ratification sequence.item kind.item] reasons]
  reasons
++  all-act-rejections
  |=  [acts=(list proposed-act:vp) surfaces=(list surface:vp) law=law-binding:vp]
  ^-  (list rejection:vp)
  ?~  acts  ~
  (weld (act-rejections i.acts surfaces law) (all-act-rejections t.acts surfaces law))
::
++  rejections
  |=  $:  proposal=proposal:vp
          intent=intent:itn
          request=request-v2:vi
          result=result-v2:vi
          law=law-binding:vp
      ==
  ^-  (list rejection:vp)
  =/  body=body:vp  body.proposal
  =/  reasons=(list rejection:vp)  ~
  =?  reasons  !=(1 version.body)
    [[%proposal-version-invalid ~] reasons]
  =?  reasons  !=((proposal-digest body) digest.proposal)
    [[%proposal-digest-mismatch ~] reasons]
  =?  reasons  !=(1 version.law)
    [[%law-version-invalid ~] reasons]
  =?  reasons  !=((law-digest version.law window.law) digest.law)
    [[%law-digest-mismatch ~] reasons]
  =?  reasons  !=(law-digest.body digest.law)
    [[%proposal-law-stale ~] reasons]
  =?  reasons  !(origin-matches origin.body intent)
    [[%intent-mismatch ~] reasons]
  =?  reasons  !=(%stated state.intent)
    [[%intent-not-stated ~] reasons]
  =?  reasons  !(request-bound:vi request)
    [[%model-request-unbound ~] reasons]
  =?  reasons  !(result-matches-request:vi request result)
    [[%model-result-mismatch ~] reasons]
  =?  reasons  !=((model-binding-for request result) model.body)
    [[%model-binding-mismatch ~] reasons]
  =?  reasons  =(0 wgt.oracle.ask.want.request)
    [[%oracle-unbound ~] reasons]
  =?  reasons  !=(evidence.body refs.want.request)
    [[%evidence-mismatch ~] reasons]
  =?  reasons  =(0 (lent acts.body))
    [[%acts-empty ~] reasons]
  =?  reasons  (gth (lent acts.body) max-acts)
    [[%acts-over-limit ~] reasons]
  =?  reasons  !(act-sequence-valid 0 acts.body)
    [[%act-sequence-invalid ~] reasons]
  =?  reasons  (gth (lent files.body) max-files)
    [[%files-over-limit ~] reasons]
  =?  reasons  (lien files.body |=(item=file-ref:vp !(file-valid item)))
    [[%file-invalid ~] reasons]
  =?  reasons  !(files-unique files.body)
    [[%file-duplicate ~] reasons]
  =?  reasons  (gth (lent surfaces.body) max-surfaces)
    [[%surfaces-over-limit ~] reasons]
  =?  reasons  (lien surfaces.body |=(item=surface:vp !(surface-valid item)))
    [[%surface-invalid ~] reasons]
  =?  reasons  !(surfaces-unique surfaces.body)
    [[%surface-duplicate ~] reasons]
  =?  reasons  (gth (lent evidence.body) max-evidence)
    [[%evidence-over-limit ~] reasons]
  =?  reasons  !(evidence-unique evidence.body)
    [[%evidence-duplicate ~] reasons]
  =?  reasons  (gth (lent obligations.body) max-obligations)
    [[%obligations-over-limit ~] reasons]
  =?  reasons  (lien obligations.body |=(item=@t =('' item)))
    [[%obligation-empty ~] reasons]
  =?  reasons  =('' summary.body)
    [[%summary-empty ~] reasons]
  =?  reasons  (gth (met 3 summary.body) max-summary-bytes)
    [[%summary-over-limit ~] reasons]
  =?  reasons  (gth (met 3 rationale.body) max-rationale-bytes)
    [[%rationale-over-limit ~] reasons]
  (weld reasons (all-act-rejections acts.body surfaces.body law))
++  judge
  |=  $:  proposal=proposal:vp
          intent=intent:itn
          request=request-v2:vi
          result=result-v2:vi
          law=law-binding:vp
      ==
  ^-  verdict:vp
  =/  reasons=(list rejection:vp)
    (rejections proposal intent request result law)
  :*  %vibecoding-proposal-verdict-v1
      digest.proposal
      digest.law
      ?=(~ reasons)
      %.n
      reasons
  ==
++  verdict-current
  |=  [proposal=proposal:vp law=law-binding:vp verdict=verdict:vp]
  ^-  ?
  ?&  =(digest.proposal proposal-digest.verdict)
      =(digest.law law-digest.verdict)
  ==
--
