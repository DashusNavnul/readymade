::  /lib/cantrip-law-engine.hoon
::
::  cantrip's law: the policy that decides what may be engraved in canon. Not one
::  rule -- a composed set, each producing a rejection reason (empty = approved),
::  mirroring the old law's *-rejection-reasons. Grows by adding clauses here; the
::  substrate and governance wiring do not change.
::
::  Rules (phase-16 set, extend freely):
::   - CANON-KIND: only truth-bearing relation kinds may be engraved.
::   - CONFORMANCE: the source must be a schema-valid handle [kind id].
::   - ATTESTATION: canon requires reputation -- at least canon-quorum DISTINCT
::     attesting ships for the underlying fact. graf computes the live count
::     (it owns attestation) and passes it in; the law stays pure.
::     The clause binds NON-PRINCIPAL proposers only: the ship's own engraving
::     acts (e.g. %ratify-goal) are a separate authority channel, already
::     src-gated and window-gated upstream; an attached foreign proposer must
::     bring fleet reputation. graf passes principal=? (unforgeable src.bowl).
::
/-  cl=canon-law
/+  graf-relations, cantrip-schema
|%
++  canon-kinds
  ^-  (set @tas)
  ::  %bound-by admits PRESCRIPTIONS (sur/canon-law +prescribe):
  ::  [[%purpose p] %bound-by [%law l]] — binding a purpose to an
  ::  engraved law.  Widening a vocabulary is a canon change, never an
  ::  agent edit; the same governor gate, writer-identity law, and
  ::  reputation quorum apply as to every other engraving.
  (silt `(list @tas)`~[%proven %verifies %approves %completed %ratified %bound-by])
++  rejections
  |=  r=rel:graf-relations
  ^-  (list @t)
  =/  src-ok=?   ?&(?=([@ *] src.r) (valid-kind:cantrip-schema `@tas`-.src.r))
  =/  kind-ok=?  (~(has in canon-kinds) kind.r)
  ::  PRESCRIPTION SHAPE (hostile-pass finding): a %bound-by that the
  ::  held builder would skip must never engrave -- canon that binds
  ::  nothing is pollution the governor signed.  src must be a %purpose
  ::  handle, dst must parse as an engraved law, and a %vocab law may
  ::  not use 0x0 for vid or root (0x0 is the conflict sentinel).
  =/  pres-ok=?
    ?.  =(%bound-by kind.r)  %.y
    ?.  ?=([%purpose @] src.r)  %.n
    ?.  ?=([%law *] dst.r)  %.n
    =/  l=(unit law:cl)  ((soft law:cl) +.dst.r)
    ?~  l  %.n
    ?.  ?=(%vocab -.u.l)  %.y
    &(!=(0x0 vid.u.l) !=(0x0 root.u.l))
  =/  rs=(list @t)  ~
  =?  rs  !kind-ok  ['not-a-canon-relation-kind' rs]
  =?  rs  !src-ok   ['source-not-a-valid-handle' rs]
  =?  rs  !pres-ok  ['prescription-malformed' rs]
  rs
++  approves  |=(r=rel:graf-relations =(~ (rejections r)))
++  canon-quorum  `@ud`2
++  rejections-attested
  |=  [r=rel:graf-relations reps=@ud]
  ^-  (list @t)
  =/  rs  (rejections r)
  ?:  (gte reps canon-quorum)  rs
  ['insufficient-attestation' rs]
++  approves-attested
  |=  [r=rel:graf-relations reps=@ud]
  =(~ (rejections-attested r reps))
++  rejections-gated
  |=  [r=rel:graf-relations reps=@ud principal=?]
  ^-  (list @t)
  ?:(principal (rejections r) (rejections-attested r reps))
++  approves-gated
  |=  [r=rel:graf-relations reps=@ud principal=?]
  =(~ (rejections-gated r reps principal))
--
