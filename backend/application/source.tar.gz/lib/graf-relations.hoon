::  /lib/graf-relations.hoon
::
::  The mutable relation overlay over the immutable fact floor (graf-substrate).
::  A relation is an edge between two facts, tagged by kind: [src kind dst].
::  Facts never change; how they RELATE is changeable, in three tiers:
::
::    private    each app's own working notebook. Free, per-app, ISOLATED --
::               one app's private notes are invisible to another's private.
::    published  each app owns ONE slot on a shared bulletin board. An app freely
::               writes ITS OWN slot; everyone reads all slots. Permissionless
::               ("being seen is free"). An app can never write another's slot --
::               enforced structurally: every op keys on the app and only touches
::               that app's slot (the agent binds app = poke source).
::    canon      the single engraved truth all apps are bound by. Changing it is
::               GOVERNED: canonize/decanonize only apply if a gate (cantrip's
::               law) approves ("being true is governed").
::
::  Reading composites downward: canon > published > private. `view app` returns
::  every visible relation tagged with its highest tier, so the gap between
::  PINNED (published, not yet canon) and ENGRAVED (canon) is visible -- that gap
::  is where in-flight work lives.
::
/+  graf-substrate
=,  graf-substrate
|%
+$  app   @tas                              ::  a source app / brain
+$  rel   [src=fact kind=@tas dst=fact]     ::  an edge between two facts
+$  tier  ?(%private %published %canon)
+$  gate  $-(rel ?)                         ::  governance predicate for canon
+$  tiers
  $:  private=(map app (set rel))
      published=(map app (set rel))
      canon=(set rel)
  ==
::  --- private: free, per-app, isolated ---
++  private-of  |=([t=tiers a=app] (~(gut by private.t) a *(set rel)))
++  note
  |=  [t=tiers a=app r=rel]
  ^-  tiers
  t(private (~(put by private.t) a (~(put in (private-of t a)) r)))
++  unnote
  |=  [t=tiers a=app r=rel]
  ^-  tiers
  t(private (~(put by private.t) a (~(del in (private-of t a)) r)))
::  --- published: free to OWN slot, all read all ---
++  slot-of  |=([t=tiers a=app] (~(gut by published.t) a *(set rel)))
++  publish
  |=  [t=tiers a=app r=rel]
  ^-  tiers
  t(published (~(put by published.t) a (~(put in (slot-of t a)) r)))
++  unpublish
  |=  [t=tiers a=app r=rel]
  ^-  tiers
  t(published (~(put by published.t) a (~(del in (slot-of t a)) r)))
++  all-published
  |=  t=tiers
  ^-  (set rel)
  %-  ~(gas in *(set rel))
  (zing (turn ~(val by published.t) |=(s=(set rel) ~(tap in s))))
::  --- canon: governed by a gate (cantrip's law) ---
++  canonize
  |=  [t=tiers g=gate r=rel]
  ^-  tiers
  ?.  (g r)  t
  t(canon (~(put in canon.t) r))
++  decanonize
  |=  [t=tiers g=gate r=rel]
  ^-  tiers
  ?.  (g r)  t
  t(canon (~(del in canon.t) r))
::  --- composite view: canon > published > private ---
++  view
  |=  [t=tiers a=app]
  ^-  (map rel tier)
  %-  ~(gas by *(map rel tier))
  ;:  weld
    (turn ~(tap in (private-of t a)) |=(r=rel [r `tier`%private]))
    (turn ~(tap in (all-published t)) |=(r=rel [r `tier`%published]))
    (turn ~(tap in canon.t) |=(r=rel [r `tier`%canon]))
  ==
--
