::  Owner presentation/commands for Viki's existing two-request solo review.
::  Provider references contain no credentials. No verdict is accepted here.
/-  np=native-coding-provider
/+  loop=native-coding-loop, accept=native-coding-accept,
    provider=native-coding-provider, guard=viki-scry-guard,
    cr=codex-responses, catalog=native-review-provider-catalog
|%
+$  scope
  ::  Public wire shape only. Viki's local-review owner validates the command.
  [%native-coding-local-review-scope-v1 owner=@p project=@t generation=@ud enabled=? provider-key=@tas selection=selection:np]
+$  campaign-view
  ::  Project/source witnesses and authenticated replies stay opaque here.
  [request=[protocol=@tas scope=* frozen=* session=@ux mode=?(%challenge %resolve) prior=*] started=@da challenge=* resolution=* pending=(unit @ux) outcome=(unit [kind=?(%challenge %accept %refuse) reason=@t]) reason=(unit @tas) rejected=* attempt=@ud failures=*]
++  digest  |=(value=* ^-(@ux (shax (jam value))))
++  hex
  |=  [o=json key=@t]
  ^-  @ux
  =/  text=@t  (need (string:cr o key))
  =/  value=@ux  (need (slaw %ux text))
  ?>  &(!=(0 value) (lte (met 0 value) 256) =(text (scot %ux value)))
  value
++  boolean
  |=  [o=json key=@t]
  ^-  ?
  =/  value=json  (need (field:cr o key))
  ?>  ?=(%b -.value)
  p.value
++  prepare-scope
  ::  Viki rejects an intervening generation atomically; no scope expires.
  |=  [our=@p name=@t previous=(unit scope) expected=@ud enabled=? key=@tas chosen=selection:np binding=@ux consent=?]
  ^-  (each scope @tas)
  ?.  =(expected ?~(previous 0 generation.u.previous))
    [%| %solo-review-scope-changed]
  ?.  ?~(previous %.y &(=(our owner.u.previous) =(name project.u.previous)))
    [%| %solo-review-scope-mismatch]
  ?.  |(enabled ?=(^ previous))  [%| %solo-review-scope-missing]
  ?.  ?:  enabled  %.y
        ?~  previous  %.n
        &(=(key provider-key.u.previous) =(chosen selection.u.previous))
    [%| %solo-review-scope-mismatch]
  ?.  |(=(%.n enabled) consent)  [%| %solo-review-consent-required]
  ?.  =(binding (digest chosen))  [%| %solo-review-provider-changed]
  =/  next=scope
    [%native-coding-local-review-scope-v1 our name +(expected) enabled key chosen]
  ?.  ?&  !=('' name)  (lte (met 3 name) 128)
          (lte (met 0 generation.next) 64)  (name-valid:provider key)
          (selection-valid:provider chosen)
          !=('unknown' model.chosen)  !=('model-unreported' model.chosen)
      ==
    [%| %solo-review-scope-invalid]
  [%& next]
++  scopes
  |=  [our=@p now=@da]
  ^-  (map @t scope)
  =/  raw=*  .^(* %gx /(scot %p our)/viki/(scot %da now)/native-coding/local-review/scopes/noun)
  (need ((soft ,(map @t scope)) raw))
++  configured
  ::  Discovery and command lookup share conflict/revocation semantics.
  |=  [our=@p now=@da]
  ^-  (map @tas selection:np)
  =/  api=(map @tas selection:np)
    ?.  (agent-live:guard our now %codex-inference)  ~
    =/  raw=*  .^(* %gx /(scot %p our)/codex-inference/(scot %da now)/native-coding/selections/noun)
    (need ((soft ,(map @tas selection:np)) raw))
  =/  paired=(map @tas binding:catalog)
    ?.  (agent-live:guard our now %cli-inference)  ~
    =/  raw=*  .^(* %gx /(scot %p our)/cli-inference/(scot %da now)/public-bindings/noun)
    (need ((soft ,(map @tas binding:catalog)) raw))
  (combine:catalog api paired)
++  registered
  |=  [our=@p now=@da key=@tas]
  ^-  (unit selection:np)
  ?.  (name-valid:provider key)  ~
  (~(get by (configured our now)) key)
++  session
  |=  [our=@p now=@da id=@ux]
  ^-  public-session:loop
  ?>  (agent-live:guard our now %viki)
  =/  raw=*  .^(* %gx /(scot %p our)/viki/(scot %da now)/native-coding/session/(scot %ux id)/noun)
  =/  found  (need (need ((soft ,(unit public-session:loop)) raw)))
  ?>  &(=(id id.session.found) =(our owner.session.found) =(our worker.found))
  found
++  observe-command
  ::  Completed review recovery rechecks Viki/Cantrip, never model inference.
  |=  [id=@ux c=campaign-view]
  ^-  *
  ?:  ?&  ?=(~ pending.c)  ?=(~ reason.c)  ?=(^ outcome.c)
          ?=(?(%accept %refuse) kind.u.outcome.c)
      ==
    [%native-coding-review-action-v1 [%observe id]]
  [%native-local-review-observe-v1 id]
++  decode
  |=  [our=@p now=@da object=json]
  ^-  *
  ?>  ?=(%o -.object)
  =/  id=@ux  (hex object 'session')
  =/  e  (session our now id)
  =/  kind=@t  (need (string:cr object 'kind'))
  ?:  |(=('solo-review-start' kind) =('solo-review-observe' kind))
    =/  bound=?  &(=('solo-review-start' kind) ?=(^ (field:cr object 'scopeBinding')))
    ?>  =((silt ?:(bound ~['nonce' 'kind' 'session' 'candidate' 'scopeBinding'] ~['nonce' 'kind' 'session' 'candidate'])) ~(key by p.object))
    =/  candidate=@ux  (hex object 'candidate')
    =/  raw=*  .^(* %gx /(scot %p our)/cantrip/(scot %da now)/native-coding/candidate/(scot %ux candidate)/noun)
    =/  r  (need (need ((soft ,(unit record:accept)) raw)))
    ?>  &(=(candidate id.candidate.r) =(id session.context.candidate.r) =(project.session.e project.context.candidate.r))
    ?:  =('solo-review-start' kind)
      ?:  bound  [%native-local-review-start-bound-v1 candidate (hex object 'scopeBinding')]
      [%native-local-review-start-v1 candidate]
    =/  raw=*  .^(* %gx /(scot %p our)/viki/(scot %da now)/native-coding/local-review/candidate/(scot %ux candidate)/noun)
    =/  c=campaign-view  (need (need ((soft ,(unit campaign-view)) raw)))
    (observe-command candidate c)
  =/  enabled=?  =('solo-review-enable' kind)
  ?>  |(enabled =('solo-review-disable' kind))
  ?>  =((silt ?:(enabled ~['nonce' 'kind' 'session' 'project' 'previous' 'providerKey' 'binding' 'consent'] ~['nonce' 'kind' 'session' 'project' 'previous'])) ~(key by p.object))
  =/  name=@t  (need (string:cr object 'project'))
  ?>  =(name project.session.e)
  =/  text=@t  (need (string:cr object 'previous'))
  =/  expected=@ud  (need (slaw %ud text))
  ?>  &(=(text (scot %ud expected)) (lte (met 0 expected) 64))
  =/  previous=(unit scope)  (~(get by (scopes our now)) name)
  =/  key=@tas
    ?:  enabled  (need (string:cr object 'providerKey'))
    ?~  previous  !!
    provider-key.u.previous
  =/  chosen=selection:np
    ?:  enabled  (need (registered our now key))
    ?~  previous  !!
    selection.u.previous
  =/  binding=@ux  ?:(enabled (hex object 'binding') (digest chosen))
  =/  next
    (prepare-scope our name previous expected enabled key chosen binding ?:(enabled (boolean object 'consent') %.n))
  ?>  ?=(%& -.next)
  [%native-local-review-scope-v1 p.next]
++  scope-json
  |=  s=scope
  ^-  json
  (pairs:enjs:format ~[['project' s+project.s] ['generation' s+(scot %ud generation.s)] ['binding' s+(scot %ux (digest s))] ['enabled' b+enabled.s] ['providerKey' s+provider-key.s] ['provider' s+provider.selection.s] ['model' s+model.selection.s]])
++  campaign-json
  |=  [our=@p now=@da row=json]
  ^-  json
  =/  id=@ux  (hex row 'id')
  =/  raw=*  .^(* %gx /(scot %p our)/viki/(scot %da now)/native-coding/local-review/candidate/(scot %ux id)/noun)
  =/  parsed  ((soft ,(unit campaign-view)) raw)
  ?~  parsed  ~
  =/  found  u.parsed
  ?~  found  ~
  (campaign-data id u.found)
++  campaign-data
  |=  [id=@ux c=campaign-view]
  ^-  json
  =/  mode=@tas
    ?:  ?=(^ resolution.c)  %resolve
    ?:  &(?=(^ challenge.c) ?=(~ outcome.c))  %resolve
    %challenge
  (pairs:enjs:format ~[['candidate' s+(scot %ux id)] ['mode' s+mode] ['pending' ?~(pending.c ~ s+(scot %ux u.pending.c))] ['reason' s+?~(reason.c '' u.reason.c)] ['outcome' s+?~(outcome.c '' kind.u.outcome.c)] ['attempt' (numb:enjs:format attempt.c)]])
++  view
  |=  [our=@p now=@da id=@ux reviews=json]
  ^-  json
  ?.  (agent-live:guard our now %viki)  ~
  =/  held=(map @t scope)  (scopes our now)
  =/  e=(unit public-session:loop)
    ?:  =(0 id)  ~
    (mole |.((session our now id)))
  =/  current=(unit scope)
    ?~(e ~ (~(get by held) project.session.u.e))
  =/  choices=(map @tas selection:np)  (configured our now)
  =/  providers=(list json)
    %+  turn  (scag 64 ~(tap by choices))
    |=  [key=@tas chosen=selection:np]
    (pairs:enjs:format ~[['key' s+key] ['binding' s+(scot %ux (digest chosen))] ['provider' s+provider.chosen] ['model' s+model.chosen]])
  =/  campaigns=(list json)
    ?.  ?=(%a -.reviews)  ~
    %+  murn  (scag 8 p.reviews)
    |=  r=json
    =/  v=json  (campaign-json our now r)
    ?:(=(~ v) ~ `v)
  (pairs:enjs:format ~[['schema' s+'native-coding-solo-review-view-v1'] ['available' b+?=(^ e)] ['project' s+?~(e '' project.session.u.e)] ['scope' ?~(current ~ (scope-json u.current))] ['providers' a+providers] ['campaigns' a+campaigns]])
--
