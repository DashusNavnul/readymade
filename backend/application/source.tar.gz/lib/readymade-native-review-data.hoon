::  Shared receipt types and identity parser; no agent or execution imports.
/-  nc=native-coding
/+  h=readymade-history
|%
+$  check  [target=@tas name=@tas passed=? source=revision:nc detail=text:h]
+$  edit  [pax=path kind=@tas before=(unit @ux) after=(unit @ux)]
+$  detail
  $:  candidate=@ux  session=@ux  source=revision:nc  stage=@tas
      edits=(list edit)  edit-total=@ud  checks=(list check)  check-total=@ud
      checked=(unit revision:nc)  passed=(unit ?)  decision=(unit @tas)
      landed=(unit revision:nc)  reason=(unit @tas)
  ==
+$  snapshot
  [%readymade-native-review-v1 owner=@p candidate=@ux value=(unit detail) problem=(unit @tas)]
++  token
  |=  text=@t
  ^-  (unit @ux)
  ?.  (lte (met 3 text) 82)  ~
  ?~  id=(slaw %ux text)  ~
  ?.  &(!=(0 u.id) (lte (met 0 u.id) 256) =(text (scot %ux u.id)))  ~
  id
--
