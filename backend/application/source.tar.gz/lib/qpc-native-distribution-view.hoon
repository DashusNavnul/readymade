:: Managed pool presentation only. Native owners authenticate these inputs.
:: Reuse the declared energy/kernel; never draw, admit, dispatch or save DATA.
/+  owner=qpc-native-owner, binding=qpc-native-owner-binding,
    controller=qpc-native-controller, d=qpc-native-decision,
    core=qpc-decision, assessment=qpc-native-assessment,
    admission=qpc-native-admission, accept=native-coding-accept,
    law=qpc-law-core, legacy=qpc-distribution-view,
    select=qpc-select, pool=qpc-native-pool, ct=cantrip-native-coding-contract,
    gate=qpc-session-gate, guard=viki-scry-guard
|%
+$  snapshot
  $:  owners=state:binding  choices=state:controller
      assessments=(unit state:assessment)  laws=(unit state:law)
  ==
++  revision
  |=  r=revision:law
  ^-  revision:legacy
  [id.r gain.parameters.r footprint.parameters.r indirection.parameters.r ?=(^ at.r)]
++  same-kernel
  |=  [a=receipt:select b=receipt:select]
  ^-  ?
  ?&  =(attention.a attention.b)  =(gain.a gain.b)
      =(weights.a weights.b)  =(total.a total.b)  =(contrast.a contrast.b)
  ==
++  prepare
  :: Historical joins use retained source/authority, not today's project head.
  |=  [o=record:owner c=record:controller a=record:assessment laws=state:law]
  ^-  (each input:legacy @tas)
  ?~  collection.o  [%| %managed-pool-unsealed]
  =/  p=pool:pool  pool.u.collection.o
  =/  f=opening:d  frozen.decision.o
  ?.  &(=(o origin.c) =(%chosen phase.c))  [%| %managed-choice-unavailable]
  ?~  admission.c  [%| %managed-admission-unavailable]
  =/  receipt=receipt:admission  u.admission.c
  ?.  ?&  =(request.receipt marker.c)
          =(assessment.receipt (digest:assessment a))
          =(binding.a [f p position.u.collection.o declaration.o scope.o])
          =(id.a (digest:assessment binding.a))
          =(pool.decision.c `p)  =(f frozen.decision.c)
          =(sealed.decision.c `position.u.collection.o)
      ==  [%| %managed-assessment-binding-mismatch]
  =/  opened  (open:d f)
  ?:  ?=(%| -.opened)  [%| p.opened]
  ?.  =(reading.core.p.opened reading.core.decision.c)
    [%| %managed-frozen-reading-mismatch]
  =/  current-laws=(list revision:law)
    (fall (~(get by laws) instrument.binding.law.f) ~[law.f])
  ?.  &((history-valid:law owner.f instrument.binding.law.f current-laws) (lien current-laws |=(r=revision:law =(r law.f))))
    [%| %managed-law-history-unavailable]
  ?.  (levy current-laws |=(r=revision:law &(=(footprint.parameters.r footprint.parameters.law.f) =(indirection.parameters.r indirection.parameters.law.f))))
    [%| %managed-scoring-profile-changed]
  =/  scored=(list scored:d)  candidates.decision.c
  =/  proposals=(list proposal:core)  proposals.core.decision.c
  ?.  ?&  =((lent scored) (lent proposals))
          =((lent scored) (lent offered.receipt))
          (gte (lent scored) 1)  (lte (lent scored) 4)
      ==
    [%| %managed-offer-count-mismatch]
  =/  rows=(list row:legacy)  ~
  =/  todo=(list scored:d)  scored
  |-  ^-  (each input:legacy @tas)
  ?~  todo
    =/  in=input:legacy
      [id.p session.p (flop rows) [%& attention.reading.core.decision.c] (turn current-laws revision)]
    =/  original  (distribution:legacy in (revision law.f))
    ?:  ?=(%| -.original)  [%| p.original]
    ?~  selection.core.decision.c  [%| %managed-selection-unavailable]
    ?.  (same-kernel p.original u.selection.core.decision.c)
      [%| %managed-kernel-receipt-mismatch]
    [%& in]
  =/  s=scored:d  i.todo
  =/  offer=offered:d  evidence.s
  =/  id=@ux  candidate.admission.offer
  =/  pool-rows=(list row:pool)
    (skim rows.p |=(v=row:pool =(candidate.v `id)))
  ?~  pool-rows  [%| %managed-hard-refusal-excluded]
  ?^  t.pool-rows  [%| %managed-pool-row-ambiguous]
  =/  found  (~(get by rows.a) id)
  ?~  found  [%| %managed-assessment-row-missing]
  =/  row=row:assessment  u.found
  ?.  ?&  =(id id.candidate.row)  =(tool.row tool.offer)
          =(effect.i.pool-rows `(effect:d candidate.row))
          =(tool.i.pool-rows (key:ct request.tool.offer))
          (lien offered.receipt |=(v=offered:d =(v offer)))
          ?=(?(%checked %refused %unknown) phase.row)
          (admission-valid:d decision.c admission.offer id (effect:d candidate.row))
      ==  [%| %managed-assessment-row-mismatch]
  =/  eligible=?  (passed:d admission.offer)
  ?:  &(eligible |(!=(%checked phase.row) ?=(~ report.row)))
    [%| %managed-assessment-unconfirmed]
  =/  report-passed=?  ?~(report.row %.n (passed:accept u.report.row))
  ?:  &(eligible !report-passed)
    [%| %managed-assessment-not-passed]
  ?:  &(=(%checked phase.row) ?=(~ report.row))
    [%| %managed-assessment-unconfirmed]
  ?.  ?~  report.row  %.y
      ?&  =(id candidate.u.report.row)
          (levy targets.u.report.row |=(t=target-result:accept ?=(^ diagnostics.t)))
          ?=(^ targets.u.report.row)
      ==
    [%| %managed-assessment-report-mismatch]
  =/  matches=(list proposal:core)
    (skim proposals |=(v=proposal:core =(id id.v)))
  ?~  matches  [%| %managed-proposal-missing]
  ?^  t.matches  [%| %managed-proposal-ambiguous]
  =/  proposal=proposal:core  i.matches
  ?.  ?&  =(eligible eligible.proposal)  =(evidence.proposal (digest:d offer))
          =(energy.proposal value.energy.s)
          =(effect.proposal (jam [%effect-v1 revision.basis.candidate.row accepted.candidate.row edits.candidate.row]))
      ==  [%| %managed-proposal-mismatch]
  :: The native kernel hashes proposal.effect, not the pool commitment namespace.
  =/  next=row:legacy
    [call-id.request.tool.offer ?:(eligible `id ~) `(shax effect.proposal) `arguments.request.tool.offer]
  $(todo t.todo, rows [next rows])
++  field
  |=  [j=json key=@t]
  ^-  (unit json)
  ?.  ?=(%o -.j)  ~
  (~(get by p.j) key)
++  pool-json
  |=  in=input:legacy
  ^-  json
  =/  rendered=json  (render:legacy ~[in])
  =/  rows=json  (need (field rendered 'pools'))
  ?>  ?=(%a -.rows)
  (snag 0 `(list json)`p.rows)
++  project
  :: Replace matching managed rows even when paused. Unrelated legacy rows stay exact.
  |=  [old=json s=(unit snapshot)]
  ^-  json
  ?~  s  old
  =/  prior  (field old 'pools')
  ?~  prior  old
  ?.  ?=(%a -.u.prior)  old
  =/  originals=(list record:owner)
    (skim ~(val by records.journal.owners.u.s) |=(o=record:owner ?=(^ collection.o)))
  ?~  originals  old
  =/  ids=(set @t)
    (silt (turn originals |=(o=record:owner (scot %ux id.pool:(need collection.o)))))
  :: The explicit traversal avoids treating a malformed old row as a managed identity.
  =/  kept=(list json)
    %+  skim  p.u.prior
    |=  j=json
    =/  id  (field j 'pool')
    ?~  id  %.y
    ?.  ?=(%s -.u.id)  %.y
    !(~(has in ids) p.u.id)
  =/  managed=(list json)
    %+  turn  originals
    |=  o=record:owner
    =/  p=pool:pool  pool:(need collection.o)
    =/  choice  (~(get by records.choices.u.s) session.p)
    =/  got=(each input:legacy @tas)
      ?~  choice  [%| %managed-choice-unavailable]
      ?~  assessments.u.s  [%| %managed-assessment-unavailable]
      ?~  laws.u.s  [%| %managed-law-history-unavailable]
      =/  a  (~(get by records.u.assessments.u.s) session.p)
      ?~  a  [%| %managed-assessment-unavailable]
      (prepare o u.choice u.a u.laws.u.s)
    =/  in=input:legacy
      ?:  ?=(%& -.got)  p.got
      [id.p session.p ~ [%| p.got] ~[(revision law.frozen.decision.o)]]
    (pool-json in)
  ?>  ?=(%o -.old)
  =/  fields=(map @t json)  (~(put by p.old) 'pools' [%a (weld kept managed)])
  [%o (~(put by fields) 'limits' [%s 'Managed rows use the retained decision A and exact native assessment/admission joins; compatible retained laws recompute weights only. Legacy rows retain their original contract. No new draw or execution.'])]
++  read
  |=  [inner=agent:gall b=bowl:gall owners=state:binding choices=state:controller]
  ^-  snapshot
  ?.  (lien ~(val by records.journal.owners) |=(o=record:owner ?=(^ collection.o)))
    [owners choices ~ ~]
  =/  laws=(unit state:law)
    %-  mole
    |.
    =/  raw=*  (need (payload:gate (on-peek:~(. inner b(src our.b)) /x/qpc/laws)))
    =/  parsed=state:law  (need ((soft state:law) raw))
    ?>  =(raw parsed)
    parsed
  =/  assessments=(unit state:assessment)
    %-  mole
    |.
    ?>  &(=(our.b src.b) (agent-live:guard our.b now.b %cantrip))
    =/  raw=*  .^(* %gx /(scot %p our.b)/cantrip/(scot %da now.b)/qpc/assessments/noun)
    =/  parsed=state:assessment  (need ((soft state:assessment) raw))
    ?>  =(raw parsed)
    parsed
  [owners choices assessments laws]
--
