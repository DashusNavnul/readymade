::  Owner-admitted executable/source association, not proof of compilation.
::  Neither successful wire decoding nor owner admission certifies source.
/+  compiler=native-coding-compiler, exports=native-coding-compiler-exports,
    decoder=native-coding-compiler-artifact, checked=native-coding-compiler-checked,
    vm=native-coding-terminal-plan, scalar=terminal-plan,
    modules=native-coding-module-sources
|%
+$  role  ?(%checked-exports %compiler-exports)
+$  attachment
  [%native-coding-compiler-attachment-v1 role=role sources=(list witness:compiler) source-digest=@ux entry-name=@t entry=plan:vm entry-digest=@ux digest=@ux]
+$  output
  [bindings=(list binding:decoder) remaining=@ud type-work=(unit @ud)]
+$  result  (each output refusal:checked)
++  profile-id
  ::  Distinct execution contract, never the old bootstrap acceleration ID.
  ::  No law substitution. Limits/version changes require a new contract.
  ^-  @ux
  (shax (jam [%native-coding-compiler-attachment-execution-v1 compiler-mode:vm 262.144 32 4.096]))
++  profile-id-v2
  ^-  @ux
  (shax (jam [%native-coding-compiler-attachment-execution-v2 compiler-mode-v2:vm 262.144 32 4.096]))
++  fuel-v2  compiler-fuel-v2:vm
++  profile-valid
  |=  profile=@ux
  ^-  ?
  |(=(profile profile-id) =(profile profile-id-v2))
++  source-id
  |=  sources=(list witness:compiler)
  ^-  @ux
  (shax (jam [%native-coding-compiler-attachment-sources-v1 sources]))
++  identity
  |=  a=attachment
  ^-  @ux
  (shax (jam a(digest 0x0)))
++  entry-valid
  |=  p=plan:vm
  ^-  ?
  ?.  &((artifact-valid:scalar p) =(`3 (arity:scalar p)))  %.n
  =/  todo=(list plan:vm)  ~[p]
  =/  seen=(set plan:vm)  ~
  =/  left=@ud  262.144
  |-  ^-  ?
  ?~  todo  %.y
  ?:  =(0 left)  %.n
  =/  p=plan:vm  i.todo
  =/  rest=(list plan:vm)  t.todo
  ?:  (~(has in seen) p)  $(todo rest, left (dec left))
  =.  seen  (~(put in seen) p)
  =.  left  (dec left)
  ?-  -.p
    %nat  $(todo rest)
    %app  $(todo [fun.p arg.p rest])
    %law  $(todo [name.p body.p rest])
    %pin
      ?.  ?:(?=(%nat -.item.p) |((lte value.item.p 4) ?=(?(%10 %11 %12) value.item.p)) %.y)  %.n
      $(todo [item.p rest])
    %delay  %.n
  ==
++  valid
  |=  a=attachment
  ^-  ?
  ?.  &((gte (lent sources.a) 1) (lte (lent sources.a) 32))  %.n
  =/  names=(list @t)  (turn sources.a |=(w=witness:compiler module.w))
  ?&  =((lent names) ~(wyt in (silt names)))
      (levy names name-valid:decoder)
      (~(has in (silt names)) 'Runtime.NativeCodingCompiler')
      (levy sources.a |=(w=witness:compiler &((gte (met 3 bytes.w) 1) (lte (met 3 bytes.w) 524.288) =(digest.w (rev 3 32 (shax bytes.w))))))
      (lte (roll sources.a |=([w=witness:compiler n=@ud] (add n (met 3 bytes.w)))) 1.048.576)
      =(source-digest.a (source-id sources.a))
      =(entry-name.a ?:(=(%checked-exports role.a) 'Runtime.NativeCodingCompiler.compile_checked_exports' 'Runtime.NativeCodingCompiler.compile_compiler_exports'))
      =(entry-digest.a (shax (jam entry.a)))
      =(digest.a (identity a))
      (lte (met 3 (jam a)) 4.194.304)
      (entry-valid entry.a)
  ==
++  inputs
  |=  [a=attachment j=job:compiler s=selection:exports]
  ^-  (each (list mapped:modules) @tas)
  ?.  (valid a)  [%| %compiler-attachment-invalid]
  =/  prepared  (inputs:exports j s)
  ?:  ?=(%| -.prepared)  prepared
  ?:  =(%compiler-exports role.a)  prepared
  =/  srcs=(list source:compiler)  (job-sources:compiler j)
  ?.  ?&  (lte (lent srcs) 8)
          (levy srcs |=(v=source:compiler (lte (met 3 text.v) 32.768)))
          (lte (roll srcs |=([v=source:compiler n=@ud] (add n (met 3 text.v)))) 131.072)
      ==
    [%| %compiler-checked-input-bound]
  prepared
++  output-valid
  |=  [role=role names=(list @t) fuel=@ud out=result]
  ^-  ?
  (output-for profile-id role names fuel out)
++  output-for
  |=  [profile=@ux role=role names=(list @t) fuel=@ud out=result]
  ^-  ?
  ?.  (profile-valid profile)  %.n
  ?.  &((gte fuel 1) (lte fuel ?:(=(profile profile-id-v2) fuel-v2 2.000.000)) (lte (met 3 (jam out)) 2.097.152))  %.n
  ?:  ?=(%| -.out)
    =/  r=refusal:checked  p.out
    ?&  !=(0 reason.r)  (lte (met 3 reason.r) 128)
        (lte code.r 65.535)  (lte (met 3 module.r) 128)
        (lte (met 3 symbol.r) 128)
        ?~(stage.r %.y &(=(%checked-exports role) (lte u.stage.r 2) (gte code.r 1)))
    ==
  =/  o=output  p.out
  ?&  =(names (turn bindings.o |=(b=binding:decoder name.b)))
      (gte (lent names) 1)  (lte (lent names) 8)
      =((lent names) ~(wyt in (silt names)))
      (levy names name-valid:decoder)
      (lte remaining.o fuel)
      ?:(=(%checked-exports role) ?~(type-work.o %.n (lte u.type-work.o type-work-cap:checked)) ?=(~ type-work.o))
      (supported:exports bindings.o)
      (levy bindings.o |=(b=binding:decoder (artifact-valid:scalar artifact.b)))
  ==
++  attempt
  |=  [a=attachment j=job:compiler s=selection:exports fuel=@ud]
  ^-  result
  (attempt-with a j s fuel %.n)
++  attempt-with
  |=  [a=attachment j=job:compiler s=selection:exports fuel=@ud modern=?]
  ^-  result
  =/  prepared  (inputs a j s)
  ?:  ?=(%| -.prepared)  [%| p.prepared ~ 0 '' '']
  =/  ran
    =/  args=(list plan:vm)
      ~[(encode:compiler (job-module:compiler j)) (wanted:exports names.s) (encode-sources:compiler p.prepared)]
    ?:  modern  (run-compiler-v2:vm fuel entry-digest.a entry.a args)
    (run-compiler:vm fuel entry-digest.a entry.a args)
  ?:  ?=(%| -.ran)  [%| p.ran ~ 0 '' '']
  =/  out=result
    ?:  =(%checked-exports role.a)
      =/  decoded  (decode:checked output.p.ran names.s)
      ?:  ?=(%| -.decoded)  [%| p.decoded]
      [%& bindings.p.decoded remaining.p.ran `remaining-typework.p.decoded]
    =/  decoded  (decode:decoder output.p.ran names.s)
    ?:  ?=(%| -.decoded)
      [%| reason.p.decoded ~ code.p.decoded module.p.decoded symbol.p.decoded]
    [%& p.decoded remaining.p.ran ~]
  ?.  (output-for ?:(modern profile-id-v2 profile-id) role.a names.s fuel out)
    [%| %compiler-attachment-output-invalid ~ 0 '' '']
  out
++  invoke
  |=  [a=attachment j=job:compiler s=selection:exports fuel=@ud]
  ^-  result
  =/  tried  (mole |.((attempt a j s fuel)))
  ?~  tried  [%| %compiler-attachment-unconfirmed ~ 0 '' '']
  u.tried
++  invoke-v2
  |=  [a=attachment j=job:compiler s=selection:exports fuel=@ud]
  ^-  result
  =/  tried  (mole |.((attempt-with a j s fuel %.y)))
  ?~  tried  [%| %compiler-attachment-unconfirmed ~ 0 '' '']
  u.tried
--
