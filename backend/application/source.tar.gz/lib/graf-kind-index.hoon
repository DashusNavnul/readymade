::  Exact derived family index. Facts and set order remain canonical.
/+  gs=graf-substrate, gew=graf-evidence-window
|%
+$  bucket  [total=@ud facts=store:gs]
+$  index  (map @tas bucket)
+$  entry  [seal=@ux fact=*]
+$  stream  [total=@ud entries=(map @ud entry)]
+$  cache  [floor=store:gs kinds=index generation=@ux streams=(map @tas stream)]
+$  cursor  [generation=@ux total=@ud seal=@ux]
+$  item  [sequence=@ud order=@ud fact=*]
+$  result
  $%  [%graf-kind-reset %1 kind=@tas cursor]
      [%graf-kind-delta %1 kind=@tas generation=@ux after=@ud through=@ud limit=@ud next=@ud seal=@ux items=(list item)]
  ==
++  cursor-kinds
  ^-  (list @tas)
  :~  %bench-turn  %bench-turn-touched  %bench-ruling  %bench-landed
      %cantrip-receipt  %bench-lesson  %flect-word  %forbid-word
      %cantrip-contention  %render-refusal
  ==
++  supported
  |=  kind=@tas
  ^-  ?
  (lien cursor-kinds |=(known=@tas =(kind known)))
++  family
  |=  fact=*
  ^-  (unit @tas)
  ::  The existing query pattern is exactly [kind any any].
  ?@  fact  ~
  ?^  -.fact  ~
  ?@  +.fact  ~
  `-.fact
++  put
  |=  [ix=index fact=*]
  ^-  index
  ?~  kind=(family fact)  ix
  =/  prior=bucket  (~(gut by ix) u.kind [0 ~])
  ?:  (~(has in facts.prior) fact)  ix
  (~(put by ix) u.kind [+(total.prior) (~(put in facts.prior) fact)])
++  seed
  |=  floor=store:gs
  ^-  cache
  ::  Protocol generation, not a clock or floor hash. Prefix SHA-256 certificates
  ::  identify the actual mapping, including equal-floor divergent append orders.
  ::  Deterministic reconstruction; no cursor state enters the agent save.
  =/  ix=index  (roll ~(tap in floor) |=([fact=* ix=index] (put ix fact)))
  =/  held=cache  [floor ix 0x1 ~]
  =/  add-kind
    |=  [kind=@tas acc=cache]
    =/  append  |=([fact=* acc=cache] (record acc kind fact))
    (roll ~(tap in (rows kinds.acc kind)) append(acc acc))
  (roll cursor-kinds add-kind(acc held))
++  start-seal
  |=  [generation=@ux kind=@tas]
  ^-  @ux
  (shax (jam [%graf-kind-prefix %1 generation kind]))
++  seal-at
  |=  [held=cache kind=@tas sequence=@ud]
  ^-  @ux
  ?:  =(0 sequence)  0x0
  =/  trail=stream  (~(gut by streams.held) kind [0 ~])
  seal:(~(got by entries.trail) sequence)
++  grow
  |=  [held=cache fact=*]
  ^-  cache
  ?~  kind=(family fact)  held
  ?.  (supported u.kind)  held(kinds (put kinds.held fact))
  ?:  (~(has in (rows kinds.held u.kind)) fact)  held
  =.  kinds.held  (put kinds.held fact)
  (record held u.kind fact)
++  record
  ::  Called once per new supported fact, or while rebuilding its family.
  |=  [held=cache kind=@tas fact=*]
  ^-  cache
  =/  trail=stream  (~(gut by streams.held) kind [0 ~])
  =/  sequence=@ud  +(total.trail)
  =/  prior=@ux
    ?:(=(0 total.trail) (start-seal generation.held kind) (seal-at held kind total.trail))
  =/  seal=@ux
    (shax (jam [prior sequence fact]))
  ::  One certificate and a reference to the existing noun per current fact.
  held(streams (~(put by streams.held) kind [sequence (~(put by entries.trail) sequence [seal fact])]))
++  difference
  |=  [after=store:gs before=store:gs]
  ^-  store:gs
  ::  Unlike +dif:in, skip unchanged persistent subtrees before splitting.
  ?:  =(after before)  ~
  ?~  after  ~
  ?~  before  after
  =/  halves=[left=store:gs right=store:gs]
    (~(bif in `store:gs`after) n.before)
  =/  left=store:gs  (difference left.halves l.before)
  =/  right=store:gs  (difference right.halves r.before)
  (~(uni in left) right)
++  sync
  |=  [held=cache next=store:gs]
  ^-  cache
  ?:  =(floor.held next)  held
  =/  removed=store:gs  (difference floor.held next)
  ::  Discard every old sequence on removal; no historical log accumulates.
  ?^  removed  (seed next)
  =/  added=store:gs  (difference next floor.held)
  =/  append  |=([fact=* acc=cache] (grow acc fact))
  =.  held  (roll ~(tap in added) append(acc held))
  held(floor next)
++  head
  |=  [held=cache kind=@tas]
  ^-  cursor
  =/  trail=stream  (~(gut by streams.held) kind [0 ~])
  [generation.held total.trail (seal-at held kind total.trail)]
++  delta
  |=  [held=cache kind=@tas generation=@ux after=@ud prior=@ux through=@ud upper=@ux limit=@ud]
  ^-  (unit result)
  ?.  (supported kind)  ~
  ?.  (valid-limit:gew limit)  ~
  ?:  (gth after through)  ~
  =/  current=cursor  (head held kind)
  ?:  ?|(!=(generation generation.current) (gth through total.current))
    `[%graf-kind-reset %1 kind current]
  ::  Seed identity alone is insufficient: F+A+B and F+B+A share a seed.
  ::  Both boundaries certify the exact consumed and captured sequences.
  ?.  &(=(prior (seal-at held kind after)) =(upper (seal-at held kind through)))
    `[%graf-kind-reset %1 kind current]
  =/  trail=stream  (~(gut by streams.held) kind [0 ~])
  =/  next=@ud  (min through (add after limit))
  =|  items=(list item)
  =/  sequence=@ud  after
  |-  ^-  (unit result)
  ?:  =(sequence next)
    `[%graf-kind-delta %1 kind generation after through limit next (seal-at held kind next) (flop items)]
  =/  row=entry  (~(got by entries.trail) +(sequence))
  $(sequence +(sequence), items [[+(sequence) (mug fact.row) fact.row] items])
++  cursor-peek
  |=  [held=cache pax=path]
  ^-  (unit (unit cage))
  ?+  pax  ~
    [%x %kind-cursor @ ~]
      ?.  (supported i.t.t.pax)  [~ ~]
      ``noun+!>([%graf-kind-cursor %1 i.t.t.pax (head held i.t.t.pax)])
    [%x %kind-cursors @ ~]
      ::  One native snapshot captures every requested family's upper bound.
      =/  requested=(list @tas)  (kinds i.t.t.pax)
      ?.  (levy requested supported)  [~ ~]
      =/  found=(list [kind=@tas cursor])
        (turn requested |=(kind=@tas [kind (head held kind)]))
      ``noun+!>([%graf-kind-cursors %1 found])
    [%x %kind-delta @ @ @ @ @ @ @ ~]
      =/  args=(list @ta)  t.t.pax
      =/  generation=(unit @ux)  (slaw %ux (snag 1 args))
      =/  after=(unit @ud)  (slaw %ud (snag 2 args))
      =/  prior=(unit @ux)  (slaw %ux (snag 3 args))
      =/  through=(unit @ud)  (slaw %ud (snag 4 args))
      =/  upper=(unit @ux)  (slaw %ux (snag 5 args))
      =/  limit=(unit @ud)  (slaw %ud (snag 6 args))
      ?~  generation  [~ ~]
      ?~  after  [~ ~]
      ?~  prior  [~ ~]
      ?~  through  [~ ~]
      ?~  upper  [~ ~]
      ?~  limit  [~ ~]
      =/  got=(unit result)
        (delta held (snag 0 args) u.generation u.after u.prior u.through u.upper u.limit)
      ?~  got  [~ ~]
      ``noun+!>(u.got)
  ==
++  rows
  |=  [ix=index kind=@tas]
  ^-  store:gs
  =/  found=bucket  (~(gut by ix) kind [0 ~])
  facts.found
++  kinds
  |=  text=@ta
  ^-  (list @tas)
  =/  chars=tape  (weld (trip text) ",")
  =|  piece=tape
  =|  out=(list @tas)
  |-  ^-  (list @tas)
  ?~  chars  (flop out)
  ?.  ?|(=('_' i.chars) =(',' i.chars))
    $(chars t.chars, piece [i.chars piece])
  ?~  piece  $(chars t.chars)
  =/  kind=(unit @tas)  (slaw %tas (crip (flop piece)))
  ?~  kind  $(chars t.chars, piece ~)
  $(chars t.chars, piece ~, out [u.kind out])
++  peek
  |=  [ix=index pax=path]
  ^-  (unit (unit cage))
  ?+  pax  ~
    [%x %count @ ~]
      =/  found=bucket  (~(gut by ix) i.t.t.pax [0 ~])
      ``noun+!>(total.found)
    [%x %by-kind @ ~]
      ``noun+!>(~(tap in (rows ix i.t.t.pax)))
    [%x %by-kinds @ ~]
      =/  found=(list [kind=@tas facts=(list *)])
        (turn (kinds i.t.t.pax) |=(kind=@tas [kind ~(tap in (rows ix kind))]))
      ``noun+!>(found)
    [%x %by-kind-page @ @ @ ~]
      =/  offset=(unit @ud)  (slaw %ud i.t.t.t.pax)
      ?~  offset  [~ ~]
      =/  limit=(unit @ud)  (slaw %ud i.t.t.t.t.pax)
      ?~  limit  [~ ~]
      ?.  (valid-limit:gew u.limit)  [~ ~]
      ``noun+!>((page:gew (rows ix i.t.t.pax) i.t.t.pax u.offset u.limit))
  ==
--
