::  Transient owner-local Graf witnesses, never saved collaboration authority.
::  Native wrapper supplies authenticated actor and facts read from local Graf.
::  A cached witness is NOT proof of membership: re-read exact native contains
::  before any offer effect. Never send/cache-project the private fact body.
|%
+$  memory
  $:  %operator-memory
      %1
      name=@t
      description=@t
      kind=@t
      body=@t
      source=@t
      at=@da
  ==
+$  metadata
  $:  root=@ux
      family=@tas
      name=@t
      description=@t
      kind=@t
      source=@t
      at=@da
      provenance=@t
  ==
+$  cache  [owner=@p facts=(map @ux *)]
+$  refusal  ?(%foreign %missing %invalid %unsupported %full %conflict)
+$  change  [cache=cache result=?(%stored %duplicate refusal)]
+$  witness  [root=@ux fact=*]
++  empty
  |=  owner=@p
  ^-  cache
  [owner ~]
++  root
  |=  fact=*
  ^-  @ux
  (shax (jam fact))
++  bounded
  |=  fact=*
  ^-  ?
  (lte (met 3 (jam fact)) 65.536)
++  cache-bounded
  |=  held=cache
  ^-  ?
  &((lte ~(wyt by facts.held) 64) (levy ~(val by facts.held) bounded))
++  describe
  ::  Exact known schema only. Body is deliberately absent from metadata.
  ::  Names and descriptions are claims from the record, not project binding.
  |=  fact=*
  ^-  (each metadata refusal)
  ?.  (bounded fact)  [%| %invalid]
  =/  parsed=(unit memory)  ((soft memory) fact)
  ?~  parsed  [%| %unsupported]
  =/  m=memory  u.parsed
  ?.  ?&  (gth (met 3 name.m) 0)
          (lte (met 3 name.m) 256)
          (lte (met 3 description.m) 512)
          (lte (met 3 kind.m) 128)
          (lte (met 3 source.m) 256)
      ==
    [%| %invalid]
  [%& [(root fact) %operator-memory name.m description.m kind.m source.m at.m 'Operator-memory record candidate; Graf membership unverified here; body not shared; project association unverified.']]
++  add
  ::  No eviction, no automatic choice, no membership claim. Duplicate is
  ::  idempotent even at capacity; conflict preserves the complete old cache.
  |=  [our=@p actor=@p held=cache fact=*]
  ^-  change
  ?.  &(=(our actor) =(our owner.held))  [held %foreign]
  ?:  =(%.n (cache-bounded held))  [held %invalid]
  =/  meta=(each metadata refusal)  (describe fact)
  ?:  ?=(%| -.meta)  [held p.meta]
  =/  id=@ux  root.p.meta
  =/  prior=(unit *)  (~(get by facts.held) id)
  ?^  prior
    [held ?:(=(fact u.prior) %duplicate %conflict)]
  ?:  =(64 ~(wyt by facts.held))  [held %full]
  [held(facts (~(put by facts.held) id fact)) %stored]
++  rows
  ::  Presentation receives only this bounded metadata projection. It must
  ::  preserve the provenance text and must not describe set order as recency.
  |=  [our=@p actor=@p held=cache]
  ^-  (each (list metadata) refusal)
  ?.  &(=(our actor) =(our owner.held))  [%| %foreign]
  ?:  =(%.n (cache-bounded held))  [%| %invalid]
  =/  todo=(list [p=@ux q=*])  ~(tap by facts.held)
  =|  out=(list metadata)
  |-  ^-  (each (list metadata) refusal)
  ?~  todo  [%& (flop out)]
  =/  parsed=(each metadata refusal)  (describe q.i.todo)
  ?:  ?=(%| -.parsed)  [%| p.parsed]
  ?.  =(p.i.todo root.p.parsed)  [%| %conflict]
  $(todo t.todo, out [p.parsed out])
++  select
  ::  Explicit digest only; empty/restarted caches cannot resolve selections.
  ::  Caller must keep witness.fact native and verify fresh Graf membership.
  |=  [our=@p actor=@p held=cache id=@ux]
  ^-  (each witness refusal)
  ?.  &(=(our actor) =(our owner.held))  [%| %foreign]
  ?:  =(%.n (cache-bounded held))  [%| %invalid]
  =/  found=(unit *)  (~(get by facts.held) id)
  ?~  found  [%| %missing]
  =/  meta=(each metadata refusal)  (describe u.found)
  ?:  ?=(%| -.meta)  [%| p.meta]
  ?.  =(id root.p.meta)  [%| %conflict]
  [%& [id u.found]]
--
