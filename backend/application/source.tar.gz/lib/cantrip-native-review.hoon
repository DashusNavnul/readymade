::  Separate admission for explicitly delegated AI reviewers. Never changes
::  the human-confirmation law, invents a human author, or executes a model.
/-  protocol=native-coding-review, jm=juggler-match, bx=boxy
/+  review=native-coding-review-request, accept=native-coding-accept,
    worker=native-coding-review-worker, tools=cantrip-native-coding,
    match=boxy-match, boxy=boxy-law, juggler=juggler-match,
    guard=viki-scry-guard, cr=codex-responses
|%
+$  key  [campaign=@ux request=@ux]
+$  retained
  $:  context=admission-context:protocol
      verdict=verdict:protocol
      queued=@ux
      grant=scope:tools
  ==
+$  ledger  (map key retained)
+$  change  [next=ledger cards=(list card:agent:gall)]
++  path-for
  |=  k=key
  ^-  path
  /native-coding/review-admission/(scot %ux campaign.k)/(scot %ux request.k)
++  publish
  |=  v=verdict:protocol
  ^-  card:agent:gall
  [%give %fact ~[(path-for [campaign.v request.v])] %noun !>(`(unit verdict:protocol)`[~ v])]
++  contribution-valid
  |=  [c=config:review r=request:review e=event:worker]
  ^-  ?
  ?~  contribution.e  %.n
  =/  v=contribution:jm  u.contribution.e
  ?.  ?&  =(proposal-id.v (cat 3 'ai-review:' (scot %ux id.r)))
          =(author.v [%model-proposed model.selection.c])
          =(target.v target.r)  ?=(~ relations.v)
          =(parent.v ?~(target.r [%match ~] [%move u.target.r]))
          =(artifact.v ?:(=(%close kind.v) `(bound:review r) ~))
          ?-  mode.r
            %propose    =(%propose kind.v)
            %challenge  ?=(?(%challenge %refuse) kind.v)
            %vote       ?=(?(%accept %refuse) kind.v)
            %close      ?=(?(%close %refuse) kind.v)
          ==
      ==  %.n
  ?:  =(%propose kind.v)  =(body.v (bound:review r))
  ?.  (lte (met 3 body.v) 8.192)  %.n
  =/  parsed  (de:json:html body.v)
  ?~  parsed  %.n
  ?.  ?=(%o -.u.parsed)  %.n
  =/  reason  (string:cr u.parsed 'reason')
  ?~  reason  %.n
  ?&  =((silt ~['artifact' 'reason' 'request' 'receipt']) ~(key by p.u.parsed))
      =(`(bound:review r) (string:cr u.parsed 'artifact'))
      =(`(scot %ux id.r) (string:cr u.parsed 'request'))
      =(`(scot %ux receipt.e) (string:cr u.parsed 'receipt'))
      !=(0 u.reason)  (lte (met 3 u.reason) 4.096)
  ==
++  refusal
  |=  [our=@p ctx=admission-context:protocol held=record:accept w=workspace-state:bx]
  ^-  (unit @tas)
  =/  s=scope:protocol  scope.ctx
  =/  c=config:review  ?:(=(worker.ctx ship.left.s) config.left.s config.right.s)
  (refusal-checked our ctx held w (valid:review worker.ctx c request.ctx))
++  refusal-checked
  ::  Only the inspected adapter may substitute its separately validated input.
  |=  [our=@p ctx=admission-context:protocol held=record:accept w=workspace-state:bx request-valid=?]
  ^-  (unit @tas)
  =/  s=scope:protocol  scope.ctx
  =/  r=request:review  request.ctx
  =/  e=event:worker  result.ctx
  ?.  ?&  enabled.s  !=(0 campaign.ctx)
          =(project.s id.spec.project.r)
          !=(ship.left.s ship.right.s)
          =(our parent.config.left.s)  =(our parent.config.right.s)
          (config-valid:review ship.left.s config.left.s)
          (config-valid:review ship.right.s config.right.s)
          |(=(worker.ctx ship.left.s) =(worker.ctx ship.right.s))
      ==  `%review-scope-invalid
  =/  c=config:review  ?:(=(worker.ctx ship.left.s) config.left.s config.right.s)
  ?.  ?&  =(project.r project.held)  =(candidate.r candidate.held)
          =(`report.r report.held)  =(%review stage.held)
          request-valid
          =(id.r id.e)  =((digest:review r) request.e)
          =((digest:review c) binding.e)  =(generation.c generation.e)
          =(%submitted phase.e)  !=(0 receipt.e)
          (lte (met 0 receipt.e) 256)
          (contribution-valid c r e)
      ==  `%review-evidence-invalid
  ?>  ?=(^ contribution.e)
  =/  previous  (project-workspace:match workspace.r)
  ?>  ?=(^ config.match.previous)
  =/  cfg=match-config:jm  u.config.match.previous
  ?.  ?&  =(ship.left.s ship.left.cfg)  =(ship.right.s ship.right.cfg)
          =((label:review ship.left.s model.selection.config.left.s) human.left.cfg)
          =((label:review ship.right.s model.selection.config.right.s) human.right.cfg)
          (event-chain-valid:boxy w)  =(event-seq.w (lent events.w))
          =(id.w id.workspace.r)  =(event-seq.w +(event-seq.workspace.r))
          ?=(^ events.w)
      ==  `%review-queue-invalid
  ?>  ?=(^ events.w)
  =/  queued=event:bx  i.events.w
  ?.  ?&  =(events.workspace.r t.events.w)  =(actor.queued worker.ctx)
          =(action.queued [%command (envelope:review r u.contribution.e)])
          =(members.w members.workspace.r)
          =(membership-epoch.w membership-epoch.workspace.r)
          =(law-digest.w law-digest.workspace.r)
      ==  `%review-queue-mismatch
  =/  current  (project-workspace:match w)
  ?.  ?&  =(0 refused.current)  =(%open status.match.current)
          =(config.match.current config.match.previous)
          =(moves.match.current moves.match.previous)
          =(pending.match.current ~[[worker.ctx (label:review worker.ctx model.selection.c) u.contribution.e]])
          ?=(~ (contribution-error:juggler match.previous u.contribution.e))
      ==  `%review-projection-mismatch
  ~
++  act
  |=  [b=bowl:gall s=ledger candidates=ledger:accept grants=(map @ux scope:tools) command=command:protocol]
  ^-  change
  (act-checked b s candidates grants command ~)
++  act-checked
  ::  Some binds a context already validated by the inspected-review adapter.
  ::  The public legacy entry above always supplies None and retains v1 law.
  |=  [b=bowl:gall s=ledger candidates=ledger:accept grants=(map @ux scope:tools) command=command:protocol inspected=(unit @ux)]
  ^-  change
  ?>  =(our.b src.b)
  =/  k=key  [campaign.command request.command]
  =/  old  (~(get by s) k)
  ?^  old  [s ~[(publish verdict.u.old)]]
  ?>  (lth ~(wyt by s) 256)
  ?>  (agent-live:guard our.b now.b %viki)
  =/  ctx=(unit admission-context:protocol)
    .^((unit admission-context:protocol) %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/review-admission/(scot %ux campaign.k)/(scot %ux request.k)/noun)
  ?>  ?=(^ ctx)
  ?>  &(=(campaign.k campaign.u.ctx) =(request.k id.request.u.ctx))
  ?>  (agent-live:guard our.b now.b %viki)
  =/  scopes=(map @t scope:protocol)
    .^((map @t scope:protocol) %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/review-scopes/noun)
  =/  current-scope  (~(get by scopes) project.scope.u.ctx)
  ?>  &(=(current-scope `scope.u.ctx) enabled.scope.u.ctx)
  =/  held  (~(get by candidates) id.candidate.request.u.ctx)
  ?>  ?=(^ held)
  =/  grant  (~(get by grants) grant.u.held)
  ?>  ?=(^ grant)
  ?>  ?&  ?=(~ revoked.u.grant)  (grant-valid:tools our.b grant.u.grant)
          =(id.grant.u.grant grant.u.held)
          =(project.grant.u.grant project.u.held)
          =(session.grant.u.grant session.context.candidate.u.held)
          =(actor.grant.u.grant actor.context.candidate.u.held)
      ==
  ?>  (agent-live:guard our.b now.b %boxy)
  =/  all=state:bx
    .^(state:bx %gx /(scot %p our.b)/boxy/(scot %da now.b)/state/noun)
  =/  workspace  (~(get by workspaces.all) id.workspace.request.u.ctx)
  ?>  ?=(^ workspace)
  ?>  ?~(inspected %.y =(u.inspected (digest:review u.ctx)))
  =/  denied
    ?~  inspected  (refusal our.b u.ctx u.held u.workspace)
    (refusal-checked our.b u.ctx u.held u.workspace %.y)
  =/  identity=@ux  (digest:review u.ctx)
  =/  admission=admission:jm
    :*  (cat 3 'ai-review:' (scot %ux request.k))
        (cat 3 'native-ai-review:' (scot %ux identity))
        ?=(~ denied)
        ?~(inspected 'native-ai-review-standing-scope-v1' 'native-ai-review-standing-scope-v2')
        ?~(denied 'Owner-delegated AI review; exact candidate, receipt and Boxy queue.' `@t`u.denied)
    ==
  =/  verdict=verdict:protocol
    [%native-coding-review-admission-v1 campaign.k request.k identity admission]
  =/  record=retained
    [u.ctx verdict (digest:review u.workspace) u.grant]
  :-  (~(put by s) k record)
  :~  (publish verdict)
      [%pass /native-review-evidence %agent [our.b %graf] %poke %graf-action !>([%attest [%native-coding-review-admission-evidence-v1 identity record]])]
  ==
++  lookup
  |=  [s=ledger k=key]
  ^-  (unit verdict:protocol)
  =/  found  (~(get by s) k)
  ?~(found ~ `verdict.u.found)
++  valid
  |=  s=ledger
  ^-  ?
  ?&  (lte ~(wyt by s) 256)
      %+  levy  ~(tap by s)
      |=  [k=key r=retained]
      ?&  =(campaign.k campaign.context.r)  =(request.k id.request.context.r)
          =(campaign.k campaign.verdict.r)  =(request.k request.verdict.r)
          =((digest:review context.r) context.verdict.r)
          =(proposal-id.admission.verdict.r (cat 3 'ai-review:' (scot %ux request.k)))
          =(receipt-id.admission.verdict.r (cat 3 'native-ai-review:' (scot %ux context.verdict.r)))
          |(=(law.admission.verdict.r 'native-ai-review-standing-scope-v1') =(law.admission.verdict.r 'native-ai-review-standing-scope-v2'))
          ?=(~ revoked.grant.r)  !=(0 queued.r)
          =(project.grant.grant.r project.request.context.r)
          =(session.grant.grant.r session.context.candidate.request.context.r)
          =(actor.grant.grant.r actor.context.candidate.request.context.r)
      ==
  ==
--
