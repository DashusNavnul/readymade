::  /lib/multiplayer-collaboration
::
::  Pure validation for finite collaboration events.  The expected route and
::  commitments are receiver-owned inputs; an Ames peer cannot widen them.
::
/-  mc=multiplayer-collaboration
|%
++  max-identifier-bytes  `@ud`256
++  max-progress-ordinal  `@ud`10.000
++  max-review-findings  `@ux`0xff
++  max-digest-bytes  `@ud`32
::
++  digest-valid
  |=  digest=digest:mc
  ^-  ?
  ?&  !=(0 digest)
      (lte (met 3 digest) max-digest-bytes)
  ==
++  bounded-identifier
  |=  value=@t
  ^-  ?
  ?&  (gth (met 3 value) 0)
      (lte (met 3 value) max-identifier-bytes)
  ==
++  kind-of
  |=  payload=payload:mc
  ^-  event-kind:mc
  ?-  -.payload
    %assignment    %assignment
    %progress      %progress
    %review        %review
    %proof         %proof
    %acceptance    %acceptance
    %refusal       %refusal
    %cancellation  %cancellation
    %expiry        %expiry
    %failure       %failure
    %completion    %completion
  ==
++  terminal
  |=  payload=payload:mc
  ^-  ?
  ?|  =(%refusal -.payload)
      =(%cancellation -.payload)
      =(%expiry -.payload)
      =(%failure -.payload)
      =(%completion -.payload)
  ==
++  payload-valid
  |=  payload=payload:mc
  ^-  ?
  ?-  -.payload
    %assignment  (digest-valid task-digest.payload)
    %progress    (lte ordinal.payload max-progress-ordinal)
    %review
      ?&  (digest-valid subject.payload)
          (lte findings.payload max-review-findings)
      ==
    %proof
      ?&  (digest-valid subject.payload)
          (digest-valid receipt.payload)
      ==
    %acceptance
      ?&  (digest-valid subject.payload)
          (digest-valid decision.payload)
      ==
    %refusal       (digest-valid subject.payload)
    %cancellation  (digest-valid subject.payload)
    %expiry         (digest-valid subject.payload)
    %failure        (digest-valid subject.payload)
    %completion     (digest-valid result.payload)
  ==
++  release-valid
  |=  [release=release-class:mc payload=payload:mc]
  ^-  ?
  (release-kind-valid release (kind-of payload))
++  release-kind-valid
  |=  [release=release-class:mc kind=event-kind:mc]
  ^-  ?
  ?-  kind
    %assignment    =(%digest-only release)
    %progress      =(%metadata-only release)
    %review        =(%structured-review release)
    %proof         =(%proof-receipt release)
    %acceptance    =(%digest-only release)
    %refusal       =(%metadata-only release)
    %cancellation  =(%metadata-only release)
    %expiry        =(%metadata-only release)
    %failure       =(%metadata-only release)
    %completion    =(%digest-only release)
  ==
++  expectation-valid
  |=  expected=expectation:mc
  ^-  ?
  ?&  =(1 version.expected)
      (bounded-identifier project.expected)
      (bounded-identifier task.expected)
      (bounded-identifier sender-session.expected)
      (bounded-identifier recipient-session.expected)
      !=(sender.expected recipient.expected)
      (digest-valid graf-root.expected)
      (digest-valid context-digest.expected)
      (digest-valid authority-digest.expected)
  ==
++  body-valid
  |=  body=envelope-body:mc
  ^-  ?
  ?&  =(%multiplayer-collaboration-envelope-v1 -.body)
      (bounded-identifier project.body)
      (bounded-identifier task.body)
      (bounded-identifier sender-session.body)
      (bounded-identifier recipient-session.body)
      !=(sender.body recipient.body)
      (gth sequence.body 0)
      ?~(parent.body %.y (digest-valid u.parent.body))
      !=(0 issued-at.body)
      (lth issued-at.body deadline.body)
      (digest-valid graf-root.body)
      (digest-valid context-digest.body)
      (digest-valid authority-digest.body)
      (payload-valid payload.body)
      (release-valid release.body payload.body)
  ==
++  envelope-digest
  |=  body=envelope-body:mc
  ^-  digest:mc
  `@ux`(shax (jam [%multiplayer-collaboration-v1 body]))
++  make-envelope
  |=  body=envelope-body:mc
  ^-  envelope:mc
  [body (envelope-digest body)]
++  envelope-valid
  |=  envelope=envelope:mc
  ^-  ?
  ?&  (body-valid body.envelope)
      (digest-valid digest.envelope)
      =((envelope-digest body.envelope) digest.envelope)
  ==
++  subject-matches
  |=  [expected=expectation:mc body=envelope-body:mc]
  ^-  ?
  ?&  =(project.expected project.body)
      =(task.expected task.body)
  ==
++  route-matches
  |=  [expected=expectation:mc body=envelope-body:mc]
  ^-  ?
  ?&  =(sender.expected sender.body)
      =(sender-session.expected sender-session.body)
      =(recipient.expected recipient.body)
      =(recipient-session.expected recipient-session.body)
  ==
++  expectation-matches
  |=  [expected=expectation:mc envelope=envelope:mc]
  ^-  ?
  =/  body=envelope-body:mc  body.envelope
  ?&  (subject-matches expected body)
      (route-matches expected body)
      =(graf-root.expected graf-root.body)
      =(context-digest.expected context-digest.body)
      =(authority-digest.expected authority-digest.body)
  ==
++  reject
  |=  refusal=refusal:mc
  ^-  admission:mc
  [%refused refusal]
++  admit-first
  |=  candidate=envelope:mc
  ^-  admission:mc
  ?.  =(1 sequence.body.candidate)
    (reject [%wrong-sequence ~])
  ?.  ?=(~ parent.body.candidate)
    (reject [%wrong-parent ~])
  [%accepted candidate]
++  admit-successor
  |=  $:  expected=expectation:mc
          prior=envelope:mc
          candidate=envelope:mc
      ==
  ^-  admission:mc
  ?.  (envelope-valid prior)
    (reject [%invalid-prior ~])
  ?.  (expectation-matches expected prior)
    (reject [%invalid-prior ~])
  ?:  =(digest.candidate digest.prior)
    [%duplicate digest.candidate]
  ?:  =(sequence.body.candidate sequence.body.prior)
    (reject [%replay-conflict ~])
  ?:  (terminal payload.body.prior)
    (reject [%terminal-settled ~])
  ?.  =((add sequence.body.prior 1) sequence.body.candidate)
    (reject [%wrong-sequence ~])
  ?.  =(`digest.prior parent.body.candidate)
    (reject [%wrong-parent ~])
  ?.  (gte issued-at.body.candidate issued-at.body.prior)
    (reject [%nonmonotonic-time ~])
  [%accepted candidate]
++  admit
  |=  $:  expected=expectation:mc
          prior=(unit envelope:mc)
          candidate=envelope:mc
          now=@da
      ==
  ^-  admission:mc
  ?.  (expectation-valid expected)
    (reject [%invalid-expectation ~])
  ?.  (envelope-valid candidate)
    (reject [%invalid-envelope ~])
  ?.  (subject-matches expected body.candidate)
    (reject [%subject-mismatch ~])
  ?.  (route-matches expected body.candidate)
    (reject [%route-mismatch ~])
  ?.  =(graf-root.expected graf-root.body.candidate)
    (reject [%graf-root-mismatch ~])
  ?.  =(context-digest.expected context-digest.body.candidate)
    (reject [%context-mismatch ~])
  ?.  =(authority-digest.expected authority-digest.body.candidate)
    (reject [%authority-mismatch ~])
  ?:  (gth now deadline.body.candidate)
    (reject [%expired ~])
  ?~  prior
    (admit-first candidate)
  (admit-successor expected u.prior candidate)
--
