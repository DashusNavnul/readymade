::  Owner-only exact source comparison. No cards, ACKs, grants or execution.
/-  r=readymade-artifact-round, pkg=readymade-package
/+  kit=readymade-collab-saved, artifact=readymade-artifact-collab,
    round=readymade-artifact-round,
    package=readymade-package, build=readymade-package-build,
    action=readymade-artifact-actions, files=native-coding-files,
    mg=readymade-app-management, web=readymade-artifact-http
|%
+$  command  [owner=@p peer=@p pact=@ux guard=@ux selected=@ux]
+$  selection
  $:  owner=@p  peer=@p  pact=@ux  guard=@ux  selected=@ux
      proposal=proposal:r  receipt=receipt:build
  ==
+$  source  [file=file:pkg text=@t]
+$  view
  $:  owner=@p  peer=@p  pact=@ux  guard=@ux  selected=@ux
      package=@ux  artifact=@ux  build-proof=@ux
      target=target:r  stage=pin:pkg
      before=(unit source)  after=source
  ==
++  prepare
  ::  Canonical proposal before approval: deliberately does NOT require ACKs.
  |=  [our=@p actor=@p peer=@p id=@ux expected=@ux selected=@ux value=saved:kit]
  ^-  (each selection @tas)
  ?.  &(=(our actor) !=(our peer))  [%| %owner-required]
  ?.  (valid:kit our value)  [%| %invalid-canonical-state]
  ?.  =(expected (guard:action our peer id value))  [%| %stale-guard]
  =/  agreement  (~(get by pacts.state.value) id)
  ?~  agreement  [%| %pact-missing]
  =/  current  value.u.agreement
  ?.  ?|  &(=(our left.terms.current) =(peer right.terms.current))
          &(=(peer left.terms.current) =(our right.terms.current))
      ==
    [%| %peer-mismatch]
  =/  held  (~(get by rounds.artifacts.value) [id generation.current %land])
  ?~  held  [%| %round-missing]
  ?.  (valid:round u.held current)  [%| %round-invalid]
  ?:  |(left-close.u.held right-close.u.held)  [%| %round-closed]
  ?~  proposal.u.held  [%| %proposal-missing]
  =/  proposal=proposal:r  u.proposal.u.held
  ?.  &(=(selected (digest:round proposal)) =(id pact.proposal))
    [%| %proposal-mismatch]
  ?.  ?=(%land -.target.proposal)  [%| %land-required]
  ?.  &(=(our receiver.proposal) =(our ship.target.proposal))
    [%| %receiver-only]
  =/  item  (~(get by packages.state.value) package.proposal)
  ?~  item  [%| %package-missing]
  ?.  (proposal-bound:artifact artifacts.value current value.u.item %land proposal)
    [%| %proposal-binding]
  =/  evidence  (~(get by evidence.artifacts.value) build-proof.proposal)
  ?~  evidence  [%| %proof-missing]
  ?.  ?&  =(%local-canonical provenance.u.evidence)
          =(our builder.u.evidence)
          (local-valid:artifact our value.u.item receipt.u.evidence)
      ==
    [%| %canonical-receiver-build-required]
  =/  receipt=receipt:build  receipt.u.evidence
  =/  offered=(list file:pkg)  files.body.offer.plan.body.receipt
  ?.  ?=([* ~] offered)  [%| %one-hoon-file-required]
  =/  file=file:pkg  i.offered
  ?.  &((source-supported:build file) =(%hoon (rear file.target.proposal)))
    [%| %hoon-required]
  ?.  (lte size.file 65.536)  [%| %source-too-large]
  [%& [our peer id expected selected proposal receipt]]
++  finish
  ::  Pure byte validation. A missing before is distinct from an empty file.
  |=  [chosen=selection before=(unit @t) after=@t]
  ^-  (each view @tas)
  =/  offered=(list file:pkg)  files.body.offer.plan.body.receipt.chosen
  ?.  ?=([* ~] offered)  [%| %one-hoon-file-required]
  =/  expected=file:pkg  i.offered
  ?.  &(=(selected.chosen (digest:round proposal.chosen)) ?=(%land -.target.proposal.chosen))
    [%| %proposal-mismatch]
  ?.  &(=(owner.chosen receiver.proposal.chosen) =(owner.chosen ship.target.proposal.chosen))
    [%| %receiver-only]
  ?.  (lte (met 3 after) 65.536)  [%| %source-too-large]
  ?.  =(expected (source-file:package path.expected after))
    [%| %canonical-source-mismatch]
  ?.  (utf8:files after)  [%| %source-not-utf8]
  ?.  ?~(before %.y (lte (met 3 u.before) 65.536))
    [%| %before-too-large]
  ?.  ?~(before %.y (utf8:files u.before))  [%| %before-not-utf8]
  =/  previous=(unit source)
    ?~  before  ~
    `[(source-file:package file.target.proposal.chosen u.before) u.before]
  =/  plan=plan:build  plan.body.receipt.chosen
  [%& [owner.chosen peer.chosen pact.chosen guard.chosen selected.chosen package.proposal.chosen artifact.proposal.chosen build-proof.proposal.chosen target.proposal.chosen [owner.chosen destination.plan revision.plan root.plan] previous [expected after]]]
++  read
  ::  All pins/paths derive from canonical state, never arbitrary HTTP paths.
  |=  [b=bowl:gall peer=@p id=@ux expected=@ux selected=@ux value=saved:kit]
  ^-  (each view @tas)
  =/  ready  (prepare our.b src.b peer id expected selected value)
  ?:  ?=(%| -.ready)  [%| p.ready]
  =/  chosen=selection  p.ready
  =/  target=target:r  target.proposal.chosen
  ?>  ?=(%land -.target)
  ::  target-private permits foreign tuples for ACKs; prepare forbids them here.
  ?.  (target-private:action b target)  [%| %private-target-drift]
  =/  plan=plan:build  plan.body.receipt.chosen
  =/  problem  (verify-workspace:build our.b now.b plan)
  ?^  problem  [%| u.problem]
  =/  offered=(list file:pkg)  files.body.offer.plan
  ?>  ?=([* ~] offered)
  =/  source=file:pkg  i.offered
  ?.  (private our.b destination.plan now.b path.source)
    [%| %workspace-source-not-private]
  =/  after-at=path
    (weld ~[(scot %p our.b) destination.plan (scot %ud revision.plan)] path.source)
  ?.  .^(? %cu after-at)  [%| %canonical-source-missing]
  =/  after=(unit @t)  ((soft @t) .^(* %cq after-at))
  ?~  after  [%| %source-not-text]
  =/  before-at=path
    (weld ~[(scot %p our.b) desk.target (scot %ud revision.target)] file.target)
  ?.  .^(? %cu before-at)  (finish chosen ~ u.after)
  =/  before=(unit @t)  ((soft @t) .^(* %cq before-at))
  ?~  before  [%| %before-not-text]
  ::  Refuse unsupported before bytes explicitly, never silently treat as create.
  (finish chosen before u.after)
++  private
  |=  [our=@p desk=@tas now=@da file=path]
  ^-  ?
  =/  rules=[r=dict:clay w=dict:clay]
    .^([r=dict:clay w=dict:clay] %cp (weld ~[(scot %p our) desk (scot %da now)] file))
  &(=([%white ~ ~] rul.r.rules) =([%white ~ ~] rul.w.rules))
++  decode
  |=  raw=@t
  ^-  command
  ?>  =(6 (lent (skim (trip raw) |=(c=@t =(c ':')))))
  =/  decoded=json  (need (de:json:html raw))
  ?>  ?=(%o -.decoded)
  =/  obj=(map @t json)  p.decoded
  =/  keys=(list @t)  ~['schema' 'owner' 'peer' 'pact' 'guard' 'selected']
  ?>  =((silt keys) ~(key by obj))
  ?>  =('readymade-artifact-source-review-command-v1' (text-field:action obj 'schema' 64))
  =/  own=@t  (text-field:action obj 'owner' 128)
  =/  other=@t  (text-field:action obj 'peer' 128)
  =/  our=@p  (need (slaw %p own))
  =/  peer=@p  (need (slaw %p other))
  ?>  &(=(own (scot %p our)) =(other (scot %p peer)) !=(our peer))
  ?>  &((lte (met 0 our) 128) (lte (met 0 peer) 128))
  [our peer (ux:action (text-field:action obj 'pact' 256)) (ux:action (text-field:action obj 'guard' 256)) (ux:action (text-field:action obj 'selected' 256))]
++  parse
  |=  raw=@t
  ^-  (unit command)
  ?.  (lte (met 3 raw) 2.048)  ~
  (mole |.((decode raw)))
++  read-request
  |=  req=inbound-request:eyre
  ^-  (unit command)
  =/  raw=(unit @t)  (header:mg header-list.request.req 'x-readymade-review-command')
  ?~  raw  ~
  (parse u.raw)
++  source-json
  |=  item=(unit source)
  ^-  json
  %-  pairs:enjs:format
  :~  ['exists' b+?=(^ item)]
      ['bytes' (numb:enjs:format ?~(item 0 size.file.u.item))]
      ['hash' ?~(item ~ s+(scot %ux hash.file.u.item))]
      ['text' ?~(item ~ s+text.u.item)]
  ==
++  json-view
  |=  v=view
  ^-  json
  =/  staged=json
    %-  pairs:enjs:format
    :~  ['ship' s+(scot %p ship.stage.v)]
        ['desk' s+(scot %tas desk.stage.v)]
        ['revision' s+(scot %ud revision.stage.v)]
        ['root' s+(scot %ux root.stage.v)]
        ['sourceFile' s+(spat path.file.after.v)]
    ==
  %-  pairs:enjs:format
  :~  ['schema' s+'readymade-artifact-source-review-v1']
      ['status' s+'verified']
      ['metadataOnly' b+%.y]
      ['executionAuthorized' b+%.n]
      ['owner' s+(scot %p owner.v)]
      ['peer' s+(scot %p peer.v)]
      ['pact' s+(scot %ux pact.v)]
      ['guard' s+(scot %ux guard.v)]
      ['selected' s+(scot %ux selected.v)]
      ['package' s+(scot %ux package.v)]
      ['artifact' s+(scot %ux artifact.v)]
      ['buildProof' s+(scot %ux build-proof.v)]
      ['target' (target-json:web target.v)]
      ['stage' staged]
      ['before' (source-json before.v)]
      ['after' (source-json `after.v)]
      ['textComplete' b+%.y]
  ==
--
