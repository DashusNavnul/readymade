::  Cantrip-local reads only. Caller supplies a judgment key, never bytes,
::  a permission window, source revision, intent, or successful test result.
/-  itn=intent
/+  clw=cantrip-law-window, demo=vibecoding-demo, dsr=desk-shell-read,
    land=cantrip-vibecoding-local-land, image=vibecoding-local-image,
    lrr=vibecoding-local-result-read, preview=vibecoding-local-preview,
    owned=vibecoding-local-preview-read, vcl=vibecoding-candidate,
    vsg=viki-scry-guard, lflect=cantrip-land-flect
|%
++  read
  |=  [our=@p actor=@p at=@da key=@ux window=window:clw]
  ^-  decision:land
  -:(read-evidence our actor at key window)
::  +read-evidence: the decision with the act the judge saw -- rows, key,
::  view, image, run, intent, parent -- so the caller can keep a receipt of
::  the judgment (lib/cantrip-land-flect) without reading twice.  No act
::  when the read itself refused before the judge ran.
++  read-evidence
  |=  [our=@p actor=@p at=@da key=@ux window=window:clw]
  ^-  [decision:land (unit act:lflect)]
  ?.  =(our actor)  [[%| %foreign-actor] ~]
  ?.  &((agent-live:vsg our at %graf) (agent-live:vsg our at %viki))
    [[%| %agent-unavailable] ~]
  =/  rows=(list *)  (owned:owned our actor at)
  =/  picked  (select:land our at rows key)
  ?:  ?=(%| -.picked)  [picked ~]
  =/  s  subject.body.p.picked
  =/  view  (read:lrr our actor at write.s)
  ?:  ?=(%| -.view)  [[%| %result-unavailable] ~]
  =/  img  (find:image rows image.s)
  ?~  img  [[%| %image-missing] ~]
  =/  run  (find:preview rows run.s)
  ?~  run  [[%| %run-missing] ~]
  =/  context  (context-of:vcl packet.candidate.p.view)
  =/  intent=(unit record:itn)
    .^  (unit record:itn)  %gx
        ~[(scot %p our) %viki (scot %da at) %intent id.intent.intent.context %noun]
    ==
  ?.  fresh.p.view  [[%| %stale-source] ~]
  =/  domo=domo:clay  .^(domo:clay %cv (beam:dsr our at base:demo /))
  =/  parent=(unit tako:clay)  (~(get by hit.domo) let.domo)
  ?~  parent  [[%| %binding-invalid] ~]
  =/  a=act:lflect  [rows key p.view u.img u.run intent u.parent]
  [(judge:land our actor at rows key p.view u.img u.run intent window u.parent) `a]
++  observe
  |=  [our=@p actor=@p at=@da r=record:land]
  ^-  (unit observation:land)
  ?.  &(=(our actor) =(our actor.admission.r) (record-valid:land r))  ~
  =/  current  (observe:lrr our at)
  =/  committed=(unit commit:land)
    ?.  exists.accepted.current  ~
    =/  s  subject.body.judgment.admission.r
    =/  domo=domo:clay  .^(domo:clay %cv (beam:dsr our at base:demo /))
    =/  tako=(unit tako:clay)  (~(get by hit.domo) (add 1 number.base.s))
    ?~  tako  ~
    =/  yaki=yaki:clay
      .^(yaki:clay %cs (beam:dsr our at base:demo /yaki/(scot %uv u.tako)))
    `[r.yaki p.yaki t.yaki]
  `[at current committed]
--
