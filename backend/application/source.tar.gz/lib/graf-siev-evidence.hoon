::  /lib/graf-siev-evidence.hoon
::
::  Graf's absorption of %siev's QPC durable evidence, per the donor's own
::  graf-warp contract: every record kind is stamped evaluator-truth=%.n and
::  action-authority=%.n with memory-owner '%graf/Warp', so what crosses here
::  is history, never law.  The exact donor state noun is retained whole and
::  fingerprint-bound; only the durable evidence surfaces are served back,
::  through the donor's own readback arms, and Graf never runs the QPC
::  transition law.  Retired pillars ride along as opaque history with no
::  read or write surface.
::
/-  gsv=graf-siev-shadow, sv=siev
/+  sk=siev-kernel
|%
+$  result
  $:  receipt=evidence-receipt:gsv
      evidence=(unit evidence-import:gsv)
  ==
::
++  import
  |=  $:  prior=(unit evidence-import:gsv)
          snapshot=siev-state:sv
          source-ship=@p
          now=@da
      ==
  ^-  result
  =/  snapshot-mug=@ud  (mug snapshot)
  =/  snapshot-digest=@ux  (shax (jam snapshot))
  ?~  prior
    :-  [%.y %evidence-imported snapshot-mug]
    `[source-ship %siev now snapshot-mug snapshot-digest snapshot]
  ?:  =(snapshot-digest snapshot-digest.u.prior)
    [[%.y %evidence-already-imported snapshot-mug] prior]
  [[%.n %evidence-import-conflict snapshot-mug] prior]
::
++  evidence-valid
  |=  ev=evidence-import:gsv
  ^-  ?
  ?&  =(snapshot-mug.ev (mug snapshot.ev))
      =(snapshot-digest.ev (shax (jam snapshot.ev)))
      =(%siev source-agent.ev)
  ==
::
::  The donor's durable-evidence readback surface, served over the exact
::  import.  Shapes are the donor's own noun peeks; drift and summary run
::  the donor's kernel arms over the retained snapshot.
++  peek-evidence
  |=  [ev=(unit evidence-import:gsv) pax=path]
  ^-  (unit (unit cage))
  ?~  ev
    ?+  pax  ~
      [%status ~]  ``noun+!>(~)
    ==
  ?+  pax  ~
    [%status ~]
      ``noun+!>(`[source-ship.u.ev source-agent.u.ev imported-at.u.ev snapshot-mug.u.ev snapshot-digest.u.ev])
    [%world ~]
      ``noun+!>(world.snapshot.u.ev)
    [%receipts ~]
      ``noun+!>(receipts.snapshot.u.ev)
    [%residue ~]
      ``noun+!>(residue.world.snapshot.u.ev)
    [%protocols ~]
      ``noun+!>(validation-protocols.world.snapshot.u.ev)
    [%protocol %verdicts ~]
      ``noun+!>(protocol-verdicts.snapshot.u.ev)
    [%drift ~]
      ``noun+!>((siev-drift-surfaces:sk snapshot.u.ev))
    [%summary ~]
      ``noun+!>((siev-runtime-summary:sk snapshot.u.ev))
  ==
--
