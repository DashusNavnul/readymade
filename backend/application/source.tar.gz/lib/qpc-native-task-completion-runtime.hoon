:: Viki's native landed-task reader. Commands contain identity and an expected
:: proposal hash only; neither supplied snapshots nor acknowledgments are proof.
:: The existing session journal retains completion, without a new saved core.
/-  nc=native-coding, worker=native-coding-worker
/+  kernel=qpc-native-task-completion, campaign=qpc-native-campaign,
    base=native-coding-completion-runtime, prior=native-coding-completion,
    loop=native-coding-loop,
    session=native-coding-session, accept=native-coding-accept,
    review=native-coding-review, local=native-coding-local-decision,
    local-store=native-coding-local-review-state,
    provider=native-coding-provider, project=native-coding-project,
    guard=viki-scry-guard
|%
+$  command  [%qpc-native-task-complete-v1 member=@ux expected=@ux]
+$  change  [coding=state:loop cards=(list card:agent:gall)]
+$  inspected  [task=task:kernel receipt=receipt:kernel]
+$  parent
  $:  %native-coding-worker-parent-v1  engaged=?
      owner=[tag=@tas pairing=(unit pairing:worker) journal=journal:worker offers=(map @ux *)]
      pending=(map @ux @ux)  failures=(map @ux @tas)
  ==
+$  release-state
  [candidates=(map @ux candidate:nc) accepted=ledger:accept parent=parent]
+$  retained-page
  [%graf-kind-page %1 kind=@tas offset=@ud limit=@ud returned=@ud more=? next=@ud items=(list *)]
++  fact-limit  1.048.576
++  history-limit  256
++  original
  |=  [our=@p records=state:campaign member=@ux]
  ^-  (each record:campaign @tas)
  =/  rows=(list record:campaign)
    (skim ~(val by records.records) |=(r=record:campaign =(member member.command.task.r)))
  ?.  =(1 (lent rows))  [%| %task-completion-declaration-missing]
  =/  r=record:campaign  (snag 0 rows)
  ?.  ?&  =(our owner.task.r)
          ?=(?(%collecting %awaiting-next-task) phase.r)
          ?=(~ request.r)  ?=(~ due.r)  ?=(~ child.r)
      ==  [%| %task-completion-declaration-unsettled]
  [%& r]
++  applied
  |=  [s=snapshot:prior r=record:campaign]
  ^-  (each record:accept @tas)
  =/  member=@ux  member.command.task.r
  =/  rows=(list record:accept)
    %+  skim  ~(val by accepted.s)
    |=  a=record:accept
    ?&  =(member session.context.candidate.a)
        =(%applied stage.a)
        ?~(landed.a %.n =(current.s revision.u.landed.a))
    ==
  ?.  =(1 (lent rows))  [%| %task-completion-applied-landing-missing]
  [%& (snag 0 rows)]
++  required
  :: These five families are emitted by their existing native owners. Keep
  :: exact values: a digest, outgoing card or successful poke is insufficient.
  |=  [e=entry:session a=record:accept h=entry:review r=captured:local]
  ^-  (each (list *) @tas)
  =/  candidate=candidate:nc  candidate.a
  =/  results=(list record:session)
    (skim records.e |=(j=record:session ?.(?=(%tool -.body.j) %.n &(?=(%candidate -.output.result.body.j) =(context.candidate context.result.body.j) =(candidate value.output.result.body.j)))))
  =/  judgments=(list record:session)
    (skim records.e |=(j=record:session ?.(?=(%judgment -.body.j) %.n &(=(%continue verdict.body.j) (~(has in (silt evidence.body.j)) (digest:accept a))))))
  ?.  &(=(1 (lent results)) =(1 (lent judgments)))
    [%| %task-completion-consumed-journal-missing]
  [%& ~[[%native-coding-acceptance-v1 (digest:accept a) a] [%native-coding-local-review-v2 id.candidate campaign.r] [%native-coding-review-v1 id.candidate h] [%native-coding-session-record-v1 id.session.e (snag 0 results)] [%native-coding-session-record-v1 id.session.e (snag 0 judgments)]]]
++  assemble
  :: Pure join only; read below supplies canonical organs and Graf membership.
  |=  $:  our=@p  declared=record:campaign  source=snapshot:prior
          key=@tas  reviews=state:review  local-review=captured:local
      ==
  ^-  (each snapshot:kernel @tas)
  =/  c=command:campaign  command.task.declared
  =/  v=snapshot:campaign  snapshot.task.declared
  ?.  ?&  =(our owner.task.declared)
          =(member.c id.session.entry.source)
          =(project.v project.source)
          =(key.c key)  =(grant.c grant.source)
          ?=(~ assignment.source)
      ==  [%| %task-completion-owner-binding-changed]
  =/  chosen  (applied source declared)
  ?:  ?=(%| -.chosen)  [%| p.chosen]
  =/  a=record:accept  p.chosen
  =/  h  (~(get by reviews) id.candidate.a)
  ?~  h  [%| %task-completion-viki-review-missing]
  ?.  ?&  advanced.u.h  =(candidate.u.h candidate.a)
          =(observed.u.h `a)  =(decision.u.h decision.a)
          =(grant.c grant.a)
      ==  [%| %task-completion-viki-review-unconsumed]
  =/  facts  (required entry.source a u.h local-review)
  ?:  ?=(%| -.facts)  [%| p.facts]
  ?>  =(5 (lent p.facts))
  =/  t=task:kernel
    [member.c project.manifest.plan.v (configuration:project project.source) objective.c expected.c artifact.plan.v cases.v p.facts]
  [%& [t entry.source project.source current.source a local-review pending.source candidates.source accepted.source tools.source ~]]
++  read
  |=  [b=bowl:gall coding=state:loop reviews=state:review member=@ux]
  ^-  (each snapshot:kernel @tas)
  ?.  &(=(our.b src.b) (agent-live:guard our.b now.b %graf))
    [%| %task-completion-owner-or-graf-unavailable]
  =/  source  (read:base b coding member)
  ?:  ?=(%| -.source)  [%| p.source]
  =/  records=state:campaign
    ;;(state:campaign .^(* %gx /(scot %p our.b)/viki/(scot %da now.b)/qpc/campaigns/noun))
  =/  declared  (original our.b records member)
  ?:  ?=(%| -.declared)  [%| p.declared]
  =/  binding  (~(get by bindings.coding) member)
  ?~  binding  [%| %task-completion-grant-binding-missing]
  =/  chosen  (applied p.source p.declared)
  ?:  ?=(%| -.chosen)  [%| p.chosen]
  =/  captured  (lookup:local our.b now.b id.candidate.p.chosen)
  ?:  ?=(%| -.captured)  [%| p.captured]
  ?~  p.captured  [%| %task-completion-local-review-missing]
  =/  held=captured:local  u.p.captured
  =/  h  campaign.held
  :: Authenticate the current native review selection without pre-landing
  :: source gates. CLI builder transport is independent of this reviewer.
  =/  issue=(unit @tas)
    ?:  ?=(^ (cli-backend:provider selection.scope.request.h))
      `%task-completion-cli-review-admission-unavailable
    ?.  (agent-live:guard our.b now.b %codex-inference)
      `%task-completion-provider-unavailable
    =/  selected=*
      .^(* %gx /(scot %p our.b)/codex-inference/(scot %da now.b)/native-coding/selection/(scot %tas provider-key.scope.request.h)/noun)
    ?.(=(`selection.scope.request.h selected) `%task-completion-review-selection-changed ~)
  ?^  issue  [%| u.issue]
  =/  joined  (assemble our.b p.declared p.source provider-key.u.binding reviews held)
  ?:  ?=(%| -.joined)  [%| p.joined]
  =/  s=snapshot:kernel  p.joined
  =/  todo=(list *)  graf.task.s
  =|  kept=(list (unit *))
  |-  ^-  (each snapshot:kernel @tas)
  ?~  todo  [%& s(graf (flop kept))]
  =/  fact=*  i.todo
  =/  encoded=@  (jam fact)
  ?:  (gth (met 3 encoded) fact-limit)  [%| %task-completion-graf-fact-too-large]
  =/  present=?
    .^(? %gx /(scot %p our.b)/graf/(scot %da now.b)/contains/(scot %uw encoded)/noun)
  $(todo t.todo, kept [?:(present `fact ~) kept])
++  retained-fact
  |=  [member=@ux r=receipt:kernel]
  [%qpc-native-task-completion-retained-v1 member r]
++  retention-bounded
  |=  [member=@ux r=receipt:kernel]
  ^-  ?
  (lte (met 3 (jam (retained-fact member r))) fact-limit)
++  read-parent
  |=  b=bowl:gall
  ^-  parent
  ;;(parent .^(* %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/worker/state/noun))
++  release-parent-valid
  :: Consistency only. Native readers supply complete actual Viki candidates,
  :: the required canonical Cantrip rows and the exact retained parent state.
  |=  [our=@p at=@da e=entry:session auth=release-state witnesses=releases:kernel]
  ^-  ?
  ?&  (lte (lent witnesses) 128)
      =((lent witnesses) ~(wyt in (silt (turn witnesses |=(w=release:kernel candidate.w)))))
      %+  levy  witnesses
      |=  w=release:kernel
      ?&  (release-valid:kernel our at e candidates.auth accepted.auth w)
          =(`job.w (~(get by journal.owner.parent.auth) key.w))
          =(`candidate.w (~(get by pending.parent.auth) ticket.order.job.w))
      ==
  ==
++  releases
  :: Read one actual parent journal. Only old foreign check reservations that
  :: are blockers in this untouched snapshot may supply release witnesses.
  |=  [b=bowl:gall s=snapshot:kernel]
  ^-  (each releases:kernel @tas)
  =/  e=entry:session  entry.s
  =/  rows=(list record:accept)
    %+  skim  ~(val by accepted.s)
    |=  a=record:accept
    =/  c=candidate:nc  candidate.a
    ?&  (candidate-pending:prior e c accepted.s)
        !=(id.session.e session.context.c)
        (same-desk:prior working.session.e source.context.c)
        (lth number.source.context.c number.working.session.e)
        =(`c (~(get by candidates.s) id.c))
        =(%unknown stage.a)  |(=(`%worker-deadline reason.a) =(`%worker-source-changed reason.a))
    ==
  ?:  =(0 (lent rows))  [%& ~]
  =/  parent=parent  (read-parent b)
  ?.  engaged.parent  [%| %task-completion-release-parent-inactive]
  =|  witnesses=releases:kernel
  |-  ^-  (each releases:kernel @tas)
  ?~  rows
    =/  auth=release-state  [candidates.s accepted.s parent]
    ?.  (release-parent-valid our.b now.b e auth witnesses)
      [%| %task-completion-release-binding-mismatch]
    [%& (flop witnesses)]
  =/  a=record:accept  i.rows
  =/  matches=(list [key=@ux job=record:worker])
    (skim ~(tap by journal.owner.parent) |=([key=@ux job=record:worker] &((released-check:kernel our.b now.b a key job) =(`id.candidate.a (~(get by pending.parent) ticket.order.job)))))
  ?~  matches  [%| %task-completion-release-unconfirmed]
  =/  match=[key=@ux job=record:worker]  i.matches
  $(rows t.rows, witnesses [[id.candidate.a (digest:accept a) key.match job.match] witnesses])
++  history-release-state
  :: The retained proposal selects exact historical rows. These are fetched
  :: natively; they are never substituted for an earlier whole-work snapshot.
  |=  [b=bowl:gall coding=state:loop receipt=receipt:kernel]
  ^-  (each release-state @tas)
  =/  todo=releases:kernel  (release-evidence:kernel proposal.receipt)
  ?:  (gth (lent todo) 128)  [%| %task-completion-release-capacity]
  ?:  =(0 (lent todo))  [%& [candidates.coding ~ *parent]]
  =/  parent=parent  (read-parent b)
  =|  accepted=ledger:accept
  |-  ^-  (each release-state @tas)
  ?~  todo  [%& [candidates.coding accepted parent]]
  =/  id=@ux  candidate.i.todo
  =/  row=(unit record:accept)
    ;;((unit record:accept) .^(* %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/candidate/(scot %ux id)/noun))
  ?~  row  [%| %task-completion-release-history-missing]
  $(todo t.todo, accepted (~(put by accepted) id u.row))
++  reconstruct
  :: Recreate the one prior receipt from the committed journal, never from a
  :: supplied successful flag. Duplicate completion must reproduce every byte.
  |=  [our=@p at=@da s=snapshot:kernel]
  ^-  (each receipt:kernel @tas)
  (reconstruct-with our at s ~)
++  reconstruct-with
  |=  [our=@p at=@da s=snapshot:kernel witnesses=releases:kernel]
  ^-  (each receipt:kernel @tas)
  =/  e=entry:session  entry.s
  ?.  &(!=(~ records.e) =(%complete phase.e) =(%complete resume.e))
    [%| %task-completion-not-current]
  =/  last=record:session  (rear records.e)
  =/  before=entry:session  (rewind:kernel e last)
  =/  prepared  (prepare-with:kernel our at.last s(entry before) witnesses)
  ?:  ?=(%| -.prepared)  [%| p.prepared]
  =/  r=receipt:kernel  [p.prepared last]
  =/  repeated  (complete-with:kernel our our at s witnesses `r)
  ?:  ?=(%| -.repeated)  [%| p.repeated]
  ?.  =(effects.next.p.repeated ~)  [%| %task-completion-replay-has-effects]
  [%& r]
++  retained
  :: Exact bounded native pages, consumed through more=%.n. A caller cannot
  :: supply the receipt or turn a missing/partial page into proof of absence.
  |=  [b=bowl:gall member=@ux]
  ^-  (each receipt:kernel @tas)
  =/  offset=@ud  0
  =|  found=(list receipt:kernel)
  |-  ^-  (each receipt:kernel @tas)
  ?:  (gte offset history-limit)  [%| %task-completion-history-capacity]
  =/  page=retained-page
    ;;(retained-page .^(* %gx /(scot %p our.b)/graf/(scot %da now.b)/by-kind-page/qpc-native-task-completion-retained-v1/(scot %ud offset)/64/noun))
  ?.  ?&  =(%qpc-native-task-completion-retained-v1 kind.page)
          =(offset offset.page)  =(64 limit.page)
          =(returned.page (lent items.page))  (lte returned.page 64)
          =(next.page (add offset returned.page))
          ?:(more.page =(returned.page 64) %.y)
      ==  [%| %task-completion-history-page-invalid]
  =/  rows=(list *)  items.page
  =/  selected=(each (list receipt:kernel) @tas)
    |-  ^-  (each (list receipt:kernel) @tas)
    ?~  rows  [%& found]
    ?:  (gth (met 3 (jam i.rows)) fact-limit)  [%| %task-completion-history-fact-too-large]
    =/  parsed
      ((soft ,[%qpc-native-task-completion-retained-v1 member=@ux receipt=receipt:kernel]) i.rows)
    ?~  parsed  [%| %task-completion-history-fact-invalid]
    ?.  =(member member.u.parsed)  $(rows t.rows)
    ?:  (gth (lent found) 0)  [%| %task-completion-history-ambiguous]
    $(rows t.rows, found ~[receipt.u.parsed])
  ?:  ?=(%| -.selected)  [%| p.selected]
  =.  found  p.selected
  ?:  more.page  $(offset next.page)
  ?.  =(1 (lent found))  [%| %task-completion-retention-unconfirmed]
  [%& (snag 0 found)]
++  historical
  :: Historical consistency only. Native readers supply the exact retained
  :: receipt, declaration, journal, acceptance and review, never a fabricated
  :: old project registration or empty current-work snapshot.
  |=  $:  our=@p  declared=record:campaign  e=entry:session
          a=record:accept  h=entry:review  local-review=captured:local
          receipt=receipt:kernel  actual=(list (unit *))
          release-auth=release-state
      ==
  ^-  (each inspected @tas)
  =/  c=command:campaign  command.task.declared
  =/  v=snapshot:campaign  snapshot.task.declared
  =/  p=proposal:kernel  proposal.receipt
  ?.  ?&  =(our owner.task.declared)  =(our owner.session.e)
          =(our worker.e)  =(member.c id.session.e)  =(member.c member.p)
          =(%complete phase.e)  =(%complete resume.e)
          ?=(~ pending.e)  ?=(~ calls.e)  ?=(^ records.e)
          =(project.manifest.plan.v project.session.e)
          =((configuration:project project.v) configuration.e)
          =(objective.c objective.session.e)
          (journal-valid:prior e)
      ==  [%| %task-completion-history-binding-mismatch]
  =/  last=record:session  (rear records.e)
  ?.  &(=(last record.receipt) =(head.e `id.last) =(sequence.e +(sequence.last)))
    [%| %task-completion-history-not-current]
  =/  candidate=candidate:nc  candidate.a
  ?.  ?&  =(%applied stage.a)  ?=(^ landed.a)  ?=(^ report.a)
          ?=(^ decision.a)  =(grant.c grant.a)
          =(expected.c source.context.candidate)
          =(member.c session.context.candidate)
          =(project.v project.a)  =(configuration.e configuration.context.candidate)
          =(our actor.context.candidate)
          (edits-declared:kernel project.v artifact.plan.v edits.candidate)
          (valid:accept (~(put by *ledger:accept) id.candidate a))
          (passed:accept (need report.a))
          =(%approve verdict:(need decision.a))
          =(working.session.e revision:(need landed.a))
          =(our owner.expected.c)  =(our owner.working.session.e)
          =(owner.expected.c owner.working.session.e)
          =(desk.expected.c desk.working.session.e)
          =(+(number.expected.c) number.working.session.e)
          advanced.h  =(candidate.h candidate)  =(observed.h `a)
          =(decision.h decision.a)
      ==  [%| %task-completion-history-landing-mismatch]
  =/  before=entry:session  (rewind:kernel e last)
  ?.  (release-parent-valid our at.last before release-auth (release-evidence:kernel p))
    [%| %task-completion-history-release-mismatch]
  =/  facts  (required before a h local-review)
  ?:  ?=(%| -.facts)  [%| p.facts]
  =/  t=task:kernel
    [member.c project.manifest.plan.v (configuration:project project.v) objective.c expected.c artifact.plan.v cases.v p.facts]
  ?.  ?&  =(5 (lent p.facts))  (graf-retained:kernel p.facts actual)
          =((digest:kernel t) task.p)  =((digest:kernel before) entry.p)
          =((digest:accept a) acceptance.p)
          =((digest:kernel local-review) review.p)
          =((digest:kernel [p.facts actual]) graf.p)
          =(working.session.e source.p)
          =(body.last (judgment-body:kernel p))
          (protected-passes:kernel project.v t (need report.a))
          (consumed:kernel before a)
      ==  [%| %task-completion-history-evidence-mismatch]
  =/  goal  (objective:prior before)
  ?:  ?=(%| -.goal)  [%| p.goal]
  =/  reviewer  selection.scope.request.campaign.local-review
  ?:  =([provider.reviewer model.reviewer] [provider.selection.before model.selection.before])
    [%| %task-completion-independent-review-required]
  =/  decided
    (decide:local our at:(need decision.a) local-review project.v candidate (need report.a) text.p.goal)
  ?:  ?=(%| -.decided)  [%| p.decided]
  ?.  =(p.decided (need decision.a))  [%| %task-completion-history-review-mismatch]
  =/  replay
    (append:session before(phase %complete, resume %complete) at.last (judgment-body:kernel p))
  ?:  ?=(%| -.replay)  [%| p.replay]
  ?.  =(e entry.p.replay)  [%| %task-completion-history-journal-mismatch]
  [%& [t receipt]]
++  inspect-history
  :: The semantic receipt comes from Graf, then joins immutable original task
  :: records. Preparing later work may change current project/provider state;
  :: that does not rewrite a previously committed completion.
  |=  [b=bowl:gall coding=state:loop reviews=state:review member=@ux]
  ^-  (each inspected @tas)
  ?.  ?&  =(our.b src.b)  (agent-live:guard our.b now.b %graf)
          (agent-live:guard our.b now.b %cantrip)
      ==  [%| %task-completion-owner-or-graf-unavailable]
  =/  found  (~(get by sessions.coding) member)
  ?~  found  [%| %task-completion-session-missing]
  =/  e=entry:session  u.found
  =/  records=state:campaign
    ;;(state:campaign .^(* %gx /(scot %p our.b)/viki/(scot %da now.b)/qpc/campaigns/noun))
  =/  declared  (original our.b records member)
  ?:  ?=(%| -.declared)  [%| p.declared]
  =/  kept  (retained b member)
  ?:  ?=(%| -.kept)  [%| p.kept]
  =/  receipt=receipt:kernel  p.kept
  =/  release-auth  (history-release-state b coding receipt)
  ?:  ?=(%| -.release-auth)  [%| p.release-auth]
  =/  matches=(list entry:review)
    (skim ~(val by reviews) |=(h=entry:review ?~(observed.h %.n =(acceptance.proposal.receipt (digest:accept u.observed.h)))))
  ?.  =(1 (lent matches))  [%| %task-completion-history-review-missing]
  =/  h=entry:review  (snag 0 matches)
  =/  value=(unit record:accept)
    ;;((unit record:accept) .^(* %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/candidate/(scot %ux id.candidate.h)/noun))
  ?~  value  [%| %task-completion-history-acceptance-missing]
  =/  raw=*
    .^(* %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/local-review/candidate/(scot %ux id.candidate.h)/noun)
  =/  parsed  ((soft ,(unit campaign:local-store)) raw)
  ?~  parsed  [%| %task-completion-history-local-incompatible]
  ?~  u.parsed  [%| %task-completion-local-review-missing]
  =/  local-row=campaign:local-store  u.u.parsed
  =/  captured=captured:local  [`scope.request.local-row local-row]
  =/  facts  (required e u.value h captured)
  ?:  ?=(%| -.facts)  [%| p.facts]
  =/  todo=(list *)  p.facts
  =|  actual=(list (unit *))
  =/  actual=(each (list (unit *)) @tas)
    |-  ^-  (each (list (unit *)) @tas)
    ?~  todo  [%& (flop actual)]
    =/  fact=*  i.todo
    ?:  (gth (met 3 (jam fact)) fact-limit)  [%| %task-completion-graf-fact-too-large]
    =/  present=?
      .^(? %gx /(scot %p our.b)/graf/(scot %da now.b)/contains/(scot %uw (jam fact))/noun)
    $(todo t.todo, actual [?:(present `fact ~) actual])
  ?:  ?=(%| -.actual)  [%| p.actual]
  (historical our.b p.declared e u.value h captured receipt p.actual p.release-auth)
++  prepare
  |=  [b=bowl:gall coding=state:loop reviews=state:review member=@ux]
  ^-  (each proposal:kernel @tas)
  =/  entry  (~(get by sessions.coding) member)
  ?:  ?~(entry %.n =(%complete phase.u.entry))
    =/  retained  (inspect-history b coding reviews member)
    ?:  ?=(%& -.retained)  [%& proposal.receipt.p.retained]
    ?.  =(%task-completion-retention-unconfirmed p.retained)  [%| p.retained]
    :: The outer owner inspects a just-returned inner completion before its
    :: Graf card can commit. This strict live reconstruction is not handoff.
    =/  snapshot  (read b coding reviews member)
    ?:  ?=(%| -.snapshot)  [%| p.snapshot]
    =/  witnesses  (releases b p.snapshot)
    ?:  ?=(%| -.witnesses)  [%| p.witnesses]
    =/  kept  (reconstruct-with our.b now.b p.snapshot p.witnesses)
    ?:  ?=(%| -.kept)  [%| p.kept]
    [%& proposal.p.kept]
  =/  snapshot  (read b coding reviews member)
  ?:  ?=(%| -.snapshot)  [%| p.snapshot]
  =/  witnesses  (releases b p.snapshot)
  ?:  ?=(%| -.witnesses)  [%| p.witnesses]
  (prepare-with:kernel our.b now.b p.snapshot p.witnesses)
++  inspect
  :: Handoff requires the semantic completion fact itself to be in Graf too.
  |=  [b=bowl:gall coding=state:loop reviews=state:review member=@ux]
  ^-  (each receipt:kernel @tas)
  =/  kept  (inspect-history b coding reviews member)
  ?:  ?=(%| -.kept)  [%| p.kept]
  [%& receipt.p.kept]
++  act
  |=  [b=bowl:gall coding=state:loop reviews=state:review c=command]
  ^-  change
  ?.  =(our.b src.b)  [coding ~]
  =/  entry  (~(get by sessions.coding) member.c)
  ?:  ?~(entry %.n =(%complete phase.u.entry))
    =/  kept  (prepare b coding reviews member.c)
    ?:  ?=(%| -.kept)  [coding ~[(refused:loop member.c p.kept)]]
    ?.  =(expected.c (digest:kernel p.kept))
      [coding ~[(refused:loop member.c %task-completion-proposal-changed)]]
    [coding ~]
  =/  snapshot  (read b coding reviews member.c)
  ?:  ?=(%| -.snapshot)  [coding ~[(refused:loop member.c p.snapshot)]]
  =/  s=snapshot:kernel  p.snapshot
  =/  witnesses  (releases b s)
  ?:  ?=(%| -.witnesses)  [coding ~[(refused:loop member.c p.witnesses)]]
  =/  proposed  (prepare-with:kernel our.b now.b s p.witnesses)
  ?:  ?=(%| -.proposed)  [coding ~[(refused:loop member.c p.proposed)]]
  ?.  =(expected.c (digest:kernel p.proposed))
    [coding ~[(refused:loop member.c %task-completion-proposal-changed)]]
  =/  moved  (complete-with:kernel our.b src.b now.b s p.witnesses ~)
  ?:  ?=(%| -.moved)  [coding ~[(refused:loop member.c p.moved)]]
  ?.  (retention-bounded member.c receipt.p.moved)
    [coding ~[(refused:loop member.c %task-completion-retention-too-large)]]
  =/  installed  (apply:loop b coding next.p.moved)
  =/  retained=card:agent:gall
    (poke:loop our.b %graf /qpc/native-task-completion-retain [%attest (retained-fact member.c receipt.p.moved)])
  [+.installed (weld -.installed ~[retained])]
++  peek
  |=  [b=bowl:gall coding=state:loop reviews=state:review path=path]
  ^-  (unit (unit cage))
  ?.  =(our.b src.b)  ~
  ?:  ?=([%x %native-coding %task-completion-proposal @ ~] path)
    =/  id  (slaw %ux i.t.t.t.path)
    ?~  id  [~ ~]
    ?.  =((scot %ux u.id) i.t.t.t.path)  [~ ~]
    ``noun+!>((prepare b coding reviews u.id))
  ?:  ?=([%x %native-coding %task-completion-history @ ~] path)
    =/  id  (slaw %ux i.t.t.t.path)
    ?~  id  [~ ~]
    ?.  =((scot %ux u.id) i.t.t.t.path)  [~ ~]
    ``noun+!>((inspect-history b coding reviews u.id))
  ?.  ?=([%x %native-coding %task-completion @ ~] path)  ~
  =/  id  (slaw %ux i.t.t.t.path)
  ?~  id  [~ ~]
  ?.  =((scot %ux u.id) i.t.t.t.path)  [~ ~]
  ``noun+!>((inspect b coding reviews u.id))
--
