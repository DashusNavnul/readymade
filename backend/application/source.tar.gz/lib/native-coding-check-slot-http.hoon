::  Owner-only observation of Cantrip's candidate slot. No dispatch or release.
/-  w=native-coding-worker
/+  accept=native-coding-accept, parent=native-coding-worker-owner-runtime,
    law=native-coding-worker, saved=qpc-native-app-state, guard=viki-scry-guard
|%
+$  facts  [held=ledger:accept owner=state:parent]
++  ledger
  ::  Exact supported saved generations; never search arbitrary noun axes.
  |=  raw=*
  ^-  ledger:accept
  =.  raw
    ?:  ?=([%cantrip-judge-state-v42 *] raw)
      =/  decoded  (need ((soft ,[%cantrip-judge-state-v42 legacy=* extra=* origin=*]) raw))
      ?>  =(raw decoded)
      legacy.decoded
    raw
  =/  tags=(list @tas)
    ~[%cantrip-judge-state-v41 %cantrip-judge-state-v40 %cantrip-judge-state-v39 %cantrip-judge-state-v38 %cantrip-judge-state-v37 %cantrip-judge-state-v36 %cantrip-judge-state-v35 %cantrip-judge-state-v34 %cantrip-judge-state-v33 %cantrip-judge-state-v32 %cantrip-judge-state-v31 %cantrip-judge-state-v30 %cantrip-judge-state-v29 %cantrip-judge-state-v28 %cantrip-judge-state-v27 %cantrip-judge-state-v26 %cantrip-judge-state-v25 %cantrip-judge-state-v24 %cantrip-judge-state-v23 %cantrip-judge-state-v22]
  |-  ^-  ledger:accept
  ?~  tags
    =/  decoded  (need ((soft ,[%cantrip-judge-state-v21 legacy=* held=ledger:accept]) raw))
    ?>  =(raw decoded)
    held.decoded
  =/  layer  (need ((soft ,[tag=@tas legacy=* tail=*]) raw))
  ?>  &(=(i.tags tag.layer) =(raw layer))
  $(raw legacy.layer, tags t.tags)
++  decode
  |=  [our=@p original=vase]
  ^-  facts
  =/  parts  (cantrip:saved original)
  =/  inner  (skim parts |=(p=part:saved =(%inner tag.p)))
  =/  owners  (skim parts |=(p=part:saved =(%native-coding-worker-parent-save-v2 tag.p)))
  ?>  &(?=([* ~] inner) ?=([* ~] owners))
  =/  held  (ledger data.i.inner)
  =/  decoded  (need ((soft ,[owner=state:parent execution=*]) data.i.owners))
  ?>  &(=(data.i.owners decoded) (valid:accept held) (valid:parent our owner.decoded))
  [held owner.decoded]
++  worker
  ::  A candidate id alone is not a binding to a native execution order.
  |=  [our=@p r=record:accept state=state:parent]
  ^-  json
  ?~  staging.r  ~
  =/  normal=@ux  (digest:accept [%native-coding-check-ticket-v1 r(stage %checking, reason ~)])
  =/  retry=@ux  (digest:accept [%native-coding-check-ticket-v1 r(stage %checking, reason `%candidate-recheck)])
  =/  matches=(list [@ux record:w])
    %+  skim  ~(tap by journal.owner.state)
    |=  [key=@ux job=record:w]
    =/  o=order:w  order.job
    ?&  =(`id.candidate.r (~(get by pending.state) ticket.o))
        =(our owner.pairing.o)  =(key (digest:law o))
        =(id.candidate.r candidate.o)  =(context.candidate.r context.o)
        =(grant.r grant.o)  =(revision.u.staging.r source.o)
        =((namespace-digest:law files.body.snapshot.u.staging.r) namespace.o)
        =((required:accept project.r candidate.r) targets.o)
        |(=(normal ticket.o) =(retry ticket.o))
    ==
  ?.  ?=([* ~] matches)  ~
  =/  [key=@ux job=record:w]  i.matches
  %-  pairs:enjs:format
  :~  ['request' s+(scot %ux key)]
      ['ticket' s+(scot %ux ticket.order.job)]
      ['ship' s+(scot %p worker.pairing.order.job)]
      ['sent' b+sent.job]
      ['phase' s+phase.job]
      ['resultPresent' b+?=(^ result.job)]
      ['resultReason' ?~(result.job ~ ?:(?=(%refused -.outcome.u.result.job) s+reason.outcome.u.result.job ~))]
  ==
++  unavailable
  |=  [our=@p at=@da]
  ^-  json
  (pairs:enjs:format ~[['schema' s+'native-coding-check-slot-v1'] ['owner' s+(scot %p our)] ['observedAt' s+(scot %da at)] ['available' b+%.n] ['condition' s+'unknown'] ['blockerCount' ~] ['blockers' a+~] ['truncated' b+%.n]])
++  project
  |=  [our=@p at=@da f=facts]
  ^-  json
  =/  released=(set @ux)
    ?.  engaged.owner.f  ~
    (released-checks-for:accept our at held.f journal.owner.owner.f pending.owner.f failures.owner.f)
  =/  blockers=(list [@ux record:accept])
    (skim ~(tap by held.f) |=([id=@ux r=record:accept] !(ready-with:accept (my ~[[id r]]) released)))
  =/  rows=(list json)
    %+  turn  (scag 32 blockers)
    |=  [id=@ux r=record:accept]
    %-  pairs:enjs:format
    :~  ['candidate' s+(scot %ux id)]
        ['session' s+(scot %ux session.context.candidate.r)]
        ['request' s+(scot %ux request.context.candidate.r)]
        ['stage' s+stage.r]
        ['reason' ?~(reason.r ~ s+u.reason.r)]
        ['worker' (worker our r owner.f)]
    ==
  %-  pairs:enjs:format
  :~  ['schema' s+'native-coding-check-slot-v1']
      ['owner' s+(scot %p our)]
      ['observedAt' s+(scot %da at)]
      ['available' b+%.y]
      ['condition' s+?:(=(~ blockers) 'free' 'blocked')]
      ['blockerCount' (numb:enjs:format (lent blockers))]
      ['blockers' a+rows]
      ['truncated' b+(gth (lent blockers) 32)]
  ==
++  view
  |=  [our=@p src=@p at=@da]
  ^-  json
  ::  Authenticate before even the safe metadata scry. Never probe %gx paths:
  ::  absent app paths can abort the event outside a Nock exception trap.
  ?.  &(=(our src) (agent-live:guard our at %cantrip))  (unavailable our at)
  ::  These owner-local peeks expose the live, already admitted state. Do
  ::  not replay full saved-state migration and candidate hashing per page.
  =/  held=ledger:accept
    .^(ledger:accept %gx /(scot %p our)/cantrip/(scot %da at)/native-coding/candidate-ledger/noun)
  =/  owner=state:parent
    .^(state:parent %gx /(scot %p our)/cantrip/(scot %da at)/native-coding/worker/state/noun)
  =/  observed  (mole |.((project our at [held owner])))
  ?~(observed (unavailable our at) u.observed)
--
