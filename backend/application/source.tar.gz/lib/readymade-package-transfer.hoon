::  Bounded inert source transport. Native callers alone establish authority.
/-  spider, pkg=readymade-package
/+  io=strandio, package=readymade-package, foundations=readymade-package-foundations
=,  strand=strand:spider
|%
+$  source  [file=file:pkg bytes=@t]
+$  bundle
  $:  offer=@ux
      nonce=@ux
      pin=pin:pkg
      sources=(list source)
      proof=@ux
  ==
++  supported
  |=  f=file:pkg
  ^-  ?
  &((package-path path.f) (gth size.f 0) (lte size.f 1.048.576))
++  package-path
  |=  p=path
  ^-  ?
  &((path-valid:package p) ?=(?(%hoon %js %css %html) (rear p)))
++  digest
  |=  [offer=@ux nonce=@ux pin=pin:pkg sources=(list source)]
  ^-  @ux
  (shax (jam [%readymade-package-source-proof-v1 offer nonce pin sources]))
++  valid
  |=  [o=offer:pkg b=bundle]
  ^-  ?
  ?&  (valid:package o)
      =(offer.b digest.o)
      (digest-valid:package nonce.b)
      =(pin.b source.body.o)
      =(files.body.o (turn sources.b |=(s=source file.s)))
      (levy sources.b |=(s=source &((supported file.s) =(file.s (source-file:package path.file.s bytes.s)))))
      =(proof.b (digest offer.b nonce.b pin.b sources.b))
  ==
++  seal
  |=  [o=offer:pkg nonce=@ux sources=(list source)]
  ^-  bundle
  =/  b=bundle  [digest.o nonce source.body.o sources (digest digest.o nonce source.body.o sources)]
  ?>  (valid o b)
  b
++  normalize
  ::  Do not execute donor mark conversion gates. Initial marks are atoms.
  |=  [f=file:pkg value=cage]
  ^-  (unit source)
  ?.  &((supported f) =(p.value (rear path.f)))  ~
  =/  bytes=(unit @t)  ((soft @t) q.q.value)
  ?~  bytes  ~
  ?.  =(f (source-file:package path.f u.bytes))  ~
  `[f u.bytes]
++  support-paths
  ^-  (set path)
  support-paths:foundations
++  pages
  ::  Foundation marks are recipient-local base source, never donor input.
  |=  [o=offer:pkg b=bundle kelvin=@ud marks=(map @tas @t)]
  ^-  (each (map path page:clay) @tas)
  ?.  (valid o b)  [%| %invalid-bundle]
  ?:  (lien sources.b |=(s=source (~(has in support-paths) path.file.s)))
    [%| %workspace-support-collision]
  ?.  &((gth kelvin 0) (valid:foundations marks))
    [%| %workspace-support-missing]
  =/  source-pages=(list [path page:clay])
    %+  turn  sources.b
    |=  s=source
    ^-  [path page:clay]
    =/  mark=@tas  (rear path.file.s)
    [path.file.s [mark bytes.s]]
  =/  out=(map path page:clay)
    (~(uni by (pages:foundations marks)) (malt source-pages))
  =/  bill=page:clay  [%bill ~]
  =/  out=(map path page:clay)  (~(put by out) /desk/bill bill)
  =/  kernel=page:clay  [%kelvin [%zuse kelvin]]
  =/  out=(map path page:clay)  (~(put by out) /sys/kelvin kernel)
  [%& out]
++  sing
  ::  One request, one bounded wait; timeout cancels this exact subscription.
  |=  [pin=pin:pkg nonce=@ux index=@ud care=care:clay path=path]
  =/  m  (strand ,(unit riot:clay))
  ^-  form:m
  ;<  now=@da  bind:m  get-time:io
  =/  when=@da  (add now ~s15)
  =/  sw=wire  /package/read/(scot %ux nonce)/(scot %ud index)
  =/  ww=wire  /package/wait/(scot %ux nonce)/(scot %ud index)/(scot %da when)
  ;<  ~  bind:m
    (send-raw-card:io [%pass sw %arvo %c [%warp ship.pin desk.pin `[%sing care [%ud revision.pin] path]]])
  ;<  ~  bind:m  (send-raw-card:io [%pass ww %arvo %b [%wait when]])
  ;<  answer=(unit riot:clay)  bind:m
    |=  tin=strand-input:strand
    ?+  in.tin  `[%skip ~]
        ~  `[%wait ~]
        [~ %sign * ?(%behn %clay) %writ *]
      ?.  =(sw wire.u.in.tin)  `[%skip ~]
      `[%done `+>.sign-arvo.u.in.tin]
        [~ %sign * %behn %wake *]
      ?.  =(ww wire.u.in.tin)  `[%skip ~]
      `[%done ~]
    ==
  ?^  answer
    ;<  ~  bind:m  (send-raw-card:io [%pass ww %arvo %b [%rest when]])
    (pure:m answer)
  ;<  ~  bind:m  (send-raw-card:io [%pass sw %arvo %c [%warp ship.pin desk.pin ~]])
  (pure:m ~)
++  root-match
  |=  [pin=pin:pkg answer=riot:clay]
  ^-  ?
  ?~  answer  %.n
  =/  root=(unit @uv)  ((soft @uv) q.q.r.u.answer)
  ?~  root  %.n
  =(root.pin u.root)
++  fetch
  |=  [o=offer:pkg nonce=@ux]
  =/  m  (strand ,(each bundle @tas))
  ^-  form:m
  ?.  &((valid:package o) (digest-valid:package nonce) (levy files.body.o supported))
    (pure:m [%| %unsupported-source])
  =/  pin=pin:pkg  source.body.o
  ;<  first=(unit riot:clay)  bind:m  (sing pin nonce 0 %z /)
  ?~  first  (pure:m [%| %source-timeout])
  ?.  (root-match pin u.first)  (pure:m [%| %source-root-mismatch])
  =/  todo=(list file:pkg)  files.body.o
  =/  sources=(list source)  ~
  =/  index=@ud  1
  |-  ^-  form:m
  ?^  todo
    ;<  answer=(unit riot:clay)  bind:m  (sing pin nonce index %x path.i.todo)
    ?~  answer  (pure:m [%| %source-timeout])
    ?~  u.answer  (pure:m [%| %source-absent])
    =/  source=(unit source)  (normalize i.todo r.u.u.answer)
    ?~  source  (pure:m [%| %source-file-mismatch])
    $(todo t.todo, sources [u.source sources], index +(index))
  ;<  last=(unit riot:clay)  bind:m  (sing pin nonce index %z /)
  ?~  last  (pure:m [%| %source-timeout])
  ?.  (root-match pin u.last)  (pure:m [%| %source-root-mismatch])
  (pure:m [%& (seal o nonce (flop sources))])
--
