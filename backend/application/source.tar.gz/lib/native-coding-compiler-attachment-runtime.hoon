::  Immutable owner admission and private results; no execution on reload.
::  An owner assertion binds bytes, not their compiler/source equivalence.
/-  nc=native-coding
/+  core=native-coding-compiler-attachment, compiler=native-coding-compiler,
    exports=native-coding-compiler-exports, old=native-coding-compiler-runtime,
    tools=cantrip-native-coding, project=native-coding-project
|%
+$  key  [configuration=@ux target=@tas]
+$  choice  [selection=selection:exports attachment=@ux enabled=?]
+$  retained
  [input=job:compiler selection=selection:exports attachment=@ux role=role:core profile=@ux scope=@ux fuel=@ud output=result:core]
+$  organ
  [%native-coding-compiler-attachment-state-v1 attachments=(map @ux attachment:core) revoked=(set @ux) choices=(map key choice) results=(map @ux retained)]
+$  command
  $%  [%native-coding-compiler-attachment-admit-v1 value=attachment:core]
      [%native-coding-compiler-attachment-revoke-v1 id=@ux]
      [%native-coding-compiler-attachment-select-v1 selection=selection:exports attachment=@ux]
      [%native-coding-compiler-attachment-unselect-v1 configuration=@ux target=@tas]
      [%native-coding-compiler-attachment-retain-v1 id=@ux value=retained]
  ==
++  empty  `organ`[%native-coding-compiler-attachment-state-v1 ~ ~ ~ ~]
++  capacity  32
++  key-for
  |=  s=selection:exports
  ^-  key
  [(configuration:project project.s) name.target.s]
++  scope-digest
  |=  s=scope:tools
  ^-  @ux
  (shax (jam s))
++  lookup
  |=  [s=organ j=job:compiler]
  ^-  (unit (each choice @tas))
  =/  found  (~(get by choices.s) [(configuration:project project.j) name.target.j])
  ?~  found  ~
  ?.  enabled.u.found  `[%| %compiler-attachment-selection-revoked]
  ?:  (~(has in revoked.s) attachment.u.found)  `[%| %compiler-attachment-revoked]
  ?.  (~(has by attachments.s) attachment.u.found)  `[%| %compiler-attachment-missing]
  ?.  &(=(project.j project.selection.u.found) =(target.j target.selection.u.found))
    `[%| %compiler-attachment-selection-conflict]
  `[%& u.found]
++  retained-valid
  |=  [id=@ux r=retained]
  ^-  ?
  ?.  ?&  =(id (key:tools request.input.r))  (identifier:tools id)
          (identifier:tools attachment.r)  (profile-valid:core profile.r)
          (lte (met 0 scope.r) 256)
          (lte (met 3 (jam r)) 4.194.304)
      ==  %.n
  =/  prepared  (inputs:exports input.r selection.r)
  ?.  ?=(%& -.prepared)  %.n
  (output-for:core profile.r role.r names.selection.r fuel.r output.r)
++  linked
  ::  Revocation does not invalidate the exact historical scope commitment.
  |=  [jobs=organ:tools id=@ux r=retained]
  ^-  ?
  ?.  (retained-valid id r)  %.n
  =/  job  (~(get by records.jobs) id)
  ?~  job  %.n
  ?.  =(request.input.r request.u.job)  %.n
  =/  grant  (~(get by grants.jobs) grant.u.job)
  ?~  grant  %.n
  &(=(project.input.r project.grant.u.grant) =(scope.r (scope-digest u.grant(revoked ~))))
++  valid
  |=  [our=@p s=organ jobs=organ:tools]
  ^-  ?
  ?.  ?&  (lte ~(wyt by attachments.s) 8)
          (lte ~(wyt by choices.s) 128)
          (lte ~(wyt by results.s) capacity)
          (lte ~(wyt in revoked.s) 8)
          (levy ~(tap by attachments.s) |=([id=@ux a=attachment:core] &(=(id digest.a) (valid:core a))))
          (levy ~(tap in revoked.s) |=(id=@ux (~(has by attachments.s) id)))
      ==  %.n
  ?.  %+  levy  ~(tap by choices.s)
      |=  [k=key c=choice]
      ?&  =(k (key-for selection.c))  (selection-valid:exports selection.c)
          =(our authority.spec.project.selection.c)
          (~(has by attachments.s) attachment.c)
      ==
    %.n
  %+  levy  ~(tap by results.s)
  |=  [id=@ux r=retained]
  =/  held  (~(get by attachments.s) attachment.r)
  =/  chosen  (~(get by choices.s) (key-for selection.r))
  ?~  held  %.n
  ?~  chosen  %.n
  ?.  ?&  =(role.r role.u.held)  =(attachment.r attachment.u.chosen)
          =(selection.r selection.u.chosen)  (linked jobs id r)
      ==  %.n
  =/  prepared  (inputs:core u.held input.r selection.r)
  ?=(%& -.prepared)
++  act
  |=  [b=bowl:gall s=organ jobs=organ:tools c=command]
  ^-  (each organ @tas)
  ?.  =(our.b src.b)  [%| %compiler-attachment-owner-required]
  ?:  ?=(%native-coding-compiler-attachment-admit-v1 -.c)
    ?.  (valid:core value.c)  [%| %compiler-attachment-invalid]
    =/  found  (~(get by attachments.s) digest.value.c)
    ?^  found
      ?.  =(u.found value.c)  [%| %compiler-attachment-conflict]
      ?:  (~(has in revoked.s) digest.value.c)  [%| %compiler-attachment-revoked]
      [%& s]
    ?:  (gte ~(wyt by attachments.s) 8)  [%| %compiler-attachment-capacity]
    [%& s(attachments (~(put by attachments.s) digest.value.c value.c))]
  ?:  ?=(%native-coding-compiler-attachment-revoke-v1 -.c)
    ?.  (~(has by attachments.s) id.c)  [%| %compiler-attachment-missing]
    [%& s(revoked (~(put in revoked.s) id.c))]
  ?:  ?=(%native-coding-compiler-attachment-unselect-v1 -.c)
    =/  k=key  [configuration.c target.c]
    =/  found  (~(get by choices.s) k)
    ?~  found  [%| %compiler-attachment-selection-missing]
    [%& s(choices (~(put by choices.s) k u.found(enabled %.n)))]
  ?:  ?=(%native-coding-compiler-attachment-select-v1 -.c)
    ?.  &(=(our.b authority.spec.project.selection.c) (selection-valid:exports selection.c))
      [%| %compiler-attachment-selection-invalid]
    ?.  (~(has by attachments.s) attachment.c)  [%| %compiler-attachment-missing]
    ?:  (~(has in revoked.s) attachment.c)  [%| %compiler-attachment-revoked]
    =/  k=key  (key-for selection.c)
    =/  incoming=choice  [selection.c attachment.c %.y]
    =/  found  (~(get by choices.s) k)
    ?^  found
      ?:  =(u.found incoming)  [%& s]
      [%| %compiler-attachment-selection-immutable]
    ?:  (gte ~(wyt by choices.s) 128)  [%| %compiler-attachment-selection-capacity]
    ?:  (lien ~(val by records.jobs) |=(r=record:tools &(=(configuration.k configuration.context.request.r) ?=(?(%compile %check) -.arguments.request.r) ?=(?(%running %unknown) stage.r))))
      [%| %compiler-attachment-selection-busy]
    ?.  (registered:old our.b now.b project.selection.c)
      [%| %compiler-attachment-project-unregistered]
    =/  catalog  (catalog:project our.b now.b project.selection.c)
    ?:  ?=(%| -.catalog)  [%| p.catalog]
    [%& s(choices (~(put by choices.s) k incoming))]
  =/  r=retained  value.c
  =/  prior  (~(get by results.s) id.c)
  ?^  prior
    ?:  =(u.prior r)  [%& s]
    [%| %compiler-attachment-retention-conflict]
  ::  Historical v1 results remain readable; new execution uses only v2.
  ?.  =(profile.r profile-id-v2:core)  [%| %compiler-attachment-execution-version]
  ?:  (gte ~(wyt by results.s) capacity)  [%| %compiler-attachment-result-capacity]
  ?.  (retained-valid id.c r)  [%| %compiler-attachment-evidence-invalid]
  =/  chosen  (lookup s input.r)
  ?~  chosen  [%| %compiler-attachment-selection-missing]
  ?:  ?=(%| -.u.chosen)  [%| p.u.chosen]
  ?.  &(=(selection.r selection.p.u.chosen) =(attachment.r attachment.p.u.chosen))
    [%| %compiler-attachment-selection-mismatch]
  =/  held  (~(get by attachments.s) attachment.r)
  ?~  held  [%| %compiler-attachment-missing]
  ?.  =(role.r role.u.held)  [%| %compiler-attachment-role-mismatch]
  =/  prepared  (inputs:core u.held input.r selection.r)
  ?:  ?=(%| -.prepared)  [%| p.prepared]
  =/  job  (~(get by records.jobs) id.c)
  ?~  job  [%| %compiler-attachment-admission-missing]
  ?.  &(=(%running stage.u.job) =(request.input.r request.u.job))
    [%| %compiler-attachment-admission-mismatch]
  =/  grant  (~(get by grants.jobs) grant.u.job)
  ?~  grant  [%| %compiler-attachment-grant-missing]
  ?.  &(=(project.input.r project.grant.u.grant) =(scope.r (scope-digest u.grant)))
    [%| %compiler-attachment-scope-mismatch]
  =/  allowed  (allowed:tools our.b now.b u.grant request.input.r)
  ?:  ?=(%| -.allowed)  [%| p.allowed]
  ?.  (pending:tools our.b now.b request.input.r)  [%| %compiler-attachment-not-pending]
  =/  exact  (prepare:compiler our.b now.b project.input.r request.input.r)
  ?:  ?=(%| -.exact)  [%| p.exact]
  ?.  =(input.r p.exact)  [%| %compiler-attachment-source-mismatch]
  [%& s(results (~(put by results.s) id.c r))]
++  report
  |=  r=retained
  ^-  tool-output:nc
  ?.  (retained-valid (key:tools request.input.r) r)
    [%refused %compiler-attachment-evidence-invalid 'The attachment result is invalid.']
  =/  refs=(list @ux)
    ~[(identity:compiler input.r) attachment.r profile.r scope.r (selection-id:exports selection.r) (shax (jam output.r))]
  =/  out=result:core  output.r
  =/  detail=@t
    ?:  ?=(%| -.out)
      (cat 3 'Admitted compiler refused: ' `@t`reason.p.out)
    ?:  =(%checked-exports role.r)
      'Checked-entry output retained as unverified PLAN data. Owner admission does not certify source equivalence or a passing native check.'
    'Compiler exports retained as unchecked PLAN data. No execution, installation or passing check is implied.'
  [%diagnostics ~[[%gallowglass %.n detail source.context.request.input.r refs]]]
--
