::  Cantrip-owned selection/result journal. Reuses its existing assembly seed.
::  Configuration is operator-only, immutable until explicit revocation.
/-  nc=native-coding
/+  core=native-coding-compiler-exports, compiler=native-coding-compiler,
    assembly=native-coding-terminal-assembly, old=native-coding-compiler-runtime,
    tools=cantrip-native-coding, project=native-coding-project,
    profile=native-coding-compiler-profile
|%
+$  key  [configuration=@ux target=@tas]
+$  choice  [selection=selection:core enabled=?]
+$  retained
  [input=job:compiler selection=selection:core seed=@ux profile=@ux scope=@ux fuel=@ud output=result:core]
+$  organ
  [%native-coding-compiler-exports-state-v1 choices=(map key choice) results=(map @ux retained)]
+$  command
  $%  [%native-coding-compiler-exports-configure-v1 project=project:nc target=@tas names=(list @t)]
      [%native-coding-compiler-exports-revoke-v1 configuration=@ux target=@tas]
      [%native-coding-compiler-exports-retain-v1 id=@ux value=retained]
  ==
++  empty  `organ`[%native-coding-compiler-exports-state-v1 ~ ~]
++  capacity  32
++  key-for
  |=  s=selection:core
  ^-  key
  [(configuration:project project.s) name.target.s]
++  scope-digest
  |=  s=scope:tools
  ^-  @ux
  (shax (jam s))
++  lookup
  ::  Absence selects the historical compiler path. Revocation/conflict does
  ::  not fall back or quietly choose different export names.
  |=  [s=organ j=job:compiler]
  ^-  (unit (each selection:core @tas))
  =/  found  (~(get by choices.s) [(configuration:project project.j) name.target.j])
  ?~  found  ~
  ?.  enabled.u.found  `[%| %compiler-export-selection-revoked]
  ?.  &(=(project.j project.selection.u.found) =(target.j target.selection.u.found))
    `[%| %compiler-export-selection-conflict]
  `[%& selection.u.found]
++  retained-valid
  |=  [id=@ux r=retained]
  ^-  ?
  ?.  ?&  =(id (key:tools request.input.r))  (identifier:tools id)
          (identifier:tools seed.r)  =(profile.r identity:profile)
          (lte (met 0 scope.r) 256)  (gte fuel.r 1)  (lte fuel.r 2.000.000)
          (lte (met 3 (jam r)) byte-limit:core)
      ==  %.n
  =/  input  (inputs:core input.r selection.r)
  ?:  ?=(%| -.input)  %.n
  =/  out=result:core  output.r
  ?:  ?=(%| -.out)
    &(!=(0 reason.p.out) (lte (met 3 reason.p.out) 128) (lte code.p.out 65.535) (lte (met 3 module.p.out) 128) (lte (met 3 symbol.p.out) 128))
  (artifact-valid:core input.r selection.r seed.r fuel.r p.out)
++  linked
  ::  Historical joins survive grant revocation; this gate grants no new work.
  |=  [jobs=organ:tools id=@ux r=retained]
  ^-  ?
  ?.  (retained-valid id r)  %.n
  =/  job  (~(get by records.jobs) id)
  ?~  job  %.n
  ?.  =(request.input.r request.u.job)  %.n
  =/  scope  (~(get by grants.jobs) grant.u.job)
  ?~  scope  %.n
  &(=(project.input.r project.grant.u.scope) =(scope.r (scope-digest u.scope(revoked ~))))
++  valid
  |=  [our=@p s=organ seed=(unit seed:assembly) jobs=organ:tools]
  ^-  ?
  ?.  &((lte ~(wyt by choices.s) 128) (lte ~(wyt by results.s) capacity))  %.n
  ?.  (levy ~(tap by choices.s) |=([k=key c=choice] &(=(k (key-for selection.c)) (selection-valid:core selection.c) =(our authority.spec.project.selection.c))))  %.n
  ?:  =(~ results.s)  %.y
  ?~  seed  =(~ results.s)
  ?.  &((seed-valid:assembly u.seed) (profiled-seed:assembly u.seed))  %.n
  %+  levy  ~(tap by results.s)
  |=  [id=@ux r=retained]
  =/  chosen  (~(get by choices.s) (key-for selection.r))
  ?~  chosen  %.n
  &(=(selection.r selection.u.chosen) =(seed.r digest.u.seed) (linked jobs id r))
++  act
  |=  [b=bowl:gall s=organ jobs=organ:tools seed=(unit seed:assembly) c=command]
  ^-  (each organ @tas)
  ?.  =(our.b src.b)  [%| %compiler-export-owner-required]
  ?:  ?=(%native-coding-compiler-exports-revoke-v1 -.c)
    =/  found  (~(get by choices.s) [configuration.c target.c])
    ?~  found  [%| %compiler-export-selection-missing]
    [%& s(choices (~(put by choices.s) [configuration.c target.c] u.found(enabled %.n)))]
  ?:  ?=(%native-coding-compiler-exports-configure-v1 -.c)
    =/  targets=(list build-target:nc)
      (skim targets.project.c |=(t=build-target:nc =(target.c name.t)))
    ?.  =(1 (lent targets))  [%| %compiler-export-target-missing]
    =/  selected=selection:core  [project.c (snag 0 targets) names.c]
    ?.  &(=(our.b authority.spec.project.c) (selection-valid:core selected))
      [%| %compiler-export-selection-invalid]
    =/  k=key  (key-for selected)
    =/  found  (~(get by choices.s) k)
    ?^  found
      ?.  &(enabled.u.found =(selected selection.u.found))
        [%| %compiler-export-selection-immutable]
      [%& s]
    ?:  (gte ~(wyt by choices.s) 128)  [%| %compiler-export-selection-capacity]
    ?:  (lien ~(val by records.jobs) |=(r=record:tools &(=(configuration.k configuration.context.request.r) ?=(?(%compile %check) -.arguments.request.r) ?=(?(%running %unknown) stage.r))))
      [%| %compiler-export-configuration-busy]
    ?.  (registered:old our.b now.b project.c)  [%| %compiler-export-project-unregistered]
    =/  catalog  (catalog:project our.b now.b project.c)
    ?:  ?=(%| -.catalog)  [%| p.catalog]
    [%& s(choices (~(put by choices.s) k [selected %.y]))]
  =/  r=retained  value.c
  =/  prior  (~(get by results.s) id.c)
  ?^  prior
    ?:  =(u.prior r)  [%& s]
    [%| %compiler-export-retention-conflict]
  ?:  (gte ~(wyt by results.s) capacity)  [%| %compiler-export-capacity]
  ?.  (retained-valid id.c r)  [%| %compiler-export-evidence-invalid]
  ?~  seed  [%| %compiler-export-seed-missing]
  ?.  &((seed-valid:assembly u.seed) (profiled-seed:assembly u.seed) =(digest.u.seed seed.r))
    [%| %compiler-export-seed-mismatch]
  =/  chosen  (lookup s input.r)
  ?~  chosen  [%| %compiler-export-selection-missing]
  ?:  ?=(%| -.u.chosen)  [%| p.u.chosen]
  ?.  =(selection.r p.u.chosen)  [%| %compiler-export-selection-mismatch]
  =/  job  (~(get by records.jobs) id.c)
  ?~  job  [%| %compiler-export-admission-missing]
  ?.  &(=(%running stage.u.job) =(request.input.r request.u.job))
    [%| %compiler-export-admission-mismatch]
  =/  scope  (~(get by grants.jobs) grant.u.job)
  ?~  scope  [%| %compiler-export-grant-missing]
  ?.  &(=(project.input.r project.grant.u.scope) =(scope.r (scope-digest u.scope)))
    [%| %compiler-export-scope-mismatch]
  =/  allowed  (allowed:tools our.b now.b u.scope request.input.r)
  ?:  ?=(%| -.allowed)  [%| p.allowed]
  ?.  (pending:tools our.b now.b request.input.r)  [%| %compiler-export-request-not-pending]
  =/  exact  (prepare:compiler our.b now.b project.input.r request.input.r)
  ?:  ?=(%| -.exact)  [%| p.exact]
  ?.  =(input.r p.exact)  [%| %compiler-export-frozen-source-mismatch]
  [%& s(results (~(put by results.s) id.c r))]
++  report
  |=  r=retained
  ^-  tool-output:nc
  ?.  (retained-valid (key:tools request.input.r) r)
    [%refused %compiler-export-evidence-invalid 'The retained export evidence is invalid.']
  =/  refs=(list @ux)  ~[(identity:compiler input.r) seed.r profile.r scope.r (selection-id:core selection.r)]
  =/  out=result:core  output.r
  ?:  ?=(%| -.out)
    [%diagnostics ~[[%gallowglass %.n (cat 3 'Named export compilation refused: ' `@t`reason.p.out) source.context.request.input.r refs]]]
  [%diagnostics ~[[%gallowglass %.n 'Named PLAN exports retained as unchecked data. No passing type check, execution or installation is implied.' source.context.request.input.r [digest.p.out refs]]]]
--
