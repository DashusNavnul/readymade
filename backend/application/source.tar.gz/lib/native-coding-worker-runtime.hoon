::  Worker transport identities and retained execution invariants.
/-  r=native-coding-worker-runtime, w=native-coding-worker, b=boks, g=grav,
    nc=native-coding, x=native-coding-worker-work-v3
/+  law=native-coding-worker, work=native-coding-worker-work-v3,
    bl=boks, guard=viki-scry-guard
|%
::  A lifetime store, never evicted; at this ceiling new orders drop silently.
::  128 ran out on 2026-11-02, a job at a time, 18 tasks in.
++  capacity  1.024
++  empty  ^-(state:r [%native-coding-worker-state-v2 ~ ~])
++  load-state
  ::  Preserve the whole v1 payload; only the outer schema tag changes.
  ::  The caller validates it and applies the usual no-replay reload rule.
  |=  raw=*
  ^-  (unit state:r)
  =/  current  ((soft state:r) raw)
  ?^  current  ?:(=(raw u.current) current ~)
  =/  old  ((soft legacy-state:r) raw)
  ?~  old  ~
  ?.  =(raw u.old)  ~
  `[%native-coding-worker-state-v2 pairing.u.old jobs.u.old]
++  wire-for
  |=  [key=@ux kind=@tas]
  ^-  wire
  /native-worker/(scot %ux key)/[kind]
++  offer-path
  |=(key=@ux ^-(path /native-coding/worker/order/(scot %ux key)))
++  tool-offer-path
  |=(key=@ux ^-(path /native-coding/worker/tool-order/(scot %ux key)))
++  tool-v3-offer-path
  |=(key=@ux ^-(path /native-coding/worker/tool-order-v3/(scot %ux key)))
++  offer-path-for
  |=  [key=@ux ingress=admitted:b]
  ^-  path
  ?:  (tool-v3-ingress ingress)  (tool-v3-offer-path key)
  ?:  (tool-ingress ingress)  (tool-offer-path key)
  (offer-path key)
++  result-path  |=(key=@ux ^-(path /result/(scot %ux key)))
++  held
  |=  [b=bowl:gall wire=wire peer=@p app=@tas pax=path]
  ^-  ?
  =/  found  (~(get by wex.b) [wire peer app])
  ?~  found  %.n
  &(-.u.found =(pax +.u.found))
++  active
  |=  j=job:r
  ^-  ?
  ?=(~ result.j)
++  busy
  |=(s=state:r ^-(? (lien ~(val by jobs.s) active)))
++  key
  |=  ingress=admitted:b
  ^-  (unit @ux)
  ?.  ?=(%task -.payload.body.envelope.ingress)  ~
  =/  id=@t  task-id.request.payload.body.envelope.ingress
  =/  prefix=@t
    ?:  (tool-v3-ingress ingress)  'native-hoon-tool-v3-'
    ?:((tool-ingress ingress) 'native-hoon-tool-' 'native-hoon-build-')
  ?.  =(prefix (end [3 (met 3 prefix)] id))  ~
  =/  parsed  (slaw %ux (rsh [3 (met 3 prefix)] id))
  ?~  parsed  ~
  ?.  (identifier:law u.parsed)  ~
  ?.  =(id (cat 3 prefix (scot %ux u.parsed)))  ~
  parsed
++  tool-v3-ingress
  |=  ingress=admitted:b
  ^-  ?
  ?.  ?=(%task -.payload.body.envelope.ingress)  %.n
  =/  prefix=@t  'native-hoon-tool-v3-'
  =(prefix (end [3 (met 3 prefix)] task-id.request.payload.body.envelope.ingress))
++  tool-ingress
  |=  ingress=admitted:b
  ^-  ?
  ?.  ?=(%task -.payload.body.envelope.ingress)  %.n
  =/  prefix=@t  'native-hoon-tool-'
  =(prefix (end [3 (met 3 prefix)] task-id.request.payload.body.envelope.ingress))
++  ingress-valid
  |=  [p=pairing:w ingress=admitted:b now=@da]
  ^-  ?
  ?&  (pairing-valid:law p)  =(source.ingress owner.p)
      (envelope-valid:bl envelope.ingress)
      =(worker.p recipient.body.envelope.ingress)
      =('juggler-native-v1' sender-session.body.envelope.ingress)
      =('juggler-native-v1' recipient-session.body.envelope.ingress)
      ?=(^ (key ingress))
      (lte received-at.ingress now)
      (lth now expires-at.body.envelope.ingress)
  ==
++  offer-valid
  |=  [p=pairing:w ingress=admitted:b offer=work-offer:r]
  ^-  ?
  =/  d=descriptor:x  (describe:work order.offer)
  =/  decision=@ux
    ?:  ?=(%native-coding-worker-offer-v1 -.offer)  decision.order.offer
    admission.order.offer
  ?&  =(p pairing.order.offer)
      (ingress-matches:work order.offer ingress received-at.ingress)
      =(owner.p owner.export.offer)  =(1 number.export.offer)
      !=(0 desk.export.offer)  !=(0 root.export.offer)  !=(0 commit.export.offer)
      !=(desk.source.d desk.export.offer)
      =(admission.offer [%admitted decision (digest:work order.offer) deadline.d])
  ==
++  permitted
  ::  The acknowledged parent watch is live authority, not a cached payload.
  |=  [b=bowl:gall s=state:r key=@ux j=job:r]
  ^-  ?
  ?~  pairing.s  %.n
  ?~  offer.j  %.n
  =/  o=work-offer:r  u.offer.j
  ?.  &((offer-valid u.pairing.s ingress.j o) =(key (digest:work order.o)))  %.n
  =/  d=descriptor:x  (describe:work order.o)
  ?.  =(`toolchain.pairing.order.o (toolchain b))  %.n
  ?.  &((lte issued.d now.b) (lth now.b deadline.d))  %.n
  (held b (wire-for key %order) owner.u.pairing.s %cantrip (offer-path-for key ingress.j))
++  task-read
  |=  [b=bowl:gall o=order:x]
  ^-  (unit record:g)
  ?.  (agent-live:guard our.b now.b %grav)  ~
  =/  raw=*
    .^(* %gx /(scot %p our.b)/grav/(scot %da now.b)/task/[(task-id:work o)]/noun)
  =/  parsed  ((soft (unit record:g)) raw)
  ?~  parsed  ~
  ?.  =(raw u.parsed)  ~
  u.parsed
++  authorized
  |=  [b=bowl:gall s=state:r key=@ux j=job:r]
  ^-  ?
  ?.  (permitted b s key j)  %.n
  ?~  offer.j  %.n
  =/  seen  (task-read b order.u.offer.j)
  ?~  seen  %.n
  (grav-ready:work order.u.offer.j u.seen now.b)
++  admission-cards
  ::  A task may arrive after its watch. Fill only missing fields of the
  ::  exact task; never replace a binding, refusal or different admission.
  |=  [our=@p now=@da offer=work-offer:r seen=(unit record:g)]
  ^-  (list card:agent:gall)
  ?~  seen  ~
  =/  o=order:x  order.offer
  =/  d=descriptor:x  (describe:work o)
  =/  task=@t  (task-id:work o)
  =/  key=@ux  (digest:work o)
  =/  decision=@ux
    ?:  ?=(%native-coding-worker-order-v1 -.o)  decision.o
    admission.o
  =/  binding=binding:g
    ?:  ?=(%native-coding-worker-order-v1 -.o)
      [%grav-binding-v1 'juggler-native-v1' owner.pairing.o 'juggler-native-v1' project.context.o 'native-hoon' %native-coding-worker %native-coding-worker-v1]
    ?:  ?=(%native-coding-worker-order-v3 -.o)
      [%grav-binding-v1 'juggler-native-v1' owner.pairing.o 'juggler-native-v1' project.context.request.purpose.o 'native-hoon' %native-coding-worker %native-coding-worker-v3]
    [%grav-binding-v1 'juggler-native-v1' owner.pairing.o 'juggler-native-v1' project.context.request.purpose.o 'native-hoon' %native-coding-worker %native-coding-worker-v2]
  ?.  ?&  (order-valid:work o)  =(our worker.pairing.o)
          (lte issued.d now)  (lth now deadline.d)
          =(admission.offer [%admitted decision key deadline.d])
          =(request.u.seen (task:work o))
          =(source.u.seen owner.pairing.o)
          =(source-envelope.u.seen digest:(envelope:work o))
          =(overall-deadline.u.seen deadline.d)
          ?=(?(%queued %claimed %authorized) phase.u.seen)
          =(~ release.u.seen)  =(~ model-request.u.seen)
          ?~(binding.u.seen %.y =(u.binding.u.seen binding))
          |(?=(%pending -.admission.u.seen) =(admission.u.seen admission.offer))
      ==  ~
  %+  weld
    ?~  binding.u.seen
      ~[[%pass (wire-for key %bind) %agent [our %grav] %poke %noun !>(`local-action:g`[%bind task binding])]]
    ~
  ?:  ?=(%pending -.admission.u.seen)
    ~[[%pass (wire-for key %admit) %agent [our %grav] %poke %noun !>(`input:g`[%cantrip task admission.offer])]]
  ~
++  toolchain
  ::  Bind selection to this app's complete native source namespace and the
  ::  current kernel source. A code update requires explicit owner selection.
  |=  b=bowl:gall
  ^-  (unit toolchain:w)
  =/  ds=cone:clay  .^(cone:clay %cx /(scot %p our.b)//(scot %da now.b)/domes)
  =/  base  (~(get by ds) [our.b %base])
  =/  host  (~(get by ds) [our.b q.byk.b])
  ?~  base  ~
  ?~  host  ~
  =/  base-commit  (~(get by hit.u.base) let.u.base)
  =/  host-commit  (~(get by hit.u.host) let.u.host)
  ?~  base-commit  ~
  ?~  host-commit  ~
  =/  kernel=yaki:clay
    .^(yaki:clay %cs /(scot %p our.b)/base/(scot %ud let.u.base)/yaki/(scot %uv u.base-commit))
  =/  executor=yaki:clay
    .^(yaki:clay %cs /(scot %p our.b)/(scot %tas q.byk.b)/(scot %ud let.u.host)/yaki/(scot %uv u.host-commit))
  =/  paths=(list path)  ~[/sys/hoon/hoon /sys/zuse/hoon /sys/lull/hoon /sys/vane/clay/hoon]
  ?.  (levy paths |=(pax=path (~(has by q.kernel) pax)))  ~
  =/  hashes=(list lobe:clay)
    (turn paths |=(pax=path (~(got by q.kernel) pax)))
  `[(digest:law [%native-worker-kernel-v1 hashes]) (digest:law [%native-worker-executor-v1 q.executor])]
++  bounded-runtime
  ::  This runtime honours a soft %jinx budget: the finite probe must time
  ::  out, never return. An old runtime ignores the hint and returns 1.
  ^-  ?
  =/  probe=tone
    (mink [0 [11 [%jinx [1 [%soft 1]]] [4 [1 0]]]] ~)
  ?.  ?=(%2 -.probe)  %.n
  ?~  trace.probe  %.n
  =([%mean 'evaluation-budget-exceeded'] i.trace.probe)
++  protocols
  ::  Pure: %bounded-evaluation-v1 is advertised exactly when the runtime has
  ::  the budget; owners refuse budget-needing orders up front without it.
  ^-  (set @tas)
  =/  base=(list @tas)  ~[%native-coding-worker-v1 %native-coding-worker-v2 %native-coding-worker-v3]
  (silt ?.(bounded-runtime base [%bounded-evaluation-v1 base]))
++  capabilities
  |=  [b=bowl:gall s=state:r]
  ^-  capabilities:r
  [%native-coding-worker-capabilities-v1 pairing.s (toolchain b) protocols]
++  retain
  |=  [value=result:x revoked=?]
  ^-  completion:r
  ?:  ?=(%native-coding-worker-result-v3 -.value)
    [%native-coding-worker-completion-v3 value revoked]
  ?>  !revoked
  value
++  original-result
  |=  value=completion:r
  ^-  result:x
  ?:  ?=(%native-coding-worker-completion-v3 -.value)  value.value
  value
++  public-result
  ::  This is the sole outward result projection. Revocation evidence is
  ::  terminal refusal; original success remains only in the owner-only state.
  |=  saved=(unit completion:r)
  ^-  (unit result:x)
  ?~  saved  ~
  =/  value=completion:r  u.saved
  ?.  ?=(%native-coding-worker-completion-v3 -.value)  `value
  ?.  revoked.value  `value.value
  `value.value(outcome [%refused %worker-completion-authority-changed 'Authority changed before completion publication; original completion is retained privately.'])
++  refresh-completion
  ::  A later authenticated watch cannot replay success after revocation.
  ::  Refusal remains readable by the original ingress owner.
  |=  [b=bowl:gall s=state:r key=@ux j=job:r]
  ^-  job:r
  ?~  result.j
    ?~  offer.j  j
    =/  o=work-offer:r  u.offer.j
    =/  d=descriptor:x  (describe:work order.o)
    ?.  ?&  (offer-valid pairing.order.o ingress.j o)
            =(key (digest:work order.o))
            =(our.b worker.pairing.order.o)
            (gte now.b deadline.d)
        ==
      j
    ::  The operation's deadline ended; its effects remain unconfirmed.
    ::  This is terminal refusal, never evidence that execution did not occur.
    (refuse our.b now.b j %worker-deadline-unconfirmed)
  =/  retained=completion:r  u.result.j
  ?.  ?=(%native-coding-worker-completion-v3 -.retained)  j
  ?:  ?=([%refused %worker-deadline-unconfirmed *] outcome.value.retained)  j
  ?:  revoked.retained  j
  ?:  (authorized b s key j)  j
  j(result `retained(revoked %.y), phase %refused, reason `%worker-completion-authority-changed)
++  fact
  |=  [key=@ux result=(unit $%(result:x completion-v3:r))]
  ^-  card:agent:gall
  =/  public=(unit result:x)
    ?~  result  ~
    ?:  ?=(%native-coding-worker-completion-v3 -.u.result)
      (public-result `u.result)
    `u.result
  [%give %fact ~[(result-path key)] %noun !>(public)]
++  refuse
  |=  [our=@p now=@da j=job:r reason=@tas]
  ^-  job:r
  ?~  offer.j  j(phase %unknown, reason `reason)
  =/  o=order:x  order.u.offer.j
  =/  result=result:x
    ?:  ?=(%native-coding-worker-order-v3 -.o)
      :*  %native-coding-worker-result-v3
          (digest:work o)  our  generation.pairing.o  toolchain.pairing.o
          source.o  namespace.o  local.j
          issued.o  now  [%refused reason (scot %tas reason)]
      ==
    ?:  ?=(%native-coding-worker-order-v2 -.o)
      :*  %native-coding-worker-result-v2
          (digest:work o)  our  generation.pairing.o  toolchain.pairing.o
          source.o  namespace.o  local.j
          issued.o  now  [%refused reason (scot %tas reason)]
      ==
    :*  %native-coding-worker-result-v1
        (digest:law o)  our  generation.pairing.o  toolchain.pairing.o
        source.o  namespace.o  local.j
        issued.o  now  [%refused reason (scot %tas reason)]
    ==
  j(phase %refused, result `(retain result %.n), reason `reason)
++  valid
  |=  [our=@p s=state:r]
  ^-  ?
  ?&  (lte ~(wyt by jobs.s) capacity)
      ?~(pairing.s %.y &((pairing-valid:law u.pairing.s) =(our worker.u.pairing.s)))
      (lte (lent (skim ~(val by jobs.s) active)) 1)
      %+  levy  ~(tap by jobs.s)
      |=  [id=@ux j=job:r]
      ?&  =(`id (key ingress.j))
          (envelope-valid:bl envelope.ingress.j)
          ?~  offer.j  &(=(~ local.j) =(~ result.j) ?=(?(%awaiting %unknown) phase.j))
          =/  o=order:x  order.u.offer.j
          ?&  =(id (digest:work o))  =(our worker.pairing.o)
              (offer-valid pairing.o ingress.j u.offer.j)
              ?~(local.j %.y &(=(our owner.u.local.j) (gth number.u.local.j 0)))
              ?:(=(%executing phase.j) ?=(^ local.j) %.y)
              ?~  result.j  ?=(?(%awaiting %importing %executing %unknown) phase.j)
              =/  completion=completion:r  u.result.j
              =/  original=result:x  (original-result completion)
              =/  public=result:x  (need (public-result result.j))
              ?&  =(?=(%native-coding-worker-order-v3 -.o) ?=(%native-coding-worker-completion-v3 -.completion))
                  (result-matches:work o original)  (result-matches:work o public)
                  =(local.j local.original)
                  =(phase.j ?:(?=(%refused -.outcome.public) %refused %checked))
                  ?:  ?=(%native-coding-worker-completion-v3 -.completion)
                    =(revoked.completion =(`%worker-completion-authority-changed reason.j))
                  %.y
              ==
          ==
      ==
  ==
++  reload
  |=  s=state:r
  ^-  state:r
  ::  An already recorded unknown keeps its original reason and evidence.
  s(jobs (~(run by jobs.s) |=(j=job:r ?:(&((active j) !=(%unknown phase.j)) j(phase %unknown, reason `%worker-reload-unconfirmed) j))))
--
