::  /lib/juggler-gravity.hoon  -- THE JUGGLER OF GRAVITY (the unbuilt frontier).
::
::  Duchamp's Juggler/Handler of Gravity: the balance-keeper. Here it is the
::  QUARANTINE that stands between the Bachelors' labor and the Bride's canon.
::  A Bachelor (a bound worker session on a moon, driven by the Waterfall) sends
::  its output here. The Juggler does NOT trust the moon's self-report -- it
::  INDEPENDENTLY re-derives the verdict from the same pure law the moon was
::  bound by: is the proposed act admissible in the assigned pataphysics
::  (regime), and is every cited operator computed (honesty)? This is the
::  gravity -- output is pulled back to what the law admits, on a DIFFERENT ship
::  from the one that produced it, before it can ever touch the sovereign canon.
::
::  Pure: no ship effects. app/juggler-review (on the comet) wraps this; the
::  cycle (lib/glass-cycle) routes submissions through it.
::
/+  regime, nick-ops
|%
::  what a Bachelor submits to the quarantine: its claimed working context plus
::  the output it produced under that context.
+$  submission
  $:  worker=@p                     ::  the moon that produced this
      lease-id=@t                   ::  the lease it worked under
      =regime:regime                ::  the assigned pataphysics
      move=@tas                     ::  the regime act it proposes
      calls=(list @tas)             ::  the operators it cited
      output=@t                     ::  the work itself
  ==
::  the Juggler's verdict: accept, or reject WITH a reason the Bride can act on.
+$  verdict  [accepted=? code=@tas reason=@t worker=@p]
::  a GROW submission: a Bachelor's typed choice (name + composition steps
::  over the ship's computed evaluators) plus the source the planet claims is
::  its canonical render.  The comet re-derives all of it from law
::  (re-derive:glass-grow) -- it never trusts the planet's render.
+$  grow-sub
  $:  worker=@p                       ::  the moon whose turn chose this
      lease-id=@t                     ::  the lease it worked under
      name=@tas                       ::  the grown arm's name
      steps=(list @tas)               ::  the composition choice
      src=@t                          ::  the claimed canonical render
  ==
::  the ship-shell vocabulary app/juggler-review speaks over Ames.  every word
::  is INERT DATA: a submission goes out, a verdict comes back; no authority
::  crosses in either direction.
+$  action
  $%  [%set-juggler who=@p]           ::  planet, self-only: name the comet
      [%dispatch sub=submission]      ::  planet, self-only: send to the comet
      ::  phase-16 CORRELATION: the quarantine hop carries a review-id the
      ::  planet minted at dispatch and the comet ECHOES back. A verdict that
      ::  does not answer an outstanding rid is refused at the dock -- forged
      ::  and replayed verdicts die even from the named comet.
      [%submit rid=@t sub=submission]      ::  comet: a Bachelor's output arrives
      [%dispatch-grow gs=grow-sub]         ::  planet, self-only: send grown code out
      [%submit-grow rid=@t gs=grow-sub]    ::  comet: grown code arrives for judgment
      [%juggler-verdict rid=@t v=verdict]  ::  planet: the comet's verdict lands
  ==
::
++  valid-acts  (silt `(list @tas)`~[%articulate %structure %propose %commit])
::
::  a cited operator is honest iff it is COMPUTED (naming the merely-advisory or
::  symbolic as if it computed is the lie the gravity catches). Mirrors the
::  bound-worker honesty leg exactly.
++  computed-cite
  |=  c=@tas
  ^-  ?
  =(%computed (class-of:nick-ops c))
::
::  THE GRAVITY. Re-derive the verdict from law. Fail-closed and ordered:
::  an unknown move, an inadmissible act, or any uncomputed cite -> reject.
++  review
  |=  sub=submission
  ^-  verdict
  ?.  (~(has in valid-acts) move.sub)
    [%.n %unknown-move (rap 3 'move ' move.sub ' is not a regime act' ~) worker.sub]
  =/  wan=act:regime  ;;(act:regime move.sub)
  ?.  (admissible:regime regime.sub wan)
    :*  %.n  %inadmissible
        (rap 3 'act ' (cat 3 move.sub (cat 3 ' not admissible in regime ' regime.sub)) ~)
        worker.sub
    ==
  ?.  (levy calls.sub computed-cite)
    =/  bad=(list @tas)  (skip calls.sub computed-cite)
    :*  %.n  %uncomputed
        (rap 3 'cited operator not computed: ' ?~(bad '?' i.bad) ~)
        worker.sub
    ==
  [%.y %ok 'gravity holds: admissible act, all cites computed' worker.sub]
--
