::  Prospective native transport. NOT wired to any live application.
::  Both scalar and bundle submissions must pass act before enabling bundles;
::  leaving the old scalar writer active would split the common namespace.
::  The caller commits records and returned facts in one Gall event. No
::  project file, draft, check, landing or grant is changed by this library.
/-  pa=cantrip-project-access, j=cantrip-project-suggestion-journal,
    wire=cantrip-project-bundle, view=cantrip-project-view
/+  access=cantrip-project-access, runtime=cantrip-project-access-runtime,
    journal=cantrip-project-suggestion-journal, read=cantrip-project-bundle-read,
    archive=cantrip-project-receipt-archive, law=cantrip-law-window
|%
+$  transition  [records=journal:j receipt=entry:j cards=(list card:agent:gall)]
+$  selector  [peer=@p query=query:view recovery=?]
++  query
  |=  r=request:pa
  ^-  query:view
  [project.r generation.r nonce.r]
++  route
  |=  [peer=@p q=query:view recovery=?]
  ^-  path
  =/  pax=path  (view-route:runtime peer q)
  ?>  ?=(^ pax)
  pax(i ?:(recovery %project-bundle-receipt %project-bundle))
++  parse
  |=  pax=path
  ^-  (unit selector)
  ?.  ?=([?(%project-bundle %project-bundle-receipt) *] pax)  ~
  =/  found  (view-parse:runtime pax(i %project-view))
  ?~  found  ~
  `[peer.u.found query.u.found =(%project-bundle-receipt i.pax)]
++  subscribed
  |=  [b=bowl:gall r=request:j]
  ^-  ?
  =/  q=request:pa  (envelope:journal r)
  ?:  ?=(%legacy -.r)  (subscribed:runtime b q)
  =/  wanted=path  (route src.b (query q) %.n)
  (lien ~(val by sup.b) |=([peer=@p pax=path] &(=(src.b peer) =(wanted pax))))
++  kicks
  ::  Grant/revocation integration must close both original and recovery paths.
  |=  [b=bowl:gall key=(unit [@t @p])]
  ^-  (list card:agent:gall)
  =/  paths=(set path)
    %-  silt
    %+  murn  ~(val by sup.b)
    |=  [peer=@p pax=path]
    ^-  (unit path)
    =/  parsed  (parse pax)
    ?~  parsed  ~
    ?.  =(peer peer.u.parsed)  ~
    ?^  key
      ?.  =(u.key [project.query.u.parsed peer])  ~
      `pax
    `pax
  (weld (kicks:runtime b key) (turn ~(tap in paths) |=(pax=path `card:agent:gall`[%give %kick ~[pax] ~])))
++  authorized
  |=  [b=bowl:gall grants=grants:pa q=request:pa current=authority:read w=window:law]
  ^-  (each grant:pa @tas)
  =/  initial  (preflight:runtime b grants q)
  ?:  ?=(%| -.initial)  [%| p.initial]
  (authorize-scoped:access our.b src.b now.b project.current grants q w scope.current)
++  ready-cards
  |=  [our=@p peer=@p q=query:view grant=@ux]
  ^-  (list card:agent:gall)
  =/  event=event:wire
    [%cantrip-project-bundle-ready-v1 our peer q grant %cantrip-project-bundle-transport-v1 8 32.768 65.536]
  ~[[%give %fact ~[(route peer q %.n)] %noun !>(event)]]
++  recover
  ::  The watch caller has already admitted current authority. This helper
  ::  observes one identity only, never calls admit, mutates a map or resends.
  |=  [our=@p peer=@p q=query:view grant=@ux records=journal:j cold=observed:j]
  ^-  (each (unit bundle:pa) @tas)
  ?:  ?=(%| -.cold)  [%| p.cold]
  =/  k=key:j  [project.q peer generation.q nonce.q]
  =/  hot  (lookup:journal records k)
  ?:  &(?=(^ hot) ?=(^ p.cold) !=(u.hot u.p.cold))
    [%| %receipt-history-conflict]
  =/  found=(unit entry:j)  ?~(hot p.cold hot)
  ?~  found  [%& ~]
  =/  e=entry:j  u.found
  ?.  &((entry-valid:journal our e) =(k (key-for:journal e)) =(grant (grant:journal e)))
    [%| %receipt-archive-invalid]
  ?.  ?=(%bundle -.e)  [%| %nonce-conflict]
  [%& `value.e]
++  recovery-cards
  |=  [our=@p peer=@p q=query:view found=(unit bundle:pa)]
  ^-  (list card:agent:gall)
  =/  pax=path  (route peer q %.y)
  =/  event=event:wire
    ?~  found
      [%cantrip-project-bundle-unconfirmed-v1 our peer q %receipt-unconfirmed]
    [%cantrip-project-bundle-receipt-v1 u.found]
  :~  [%give %fact ~[pax] %noun !>(event)]
      [%give %kick ~[pax] ~]
  ==
++  watch-with
  ::  Pure seam: the runtime, not a command payload, supplies observations.
  |=  [b=bowl:gall grants=grants:pa records=journal:j pax=path current=authority:read cold=observed:j w=window:law]
  ^-  (each (list card:agent:gall) @tas)
  =/  parsed  (parse pax)
  ?~  parsed  [%| %path-invalid]
  ?.  =(src.b peer.u.parsed)  [%| %foreign-peer]
  =/  q=query:view  query.u.parsed
  =/  request=request:pa  [project.q generation.q nonce.q %suggest ~ ~ `@t`0]
  =/  permitted  (authorized b grants request current w)
  ?:  ?=(%| -.permitted)  [%| p.permitted]
  ?.  (valid:journal our.b grants records)  [%| %journal-invalid]
  =/  digest=@ux  (digest:access p.permitted)
  ?.  recovery.u.parsed  [%& (ready-cards our.b src.b q digest)]
  =/  found  (recover our.b src.b q digest records cold)
  ?:  ?=(%| -.found)  [%| p.found]
  [%& (recovery-cards our.b src.b q p.found)]
++  watch
  |=  [b=bowl:gall grants=grants:pa records=journal:j pax=path history=(unit shared-state:archive) w=window:law]
  ^-  (each (list card:agent:gall) @tas)
  =/  parsed  (parse pax)
  ?~  parsed  [%| %path-invalid]
  ?.  =(src.b peer.u.parsed)  [%| %foreign-peer]
  =/  q=query:view  query.u.parsed
  =/  request=request:pa  [project.q generation.q nonce.q %suggest ~ ~ `@t`0]
  =/  current  (authorize:read b grants request w)
  ?:  ?=(%| -.current)  [%| p.current]
  =/  cold=observed:j
    ?.  recovery.u.parsed  [%| %not-a-recovery-read]
    (cold:read our.b our.b now.b history grants records [project.q src.b generation.q nonce.q])
  (watch-with b grants records pax p.current cold w)
++  act-with
  ::  One whole scalar or bundle receipt, one common identity and one fact.
  ::  All current authority/source checks are delegated to the existing laws.
  |=  [b=bowl:gall grants=grants:pa records=journal:j r=request:j observed=observation:read w=window:law]
  ^-  (each transition @tas)
  =/  q=request:pa  (envelope:journal r)
  =/  permitted  (authorized b grants q authority.observed w)
  ?:  ?=(%| -.permitted)  [%| p.permitted]
  ?.  (subscribed b r)  [%| %watch-required]
  =/  moved
    (admit:journal our.b src.b now.b project.authority.observed grants records r basis.observed w scope.authority.observed cold.observed)
  ?:  ?=(%| -.moved)  [%| p.moved]
  =/  e=entry:j  receipt.p.moved
  =/  cards=(list card:agent:gall)
    ?:  ?=(%legacy -.e)
      ::  This exact old typed fact and old path preserve scalar wire bytes.
      ~[[%give %fact ~[(route:runtime src.b q)] %noun !>(`event:pa`[%cantrip-project-receipt-v1 value.e])]]
    ~[[%give %fact ~[(route src.b (query q) %.n)] %noun !>(`event:wire`[%cantrip-project-bundle-receipt-v1 value.e])]]
  [%& [next.p.moved e cards]]
++  act
  |=  [b=bowl:gall grants=grants:pa records=journal:j r=request:j history=(unit shared-state:archive) w=window:law]
  ^-  (each transition @tas)
  =/  q=request:pa  (envelope:journal r)
  =/  initial  (preflight:runtime b grants q)
  ?:  ?=(%| -.initial)  [%| p.initial]
  ?.  (subscribed b r)  [%| %watch-required]
  =/  observed  (observe:read b grants records r history w)
  ?:  ?=(%| -.observed)  [%| p.observed]
  (act-with b grants records r p.observed w)
--
