::  /lib/multiplayer-project-role
::
::  Changing a member's role, with no new type. A role has always come from
::  an accepted invitation, so a role change is the same thing again: the
::  operator issues an invitation to an EXISTING member at a different role,
::  and the member's own acceptance applies it. The project history then
::  reads %invitation-issued (who offered which role) and
::  %invitation-accepted (that the member took it), exactly as for a join.
::  Until the member accepts, nothing changes; they may decline, and the
::  operator may revoke. For a ship that is not a member these arms are the
::  ordinary invite and accept.
::
::  Only the operator may offer an existing member another role; the
::  authority's own role is fixed; nobody is offered %operator.
::
/-  mp=multiplayer-project
/+  law=multiplayer-project
|%
++  invite
  |=  $:  project=project:mp
          actor=@p
          target=@p
          role=role:mp
          issued-at=@da
          expires-at=@da
          nonce=digest:mp
      ==
  ^-  result:mp
  =/  held=(unit member:mp)  (~(get by members.project) target)
  ?~  held  (invite:law project actor target role issued-at expires-at nonce)
  ?.  (project-valid:law project)  [%| [%invalid-project ~]]
  ?.  (time-valid:law project issued-at)
    [%| [%event-before-head (latest-time:law project) issued-at]]
  =/  actor-role=(unit role:mp)  (role-for:law project actor)
  ?.  ?&  ?=(^ actor-role)
          =(%operator u.actor-role)
          !=(%operator role)
      ==
    [%| [%not-authorized actor actor-role]]
  ?:  |(=(authority.spec.project target) =(role.u.held role))
    [%| [%already-member target]]
  =/  pending-id=(unit digest:mp)  (~(get by pending.project) target)
  ?^  pending-id  [%| [%invitation-exists target u.pending-id]]
  =/  invitation=invitation:mp
    (invitation-for:law project actor target role issued-at expires-at nonce)
  ?.  (invitation-valid:law invitation)  [%| [%invalid-invitation ~]]
  ?:  (~(has by invitations.project) digest.invitation)
    [%| [%invitation-exists target digest.invitation]]
  =/  next=project:mp
    %=  project
      invitations  (~(put by invitations.project) digest.invitation invitation)
      pending      (~(put by pending.project) target digest.invitation)
    ==
  [%& (append-event:law next actor [%invitation-issued digest.invitation target role] issued-at)]
::
++  accept
  |=  [project=project:mp actor=@p invitation-id=digest:mp observed-at=@da]
  ^-  result:mp
  =/  held=(unit member:mp)  (~(get by members.project) actor)
  ?~  held  (accept:law project actor invitation-id observed-at)
  ?.  (project-valid:law project)  [%| [%invalid-project ~]]
  ?.  (time-valid:law project observed-at)
    [%| [%event-before-head (latest-time:law project) observed-at]]
  =/  found=(unit invitation:mp)
    (~(get by invitations.project) invitation-id)
  ?~  found  [%| [%invitation-missing invitation-id]]
  =/  invitation=invitation:mp  u.found
  ?.  ?=(%pending -.status.invitation)
    [%| [%invitation-closed status.invitation]]
  ?.  =(target.body.invitation actor)
    [%| [%invitation-target target.body.invitation actor]]
  ?:  (gte observed-at expires-at.body.invitation)
    [%| [%invitation-expired expires-at.body.invitation observed-at]]
  ?:  |(=(authority.spec.project actor) =(role.u.held role.body.invitation))
    [%| [%already-member actor]]
  ::  Member since the first join; the role and the invitation that gave it
  ::  are the new ones.
  =/  changed=member:mp  [role.body.invitation joined-at.u.held `invitation-id]
  =/  resolved=invitation:mp
    invitation(status [%accepted actor observed-at])
  =/  next=project:mp
    %=  project
      members      (~(put by members.project) actor changed)
      invitations  (~(put by invitations.project) invitation-id resolved)
      pending      (~(del by pending.project) actor)
    ==
  [%& (append-event:law next actor [%invitation-accepted invitation-id] observed-at)]
--
