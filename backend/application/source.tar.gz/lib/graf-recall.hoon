::  /lib/graf-recall.hoon
::
::  The REAL Aho-Corasick recall over graf's fact-set -- "fire the whole vocabulary
::  at the query in one linear pass". Ports lib/warp-ac.hoon (base-256 axis-trie AC,
::  where a concept's axis IS its cord read little-endian) onto the content-addressed
::  facts, replacing the dead bucket stand-in in lib/graf-ac.hoon.
::
::  A fact's KEY is its concept-cord: normally the id in [kind id body].  A
::  weight-role hypothesis separates its content-addressed handle from its
::  shared tensor/component lookup key, so every scalar can inherit it without
::  aliasing competing hypotheses.  Build the automaton ONCE from every key;
::  recall(text) then scans the
::  query once and returns every fact whose key appears in it -- linear and
::  independent of |facts| (Aho-Corasick Theorem 2). This is graf's "being seen is
::  free": one pass fires all facts at once.
::
/+  warp-ac, wh=weight-hypothesis
|%
+$  index  [ac=ac:warp-ac by-key=(jug @ *)]         ::  baked automaton + key -> facts
::  a fact's concept-cord: [kind id body] -> id; else 0 (unindexed).
++  key-of
  |=  f=*
  ^-  @
  =/  hypothesis=(unit fact:wh)  (decode:wh f)
  ?^  hypothesis  key.u.hypothesis
  ?.  ?=([@ @ *] f)  0
  +<.f
::  bake: build the AC from every keyed fact's cord, once.
++  build
  |=  fs=(set *)
  ^-  index
  =/  fl=(list *)  ~(tap in fs)
  =/  keys=(list @t)  (skip `(list @t)`(turn fl key-of) |=(k=@t =(k 0)))
  =/  j=(jug @ *)
    %+  roll  fl
    |=  [f=* acc=(jug @ *)]
    =/  k=@  (key-of f)
    ?:  =(k 0)  acc
    (~(put ju acc) k f)
  [(make:warp-ac keys) j]
::  recall: scan the query once; return every fact whose key fired.
++  recall
  |=  [ix=index query=@t]
  ^-  (set *)
  =/  hits=(list [off=@ud kw=@])  (scan:warp-ac ac.ix query)
  %-  ~(gas in *(set *))
  %-  zing
  %+  turn  hits
  |=  [off=@ud kw=@]
  ^-  (list *)
  ~(tap in (~(get ju by-key.ix) kw))
::  convenience: bake + recall in one shot over a fact-set.
++  fire
  |=  [fs=(set *) query=@t]
  ^-  (set *)
  (recall (build fs) query)
--
