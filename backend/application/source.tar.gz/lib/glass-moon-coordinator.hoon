::  Isolated selected-provider imports; protocol nouns and agent names stay unchanged.
::  /lib/glass-moon-coordinator
::
::  Pure identity, replay, correlation, and reload planning for the durable
::  command coordinator.  Runtime cards belong to the Gall app.
::
/-  mb=model-bridge, ms=multiplayer-session,
    msc=glass-moon-coordinator
/+  mscl=glass-moon-command, msel=glass-moon-executor,
    msl=multiplayer-session
|%
++  key-for
  |=  input=input:msc
  ^-  key:msc
  (shax (jam [recipient.input sender-session.input recipient-session.input task-id.task.input]))
++  payload-digest
  |=  input=input:msc
  ^-  @ux
  (shax (jam input))
++  input-valid
  |=  input=input:msc
  ^-  ?
  ?&  (task-admissible:msel task.input)
      (bounded-text:mb sender-session.input max-identifier-bytes:mb)
      (bounded-text:mb recipient-session.input max-identifier-bytes:mb)
      ?=(^ (effective-limit:mscl limit.input task.input))
  ==
++  make-record
  |=  [our=@p input=input:msc at=@da]
  ^-  record:msc
  =/  effective=(unit @dr)  (effective-limit:mscl limit.input task.input)
  ?>  ?=(^ effective)
  =/  body=message-body:ms
    :*  %multiplayer-session-message-v1
        task-id.task.input
        our
        recipient.input
        sender-session.input
        recipient-session.input
        %request
        ~
        (encode-task:msel task.input)
        at
    ==
  =/  request=message:ms  (make-message:msl body)
  :*  (key-for input)
      (payload-digest input)
      input
      request
      (add at u.effective)
      %await-delivery
      ~
      ~
  ==
++  admit
  |=  [our=@p input=input:msc at=@da records=(map key:msc record:msc)]
  ^-  admission:msc
  ?.  (input-valid input)  [%invalid ~]
  =/  key=key:msc  (key-for input)
  =/  found=(unit record:msc)  (~(get by records) key)
  ?~  found  [%new (make-record our input at)]
  ?:  =((payload-digest input) payload-digest.u.found)
    [%resume u.found]
  [%conflict key]
++  accept-delivery
  |=  [record=record:msc result=delivery-result:ms]
  ^-  record:msc
  record(delivery `result, phase ?:(?=(%accepted -.result) %await-response %await-delivery))
++  response-matches
  |=  [our=@p record=record:msc response=message:ms]
  ^-  ?
  %-  response-matches:mscl
  :*  our
      recipient.input.record
      sender-session.input.record
      recipient-session.input.record
      request.record
      response
  ==
++  complete
  |=  [record=record:msc response=message:ms]
  ^-  record:msc
  record(terminal `[%completed response])
++  recovery-plan
  |=  record=record:msc
  ^-  recovery:msc
  ?^  terminal.record  [%.n %.n %.n]
  ?:  =(%await-delivery phase.record)
    [%.y %.y %.y]
  [%.n %.y %.y]
--
