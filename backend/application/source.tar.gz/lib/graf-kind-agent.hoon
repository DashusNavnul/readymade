::  Derived read acceleration. Inner state, permissions and effects are intact.
/+  ki=graf-kind-index, gs=graf-substrate
|%
+$  card  card:agent:gall
++  floor-path  /x/derived-kind-floor
++  read
  |=  [inner=agent:gall b=bowl:gall]
  ^-  store:gs
  =/  ag  ~(. inner b(src our.b))
  =/  found=(unit (unit cage))  (on-peek:ag floor-path)
  ?>  ?=(^ found)
  ?>  ?=(^ u.found)
  ?>  =(%noun p.u.u.found)
  ::  Trust the typed inner DATA vase, never cast an executable core.
  !<(store:gs q.u.u.found)
++  agent
  |=  inner=agent:gall
  ^-  agent:gall
  =|  held=cache:ki
  |_  =bowl:gall
  +*  this  .
      ag  ~(. inner bowl)
      finish
        |=  out=(quip card agent:gall)
        ^-  (quip card _this)
        [-.out this(inner +.out, held (sync:ki held (read +.out bowl)))]
  ++  on-init
    =^  cards  inner  on-init:ag
    [cards this(held (seed:ki (read inner bowl)))]
  ++  on-save  on-save:ag
  ++  on-load
    |=  old=vase
    =^  cards  inner  (on-load:ag old)
    [cards this(held (seed:ki (read inner bowl)))]
  ++  on-poke
    |=  [=mark =vase]
    (finish (on-poke:ag mark vase))
  ++  on-watch
    |=  =path
    (finish (on-watch:ag path))
  ++  on-leave
    |=  =path
    (finish (on-leave:ag path))
  ++  on-peek
    |=  =path
    ::  The accessor is visible only to this wrapper's direct inner call.
    ?:  =(floor-path path)  ~
    =/  incremental=(unit (unit cage))  (cursor-peek:ki held path)
    ?^  incremental  incremental
    =/  found=(unit (unit cage))  (peek:ki kinds.held path)
    ?^  found  found
    (on-peek:ag path)
  ++  on-agent
    |=  [=wire =sign:agent:gall]
    (finish (on-agent:ag wire sign))
  ++  on-arvo
    |=  [=wire sign=sign-arvo]
    (finish (on-arvo:ag wire sign))
  ++  on-fail
    |=  [=term =tang]
    (finish (on-fail:ag term tang))
  --
--
