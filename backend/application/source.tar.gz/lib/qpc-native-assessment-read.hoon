::  Cantrip-side canonical reader. The only request input is a session ID.
::  Retained decision law and fresh authority/source authorize assessment only.
/-  nc=native-coding
/+  a=qpc-native-assessment, bind=qpc-native-owner-binding,
    owner=qpc-native-owner, d=qpc-native-declaration,
    ct=cantrip-native-coding, accept=native-coding-accept,
    instrument=qpc-instrument-contract, project=native-coding-project,
    law=qpc-law-core, window=cantrip-law-window, guard=viki-scry-guard
|%
+$  reader  $-([inner=agent:gall b=bowl:gall id=@ux] (each view:a @tas))
++  read
  |=  [inner=agent:gall b=bowl:gall id=@ux]
  ^-  (each view:a @tas)
  ?.  &(=(our.b src.b) (identifier:ct id))  [%| %qpc-assessment-owner-required]
  =/  gate  (raw:instrument inner b /x/qpc/required-sessions)
  =/  tools  (raw:instrument inner b /x/native-coding/tool-state)
  =/  ordinary  (raw:instrument inner b /x/native-coding/candidate-ledger)
  =/  law-raw  (raw:instrument inner b /x/law/window/current)
  ?~  gate  [%| %qpc-assessment-gate-unavailable]
  ?~  tools  [%| %qpc-assessment-tools-unavailable]
  ?~  ordinary  [%| %qpc-assessment-ordinary-ledger-unavailable]
  ?~  law-raw  [%| %qpc-assessment-law-unavailable]
  =/  managed  ((soft ,[%qpc-session-gate-v1 %cantrip ids=(set @ux)]) u.gate)
  =/  book  ((soft organ:ct) u.tools)
  =/  accepted  ((soft ledger:accept) u.ordinary)
  =/  current-law  ((soft window:window) u.law-raw)
  ?~  managed  [%| %qpc-assessment-gate-invalid]
  ?~  book  [%| %qpc-assessment-tools-invalid]
  ?~  accepted  [%| %qpc-assessment-ordinary-ledger-invalid]
  ?~  current-law  [%| %qpc-assessment-law-invalid]
  ?.  (~(has in ids.u.managed) id)  [%| %qpc-assessment-unmanaged]
  ?.  &((~(has in admissible.u.current-law) %probe) !(~(has in blocked.u.current-law) %probe))
    [%| %qpc-assessment-law-blocked]
  ?.  (agent-live:guard our.b now.b %viki)  [%| %qpc-assessment-owner-unavailable]
  =/  raw=*
    .^(* %gx /(scot %p our.b)/viki/(scot %da now.b)/qpc/owner/noun)
  =/  prospective  ((soft state:bind) raw)
  ?~  prospective  [%| %qpc-assessment-owner-invalid]
  ?.  &(=(raw u.prospective) (valid:bind our.b u.prospective))
    [%| %qpc-assessment-owner-invalid]
  =/  found  (~(get by records.journal.u.prospective) id)
  =/  ticket  (~(get by tickets.u.prospective) id)
  ?~  found  [%| %qpc-assessment-opening-missing]
  ?~  ticket  [%| %qpc-assessment-registration-missing]
  =/  r=record:owner  u.found
  ?.  &(?=(~ closed.r) =(%sealed phase.u.ticket))
    [%| %qpc-assessment-owner-not-sealed]
  ?~  collection.r  [%| %qpc-assessment-pool-missing]
  =/  c=collection:owner  u.collection.r
  =/  registered=record:d  registration.u.ticket
  ?.  &(=(declaration.r (declared:bind registered)) (usable:d registered))
    [%| %qpc-assessment-declaration-changed]
  ::  The prospective owner's validated collection is the one canonical
  ::  pool. A legacy gate cache need not have observed a separate seal poke.
  =/  laws=state:law
    .^(state:law %gx /(scot %p our.b)/viki/(scot %da now.b)/qpc/laws/noun)
  :: Preserve the opened decision's law while keeping all current permission,
  :: source, membership and exact grant checks in the assessment path.
  =/  expected  (retained:law laws binding.law.value.registered our.b id.law.value.registered)
  ?:  ?=(%| -.expected)  [%| p.expected]
  ?.  =(law.value.registered p.expected)  [%| %qpc-assessment-qpc-law-changed]
  =/  p=project:nc  project.value.registered
  =/  current  (current:project our.b now.b p)
  ?:  ?=(%| -.current)  [%| p.current]
  ?.  =(source.pool.c revision.working.p.current)  [%| %qpc-assessment-source-changed]
  =/  catalog  (catalog:project our.b now.b p)
  ?:  ?=(%| -.catalog)  [%| p.catalog]
  ?.  &((member:project p p.catalog our.b %compile) (member:project p p.catalog our.b %check))
    [%| %qpc-assessment-membership-refused]
  =/  v=view:a
    [[frozen.decision.r pool.c position.c declaration.r scope.r] u.book]
  =/  prepared  (begin:a empty:a our.b our.b now.b v)
  ?:  ?=(%| -.prepared)  [%| p.prepared]
  =/  assessment=record:a  (~(got by records.p.prepared) id)
  ?.  =(p project.grant.scope.binding.assessment)
    [%| %qpc-assessment-project-changed]
  =/  rows=(list row:a)  ~(val by rows.assessment)
  |-  ^-  (each view:a @tas)
  ?~  rows  [%& v]
  =/  candidate=candidate:nc  candidate.i.rows
  ?:  (~(has by u.accepted) id.candidate)
    [%| %qpc-assessment-ordinary-candidate-collision]
  ?.  &(=(basis.candidate working.p.current) =(accepted.candidate revision.accepted.p.current))
    [%| %qpc-assessment-candidate-source-changed]
  =/  permission
    (candidate-permission:ct our.b now.b u.book (bridge:a assessment i.rows))
  ?:  ?=(%| -.permission)  [%| p.permission]
  $(rows t.rows)
--
