::  /lib/cantrip-vibecoding-dispatch
::
::  Cantrip's pure dispatch law for native vibecoding.  It joins, but never
::  copies, the Viki proposal verdict, sponsor-bound seat session, Viki/Graf
::  seat write, Clay-backed workspace claim, and live moon lease.
::
::  Passing this gate grants no general shell and no landing authority.  It
::  admits one exact proposal act inside the claimed fork.  The real executor
::  must still return a correlated artifact and receipt.
::
/-  vd=vibecoding-dispatch, vp=vibecoding-proposal, ss=seat-session,
    mg=moon-grant, graf-sur=graf, ws=workspace, gsc=graf-seat-claim
/+  cvp=cantrip-vibecoding-proposal, clw=cantrip-law-window, sl=seat-session,
    es=entity-subject, wl=workspace
|%
++  tier-rank
  |=  tier=grant-tier:mg
  ^-  @ud
  ?-  tier
    %safe        0
    %reversible  1
    %data        2
  ==
::
::  This mapping is Cantrip law.  It is deliberately conservative: writing a
::  workspace is data authority even though the fork makes it reversible.
++  act-tier
  |=  kind=act:clw
  ^-  grant-tier:mg
  ?-  kind
    ?(%read %inspect %compare %hypothesize %probe %summarize %done)  %safe
    %branch       %reversible
    ?(%inscribe %implement %promote %reduce)  %data
  ==
++  act-of
  |=  [sequence=@ud acts=(list proposed-act:vp)]
  ^-  (unit proposed-act:vp)
  ?~  acts  ~
  ?:(=(sequence sequence.i.acts) `i.acts $(acts t.acts))
::
::  Capability is derived from the exact target and act.  The caller cannot
::  claim a cheaper tool name for a more powerful operation.
++  capability-for
  |=  act=proposed-act:vp
  ^-  @t
  ?-  -.target.act
    %clay
      ?:(=(%safe (act-tier kind.act)) 'read-file' 'write-hoon')
    %thread
      `@t`name.target.act
    %graf
      ?:(=(%safe (act-tier kind.act)) 'graf-recall' 'graf-inscribe')
    %gall
      'poke-agent'
  ==
++  target-in-workspace
  |=  [target=surface:vp workspace=@tas]
  ^-  ?
  ?-  -.target
    %clay    =(desk.target workspace)
    %thread  =(desk.target workspace)
    %graf    %.n
    %gall    %.n
  ==
++  session-rejections
  |=  [our=@p actor=@p seat=seat:ss table=table:sl workspace=@tas]
  ^-  (list refusal:vd)
  =/  ruling=verdict:ss  (may-act:sl our table seat actor)
  ?.  allowed.ruling
    %+  turn  refusals.ruling
    |=(reason=refusal:ss [%session-refused reason])
  =/  reasons=(list refusal:vd)  ~
  =?  reasons  !=(%seated ground.ruling)
    [[%actor-not-seated ~] reasons]
  =/  got=(unit session:ss)  (~(get by table) seat)
  =/  workspace-session-ok=?  ?~(got %.n =(workspace.u.got workspace))
  =?  reasons  !workspace-session-ok
    [[%session-workspace-mismatch ~] reasons]
  reasons
++  mirror-rejections
  |=  [mirror=(unit mirrored-lease:mg) grant=moon-grant:mg actor=@p now=@da]
  ^-  (list refusal:vd)
  ?~  mirror  ~[[%mirror-absent ~]]
  =/  reasons=(list refusal:vd)  ~
  =/  exact-mirror=?
    ?&  =((scot %p actor) holder.u.mirror)
        ?=(^ expires-at.grant)
        =(u.expires-at.grant expires.u.mirror)
    ==
  =?  reasons  !exact-mirror
    [[%mirror-mismatch ~] reasons]
  =?  reasons  ?|  !=(%active status.u.mirror)
                    &(!=(0 expires.u.mirror) !(lth now expires.u.mirror))
                 ==
    [[%mirror-not-live ~] reasons]
  reasons
++  grant-rejections
  |=  $:  grant=(unit moon-grant:mg)
          actor=@p
          our=@p
          seat=seat:ss
          write=graf-seat-write:graf-sur
          mirror=(unit mirrored-lease:mg)
          capability=@t
          required=grant-tier:mg
          now=@da
      ==
  ^-  (list refusal:vd)
  ?~  grant  ~[[%lease-absent ~]]
  =/  g=moon-grant:mg  u.grant
  =/  reasons=(list refusal:vd)  ~
  =?  reasons  ?|  !=(grantee.g actor)
                    !=(lease-id.g lease-id.write)
                 ==
    [[%lease-mismatch ~] reasons]
  =?  reasons  !(lease-live:es grant actor now)
    [[%lease-not-live ~] reasons]
  =?  reasons  !=(parent.g our)
    [[%lease-wrong-parent ~] reasons]
  =.  reasons  (weld reasons (mirror-rejections mirror g actor now))
  =/  seat-cap=@t  (seat-cap:gsc seat)
  =?  reasons  ?|  !(~(has in allowed-tools.g) seat-cap)
                    !(~(has in allowed-tools.g) capability)
                 ==
    [[%capability-not-leased capability] reasons]
  =?  reasons  (gth (tier-rank required) (tier-rank tier-ceiling.g))
    [[%tier-exceeds-lease required tier-ceiling.g] reasons]
  reasons
++  rejections
  |=  $:  proposal=proposal:vp
          proposal-verdict=verdict:vp
          law=law-binding:vp
          our=@p
          actor=@p
          seat=seat:ss
          table=table:sl
          write=graf-seat-write:graf-sur
          claim=claim:ws
          desks=(set @tas)
          grant=(unit moon-grant:mg)
          mirror=(unit mirrored-lease:mg)
          sequence=@ud
          now=@da
      ==
  ^-  (list refusal:vd)
  =/  workspace=@tas  fork.claim
  =/  reasons=(list refusal:vd)  ~
  =?  reasons  !(verdict-current:cvp proposal law proposal-verdict)
    [[%proposal-stale ~] reasons]
  =?  reasons  !review-admitted.proposal-verdict
    [[%proposal-not-admitted ~] reasons]
  =?  reasons  execution-admitted.proposal-verdict
    [[%proposal-claims-execution ~] reasons]
  =?  reasons  !=(operator.origin.body.proposal our)
    [[%operator-mismatch ~] reasons]
  =.  reasons
    (weld reasons (session-rejections our actor seat table workspace))
  =/  actor-write=(unit @p)  (slaw %p assigned-ship-id.write)
  =/  workspace-write=(unit @tas)  (slaw %tas session-id.write)
  =/  actor-write-ok=?  ?~(actor-write %.n =(u.actor-write actor))
  =/  workspace-write-ok=?  ?~(workspace-write %.n =(u.workspace-write workspace))
  =/  write-matches=?
    ?&  =(seat-id.write seat)
        actor-write-ok
        workspace-write-ok
        =(%claim write-kind.write)
    ==
  =?  reasons  !write-matches
    [[%seat-write-mismatch ~] reasons]
  ::  A CONJUNCT THAT COULD NOT FAIL.  workspace is bound to fork.claim at the
  ::  top of this arm, so the second half of this test was =(fork.claim
  ::  fork.claim) -- it read as though it validated the claim's fork against
  ::  the workspace, and validated nothing.
  ::
  ::  Removing it changes no behaviour, and the claim is still not
  ::  self-certifying: the seat write must name the same workspace in its
  ::  session-id (checked as workspace-write-ok above) and desks must have that
  ::  workspace active (%workspace-not-active below). Those are the independent
  ::  statements the claimed fork is held against. The only thing left for this
  ::  test is the holder.
  =/  claim-matches=?  =(holder.claim actor)
  =?  reasons  !claim-matches
    [[%workspace-claim-mismatch ~] reasons]
  =?  reasons  !(~(has in desks) workspace)
    [[%workspace-not-active ~] reasons]
  =/  selected=(unit proposed-act:vp)  (act-of sequence acts.body.proposal)
  ?~  selected
    [[%act-not-found sequence] reasons]
  =/  act=proposed-act:vp  u.selected
  =/  capability=@t  (capability-for act)
  =/  required=grant-tier:mg  (act-tier kind.act)
  =?  reasons  !(target-in-workspace target.act workspace)
    [[%target-outside-workspace ~] reasons]
  (weld reasons (grant-rejections grant actor our seat write mirror capability required now))
++  gate
  |=  $:  proposal=proposal:vp
          proposal-verdict=verdict:vp
          law=law-binding:vp
          our=@p
          actor=@p
          seat=seat:ss
          table=table:sl
          write=graf-seat-write:graf-sur
          claim=claim:ws
          desks=(set @tas)
          grant=(unit moon-grant:mg)
          mirror=(unit mirrored-lease:mg)
          sequence=@ud
          now=@da
      ==
  ^-  verdict:vd
  =/  reasons=(list refusal:vd)
    (rejections proposal proposal-verdict law our actor seat table write claim desks grant mirror sequence now)
  =/  selected=(unit proposed-act:vp)  (act-of sequence acts.body.proposal)
  =/  capability=(unit @t)
    ?~(selected ~ `(capability-for u.selected))
  =/  ceiling=(unit grant-tier:mg)
    ?~(grant ~ `tier-ceiling.u.grant)
  :*  %vibecoding-dispatch-verdict-v1
      ?=(~ reasons)
      digest.proposal
      actor
      seat
      fork.claim
      sequence
      ?~(selected ~ `kind.u.selected)
      capability
      ceiling
      reasons
      ?:(?=(~ reasons) 'exact act admitted inside the claimed workspace' 'dispatch refused; inspect every typed reason')
  ==
--
