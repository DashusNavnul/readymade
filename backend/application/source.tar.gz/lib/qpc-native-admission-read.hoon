::  Cantrip-side canonical eligibility reader. Input is one retained marker
::  ID, never a report, source, verdict, law snapshot or claimed sequence.
::  NOT COMPOSED: the next owner phase must persist the actual status event
::  and marker before dispatch, and expose the private marker projection.
/+  admit=qpc-native-admission, a=qpc-native-assessment,
    current=qpc-native-assessment-read, instrument=qpc-instrument-contract,
    bind=qpc-native-owner-binding, owner=qpc-native-owner,
    pool=qpc-native-pool, law=cantrip-law-window,
    editor=cantrip-editor-save, guard=viki-scry-guard
|%
+$  reader  $-([inner=agent:gall b=bowl:gall id=@ux] (each receipt:admit @tas))
++  read
  |=  [inner=agent:gall b=bowl:gall id=@ux]
  ^-  (each receipt:admit @tas)
  ?.  =(our.b src.b)  [%| %qpc-admission-owner-required]
  ?.  (agent-live:guard our.b now.b %viki)  [%| %qpc-admission-owner-unavailable]
  =/  marker=(unit marker:admit)
    .^((unit marker:admit) %gx /(scot %p our.b)/viki/(scot %da now.b)/qpc/admission-request/(scot %ux id)/noun)
  ?~  marker  [%| %qpc-admission-marker-missing]
  ?.  =(id id.event.u.marker)  [%| %qpc-admission-marker-mismatch]
  =/  session=@ux  session.u.marker
  =/  input=(unit input:pool)
    .^((unit input:pool) %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/qpc-input/(scot %ux session)/noun)
  ?~  input  [%| %qpc-admission-session-missing]
  ::  This existing reader joins current law, current numbered Clay source,
  ::  all actual project targets, grant/revocation and membership to the
  ::  canonical frozen owner. A cached hash or owner poke is insufficient.
  =/  fresh  (read:current inner b session)
  ?:  ?=(%| -.fresh)  [%| p.fresh]
  =/  raw  (raw:instrument inner b /x/qpc/assessments)
  =/  law-raw  (raw:instrument inner b /x/law/window/current)
  ?~  raw  [%| %qpc-admission-assessment-unavailable]
  ?~  law-raw  [%| %qpc-admission-law-unavailable]
  =/  assessed  ((soft state:a) u.raw)
  =/  window  ((soft window:law) u.law-raw)
  ?~  assessed  [%| %qpc-admission-assessment-invalid]
  ?~  window  [%| %qpc-admission-law-invalid]
  ?.  (permission:editor u.window)  [%| %qpc-admission-inscribe-blocked]
  ?.  (valid:a our.b u.assessed)  [%| %qpc-admission-assessment-invalid]
  =/  found  (~(get by records.u.assessed) session)
  ?~  found  [%| %qpc-admission-assessment-missing]
  =/  prospective=state:bind
    .^(state:bind %gx /(scot %p our.b)/viki/(scot %da now.b)/qpc/owner/noun)
  ?.  (valid:bind our.b prospective)  [%| %qpc-admission-owner-invalid]
  =/  ticket  (~(get by tickets.prospective) session)
  ?~  ticket  [%| %qpc-admission-declaration-missing]
  =/  cases  cases.task.value.registration.u.ticket
  (prepare:admit our.b now.b u.marker p.fresh u.found cases entry.u.input)
--
