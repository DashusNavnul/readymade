::  Native ARK law state and owner HTTP adapter. No controller dispatch.
/+  instrument=qpc-instrument-read-contract, gate=qpc-session-gate,
    web=pataphor-terminal-http, cr=codex-responses,
    pure=qpc-law-core, measurements=qpc-measurement-view,
    successors=qpc-successor-measurement-view,
    candidates=qpc-candidate-view, distribution=qpc-distribution-view,
    window=qpc-window, tools=cantrip-native-coding, guard=viki-scry-guard,
    contract=qpc-instrument-contract
|%
+$  parameters  parameters:pure
+$  edit  edit:pure
+$  command  command:pure
+$  binding  binding:pure
+$  revision  revision:pure
+$  state  state:pure
++  digest  digest:pure
++  defaults  defaults:pure
++  parameters-valid  parameters-valid:pure
++  reason-valid  reason-valid:pure
++  initial  initial:pure
++  valid  valid:pure
++  history-valid  history-valid:pure
++  current  current:pure
++  preview  preview:pure
++  apply  apply:pure
++  freeze  freeze:pure
++  open-decision  open-decision:pure
++  binding-of  binding-of:contract
++  members
  ::  Each planned session with its law binding; pool members share one.
  |=  [inner=agent:gall b=bowl:gall]
  ^-  (unit (list [session=@ux bound=binding]))
  =/  ag  ~(. inner b(src our.b))
  =/  raw  (payload:gate (on-peek:ag /x/qpc/instrument/state))
  ?~  raw  ~
  =/  parsed  ((soft state:instrument) u.raw)
  ?~  parsed  ~
  `(turn ~(val by plans.u.parsed) |=(r=record:instrument [session.plan.r (binding-of plan.r)]))
++  members-json
  ::  Each enrolled session's place in its stream; pool members share one.
  |=  [inner=agent:gall b=bowl:gall]
  ^-  json
  =/  ag  ~(. inner b(src our.b))
  =/  raw  (payload:gate (on-peek:ag /x/qpc/instrument/state))
  ?~  raw  [%a ~]
  =/  parsed  ((soft state:instrument) u.raw)
  ?~  parsed  [%a ~]
  :-  %a
  %+  turn  ~(val by plans.u.parsed)
  |=  r=record:instrument
  %-  pairs:enjs:format
  :~  ['session' [%s (scot %ux session.plan.r)]]
      ['instrument' [%s (scot %ux instrument.plan.r)]]
      ['stream' [%s (scot %ux stream.plan.r)]]
      ['task' [%s task.plan.r]]
      ['artifact' [%s (spat artifact.plan.r)]]
      ['manifest' [%s (scot %tas version.manifest.plan.r)]]
      ['active' [%b active.r]]
      ['step' (numb:enjs:format step.r)]
      ['reason' ?~(reason.r [%~] [%s (scot %tas u.reason.r)])]
  ==
++  bindings
  ::  Distinct law bindings: one per instrument law, however many members.
  |=  [inner=agent:gall b=bowl:gall]
  ^-  (unit (list binding))
  =/  ms  (members inner b)
  ?~  ms  ~
  `~(tap in (silt (turn u.ms |=([@ux bound=binding] bound))))
++  distributions
  ::  Inert: per-law QPC weights for each sealed pool, recomputed from retained
  ::  inputs. A is the instrument's frozen first measurement or a stated pause.
  ::  Cantrip's ledger is read only when a pool exists and Cantrip is live.
  |=  [inner=agent:gall held=state b=bowl:gall]
  ^-  json
  =/  sealed  (read:candidates inner b)
  ?~  sealed  (render:distribution ~)
  ?~  pools.u.sealed  (render:distribution ~)
  =/  ms=(list [session=@ux bound=binding])  (fall (members inner b) ~)
  =/  measured  (read:measurements inner b)
  =/  laws=(map @ux (list revision:distribution))
    %-  malt
    %+  turn  ms
    |=  [session=@ux x=binding]
    :-  session
    %+  turn  (fall (~(get by held) instrument.x) ~[(initial x our.b)])
    |=  r=revision
    ^-  revision:distribution
    [id.r gain.parameters.r footprint.parameters.r indirection.parameters.r ?=(^ at.r)]
  =/  attention=(map @ux (each [num=@ud den=@ud] @tas))
    %-  malt
    %+  turn  ms
    |=  [session=@ux x=binding]
    ^-  [@ux (each [num=@ud den=@ud] @tas)]
    :-  session
    ?~  measured  [%| %measurement-unavailable]
    =/  found=(list [num=@ud den=@ud])
      %+  murn  ~(val by windows.u.measured)
      |=  w=state:window
      ?.  =(instrument.x instrument.binding.w)  ~
      ?~  measured.w  ~
      `attention.tensor.u.measured.w
    ?~  found  [%| %attention-unavailable]
    ?^  t.found  [%| %attention-ambiguous]
    [%& i.found]
  =/  ledger=(unit organ:tools)
    ?.  (agent-live:guard our.b now.b %cantrip)  ~
    ((soft organ:tools) .^(* %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/tool-state/noun))
  (render:distribution (inputs:distribution pools.u.sealed ledger laws attention))
++  project-context
  :: Exact retained-law projection shared by synchronization and handoff.
  :: Planned membership supplies no law authority; retained current/valid do.
  |=  [our=@p held=state ms=(list [session=@ux bound=binding])]
  ^-  laws:instrument
  =/  bs=(list binding)  ~(tap in (silt (turn ms |=([@ux bound=binding] bound))))
  %+  roll  ms
  |=  [[session=@ux bound=binding] result=laws:instrument]
  ::  One distinct binding per instrument, shared by all its members.
  ?.  =(1 (lent (skim bs |=(other=binding =(instrument.bound instrument.other)))))  result
  =/  r=revision  (current held bound our)
  ?.  &(=(bound binding.r) (valid r))  result
  (~(put by result) session [instrument.bound id.r])
++  synchronize
  :: Project native retained law into the inner collection owner. This is a
  :: local transition, never a card or a sender-supplied authority claim.
  |=  [inner=agent:gall held=state b=bowl:gall]
  ^-  agent:gall
  =/  context=laws:instrument
    (project-context our.b held (fall (members inner b) ~))
  =/  ag  ~(. inner b(src our.b))
  =/  result
    (on-poke:ag %noun !>([%qpc-instrument-law-context-v1 context]))
  ?>  ?=(~ -.result)
  +.result
++  revision-json
  |=  r=revision
  %-  pairs:enjs:format
  :~  ['revision' [%s (scot %ux id.r)]]
      ['instrument' [%s (scot %ux instrument.binding.r)]]
      ['session' [%s (scot %ux session.binding.r)]]
      ['project' [%s project.binding.r]]
      ['artifact' [%s (spat artifact.binding.r)]]
      ['objective' [%s (scot %ux objective.binding.r)]]
      ['scoringProfile' [%s 'unavailable']]
      ['gain' (numb:enjs:format gain.parameters.r)]
      ['footprint' (numb:enjs:format footprint.parameters.r)]
      ['indirection' (numb:enjs:format indirection.parameters.r)]
      ['denominator' (numb:enjs:format (add footprint.parameters.r indirection.parameters.r))]
      ['reason' [%s reason.r]]
      ['at' [%s ?~(at.r 'not-yet-saved' (scot %da u.at.r))]]
  ==
++  decode
  |=  raw=@t
  ^-  (unit command)
  %-  mole
  |.
  =/  j=json  (need (de:json:html raw))
  ?>  ?=(%o -.j)
  ?>  (levy ~(tap by p.j) |=([k=@t v=json] (lien `(list @t)`~['instrument' 'expected' 'kind' 'value' 'footprint' 'indirection' 'reason'] |=(known=@t =(k known)))))
  =/  instrument=@ux  (need (slaw %ux (need (string:cr j 'instrument'))))
  =/  expected=@ux  (need (slaw %ux (need (string:cr j 'expected'))))
  =/  kind=@t  (need (string:cr j 'kind'))
  =/  change=edit
    ?:  =('gain' kind)  [%gain (need (number:web j 'value'))]
    ?>  =('weights' kind)
    [%weights (need (number:web j 'footprint')) (need (number:web j 'indirection'))]
  [%qpc-law-edit-v1 instrument expected change (need (string:cr j 'reason'))]
++  page
  ^-  @t
  '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ARK working law</title><script defer src="/apps/qpc-ark/ark.js"></script></head><body><main id="ark"></main></body></html>'
++  page-response
  ::  This presentation intentionally embeds the existing same-origin work
  ::  surface. The generic terminal CSP has no frame-src, so use an explicit
  ::  page-only policy. Neither frame grants access to the other's authority.
  |=  id=@ta
  ^-  (list card:agent:gall)
  =/  header=response-header:http
    :-  200
    :~  ['content-type' 'text/html; charset=utf-8']
        ['cache-control' 'no-store']
        ['x-content-type-options' 'nosniff']
        ['content-security-policy' (crip "default-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; frame-src 'self'; base-uri 'none'; frame-ancestors 'self'")]
    ==
  =/  data=(unit octs)  `(as-octs:mimes:html page)
  =/  path=path  /http-response/[id]
  :~  [%give %fact ~[path] %http-response-header !>(header)]
      [%give %fact ~[path] %http-response-data !>(data)]
      [%give %kick ~[path] ~]
  ==
++  agent
  |=  inner=agent:gall
  =|  held=state
  ^-  agent:gall
  |_  =bowl:gall
  +*  this  .
      ag  ~(. inner bowl)
      boot
        ^-  card:agent:gall
        [%pass /qpc-law-bind %arvo %e %connect [~ /apps/qpc-ark] dap.bowl]
      view
        ^-  json
        =/  bs  (bindings inner bowl)
        =/  measured  (read:measurements inner bowl)
        %-  pairs:enjs:format
        :~  ['schema' [%s 'qpc-ark-law-v1']]
            ['owner' [%s (scot %p our.bowl)]]
            ['measurement' [%s (status:measurements measured)]]
            ['measurements' (render:measurements measured)]
            ['successorMeasurements' (render:successors (read:successors inner bowl))]
            ['selection' [%s 'unavailable']]
            ['candidates' (render:candidates (read:candidates inner bowl))]
            ['distributions' (distributions inner held bowl)]
            ['members' (members-json inner bowl)]
            ['sensing' [%s 'Native ordered history; unknown outcomes stay unknown.']]
            ['application' [%s 'Saved law; controller consumption is not installed.']]
            ['laws' [%a ?~(bs ~ (turn u.bs |=(b=binding (revision-json (current held b our.bowl)))))]]
        ==
      enact
        |=  cmd=command
        ^-  (each state @tas)
        =/  bs  (bindings inner bowl)
        ?~  bs  [%| %instrument-owner-unavailable]
        =/  matched  (skim u.bs |=(b=binding =(instrument.cmd instrument.b)))
        ?.  =(1 (lent matched))  [%| %instrument-missing-or-ambiguous]
        (apply held (snag 0 matched) our.bowl src.bowl now.bowl cmd)
  ++  on-init
    =^  cards  inner  on-init:ag
    =.  inner  (synchronize inner held bowl)
    [[boot cards] this]
  ::  v2 guarantees the owner-only /x/qpc/ark/view read surface. The retained
  ::  fields are unchanged; old v1 envelopes migrate without relabeling law.
  ++  on-save  !>([%qpc-law-owner-v2 held on-save:ag])
  ++  on-load
    |=  old=vase
    =/  saved=[state=state inner=vase]
      ?.  ?=([?(%qpc-law-owner-v1 %qpc-law-owner-v2) *] q.old)  [*state old]
      =/  p  !<([?(%qpc-law-owner-v1 %qpc-law-owner-v2) state=state inner=vase] old)
      +.p
    ?>  (lte ~(wyt by state.saved) 64)
    ?>  (levy ~(tap by state.saved) |=([id=@ux rows=(list revision)] (history-valid our.bowl id rows)))
    =.  held  state.saved
    =^  cards  inner  (on-load:ag inner.saved)
    =.  inner  (synchronize inner held bowl)
    [[boot cards] this]
  ++  on-poke
    |=  [=mark =vase]
    ::  The internal context protocol is not an operator or model command.
    ?>  !?=([%qpc-instrument-law-context-v1 *] q.vase)
    ?:  &(=(%noun mark) ?=([%qpc-law-edit-v1 *] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  cmd=command  ;;(command q.vase)
      =/  result  (enact cmd)
      ?>  ?=(%& -.result)
      =.  held  p.result
      =.  inner  (synchronize inner held bowl)
      [~ this]
    ?:  =(%handle-http-request mark)
      =/  [id=@ta req=inbound-request:eyre]  !<([@ta inbound-request:eyre] vase)
      =/  url=@t  url.request.req
      ?:  =('/apps/qpc-ark' (cut 3 [0 13] url))
        ?.  &(authenticated.req =(our.bowl src.bowl))
          [(failure:web id 403 'Owner authentication required.') this]
        ?:  =('GET' method.request.req)
          ?:  |(=('/apps/qpc-ark' url) =('/apps/qpc-ark/' url))
            [(page-response id) this]
          ?:  =('/apps/qpc-ark/state' url)  [(json-response:web id 200 view) this]
          ?:  =('/apps/qpc-ark/ark.js' url)
            =/  js=@t  .^(@t %cx (scot %p our.bowl) q.byk.bowl (scot %da now.bowl) /ui/qpc-ark/js)
            [(respond:web id 200 'application/javascript; charset=utf-8' js %.n) this]
          [(failure:web id 404 'Unknown instrument route.') this]
        ?.  &(=('POST' method.request.req) =('/apps/qpc-ark/edit' url))
          [(failure:web id 405 'Use an explicit law edit.') this]
        =/  headers  (~(gas by *(map @t @t)) header-list.request.req)
        ?.  &(=(`'application/json' (~(get by headers) 'content-type')) =(`'1' (~(get by headers) 'x-qpc-law')))
          [(failure:web id 415 'Use a same-origin law command.') this]
        =/  body  body.request.req
        ?~  body  [(failure:web id 400 'Missing law edit.') this]
        ?.  &(=(p.u.body (met 3 q.u.body)) (lte p.u.body 2.048))
          [(failure:web id 413 'Law edit too large.') this]
        =/  cmd  (decode q.u.body)
        ?~  cmd  [(failure:web id 400 'Invalid typed law edit.') this]
        =/  result  (enact u.cmd)
        ?:  ?=(%| -.result)
          [(failure:web id 409 (scot %tas p.result)) this]
        =.  held  p.result
        =.  inner  (synchronize inner held bowl)
        [(json-response:web id 200 view) this]
      =^  cards  inner  (on-poke:ag mark vase)
      =.  inner  (synchronize inner held bowl)
      [cards this]
    =^  cards  inner  (on-poke:ag mark vase)
    =.  inner  (synchronize inner held bowl)
    [cards this]
  ++  on-peek
    |=  =path
    ?:  =(/x/qpc/ark/view path)
      ?.  =(our.bowl src.bowl)  ~
      ``noun+!>(view)
    ?:  =(/x/qpc/laws path)
      ?.  =(our.bowl src.bowl)  ~
      ``noun+!>(held)
    (on-peek:ag path)
  ++  on-watch
    |=  =path
    ::  Eyre subscribes before authentication; the watch itself emits no data.
    ?:  ?=([%http-response @ ~] path)  [~ this]
    =^  cards  inner  (on-watch:ag path)
    [cards this]
  ++  on-leave
    |=  =path
    ?:  ?=([%http-response @ ~] path)  [~ this]
    =^  cards  inner  (on-leave:ag path)
    [cards this]
  ++  on-agent
    |=  [=wire =sign:agent:gall]
    =^  cards  inner  (on-agent:ag wire sign)
    [cards this]
  ++  on-arvo
    |=  [=wire =sign-arvo]
    ?:  =(/qpc-law-bind wire)  [~ this]
    =^  cards  inner  (on-arvo:ag wire sign-arvo)
    [cards this]
  ++  on-fail
    |=  [=term =tang]
    =^  cards  inner  (on-fail:ag term tang)
    [cards this]
  --
--
