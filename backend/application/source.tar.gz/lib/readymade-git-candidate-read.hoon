::  Canonical receipt and private Clay read boundary for owner proposal intake.
/-  nc=native-coding
/+  bridge=readymade-git-candidate, git=readymade-git-proposal,
    law=native-coding-project, guard=viki-scry-guard
|%
++  read
  |=  [our=@p at=@da p=project:nc ctx=context:nc selected=source-selection:git]
  ^-  (each plan:bridge @tas)
  ?.  (valid:bridge selected)  [%| %selection-invalid]
  =/  source  (current:law our at p)
  ?:  ?=(%| -.source)  [%| p.source]
  ?.  =(source.ctx revision.working.p.source)  [%| %working-source-changed]
  ?.  (agent-live:guard our at %urgit)  [%| %git-agent-unavailable]
  =/  capability=*  .^(* %gx /(scot %p our)/urgit/(scot %da at)/visibility/build/noun)
  ?.  =(marker:git capability)  [%| %git-proposal-unsupported]
  =/  pax=path  (proposal-path:git [repository.selected number.selected base.selected head.selected 0x1])
  =/  raw=*  .^(* %gx (weld ~[(scot %p our) %urgit (scot %da at)] (weld pax /noun)))
  ?.  (lte (met 3 (jam raw)) 2.621.440)  [%| %git-receipt-over-limit]
  =/  parsed  ((soft ,(each proposal:git @tas)) raw)
  ?~  parsed  [%| %git-receipt-incompatible]
  ?:  ?=(%| -.u.parsed)  [%| p.u.parsed]
  (build:bridge our p ctx working.p.source revision.accepted.p.source selected p.u.parsed)
--
