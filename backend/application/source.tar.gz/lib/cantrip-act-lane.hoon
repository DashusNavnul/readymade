::  /lib/cantrip-act-lane.hoon
::
::  The five-verdict law, run live (the producer phase 15 lacked).  An act
::  submission [act summary move-id] is judged by
::  +evaluate-act-verdict:cantrip-law against the law state derived from
::  cantrip's current bands and regime and a residue this lane keeps; the
::  residue moves by +apply-verdict-to-residue.  Every verdict is a fact.
::  A %rival or %branch verdict opens a CONTENTION (lib/cantrip-flect)
::  between the submission and the last accepted act on the same move; a
::  later %accept on that move resolves it, the accepted act's tag as the
::  winner.  Nothing here is advisory: the verdicts are the law's own,
::  computed; the facts are what it said.
::
/-  cs=cantrip
/+  cl=cantrip-verdict, cf=cantrip-flect, clw=cantrip-law-window
|%
+$  organ
  $:  %cantrip-act-lane-v1
      residue=law-residue:cs
      accepted=(map @t act-submission:cs)      ::  last accepted act, by move
      open=(map @t contention:cf)              ::  the open contention, by move
  ==
+$  verdict-fact
  [%cantrip-verdict %1 result=act-verdict-result:cs sub=act-submission:cs who=@p at=@da]
++  empty  ^-  organ  [%cantrip-act-lane-v1 *law-residue:cs ~ ~]
::  the law's state from the window law's bands and regime; the window's
::  three-way drift and rival bands narrow to the law's two, %medium as %high
++  law-state-of
  |=  [b=bands:clw regime=regime:clw]
  ^-  law-state:cs
  =/  two  |=(x=band:clw ^-(?(%low %high) ?:(?=(%low x) %low %high)))
  [regime focus.b goal-distance.b evidence.b (two drift.b) (two rival.b)]
++  submit
  |=  [o=organ sub=act-submission:cs law=law-state:cs who=@p at=@da]
  ^-  [o=organ result=act-verdict-result:cs facts=(list *)]
  =/  v=act-verdict-result:cs  (evaluate-act-verdict:cl sub law residue.o ~ ~)
  =.  residue.o  (apply-verdict-to-residue:cl v residue.o sub)
  =/  facts=(list *)  ~[`verdict-fact`[%cantrip-verdict %1 v sub who at]]
  ?-    verdict.v
      %accept
    =/  was  (~(get by open.o) move-id.sub)
    =.  accepted.o  (~(put by accepted.o) move-id.sub sub)
    ?~  was  [o v facts]
    =.  open.o  (~(del by open.o) move-id.sub)
    [o v (snoc facts `*`(resolve-fact:cf u.was (submission-tag:cf sub) who at))]
  ::
      ?(%rival %branch)
    ::  one contention stands per move until the move accepts
    ?:  (~(has by open.o) move-id.sub)  [o v facts]
    =/  prior  (~(get by accepted.o) move-id.sub)
    ?~  prior  [o v facts]
    =/  c  (contention-of:cf v sub u.prior)
    ?~  c  [o v facts]
    =.  open.o  (~(put by open.o) move-id.sub u.c)
    [o v (snoc facts `*`(open-fact:cf u.c who at))]
  ::
      ?(%retry %reject)
    [o v facts]
  ==
--
