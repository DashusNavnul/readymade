::  One owner-requested observation of the existing private-request route.
::  No task bodies, credentials, provider guesses, commands or saved state.
|%
+$  observation  $%([%unknown ~] [%unavailable ~] [%data value=*])
+$  reader  $-([agent=@tas query=path] observation)
++  native
  |=  [b=bowl:gall agent=@tas query=path]
  ^-  observation
  =/  result=(each observation tang)
    %-  mule
    |.
    ?.  .^(? %gu /(scot %p our.b)/[agent]/(scot %da now.b)/$)
      [%unavailable ~]
    ?:  =(~ query)  [%data ~]
    [%data .^(* %gx (weld /(scot %p our.b)/[agent]/(scot %da now.b) (snoc query %noun)))]
  ?:(?=(%& -.result) p.result [%unknown ~])
++  service
  |=  result=observation
  ^-  json
  s+?:(?=(%data -.result) 'available' ?:(?=(%unavailable -.result) 'unavailable' 'unknown'))
++  flag
  |=  result=observation
  ^-  json
  ?.  ?=(%data -.result)  ~
  =/  value=(unit ?)  ((soft ?) value.result)
  ?~(value ~ b+u.value)
++  protocol
  |=  result=observation
  ^-  json
  ?.  ?=(%data -.result)  ~
  =/  value=(unit (unit @tas))  ((soft (unit @tas)) value.result)
  ?~  value  ~
  ?~  u.value  ~
  ?.  (lte (met 3 u.u.value) 64)  ~
  s+u.u.value
++  trust
  |=  result=observation
  ^-  json
  ?.  ?=(%data -.result)  ~
  =/  names=*  value.result
  =/  left=@ud  256
  |-  ^-  json
  ?~  names  b+%.n
  ?.  ?=(^ names)  ~
  ?:  =(0 left)  ~
  ?.  ?=(@ -.names)  ~
  ?:  =('noltbook' -.names)  b+%.y
  $(names +.names, left (dec left))
++  ceiling
  |=  result=observation
  ^-  json
  ?.  ?=(%data -.result)  ~
  =/  value=(unit @tas)  ((soft @tas) value.result)
  ?~  value  ~
  ?.  (lte (met 3 u.value) 64)  ~
  s+u.value
++  view
  |=  [our=@p now=@da read=reader]
  ^-  json
  %-  pairs:enjs:format
  :~  ['schema' s+'readymade-model-setup-v1']
      ['owner' s+(scot %p our)]
      ['observedAt' (sect:enjs:format now)]
      ['a2a' (service (read %a2a ~))]
      ['cantrip' (service (read %cantrip ~))]
      ['viki' (service (read %viki ~))]
      ['bridge' (service (read %model-bridge ~))]
      ['portOpen' (flag (read %model-bridge /port/open))]
      ['peerReady' (flag (read %model-bridge /ready))]
      ['peerBusy' (flag (read %model-bridge /pending))]
      ['peerProtocol' (protocol (read %model-bridge /peer/protocol))]
      ['privateTrusted' (trust (read %a2a /trusted))]
      ['ceiling' (ceiling (read %cantrip /law/ceiling))]
  ==
--
