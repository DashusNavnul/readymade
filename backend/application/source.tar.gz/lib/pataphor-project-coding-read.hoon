::  Current private development project from its canonical catalog and Clay.
::  Complete desk maps bind metadata; only Hoon source enters model context.
/-  pc=pataphor-project-coding
/+  coding=pataphor-project-coding, save=cantrip-project-save,
    project=cantrip-project-save-read
|%
++  accepted  %pataphor-dev
++  working  %pataphor-dev-work
++  read
  |=  [our=@p actor=@p at=@da]
  ^-  (each manifest:pc @tas)
  ?.  =(our actor)  [%| %foreign-owner]
  =/  basis  (read:project our actor at project:coding working)
  ?:  ?=(%| -.basis)  [%| p.basis]
  ?.  =(accepted base-desk.project.p.basis)  [%| %development-base-mismatch]
  =/  revision=@ud  base-revision.body.snapshot.working.p.basis
  =/  rows  ~(tap by files.body.snapshot.working.p.basis)
  =/  sources=(map path @t)  ~
  =/  total=@ud  0
  |-  ^-  (each manifest:pc @tas)
  ?~  rows
    =/  manifest=manifest:pc
      [%pataphor-project-manifest-v1 p.basis sources targets:coding]
    ?.  (manifest-valid:coding manifest)  [%| %manifest-invalid]
    [%& manifest]
  =/  pax=path  p.i.rows
  ?.  (path-valid:save pax)  $(rows t.rows)
  =/  source=@t
    .^(@t %cx (scot %p our) working (scot %ud revision) pax)
  =/  size=@ud  (met 3 source)
  ?.  &((lte size 32.768) (lte (add total size) 65.536))
    [%| %source-over-limit]
  ?.  =(q.i.rows `@ux`(page-to-lobe:clay [%hoon source]))
    [%| %source-hash-mismatch]
  $(rows t.rows, total (add total size), sources (~(put by sources) pax source))
--
