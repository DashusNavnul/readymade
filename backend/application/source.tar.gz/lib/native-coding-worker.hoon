::  Pure candidate-build binding law. The caller supplies canonical source,
::  current permission and authenticated transport; wire data cannot grant it.
/-  w=native-coding-worker, nc=native-coding, b=boks, g=grav
/+  project=native-coding-project, budget=native-coding-hoon-check-budget,
    bl=boks, gl=grav
|%
++  digest
  |=(value=* ^-(@ux (shax (jam [%native-coding-worker-v1 value]))))
++  identifier
  |=(value=@ux &(!=(0 value) (lte (met 0 value) 256)))
++  pairing-valid
  |=  p=pairing:w
  ^-  ?
  ?&  !=(owner.p worker.p)  =(%earl (clan:title worker.p))
      =(owner.p (^sein:title worker.p))  (gth generation.p 0)
      (lte generation.p 4.294.967.295)
      (identifier kernel.toolchain.p)  (identifier executor.toolchain.p)
  ==
++  target-valid
  |=  t=build-target:nc
  ^-  ?
  ?&  =(%hoon kind.t)  !=(0 name.t)  (lte (met 3 name.t) 128)
      ?=(^ entry.t)  (path-valid:project entry.t)
      =(%hoon (rear entry.t))
      (lte (lent dependencies.t) 128)
      (levy dependencies.t |=(p=path &(?=(^ p) (path-valid:project p))))
      (lte (lent checks.t) 32)
      =((lent checks.t) ~(wyt in (silt (turn checks.t |=([n=@tas e=@t] n)))))
      %+  levy  checks.t
      |=  [name=@tas expression=@t]
      &(!=(0 name) !=(%compile name) (lte (met 3 name) 128) !=('' expression) (lte (met 3 expression) 8.192))
  ==
++  order-valid
  |=  o=order:w
  ^-  ?
  ?&  (pairing-valid pairing.o)
      (levy `(list @ux)`~[ticket.o grant.o authority.o decision.o candidate.o namespace.o configuration.context.o session.context.o request.context.o] identifier)
      =(owner.pairing.o actor.context.o)
      =(owner.pairing.o owner.source.context.o)
      =(owner.pairing.o owner.source.o)
      (revision-valid:project source.o)  (revision-valid:project source.context.o)
      !=('' project.context.o)  (lte (met 3 project.context.o) 128)
      (gth (lent targets.o) 0)  (lte (lent targets.o) 64)
      (levy targets.o target-valid)
      =((lent targets.o) ~(wyt in (silt (turn targets.o |=(t=build-target:nc name.t)))))
      (gte maximum.o 1)  (lte maximum.o candidate-total-limit:budget)
      (gth (units:budget targets.o) 0)
      (gte maximum.o (units:budget targets.o))
      (gth issued.o 0)  (gth deadline.o issued.o)
      (lte deadline.o (add issued.o ~m30))
      (lte (met 3 (jam o)) 262.144)
  ==
++  authorized
  ::  No expiry on pairing/session authority. Only this operation has a limit.
  |=  [s=scope:w o=order:w]
  ^-  ?
  ?&  !revoked.s  (order-valid o)
      =(pairing.s pairing.o)  =(grant.s grant.o)
      =(authority.s authority.o)  =(decision.s decision.o)
  ==
++  namespace-digest
  |=(files=(map path @ux) ^-(@ux (digest [%namespace files])))
++  source-ready
  ::  Worker calls only with its own numbered Clay read after staged import.
  ::  This checks the COMPLETE namespace, not merely the declared imports.
  |=  [o=order:w local=revision:nc files=(map path @ux)]
  ^-  ?
  ?&  (order-valid o)  (revision-valid:project local)
      =(worker.pairing.o owner.local)
      (lte ~(wyt by files) max-files:project)
      =((namespace-digest files) namespace.o)
      (levy ~(tap by files) |=([pax=path blob=@ux] &(?=(^ pax) (path-valid:project pax) (identifier blob))))
      %+  levy  targets.o
      |=  t=build-target:nc
      (levy `(list path)`[entry.t dependencies.t] |=(pax=path (~(has by files) pax)))
  ==
++  task-id
  |=(o=order:w ^-(@t (cat 3 'native-hoon-build-' (scot %ux (digest o)))))
++  task
  ::  Boks carries a bounded reference, not source bytes or executable nouns.
  ::  Resolving this exact order and importing its source is a later stage.
  |=  o=order:w
  ^-  task-request:b
  :*  %boks-task-request-v1
      (task-id o)
      (cat 3 'Build the exact native Hoon candidate order ' (scot %ux (digest o)))
      [%boks-task-authority-v1 ~[(spat /(scot %p owner.source.o)/(scot %tas desk.source.o)/(scot %ud number.source.o))] ~ ~[%compile %check] %.n (sub deadline.o issued.o) 262.144]
      ~[%native-coding-worker-result-v1]
  ==
++  envelope
  |=  o=order:w
  ^-  envelope:b
  (make-envelope:bl [%boks-envelope-v1 worker.pairing.o 'juggler-native-v1' 'juggler-native-v1' (task-id o) ~ [%task (task o)] issued.o deadline.o])
++  ingress-matches
  ::  A caller must first authenticate the local Boks subscription. A forged
  ::  admitted noun supplied in an ordinary poke never reaches this gate.
  |=  [o=order:w ingress=admitted:b now=@da]
  ^-  ?
  ?&  (order-valid o)  (envelope-valid:bl envelope.ingress)
      =(source.ingress owner.pairing.o)  =(envelope.ingress (envelope o))
      (lte issued.o received-at.ingress)  (lte received-at.ingress now)
      (lth now deadline.o)
  ==
++  grav-ready
  ::  A queued Boks task alone cannot dispatch. Grav's distinct admission
  ::  must name this exact order as its ceiling and the frozen decision.
  |=  [o=order:w r=record:g now=@da]
  ^-  ?
  ?.  (order-valid o)  %.n
  ?.  &(=(request.r (task o)) =(source.r owner.pairing.o))  %.n
  =/  wire=envelope:b  (envelope o)
  ?.  &(=(source-envelope.r digest.wire) (may-dispatch:gl r now))  %.n
  ?>  ?=(^ binding.r)
  ?.  =(u.binding.r [%grav-binding-v1 'juggler-native-v1' owner.pairing.o 'juggler-native-v1' project.context.o 'native-hoon' %native-coding-worker %native-coding-worker-v1])  %.n
  ?>  ?=(%admitted -.admission.r)
  ?&  =(decision.o decision.admission.r)
      =((digest o) ceiling.admission.r)
      =(deadline.o expires-at.admission.r)  =(deadline.o overall-deadline.r)
  ==
++  row-valid
  |=  [r=row:w local=revision:nc]
  ^-  ?
  ?&  (target-valid target.r)
      =([%compile (turn checks.target.r |=([n=@tas e=@t] n))] (turn diagnostics.r |=(d=diagnostic:nc name.d)))
      %+  levy  diagnostics.r
      |=  d=diagnostic:nc
      &((lte (met 3 detail.d) 32.768) =(local source.d) (lte (lent artifacts.d) 4) (levy artifacts.d identifier))
  ==
++  result-matches
  ::  Shape and exact source binding, not independent proof of execution.
  ::  The receiver must authenticate the selected worker's native result app.
  |=  [o=order:w r=result:w]
  ^-  ?
  ?.  ?&  (order-valid o)  =((digest o) request.r)
          =(worker.pairing.o worker.r)  =(generation.pairing.o generation.r)
          =(toolchain.pairing.o toolchain.r)
          =(source.o source.r)  =(namespace.o namespace.r)
          (lte issued.o started.r)  (lte started.r finished.r)
          (lte (met 3 (jam r)) 262.144)
      ==  %.n
  ?^  local.r
    ?.  &((revision-valid:project u.local.r) =(worker.r owner.u.local.r))  %.n
    ?:  ?=(%refused -.outcome.r)
      &(!=(0 reason.outcome.r) (lte (met 3 reason.outcome.r) 128) (lte (met 3 detail.outcome.r) 2.048))
    ?&  =(targets.o (turn rows.outcome.r |=(row=row:w target.row)))
        (levy rows.outcome.r |=(row=row:w (row-valid row u.local.r)))
    ==
  ?.  ?=(%refused -.outcome.r)  %.n
  &(!=(0 reason.outcome.r) (lte (met 3 reason.outcome.r) 128) (lte (met 3 detail.outcome.r) 2.048))
--
