::  Pure callback reducer. Only an authenticated local Spider wrapper calls it.
::  The retained pending tid is the authority boundary; remote nouns are not.
/-  c=readymade-collab, j=readymade-collab-jobs, pkg=readymade-package
/+  flow=readymade-collab, package=readymade-package,
    transfer=readymade-package-transfer, release=readymade-package-release,
    compiler=readymade-package-build
|%
++  native-reason
  |=  reason=@tas
  ^-  @t
  ?.  &((gth (met 3 reason) 0) (lte (met 3 reason) 128))
    'invalid-native-reason'
  ?.  %+  levy  (trip reason)
      |=  char=@t
      |(&((gte char 'a') (lte char 'z')) &((gte char '0') (lte char '9')) =(char '-'))
    'invalid-native-reason'
  `@t`reason
++  ignore
  |=  [state=state:c ledger=ledger:j message=@t]
  ^-  change:j
  [state ledger %.n ~ message]
++  settle
  |=  $:  our=@p
          state=state:c
          ledger=ledger:j
          tid=@ta
          job=job:j
          phase=?(%confirmed %refused %uncertain)
          result=*
          outgoing=(unit envelope:c)
          message=@t
      ==
  ^-  change:j
  =/  receipt=receipt:c
    [request.command.job op.command.job phase our message]
  :*  (record:flow state receipt)
      (~(put by ledger) tid job(phase phase, result `result))
      %.y
      outgoing
      message
  ==
++  release-complete
  |=  [our=@p state=state:c ledger=ledger:j tid=@ta job=job:j result=*]
  ^-  change:j
  =/  parsed=(unit result:release)  ((soft result:release) result)
  ?~  parsed  (ignore state ledger 'Malformed release callback.')
  =/  answer=result:release  u.parsed
  ?.  =(request.answer request.command.job)
    (ignore state ledger 'Release request mismatch.')
  ?:  ?=(%readymade-package-release-refused -.answer)
    (settle our state ledger tid job %refused result ~ (cat 3 'Native selective release refused: ' (native-reason reason.answer)))
  ?:  ?=(%readymade-package-release-uncertain -.answer)
    (settle our state ledger tid job %uncertain result ~ (cat 3 'Native selective release uncertain; do not retry: ' (native-reason reason.answer)))
  =/  cmd=command:c  command.job
  =/  peer=(unit @p)  (slaw %p peer.cmd)
  =/  graf=(unit @ux)  (slaw %ux digest.cmd)
  =/  selected=(unit selection:release)  (select:release reference.cmd)
  ?.  &(?=(^ peer) ?=(^ graf) ?=(^ selected))
    (ignore state ledger 'Release command binding mismatch.')
  ?.  &((digest-valid:package u.graf) (files-valid:package files.answer))
    (ignore state ledger 'Release manifest invalid.')
  ?.  ?=([* ~] files.answer)
    (ignore state ledger 'Release must contain one selected source.')
  =/  file=file:pkg  i.files.answer
  ?.  ?&  =(our ship.original.answer)
          =(our ship.release.answer)
          =(desk.original.answer desk.u.selected)
          =(revision.original.answer revision.u.selected)
          =(path.file path.u.selected)
          (gth size.file 0)
          (lte size.file 262.144)
          (pin-valid:package original.answer)
          (pin-valid:package release.answer)
          (lte (met 0 root.original.answer) 256)
          (lte (met 0 root.release.answer) 256)
          (lte revision.release.answer 18.446.744.073.709.551.615)
          !=(desk.original.answer desk.release.answer)
          =(desk.release.answer (name:release our u.peer request.cmd original.answer file))
      ==
    (ignore state ledger 'Release provenance or selection mismatch.')
  =/  body=body:pkg
    [%readymade-package-v1 our u.peer u.graf release.answer files.answer summary.cmd]
  ?.  (body-valid:package body)
    (ignore state ledger 'Released offer invalid.')
  =/  offer=offer:pkg  (make:package body)
  =/  old=(unit package:c)  (~(get by packages.state) digest.offer)
  ?^  old
    ?.  ?&  =(offer offer.value.u.old)
            =(title.cmd title.u.old)
            =(summary.cmd summary.u.old)
        ==
      (ignore state ledger 'Released offer conflicts with retained state.')
    =/  outgoing=envelope:c
      [%readymade-collab-wire-v1 request.cmd [%package title.cmd summary.cmd offer]]
    (settle our state ledger tid job %confirmed result `outgoing 'Selected source released; peer delivery and consent remain separate.')
  ?:  (gte ~(wyt by packages.state) 256)
    (settle our state ledger tid job %refused result ~ 'Package capacity reached; release retained without sending.')
  =/  item=package:c  [title.cmd summary.cmd [offer %received ~ ~ ~ ~]]
  =/  next=state:c  state(packages (~(put by packages.state) digest.offer item))
  =/  outgoing=envelope:c
    [%readymade-collab-wire-v1 request.cmd [%package title.cmd summary.cmd offer]]
  (settle our next ledger tid job %confirmed result `outgoing 'Selected source released; peer delivery and consent remain separate.')
++  inspect-complete
  |=  [our=@p state=state:c ledger=ledger:j tid=@ta job=job:j result=*]
  ^-  change:j
  =/  parsed
    ((soft ,[%readymade-package-inspection-v1 offer=@ux nonce=@ux answer=(each bundle:transfer @tas)]) result)
  ?~  parsed  (ignore state ledger 'Malformed inspection callback.')
  =/  callback  u.parsed
  ?.  &(=(offer.job `offer.callback) =(nonce.job nonce.callback))
    (ignore state ledger 'Inspection offer or nonce mismatch.')
  ?:  ?=(%| -.answer.callback)
    (settle our state ledger tid job %refused result ~ (cat 3 'Native source inspection refused: ' (native-reason p.answer.callback)))
  =/  old=(unit package:c)  (~(get by packages.state) offer.callback)
  ?~  old  (ignore state ledger 'Inspection package is not retained.')
  =/  item=package:c  u.old
  =/  bundle=bundle:transfer  p.answer.callback
  ?.  ?&  =(our recipient.body.offer.value.item)
          =(peer.command.job (scot %p sender.body.offer.value.item))
          =(nonce.job nonce.bundle)
          (valid:transfer offer.value.item bundle)
      ==
    (ignore state ledger 'Inspection bundle does not match the canonical offer.')
  ::  Persist commitments only, even if canonical state refuses inspection.
  =/  receipt
    [%readymade-package-inspection-receipt-v1 offer.callback nonce.callback pin.bundle (manifest:package files.body.offer.value.item) proof.bundle]
  =/  moved
    (inspect:package value.item pin.bundle (turn sources.bundle |=(s=source:transfer file.s)))
  ?.  ?=(%& -.moved)
    (settle our state ledger tid job %refused receipt ~ 'Canonical package state refused inspection.')
  =/  next=state:c
    state(packages (~(put by packages.state) offer.callback item(value p.moved)))
  (settle our next ledger tid job %confirmed receipt ~ 'Exact source and pinned manifest inspected; no execution occurred.')
++  stage-complete
  |=  [our=@p state=state:c ledger=ledger:j tid=@ta job=job:j result=*]
  ^-  change:j
  =/  parsed
    ((soft ,[%readymade-package-stage-v1 offer=@ux nonce=@ux answer=stage-result:j]) result)
  ?~  parsed  (ignore state ledger 'Malformed workspace callback.')
  =/  callback  u.parsed
  ?.  &(=(offer.job `offer.callback) =(nonce.job nonce.callback))
    (ignore state ledger 'Workspace offer or nonce mismatch.')
  ?:  ?=(%refused -.answer.callback)
    (settle our state ledger tid job %refused result ~ (cat 3 'Native workspace preparation refused: ' (native-reason reason.answer.callback)))
  ?:  ?=(%uncertain -.answer.callback)
    (settle our state ledger tid job %uncertain result ~ (cat 3 'Native workspace uncertain; do not retry: ' (native-reason reason.answer.callback)))
  =/  old=(unit package:c)  (~(get by packages.state) offer.callback)
  ?~  old  (ignore state ledger 'Workspace package is not retained.')
  =/  value=state:pkg  value.u.old
  ?.  ?&  (valid:package offer.value)
          =(our recipient.body.offer.value)
          =(peer.command.job (scot %p sender.body.offer.value))
          =(%accepted stage.value)
          ?=(^ destination.value)
          ?=(^ consent.value)
      ==
    (ignore state ledger 'Canonical package no longer authorizes this workspace.')
  ?.  ?&  =(destination.answer.callback u.destination.value)
          =(u.consent.value (consent-digest:package offer.value u.destination.value))
          =(1 revision.answer.callback)
          !=(0 root.answer.callback)
          (lte (met 0 root.answer.callback) 256)
          (digest-valid:package proof.answer.callback)
          (digest-valid:package source-proof.answer.callback)
      ==
    (ignore state ledger 'Workspace evidence does not match canonical consent.')
  ::  Proofs attest the trusted native readback. Their local foundation pages
  ::  are not present here; execution must re-read actual Clay independently.
  (settle our state ledger tid job %confirmed result ~ 'Private inactive workspace prepared; package remains accepted, not built.')
++  build-complete
  |=  [our=@p state=state:c ledger=ledger:j tid=@ta job=job:j result=*]
  ^-  change:j
  ?:  (gth (met 3 (jam result)) 131.072)
    (ignore state ledger 'Build callback exceeds its bounded receipt.')
  =/  parsed
    ((soft ,[%readymade-package-build-v1 offer=@ux nonce=@ux answer=result:compiler]) result)
  ?~  parsed  (ignore state ledger 'Malformed native build callback.')
  =/  callback  u.parsed
  ?.  &(=(offer.job `offer.callback) =(nonce.job nonce.callback))
    (ignore state ledger 'Build offer or nonce mismatch.')
  ?:  ?=(%refused -.answer.callback)
    (settle our state ledger tid job %refused result ~ (cat 3 'Native compile refused: ' (native-reason reason.answer.callback)))
  ?:  ?=(%uncertain -.answer.callback)
    (settle our state ledger tid job %uncertain result ~ (cat 3 'Native compile uncertain; observe without retry: ' (native-reason reason.answer.callback)))
  =/  prepared  (ready:compiler our state ledger offer.callback nonce.callback)
  ?.  ?=(%& -.prepared)
    (ignore state ledger 'Canonical package, consent or stage changed during compilation.')
  =/  plan=plan:compiler  p.prepared
  =/  item=package:c  (~(got by packages.state) offer.callback)
  ?:  ?=(%confirmed -.answer.callback)
    =/  receipt=receipt:compiler  receipt.answer.callback
    ?.  &((valid:compiler our receipt) =(plan plan.body.receipt))
      (ignore state ledger 'Compiled artifact does not match exact canonical build plan.')
    (finish-build our state ledger tid job result item plan %.y `artifact.body.receipt proof.receipt)
  ?.  (lien files.body.offer.plan |=(f=file:pkg =(path.f path.answer.callback)))
    (ignore state ledger 'Compile failure names an undeclared source path.')
  =/  proof=@ux  (shax (jam [%readymade-package-build-failure-v1 our plan answer.callback]))
  (finish-build our state ledger tid job result item plan %.n ~ proof)
++  finish-build
  |=  $:  our=@p
          state=state:c
          ledger=ledger:j
          tid=@ta
          job=job:j
          result=*
          item=package:c
          plan=plan:compiler
          success=?
          artifact=(unit @ux)
          proof=@ux
      ==
  ^-  change:j
  =/  offer=offer:pkg  offer.plan
  =/  exact=result:pkg
    [digest.offer consent.plan source.body.offer (manifest:package files.body.offer) success artifact proof]
  =/  moved  (finish:package our our value.item source.body.offer exact)
  ?.  ?=(%& -.moved)  (ignore state ledger 'Canonical package refused the exact compile result.')
  =/  next=state:c
    state(packages (~(put by packages.state) digest.offer item(value p.moved)))
  =/  message=@t
    ?:  success
      'Native Hoon source compiled; functional tests and deployment were not run.'
    'Native Hoon compilation failed; the exact failure is recorded.'
  (settle our next ledger tid job %confirmed result ~ message)
++  complete
  |=  [our=@p state=state:c ledger=ledger:j tid=@ta result=*]
  ^-  change:j
  ?.  &((lte ~(wyt by ledger) 1.024) (lte (met 3 (jam result)) 18.874.368))
    (ignore state ledger 'Callback or journal exceeds its bound.')
  =/  found=(unit job:j)  (~(get by ledger) tid)
  ?~  found  (ignore state ledger 'Unknown native job.')
  =/  job=job:j  u.found
  ?.  =(%pending phase.job)
    (ignore state ledger 'Native job already settled; no replay or retry.')
  =/  cmd=command:c  command.job
  =/  peer=(unit @p)  (slaw %p peer.cmd)
  ?.  ?&  =(owner.cmd (scot %p our))
          (identifier:flow request.cmd)
          (digest-valid:package nonce.job)
          ?=(^ peer)
      ==
    (ignore state ledger 'Invalid retained owner job.')
  ?.  &(!=(our u.peer) =(peer.cmd (scot %p u.peer)))
    (ignore state ledger 'Invalid retained peer.')
  ?-  kind.job
    %release
      ?.  ?&  =('offer' op.cmd)
              ?=(~ offer.job)
              (identifier:flow title.cmd)
              (bounded-text:flow summary.cmd 4.096)
          ==
        (ignore state ledger 'Release job kind mismatch.')
      (release-complete our state ledger tid job result)
    %inspect
      ?.  =('inspect' op.cmd)
        (ignore state ledger 'Inspection job kind mismatch.')
      (inspect-complete our state ledger tid job result)
    %stage
      ?.  =('accept' op.cmd)
        (ignore state ledger 'Workspace job kind mismatch.')
      (stage-complete our state ledger tid job result)
    %build
      ?.  =('build' op.cmd)
        (ignore state ledger 'Build job kind mismatch.')
      (build-complete our state ledger tid job result)
  ==
--
