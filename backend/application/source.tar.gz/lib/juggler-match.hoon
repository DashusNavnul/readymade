::  /lib/juggler-match.hoon
::
::  Pure event-sourced Juggler match kernel.  The future Gall shell maps bowl
::  identity onto `source`; this kernel never reads actor identity from a
::  contribution payload.
::
/-  jm=juggler-match
|%
++  max-body-bytes  16.384
++  max-relations   32
++  max-pending     64
++  max-moves       4.096
::
++  initial-state
  ^-  match-state:jm
  :*  'juggler-shared-match-v1'
      %vacant
      ~
      1
      ~
      ~
      ~
      ~
      ~
  ==
::
++  non-empty
  |=  text=@t
  ^-  ?
  !=(0 (met 3 text))
::
++  move-limit-error
  |=  [move-count=@ud accepted=?]
  ^-  (unit @tas)
  ?.  accepted  ~
  ?:  (gte move-count max-moves)  `%move-limit
  ~
::
++  participant-valid
  |=  participant=participant:jm
  ^-  ?
  (non-empty human.participant)
::
++  participant-for
  |=  [config=match-config:jm who=@p]
  ^-  (unit participant:jm)
  ?:  =(who ship.left.config)   `left.config
  ?:  =(who ship.right.config)  `right.config
  ~
::
++  move-for
  |=  [moves=(list move:jm) wanted=@ud]
  ^-  (unit move:jm)
  ?~  moves  ~
  ?:  =(wanted id.i.moves)  `i.moves
  $(moves t.moves)
::
++  pending-for
  |=  [pending=(list pending-contribution:jm) proposal-id=@t]
  ^-  (unit pending-contribution:jm)
  ?~  pending  ~
  ?:  =(proposal-id proposal-id.contribution.i.pending)  `i.pending
  $(pending t.pending)
::
++  drop-pending
  |=  [pending=(list pending-contribution:jm) proposal-id=@t]
  ^-  (list pending-contribution:jm)
  ?~  pending  ~
  ?:  =(proposal-id proposal-id.contribution.i.pending)  t.pending
  [i.pending $(pending t.pending)]
::
++  proposal-used
  |=  [state=match-state:jm proposal-id=@t]
  ^-  ?
  ?:  (lien pending.state |=(item=pending-contribution:jm =(proposal-id proposal-id.contribution.item)))
    %.y
  (lien settlements.state |=(item=settlement:jm =(proposal-id proposal-id.contribution.item)))
::
++  anchor-valid
  |=  [state=match-state:jm anchor=anchor:jm]
  ^-  ?
  ?-  -.anchor
    %match  %.y
    %axis   (gth axis.anchor 0)
    %move   ?=(^ (move-for moves.state id.anchor))
  ==
::
++  author-valid
  |=  author=author:jm
  ^-  ?
  ?-  -.author
    %human          %.y
    %model-assisted  (non-empty model.author)
    %model-proposed  (non-empty model.author)
  ==
::
++  relation-valid
  |=  [state=match-state:jm relation=relation:jm]
  ^-  ?
  (anchor-valid state target.relation)
::
++  contribution-error
  |=  [state=match-state:jm contribution=contribution:jm]
  ^-  (unit @tas)
  ?.  (non-empty proposal-id.contribution)  `%empty-proposal-id
  ?.  (non-empty body.contribution)         `%empty-body
  ?.  (lte (met 3 body.contribution) max-body-bytes)  `%body-too-large
  ?.  (author-valid author.contribution)    `%invalid-author
  ?.  (anchor-valid state parent.contribution)  `%unknown-parent
  ?.  (lte (lent relations.contribution) max-relations)  `%relation-limit
  ?.  (levy relations.contribution |=(relation=relation:jm (relation-valid state relation)))
    `%unknown-relation
  ?:  =(%propose kind.contribution)
    ?:  ?&  ?=(~ target.contribution)
            ?=(~ artifact.contribution)
        ==
      ~
    `%invalid-propose-shape
  ?~  target.contribution  `%missing-target
  ?.  ?=(^ (move-for moves.state u.target.contribution))  `%unknown-target
  ?:  =(%close kind.contribution)
    ?~  artifact.contribution  `%missing-artifact
    ?:  (non-empty u.artifact.contribution)  ~
    `%empty-artifact
  ?:  ?=(~ artifact.contribution)  ~
  `%unexpected-artifact
::
++  accepted-by
  |=  [moves=(list move:jm) who=@p target-id=@ud]
  ^-  ?
  ?~  moves  %.n
  =/  item=move:jm  i.moves
  ?.  =(who actor.item)  $(moves t.moves)
  ?.  =(%accept kind.contribution.item)  $(moves t.moves)
  ?~  target.contribution.item  $(moves t.moves)
  ?:  =(target-id u.target.contribution.item)  %.y
  $(moves t.moves)
::
++  dual-accept
  |=  [state=match-state:jm target-id=@ud]
  ^-  ?
  ?~  config.state  %.n
  ?&  (accepted-by moves.state ship.left.u.config.state target-id)
      (accepted-by moves.state ship.right.u.config.state target-id)
  ==
::
++  apply-event
  |=  [state=match-state:jm event=match-event:jm]
  ^-  match-state:jm
  ?-  -.event
    %opened
      :*  version.state
          %open
          `config.event
          1
          ~
          ~
          ~
          ~
          [event events.state]
      ==
    %queued
      %=  state
        pending  [pending.event pending.state]
        events   [event events.state]
      ==
    %settled
      =/  settled=settlement:jm  settlement.event
      =/  next=match-state:jm
        %=  state
          pending
            (drop-pending pending.state proposal-id.contribution.settled)
          settlements  [settled settlements.state]
          events       [event events.state]
        ==
      ?~  move-id.settled  next
      =/  moved=move:jm
        [u.move-id.settled actor.settled human.settled contribution.settled admission.settled]
      =/  closes=?  =(%close kind.contribution.settled)
      %=  next
        next-move-id  +(u.move-id.settled)
        moves         [moved moves.next]
        status        ?:(closes %closed status.next)
        closure
          ?:  closes
            `[(need target.contribution.settled) (need artifact.contribution.settled)]
          closure.next
      ==
  ==
::
++  replay
  |=  events=(list match-event:jm)
  ^-  match-state:jm
  =/  state=match-state:jm  initial-state
  |-
  ?~  events  state
  $(events t.events, state (apply-event state i.events))
::
++  refuse
  |=  [state=match-state:jm code=@tas]
  ^-  match-result:jm
  [%.n code state ~]
::
++  succeed
  |=  [state=match-state:jm code=@tas event=match-event:jm]
  ^-  match-result:jm
  [%.y code (apply-event state event) `event]
::
++  open-match
  |=  [state=match-state:jm actor=@p config=match-config:jm]
  ^-  match-result:jm
  ?.  =(%vacant status.state)  (refuse state %already-opened)
  ?.  =(actor host.config)  (refuse state %not-host)
  ?.  ?&  (non-empty match-id.config)
          (non-empty objective.config)
          (participant-valid left.config)
          (participant-valid right.config)
          !=(ship.left.config ship.right.config)
          !=(human.left.config human.right.config)
          !=(host.config ship.left.config)
          !=(host.config ship.right.config)
      ==
    (refuse state %invalid-config)
  (succeed state %opened [%opened config])
::
++  submit
  |=  [state=match-state:jm actor=@p contribution=contribution:jm]
  ^-  match-result:jm
  ?.  =(%open status.state)  (refuse state %match-not-open)
  ?~  config.state  (refuse state %missing-config)
  =/  participant=(unit participant:jm)
    (participant-for u.config.state actor)
  ?~  participant  (refuse state %not-participant)
  ?:  (proposal-used state proposal-id.contribution)
    (refuse state %proposal-used)
  ?:  (gte (lent pending.state) max-pending)
    (refuse state %pending-limit)
  =/  error=(unit @tas)  (contribution-error state contribution)
  ?^  error  (refuse state u.error)
  =/  pending=pending-contribution:jm
    [actor human.u.participant contribution]
  (succeed state %queued [%queued pending])
::
++  settle
  |=  [state=match-state:jm actor=@p proposal-id=@t admission=admission:jm]
  ^-  match-result:jm
  ?.  =(%open status.state)  (refuse state %match-not-open)
  ?~  config.state  (refuse state %missing-config)
  ?.  =(actor host.u.config.state)  (refuse state %not-cantrip-host)
  =/  pending=(unit pending-contribution:jm)
    (pending-for pending.state proposal-id)
  ?~  pending  (refuse state %pending-not-found)
  ?.  =(proposal-id proposal-id.admission)
    (refuse state %admission-mismatch)
  ?.  ?&  (non-empty receipt-id.admission)
          (non-empty law.admission)
          (non-empty reason.admission)
      ==
    (refuse state %invalid-admission)
  =/  contribution=contribution:jm  contribution.u.pending
  =/  settlement-error=(unit @tas)
    =/  capacity-error=(unit @tas)
      (move-limit-error (lent moves.state) accepted.admission)
    ?^  capacity-error  capacity-error
    ?.  accepted.admission  ~
    ?.  =(%close kind.contribution)  ~
    ?.  =(1 (lent pending.state))  `%pending-remains
    ?:  (dual-accept state (need target.contribution))  ~
    `%dual-accept-required
  ?^  settlement-error  (refuse state u.settlement-error)
  =/  move-id=(unit @ud)
    ?:(accepted.admission `next-move-id.state ~)
  =/  settlement=settlement:jm
    :*  actor.u.pending
        human.u.pending
        contribution
        admission
        move-id
    ==
  (succeed state ?:(accepted.admission %accepted %rejected) [%settled settlement])
::
++  apply
  |=  [state=match-state:jm action=match-action:jm source=source:jm]
  ^-  match-result:jm
  ?-  -.action
    %open
      ?.  ?=(%host -.source)  (refuse state %host-source-required)
      (open-match state ship.source config.action)
    %submit
      ?.  ?=(%participant -.source)
        (refuse state %participant-source-required)
      (submit state ship.source contribution.action)
    %settle
      ?.  ?=(%cantrip -.source)
        (refuse state %cantrip-source-required)
      (settle state ship.source proposal-id.action admission.action)
  ==
--
