::  Native candidate-owner archive adapter. No runtime activation lives here.
::  Append once; independently read both immutable indices before retirement.
/-  w=native-coding-worker
/+  law=native-coding-worker-owner-archive, accept=native-coding-accept,
    read=native-coding-worker-owner-read, ct=cantrip-native-coding,
    allowance=native-coding-check-authorization, names=native-coding-provider
|%
+$  change  [archive=state:law parent=parent:law cards=(list card:agent:gall)]
+$  readout  (each (unit *) @tas)
+$  found  (each (unit receipt:law) @tas)
+$  pointer  [%native-worker-owner-ticket-v1 key=@ux digest=@ux]
+$  resolver  $-(@ux (unit receipt:law))
+$  driver
  $:  by-key=$-([b=bowl:gall s=state:law key=@ux] found)
      by-ticket=$-([b=bowl:gall s=state:law ticket=@ux] found)
      configure=$-([b=bowl:gall s=state:law desk=@tas] state:law)
      advance=$-([inner=agent:gall b=bowl:gall s=state:law parent=parent:law] change)
      observe=$-([inner=agent:gall b=bowl:gall s=state:law parent=parent:law] change)
      one=$-([inner=agent:gall b=bowl:gall s=state:law parent=parent:law key=@ux expected=@ux] change)
  ==
++  beam
  |=  [our=@p h=head:law pax=path]
  ^-  path
  (weld ~[(scot %p our) desk.h (scot %ud number.h)] pax)
++  law-name
  |=(desk=@tas &((name-valid:names desk) !=(%base desk)))
++  private
  |=  [our=@p now=@da desk=@tas pax=path]
  ^-  ?
  =/  rules=[r=dict:clay w=dict:clay]
    .^([r=dict:clay w=dict:clay] %cp (weld ~[(scot %p our) desk (scot %da now)] pax))
  &(=([%white ~ ~] rul.r.rules) =([%white ~ ~] rul.w.rules))
++  current
  |=  [our=@p now=@da desk=@tas]
  ^-  (unit head:law)
  ?.  (law-name desk)  ~
  =/  domes=cone:clay  .^(cone:clay %cx /(scot %p our)//(scot %da now)/domes)
  =/  d  (~(get by domes) [our desk])
  ?~  d  ~
  ?.  &(=(%dead liv.u.d) =(~ ren.u.d) =(~ wic.u.d))  ~
  ?.  &((private our now desk /) (private our now desk /native-worker-owner-history))  ~
  =/  commit  (~(get by hit.u.d) let.u.d)
  ?~  commit  ~
  `[desk let.u.d u.commit]
++  configure
  |=  [b=bowl:gall s=state:law desk=@tas]
  ^-  state:law
  ?>  &(=(our.b src.b) (law-name desk))
  ?^  head.s
    ?>  =(desk desk.u.head.s)
    s
  ?>  ?=(~ writing.s)
  =/  h  (current our.b now.b desk)
  ?>  ?=(^ h)
  =/  root=arch  .^(arch %cy (beam our.b u.h /native-worker-owner-history))
  ?>  &(=(~ fil.root) =(~ dir.root))
  [h ~]
++  read-noun
  |=  [our=@p now=@da s=state:law pax=path]
  ^-  readout
  ?~  head.s  [%& ~]
  =/  h=head:law  u.head.s
  ?.  =(`h (current our now desk.h))  [%| %worker-owner-archive-head-unavailable]
  ?.  (private our now desk.h pax)  [%| %worker-owner-archive-not-private]
  =/  node=arch  .^(arch %cy (beam our h pax))
  ?~  fil.node  [%& ~]
  [%& `.^(* %cx (beam our h pax))]
++  decode-key
  |=  [our=@p key=@ux got=readout]
  ^-  found
  ?:  ?=(%| -.got)  [%| p.got]
  ?~  p.got  [%& ~]
  =/  parsed  ((soft receipt:law) u.p.got)
  ?~  parsed  [%| %worker-owner-archive-invalid]
  ?.  &(=(u.p.got u.parsed) =(key key.u.parsed) (valid-receipt:law our u.parsed))
    [%| %worker-owner-archive-invalid]
  [%& parsed]
++  decode-pointer
  |=  got=readout
  ^-  (each (unit pointer) @tas)
  ?:  ?=(%| -.got)  [%| p.got]
  ?~  p.got  [%& ~]
  =/  parsed  ((soft pointer) u.p.got)
  ?~  parsed  [%| %worker-owner-archive-ticket-invalid]
  ?.  =(u.p.got u.parsed)  [%| %worker-owner-archive-ticket-invalid]
  [%& parsed]
++  join-ticket
  |=  [our=@p ticket=@ux index=pointer got=found]
  ^-  found
  ?:  ?=(%| -.got)  [%| p.got]
  ?~  p.got  [%| %worker-owner-archive-ticket-unavailable]
  =/  e=receipt:law  u.p.got
  ?.  &((valid-receipt:law our e) =(ticket ticket.e) =(index (pointer:law e)))
    [%| %worker-owner-archive-ticket-invalid]
  [%& `e]
++  lookup
  |=  [our=@p now=@da s=state:law key=@ux]
  ^-  found
  (decode-key our key (read-noun our now s (path-for:law key)))
++  lookup-ticket
  |=  [our=@p now=@da s=state:law ticket=@ux]
  ^-  found
  =/  index  (decode-pointer (read-noun our now s (ticket-path:law ticket)))
  ?:  ?=(%| -.index)  [%| p.index]
  ?~  p.index  [%& ~]
  (join-ticket our ticket u.p.index (lookup our now s key.u.p.index))
++  replay-with
  ::  This returns history only. Neither a grant nor a dispatch is produced.
  |=  [our=@p src=@p ticket=@ux candidate=record:accept got=found]
  ^-  found
  ?.  =(our src)  [%| %worker-owner-archive-owner-required]
  ?:  ?=(%| -.got)  [%| p.got]
  ?~  p.got  [%& ~]
  =/  result  (replay:law our src u.p.got ticket candidate)
  ?:  ?=(%| -.result)  [%| p.result]
  [%& `p.result]
++  replay
  |=  [b=bowl:gall s=state:law ticket=@ux candidate=record:accept]
  ^-  found
  ?.  =(our.b src.b)  [%| %worker-owner-archive-owner-required]
  (replay-with our.b src.b ticket candidate (lookup-ticket our.b now.b s ticket))
++  pressure
  |=  parent=parent:law
  ^-  ?
  |((gth ~(wyt by journal.owner.parent) hot-limit:law) (gth ~(wyt by offers.owner.parent) hot-limit:law) (gth ~(wyt by pending.parent) hot-limit:law))
++  receipt-for
  ::  Read the current inner agent, not caller-provided candidate/grant DATA.
  ::  QPC bridge rows remain checking and are deliberately ineligible here.
  |=  [inner=agent:gall b=bowl:gall parent=parent:law key=@ux]
  ^-  (unit receipt:law)
  =/  job  (~(get by journal.owner.parent) key)
  ?~  job  ~
  =/  candidate  (candidate:read inner b candidate.order.u.job)
  ?~  candidate  ~
  ?.  ?=(?(%applied %refused) stage.u.candidate)  ~
  =/  ag  ~(. inner b(src our.b))
  =/  raw  (payload:allowance (on-peek:ag /x/native-coding/tool-state))
  ?~  raw  ~
  =/  parsed  ((soft organ:ct) u.raw)
  ?~  parsed  ~
  ?.  =(u.raw u.parsed)  ~
  =/  grant  (~(get by grants.u.parsed) grant.u.candidate)
  ?~  grant  ~
  =/  e  (snapshot:law our.b parent key u.candidate u.grant)
  ?:(?=(%& -.e) `p.e ~)
++  choice-with
  |=  [our=@p parent=parent:law resolve=resolver]
  ^-  (unit receipt:law)
  ?.  &((parent-valid:law our parent) (pressure parent))  ~
  =/  rows=(list [key=@ux job=record:w])
    (skim ~(tap by journal.owner.parent) |=([key=@ux job=record:w] ?=(?(%checked %refused) phase.job)))
  =.  rows
    %+  sort  rows
    |=  [a=[key=@ux job=record:w] z=[key=@ux job=record:w]]
    ?:(=(issued.order.job.a issued.order.job.z) (lth key.a key.z) (lth issued.order.job.a issued.order.job.z))
  |-
  ?~  rows  ~
  =/  e  (resolve key.i.rows)
  ?~  e  $(rows t.rows)
  ?.  &(=(key.i.rows key.u.e) (valid-receipt:law our u.e) (matches:law parent u.e))
    $(rows t.rows)
  e
++  advance-with
  ::  Pure submission boundary. The native caller supplies both canonical
  ::  reads. A missing or uncertain index never counts as confirmed absence.
  |=  [b=bowl:gall s=state:law parent=parent:law e=receipt:law by-key=found by-ticket=found]
  ^-  change
  ?.  (pressure parent)  [s parent ~]
  (append-with b s parent e by-key by-ticket /native-worker-owner-archive)
++  append-with
  ::  Shared once-only append boundary. Only the two internal entry points
  ::  choose a callback; a runtime command supplies neither cards nor DATA.
  |=  [b=bowl:gall s=state:law parent=parent:law e=receipt:law by-key=found by-ticket=found channel=wire]
  ^-  change
  ?.  =(our.b src.b)  [s parent ~]
  ?.  |(=(channel /native-worker-owner-archive) =(channel /native-worker-owner-archive-one))  [s parent ~]
  ?~  head.s  [s parent ~]
  ?^  writing.s  [s parent ~]
  ?.  &((parent-valid:law our.b parent) (valid:law our.b s parent) (valid-receipt:law our.b e) (matches:law parent e))
    [s parent ~]
  ?.  &(=([%& ~] by-key) =([%& ~] by-ticket))  [s parent ~]
  =/  h=head:law  u.head.s
  :*  s(writing `e)  parent
      :~  [%pass channel %arvo %c %info desk.h [%& [[(path-for:law key.e) %ins %noun !>(e)] [(ticket-path:law ticket.e) %ins %noun !>((pointer:law e))] ~]]]
          [%pass channel %arvo %c %warp our.b desk.h ~ %sing %z [%ud +(number.h)] /]
      ==
  ==
++  one-with
  ::  Owner-selected identity and expected digest only. The native caller
  ::  derives the whole receipt from its current inner candidate and grant.
  ::  Pressure is an automatic scheduling rule, not archival eligibility.
  |=  [b=bowl:gall s=state:law parent=parent:law key=@ux expected=@ux e=(unit receipt:law) by-key=found by-ticket=found]
  ^-  change
  ?.  =(our.b src.b)  [s parent ~]
  ?~  e  [s parent ~]
  ?.  &(=(key key.u.e) =(expected (shax (jam u.e))))  [s parent ~]
  (append-with b s parent u.e by-key by-ticket /native-worker-owner-archive-one)
++  one
  |=  [inner=agent:gall b=bowl:gall s=state:law parent=parent:law key=@ux expected=@ux]
  ^-  change
  ?.  =(our.b src.b)  [s parent ~]
  ?~  head.s  [s parent ~]
  ?^  writing.s  [s parent ~]
  =/  e  (receipt-for inner b parent key)
  ?~  e  [s parent ~]
  ?.  =(expected (shax (jam u.e)))  [s parent ~]
  (one-with b s parent key expected e (lookup our.b now.b s key) (lookup-ticket our.b now.b s ticket.u.e))
++  advance
  |=  [inner=agent:gall b=bowl:gall s=state:law parent=parent:law]
  ^-  change
  ?~  head.s  [s parent ~]
  ?^  writing.s  [s parent ~]
  =/  chosen
    (choice-with our.b parent |=(key=@ux (receipt-for inner b parent key)))
  ?~  chosen  [s parent ~]
  =/  e=receipt:law  u.chosen
  (advance-with b s parent e (lookup our.b now.b s key.e) (lookup-ticket our.b now.b s ticket.e))
++  confirm
  ::  No acknowledgement alone frees a row. Full native observations must
  ::  prove exactly one append, both indices and the unchanged settled join.
  |=  [our=@p s=state:law parent=parent:law after=head:law old=yaki:clay new=yaki:clay got=found candidate=(unit record:accept)]
  ^-  change
  ?~  writing.s  [s parent ~]
  ?~  head.s  [s parent ~]
  ?.  &((parent-valid:law our parent) (valid:law our s parent))  [s parent ~]
  =/  e=receipt:law  u.writing.s
  ?.  &(=([%& `e] got) =(`settled.e candidate))  [s parent ~]
  ?.  (append-valid:law u.head.s after e old new)  [s parent ~]
  [[`after ~] (retire:law our parent e e settled.e) ~]
++  observe
  |=  [inner=agent:gall b=bowl:gall s=state:law parent=parent:law]
  ^-  change
  ?~  writing.s  [s parent ~]
  ?~  head.s  [s parent ~]
  =/  before=head:law  u.head.s
  =/  after  (current our.b now.b desk.before)
  ?~  after  [s parent ~]
  =/  e=receipt:law  u.writing.s
  =/  got  (lookup-ticket our.b now.b [after ~] ticket.e)
  ?.  =([%& `e] got)  [s parent ~]
  =/  old=yaki:clay
    .^(yaki:clay %cs /(scot %p our.b)/[desk.before]/(scot %da now.b)/yaki/(scot %uv commit.before))
  =/  new=yaki:clay
    .^(yaki:clay %cs /(scot %p our.b)/[desk.before]/(scot %da now.b)/yaki/(scot %uv commit.u.after))
  (confirm our.b s parent u.after old new got (candidate:read inner b candidate.e))
++  native-driver
  ::  Only native proof supplies another backend; no runtime poke can do so.
  ^-  driver
  :*  |=([b=bowl:gall s=state:law key=@ux] (lookup our.b now.b s key))
      |=([b=bowl:gall s=state:law ticket=@ux] (lookup-ticket our.b now.b s ticket))
      configure  advance  observe  one
  ==
--
