::  One native evidence page, then kick. Graf retains all state and authority.
/+  g=graf-evidence-pages
|%
+$  kind
  ?(%workspace-claim %bench-guest %bench-guest-revoked %bench-turn %bench-turn-touched)
+$  request  [kind=kind offset=@ud]
++  evidence-path
  |=  pax=path
  ^-  ?
  ?=([%readymade %evidence *] pax)
++  route
  |=  pax=path
  ^-  (unit request)
  ?.  ?=([%readymade %evidence @ @ ~] pax)  ~
  =/  family=(unit kind)  ((soft kind) i.t.t.pax)
  ?~  family  ~
  =/  text=@t  i.t.t.t.pax
  ?.  (lte (met 3 text) 8)  ~
  =/  offset=(unit @ud)  (slaw %ud text)
  ?~  offset  ~
  ?.  &(=(text (scot %ud u.offset)) (lte u.offset 32.768))  ~
  `[u.family u.offset]
++  valid
  |=  [wanted=request value=kind-page:g]
  ^-  ?
  ?.  (lte offset.wanted 32.768)  %.n
  ?.  (page-valid:g value kind.wanted offset.wanted)  %.n
  ?.  =(returned.value ~(wyt in (silt items.value)))  %.n
  %+  levy  items.value
  |=  item=*
  ?.  ?=([@ *] item)  %.n
  =(kind.wanted -.item)
++  page
  |=  [inner=agent:gall b=bowl:gall wanted=request]
  ^-  (unit kind-page:g)
  ?.  (lte offset.wanted 32.768)  ~
  =/  result=(each (unit kind-page:g) tang)
    %-  mule
    |.
    =/  ag  ~(. inner b(src our.b))
    =/  pax=path
      /x/by-kind-page/[(scot %tas kind.wanted)]/[(scot %ud offset.wanted)]/64
    =/  got=(unit (unit cage))  (on-peek:ag pax)
    ?~  got  ~
    ?~  u.got  ~
    ?.  =(%noun p.u.u.got)  ~
    ::  Decode only DATA. Compiler TYPE is never inspected or reconstructed.
    =/  value=(unit kind-page:g)  ((soft kind-page:g) q.q.u.u.got)
    ?~  value  ~
    ?.  (valid wanted u.value)  ~
    value
  ?:(?=(%& -.result) p.result ~)
++  agent
  |=  inner=agent:gall
  ^-  agent:gall
  |_  =bowl:gall
  +*  this  .
      ag  ~(. inner bowl)
  ++  on-init
    =^  cards  inner  on-init:ag
    [cards this]
  ++  on-save  on-save:ag
  ++  on-load
    |=  old=vase
    =^  cards  inner  (on-load:ag old)
    [cards this]
  ++  on-poke
    |=  [=mark =vase]
    =^  cards  inner  (on-poke:ag mark vase)
    [cards this]
  ++  on-watch
    |=  =path
    ?:  (evidence-path path)
      ~|  [%readymade-evidence-refused src.bowl path]
      ?>  =(src.bowl our.bowl)
      =/  wanted=(unit request)  (route path)
      ?>  ?=(^ wanted)
      =/  value=(unit kind-page:g)  (page inner bowl u.wanted)
      ?>  ?=(^ value)
      :_  this
      :~  [%give %fact ~[path] %noun !>(u.value)]
          [%give %kick ~[path] ~]
      ==
    =^  cards  inner  (on-watch:ag path)
    [cards this]
  ++  on-leave
    |=  =path
    ?:  (evidence-path path)  [~ this]
    =^  cards  inner  (on-leave:ag path)
    [cards this]
  ++  on-peek  |=(=path (on-peek:ag path))
  ++  on-agent
    |=  [=wire =sign:agent:gall]
    =^  cards  inner  (on-agent:ag wire sign)
    [cards this]
  ++  on-arvo
    |=  [=wire sign=sign-arvo]
    =^  cards  inner  (on-arvo:ag wire sign)
    [cards this]
  ++  on-fail
    |=  [=term =tang]
    =^  cards  inner  (on-fail:ag term tang)
    [cards this]
  --
--
