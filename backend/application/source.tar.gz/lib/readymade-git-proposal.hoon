::  Exact Git proposal wire contract and literal raw-text mapping. No review runtime.
/-  nc=native-coding
/+  files=native-coding-files, law=native-coding-project
|%
+$  source-selection  [repository=@t number=@ud base=@ux head=@ux]
+$  candidate-status
  [%native-coding-git-proposal-status-v1 session=@ux request=@ux state=?(%missing %pending %unknown %refused %candidate) candidate=(unit @ux) reason=(unit @t)]
+$  candidate-lookup
  [%native-coding-git-proposal-lookup-v1 session=@ux origin=@ux matches=(list candidate-status) total=@ud]
+$  selection  [repository=@t number=@ud base=@ux head=@ux candidate=@ux]
+$  leaf  [git-path=path clay-path=path mark=@tas blob=@ux bytes=@ud text=@t]
+$  proposal
  $:  %readymade-git-proposal-v1
      owner=@p  repository=@t  number=@ud
      source-ship=@p  source-repository=@t  source-ref=@t  target-ref=@t
      state=?(%open %merged %closed)  base=@ux  head=@ux
      policy=%literal-marked-raw-text-v1
      before=(list leaf)  after=(list leaf)
  ==
++  marker  %transfer-visibility-t0-t1-t2-proposal-v1
++  candidate-origin
  |=  [selected=source-selection source=@ux]
  ^-  @ux
  (shax (jam [%readymade-git-origin-v1 selected source]))
++  candidate-identity
  |=  [selected=source-selection nonce=@ux source=@ux]
  ^-  @ux
  (shax (jam [%readymade-git-candidate-v1 selected nonce source]))
++  command-input
  |=  [origin=@ux request=@ux]
  ^-  @t
  (rap 3 ~['/git-proposal ' (scot %ux origin) ' ' (scot %ux request)])
++  oid-valid
  |=  id=@ux
  &(!=(0 id) (lte (met 0 id) 160))
++  selection-valid
  |=  s=selection
  ?&  (segment-valid:law repository.s)  (gth number.s 0)  (lte number.s 1.000.000)
      (oid-valid base.s)  (oid-valid head.s)
      !=(0 candidate.s)  (lte (met 0 candidate.s) 256)
  ==
++  token
  |=  text=@t
  ^-  (unit @ux)
  ?.  =(40 (met 3 text))  ~
  ?.  (levy (trip text) |=(c=@t |(&((gte c '0') (lte c '9')) &((gte c 'a') (lte c 'f')))))  ~
  ::  Git's raw 40 hex digits are not Hoon's dot-grouped @ux syntax.
  =/  chars=tape  (trip text)
  =/  id=@ux  0x0
  |-
  ?~  chars  ?:((oid-valid id) `id ~)
  =/  digit=@ud  ?:((lte i.chars '9') (sub i.chars '0') (add 10 (sub i.chars 'a')))
  $(chars t.chars, id (add (mul id 16) digit))
++  route
  |=  pax=path
  ^-  (unit selection)
  ?.  ?=([%x %readymade %git-review @ @ @ @ @ ~] pax)  ~
  =/  parts=[repo=@t number-text=@t base-text=@t head-text=@t candidate-text=@t ~]
    t.t.t.pax
  ?~  number=(slaw %ud number-text.parts)  ~
  ?~  base=(token base-text.parts)  ~
  ?~  head=(token head-text.parts)  ~
  ?~  candidate=(slaw %ux candidate-text.parts)  ~
  ?.  &(=(number-text.parts (scot %ud u.number)) =(candidate-text.parts (scot %ux u.candidate)))  ~
  =/  s=selection  [repo.parts u.number u.base u.head u.candidate]
  ?:((selection-valid s) `s ~)
++  oid-text
  |=  id=@ux
  ^-  @t
  ?>  (oid-valid id)
  =/  text=@t  (crip (skip (slag 2 (trip (scot %ux id))) |=(c=@t =(c '.'))))
  (rap 3 ~[(rap 3 (reap (sub 40 (met 3 text)) '0')) text])
++  proposal-path
  |=  s=selection
  ^-  path
  /readymade/proposal/[repository.s]/[(scot %ud number.s)]/[(oid-text base.s)]/[(oid-text head.s)]
++  blob
  ::  Verify the Git blob independently without converting its identity.
  |=  text=@t
  ^-  @ux
  =/  header=@t  (rap 3 ~['blob ' (crip ((d-co:co 1) (met 3 text)))])
  =/  raw=@t  (rap 3 ~[header '\00' text])
  =/  size=@ud  (add (add (met 3 header) 1) (met 3 text))
  (sha-1l:sha [size (rev 3 size raw)])
++  map-leaf
  ::  Exact roundtrip: directory parts stay literal; final base+mark join by dot.
  |=  e=leaf
  ^-  ?
  ?.  ?&  (path-valid:law git-path.e)  (path-valid:law clay-path.e)
          (gte (lent clay-path.e) 2)  (gth (lent git-path.e) 0)
          =(mark.e (rear clay-path.e))  =(bytes.e (met 3 text.e))
          (lte bytes.e 65.536)  (oid-valid blob.e)  =((blob text.e) blob.e)
      ==  %.n
  =/  back=path  (flop clay-path.e)
  ?>  ?=(^ back)
  ?>  ?=(^ t.back)
  =/  literal=@ta  (rap 3 ~[i.t.back '.' i.back])
  =(git-path.e (weld (flop t.t.back) ~[literal]))
++  namespace
  |=  [p=project:nc rows=(list leaf)]
  ^-  (each (map path @ux) @tas)
  ?.  (lte (lent rows) 256)  [%| %namespace-over-limit]
  =/  lobes=(map path @ux)  ~
  =/  literal=(set path)  ~
  =/  bytes=@ud  0
  |-  ^-  (each (map path @ux) @tas)
  ?~  rows  [%& lobes]
  =/  e=leaf  i.rows
  ?.  &((map-leaf e) (content-valid:files p clay-path.e [mark.e text.e]))
    [%| %mapping-invalid]
  ?:  |((~(has by lobes) clay-path.e) (~(has in literal) git-path.e))  [%| %mapping-duplicate]
  =.  bytes  (add bytes bytes.e)
  ?:  (gth bytes 1.048.576)  [%| %namespace-over-limit]
  $(rows t.rows, literal (~(put in literal) git-path.e), lobes (~(put by lobes) clay-path.e `@ux`(page-to-lobe:clay [mark.e text.e])))
--
