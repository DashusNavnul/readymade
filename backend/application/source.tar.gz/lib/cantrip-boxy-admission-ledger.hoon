::  /lib/cantrip-boxy-admission-ledger.hoon
::
::  Durable, bounded storage for Cantrip's Boxy motion verdicts.  The key is the
::  digest of the complete request, so a changed law, membership epoch, motion,
::  or decision cannot reuse an earlier receipt.  This library validates only
::  the receipt's deterministic shape; the Gall shell must also validate the
::  request against Boxy's current authoritative workspace before recording it.
::
/-  ca=cantrip-action
/+  bca=boxy-cantrip-admission
|%
+$  admission-record
  $:  request=boxy-motion-admission-request:ca
      verdict=boxy-motion-admission-verdict:ca
  ==
+$  ledger  (map @ux admission-record)
+$  watch-result
  $%  [%pending ~]
      [%ready verdict=boxy-motion-admission-verdict:ca]
  ==
++  maximum-records  4.096
::
++  expected-verdict
  |=  request=boxy-motion-admission-request:ca
  ^-  boxy-motion-admission-verdict:ca
  =/  receipt-id=@t  (receipt-id-for:bca request)
  ?-  -.authorship.motion.request
    %human
      [binding.request receipt-id %.y 'cantrip-boxy-motion-v1' 'admitted-human-motion']
    %model-assisted
      [binding.request receipt-id %.y 'cantrip-boxy-motion-v1' 'admitted-assisted-motion']
    %model-proposed
      [binding.request receipt-id %.n 'cantrip-boxy-motion-v1' 'model-proposal-cannot-execute']
  ==
::
::  THE CONSENT LAW (ladder 9): a %model-proposed motion becomes executable
::  only through the resident principal's explicit approval, which reaches
::  this ledger solely via Hand's principal-only consent lane.  For human
::  and assisted authorship the approved form collapses to the base form,
::  so approval can never widen what the base law already admits.
++  expected-verdict-approved
  |=  request=boxy-motion-admission-request:ca
  ^-  boxy-motion-admission-verdict:ca
  =/  base=boxy-motion-admission-verdict:ca  (expected-verdict request)
  ?.  ?=(%model-proposed -.authorship.motion.request)  base
  base(admitted %.y, reason 'admitted-principal-approved-motion')
::
++  record-valid
  |=  [key=@ux record=admission-record]
  ^-  ?
  ?&  =((request-key-for:bca request.record) key)
      ?|  =((expected-verdict request.record) verdict.record)
          =((expected-verdict-approved request.record) verdict.record)
      ==
  ==
::
++  valid
  |=  ledger=ledger
  ^-  ?
  =/  entries=(list [@ux admission-record])  ~(tap by ledger)
  ?.  (lte (lent entries) maximum-records)  %.n
  |-
  ?~  entries  %.y
  ?.  (record-valid -.i.entries +.i.entries)  %.n
  $(entries t.entries)
::
++  lookup
  |=  [ledger=ledger key=@ux]
  ^-  (unit admission-record)
  (~(get by ledger) key)
::
::  THE RETIREMENT LAW: the resident principal releases a consumed receipt
::  and its capacity returns to the bounded ledger.  Deletion is total and
::  idempotent; Cantrip cannot verify consumption itself (the constitutional
::  event may have aged past Boxy's retained window), so authority is the
::  ship-gate on the poke, and the discipline is: retire only after the
::  verdict's admission event is part of Boxy's constitutional history.
++  retire
  |=  [records=ledger key=@ux]
  ^-  ledger
  (~(del by records) key)
::
++  watch-for
  |=  [ledger=ledger key=@ux]
  ^-  watch-result
  =/  found=(unit admission-record)  (lookup ledger key)
  ?~  found  [%pending ~]
  [%ready verdict.u.found]
::
++  record
  |=  $:  records=ledger
          request=boxy-motion-admission-request:ca
          verdict=boxy-motion-admission-verdict:ca
      ==
  ^-  (unit ledger)
  =/  key=@ux  (request-key-for:bca request)
  =/  item=admission-record  [request verdict]
  ?.  (record-valid key item)  ~
  =/  found=(unit admission-record)  (~(get by records) key)
  ?^  found
    ?:  =(u.found item)  [~ records]
    ~
  ?:((gte (lent ~(tap by records)) maximum-records) ~ [~ (~(put by records) key item)])
--
