::  /lib/graf-territory-state.hoon
::
::  Maintain the code-owned territory boundary without changing retained
::  grants.  Backfill adds missing current organs; retire removes only names
::  explicitly retired by the caller.  Both operations are idempotent.
::
|%
+$  territory  [axis=@ud writable=? active=?]
++  backfill
  |=  [current=(map @t territory) seeds=(list [@t territory])]
  ^-  (map @t territory)
  =/  rest  seeds
  =/  out  current
  |-
  ?~  rest  out
  =/  entry  i.rest
  =.  out
    ?:  (~(has by out) -.entry)
      out
    (~(put by out) -.entry +.entry)
  $(rest t.rest)
::
++  retire
  |=  [current=(map @t territory) retired=(list @t)]
  ^-  (map @t territory)
  ?~  retired  current
  $(current (~(del by current) i.retired), retired t.retired)
--
