::  Explicit owner registration only. No inference, selection, grant, review
::  or effect commands. Ordinary inner events/cards remain byte-for-byte.
/-  nc=native-coding
/+  d=qpc-native-declaration, builder=qpc-native-profile-build,
    instrument=qpc-instrument-read-contract, source=qpc-instrument-source,
    observer=qpc-observer, law=qpc-law-core,
    project=native-coding-project, q=qpc-native-outcome,
    guard=viki-scry-guard, contract=cantrip-native-coding-contract,
    reservation=qpc-session-reservation
|%
+$  reader  $-([inner=agent:gall b=bowl:gall c=command:d] (each snapshot:d @tas))
++  read
  |=  [inner=agent:gall b=bowl:gall c=command:d]
  ^-  (each snapshot:d @tas)
  ?.  (command-valid:d our.b c)  [%| %qpc-profile-command-invalid]
  =/  plans  (raw:instrument inner b /x/qpc/instrument/state)
  =/  laws  (raw:instrument inner b /x/qpc/laws)
  =/  used  (raw:instrument inner b /x/native-coding/local-used-sessions)
  =/  required  (raw:instrument inner b /x/qpc/required-sessions)
  ?~  plans  [%| %qpc-profile-instrument-unavailable]
  ?~  laws  [%| %qpc-profile-law-unavailable]
  ?~  used  [%| %qpc-profile-sessions-unavailable]
  ?~  required  [%| %qpc-profile-gate-unavailable]
  =/  held  ((soft state:instrument) u.plans)
  =/  history  ((soft state:law) u.laws)
  =/  used-viki  ((soft (set @ux)) u.used)
  =/  required-viki  ((soft ,[%qpc-session-gate-v1 %viki ids=(set @ux)]) u.required)
  ?~  held  [%| %qpc-profile-instrument-invalid]
  ?~  history  [%| %qpc-profile-law-invalid]
  ?~  used-viki  [%| %qpc-profile-sessions-invalid]
  ?~  required-viki  [%| %qpc-profile-gate-invalid]
  =/  found  (~(get by plans.u.held) member.c)
  ?~  found  [%| %qpc-profile-task-missing]
  =/  plan=plan:instrument  plan.u.found
  =/  input  (input:observer inner b member.c)
  ?~  input  [%| %qpc-profile-task-session-missing]
  =/  cases  (raw:instrument inner b /x/qpc/cases/(scot %ux cases.plan))
  ?~  cases  [%| %qpc-profile-cases-unavailable]
  =/  parsed  ((soft ,(unit cases:q)) u.cases)
  ?~  parsed  [%| %qpc-profile-cases-invalid]
  ?~  u.parsed  [%| %qpc-profile-cases-missing]
  =/  config  (project-read:instrument inner b member.c project.manifest.plan)
  ?:  ?=(%| -.config)  [%| p.config]
  =/  frozen  (freeze:law u.history (binding-of:instrument plan) our.b expected-law.c)
  ?:  ?=(%| -.frozen)  [%| p.frozen]
  =/  current  (current:project our.b now.b p.config)
  ?:  ?=(%| -.current)  [%| p.current]
  =/  pinned
    (read:source our.b now.b p.config revision.working.p.current artifact.plan u.u.parsed)
  ?:  ?=(%| -.pinned)  [%| p.pinned]
  ?.  (agent-live:guard our.b now.b %cantrip)  [%| %qpc-profile-cantrip-unavailable]
  =/  ledger=organ:contract
    .^(organ:contract %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/tool-state/noun)
  =/  required-cantrip=[%qpc-session-gate-v1 %cantrip ids=(set @ux)]
    .^([%qpc-session-gate-v1 %cantrip ids=(set @ux)] %gx /(scot %p our.b)/cantrip/(scot %da now.b)/qpc/required-sessions/noun)
  ::  A collection session may already hold its single campaign grant.
  =/  unused=?
    ?&  ?=(^ (spare:reservation ledger u.used-viki session.c))
        !(~(has by plans.u.held) session.c)
    ==
  =/  managed=?
    &((~(has in ids.u.required-viki) session.c) (~(has in ids.required-cantrip) session.c))
  [%& [plan p.config objective.session.entry.u.input u.u.parsed p.pinned p.frozen unused managed]]
++  wrap
  ::  Reader injection is an internal native proof seam, never a command.
  |=  [inner=agent:gall fetch=reader]
  =/  held=state:d  empty:d
  ^-  agent:gall
  |_  =bowl:gall
  +*  this  .
      ag  ~(. inner bowl)
  ++  on-init
    =^  cards  inner  on-init:ag
    [cards this]
  ++  on-save  !>([%qpc-native-declaration-owner-v1 held on-save:ag])
  ++  on-load
    |=  old=vase
    =/  saved=[held=state:d inner=vase]
      ?.  ?=([%qpc-native-declaration-owner-v1 *] q.old)  [empty:d old]
      =/  prior  !<([%qpc-native-declaration-owner-v1 held=state:d inner=vase] old)
      +.prior
    ?>  (valid:d our.bowl held.saved)
    =.  held  held.saved
    =^  cards  inner  (on-load:ag inner.saved)
    [cards this]
  ++  on-poke
    |=  [=mark =vase]
    ?:  &(=(%noun mark) ?=([%qpc-profile-register-v1 *] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  c=command:d  !<(command:d vase)
      =/  got  (fetch inner bowl c)
      ?>  ?=(%& -.got)
      =/  next  (begin:d held our.bowl src.bowl now.bowl c p.got)
      ?>  ?=(%& -.next)
      =.  held  p.next
      =/  r=record:d  (~(got by records.held) session.c)
      [~[[%pass (wire-for:d r %wake) %arvo %b %wait due.r]] this]
    ?:  &(=(%noun mark) ?=([%qpc-profile-cancel-v1 @] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  id=@ux  +.q.vase
      [~ this(held (stop:d held id %cancelled %operator-cancelled))]
    =^  cards  inner  (on-poke:ag mark vase)
    [cards this]
  ++  on-arvo
    |=  [=wire sign=sign-arvo]
    ?.  ?=([%qpc-profile *] wire)
      =^  cards  inner  (on-arvo:ag wire sign)
      [cards this]
    ?.  &(=(our.bowl src.bowl) ?=([%qpc-profile ?(%wake %build) @ @ ~] wire))  [~ this]
    =/  id  (slaw %ux i.t.t.wire)
    ?~  id  [~ this]
    =/  found  (~(get by records.held) u.id)
    ?~  found  [~ this]
    =/  r=record:d  u.found
    ?.  =(wire (wire-for:d r i.t.wire))  [~ this]
    ?:  =(%wake i.t.wire)
      ?.  &(=(%scheduled phase.r) ?=([%behn %wake *] sign))  [~ this]
      ?.  (gte now.bowl due.r)  [~ this]
      ?^  error.sign
        [~ this(held (stop:d held u.id %unknown %qpc-profile-wake-unconfirmed))]
      =/  got  (fetch inner bowl command.value.r)
      ?:  ?=(%| -.got)
        [~ this(held (stop:d held u.id %refused p.got))]
      =/  v=snapshot:d  p.got
      ?.  (unchanged:d our.bowl r v)
        [~ this(held (stop:d held u.id %refused %qpc-profile-declaration-changed))]
      =.  held  (start:d held u.id id.r)
      =/  p=revision:nc  profile.command.value.r
      =/  target=beak  [owner.p desk.p ud+number.p]
      =/  job=shed:khan  (run:builder our.bowl id.r p)
      [~[[%pass (wire-for:d r %build) %arvo %k %lard target job]] this]
    ?.  &(=(%building phase.r) ?=([%khan %arow *] sign))  [~ this]
    ?.  ?=(%& -.p.sign)
      [~ this(held (stop:d held u.id %unknown %qpc-profile-build-unconfirmed))]
    =/  got  ((soft ,(each build:d @tas)) q.q.p.p.sign)
    ?~  got
      [~ this(held (stop:d held u.id %unknown %qpc-profile-build-result-invalid))]
    ?:  ?=(%| -.u.got)
      [~ this(held (stop:d held u.id %refused p.u.got))]
    =/  current  (fetch inner bowl command.value.r)
    ?:  ?=(%| -.current)
      [~ this(held (stop:d held u.id %refused p.current))]
    ?.  (unchanged:d our.bowl r p.current)
      [~ this(held (stop:d held u.id %refused %qpc-profile-declaration-changed))]
    [~ this(held (finish:d held u.id p.u.got))]
  ++  on-peek
    |=  =path
    ?:  =(/x/qpc/profile-declarations path)
      ?.  =(our.bowl src.bowl)  ~
      ``noun+!>(held)
    (on-peek:ag path)
  ++  on-watch
    |=  =path
    =^  cards  inner  (on-watch:ag path)
    [cards this]
  ++  on-leave
    |=  =path
    =^  cards  inner  (on-leave:ag path)
    [cards this]
  ++  on-agent
    |=  [=wire =sign:agent:gall]
    =^  cards  inner  (on-agent:ag wire sign)
    [cards this]
  ++  on-fail
    |=  [=term =tang]
    =^  cards  inner  (on-fail:ag term tang)
    [cards this]
  --
++  agent  |=(inner=agent:gall (wrap inner read))
--
