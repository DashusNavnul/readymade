::  Inert candidate assessment journal. Native readers authenticate every
::  input; pure consistency is not owner authentication or effect admission.
::  No ordinary acceptance row, review, landing, selection or retry exists.
/-  nc=native-coding, w=native-coding-worker
/+  d=qpc-native-decision, prospective=qpc-native-owner,
    pool=qpc-native-pool, ct=cantrip-native-coding,
    project=native-coding-project, files=native-coding-files,
    accept=native-coding-accept, worker=native-coding-worker,
    parent=native-coding-worker-owner, journal=native-coding-worker-journal
|%
+$  binding
  $:  opening=opening:d  pool=pool:pool  sealed=@ud
      declaration=declaration:prospective  scope=scope:ct
  ==
+$  view  [binding=binding tools=organ:ct]
+$  row
  $:  tool=record:ct  candidate=candidate:nc  targets=(list build-target:nc)
      maximum=@ud  phase=?(%prepared %cloning %staging %staged %sent %checked %refused %unknown)
      staging=(unit tree:nc)  order=(unit order:w)
      retained=(unit record:w)  report=(unit report:accept)
      reason=(unit @tas)
  ==
+$  record  [id=@ux binding=binding at=@da rows=(map @ux row)]
+$  state
  [%qpc-native-assessments-v1 records=(map @ux record) unavailable=(map @ux @tas)]
++  empty  ^-(state [%qpc-native-assessments-v1 ~ ~])
++  digest  |=(v=* ^-(@ux (shax (jam [%qpc-native-assessment-v1 v]))))
++  start-payload
  |=(id=@ux !>([%qpc-assessment-worker-start-v1 id]))
++  binding-valid
  |=  [our=@p b=binding]
  ^-  ?
  =/  f=opening:d  opening.b
  =/  p=pool:pool  pool.b
  =/  g=grant:ct  grant.scope.b
  =/  declared=declaration:prospective  declaration.b
  =/  opened  (open:d f)
  ?&  ?=(%& -.opened)  (valid:pool p)  =(our owner.f)
      =(our owner.p)  =(session.f session.p)  =(request.f request.p)
      =(source.f source.p)  =(project.f project.p)
      =(configuration.f configuration.p)  =(grant.f grant.p)
      (lth position.f sealed.b)  (lte (met 0 sealed.b) 64)
      (grant-valid:ct our g)  ?=(~ revoked.scope.b)
      =(grant.f id.g)  =(session.f session.g)  =(our actor.g)
      =(project.f id.spec.project.g)
      =(configuration.f (configuration:project project.g))
      =(authority.f (digest:prospective scope.b))
      (~(has in operations.g) %compile)  (~(has in operations.g) %check)
      =(task.f task.declared)  =(objective.f objective.declared)
      =(scorer.f scorer.declared)  =(required.f required.declared)
      =(parameters.law.f weights.declared)
      =(scorer-source.f (digest:prospective [scorer.declared source.declared pax.declared hash.declared]))
  ==
++  row-binding-valid
  |=  [b=binding v=row]
  ^-  ?
  =/  c=candidate:nc  candidate.v
  =/  t=record:ct  tool.v
  =/  p=pool:pool  pool.b
  =/  matches=(list row:pool)
    (skim rows.p |=(r=row:pool =(`id.c candidate.r)))
  ?~  matches  %.n
  ?^  t.matches  %.n
  =/  item=row:pool  i.matches
  ?~  result.t  %.n
  =/  result=tool-result:nc  u.result.t
  ?&  =(%cantrip origin.item)  =(%finished stage.t)
      =(tool.item (key:ct request.t))  =(grant.p grant.t)
      =(result.item (digest:pool result))  =(call.item call-id.result)
      =(context.request.t context.result)  =(call-id.request.t call-id.result)
      =(output.result [%candidate c])  ?=(%patch -.arguments.request.t)
      =(context.c [project.p configuration.p session.p request.p owner.p source.p])
      =(context.c context.result)  =(source.p revision.basis.c)
      =(`(effect:d c) effect.item)
      (candidate-valid:files project.grant.scope.b c)
      =(targets.v (required:accept project.grant.scope.b c))
      =(maximum.v max-eval-work.grant.scope.b)
  ==
++  bridge
  ::  Private compatibility projection for the existing worker codec only.
  ::  Never publish this in the ordinary candidate/acceptance ledger.
  |=  [r=record v=row]
  ^-  record:accept
  [%native-coding-acceptance-v1 project.grant.scope.binding.r candidate.v grant.tool.v at.r %checking staging.v ~ ~ ~ ~]
++  stage-valid
  |=  [r=record v=row stage=tree:nc]
  ^-  ?
  ?&  (tree-valid:project project.grant.scope.binding.r stage)
      =(owner.source.opening.binding.r owner.revision.stage)
      =((staging-desk:accept id.candidate.v) desk.revision.stage)
      =(2 number.revision.stage)
      =((after-map:files candidate.v) files.body.snapshot.stage)
  ==
++  clone-valid
  |=  [r=record v=row clone=tree:nc]
  ^-  ?
  =/  source=revision:nc  source.context.candidate.v
  ?&  (tree-valid:project project.grant.scope.binding.r clone)
      =(owner.source owner.revision.clone)
      =((staging-desk:accept id.candidate.v) desk.revision.clone)
      =(1 number.revision.clone)  =(commit.source commit.revision.clone)
      =(root.source root.revision.clone)
      =(files.body.snapshot.basis.candidate.v files.body.snapshot.clone)
  ==
++  order-valid
  |=  [r=record v=row o=order:w]
  ^-  ?
  ?~  staging.v  %.n
  =/  expected
    (make-order:parent issued.o deadline.o pairing.o (bridge r v) scope.binding.r [maximum.v ~])
  ?.  ?=(%& -.expected)  %.n
  =(o p.expected)
++  begin
  ::  The native reader joins this view to the prospective owner's sealed
  ::  journal and the original Cantrip records before calling this gate.
  |=  [s=state our=@p actor=@p at=@da v=view]
  ^-  (each state @tas)
  ?.  =(our actor)  [%| %qpc-assessment-owner-required]
  =/  b=binding  binding.v
  =/  p=pool:pool  pool.b
  ?:  (~(has by records.s) session.p)  [%| %qpc-assessment-already-recorded]
  ?.  (lth ~(wyt by records.s) 64)  [%| %qpc-assessment-capacity]
  ?.  (binding-valid our b)  [%| %qpc-assessment-binding-invalid]
  ?.  =(`scope.b (~(get by grants.tools.v) grant.p))
    [%| %qpc-assessment-grant-changed]
  =/  todo=(list row:pool)  rows.p
  =/  rows=(map @ux row)  ~
  =/  collected=(each (map @ux row) @tas)
    |-  ^-  (each (map @ux row) @tas)
    ?~  todo  [%& rows]
    =/  item=row:pool  i.todo
    =/  found  (~(get by records.tools.v) tool.item)
    ?:  =(%journal-refusal origin.item)
      ?^  found  [%| %qpc-assessment-refusal-changed]
      $(todo t.todo)
    ?~  found  [%| %qpc-assessment-tool-missing]
    =/  t=record:ct  u.found
    ?~  result.t  [%| %qpc-assessment-tool-unsettled]
    =/  result=tool-result:nc  u.result.t
    ?.  ?&  =(tool.item (key:ct request.t))  =(grant.p grant.t)
            =(%finished stage.t)  =(result.item (digest:pool result))
            =(context.request.t context.result)  =(call-id.request.t call-id.result)
            =(call.item call-id.result)
        ==  [%| %qpc-assessment-tool-mismatch]
    ?~  candidate.item
      ?.  ?=(%refused -.output.result)  [%| %qpc-assessment-refusal-mismatch]
      $(todo t.todo)
    ?.  ?=(%candidate -.output.result)  [%| %qpc-assessment-candidate-missing]
    =/  c=candidate:nc  value.output.result
    =/  context=context:nc
      [project.p configuration.p session.p request.p owner.p source.p]
    ?.  ?&  =(u.candidate.item id.c)  =(`(effect:d c) effect.item)
            =(context context.c)  =(source.p revision.basis.c)
            (candidate-valid:files project.grant.scope.b c)
            =(context context.result)  ?=(%patch -.arguments.request.t)
        ==  [%| %qpc-assessment-candidate-mismatch]
    ?:  (~(has by rows) id.c)  [%| %qpc-assessment-candidate-duplicate]
    =/  row=row
      [t c (required:accept project.grant.scope.b c) max-eval-work.grant.scope.b %prepared ~ ~ ~ ~ ~]
    $(todo t.todo, rows (~(put by rows) id.c row))
  ?:  ?=(%| -.collected)  [%| p.collected]
  =/  r=record  [(digest b) b at p.collected]
  [%& s(records (~(put by records.s) session.p r))]
++  start-clone
  ::  Commit this state before the one Clay merge card is released.
  |=  [r=record id=@ux]
  ^-  (each record @tas)
  =/  found  (~(get by rows.r) id)
  ?~  found  [%| %qpc-assessment-candidate-missing]
  =/  v=row  u.found
  ?.  =(%prepared phase.v)  [%| %qpc-assessment-clone-closed]
  ?:  (lien ~(val by rows.r) |=(other=row ?=(?(%cloning %staging %staged %sent) phase.other)))
    [%| %qpc-assessment-active-candidate]
  [%& r(rows (~(put by rows.r) id v(phase %cloning)))]
++  cloned
  ::  A native private-desk read authenticates this exact revision1 clone.
  ::  Commit %staging before emitting the one Clay edit card.
  |=  [r=record id=@ux source=tree:nc]
  ^-  (each record @tas)
  =/  found  (~(get by rows.r) id)
  ?~  found  [%| %qpc-assessment-candidate-missing]
  =/  v=row  u.found
  ?.  =(%cloning phase.v)  [%| %qpc-assessment-clone-closed]
  ?.  (clone-valid r v source)  [%| %qpc-assessment-clone-mismatch]
  [%& r(rows (~(put by rows.r) id v(phase %staging, staging `source)))]
++  stage
  ::  Phase B must first authenticate the private Clay clone/edit ancestry,
  ::  current source and grant. This pure tree check alone proves no write.
  |=  [r=record id=@ux source=tree:nc parents=(list @uv)]
  ^-  (each record @tas)
  =/  found  (~(get by rows.r) id)
  ?~  found  [%| %qpc-assessment-candidate-missing]
  =/  v=row  u.found
  ?.  =(%staging phase.v)  [%| %qpc-assessment-stage-closed]
  ?.  =(~[commit.source.context.candidate.v] parents)
    [%| %qpc-assessment-stage-parent-mismatch]
  ?.  (stage-valid r v source)  [%| %qpc-assessment-stage-mismatch]
  [%& r(rows (~(put by rows.r) id v(phase %staged, staging `source)))]
++  map-order
  ::  Reserve exactly the existing shared worker parent's order; this gate
  ::  emits no dispatch and cannot choose another ticket on an unknown result.
  |=  [r=record id=@ux o=order:w]
  ^-  (each record @tas)
  =/  found  (~(get by rows.r) id)
  ?~  found  [%| %qpc-assessment-candidate-missing]
  =/  v=row  u.found
  ?.  =(%staged phase.v)  [%| %qpc-assessment-order-closed]
  ?:  (lien ~(val by rows.r) |=(other=row =(%sent phase.other)))
    [%| %qpc-assessment-worker-busy]
  ?.  (order-valid r v o)  [%| %qpc-assessment-order-mismatch]
  [%& r(rows (~(put by rows.r) id v(phase %sent, order `o)))]
++  stop
  |=  [r=record id=@ux phase=?(%refused %unknown) reason=@tas]
  ^-  record
  =/  found  (~(get by rows.r) id)
  ?~  found  r
  =/  v=row  u.found
  ?.  ?=(?(%prepared %cloning %staging %staged %sent) phase.v)  r
  r(rows (~(put by rows.r) id v(phase phase, reason `reason)))
++  settle
  ::  The wrapper must read this row from the shared parent's authenticated
  ::  retained journal. No command may accept a worker report or auth boolean.
  |=  [r=record id=@ux held=record:w]
  ^-  (each record @tas)
  =/  found  (~(get by rows.r) id)
  ?~  found  [%| %qpc-assessment-candidate-missing]
  =/  v=row  u.found
  ?~  order.v  [%| %qpc-assessment-order-missing]
  ?.  &(=(u.order.v order.held) (valid:journal owner.opening.binding.r (malt ~[[(digest:worker order.held) held]])))
    [%| %qpc-assessment-result-mismatch]
  ?^  retained.v
    ?:  =(u.retained.v held)  [%& r]
    ::  The same unresolved parent row may later acquire its one receipt.
    ::  Retain that evidence without replacing the assessment's unknown.
    ?:  &(=(%unknown phase.v) ?=(~ result.u.retained.v) ?=(^ result.held))
      [%& r(rows (~(put by rows.r) id v(retained `held)))]
    [%| %qpc-assessment-result-conflict]
  ?.  ?=(?(%sent %unknown) phase.v)  [%| %qpc-assessment-result-closed]
  ?.  ?=(?(%checked %refused %unknown %revoked) phase.held)
    [%| %qpc-assessment-result-not-terminal]
  =/  v=row  v(retained `held)
  ?:  =(%unknown phase.v)
    [%& r(rows (~(put by rows.r) id v))]
  ?:  ?=(?(%unknown %revoked) phase.held)
    [%& r(rows (~(put by rows.r) id v(phase %unknown, reason `%qpc-assessment-worker-unconfirmed)))]
  ?:  =(%refused phase.held)
    [%& r(rows (~(put by rows.r) id v(phase %refused, reason `%qpc-assessment-worker-refused)))]
  =/  auth=scope:w
    (scope:parent pairing.order.held (bridge r v) scope.binding.r [maximum.v ~])
  =/  state=state:parent
    [%native-coding-worker-owner-v1 `pairing.order.held (malt ~[[(digest:worker order.held) held]]) ~]
  =/  result  (report:parent state auth (digest:worker order.held) (bridge r v))
  ?:  ?=(%| -.result)  [%| p.result]
  [%& r(rows (~(put by rows.r) id v(phase %checked, report `p.result)))]
++  unavailable
  |=  [s=state id=@ux reason=@tas]
  ^-  state
  ?.  |((~(has by unavailable.s) id) (lth ~(wyt by unavailable.s) 128))  s
  s(unavailable (~(put by unavailable.s) id reason))
++  recover
  ::  Reload preserves all evidence and turns only unfinished rows unknown.
  |=  s=state
  ^-  state
  =/  recovered=(map @ux record)
    %-  ~(run by records.s)
    |=  r=record
    =/  rows=(map @ux row)
      %-  ~(run by rows.r)
      |=  v=row
      ?:(?=(?(%prepared %cloning %staging %staged %sent) phase.v) v(phase %unknown, reason `%qpc-assessment-reload-unconfirmed) v)
    r(rows rows)
  s(records recovered)
++  valid
  |=  [our=@p s=state]
  ^-  ?
  ?&  (lte ~(wyt by records.s) 64)  (lte ~(wyt by unavailable.s) 128)
      (levy ~(tap by unavailable.s) |=([id=@ux reason=@tas] &((identifier:ct id) !=(%$ reason))))
      %+  levy  ~(tap by records.s)
      |=  [id=@ux r=record]
      ?&  =(id session.pool.binding.r)  =(id.r (digest binding.r))
          (binding-valid our binding.r)  (lte ~(wyt by rows.r) 4)
          =(~(wyt by rows.r) (lent (skim rows.pool.binding.r |=(v=row:pool ?=(^ candidate.v)))))
          %+  levy  ~(tap by rows.r)
          |=  [key=@ux v=row]
          =/  p=project:nc  project.grant.scope.binding.r
          ?&  =(key id.candidate.v)  (row-binding-valid binding.r v)
              ?~(staging.v %.y |((clone-valid r v u.staging.v) (stage-valid r v u.staging.v)))
              ?~(order.v %.y (order-valid r v u.order.v))
              ?~(retained.v %.y &(?=(^ order.v) =(order.u.retained.v u.order.v) (valid:journal our (malt ~[[(digest:worker order.u.retained.v) u.retained.v]]))))
              ?~(report.v %.y &(?=(^ staging.v) =(`staging.u.report.v staging.v) (report-valid:accept p candidate.v u.report.v)))
              ?~(reason.v %.y !=(%$ u.reason.v))
              ?:  ?=(?(%prepared %cloning) phase.v)  &(?=(~ staging.v) ?=(~ order.v) ?=(~ retained.v) ?=(~ report.v) ?=(~ reason.v))
              ?:  =(%staging phase.v)  ?~(staging.v %.n &((clone-valid r v u.staging.v) ?=(~ order.v) ?=(~ retained.v) ?=(~ report.v) ?=(~ reason.v)))
              ?:  =(%staged phase.v)  ?~(staging.v %.n &((stage-valid r v u.staging.v) ?=(~ order.v) ?=(~ retained.v) ?=(~ report.v) ?=(~ reason.v)))
              ?:  =(%sent phase.v)  &(?=(^ staging.v) ?=(^ order.v) ?=(~ retained.v) ?=(~ report.v) ?=(~ reason.v))
              ?:  =(%checked phase.v)
                ?~  retained.v  %.n
                ?~  report.v  %.n
                ?.  &(?=(~ reason.v) =(%checked phase.u.retained.v))  %.n
                =/  replayed
                  (settle r(rows (~(put by rows.r) key v(phase %sent, retained ~, report ~))) key u.retained.v)
                ?.(?=(%& -.replayed) %.n =(r p.replayed))
              &(?=(^ reason.v) ?=(~ report.v))
          ==
      ==
  ==
--
