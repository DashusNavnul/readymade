::  Viki's durable, provider-independent coding journal. Pure transitions:
::  the owning Gall app supplies canonical reads and interprets effects through
::  Cantrip/native tools. Neither model output nor this library grants authority.
/-  nc=native-coding, np=native-coding-provider, frozen=native-coding-context
/+  provider=native-coding-provider, project=native-coding-project
|%
++  session-limit  512
++  journal-limit  4.096
++  digest
  |=  value=*
  ^-  @ux
  (shax (jam [%native-coding-session-journal-v1 value]))
++  text-valid
  |=  text=@t
  ^-  ?
  &(!=('' text) (lte (met 3 text) text-limit:np))
++  request-id
  |=  [session=@ux turn=@ud]
  ^-  @ux
  (digest [%inference session turn])
++  event-id
  |=  [session=@ux sequence=@ud previous=(unit @ux) at=@da body=*]
  ^-  @ux
  (digest [session sequence previous at body])
+$  phase
  ?(%idle %ready %inference %tools %judgment %paused %unknown %complete %refused)
+$  body
  $%  [%operator text=@t]
      [%model result=public-reply:np]
      [%tool result=tool-result:nc]
      [%selection value=selection:np]
      [%status value=phase reason=@tas]
      [%terminal input=@t output=@t]
      [%context value=binding:frozen]
      [%judgment verdict=?(%complete %continue %refuse) evidence=(list @ux) reason=@t]
  ==
+$  record
  [sequence=@ud previous=(unit @ux) at=@da body=body id=@ux]
+$  entry
  $:  %native-coding-session-state-v1
      session=session:nc  configuration=@ux  selection=selection:np
      worker=@p  phase=phase  resume=phase  turn=@ud
      pending=(unit request:np)  calls=(list call:np)
      results=(map @t tool-result:nc)
      history=(list message:np)  records=(list record)
      head=(unit @ux)  sequence=@ud  source-context=@t
      summary=@t  summary-through=(unit @ux)
  ==
+$  organ  (map @ux entry)
+$  effect
  $%  [%infer worker=@p request=request:np]
      [%tool session=@ux request=@ux call=call:np]
      [%judge session=@ux request=@ux evidence=(list @ux)]
      [%cancel worker=@p request=@ux]
      [%retain-context value=receipt:frozen]
      [%retain session=@ux record=record]
  ==
+$  transition  [entry=entry effects=(list effect)]
++  append
  |=  [e=entry at=@da value=body]
  ^-  (each transition @tas)
  ?:  (gte (lent records.e) journal-limit)  [%| %journal-capacity]
  =/  r=record
    [sequence.e head.e at value (event-id id.session.e sequence.e head.e at value)]
  [%& [e(records (weld records.e ~[r]), head `id.r, sequence +(sequence.e)) ~[[%retain id.session.e r]]]]
++  noted
  ::  The journal's latest record already states this status reason.
  |=  [e=entry reason=@tas]
  ^-  ?
  ?~  records.e  %.n
  =/  last=record  (rear records.e)
  ?.  ?=(%status -.body.last)  %.n
  =(reason reason.body.last)
++  unclaimed-waits
  ::  Deadline waits granted to the current request because no CLI connector
  ::  had claimed it: status rows since this request's dispatch (ptf-5822).
  |=  e=entry
  ^-  @ud
  =/  recs=(list record)  (flop records.e)
  =|  n=@ud
  |-  ^-  @ud
  ?~  recs  n
  ?:  ?=(%model -.body.i.recs)  n
  ?.  ?=(%status -.body.i.recs)  $(recs t.recs)
  ?:  =(%dispatch reason.body.i.recs)  n
  $(recs t.recs, n ?:(=(%provider-unclaimed-wait reason.body.i.recs) +(n) n))
++  gateway-retries
  ::  Provider gateway retries journaled since the last model reply.
  |=  e=entry
  ^-  @ud
  =/  recs=(list record)  (flop records.e)
  =|  n=@ud
  |-  ^-  @ud
  ?~  recs  n
  ?:  ?=(%model -.body.i.recs)  n
  ?.  ?=(%status -.body.i.recs)  $(recs t.recs)
  $(recs t.recs, n ?:(=(%provider-gateway-retry reason.body.i.recs) +(n) n))
++  begin
  ::  Caller must have read canonical membership and exact source already.
  |=  [our=@p actor=@p at=@da s=session:nc configuration=@ux selected=selection:np worker=@p context=@t]
  ^-  (each transition @tas)
  ?.  &(=(our actor) =(our owner.s) !=(0 id.s) (text-valid objective.s))
    [%| %session-owner-invalid]
  ?.  &((revision-valid:project working.s) (selection-valid:provider selected) !=(0 configuration))
    [%| %session-configuration-invalid]
  ?.  (lte (met 3 context) instruction-limit:np)  [%| %source-context-capacity]
  =/  e=entry
    :*  %native-coding-session-state-v1  s  configuration  selected
        worker  %ready  %ready  0  ~  ~  ~
        ~[[%user ~[[%text objective.s]]]]  ~  ~  0  context  ''  ~
    ==
  (append e at [%operator objective.s])
++  instruct
  ::  Instructions during a pending turn are retained and pause continuation.
  |=  [our=@p actor=@p at=@da e=entry text=@t]
  ^-  (each transition @tas)
  ?.  &(=(our actor) =(our owner.session.e) (text-valid text))  [%| %instruction-invalid]
  ?:  (gte (lent history.e) history-limit:np)  [%| %history-capacity]
  =.  e  e(history (weld history.e `(list message:np)`~[[%user ~[[%text text]]]]))
  =.  e
    ?:  ?=(^ pending.e)  e(resume phase.e, phase %paused)
    ?:  |(=(%judgment phase.e) =(%judgment resume.e))  e(resume %judgment, phase %paused)
    ?:  ?=(^ calls.e)  e(resume %tools, phase %paused)
    e(phase %ready, resume %ready)
  (append e at [%operator text])
++  continue-instruction
  ::  An explicit owner answer may supersede a quiescent completion judgment.
  ::  Caller first checks canonical candidate work; this grants no acceptance.
  |=  [our=@p actor=@p at=@da next=transition]
  ^-  (each transition @tas)
  =/  e=entry  entry.next
  ?.  &(=(our actor) =(our owner.session.e) =(%paused phase.e) =(%judgment resume.e) ?=(~ pending.e) ?=(~ calls.e))
    [%| %instruction-continuation-not-ready]
  ?~  records.e  [%| %instruction-record-required]
  =/  last=record  (rear records.e)
  ?.  &(?=(%operator -.body.last) =(head.e `id.last) =(at at.last))
    [%| %instruction-record-required]
  =/  continued
    (append e(phase %ready, resume %ready) at [%status %ready %operator-instruction-continued])
  ?:  ?=(%| -.continued)  continued
  [%& p.continued(effects (weld effects.next effects.p.continued))]
++  dispatch
  ::  One persisted pending request precedes the inference effect.
  |=  [at=@da e=entry tools=(list tool:np) instructions=@t maximum=@ud]
  ^-  (each transition @tas)
  =/  pending  pending.e
  =/  calls  calls.e
  ?.  &(=(%ready phase.e) ?=(~ pending) ?=(~ calls))  [%| %session-not-ready]
  =/  text=@t  (cat 3 instructions (cat 3 '\0a' source-context.e))
  =/  r=request:np
    :*  %native-coding-inference-v1  (request-id id.session.e turn.e)
        id.session.e  selection.e  text  history.e  tools  maximum
        streaming.capabilities.selection.e
    ==
  ?.  (request-valid:provider r)  [%| %inference-context-invalid]
  =/  next  (append e at [%status %inference %dispatch])
  ?:  ?=(%| -.next)  next
  =/  out=transition  p.next
  [%& [entry.out(phase %inference, resume %inference, pending `r, turn +(turn.e), results ~) (weld effects.out `(list effect)`~[[%infer worker.e r]])]]
++  retain-context
  ::  Append before interpreting inference effects. Failure dispatches nothing.
  |=  [at=@da next=transition value=receipt:frozen]
  ^-  (each transition @tas)
  =/  e=entry  entry.next
  ?~  pending.e  [%| %context-request-missing]
  =/  r=request:np  u.pending.e
  ?.  ?&  =(%inference phase.e)  =(owner.session.e owner.value)
          =(id.session.e session.value)  =(id.r request.value)
          =(worker.e worker.value)  =(working.session.e source.packet.prepared.value)
          =(source-context.e text.packet.prepared.value)
          =(provider.selection.r provider.value)  =(model.selection.r model.value)
          =((shax (jam r)) request-digest.value)
          =((shax (jam history.r)) history-digest.value)
          =((shax (jam tools.r)) tools-digest.value)
          =((shax (jam prepared.value(digest 0x0))) digest.prepared.value)
          (lte (met 3 (jam prepared.value)) 163.840)
          !(lien records.e |=(record=record &(?=(%context -.body.record) =(id.r request.value.body.record))))
      ==  [%| %context-request-mismatch]
  =/  kept  (append e at [%context (bind-receipt:frozen value)])
  ?:  ?=(%| -.kept)  kept
  [%& p.kept(effects (weld effects.p.kept `(list effect)`[[%retain-context value] effects.next]))]
++  model
  ::  Only the frozen provider request's result can advance this turn.
  |=  [at=@da e=entry r=reply:np]
  ^-  (each transition @tas)
  =/  pending  pending.e
  ?~  pending  [%| %no-pending-inference]
  =/  wanted=request:np  u.pending
  ?.  ?&  =(id.wanted id.r)
          (model-matches:provider selection.wanted provider.r model.r)
          (calls-valid:provider calls.r tools.wanted)
      ==  [%| %inference-result-mismatch]
  ?:  (gte (lent history.e) history-limit:np)  [%| %history-capacity]
  =/  blocks=(list block:np)
    (turn continuation.r |=(v=json [%opaque provider.r model.r v]))
  =.  blocks  ?:(=('' text.r) blocks (weld blocks `(list block:np)`~[[%text text.r]]))
  =.  blocks  (weld blocks (turn calls.r |=(c=call:np `block:np`[%call c])))
  ?.  ?=(^ blocks)  [%| %empty-provider-result]
  =/  next-phase=phase  ?:(?=(^ calls.r) %tools ?:(=(%refusal stop.r) %refused %judgment))
  =/  paused=?  =(%paused phase.e)
  =.  e
    e(pending ~, calls calls.r, history (weld history.e `(list message:np)`~[[%assistant blocks]]), phase ?:(paused %paused next-phase), resume next-phase)
  =/  next  (append e at [%model (publish:provider r)])
  ?:  ?=(%| -.next)  next
  =/  out=transition  p.next
  ?:  |(paused =(%refused next-phase))  [%& out]
  =/  run=(list effect)
    ?~  calls.r
      ~[[%judge id.session.e id.r ~[raw-digest.r]]]
    ~[[%tool id.session.e id.r i.calls.r]]
  [%& out(effects (weld effects.out run))]
++  result
  ::  Tool results are supplied only by the authenticated native runtime.
  ::  Text is its model-readable projection, never a second source of authority.
  |=  [at=@da e=entry r=tool-result:nc text=@t]
  ^-  (each transition @tas)
  =/  queue=(list call:np)  calls.e
  ?~  queue  [%| %no-pending-tool]
  ?.  =(~ pending.e)  [%| %no-pending-tool]
  =/  c=call:np  i.queue
  ?.  ?&  =(call-id.r id.c)  =(id.session.e session.context.r)
          =(project.session.e project.context.r)
          =(configuration.e configuration.context.r)
          =(working.session.e source.context.r)
          =(owner.session.e actor.context.r)
          =(request.context.r (request-id id.session.e (dec turn.e)))
          (lte (met 3 text) text-limit:np)
      ==  [%| %tool-result-mismatch]
  ?:  (~(has by results.e) id.c)  [%| %tool-result-already-recorded]
  ::  Unknown effects keep the exact unresolved call available for observation.
  ?:  ?=(%unknown -.output.r)
    (append e(phase %unknown, resume %unknown) at [%tool r])
  ?:  (gte (lent history.e) history-limit:np)  [%| %history-capacity]
  =/  failed=?  ?=(%refused -.output.r)
  =/  paused=?  =(%paused phase.e)
  =.  e
    e(calls t.queue, results (~(put by results.e) id.c r), history (weld history.e `(list message:np)`~[[%user ~[[%result id.c text failed]]]]))
  =/  next-phase=phase  ?:(?=(^ t.queue) %tools %ready)
  =.  e  e(phase ?:(paused %paused next-phase), resume next-phase)
  =/  next  (append e at [%tool r])
  ?:  ?=(%| -.next)  next
  =/  out=transition  p.next
  ?:  paused  [%& out]
  ?~  t.queue  [%& out]
  [%& out(effects (weld effects.out `(list effect)`~[[%tool id.session.e request.context.r i.t.queue]]))]
++  pause
  |=  [our=@p actor=@p at=@da e=entry cancel=?]
  ^-  (each transition @tas)
  ?.  &(=(our actor) =(our owner.session.e))  [%| %owner-required]
  =/  run=(list effect)
    ?:  &(cancel ?=(^ pending.e))  ~[[%cancel worker.e id.u.pending.e]]
    ~
  =/  next  (append e(phase %paused, resume ?:(=(%paused phase.e) resume.e phase.e)) at [%status %paused ?:(cancel %interrupt %operator-pause)])
  ?:  ?=(%| -.next)  next
  [%& p.next(effects (weld effects.p.next run))]
++  uncertain
  ::  Unknown remote effects remain recorded; reconnection cannot resend them.
  |=  [at=@da e=entry id=@ux reason=@tas]
  ^-  (each transition @tas)
  ?.  ?&  ?=(^ pending.e)  =(id id.u.pending.e)  ==  [%| %inference-result-mismatch]
  (append e(phase %unknown, resume %unknown) at [%status %unknown reason])
++  resume
  |=  [our=@p actor=@p at=@da e=entry]
  ^-  (each transition @tas)
  ?.  &(=(our actor) =(our owner.session.e) =(%paused phase.e))  [%| %resume-refused]
  =/  run=(list effect)
    ?:  ?=(^ pending.e)  ~
    ?:  =(%judgment resume.e)  ~[[%judge id.session.e (request-id id.session.e (dec turn.e)) ?~(head.e ~ ~[u.head.e])]]
    ?:  ?=(^ calls.e)  ~[[%tool id.session.e (request-id id.session.e (dec turn.e)) i.calls.e]]
    ~
  =/  next  (append e(phase resume.e) at [%status resume.e %operator-resume])
  ?:  ?=(%| -.next)  next
  [%& p.next(effects (weld effects.p.next run))]
++  select
  |=  [our=@p actor=@p at=@da e=entry s=selection:np worker=@p]
  ^-  (each transition @tas)
  ?.  &(=(our actor) =(our owner.session.e) (selection-valid:provider s))  [%| %selection-refused]
  ?.  &(?=(~ pending.e) ?=(~ calls.e))  [%| %turn-still-pending]
  (append e(selection s, worker worker) at [%selection s])
++  judge
  ::  Viki supplies native acceptance evidence; the model cannot call this.
  |=  [at=@da e=entry verdict=?(%complete %continue %refuse) evidence=(list @ux) reason=@t]
  ^-  (each transition @tas)
  ?.  &(=(%judgment phase.e) ?=(~ pending.e) ?=(~ calls.e))  [%| %judgment-not-ready]
  ?.  &(?=(^ evidence) (text-valid reason))  [%| %judgment-evidence-required]
  =/  next-phase=phase  ?-(verdict %complete %complete, %continue %ready, %refuse %refused)
  (append e(phase next-phase, resume next-phase) at [%judgment verdict evidence reason])
++  checkpoint
  ::  A compact continuation never deletes the retained original records.
  |=  [our=@p actor=@p at=@da e=entry text=@t through=@ux history=(list message:np)]
  ^-  (each transition @tas)
  ?.  &(=(our actor) =(our owner.session.e) ?=(~ pending.e) ?=(~ calls.e))  [%| %checkpoint-refused]
  ?.  &((text-valid text) (history-valid:provider history) (lien records.e |=(r=record =(through id.r))))
    [%| %checkpoint-invalid]
  (append e(summary text, summary-through `through, history history) at [%status phase.e %continuation-checkpoint])
++  advance-source
  ::  Viki calls this only after canonically confirming an approved landing.
  ::  Remaining calls from the old source receive explicit refusals, never
  ::  silent execution against new bytes. Only a retained fleet assignment
  ::  continues automatically; ordinary sessions and operator pauses stop.
  |=  [at=@da e=entry source=revision:nc evidence=@ux automatic=?]
  ^-  (each transition @tas)
  =/  pending  pending.e
  ?.  &(?=(~ pending) (revision-valid:project source))  [%| %source-advance-refused]
  ?.  &(=(owner.working.session.e owner.source) =(desk.working.session.e desk.source) =(+(number.working.session.e) number.source))  [%| %source-advance-mismatch]
  =/  paused=?  =(%paused phase.e)
  =/  effects=(list effect)  ~
  =.  e  e(phase %paused)
  |-  ^-  (each transition @tas)
  =/  queue=(list call:np)  calls.e
  ?~  queue
    =/  next-phase=phase  ?:(|(paused !automatic) %paused %ready)
    =/  confirmed=@t
      (rap 3 ~['Viki native confirmation: review is approved and the exact candidate has already landed in private working source ' (scot %p owner.source) '/' (scot %tas desk.source) '/' (scot %ud number.source) ' root=' (scot %uv root.source) ' commit=' (scot %uv commit.source) ' evidence=' (scot %ux evidence) '. Review and landing are complete; do not request or replay them. No deployment or accepted-source change is claimed. Continue only remaining work under the existing grant; this confirmation grants no new tools or permissions and does not claim task completion.'])
    =.  e
      e(session session.e(working source), phase next-phase, resume %ready, history (weld history.e `(list message:np)`~[[%user ~[[%text confirmed]]]]))
    =/  reason=@t
      ?:  automatic  'Exact approved candidate landed. Continue from the new numbered source.'
      'Exact approved candidate landed in the private working source. Coding is paused; Resume to continue remaining work. Task completion is not claimed.'
    =/  next  (append e at [%judgment %continue ~[evidence] reason])
    ?:  ?=(%| -.next)  next
    [%& p.next(effects (weld effects effects.p.next))]
  =/  context=context:nc
    [project.session.e configuration.e id.session.e (request-id id.session.e (dec turn.e)) owner.session.e working.session.e]
  =/  refused=tool-result:nc
    [%native-coding-tool-result-v1 context id.i.queue [%refused %source-advanced 'Call was not executed: the approved candidate changed the source revision. Propose a new call.']]
  =/  next  (result at e refused 'Not executed: source revision advanced after approved candidate landing.')
  ?:  ?=(%| -.next)  next
  $(e entry.p.next, effects (weld effects effects.p.next))
++  revise
  ::  Failed native checks guide a fresh proposal. Superseded queued calls
  ::  receive results so provider history does not contain dangling calls.
  |=  [at=@da e=entry evidence=@ux reason=@t]
  ^-  (each transition @tas)
  =/  pending  pending.e
  ?.  &(?=(~ pending) (text-valid reason))  [%| %revision-guidance-refused]
  =/  paused=?  =(%paused phase.e)
  =/  effects=(list effect)  ~
  =.  e  e(phase %paused)
  |-  ^-  (each transition @tas)
  =/  queue=(list call:np)  calls.e
  ?~  queue
    =.  e  e(phase ?:(paused %paused %ready), resume %ready, history (weld history.e `(list message:np)`~[[%user ~[[%text reason]]]]))
    =/  next  (append e at [%judgment %continue ~[evidence] reason])
    ?:  ?=(%| -.next)  next
    [%& p.next(effects (weld effects effects.p.next))]
  =/  context=context:nc
    [project.session.e configuration.e id.session.e (request-id id.session.e (dec turn.e)) owner.session.e working.session.e]
  =/  refused=tool-result:nc
    [%native-coding-tool-result-v1 context id.i.queue [%refused %candidate-revision-required 'Not executed: Viki requires a revised candidate after native review.']]
  =/  next  (result at e refused 'Not executed: candidate revision required.')
  ?:  ?=(%| -.next)  next
  $(e entry.p.next, effects (weld effects effects.p.next))
--
