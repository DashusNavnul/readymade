::  Mathematical/session fixtures only; these are not model observations.
/-  nc=native-coding, np=native-coding-provider
/+  qpc=qpc-native-collection, sessions=native-coding-session
|%
++  patch
  |=  [id=@t replacement=@t]
  ^-  call:np
  :+  id  'patch'
  (pairs:enjs:format ~[['path' s+'/lib/example/hoon'] ['before' s+'0x1'] ['start' n+'1'] ['remove' n+'1'] ['expected' s+'old\0a'] ['replacement' s+replacement]])
++  actionable
  |=  next=transition:sessions
  ^-  (list effect:sessions)
  (skip effects.next |=(e=effect:sessions ?=(%retain -.e)))
++  prove
  =/  at=@da  ~2026.10.10
  =/  source=revision:nc  [~zod %work 1 0v1 0v2]
  =/  e=entry:sessions  *entry:sessions
  =/  rid=@ux  (request-id:sessions 0x11 0)
  =/  request=request:np  *request:np
  =.  request  request(id rid, session 0x11, tools tools:qpc)
  =.  e
    e(id.session 0x11, project.session 'qpc', owner.session ~zod, working.session source, configuration 0x12, phase %inference, resume %inference, turn 1, pending `request)
  =/  first=call:np  (patch 'a' 'first\0a')
  =/  second=call:np  (patch 'b' 'second\0a')
  =/  reply=reply:np  *reply:np
  =.  reply  reply(id rid, stop %tools, calls ~[first second], raw-digest 0x23)
  =/  opened  (model:qpc at e reply)
  ?>  ?=(%& -.opened)
  =/  next=transition:sessions  p.opened
  ?>  =(%tools phase.entry.next)
  ?>  =(`(list effect:sessions)`~[[%tool 0x11 rid first]] (actionable next))
  =/  kept=record:sessions  (rear records.entry.next)
  ?>  &(=(2 (lent calls.entry.next)) ?=(%model -.body.kept))
  =/  ctx=context:nc  ['qpc' 0x12 0x11 rid ~zod source]
  =/  candidate=candidate:nc  *candidate:nc
  =.  candidate  candidate(id 0x31, context ctx)
  =/  r=tool-result:nc  [%native-coding-tool-result-v1 ctx 'a' [%candidate candidate]]
  =/  one  (result:qpc at entry.next r 'first candidate retained')
  ?>  ?=(%& -.one)
  ?>  =(`(list effect:sessions)`~[[%tool 0x11 rid second]] (actionable p.one))
  ?>  =(%tools phase.entry.p.one)
  =/  last=tool-result:nc  r(call-id 'b', output [%candidate candidate(id 0x32)])
  =/  two  (result:qpc at entry.p.one last 'second candidate retained')
  ?>  ?=(%& -.two)
  ?>  &(=(%paused phase.entry.p.two) =(%paused resume.entry.p.two))
  ?>  &(=(~ calls.entry.p.two) =(2 ~(wyt by results.entry.p.two)))
  ?>  &((sealed:qpc entry.p.two) =(~ (actionable p.two)))
  =/  duplicate  (result:qpc at entry.p.two last 'duplicate')
  ?>  ?=(%| -.duplicate)
  =/  rerun  (model:qpc at entry.p.two reply)
  ?>  ?=(%| -.rerun)
  ::  Pause before the reply, and pause between alternatives, preserve the
  ::  queue without dispatch. Explicit ordinary resume emits only its head.
  =/  paused  (model:qpc at e(phase %paused) reply)
  ?>  ?=(%& -.paused)
  ?>  &(=(%paused phase.entry.p.paused) =(~ (actionable p.paused)))
  =/  resumed  (resume:sessions ~zod ~zod at entry.p.paused)
  ?>  ?=(%& -.resumed)
  ?>  =(`(list effect:sessions)`~[[%tool 0x11 rid first]] (actionable p.resumed))
  =/  stopped  (result:qpc at entry.next(phase %paused) r 'paused result')
  ?>  ?=(%& -.stopped)
  ?>  &(=(%paused phase.entry.p.stopped) =(%tools resume.entry.p.stopped) =(~ (actionable p.stopped)))
  ::  Unknown retains the exact unresolved call; no second proposal or review.
  =/  unknown  (result:qpc at entry.next r(output [%unknown %unconfirmed 'unknown']) 'unknown')
  ?>  ?=(%& -.unknown)
  ?>  &(=(%unknown phase.entry.p.unknown) =(calls.entry.next calls.entry.p.unknown) =(~ (actionable p.unknown)))
  ::  Every call is validated before the first dispatch, including the last.
  =/  malformed=call:np  second(arguments (pairs:enjs:format ~[['path' s+'/lib/example/hoon']]))
  =/  rejected  (model:qpc at e reply(calls ~[first malformed]))
  ?>  ?=(%& -.rejected)
  ?>  &((sealed:qpc entry.p.rejected) =(~ (actionable p.rejected)) =(~ calls.entry.p.rejected))
  =/  mixed  (model:qpc at e reply(calls ~[first second(name 'eval')]))
  ?>  ?=(%| -.mixed)
  =/  short  (model:qpc at e reply(calls ~[first]))
  ?>  ?=(%& -.short)
  ?>  &((sealed:qpc entry.p.short) =(~ (actionable p.short)))
  =/  truncated  (model:qpc at e reply(stop %length))
  ?>  ?=(%& -.truncated)
  ?>  &((sealed:qpc entry.p.truncated) =(~ (actionable p.truncated)))
  ::  A refused native patch remains evidence, never a fabricated candidate.
  =/  refusal  (result:qpc at entry.p.one last(output [%refused %stale 'stale']) 'refused')
  ?>  ?=(%& -.refusal)
  ?>  &((sealed:qpc entry.p.refusal) =(~ (actionable p.refusal)))
  [%qpc-native-collection-proof-v1 %whole-reply-checked %alternatives-collected %no-review]
--
