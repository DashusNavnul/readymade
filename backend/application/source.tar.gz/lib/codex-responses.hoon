::  Pure Responses transport codec. Provider text is data, never commands.
::  Reference: https://developers.openai.com/api/reference/responses/create
::  and https://platform.openai.com/docs/api-reference/responses-streaming
::  The caller owns HTTP authentication, context, admission and persistence.
|%
++  body-limit  2.097.152
++  event-limit  8.192
++  text-limit  65.536
+$  receipt
  $:  version=%codex-responses-v1
      text=@t  model=@t  response-id=@t  usage=json
      raw=@t  raw-bytes=@ud  raw-digest=@ux
      format=?(%json %sse)  events=@ud
  ==
+$  stream-state
  $:  done=(unit json)
      previous=(unit @ud)
      count=@ud
      ended=?
      identity=(unit [id=@t model=@t])
      seen=(map @ud [id=@t kind=@t])
      items=(map @ud json)
  ==
++  field
  |=  [value=json key=@t]
  ^-  (unit json)
  ?.  ?=([%o *] value)  ~
  (~(get by p.value) key)
++  string
  |=  [value=json key=@t]
  ^-  (unit @t)
  =/  got  (field value key)
  ?~  got  ~
  ?.  ?=([%s *] u.got)  ~
  `p.u.got
++  bounded
  |=  [text=@t limit=@ud]
  ^-  ?
  &((gth (met 3 text) 0) (lte (met 3 text) limit))
++  nullable
  |=  value=(unit json)
  ^-  ?
  ?~(value %.y =(~ u.value))
++  natural
  |=  value=(unit json)
  ^-  (unit @ud)
  ?~  value  ~
  ?.  ?=([%n *] u.value)  ~
  ?.  (bounded p.u.value 20)  ~
  ?.  (levy (trip p.u.value) |=(c=@t &((gte c '0') (lte c '9'))))  ~
  (rush p.u.value dem)
++  request
  |=  [model=@t instructions=@t input=json streaming=?]
  ^-  (each @t @tas)
  ?.  &((bounded model 256) (bounded instructions text-limit))
    [%| %request-invalid]
  ?.  ?=([%a ^] input)  [%| %input-invalid]
  =/  body=@t
    %-  en:json:html
    %-  pairs:enjs:format
    :~  ['model' s+model]
        ['instructions' s+instructions]
        ['input' input]
        ['include' a+~[s+'reasoning.encrypted_content']]
        ['tools' a+~]
        ['tool_choice' s+'auto']
        ['parallel_tool_calls' b+%.n]
        ['store' b+%.n]
        ['stream' b+streaming]
    ==
  ?.  (bounded body body-limit)  [%| %request-too-large]
  [%& body]
++  message-text
  |=  item=json
  ^-  (each @t @tas)
  =/  kind  (string item 'type')
  ?:  =(`'reasoning' kind)
    =/  status  (field item 'status')
    ?.  |((nullable status) =(`[%s 'completed'] status))
      [%| %incomplete-item]
    [%& '']
  ?.  =(`'message' kind)  [%| %tool-output-refused]
  ?.  =(`'assistant' (string item 'role'))
    [%| %message-invalid]
  ?.  =(`'completed' (string item 'status'))  [%| %incomplete-item]
  =/  parts  (field item 'content')
  ?~  parts  [%| %message-invalid]
  ?.  ?=([%a ^] u.parts)  [%| %message-invalid]
  =/  rest=(list json)  p.u.parts
  =/  text=@t  ''
  |-  ^-  (each @t @tas)
  ?~  rest  [%& text]
  ?.  =(`'output_text' (string i.rest 'type'))  [%| %refusal-or-tool]
  =/  part  (string i.rest 'text')
  ?~  part  [%| %text-invalid]
  ?.  (lte (add (met 3 text) (met 3 u.part)) text-limit)
    [%| %text-too-large]
  $(rest t.rest, text (cat 3 text u.part))
++  response-text
  |=  response=json
  ^-  (each @t @tas)
  ?.  =(`'response' (string response 'object'))  [%| %response-invalid]
  ?.  =(`'completed' (string response 'status'))  [%| %incomplete-response]
  ?.  &((nullable (field response 'error')) (nullable (field response 'incomplete_details')))
    [%| %provider-error]
  =/  output  (field response 'output')
  ?~  output  [%| %output-missing]
  ?.  ?=([%a ^] u.output)  [%| %output-missing]
  =/  rest=(list json)  p.u.output
  =/  text=@t  ''
  |-  ^-  (each @t @tas)
  ?~  rest
    ?.  (bounded text text-limit)  [%| %text-missing]
    [%& text]
  =/  part  (message-text i.rest)
  ?.  ?=(%& -.part)  [%| p.part]
  ?.  (lte (add (met 3 text) (met 3 p.part)) text-limit)
    [%| %text-too-large]
  $(rest t.rest, text (cat 3 text p.part))
++  finish
  |=  [response=json raw=@t format=?(%json %sse) events=@ud]
  ^-  (each receipt @tas)
  =/  content  (response-text response)
  ?.  ?=(%& -.content)  [%| p.content]
  =/  model  (string response 'model')
  =/  id  (string response 'id')
  ?~  model  [%| %model-missing]
  ?~  id  [%| %response-id-missing]
  ?.  &((bounded u.model 256) (bounded u.id 256))  [%| %identity-invalid]
  =/  usage  (field response 'usage')
  ?~  usage  [%| %usage-missing]
  =/  in  (natural (field u.usage 'input_tokens'))
  =/  out  (natural (field u.usage 'output_tokens'))
  =/  total  (natural (field u.usage 'total_tokens'))
  ?~  in  [%| %usage-invalid]
  ?~  out  [%| %usage-invalid]
  ?~  total  [%| %usage-invalid]
  ?.  =((add u.in u.out) u.total)  [%| %usage-invalid]
  [%& [%codex-responses-v1 p.content u.model u.id u.usage raw (met 3 raw) (shax raw) format events]]
++  lines
  |=  raw=@t
  ^-  (list @t)
  =/  rest=tape  (trip raw)
  =/  line=tape  ~
  =/  out=(list @t)  ~
  |-  ^-  (list @t)
  ?~  rest  (flop ?~(line out [(crip (flop line)) out]))
  ?:  =(10 i.rest)
    =/  kept=tape  ?~(line ~ ?:(=(13 i.line) t.line line))
    $(rest t.rest, line ~, out [(crip (flop kept)) out])
  $(rest t.rest, line [i.rest line])
++  safe-item
  |=  item=json
  ^-  ?
  =/  kind  (string item 'type')
  ?.  |(=(`'message' kind) =(`'reasoning' kind))  %.n
  =/  content  (field item 'content')
  ?:  =(`'reasoning' kind)  %.y
  ?~  content  %.n
  ?.  ?=([%a *] u.content)  %.n
  (levy p.u.content |=(part=json =(`'output_text' (string part 'type'))))
++  progress-valid
  |=  [event=json kind=@t]
  ^-  ?
  ?:  |(=('response.created' kind) =('response.in_progress' kind))
    =/  response  (field event 'response')
    ?~  response  %.n
    ?.  (nullable (field u.response 'error'))  %.n
    =/  output  (field u.response 'output')
    ?~  output  %.n
    ?.  ?=([%a *] u.output)  %.n
    (levy p.u.output safe-item)
  ?:  |(=('response.output_item.added' kind) =('response.output_item.done' kind))
    =/  item  (field event 'item')
    ?~(item %.n (safe-item u.item))
  ?:  |(=('response.content_part.added' kind) =('response.content_part.done' kind))
    =/  part  (field event 'part')
    ?~(part %.n =(`'output_text' (string u.part 'type')))
  ?:  |(=('response.reasoning_summary_part.added' kind) =('response.reasoning_summary_part.done' kind))
    =/  part  (field event 'part')
    ?~(part %.n =(`'summary_text' (string u.part 'type')))
  ?:  (~(has in (silt ~['response.output_text.delta' 'response.reasoning_text.delta' 'response.reasoning_summary_text.delta'])) kind)
    ?=(^ (string event 'delta'))
  ?:  (~(has in (silt ~['response.output_text.done' 'response.reasoning_text.done' 'response.reasoning_summary_text.done'])) kind)
    ?=(^ (string event 'text'))
  %.n
++  identify
  |=  [response=json state=stream-state]
  ^-  (each stream-state @tas)
  ?.  =(`'response' (string response 'object'))  [%| %response-invalid]
  =/  id  (string response 'id')
  =/  model  (string response 'model')
  ?~  id  [%| %identity-invalid]
  ?~  model  [%| %identity-invalid]
  ?.  &((bounded u.id 256) (bounded u.model 256))  [%| %identity-invalid]
  =/  value=[id=@t model=@t]  [u.id u.model]
  ?.  ?~(identity.state %.y =(u.identity.state value))  [%| %response-conflict]
  [%& state(identity `value)]
++  item-event
  |=  [event=json added=? state=stream-state]
  ^-  (each stream-state @tas)
  ?~  identity.state  [%| %response-identity-missing]
  =/  index  (natural (field event 'output_index'))
  ?~  index  [%| %item-index-invalid]
  ?.  (lth u.index 256)  [%| %item-index-invalid]
  =/  item  (field event 'item')
  ?~  item  [%| %item-missing]
  ?.  (safe-item u.item)  [%| %tool-output-refused]
  =/  id  (string u.item 'id')
  =/  kind  (string u.item 'type')
  ?~  id  [%| %item-id-invalid]
  ?~  kind  [%| %item-id-invalid]
  ?.  (bounded u.id 256)  [%| %item-id-invalid]
  =/  old  (~(get by seen.state) u.index)
  ?.  ?~  old
        (levy ~(tap by seen.state) |=([slot=@ud entry-id=@t entry-kind=@t] !=(entry-id u.id)))
      &(!added =([u.id u.kind] u.old))
    [%| %item-conflict]
  ?:  (~(has by items.state) u.index)  [%| %item-duplicate]
  =/  next=stream-state  state(seen (~(put by seen.state) u.index [u.id u.kind]))
  ?:  added  [%& next]
  =/  valid  (message-text u.item)
  ?.  ?=(%& -.valid)  [%| p.valid]
  [%& next(items (~(put by items.next) u.index u.item))]
++  assemble
  |=  [response=json state=stream-state]
  ^-  (each json @tas)
  ?.  ?=([%o *] response)  [%| %response-invalid]
  =/  output  (field response 'output')
  ?~  output  [%| %output-missing]
  ?.  ?=([%a *] u.output)  [%| %output-missing]
  =/  count=@ud  ~(wyt by items.state)
  ?.  =(count ~(wyt by seen.state))  [%| %item-unfinished]
  ?:  =(0 count)  [%& response]
  =/  index=@ud  0
  =/  collected=(list json)  ~
  |-  ^-  (each json @tas)
  ?:  =(index count)
    =/  ordered=(list json)  (flop collected)
    ?.  ?~(p.u.output %.y =(p.u.output ordered))  [%| %output-conflict]
    [%& [%o (~(put by p.response) 'output' [%a ordered])]]
  =/  item  (~(get by items.state) index)
  ?~  item  [%| %item-index-gap]
  $(index +(index), collected [u.item collected])
++  event
  |=  [name=@t data=@t state=stream-state]
  ^-  (each stream-state @tas)
  ?:  =('[DONE]' data)
    ?.  &(?=(^ done.state) !ended.state)  [%| %sse-terminal-invalid]
    [%& state(ended %.y)]
  ?:  |(?=(^ done.state) ended.state)  [%| %sse-trailing-event]
  ?:  (gte count.state event-limit)  [%| %sse-too-many-events]
  =/  parsed  (de:json:html data)
  ?~  parsed  [%| %sse-json-invalid]
  =/  kind  (string u.parsed 'type')
  ?~  kind  [%| %sse-event-invalid]
  ?.  |(=('' name) =(name u.kind))  [%| %sse-event-mismatch]
  =/  sequence  (natural (field u.parsed 'sequence_number'))
  ?~  sequence  [%| %sse-sequence-invalid]
  ?.  ?~(previous.state %.y (gth u.sequence u.previous.state))
    [%| %sse-sequence-invalid]
  =/  next=stream-state  state(previous sequence, count +(count.state))
  =/  response  (field u.parsed 'response')
  =/  bound=(each stream-state @tas)
    ?~(response [%& next] (identify u.response next))
  ?.  ?=(%& -.bound)  [%| p.bound]
  =.  next  p.bound
  =/  reference  (field u.parsed 'response_id')
  ?.  ?~  reference  %.y
      ?&  ?=([%s *] u.reference)
          ?=(^ identity.next)
          =(p.u.reference id.u.identity.next)
      ==
    [%| %response-conflict]
  ?:  =('response.completed' u.kind)
    ?~  response  [%| %response-missing]
    =/  complete  (assemble u.response next)
    ?.  ?=(%& -.complete)  [%| p.complete]
    [%& next(done `p.complete)]
  ?:  |(=('response.output_item.added' u.kind) =('response.output_item.done' u.kind))
    (item-event u.parsed =('response.output_item.added' u.kind) next)
  =/  index  (natural (field u.parsed 'output_index'))
  ?.  ?~(index %.y !(~(has by items.next) u.index))  [%| %item-trailing-event]
  ?.  (progress-valid u.parsed u.kind)  [%| %sse-event-refused]
  [%& next]
++  sse
  |=  raw=@t
  ^-  (each receipt @tas)
  =/  rest=(list @t)  (lines raw)
  =/  name=@t  ''
  =/  data=@t  ''
  =/  state=stream-state  [~ ~ 0 %.n ~ ~ ~]
  |-  ^-  (each receipt @tas)
  ?~  rest
    ?.  &(=('' data) =('' name))  [%| %sse-unfinished-event]
    ?~  done.state  [%| %completion-missing]
    (finish u.done.state raw %sse count.state)
  =/  line=@t  i.rest
  ?:  =('' line)
    ?:  =('' data)
      ?.  =('' name)  [%| %sse-data-missing]
      $(rest t.rest)
    =/  step  (event name data state)
    ?.  ?=(%& -.step)  [%| p.step]
    $(rest t.rest, name '', data '', state p.step)
  ?:  =(':' (cut 3 [0 1] line))  $(rest t.rest)
  =/  is-data=?  =('data:' (cut 3 [0 5] line))
  =/  is-name=?  =('event:' (cut 3 [0 6] line))
  ?.  |(is-data is-name)  [%| %sse-field-refused]
  =/  start=@ud  ?:(is-data 5 6)
  =/  value=@t  (rsh [3 start] line)
  =/  trimmed=@t
    ?:(=(' ' (cut 3 [0 1] value)) (rsh [3 1] value) value)
  ?:  is-name
    ?.  =('' name)  [%| %sse-duplicate-event]
    $(rest t.rest, name trimmed)
  $(rest t.rest, data ?:(=('' data) trimmed (cat 3 data (cat 3 '\0a' trimmed))))
++  decode
  |=  raw=@t
  ^-  (each receipt @tas)
  ?.  (bounded raw body-limit)  [%| %body-size-invalid]
  =/  parsed  (de:json:html raw)
  ?^  parsed  (finish u.parsed raw %json 1)
  (sse raw)
++  decode-chunks
  |=  chunks=(list @t)
  ^-  (each receipt @tas)
  =/  raw=@t  ''
  =/  count=@ud  0
  |-  ^-  (each receipt @tas)
  ?~  chunks  (decode raw)
  ?.  &((lth count 4.096) (lte (add (met 3 raw) (met 3 i.chunks)) body-limit))
    [%| %body-size-invalid]
  $(chunks t.chunks, raw (cat 3 raw i.chunks), count +(count))
--
