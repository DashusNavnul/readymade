::  Candidate-owner history law. Full correlated evidence, never authority.
::  No app migration, Clay submission, grant removal or dispatch lives here.
/-  w=native-coding-worker, wr=native-coding-worker-runtime, nc=native-coding
/+  owner=native-coding-worker-owner, journal=native-coding-worker-journal,
    law=native-coding-worker, accept=native-coding-accept,
    ct=cantrip-native-coding, names=native-coding-provider
|%
+$  parent
  [%native-coding-worker-parent-v1 engaged=? owner=state:owner pending=(map @ux @ux) failures=(map @ux @tas)]
+$  receipt
  $:  %native-coding-worker-owner-retired-v1
      key=@ux  ticket=@ux  candidate=@ux
      job=record:w  offer=(unit offer:wr)  failure=(unit @tas)
      settled=record:accept  grant=scope:ct
  ==
+$  head  [desk=@tas number=@ud commit=@uv]
+$  state  [head=(unit head) writing=(unit receipt)]
++  empty  *state
++  hot-limit  192
++  parent-valid
  ::  This is the existing parent DATA shape, including its cross-map joins.
  |=  [our=@p s=parent]
  ^-  ?
  ?&  (valid:owner our owner.s)  (lte ~(wyt by pending.s) capacity:journal)
      (levy ~(tap by pending.s) |=([ticket=@ux id=@ux] &((identifier:law ticket) (identifier:law id))))
      (levy ~(tap by failures.s) |=([ticket=@ux reason=@tas] &((~(has by pending.s) ticket) !=(0 reason) (lte (met 3 reason) 128))))
      (levy ~(val by journal.owner.s) |=(j=record:w =(`candidate.order.j (~(get by pending.s) ticket.order.j))))
  ==
++  settled-result
  ::  Report translation is historical. It does not recheck or grant authority.
  |=  [j=record:w r=record:accept]
  ^-  ?
  ?.  &(?=(?(%checked %refused) phase.j) sent.j ?=(^ result.j) ?=(~ reason.j))  %.n
  ?.  ?=(?(%applied %refused) stage.r)  %.n
  =/  out=result:w  u.result.j
  ?:  ?=(%refused -.outcome.out)
    ?&  =(%refused phase.j)  =(%refused stage.r)
        !=(%worker-deadline-unconfirmed reason.outcome.out)
        =(`reason.outcome.out reason.r)
        ?=(~ report.r)  ?=(~ decision.r)  ?=(~ landed.r)
    ==
  ?.  &(!=(%refused phase.j) ?=(^ staging.r) ?=(^ report.r) ?=(^ decision.r))  %.n
  =/  rows=(list target-result:accept)
    (turn rows.outcome.out |=(v=row:w [target.v (turn diagnostics.v |=(d=diagnostic:nc d(source source.order.j)))]))
  ?&  =(u.report.r [%native-coding-candidate-report-v1 candidate.order.j u.staging.r rows])
      ?:  =(%applied stage.r)  =(%approve verdict.u.decision.r)
      &(!=(%approve verdict.u.decision.r) =(`verdict.u.decision.r reason.r))
  ==
++  valid-receipt
  |=  [our=@p e=receipt]
  ^-  ?
  ::  Retain every unknown first-failure/QPC release witness in the hot maps.
  ?.  &(?=(~ failure.e) ?=(^ offer.e) (settled-result job.e settled.e))  %.n
  =/  o=order:w  order.job.e
  =/  r=record:accept  settled.e
  ?.  ?=(^ staging.r)  %.n
  =/  checking=record:accept  r(stage %checking, report ~, decision ~, landed ~, reason ~)
  ?&  =(key.e (digest:law o))  =(ticket.e ticket.o)  =(candidate.e candidate.o)
      =(our owner.pairing.o)  =(candidate.e id.candidate.r)
      =(context.o context.candidate.r)  =(grant.o grant.r)
      =(source.o revision.u.staging.r)
      =(namespace.o (namespace-digest:law files.body.snapshot.u.staging.r))
      =(targets.o (required:accept project.r candidate.r))
      |(=(ticket.e (ticket:owner checking)) =(ticket.e (ticket:owner checking(reason `%candidate-recheck))))
      (valid:accept (malt ~[[candidate.e r]]))
      (valid:owner our [%native-coding-worker-owner-v1 ~ (malt ~[[key.e job.e]]) (malt ~[[key.e u.offer.e]])])
      (grant-valid:ct our grant.grant.e)
      =(grant.r id.grant.grant.e)  =(project.r project.grant.grant.e)
      =(session.context.candidate.r session.grant.grant.e)
      =(actor.context.candidate.r actor.grant.grant.e)
  ==
++  matches
  |=  [s=parent e=receipt]
  ^-  ?
  ?&  =(`job.e (~(get by journal.owner.s) key.e))
      =(offer.e (~(get by offers.owner.s) key.e))
      =(`candidate.e (~(get by pending.s) ticket.e))
      =(failure.e (~(get by failures.s) ticket.e))
  ==
++  snapshot
  ::  Runtime supplies canonical candidate/grant reads, not poke payloads.
  |=  [our=@p s=parent key=@ux settled=record:accept grant=scope:ct]
  ^-  (each receipt @tas)
  ?.  (parent-valid our s)  [%| %worker-owner-archive-parent-invalid]
  =/  found  (~(get by journal.owner.s) key)
  ?~  found  [%| %worker-owner-archive-job-missing]
  =/  j=record:w  u.found
  =/  e=receipt
    [%native-coding-worker-owner-retired-v1 key ticket.order.j candidate.order.j j (~(get by offers.owner.s) key) (~(get by failures.s) ticket.order.j) settled grant]
  ?.  &((matches s e) (valid-receipt our e))  [%| %worker-owner-archive-unsettled]
  [%& e]
++  retire
  ::  Only after exact archive readback. Candidate and grants stay canonical;
  ::  all four historical worker maps retire together in one native event.
  |=  [our=@p s=parent expected=receipt observed=receipt current=record:accept]
  ^-  parent
  ?>  &((parent-valid our s) (valid-receipt our expected) =(expected observed))
  ?>  &((matches s expected) =(current settled.expected))
  =/  next=parent
    s(owner owner.s(journal (~(del by journal.owner.s) key.expected), offers (~(del by offers.owner.s) key.expected)), pending (~(del by pending.s) ticket.expected), failures (~(del by failures.s) ticket.expected))
  ?>  (parent-valid our next)
  next
++  replay
  ::  A retained ticket can be observed but never dispatched again. An exact
  ::  historical grant snapshot is evidence, even if it is now revoked.
  |=  [our=@p src=@p e=receipt ticket=@ux candidate=record:accept]
  ^-  (each receipt @tas)
  ?.  &(=(our src) (valid-receipt our e))  [%| %worker-owner-archive-owner-required]
  ?.  ?&  =(ticket ticket.e)  =(candidate.candidate candidate.settled.e)
          =(project.candidate project.settled.e)  =(grant.candidate grant.settled.e)
          =(requested-at.candidate requested-at.settled.e)
          =(staging.candidate staging.settled.e)
      ==  [%| %worker-owner-archive-ticket-conflict]
  [%& e]
++  replay-order
  |=  [our=@p src=@p e=receipt o=order:w]
  ^-  (each receipt @tas)
  ?.  &(=(our src) (valid-receipt our e))  [%| %worker-owner-archive-owner-required]
  ?.  =(o order.job.e)  [%| %worker-owner-archive-ticket-conflict]
  [%& e]
++  path-for
  |=(key=@ux ^-(path /native-worker-owner-history/by-key/(scot %ux key)/noun))
++  ticket-path
  |=(ticket=@ux ^-(path /native-worker-owner-history/by-ticket/(scot %ux ticket)/noun))
++  pointer
  |=  e=receipt
  [%native-worker-owner-ticket-v1 key.e (shax (jam e))]
++  append-valid
  |=  [before=head after=head e=receipt old=yaki:clay new=yaki:clay]
  ^-  ?
  ?&  =(desk.before desk.after)  =(+(number.before) number.after)
      =(~[commit.before] p.new)
      !(~(has by q.old) (path-for key.e))  !(~(has by q.old) (ticket-path ticket.e))
      =/  expected  (~(put by q.old) (path-for key.e) (page-to-lobe:clay [%noun e]))
      =(q.new (~(put by expected) (ticket-path ticket.e) (page-to-lobe:clay [%noun (pointer e)])))
  ==
++  valid
  |=  [our=@p s=state parent=parent]
  ^-  ?
  ?~  head.s  ?=(~ writing.s)
  ?.  &((name-valid:names desk.u.head.s) !=(%base desk.u.head.s) (lte (met 0 commit.u.head.s) 256))  %.n
  ?~  writing.s  %.y
  &((valid-receipt our u.writing.s) (matches parent u.writing.s))
--
