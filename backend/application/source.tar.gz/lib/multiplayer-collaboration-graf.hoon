::  /lib/multiplayer-collaboration-graf
::
::  Pure projection from an already-admitted collaboration envelope into
::  Graf crossing-lane metadata.  Names are receiver-side inputs to handle
::  derivation; only content addresses, finite classes, sizes, and ship
::  identities survive in the record.
::
/-  mc=multiplayer-collaboration, graf-sur=graf
/+  mcl=multiplayer-collaboration, graf-attic
|%
++  max-crossing-envelope-bytes  `@ud`4.096
++  max-crossing-page-work  `@ud`512
++  crossing-family  %collaboration-crossing
::
++  commit
  |=  noun=*
  ^-  digest:mc
  `@ux`(shax (jam noun))
++  session-hash
  |=  [ship=@p session=@t]
  ^-  digest:mc
  (commit [%multiplayer-collaboration-session-v1 ship session])
++  node-handle
  |=  [parent=digest:mc branch=crossing-branch:mc subject=*]
  ^-  digest:mc
  (commit [%multiplayer-collaboration-crossing-node-v1 parent branch subject])
++  crossing-layout
  |=  expected=expectation:mc
  ^-  crossing-layout:mc
  =/  lane-root=digest:mc
    (commit [%multiplayer-collaboration-crossing-root-v1 graf-root.expected])
  =/  project-root=digest:mc
    (node-handle lane-root %project project.expected)
  =/  task-root=digest:mc
    (node-handle project-root %task task.expected)
  :*  %multiplayer-collaboration-crossing-layout-v1
      lane-root
      project-root
      task-root
      (node-handle task-root %event ~)
      (node-handle task-root %review ~)
      (node-handle task-root %proof ~)
      (node-handle task-root %landing ~)
      (node-handle task-root %conflict ~)
      (node-handle task-root %recovery ~)
      (node-handle task-root %release ~)
  ==
++  layout-roots
  |=  layout=crossing-layout:mc
  ^-  (list digest:mc)
  :~  project-root.layout
      task-root.layout
      event-root.layout
      review-root.layout
      proof-root.layout
      landing-root.layout
      conflict-root.layout
      recovery-root.layout
      release-root.layout
  ==
++  layout-valid
  |=  [expected=expectation:mc layout=crossing-layout:mc]
  ^-  ?
  =/  roots=(list digest:mc)  (layout-roots layout)
  ?&  =((crossing-layout expected) layout)
      (digest-valid:mcl lane-root.layout)
      (levy roots digest-valid:mcl)
      =(9 ~(wyt in (silt roots)))
  ==
++  branch-for
  |=  payload=payload:mc
  ^-  crossing-branch:mc
  ?-  -.payload
    %assignment    %task
    %progress      %event
    %review        %review
    %proof         %proof
    %acceptance    %landing
    %refusal       %conflict
    %cancellation  %recovery
    %expiry        %recovery
    %failure       %conflict
    %completion    %release
  ==
++  root-for
  |=  [layout=crossing-layout:mc branch=crossing-branch:mc]
  ^-  digest:mc
  ?-    branch
      %project   project-root.layout
      %task      task-root.layout
      %event     event-root.layout
      %review    review-root.layout
      %proof     proof-root.layout
      %landing   landing-root.layout
      %conflict  conflict-root.layout
      %recovery  recovery-root.layout
      %release   release-root.layout
  ==
++  event-handle
  |=  [layout=crossing-layout:mc event=digest:mc]
  ^-  digest:mc
  (node-handle event-root.layout %event event)
++  record-body
  |=  [expected=expectation:mc candidate=envelope:mc]
  ^-  crossing-record-body:mc
  =/  layout=crossing-layout:mc  (crossing-layout expected)
  =/  kind=event-kind:mc  (kind-of:mcl payload.body.candidate)
  =/  branch=crossing-branch:mc  (branch-for payload.body.candidate)
  =/  parent-handle=(unit digest:mc)
    ?~  parent.body.candidate
      ~
    `(event-handle layout u.parent.body.candidate)
  :*  %multiplayer-collaboration-crossing-record-v1
      lane-root.layout
      project-root.layout
      task-root.layout
      branch
      (root-for layout branch)
      (event-handle layout digest.candidate)
      digest.candidate
      parent.body.candidate
      parent-handle
      sender.body.candidate
      (session-hash sender.body.candidate sender-session.body.candidate)
      recipient.body.candidate
      (session-hash recipient.body.candidate recipient-session.body.candidate)
      sequence.body.candidate
      kind
      release.body.candidate
      graf-root.body.candidate
      context-digest.body.candidate
      authority-digest.body.candidate
      (met 3 (jam body.candidate))
  ==
++  record-digest
  |=  body=crossing-record-body:mc
  ^-  digest:mc
  (commit [%multiplayer-collaboration-crossing-record-v1 body])
++  make-record
  |=  [expected=expectation:mc candidate=envelope:mc]
  ^-  crossing-record:mc
  =/  body=crossing-record-body:mc  (record-body expected candidate)
  [body (record-digest body)]
++  record-valid
  |=  $:  expected=expectation:mc
          candidate=envelope:mc
          record=crossing-record:mc
      ==
  ^-  ?
  ?&  (layout-valid expected (crossing-layout expected))
      (lte envelope-bytes.body.record max-crossing-envelope-bytes)
      (digest-valid:mcl digest.record)
      =((make-record expected candidate) record)
  ==
++  digest-text
  |=  value=digest:mc
  ^-  @t
  (crip (trip (scot %ux value)))
++  event-root-for
  |=  body=crossing-record-body:mc
  ^-  digest:mc
  (node-handle task-root.body %event ~)
++  stored-branch-root
  |=  body=crossing-record-body:mc
  ^-  digest:mc
  ?-    branch.body
      %project   project-root.body
      %task      task-root.body
      %event     (event-root-for body)
      %review    (node-handle task-root.body %review ~)
      %proof     (node-handle task-root.body %proof ~)
      %landing   (node-handle task-root.body %landing ~)
      %conflict  (node-handle task-root.body %conflict ~)
      %recovery  (node-handle task-root.body %recovery ~)
      %release   (node-handle task-root.body %release ~)
  ==
++  branch-for-kind
  |=  kind=event-kind:mc
  ^-  crossing-branch:mc
  ?-    kind
      %assignment    %task
      %progress      %event
      %review        %review
      %proof         %proof
      %acceptance    %landing
      %refusal       %conflict
      %cancellation  %recovery
      %expiry        %recovery
      %failure       %conflict
      %completion    %release
  ==
++  stored-parent-valid
  |=  body=crossing-record-body:mc
  ^-  ?
  ?~  parent-event.body
    ?=(~ parent-handle.body)
  ?~  parent-handle.body  %.n
  =((node-handle (event-root-for body) %event u.parent-event.body) u.parent-handle.body)
++  stored-record-valid
  |=  record=crossing-record:mc
  ^-  ?
  =/  body=crossing-record-body:mc  body.record
  ?&  (digest-valid:mcl digest.record)
      =((record-digest body) digest.record)
      =((commit [%multiplayer-collaboration-crossing-root-v1 graf-root.body]) lane-root.body)
      (digest-valid:mcl project-root.body)
      (digest-valid:mcl task-root.body)
      =((stored-branch-root body) branch-root.body)
      =((branch-for-kind kind.body) branch.body)
      (release-kind-valid:mcl release.body kind.body)
      =((node-handle (event-root-for body) %event event-digest.body) event-handle.body)
      (digest-valid:mcl event-digest.body)
      (stored-parent-valid body)
      (digest-valid:mcl sender-session-hash.body)
      (digest-valid:mcl recipient-session-hash.body)
      (gth sequence.body 0)
      (digest-valid:mcl graf-root.body)
      (digest-valid:mcl context-digest.body)
      (digest-valid:mcl authority-digest.body)
      (lte envelope-bytes.body max-crossing-envelope-bytes)
  ==
++  record-handle
  |=  record=crossing-record:mc
  ^-  graf-handle:graf-sur
  :*  %collaboration-crossing
      1
      (digest-text event-handle.body.record)
      (digest-text digest.record)
  ==
++  stash-record
  |=  [att=attic:graf-attic record=crossing-record:mc]
  ^-  attic:graf-attic
  ?.  (stored-record-valid record)  att
  (stash:graf-attic att crossing-family ~[record])
::
+$  crossing-decode
  [records=(list crossing-record:mc) safe=?]
++  decode-records
  |=  records=(list attic-record:graf-attic)
  ^-  crossing-decode
  ?~  records  [~ %.y]
  ?.  =(crossing-family family.i.records)  [~ %.n]
  =/  candidate=(unit crossing-record:mc)
    ((soft crossing-record:mc) value.i.records)
  ?~  candidate  [~ %.n]
  ?.  (stored-record-valid u.candidate)  [~ %.n]
  =/  rest  $(records t.records)
  [[u.candidate records.rest] safe.rest]
++  crossing-page
  |=  [att=attic:graf-attic budget=@ud]
  ^-  graf-collaboration-crossing-page:graf-sur
  ?:  (gth budget max-crossing-page-work)
    [~ 0 0 %.n %.n]
  =/  raw=attic-page:graf-attic
    (page:graf-attic att ~[crossing-family] budget)
  =/  decoded=crossing-decode  (decode-records records.raw)
  :*  records.decoded
      (lent records.decoded)
      work-count.raw
      exhausted.raw
      &(safe.raw safe.decoded)
  ==
++  crossing-count
  |=  att=attic:graf-attic
  ^-  @ud
  =/  summary  (family-summary:graf-attic att crossing-family)
  (add archived-count.summary staged-count.summary)
++  crossing-latest
  |=  att=attic:graf-attic
  ^-  (unit crossing-record:mc)
  =/  result  (crossing-page att max-crossing-page-work)
  ?~  records.result  ~
  `i.records.result
++  crossing-last-id
  |=  att=attic:graf-attic
  ^-  (unit @t)
  =/  latest  (crossing-latest att)
  ?~  latest  ~
  `(digest-text event-handle.body.u.latest)
++  find-task-record
  |=  [records=(list crossing-record:mc) task-root=digest:mc]
  ^-  (unit crossing-record:mc)
  ?~  records  ~
  ?:  =(task-root.body.i.records task-root)
    `i.records
  $(records t.records)
++  task-latest
  |=  [att=attic:graf-attic expected=expectation:mc]
  ^-  [latest=(unit crossing-record:mc) complete=?]
  =/  page  (crossing-page att max-crossing-page-work)
  ?.  &(safe.page exhausted.page)  [~ %.n]
  =/  layout  (crossing-layout expected)
  [(find-task-record records.page task-root.layout) %.y]
++  ingest-stored
  |=  $:  att=attic:graf-attic
          expected=expectation:mc
          prior=(unit envelope:mc)
          candidate=envelope:mc
          now=@da
      ==
  ^-  crossing-admission:mc
  =/  stored  (task-latest att expected)
  ?.  complete.stored
    [%refused [%invalid-prior ~]]
  ?~  latest.stored
    ?:  ?=(^ prior)
      [%refused [%invalid-prior ~]]
    (ingest expected ~ candidate now)
  ?~  prior
    ?:  =(digest.candidate event-digest.body.u.latest.stored)
      [%duplicate digest.candidate]
    [%refused [%invalid-prior ~]]
  ?.  (record-valid expected u.prior u.latest.stored)
    [%refused [%invalid-prior ~]]
  (ingest expected prior candidate now)
++  ingest
  |=  $:  expected=expectation:mc
          prior=(unit envelope:mc)
          candidate=envelope:mc
          now=@da
      ==
  ^-  crossing-admission:mc
  =/  admitted=admission:mc  (admit:mcl expected prior candidate now)
  ?-  -.admitted
    %accepted
      =/  record=crossing-record:mc  (make-record expected candidate)
      ?.  (record-valid expected candidate record)
        [%refused [%invalid-envelope ~]]
      [%record record]
    %duplicate  [%duplicate digest.admitted]
    %refused    [%refused refusal.admitted]
  ==
--
