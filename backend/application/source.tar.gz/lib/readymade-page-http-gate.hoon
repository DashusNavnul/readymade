::  Anonymous Eyre login answers are current-duct only, never path broadcasts.
::  Gall ap-ducts-from-paths (base/sys/vane/gall.hoon 1664-1669): with both
::  paths and target-ship empty the sole recipient is agent-duct. Explicit
::  paths instead select every matching subscription, regardless of ship.
|%
+$  card  card:agent:gall
++  eyre-id
  |=  id=@ta
  ^-  ?
  ?.  &((gte (met 3 id) 8) (lte (met 3 id) 64))  %.n
  :: Native Eyre759 renders the entire identifier with %ta before its path.
  =/  decoded=(unit @ta)  (slaw %ta id)
  ?~  decoded  %.n
  ?.  =(id (scot %ta u.decoded))  %.n
  =/  id=@ta  u.decoded
  ?.  =('eyre_' (end [3 5] id))  %.n
  =/  suffix=@ta  (rsh [3 5] id)
  =/  value=(unit @uv)  (slaw %uv suffix)
  ?~  value  %.n
  =(suffix (scot %uv u.value))
++  occupied
  |=  [our=@p route=path incoming=bitt:gall]
  ^-  ?
  %+  lien  ~(tap by incoming)
  |=  row=[key=duct value=[ship=@p route=path]]
  &(=(our ship.value.row) =(route route.value.row))
++  redirect
  |=  ~
  ^-  (list card)
  =/  header=[status-code=@ud headers=(list [@t @t])]
    [307 ~[['location' '/~/login?redirect=%2Fapps%2Fpataphor'] ['cache-control' 'no-store']]]
  :~  [%give %fact ~ %http-response-header !>(header)]
      [%give %fact ~ %http-response-data !>(*(unit octs))]
      [%give %kick ~ ~]
  ==
++  watch
  |=  [our=@p src=@p route=path incoming=bitt:gall]
  ^-  (unit (list card))
  ?.  ?=([%http-response @ ~] route)  ~
  ::  Existing owner-internal HTTP carriers need not have an Eyre identifier.
  ?:  =(our src)  `~
  ?.  (eyre-id i.t.route)  ~
  ?:  (occupied our route incoming)  ~
  `(redirect ~)
--
