::  Bounded traversal of the immutable Clay session-history directory.
::  The caller supplies a verified head and its actual directory map.
|%
+$  head  [desk=@tas number=@ud commit=@uv]
+$  task
  $%  [%tree entries=(map @ta ~)]
      [%entry key=@ta]
  ==
+$  page  [head=head offset=@ud next=(unit @ud) ids=(list @ux)]
++  select
  |=  [h=head entries=(map @ta ~) offset=@ud limit=@ud]
  ^-  (each page @tas)
  ?.  &((gte limit 1) (lte limit 64))  [%| %archive-page-limit-invalid]
  =/  todo=(list task)  ~[[%tree entries]]
  =/  skip=@ud  offset
  =/  left=@ud  limit
  =/  ids=(list @ux)  ~
  |-  ^-  (each page @tas)
  ?~  todo  [%& [h offset ~ (flop ids)]]
  ?-  -.i.todo
    %tree
      ?~  entries.i.todo  $(todo t.todo)
      $(todo [[%tree l.entries.i.todo] [%entry p.n.entries.i.todo] [%tree r.entries.i.todo] t.todo])
    %entry
      ?:  !=(0 skip)  $(todo t.todo, skip (dec skip))
      ?:  =(0 left)  [%& [h offset `(add offset (lent ids)) (flop ids)]]
      =/  id  (slaw %ux key.i.todo)
      ?~  id  [%| %archive-index-invalid]
      ?.  =((scot %ux u.id) key.i.todo)  [%| %archive-index-invalid]
      $(todo t.todo, left (dec left), ids [u.id ids])
  ==
--
