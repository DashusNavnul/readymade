::  Read-only identities from private native owner records. No credentials,
::  grants, model text, source bodies, authority, state or effects are added.
::  The caller authenticates the snapshot and its cross-owner joins first.
/-  nc=native-coding
/+  controller=qpc-native-controller, selected=qpc-native-selected,
    history=qpc-selected-history, measured=qpc-selected-measurement,
    decision=qpc-native-decision, admission=qpc-native-admission,
    select=qpc-select, view=qpc-measurement-view
|%
+$  snapshot
  [choices=state:controller executions=state:selected feedback=state:history]
++  hex  |=(id=@ux ^-(json [%s (scot %ux id)]))
++  revision
  |=  r=revision:nc
  ^-  json
  %-  pairs:enjs:format
  :~  ['owner' [%s (scot %p owner.r)]]
      ['desk' [%s (scot %tas desk.r)]]
      ['number' [%s (decimal:view number.r)]]
      ['commit' [%s (scot %uv commit.r)]]
      ['root' [%s (scot %uv root.r)]]
  ==
++  admitted
  |=  r=receipt:admission
  ^-  json
  %-  pairs:enjs:format
  :~  ['receiptDigest' (hex (digest:measured r))]
      ['marker' (hex id.event.request.r)]
      ['assessment' (hex assessment.r)]
      ['at' [%s (scot %da at.r)]]
      ['offers' [%a (turn offered.r |=(v=offered:decision (hex id.admission.v)))]]
  ==
++  selection
  |=  r=receipt:select
  ^-  json
  %-  pairs:enjs:format
  :~  ['selected' (hex `@ux`selected.r)]
      ['draw' [%s (decimal:view draw.r)]]
      ['gain' (numb:enjs:format gain.r)]
      ['attention' (ratio:view attention.r)]
      ['total' [%s (decimal:view total.r)]]
      ['contrast' [%b contrast.r]]
      :-  'weights'
      :-  %a
      %+  turn  weights.r
      |=  v=weighted:select
      %-  pairs:enjs:format
      :~  ['candidate' (hex `@ux`id.choice.v)]
          ['effect' (hex digest.choice.v)]
          ['energy' (ratio:view energy.choice.v)]
          ['weight' [%s (decimal:view weight.v)]]
      ==
  ==
++  execution
  |=  r=record:selected
  ^-  json
  %-  pairs:enjs:format
  :~  ['record' (hex (digest:selected r))]
      ['phase' [%s (scot %tas phase.r)]]
      ['reason' ?~(reason.r [%~] [%s (scot %tas u.reason.r)])]
      ['candidate' (hex candidate.plan.r)]
      ['effect' (hex effect.plan.r)]
      ['admissionMarker' ?~(marker.r [%~] (hex id.event.u.marker.r))]
      :-  'mapping'
      ?~  mapping.r  [%~]
      =/  m=mapping:decision  u.mapping.r
      %-  pairs:enjs:format
      :~  ['id' (hex id.m)]
          ['decision' (hex decision.m)]
          ['pool' (hex pool.m)]
          ['candidate' (hex candidate.m)]
          ['effect' (hex effect.m)]
          ['admission' (hex id.admission.m)]
          ['tool' (hex tool.m)]
          ['request' (hex request.context.request.m)]
      ==
  ==
++  outcome
  |=  [id=@ux r=receipt:measured]
  ^-  json
  %-  pairs:enjs:format
  :~  ['enrollment' (hex id)]
      ['receipt' (hex id.r)]
      ['status' [%s (scot %tas status.r)]]
      ['reservation' (hex reservation.r)]
      ['frame' (hex frame.r)]
      ['call' [%s call.r]]
      ['controller' (hex controller.r)]
      ['execution' (hex selected.r)]
      ['assessment' (hex assessment.r)]
      ['mapping' (hex mapping.r)]
      ['release' (hex release.r)]
      ['acceptance' (hex acceptance.r)]
      ['independentDecision' (hex decision.r)]
      ['at' [%s (scot %da at.r)]]
      ['predictionSource' (revision prediction.r)]
      ['resultingSource' (revision resulting.r)]
  ==
++  record
  |=  [s=snapshot id=@ux c=record:controller]
  ^-  json
  =/  d=state:decision  decision.c
  =/  fingerprint=@ux  (digest:selected c)
  =/  e=(unit record:selected)  (~(get by records.executions.s) id.d)
  =/  outcomes=(list [@ux receipt:measured])
    %+  skim  ~(tap by receipts.feedback.s)
    |=  [id=@ux r=receipt:measured]
    =(controller.r fingerprint)
  %-  pairs:enjs:format
  :~  ['collection' (hex id)]
      ['decision' (hex id.d)]
      ['controller' (hex fingerprint)]
      ['instrument' (hex instrument.binding.law.frozen.d)]
      ['stream' (hex session.binding.law.frozen.d)]
      ['law' (hex id.law.frozen.d)]
      ['epoch' (hex epoch.binding.core.d)]
      ['source' (revision source.frozen.d)]
      ['pool' ?~(pool.d [%~] (hex id.u.pool.d))]
      ['phase' [%s (scot %tas phase.c)]]
      ['reason' ?~(reason.c [%~] [%s (scot %tas u.reason.c)])]
      ['admission' ?~(admission.c [%~] (admitted u.admission.c))]
      :-  'draw'
      ?~  attempt.c  [%~]
      =/  a=attempt:controller  u.attempt.c
      (pairs:enjs:format ~[['event' (hex id.event.a)] ['at' [%s (scot %da at.event.a)]] ['value' [%s (decimal:view draw.a)]]])
      ['selection' ?~(selection.core.d [%~] (selection u.selection.core.d))]
      ['execution' ?~(e [%~] (execution u.e))]
      ['outcomes' [%a (turn outcomes outcome)]]
  ==
++  render
  ::  Missing or inconsistent canonical state is supplied as null by +view.
  |=  s=(unit snapshot)
  ^-  json
  %-  pairs:enjs:format
  :~  ['schema' [%s 'qpc-native-evidence-view-v1']]
      ['status' [%s ?~(s 'unavailable' 'available')]]
      ['meaning' [%s 'Retained native records. A draw or sent mapping does not establish application; outcomes require the independent receipt join.']]
      ['records' [%a ?~(s ~ (turn ~(tap by records.choices.u.s) |=([id=@ux c=record:controller] (record u.s id c))))]]
  ==
--
