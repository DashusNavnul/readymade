::  Independent named-check adjudication, never a selection or permission.
::  The owner must supply its prospectively retained work and canonical
::  Cantrip acceptance record. A caller-created noun cannot establish either.
/-  nc=native-coding, np=native-coding-provider
/+  obs=qpc-observation, accept=native-coding-accept,
    project=native-coding-project, sessions=native-coding-session,
    pool=qpc-native-pool, tools=cantrip-native-coding-contract,
    codec=native-coding-tool-codec, report=qpc-report
|%
+$  case  [proposition=@tas target=build-target:nc check=@tas]
+$  cases  [%qpc-hoon-cases-v1 rows=(list case)]
+$  assessment
  [proposition=@tas verdict=?(%pass %fail %unknown) reason=@tas diagnostic=@ux]
+$  receipt
  $:  %qpc-native-outcome-v1  work=@ux  candidate=@ux  acceptance=@ux
      report=@ux  prediction=revision:nc  checked=revision:nc
      outcomes=(list assessment)
  ==
+$  linked
  $:  %qpc-linked-outcome-v1  frame=@ux  call=@t  confidence=(list @ud)
      model-record=@ux  tool-record=@ux  result=receipt
  ==
++  digest
  |=  value=*
  ^-  @ux
  (shax (jam [%qpc-native-outcome-v1 value]))
++  cases-valid
  |=  [m=manifest:obs w=work:obs p=project:nc cs=cases]
  ^-  ?
  ?&  (work-valid:obs m w)  =(case-set.w (digest cs))
      =(configuration.w (configuration:project p))
      =(project.m id.spec.p)  =(owner.m authority.spec.p)
      =((turn propositions.m |=(v=proposition:obs id.v)) (turn rows.cs |=(v=case proposition.v)))
      (lte (met 3 (jam cs)) 32.768)
      %+  levy  rows.cs
      |=  v=case
      ?&  =(%hoon kind.target.v)  !=(%compile check.v)
          (lien targets.p |=(t=build-target:nc =(t target.v)))
          =(1 (lent (skim checks.target.v |=([name=@tas expression=@t] =(name check.v)))))
          =((lent checks.target.v) ~(wyt in (silt (turn checks.target.v |=([name=@tas expression=@t] name)))))
          !(lien checks.target.v |=([name=@tas expression=@t] =(%compile name)))
      ==
  ==
++  assess
  ::  Artifact shape is specific to native-coding-tools/candidate-target.
  ::  A returned noun has [compiled-hash result-hash]; an evaluation error
  ::  has only compiled-hash. No parsing of diagnostic English occurs here.
  |=  [v=case source=revision:nc t=target-result:accept]
  ^-  (each assessment @tas)
  ?.  &(=(%hoon kind.target.v) =(target.v target.t))
    [%| %qpc-outcome-target-mismatch]
  =/  names=(list @tas)
    [%compile (turn checks.target.v |=([name=@tas expression=@t] name))]
  ?.  ?&  =(names (turn diagnostics.t |=(d=diagnostic:nc name.d)))
          =((lent names) ~(wyt in (silt names)))
          !=(%compile check.v)  (~(has in (silt names)) check.v)
          (levy diagnostics.t |=(d=diagnostic:nc =(source source.d)))
      ==  [%| %qpc-outcome-diagnostics-mismatch]
  =/  compiled=diagnostic:nc  (snag 0 diagnostics.t)
  ?.  =(?:(passed.compiled 1 0) (lent artifacts.compiled))
    [%| %qpc-outcome-compile-artifacts]
  =/  d=diagnostic:nc
    (need (lien-find check.v diagnostics.t))
  =/  evidence=@ux  (digest [target.t d])
  ?.  passed.compiled
    ?.  &(!passed.d =(~ artifacts.d))  [%| %qpc-outcome-unbuilt-result]
    [%& [proposition.v %unknown %not-compiled evidence]]
  ?.  ?=(^ artifacts.d)  [%| %qpc-outcome-artifact-mismatch]
  ?.  =((snag 0 artifacts.compiled) i.artifacts.d)
    [%| %qpc-outcome-artifact-mismatch]
  ?:  =(1 (lent artifacts.d))
    ?:  passed.d  [%| %qpc-outcome-unexecuted-pass]
    [%& [proposition.v %unknown %no-returned-value evidence]]
  ?.  =(2 (lent artifacts.d))  [%| %qpc-outcome-result-artifacts]
  ?.  =(passed.d =((shax (jam 0)) (snag 1 `(list @ux)`artifacts.d)))
    [%| %qpc-outcome-result-disagreement]
  [%& [proposition.v ?:(passed.d %pass %fail) %returned-value evidence]]
++  lien-find
  |=  [name=@tas rows=(list diagnostic:nc)]
  ^-  (unit diagnostic:nc)
  ?~  rows  ~
  ?:  =(name name.i.rows)  `i.rows
  $(rows t.rows)
++  adjudicate
  ::  This receipt concerns a candidate's checks. It does not assert that
  ::  the candidate was selected, landed, or admitted to a tensor window.
  |=  [m=manifest:obs w=work:obs cs=cases r=record:accept]
  ^-  (each receipt @tas)
  =/  c=candidate:nc  candidate.r
  =/  ctx=context:nc
    [project.m configuration.w session.w request.w owner.m source.w]
  ?.  ?&  (cases-valid m w project.r cs)  =(ctx context.c)
          =(~ previous.c)  =(1 (lent edits.c))
          (levy edits.c |=(e=edit:nc =(artifact.w path.change.e)))
          (valid:accept (~(put by *ledger:accept) id.c r))
      ==  [%| %qpc-outcome-work-mismatch]
  =/  report  report.r
  ?~  report  [%| %qpc-outcome-report-unavailable]
  =/  rows=(list case)  rows.cs
  =/  out=(list assessment)  ~
  |-  ^-  (each receipt @tas)
  ?~  rows
    [%& [%qpc-native-outcome-v1 (digest:obs w) id.c (digest:accept r) (digest:accept u.report) source.w revision.staging.u.report (flop out)]]
  =/  found=(list target-result:accept)
    (skim targets.u.report |=(t=target-result:accept =(target.i.rows target.t)))
  ?.  =(1 (lent found))  [%| %qpc-outcome-target-unavailable]
  =/  got  (assess i.rows revision.staging.u.report (snag 0 found))
  ?:  ?=(%| -.got)  [%| p.got]
  $(rows t.rows, out [p.got out])
++  link
  ::  Inputs come from the private observation owner, native session journal
  ::  and Cantrip. This join grants no trust to a caller-supplied replacement.
  |=  [m=manifest:obs f=frame:obs cs=cases e=entry:sessions tool=record:tools r=record:accept]
  ^-  (each linked @tas)
  =/  w=work:obs  work.f
  ?.  ?&  (chain:pool e)  =(owner.m owner.f)  =(owner.m owner.session.e)
          =(session.w id.session.e)  =(id.f (digest:obs f(id 0x0)))
          (work-valid:obs m w)  ?=(%& -.result.f)
      ==  [%| %qpc-outcome-frame-invalid]
  =/  models=(list record:sessions)
    (skim records.e |=(v=record:sessions &(=(sequence.v journal.f) ?=(%model -.body.v))))
  ?.  =(1 (lent models))  [%| %qpc-outcome-model-missing]
  =/  model=record:sessions  (snag 0 models)
  ?>  ?=(%model -.body.model)
  =/  reply=public-reply:np  result.body.model
  ?.  &(=(reply.f (digest:obs reply)) =(request.w id.reply) =(at.f at.model))
    [%| %qpc-outcome-model-mismatch]
  =/  contexts=(list record:sessions)
    (skim records.e |=(v=record:sessions &(=(id.v context.f) (lth sequence.v journal.f) ?=(%context -.body.v))))
  ?.  =(1 (lent contexts))  [%| %qpc-outcome-context-missing]
  =/  context=record:sessions  (snag 0 contexts)
  ?>  ?=(%context -.body.context)
  ?.  ?&  =(source.w source.value.body.context)  =(session.w session.value.body.context)
          =(request.w request.value.body.context)  =(owner.m owner.value.body.context)
      ==  [%| %qpc-outcome-context-mismatch]
  =/  rows  (call-predictions:obs m w calls.reply text.reply)
  ?.  =(result.f rows)  [%| %qpc-outcome-predictions-mismatch]
  ?>  ?=(%& -.rows)
  =/  calls=(list call:np)
    (skim calls.reply |=(v=call:np =(call-id.request.tool id.v)))
  ?.  =(1 (lent calls))  [%| %qpc-outcome-call-missing]
  =/  ctx=context:nc
    [project.m configuration.w session.w request.w owner.m source.w]
  =/  decoded  (decode:codec ctx source.w (snag 0 calls))
  ?.  ?=(%& -.decoded)  [%| %qpc-outcome-call-invalid]
  ?.  ?&  =(p.decoded request.tool)  =(%finished stage.tool)
          =(grant.r grant.tool)  (gte at.tool at.f)
          =(`[%native-coding-tool-result-v1 ctx call-id.request.tool [%candidate candidate.r]] result.tool)
      ==  [%| %qpc-outcome-tool-mismatch]
  =/  results=(list record:sessions)
    %+  skim  records.e
    |=  v=record:sessions
    ?.  ?=(%tool -.body.v)  %.n
    &((gth sequence.v journal.f) =(`result.body.v result.tool))
  ?.  =(1 (lent results))  [%| %qpc-outcome-tool-journal-missing]
  =/  predictions=(list row:report)
    (skim p.rows |=(v=row:report =(call.v call-id.request.tool)))
  ?.  =(1 (lent predictions))  [%| %qpc-outcome-prediction-missing]
  =/  adjudicated  (adjudicate m w cs r)
  ?:  ?=(%| -.adjudicated)  [%| p.adjudicated]
  =/  prediction=row:report  (snag 0 predictions)
  =/  recorded=record:sessions  (snag 0 results)
  [%& [%qpc-linked-outcome-v1 id.f call-id.request.tool values.prediction id.model id.recorded p.adjudicated]]
--
