::  /lib/cantrip-law-window.hoon
::
::  The regime -> admissible-act -> ADVISORY WINDOW law engine -- the thing that
::  makes cantrip actually cantrip. Ported (the MACHINERY, not the 154 act-names)
::  from lib/cantrip-law.hoon. WHO READS IT (measured 2026-09-28): the landing court
::  (ted/workspace-land refuses unless %implement is admissible), the vibecoding
::  proposal and viki's decisions (admissible, never-auto and the digest), and
::  bench, which sets a seat's sandbox to write only while %implement is admissible
::  and says so in the seat's ship-truth line.  NO code reads omega, coherence,
::  zeno or theta: they are shown to the operator on the page and steer nothing.
::
::  STATUS DISCIPLINE (honest labels, per the Nick Core 1 contract):
::   - regime + admissible/blocked act-sets = COMPUTED (a real gate; proven below).
::   - omega / coherence / zeno / theta / never-auto = ADVISORY (symbolic steering)
::     EXCEPT never-auto, which is a COMPUTED hard constraint (irreversible acts).
::
|%
+$  band     ?(%low %medium %high)
+$  regime   ?(%grounding %opening %vectoring %ratification)
+$  omega    ?(%omega-1 %omega-2 %omega-3 %omega-4)
+$  act
  $?  %read  %inspect  %compare  %hypothesize  %probe  %summarize
      %inscribe  %implement  %promote  %branch  %reduce  %done
  ==
+$  bands    [focus=band goal-distance=band evidence=band drift=band rival=band]
+$  residue  [turn=@ud contraindications=@ud rivals=@ud blockers=@ud]
+$  window                                              ::  what Viki consumes
  $:  =regime                                           ::  computed
      admissible=(set act)                              ::  computed gate
      blocked=(set act)                                 ::  computed
      never-auto=(set act)                              ::  computed hard constraint
      =omega                                            ::  advisory
      coherence=band                                    ::  advisory
      zeno=band                                         ::  advisory
      theta=band                                        ::  advisory
  ==
++  all-acts
  ^-  (list act)
  ~[%read %inspect %compare %hypothesize %probe %summarize %inscribe %implement %promote %branch %reduce %done]
::  the irreversible/effectful acts: NEVER auto-execute on evidence -- they demand
::  explicit principal ratification regardless of regime. The fast/slow boundary.
++  never-auto-acts  ^-((set act) (~(gas in *(set act)) ~[%implement %promote]))
++  requires-ratification  |=(a=act (~(has in never-auto-acts) a))
::  COMPUTED: derive the regime from sensor bands + residue.
++  derive-regime
  |=  [b=bands r=residue]
  ^-  regime
  ?:  (gte contraindications.r 3)  %grounding             ::  sustained rejection -> ground
  ?:  ?=(%high drift.b)  %grounding                       ::  high drift -> ground
  ?:  ?&(?=(%high evidence.b) ?=(%low rival.b) ?=(%low goal-distance.b) =(0 rivals.r))
    %ratification                                         ::  converged -> ratify
  ?:  ?&(?|(?=(%medium evidence.b) ?=(%high evidence.b)) ?|(?=(%medium focus.b) ?=(%high focus.b)))
    %vectoring                                            ::  evidence + focus -> vector
  ?:  ?|(?=(%medium focus.b) ?=(%high focus.b))  %opening ::  some focus -> open
  %grounding
::  COMPUTED: admissible acts = all acts minus the explicit blocks. never-auto
::  (irreversible) acts are admissible ONLY in %ratification -- the converged,
::  commit-ready posture (high evidence, zero rivals, on-goal). In every other
::  regime they drop out, so `%implement in admissible` is a TRUTHFUL signal
::  that the act may auto-land: a consumer (nick-runtime, scribe) that lands on
::  admissibility alone is correct by construction, and reaching %ratification
::  demands full convergence, not merely leaving %grounding. (High drift and
::  sustained contraindications both force %grounding, so posture and act-set
::  can never disagree.) Other blocks come from sensors/residue directly.
++  admissible
  |=  [b=bands r=residue]
  ^-  (set act)
  =/  reg=regime  (derive-regime b r)
  =/  blk=(set act)  *(set act)
  =?  blk  !?=(%ratification reg)  (~(gas in blk) ~[%implement %promote])  ::  never-auto: commit only when ratified
  =?  blk  ?=(%low evidence.b)  (~(put in blk) %promote)                 ::  weak evidence
  =?  blk  (gth rivals.r 0)     (~(put in blk) %promote)                 ::  live rivals
  =?  blk  (gth blockers.r 0)   (~(gas in blk) ~[%promote %done])        ::  open blockers
  (~(gas in *(set act)) (skim all-acts |=(a=act !(~(has in blk) a))))
++  blocked-acts
  |=  [b=bands r=residue]
  ^-  (set act)
  =/  ok=(set act)  (admissible b r)
  (~(gas in *(set act)) (skim all-acts |=(a=act !(~(has in ok) a))))
::  ADVISORY steering: symbolic biases within the admissible bounds.
++  omega-for
  |=  =regime
  ^-  omega
  ?-  regime
    %grounding     %omega-1
    %opening       %omega-2
    %vectoring     %omega-3
    %ratification  %omega-4
  ==
++  coherence-for
  |=  b=bands
  ^-  band
  ?:  ?&(?=(%high evidence.b) ?=(%low drift.b))  %high
  ?:  ?|(?=(%medium evidence.b) ?=(%high focus.b) ?=(%medium focus.b))  %medium
  %low
++  zeno-for   |=(r=residue ^-(band ?:((gte turn.r 5) %high ?:((gte turn.r 3) %medium %low))))
++  theta-for  |=(r=residue ^-(band ?:((gte turn.r 5) %high ?:((gte turn.r 2) %medium %low))))
::  +restrict: the window under the operator's act law (lib/act-law): every
::  forbidden act leaves admissible and joins blocked.  Applied where every
::  reader scries the window (cantrip /x/law/window/current), so the landing
::  court, bench's seat write mode, viki and the rest obey a forbid with no
::  check of their own.  Only ever narrows: it cannot admit an act.
++  restrict
  |=  [w=window gone=(set act)]
  ^-  window
  w(admissible (~(dif in admissible.w) gone), blocked (~(uni in blocked.w) gone))
::  the whole advisory window Viki reads.
++  window-of
  |=  [b=bands r=residue]
  ^-  window
  =/  reg=regime  (derive-regime b r)
  :*  reg
      (admissible b r)
      (blocked-acts b r)
      never-auto-acts
      (omega-for reg)
      (coherence-for b)
      (zeno-for r)
      (theta-for r)
  ==
--
