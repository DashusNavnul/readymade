::  Owner observation and cancellation of frozen pending native tools.
::  No new tool admission, source mutation, or start/stop retry.
/-  nc=native-coding
/+  tools=cantrip-native-coding, guard=viki-scry-guard
|%
+$  handle-view
  [id=@ux tid=@tas phase=@tas cancel=? stop=? reason=@tas start=?(%unsent %sent %accepted %refused)]
++  scoped
  |=  [our=@p session=@ux r=tool-request:nc]
  ^-  ?
  &(=(our actor.context.r) =(our owner.source.context.r) =(session session.context.r))
++  read
  |=  [our=@p now=@da session=@ux id=@ux r=tool-request:nc]
  ^-  (each job:nc @tas)
  ?.  &((scoped our session r) =(id (key:tools r)))  [%| %job-scope-mismatch]
  ?.  (agent-live:guard our now %cantrip)  [%| %cantrip-unavailable]
  =/  found=(unit record:tools)
    .^((unit record:tools) %gx /(scot %p our)/cantrip/(scot %da now)/native-coding/job/(scot %ux id)/noun)
  ?~  found  [%| %job-not-retained]
  ?.  =(r request.u.found)  [%| %job-request-mismatch]
  [%& (public-job:tools id u.found)]
++  card
  |=  [our=@p id=@ux]
  ^-  card:agent:gall
  [%pass /native-coding/observe/(scot %ux id) %agent [our %cantrip] %poke %noun !>([%native-coding-observe-v1 id])]
++  cancel
  |=  [our=@p now=@da session=@ux id=@ux r=tool-request:nc]
  ^-  (each [text=@t cards=(list card:agent:gall)] @tas)
  ?.  (executable:tools -.arguments.r)  [%| %job-cancellation-not-executable]
  =/  observed  (read our now session id r)
  ?:  ?=(%| -.observed)  [%| p.observed]
  =/  raw=*
    .^(* %gx /(scot %p our)/cantrip/(scot %da now)/native-coding/job-handle/(scot %ux id)/noun)
  =/  parsed  ((soft (unit handle-view)) raw)
  ?~  parsed  [%| %job-handle-invalid]
  ?.  =(raw u.parsed)  [%| %job-handle-invalid]
  ?~  u.parsed  [%| %legacy-job-handle-unavailable]
  =/  e=handle-view  u.u.parsed
  ?.  =(id id.e)  [%| %job-handle-mismatch]
  ?:  |(cancel.e stop.e =(%refused start.e) ?=(?(%finished %cancelled) phase.e))
    [%& [(cat 3 (line id observed) 'Requested the retained outcome. No cancellation was repeated; the original request remains pending until its result arrives.') ~[(card our id)]]]
  :-  %&
  :-  (cat 3 (line id observed) 'Cancellation requested; the session is paused and its original request remains pending until Cantrip confirms the outcome. Earlier effects are not rolled back.')
  ~[[%pass /native-coding/cancel-tool/(scot %ux id) %agent [our %cantrip] %poke %noun !>([%native-coding-cancel-v1 id])]]
++  line
  |=  [id=@ux observed=(each job:nc @tas)]
  ^-  @t
  (rap 3 ~[(scot %ux id) ' · ' ?:(?=(%& -.observed) status.p.observed p.observed) '\0a'])
++  command
  |=  [our=@p now=@da session=@ux pending=(map @ux tool-request:nc) args=tool-args:nc]
  ^-  (each [text=@t cards=(list card:agent:gall)] @tas)
  =/  rows=(list [@ux tool-request:nc])
    (skim ~(tap by pending) |=([id=@ux r=tool-request:nc] (scoped our session r)))
  ?:  ?=(%jobs -.args)
    ?.  &((gte limit.args 1) (lte limit.args 64) (lte cursor.args (lent rows)))
      [%| %job-page-invalid]
    =/  picked=(list [@ux tool-request:nc])  (scag limit.args (slag cursor.args rows))
    =/  text=@t
      %-  rap  :-  3
      %+  turn  picked
      |=  [id=@ux r=tool-request:nc]
      (line id (read our now session id r))
    [%& [(rap 3 ~['Pending tool jobs for this session (not complete job history):\0a' text 'Next cursor ' (scot %ud (add cursor.args (lent picked))) '\0a']) ~]]
  ?.  ?=(?(%observe %cancel) -.args)  [%| %job-control-required]
  =/  r  (~(get by pending) job.args)
  ?~  r  [%| %job-not-pending-in-session]
  ?:  ?=(%cancel -.args)  (cancel our now session job.args u.r)
  =/  observed  (read our now session job.args u.r)
  ?:  ?=(%| -.observed)  [%| p.observed]
  [%& [(cat 3 (line job.args observed) 'Requested the retained result; no tool was restarted.') ~[(card our job.args)]]]
--
