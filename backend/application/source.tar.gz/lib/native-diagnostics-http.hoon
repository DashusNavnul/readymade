::  One owner page for native health: workers, queues, reviewers, storage,
::  grants and recovery. Each finding names the exact read it came from, so a
::  failure always carries its evidence. Read-only; a source that cannot be
::  read is reported unknown with the reason, never guessed.
/+  guard=viki-scry-guard, capacity=native-capacity-http, accept=native-coding-accept
|%
+$  status  ?(%ok %attention %unknown)
+$  finding  [area=@t status=status summary=@t evidence=@t]
++  base
  |=  [our=@p now=@da app=@tas]
  ^-  path
  ~[(scot %p our) app (scot %da now)]
++  live
  |=  [our=@p now=@da app=@tas]
  ^-  ?
  (agent-live:guard our now app)
++  num  |=(n=@ud (crip (a-co:co n)))
++  hosted
  ::  A hosted agent's brain-shell: a fault means its newest code was refused
  ::  and the previous build is still running.
  |=  [our=@p now=@da app=@tas]
  ^-  finding
  =/  area=@t  (cat 3 'Hosted agent ' app)
  =/  evidence=@t  (rap 3 ~['/gx/' app '/brain-shell/status/noun'])
  ?.  (live our now app)  [area %attention 'Not running.' evidence]
  =/  got  ((soft ,[rev=@ud loaded=? fault=(unit [at=@da why=@tas *])]) .^(* %gx (weld (base our now app) /brain-shell/status/noun)))
  ?~  got  [area %unknown 'Status unreadable.' evidence]
  ?^  fault.u.got
    [area %attention (rap 3 ~['Newest build refused (' (scot %tas why.u.fault.u.got) '); build ' (num rev.u.got) ' still running.']) evidence]
  ?.  loaded.u.got  [area %attention 'Not loaded.' evidence]
  [area %ok (rap 3 ~['Build ' (num rev.u.got) ' running.']) evidence]
++  jobs
  |=  [our=@p now=@da]
  ^-  finding
  =/  area=@t  'Native jobs'
  =/  evidence=@t  '/gx/cantrip/native-coding/reconciliation/noun'
  ?.  (live our now %cantrip)  [area %unknown 'Cantrip not running.' evidence]
  =/  got  ((soft ,[phases=(map @tas @ud) revoked-live=(list @ux) unknown=(list @ux)]) .^(* %gx (weld (base our now %cantrip) /native-coding/reconciliation/noun)))
  ?~  got  [area %unknown 'Reconciliation unreadable.' evidence]
  =/  running=@ud  (roll (turn `(list @tas)`~[%watching %starting %running %stopping] |=(p=@tas (~(gut by phases.u.got) p 0))) add)
  =/  summary=@t
    (rap 3 ~[(num running) ' running, ' (num (lent unknown.u.got)) ' unknown, ' (num (lent revoked-live.u.got)) ' still live under a revoked grant.'])
  [area ?:(|(?=(^ unknown.u.got) ?=(^ revoked-live.u.got)) %attention %ok) summary evidence]
++  queue
  ::  Candidate checks: anything unknown waits on an owner decision.
  |=  [our=@p now=@da]
  ^-  finding
  =/  area=@t  'Candidate check queue'
  =/  evidence=@t  '/gx/cantrip/native-coding/candidate-ledger/noun'
  ?.  (live our now %cantrip)  [area %unknown 'Cantrip not running.' evidence]
  =/  held=ledger:accept
    .^(ledger:accept %gx (weld (base our now %cantrip) /native-coding/candidate-ledger/noun))
  =/  stages=(list @tas)  (turn ~(val by held) |=(r=record:accept `@tas`stage.r))
  =/  open=@ud  (lent (skim stages |=(s=@tas ?=(?(%cloning %staging %checking %review %landing) s))))
  =/  unknown=@ud  (lent (skim stages |=(s=@tas =(%unknown s))))
  :^  area  ?:((gth unknown 0) %attention %ok)
    (rap 3 ~[(num ~(wyt by held)) ' candidates, ' (num open) ' in progress, ' (num unknown) ' unknown.'])
  evidence
++  reviewer
  |=  [our=@p now=@da]
  ^-  finding
  =/  area=@t  'Model reviewer (subscription)'
  =/  evidence=@t  '/gx/cli-inference/summary/noun'
  ?.  (live our now %cli-inference)  [area %attention 'The inference agent is not running; reviews will wait.' evidence]
  =/  raw=*  .^(* %gx (weld (base our now %cli-inference) /summary/noun))
  ?:  =(0 raw)  [area %unknown 'The inference agent returned an empty summary.' evidence]
  [area %ok 'The inference agent answers. Sign-in and quota are not observed here.' evidence]
++  archives
  |=  [our=@p now=@da]
  ^-  (list finding)
  :~  =/  area=@t  'Session archive'
      =/  evidence=@t  '/gx/viki/native-coding/session-archive/status/noun'
      ?.  (live our now %viki)  [area %unknown 'Viki not running.' evidence]
      =/  got  ((soft ,[head=(unit [desk=@tas number=@ud commit=@uv]) writing=(unit *)]) .^(* %gx (weld (base our now %viki) /native-coding/session-archive/status/noun)))
      ?~  got  [area %unknown 'Status unreadable.' evidence]
      ?~  head.u.got  [area %ok 'Not configured.' evidence]
      ?^  writing.u.got  [area %attention 'An archive write is pending; recover reads it without resending.' evidence]
      [area %ok (rap 3 ~['Configured on ' desk.u.head.u.got ', revision ' (num number.u.head.u.got) '.']) evidence]
    ::
      =/  area=@t  'Suggestion archive'
      =/  evidence=@t  '/gx/cantrip/project-access/history/qualification/noun'
      ?.  (live our now %cantrip)  [area %unknown 'Cantrip not running.' evidence]
      =/  got  ((soft ,[origin=* saved=* history=(unit [head=(unit [desk=@tas number=@ud commit=@uv]) writing=(unit *)])]) .^(* %gx (weld (base our now %cantrip) /project-access/history/qualification/noun)))
      ?~  got  [area %unknown 'Qualification unreadable.' evidence]
      ?~  history.u.got  [area %attention 'Not qualified.' evidence]
      ?^  writing.u.history.u.got  [area %attention 'An archive write is pending.' evidence]
      ?~  head.u.history.u.got  [area %ok 'Not configured.' evidence]
      [area %ok (rap 3 ~['Configured on ' desk.u.head.u.history.u.got ', revision ' (num number.u.head.u.history.u.got) '.']) evidence]
    ::
      =/  area=@t  'Standing policy'
      =/  evidence=@t  '/gx/cantrip/standing-policy/current/noun'
      ?.  (live our now %cantrip)  [area %unknown 'Cantrip not running.' evidence]
      =/  got  ((soft ,(each (unit [tag=@tas version=@ud at=@da issuer=@p body=(unit *) previous=(unit @ux)]) @tas)) .^(* %gx (weld (base our now %cantrip) /standing-policy/current/noun)))
      ?~  got  [area %unknown 'Unreadable.' evidence]
      ?:  ?=(%| -.u.got)
        ?:  =(%standing-policy-store-missing p.u.got)  [area %ok 'No store yet.' evidence]
        [area %attention (cat 3 'Store refused: ' (scot %tas p.u.got)) evidence]
      ?~  p.u.got  [area %ok 'No version yet.' evidence]
      [area %ok (rap 3 ~['Version ' (num version.u.p.u.got) ?~(body.u.p.u.got ', revoked.' ', in force.')]) evidence]
  ==
++  storage
  ::  Every lifetime wall; nearly full or unreadable walls need attention.
  |=  [our=@p now=@da]
  ^-  (list finding)
  %+  turn
    :~  (receipts:capacity our now)  (sessions:capacity our now)  (openings:capacity our now)
        (completions:capacity our now)  (grants:capacity our now)  (ceilings:capacity our now)
        (invitations:capacity our now)
    ==
  |=  f=figure:capacity
  ^-  finding
  ?:  ?=(%unknown -.f)  [name.f %unknown (cat 3 'Unreadable: ' (scot %tas reason.f)) '/apps/pataphor-native/coding/capacity']
  =/  left=@ud  ?:((gth used.f limit.f) 0 (sub limit.f used.f))
  :^  name.f  ?:((lte (mul left 8) limit.f) %attention %ok)
    (rap 3 ~[(num used.f) ' of ' (num limit.f) ' used, ' (num left) ' left.' ?~(settled.f '' (rap 3 ~[' ' (num u.settled.f) ' settled still counted.']))])
  '/apps/pataphor-native/coding/capacity'
++  findings
  |=  [our=@p now=@da]
  ^-  (list finding)
  ;:  weld
    (turn `(list @tas)`~[%cantrip %viki %readymade-collab %pataphor-native-console] |=(app=@tas (hosted our now app)))
    ~[(jobs our now) (queue our now) (reviewer our now)]
    (archives our now)
    (storage our now)
  ==
++  route
  |=  [our=@p src=@p now=@da url=@t]
  ^-  (unit json)
  ?.  =('/apps/pataphor-native/coding/diagnostics' url)  ~
  ?.  =(our src)
    `(pairs:enjs:format ~[['schema' s+'native-diagnostics-v1'] ['available' b+%.n] ['error' s+'owner-required']])
  =/  rows=(list finding)  (findings our now)
  :-  ~
  %-  pairs:enjs:format
  :~  ['schema' s+'native-diagnostics-v1']  ['owner' s+(scot %p our)]  ['available' b+%.y]
      :-  'findings'
      :-  %a
      %+  turn  rows
      |=  f=finding
      (pairs:enjs:format ~[['area' s+area.f] ['status' s+status.f] ['summary' s+summary.f] ['evidence' s+evidence.f]])
  ==
--
