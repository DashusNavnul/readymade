::  Pure shared admission. No archive IO, app state or transport activation.
/-  j=cantrip-project-suggestion-journal, pa=cantrip-project-access,
    mp=multiplayer-project, mc=multiplayer-changeset, nc=native-coding
/+  access=cantrip-project-access, runtime=cantrip-project-access-runtime,
    changes=multiplayer-changeset, model=pataphor-editor-model,
    law=cantrip-law-window
|%
++  key-for
  |=  r=entry:j
  ^-  key:j
  ?:  ?=(%legacy -.r)
    [project.request.value.r peer.value.r generation.request.value.r nonce.request.value.r]
  [project.request.value.r peer.value.r generation.request.value.r nonce.request.value.r]
++  raw
  ::  Keep the v1 noun and hash exactly; do not persist the internal carrier.
  |=(r=entry:j ^-(* value.r))
++  hash
  |=(r=entry:j ^-(@ux (shax (jam (raw r)))))
++  at
  |=  r=entry:j
  ^-  @da
  ?:(?=(%legacy -.r) at.value.r at.value.r)
++  owner
  |=  r=entry:j
  ^-  @p
  ?:(?=(%legacy -.r) owner.value.r owner.value.r)
++  grant
  |=  r=entry:j
  ^-  @ux
  ?:(?=(%legacy -.r) grant.value.r grant.value.r)
++  request-for
  |=  r=entry:j
  ^-  request:j
  ?-  -.r
    %legacy  [%legacy request.value.r]
    %bundle  [%bundle request.value.r]
  ==
++  envelope
  |=  r=request:j
  ^-  request:pa
  ?:  ?=(%legacy -.r)  value.r
  [project.value.r generation.value.r nonce.value.r %suggest `parent.value.r ~ `@t`0]
++  bundle-valid
  ::  Historical structure only. Current permission is checked by replay/admit.
  |=  b=bundle:pa
  ^-  ?
  =/  r=bundle-request:pa  request.b
  ?.  ?&  (runtime-request-valid r)  (gth at.b 0)
          (lte (met 0 owner.b) 128)  (lte (met 0 peer.b) 128)
          (gth grant.b 0)  (lte (met 0 grant.b) 256)
          (gth root.parent.r 0)  (lte (met 0 root.parent.r) 256)
          (snapshot-valid:changes snapshot.parent.r)
          =(project.r project.body.snapshot.parent.r)
          (paths-valid:access ~(key by files.body.snapshot.parent.r))
          =(digest.b (bundle-digest:access owner.b peer.b grant.b r))
      ==  %.n
  =/  count=@ud  (lent changes.r)
  ?.  &((gth count 0) (lte count 8) =(count ~(wyt by sources.r)))  %.n
  =/  manifest=(list change:mc)
    %+  turn  ~(tap by sources.r)
    |=  [pax=path source=@t]
    [%modify pax (~(get by files.body.snapshot.parent.r) pax) `(shax source)]
  ?.  =(manifest changes.r)  %.n
  ?.  (levy manifest |=(c=change:mc (change-valid:changes files.body.snapshot.parent.r c)))  %.n
  =/  rows=(list [pax=path source=@t])  ~(tap by sources.r)
  =/  bytes=@ud  0
  |-  ^-  ?
  ?~  rows  %.y
  =/  size=@ud  (met 3 source.i.rows)
  ?.  &((text-valid:model source.i.rows) (lte size 32.768) (lte (add bytes size) 65.536))  %.n
  $(rows t.rows, bytes (add bytes size))
++  runtime-request-valid
  |=  r=bundle-request:pa
  ^-  ?
  (request-valid:runtime (envelope [%bundle r]))
++  entry-valid
  |=  [our=@p r=entry:j]
  ^-  ?
  &(=(our (owner r)) ?:(?=(%legacy -.r) (receipt-valid:runtime value.r) (bundle-valid value.r)))
++  count
  |=(s=journal:j ^-(@ud (add ~(wyt by legacy.s) ~(wyt by bundles.s))))
++  valid
  |=  [our=@p grants=grants:pa s=journal:j]
  ^-  ?
  ?.  &((lte (count s) 64) (valid:runtime our grants legacy.s))  %.n
  %+  levy  ~(tap by bundles.s)
  |=  [k=key:j b=bundle:pa]
  ?.  &(!(~(has by legacy.s) k) (entry-valid our [%bundle b]) =(k (key-for [%bundle b])))  %.n
  =/  g  (~(get by grants) [project.k peer.k])
  ?~  g  %.n
  ?&  (lte generation.k generation.grant.u.g)
      |((lth generation.k generation.grant.u.g) =(grant.b (digest:access grant.u.g)))
  ==
++  lookup
  ::  Call only after valid: one identity can occupy exactly one hot map.
  |=  [s=journal:j k=key:j]
  ^-  (unit entry:j)
  =/  old  (~(get by legacy.s) k)
  ?^  old  `[%legacy u.old]
  =/  bundle  (~(get by bundles.s) k)
  ?~  bundle  ~
  `[%bundle u.bundle]
++  entries
  |=  s=journal:j
  ^-  (list entry:j)
  (weld (turn ~(val by legacy.s) |=(r=receipt:pa `entry:j`[%legacy r])) (turn ~(val by bundles.s) |=(r=bundle:pa `entry:j`[%bundle r])))
++  remove
  |=  [s=journal:j k=key:j]
  ^-  journal:j
  [(~(del by legacy.s) k) (~(del by bundles.s) k)]
++  canonical
  ::  Reorder only an exact manifest: never repair missing/duplicate changes
  ::  or substitute source hashes. First admission and replay use this law.
  |=  r=request:j
  ^-  (unit request:j)
  ?:  ?=(%legacy -.r)  `r
  =/  q=bundle-request:pa  value.r
  =/  manifest=(list change:mc)
    %+  turn  ~(tap by sources.q)
    |=  [pax=path text=@t]
    [%modify pax (~(get by files.body.snapshot.parent.q) pax) `(shax text)]
  ?.  &((gth (lent manifest) 0) (lte (lent manifest) 8) =((lent manifest) (lent changes.q)))  ~
  ?.  (levy manifest |=(c=change:mc (lien changes.q |=(other=change:mc =(c other)))))  ~
  `[%bundle q(changes manifest)]
++  replay
  |=  [our=@p actor=@p now=@da p=project:mp grants=grants:pa r=request:j w=window:law scope=(unit project:nc) got=observed:j]
  ^-  observed:j
  =/  q=request:pa  (envelope r)
  ?.  (request-valid:runtime q)  [%| %request-invalid]
  =/  permitted  (authorize-scoped:access our actor now p grants q w scope)
  ?:  ?=(%| -.permitted)  [%| p.permitted]
  =/  normalized  (canonical r)
  ?~  normalized  [%| %bundle-manifest-mismatch]
  ?:  ?=(%| -.got)  got
  ?~  p.got  got
  =/  old=entry:j  u.p.got
  ?.  &((entry-valid our old) =([project.q actor generation.q nonce.q] (key-for old)))
    [%| %receipt-archive-invalid]
  ?.  &(=(u.normalized (request-for old)) =((digest:access p.permitted) (grant old)))
    [%| %nonce-conflict]
  got
++  admit
  ::  A canonical cold lookup is required even when the hot key is absent.
  ::  Neither error nor missing body behind an index can authorize insertion.
  |=  [our=@p actor=@p now=@da p=project:mp grants=grants:pa s=journal:j r=request:j b=basis:pa w=window:law scope=(unit project:nc) cold=observed:j]
  ^-  result:j
  =/  checked  (replay our actor now p grants r w scope cold)
  ?:  ?=(%| -.checked)  [%| p.checked]
  ?.  (valid our grants s)  [%| %journal-invalid]
  =/  q=request:pa  (envelope r)
  =/  hot  (lookup s [project.q actor generation.q nonce.q])
  =/  prior  (replay our actor now p grants r w scope [%& hot])
  ?:  ?=(%| -.prior)  [%| p.prior]
  ?^  hot
    ?:  &(?=(^ p.checked) !=(u.p.checked u.hot))  [%| %receipt-history-conflict]
    [%& [s u.hot]]
  ?^  p.checked  [%& [s u.p.checked]]
  ?:  (gte (count s) 64)  [%| %receipt-capacity]
  ?:  ?=(%legacy -.r)
    =/  made  (perform-scoped:access our actor now p grants legacy.s value.r b w scope)
    ?:  ?=(%| -.made)  [%| p.made]
    [%& [s(legacy next.p.made) [%legacy receipt.p.made]]]
  =/  made  (prepare-bundle:access our actor now p grants value.r b w scope)
  ?:  ?=(%| -.made)  [%| p.made]
  =/  entry=entry:j  [%bundle p.made]
  [%& [s(bundles (~(put by bundles.s) (key-for entry) p.made)) entry]]
--
