::  /lib/moon-graf-effect.hoon
::
::  Pure translation between a persisted Moon-Warden dispatch and the exact
::  idempotent Graf mutation/readback that proves it.  The Gall continuation
::  wire binds immutable routing identity plus a hash of the typed action; an
::  acknowledgement is never enough without the corresponding canonical read.
::
/-  mg=moon-grant, ga=graf-action
/+  graf-relations
|%
+$  relation  rel:graf-relations
+$  effect-spec
  $:  proposal-id=@t
      lease-id=@t
      tool=@t
      action-hash=@uv
  ==
+$  read-spec
  $%  [%fact kind=@tas id=@t expected=*]
      [%slot app=@tas expected=relation]
  ==
+$  write
  $%  [%territory fact=*]
      [%graf action=action:ga]
  ==
::  Convert a dispatching proposal back into the one stable effect intent used
::  both on initial approval and restart replay.
++  effect-of-proposal
  |=  p=moon-act-proposal:mg
  ^-  (unit effect-intent:mg)
  ?.  =(%dispatching status.p)  ~
  =/  e=effect-intent:mg
    :*  proposal-id.p  lease-id.p  grantee.p  tool.p  arg.p  arg2.p
        (rap 3 'restart-safe native Graf dispatch: ' tool.p ~)
    ==
  ?~  (write-of e)  ~
  `e
::  The adapter is deliberately narrow.  Other mutating guardian tools remain
::  unavailable until they receive their own native, provable effect surface.
++  write-of
  |=  e=effect-intent:mg
  ^-  (unit write)
  ?+  tool.e  ~
    %graf-inscribe
      =/  fact=*  [%moon-memory proposal-id.e [lease-id.e grantee.e arg.e arg2.e]]
      `[%territory fact]
    %graf-relate
      =/  kind=(unit @tas)  (slaw %tas arg2.e)
      ?~  kind  ~
      =/  rel=relation
        [[%moon-act proposal-id.e lease-id.e grantee.e] u.kind arg.e]
      `[%graf [%publish %nets rel]]
  ==
::  Canonical read required after delivery or a positive Graf poke acknowledgement.
++  read-spec-of
  |=  e=effect-intent:mg
  ^-  (unit read-spec)
  =/  w  (write-of e)
  ?~  w  ~
  ?-  -.u.w
    %territory  `[%fact %moon-memory proposal-id.e fact.u.w]
    %graf
      ?-  -.action.u.w
        %publish  `[%slot app.action.u.w r.action.u.w]
        %light          ~
        %plant          ~
        %note           ~
        %unnote         ~
        %unpublish      ~
        %propose-canon  ~
        %set-governor   ~
        %allow-ship     ~
        %attest         ~
        %contradict     ~
        %bok-bake       ~
        %grant-auto        ~
        %grant-territory   ~
        %revoke-territory  ~
      ==
  ==
::  Exact private continuation.  The action hash prevents an old or altered
::  payload from closing a proposal that merely reused the same text IDs.
++  wire-of
  |=  e=effect-intent:mg
  ^-  (unit wire)
  =/  w  (write-of e)
  ?~  w  ~
  =/  digest=@uv  (sham (jam u.w))
  `[%moon-effect %graf proposal-id.e lease-id.e tool.e (scot %uv digest) ~]
++  parse-wire
  |=  w=wire
  ^-  (unit effect-spec)
  ?.  ?=([%moon-effect %graf @ @ @ @ ~] w)  ~
  =/  digest=(unit @uv)  (slaw %uv i.t.t.t.t.t.w)
  ?~  digest  ~
  `[i.t.t.w i.t.t.t.w i.t.t.t.t.w u.digest]
++  wire-matches
  |=  [spec=effect-spec e=effect-intent:mg]
  ^-  ?
  =/  w  (write-of e)
  ?~  w  %.n
  ?&  =(proposal-id.spec proposal-id.e)
      =(lease-id.spec lease-id.e)
      =(tool.spec tool.e)
      =(action-hash.spec (sham (jam u.w)))
  ==
++  fact-present
  |=  [expected=* facts=(list *)]
  ^-  ?
  (~(has in (~(gas in *(set *)) facts)) expected)
++  relation-present
  |=  [expected=relation slot=(set relation)]
  ^-  ?
  (~(has in slot) expected)
--
