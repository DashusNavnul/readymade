::  /lib/cantrip-verdict.hoon
::
::  The five-verdict law -- accept, retry, rival, branch, reject -- and the
::  residue it moves, split out of lib/cantrip-law so an agent can run the
::  law live without building the QPC formula library the rest of that file
::  needs.  cantrip-law keeps every arm and type under its old name as an
::  alias; the proofs that cite it are unchanged.  Nothing here is advisory:
::  the admissible set and the verdict are computed from law state and residue.
::
/-  cantrip-sur=cantrip
|%
+$  continuation-latest-body
  $:  lease-id=@t
  ==
++  tas-text
  |=  val=@tas
  ^-  @t
  (scot %tas val)
++  text-has-prefix
  |=  [txt=@t prefix=@t]
  ^-  ?
  =/  txt-tape=tape  (trip txt)
  =/  pre-tape=tape  (trip prefix)
  ?:  (lth (lent txt-tape) (lent pre-tape))
    %.n
  =(pre-tape (scag (lent pre-tape) txt-tape))
++  text-list-has
  |=  [needle=@t items=(list @t)]
  ^-  ?
  %+  lien  items
  |=(item=@t =(needle item))
++  summary-has-rejection-code
  |=  [summary=@t code=@tas]
  ^-  ?
  ?|  (text-has-prefix summary (cat 3 'waterwheel-rejection-code=%' (cat 3 (tas-text code) ':')))
      (text-has-prefix summary (cat 3 'waterwheel-rejection-code=' (cat 3 (tas-text code) ':')))
  ==
++  text-list-has-rejection-code
  |=  [items=(list @t) code=@tas]
  ^-  ?
  ?|  (text-list-has (cat 3 'waterwheel-code:%' (tas-text code)) items)
      (text-list-has (cat 3 'waterwheel-code:' (tas-text code)) items)
  ==
++  waterwheel-rejection-code-from-summary
  |=  summary=@t
  ^-  waterwheel-rejection-code:cantrip-sur
  ?:  (summary-has-rejection-code summary %act-not-allowed)
    %act-not-allowed
  ?:  (summary-has-rejection-code summary %act-forbidden)
    %act-forbidden
  ?:  (summary-has-rejection-code summary %memory-ref-unbound)
    %memory-ref-unbound
  ?:  (summary-has-rejection-code summary %glyph-handle-unbound)
    %glyph-handle-unbound
  ?:  (summary-has-rejection-code summary %formula-ref-unbound)
    %formula-ref-unbound
  ?:  (summary-has-rejection-code summary %fail-closed)
    %fail-closed
  %none
++  waterwheel-rejection-code-tag
  |=  code=waterwheel-rejection-code:cantrip-sur
  ^-  @t
  (cat 3 'waterwheel-code:' (tas-text code))
++  add-waterwheel-code-to-residue
  |=  [res=law-residue:cantrip-sur code=waterwheel-rejection-code:cantrip-sur]
  ^-  law-residue:cantrip-sur
  ?:  ?=(%none code)
    res
  =/  tag=@t  (waterwheel-rejection-code-tag code)
  =/  ci=(list @t)  fired-contraindications.res
  =/  blockers=(list @t)  unresolved-blockers.res
  =?  ci  ?|(?=(%act-forbidden code) ?=(%fail-closed code))
    ?:  (text-list-has-rejection-code ci code)  ci  (snoc ci tag)
  =?  blockers  ?|(?=(%act-not-allowed code) ?=(%memory-ref-unbound code) ?=(%glyph-handle-unbound code) ?=(%formula-ref-unbound code) ?=(%fail-closed code))
    ?:  (text-list-has-rejection-code blockers code)  blockers  (snoc blockers tag)
  res(fired-contraindications ci, unresolved-blockers blockers)
++  all-act-names
  ^-  (list act-name:cantrip-sur)
  ~[%read %inspect %compare %hypothesize %probe %summarize %implement %promote %branch %reduce %done]
++  regime-admissible-acts
  |=  regime=law-regime:cantrip-sur
  ^-  (list act-name:cantrip-sur)
  all-act-names
++  sensor-blocked-acts
  |=  law=law-state:cantrip-sur
  ^-  (list act-name:cantrip-sur)
  =/  extra=(list act-name:cantrip-sur)  ~
  =?  extra  ?=(%high drift.law)
    (weld extra `(list act-name:cantrip-sur)`~[%implement %promote])
  =?  extra  ?=(%low evidence.law)
    (weld extra `(list act-name:cantrip-sur)`~[%promote])
  extra
++  compute-admissible
  |=  law=law-state:cantrip-sur
  ^-  (list act-name:cantrip-sur)
  =/  base  (regime-admissible-acts regime.law)
  =/  extra-blocked=(set act-name:cantrip-sur)
    (~(gas in *(set act-name:cantrip-sur)) (sensor-blocked-acts law))
  %+  skim  base
  |=(a=act-name:cantrip-sur !(~(has in extra-blocked) a))
++  compute-blocked
  |=  law=law-state:cantrip-sur
  ^-  (list act-name:cantrip-sur)
  =/  legal=(set act-name:cantrip-sur)
    (~(gas in *(set act-name:cantrip-sur)) (compute-admissible law))
  %+  skim  all-act-names
  |=(a=act-name:cantrip-sur !(~(has in legal) a))
++  derive-regime
  |=  $:  law=law-state:cantrip-sur
          res=law-residue:cantrip-sur
          crossing=(unit crossing-evidence:cantrip-sur)
      ==
  ^-  law-regime:cantrip-sur
  ::  Priority 0: sustained rejection forces grounding (3+ contraindications)
  ?:  (gte (lent fired-contraindications.res) 3)  %grounding
  ::  Priority 0b: crossing-pressure — disclosure says may-not-cross
  ?:  ?&(?=(^ crossing) ?!(may-cross.u.crossing))  %grounding
  ::  Priority 0c: crossing-pressure — continuity-integrity too low
  ?:  ?&(?=(^ crossing) (lth continuity-integrity.u.crossing 30))  %grounding
  ::  Priority 1: drift=high forces grounding
  ?:  ?=(%high drift.law)  %grounding
  ?:  ?&(?=(%high evidence.law) ?=(%low rival.law) ?=(%low goal-distance.law) =(0 (lent live-rivals.res)))
    %ratification
  ?:  ?&(?=(%medium evidence.law) ?=(%medium focus.law))  %vectoring
  ?:  ?&(?=(%high evidence.law) ?=(%medium focus.law))  %vectoring
  ?:  ?&(?=(%medium evidence.law) ?=(%high focus.law))  %vectoring
  ?:  ?&(?=(%high evidence.law) ?=(%high focus.law))  %vectoring
  ?:  ?|(?=(%medium focus.law) ?=(%high focus.law))  %opening
  %grounding
++  compute-full-admissible
  |=  $:  law=law-state:cantrip-sur
          res=law-residue:cantrip-sur
          crossing=(unit crossing-evidence:cantrip-sur)
          cont=(unit continuation-packet:cantrip-sur)
      ==
  ^-  (list act-name:cantrip-sur)
  ::  Use stored regime (set by set-bands/operator-clamp/operator-loosen), not re-derived
  =/  base  (compute-admissible law)
  ::  block promote when live rivals exist
  =?  base  (gth (lent live-rivals.res) 0)
    (skim base |=(a=act-name:cantrip-sur !=(a %promote)))
  ::  block promote and done when unresolved blockers exist
  =?  base  (gth (lent unresolved-blockers.res) 0)
    %+  skim  base
    |=(a=act-name:cantrip-sur ?&(!=(a %promote) !=(a %done)))
  ::  block promote when crossing integrity too low (< 50)
  =?  base  ?&(?=(^ crossing) (lth continuity-integrity.u.crossing 50))
    (skim base |=(a=act-name:cantrip-sur !=(a %promote)))
  ::  block promote and done when crossing says may-not-cross
  =?  base  ?&(?=(^ crossing) ?!(may-cross.u.crossing))
    %+  skim  base
    |=(a=act-name:cantrip-sur ?&(!=(a %promote) !=(a %done)))
  ::  block implement, promote, done when continuation consequence is refuse/defer
  =?  base  ?=(^ cont)
    =/  csq  (evaluate-continuation-consequence u.cont `law res crossing)
    ?.  ?|(?=(%refuse verdict.csq) ?=(%defer verdict.csq))
      base
    %+  skim  base
    |=(a=act-name:cantrip-sur ?&(!=(a %implement) !=(a %promote) !=(a %done)))
  base
++  compute-full-blocked
  |=  $:  law=law-state:cantrip-sur
          res=law-residue:cantrip-sur
          crossing=(unit crossing-evidence:cantrip-sur)
          cont=(unit continuation-packet:cantrip-sur)
      ==
  ^-  (list act-name:cantrip-sur)
  =/  legal=(set act-name:cantrip-sur)
    (~(gas in *(set act-name:cantrip-sur)) (compute-full-admissible law res crossing cont))
  %+  skim  all-act-names
  |=(a=act-name:cantrip-sur !(~(has in legal) a))
++  evaluate-act-verdict
  |=  $:  sub=act-submission:cantrip-sur
          law=law-state:cantrip-sur
          res=law-residue:cantrip-sur
          crossing=(unit crossing-evidence:cantrip-sur)
          cont=(unit continuation-packet:cantrip-sur)
      ==
  ^-  act-verdict-result:cantrip-sur
  ::  Use stored regime directly — operator-clamp and derive-regime already updated it
  =/  stored-regime  regime.law
  =/  admissible  (compute-full-admissible law res crossing cont)
  =/  blocked  (compute-full-blocked law res crossing cont)
  =/  new-turn  +(turn.res)
  ::  1. admissibility gate (all acts legal unless explicit blockers remove them)
  =/  legal=(set act-name:cantrip-sur)
    (~(gas in *(set act-name:cantrip-sur)) admissible)
  ?.  (~(has in legal) act.sub)
    :*  move-id.sub  act.sub  %reject
        'act not admissible under current law'
        stored-regime  admissible  blocked  new-turn
    ==
  ::  2. contraindication check — fired CIs from residue block specific acts
  =/  ci-blocked=?
    ?&  ?=(%implement act.sub)
        %+  lien  fired-contraindications.res
        |=(ci=@t =(ci 'no-implement-without-evidence'))
    ==
  ?:  ci-blocked
    :*  move-id.sub  act.sub  %reject
        'contraindication blocks this act'
        stored-regime  admissible  blocked  new-turn
    ==
  ::  2b. consecutive rejection escalation — 3+ rejections in a row force grounding acts only
  =/  streak-blocked=?
    ?&  (gte (lent fired-contraindications.res) 3)
        ?|(?=(%implement act.sub) ?=(%promote act.sub) ?=(%reduce act.sub) ?=(%done act.sub))
    ==
  ?:  streak-blocked
    :*  move-id.sub  act.sub  %reject
        'too many contraindications — escalation blocks action acts'
        stored-regime  admissible  blocked  new-turn
    ==
  ::  3. branch verdict — explicit branch act
  ?:  ?=(%branch act.sub)
    :*  move-id.sub  act.sub  %branch
        'branch path opened'
        stored-regime  admissible  blocked  new-turn
    ==
  ::  4. rival verdict — live rivals + compare/hypothesize
  ?:  ?&  ?|(?=(%compare act.sub) ?=(%hypothesize act.sub))
          ?=(%high rival.law)
          (gth (lent live-rivals.res) 0)
      ==
    :*  move-id.sub  act.sub  %rival
        'competing interpretation alive — rival preserved'
        stored-regime  admissible  blocked  new-turn
    ==
  ::  5a. retry escalation — 3+ consecutive retries force rejection
  ?:  ?&  ?|(?=(%implement act.sub) ?=(%promote act.sub) ?=(%reduce act.sub))
          ?=(%low evidence.law)
          (gte consecutive-retries.res 3)
      ==
    :*  move-id.sub  act.sub  %reject
        'retry escalation: 3+ consecutive retries force rejection'
        stored-regime  admissible  blocked  new-turn
    ==
  ::  5b. normal retry
  ?:  ?&  ?|(?=(%implement act.sub) ?=(%promote act.sub) ?=(%reduce act.sub))
          ?=(%low evidence.law)
      ==
    :*  move-id.sub  act.sub  %retry
        'evidence too low for action act — retry with stronger evidence'
        stored-regime  admissible  blocked  new-turn
    ==
  ::  6. accept
  :*  move-id.sub  act.sub  %accept
      'act admissible and accepted'
      stored-regime  admissible  blocked  new-turn
  ==
++  apply-verdict-to-residue
  |=  [verdict=act-verdict-result:cantrip-sur res=law-residue:cantrip-sur sub=act-submission:cantrip-sur]
  ^-  law-residue:cantrip-sur
  =/  new-turn  turn.verdict
  ?-    verdict.verdict
      %accept
    res(turn new-turn, last-accepted `act.sub, consecutive-retries 0)
      %reject
    =/  code=waterwheel-rejection-code:cantrip-sur
      (waterwheel-rejection-code-from-summary summary.sub)
    =/  new-ci=(list @t)
      ?:  ?=(%implement act.sub)
        (snoc fired-contraindications.res 'no-implement-without-evidence')
      fired-contraindications.res
    =/  base=law-residue:cantrip-sur
      res(turn new-turn, last-rejected `act.sub, fired-contraindications new-ci, consecutive-retries 0)
    (add-waterwheel-code-to-residue base code)
      %retry
    =/  code=waterwheel-rejection-code:cantrip-sur
      (waterwheel-rejection-code-from-summary summary.sub)
    =/  base=law-residue:cantrip-sur
      res(turn new-turn, last-rejected `act.sub, consecutive-retries +(consecutive-retries.res))
    (add-waterwheel-code-to-residue base code)
      %rival
    ::  use move-id as stable rival ref (predictable, unique per poke)
    res(turn new-turn, live-rivals (snoc live-rivals.res move-id.sub))
      %branch
    ::  use move-id as stable branch handle (predictable, unique per poke)
    res(turn new-turn, live-branches (snoc live-branches.res move-id.sub))
  ==
++  waterwheel-verdict-tightens
  |=  verdict=law-verdict:cantrip-sur
  ^-  ?
  ?.  ?=(%accept verdict)
    %.y
  %.n
++  evaluate-continuation-consequence
  |=  $:  packet=continuation-packet:cantrip-sur
          law=(unit law-state:cantrip-sur)
          res=law-residue:cantrip-sur
          crossing=(unit crossing-evidence:cantrip-sur)
      ==
  ^-  continuation-consequence:cantrip-sur
  ::  authority check: soft-parse body for lease-id presence
  =/  auth-match=?
    =/  parsed=(unit continuation-latest-body)
      ((soft continuation-latest-body) body.packet)
    ?~  parsed  %.n
    !=(lease-id.u.parsed '')
  ::  collect blocking reason tags
  =/  blk=(list @t)  ~
  =?  blk  (gth (lent unresolved-blockers.res) 0)
    (weld blk ~['unresolved-blockers-present'])
  =?  blk  (gth (lent fired-contraindications.res) 0)
    (weld blk ~['active-contraindications'])
  =?  blk  (gth (lent live-rivals.res) 0)
    (weld blk ~['live-rivals-unresolved'])
  =?  blk  (gth (lent live-branches.res) 0)
    (weld blk ~['live-branches-open'])
  =?  blk  ?=(~ law)
    (weld blk ~['no-law-set'])
  ::  incorporate crossing evidence if present
  =?  blk  ?&(?=(^ crossing) ?!(validity-passed.u.crossing))
    (weld blk ~['crossing-validity-failed'])
  =?  blk  ?&(?=(^ crossing) ?!(may-cross.u.crossing))
    (weld blk ~['crossing-blocked'])
  ::  refuse if hard residue blockers present
  ?:  (gth (lent unresolved-blockers.res) 0)
    :*  verdict=%refuse  reason='unresolved blockers prevent continuation'
        regime=%grounding  authority-match=auth-match  blockers=blk
    ==
  ?:  (gth (lent fired-contraindications.res) 0)
    :*  verdict=%refuse  reason='active contraindications block continuation'
        regime=%grounding  authority-match=auth-match  blockers=blk
    ==
  ::  refuse if crossing evidence says may-not-cross
  ?:  ?&(?=(^ crossing) ?!(may-cross.u.crossing))
    :*  verdict=%refuse  reason=crossing-reason.u.crossing
        regime=%grounding  authority-match=auth-match  blockers=blk
    ==
  ::  refuse if crossing validity failed
  ?:  ?&(?=(^ crossing) ?!(validity-passed.u.crossing))
    :*  verdict=%refuse  reason='crossing validity failed'
        regime=%grounding  authority-match=auth-match  blockers=blk
    ==
  ::  refuse if continuity-integrity too low (< 30 out of 100)
  ?:  ?&(?=(^ crossing) (lth continuity-integrity.u.crossing 30))
    :*  verdict=%refuse  reason='continuity-integrity too low'
        regime=%grounding  authority-match=auth-match  blockers=blk
    ==
  ::  defer if no law state set
  ?~  law
    :*  verdict=%defer  reason='no law state set'
        regime=%grounding  authority-match=auth-match  blockers=blk
    ==
  =/  cur-regime  regime.u.law
  ::  defer if crossing lineage not confirmed (lineage-score > 50 out of 100)
  ?:  ?&(?=(^ crossing) ?!(lineage-confirmed.u.crossing) (gth lineage-score.u.crossing 50))
    :*  verdict=%defer  reason='crossing lineage not confirmed'
        regime=cur-regime  authority-match=auth-match  blockers=blk
    ==
  ::  defer if plurality not resolved per crossing
  ?:  ?&(?=(^ crossing) ?!(plurality-resolved.u.crossing))
    :*  verdict=%defer  reason='plurality not resolved per crossing'
        regime=cur-regime  authority-match=auth-match  blockers=blk
    ==
  ::  defer if live rivals or branches unresolved
  ?:  (gth (lent live-rivals.res) 0)
    :*  verdict=%defer  reason='live rivals must resolve before continuation'
        regime=cur-regime  authority-match=auth-match  blockers=blk
    ==
  ?:  (gth (lent live-branches.res) 0)
    :*  verdict=%defer  reason='live branches must resolve before continuation'
        regime=cur-regime  authority-match=auth-match  blockers=blk
    ==
  ::  defer if regime too early for continuation
  ?:  ?=(%grounding cur-regime)
    :*  verdict=%defer  reason='grounding regime — continuation premature'
        regime=cur-regime  authority-match=auth-match  blockers=blk
    ==
  ?:  ?=(%opening cur-regime)
    :*  verdict=%defer  reason='opening regime — continuation premature'
        regime=cur-regime  authority-match=auth-match  blockers=blk
    ==
  ::  accept: vectoring or ratification with clean residue and good crossing
  :*  verdict=%accept
      reason=?:(?=(^ crossing) 'law and crossing accept continuation' 'law state accepts continuation')
      regime=cur-regime  authority-match=auth-match  blockers=blk
  ==
--
