::  Owner presentation transport. Source importer remains the write authority.
::  Caller authenticates Eyre owner before read/decode. No public snapshot input.
/-  nc=native-coding
/+  source=native-coding-source-import, runtime=native-coding-source-import-runtime,
    bootstrap=native-coding-bootstrap, guard=viki-scry-guard,
    input=native-coding-onboarding-http, terminal=native-coding-terminal,
    cr=codex-responses
|%
++  body-limit  13.631.488
++  summaries
  |=  [our=@p now=@da]
  ^-  (unit (map @ux summary:runtime))
  ?.  (agent-live:guard our now %native-coding-source-import)  ~
  `.^((map @ux summary:runtime) %gx /(scot %p our)/native-coding-source-import/(scot %da now)/status/noun)
++  entry
  |=  [our=@p now=@da id=@ux]
  ^-  (unit entry:runtime)
  .^((unit entry:runtime) %gx /(scot %p our)/native-coding-source-import/(scot %da now)/record/(scot %ux id)/noun)
++  next-id
  |=  [our=@p token=@uv held=(map @ux summary:runtime)]
  ^-  @ux
  ?:  (gte ~(wyt by held) 4)  0x0
  =/  index=@ud  0
  |-
  ?:  (gte index 8)  0x0
  =/  id=@ux  (shax (jam [%native-coding-source-import-http-v1 our token index]))
  ?:  |(=(0 id) (~(has by held) id))  $(index +(index))
  id
++  revision-json
  |=  r=revision:nc
  ^-  json
  %-  pairs:enjs:format
  :~  ['owner' s+(scot %p owner.r)]
      ['desk' s+desk.r]
      ['number' (numb:enjs:format number.r)]
      ['root' s+(scot %uv root.r)]
      ['commit' s+(scot %uv commit.r)]
  ==
++  file-json
  |=  f=file:source
  ^-  json
  %-  pairs:enjs:format
  :~  ['path' s+(spat pax.f)]
      ['mark' s+mark.f]
      ['size' (numb:enjs:format size.f)]
      ['sha256' s+(scot %ux sha256.f)]
  ==
++  row-json
  |=  [our=@p now=@da id=@ux]
  ^-  json
  =/  e  (need (entry our now id))
  =/  r=record:source  record.e
  =/  s=summary:runtime  (summarize:runtime e)
  %-  pairs:enjs:format
  :~  ['id' s+(scot %ux id)]
      ['desk' s+desk.s]
      ['release' s+(scot %ux release.s)]
      ['cursor' (numb:enjs:format cursor.s)]
      ['total' (numb:enjs:format total.s)]
      ['phase' s+phase.s]
      ['reason' s+reason.s]
      ['complete' b+complete.s]
      ['baseline' (revision-json baseline.request.r)]
      ['current' (revision-json revision.current.r)]
      ['files' a+(turn files.release.request.r file-json)]
  ==
++  choices
  |=  [our=@p now=@da held=(map @ux summary:runtime)]
  ^-  [rows=(list json) truncated=?]
  ?.  &((agent-live:guard our now %viki) (agent-live:guard our now %cantrip))  [~ %.n]
  =/  domes=cone:clay  .^(cone:clay %cx /(scot %p our)//(scot %da now)/domes)
  =/  names=(list @tas)
    %+  murn  ~(tap by domes)
    |=  [key=[ship=@p desk=@tas] value=dome:clay]
    ?.  &(=(our ship.key) (isolated:bootstrap value))  ~
    ?:  (lien ~(val by held) |=(s=summary:runtime =(desk.s desk.key)))  ~
    `desk.key
  =/  eligible=(list json)
    %+  murn  (scag 64 names)
    |=  desk=@tas
    =/  found  (available:runtime our now desk)
    ?:  ?=(%| -.found)  ~
    `(revision-json revision.p.found)
  [(scag 16 eligible) |((gth (lent names) 64) (gth (lent eligible) 16))]
++  state
  |=  [our=@p now=@da token=@uv]
  ^-  json
  =/  found  (summaries our now)
  =/  held=(map @ux summary:runtime)  ?~(found ~ u.found)
  =/  id=@ux  ?~(found 0x0 (next-id our token held))
  =/  baseline=[rows=(list json) truncated=?]
    ?~  found  [~ %.n]
    (choices our now held)
  =/  rows=(list json)
    (turn ~(tap by held) |=([id=@ux s=summary:runtime] (row-json our now id)))
  %-  pairs:enjs:format
  :~  ['nonce' s+(scot %uv token)]
      ['available' b+?=(^ found)]
      ['nextId' s+?:(=(0 id) '' (scot %ux id))]
      ['capacity' (numb:enjs:format 4)]
      ['rows' a+rows]
      ['baselines' a+rows.baseline]
      ['baselinesTruncated' b+truncated.baseline]
      ['limits' (pairs:enjs:format ~[['fileBytes' (numb:enjs:format file-cap:source)] ['batchBytes' (numb:enjs:format batch-cap:source)] ['batchFiles' (numb:enjs:format 5)] ['releaseBytes' (numb:enjs:format release-cap:source)] ['releaseFiles' (numb:enjs:format 1.024)]])]
  ==
++  hex
  |=  [o=json key=@t]
  ^-  @ux
  =/  text=@t  (text:input o key 82 %.y)
  =/  n=@ux  (need (slaw %ux text))
  ?>  &(!=(0 n) (lte (met 0 n) 256) =(text (scot %ux n)))
  n
++  uv
  |=  [o=json key=@t]
  ^-  @uv
  =/  text=@t  (text:input o key 82 %.y)
  =/  n=@uv  (need (slaw %uv text))
  ?>  &(!=(0 n) (lte (met 0 n) 256) =(text (scot %uv n)))
  n
++  natural
  |=  [o=json key=@t maximum=@ud]
  ^-  @ud
  =/  n=@ud  (need (natural:cr (field:cr o key)))
  ?>  (lte n maximum)
  n
++  array
  |=  [o=json key=@t maximum=@ud]
  ^-  (list json)
  =/  value=json  (need (field:cr o key))
  ?>  ?=(%a -.value)
  ?>  &((gte (lent p.value) 1) (lte (lent p.value) maximum))
  p.value
++  metadata
  |=  o=json
  ^-  file:source
  =/  text=@t  (text:input o 'path' 2.048 %.y)
  =/  pax=path  (path-of:terminal / text)
  ?>  =(text (spat pax))
  =/  f=file:source
    [pax (name:terminal (text:input o 'mark' 16 %.y)) (natural o 'size' file-cap:source) (hex o 'sha256')]
  ?>  (file-valid:source f)
  f
++  baseline
  |=  [our=@p o=json]
  ^-  revision:nc
  ?>  =((scot %p our) (text:input o 'owner' 64 %.y))
  [our (name:terminal (text:input o 'desk' 64 %.y)) (natural o 'number' 4.294.967.295) (uv o 'root') (uv o 'commit')]
++  parse
  |=  [our=@p now=@da token=@uv o=json]
  ^-  command:runtime
  ?>  ?=(%o -.o)
  ?>  =(`(scot %uv token) (string:cr o 'nonce'))
  =/  held  (need (summaries our now))
  =/  id=@ux  (hex o 'id')
  =/  kind=@t  (text:input o 'kind' 40 %.y)
  ?:  =('source-import-observe' kind)
    ?>  (~(has by held) id)
    [%native-coding-source-import-observe-v1 id]
  ?:  =('source-import-begin' kind)
    =/  files=(list file:source)  (turn (array o 'files' 1.024) metadata)
    =/  release=release:source  [%native-coding-source-release-v1 (digest:source files) files]
    =/  r=request:source
      [%native-coding-source-import-v1 id our (baseline our (need (field:cr o 'baseline'))) release]
    ?>  (request-valid:source r)
    =/  old  (entry our now id)
    ?^  old
      ?>  =(r request.record.u.old)
      [%native-coding-source-import-begin-v1 r]
    ?>  =(id (next-id our token held))
    =/  current  (available:runtime our now desk.baseline.r)
    ?>  ?=(%& -.current)
    ?>  =(baseline.r revision.p.current)
    [%native-coding-source-import-begin-v1 r]
  ?>  =('source-import-part' kind)
  =/  e=entry:runtime  (need (entry our now id))
  =/  cursor=@ud  (natural o 'cursor' 1.024)
  =/  uploads=(list upload:source)
    %+  turn  (array o 'files' 5)
    |=  value=json
    [(metadata value) (text:input value 'source' file-cap:source %.y)]
  =/  b=batch:source  [(hex o 'release') cursor uploads]
  ?>  (batch-valid:source record.e(cursor cursor) b)
  [%native-coding-source-import-part-v1 id b]
++  decode
  |=  [our=@p now=@da token=@uv raw=@t]
  ^-  (each command:runtime @tas)
  ?.  (lte (met 3 raw) body-limit)  [%| %source-import-body-too-large]
  =/  decoded=(unit command:runtime)
    %-  mole
    |.  ^-  command:runtime
    (parse our now token (need (de:json:html raw)))
  ?~  decoded  [%| %source-import-json-refused]
  [%& u.decoded]
--
