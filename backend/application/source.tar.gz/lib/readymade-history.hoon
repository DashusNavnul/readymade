::  Bounded private transcript pages. No saved state or execution authority.
/-  pc=pataphor-chat
|%
+$  request  [before=@ud limit=@ud]
+$  text     [body=@t bytes=@ud shown=@ud truncated=?]
+$  row
  [id=@ud time=@da status=@tas request=text output=(unit text)]
+$  snapshot
  $:  %readymade-history-v1  revision=@ud  epoch=@ta
      before=@ud  limit=@ud  total=@ud  floor=@ud  active=(unit @ud)
      error=(unit text)  entries=(list row)  more=?  next-before=(unit @ud)
  ==
::  before=0 selects the head; positive cursors exclude that entry id.
++  route
  |=  pax=path
  ^-  (unit request)
  ?.  ?=([%conversation %history @ @ ~] pax)  ~
  =/  before=(unit @ud)  (slaw %ud i.t.t.pax)
  ?~  before  ~
  =/  limit=(unit @ud)  (slaw %ud i.t.t.t.pax)
  ?~  limit  ~
  ?.  &((gth u.limit 0) (lte u.limit 16))  ~
  ?.  &(=(i.t.t.pax (scot %ud u.before)) =(i.t.t.t.pax (scot %ud u.limit)))  ~
  `[u.before u.limit]
::  Do not end a valid UTF-8 prefix inside a code point.
++  prefix
  |=  [body=@t cap=@ud]
  ^-  @t
  =/  n=@ud  (min cap (met 3 body))
  |-  ^-  @t
  ?:  |(=(0 n) =(n (met 3 body)))  (end [3 n] body)
  =/  byte=@ud  (cut 3 [n 1] body)
  ?:  &((gte byte 128) (lte byte 191))  $(n (dec n))
  (end [3 n] body)
++  bounded
  |=  [body=@t cap=@ud]
  ^-  text
  =/  kept=@t  (prefix body cap)
  =/  bytes=@ud  (met 3 body)
  =/  shown=@ud  (met 3 kept)
  [kept bytes shown (lth shown bytes)]
++  project-row
  |=  e=entry:pc
  ^-  row
  [id.e time.e status.e (bounded request.e 4.096) ?~(output.e ~ `(bounded u.output.e 8.192))]
++  project
  |=  [revision=@ud r=request st=state-0:pc]
  ^-  snapshot
  ?>  &((gth limit.r 0) (lte limit.r 16))
  ::  At most limit+1 entries are retained while finding the page boundary.
  =/  found=(list entry:pc)
    =/  remaining=(list entry:pc)  entries.st
    =|  rev=(list entry:pc)
    =/  room=@ud  +(limit.r)
    |-  ^-  (list entry:pc)
    ?~  remaining  (flop rev)
    ?:  =(0 room)  (flop rev)
    ?.  |(=(0 before.r) (lth id.i.remaining before.r))
      $(remaining t.remaining)
    $(remaining t.remaining, rev [i.remaining rev], room (dec room))
  =/  selected=(list entry:pc)  (scag limit.r found)
  =/  more=?  (gth (lent found) limit.r)
  =/  cursor=(unit @ud)  ?.(more ~ `id:(rear selected))
  :*  %readymade-history-v1  revision  epoch.st  before.r  limit.r
      (lent entries.st)  floor.st  active.st
      ?~(error.st ~ `(bounded u.error.st 512))
      (turn selected project-row)  more  cursor
  ==
::  Native Gall sup is bitt=(map duct [ship path]); deduplicate same-path ducts.
++  paths
  |=  [our=@p subs=bitt:gall]
  ^-  (list path)
  =/  wanted=(list path)
    %+  murn  ~(val by subs)
    |=  [who=@p pax=path]
    ^-  (unit path)
    ?.  =(our who)  ~
    ?~  (route pax)  ~
    `pax
  ~(tap in (silt wanted))
++  changed
  |=  [before=state-0:pc after=state-0:pc]
  ^-  ?
  !=([epoch.before next.before floor.before entries.before active.before error.before] [epoch.after next.after floor.after entries.after active.after error.after])
++  facts
  |=  [b=bowl:gall st=state-0:pc]
  ^-  (list card:agent:gall)
  %+  turn  (paths our.b sup.b)
  |=  pax=path
  =/  r=(unit request)  (route pax)
  ?>  ?=(^ r)
  [%give %fact ~[pax] %noun !>((project act.b u.r st))]
--
