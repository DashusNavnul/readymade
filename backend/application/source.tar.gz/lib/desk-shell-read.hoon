::  /lib/desk-shell-read
/-  ds=desk-shell
/+  dd=desk-diff
::
::  THE ONE PLACE THAT READS DESKS.  lib/desk-shell decides and stays pure;
::  this scries, and everything that needs desk contents calls it here.
::
::  It exists to pay a debt that was named when it was incurred:
::  ted/workspace-land duplicated ted/desk-shell-survey's walk, and the
::  cockpit was about to become a third copy.  Two sites for one piece of I/O
::  is the defect this codebase keeps meeting.
::
::  +changed IS THE CHEAP ONE, and the reason it can go on a page.
::
::  MEASURED: the full walk (every file in both desks) took 18.4s for
::  %pataphor against a fork of 1.483 paths.  The pruned walk answers the same
::  question in 2.1s, because `%cz` ON A DIRECTORY HASHES ITS WHOLE SUBTREE --
::  verified on live desks before being relied on:
::
::    /app  differs between %pataphor and %agent-a   (cockpit.hoon changed)
::    /mar  matches                                   (untouched)
::
::  So an unchanged directory is skipped unread, and cost tracks what CHANGED
::  rather than what EXISTS.
::
::  +changed and +changed-since now read commits through lib/desk-diff: a %cz
::  recomputes a subtree hash each time, so the pruned walk still cost seconds.
::
::  %cy BEFORE %cz, always.  %cz on a missing path bails, +mule cannot catch a
::  failed scry, and "missing on one side" is the case being looked for.
::
::  THE STATUS NAMES SAY WHAT WAS MEASURED.  A content comparison cannot tell
::  "the worker deleted it" from "base moved ahead after the fork was taken";
::  both read as `in base, not in fork`.  Hence %only-in-base rather than
::  %removed -- the shorter name blames a worker for someone else's upstream
::  commit.  Clay's %merg has the ancestry to resolve it at landing time; this
::  does not, and does not pretend to.
::
|%
+$  status  ?(%only-in-fork %only-in-base %differs)
+$  change  [pax=path what=status]
+$  exact-change
  $:  pax=path
      what=status
      before=(unit @uv)
      after=(unit @uv)
  ==
::
++  beam
  |=  [our=@p now=@da dek=@tas pax=path]
  ^-  path
  (weld ~[(scot %p our) dek (scot %da now)] pax)
::
++  private-path
  |=  [our=@p at=@da desk=@tas pax=path]
  ^-  ?
  =/  rules=[r=dict:clay w=dict:clay]
    .^([r=dict:clay w=dict:clay] %cp (beam our at desk pax))
  &(=([%white ~ ~] rul.r.rules) =([%white ~ ~] rul.w.rules))
::
::  every file at or under one node of ONE desk.  Only ever called on a
::  subtree present on a single side, so its cost is the size of the
::  difference rather than of the desk.
++  under
  |=  [our=@p now=@da dek=@tas root=path]
  ^-  (list path)
  =/  pending=(list path)  ~[root]
  =/  out=(list path)  ~
  |-  ^-  (list path)
  ?~  pending  out
  =/  here=path  i.pending
  =/  node=arch  .^(arch %cy (beam our now dek here))
  =/  kids=(list path)
    %+  turn  ~(tap by dir.node)
    |=([k=@ta *] (weld here ~[k]))
  =?  out  ?=(^ fil.node)  [here out]
  $(pending (weld kids t.pending), out out)
::
::  Read the commit map for every held file.
::  Reproduce Clay's per-file content hash from each lobe.
++  held-at
  |=  [our=@p now=@da desk=@tas]
  ^-  held:ds
  %-  ~(run by (path-map:dd our now desk (let-of:dd our now desk)))
  |=  lobe=lobe:clay
  ^-  blob:ds
  [~ `@uv`(shax (jam [[/ lobe] *@uvI]))]
::
++  changed
  |=  [our=@p now=@da base=@tas fork=@tas]
  ^-  (list change)
  (changed:dd our now base fork)
::
::  ---- WHAT A FORK CHANGED, as opposed to how it DIFFERS ----
::
::  +changed compares both sides at the same moment, so it answers "how do
::  these two desks differ NOW".  That is the wrong question for contention.
::
::  Measured 2026-08-19, first two-seat run: landing %flunky against %busboy
::  refused %contested on /app/bench/hoon, which NEITHER SEAT HAD TOUCHED --
::  flunky was claimed before that file existed, busboy while it was younger,
::  and base had moved past both.  Two stale forks, no conflict, one refusal.
::  As base advances every fork drifts, so every PAIR of forks accrues false
::  contention and multi-seat landing gets monotonically harder for reasons
::  unrelated to anything anyone did.
::
::  So this reads each side at ITS OWN case: the fork now, the base as it stood
::  when the fork was taken.  What comes back is what the WORKER did.  A claim
::  already records `at`, so the fork point is not new information -- it was
::  simply never used.
::
::  Same prune, same fail-closed reads, same three-valued status: an unchanged
::  node hash still stops the walk, and %only-in-base still means the base had
::  something at fork time that the fork does not have now -- which for THIS
::  comparison really does mean the worker removed it.
::  The case is taken ALREADY RENDERED, as the path segment it becomes.  A
::  $case union here mints a branch clay's own type cannot reach, and reading
::  it as a segment is what a beam is made of anyway: callers pass
::  (scot %da now) or (scot %ud 1) and nothing has to agree about a union.
++  beam-at
  |=  [our=@p dek=@tas cas=@ta pax=path]
  ^-  path
  (weld ~[(scot %p our) dek cas] pax)
::  every file at or under one node of one desk, read at a given case.
++  under-at
  |=  [our=@p dek=@tas cas=@ta here=path]
  ^-  (list path)
  =/  pending=(list path)  ~[here]
  =/  out=(list path)  ~
  |-  ^-  (list path)
  ?~  pending  out
  =/  at=path  i.pending
  =/  node=arch  .^(arch %cy (beam-at our dek cas at))
  =/  kids=(list path)
    %+  turn  ~(tap by dir.node)
    |=([k=@ta *] (weld at ~[k]))
  =?  out  ?=(^ fil.node)  [at out]
  $(pending (weld kids t.pending), out out)
++  changed-since
  |=  [our=@p base=@tas base-at=@ta fork=@tas fork-at=@ta]
  ^-  (list change)
  ::  no `now` here: borrow it from whichever case is a date.
  =/  now=@da
    =/  fd=(unit @da)  (slaw %da fork-at)
    ?^  fd  u.fd
    =/  bd=(unit @da)  (slaw %da base-at)
    ?^  bd  u.bd
    ~|(%changed-since-needs-a-date !!)
  ::  a date case becomes the newest aeon at or before it; a %ud case IS one.
  =/  aeon-of
    |=  [dek=@tas cas=@ta]
    ^-  @ud
    =/  dat=(unit @da)  (slaw %da cas)
    ?^  dat  (aeon-at:dd our now dek u.dat)
    =/  rev=(unit @ud)  (slaw %ud cas)
    ?^  rev  u.rev
    ~|(%changed-since-bad-case !!)
  %+  diff-maps:dd
    (path-map:dd our now base (aeon-of base base-at))
  (path-map:dd our now fork (aeon-of fork fork-at))
::
::  +held-as-of: a fork's held map, with STALENESS FOLDED AWAY.
::
::  The survey law (+judge in lib/desk-shell) asks whether each fork differs
::  from base.  It is pure and correct, and it reads "differs" on contents.
::  So it cannot tell a fork that CHANGED a path from one that merely fell
::  behind base on it -- and that is the whole false-contention bug.
::
::  This does not touch the law.  It fixes the law's INPUT: at every path the
::  fork did not change since its own claim, the fork's blob is replaced with
::  base's CURRENT blob.  +judge then sees "same as base", which is the truth
::  about what the worker did.  At every path the fork DID change, its own
::  blob stays -- and only those can contest.
::
::  `fork-at` is the claim's `at`, rendered.  The subtraction is a pruned
::  +changed-since walk, so it costs the size of the worker's edit, not of the
::  desk.
++  held-as-of
  |=  [our=@p now=@da base=@tas fork=@tas fork-at=@ta]
  ^-  held:ds
  =/  live=held:ds  (held-at our now fork)
  =/  base-now=held:ds  (held-at our now base)
  ::  what the worker actually touched, relative to where they started
  =/  mine=(set path)
    %-  silt
    %+  turn  (changed-since our base fork-at fork (scot %da now))
    |=(c=change pax.c)
  ::  everything else: look exactly like base does right now
  =/  all=(set path)  (~(uni in ~(key by live)) ~(key by base-now))
  %-  ~(gas by *held:ds)
  %+  turn  ~(tap in all)
  |=  pax=path
  ^-  [path blob:ds]
  ?:  (~(has in mine) pax)
    [pax (~(gut by live) pax ~)]
  [pax (~(gut by base-now) pax ~)]
::
::  Read a file hash only after %cy proves the file exists.  This preserves
::  the library's fail-closed rule: %cz is never used as an existence probe.
++  hash-at
  |=  [our=@p now=@da desk=@tas pax=path]
  ^-  (unit @uv)
  =/  node=arch  .^(arch %cy (beam our now desk pax))
  ?:  ?=(~ fil.node)  ~
  [~ .^(@uv %cz (beam our now desk pax))]
::
::  Enrich the pruned change set with the exact content hashes from each
::  side.  Absence remains a typed unit, not a magic hash.
++  changed-exact
  |=  [our=@p now=@da base=@tas fork=@tas]
  ^-  (list exact-change)
  %+  turn  (changed our now base fork)
  |=  row=change
  :*  pax.row
      what.row
      (hash-at our now base pax.row)
      (hash-at our now fork pax.row)
  ==
::
++  tally
  |=  [rows=(list change) w=status]
  ^-  @ud
  (lent (skim rows |=(c=change =(what.c w))))
++  tally-exact
  |=  [rows=(list exact-change) w=status]
  ^-  @ud
  (lent (skim rows |=(c=exact-change =(what.c w))))
--
