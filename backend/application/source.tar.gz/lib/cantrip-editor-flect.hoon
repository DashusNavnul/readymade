::  /lib/cantrip-editor-flect.hoon
::
::  The editor-save judge as law geometry (phase 9 of cantrip x flect).
::  The lane's act is [change basis].  Its type-law says only that the
::  act has the right shape -- which a refused save has as surely as an
::  admitted one, so the type alone can never disagree with the judge.
::  This law adds one %run gate per predicate of +judge:cantrip-editor-save,
::  at the axis of the field the predicate reads, in the judge's order,
::  with the environment [our actor at window].  A save is admitted when
::  the act fits; the first miss names the judge's own reason.  Nothing
::  here scries: the gates run in mock, so any ship recomputes them from
::  the nouns (+verify:flect-law).
::
/+  flect, flect-law, save=cantrip-editor-save, model=pataphor-editor-model,
    law=cantrip-law-window
|%
+$  act  [change=change:model basis=basis:save]
+$  env  [our=@p actor=@p at=@da w=window:law]
::  the act's type, fixed here so every receipt cites the one law
++  act-type  ^-  type  -:!>(*act)
::
::  Axes: change = 2, its owner = 10, its replacement = 47; basis = 3.
::  A gate is called with [act-noun env] and answers a loobean.
++  actor-gate
  ^-  *
  |=  [a=* e=*]
  =/  n  ;;(env e)
  =(our.n actor.n)
++  basis-gate
  ^-  *
  |=  [a=* e=*]
  (basis-valid:save basis:;;(act a))
++  compare-gate
  ^-  *
  |=  [a=* e=*]
  =/  x  ;;(act a)
  =/  n  ;;(env e)
  =/  c  (compare-change:model our.n actor.n at.n change.x current.basis.x)
  ?=(%& -.c)
++  permission-gate
  ^-  *
  |=  [a=* e=*]
  (permission:save w:;;(env e))
++  changed-gate
  ^-  *
  |=  [a=* e=*]
  =/  x  ;;(act a)
  ?.  ?=(%text -.body.current.basis.x)  %.n
  !=(replacement.change.x source.body.current.basis.x)
++  gates
  ^-  law:flect-law
  :~  [10 %run actor-gate]
      [3 %run basis-gate]
      [2 %run compare-gate]
      [47 %run permission-gate]
      [47 %run changed-gate]
  ==
++  editor-law
  ^-  law:flect-law
  (weld (law-of:flect-law act-type) gates)
++  editor-receipt
  |=  [a=act e=env]
  ^-  receipt:flect-law
  (judge-with:flect-law editor-law !>(`act`a) e)
::  +reason: the first miss, as the judge would have said it
++  reason
  |=  [r=receipt:flect-law a=act e=env]
  ^-  (unit @tas)
  ?~  misses.verdict.r  ~
  =/  d  demand.i.misses.verdict.r
  ?.  ?=(%run -.d)  `%act-ill-shaped
  ?:  =(gate.d actor-gate)  `%foreign-actor
  ?:  =(gate.d basis-gate)  `%basis-invalid
  ?:  =(gate.d permission-gate)  `%inscribe-blocked
  ?:  =(gate.d changed-gate)  `%source-unchanged
  ?:  =(gate.d compare-gate)
    =/  c  (compare-change:model our.e actor.e at.e change.a current.basis.a)
    ?:(?=(%| -.c) `p.c `%stale)
  `%unknown-gate
--
