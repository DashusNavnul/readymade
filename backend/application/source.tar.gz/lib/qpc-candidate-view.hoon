::  Read-only projection of sealed native QPC candidate pools. No eligibility,
::  energy, probability, draw or admission is computed or inferred here.
/+  gate=qpc-session-gate, pool=qpc-native-pool
|%
+$  held  [required=(set @ux) pools=(list pool:pool)]
++  read
  ::  Pools are retained by the session gate under Viki's law owner.
  |=  [inner=agent:gall b=bowl:gall]
  ^-  (unit held)
  ?.  =(our.b src.b)  ~
  =/  ag  ~(. inner b)
  =/  raw  (payload:gate (on-peek:ag /x/qpc/required-sessions))
  ?~  raw  ~
  =/  parsed  ((soft ,[%qpc-session-gate-v1 %viki required=(set @ux)]) u.raw)
  ?~  parsed  ~
  =/  ids=(list @ux)  (sort ~(tap in required.u.parsed) lth)
  =/  found=(list pool:pool)
    %+  murn  ids
    |=  id=@ux
    ^-  (unit pool:pool)
    =/  data  (payload:gate (on-peek:ag /x/qpc/pool/(scot %ux id)))
    ?~  data  ~
    =/  kept  ((soft ,(unit pool:pool)) u.data)
    ?~  kept  ~
    u.kept
  `[required.u.parsed found]
++  hex  |=(x=@ux ^-(json [%s (scot %ux x)]))
++  row
  ::  A row without a candidate is a hard refusal: Cantrip refused it, or the
  ::  journal retained a refusal Cantrip never recorded. It stays excluded.
  |=  r=row:pool
  ^-  json
  %-  pairs:enjs:format
  :~  ['call' [%s call.r]]
      ['standing' [%s ?~(candidate.r 'hard-refusal' 'candidate')]]
      ['origin' [%s (scot %tas origin.r)]]
      ['candidate' ?~(candidate.r [%~] (hex u.candidate.r))]
      ['effect' ?~(effect.r [%~] (hex u.effect.r))]
      ['eligibility' [%s ?~(candidate.r 'excluded' 'undetermined')]]
      ['energy' [%s 'undeclared']]
      ['toolLedger' (hex tool.r)]
      ['journalRecord' (hex journal.r)]
      ['resultDigest' (hex result.r)]
  ==
++  sealed
  |=  p=pool:pool
  ^-  json
  %-  pairs:enjs:format
  :~  ['pool' (hex id.p)]
      ['session' (hex session.p)]
      ['project' [%s project.p]]
      ['configuration' (hex configuration.p)]
      ['sourceDesk' [%s desk.source.p]]
      ['sourceRevision' (numb:enjs:format number.source.p)]
      ['grant' (hex grant.p)]
      ['provider' [%s provider-key.p]]
      ['request' (hex request.p)]
      ['modelRecord' (hex model-record.p)]
      ['contextRecord' (hex context-record.p)]
      ['reply' (hex reply.p)]
      ['journalHead' (hex through.p)]
      ['attestation' [%s 'Graf %attest of this pool was sent when it was sealed.']]
      ['candidates' (numb:enjs:format (lent (skim rows.p |=(r=row:pool ?=(^ candidate.r)))))]
      ['hardRefusals' (numb:enjs:format (lent (skim rows.p |=(r=row:pool ?=(~ candidate.r)))))]
      ['rows' [%a (turn rows.p row)]]
  ==
++  status
  |=  h=(unit held)
  ^-  @t
  ?~  h  'unavailable'
  ?~  pools.u.h  'none-sealed'
  'sealed'
++  render
  |=  h=(unit held)
  ^-  json
  %-  pairs:enjs:format
  :~  ['schema' [%s 'qpc-candidate-view-v1']]
      ['status' [%s (status h)]]
      ['managedSessions' ?~(h [%~] (numb:enjs:format ~(wyt in required.u.h)))]
      ['sealedPools' ?~(h [%~] (numb:enjs:format (lent pools.u.h)))]
      ['energy' [%s 'No declared energy source is admitted; probabilities are unavailable.']]
      ['selection' [%s 'No QPC draw is installed; no selection receipt exists.']]
      ['pools' [%a ?~(h ~ (turn pools.u.h sealed))]]
  ==
--
