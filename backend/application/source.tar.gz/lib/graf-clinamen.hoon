::  /lib/graf-clinamen.hoon
::
::  The pataphysical operators folded into graf's fact store.  graf-search
::  matches facts EXACTLY (holes / exact / cell); these arms handle the MISSES
::  and the EXCEPTIONS, the province of 'pataphysics.  All pure over
::  graf-substrate's append-only `store`.
::
::    clinamen  the swerve: the lit facts nearest a query that is NOT lit,
::              within a bounded structural deviation -- recall by minimal edit.
::    antinomy  the rivals: the equidistant nearest swerves, held together, not
::              collapsed to one.
::    syzygy    the alignment: the facts satisfying ALL patterns at once
::              (conjunctive recall) -- the dual of graf-search's ANY.
::    residue   the retraction: facts recall must skip while the append-only
::              store keeps them lit (passed as a (set fact) filter throughout).
::
::  Structural distance: two facts of the SAME tree shape differ by the summed
::  byte edit-distance of their disagreeing leaves; different shapes are
::  incommensurable (~).  The clinamen is the minimal such swerve from a query
::  into memory.  Nothing here writes the store or touches a live surface.
::
/+  graf-substrate, graf-search
=,  graf-substrate
|%
::  bounded Levenshtein over two atoms' bytes; ~ if the distance exceeds max.
++  atom-dist
  |=  [a=@ b=@ max=@ud]
  ^-  (unit @ud)
  =/  la=@ud  (met 3 a)
  =/  lb=@ud  (met 3 b)
  =/  gap=@ud  ?:((gth la lb) (sub la lb) (sub lb la))
  ?:  (gth gap max)  ~
  =/  ba  |=(i=@ud `@`(cut 3 [i 1] a))
  =/  bb  |=(i=@ud `@`(cut 3 [i 1] b))
  =/  prev=(list @ud)
    =/  k=@ud  0
    =|  acc=(list @ud)
    |-  ^-  (list @ud)
    ?:  (gth k lb)  (flop acc)
    $(k +(k), acc [k acc])
  =/  ii=@ud  0
  |-  ^-  (unit @ud)
  ?:  (gte ii la)
    =/  d=@ud  (snag lb prev)
    ?:  (lte d max)  `d  ~
  =/  cur=(list @ud)  ~[+(ii)]
  =/  jj=@ud  0
  =/  rowmin=@ud  +(ii)
  |-  ^-  (unit @ud)
  ?:  (gte jj lb)
    ?:  (gth rowmin max)  ~
    ^$(ii +(ii), prev (flop cur))
  =/  ins=@ud  (add (snag jj cur) 1)
  =/  del=@ud  (add (snag +(jj) prev) 1)
  =/  sub=@ud
    =/  p=@ud  (snag jj prev)
    ?:  =((ba ii) (bb jj))  p  +(p)
  =/  m=@ud  (min ins (min del sub))
  $(jj +(jj), cur [m cur], rowmin (min rowmin m))
::  structural swerve distance between two facts of the SAME shape; ~ if the
::  shapes differ or the summed distance exceeds max.
++  swerve-dist
  |=  [a=fact b=fact max=@ud]
  ^-  (unit @ud)
  ?@  a
    ?@  b  (atom-dist a b max)
    ~
  ?@  b  ~
  =/  dh  $(a -.a, b -.b)
  ?~  dh  ~
  =/  dt  $(a +.a, b +.b, max (sub max u.dh))
  ?~  dt  ~
  `(add u.dh u.dt)
::  the clinamen: lit facts nearest a query within budget k, residue-filtered,
::  exact matches excluded, sorted nearest-first (fact order breaks ties).
++  clinamen
  |=  [s=store q=fact k=@ud residue=(set fact)]
  ^-  (list [dist=@ud =fact])
  =/  cands=(list [dist=@ud =fact])
    %+  murn  (facts s)
    |=  f=fact
    ^-  (unit [@ud fact])
    ?:  (~(has in residue) f)  ~
    =/  d  (swerve-dist q f k)
    ?~  d  ~
    ?:  =(u.d 0)  ~
    `[u.d f]
  %+  sort  cands
  |=  [x=[d=@ud f=fact] y=[d=@ud f=fact]]
  ?:  !=(d.x d.y)  (lth d.x d.y)
  (dor f.x f.y)
::  the antinomy: the rivals at the minimal nonzero swerve -- memory refusing to
::  collapse equidistant near-misses to a single answer.
++  antinomy
  |=  [s=store q=fact k=@ud residue=(set fact)]
  ^-  (list fact)
  =/  cl=(list [dist=@ud =fact])  (clinamen s q k residue)
  ?:  =(0 (lent cl))  ~
  =/  best=@ud  dist:(snag 0 cl)
  %+  turn
    (skim cl |=(c=[dist=@ud =fact] =(dist.c best)))
  |=(c=[dist=@ud =fact] fact.c)
::  the syzygy: facts aligned across ALL patterns (conjunction), residue-filtered
::  -- the dual of graf-search's ANY.
++  syzygy
  |=  [s=store pats=(list pat:graf-search) residue=(set fact)]
  ^-  (set fact)
  ?:  =(0 (lent pats))  *(set fact)
  %-  ~(gas in *(set fact))
  %+  skim  (facts s)
  |=  f=fact
  ?:  (~(has in residue) f)  |
  (levy pats |=(p=pat:graf-search (match:graf-search p f)))
--
