::  /lib/a2a-judgment
::
::  THE JUDGMENT LAW FOR THE DOOR.  Which foreign tasks the ship takes up on
::  its own, which it holds for a person, which it refuses outright.  Pure:
::  facts in, verdict out; the door applies it and cantrip records the
::  transition.  Written so Viki can adopt it unchanged when judgment moves
::  there (roadmap 33-34): nothing here knows about HTTP, tokens, or state.
::
::  Also the shape of the labor: an accepted task becomes one bounded
::  model-bridge request, built the way the executor builds one, so the
::  bridge cannot tell the door's work from the fleet's.
::
/-  a=a2a, mb=model-bridge
|%
+$  verdict  ?(%accept %hold %refuse)
::  what the law is allowed to know about a submission
+$  facts
  $:  trusted=?              ::  operator marked the principal trusted
      intent-bytes=@ud       ::  size of the joined text
      ceiling=@tas           ::  cantrip's health ceiling (%full, %reduced, %closed, ...)
      live=@ud               ::  this principal's non-terminal tasks
      bridge-ready=?         ::  a model host is attached
  ==
++  max-auto-intent  `@ud`4.096
++  max-auto-live  `@ud`8
::  The order is the argument: refuse what can never run, hold what a person
::  must see, accept only what a trusted caller asked for inside every bound.
++  judge
  |=  f=facts
  ^-  verdict
  ?:  (gth intent-bytes.f max-text-bytes:a)  %refuse
  ?:  =(%closed ceiling.f)  %hold
  ?.  trusted.f  %hold
  ?.  bridge-ready.f  %hold
  ?:  (gth intent-bytes.f max-auto-intent)  %hold
  ?:  (gte live.f max-auto-live)  %hold
  %accept
++  reason-text
  |=  [v=verdict f=facts]
  ^-  @t
  ?-  v
    %accept  'accepted by the door law: trusted principal within bounds'
    %refuse  'refused by the door law: intent exceeds the text limit'
    %hold
      ?:  =(%closed ceiling.f)  'held: cantrip health ceiling is closed'
      ?.  trusted.f  'held: principal is not trusted for automatic work'
      ?.  bridge-ready.f  'held: no model host is attached'
      ?:  (gth intent-bytes.f max-auto-intent)  'held: intent too large for automatic work'
      'held: principal has too many live tasks'
  ==
::
::  ---- the labor ----
::
++  bridge-id  'a2a'
++  session-of
  |=  who=principal:a
  ^-  @t
  (cat 3 'a2a:' who)
++  spec
  |=  [port=@tas protocol=@tas]
  ^-  model-bridge-spec:mb
  :*  %1
      bridge-id
      bridge-id
      'model-unreported'
      'codex-exec-jsonl-request-v1'
      'codex-exec-jsonl-response-v1'
      [%local-session port protocol]
      no-auth:mb
  ==
++  body-json
  |=  text=@t
  ^-  @t
  %-  en:json:html
  %-  pairs:enjs:format
  :~  ['input' s+text]
      ['policy' (pairs:enjs:format ~[['maxOutputBytes' (numb:enjs:format max-text-bytes:a)] ['tools' a+~] ['source' s+'a2a']])]
  ==
++  request
  |=  [who=principal:a task-id=@t text=@t]
  ^-  model-bridge-request:mb
  =/  body=@t  (body-json text)
  :*  %1
      task-id
      (session-of who)
      ''
      body
      (crip (scow %ux (shax (jam [%a2a-context-v1 who task-id]))))
      (crip (scow %ux (shax body)))
  ==
::  the bridge's answer, as the door records it
++  outcome
  |=  ev=model-bridge-event:mb
  ^-  (unit (each @t @t))
  ?-  -.ev
    %ready      ~
    %accepted   ~
    %result     `[%& content.result.ev]
    %error      `[%| (cat 3 (cat 3 'model error ' (scot %tas code.error.ev)) (cat 3 ': ' message.error.ev))]
    %cancelled  `[%| (cat 3 'model cancelled: ' reason.cancel.ev)]
  ==
--
