::  Parent-owned source inspection transport. No Boxy vote or candidate save.
/-  nc=native-coding, ri=native-coding-review-inspection, protocol=native-coding-review
/+  accept=native-coding-accept, files=native-coding-files,
    judgment=native-coding-judgment,
    review=native-coding-review-request, law=native-coding-review-inspection,
    guard=viki-scry-guard, grants=cantrip-native-coding
|%
+$  key  [campaign=@ux moon=@p]
+$  entry
  $:  record=record:accept
      before=(map path replacement:nc)
      objective=@t
      peer=reviewer:protocol
      manifest=manifest:ri
      sent=(set @ud)
      last=(unit event:ri)
      inspected=(unit entry:ri)
      watching=?
      phase=?(%running %watching %complete %unknown %refused %cancelled)
      reason=@tas
  ==
+$  state  (map key entry)
+$  change  [state=state cards=(list card:agent:gall)]
++  source
  |=  [side=?(%before %after) pax=path body=replacement:nc]
  ^-  source:ri
  [side pax mark.body (met 3 source.body) `@ux`(page-to-lobe:clay [mark.body source.body]) (shax source.body)]
++  bodies
  |=  [r=record:accept before=(map path replacement:nc)]
  ^-  (each (list [descriptor=source:ri text=@t]) @tas)
  ?~  report.r  [%| %inspection-report-missing]
  ?.  &((valid:accept (~(put by *ledger:accept) id.candidate.r r)) =(%review stage.r) (passed:accept u.report.r) (lte (lent edits.candidate.r) 8))  [%| %inspection-candidate-invalid]
  =/  expected=(set path)
    (silt (murn edits.candidate.r |=(e=edit:nc ?~(before.change.e ~ `path.change.e))))
  ?.  =(expected ~(key by before))  [%| %inspection-before-set]
  ?.  (levy ~(val by before) |=(b=replacement:nc (text-valid:ri source.b 1.048.576)))
    [%| %inspection-before-size]
  =/  rows=(list edit:nc)  edits.candidate.r
  =/  out=(list [descriptor=source:ri text=@t])  ~
  |-  ^-  (each (list [descriptor=source:ri text=@t]) @tas)
  ?~  rows  [%& (flop out)]
  =/  e=edit:nc  i.rows
  =/  old  (~(get by before) path.change.e)
  ?.  ?~(old %.y =(before.change.e ``@ux`(page-to-lobe:clay [mark.u.old source.u.old])))
    [%| %inspection-before-lobe]
  =.  out
    ?~(old out [[(source %before path.change.e u.old) source.u.old] out])
  =.  out
    ?~(content.e out [[(source %after path.change.e u.content.e) source.u.content.e] out])
  $(rows t.rows)
++  prepare
  ::  Pure recipe; begin independently rereads these exact old/staged bytes.
  |=  [r=record:accept before=(map path replacement:nc) objective=@t]
  ^-  (each manifest:ri @tas)
  =/  inputs  (bodies r before)
  ?:  ?=(%| -.inputs)  [%| p.inputs]
  =/  rows=(list [descriptor=source:ri text=@t])  p.inputs
  =/  pages=(list page:ri)  ~
  =/  index=@ud  0
  =/  built=(each (list page:ri) @tas)
    |-  ^-  (each (list page:ri) @tas)
    ?~  rows  [%& pages]
    =/  part  (partition:law index descriptor.i.rows text.i.rows)
    ?:  ?=(%| -.part)  [%| p.part]
    =.  pages  (weld pages pages.p.part)
    ?:  (gth (lent pages) page-limit:ri)  [%| %inspection-page-capacity]
    $(rows t.rows, index +(index))
  ?:  ?=(%| -.built)  [%| p.built]
  ?>  ?=(^ report.r)
  =/  m=manifest:ri
    [%native-coding-review-inspection-manifest-v1 (artifact:judgment candidate.r u.report.r objective) id.candidate.r (digest:ri u.report.r) configuration.context.candidate.r session.context.candidate.r request.context.candidate.r source.context.candidate.r revision.staging.u.report.r objective instructions.project.r conventions.project.r (turn p.inputs |=(v=[descriptor=source:ri text=@t] descriptor.v)) p.built]
  ?.  (valid:law m)  [%| %inspection-manifest-invalid]
  [%& m]
++  canonical-sources
  |=  [r=record:accept before=(map path replacement:nc)]
  ^-  ?
  ?~  report.r  %.n
  =/  inputs  (bodies r before)
  ?:  ?=(%| -.inputs)  %.n
  %+  levy  p.inputs
  |=  v=[descriptor=source:ri text=@t]
  =/  tree=tree:nc
    ?:(=(%before side.descriptor.v) basis.candidate.r staging.u.report.r)
  =/  actual  (file:files project.r tree pax.descriptor.v)
  ?.  ?=(%& -.actual)  %.n
  &(=(mark.p.actual mark.descriptor.v) =(source.p.actual text.v))
++  page-text
  |=  [e=entry index=@ud]
  ^-  @t
  =/  p=page:ri  (snag index pages.manifest.e)
  =/  s=source:ri  (snag source.p sources.manifest.e)
  =/  text=@t
    ?:  =(%before side.s)
      =/  body=replacement:nc  (~(got by before.e) pax.s)
      source.body
    =/  edits=(list edit:nc)
      (skim edits.candidate.record.e |=(edit=edit:nc =(pax.s path.change.edit)))
    =/  found=edit:nc  (snag 0 edits)
    ?>  ?=(^ content.found)
    source.u.content.found
  (cut 3 [offset.p bytes.p] text)
++  authority
  |=  [b=bowl:gall e=entry]
  ^-  (unit @tas)
  ?.  &((agent-live:guard our.b now.b %cantrip) (agent-live:guard our.b now.b %viki))  `%inspection-authority-unavailable
  =/  current=(unit record:accept)
    .^((unit record:accept) %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/candidate/(scot %ux id.candidate.record.e)/noun)
  ?.  =(`record.e current)  `%inspection-candidate-changed
  =/  scopes=(map @t scope:protocol)
    .^((map @t scope:protocol) %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/review-scopes/noun)
  =/  scope  (~(get by scopes) id.spec.project.record.e)
  ?~  scope  `%inspection-scope-missing
  ?.  &(enabled.u.scope |(=(peer.e left.u.scope) =(peer.e right.u.scope)))
    `%inspection-scope-changed
  =/  grant=(unit scope:grants)
    .^((unit scope:grants) %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/grant/(scot %ux grant.record.e)/noun)
  ?~  grant  `%inspection-grant-missing
  ?.  ?&  ?=(~ revoked.u.grant)  (grant-valid:grants our.b grant.u.grant)
          =(grant.record.e id.grant.u.grant)  =(project.record.e project.grant.u.grant)
          =(session.context.candidate.record.e session.grant.u.grant)
          =(actor.context.candidate.record.e actor.grant.u.grant)
      ==  `%inspection-grant-changed
  ~
++  wire-for
  |=  [k=key kind=@tas]
  ^-  wire
  /native-review-inspection/(scot %ux campaign.k)/(scot %p moon.k)/[kind]
++  remote
  |=  [k=key e=entry action=action:ri]
  ^-  card:agent:gall
  [%pass (wire-for k %command) %agent [moon.k %native-coding-reviewer] %poke %noun !>(`command:ri`[%native-coding-review-inspection-v1 (digest:ri config.peer.e) generation.config.peer.e action])]
++  put
  |=  [our=@p s=state k=key e=entry cards=(list card:agent:gall)]
  ^-  change
  ::  Full source/evidence is retained in Viki; Graf gets a binding digest.
  :-  (~(put by s) k e)
  :-  [%pass (wire-for k %retain) %agent [our %graf] %poke %graf-action !>([%attest [%native-coding-review-inspection-parent-v1 k (digest:ri [peer.e (key:ri manifest.e) sent.e last.e phase.e reason.e])]])]
  cards
++  begin
  |=  [b=bowl:gall s=state campaign=@ux r=record:accept before=(map path replacement:nc) objective=@t peer=reviewer:protocol]
  ^-  (each change @tas)
  ::  Internal Viki continuation: src may be an authenticated moon callback.
  ::  Canonical scope, grant, candidate and source reads below authorize work.
  ?.  &(!=(0 campaign) =(our.b parent.config.peer) (config-valid:review ship.peer config.peer))  [%| %inspection-owner-required]
  =/  k=key  [campaign ship.peer]
  =/  old  (~(get by s) k)
  ?^  old
    ?.  &(=(record.u.old r) =(before.u.old before) =(objective.u.old objective) =(peer.u.old peer))
      [%| %inspection-campaign-reused]
    [%& (observe b s k)]
  ?:  (gte ~(wyt by s) 64)  [%| %inspection-parent-capacity]
  =/  built  (prepare r before objective)
  ?:  ?=(%| -.built)  [%| p.built]
  ?:  (lien ~(val by s) |=(e=entry &(=(ship.peer.e ship.peer) =((key:ri manifest.e) (key:ri p.built)))))
    [%| %inspection-already-retained]
  =/  e=entry  [r before objective peer p.built ~ ~ ~ %.n %running %awaiting-inspection]
  =/  denied  (authority b e)
  ?^  denied  [%| u.denied]
  ?.  (canonical-sources r before)  [%| %inspection-canonical-source-mismatch]
  [%& (put our.b s k e ~[(remote k e [%begin manifest.e])])]
++  watch
  |=  [b=bowl:gall k=key e=entry]
  ^-  (list card:agent:gall)
  =/  w=wire  (wire-for k %receipt)
  =/  pax=path  /inspection/(scot %ux (key:ri manifest.e))
  =/  held=(unit [acked=? path=path])
    (~(get by wex.b) [w moon.k %native-coding-reviewer])
  =/  card=card:agent:gall
    [%pass w %agent [moon.k %native-coding-reviewer] %watch pax]
  ?~  held  ~[card]
  ?:  &(!acked.u.held =(pax path.u.held))  ~
  ~[[%pass w %agent [moon.k %native-coding-reviewer] %leave ~] card]
++  advance
  |=  [b=bowl:gall s=state k=key e=entry]
  ^-  change
  ?~  last.e  [s ~]
  =/  event=event:ri  u.last.e
  ?:  ?=(^ inspected.e)  [s ~]
  ?:  ?=(?(%refused %cancelled) phase.event)
    (put our.b s k e(phase ?:(=(%refused phase.event) %refused %cancelled), reason reason.event) ~)
  =/  denied  (authority b e)
  ?^  denied  (put our.b s k e(phase %unknown, reason u.denied) ~)
  ?:  =(%complete phase.event)
    ?:  watching.e  [s ~]
    =/  wide=entry  e
    (put our.b s k wide(watching %.y, phase %watching, reason %awaiting-inspection-receipt) (watch b k e))
  ?.  =(%ready phase.event)  [s ~]
  =/  index=@ud  next.event
  ?:  (~(has in sent.e) index)  [s ~]
  ?.  &(=(index ~(wyt in sent.e)) (lth index (lent pages.manifest.e)))  [s ~]
  =/  text=@t  (page-text e index)
  ?.  (page-valid:law manifest.e index text)
    (put our.b s k e(phase %refused, reason %inspection-retained-page-invalid) ~)
  (put our.b s k e(sent (~(put in sent.e) index), phase %running, reason %awaiting-page-result) ~[(remote k e [%page (key:ri manifest.e) index text])])
++  receive
  |=  [b=bowl:gall s=state event=event:ri]
  ^-  change
  =/  matches=(list [key entry])
    %+  skim  ~(tap by s)
    |=  [k=key e=entry]
    &(=(src.b moon.k) =(key.event (key:ri manifest.e)) =(binding.event (digest:ri config.peer.e)) =(generation.event generation.config.peer.e))
  ?~  matches  [s ~]
  ?^  t.matches  [s ~]
  =/  found=[k=key e=entry]  i.matches
  =/  k=key  k.found
  =/  e=entry  e.found
  ?^  inspected.e  [s ~]
  ?.  (lte next.event ~(wyt in sent.e))  [s ~]
  ?.  ?~(last.e %.y (gte next.event next.u.last.e))  [s ~]
  ?:  =(%complete phase.event)
    ?.  &(=(next.event (lent pages.manifest.e)) !=(0 coverage.event))  [s ~]
    (advance b s k e(last `event))
  ?:  ?=(?(%pending %unknown) phase.event)
    ?.  (~(has in sent.e) next.event)  [s ~]
    (put our.b s k e(last `event, phase %unknown, reason reason.event) ~)
  (advance b s k e(last `event))
++  observe
  ::  Reading an unknown mutation does not resend begin or page commands.
  |=  [b=bowl:gall s=state k=key]
  ^-  change
  =/  found  (~(get by s) k)
  ?~  found  [s ~]
  =/  e=entry  u.found
  ?^  inspected.e  [s ~]
  =/  denied  (authority b e)
  ?^  denied  (put our.b s k e(phase %unknown, reason u.denied) ~)
  ?:  watching.e  [s (watch b k e)]
  [s ~[(remote k e [%observe (key:ri manifest.e)])]]
++  on-agent
  |=  [b=bowl:gall s=state w=wire sign=sign:agent:gall]
  ^-  (unit change)
  ?.  ?=([%native-review-inspection @ @ @ ~] w)  ~
  =/  campaign  (slaw %ux i.t.w)
  =/  moon  (slaw %p i.t.t.w)
  ?~  campaign  ~
  ?~  moon  ~
  =/  k=key  [u.campaign u.moon]
  =/  found  (~(get by s) k)
  ?~  found  ~
  =/  e=entry  u.found
  ?:  =(%retain i.t.t.t.w)  `[s ~]
  ?^  inspected.e  `[s ~]
  ?:  ?=(%poke-ack -.sign)
    ?~  p.sign  `[s ~]
    `(put our.b s k e(phase %unknown, reason %inspection-command-refused) ~)
  ?.  =(%receipt i.t.t.t.w)  `[s ~]
  ?:  ?=(?(%watch-ack %kick) -.sign)  `[s ~]
  ?.  &(=(%noun p.cage.sign) =(`[%& /inspection/(scot %ux (key:ri manifest.e))] (~(get by wex.b) [w moon.k %native-coding-reviewer])))  `[s ~]
  =/  parsed  ((soft entry:ri) q.q.cage.sign)
  ?~  parsed  `[s ~]
  ?.  =(q.q.cage.sign u.parsed)  `[s ~]
  ?.  &(=(config.peer.e config.u.parsed) =(manifest.e manifest.u.parsed) =(%complete phase.u.parsed) (entry-valid:law moon.k u.parsed) ?=(^ last.e))  `[s ~]
  ?>  ?=(^ last.e)
  ?.  =((coverage:law u.parsed) coverage.u.last.e)  `[s ~]
  =/  denied  (authority b e)
  ?^  denied  `(put our.b s k e(phase %unknown, reason u.denied) ~)
  =/  wide=entry  e
  `(put our.b s k wide(inspected `u.parsed, phase %complete, reason %inspection-covered-not-approved) ~[[%pass w %agent [moon.k %native-coding-reviewer] %leave ~]])
++  lookup
  |=  [s=state k=key]
  ^-  (unit entry:ri)
  =/  found  (~(get by s) k)
  ?~  found  ~
  ?:(=(%complete phase.u.found) inspected.u.found ~)
++  valid
  |=  [our=@p s=state]
  ^-  ?
  ?&  (lte ~(wyt by s) 64)
      %+  levy  ~(tap by s)
      |=  [k=key e=entry]
      =/  built  (prepare record.e before.e objective.e)
      ?.  ?=(%& -.built)  %.n
      ?&  !=(0 campaign.k)  =(moon.k ship.peer.e)
          =(our parent.config.peer.e)  (config-valid:review moon.k config.peer.e)
          =(p.built manifest.e)
          (lte ~(wyt in sent.e) (lent pages.manifest.e))
          =((silt (gulf 0 ~(wyt in sent.e))) (~(put in sent.e) ~(wyt in sent.e)))
          ?~(last.e %.y &(=(key.u.last.e (key:ri manifest.e)) =(binding.u.last.e (digest:ri config.peer.e)) =(generation.u.last.e generation.config.peer.e) (lte next.u.last.e ~(wyt in sent.e))))
          ?~(inspected.e !=(%complete phase.e) &(=(%complete phase.e) =(config.peer.e config.u.inspected.e) =(manifest.e manifest.u.inspected.e) (entry-valid:law moon.k u.inspected.e) =(%complete phase.u.inspected.e) =((lent pages.manifest.e) ~(wyt in sent.e)) ?~(last.e %.n &(=(%complete phase.u.last.e) =(coverage.u.last.e (coverage:law u.inspected.e))))))
      ==
  ==
++  reload
  |=  [b=bowl:gall s=state]
  ^-  change
  =/  keys=(list key)  ~(tap in ~(key by s))
  =/  cards=(list card:agent:gall)  ~
  |-  ^-  change
  ?~  keys  [s cards]
  =/  next  (observe b s i.keys)
  $(keys t.keys, s state.next, cards (weld cards cards.next))
--
