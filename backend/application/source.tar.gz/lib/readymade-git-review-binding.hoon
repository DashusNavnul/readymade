::  Owner-selected exact content correspondence, never origin or approval.
::  Git receipt types are a finite wire contract; no Git executable imports.
/-  nc=native-coding
/+  files=native-coding-files, law=native-coding-project,
    accept=native-coding-accept, review=native-coding-review, git=readymade-git-proposal
|%
+$  selection  selection:git
+$  leaf  leaf:git
+$  proposal  proposal:git
+$  detail
  $:  proposal=proposal  candidate=@ux  context=context:nc
      basis=revision:nc  accepted=revision:nc  checked=revision:nc
      record=@ux  report=@ux  stage=@tas  passed=?
      decision=(unit @ux)  challenge=(unit @ux)  verdict=(unit @tas)
      landed=(unit revision:nc)
      correspondence=%exact-content  origin=%unproven  authority=%none
  ==
+$  snapshot
  [%readymade-git-review-binding-v1 owner=@p selection=selection value=(unit detail) problem=(unit @tas)]
++  marker  marker:git
++  oid-valid  oid-valid:git
++  selection-valid  selection-valid:git
++  token  token:git
++  route  route:git
++  oid-text  oid-text:git
++  proposal-path  proposal-path:git
++  blob  blob:git
++  map-leaf  map-leaf:git
++  namespace  namespace:git
++  empty
  |=  [our=@p selected=selection reason=@tas]
  ^-  snapshot
  [%readymade-git-review-binding-v1 our selected ~ `reason]
++  project
  |=  [our=@p selected=selection git=proposal retained=candidate:nc e=entry:review]
  ^-  snapshot
  ?.  (selection-valid selected)  (empty our selected %selection-invalid)
  ?.  ?&  =(our owner.git)  =(repository.selected repository.git)
          =(number.selected number.git)  =(base.selected base.git)  =(head.selected head.git)
          (lte (met 3 source-repository.git) 128)
          (lte (met 3 source-ref.git) 256)  (lte (met 3 target-ref.git) 256)
      ==  (empty our selected %proposal-identity-mismatch)
  =/  c=candidate:nc  candidate.e
  ?.  ?&  =(retained c)  =(candidate.selected id.c)  =(our actor.context.c)
          =(our owner.source.context.c)  =(source.context.c revision.basis.c)
          =((candidate-digest:files c) id.c)
      ==  (empty our selected %candidate-identity-mismatch)
  ?~  observed.e  (empty our selected %native-check-unavailable)
  =/  r=record:accept  u.observed.e
  ?.  (lte (met 3 (jam r)) 1.048.576)  (empty our selected %native-record-over-limit)
  ?.  &(=(c candidate.r) (valid:accept (malt ~[[id.c r]])))
    (empty our selected %native-record-invalid)
  ?~  report.r  (empty our selected %native-check-unavailable)
  =/  report=report:accept  u.report.r
  ?.  (report-valid:accept project.r c report)  (empty our selected %native-report-invalid)
  ?.  ?~  decision.e  %.y
        &(=(report.r `report.u.decision.e) (decision-valid:accept project.r c u.decision.e))
    (empty our selected %native-decision-invalid)
  =/  before  (namespace project.r before.git)
  ?:  ?=(%| -.before)  (empty our selected p.before)
  =/  after  (namespace project.r after.git)
  ?:  ?=(%| -.after)  (empty our selected p.after)
  ?.  =(p.before files.body.snapshot.basis.c)  (empty our selected %base-namespace-mismatch)
  ?.  &(=(p.after (after-map:files c)) =(p.after files.body.snapshot.staging.report))
    (empty our selected %head-namespace-mismatch)
  =/  value=detail
    :*  git  id.c  context.c  revision.basis.c  accepted.c  revision.staging.report
        (digest:accept r)  (digest:accept report)  stage.r  (passed:accept report)
        ?~(decision.e ~ `(digest:accept u.decision.e))
        ?~(decision.e ~ `(digest:accept challenge.u.decision.e))
        ?~(decision.e ~ `verdict.u.decision.e)
        ?~(landed.r ~ `revision.u.landed.r)
        %exact-content  %unproven  %none
    ==
  [%readymade-git-review-binding-v1 our selected `value ~]
--
