::  Pure private command admission and durable page receipts. No cards sent.
/-  pc=pataphor-chat
/+  store=pataphor-chat-store, rt=pataphor-chat-runtime, h=readymade-history
|%
+$  command
  $:  %readymade-command-v1  id=@uv  nonce=@uv
      action=$%([%ask text=@t] [%new ~] [%stop-tracking ~])
  ==
+$  receipt
  $:  %readymade-receipt-v1  id=@uv  at=@da
      outcome=?(%accepted %refused)  reason=(unit @t)
      execution=(unit [epoch=@ta entry=@ud message=@ta])
  ==
+$  stored  [digest=@ux reply=receipt dispatch=(unit @t)]
+$  ledger  (map @uv stored)
+$  decision
  $%  [%replay record=stored]
      [%run command=action:pc]
      [%refuse reason=@t]
  ==
++  capacity  1.024
++  digest
  |=  cmd=command
  ^-  @ux
  `@ux`(shax (jam cmd))
++  admit
  |=  [our=@p src=@p cmd=command chat=state-0:pc receipts=ledger]
  ^-  decision
  ?.  =(our src)  [%refuse 'Only the owner ship may submit.']
  ?.  &((gth id.cmd 0) (lte (met 0 id.cmd) 128))
    [%refuse 'Submission id must be a nonzero 128-bit value.']
  ?.  (lte (met 0 nonce.cmd) 128)
    [%refuse 'Invalid submission nonce.']
  ?:  &(?=(%ask -.action.cmd) (gth (met 3 +.action.cmd) 8.192))
    [%refuse 'Submission exceeds 8192 bytes.']
  =/  known=(unit stored)  (~(get by receipts) id.cmd)
  ?^  known
    ?.  =(digest.u.known (digest cmd))
      [%refuse 'Submission id was reused with a different command.']
    [%replay u.known]
  ?.  &(!=(0 nonce.chat) =(nonce.chat nonce.cmd))
    [%refuse 'Invalid or expired form. Reload before submitting again.']
  ?:  (gte ~(wyt by receipts) capacity)
    [%refuse 'Submission receipt storage is full. Nothing was evicted.']
  [%run action.cmd]
++  refused
  |=  [now=@da cmd=command reason=@t]
  ^-  stored
  =/  clipped=text:h  (bounded:h reason 512)
  [(digest cmd) [%readymade-receipt-v1 id.cmd now %refused `body.clipped ~] ~]
++  dispatch-match
  ::  The caller supplies compiled Gall cards; their vase type is opaque.
  |=  [our=@p entry=@ud epoch=@ta prompt=@t raw=*]
  ^-  (unit @t)
  =/  sent
    ((soft ,[%pass wire=wire %agent dock=dock %poke %noun payload=[type=* value=*]]) raw)
  ?~  sent  ~
  ?.  =(wire.u.sent /private/(scot %ud entry))  ~
  ?.  =(dock.u.sent [our %a2a])  ~
  ?.  =(value.payload.u.sent [%local-send (mid:rt entry) epoch prompt])  ~
  `prompt
++  settle
  |=  [our=@p now=@da cmd=command before=state-0:pc after=state-0:pc cards=(list card:agent:gall)]
  ^-  stored
  ?.  ?=(%ask -.action.cmd)
    =/  expected=state-0:pc
      ?-  -.action.cmd
        %new  (reset:store before)
        %stop-tracking  before(pending ~, unconfirmed ~, shared-error ~)
      ==
    =/  normalized=state-0:pc
      after(nonce nonce.before, poll-at poll-at.before)
    ?.  =(expected normalized)
      (refused now cmd 'Native command changed unexpected chat state.')
    [(digest cmd) [%readymade-receipt-v1 id.cmd now %accepted ~ ~] ~]
  =/  why=@t  (fall error.after 'No matching native request dispatch was produced.')
  =/  before-count=@ud  (lent entries.before)
  ?.  ?&  (gth next.before 0)  =(epoch.before epoch.after)
          =(+(next.before) next.after)
          =(`next.before active.after)
          =(+(before-count) (lent entries.after))
          =(floor.before floor.after)
          =(connected.before connected.after)
          =(pending.before pending.after)
          =(shared-error.before shared-error.after)
          =(unconfirmed.before unconfirmed.after)
      ==  (refused now cmd why)
  ?~  entries.after  (refused now cmd why)
  ?.  ?&  =(entries.before t.entries.after)
          =(next.before id.i.entries.after)
          =(now time.i.entries.after)
          =(%submitted status.i.entries.after)
          =(~ output.i.entries.after)
          =((trim:store +.action.cmd) request.i.entries.after)
      ==  (refused now cmd why)
  =/  entry=@ud  next.before
  =/  message=@ta  (mid:rt entry)
  =/  prompt=@t  (prompt:store entry after)
  =/  matched=(list @t)
    %+  murn  cards
    |=  card=card:agent:gall
    (dispatch-match our entry epoch.after prompt card)
  ?.  =(1 (lent matched))  (refused now cmd why)
  [(digest cmd) [%readymade-receipt-v1 id.cmd now %accepted ~ `[epoch.after entry message]] `prompt]
++  remember
  |=  [receipts=ledger record=stored]
  ^-  ledger
  ?>  !(~(has by receipts) id.reply.record)
  ?>  (lth ~(wyt by receipts) capacity)
  (~(put by receipts) id.reply.record record)
++  valid-ledger
  |=  receipts=ledger
  ^-  ?
  ?.  (lte ~(wyt by receipts) capacity)  %.n
  %+  levy  ~(tap by receipts)
  |=  [key=@uv record=stored]
  ?&  (gth key 0)  (lte (met 0 key) 128)  =(key id.reply.record)
      (lte (met 0 digest.record) 256)
      ?~(reason.reply.record %.y (lte (met 3 u.reason.reply.record) 512))
      ?~(dispatch.record %.y (lte (met 3 u.dispatch.record) 4.096))
      ?:  =(%refused outcome.reply.record)
        &(=(~ execution.reply.record) =(~ dispatch.record))
      =(?=(^ execution.reply.record) ?=(^ dispatch.record))
  ==
++  restore
  |=  old=vase
  ^-  (unit [chat=state-0:pc receipts=ledger])
  =/  v2
    ((soft ,[%pataphor-page-state-v2 chat=state-0:pc receipts=ledger]) q.old)
  ?^  v2
    ?.  (valid-ledger receipts.u.v2)  ~
    `[chat.u.v2 receipts.u.v2]
  =/  v1  ((soft ,[%pataphor-page-state-v1 chat=state-0:pc]) q.old)
  ?~  v1  ~
  `[chat.u.v1 ~]
--
