::  Terminal HTTP presentation and bounded wire parsing. GLS owns decisions.
/+  session=terminal-session
|%
+$  action  [kind=@ud generation=@ud sequence=@ud data=octs rows=@ud cols=@ud]
++  number
  |=  [object=json key=@t]
  ^-  (unit @ud)
  ?.  ?=(%o -.object)  ~
  =/  found  (~(get by p.object) key)
  ?~  found  ~
  ?.  ?=(%n -.u.found)  ~
  =/  parsed  (rush p.u.found dim:ag)
  ?~  parsed  ~
  ?.  &(=(u.found (numb:enjs:format u.parsed)) (lte u.parsed 4.294.967.295))  ~
  `u.parsed
++  decode
  |=  raw=@t
  ^-  (unit action)
  =/  parsed  (de:json:html raw)
  ?~  parsed  ~
  ?.  ?=(%o -.u.parsed)  ~
  ?.  (levy ~(tap by p.u.parsed) |=([key=@t val=json] |(=('kind' key) =('generation' key) =('sequence' key) =('data' key) =('rows' key) =('cols' key) =('viewer' key) =('controlRevision' key) =('controlKey' key))))  ~
  =/  kind  (number u.parsed 'kind')
  =/  generation  (number u.parsed 'generation')
  =/  sequence  (number u.parsed 'sequence')
  ?~  kind  ~
  ?~  generation  ~
  ?~  sequence  ~
  =/  encoded  (~(get by p.u.parsed) 'data')
  =/  decoded=(unit octs)
    ?~  encoded  `[0 0]
    ?.  ?=(%s -.u.encoded)  ~
    ?:(=('' p.u.encoded) `[0 0] (de:base64:mimes:html p.u.encoded))
  ?~  decoded  ~
  ?:  (gth p.u.decoded 16.384)  ~
  =/  data=octs  u.decoded
  =/  rows=@ud  (fall (number u.parsed 'rows') 0)
  =/  cols=@ud  (fall (number u.parsed 'cols') 0)
  ?:  &(!=(2 u.kind) !=(0 p.data))  ~
  ?:  &(=(2 u.kind) =(0 p.data))  ~
  ?:  &(=(3 u.kind) |((lth rows 1) (gth rows 1.000) (lth cols 1) (gth cols 1.000)))  ~
  `[u.kind u.generation u.sequence data rows cols]
++  cursor
  |=  [s=state:session connected=? offset=@ud]
  ^-  @uv
  `@uv`(sham [s connected offset])
++  state
  |=  [s=state:session connected=? nonce=@uv offset=@ud]
  ^-  json
  %-  pairs:enjs:format
  :~  ['phase' (numb:enjs:format phase.s)]
      ['generation' (numb:enjs:format generation.s)]
      ['inputNext' (numb:enjs:format input-next.s)]
      ['connected' [%b connected]]
      ['nonce' [%s (scot %uv nonce)]]
      ['offset' (numb:enjs:format offset)]
      ['cursor' [%s (scot %uv (cursor s connected offset))]]
  ==
++  events
  |=  [snapshot=json retained=octs offset=@ud requested=@ud]
  ^-  json
  =/  first=@ud  (sub offset p.retained)
  =/  reset=?  |((lth requested first) (gth requested offset))
  =/  begin=@ud  ?:(reset first requested)
  =/  length=@ud  (sub offset begin)
  =/  bytes=octs  [length (cut 3 [(sub begin first) length] q.retained)]
  %-  pairs:enjs:format
  :~  ['offset' (numb:enjs:format offset)]
      ['reset' [%b reset]]
      ['data' [%s (en:base64:mimes:html bytes)]]
      ['state' snapshot]
  ==
++  respond
  |=  [id=@ta code=@ud mime=@t body=@t head=?]
  ^-  (list card:agent:gall)
  =/  payload=simple-payload:http
    :_  ?:(head ~ `(as-octs:mimes:html body))
    :-  code
    %+  weld
      ?:(=(405 code) ~[['allow' 'GET, HEAD']] ~)
    :~  ['content-type' mime]
        ['cache-control' 'no-store']
        ['x-content-type-options' 'nosniff']
        ['content-security-policy' (crip "default-src 'none'; script-src 'self'; worker-src blob:; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src data:; connect-src 'self'; base-uri 'none'; frame-ancestors 'self' http://localhost:*")]
    ==
  =/  route=path  /http-response/[id]
  :~  [%give %fact ~[route] %http-response-header !>(response-header.payload)]
      [%give %fact ~[route] %http-response-data !>(data.payload)]
      [%give %kick ~[route] ~]
  ==
++  json-response
  |=  [id=@ta code=@ud body=json]
  (respond id code 'application/json; charset=utf-8' (en:json:html body) %.n)
++  failure
  |=  [id=@ta code=@ud reason=@t]
  (json-response id code (pairs:enjs:format ~[['error' [%s reason]]]))
++  page  (page-at '/apps/pataphor-terminal')
::  Same page rooted at another Eyre path, so a second agent (its own Lick
::  socket, its own session) can serve the same UI from its own base.
++  page-at
  |=  base=@t
  ^-  @t
  (page-at-assets base)
::  Only asset URLs change; the document location still owns terminal routing.
++  page-at-assets
  |=  assets=@t
  ^-  @t
  %+  rap  3
  :~  '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Pataphor terminal</title>'
      '<link rel="stylesheet" href="'  assets  '/xterm.css"><style>*{box-sizing:border-box}html,body{width:100%;height:100%;margin:0;overflow:hidden;background:#181818;color:#ddd;font:12px system-ui,sans-serif}body{display:flex;flex-direction:column}header{flex:none;min-height:34px;padding:4px 10px;display:flex;gap:8px;align-items:center;border-bottom:1px solid #303033;background:#202024}button,a{color:#ccc;background:transparent;border:1px solid transparent;border-radius:3px;padding:4px 7px;font:inherit;cursor:pointer}button:hover,button:focus-visible{background:#333;border-color:#555}button:disabled{opacity:.35;cursor:default}#terminal{flex:1;min-width:0;min-height:0;padding:6px 8px;overflow:hidden}#terminal-status{flex:1;color:#aaa;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.xterm{height:100%}.xterm-viewport{overscroll-behavior:contain}@media(max-width:500px){header{gap:2px;padding:4px}header>span:first-child{display:none}button{padding:4px}}</style>'
      '<script defer src="'  assets  '/xterm.js"></script><script defer src="'  assets  '/terminal.js"></script><script defer src="'  assets  '/power.js"></script></head><body><header>'
      '<span>TERMINAL</span><span id="terminal-status" aria-live="polite">Connecting</span><button data-terminal-action="take">Take control</button><button data-terminal-action="release">Release control</button><button data-terminal-action="start">Start</button><button data-terminal-action="interrupt">Interrupt</button><button data-terminal-action="stop">Stop</button><button data-terminal-action="reconnect">Reconnect</button>'
      '</header><main id="terminal"></main></body></html>'
  ==
--
