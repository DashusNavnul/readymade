::  Pure measurement row contract; no admission, stored state or authority.
::  Keep the legacy digest domain and row predicate exact.
/+  decision=qpc-decision
|%
+$  measurement-row
  $:  id=@ux  step=@ud  work=@ux  resulting-source=@ux  segment=@ux  law=@ux
      confidence=(list @ud)  outcomes=(list outcome:decision)
  ==
++  digest  |=(value=* ^-(@ux (shax (jam [%qpc-measurement-admission-v1 value]))))
++  identifier
  |=  value=@ux
  &(!=(0 value) (lte (met 0 value) 256))
++  row-valid
  |=  r=measurement-row
  ?&  (levy `(list @ux)`~[id.r work.r resulting-source.r segment.r law.r] identifier)
      (lte (met 0 step.r) 64)  =(2 (lent confidence.r))  =(2 (lent outcomes.r))
      (levy confidence.r |=(v=@ud (lte v 1.000.000)))
      (levy outcomes.r |=(v=outcome:decision ?:(=(%unknown verdict.v) =(0 evidence.v) (identifier evidence.v))))
  ==
--
