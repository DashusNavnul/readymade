::  /lib/multiplayer-work
::
::  Pure work-planning law.  Viki owns the cited intent, Cantrip owns the
::  dispatch ceiling, and the project-seat registry owns claimant authority.
::
/-  itn=intent, ma=multiplayer-act, mp=multiplayer-project,
    ms=multiplayer-seat, mw=multiplayer-work
/+  mal=multiplayer-act, msl=multiplayer-seat
|%
++  max-tasks  `@ud`256
++  max-dependencies  `@ud`64
++  max-conditions  `@ud`64
::
++  intent-digest
  |=  intent=intent:itn
  ^-  digest:mp
  `@ux`(shax (jam [%multiplayer-work-intent-v1 intent]))
++  intent-valid
  |=  [intent=intent:itn authority=@p]
  ^-  ?
  ?&  =(%1 -.intent)
      !=(0 id.intent)
      !=(0 convo.intent)
      !=(0 from-seq.intent)
      !=(0 said.intent)
      =(authority by.intent)
      !=(0 at.intent)
      ?|  =(%stated state.intent)
          =(%dispatched state.intent)
      ==
  ==
++  task-digest
  |=  body=task-body:mw
  ^-  digest:mp
  `@ux`(shax (jam [%multiplayer-work-task-v1 body]))
++  condition-valid
  |=  condition=condition:mw
  ^-  ?
  ?-  -.condition
    %file     ?&  ?=(^ path.condition)  !=(0 expected.condition)  ==
    %proof    !=(0 thread.condition)
    %receipt  !=(0 kind.condition)
  ==
++  conditions-valid
  |=  conditions=(list condition:mw)
  ^-  ?
  ?~  conditions  &
  ?&  (condition-valid i.conditions)
      $(conditions t.conditions)
  ==
++  task-valid
  |=  task=task:mw
  ^-  ?
  ?&  =(1 version.body.task)
      !=(0 id.body.task)
      !=(0 summary.body.task)
      (lte (lent dependencies.body.task) max-dependencies)
      =((lent dependencies.body.task) (lent ~(tap in (silt dependencies.body.task))))
      !(lien dependencies.body.task |=(dependency=task-id:mw =(dependency id.body.task)))
      ?=(^ completion.body.task)
      (lte (lent completion.body.task) max-conditions)
      (conditions-valid completion.body.task)
      =((task-digest body.task) digest.task)
  ==
++  workspace-digest
  |=  grant=workspace-grant:mw
  ^-  digest:mp
  `@ux`(shax (jam [%multiplayer-workspace-grant-v1 grant(digest 0)]))
++  dispatch-valid
  |=  [project=project-id:mp task=task:mw dispatch=dispatch:mw]
  ^-  ?
  ?&  =(digest.task task-digest.dispatch)
      (ceiling-valid:mal ceiling.dispatch)
      =(project project.ceiling.dispatch)
      =(`digest:mp`(ceiling-digest:mal ceiling.dispatch) ceiling-digest.dispatch)
      !=(0 dispatched-at.dispatch)
  ==
++  claim-valid
  |=  [task=task:mw claim=claim:mw]
  ^-  ?
  ?&  =(digest.task task-digest.claim)
      !=(0 seat.claim)
      !=(0 lease-generation.claim)
      !=(0 role-epoch.claim)
      !=(0 nonce.claim)
      !=(0 claimed-at.claim)
  ==
++  workspace-valid
  |=  $:  project=project-id:mp
          task=task:mw
          dispatch=dispatch:mw
          claim=claim:mw
          workspace=workspace-grant:mw
      ==
  ^-  ?
  ?&  =(1 version.workspace)
      =(project project.workspace)
      =(id.body.task task.workspace)
      =(digest.task task-digest.workspace)
      =(workspace.ceiling.dispatch workspace.workspace)
      =(seat.claim seat.workspace)
      =(actor.claim ship.workspace)
      =(lease-generation.claim lease-generation.workspace)
      =(role-epoch.claim role-epoch.workspace)
      !=(0 base-revision.workspace)
      =(ceiling-digest.dispatch ceiling-digest.workspace)
      =((workspace-digest workspace) digest.workspace)
  ==
++  task-state-valid
  |=  [project=project-id:mp state=task-state:mw]
  ^-  ?
  ?.  (task-valid task.state)  %.n
  ?~  dispatch.state
    ?&  ?=(~ claim.state)
        ?=(~ workspace.state)
    ==
  =/  dispatch=dispatch:mw  u.dispatch.state
  ?.  (dispatch-valid project task.state dispatch)  %.n
  ?~  claim.state  ?=(~ workspace.state)
  =/  claim=claim:mw  u.claim.state
  ?.  (claim-valid task.state claim)  %.n
  ?~  workspace.state  %.y
  (workspace-valid project task.state dispatch claim u.workspace.state)
::
++  plan-valid
  |=  plan=plan:mw
  ^-  ?
  ?&  =(1 version.plan)
      !=(0 project.plan)
      (intent-valid intent.plan authority.plan)
      =((intent-digest intent.plan) intent-digest.plan)
      (lte ~(wyt by tasks.plan) max-tasks)
      %+  levy  ~(tap by tasks.plan)
      |=  row=[task-id:mw task-state:mw]
      ?&  =(-.row id.body.task.+.row)
          (task-state-valid project.plan +.row)
          (levy dependencies.body.task.+.row |=(dependency=task-id:mw (~(has by tasks.plan) dependency)))
      ==
  ==
++  reject
  |=  refusal=refusal:mw
  ^-  result:mw
  [%| refusal]
++  allow
  |=  [plan=plan:mw code=code:mw]
  ^-  result:mw
  [%& [plan code]]
::
++  open
  |=  [project=project-id:mp authority=@p intent=intent:itn]
  ^-  result:mw
  ?.  ?&  !=(0 project)
          (intent-valid intent authority)
      ==
    (reject [%invalid-intent ~])
  (allow [1 project authority intent (intent-digest intent) ~] %opened)
::
++  dependencies-exist
  |=  [plan=plan:mw task=task:mw]
  ^-  (unit [task=task-id:mw dependency=task-id:mw])
  =/  dependencies=(list task-id:mw)  dependencies.body.task
  |-
  ?~  dependencies  ~
  ?:  (~(has by tasks.plan) i.dependencies)  $(dependencies t.dependencies)
  `[id.body.task i.dependencies]
++  add-task
  |=  [plan=plan:mw actor=@p body=task-body:mw]
  ^-  result:mw
  ?.  (plan-valid plan)  (reject [%invalid-plan ~])
  ?.  =(authority.plan actor)
    (reject [%foreign-authority authority.plan actor])
  =/  task=task:mw  [body (task-digest body)]
  ?.  (task-valid task)  (reject [%invalid-task ~])
  ?:  (~(has by tasks.plan) id.body)  (reject [%task-exists id.body])
  =/  missing=(unit [task=task-id:mw dependency=task-id:mw])
    (dependencies-exist plan task)
  ?^  missing  (reject [%dependency-missing task.u.missing dependency.u.missing])
  =/  state=task-state:mw  [task ~ ~ ~]
  (allow plan(tasks (~(put by tasks.plan) id.body state)) %task-added)
::
++  dispatch
  |=  [plan=plan:mw actor=@p task-id=task-id:mw ceiling=ceiling:ma dispatched-at=@da]
  ^-  result:mw
  ?.  (plan-valid plan)  (reject [%invalid-plan ~])
  ?.  =(authority.plan actor)
    (reject [%foreign-authority authority.plan actor])
  =/  found=(unit task-state:mw)  (~(get by tasks.plan) task-id)
  ?~  found  (reject [%task-missing task-id])
  =/  state=task-state:mw  u.found
  ?^  dispatch.state  (reject [%already-dispatched task-id])
  ?.  ?&  (ceiling-valid:mal ceiling)
          =(project.plan project.ceiling)
      ==
    (reject [%invalid-ceiling ~])
  =/  dispatched=dispatch:mw
    [digest.task.state ceiling `digest:mp`(ceiling-digest:mal ceiling) dispatched-at]
  =/  next=task-state:mw  state(dispatch `dispatched)
  (allow plan(tasks (~(put by tasks.plan) task-id next)) %dispatched)
::
++  claim
  |=  $:  plan=plan:mw
          registry=registry:ms
          binding=role-binding:ms
          actor=@p
          task-id=task-id:mw
          seat=@tas
          nonce=digest:mp
          claimed-at=@da
      ==
  ^-  result:mw
  ?.  (plan-valid plan)  (reject [%invalid-plan ~])
  =/  found=(unit task-state:mw)  (~(get by tasks.plan) task-id)
  ?~  found  (reject [%task-missing task-id])
  =/  state=task-state:mw  u.found
  ?~  dispatch.state  (reject [%not-dispatched task-id])
  =/  authorized=lease-result:ms
    (authorize:msl registry actor seat binding claimed-at)
  ?-  -.authorized
    %|  (reject [%seat-refused p.authorized])
    %&
      =/  lease=lease:ms  p.authorized
      ?^  claim.state
        ?:  ?&  =(actor actor.u.claim.state)
                =(seat seat.u.claim.state)
                =(generation.lease lease-generation.u.claim.state)
                =(nonce nonce.u.claim.state)
            ==
          (allow plan %claim-replay)
        (reject [%claim-held task-id actor.u.claim.state])
      ?:  =(0 nonce)  (reject [%invalid-task ~])
      =/  claimed=claim:mw
        :*  digest.task.state  actor  seat  generation.lease
            epoch.binding  nonce  claimed-at
        ==
      =/  next=task-state:mw  state(claim `claimed)
      (allow plan(tasks (~(put by tasks.plan) task-id next)) %claimed)
  ==
::
++  grant-workspace
  |=  $:  plan=plan:mw
          registry=registry:ms
          binding=role-binding:ms
          actor=@p
          task-id=task-id:mw
          workspace=@tas
          base-revision=@ud
          granted-at=@da
      ==
  ^-  result:mw
  ?.  (plan-valid plan)  (reject [%invalid-plan ~])
  ?.  =(authority.plan actor)
    (reject [%foreign-authority authority.plan actor])
  ?:  =(0 base-revision)  (reject [%base-revision-invalid base-revision])
  =/  found=(unit task-state:mw)  (~(get by tasks.plan) task-id)
  ?~  found  (reject [%task-missing task-id])
  =/  state=task-state:mw  u.found
  ?~  dispatch.state  (reject [%not-dispatched task-id])
  ?~  claim.state  (reject [%not-dispatched task-id])
  ?^  workspace.state  (reject [%workspace-exists task-id])
  ?.  =(workspace workspace.ceiling.u.dispatch.state)
    (reject [%workspace-mismatch workspace.ceiling.u.dispatch.state workspace])
  =/  authorized=lease-result:ms
    (authorize:msl registry actor.u.claim.state seat.u.claim.state binding granted-at)
  ?-  -.authorized
    %|  (reject [%seat-refused p.authorized])
    %&
      =/  lease=lease:ms  p.authorized
      =/  grant=workspace-grant:mw
        :*  1  project.plan  task-id  digest.task.state  workspace
            seat.u.claim.state  actor.u.claim.state  generation.lease
            epoch.binding  base-revision  ceiling-digest.u.dispatch.state
            granted-at  0x0
        ==
      =.  grant  grant(digest (workspace-digest grant))
      =/  next=task-state:mw  state(workspace `grant)
      (allow plan(tasks (~(put by tasks.plan) task-id next)) %workspace-granted)
  ==
--
