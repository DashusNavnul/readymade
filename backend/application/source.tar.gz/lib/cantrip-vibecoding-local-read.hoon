::  Canonical joins for the local-only Cantrip demo write gate.
::  No caller-supplied authority, passed tests, model source, or seat.
/-  itn=intent, vc=vibecoding-candidate, vp=vibecoding-proposal
/+  clw=cantrip-law-window, cvp=cantrip-vibecoding-proposal,
    local=cantrip-vibecoding-local, demo=vibecoding-demo,
    dsr=desk-shell-read, vcl=vibecoding-candidate,
    vcr=vibecoding-candidate-review, vsg=viki-scry-guard
|%
++  read
  |=  [our=@p actor=@p at=@da candidate-key=@ux review-key=@ux window=window:clw]
  ^-  decision:local
  ?.  =(our actor)  [%| %foreign-actor]
  ?.  &((agent-live:vsg our at %graf) (agent-live:vsg our at %viki))
    [%| %agent-unavailable]
  =/  graf=path  /(scot %p our)/graf/(scot %da at)
  =/  candidates=(list *)
    .^((list *) %gx (weld graf /by-kind/vibecoding-candidate/noun))
  =/  found=(unit candidate:vc)  (find:vcr candidates candidate-key)
  ?~  found  [%| %candidate-missing]
  =/  candidate=candidate:vc  u.found
  =/  reviews=(list *)
    .^((list *) %gx (weld graf /by-kind/vibecoding-proposal-record/noun))
  =/  reviewed=(unit record:vp)  (find-record:cvp reviews review-key)
  ?~  reviewed  [%| %review-missing]
  =/  context=context:vc  (context-of:vcl packet.candidate)
  =/  held
    |=  fact=*
    .^(? %gx (weld graf /contains/(scot %uw (jam fact))/noun))
  ?.  &((held (packet-fact:vcl packet.candidate)) (held (packet-fact:vcl context)))
    [%| %evidence-missing]
  =/  viki=path  /(scot %p our)/viki/(scot %da at)
  =/  intent-path=path  ~[%intent id.intent.intent.context %noun]
  =/  stated=(unit record:itn)
    .^((unit record:itn) %gx (weld viki intent-path))
  ?.  =(`intent.context stated)  [%| %intent-changed]
  =/  a=snapshot:demo  (read:demo our at base:demo)
  =/  w=snapshot:demo  (read:demo our at work:demo)
  ?.  &(exists.a exists.w)  [%| %project-changed]
  =/  domes=cone:clay  .^(cone:clay %cx /(scot %p our)//(scot %da at)/domes)
  =/  accepted=dome:clay  (~(got by domes) [our base:demo])
  =/  working=dome:clay  (~(got by domes) [our work:demo])
  =/  result=decision:local
    (judge:local our actor candidate u.reviewed window a w let.accepted let.working at)
  ?:  ?=(%| -.result)  result
  =/  actual=@uv  .^(@uv %cz (beam:dsr our at work:demo target:demo))
  ?.  =(actual before.p.result)  [%| %file-hash-mismatch]
  result
--
