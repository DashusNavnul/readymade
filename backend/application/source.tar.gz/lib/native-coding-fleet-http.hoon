::  Public configured placement choices and explicit owner queue decoding.
::  No credentials, remote binding synthesis, execution or claim admission.
/-  nf=native-coding-fleet
/+  runtime=native-coding-fleet-runtime, loop=native-coding-loop,
    opening=native-coding-opening-http, open=viki-native-opening,
    guard=viki-scry-guard, cr=codex-responses, terminal=native-coding-terminal
|%
++  digest  |=(value=* ^-(@ux (shax (jam value))))
++  choices
  |=  [our=@p now=@da ids=(list @ux) rows=(unit (list row:opening))]
  ^-  (unit (map @ux placement:runtime))
  ?.  (agent-live:guard our now %viki)  ~
  ?~  rows  ~
  ?:  |((gte (lent ids) 64) (gte (lent u.rows) 128))  `~
  =/  used=(set @ux)  (silt (weld ids (turn u.rows |=(r=row:opening id.r))))
  =/  all=(map @ux placement:runtime)
    .^((map @ux placement:runtime) %gx /(scot %p our)/viki/(scot %da now)/native-coding/fleet/placements/noun)
  =/  fleet=organ:nf
    .^(organ:nf %gx /(scot %p our)/viki/(scot %da now)/native-coding/fleet/noun)
  =/  result=(map @ux placement:runtime)  ~
  =/  todo=(list [@ux placement:runtime])  (scag 64 ~(tap by all))
  |-  ^-  (unit (map @ux placement:runtime))
  ?~  todo  `result
  =/  id=@ux  -.i.todo
  =/  p=placement:runtime  +.i.todo
  =/  worker  (~(get by workers.fleet) seat.seat-session.route.p)
  ?:  |((~(has in used) id) !=(id session.config.p) !(placement-valid:runtime our p))
    $(todo t.todo)
  ?~  worker  $(todo t.todo)
  ?.  &(=(route.p route.u.worker) =(binding.config.p binding.u.worker) =(generation.config.p generation.u.worker))  $(todo t.todo)
  $(todo t.todo, result (~(put by result) id p))
++  view
  |=  [our=@p now=@da ids=(list @ux) rows=(unit (list row:opening))]
  ^-  json
  =/  available  (choices our now ids rows)
  =/  data=(list json)
    ?~  available  ~
    %+  turn  ~(tap by u.available)
    |=  [id=@ux p=placement:runtime]
    (pairs:enjs:format ~[['id' s+(scot %ux id)] ['digest' s+(scot %ux (digest p))] ['worker' s+(scot %p moon.seat-session.route.p)] ['generation' s+(scot %ud generation.config.p)] ['provider' s+provider.selection.config.p] ['model' s+model.selection.config.p] ['key' s+provider-key.config.p] ['credential' s+credential.selection.config.p] ['endpoint' s+endpoint.selection.config.p] ['format' s+format.selection.config.p]])
  (pairs:enjs:format ~[['available' b+?=(^ available)] ['rows' a+data]])
++  hex
  |=  text=@t
  ^-  @ux
  =/  value=@ux  (need (slaw %ux text))
  ?>  &(!=(0 value) (lte (met 0 value) 256) =(text (scot %ux value)))
  value
++  moon-open
  |=  [our=@p now=@da id=@ux object=json]
  ^-  request:open
  ?>  (agent-live:guard our now %viki)
  =/  sessions=(list public-session:loop)
    .^((list public-session:loop) %gx /(scot %p our)/viki/(scot %da now)/native-coding/sessions/noun)
  =/  ids=(list @ux)  (turn sessions |=(s=public-session:loop id.session.s))
  =/  available  (need (choices our now ids (read:opening our now)))
  =/  p=placement:runtime  (~(got by available) id)
  ?>  =((hex (need (string:cr object 'placement'))) (digest p))
  =/  ship=@p  (need (slaw %p (need (string:cr object 'worker'))))
  ?>  =(ship moon.seat-session.route.p)
  =/  r=request:open  (request:opening object id selection.config.p ship)
  ::  Provider selection's credential and relay provider-key are independent.
  r(key provider-key.config.p)
++  strings
  |=  [object=json key=@t limit=@ud]
  ^-  (list @t)
  =/  value=json  (need (field:cr object key))
  ?>  ?=(%a -.value)
  ?>  (lte (lent p.value) limit)
  %+  turn  p.value
  |=  item=json
  ?>  ?=(%s -.item)
  ?>  (lte (met 3 p.item) 4.096)
  p.item
++  queue
  |=  [session=@ux nonce=@ux object=json]
  ^-  [%native-coding-fleet-enqueue-session-v1 session=@ux nonce=@ux role=role:nf paths=(set path) dependencies=(set @ux)]
  =/  role=@t  (need (string:cr object 'role'))
  ?>  ?=(?(%build %check) role)
  =/  paths=(list path)
    %+  turn  (strings object 'paths' 64)
    |=  text=@t
    =/  p=path  (path-of:terminal / text)
    ?>  &(?=(^ p) =(text (spat p)))
    p
  =/  dependencies=(list @ux)  (turn (strings object 'dependencies' 32) hex)
  ?>  &(=((lent paths) ~(wyt in (silt paths))) =((lent dependencies) ~(wyt in (silt dependencies))))
  [%native-coding-fleet-enqueue-session-v1 session nonce role (silt paths) (silt dependencies)]
--
