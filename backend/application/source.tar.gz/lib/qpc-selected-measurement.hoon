::  Native selected-branch evidence join, not a row-input authority surface.
::  The owner reserves before generation and supplies canonical retained
::  journals, assessments, execution records and the actual current Clay tree.
::  A consumed mapping or materialized candidate alone settles nothing.
/-  nc=native-coding
/+  enrollment=qpc-measurement-admission, obs=qpc-observation,
    sensing=qpc-task-sensing, window=qpc-successor-window,
    d=qpc-native-decision, controller=qpc-native-controller,
    selected=qpc-native-selected, assessment=qpc-native-assessment,
    admission=qpc-native-admission, owner=qpc-native-owner,
    pool=qpc-native-pool, sessions=native-coding-session,
    ct=cantrip-native-coding, accept=native-coding-accept,
    report=qpc-report, decisions=qpc-decision, project=native-coding-project
|%
+$  reservation
  [%qpc-selected-reservation-v1 id=@ux enrollment=enrollment:enrollment prefix=state:window]
+$  receipt
  $:  %qpc-selected-measurement-v1  id=@ux  reservation=@ux
      frame=@ux  call=@t  controller=@ux  selected=@ux  assessment=@ux
      mapping=@ux  release=@ux  acceptance=@ux  decision=@ux  at=@da
      status=?(%applied %refused)  prediction=revision:nc
      resulting=revision:nc  row=measurement-row:enrollment
  ==
+$  evidence
  $:  reservation=reservation  observed=state:obs  frame=@ux
      entry=entry:sessions  choice=record:controller
      execution=record:selected  assessment=record:assessment  release=receipt:admission
      ledger=organ:ct  acceptance=record:accept  current=tree:nc  at=@da
  ==
++  digest  |=(v=* ^-(@ux (shax (jam [%qpc-selected-measurement-v1 v]))))
++  reservation-valid
  |=  r=reservation
  ^-  ?
  =/  e=enrollment:enrollment  enrollment.r
  =/  p=state:window  prefix.r
  =/  current  (current:window p (digest:enrollment source.work.e))
  ?&  =(id.r (digest r(id 0x0)))  (enrollment-valid:enrollment e)
      (valid:window p)  ?=(%& -.current)
      =(instrument.position.e instrument.binding.p)
      =(stream.position.e stream.binding.p)
      =(manifest.contract.e manifest.binding.p)
      =(policy.contract.e policy.binding.p)
      =(step.position.e ordinal.p)  =(segment.p `segment.position.e)
      =(source.task.e source.work.e)
  ==
++  reserve
  ::  Caller first proves the stream has no queued unresolved work, then
  ::  persists this exact prefix and the queue slot in one native event.
  |=  [e=enrollment:enrollment p=state:window]
  ^-  (each reservation @tas)
  =/  r=reservation  [%qpc-selected-reservation-v1 0x0 e p]
  =.  r  r(id (digest r))
  ?:((reservation-valid r) [%& r] [%| %qpc-selected-reservation-invalid])
++  chronology
  ::  Original authenticated proposal chronology; no fabricated ordinary
  ::  outcome/acceptance is used to relabel a managed alternative.
  |=  [r=enrollment:enrollment m=manifest:obs f=frame:obs p=pool:pool row=row:pool e=entry:sessions]
  ^-  ?
  =/  pre  (prefix:enrollment r e)
  ?:  ?=(%| -.pre)  %.n
  =/  contexts=(list record:sessions)
    (skim records.e |=(x=record:sessions &(?=(%context -.body.x) =(id.x context-record.p))))
  =/  models=(list record:sessions)
    (skim records.e |=(x=record:sessions &(?=(%model -.body.x) =(id.x model-record.p))))
  =/  tools=(list record:sessions)
    (skim records.e |=(x=record:sessions &(?=(%tool -.body.x) =(id.x journal.row))))
  ?.  &(=(1 (lent contexts)) =(1 (lent models)) =(1 (lent tools)))  %.n
  =/  c=record:sessions  (snag 0 contexts)
  =/  model=record:sessions  (snag 0 models)
  =/  tool=record:sessions  (snag 0 tools)
  ?>  &(?=(%context -.body.c) ?=(%model -.body.model) ?=(%tool -.body.tool))
  =/  between=(list record:sessions)
    (scag (sub sequence.c (min sequence.c sequence.before.r)) (slag sequence.before.r records.e))
  ?~  between  %.n
  =/  result=tool-result:nc  result.body.tool
  ?.  ?=(%candidate -.output.result)  %.n
  =/  ctx=context:nc  [project.m configuration.work.r session.work.r request.work.r owner.r source.work.r]
  ?&  =(id.c context.f)  =(value.body.c context.p)
      =(sequence.model journal.f)  =(at.model at.f)
      =(reply.f (digest:obs result.body.model))
      =(result.f (call-predictions:obs m work.f calls.result.body.model text.result.body.model))
      =(result.row (digest:pool result))  =(call.row call-id.result)
      =(candidate.row `id.value.output.result)
      =(ctx context.result)  =(ctx context.value.output.result)
      (gte sequence.c sequence.before.r)  (lth sequence.c sequence.model)
      (gth sequence.tool sequence.model)
      (lte at.r at.c)  (lte at.c at.model)  (lte at.model at.tool)
      =([%status %inference %dispatch] body:(rear between))
      (levy `(list record:sessions)`between |=(x=record:sessions &((lte at.r at.x) (lte at.x at.c))))
      (levy (scag (dec (lent between)) `(list record:sessions)`between) |=(x=record:sessions =([%status %ready %operator-resume] body.x)))
  ==
++  terminal
  ::  Actual accepted landing, or an actual completed refusal/revision
  ::  decision. Unknown, checking, review and candidate creation stay pending.
  |=  [mapping=mapping:d tool=record:ct a=record:accept current=tree:nc at=@da]
  ^-  (each [status=?(%applied %refused) resulting=revision:nc] @tas)
  ?.  &(=(%finished stage.tool) =(request.mapping request.tool) =(grant.mapping grant.tool))
    [%| %qpc-selected-tool-unfinished]
  ?~  result.tool  [%| %qpc-selected-tool-unfinished]
  =/  result=tool-result:nc  u.result.tool
  ?.  ?&  ?=(%candidate -.output.result)
          =(context.request.mapping context.result)  =(call-id.request.mapping call-id.result)
      ==  [%| %qpc-selected-candidate-missing]
  =/  c=candidate:nc  value.output.result
  ?.  ?&  =(c candidate.a)  =(context.request.mapping context.c)
          =(effect.mapping (effect:d c))  =(grant.mapping grant.a)
          (valid:accept (malt ~[[id.c a]]))  (tree-valid:project project.a current)
          (lte at.tool requested-at.a)  (lte requested-at.a at)
      ==  [%| %qpc-selected-acceptance-mismatch]
  ?~  decision.a  [%| %qpc-selected-decision-unavailable]
  ?.  &((lte requested-at.a at.u.decision.a) (lte at.u.decision.a at))
    [%| %qpc-selected-decision-order]
  ?:  =(%applied stage.a)
    ?~  landed.a  [%| %qpc-selected-landing-unavailable]
    ?.  =(current u.landed.a)  [%| %qpc-selected-landed-source-changed]
    [%& [%applied revision.current]]
  ?.  ?&  =(%refused stage.a)  !=(%approve verdict.u.decision.a)
          ?=(~ landed.a)  =(current basis.c)
      ==  [%| %qpc-selected-terminal-unavailable]
  [%& [%refused revision.current]]
++  assemble
  |=  v=evidence
  ^-  (each receipt @tas)
  =/  r=reservation  reservation.v
  ?.  (reservation-valid r)  [%| %qpc-selected-reservation-invalid]
  =/  enrolled=enrollment:enrollment  enrollment.r
  =/  choice=record:controller  choice.v
  =/  execution=record:selected  execution.v
  =/  decision=state:d  decision.choice
  =/  f=opening:d  frozen.decision
  ?.  ?&  (valid:controller [%qpc-native-controller-v1 (malt ~[[session.f choice]]) ~])
          (valid:selected [%qpc-native-selected-v1 (malt ~[[id.plan.execution execution]]) ~])
          =(%chosen phase.choice)  =(%sent phase.execution)
          =(selection.plan.execution (digest:selected choice))
          =(prefix.r prefix.f)  =(session.f session.work.enrolled)
          =(request.f request.work.enrolled)  =(source.f source.work.enrolled)
          =(task.f (digest:sensing task.enrolled))
          =(objective.f objective.task.enrolled)  =(id.law.f law.contract.enrolled)
      ==  [%| %qpc-selected-choice-mismatch]
  =/  original=record:owner  origin.choice
  =/  p=pool:pool  pool:(need collection.original)
  =/  plan  (make:selected choice [entry.v key.original grant.f] at.plan.execution nonce.plan.execution)
  ?.  &(?=(%& -.plan) =(p.plan plan.execution))  [%| %qpc-selected-plan-mismatch]
  =/  mapping=mapping:d  (need mapping.execution)
  =/  now=current:d  [source.f epoch.binding.core.decision authority.f]
  =/  replay  (release:d decision candidate.plan.execution id.grant.plan.execution request.plan.execution admission.mapping now)
  ?.  &(?=(%& -.replay) =(mapping +.p.replay))  [%| %qpc-selected-mapping-mismatch]
  ?.  (valid:obs owner.enrolled observed.v)  [%| %qpc-selected-observation-invalid]
  =/  found  (~(get by frames.observed.v) frame.v)
  ?~  found  [%| %qpc-selected-frame-missing]
  =/  frame=frame:obs  u.found
  ?.  &(=(work.enrolled work.frame) ?=(%& -.result.frame))  [%| %qpc-selected-frame-mismatch]
  =/  manifest=manifest:obs  (~(got by manifests.observed.v) manifest.work.frame)
  =/  pre  (prefix:enrollment enrolled entry.v)
  ?:  ?=(%| -.pre)  [%| p.pre]
  =/  project=project:nc  project.grant.scope.original
  ?.  ?&  =(project.enrolled (digest:enrollment project))
          =(project project.acceptance.v)
          (validate:sensing contract.enrolled task.enrolled manifest work.enrolled project cases.task.enrolled p.pre)
      ==  [%| %qpc-selected-sensing-mismatch]
  =/  rows=(list row:pool)
    (skim rows.p |=(x=row:pool &(=(collection-tool.mapping tool.x) =(candidate.x `candidate.mapping))))
  ?.  =(1 (lent rows))  [%| %qpc-selected-original-call-missing]
  =/  row=row:pool  (snag 0 rows)
  ?.  (chronology enrolled manifest frame p row entry.v)  [%| %qpc-selected-provenance-mismatch]
  =/  predictions=(list row:report)
    (skim p.result.frame |=(x=row:report =(call.row call.x)))
  ?.  =(1 (lent predictions))  [%| %qpc-selected-prediction-missing]
  =/  binding=binding:assessment
    [f p position:(need collection.original) declaration.original scope.original]
  ?.  =(binding binding.assessment.v)  [%| %qpc-selected-assessment-binding]
  =/  admitted=receipt:admission  (need admission.choice)
  =/  release=receipt:admission  release.v
  =/  marker=marker:admission  (need marker.execution)
  =/  attempt=attempt:controller  (need attempt.choice)
  ?.  ?&  =(marker request.release)
          =(position.admission.mapping sequence.event.marker)
          (marker-valid:admission marker assessment.v entry.v)
          (lte at.admitted at.event.attempt)
          (lte at.event.attempt at.plan.execution)
          (lte at.plan.execution at.event.marker)
          (lte at.event.marker at.release)  (lte at.release at.v)
      ==  [%| %qpc-selected-release-marker-mismatch]
  ::  Validate historical diagnostics with their retained historical scope.
  ::  A later revocation cannot erase an already authenticated assessment or
  ::  landing. This projection emits no effects and grants no new authority.
  =/  historical=organ:ct
    ledger.v(grants (~(put by grants.ledger.v) grant.f scope.original))
  =/  checked
    (prepare:admission owner.f at.admitted marker.choice [binding historical] assessment.v cases.task.enrolled entry.v)
  ?.  &(?=(%& -.checked) =(p.checked admitted))  [%| %qpc-selected-assessment-mismatch]
  ::  The second immutable Cantrip receipt belongs to the release marker,
  ::  not the earlier selection marker. Rebuild it from the same historical
  ::  assessment/scope and bind its exact selected admission to the mapping.
  =/  release-checked
    (prepare:admission owner.f at.release marker [binding historical] assessment.v cases.task.enrolled entry.v)
  ?.  &(?=(%& -.release-checked) =(p.release-checked release))
    [%| %qpc-selected-release-admission-mismatch]
  =/  release-offers=(list offered:d)
    (skim offered.release |=(x=offered:d =(candidate.mapping candidate.admission.x)))
  ?.  =(1 (lent release-offers))  [%| %qpc-selected-release-admission-missing]
  =/  release-offer=offered:d  (snag 0 release-offers)
  ?.  =(admission.release-offer admission.mapping)
    [%| %qpc-selected-release-mapping-mismatch]
  =/  offers=(list offered:d)
    (skim offered.admitted |=(x=offered:d =(candidate.mapping candidate.admission.x)))
  ?.  =(1 (lent offers))  [%| %qpc-selected-assessment-missing]
  =/  checks=(list check:d)  checks.admission:(snag 0 offers)
  =/  outcomes=(list outcome:decisions)
    (turn (scag (lent propositions.manifest) (slag 1 checks)) |=(x=check:d outcome.x))
  =/  tool  (~(get by records.ledger.v) tool.mapping)
  ?~  tool  [%| %qpc-selected-execution-unfinished]
  ?.  (lte at.release at.u.tool)  [%| %qpc-selected-execution-order]
  =/  settled  (terminal mapping u.tool acceptance.v current.v at.v)
  ?:  ?=(%| -.settled)  [%| p.settled]
  =/  measured=measurement-row:enrollment
    [id.frame step.position.enrolled (digest:obs work.frame) (digest:enrollment resulting.p.settled) segment.position.enrolled law.contract.enrolled values:(snag 0 predictions) outcomes]
  ?.  (row-valid:enrollment measured)  [%| %qpc-selected-measurement-invalid]
  =/  value=receipt
    :*  %qpc-selected-measurement-v1  0x0  id.r  id.frame  call.row
        (digest:selected choice)  (digest:selected execution)
        (digest:assessment assessment.v)  id.mapping  (digest release)
        (digest:accept acceptance.v)  (digest:accept (need decision.acceptance.v))
        at.v  status.p.settled  source.work.enrolled  resulting.p.settled  measured
    ==
  [%& value(id (digest value))]
++  linked-valid
  ::  Saved receipt consistency only. The native producer owns authenticity;
  ::  no command accepts this receipt or an arbitrary observation row.
  |=  [r=reservation f=frame:obs value=receipt]
  ^-  ?
  ?.  ?=(%& -.result.f)  %.n
  =/  predictions=(list row:report)
    (skim p.result.f |=(x=row:report =(call.value call.x)))
  ?.  =(1 (lent predictions))  %.n
  =/  e=enrollment:enrollment  enrollment.r
  =/  row=measurement-row:enrollment  row.value
  ?&  (reservation-valid r)  =(id.value (digest value(id 0x0)))
      =(id.r reservation.value)  =(id.f frame.value)
      =(work.f work.e)  =(prediction.value source.work.e)
      (row-valid:enrollment row)
      =(id.row id.f)  =(step.row step.position.e)
      =(work.row (digest:obs work.e))  =(segment.row segment.position.e)
      =(law.row law.contract.e)  =(confidence.row values:(snag 0 predictions))
      =(resulting-source.row (digest:enrollment resulting.value))
      (levy `(list @ux)`~[controller.value selected.value assessment.value mapping.value release.value acceptance.value decision.value] identifier:ct)
      (gte at.value at.f)
      ?:  =(%applied status.value)
        &(=(owner.prediction.value owner.resulting.value) =(desk.prediction.value desk.resulting.value) =(+(number.prediction.value) number.resulting.value))
      =(prediction.value resulting.value)
  ==
--
