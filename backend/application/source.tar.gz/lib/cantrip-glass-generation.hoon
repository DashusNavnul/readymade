::  Generation precedes a model proposal. This admits bounded read/inspect
::  work from Viki's owner goal, never manufactures a model or write verdict.
::  All evidence is supplied by canonical owners in the same native event.
/-  gol=goal, vc=vibecoding-candidate, cs=vibecoding-check-spec,
    vr=glass-moon-route, mg=moon-grant, gs=graf, ws=workspace
/+  planner=plan, route=viki-route, seat=seat-session,
    dispatch=cantrip-vibecoding-dispatch, law=cantrip-law-window,
    candidate=vibecoding-candidate, checks=vibecoding-check-spec
|%
+$  evidence
  $:  goal=goal:gol  plan=plan:planner  context=context:vc
      approval=approval:cs  route=moon-route:vr
      sessions=table:seat  window=window:law
      seat-write=graf-seat-write:gs  claim=claim:ws  desks=(set @tas)
      grant=(unit moon-grant:mg)  mirror=(unit mirrored-lease:mg)
  ==
+$  admission
  [%glass-generation-admission-v1 nonce=@ux digest=@ux at=@da evidence=evidence]
++  digest
  |=  value=*
  ^-  @ux
  `@ux`(shax (jam value))
++  same-authority
  ::  Full snapshots remain committed historical evidence. Current authority
  ::  depends on the selected row and workspace, not unrelated fleet members.
  ::  The caller must separately admit the fresh canonical evidence.
  |=  [before=evidence after=evidence]
  ^-  ?
  =/  selected  seat-session.route.before
  =/  prior  (~(get by sessions.before) seat.selected)
  =/  current  (~(get by sessions.after) seat.selected)
  ?&  =(before(sessions sessions.after, desks desks.after) after)
      =(`selected prior)  =(prior current)
      (~(has in desks.before) workspace.selected)
      (~(has in desks.after) workspace.selected)
  ==
++  inspect-allowed
  |=  w=window:law
  ^-  ?
  %+  levy  `(list act:law)`~[%read %inspect]
  |=  a=act:law
  ?&  (~(has in admissible.w) a)
      !(~(has in blocked.w) a)
      !(~(has in never-auto.w) a)
  ==
++  admit
  |=  [our=@p actor=@p now=@da nonce=@ux e=evidence]
  ^-  (each admission @tas)
  ?.  =(our actor)  [%| %foreign-owner]
  ?.  &(!=(0 nonce) (lte (met 0 nonce) 128))  [%| %nonce-invalid]
  ?.  ?&  !=('' gid.goal.e)  =(%operator origin.goal.e)
          (lte at.goal.e now)
          =(plan.e (make:planner goal.e refs.plan.e))
      ==  [%| %goal-plan-invalid]
  ?.  ?&  (current-context-valid:candidate context.e)
          =(our by.intent.intent.context.e)
          =(text.goal.e said.intent.intent.context.e)
          (lte at.context.e now)
          =(law.context.e (digest window.e))
      ==  [%| %context-invalid]
  ?.  ?&  (approval-valid:checks approval.e)
          =(our owner.approval.e)
          =(context.approval.e (digest context.e))
          (lte at.context.e at.approval.e)
          (lte at.approval.e now)
      ==  [%| %approval-invalid]
  ?.  (inspect-allowed window.e)  [%| %inspect-not-admitted]
  ?.  (allowed:route our now sessions.e route.e)  [%| %route-not-current]
  =/  s  seat-session.route.e
  ?.  ?&  =(workspace.s desk.work.context.e)
          =(workspace.s fork.claim.e)  =(moon.s holder.claim.e)
          (~(has in desks.e) workspace.s)
          =(seat.s seat-id.seat-write.e)
          =((scot %p moon.s) assigned-ship-id.seat-write.e)
          =(`@t`workspace.s session-id.seat-write.e)
          =(%claim write-kind.seat-write.e)
      ==  [%| %workspace-or-seat-write-mismatch]
  =/  reasons
    (grant-rejections:dispatch grant.e moon.s our seat.s seat-write.e mirror.e 'read-file' %safe now)
  ?^  reasons  [%| %lease-not-admitted]
  =/  key=@ux  (digest [%glass-generation-v1 nonce e])
  [%& [%glass-generation-admission-v1 nonce key now e]]
--
