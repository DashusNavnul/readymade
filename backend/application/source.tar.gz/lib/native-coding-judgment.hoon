::  Viki's candidate judgment joins native check evidence with the existing
::  Boxy/Juggler event history. A model cannot provide a passed challenge.
::  Callers read the workspace canonically; this module does not invent votes,
::  reviewers, admissions, a closed match, or evidence of semantic correctness.
/-  nc=native-coding, bx=boxy, jm=juggler-match
/+  accept=native-coding-accept, files=native-coding-files,
    boxy=boxy-law, match=boxy-match, juggler=juggler-match, cr=codex-responses
|%
++  artifact
  |=  [c=candidate:nc r=report:accept objective=@t]
  ^-  @t
  (cat 3 'native-coding:' (scot %ux (digest:accept [c r objective])))
++  proposal
  ::  Reviewers can explain their reasoning in challenge/accept moves. The
  ::  proposed target is the exact immutable candidate/report/objective tuple.
  |=  [c=candidate:nc r=report:accept objective=@t model=@t]
  ^-  contribution:jm
  =/  bound=@t  (artifact c r objective)
  [bound %propose [%model-proposed model] [%match ~] ~ bound ~ ~]
++  inspect
  |=  [p=project:nc c=candidate:nc r=report:accept objective=@t model=@t]
  ^-  (unit @tas)
  ?.  (candidate-valid:files p c)  `%candidate-invalid
  ?.  (report-valid:accept p c r)  `%candidate-report-invalid
  ?.  &(!=(0 objective) (lte (met 3 objective) 65.536))  `%objective-invalid
  (contribution-error:juggler initial-state:juggler (proposal c r objective model))
++  own-moon
  |=  [our=@p worker=@p]
  ^-  ?
  &(!=(our worker) =(%earl (clan:title worker)) =(our (^sein:title worker)))
++  challenged
  ::  A retained, admitted challenge by the other participant must concern
  ::  this target. Dual acceptance below is the match's resolution rule.
  |=  [state=match-state:jm target=move:jm]
  ^-  ?
  %+  lien  moves.state
  |=  m=move:jm
  ?&  =(%challenge kind.contribution.m)  !=(actor.m actor.target)
      =(target.contribution.m `id.target)  accepted.admission.m
      !=(0 body.contribution.m)
  ==
++  evaluate
  ::  Passing checks alone cannot produce approval. A canonical closed match
  ::  with real parent-owned moon participants must resolve this exact target.
  |=  $:  our=@p  at=@da  p=project:nc  c=candidate:nc
          r=report:accept  objective=@t  model=@t  workspace=workspace-state:bx
      ==
  ^-  (each decision:accept @tas)
  =/  error  (inspect p c r objective model)
  ?^  error  [%| u.error]
  ?.  (passed:accept r)  [%| %native-checks-failed]
  ?.  ?&  (event-chain-valid:boxy workspace)
          =(event-seq.workspace (lent events.workspace))
          ?=(^ events.workspace)  ?=(^ head.workspace)
      ==  [%| %boxy-history-incomplete]
  =/  projected  (project-workspace:match workspace)
  =/  state=match-state:jm  match.projected
  ?.  &(?=(^ config.state) ?=(^ closure.state))  [%| %challenge-awaiting-resolution]
  =/  config=match-config:jm  u.config.state
  ?.  ?&  =(our host.config)  =(id.workspace match-id.config)
          (own-moon our ship.left.config)  (own-moon our ship.right.config)
          !=(ship.left.config ship.right.config)
          =(objective objective.config)
      ==  [%| %challenge-participants-or-objective-mismatch]
  ?.  &(?=(~ pending.state) =(%closed status.state))  [%| %challenge-awaiting-resolution]
  =/  bound=@t  (artifact c r objective)
  ?.  =(bound artifact.u.closure.state)  [%| %challenge-artifact-mismatch]
  =/  target  (move-for:juggler moves.state target.u.closure.state)
  ?~  target  [%| %challenge-target-missing]
  ?.  ?&  =(%propose kind.contribution.u.target)
          =(bound body.contribution.u.target)
          accepted.admission.u.target
          (challenged state u.target)
          (dual-accept:juggler state id.u.target)
      ==  [%| %challenge-unresolved]
  =/  challenge=challenge:accept
    :*  %native-coding-challenge-v1  id.c  (digest:accept r)  %passed
        ~[u.head.workspace (digest:accept state) (digest:accept (proposal c r objective model))]
        'Exact candidate and native checks challenged and accepted by both moon participants in canonical Boxy history.'
    ==
  =/  decision=decision:accept
    [%native-coding-decision-v1 id.c context.c basis.c r challenge %approve source.context.c at]
  ?.  (decision-valid:accept p c decision)  [%| %decision-invalid]
  [%& decision]
++  failure-text
  ::  Name each failed check with its native detail (for a failed compile,
  ::  the compiler trace) so the model can fix the cause. Bounded below the
  ::  decision's 8,192-byte reason limit.
  |=  r=report:accept
  ^-  @t
  =/  rows=(list @t)
    %-  zing
    %+  turn  targets.r
    |=  t=target-result:accept
    %+  murn  diagnostics.t
    |=  d=diagnostic:nc
    ?:  passed.d  ~
    `(rap 3 ~['\0a- ' name.target.t ' ' (spat entry.target.t) ' ' name.d ': ' detail.d])
  =/  out=@t  'Required native compilation or project checks failed; revise the candidate.'
  |-  ^-  @t
  ?~  rows  out
  =/  next=@t  (cat 3 out i.rows)
  ?:  (lte (met 3 next) 8.000)  $(rows t.rows, out next)
  (cat 3 (end [3 7.900] next) '\0a(remaining detail omitted)')
++  failed-checks
  ::  A negative native report can request revision without a fabricated
  ::  Boxy match. It never grants a write or claims the objective was met.
  |=  [at=@da p=project:nc c=candidate:nc r=report:accept]
  ^-  (each decision:accept @tas)
  ?.  (report-valid:accept p c r)  [%| %candidate-report-invalid]
  ?:  (passed:accept r)  [%| %challenge-required]
  =/  challenge=challenge:accept
    :*  %native-coding-challenge-v1  id.c  (digest:accept r)  %failed
        ~[(digest:accept r)]  (failure-text r)
    ==
  =/  decision=decision:accept
    [%native-coding-decision-v1 id.c context.c basis.c r challenge %revise source.context.c at]
  ?.  (decision-valid:accept p c decision)  [%| %decision-invalid]
  [%& decision]
++  negative
  ::  Preserve the original v1-only entry point.
  |=  $:  our=@p
          at=@da
          p=project:nc
          c=candidate:nc
          r=report:accept
          objective=@t
          model=@t
          workspace=workspace-state:bx
          actor=@p
          contribution=contribution:jm
          admission=admission:jm
          request=@ux
          receipt=@ux
          authority=@ux
      ==
  ^-  (each decision:accept @tas)
  (negative-checked our at p c r objective model workspace actor contribution admission request receipt authority ~)
++  negative-checked
  ::  The caller joins this exact settlement to Cantrip's canonical verdict
  ::  and the authenticated worker receipt. For v2 it also validates Cantrip's
  ::  retained inspection proof before supplying its exact context digest.
  ::  This pure gate does not authenticate that digest. A failed review is not a claim
  ::  that the unchanged native compilation/check report failed.
  |=  $:  our=@p
          at=@da
          p=project:nc
          c=candidate:nc
          r=report:accept
          objective=@t
          model=@t
          workspace=workspace-state:bx
          actor=@p
          contribution=contribution:jm
          admission=admission:jm
          request=@ux
          receipt=@ux
          authority=@ux
          inspected=(unit @ux)
      ==
  ^-  (each decision:accept @tas)
  =/  error  (inspect p c r objective model)
  ?^  error  [%| u.error]
  ?.  ?&  (own-moon our actor)  !=(0 receipt)  !=(0 authority)
          (event-chain-valid:boxy workspace)
          =(event-seq.workspace (lent events.workspace))  ?=(^ head.workspace)
          ?~  inspected
            =(law.admission 'native-ai-review-standing-scope-v1')
          &(=(u.inspected authority) =(law.admission 'native-ai-review-standing-scope-v2'))
          =(proposal-id.contribution proposal-id.admission)
          =(proposal-id.contribution (cat 3 'ai-review:' (scot %ux request)))
          ?=(%model-proposed -.author.contribution)
      ==  [%| %negative-review-evidence-invalid]
  =/  projected  (project-workspace:match workspace)
  =/  m=match-state:jm  match.projected
  ?~  config.m  [%| %negative-review-match-missing]
  =/  cfg=match-config:jm  u.config.m
  ?.  ?&  =(our host.cfg)  =(objective objective.cfg)  =(id.workspace match-id.cfg)
          (own-moon our ship.left.cfg)  (own-moon our ship.right.cfg)
          !=(ship.left.cfg ship.right.cfg)
          |(=(actor ship.left.cfg) =(actor ship.right.cfg))
          =(0 refused.projected)  ?=(~ pending.m)
      ==  [%| %negative-review-match-invalid]
  =/  matches=(list settlement:jm)
    %+  skim  settlements.m
    |=  v=settlement:jm
    &(=(actor actor.v) =(contribution contribution.v) =(admission admission.v))
  ?~  matches  [%| %negative-review-settlement-missing]
  ?.  ?=(~ t.matches)  [%| %negative-review-settlement-missing]
  ?.  |(!accepted.admission =(%refuse kind.contribution))  [%| %negative-review-not-refused]
  =/  reason=(each @t @tas)
    ?.  accepted.admission
      ?.  &(!=(0 reason.admission) (lte (met 3 reason.admission) 4.096))
        [%| %negative-review-reason-invalid]
      [%& (cat 3 'Cantrip refused this exact AI review contribution: ' (en:json:html s+reason.admission))]
    ?.  (lte (met 3 body.contribution) 8.192)  [%| %negative-review-body-invalid]
    =/  parsed  (de:json:html body.contribution)
    ?~  parsed  [%| %negative-review-body-invalid]
    ?.  ?&  =(`(artifact c r objective) (string:cr u.parsed 'artifact'))
            =(`(scot %ux request) (string:cr u.parsed 'request'))
            =(`(scot %ux receipt) (string:cr u.parsed 'receipt'))
        ==
      [%| %negative-review-body-mismatch]
    =/  text  (string:cr u.parsed 'reason')
    ?~  text  [%| %negative-review-reason-missing]
    ?.  &(!=(0 u.text) (lte (met 3 u.text) 4.096))  [%| %negative-review-reason-invalid]
    [%& (rap 3 ~['AI reviewer ' (scot %p actor) ' refused this exact candidate: ' (en:json:html s+u.text)])]
  ?:  ?=(%| -.reason)  [%| p.reason]
  =/  text=@t
    (cat 3 p.reason ' Native checks remain as recorded; this is negative review evidence, not a new compiler result. Address the stated issue within the existing objective and permissions, then propose a fresh candidate.')
  =/  challenge=challenge:accept
    :*  %native-coding-challenge-v1  id.c  (digest:accept r)  %failed
        ~[u.head.workspace (digest:accept i.matches) (digest:accept admission) authority receipt]  text
    ==
  =/  d=decision:accept
    [%native-coding-decision-v1 id.c context.c basis.c r challenge %revise source.context.c at]
  ?:((decision-valid:accept p c d) [%& d] [%| %negative-review-decision-invalid])
--
