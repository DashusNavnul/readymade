::  Public subscription discovery. No capability or credential secret is input.
/-  np=native-coding-provider
/+  provider=native-coding-provider
|%
+$  binding
  ::  Public wire boundary; private CLI runtime types are not dependencies.
  [key=@tas backend=?(%codex %claude) connector=@t active=?]
++  label
  |=  value=@t
  ^-  ?
  ?&  (gth (met 3 value) 0)  (lte (met 3 value) 64)
      (levy (trip value) |=(c=@t |(&((gte c 'a') (lte c 'z')) &((gte c '0') (lte c '9')) =(c '-'))))
  ==
++  selection
  |=  [key=@tas b=binding]
  ^-  (unit selection:np)
  ?.  &(active.b =(key key.b) (label key) (label connector.b))  ~
  =/  codex=?  =(%codex backend.b)
  =/  chosen=selection:np
    [%native-coding-provider-v1 ?:(codex %codex %anthropic) ?:(codex 'codex-cli' 'claude-cli') ?:(codex codex-cli-endpoint:np claude-cli-endpoint:np) ?:(codex %responses %messages) [%.n %.y %.n] key]
  ?.((selection-valid:provider chosen) ~ `chosen)
++  combine
  ::  API/CLI name collisions are omitted, never resolved by transport priority.
  ::  A revoked pairing also shadows any stale API entry under the same name.
  |=  [api=(map @tas selection:np) paired=(map @tas binding)]
  ^-  (map @tas selection:np)
  =/  out=(map @tas selection:np)
    %-  malt
    %+  skim  ~(tap by api)
    |=  [key=@tas s=selection:np]
    &((name-valid:provider key) (selection-valid:provider s) ?=(~ (cli-backend:provider s)))
  =/  todo  ~(tap by paired)
  |-  ^-  (map @tas selection:np)
  ?~  todo  out
  =/  key=@tas  p.i.todo
  =/  chosen  (selection key q.i.todo)
  =/  existing  (~(get by api) key)
  =.  out  (~(del by out) key)
  ?~  chosen  $(todo t.todo)
  ?:  &(?=(^ existing) !=(u.existing u.chosen))  $(todo t.todo)
  $(todo t.todo, out (~(put by out) key u.chosen))
--
