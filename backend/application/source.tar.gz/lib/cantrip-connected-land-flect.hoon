::  /lib/cantrip-connected-land-flect.hoon
::
::  The connected-land judge as law geometry (phase 11, the last lane).
::  The lane's act is everything +judge:cantrip-connected-land reads from
::  the record: the command, Viki's whole judgment ledger, the owner's
::  checks record and its observation, the stated intent and the current
::  basis.  The type-law says only that the act has the right shape; this
::  law adds one %run gate per predicate of the judge, at the axis of the
::  field it reads, in the judge's order, with the environment
::  [our actor at window].  The first miss names the judge's own refusal.
::  Nothing here scries: the gates run in mock.
::
/-  itn=intent
/+  flect, flect-law, land=cantrip-connected-land,
    judgment=viki-vibecoding-connected-judgment, checks=cantrip-connected-checks,
    law=cantrip-law-window
|%
+$  act
  $:  c=command:land  held=ledger:judgment  own=record:checks
      observed=observation:checks  stated=(unit record:itn)  current=basis:land
  ==
+$  env  [our=@p actor=@p at=@da w=window:law]
++  act-type  ^-  type  -:!>(*act)
::  Axes: command 2, ledger 6, own 14, observed 30, stated 62, current 63;
::  the whole act = 1.
++  actor-gate
  ^-  *
  |=  [a=* e=*]
  =/  n  ;;(env e)
  =(our.n actor.n)
++  select-gate
  ^-  *
  |=  [a=* e=*]
  =/  x  ;;(act a)
  =/  n  ;;(env e)
  =/  picked  (select:land our.n at.n held.x c.x)
  ?=(%& -.picked)
::  the checks record the retained judgment was made on
++  judged-record
  |=  [x=act n=env]
  ^-  (unit record:checks)
  =/  picked  (select:land our.n at.n held.x c.x)
  ?:  ?=(%| -.picked)  ~
  `record.body.judgment.p.picked
++  checks-gate
  ^-  *
  |=  [a=* e=*]
  =/  x  ;;(act a)
  =/  n  ;;(env e)
  =/  r  (judged-record x n)
  ?~  r  %.n
  &(=(u.r own.x) =(u.r record.observed.x))
++  stale-gate
  ^-  *
  |=  [a=* e=*]
  =/  x  ;;(act a)
  &(fresh.observed.x =(~ reason.observed.x))
++  intent-gate
  ^-  *
  |=  [a=* e=*]
  =/  x  ;;(act a)
  =/  n  ;;(env e)
  =/  r  (judged-record x n)
  ?~  r  %.n
  =(`intent.commitment.snapshot.compilation.u.r stated.x)
++  permission-gate
  ^-  *
  |=  [a=* e=*]
  =/  n  ;;(env e)
  (permission:land w.n)
++  admission-gate
  ^-  *
  |=  [a=* e=*]
  =/  x  ;;(act a)
  =/  n  ;;(env e)
  =/  picked  (select:land our.n at.n held.x c.x)
  ?:  ?=(%| -.picked)  %.n
  %-  admission-valid:land
  [%cantrip-connected-land-admission-v2 c.x our.n at.n p.picked current.x w.n]
++  gates
  ^-  law:flect-law
  :~  [1 %run actor-gate]
      [6 %run select-gate]
      [14 %run checks-gate]
      [30 %run stale-gate]
      [62 %run intent-gate]
      [1 %run permission-gate]
      [63 %run admission-gate]
  ==
++  land-law
  ^-  law:flect-law
  (weld (law-of:flect-law act-type) gates)
++  land-receipt
  |=  [a=act e=env]
  ^-  receipt:flect-law
  (judge-with:flect-law land-law !>(`act`a) e)
::  +reason: the first miss, as the judge would have said it
++  reason
  |=  [r=receipt:flect-law a=act e=env]
  ^-  (unit @tas)
  ?~  misses.verdict.r  ~
  =/  d  demand.i.misses.verdict.r
  ?.  ?=(%run -.d)  `%act-ill-shaped
  ?:  =(gate.d actor-gate)  `%foreign-actor
  ?:  =(gate.d select-gate)
    =/  picked  (select:land our.e at.e held.a c.a)
    ?:(?=(%| -.picked) `p.picked `%judgment-missing)
  ?:  =(gate.d checks-gate)  `%checks-mismatch
  ?:  =(gate.d stale-gate)  `%checks-stale
  ?:  =(gate.d intent-gate)  `%intent-changed
  ?:  =(gate.d permission-gate)  `%landing-not-admitted
  ?:  =(gate.d admission-gate)  `%landing-binding-invalid
  `%unknown-gate
--
