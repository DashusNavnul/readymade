::  Owner source delivery before project onboarding. Packaging has no effects.
::  The future owning app must persist change.record before emitting its card.
::  Snapshots are internal runtime inputs, NEVER public command arguments.
::  The owning app reads Clay and excludes public/active/protected/reserved
::  desks before begin and EVERY submit. No activation or desk.bill.
/-  nc=native-coding
/+  project=native-coding-project, utf8=native-coding-source-text
|%
+$  file  [pax=path mark=@tas size=@ud sha256=@ux]
+$  release  [%native-coding-source-release-v1 digest=@ux files=(list file)]
+$  upload  [file=file bytes=@t]
+$  batch  [release=@ux cursor=@ud files=(list upload)]
+$  request
  [%native-coding-source-import-v1 id=@ux owner=@p baseline=revision:nc release=release]
+$  snapshot
  [revision=revision:nc files=(map path lobe:clay) parents=(list tako:clay)]
+$  intent  [batch=batch before=snapshot expected=(map path lobe:clay)]
+$  receipt
  [cursor=@ud count=@ud before=revision:nc after=revision:nc blobs=(list [path lobe:clay])]
+$  record
  $:  request=request  origin=snapshot  current=snapshot  cursor=@ud
      receipts=(list receipt)  pending=(unit intent)
      phase=?(%staged %submitted %confirmed %unknown)  reason=@tas
  ==
+$  change  [record=record cards=(list card:agent:gall)]
::  The existing coding-moon qpc-formula source is 769,583 bytes. Delivery
::  admits that file without changing the separate compiler/tool input caps.
++  file-cap  1.048.576
++  batch-cap  2.097.152
++  release-cap  33.554.432
++  digest
  |=  files=(list file)
  ^-  @ux
  (shax (jam [%native-coding-source-release-v1 files]))
++  file-valid
  |=  f=file
  ^-  ?
  ?.  &((project-path pax.f) =(mark.f (rear pax.f)) (gth size.f 0) (lte size.f file-cap) !=(0 sha256.f) (lte (met 0 sha256.f) 256))  %.n
  ?:  =(%hoon mark.f)  ?=(?(%app %lib %sur %mar %ted %gen) (snag 0 pax.f))
  ?:  ?=(?(%js %css %html) mark.f)  =(%ui (snag 0 pax.f))
  ?.  =(%gls mark.f)  %.n
  ?=($?([%src *] [%compiler %src *] [%prelude %src *] [%gallowglass %src *] [%gallowglass %compiler %src *] [%gallowglass %prelude %src *]) pax.f)
++  project-path
  |=  pax=path
  ^-  ?
  &((gte (lent pax) 3) (lte (lent pax) 16) (path-valid:project pax))
++  release-valid
  |=  r=release
  ^-  ?
  ?&  (gte (lent files.r) 1)  (lte (lent files.r) 1.024)
      =(digest.r (digest files.r))  (levy files.r file-valid)
      =((lent files.r) ~(wyt in (silt (turn files.r |=(f=file pax.f)))))
      (lte (roll files.r |=([f=file total=@ud] (add total size.f))) release-cap)
  ==
++  request-valid
  |=  r=request
  ^-  ?
  ?&  !=(0 id.r)  (lte (met 0 id.r) 256)
      =(owner.r owner.baseline.r)  (revision-valid:project baseline.r)
      !=(%base desk.baseline.r)  !=(%$ desk.baseline.r)
      (release-valid release.r)
  ==
++  snapshot-valid
  |=  s=snapshot
  ^-  ?
  &((revision-valid:project revision.s) (lte ~(wyt by files.s) 4.096) (lte (lent parents.s) 4.096))
++  upload-valid
  |=  u=upload
  ^-  ?
  ?.  &((file-valid file.u) =(size.file.u (met 3 bytes.u)) =(sha256.file.u (shax bytes.u)))  %.n
  (valid:utf8 bytes.u)
++  blob
  |=  u=upload
  ^-  lobe:clay
  (page-to-lobe:clay [mark.file.u bytes.u])
++  overlay
  |=  [before=(map path lobe:clay) files=(list upload)]
  ^-  (map path lobe:clay)
  ?~  files  before
  $(before (~(put by before) pax.file.i.files (blob i.files)), files t.files)
++  batch-valid
  |=  [r=record b=batch]
  ^-  ?
  ?&  =(release.b digest.release.request.r)  =(cursor.b cursor.r)
      (gte (lent files.b) 1)  (lte (lent files.b) 5)
      (lte (add cursor.r (lent files.b)) (lent files.release.request.r))
      =((turn files.b |=(u=upload file.u)) (scag (lent files.b) (slag cursor.r files.release.request.r)))
      (levy files.b upload-valid)
      (lte (roll files.b |=([u=upload total=@ud] (add total size.file.u))) batch-cap)
  ==
++  same-desk
  |=  [a=revision:nc b=revision:nc]
  ^-  ?
  &(=(owner.a owner.b) =(desk.a desk.b))
++  overlay-blobs
  |=  [files=(map path lobe:clay) blobs=(list [p=path q=lobe:clay])]
  ^-  (map path lobe:clay)
  ?~  blobs  files
  $(files (~(put by files) p.i.blobs q.i.blobs), blobs t.blobs)
++  history-valid
  |=  [r=record rows=(list receipt) cursor=@ud previous=revision:nc files=(map path lobe:clay)]
  ^-  ?
  ?~  rows
    &(=(cursor cursor.r) =(previous revision.current.r) =(files files.current.r))
  =/  row=receipt  i.rows
  ?.  ?&  =(cursor cursor.row)  =(previous before.row)
          (gte count.row 1)  (lte count.row 5)
          (lte (add cursor count.row) (lent files.release.request.r))
          (revision-valid:project after.row)  (same-desk previous after.row)
          ?|(=(previous after.row) =(+(number.previous) number.after.row))
          =(count.row (lent blobs.row))
          =((turn (scag count.row (slag cursor files.release.request.r)) |=(f=file pax.f)) (turn blobs.row |=([p=path q=lobe:clay] p)))
      ==  %.n
  =/  next=(map path lobe:clay)  (overlay-blobs files blobs.row)
  ?.  ?|(=(+(number.previous) number.after.row) =(files next))  %.n
  $(rows t.rows, cursor (add cursor count.row), previous after.row, files next)
++  valid
  |=  r=record
  ^-  ?
  ?.  ?&  (request-valid request.r)  (snapshot-valid origin.r)
          (snapshot-valid current.r)  =(baseline.request.r revision.origin.r)
          (same-desk revision.origin.r revision.current.r)
          (lte cursor.r (lent files.release.request.r))
          (lte (lent receipts.r) 1.024)
          (history-valid r receipts.r 0 revision.origin.r files.origin.r)
      ==  %.n
  ?~  pending.r  =(%confirmed phase.r)
  ?&  ?=(?(%staged %submitted %unknown) phase.r)
      =(before.u.pending.r current.r)  (batch-valid r batch.u.pending.r)
      =(expected.u.pending.r (overlay files.current.r files.batch.u.pending.r))
      (lte ~(wyt by expected.u.pending.r) 4.096)
  ==
++  begin
  |=  [our=@p actor=@p r=request before=snapshot]
  ^-  (each record @tas)
  ?.  &(=(our actor) =(our owner.r) (request-valid r))  [%| %source-import-owner-required]
  ?.  &((snapshot-valid before) =(baseline.r revision.before))  [%| %source-import-baseline-changed]
  [%& [r before before 0 ~ ~ %confirmed %source-import-baseline-retained]]
++  stage
  ::  Pure preparation. The caller retains the returned intent; no write yet.
  |=  [our=@p actor=@p r=record b=batch]
  ^-  (each record @tas)
  ?.  &(=(our actor) =(our owner.request.r))  [%| %source-import-owner-required]
  ?.  (valid r)  [%| %source-import-record-invalid]
  ?.  &(=(%confirmed phase.r) ?=(~ pending.r))  [%| %source-import-batch-held]
  ?.  (batch-valid r b)  [%| %source-import-batch-invalid]
  =/  expected  (overlay files.current.r files.b)
  ?:  (gth ~(wyt by expected) 4.096)  [%| %source-import-namespace-bound]
  [%& r(pending `[b current.r expected], phase %staged, reason %source-import-batch-staged)]
++  finish
  |=  [r=record after=snapshot]
  ^-  record
  ?>  ?=(^ pending.r)
  ?>  &((snapshot-valid after) (same-desk revision.current.r revision.after) =(files.after expected.u.pending.r))
  ?>  ?|(=(after current.r) &(=(number.revision.after +(number.revision.current.r)) =(parents.after ~[commit.revision.current.r])))
  =/  b=batch  batch.u.pending.r
  =/  done=receipt
    [cursor.r (lent files.b) revision.current.r revision.after (turn files.b |=(u=upload [pax.file.u (blob u)]))]
  r(current after, cursor (add cursor.r (lent files.b)), receipts (snoc receipts.r done), pending ~, phase %confirmed, reason %source-import-batch-confirmed)
++  submit
  ::  One effect per staged intent. Persist the submitted state atomically
  ::  before emitting the returned card; neither reload nor observe resends it.
  |=  [our=@p actor=@p r=record current=snapshot]
  ^-  (each change @tas)
  ?.  &(=(our actor) =(our owner.request.r))  [%| %source-import-owner-required]
  ?.  (valid r)  [%| %source-import-record-invalid]
  ?.  &(=(%staged phase.r) ?=(^ pending.r))  [%| %source-import-not-staged]
  ?.  =(current before.u.pending.r)  [%| %source-import-baseline-changed]
  ?:  =(files.current expected.u.pending.r)
    [%& [(finish r current) ~]]
  =/  edits=(list [path miso:clay])
    %+  murn  files.batch.u.pending.r
    |=  u=upload
    =/  old  (~(get by files.current) pax.file.u)
    ?:  =(`(blob u) old)  ~
    ?~  old
      `[pax.file.u %ins mark.file.u !>(bytes.u)]
    `[pax.file.u %mut mark.file.u !>(bytes.u)]
  =/  card=card:agent:gall
    [%pass /native-source-import/(scot %ux id.request.r)/(scot %ud cursor.r) %arvo %c %info desk.baseline.request.r [%& edits]]
  [%& [r(phase %submitted, reason %source-import-write-submitted) ~[card]]]
++  observe
  |=  [our=@p actor=@p r=record current=(unit snapshot)]
  ^-  (each record @tas)
  ?.  &(=(our actor) =(our owner.request.r))  [%| %source-import-owner-required]
  ?.  (valid r)  [%| %source-import-record-invalid]
  ?.  &(?=(?(%submitted %unknown) phase.r) ?=(^ pending.r))  [%| %source-import-no-write-pending]
  ?~  current  [%& r(phase %unknown, reason %source-import-observation-unavailable)]
  =/  old=snapshot  before.u.pending.r
  ?:  =(u.current old)  [%& r(phase %unknown, reason %source-import-write-unconfirmed)]
  ?.  ?&  (snapshot-valid u.current)  (same-desk revision.old revision.u.current)
          =(number.revision.u.current +(number.revision.old))
          =(parents.u.current ~[commit.revision.old])
          =(files.u.current expected.u.pending.r)
      ==
    [%& r(phase %unknown, reason %source-import-write-conflict)]
  [%& (finish r u.current)]
++  complete
  |=  r=record
  ^-  ?
  &(=(%confirmed phase.r) ?=(~ pending.r) =(cursor.r (lent files.release.request.r)))
--
