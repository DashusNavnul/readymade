::  Resolve the project for one retained session. A workspace preparation that
::  exists but is not ready must never fall back to the shared working desk.
/-  nc=native-coding
/+  project=native-coding-project, guard=viki-scry-guard
|%
++  resolve
  |=  [our=@p now=@da registered=(map @t project:nc) session=@ux id=@t]
  ^-  (each project:nc @tas)
  =/  base  (~(get by registered) id)
  ?~  base  [%| %project-missing]
  ?.  (agent-live:guard our now %viki)  [%| %session-workspace-unavailable]
  =/  scoped=(unit (each project:nc @tas))
    .^((unit (each project:nc @tas)) %gx /(scot %p our)/viki/(scot %da now)/native-coding/session-project/(scot %ux session)/noun)
  ?~  scoped  [%& u.base]
  ?:  ?=(%| -.u.scoped)  u.scoped
  =/  selected=project:nc  p.u.scoped
  ?.  &((valid:project selected) =(selected u.base(working working.selected)))
    [%| %session-workspace-project-changed]
  [%& selected]
--
