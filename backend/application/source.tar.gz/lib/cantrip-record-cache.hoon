::  /lib/cantrip-record-cache
::
::  Cantrip's complete rebuild law.  Every accepted record is the exact Graf
::  fact [kind id body]; the record id is both its idempotency key and the key
::  that gives replay a deterministic order independent of poke arrival.
::
/+  cw=cantrip-law-window
|%
+$  record  [kind=@tas id=@t body=*]
+$  ledger
  $:  records=(map @t @)
      conflicts=(set @t)
  ==
+$  cache
  $:  residue=residue:cw
      streak=@ud
      health=(unit @ud)
      records=(map @t @)
      conflicts=(set @t)
  ==
::
++  record-kinds
  ^-  (set @tas)
  %-  silt
  ^-  (list @tas)
  :~  %loom-turn
      %verify-pass
      %verify-failure
      %rival
      %rival-resolved
      %blocker
      %blocker-cleared
      %health-sample
  ==
++  empty
  ^-  cache
  [*residue:cw 0 ~ ~ ~]
++  legacy-fallback
  |=  old=judgment
  ^-  cache
  ::  Pre-citation judgment cannot be promoted into cited state.  The argument
  ::  is kept explicit so the migration proof can show nonempty history dies.
  empty
++  valid
  |=  r=record
  ^-  ?
  (~(has in record-kinds) kind.r)
++  fact-of
  |=  r=record
  ^-  *
  r
::  Build one record per id.  Identical replay is inert.  Conflicting reuse
::  removes the id entirely and leaves a permanent, explicit conflict.
++  index
  |=  records-in=(list record)
  ^-  ledger
  %+  roll  records-in
  |=  [r=record acc=ledger]
  ?.  (valid r)  acc
  ?:  (~(has in conflicts.acc) id.r)  acc
  =/  prior=(unit @)  (~(get by records.acc) id.r)
  ?~  prior
    acc(records (~(put by records.acc) id.r (jam r)))
  ?:  =(u.prior (jam r))  acc
  =/  next-records=(map @t @)  (~(del by records.acc) id.r)
  =/  next-conflicts=(set @t)  (~(put in conflicts.acc) id.r)
  [next-records next-conflicts]
::
+$  judgment
  [residue=residue:cw streak=@ud health=(unit @ud)]
++  apply-record
  |=  [r=record j=judgment]
  ^-  judgment
  =/  next-residue=residue:cw  residue.j
  =/  next-streak=@ud  streak.j
  =/  next-health=(unit @ud)  health.j
  =?  next-residue  =(%loom-turn kind.r)
    next-residue(turn +(turn.next-residue))
  =?  next-residue  =(%verify-failure kind.r)
    next-residue(contraindications +(contraindications.next-residue))
  =?  next-streak  =(%verify-failure kind.r)  0
  =?  next-residue  =(%verify-pass kind.r)
    next-residue(contraindications 0)
  =?  next-streak  =(%verify-pass kind.r)  +(next-streak)
  =?  next-residue  =(%rival kind.r)
    next-residue(rivals +(rivals.next-residue))
  =?  next-residue  =(%rival-resolved kind.r)
    next-residue(rivals ?:(=(0 rivals.next-residue) 0 (dec rivals.next-residue)))
  =?  next-residue  =(%blocker kind.r)
    next-residue(blockers +(blockers.next-residue))
  =?  next-residue  =(%blocker-cleared kind.r)
    next-residue(blockers ?:(=(0 blockers.next-residue) 0 (dec blockers.next-residue)))
  =?  next-health  =(%health-sample kind.r)
    =/  parsed=(unit @ud)  ((soft @ud) body.r)
    ?~(parsed next-health parsed)
  [next-residue next-streak next-health]
::  Map traversal fixes one total replay order by id.  Input fact order, poke
::  interleaving, and restart therefore cannot change the rebuilt judgment.
++  rebuild
  |=  records-in=(list record)
  ^-  cache
  =/  ledger=ledger  (index records-in)
  =/  judged=judgment
    %+  roll  ~(tap by records.ledger)
    |=  [entry=[id=@t jammed=@] acc=judgment]
    =/  r=record  ;;(record (cue jammed.entry))
    (apply-record r acc)
  [residue.judged streak.judged health.judged records.ledger conflicts.ledger]
++  cited
  |=  [c=cache r=record]
  ^-  ?
  ?:  (~(has in conflicts.c) id.r)  %.n
  =/  found=(unit @)  (~(get by records.c) id.r)
  ?~(found %.n =(u.found (jam r)))
++  decode-records
  |=  raw=(list *)
  ^-  (unit (list record))
  =|  out=(list record)
  |-  ^-  (unit (list record))
  ?~  raw  `(flop out)
  =/  parsed=(each record tang)
    %-  mule
    |.(;;(record i.raw))
  ?-  -.parsed
    ::  Graf's by-kind index is shared with older domain facts.  A row whose
    ::  tail is not the exact [id=@t body=*] law-record envelope is unrelated,
    ::  not a partial law history.  Read failure still fails closed in the
    ::  caller; only a successfully read, structurally foreign row is skipped.
    %|  $(raw t.raw)
    %&  $(raw t.raw, out [p.parsed out])
  ==
--
