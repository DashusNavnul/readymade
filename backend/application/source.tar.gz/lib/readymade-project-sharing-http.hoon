::  Bounded owner HTTP commands. Parsing grants no authority or permission.
/+  sharing=readymade-project-sharing, mg=readymade-app-management,
    terminal=native-coding-terminal
|%
++  ship
  |=  text=@t
  ^-  @p
  =/  value=@p  (need (slaw %p text))
  ?>  =(text (scot %p value))
  value
++  paths
  ::  LF-separated absolute Clay paths; no aliases or duplicate selections.
  |=  text=@t
  ^-  (set path)
  =|  selected=(set path)
  |-  ^-  (set path)
  ?>  &(!=('' text) (lth ~(wyt in selected) 8))
  =/  part  (split:terminal 10 text)
  =/  pax=path  (path-of:terminal ~ head.part)
  ?>  =(head.part (spat pax))
  ?>  !(~(has in selected) pax)
  =.  selected  (~(put in selected) pax)
  ?.  found.part  selected
  $(text tail.part)
++  decode
  |=  raw=@t
  ^-  command:sharing
  ?>  (lte (met 3 raw) 8.192)
  =/  value=json  (need (de:json:html raw))
  ?>  ?=(%o -.value)
  =/  obj=(map @t json)  p.value
  =/  fields=@ud  ~(wyt by obj)
  ::  All values are strings. Extra colons reject duplicate/nested keys.
  ?>  =(fields (lent (skim (trip raw) |=(c=@t =(c ':')))))
  ?>  =('readymade-project-sharing-v1' (text-field:mg obj 'schema' 64))
  =/  request=@t  (text-field:mg obj 'request' 36)
  =/  owner=@p  (ship (text-field:mg obj 'owner' 128))
  =/  project=@t  (text-field:mg obj 'project' 128)
  =/  peer=@p  (ship (text-field:mg obj 'peer' 128))
  =/  expected-text=@t  (text-field:mg obj 'expected' 81)
  =/  expected=@ux  (need (slaw %ux expected-text))
  ?>  =(expected-text (scot %ux expected))
  =/  operation=@t  (text-field:mg obj 'operation' 16)
  =/  selection=selection:sharing
    ?:  =('revoke' operation)
      ?>  =(8 fields)
      =/  text=@t  (text-field:mg obj 'generation' 32)
      =/  generation=@ud  (need (slaw %ud text))
      ?>  =(text (scot %ud generation))
      [%revoke generation]
    ?>  &(=('grant' operation) =(10 fields))
    =/  desk=@tas  (text-field:mg obj 'desk' 64)
    ?>  (desk-valid:mg desk)
    =/  selected=(set path)  (paths (text-field:mg obj 'paths' 4.096))
    =/  permission=@t  (text-field:mg obj 'permission' 16)
    ?>  ?=(?(%view %suggest %view-suggest) permission)
    [%grant desk selected [!=(permission %suggest) !=(permission %view)]]
  =/  command=command:sharing  [request owner project peer expected selection]
  ?>  (valid:sharing command)
  command
++  parse
  |=  raw=@t
  ^-  (unit command:sharing)
  (mole |.((decode raw)))
++  post-request
  |=  req=inbound-request:eyre
  ^-  (unit command:sharing)
  ?.  &(authenticated.req =('POST' method.request.req))  ~
  =/  host  (header:mg header-list.request.req 'host')
  =/  origin  (header:mg header-list.request.req 'origin')
  =/  mime  (header:mg header-list.request.req 'content-type')
  ?~  host  ~
  ?~  origin  ~
  ?~  mime  ~
  ?.  ?&  =(u.origin (cat 3 ?:(secure.req 'https://' 'http://') u.host))
          |(=(u.mime 'application/json') =(u.mime 'application/json; charset=utf-8'))
      ==  ~
  ?.  =(`'v1' (header:mg header-list.request.req 'x-readymade-project-sharing'))  ~
  ?~  body.request.req  ~
  =/  body  u.body.request.req
  ?.  &((lte p.body 8.192) =(p.body (met 3 q.body)))  ~
  (parse q.body)
++  result-request
  |=  req=inbound-request:eyre
  ^-  (unit @t)
  ?.  &(authenticated.req =('GET' method.request.req))  ~
  =/  id  (header:mg header-list.request.req 'x-readymade-project-request')
  ?~  id  ~
  ?:((uuid:mg u.id) id ~)
++  read-request
  |=  req=inbound-request:eyre
  ^-  (unit [project=@t peer=@p])
  ?.  &(authenticated.req =('GET' method.request.req))  ~
  =/  project  (header:mg header-list.request.req 'x-readymade-project')
  =/  peer  (header:mg header-list.request.req 'x-readymade-project-peer')
  ?~  project  ~
  ?~  peer  ~
  ?.  &(!=('' u.project) (lte (met 3 u.project) 128))  ~
  =/  parsed  (mole |.((ship u.peer)))
  ?~  parsed  ~
  `[u.project u.parsed]
++  snapshot
  ::  One peer's metadata only; membership does not imply source permission.
  |=  [o=observation:sharing peer=@p]
  ^-  json
  =/  held  (~(get by held.o) [id.spec.catalog.o peer])
  =/  grant=json
    ?~  held  ~
    =/  g  grant.u.held
    %-  pairs:enjs:format
    :~  ['generation' s+(scot %ud generation.g)]
        ['desk' s+desk.g]
        ['paths' a+(turn ~(tap in paths.g) |=(p=path s+(spat p)))]
        ['view' b+view.permissions.g]
        ['suggest' b+suggest.permissions.g]
        ['revoked' b+revoked.u.held]
    ==
  %-  pairs:enjs:format
  :~  ['schema' s+'readymade-project-sharing-view-v1']
      ['owner' s+(scot %p owner.o)]
      ['project' s+id.spec.catalog.o]
      ['peer' s+(scot %p peer)]
      ['expected' s+(scot %ux (stamp:sharing o))]
      ['member' b+(~(has by members.catalog.o) peer)]
      ['baseDesk' s+base-desk.spec.catalog.o]
      ['workingDesk' ?~(scope.o ~ s+working.u.scope.o)]
      ['grant' grant]
  ==
++  view
  ::  Only canonical observation confirms a retained command. No source body.
  |=  [o=observation:sharing r=record:sharing]
  ^-  json
  %-  pairs:enjs:format
  :~  ['schema' s+'readymade-project-sharing-result-v1']
      ['request' s+request.command.r]
      ['owner' s+(scot %p owner.command.r)]
      ['project' s+project.command.r]
      ['peer' s+(scot %p peer.command.r)]
      ['operation' s+-.selection.command.r]
      ['intent' s+(scot %ux intent.r)]
      ['status' s+(outcome:sharing o r)]
  ==
--
