::  /lib/bride-judgment.hoon
::
::  The Bride is the ship-side final judgment boundary. Bachelor output and
::  local review verdicts are evidence; neither can authorize canon alone.
::  A judgment binds the exact task, instructions, round, submissions, and
::  verdicts, and returns the only canon noun Waterwheel may engrave.
::
/+  jg=juggler-gravity
|%
+$  growth  [gsub=grow-sub:jg desc=@t]
+$  judgment
  $:  accepted=?
      code=@tas
      reason=@t
      case-mug=@uv
      canon=(unit @t)
  ==
+$  candidate
  $%  [%work task=@t instructions=@t round=@ud subs=(list submission:jg) verdicts=(list verdict:jg)]
      [%grow task=@t instructions=@t round=@ud grows=(list growth) verdicts=(list verdict:jg)]
  ==
+$  bound-judgment
  $:  evidence-digest=@ux
      decision=judgment
  ==
++  max-workers  9
++  max-intent-bytes  16.384
++  max-evidence-bytes  65.536
::
++  refuse
  |=  [code=@tas reason=@t case-mug=@uv]
  ^-  judgment
  [%.n code reason case-mug ~]
::
++  workers-match
  |=  [subs=(list submission:jg) verdicts=(list verdict:jg)]
  ^-  ?
  ?~  subs  ?~(verdicts %.y %.n)
  ?~  verdicts  %.n
  ?&  =(worker.i.subs worker.i.verdicts)
      $(subs t.subs, verdicts t.verdicts)
  ==
::
++  growth-workers-match
  |=  [grows=(list growth) verdicts=(list verdict:jg)]
  ^-  ?
  ?~  grows  ?~(verdicts %.y %.n)
  ?~  verdicts  %.n
  ?&  =(worker.gsub.i.grows worker.i.verdicts)
      $(grows t.grows, verdicts t.verdicts)
  ==
::
++  join-canon
  |=  subs=(list submission:jg)
  ^-  @t
  %+  roll  subs
  |=  [sub=submission:jg acc=@t]
  ?:(=(0 (met 3 acc)) output.sub (rap 3 acc '\0a' output.sub ~))
::
++  decide
  |=  $:  task=@t
          instructions=@t
          round=@ud
          subs=(list submission:jg)
          verdicts=(list verdict:jg)
      ==
  ^-  judgment
  =/  case-mug=@uv  (mug [%work task instructions round subs verdicts])
  ?:  ?|(=(0 (met 3 task)) =(0 (met 3 instructions)))
    (refuse %unbound-intent 'Bride refused: task or instructions are empty' case-mug)
  ?:  ?|(=(0 (lent subs)) !=((lent subs) (lent verdicts)))
    (refuse %incomplete-review 'Bride refused: every submission requires one review verdict' case-mug)
  ?.  (workers-match subs verdicts)
    (refuse %misbound-review 'Bride refused: review workers do not match the submitted labor' case-mug)
  ?.  (levy verdicts |=(verdict=verdict:jg accepted.verdict))
    (refuse %review-refused 'Bride refused: at least one bounded review rejected the labor' case-mug)
  ?.  (levy subs |=(sub=submission:jg (gth (met 3 output.sub) 0)))
    (refuse %empty-labor 'Bride refused: empty labor cannot enter canon' case-mug)
  =/  canon=@t  (join-canon subs)
  [%.y %accepted 'Bride accepted the exact reviewed round for canon' case-mug `canon]
::
++  decide-grow
  |=  $:  task=@t
          instructions=@t
          round=@ud
          grows=(list growth)
          verdicts=(list verdict:jg)
      ==
  ^-  judgment
  =/  case-mug=@uv  (mug [%grow task instructions round grows verdicts])
  ?:  ?|(=(0 (met 3 task)) =(0 (met 3 instructions)))
    (refuse %unbound-intent 'Bride refused growth: task or instructions are empty' case-mug)
  ?:  ?|(=(0 (lent grows)) !=((lent grows) (lent verdicts)))
    (refuse %incomplete-review 'Bride refused growth: every proposal requires one review verdict' case-mug)
  ?.  (growth-workers-match grows verdicts)
    (refuse %misbound-review 'Bride refused growth: review workers do not match the proposals' case-mug)
  ?.  (levy verdicts |=(verdict=verdict:jg accepted.verdict))
    (refuse %review-refused 'Bride refused growth: at least one bounded review rejected the proposal' case-mug)
  ?.  (levy grows |=(growth=growth (gth (met 3 desc.growth) 0)))
    (refuse %empty-labor 'Bride refused growth: every accepted proposal needs a description' case-mug)
  [%.y %accepted 'Bride accepted the exact reviewed growth round for bounded commit' case-mug ~]
::
::  This gate runs before hashing or judging an externally supplied candidate.
::  It bounds every list and cord that the decision arms subsequently scan.
++  bounded-candidate
  |=  item=candidate
  ^-  ?
  ?:  ?|  (gth (met 3 task.item) max-intent-bytes)
          (gth (met 3 instructions.item) max-intent-bytes)
      ==
    %.n
  ?-  -.item
    %work
      ?&  (lte (lent subs.item) max-workers)
          (lte (lent verdicts.item) max-workers)
          (levy subs.item |=(sub=submission:jg (lte (met 3 output.sub) max-evidence-bytes)))
          (levy verdicts.item |=(verdict=verdict:jg (lte (met 3 reason.verdict) max-evidence-bytes)))
      ==
    %grow
      ?&  (lte (lent grows.item) max-workers)
          (lte (lent verdicts.item) max-workers)
          %+  levy  grows.item
          |=  item=growth
          ?&  (lte (met 3 desc.item) max-evidence-bytes)
              (lte (met 3 src.gsub.item) max-evidence-bytes)
          ==
          (levy verdicts.item |=(verdict=verdict:jg (lte (met 3 reason.verdict) max-evidence-bytes)))
      ==
  ==
::
::  The shared identity gate lets a caller bind a later sovereign decision to
::  the exact candidate without re-running the Bride's decision function.
++  candidate-digest
  |=  item=candidate
  ^-  (unit @ux)
  ?.  (bounded-candidate item)  ~
  `(shax (jam [%bride-judgment-candidate-v1 item]))
::
::  The SHA-256 identity and decision are born from the same typed candidate.
::  Over-budget candidates have no judgment and therefore no canon authority.
++  adjudicate
  |=  item=candidate
  ^-  (unit bound-judgment)
  =/  evidence-digest=(unit @ux)  (candidate-digest item)
  ?~  evidence-digest  ~
  =/  decision=judgment
    ?-  -.item
      %work
        (decide task.item instructions.item round.item subs.item verdicts.item)
      %grow
        (decide-grow task.item instructions.item round.item grows.item verdicts.item)
    ==
  `[u.evidence-digest decision]
--
