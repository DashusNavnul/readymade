::  Pure collection-to-execution binding. No cards, command or authority.
::  The native owner must persist +open BEFORE provider dispatch, supply its
::  canonical journal positions/stores, authenticate admission receipts, and
::  recheck Cantrip immediately before effects. Hashes alone prove none of this.
::  Before +open the owner must authenticate the exact task, objective,
::  evaluator source/version and criterion weights against frozen declarations.
::  This layer uses qpc-energy-v1; it does not validate arbitrary objective
::  profiles or prove that scorer-source names this evaluator's actual code.
/-  nc=native-coding
/+  decision=qpc-decision, window=qpc-window, admission=qpc-measurement-contract,
    law=qpc-law-core, pool=qpc-native-pool, energy=qpc-energy,
    tools=cantrip-native-coding-contract, files=native-coding-files,
    successor=qpc-successor-window
|%
+$  prefix
  $%  state:window
      state:successor
  ==
+$  reading
  [epoch=@ux live=(list point:window) reference=(list point:window)]
+$  opening
  $:  owner=@p  project=@t  configuration=@ux  source=revision:nc
      session=@ux  request=@ux  request-digest=@ux  grant=@ux  authority=@ux
      task=@ux  objective=@ux  scorer=%qpc-energy-v1  scorer-source=@ux
      required=(list @tas)  position=@ud
      law=revision:law  prefix=prefix
  ==
+$  generation
  [opening=@ux position=@ud request=@ux request-digest=@ux receipt=@ux]
+$  current  [source=revision:nc epoch=@ux authority=@ux]
+$  check  [name=@tas outcome=outcome:decision]
+$  admission-receipt
  $:  id=@ux  opening=@ux  candidate=@ux  effect=@ux
      source=revision:nc  authority=@ux  position=@ud  checks=(list check)
  ==
+$  offered  [tool=record:tools admission=admission-receipt]
+$  scored  [evidence=offered energy=energy:energy]
+$  mapping
  $:  %qpc-execution-mapping-v1  id=@ux  decision=@ux  pool=@ux
      collection-session=@ux  collection-request=@ux  collection-tool=@ux
      candidate=@ux  effect=@ux  grant=@ux  request=tool-request:nc
      tool=@ux  admission=admission-receipt  needs-admission=?
  ==
+$  completion
  $:  mapping=@ux  tool=@ux
      kind=?(%applied %failed %refused %cancelled %unknown)  evidence=@ux
      candidate=(unit candidate:nc)  resulting=(unit revision:nc)
  ==
+$  state
  $:  %qpc-native-decision-v1  id=@ux  frozen=opening  core=state:decision
      generation=(unit generation)  pool=(unit pool:pool)  sealed=(unit @ud)
      candidates=(list scored)  chosen-at=(unit @ud)
      released=(unit mapping)  result=(unit completion)
  ==
++  digest  |=(v=* ^-(@ux (shax (jam [%qpc-native-decision-v1 v]))))
++  source-digest  |=(v=revision:nc (digest:admission v))
++  effect
  |=  c=candidate:nc
  (digest:pool [%effect-v1 revision.basis.c accepted.c edits.c])
++  observations
  ::  The core uses settled sources; the retained prefix keeps predictions too.
  |=  [epoch=@ux points=(list point:window)]
  ^-  (list observation:decision)
  %+  turn  points
  |=  p=point:window
  [id.row.p step.row.p work.row.p resulting-source.row.p epoch segment.row.p law.row.p confidence.row.p outcomes.row.p]
++  prefix-binding
  |=  p=prefix
  ^-  [instrument=@ux stream=@ux manifest=@ux]
  ?:  ?=([%qpc-successor-window-v1 *] p)
    [instrument.binding.p stream.binding.p manifest.binding.p]
  [instrument.binding.p stream.binding.p manifest.binding.p]
++  read-prefix
  ::  Keep the actual immutable policy state in the opening. This projection
  ::  feeds shared arithmetic only; it never constructs a legacy window.
  |=  [p=prefix source=@ux]
  ^-  (each reading @tas)
  ?:  ?=([%qpc-successor-window-v1 *] p)
    ?.  (valid:successor p)  [%| %qpc-prefix-invalid]
    =/  got  (current:successor p source)
    ?:  ?=(%| -.got)  [%| p.got]
    =/  e=epoch:successor  (need reference.p)
    [%& [id.e live.p.got reference.e]]
  ?.  (valid:window p)  [%| %qpc-prefix-invalid]
  ?~  reference.p  [%| %qpc-reference-unavailable]
  ?~  measured.p  [%| %qpc-reading-unavailable]
  ?.  =(source.p `source)  [%| %qpc-settled-source-mismatch]
  [%& [id.u.reference.p live.u.measured.p reference.u.reference.p]]
++  open
  ::  IDs commit owner-authenticated declarations; nonzero is not admission.
  |=  f=opening
  ^-  (each state @tas)
  ?.  ?&  (levy `(list @ux)`~[configuration.f session.f request.f request-digest.f grant.f authority.f task.f objective.f scorer-source.f] identifier:decision)
          =(owner.f owner.source.f)  !=(%$ project.f)
          (lte (met 0 position.f) 64)
          (gte (lent required.f) 1)  (lte (lent required.f) 16)
          (levy required.f |=(n=@tas !=(%$ n)))
          =((lent required.f) ~(wyt in (silt required.f)))
      ==  [%| %qpc-opening-invalid]
  ?.  &((valid:law law.f) =(owner.f actor.law.f))
    [%| %qpc-frozen-law-invalid]
  =/  b  (prefix-binding prefix.f)
  ?.  ?&  =(instrument.b instrument.binding.law.f)
          =(stream.b session.binding.law.f)
          =(manifest.b objective.binding.law.f)
          =(project.f project.binding.law.f)
      ==  [%| %qpc-law-prefix-mismatch]
  =/  got  (read-prefix prefix.f (source-digest source.f))
  ?:  ?=(%| -.got)  [%| p.got]
  =/  r=reading  p.got
  =/  bound=binding:decision
    [configuration.f session.f (source-digest source.f) epoch.r manifest.b id.law.f authority.f]
  =/  opened
    (open:decision bound 2 16 gain.parameters.law.f (observations epoch.r live.r) (observations epoch.r reference.r))
  ?:  ?=(%| -.opened)  [%| p.opened]
  =/  s=state  *state
  [%& s(id (digest f), frozen f, core p.opened)]
++  fresh
  |=  [s=state now=current]
  ?&  =(source.now source.frozen.s)
      =(epoch.now epoch.binding.core.s)
      =(authority.now authority.frozen.s)
  ==
++  admission-valid
  ::  Consistency only. The owner must read authentic current Cantrip evidence.
  |=  [s=state a=admission-receipt candidate=@ux effect=@ux]
  ?&  =(id.a (digest a(id 0x0)))  =(id.s opening.a)
      =(candidate candidate.a)  =(effect effect.a)
      =(source.frozen.s source.a)  =(authority.frozen.s authority.a)
      (lte (met 0 position.a) 64)
      =(required.frozen.s (turn checks.a |=(c=check name.c)))
      %+  levy  checks.a
      |=  c=check
      ?:  =(%unknown verdict.outcome.c)  =(0 evidence.outcome.c)
      (identifier:decision evidence.outcome.c)
  ==
++  passed
  |=  a=admission-receipt
  (levy checks.a |=(c=check =(%pass verdict.outcome.c)))
++  bind
  |=  [s=state p=pool:pool g=generation sealed=@ud values=(list offered) now=current]
  ^-  (each state @tas)
  ?:  ?=(^ pool.s)  [%| %qpc-pool-already-bound]
  ?.  =(%proposing phase.core.s)  [%| %qpc-decision-not-proposing]
  ?.  (fresh s now)  [%| %qpc-decision-stale]
  ?.  ?&  =(id.s opening.g)  =(request.frozen.s request.g)
          =(request-digest.frozen.s request-digest.g)
          (identifier:decision receipt.g)
          (lth position.frozen.s position.g)  (lth position.g sealed)
          (lte (met 0 sealed) 64)
      ==  [%| %qpc-generation-order]
  ?.  ?&  (valid:pool p)  =(owner.frozen.s owner.p)
          =(session.frozen.s session.p)  =(project.frozen.s project.p)
          =(configuration.frozen.s configuration.p)  =(source.frozen.s source.p)
          =(grant.frozen.s grant.p)  =(request.g request.p)
          =(request-digest.g request-digest.context.p)
      ==  [%| %qpc-pool-binding-mismatch]
  =/  rows=(list row:pool)
    (skim rows.p |=(r=row:pool ?=(^ candidate.r)))
  ?.  ?&  =((lent values) (lent rows))  (lte (lent values) 4)
          =((lent values) ~(wyt in (silt (turn values |=(v=offered (key:tools request.tool.v))))))
      ==  [%| %qpc-pool-evidence-count]
  =/  core=state:decision  core.s
  =/  scored=(list scored)  ~
  =/  todo=(list offered)  values
  |-  ^-  (each state @tas)
  ?~  todo
    [%& s(core core, generation `g, pool `p, sealed `sealed, candidates (flop scored))]
  =/  v=offered  i.todo
  =/  key=@ux  (key:tools request.tool.v)
  =/  matches=(list row:pool)  (skim rows |=(r=row:pool =(key tool.r)))
  ?.  =(1 (lent matches))  [%| %qpc-pool-tool-missing]
  =/  row=row:pool  (snag 0 matches)
  ?.  &(=(%cantrip origin.row) =(grant.p grant.tool.v) =(%finished stage.tool.v))
    [%| %qpc-pool-tool-unfinished]
  ?~  result.tool.v  [%| %qpc-pool-result-missing]
  =/  result=tool-result:nc  u.result.tool.v
  =/  request=tool-request:nc  request.tool.v
  =/  ctx=context:nc
    [project.p configuration.p session.p request.p owner.p source.p]
  ?.  ?&  =(ctx context.request)  =(ctx context.result)
          =(call.row call-id.request)  =(call.row call-id.result)
          =(result.row (digest:pool result))  ?=(%patch -.arguments.request)
          ?=(%candidate -.output.result)
      ==  [%| %qpc-pool-tool-mismatch]
  =/  c=candidate:nc  value.output.result
  ?.  ?&  =(ctx context.c)  =(source.p revision.basis.c)
          =(id.c (candidate-digest:files c))  =(~ previous.c)
          =(1 (lent edits.c))  =(candidate.row `id.c)
          =(effect.row `(effect c))
      ==  [%| %qpc-pool-candidate-mismatch]
  ?.  &((admission-valid s admission.v id.c (effect c)) (gth position.admission.v sealed))
    [%| %qpc-admission-binding-mismatch]
  =/  measured
    (measure:energy `arguments.request [footprint.parameters.law.frozen.s indirection.parameters.law.frozen.s])
  ?:  ?=(%| -.measured)  [%| p.measured]
  =/  proposal=proposal:decision
    [id.c (jam [%effect-v1 revision.basis.c accepted.c edits.c]) (digest v) (passed admission.v) value.p.measured]
  =/  offered  (offer:decision core proposal (source-digest source.p) epoch.now)
  ?:  ?=(%| -.offered)  [%| p.offered]
  $(todo t.todo, core p.offered, scored [[v p.measured] scored])
++  choose
  ::  The owner records one Urbit-owned draw and this result atomically.
  |=  [s=state draw=@ud position=@ud now=current]
  ^-  (each state @tas)
  ?~  sealed.s  [%| %qpc-pool-not-bound]
  ?.  (fresh s now)  [%| %qpc-decision-stale]
  ?.  &((lte (met 0 position) 64) (gth position u.sealed.s) (levy candidates.s |=(c=scored (gth position position.admission.evidence.c))))
    [%| %qpc-choice-order]
  =/  picked  (select-once:decision core.s draw (source-digest source.now) epoch.now)
  ?:  ?=(%| -.picked)  [%| p.picked]
  [%& s(core p.picked, chosen-at `position)]
++  release
  ::  Consume and persist before dispatch. This result STILL needs Cantrip
  ::  admission for the new session's own grant and pending exact request.
  ::  A later law edit does not rewrite the retained law or select again.
  |=  [s=state candidate=@ux grant=@ux request=tool-request:nc checked=admission-receipt now=current]
  ^-  (each [state mapping] @tas)
  ?.  (fresh s now)  [%| %qpc-decision-stale]
  =/  released  (release:decision core.s candidate (source-digest source.now) epoch.now)
  ?:  ?=(%| -.released)  [%| p.released]
  =/  matches=(list scored)
    (skim candidates.s |=(c=scored =(candidate candidate.admission.evidence.c)))
  ?.  =(1 (lent matches))  [%| %qpc-selected-evidence-missing]
  =/  selected=scored  (snag 0 matches)
  =/  prior=tool-request:nc  request.tool.evidence.selected
  ?.  ?&  (identifier:decision grant)  !=(grant grant.frozen.s)
          (identifier:decision session.context.request)
          (identifier:decision request.context.request)
          !=(session.frozen.s session.context.request)
          !=(request.frozen.s request.context.request)
          !=(%$ call-id.request)
          =(project.frozen.s project.context.request)
          =(configuration.frozen.s configuration.context.request)
          =(owner.frozen.s actor.context.request)
          =(source.frozen.s source.context.request)
          =(arguments.prior arguments.request)
      ==  [%| %qpc-execution-mapping-mismatch]
  ?.  &((admission-valid s checked candidate effect.admission.evidence.selected) (passed checked))
    [%| %qpc-admission-recheck-required]
  ?~  chosen-at.s  [%| %qpc-choice-missing]
  ?.  (gth position.checked u.chosen-at.s)  [%| %qpc-admission-recheck-required]
  ?~  pool.s  [%| %qpc-pool-not-bound]
  =/  m=mapping
    :*  %qpc-execution-mapping-v1  0x0  id.s  id.u.pool.s
        session.frozen.s  request.frozen.s  (key:tools prior)
        candidate  effect.checked  grant  request  (key:tools request)  checked  %.y
    ==
  =.  m  m(id (digest m))
  [%& [s(core p.released, released `m) m]]
++  stop
  ::  Refusal/cancellation before release records no invented execution.
  ::  After release, only the exact mapped +finish may settle the decision.
  |=  [s=state kind=?(%refused %cancelled) evidence=@ux]
  ^-  (each state @tas)
  ?:  |(?=(^ released.s) =(%released phase.core.s))
    [%| %qpc-action-already-released]
  =/  closed  (close:decision core.s kind evidence)
  ?:  ?=(%| -.closed)  [%| p.closed]
  [%& s(core p.closed)]
++  finish
  ::  Retain observation, including unknown; this never dispatches or retries.
  ::  Completion is not a confidence report or an admitted measurement row.
  |=  [s=state value=completion]
  ^-  (each state @tas)
  ?~  released.s  [%| %qpc-action-not-released]
  =/  m=mapping  u.released.s
  ?.  &(=(id.m mapping.value) =(tool.m tool.value))
    [%| %qpc-outcome-mapping-mismatch]
  ?^  candidate.value
    =/  c=candidate:nc  u.candidate.value
    ?.  ?&  =(context.request.m context.c)  =(source.frozen.s revision.basis.c)
            =(id.c (candidate-digest:files c))  =(effect.m (effect c))
        ==  [%| %qpc-outcome-candidate-mismatch]
    (finish-checked s value)
  ?:  =(%applied kind.value)  [%| %qpc-applied-candidate-missing]
  (finish-checked s value)
++  finish-checked
  |=  [s=state value=completion]
  ^-  (each state @tas)
  ?:  =(%unknown kind.value)
    ?^  resulting.value  [%| %qpc-unknown-source-claim]
    (close-result s value)
  ?:  =(%applied kind.value)
    ?~  resulting.value  [%| %qpc-applied-source-missing]
    ::  Native acceptance lands one Clay revision on this exact working desk.
    ::  Same revision is unresolved; skipped revisions are a source conflict.
    ?.  ?&  =(owner.source.frozen.s owner.u.resulting.value)
            =(desk.source.frozen.s desk.u.resulting.value)
            =(+(number.source.frozen.s) number.u.resulting.value)
        ==  [%| %qpc-applied-source-mismatch]
    (close-result s value)
  ?^  resulting.value
    ?.  =(source.frozen.s u.resulting.value)  [%| %qpc-unapplied-source-changed]
    (close-result s value)
  (close-result s value)
++  close-result
  |=  [s=state value=completion]
  ^-  (each state @tas)
  =/  closed  (close:decision core.s kind.value evidence.value)
  ?:  ?=(%| -.closed)  [%| p.closed]
  [%& s(core p.closed, result `value)]
--
