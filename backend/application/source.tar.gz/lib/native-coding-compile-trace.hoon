::  Explain a failed Hoon build. Ford answers a failed %a build with no
::  value, so a candidate check could only say "no compiled value". This
::  recompiles the same file the way Ford does (zuse, then each import under
::  its face, structures before libraries) inside +mule, keeping the real
::  compiler trace: syntax errors, nest-fails and -find, with their spots.
::  Header lines are blanked, not removed, so line numbers match the file.
/-  spider, nc=native-coding
/+  strandio, accept=native-coding-accept
|%
+$  taut  [face=(unit term) name=term]
+$  header  [sur=(list taut) lib=(list taut) body=@t]
++  trace-limit  6.144
++  tank-limit  64
++  lines
  |=  text=@t
  ^-  (list tape)
  =/  t=tape  (trip text)
  =|  cur=tape
  =|  out=(list tape)
  |-  ^-  (list tape)
  ?~  t  (flop [(flop cur) out])
  ?:  =('\0a' i.t)  $(t t.t, out [(flop cur) out], cur ~)
  $(t t.t, cur [i.t cur])
++  strip
  |=  t=tape
  ^-  tape
  ?~  t  ~
  ?:  =(' ' i.t)  $(t t.t)
  t
++  trim  |=(t=tape ^-(tape (flop (strip (flop (strip t))))))
++  uncomment
  |=  t=tape
  ^-  tape
  =/  at  (find "::" t)
  ?~(at t (scag u.at t))
++  split
  |=  t=tape
  ^-  (list tape)
  =|  cur=tape
  =|  out=(list tape)
  |-  ^-  (list tape)
  ?~  t  (flop [(flop cur) out])
  ?:  =(',' i.t)  $(t t.t, out [(flop cur) out], cur ~)
  $(t t.t, cur [i.t cur])
++  taut-of
  ::  Ford's taut-rule: *name (no face), face=name, or bare name as its face.
  |=  item=tape
  ^-  (unit taut)
  ?~  item  ~
  =/  named
    |=  t=tape
    ^-  (unit term)
    =/  c=@t  (crip t)
    ?.(&(?=(^ t) ((sane %tas) c)) ~ `c)
  ?:  =('*' i.item)
    =/  n  (named t.item)
    ?~(n ~ `[~ u.n])
  =/  at  (find "=" `tape`item)
  ?~  at
    =/  n  (named item)
    ?~(n ~ `[n u.n])
  =/  f  (named (scag u.at `tape`item))
  =/  n  (named (slag +(u.at) `tape`item))
  ?:  |(?=(~ f) ?=(~ n))  ~
  `[f u.n]
++  items
  |=  t=tape
  ^-  (unit (list taut))
  =/  parts=(list tape)  (split t)
  =|  out=(list taut)
  |-  ^-  (unit (list taut))
  ?~  parts  `(flop out)
  =/  one=tape  (trim i.parts)
  ?~  one  $(parts t.parts)
  =/  got  (taut-of one)
  ?~  got  ~
  $(parts t.parts, out [u.got out])
++  parse
  ::  Leading /- and /+ runes with indented continuation lines; /? is
  ::  ignored as Ford does. Other Ford runes are not reproduced here.
  |=  text=@t
  ^-  (each header @t)
  =/  rows=(list tape)  (lines text)
  =|  out=(list tape)
  =|  sur=(list taut)
  =|  lib=(list taut)
  =/  kind=?(%none %sur %lib)  %none
  =/  open=?  %.y
  |-  ^-  (each header @t)
  ?~  rows
    [%& (flop sur) (flop lib) (rap 3 (join '\0a' (turn (flop out) crip)))]
  =/  row=tape  i.rows
  ?.  open  $(rows t.rows, out [row out])
  =/  bare=tape  (trim (uncomment row))
  ?~  bare  $(rows t.rows, out [row out])
  =/  head=tape  (scag 2 `tape`bare)
  ?:  =("/?" head)  $(rows t.rows, out [~ out])
  ?:  |(=("/-" head) =("/+" head))
    =/  got  (items (slag 2 `tape`bare))
    ?~  got  [%| 'the import header could not be read']
    ?:  =("/-" head)
      $(rows t.rows, out [~ out], kind %sur, sur (weld (flop u.got) sur))
    $(rows t.rows, out [~ out], kind %lib, lib (weld (flop u.got) lib))
  ?:  =('/' i.bare)  [%| 'the header uses a Ford rune this explainer does not reproduce']
  ?:  &(!=(%none kind) =(" " (scag 1 row)))
    =/  got  (items bare)
    ?~  got  [%| 'the import header could not be read']
    ?:  =(%sur kind)
      $(rows t.rows, out [~ out], sur (weld (flop u.got) sur))
    $(rows t.rows, out [~ out], lib (weld (flop u.got) lib))
  $(rows t.rows, out [row out], open %.n)
++  subject
  ::  Ford's order: each dependency is slopped on top of the previous subject.
  |=  [base=vase deps=(list [face=(unit term) =vase])]
  ^-  vase
  |-  ^-  vase
  ?~  deps  base
  =/  dep=vase  vase.i.deps
  =?  p.dep  ?=(^ face.i.deps)  [%face u.face.i.deps p.dep]
  $(deps t.deps, base (slop dep base))
++  compile
  |=  [sut=vase pax=path body=@t]
  ^-  (each vase tang)
  %-  mule
  |.
  =/  gen=hoon
    [%tssg (scan (trip body) (ifix [gay gay] (most gap tall:(vang & pax))))]
  (slap sut gen)
++  render
  ::  Bounded text: the head and tail of the trace survive truncation.
  |=  =tang
  ^-  @t
  =/  rows=wall
    (zing (turn (scag tank-limit tang) |=(t=tank (wash [0 120] t))))
  =/  all=@t  (rap 3 (turn rows |=(r=tape (crip (weld r "\0a")))))
  ?:  (lte (met 3 all) trace-limit)  all
  =/  half=@ud  (div (sub trace-limit 16) 2)
  (rap 3 ~[(end [3 half] all) '\0a...\0a' (cut 3 [(sub (met 3 all) half) half] all)])
++  explain
  ::  Strand: build each import as Ford would, then recompile under +mule.
  |=  [target=beak pax=path text=@t]
  =/  m  (strand:spider ,@t)
  ^-  form:m
  =/  parsed  (parse text)
  ?:  ?=(%| -.parsed)  (pure:m (cat 3 'Compiler trace unavailable: ' p.parsed))
  =/  todo=(list [kind=?(%sur %lib) =taut])
    %+  weld
      (turn sur.p.parsed |=(t=taut ^-([?(%sur %lib) taut] [%sur t])))
    (turn lib.p.parsed |=(t=taut ^-([?(%sur %lib) taut] [%lib t])))
  =|  deps=(list [face=(unit term) =vase])
  |-  ^-  form:m
  ?~  todo
    =/  ran  (compile (subject !>(..zuse) (flop deps)) pax body.p.parsed)
    ?:  ?=(%& -.ran)
      (pure:m 'This file recompiled without error in isolation; the failure is in its build context.')
    (pure:m (render p.ran))
  =/  dep=path  /[kind.i.todo]/[name.taut.i.todo]/hoon
  ;<  got=(unit vase)  bind:m  (build-file:strandio [target dep])
  ?~  got
    (pure:m (rap 3 ~['Import ' (spat dep) ' does not build or does not exist; fix it first.']))
  $(todo t.todo, deps [[face.taut.i.todo u.got] deps])
++  with-trace
  ::  Put the trace into the failed compile diagnostic of a target row.
  |=  [row=target-result:accept trace=@t]
  ^-  target-result:accept
  ?~  diagnostics.row  row
  =/  first=diagnostic:nc  i.diagnostics.row
  ?.  &(=(%compile name.first) !passed.first)  row
  =/  detail=@t  (rap 3 ~[detail.first '\0aCompiler trace:\0a' trace])
  row(diagnostics [first(detail detail) t.diagnostics.row])
--
