::  Presentation decoder only. Reads canonical local source/catalog; Viki
::  rechecks ownership, exact baseline, catalog and private clone before effects.
/-  nc=native-coding, mp=multiplayer-project
/+  onboarding=viki-native-onboarding, bootstrap=native-coding-bootstrap,
    project=native-coding-project, catalog=multiplayer-project,
    private=pataphor-editor-read, terminal=native-coding-terminal,
    guard=viki-scry-guard, cr=codex-responses
|%
+$  row  [id=@ux project=@t working=@tas phase=?(%catalog %bootstrap %ready %refused) reason=@tas]
+$  command  [%native-coding-onboarding-action-v1 action=command:onboarding]
++  read
  |=  [our=@p now=@da]
  ^-  (unit (list row))
  ?.  (agent-live:guard our now %viki)  ~
  =/  held=[%native-coding-onboarding-v1 rows=(list row)]
    .^([%native-coding-onboarding-v1 rows=(list row)] %gx /(scot %p our)/viki/(scot %da now)/native-coding/onboarding/noun)
  `rows.held
++  rows-json
  |=  rows=(unit (list row))
  ^-  json
  =/  values=(list json)
    ?~  rows  ~
    %+  turn  (scag 32 u.rows)
    |=  r=row
    (pairs:enjs:format ~[['id' s+(scot %ux id.r)] ['project' s+project.r] ['working' s+working.r] ['phase' s+phase.r] ['reason' s+reason.r]])
  (pairs:enjs:format ~[['available' b+?=(^ rows)] ['rows' a+values]])
++  text
  |=  [object=json key=@t limit=@ud required=?]
  ^-  @t
  =/  value=@t  (need (string:cr object key))
  ?>  &((lte (met 3 value) limit) |(!required !=(0 value)))
  value
++  strings
  |=  [object=json key=@t limit=@ud]
  ^-  (list @t)
  =/  value  (need (field:cr object key))
  ?>  ?=(%a -.value)
  ?>  (lte (lent p.value) limit)
  %+  turn  p.value
  |=  item=json
  ?>  ?=(%s -.item)
  ?>  &(!=(0 p.item) (lte (met 3 p.item) 2.048))
  p.item
++  paths
  |=  values=(list @t)
  ^-  (list path)
  %+  turn  values
  |=  value=@t
  ?>  =(47 (end [3 1] value))
  (path-of:terminal ~ value)
++  decode
  ::  Caller authenticates owner and CSRF before this gate. Its result is only
  ::  a Viki request; no source writes, grants or callbacks originate here.
  |=  [our=@p now=@da object=json]
  ^-  command
  ?>  ?=(%o -.object)
  =/  kind=@t  (text object 'kind' 32 %.y)
  ?:  =('project-observe' kind)
    =/  id=@ux  (digest:terminal (text object 'id' 82 %.y))
    [%native-coding-onboarding-action-v1 [%observe id]]
  ?>  =('project-create' kind)
  =/  id=@t  (text object 'project' 128 %.y)
  ?>  (segment-valid:project id)
  =/  title=@t  (text object 'title' 256 %.y)
  =/  accepted=@tas  (name:terminal (text object 'acceptedDesk' 64 %.y))
  =/  working=@tas  (name:terminal (text object 'workingDesk' 64 %.y))
  ?>  !=(accepted working)
  =/  instructions=@t  (text object 'instructions' 16.384 %.y)
  =/  conventions=@t  (text object 'conventions' 8.192 %.n)
  =/  readable=(set path)  (silt (paths (strings object 'readable' 64)))
  =/  writable=(set path)  (silt (paths (strings object 'writable' 64)))
  =/  protected=(set path)  (silt (paths (strings object 'protected' 64)))
  ?>  &(?=(^ readable) ?=(^ writable))
  =/  operations=(set operation:nc)
    %-  silt
    %+  turn  (strings object 'operations' 32)
    |=  value=@t
    ?>  ?=(operation:nc value)
    `operation:nc`value
  ?>  &((~(has in operations) %read) (~(has in operations) %compile) (~(has in operations) %check))
  =/  policy=policy:nc
    [readable writable protected operations (need (natural:cr (field:cr object 'maxFileBytes'))) (need (natural:cr (field:cr object 'maxCandidateBytes')))]
  =/  marks=(map @tas @tas)
    %-  malt
    %+  turn  (strings object 'marks' 32)
    |=  value=@t
    =/  mark=@tas  (name:terminal value)
    [mark mark]
  ?>  ?=(^ marks)
  =/  target-kind=@t  (text object 'targetKind' 16 %.y)
  ?>  ?=(?(%hoon %gallowglass) target-kind)
  =/  entry=path  (snag 0 (paths ~[(text object 'entry' 2.048 %.y)]))
  ?>  ?=(^ entry)
  =/  dependencies=(list path)  (paths (strings object 'dependencies' 128))
  =/  targets=(list build-target:nc)
    ~[[(name:terminal (text object 'target' 64 %.y)) `?(%hoon %gallowglass)`target-kind entry dependencies ~[[(name:terminal (text object 'checkName' 64 %.y)) (text object 'checkExpression' 8.192 %.y)]]]]
  =/  imports=(map path (list path))  (~(put by *(map path (list path))) entry dependencies)
  =/  digest=@ux
    (shax (jam [%native-coding-owner-project-law-v1 our id title accepted working policy instructions conventions marks imports targets]))
  =/  spec=project-spec:mp  [1 id title our accepted 1 digest now]
  ?>  (agent-live:guard our now %multiplayer-runtime)
  =/  existing=(unit project:mp)
    .^((unit project:mp) %gx /(scot %p our)/multiplayer-runtime/(scot %da now)/catalog/[id]/noun)
  =.  spec
    ?~  existing  spec
    ?>  ?&  (project-valid:catalog u.existing)  =(our authority.spec.u.existing)
            =(accepted base-desk.spec.u.existing)  =(title title.spec.u.existing)
        ==
    spec.u.existing
  =/  p=project:nc
    [%native-coding-project-v1 spec working policy instructions conventions marks imports targets]
  ?>  (valid:project p)
  ?>  (private-path:private our now accepted /)
  =/  dome  (dome:bootstrap our now accepted)
  ?>  ?=(^ dome)
  =/  baseline  (tree-at:project our now p accepted let.u.dome)
  ?>  ?=(%& -.baseline)
  ::  Time is excluded from identity. Repeated forms cannot allocate siblings;
  ::  an already retained setup is observed by its displayed ID instead.
  =/  stable=project:nc  p(spec spec(created-at `@da`0))
  =/  nonce=@ux  (shax (jam [%native-coding-onboarding-http-v1 stable revision.p.baseline]))
  =/  rows  (read our now)
  ?>  ?=(^ rows)
  ?>  !(lien u.rows |=(r=row =(nonce id.r)))
  =/  request=request:bootstrap
    [%native-coding-bootstrap-request-v1 nonce p revision.p.baseline our (cat 3 'Native coding project: ' id) ~ %clone ~]
  ?>  (request-valid:bootstrap our request)
  [%native-coding-onboarding-action-v1 [%begin request]]
--
