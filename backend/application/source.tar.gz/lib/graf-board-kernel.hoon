::  /lib/graf-board-kernel.hoon
::
::  One transition and projection law for the canonical Graf Board and the
::  read-only Siev shadow organ.  Runtime authority remains outside this core:
::  callers supply the acting ship and the exact live Warden gate set.
::
/-  gb=graf-board, graf-event, mg=moon-grant
/+  moon-guardian, nock-meter, regime, resonance, teleo-nd
=,  si
|%
+$  guard-check-result
  [allowed=? detail=@tas product=(unit *)]
+$  board-transition
  [state=board-state:gb event=(unit territory-event:graf-event)]
::
++  max-recent-keys  128
++  max-gate-ref-bytes  64
++  max-gate-fuel    10.000
++  max-gate-bytes   4.096
++  max-guard-fuel   1.000
++  max-guard-bytes  4.096
++  max-r-sign-dims  64
++  max-teleo-targets-per-field  64
++  outbox-cap       128
::
++  initial-board-state
  ^-  board-state:gb
  [%8 ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~]
::
++  cutover-seal-matches
  |=  [st=board-state:gb seal=cutover-seal:gb]
  ^-  ?
  ?&  =((mug st) state-mug.seal)
      =((lent accepted-actions.st) accepted-action-count.seal)
  ==
::
++  seen-key
  |=  [keys=(list @t) key=@t]
  ^-  ?
  (lien keys |=(k=@t =(k key)))
::
++  named-guard-passes
  |=  g=@tas
  ^-  ?
  ?+  g  %.n
    %always  %.y
  ==
::
++  guard-check
  |=  [e=act-edge:gb w=walker:gb]
  ^-  guard-check-result
  ?~  guard-formula.e
    ?:  (named-guard-passes guard.e)
      [%.y %guard-allowed ~]
    [%.n %guard-denied ~]
  =/  checked=(each res:nock-meter tang)
    %-  mule
    |.((meter:nock-meter w u.guard-formula.e max-guard-fuel))
  ?:  ?=(%| -.checked)  [%.n %guard-mule-fault ~]
  =/  fired  p.checked
  ?:  ?=(%| -.fired)  [%.n p.fired ~]
  ?:  =(0 p.fired)  [%.y %formula-true `p.fired]
  ?:  =(1 p.fired)  [%.n %formula-false `p.fired]
  [%.n %formula-malformed `p.fired]
::
++  valid-edge
  |=  e=act-edge:gb
  ^-  ?
  ?~  guard-formula.e  %.y
  (lte (met 3 (jam u.guard-formula.e)) max-guard-bytes)
::
++  valid-r-sign-input
  |=  input=r-sign-input:gb
  ^-  ?
  ?&  ?=(^ grad-v.input)
      =((lent grad-v.input) (lent grad-c.input))
      (lte (lent grad-v.input) max-r-sign-dims)
  ==
::
++  valid-gate
  |=  g=board-gate:gb
  ^-  ?
  ?&  !=(0 gate-ref.g)
      (lte (met 3 gate-ref.g) max-gate-ref-bytes)
      !=(0 fuel.g)
      (lte fuel.g max-gate-fuel)
      (lte (met 3 (jam formula.g)) max-gate-bytes)
  ==
::
++  find-act
  |=  [acts=(list act-node:gb) aid=@t]
  ^-  (unit act-node:gb)
  =/  hits  (skim acts |=(a=act-node:gb =(act-id.a aid)))
  ?~(hits ~ `i.hits)
::
++  find-gate
  |=  [gates=(list board-gate:gb) ref=@t]
  ^-  (unit board-gate:gb)
  =/  hits  (skim gates |=(g=board-gate:gb =(gate-ref.g ref)))
  ?~(hits ~ `i.hits)
::
++  find-binding
  |=  [bindings=(list gate-lease:gb) ref=@t]
  ^-  (unit gate-lease:gb)
  =/  hits  (skim bindings |=(b=gate-lease:gb =(gate-ref.b ref)))
  ?~(hits ~ `i.hits)
::
++  gate-authorized
  |=  $:  ref=@t
          bindings=(list gate-lease:gb)
          live=(set @t)
          actor=@p
          sovereign=@p
      ==
  ^-  ?
  =/  bound  (find-binding bindings ref)
  ?~  bound  %.y
  ?&  ?|(=(actor grantee.u.bound) =(actor sovereign))
      (~(has in live) ref)
  ==
::
++  find-edge
  |=  [edges=(list act-edge:gb) eid=@t]
  ^-  (unit act-edge:gb)
  =/  hits  (skim edges |=(e=act-edge:gb =(edge-id.e eid)))
  ?~(hits ~ `i.hits)
::
++  find-walker
  |=  [walkers=(list walker:gb) wid=@t]
  ^-  (unit walker:gb)
  =/  hits  (skim walkers |=(w=walker:gb =(walker-id.w wid)))
  ?~(hits ~ `i.hits)
::
++  find-region
  |=  [regions=(list regime-region:gb) root=@t]
  ^-  (unit regime-region:gb)
  =/  hits  (skim regions |=(r=regime-region:gb =(root-act.r root)))
  ?~(hits ~ `i.hits)
::
++  find-teleo-target
  |=  [targets=(list teleo-target:gb) root=@t eid=@t]
  ^-  (unit teleo-target:gb)
  =/  hits
    %+  skim  targets
    |=(t=teleo-target:gb ?&(=(root-act.t root) =(edge-id.t eid)))
  ?~(hits ~ `i.hits)
::
++  regime-allows
  |=  $:  regions=(list regime-region:gb)
          acts=(list act-node:gb)
          from=@t
          to=@t
      ==
  ^-  ?
  =/  region  (find-region regions from)
  ?~  region  %.y
  =/  target  (find-act acts to)
  ?~  target  %.n
  =/  wan  ((soft act:regime) act.u.target)
  ?~  wan  %.n
  (admissible:regime ;;(regime:regime regime.u.region) u.wan)
::
++  meta-of
  |=  act=board-action:gb
  ^-  board-meta:gb
  ?-  -.act
    %record-gate           meta.act
    %bind-gate-lease       meta.act
    %record-act-node       meta.act
    %record-act-edge       meta.act
    %record-r-sign-edge    meta.act
    %record-regime-region  meta.act
    %record-teleo-target   meta.act
    %spawn-walker          meta.act
    %advance-walker        meta.act
    %close-walk            meta.act
  ==
::
++  advance
  |=  $:  acts=(list act-node:gb)
          edges=(list act-edge:gb)
          walkers=(list walker:gb)
          gates=(list board-gate:gb)
          bindings=(list gate-lease:gb)
          regions=(list regime-region:gb)
          live=(set @t)
          actor=@p
          sovereign=@p
          wid=@t
          eid=@t
      ==
  ^-  $:  ok=?
          detail=@t
          walkers=(list walker:gb)
          fire=(unit gate-fire:gb)
          guard=(unit guard-fire:gb)
      ==
  =/  mw  (find-walker walkers wid)
  ?~  mw  [%.n 'no-walker' walkers ~ ~]
  ?.  =(%open status.u.mw)  [%.n 'walker-closed' walkers ~ ~]
  =/  me  (find-edge edges eid)
  ?~  me  [%.n 'no-edge' walkers ~ ~]
  ?.  =(from-act.u.me position.u.mw)  [%.n 'off-edge' walkers ~ ~]
  =/  target  (find-act acts to-act.u.me)
  ?~  target  [%.n 'no-to-act' walkers ~ ~]
  ?.  (regime-allows regions acts position.u.mw to-act.u.me)
    [%.n 'regime-denied' walkers ~ ~]
  =/  checked  (guard-check u.me u.mw)
  =/  evidence=guard-fire:gb
    [wid eid allowed.checked detail.checked product.checked]
  ?.  allowed.checked  [%.n detail.checked walkers ~ `evidence]
  =/  moved=(list walker:gb)
    %+  turn  walkers
    |=  w=walker:gb
    ?.  =(walker-id.w wid)  w
    w(position to-act.u.me, walk-log [eid walk-log.w])
  =/  ref=(unit @t)  gate-ref.u.target
  ?~  ref  [%.y 'advanced' moved ~ `evidence]
  =/  gate  (find-gate gates u.ref)
  ?~  gate  [%.n 'no-capability' walkers ~ `evidence]
  ?.  (gate-authorized u.ref bindings live actor sovereign)
    [%.n 'lease-refused' walkers ~ `evidence]
  =/  fired  (meter:nock-meter u.mw formula.u.gate fuel.u.gate)
  ?:  ?=(%| -.fired)  [%.n 'gate-fault' walkers ~ `evidence]
  [%.y 'gate-fired' moved `[wid eid u.ref p.fired] `evidence]
::
++  weights-of
  |=  [edges=(list act-edge:gb) walkers=(list walker:gb)]
  ^-  (list edge-weight:gb)
  =/  logs
    ^-  (list @t)
    %-  zing
    %+  turn  (skim walkers |=(w=walker:gb =(%accepted status.w)))
    |=(w=walker:gb walk-log.w)
  %+  turn  edges
  |=  e=act-edge:gb
  [edge-id.e (lent (skim logs |=(i=@t =(i edge-id.e))))]
::
++  edge-weight-of
  |=  [weights=(list edge-weight:gb) eid=@t]
  ^-  @ud
  =/  hits  (skim weights |=(x=edge-weight:gb =(edge-id.x eid)))
  ?~(hits 0 weight.i.hits)
::
++  teleo-of
  |=  $:  edges=(list act-edge:gb)
          walkers=(list walker:gb)
          targets=(list teleo-target:gb)
          root=@t
      ==
  ^-  teleo-snapshot:gb
  =/  weights  (weights-of edges walkers)
  =/  field-targets=(list teleo-target:gb)
    (skim targets |=(t=teleo-target:gb =(root-act.t root)))
  =/  points=(list teleo-point:gb)
    %+  turn  field-targets
    |=  t=teleo-target:gb
    [edge-id.t (edge-weight-of weights edge-id.t) target.t]
  =/  current=vec:teleo-nd
    (turn points |=(p=teleo-point:gb (sun current.p)))
  =/  goal=vec:teleo-nd
    (turn points |=(p=teleo-point:gb (sun target.p)))
  [(v-teleo:teleo-nd current goal) points %advisory %computed]
::
::  Exact squared accepted-use-count distance after one hypothetical use.
++  projected-distance-squared
  |=  $:  weights=(list edge-weight:gb)
          targets=(list teleo-target:gb)
          eid=@t
      ==
  ^-  @ud
  =/  current=vec:teleo-nd
    %+  turn  targets
    |=  t=teleo-target:gb
    =/  w  (edge-weight-of weights edge-id.t)
    (sun ?:(=(edge-id.t eid) +(w) w))
  =/  goal=vec:teleo-nd
    (turn targets |=(t=teleo-target:gb (sun target.t)))
  (distance-squared:teleo-nd current goal)
::  Preserve the public potential units: floor(squared-count-distance / 2).
++  projected-v
  |=  $:  weights=(list edge-weight:gb)
          targets=(list teleo-target:gb)
          eid=@t
      ==
  ^-  @ud
  (div (projected-distance-squared weights targets eid) 2)
::
++  menu-of
  |=  $:  acts=(list act-node:gb)
          edges=(list act-edge:gb)
          walkers=(list walker:gb)
          gates=(list board-gate:gb)
          bindings=(list gate-lease:gb)
          regions=(list regime-region:gb)
          targets=(list teleo-target:gb)
          live=(set @t)
          actor=@p
          sovereign=@p
          wid=@t
      ==
  ^-  (list menu-item:gb)
  =/  mw  (find-walker walkers wid)
  ?~  mw  ~
  ?.  =(%open status.u.mw)  ~
  =/  legal
    %+  skim  edges
    |=  e=act-edge:gb
    =/  checked  (guard-check e u.mw)
    ?&  =(from-act.e position.u.mw)
        (regime-allows regions acts position.u.mw to-act.e)
        allowed.checked
    ==
  =/  loaded=(list menu-item:gb)
    %+  murn  legal
    |=  e=act-edge:gb
    =/  target  (find-act acts to-act.e)
    ?~  target  ~
    =/  ref=(unit @t)  gate-ref.u.target
    ?~  ref  `[e ~]
    =/  gate  (find-gate gates u.ref)
    ?~  gate  ~
    ?.  (gate-authorized u.ref bindings live actor sovereign)  ~
    `[e gate]
  =/  ws  (weights-of edges walkers)
  =/  field-targets=(list teleo-target:gb)
    (skim targets |=(t=teleo-target:gb =(root-act.t position.u.mw)))
  =/  wt  |=(eid=@t (edge-weight-of ws eid))
  =/  pv  |=(eid=@t (projected-distance-squared ws field-targets eid))
  %+  sort  loaded
  |=  [a=menu-item:gb b=menu-item:gb]
  ?~  field-targets  (gte (wt edge-id.edge.a) (wt edge-id.edge.b))
  =/  va  (pv edge-id.edge.a)
  =/  vb  (pv edge-id.edge.b)
  ?:  !=(va vb)  (lth va vb)
  (gte (wt edge-id.edge.a) (wt edge-id.edge.b))
::
++  binding-live
  |=  [b=gate-lease:gb =bowl:gall]
  ^-  ?
  =/  read=(each (unit moon-grant:mg) tang)
    %-  mule
    |.(.^((unit moon-grant:mg) %gx /(scot %p our.bowl)/nets/(scot %da now.bowl)/compare/moon-warden/grant/[lease-id.b]/noun))
  =/  grant=(unit moon-grant:mg)
    ?-  -.read
      %&  p.read
      %|  ~
    ==
  ?~  grant  %.n
  ?.  =(lease-id.b lease-id.u.grant)  %.n
  ?.  =(grantee.b grantee.u.grant)  %.n
  ?.  =(our.bowl parent.u.grant)  %.n
  =/  clamped  (clamp:moon-guardian [lease-id.b tool.b '' ''] grant now.bowl)
  =(%execute verdict.clamped)
::
++  live-gates
  |=  [bindings=(list gate-lease:gb) =bowl:gall]
  ^-  (set @t)
  %-  silt
  %+  murn  bindings
  |=  b=gate-lease:gb
  ?:((binding-live b bowl) `gate-ref.b ~)
::
++  binding-gates
  |=  bindings=(list gate-lease:gb)
  ^-  (set @t)
  %-  silt
  (turn bindings |=(b=gate-lease:gb gate-ref.b))
::
++  event-for
  |=  act=board-action:gb
  ^-  territory-event:graf-event
  [%plant [-.act +>.act]]
::
++  action-seen
  |=  [actions=(list board-action:gb) act=board-action:gb]
  ^-  ?
  (lien actions |=(prior=board-action:gb =(prior act)))
::
::  The one board reducer.  Gall owns the source-ship gate and Warden owns the
::  live lease set; this core owns only deterministic transition law.
++  apply-board-action
  |=  $:  st=board-state:gb
          act=board-action:gb
          actor=@p
          sovereign=@p
          live=(set @t)
          can-bind=?
      ==
  ^-  board-transition
  =/  key  idempotency-key:(meta-of act)
  ?:  (seen-key recent-keys.st key)
    [st(last-receipt `[-.act key %.y %.y 'duplicate']) ~]
  =/  rkeys  (scag max-recent-keys `(list @t)`[key recent-keys.st])
  ?-    -.act
      %record-gate
    =/  g  gate.act
    ?^  (find-gate gates.st gate-ref.g)
      [st(recent-keys rkeys, last-receipt `[-.act key %.n %.n 'gate-exists']) ~]
    ?.  (valid-gate g)
      [st(recent-keys rkeys, last-receipt `[-.act key %.n %.n 'invalid-gate']) ~]
    =/  event  (event-for act)
    :-  %=  st
          gates         [g gates.st]
          recent-keys   rkeys
          last-receipt  `[-.act key %.y %.n 'recorded']
          outbox        (scag outbox-cap ^+(outbox.st [event outbox.st]))
          accepted-actions  [act accepted-actions.st]
        ==
    `event
  ::
      %bind-gate-lease
    =/  b  binding.act
    ?.  =(actor sovereign)
      [st(recent-keys rkeys, last-receipt `[-.act key %.n %.n 'principal-only']) ~]
    ?~  (find-gate gates.st gate-ref.b)
      [st(recent-keys rkeys, last-receipt `[-.act key %.n %.n 'no-gate']) ~]
    ?^  (find-binding bindings.st gate-ref.b)
      [st(recent-keys rkeys, last-receipt `[-.act key %.n %.n 'gate-already-bound']) ~]
    ?.  can-bind
      [st(recent-keys rkeys, last-receipt `[-.act key %.n %.n 'lease-not-live']) ~]
    =/  event  (event-for act)
    :-  %=  st
          bindings      [b bindings.st]
          recent-keys   rkeys
          last-receipt  `[-.act key %.y %.n 'bound']
          outbox        (scag outbox-cap ^+(outbox.st [event outbox.st]))
          accepted-actions  [act accepted-actions.st]
        ==
    `event
  ::
      %record-act-node
    =/  n  node.act
    ?^  (find-act acts.st act-id.n)
      [st(recent-keys rkeys, last-receipt `[-.act key %.n %.n 'act-exists']) ~]
    =/  gate-loaded=?
      ?~  gate-ref.n  %.y
      ?=(^ (find-gate gates.st u.gate-ref.n))
    ?.  gate-loaded
      [st(recent-keys rkeys, last-receipt `[-.act key %.n %.n 'no-gate']) ~]
    =/  event  (event-for act)
    :-  %=  st
          acts          [n acts.st]
          recent-keys   rkeys
          last-receipt  `[-.act key %.y %.n 'recorded']
          outbox        (scag outbox-cap ^+(outbox.st [event outbox.st]))
          accepted-actions  [act accepted-actions.st]
        ==
    `event
  ::
      %record-act-edge
    =/  e  edge.act
    ?^  (find-edge edges.st edge-id.e)
      [st(recent-keys rkeys, last-receipt `[-.act key %.n %.n 'edge-exists']) ~]
    ?~  (find-act acts.st from-act.e)
      [st(recent-keys rkeys, last-receipt `[-.act key %.n %.n 'no-from-act']) ~]
    ?~  (find-act acts.st to-act.e)
      [st(recent-keys rkeys, last-receipt `[-.act key %.n %.n 'no-to-act']) ~]
    ?:  =(%r-sign guard.e)
      [st(recent-keys rkeys, last-receipt `[-.act key %.n %.n 'reserved-guard']) ~]
    ?.  (valid-edge e)
      [st(recent-keys rkeys, last-receipt `[-.act key %.n %.n 'guard-formula-too-large']) ~]
    =/  event  (event-for act)
    :-  %=  st
          edges         [e edges.st]
          recent-keys   rkeys
          last-receipt  `[-.act key %.y %.n 'recorded']
          outbox        (scag outbox-cap ^+(outbox.st [event outbox.st]))
          accepted-actions  [act accepted-actions.st]
        ==
    `event
  ::
      %record-r-sign-edge
    ?.  =(actor sovereign)
      [st(recent-keys rkeys, last-receipt `[-.act key %.n %.n 'principal-only']) ~]
    ?^  (find-edge edges.st edge-id.act)
      [st(recent-keys rkeys, last-receipt `[-.act key %.n %.n 'edge-exists']) ~]
    ?~  (find-act acts.st from-act.act)
      [st(recent-keys rkeys, last-receipt `[-.act key %.n %.n 'no-from-act']) ~]
    ?~  (find-act acts.st to-act.act)
      [st(recent-keys rkeys, last-receipt `[-.act key %.n %.n 'no-to-act']) ~]
    ?.  (valid-r-sign-input input.act)
      [st(recent-keys rkeys, last-receipt `[-.act key %.n %.n 'invalid-r-sign-input']) ~]
    =/  r=@s  (resonate:resonance grad-v.input.act grad-c.input.act)
    =/  valence=?(%positive %negative %neutral)
      (valence:resonance grad-v.input.act grad-c.input.act)
    =/  admitted=?  (admissible:resonance grad-v.input.act grad-c.input.act)
    =/  formula=*  [1 admitted]
    =/  e=act-edge:gb
      [edge-id.act from-act.act to-act.act %r-sign `formula summary.act]
    =/  receipt=lattice-receipt:gb
      [%r-sign-gate edge-id.act %advisory %computed input.act r valence admitted]
    =/  event  (event-for act)
    :-  %=  st
          edges         [e edges.st]
          lattice       [receipt lattice.st]
          recent-keys   rkeys
          last-receipt  `[-.act key %.y %.n 'recorded-r-sign']
          outbox        (scag outbox-cap ^+(outbox.st [event outbox.st]))
          accepted-actions  [act accepted-actions.st]
        ==
    `event
  ::
      %record-regime-region
    =/  region  region.act
    ?.  =(actor sovereign)
      [st(recent-keys rkeys, last-receipt `[-.act key %.n %.n 'principal-only']) ~]
    ?~  (find-act acts.st root-act.region)
      [st(recent-keys rkeys, last-receipt `[-.act key %.n %.n 'no-root-act']) ~]
    ?^  (find-region regions.st root-act.region)
      [st(recent-keys rkeys, last-receipt `[-.act key %.n %.n 'region-exists']) ~]
    =/  event  (event-for act)
    :-  %=  st
          regions       [region regions.st]
          recent-keys   rkeys
          last-receipt  `[-.act key %.y %.n 'recorded-region']
          outbox        (scag outbox-cap ^+(outbox.st [event outbox.st]))
          accepted-actions  [act accepted-actions.st]
        ==
    `event
  ::
      %record-teleo-target
    =/  target  target.act
    ?.  =(actor sovereign)
      [st(recent-keys rkeys, last-receipt `[-.act key %.n %.n 'principal-only']) ~]
    ?~  (find-act acts.st root-act.target)
      [st(recent-keys rkeys, last-receipt `[-.act key %.n %.n 'no-root-act']) ~]
    =/  edge  (find-edge edges.st edge-id.target)
    ?~  edge
      [st(recent-keys rkeys, last-receipt `[-.act key %.n %.n 'no-edge']) ~]
    ?.  =(root-act.target from-act.u.edge)
      [st(recent-keys rkeys, last-receipt `[-.act key %.n %.n 'edge-outside-field']) ~]
    ?^  (find-teleo-target targets.st root-act.target edge-id.target)
      [st(recent-keys rkeys, last-receipt `[-.act key %.n %.n 'target-exists']) ~]
    =/  field-count
      (lent (skim targets.st |=(t=teleo-target:gb =(root-act.t root-act.target))))
    ?:  (gte field-count max-teleo-targets-per-field)
      [st(recent-keys rkeys, last-receipt `[-.act key %.n %.n 'target-capacity']) ~]
    =/  event  (event-for act)
    :-  %=  st
          targets       [target targets.st]
          recent-keys   rkeys
          last-receipt  `[-.act key %.y %.n 'recorded-teleo-target']
          outbox        (scag outbox-cap ^+(outbox.st [event outbox.st]))
          accepted-actions  [act accepted-actions.st]
        ==
    `event
  ::
      %spawn-walker
    =/  w  walker.act
    ?^  (find-walker walkers.st walker-id.w)
      [st(recent-keys rkeys, last-receipt `[-.act key %.n %.n 'walker-exists']) ~]
    ?~  (find-act acts.st position.w)
      [st(recent-keys rkeys, last-receipt `[-.act key %.n %.n 'no-position-act']) ~]
    =/  event  (event-for act)
    :-  %=  st
          walkers       [w(walk-log ~, status %open) walkers.st]
          recent-keys   rkeys
          last-receipt  `[-.act key %.y %.n 'spawned']
          outbox        (scag outbox-cap ^+(outbox.st [event outbox.st]))
          accepted-actions  [act accepted-actions.st]
        ==
    `event
  ::
      %advance-walker
    =/  res
      %-  advance
      :*  acts.st  edges.st  walkers.st  gates.st  bindings.st
          regions.st  live  actor  sovereign  walker-id.act  edge-id.act
      ==
    =/  event  (event-for act)
    =/  next=board-state:gb
      %=  st
        walkers       walkers.res
        recent-keys   rkeys
        last-receipt  `[-.act key ok.res %.n detail.res]
        last-fire     ?:(ok.res fire.res last-fire.st)
        last-guard    ?~(guard.res last-guard.st guard.res)
        outbox        ?:(ok.res (scag outbox-cap ^+(outbox.st [event outbox.st])) outbox.st)
        accepted-actions  ?:(ok.res [act accepted-actions.st] accepted-actions.st)
      ==
    [next ?:(ok.res `event ~)]
  ::
      %close-walk
    =/  mw  (find-walker walkers.st walker-id.act)
    ?~  mw
      [st(recent-keys rkeys, last-receipt `[-.act key %.n %.n 'no-walker']) ~]
    ?.  =(%open status.u.mw)
      [st(recent-keys rkeys, last-receipt `[-.act key %.n %.n 'walker-closed']) ~]
    =/  new-status  ?:(accepted.act %accepted %rejected)
    =/  nws
      %+  turn  walkers.st
      |=  w=walker:gb
      ?.  =(walker-id.w walker-id.act)  w
      w(status new-status)
    =/  event  (event-for act)
    :-  %=  st
          walkers       nws
          recent-keys   rkeys
          last-receipt  `[-.act key %.y %.n 'closed']
          outbox        (scag outbox-cap ^+(outbox.st [event outbox.st]))
          accepted-actions  [act accepted-actions.st]
        ==
    `event
  ==
::
::  A trusted accepted action is consumed only from the Gall subscription
::  owned by the caller.  The semantic Graf fact intentionally omits dispatch
::  metadata, so the canonical board exposes this lossless replay envelope on
::  a separate path.  Full action membership makes restart replay byte-inert.
++  apply-trusted-action
  |=  $:  st=board-state:gb
          act=board-action:gb
          sovereign=@p
      ==
  ^-  board-state:gb
  ?:  (action-seen accepted-actions.st act)  st
  =/  live=(set @t)  (binding-gates bindings.st)
  =/  result=board-transition
    (apply-board-action st act sovereign sovereign live %.y)
  ?~  event.result  st
  state.result
::
++  apply-trusted-shadow-event
  |=  $:  st=board-state:gb
          event=board-shadow-event:gb
          sovereign=@p
      ==
  ^-  board-state:gb
  ?-  -.event
    %snapshot  state.event
    %accepted  (apply-trusted-action st action.event sovereign)
  ==
--
