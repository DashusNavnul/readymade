::  /lib/cantrip-multiplayer-retry
::
::  Pure retry schedule for Cantrip's authenticated multiplayer outbox.
::  A timer may resend the exact move, but it never changes receiver status.
::
/-  ct=cantrip
|%
+$  retry-ticket
  [move-id=@t attempt=@ud generation=@ud]
+$  retry-decision
  $%  [%retry next-attempt=@ud next-delay=@dr]
      [%stop reason=@tas]
  ==
::
++  max-attempts  4
++  active
  |=  status=mp-outbox-status:ct
  ^-  ?
  ?=(?(%sent %pending %accepted %held) status)
++  retry-delay
  |=  attempt=@ud
  ^-  @dr
  =/  raw=@dr  (mul ~s5 (bex attempt))
  ?:  (gth raw ~s60)  ~s60
  raw
::
++  retry-wire
  |=  ticket=retry-ticket
  ^-  wire
  /mp-auto-retry/(scot %t move-id.ticket)/(scot %ud attempt.ticket)/(scot %ud generation.ticket)
::
++  parse-retry-wire
  |=  =wire
  ^-  (unit retry-ticket)
  ?.  ?=([%mp-auto-retry @ @ @ ~] wire)  ~
  =/  move-id=(unit @t)  (slaw %t i.t.wire)
  ?~  move-id  ~
  =/  attempt=(unit @ud)  (slaw %ud i.t.t.wire)
  ?~  attempt  ~
  =/  generation=(unit @ud)  (slaw %ud i.t.t.t.wire)
  ?~  generation  ~
  `[u.move-id u.attempt u.generation]
::
++  decide
  |=  [status=mp-outbox-status:ct attempt=@ud]
  ^-  retry-decision
  ?.  (active status)
    [%stop %terminal]
  ?:  (gte attempt max-attempts)
    [%stop %exhausted]
  =/  next-attempt=@ud  (add attempt 1)
  [%retry next-attempt (retry-delay next-attempt)]
--
