::  Owner-only HTTP projection. Credentials occur only in decoded POST cards.
::  Viki owns sessions; this adapter never invokes a model or admits a tool.
/-  nc=native-coding, np=native-coding-provider, nf=native-coding-fleet,
    ss=seat-session
/+  loop=native-coding-loop, journal=native-coding-session,
    codec=native-coding-tool-codec, cr=codex-responses,
    law=native-coding-provider, guard=viki-scry-guard,
    terminal=native-coding-terminal, reviews=native-coding-review-http, project=native-coding-project,
    opening=native-coding-opening-http, files=native-coding-files-http,
    campaigns=native-coding-campaign-http, fleet-http=native-coding-fleet-http,
    onboarding=native-coding-onboarding-http,
    workspaces=native-coding-session-workspace-http,
    mappings=native-coding-compiler-mapping-http,
    exports=native-coding-compiler-exports-http,
    deployment=native-coding-deployment-http, running=native-coding-running-http,
    completion=native-coding-completion-http, git-http=native-coding-git-http,
    context-json=native-coding-context-json,
    solo=native-coding-solo-review-http, connection=native-coding-connection-http,
    decision-http=native-coding-candidate-decision-http
|%
+$  viewer  [session=@ux after=@ud cursor=@t]
++  git-proposal-get
  |=  [our=@p now=@da url=@t]
  ^-  (unit json)
  (route:git-http our now url)
++  completion-get
  |=  [our=@p now=@da url=@t]
  ^-  (unit json)
  (route:completion our now url)
++  compiler-exports-get
  |=  [our=@p now=@da url=@t]
  ^-  (unit json)
  (route:exports our now url)
++  deployment-get
  |=  [our=@p now=@da url=@t]
  ^-  (unit json)
  =/  current  (route:running our now url)
  ?^  current  current
  (route:deployment our now url)
++  workspace-get
  |=  [our=@p now=@da url=@t]
  ^-  (unit json)
  (route:workspaces our now url)
++  compiler-mapping-get
  |=  [our=@p now=@da url=@t]
  ^-  (unit json)
  (route:mappings our now url)
++  query
  |=  text=@t
  ^-  (unit viewer)
  =/  parsed
    %-  mole
    |.
    =/  one  (split:terminal 38 text)
    =/  two  (split:terminal 38 tail.one)
    ?>  &(found.one found.two)
    ?>  &(!=('' head.one) (lte (met 3 text) 200))
    =/  sid=@ux  (need (slaw %ux head.one))
    =/  after=@ud  (need (rush head.two dim:ag))
    ?>  &((lte after 4.096) =(head.one (scot %ux sid)))
    =/  cursor=@ux  (need (slaw %ux tail.two))
    ?>  =(tail.two (scot %ux cursor))
    [sid after tail.two]
  parsed
++  read
  |=  [our=@p now=@da]
  ^-  (unit [projects=(map @t project:nc) sessions=(list public-session:loop)])
  ?.  (agent-live:guard our now %viki)  ~
  =/  projects=(map @t project:nc)
    .^((map @t project:nc) %gx /(scot %p our)/viki/(scot %da now)/native-coding/projects/noun)
  =/  sessions=(list public-session:loop)
    .^((list public-session:loop) %gx /(scot %p our)/viki/(scot %da now)/native-coding/sessions/noun)
  `[projects sessions]
++  selection
  |=  object=json
  ^-  selection:np
  =/  supplied  (field:cr object 'transport')
  =/  transport=@t
    ?~  supplied  'api'
    ?>  ?=(%s -.u.supplied)
    p.u.supplied
  ?:  |(=('codex-cli' transport) =('claude-cli' transport))
    =/  codex=?  =('codex-cli' transport)
    =/  chosen=selection:np
      [%native-coding-provider-v1 ?:(codex %codex %anthropic) transport ?:(codex codex-cli-endpoint:np claude-cli-endpoint:np) ?:(codex %responses %messages) [%.n %.y %.n] (need (string:cr object 'key'))]
    ?>  (selection-valid:law chosen)
    chosen
  ?>  =('api' transport)
  =/  provider=@t  (need (string:cr object 'provider'))
  ?>  ?=(provider:np provider)
  =/  format=wire-format:np
    ?:(=(%anthropic provider) %messages ?:(|(=(%xai provider) =(%compatible provider)) %chat %responses))
  =/  endpoint=@t
    ?-  provider
      %openai  openai-endpoint:np
      %codex  codex-endpoint:np
      %anthropic  anthropic-endpoint:np
      %xai  xai-endpoint:np
      %compatible  (need (string:cr object 'endpoint'))
    ==
  =/  chosen=selection:np
    [%native-coding-provider-v1 provider (need (string:cr object 'model')) endpoint format [%.y %.y %.n] (need (string:cr object 'key'))]
  ?>  (selection-valid:law chosen)
  chosen
++  worker
  |=  [our=@p object=json]
  ^-  @p
  =/  supplied  (string:cr object 'worker')
  ?~  supplied  our
  =/  ship=@p  (need (slaw %p u.supplied))
  ?>  =(u.supplied (scot %p ship))
  ship
++  fleet-view
  |=  [our=@p now=@da]
  ^-  json
  ?.  (agent-live:guard our now %viki)
    (pairs:enjs:format ~[['available' b+%.n] ['workers' a+~] ['tasks' a+~]])
  =/  held=organ:nf
    .^(organ:nf %gx /(scot %p our)/viki/(scot %da now)/native-coding/fleet/noun)
  =/  workers=(list json)
    %+  turn  ~(tap by workers.held)
    |=  [seat=seat:ss w=worker:nf]
    (pairs:enjs:format ~[['id' s+(scot %tas seat)] ['ship' s+(scot %p moon.seat-session.route.w)] ['generation' (numb:enjs:format generation.w)] ['capacity' (numb:enjs:format capacity.w)] ['roles' a+(turn ~(tap in roles.w) |=(r=role:nf s+r))] ['inspection' s+(scot %ux inspection.w)] ['observed' b+?=(^ observed.w)]])
  =/  tasks=(list json)
    %+  turn  ~(tap by tasks.held)
    |=  [id=@ux e=entry:nf]
    (pairs:enjs:format ~[['id' s+(scot %ux id)] ['project' s+project.context.task.e] ['session' s+(scot %ux session.context.task.e)] ['role' s+role.task.e] ['objective' s+objective.task.e] ['phase' s+phase.e] ['worker' s+?~(assignment.e '' (scot %p worker.u.assignment.e))] ['released' b+released.e] ['evidence' a+(turn evidence.e |=(id=@ux s+(scot %ux id)))]])
  (pairs:enjs:format ~[['available' b+%.y] ['workers' a+workers] ['tasks' a+tasks]])
++  hex
  |=  [object=json key=@t]
  ^-  @ux
  =/  text=@t  (need (string:cr object key))
  =/  value=@ux  (need (slaw %ux text))
  ?>  &(!=(0 value) (lte (met 0 value) 256) =(text (scot %ux value)))
  value
++  command
  ::  Same-origin CSRF token is checked before interpreting any command.
  |=  [our=@p now=@da token=@uv raw=@t]
  ^-  (each [id=@ux target=@tas payload=*] @tas)
  ?.  (lte (met 3 raw) 131.072)  [%| %body-too-large]
  =/  parsed
    %-  mole
    |.
    =/  object=json  (need (de:json:html raw))
    ?>  =(`(scot %uv token) (string:cr object 'nonce'))
    =/  kind=@t  (need (string:cr object 'kind'))
    ?:  ?=(?(%project-create %project-observe) kind)
      =/  text=@t  (need (string:cr object 'session'))
      =/  viewer=@ux  (need (slaw %ux text))
      ?>  &((lte (met 0 viewer) 256) =(text (scot %ux viewer)))
      [viewer %viki (decode:onboarding our now object)]
    ?:  ?=(?(%campaign-observe %campaign-scope %campaign-disable) kind)
      ::  Session is only a view selector here; detached zero is legitimate.
      =/  text=@t  (need (string:cr object 'session'))
      =/  viewer=@ux  (need (slaw %ux text))
      ?>  &((lte (met 0 viewer) 256) =(text (scot %ux viewer)))
      [viewer %viki [%native-coding-review-campaign-action-v1 (action:campaigns our now kind object)]]
    =/  session=@ux  (hex object 'session')
    ?:  =('candidate-decide' kind)
      [session %cantrip (decode:decision-http our now object)]
    ?:  =('connection-select' kind)
      [session %viki (decode:connection our now object)]
    ?:  ?=(?(%solo-review-enable %solo-review-disable %solo-review-start %solo-review-observe) kind)
      [session %viki (decode:solo our now object)]
    ?:  ?=(?(%completion-observe %completion-accept) kind)
      [session %viki (decode:completion our now object)]
    ?:  ?=(?(%deployment-grant %deployment-revoke %deployment-prepare %deployment-observe %deployment-activate %deployment-cancel) kind)
      [session %cantrip (decode:deployment our now object)]
    ?:  ?=(?(%compiler-mapping-configure %compiler-mapping-revoke) kind)
      [session %cantrip (decode:mappings our now object)]
    ?:  ?=(?(%compiler-exports-configure %compiler-exports-revoke) kind)
      [session %cantrip (decode:exports our now object)]
    ?:  ?=(?(%workspace-prepare %workspace-observe) kind)
      [session %viki (decode:workspaces our now object)]
    =/  nonce=@ux  (shax (jam [%native-coding-http-v1 our token session raw]))
    ?:  =('git-candidate' kind)
      [session %viki (decode:git-http our nonce object)]
    ?:  =('terminal' kind)
      =/  input=@t  (need (string:cr object 'input'))
      =/  expected  (field:cr object 'source')
      =/  action=action:loop
        ?~  expected  [%terminal session nonce input]
        [%terminal-at session nonce (hex object 'source') input]
      [session %viki [%native-coding-action-v1 action]]
    ?:  =('open' kind)
      ?>  (open-ready:workspaces our now session object)
      =/  target=@p  (worker our object)
      ?:  !=(our target)
        [session %viki (moon-open:fleet-http our now session object)]
      =/  chosen=selection:np  (selection object)
      [session %viki (request:opening object session chosen target)]
    ?:  =('fleet-enqueue' kind)
      [session %viki (queue:fleet-http session nonce object)]
    ?:  =('opening-observe' kind)
      [session %viki [%native-coding-session-open-observe-v1 (hex object 'opening')]]
    ?:  =('select' kind)
      =/  chosen=selection:np  (selection object)
      [session %viki [%native-coding-action-v1 [%select session chosen credential.chosen (worker our object)]]]
    ?:  =('fleet-inspect' kind)
      =/  seat=@t  (need (string:cr object 'seat'))
      ?>  ?=(seat:ss seat)
      [session %viki [%native-coding-fleet-action-v1 [%inspect seat]]]
    ?:  =('fleet-control' kind)
      =/  action=@t  (need (string:cr object 'control'))
      ?>  ?=(?(%pause %observe %cancel) action)
      [session %viki [%native-coding-fleet-action-v1 [%control (hex object 'task') action]]]
    ?:  =('review-observe' kind)
      [session %viki [%native-coding-review-action-v1 [%observe (hex object 'candidate')]]]
    ?:  =('review-bind' kind)
      =/  workspace=@tas  (need (string:cr object 'workspace'))
      ?>  (segment-valid:project workspace)
      [session %viki [%native-coding-review-action-v1 [%bind (hex object 'candidate') workspace]]]
    ?:  =('grant-revoke' kind)
      [session %cantrip [%native-coding-revoke-v1 (hex object 'grant')]]
    ?:  =('configure' kind)
      =/  chosen=selection:np  (selection object)
      ?>  =(~ (cli-backend:law chosen))
      =/  secret=@t  (need (string:cr object 'secret'))
      ?>  (text-valid:law secret credential-limit:np)
      =/  credentials=credentials:np
        [provider.chosen endpoint.chosen secret (fall (string:cr object 'account') '')]
      [session %codex-inference [%native-coding-configure credential.chosen credentials]]
    ?:  =('provider-select' kind)
      =/  chosen=selection:np  (selection object)
      ?>  =(~ (cli-backend:law chosen))
      [session %codex-inference [%native-coding-select credential.chosen chosen]]
    ?:  =('adopt-codex' kind)
      =/  key=@tas  (need (string:cr object 'key'))
      ?>  (name-valid:law key)
      [session %codex-inference [%native-coding-adopt-codex key]]
    =/  action=action:loop
      ?:  =('pause' kind)  [%pause session %.n]
      ?:  =('interrupt' kind)  [%pause session %.y]
      ?:  =('resume' kind)  [%resume session]
      ?:  =('observe' kind)  [%observe session]
      !!
    [session %viki [%native-coding-action-v1 action]]
  ?~  parsed  [%| %command-invalid]
  [%& u.parsed]
++  record-json
  |=  r=record:journal
  ^-  json
  =/  text=@t
    ?:  ?=(%operator -.body.r)  text.body.r
    ?:  ?=(%terminal -.body.r)  (cat 3 input.body.r (cat 3 '\0a' output.body.r))
    ?:  ?=(%model -.body.r)  text.result.body.r
    ?:  ?=(%tool -.body.r)
      =/  result  (result-text:codec result.body.r)
      ?:(?=(%& -.result) p.result 'Result exceeds presentation bound; inspect the retained native result.')
    ?:  ?=(%selection -.body.r)  (cat 3 'Provider selected: ' model.value.body.r)
    ?:  ?=(%status -.body.r)  (cat 3 (scot %tas value.body.r) (cat 3 ': ' (scot %tas reason.body.r)))
    ?:  ?=(%context -.body.r)  (cat 3 'Prepared request context: ' (scot %ux request.value.body.r))
    ::  All journal body variants are handled above; no private provider
    ::  receipt is a journal body.
    reason.body.r
  =/  frozen=json  ?:(?=(%context -.body.r) (receipt:context-json value.body.r) ~)
  (pairs:enjs:format ~[['id' s+(scot %ux id.r)] ['sequence' (numb:enjs:format sequence.r)] ['kind' s+-.body.r] ['text' s+text] ['file' (record:files r)] ['context' frozen]])
++  command-status
  |=  [session=@ux receipt=@ux kind=?(%submitted %delivered %refused)]
  ^-  @t
  =/  text=@t
    ?-  kind
      %submitted  ': submitted; observing native retention'
      %delivered  ': delivered; inspect session for outcome'
      %refused  ': native delivery refused'
    ==
  (rap 3 ~[(scot %ux session) ' ' (scot %ux receipt) text])
++  scoped-delivery
  |=  [selected=@ux delivery=@t]
  ^-  @t
  =/  first  (split:terminal 32 delivery)
  ?:  =('Refused' head.first)
    =/  owner  (split:terminal 32 tail.first)
    =/  parsed  (slaw %ux head.owner)
    ?~  parsed  ''
    ?.  =(head.owner (scot %ux u.parsed))  ''
    ?:(|(=(0 u.parsed) =(selected u.parsed)) delivery '')
  ?.  =('0x' (cut 3 [0 2] delivery))  delivery
  =/  parsed  (slaw %ux head.first)
  ?~  parsed  ''
  ?.  &(found.first =(head.first (scot %ux u.parsed)) =(selected u.parsed))  ''
  =/  receipt  (split:terminal 58 tail.first)
  =/  value  (slaw %ux head.receipt)
  ?~  value  ''
  ?.  &(found.receipt =(head.receipt (scot %ux u.value)))  ''
  tail.first
++  snapshot
  |=  [our=@p now=@da token=@uv connected=? selected=@ux after=@ud delivery=@t editor=json]
  ^-  json
  =.  delivery  (scoped-delivery selected delivery)
  =/  current  (read our now)
  =/  projects=(list json)
    ?~  current  ~
    (turn ~(tap by projects.u.current) |=([id=@t p=project:nc] (project-json:opening p)))
  =/  sessions=(list json)
    ?~  current  ~
    (turn sessions.u.current |=([s=public-session:loop] (pairs:enjs:format ~[['id' s+(scot %ux id.session.s)] ['project' s+project.session.s] ['objective' s+objective.session.s] ['phase' s+phase.s] ['model' s+model.selection.s] ['worker' s+(scot %p worker.s)] ['source' (revision:files working.session.s)]])))
  =/  found=(unit public-session:loop)
    ?~  current  ~
    =/  matching  (skim sessions.u.current |=(s=public-session:loop =(selected id.session.s)))
    ?~(matching ~ `i.matching)
  =/  records=(list record:journal)  ?~(found ~ records.u.found)
  =/  next=@ud  ?~(found 0 sequence.u.found)
  =/  reset=?  (gth after next)
  =/  rows=(list record:journal)
    (scag 32 (skim records |=(r=record:journal (gte sequence.r ?:(reset 0 after)))))
  =/  until=@ud  ?~(rows ?:(reset 0 after) +((rear (turn rows |=(r=record:journal sequence.r)))))
  =/  fleet=json  (fleet-view our now)
  =/  review-data=json  (reviews:reviews our now selected)
  =/  solo-review=json  (view:solo our now selected review-data)
  =/  grant-data=json  (grants:reviews our now selected)
  =/  openings=(unit (list row:opening))  (read:opening our now)
  =/  campaigns=json  (view:campaigns our now)
  =/  setup=json  (rows-json:onboarding (read:onboarding our now))
  =/  workspace-rows=(unit (list row:workspaces))  (read:workspaces our now)
  =/  workspace-view=json  (view:workspaces our now workspace-rows selected)
  =/  compiler-mappings=json  (view:mappings our now selected)
  =/  compiler-exports=json  (view:exports our now selected)
  =/  deployments=json  (view:deployment our now selected)
  =/  completion-view=json  (view:completion our now selected %.n ~ ~)
  =/  ids=(list @ux)
    ?~(current ~ (turn sessions.u.current |=(s=public-session:loop id.session.s)))
  =/  placements=json  (view:fleet-http our now ids openings)
  =/  reserved-ids=(list @ux)
    ~(tap in (silt (weld ids ?~(workspace-rows ~ (turn u.workspace-rows |=(r=row:workspaces id.r))))))
  =/  next-id=@ux  ?~(current 0x0 ?~(workspace-rows 0x0 (next:opening our token ids reserved-ids openings)))
  =/  cursor=@ux  (shax (jam [current fleet placements review-data solo-review grant-data openings campaigns setup workspace-view compiler-mappings compiler-exports deployments completion-view connected delivery editor token]))
  %-  pairs:enjs:format
  :~  ['nonce' s+(scot %uv token)]
      ['candidateDecide' b+%.y]
      ['cursor' s+(scot %ux cursor)]
      ['nextSession' s+(scot %ux next-id)]
      ['ready' b+&(connected ?=(^ current))]
      ['owner' s+(scot %p our)]
      ['session' s+(scot %ux selected)]
      ['phase' s+?~(found 'detached' phase.u.found)]
      ['projects' a+projects]
      ['sessions' a+sessions]
      ['openings' (rows-json:opening openings)]
      ['campaigns' campaigns]
      ['completion' completion-view]
      ['onboarding' setup]
      ['workspaces' workspace-view]
      ['compilerMappings' compiler-mappings]
      ['compilerExports' compiler-exports]
      ['deployments' deployments]
      ['fleet' fleet]
      ['placements' placements]
      ['reviews' review-data]
      ['soloReview' solo-review]
      ['grants' grant-data]
      ['records' a+(turn rows record-json)]
      ['after' (numb:enjs:format until)]
      ['more' b+(lth until next)]
      ['reset' b+reset]
      ['delivery' s+delivery]
      ['editor' editor]
  ==
++  page
  ^-  @t
  %+  rap  3
  :~  '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Pataphor coding</title><link rel="stylesheet" href="/apps/pataphor-native/coding/xterm.css"><script defer src="/apps/pataphor-native/coding/native-coding-deployment.js"></script><script defer src="/apps/pataphor-native/coding/codemirror.js"></script><script defer src="/apps/pataphor-native/coding/hoon-editor.js"></script><script defer src="/apps/pataphor-native/coding/native-coding-files.js"></script><script defer src="/apps/pataphor-native/coding/native-coding-onboarding.js"></script><script defer src="/apps/pataphor-native/coding/native-coding-session-workspace.js"></script><style>details[open]{max-height:55vh;overflow:auto}#native-onboarding,#native-session-workspaces{flex-shrink:0}</style>'
      '<script defer src="/apps/pataphor-native/coding/native-coding-completion.js"></script>'
      '<script defer src="/apps/pataphor-native/coding/native-coding-flow.js"></script>'
      '<style>*{box-sizing:border-box}html,body{height:100%;margin:0;background:#181818;color:#ddd;font:12px system-ui}body{display:flex;flex-direction:column}header,nav{display:flex;gap:6px;align-items:center;padding:6px;border-bottom:1px solid #333;flex-wrap:wrap}button,input,select{background:#26262a;color:#ddd;border:1px solid #444;padding:5px;font:inherit}button{cursor:pointer}#terminal{flex:1;min-height:0;overflow:hidden;padding:6px}.xterm{height:100%}#status{flex:1}details{padding:4px 8px}details>div{display:flex;gap:6px;flex-wrap:wrap;padding:8px}input{min-width:100px;max-width:230px}a{color:#ffba50}</style><script defer src="/apps/pataphor-native/coding/xterm.js"></script><script defer src="/apps/pataphor-native/coding/native-coding-compiler-mapping.js"></script><script defer src="/apps/pataphor-native/coding/native-coding-compiler-exports.js"></script><script defer src="/apps/pataphor-native/coding/native-coding.js"></script></head><body>'
      '<header><strong>Pataphor · native coding</strong><span id="status">Connecting</span><button data-action="reconnect">Reconnect</button><a href="/apps/pataphor-native">Previous console</a></header><nav><select id="project" aria-label="Project"></select><select id="session" aria-label="Session"><option value="">Select session</option></select><button data-action="open">New session</button><button data-action="pause">Pause</button><button data-action="resume">Resume</button><button data-action="interrupt">Interrupt</button><button data-action="submit">Submit</button><span>Enter submits · Shift+Enter adds a line</span></nav>'
      '<nav><a href="/apps/pataphor-native/source-import">Prepare project sources</a></nav>'
      '<details><summary>Files</summary><div id="native-files" style="display:block"></div></details>'
      '<div id="native-onboarding"></div>'
      '<div id="native-completions" style="flex-shrink:0"></div>'
      '<div id="native-session-workspaces"></div>'
      '<div id="native-compiler-mapping" style="flex-shrink:0"></div>'
      '<div id="native-compiler-exports" style="flex-shrink:0"></div>'
      '<div id="native-deployments" style="flex-shrink:0"></div>'
      '<details><summary>Moon placement and queue</summary><div><select id="moon-placement" aria-label="Unused configured moon session"></select><span id="placement-detail"></span></div><p>For a moon, choose its worker and an unused placement before New session. The placement fixes its session ID, provider and model; local provider fields do not change it. Opening does not queue a moon session.</p><div><select id="queue-role" aria-label="Queue role"><option value="">Choose role</option><option value="build">Build</option><option value="check">Check</option></select><label>Path claims, one absolute project path per line<textarea id="queue-paths" rows="3" maxlength="32768" placeholder="/app/example/hoon"></textarea></label><label>Dependency tasks<select id="queue-dependencies" multiple size="3" aria-label="Dependency task IDs"></select></label><button data-action="fleet-enqueue">Queue selected session</button></div><p>Empty path claims reserve no file changes. Dependencies must be retained tasks in this project. Queueing is an explicit request; Viki checks the current session, source, grants and path claims before dispatch.</p></details>'
      '<details><summary>AI reviewer campaigns and standing scope</summary><div><select id="campaign" aria-label="Review campaign"></select><button data-action="campaign-observe">Observe campaign</button></div><pre id="campaign-detail"></pre><p>Up to 32 retained campaigns and five reviewer jobs per campaign. Observe advances native coordination when recorded prerequisites are satisfied.</p><pre id="campaign-scope-detail"></pre><div><button data-action="campaign-load">Load current scope into form</button><button data-action="campaign-disable">Disable current standing scope</button></div><div id="campaign-reviewers"></div><p>Enter the exact configuration already installed on each distinct registered moon. These fields do not configure moons or verify their credentials. Generation is the reviewer generation, which may differ from its fleet generation. Parent identity is fixed to this planet.</p><label><input id="campaign-consent" type="checkbox" style="min-width:auto">I authorize these reviewers for this project until I disable or replace this scope.</label><button data-action="campaign-scope">Enable standing review scope</button></details>'
      '<details><summary>New session and provider settings</summary><div><select id="worker" aria-label="Session worker"></select><select id="transport" aria-label="Model connection"><option value="codex-cli">Codex subscription</option><option value="claude-cli">Claude Code subscription</option><option value="api">API credential</option></select><a href="/apps/pataphor-cli">Connect subscription</a><select id="provider"><option>codex</option><option>openai</option><option>anthropic</option><option>xai</option><option>compatible</option></select><input id="model" aria-label="Model" placeholder="Model" value="codex-cli"><input id="key" aria-label="Pairing or credential name" value="desktop"><input id="endpoint" aria-label="Compatible API endpoint" placeholder="Compatible HTTPS endpoint"><input id="objective" aria-label="New session objective" placeholder="New session objective"><button data-action="provider-select">Register provider selection</button><button data-action="select">Use provider for session</button></div>'
      '<fieldset><legend>Tools delegated to this session</legend><div id="delegation-operations"></div><p>Choose permitted tools, then click New session. Delegation stays active until revoked; project restrictions still apply.</p><label>Maximum work per native evaluation (microseconds) <input id="max-eval-work" type="number" min="1" max="2000000" step="1" value="2000000"></label></fieldset><div id="api-credentials" hidden><input id="secret" type="password" autocomplete="off" aria-label="Provider access token" placeholder="Access token"><input id="account" autocomplete="off" aria-label="Codex account ID" placeholder="Codex account ID"><button data-action="configure">Store credential on Urbit</button><button data-action="adopt-codex">Use existing Codex access</button></div><p id="connection-help">Use an existing CLI subscription on your computer. Pair its name using Connect subscription. Proposals return to Urbit for permission checks and native tool execution.</p></details>'
      '<details><summary>Inspection permissions for new sessions</summary><label>App and exact read path, one per line<textarea id="inspection-paths" rows="3" maxlength="32768" placeholder="graf /status/noun" aria-describedby="inspection-help" disabled></textarea></label><p id="inspection-help">Select the inspect tool and enter exact app paths to delegate.</p></details>'
      '<details><summary>Session openings</summary><div><select id="opening" aria-label="Session opening"></select><button data-action="opening-observe">Observe opening</button><button data-action="opening-attach">Attach opened session</button></div><pre id="opening-detail" aria-live="polite"></pre></details><details><summary>Fleet workers and tasks</summary><div><select id="fleet-seat" aria-label="Fleet seat"></select><button data-action="fleet-inspect">Inspect worker</button><span id="fleet-status"></span></div><div><select id="fleet-task" aria-label="Fleet task"></select><button data-action="fleet-observe">Observe task</button><button data-action="fleet-pause">Pause task</button><button data-action="fleet-cancel">Cancel task</button></div><pre id="fleet-detail"></pre></details>'
      '<details><summary>Candidate review and delegation</summary><div><select id="review-candidate" aria-label="Candidate"></select><button data-action="review-observe">Observe candidate</button><input id="review-workspace" aria-label="Challenge workspace" placeholder="Boxy challenge workspace"><button data-action="review-bind">Connect challenge</button></div><pre id="review-detail"></pre><p>Bounded view: up to eight candidates and eight checks per candidate. Viki reads the full native record before judgment.</p><div><select id="standing-grant" aria-label="Delegation"></select><button data-action="grant-revoke">Revoke delegation</button></div><pre id="grant-detail"></pre></details><main id="terminal"></main></body></html>'
  ==
--
