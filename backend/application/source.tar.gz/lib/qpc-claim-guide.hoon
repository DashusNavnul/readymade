::  /lib/qpc-claim-guide
::
::  Exclude declared path overlaps, then respect declared work priority.
::  Equal priorities prefer the oldest recorded task, then its stable id.
::  These inputs describe work we can inspect. Text hashes do not measure
::  semantic distance and cannot justify overruling the queue's priority.
::
/-  mq=multiplayer-queue
/+  qcq=qpc-ct-qualia
|%
::  Shared identity observable used by seiv-guidance with ordered samples.
::  Retained for that consumer; queue ordering does not use a tensor.
++  lens
  ^-  observable:qcq
  :*  o00=[pos=& mag=1.000.000]
      o01=[pos=& mag=0]
      o10=[pos=& mag=0]
      o11=[pos=& mag=1.000.000]
  ==
::
::  DECLARED TARGETS.  By convention payload-ref may name the paths a task will
::  touch, space-separated.  This is a convention rather than a schema change
::  because sur/multiplayer-queue is immutable coordination vocabulary -- a task
::  that declares nothing simply gets no collision protection, which is honest:
::  the queue cannot guard work that refuses to say what it edits.
++  target-set
  |=  t=task:mq
  ^-  (set @t)
  =/  cs=tape  (trip payload-ref.t)
  =|  cur=tape
  =|  acc=(list @t)
  |-  ^-  (set @t)
  ?~  cs
    (silt ?~(cur acc [(crip (flop cur)) acc]))
  ?:  =(' ' i.cs)
    $(cs t.cs, cur ~, acc ?~(cur acc [(crip (flop cur)) acc]))
  $(cs t.cs, cur [i.cs cur])
::
::  Does this candidate touch anything already being worked on?
++  collides
  |=  [inflight=(list task:mq) t=task:mq]
  ^-  ?
  =/  mine=(set @t)  (target-set t)
  ?:  =(0 ~(wyt in mine))  %.n
  %+  lien  inflight
  |=  o=task:mq
  =/  theirs=(set @t)  (target-set o)
  !=(0 ~(wyt in (~(int in mine) theirs)))
::
::  Score is the task's declared priority, in the same units as /claimable.
::  It is not a confidence or diversity estimate. Overlaps remain excluded
::  regardless of priority. Missing targets offer no collision protection.
++  guide
  |=  [inflight=(list task:mq) candidates=(list task:mq)]
  ^-  (list [score=@ud task=task:mq])
  =/  safe=(list task:mq)
    (skip candidates |=(t=task:mq (collides inflight t)))
  =/  scored=(list [score=@ud task=task:mq])
    %+  turn  safe
    |=  t=task:mq
    ^-  [@ud task:mq]
    [priority.t t]
  %+  sort  scored
  |=  [a=[score=@ud task=task:mq] b=[score=@ud task=task:mq]]
  ^-  ?
  ?:  =(score.a score.b)
    ?:  =(recorded-at.task.a recorded-at.task.b)
      (lth task-id.task.a task-id.task.b)
    (lth recorded-at.task.a recorded-at.task.b)
  (gth score.a score.b)
--
