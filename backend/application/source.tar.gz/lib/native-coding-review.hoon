::  Viki's private review ledger. Cantrip supplies candidate/check/landing
::  truth, Boxy supplies actual challenge history, and Viki retains decisions.
/-  nc=native-coding, bx=boxy, protocol=native-coding-review,
    ri=native-coding-review-inspection
/+  loop=native-coding-loop, session=native-coding-session,
    accept=native-coding-accept, judgment=native-coding-judgment,
    guard=viki-scry-guard, project=native-coding-project,
    campaigns=native-coding-review-orchestration,
    request=native-coding-review-request, grants=cantrip-native-coding,
    admissions=cantrip-native-review, scoped=native-coding-session-project,
    inspected=native-coding-inspected-review,
    proof=cantrip-native-inspected-review,
    dispatch=native-coding-review-decision, local=native-coding-local-decision,
    fleet=native-coding-fleet-runtime
|%
+$  card  card:agent:gall
+$  entry
  $:  candidate=candidate:nc  objective=@t  model=@t
      workspace=(unit @tas)  observed=(unit record:accept)
      decision=(unit decision:accept)  advanced=?
  ==
+$  state  (map @ux entry)
+$  change  [cards=(list card) reviews=state coding=state:loop]
+$  command
  $%  [%start candidate=@ux]
      [%bind candidate=@ux workspace=@tas]
      [%observe candidate=@ux]
  ==
+$  negative-request
  [%native-coding-review-negative-v1 campaign=@ux request=@ux]
++  advance-landed
  ::  Called only after status joins the exact canonical approval and landing.
  ::  A unique retained assignment preserves the existing fleet continuation.
  ::  Neither model text nor worker location selects automatic continuation.
  |=  [at=@da coding=state:loop e=entry:session source=revision:nc evidence=@ux]
  ^-  (each transition:session @tas)
  =/  automatic=?  ?=(^ (assigned:fleet fleet.coding id.session.e))
  (advance-source:session at e source evidence automatic)
++  objective
  ::  Include all retained operator instructions in their actual order.
  |=  e=entry:session
  ^-  (each @t @tas)
  =/  text=@t
    (rap 3 (murn records.e |=(r=record:session ?:(?=(%operator -.body.r) `(cat 3 text.body.r '\0a') ~))))
  ?:  |(=(0 text) (gth (met 3 text) 65.536))  [%| %review-objective-capacity]
  [%& text]
++  notify
  |=  [our=@p id=@ux held=entry]
  ^-  (list card)
  :~  (changed:loop session.context.candidate.held 0)
      (poke:loop our %graf /native-coding/review-retain [%attest [%native-coding-review-v1 id held]])
  ==
++  put
  |=  [our=@p reviews=state coding=state:loop id=@ux e=entry cards=(list card)]
  ^-  change
  [(weld (notify our id e) cards) (~(put by reviews) id e) coding]
++  act
  |=  [b=bowl:gall reviews=state coding=state:loop action=command]
  ^-  change
  ?.  =(our.b src.b)  [~ reviews coding]
  =/  id=@ux
    ?-  -.action
      %start  candidate.action
      %bind  candidate.action
      %observe  candidate.action
    ==
  =/  found  (~(get by reviews) id)
  ?:  ?=(%start -.action)
    ?^  found  [(notify our.b id u.found) reviews coding]
    ?:  (gte ~(wyt by reviews) 128)  [~[(refused:loop 0x0 %review-capacity)] reviews coding]
    =/  candidate  (~(get by candidates.coding) id)
    ?~  candidate  [~ reviews coding]
    =/  e  (~(get by sessions.coding) session.context.u.candidate)
    ?~  e  [~ reviews coding]
    ?.  &(=(working.session.u.e source.context.u.candidate) ?=(~ pending.u.e))
      [~[(refused:loop id.session.u.e %review-source-mismatch)] reviews coding]
    =/  goal  (objective u.e)
    ?:  ?=(%| -.goal)  [~[(refused:loop id.session.u.e p.goal)] reviews coding]
    =/  held=entry  [u.candidate p.goal model.selection.u.e ~ ~ ~ %.n]
    (put our.b reviews coding id held ~[(poke:loop our.b %cantrip /native-coding/review/(scot %ux id) [%native-coding-review-v1 id])])
  ?~  found  [~ reviews coding]
  ?:  ?=(%bind -.action)
    ?.  &(!=(0 workspace.action) ?=(~ decision.u.found))  [~ reviews coding]
    =.  reviews  (~(put by reviews) id u.found(workspace `workspace.action))
    (observe b reviews coding id)
  (observe b reviews coding id)
++  observe
  ::  A lost callback is repaired by a read, not by reissuing a write.
  |=  [b=bowl:gall reviews=state coding=state:loop id=@ux]
  ^-  change
  =/  found  (~(get by reviews) id)
  ?~  found  [~ reviews coding]
  ?.  (agent-live:guard our.b now.b %cantrip)  [~ reviews coding]
  =/  canonical=(unit record:accept)
    .^((unit record:accept) %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/candidate/(scot %ux id)/noun)
  ?~  canonical  [(notify our.b id u.found) reviews coding]
  (status b reviews coding id u.canonical)
++  status
  ::  Even a same-ship callback is joined to Cantrip's canonical retained row.
  |=  [b=bowl:gall reviews=state coding=state:loop id=@ux incoming=record:accept]
  ^-  change
  ?.  &(=(our.b src.b) (agent-live:guard our.b now.b %cantrip))  [~ reviews coding]
  =/  found  (~(get by reviews) id)
  ?~  found  [~ reviews coding]
  =/  canonical=(unit record:accept)
    .^((unit record:accept) %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/candidate/(scot %ux id)/noun)
  ?.  =(canonical `incoming)  [~ reviews coding]
  =/  held=entry  u.found
  ?.  &(=(candidate.held candidate.incoming) (valid:accept (~(put by *ledger:accept) id incoming)))
    [~ reviews coding]
  =.  held  held(observed `incoming)
  =/  e  (~(get by sessions.coding) session.context.candidate.held)
  ?~  e  (put our.b reviews coding id held ~)
  =/  current-goal  (objective u.e)
  ?:  |(?=(%| -.current-goal) !=(objective.held p.current-goal))
    (put our.b reviews coding id held ~[(refused:loop id.session.u.e %review-instructions-changed)])
  ?:  &(!advanced.held =(%refused stage.incoming))
    =/  denied  (grant-error our.b now.b incoming)
    ?^  denied  (hold b reviews coding id held u.denied)
    ?^  decision.incoming
      ?.  =(decision.held decision.incoming)  (put our.b reviews coding id held ~)
      =/  denied
        ?.  &(=(%revise verdict.u.decision.incoming) (passed:accept report.u.decision.incoming))  ~
        (scope-error our.b now.b candidate.held objective.held u.decision.incoming)
      ?^  denied  (hold b reviews coding id held u.denied)
      (revision b reviews coding id held u.e reason.challenge.u.decision.incoming incoming)
    =/  reason=@t
      (cat 3 'Viki requires a revised candidate. Native outcome: ' (cat 3 ?~(reason.incoming 'refused' (scot %tas u.reason.incoming)) (cat 3 '. Retained candidate report: ' (scot %ux id))))
    (revision b reviews coding id held u.e reason incoming)
  ?:  =(%unknown stage.incoming)
    =/  next  (append:session u.e(phase %unknown, resume %unknown) now.b [%status %unknown %candidate-outcome-unconfirmed])
    ?:  ?=(%| -.next)  (put our.b reviews coding id held ~)
    =/  out  (apply:loop b coding p.next)
    (put our.b reviews +.out id held -.out)
  ?:  =(%applied stage.incoming)
    ?:  advanced.held  (put our.b reviews coding id held ~)
    ?.  &(?=(^ decision.held) =(decision.held decision.incoming) ?=(^ landed.incoming))
      (put our.b reviews coding id held ~)
    =/  next  (advance-landed now.b coding u.e revision.u.landed.incoming (digest:accept incoming))
    ?:  ?=(%| -.next)  (put our.b reviews coding id held ~[(refused:loop id.session.u.e p.next)])
    =/  advanced  (apply:loop b coding p.next)
    =/  cards=(list card)
      ?:  =(%ready phase.entry.p.next)  ~[(run-card:loop our.b id.session.u.e)]
      ~
    (put our.b reviews +.advanced id held(advanced %.y) (weld -.advanced cards))
  ?.  &(=(%review stage.incoming) ?=(^ report.incoming))
    (put our.b reviews coding id held ~)
  ?^  decision.held  (put our.b reviews coding id held ~)
  =/  local-result  (offer:local our.b now.b project.incoming candidate.held u.report.incoming objective.held)
  ?:  ?=(%| -.local-result)
    (put our.b reviews coding id held ~[(refused:loop id.session.u.e p.local-result)])
  ?^  p.local-result
    (put our.b reviews coding id held(decision `u.p.local-result) (cards:dispatch our.b coding candidate.held))
  ?:  &(?=(~ workspace.held) (passed:accept u.report.incoming))
    ::  An owner's local-review scope takes a passing candidate first; a
    ::  repeated start is a no-op. Otherwise the parent campaign enforces the
    ::  standing moon scope, and its retained intent prevents redispatch.
    ::  With neither scope nothing can approve, so the journal says so.
    =/  name=@t  id.spec.project.incoming
    ?:  (has-scope:local our.b now.b name)
      (put our.b reviews coding id held ~[(poke:loop our.b %viki /native-coding/local-review-start [%native-local-review-start-v1 id])])
    ?.  (moon-scoped our.b now.b name)
      (unreviewed b reviews coding id held u.e)
    (put our.b reviews coding id held ~[(poke:loop our.b %viki /native-coding/campaign-start [%native-coding-review-campaign-action-v1 [%start id objective.held]])])
  =/  result=(each decision:accept @tas)
    ?.  (passed:accept u.report.incoming)
      (failed-checks:judgment now.b project.incoming candidate.held u.report.incoming)
    ?~  workspace.held  [%| %challenge-required]
    ?.  (agent-live:guard our.b now.b %boxy)  [%| %boxy-unavailable]
    =/  all=state:bx
      .^(state:bx %gx /(scot %p our.b)/boxy/(scot %da now.b)/state/noun)
    =/  workspace  (~(get by workspaces.all) u.workspace.held)
    ?~  workspace  [%| %challenge-workspace-missing]
    (evaluate:judgment our.b now.b project.incoming candidate.held u.report.incoming objective.held model.held u.workspace)
  ?:  ?=(%| -.result)
    (put our.b reviews coding id held ~[(refused:loop id.session.u.e p.result)])
  (put our.b reviews coding id held(decision `p.result) (cards:dispatch our.b coding candidate.held))
++  moon-scoped
  |=  [our=@p at=@da name=@t]
  ^-  ?
  ?.  (agent-live:guard our at %viki)  %.n
  =/  raw=*
    .^(* %gx /(scot %p our)/viki/(scot %da at)/native-coding/review-scopes/noun)
  =/  scopes  ((soft ,(map @t scope:protocol)) raw)
  ?~  scopes  %.n
  =/  s  (~(get by u.scopes) name)
  &(?=(^ s) enabled.u.s)
++  unreviewed
  ::  A passing candidate with no owner review scope cannot be approved.
  ::  Record that once in the session journal instead of waiting silently.
  |=  [b=bowl:gall reviews=state coding=state:loop id=@ux held=entry e=entry:session]
  ^-  change
  ?:  (noted:session e %review-scope-required)  (put our.b reviews coding id held ~)
  =/  next  (append:session e now.b [%status phase.e %review-scope-required])
  ?:  ?=(%| -.next)  (put our.b reviews coding id held ~)
  =/  out  (apply:loop b coding p.next)
  (put our.b reviews +.out id held -.out)
++  complete
  ::  A model's final text is not completion evidence. Viki requires an applied
  ::  candidate judged against the current complete operator instruction set.
  |=  [b=bowl:gall reviews=state coding=state:loop id=@ux request=@ux]
  ^-  change
  ?.  =(our.b src.b)  [~ reviews coding]
  =/  e  (~(get by sessions.coding) id)
  ?~  e  [~ reviews coding]
  ?.  &(=(%judgment phase.u.e) =(request (request-id:session id (dec turn.u.e))))
    [~ reviews coding]
  =/  goal  (objective u.e)
  ?:  ?=(%| -.goal)  [~ reviews coding]
  =/  matches=(list entry)
    %+  skim  ~(val by reviews)
    |=  r=entry
    ?&  advanced.r  =(id session.context.candidate.r)  =(p.goal objective.r)
        ?=(^ observed.r)  ?=(^ landed.u.observed.r)
        =(working.session.u.e revision.u.landed.u.observed.r)
        ?=(^ decision.r)  =(%approve verdict.u.decision.r)
    ==
  ?~  matches
    [~[(refused:loop id %native-completion-evidence-required)] reviews coding]
  ?^  t.matches
    [~[(refused:loop id %native-completion-evidence-required)] reviews coding]
  =/  config  (resolve:scoped our.b now.b projects.coding id project.session.u.e)
  ?:  ?=(%| -.config)  [~[(refused:loop id p.config)] reviews coding]
  =/  source  (current:project our.b now.b p.config)
  ?:  ?=(%| -.source)  [~ reviews coding]
  ?.  =(working.session.u.e revision.working.p.source)  [~ reviews coding]
  =/  next  (judge:session now.b u.e %complete ~[(digest:accept i.matches)] 'Viki confirmed exact native checks, resolved challenge, and the resulting working revision.')
  ?:  ?=(%| -.next)  [~ reviews coding]
  =/  out  (apply:loop b coding p.next)
  [-.out reviews +.out]
++  peek
  |=  [reviews=state path=path]
  ^-  (unit (unit cage))
  ?:  =(/x/native-coding/reviews path)  ``noun+!>(reviews)
  ?.  ?=([%x %native-coding ?(%decision %review) @ ~] path)  ~
  =/  id  (slaw %ux i.t.t.t.path)
  ?~  id  [~ ~]
  =/  found  (~(get by reviews) u.id)
  ?:  =(%review i.t.t.path)  ``noun+!>(found)
  =/  d=(unit decision:accept)  ?~(found ~ decision.u.found)
  ``noun+!>(d)
++  grant-error
  |=  [our=@p at=@da r=record:accept]
  ^-  (unit @tas)
  ?.  (agent-live:guard our at %cantrip)  `%review-grant-unavailable
  =/  g=(unit scope:grants)
    .^((unit scope:grants) %gx /(scot %p our)/cantrip/(scot %da at)/native-coding/grant/(scot %ux grant.r)/noun)
  ?~  g  `%review-grant-unavailable
  ?^  revoked.u.g  `%review-grant-revoked
  ?.  ?&  (grant-valid:grants our grant.u.g)  =(grant.r id.grant.u.g)
          =(project.r project.grant.u.g)
          =(session.context.candidate.r session.grant.u.g)
          =(actor.context.candidate.r actor.grant.u.g)
      ==  `%review-grant-mismatch
  ~
++  scope-error
  |=  [our=@p at=@da c=candidate:nc objective=@t d=decision:accept]
  ^-  (unit @tas)
  ?:  (marked:local d)  (admit:local our at c d)
  ?.  (agent-live:guard our at %viki)  `%review-scope-unavailable
  =/  all=(map @ux campaign:campaigns)
    .^((map @ux campaign:campaigns) %gx /(scot %p our)/viki/(scot %da at)/native-coding/review-campaigns/noun)
  =/  scopes=(map @t scope:protocol)
    .^((map @t scope:protocol) %gx /(scot %p our)/viki/(scot %da at)/native-coding/review-scopes/noun)
  ?.  %+  lien  ~(tap by all)
      |=  [id=@ux e=campaign:campaigns]
      ?&  =(c candidate.record.e)  =(objective objective.e)
          enabled.scope.e  (scope-valid:campaigns our scope.e)
          =(`scope.e (~(get by scopes) project.scope.e))
          %+  lien  ~(val by jobs.e)
          |=  j=job:campaigns
          ?~  event.j  %.n
          =/  ctx=admission-context:protocol  [id scope.e worker.j request.j u.event.j]
          (~(has in (silt evidence.challenge.d)) (digest:request ctx))
      ==
    `%review-scope-revoked
  ~
++  hold
  ::  Losing authority is not a request to revise source until it passes.
  |=  [b=bowl:gall reviews=state coding=state:loop id=@ux held=entry reason=@tas]
  ^-  change
  =/  found  (~(get by sessions.coding) session.context.candidate.held)
  ?~  found  [~ reviews coding]
  =/  e=entry:session  u.found
  ?:  |(advanced.held =(%paused phase.e))  [~ reviews coding]
  ?.  =(working.session.e source.context.candidate.held)  [~ reviews coding]
  =/  next  (append:session e(phase %paused, resume phase.e) now.b [%status %paused reason])
  ?:  ?=(%| -.next)  [~ reviews coding]
  =/  out  (apply:loop b coding p.next)
  (put our.b reviews +.out id held -.out)
++  revision
  |=  [b=bowl:gall reviews=state coding=state:loop id=@ux held=entry e=entry:session reason=@t incoming=record:accept]
  ^-  change
  =/  next  (revise:session now.b e (digest:accept incoming) reason)
  ?:  ?=(%| -.next)  (put our.b reviews coding id held ~)
  =/  out  (apply:loop b coding p.next)
  =/  cards=(list card)  ?:(=(%ready phase.entry.p.next) ~[(run-card:loop our.b id.session.e)] ~)
  (put our.b reviews +.out id held(advanced %.y) (weld -.out cards))
++  negative
  ::  Notification data selects a canonical receipt; it supplies no verdict.
  |=  [b=bowl:gall reviews=state coding=state:loop campaign=@ux request-id=@ux]
  ^-  change
  ?.  &(=(our.b src.b) (agent-live:guard our.b now.b %viki))
    [~ reviews coding]
  =/  all=(map @ux campaign:campaigns)
    .^((map @ux campaign:campaigns) %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/review-campaigns/noun)
  =/  found  (~(get by all) campaign)
  ?~  found  [~ reviews coding]
  =/  c=campaign:campaigns  u.found
  =/  id=@ux  id.candidate.record.c
  =/  held  (~(get by reviews) id)
  ?~  held  [~ reviews coding]
  ?.  &(=(candidate.u.held candidate.record.c) =(objective.u.held objective.c) !advanced.u.held)
    [~ reviews coding]
  =/  e  (~(get by sessions.coding) session.context.candidate.u.held)
  ?~  e  [~ reviews coding]
  =/  goal  (objective u.e)
  ?.  &(?=(%& -.goal) =(p.goal objective.c) =(working.session.u.e source.context.candidate.u.held))
    [~ reviews coding]
  =/  scopes=(map @t scope:protocol)
    .^((map @t scope:protocol) %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/review-scopes/noun)
  ?.  &(enabled.scope.c =(`scope.c (~(get by scopes) project.scope.c)))
    (hold b reviews coding id u.held %review-scope-revoked)
  ?.  (agent-live:guard our.b now.b %cantrip)
    (hold b reviews coding id u.held %review-grant-unavailable)
  =/  r=(unit record:accept)
    .^((unit record:accept) %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/candidate/(scot %ux id)/noun)
  ?~  r  [~ reviews coding]
  ?.  &(=(candidate.u.r candidate.u.held) =(project.u.r project.record.c) =(report.u.r report.record.c))
    [~ reviews coding]
  =/  denied  (grant-error our.b now.b u.r)
  ?^  denied  (hold b reviews coding id u.held u.denied)
  ?:  |(=(0 request-id) ?=(^ decision.u.held))  [~ reviews coding]
  ?.  &(=(%review stage.u.r) ?=(^ report.u.r))  [~ reviews coding]
  =/  j  (~(get by jobs.c) request-id)
  ?~  j  [~ reviews coding]
  ?~  event.u.j  [~ reviews coding]
  =/  result  u.event.u.j
  ?~  contribution.result  [~ reviews coding]
  =/  request-valid=?
    ?:  (valid:request worker.u.j config.u.j request.u.j)  %.y
    ?.  (agent-live:guard our.b now.b %viki)  %.n
    =/  captured=(unit entry:ri)
      .^((unit entry:ri) %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/review-inspection/(scot %ux campaign)/(scot %ux request-id)/noun)
    ?~  captured  %.n
    =/  prepared  (inference:inspected worker.u.j config.u.j request.u.j u.captured)
    ?=(%& -.prepared)
  ?.  ?&  =(%submitted phase.result)  !=(0 receipt.result)
          =(id.result request-id)  =(binding.result (digest:request config.u.j))
          =(generation.result generation.config.u.j)
          =(request.result (digest:request request.u.j))
          request-valid
          |(=([worker.u.j config.u.j] left.scope.c) =([worker.u.j config.u.j] right.scope.c))
          =(candidate.request.u.j candidate.u.r)  =(report.request.u.j u.report.u.r)
      ==  [~ reviews coding]
  =/  ctx=admission-context:protocol  [campaign scope.c worker.u.j request.u.j result]
  =/  verdict=(unit verdict:protocol)
    .^((unit verdict:protocol) %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/review-admission/(scot %ux campaign)/(scot %ux request-id)/noun)
  ?~  verdict  [~ reviews coding]
  ?.  &(=(campaign campaign.u.verdict) =(request-id request.u.verdict) =((digest:request ctx) context.u.verdict))  [~ reviews coding]
  ::  A v2 law label is insufficient: read the inspection evidence retained
  ::  with this canonical Cantrip admission and revalidate its exact request.
  =/  inspected-context=(unit @ux)
    ?.  =(law.admission.u.verdict 'native-ai-review-standing-scope-v2')  ~
    =/  key=@ux  (proof-key:proof ctx)
    =/  captured=(unit entry:ri)
      .^((unit entry:ri) %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/review-proof/(scot %ux key)/noun)
    ?~  captured  ~
    =/  prepared  (inference:inspected worker.u.j config.u.j request.u.j u.captured)
    ?:  ?=(%| -.prepared)  ~
    `context.u.verdict
  ?:  &(accepted.admission.u.verdict !(contribution-valid:admissions config.u.j request.u.j result))
    [~ reviews coding]
  ?.  (agent-live:guard our.b now.b %boxy)  [~ reviews coding]
  =/  box=state:bx  .^(state:bx %gx /(scot %p our.b)/boxy/(scot %da now.b)/state/noun)
  =/  workspace  (~(get by workspaces.box) workspace.c)
  ?~  workspace  [~ reviews coding]
  =/  decided
    (negative-checked:judgment our.b now.b project.u.r candidate.u.r u.report.u.r objective.c model.u.held u.workspace worker.u.j u.contribution.result admission.u.verdict request-id receipt.result context.u.verdict inspected-context)
  ?:  ?=(%| -.decided)  [~ reviews coding]
  (put our.b reviews coding id u.held(workspace `workspace.c, observed `u.r, decision `p.decided) (cards:dispatch our.b coding candidate.u.held))
--
