::  Owner-only bounded HTTP codec. Cached source is historical disclosure,
::  never evidence of continuing permission, a local session or a commit.
/+  client=readymade-project-view-client, runtime=cantrip-project-access-runtime,
    mg=readymade-app-management
|%
++  ship
  |=  text=@t
  ^-  @p
  ?>  (lte (met 3 text) 128)
  =/  value=@p  (need (slaw %p text))
  ?>  &((lte (met 0 value) 128) =(text (scot %p value)))
  value
++  project-valid
  |=  text=@t
  ^-  ?
  ?&  (gth (met 3 text) 0)  (lte (met 3 text) 128)
      (levy (trip text) |=(c=@t &((gte c 32) !=(c 127) !=(c ':'))))
  ==
++  generation
  |=  text=@t
  ^-  @ud
  ?>  (lte (met 3 text) 32)
  =/  value=@ud  (need (slaw %ud text))
  ?>  &((gth value 0) (lte (met 0 value) 64) =(text (scot %ud value)))
  value
++  select
  |=  [owner=@t project=@t gen=@t request=@t]
  ^-  selector:client
  ?>  (project-valid project)
  ?>  (lte (met 3 request) 64)
  =/  nonce=@ux  (need (slaw %ux request))
  ?>  &((gth nonce 0) (lte (met 0 nonce) 128) =(request (scot %ux nonce)))
  [(ship owner) [project (generation gen) nonce]]
++  decode
  |=  raw=@t
  ^-  command:client
  ?>  (lte (met 3 raw) 4.096)
  =/  value=json  (need (de:json:html raw))
  ?>  ?=(%o -.value)
  =/  obj=(map @t json)  p.value
  ?>  =(4 ~(wyt by obj))
  ::  All values exclude colons; catch duplicate and escaped-alias keys.
  ?>  =(4 (lent (skim (trip raw) |=(c=@t =(c ':')))))
  ?>  =('readymade-project-view-v1' (text-field:mg obj 'schema' 64))
  =/  owner=@p  (ship (text-field:mg obj 'owner' 128))
  =/  project=@t  (text-field:mg obj 'project' 128)
  ?>  (project-valid project)
  [owner project (generation (text-field:mg obj 'generation' 32))]
++  parse
  |=  raw=@t
  ^-  (unit command:client)
  (mole |.((decode raw)))
++  post-request
  |=  req=inbound-request:eyre
  ^-  (unit command:client)
  ?.  ?&  authenticated.req  =('POST' method.request.req)
          =('/apps/readymade-collab/project-view' url.request.req)
      ==  ~
  =/  host  (header:mg header-list.request.req 'host')
  =/  origin  (header:mg header-list.request.req 'origin')
  =/  mime  (header:mg header-list.request.req 'content-type')
  ?~  host  ~
  ?~  origin  ~
  ?~  mime  ~
  ?.  ?&  =(u.origin (cat 3 ?:(secure.req 'https://' 'http://') u.host))
          |(=(u.mime 'application/json') =(u.mime 'application/json; charset=utf-8'))
          =(`'v1' (header:mg header-list.request.req 'x-readymade-project-view'))
      ==  ~
  ?~  body.request.req  ~
  =/  body  u.body.request.req
  ?.  &((lte p.body 4.096) =(p.body (met 3 q.body)))  ~
  (parse q.body)
++  result-request
  |=  req=inbound-request:eyre
  ^-  (unit selector:client)
  ?.  ?&  authenticated.req  =('GET' method.request.req)
          =('/apps/readymade-collab/project-view-result' url.request.req)
      ==  ~
  =/  owner  (header:mg header-list.request.req 'x-readymade-project-owner')
  =/  project  (header:mg header-list.request.req 'x-readymade-project')
  =/  gen  (header:mg header-list.request.req 'x-readymade-project-generation')
  =/  request  (header:mg header-list.request.req 'x-readymade-project-view-request')
  ?~  owner  ~
  ?~  project  ~
  ?~  gen  ~
  ?~  request  ~
  (mole |.((select u.owner u.project u.gen u.request)))
++  encode
  |=  [our=@p e=entry:client]
  ^-  json
  ?>  (valid-key:client key.e)
  =/  observation=json
    ?.  =(%ready phase.e)  ~
    ?>  ?=(^ response.e)
    =/  r  u.response.e
    ?>  ?&  (view-valid:runtime r)  =(owner.key.e owner.r)
            =(our peer.r)  =(query.key.e query.r)
        ==
    =/  b  basis.r
    =/  rows=(list json)
      %+  turn  ~(tap by files.b)
      |=  item=[pax=path text=@t]
      %-  pairs:enjs:format
      :~  ['path' s+(spat pax.item)]  ['text' s+text.item]
          ['hash' s+(scot %ux (~(got by files.body.snapshot.b) pax.item))]
      ==
    %-  pairs:enjs:format
    :~  ['owner' s+(scot %p owner.r)]  ['peer' s+(scot %p peer.r)]
        ['grant' s+(scot %ux grant.r)]  ['observedAt' s+(scot %da at.b)]
        ['root' s+(scot %ux root.b)]  ['snapshotDigest' s+(scot %ux digest.snapshot.b)]
        ['desk' s+base-desk.body.snapshot.b]
        ['revision' s+(scot %ud base-revision.body.snapshot.b)]
        ['files' a+rows]
    ==
  =/  value=json
    %-  pairs:enjs:format
    :~  ['schema' s+'readymade-project-view-result-v1']
        ['owner' s+(scot %p owner.key.e)]  ['peer' s+(scot %p our)]
        ['project' s+project.query.key.e]
        ['generation' s+(scot %ud generation.query.key.e)]
        ['request' s+(scot %ux nonce.query.key.e)]
        ['status' s+phase.e]  ['reason' s+reason.e]
        ['deadline' s+(scot %da deadline.e)]  ['retainedUntil' s+(scot %da retained.e)]
        ['permissionGranted' b+%.n]  ['observation' observation]
    ==
  ?>  (lte (met 3 (en:json:html value)) 524.288)
  value
++  response
  |=  [our=@p e=entry:client]
  ^-  (unit json)
  (mole |.((encode our e)))
--
