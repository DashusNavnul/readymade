::  /lib/cantrip-lease
::
::  Pure bounded law for Cantrip's canonical lease mirror.  Exact replay is
::  idempotent, conflicting reuse is refused, and released/expired evidence is
::  retained rather than deleted.
::
/-  cl=cantrip-lease, mg=moon-grant
|%
++  visible
  |=  [lease=mirrored-lease:mg now=@da]
  ^-  mirrored-lease:mg
  ?:  !=(%active status.lease)  lease
  ::  Zero is explicit until-revoked authority, not a missing deadline.
  ?:  |(=(0 expires.lease) (lth now expires.lease))  lease
  lease(status %expired)
::
++  lookup
  |=  [leases=table:cl lease-id=@t now=@da]
  ^-  (unit mirrored-lease:mg)
  =/  found=(unit mirrored-lease:mg)  (~(get by leases) lease-id)
  ?~(found ~ `(visible u.found now))
::
++  snapshot
  |=  [leases=table:cl now=@da]
  ^-  table:cl
  =/  rows=(list [@t mirrored-lease:mg])  ~(tap by leases)
  =/  out=table:cl  *table:cl
  |-
  ?~  rows  out
  $(rows t.rows, out (~(put by out) -.i.rows (visible +.i.rows now)))
::
++  valid
  |=  leases=table:cl
  ^-  ?
  ?:  (gth ~(wyt by leases) max-leases:cl)  %.n
  =/  rows=(list [@t mirrored-lease:mg])  ~(tap by leases)
  |-
  ?~  rows  %.y
  ?.  ?&(!=(0 -.i.rows) !=(0 holder.+.i.rows))  %.n
  $(rows t.rows)
::
++  mirror
  |=  [leases=table:cl lease-id=@t holder=@t expires=@da now=@da]
  ^-  transition:cl
  =/  refused
    |=  reason=refusal:cl
    ^-  transition:cl
    [leases [%.n `reason ~]]
  ?:  =(0 lease-id)  (refused %lease-id-empty)
  ?:  =(0 holder)  (refused %holder-empty)
  ?:  &(!=(0 expires) !(lth now expires))  (refused %already-expired)
  =/  candidate=mirrored-lease:mg  [holder expires %active]
  =/  prior=(unit mirrored-lease:mg)  (~(get by leases) lease-id)
  ?^  prior
    ?:  =(candidate u.prior)
      [leases [%.y ~ `candidate]]
    (refused %conflicting-mirror)
  ?:  (gte ~(wyt by leases) max-leases:cl)
    (refused %capacity)
  [(~(put by leases) lease-id candidate) [%.y ~ `candidate]]
::
++  release
  |=  [leases=table:cl lease-id=@t now=@da]
  ^-  transition:cl
  =/  prior=(unit mirrored-lease:mg)  (~(get by leases) lease-id)
  ?~  prior
    [leases [%.n `%lease-absent ~]]
  =/  shown=mirrored-lease:mg  (visible u.prior now)
  =/  released=mirrored-lease:mg  shown(status %released)
  ?:  =(%released status.shown)
    [leases [%.y ~ `shown]]
  [(~(put by leases) lease-id released) [%.y ~ `released]]
--
