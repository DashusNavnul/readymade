::  Pure saved-v4 boundary. No migration cards, rewatch, replay or authority.
::  The future native wrapper authenticates owners/Ames and supplies saved data.
/-  c=readymade-collab, j=readymade-collab-jobs, a=readymade-artifact-collab,
    p=readymade-pact, pkg=readymade-package, r=readymade-artifact-round
/+  flow=readymade-collab, artifact=readymade-artifact-collab,
    pact=readymade-pact, package=readymade-package,
    round=readymade-artifact-round, archive=readymade-collab-graf,
    build=readymade-package-build
|%
+$  saved
  $:  %readymade-collab-app-v4
      state=state:c
      commands=(map @t @ux)
      ledger=ledger:j
      pending=pending:archive
      artifacts=state:a
  ==
++  empty
  ^-  saved
  [%readymade-collab-app-v4 empty:flow ~ ~ ~ empty:artifact]
++  base-valid
  |=  [our=@p value=saved]
  ^-  ?
  ?&  (lte ~(wyt by packages.state.value) 256)
      (lte ~(wyt by pacts.state.value) 256)
      (lte (lent receipts.state.value) 128)
      (lte ~(wyt by requests.state.value) 4.096)
      (lte ~(wyt by commands.value) 4.096)
      (lte ~(wyt by ledger.value) 1.024)
      (lte ~(wyt by pending.value) 256)
      %+  levy  ~(tap by pending.value)
      |=  row=[hash=@ux entry=entry:archive]
      ?&  =(hash.row (digest:archive fact.entry.row))
          =(request.entry.row (request-of:archive fact.entry.row))
          (bounded:archive fact.entry.row)
      ==
  ==
++  evidence-valid
  |=  [our=@p state=state:c hash=@ux entry=evidence:a]
  ^-  ?
  =/  receipt=receipt:build  receipt.entry
  ?.  =(hash proof.receipt)  %.n
  =/  item=(unit package:c)
    (~(get by packages.state) digest.offer.plan.body.receipt)
  ?~  item  %.n
  ?:  =(%local-canonical provenance.entry)
    &(=(our builder.entry) (local-valid:artifact our value.u.item receipt))
  &(!=(our builder.entry) (receipt-valid:artifact value.u.item builder.entry receipt))
++  round-valid
  ::  Validate historical metadata against its immutable terms and generation.
  ::  The temporary active view is ONLY for shape validation. Never saved or
  ::  returned as permission: readiness always uses the real canonical pact.
  |=  [our=@p state=state:c artifacts=state:a key=key:a held=state:r]
  ^-  ?
  ?.  ?&  =(pact.key pact.held)
          =(generation.key generation.held)
          =(purpose.key purpose.held)
      ==
    %.n
  =/  agreement=(unit agreement:c)  (~(get by pacts.state) pact.key)
  ?~  agreement  %.n
  =/  current=state:p  value.u.agreement
  ?.  &((valid-terms:pact terms.current) =(pact.key (digest:pact terms.current)))  %.n
  ?.  (lte generation.held generation.current)  %.n
  =/  source=(unit package:c)  (~(get by packages.state) package.terms.current)
  ?~  source  %.n
  ?.  (context-valid:artifact our our current value.u.source)  %.n
  =/  historical=state:p
    current(generation generation.held, left-consent %.y, right-consent %.y)
  ?.  (valid:round held historical)  %.n
  ?~  proposal.held  %.y
  (proposal-bound:artifact artifacts historical value.u.source purpose.key u.proposal.held)
++  valid
  |=  [our=@p value=saved]
  ^-  ?
  ?.  (base-valid our value)  %.n
  =/  index=state:a  artifacts.value
  ?&  (lte ~(wyt by evidence.index) 256)
      (lte ~(wyt by rounds.index) 256)
      (lte ~(wyt by requests.index) 4.096)
      (levy ~(tap by evidence.index) |=([hash=@ux entry=evidence:a] (evidence-valid our state.value hash entry)))
      (levy ~(tap by rounds.index) |=([key=key:a held=state:r] (round-valid our state.value index key held)))
      %+  levy  ~(tap by requests.index)
      |=  row=[[who=@p request=@t] hash=@ux]
      &((digest-valid:package hash.row) =(request.row (scot %ux hash.row)))
  ==
++  restore
  ::  Input is the saved payload, not a vase. Recursive vase types stay opaque.
  |=  [our=@p raw=*]
  ^-  (unit saved)
  =/  four=(unit saved)  ((soft saved) raw)
  ?^  four
    ?:((valid our u.four) four ~)
  =/  three
    ((soft ,[%readymade-collab-app-v3 state=state:c commands=(map @t @ux) ledger=ledger:j pending=pending:archive]) raw)
  ?^  three
    =/  next=saved  [%readymade-collab-app-v4 state.u.three commands.u.three ledger.u.three pending.u.three empty:artifact]
    ?:((valid our next) `next ~)
  =/  two
    ((soft ,[%readymade-collab-app-v2 state=state:c commands=(map @t @ux) ledger=ledger:j]) raw)
  ?^  two
    =/  next=saved  [%readymade-collab-app-v4 state.u.two commands.u.two ledger.u.two ~ empty:artifact]
    ?:((valid our next) `next ~)
  =/  one
    ((soft ,[%readymade-collab-app-v1 state=state:c commands=(map @t @ux)]) raw)
  ?~  one  ~
  =/  next=saved  [%readymade-collab-app-v4 state.u.one commands.u.one ~ ~ empty:artifact]
  ?:((valid our next) `next ~)
++  receive
  ::  Resolves BOTH canonical inputs from the same saved value; caller cannot
  ::  splice a detached reducer result into another pact or stale snapshot.
  |=  [value=saved our=@p sender=@p id=@ux event=envelope:a]
  ^-  (each saved @tas)
  ?.  (valid our value)  [%| %invalid-saved]
  =/  agreement=(unit agreement:c)  (~(get by pacts.state.value) id)
  ?~  agreement  [%| %unknown-pact]
  =/  item=agreement:c  u.agreement
  ?.  =(id (digest:pact terms.value.item))  [%| %pact-key]
  =/  source=(unit package:c)  (~(get by packages.state.value) package.terms.value.item)
  ?~  source  [%| %unknown-package]
  =/  moved=change:a
    (receive:artifact artifacts.value our sender value.item value.u.source event)
  ?.  accepted.moved  [%| reason.moved]
  =/  next-state=state:c
    state.value(pacts (~(put by pacts.state.value) id item(value pact.moved)))
  =/  next=saved  value(state next-state, artifacts state.moved)
  ?.  (valid our next)  [%| %invalid-result]
  [%& next]
++  receive-routed
  ::  Runtime v2 entry: direct canonical lookup, no first-match/package scan.
  ::  Legacy unqualified build evidence is deliberately unavailable here.
  |=  [value=saved our=@p sender=@p event=envelope:a]
  ^-  (each saved @tas)
  =/  id=(unit @ux)  (route:artifact event)
  ?~  id  [%| %unrouted-evidence]
  (receive value our sender u.id event)
++  record-local
  |=  [value=saved our=@p id=@ux receipt=receipt:build]
  ^-  (each saved @tas)
  ?.  (valid our value)  [%| %invalid-saved]
  =/  agreement=(unit agreement:c)  (~(get by pacts.state.value) id)
  ?~  agreement  [%| %unknown-pact]
  =/  item=agreement:c  u.agreement
  ?.  =(id (digest:pact terms.value.item))  [%| %pact-key]
  =/  source=(unit package:c)  (~(get by packages.state.value) package.terms.value.item)
  ?~  source  [%| %unknown-package]
  =/  moved=change:a
    (record-local:artifact artifacts.value our value.item value.u.source receipt)
  ?.  accepted.moved  [%| reason.moved]
  =/  next=saved  value(artifacts state.moved)
  ?.  (valid our next)  [%| %invalid-result]
  [%& next]
--
