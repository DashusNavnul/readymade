::  Owner presentation only. Cantrip owns deployment authority and lifecycle.
/-  nc=native-coding
/+  deploy=native-coding-deployment, runtime=cantrip-native-deployment,
    accept=native-coding-accept, project=native-coding-project,
    selected=native-coding-compiler-mapping-http, input=native-coding-onboarding-http,
    terminal=native-coding-terminal, cr=codex-responses, guard=viki-scry-guard
|%
+$  row  [id=@ux request=request:deploy phase=@tas reason=(unit @tas)]
++  grants
  |=  [our=@p now=@da]
  ^-  (map @ux scope:deploy)
  ?>  (agent-live:guard our now %cantrip)
  .^((map @ux scope:deploy) %gx /(scot %p our)/cantrip/(scot %da now)/native-coding/deployment-grants/noun)
++  record
  |=  [our=@p now=@da id=@ux]
  ^-  record:deploy
  ?>  (agent-live:guard our now %cantrip)
  %-  need
  .^((unit record:deploy) %gx /(scot %p our)/cantrip/(scot %da now)/native-coding/deployment/(scot %ux id)/noun)
++  hex
  |=  [object=json key=@t]
  ^-  @ux
  =/  value=@ux  (digest:terminal (text:input object key 82 %.y))
  ?>  !=(0 value)
  value
++  view
  |=  [our=@p now=@da session=@ux]
  ^-  json
  =/  found  (selected:selected our now session)
  ?.  ?=(%& -.found)
    (pairs:enjs:format ~[['available' b+%.n] ['session' s+(scot %ux session)] ['grants' a+~] ['rows' a+~]])
  ?.  (agent-live:guard our now %cantrip)
    (pairs:enjs:format ~[['available' b+%.n] ['session' s+(scot %ux session)] ['grants' a+~] ['rows' a+~]])
  =/  p=project:nc  project.p.found
  =/  scopes=(list [@ux scope:deploy])
    (skim ~(tap by (grants our now)) |=([id=@ux g=scope:deploy] =(p project.grant.g)))
  =/  all=[%native-coding-deployments-v1 rows=(list row)]
    .^([%native-coding-deployments-v1 rows=(list row)] %gx /(scot %p our)/cantrip/(scot %da now)/native-coding/deployments/noun)
  =/  matching=(list row)
    (skim rows.all |=(r=row (~(has in (silt (turn scopes |=([id=@ux g=scope:deploy] id)))) grant.request.r)))
  =/  rows=(list json)
    %+  turn  (scag 32 matching)
    |=  item=row
    =/  r=record:deploy  (record our now id.item)
    =/  cancellation  (cancellation:deploy r)
    (pairs:enjs:format ~[['id' s+(scot %ux id.item)] ['candidate' s+(scot %ux candidate.request.r)] ['grant' s+(scot %ux grant.request.r)] ['phase' s+phase.r] ['reason' s+?~(reason.r '' u.reason.r)] ['previous' s+?~(previous.request.r '' (scot %ux u.previous.request.r))] ['apps' a+(turn ~(tap in apps.grant.r) |=(name=@tas s+name))] ['runtime' s+?~(runtime.r '' desk.revision.u.runtime.r)] ['revision' s+?~(runtime.r '' (scot %ud number.revision.u.runtime.r))] ['cancellation' s+reason.cancellation]])
  (pairs:enjs:format ~[['available' b+%.y] ['session' s+(scot %ux session)] ['project' s+id.spec.p] ['configuration' s+(scot %ux (configuration:project p))] ['truncated' b+|((gth (lent matching) 32) (gth (lent scopes) 32))] ['rows' a+rows] ['grants' a+(turn (scag 32 scopes) |=([id=@ux g=scope:deploy] (pairs:enjs:format ~[['id' s+(scot %ux id)] ['revoked' b+?=(^ revoked.g)] ['updates' b+updates.grant.g] ['apps' a+(turn ~(tap in apps.grant.g) |=(name=@tas s+name))]])))]])
++  route
  |=  [our=@p now=@da url=@t]
  ^-  (unit json)
  =/  prefix=@t  '/apps/pataphor-native/coding/deployments?'
  ?.  &(=(prefix (cut 3 [0 (met 3 prefix)] url)) (lte (met 3 url) 180))  ~
  =/  text=@t  (rsh [3 (met 3 prefix)] url)
  =/  id  (slaw %ux text)
  ?~  id  ~
  ?.  &((lte (met 0 u.id) 256) =(text (scot %ux u.id)))  ~
  `(view our now u.id)
++  decode
  |=  [our=@p now=@da object=json]
  ^-  command:runtime
  =/  session=@ux  (hex object 'session')
  =/  found  (selected:selected our now session)
  ?>  ?=(%& -.found)
  =/  p=project:nc  project.p.found
  ?>  =((configuration:project p) (hex object 'configuration'))
  =/  kind=@t  (text:input object 'kind' 32 %.y)
  =/  id=@ux  (hex object 'id')
  =/  held  (grants our now)
  ?:  =('deployment-grant' kind)
    =/  names=(list @tas)
      (turn (strings:input object 'apps' 8) |=(text=@t (name:terminal text)))
    ?>  =((lent names) ~(wyt in (silt names)))
    =/  updates=json  (need (field:cr object 'updates'))
    ?>  ?=(%b -.updates)
    =/  g=grant:deploy  [id p our (silt names) p.updates]
    ?>  (grant-valid:deploy our g)
    =/  old  (~(get by held) id)
    ?>  ?~(old %.y &(=(grant.u.old g) =(~ revoked.u.old)))
    [%native-coding-deployment-grant-v1 g]
  ?:  =('deployment-revoke' kind)
    =/  g  (~(got by held) id)
    ?>  =(p project.grant.g)
    [%native-coding-deployment-revoke-v1 id]
  ?:  =('deployment-prepare' kind)
    =/  candidate=@ux  (hex object 'candidate')
    =/  grant=@ux  (hex object 'grant')
    =/  g  (~(got by held) grant)
    ?>  &(=(p project.grant.g) =(~ revoked.g))
    =/  accepted=(unit record:accept)
      .^((unit record:accept) %gx /(scot %p our)/cantrip/(scot %da now)/native-coding/candidate/(scot %ux candidate)/noun)
    ?>  ?=(^ accepted)
    ?>  &(=(p project.u.accepted) =(session session.context.candidate.u.accepted) =(%applied stage.u.accepted))
    =/  prior=@t  (text:input object 'previous' 82 %.n)
    =/  previous=(unit @ux)  ?:(=('' prior) ~ `(hex object 'previous'))
    [%native-coding-deploy-v1 id candidate grant previous]
  =/  r=record:deploy  (record our now id)
  ?>  =(p project.grant.r)
  ?:  =('deployment-observe' kind)  [%native-coding-deployment-observe-v1 id]
  ?:  =('deployment-cancel' kind)  [%native-coding-deployment-cancel-v1 id]
  ?>  =('deployment-activate' kind)
  ?>  =(%ready phase.r)
  [%native-coding-deployment-activate-v1 id]
--
