::  Project membership discovery, never execution or invitation authority.
/-  mp=multiplayer-project
/+  law=multiplayer-project, pages=readymade-session-catalog
|%
++  page
  |=  [our=@p now=@da p=project:mp kind=?(%members %invitations) query=query:pages]
  ^-  (each json @tas)
  ?.  &((law-valid p) =(our authority.spec.p))  [%| %project-members-unavailable]
  =/  rows=(list json)
    ?:  =(%members kind)
      =/  members=(list [@p member:mp])
        (sort ~(tap by members.p) |=([a=[@p member:mp] b=[@p member:mp]] (lth -.a -.b)))
      %+  turn  members
      |=  [ship=@p member=member:mp]
      (pairs:enjs:format ~[['ship' s+(scot %p ship)] ['role' s+role.member] ['joinedAt' s+(scot %da joined-at.member)]])
    =/  pending=(list [@ux invitation:mp])
      %+  skim  ~(tap by invitations.p)
        |=  [id=@ux inv=invitation:mp]
        ?=(%pending -.status.inv)
    =/  invitations=(list [@ux invitation:mp])
      %+  sort  pending
      |=  [a=[@ux invitation:mp] b=[@ux invitation:mp]]
      (lth -.a -.b)
    %+  turn  invitations
    |=  [id=@ux inv=invitation:mp]
    %-  pairs:enjs:format
    :~  ['id' s+(scot %ux id)]
        ['target' s+(scot %p target.body.inv)]
        ['role' s+role.body.inv]
        ['issuedBy' s+(scot %p issued-by.body.inv)]
        ['expiresAt' s+(scot %da expires-at.body.inv)]
        ['expired' b+(gte now expires-at.body.inv)]
    ==
  =/  total=@ud  (lent rows)
  =/  digest=@ux  (shax (jam [%readymade-project-members-v1 spec.p kind rows]))
  ?:  &((gth offset.query 0) ?=(~ expected.query))  [%| %project-members-cursor]
  ?.  ?~(expected.query %.y =(u.expected.query digest))  [%| %project-members-stale]
  ?.  &((lte offset.query total) |(=(0 offset.query) (lth offset.query total)))
    [%| %project-members-cursor]
  =/  selected=(list json)  (scag 64 (slag offset.query rows))
  =/  end=@ud  (add offset.query (lent selected))
  =/  value=json
    %-  pairs:enjs:format
    :~  ['schema' s+'readymade-project-members-v1']
        ['project' s+id.spec.p]
        ['authority' s+(scot %p authority.spec.p)]
        ['permissionGranted' b+%.n]
        ['inviteUntil' s+(scot %da (add now ~d1))]
        ['kind' s+kind]
        ['catalog' s+(scot %ux digest)]
        ['offset' (numb:enjs:format offset.query)]
        ['total' (numb:enjs:format total)]
        ['next' ?:(=(end total) ~ (numb:enjs:format end))]
        ['rows' a+selected]
    ==
  ?.  (lte (met 3 (en:json:html value)) 65.536)  [%| %project-members-bytes]
  [%& value]
++  law-valid
  |=  p=project:mp
  ^-  ?
  ?&  (lte (met 3 id.spec.p) 128)
      (lte (met 3 title.spec.p) 256)
      (project-valid:law p)
  ==
--
