::  qpc-ct-world/1: exact state/update covariance, distinct from legacy qualia.
::  Input: chronological reports, each d confidences in [0, 1.000.000].
::  This pure core establishes arithmetic only. The owning agent must attest
::  manifest/epoch, report continuity, disjoint baseline and evidence identity.
::  No authority, hidden-state claim, clipping, square root or live mutation.
|%
+$  report  (list @ud)
+$  window  (list report)
+$  matrix  (list (list @s))
+$  ratio  [num=@ud den=@ud]
+$  normalized-shape
  [denominator=@ud state=matrix update=matrix]
+$  reading
  $:  %qpc-ct-update-v1
      dimensions=@ud  width=@ud  denominator=@ud  entries=matrix
      attention=ratio
  ==
++  scale  1.000.000
++  valid
  |=  [dimensions=@ud width=@ud reports=window]
  ^-  ?
  ?&  (gte dimensions 2)  (lte dimensions 16)
      ?|(=(width 16) =(width 32) =(width 64))
      =((lent reports) +(width))
      %+  levy  reports
      |=  row=report
      ?&  =((lent row) dimensions)
          (levy row |=(p=@ud (lte p scale)))
      ==
  ==
++  numerator
  ::  W sum(p_a delta-p_b) - sum(p_a) sum(delta-p_b).
  ::  Called only after +valid; units are confidence integer squared.
  |=  [reports=window left=@ud right=@ud]
  ^-  @s
  =/  n=@ud  (dec (lent reports))
  =/  rows=window  reports
  =/  sx=@ud  0
  =/  sy=@s  --0
  =/  sxy=@s  --0
  |-  ^-  @s
  ?:  (lth (lent rows) 2)
    (dif:si (pro:si (sun:si n) sxy) (pro:si (sun:si sx) sy))
  =/  first=report  (snag 0 rows)
  =/  next=report  (snag 1 rows)
  =/  x=@ud  (snag left first)
  =/  dy=@s
    (dif:si (sun:si (snag right next)) (sun:si (snag right first)))
  $(rows (slag 1 rows), sx (add sx x), sy (sum:si sy dy), sxy (sum:si sxy (pro:si (sun:si x) dy)))
++  square-row
  |=  row=(list @s)
  ^-  @ud
  =/  total=@ud  0
  |-  ^-  @ud
  ?~  row  total
  $(row t.row, total (add total (mul (abs:si i.row) (abs:si i.row))))
++  square-matrix
  |=  rows=matrix
  ^-  @ud
  =/  total=@ud  0
  |-  ^-  @ud
  ?~  rows  total
  $(rows t.rows, total (add total (square-row i.rows)))
++  shape
  ::  H_state=C C^T/A and H_update=C^T C/A. The scale of C cancels;
  ::  keep both frames for nonsymmetric state/update covariance. At A=0
  ::  there is no normalized shape, not a zero ellipse or an identity matrix.
  |=  value=reading
  ^-  (unit normalized-shape)
  ?>  &((gte dimensions.value 2) (lte dimensions.value 16))
  ?>  =(dimensions.value (lent entries.value))
  ?>  (levy entries.value |=(row=(list @s) =(dimensions.value (lent row))))
  =/  squared=@ud  (square-matrix entries.value)
  ?:  =(0 squared)  ~
  =/  axes=(list @ud)  (gulf 0 (dec dimensions.value))
  =/  gram
    |=  transpose=?
    ^-  matrix
    %+  turn  axes
    |=  a=@ud
    %+  turn  axes
    |=  b=@ud
    %+  roll  axes
    |=  [k=@ud total=@s]
    =/  left=@s
      ?:(transpose (snag a (snag k entries.value)) (snag k (snag a entries.value)))
    =/  right=@s
      ?:(transpose (snag b (snag k entries.value)) (snag k (snag b entries.value)))
    (sum:si total (pro:si left right))
  `[squared (gram %.n) (gram %.y)]
++  measure
  |=  [dimensions=@ud width=@ud live=window reference=window]
  ^-  (each reading @tas)
  ?.  (valid dimensions width live)  [%| %invalid-live-window]
  ?.  (valid dimensions width reference)  [%| %invalid-reference-window]
  ::  z=2p/S-1, u=delta-p/S. K=2*numerator/(W^2*S^2).
  ::  C=(K_live-K_reference)/(2d): the two factors of 2 cancel.
  =/  denominator=@ud  (mul dimensions (mul (mul width width) (mul scale scale)))
  =/  axes=(list @ud)  (gulf 0 (dec dimensions))
  =/  entries=matrix
    %+  turn  axes
    |=  left=@ud
    %+  turn  axes
    |=  right=@ud
    (dif:si (numerator live left right) (numerator reference left right))
  =/  squared=@ud  (square-matrix entries)
  =/  den=@ud  (mul denominator denominator)
  ::  A in [0,1] follows from bounded covariance; do not clip a violation.
  ?>  (lte squared den)
  [%& [%qpc-ct-update-v1 dimensions width denominator entries [squared den]]]
--
