::  /lib/grav
::
::  Pure Grav transition and compatibility law.  Dispatch stays impossible
::  until a distinct Cantrip decision is admitted and remains unexpired.
::
/-  b=boks, g=grav, mq=multiplayer-queue,
    mse=multiplayer-session-executor, msc=multiplayer-session-coordinator
/+  bl=boks
|%
++  authority-from-legacy
  |=  old=task-authority:mse
  ^-  task-authority:b
  :*  %boks-task-authority-v1
      read-paths.old
      write-paths.old
      tools.old
      allow-mutations.old
      max-runtime.old
      max-output.old
  ==
++  authority-to-legacy
  |=  current=task-authority:b
  ^-  task-authority:mse
  :*  %multiplayer-task-authority-v1
      read-paths.current
      write-paths.current
      tools.current
      allow-mutations.current
      max-runtime.current
      max-output.current
  ==
++  task-from-legacy
  |=  old=task-request:mse
  ^-  task-request:b
  :*  %boks-task-request-v1
      task-id.old
      intent.old
      (authority-from-legacy authority.old)
      expected-evidence.old
  ==
++  task-to-legacy
  |=  current=task-request:b
  ^-  task-request:mse
  :*  %multiplayer-task-request-v1
      task-id.current
      intent.current
      (authority-to-legacy authority.current)
      expected-evidence.current
  ==
++  binding-from-legacy
  |=  old=binding:mse
  ^-  binding:g
  :*  %grav-binding-v1
      local-session.old
      peer.old
      peer-session.old
      workspace.old
      backend.old
      port.old
      protocol.old
  ==
++  dispatch-from-coordinator
  |=  old=input:msc
  ^-  dispatch-request:g
  :*  recipient.old
      sender-session.old
      recipient-session.old
      (task-from-legacy task.old)
      limit.old
  ==
++  queue-from-legacy
  |=  old=fact:mq
  ^-  queue-event:g
  ?-  -.old
    %task
      :*  %task
          %grav-queue-v1
          fact-id.old
          idempotency-key.old
          task-id.old
          actor.old
          priority.old
          dependencies.old
          payload-ref.old
          recorded-at.old
      ==
    %claimed
      :*  %claimed
          %grav-queue-v1
          fact-id.old
          idempotency-key.old
          task-id.old
          claim-id.old
          actor.old
          claimed-at.old
          expires-at.old
      ==
    %working
      :*  %working
          %grav-queue-v1
          fact-id.old
          idempotency-key.old
          task-id.old
          claim-id.old
          actor.old
          predecessor.old
          recorded-at.old
      ==
    %done
      :*  %done
          %grav-queue-v1
          fact-id.old
          idempotency-key.old
          task-id.old
          claim-id.old
          actor.old
          predecessor.old
          artifact-ref.old
          evidence.old
          recorded-at.old
      ==
    %abandoned
      :*  %abandoned
          %grav-queue-v1
          fact-id.old
          idempotency-key.old
          task-id.old
          claim-id.old
          actor.old
          predecessor.old
          reason.old
          recorded-at.old
      ==
  ==
++  queue-to-legacy
  |=  current=queue-event:g
  ^-  fact:mq
  ?-  -.current
    %task
      :*  %task
          %multiplayer-queue-v1
          fact-id.current
          idempotency-key.current
          task-id.current
          actor.current
          priority.current
          dependencies.current
          payload-ref.current
          recorded-at.current
      ==
    %claimed
      :*  %claimed
          %multiplayer-queue-v1
          fact-id.current
          idempotency-key.current
          task-id.current
          claim-id.current
          actor.current
          claimed-at.current
          expires-at.current
      ==
    %working
      :*  %working
          %multiplayer-queue-v1
          fact-id.current
          idempotency-key.current
          task-id.current
          claim-id.current
          actor.current
          predecessor.current
          recorded-at.current
      ==
    %done
      :*  %done
          %multiplayer-queue-v1
          fact-id.current
          idempotency-key.current
          task-id.current
          claim-id.current
          actor.current
          predecessor.current
          artifact-ref.current
          evidence.current
          recorded-at.current
      ==
    %abandoned
      :*  %abandoned
          %multiplayer-queue-v1
          fact-id.current
          idempotency-key.current
          task-id.current
          claim-id.current
          actor.current
          predecessor.current
          reason.current
          recorded-at.current
      ==
  ==
++  open
  |=  [ingress=admitted:b binding=(unit binding:g) overall-deadline=@da]
  ^-  (unit record:g)
  ?.  ?=(%task -.payload.body.envelope.ingress)  ~
  =/  request=task-request:b  request.payload.body.envelope.ingress
  ?.  (task-valid:bl request)  ~
  ?.  (gth overall-deadline received-at.ingress)  ~
  =/  record=record:g
    :*  %grav-record-v1
        source.ingress
        digest.envelope.ingress
        request
        binding
        ~
        [%pending ~]
        %queued
        ~
        ~
        ~
        received-at.ingress
        overall-deadline
    ==
  `record
++  apply-cantrip
  |=  [record=record:g decision=cantrip-admission:g]
  ^-  record:g
  ?-  -.decision
    %pending
      record(admission decision)
    %admitted
      record(admission decision, phase %authorized)
    %refused
      record(admission decision, phase %refused)
  ==
++  may-dispatch
  |=  [record=record:g now=@da]
  ^-  ?
  ?.  =(%authorized phase.record)  %.n
  ?~  binding.record  %.n
  ?.  ?=(%admitted -.admission.record)  %.n
  ?&  !=(0 decision.admission.record)
      !=(0 ceiling.admission.record)
      (gth expires-at.admission.record now)
      (gth overall-deadline.record now)
  ==
++  mark-dispatched
  |=  [record=record:g now=@da request-id=@t]
  ^-  record:g
  ?.  (may-dispatch record now)  record
  record(phase %dispatching, model-request `request-id)
++  settle
  |=  [record=record:g release=task-release:b]
  ^-  record:g
  =/  terminal=phase:g
    ?-  -.release
      %completed           %completed
      %review              %completed
      %model-error         %refused
      %cancelled           %cancelled
      %attestation-failed  %refused
    ==
  record(release `release, phase terminal)
--
