::  Owner HTTP adapter. Only Viki's owning status supplies progress.
/-  project=viki-glass-project
/+  page=pataphor-glass-project-page, http=pataphor-chat-http,
    guard=viki-scry-guard, guidance=glass-coding-remediation-read
|%
+$  response  [cards=(list card:agent:gall) nonce=@uv]
+$  live-egg
  $:  version=$?(%16 %20)  %live  control=*  run=*  sub=*  stats=*
      bitt=*  boat=*  boar=*  code=*
      old-state=[%| saved=[type=* noun=*]]  beak=beak  rest=*
  ==
++  supported
  |=  saved=*
  ^-  ?
  =/  shoe  ((soft ,[%shoe-app inner=[type=* noun=*] console=*]) saved)
  ?~  shoe  %.n
  ?|  ?=([%viki-familiar-state-v13 [%viki-familiar-state-v12 *] *] noun.inner.u.shoe)
      ?=([%viki-familiar-state-v14 [%viki-familiar-state-v11 *] * *] noun.inner.u.shoe)
      ?=([%viki-familiar-state-v15 [%viki-familiar-state-v11 [%viki-familiar-state-v10 [%viki-familiar-state-v9 *] *] *] * *] noun.inner.u.shoe)
      ?=([%viki-familiar-state-v16 [%viki-familiar-state-v15 [%viki-familiar-state-v11 [%viki-familiar-state-v10 [%viki-familiar-state-v9 *] *] *] * *] *] noun.inner.u.shoe)
  ==
++  service
  |=  [our=@p actor=@p at=@da]
  ^-  (unit @tas)
  ?.  =(our actor)  `%owner-required
  ?.  (agent-live:guard our at %viki)  `%viki-unavailable
  =/  raw=*  .^(* %gv /(scot %p our)/viki/(scot %da at)/$)
  =/  egg  ((soft ,live-egg) raw)
  ?~  egg  `%project-requests-not-supported
  ?.  (supported noun.saved.old-state.u.egg)  `%project-requests-not-supported
  ~
++  checked
  |=  entries=catalog:project
  ^-  (each catalog:project @tas)
  ?:  (gth ~(wyt by entries) 128)  [%| %status-overflow]
  ?.  %+  levy  ~(tap by entries)
      |=  [key=@ux item=status:project]
      ?&  =(key nonce.item)  !=(0 key)  (lte (met 0 key) 128)
          =(project.item project-name:page)
          !=('' goal.item)  (lte (met 3 goal.item) 128)
          !=('' text.item)  (lte (met 3 text.item) 8.192)
      ==
    [%| %status-binding-invalid]
  [%& entries]
++  read
  |=  [our=@p actor=@p at=@da]
  ^-  (each catalog:project @tas)
  =/  error  (service our actor at)
  ?^  error  [%| u.error]
  =/  current=catalog:project
    .^(catalog:project %gx /(scot %p our)/viki/(scot %da at)/glass/projects/noun)
  (checked current)
++  location
  |=  url=@t
  ^-  (each (unit @ux) @tas)
  =/  prefix=@t  '/apps/pataphor-work?'
  =/  size=@ud  (met 3 prefix)
  ?.  &(=(prefix (cut 3 [0 size] url)) (gte (met 3 url) size))
    [%| %not-project]
  =/  fields  (parse-fields:http (cut 3 [size (sub (met 3 url) size)] url))
  ?~  fields  [%| %not-project]
  ?.  &(=(`'1' (~(get by u.fields) 'glass')) (~(has by u.fields) 'project'))
    [%| %not-project]
  ?.  =(`project-name:page (~(get by u.fields) 'project'))  [%| %invalid-address]
  =/  request  (~(get by u.fields) 'request')
  =/  selected=(unit @ux)
    ?~  request  ~
    (slaw %ux u.request)
  ?:  &(?=(^ request) ?=(~ selected))  [%| %invalid-address]
  ?.  ?~(selected %.y &(!=(0 u.selected) (lte (met 0 u.selected) 128)))
    [%| %invalid-address]
  ?.  =(url (href:page selected))  [%| %invalid-address]
  [%& selected]
++  start
  |=  [our=@p item=request:project]
  ^-  card:agent:gall
  [%pass /glass-goal/[goal.item] %agent [our %viki] %poke %noun !>(item)]
++  handle
  |=  [b=bowl:gall token=@uv id=@ta req=inbound-request:eyre]
  ^-  (unit response)
  =/  route  (location url.request.req)
  ?:  =([%| %not-project] route)  ~
  =/  head=?  =('HEAD' method.request.req)
  ?.  &(authenticated.req =(our.b src.b))
    `[(respond:http id 403 'Owner authentication required.' ~ head) token]
  ?:  ?=(%| -.route)
    `[(respond:http id 404 'Invalid project request address.' ~ head) token]
  ?:  head  `[(respond:http id 200 '' ~ %.y) token]
  ?:  =('GET' method.request.req)
    =/  current  (read our.b src.b now.b)
    =/  correction=view:guidance
      ?:  ?=(%| -.current)  [%& ~]
      ?~  p.route  [%& ~]
      =/  selected  (~(get by p.current) u.p.route)
      ?~  selected  [%& ~]
      (read:guidance our.b src.b now.b u.selected)
    `[(respond:http id 200 (page-with-guidance:page our.b token p.route current correction) ~ %.n) token]
  ?.  =('POST' method.request.req)
    `[(respond:http id 405 'Use the project request form.' ~[['allow' 'GET, HEAD, POST']] %.n) token]
  ?^  p.route
    `[(respond:http id 405 'Observe this request; use a new form for another change.' ~ %.n) token]
  =/  headers  (~(gas by *(map @t @t)) header-list.request.req)
  ?.  =(`'application/x-www-form-urlencoded' (~(get by headers) 'content-type'))
    `[(respond:http id 415 'Use the project request form.' ~ %.n) token]
  =/  body  body.request.req
  ?~  body  `[(respond:http id 400 'Empty form.' ~ %.n) token]
  ?.  &((lte p.u.body 16.384) =(p.u.body (met 3 q.u.body)))
    `[(respond:http id 413 'Invalid form size.' ~ %.n) token]
  =/  selected  (decode:page token q.u.body)
  ?~  selected
    `[(respond:http id 403 'Invalid or expired form or expected examples. Reload before submitting.' ~ %.n) token]
  =/  error  (service our.b src.b now.b)
  ?^  error
    `[(respond:http id 503 (cat 3 'Request not submitted: ' `@t`u.error) ~ %.n) token]
  =/  item=request:project  (action:page our.b token u.selected)
  =/  next=@uv  `@uv`(sham [token eny.b now.b %glass-project])
  `[(weld ~[(start our.b item)] (respond:http id 303 'Requested; Viki retention is unconfirmed.' ~[['location' (href:page `nonce.item)]] %.n)) next]
--
