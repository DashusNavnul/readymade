::  Selected owner authority for an isolated two-file development request.
/-  pc=pataphor-project-coding, vr=glass-moon-route, vw=viki-worker,
    mg=moon-grant, gs=graf, ws=workspace
/+  coding=pataphor-project-coding, source=pataphor-project-coding-read,
    route=viki-route, seats=seat-session, law=cantrip-law-window,
    generation=cantrip-glass-generation, dispatch=cantrip-vibecoding-dispatch,
    guard=viki-scry-guard, vgc=viki-glass-coding
|%
+$  evidence
  $:  route=moon-route:vr  sessions=table:seats  window=window:law
      seat-write=graf-seat-write:gs  claim=claim:ws  desks=(set @tas)
      grant=(unit moon-grant:mg)  mirror=(unit mirrored-lease:mg)
  ==
+$  admission
  $:  request=request:pc  manifest=manifest:pc  prior=(unit result:pc)
      at=@da  evidence=evidence
  ==
++  valid
  |=  [our=@p a=admission]
  ^-  ?
  =/  r=request:pc  request.a
  =/  prepared  (prepare-request:coding our our nonce.r manifest.a prior.a text.r)
  ?.  =([%& r] prepared)  %.n
  =/  e=evidence  evidence.a
  =/  s  seat-session.route.e
  ?.  ?&  =(our owner.basis.manifest.a)  (lte at.basis.manifest.a at.a)
          =(%codex kind.provider.route.e)
          =(working:source base-desk.body.snapshot.working.basis.manifest.a)
          =(working:source workspace.s)
          =(accepted:source base-desk.project.basis.manifest.a)
          =(base.claim.e base-desk.project.basis.manifest.a)
          (lte at.claim.e at.a)
          (allowed:route our at.a sessions.e route.e)
          (inspect-allowed:generation window.e)
          =(workspace.s fork.claim.e)  =(moon.s holder.claim.e)
          (~(has in desks.e) workspace.s)
          =(seat.s seat-id.seat-write.e)
          =((scot %p moon.s) assigned-ship-id.seat-write.e)
          =(`@t`workspace.s session-id.seat-write.e)
          =(%claim write-kind.seat-write.e)
      ==  %.n
  ?~  grant.e  %.n
  ?~  mirror.e  %.n
  =/  forever=@da  `@da`0
  ?.  &(=(0 lease-seconds.u.grant.e) =(`forever expires-at.u.grant.e) =(forever expires.u.mirror.e))  %.n
  =(~ (grant-rejections:dispatch grant.e moon.s our seat.s seat-write.e mirror.e 'read-file' %safe at.a))
++  same
  ::  Ignore unrelated seats and desks, but retain full original snapshots.
  |=  [before=evidence after=evidence]
  ^-  ?
  =/  s  seat-session.route.before
  ?&  =(before(sessions sessions.after, desks desks.after) after)
      =(`s (~(get by sessions.after) seat.s))
      (~(has in desks.before) workspace.s)
      (~(has in desks.after) workspace.s)
  ==
++  read
  |=  [b=bowl:gall workers=worker-organ:vw selected=moon-route:vr]
  ^-  (each evidence @tas)
  ?.  &(=(our.b src.b) authoritative.workers)  [%| %owner-authority-unavailable]
  ?.  %+  levy  `(list @tas)`~[%graf %seat-warden %cantrip %multiplayer-session-coordinator]
      |=(app=@tas (agent-live:guard our.b now.b app))
    [%| %native-service-unavailable]
  =/  table=table:seats
    .^(table:seats %gx /(scot %p our.b)/seat-warden/(scot %da now.b)/table/noun)
  =/  s  seat-session.selected
  =/  write=(unit graf-seat-write:gs)
    .^((unit graf-seat-write:gs) %gx /(scot %p our.b)/graf/(scot %da now.b)/seat/[seat.s]/holder/noun)
  ?~  write  [%| %seat-write-missing]
  =/  rows=(list [fact=* ships=(set @p)])
    .^((list [* (set @p)]) %gx /(scot %p our.b)/graf/(scot %da now.b)/attested/noun)
  =/  owned=(list *)
    (murn rows |=(r=[fact=* ships=(set @p)] ?:((~(has in ships.r) our.b) `fact.r ~)))
  =/  claim  (claim-for:vgc owned moon.s workspace.s)
  ?~  claim  [%| %workspace-claim-missing-or-conflicting]
  =/  window=window:law
    .^(window:law %gx /(scot %p our.b)/cantrip/(scot %da now.b)/law/window/current/noun)
  =/  grant=(unit moon-grant:mg)
    (~(get by grants.core.workers) lease-id.u.write)
  =/  mirror=(unit mirrored-lease:mg)
    .^((unit mirrored-lease:mg) %gx /(scot %p our.b)/cantrip/(scot %da now.b)/lease/[lease-id.u.write]/noun)
  =/  desks=(set @tas)
    .^((set @tas) %cd ~[(scot %p our.b) '' (scot %da now.b)])
  [%& [selected table window u.write u.claim desks grant mirror]]
++  current
  |=  [b=bowl:gall routes=(list moon-route:vr) workers=worker-organ:vw a=admission]
  ^-  (each ~ @tas)
  ?.  &(=(our.b src.b) (valid our.b a))  [%| %admission-invalid]
  =/  selected=moon-route:vr  route.evidence.a
  ?.  =((skim routes |=(r=moon-route:vr =((key-for:route r) (key-for:route selected)))) ~[selected])
    [%| %selected-route-changed]
  =/  manifest  (read:source our.b our.b now.b)
  ?:  ?=(%| -.manifest)  [%| p.manifest]
  ?.  =((manifest-id:coding manifest.a) (manifest-id:coding p.manifest))
    [%| %source-changed]
  =/  e  (read b workers selected)
  ?:  ?=(%| -.e)  [%| p.e]
  ?.  &((valid our.b a(at now.b, evidence p.e)) (same evidence.a p.e))
    [%| %selected-authority-changed]
  [%& ~]
--
