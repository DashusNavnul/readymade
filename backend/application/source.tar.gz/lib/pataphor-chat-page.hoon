::  Stable native workspace shell. Hawk owns conversation and working views.
/-  pc=pataphor-chat
/+  asset=ui-asset
|%
++  escape
  |=  text=@t
  ^-  @t
  %+  rap  3
  %+  turn  (trip text)
  |=  c=@tD
  ^-  @t
  ?:  =(c 38)  '&amp;'
  ?:  =(c 60)  '&lt;'
  ?:  =(c 62)  '&gt;'
  ?:  =(c 34)  '&quot;'
  ?:  =(c 39)  '&#39;'
  (crip ~[c])
::  Shared by the still-active editor, preview, review and project forms.
++  url
  |=  text=@t
  ^-  @t
  %-  crip
  %-  zing
  %+  turn  (trip text)
  |=  c=@tD
  ^-  tape
  ?:  ?|  &((gte c 'A') (lte c 'Z'))  &((gte c 'a') (lte c 'z'))
          &((gte c '0') (lte c '9'))  =(c '-')  =(c '_')  =(c '.')  =(c '~')
      ==
    ~[c]
  =/  hex=@t  '0123456789ABCDEF'
  ~['%' (cut 3 [(rsh 2 c) 1] hex) (cut 3 [(dis c 0xf) 1] hex)]
++  field
  |=  [name=@t value=@t]
  ^-  @t
  (rap 3 ~['<input type="hidden" name="' (escape name) '" value="' (escape value) '">'])
++  css
  ^-  @t
  %+  rap  3
  :~  ':root{color-scheme:dark;--bg:#181818;--panel:#242424;--line:#353535;--muted:#aaa;--ink:#ddd;--accent:#ffaa00}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.55 ui-monospace,SFMono-Regular,Consolas,monospace}a{color:inherit;text-decoration:none}a:hover{text-decoration:underline}button,input,textarea{font:inherit}button:focus-visible,a:focus-visible,input:focus-visible,textarea:focus-visible{outline:2px solid var(--accent);outline-offset:4px}'
      'aside{background:var(--panel);border-right:1px solid var(--line)}.brand{font-size:19px;font-weight:750}.identity{font-size:12px;color:var(--muted);overflow-wrap:anywhere}nav h2{font-size:11px;letter-spacing:1.6px;color:var(--muted);text-transform:uppercase}.room{display:block;padding:10px 12px;margin:5px 0;border:1px solid var(--line);border-radius:2px;overflow-wrap:anywhere}.private-room{background:#29251c;border-color:#64502d}main{width:100%;min-width:0}header{display:flex;align-items:center;justify-content:space-between;gap:18px}p{margin:10px 0}.notice{padding:12px 16px;border:1px solid #685038;color:#ffd59b;overflow-wrap:anywhere}button{background:transparent;color:var(--accent);border:1px solid #64502d;border-radius:2px;padding:6px 10px;cursor:pointer}button:disabled{opacity:.5}summary{cursor:pointer;color:var(--muted);font-size:12px;padding:8px 0}'
  ==
++  page
  |=  v=view:pc
  ^-  @t
  (page-with-assets v *manifest:asset)
++  script
  |=  [assets=manifest:asset name=@ta]
  ^-  @t
  =/  ref=(unit reference:asset)  (~(get by files.assets) name)
  =/  url=@t  ?~(ref (rap 3 ~['/apps/pataphor/' name '.js']) (url:asset u.ref))
  (rap 3 ~['<script src="' (escape url) '" defer></script>'])
++  page-with-assets
  |=  [v=view:pc assets=manifest:asset]
  ^-  @t
  (page-with-capabilities v assets %.y %.y)
++  page-with-capabilities
  |=  [v=view:pc assets=manifest:asset work=? coding=?]
  ^-  @t
  %+  rap  3
  :~  '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="referrer" content="no-referrer"><title>Pataphor</title>'
      '<meta name="readymade-assets" content="'  (escape (en:json:html (json:asset assets)))  '">'
      (script assets %workspace)
      (script assets %sigil)  (script assets %dialogue)
      (script assets %panes)
      (script assets %sigil-key)
      (script assets %readymade-apps)
      (script assets %readymade-messages)
      '<style>'  css  workspace-css  '</style></head><body class="workspace" data-ship-atom="'
      (scot %ux our.v)
      ?:(coding '' '" data-native-coding="false')
      '"><header class="workspace-bar"><a href="/apps/pataphor">PATAPHOR</a><span>'
      (escape (scot %p our.v))
      '</span></header><div class="layout">'
      '<aside><a class="brand" href="/apps/pataphor">Pataphor</a><div class="identity">'
      (escape (scot %p our.v))
      '</div><nav aria-label="Workspace"><h2>Work</h2>'
      ?:(coding '<a class="room private-room" href="/apps/pataphor-native/coding" target="pataphor-project" data-native-coding-link data-scene-editor data-work-view="files">Files</a>' '')
      '<a class="room private-room" href="/apps/pataphor-terminal" target="pataphor-project" data-scene-terminal data-work-view="terminal">Terminal</a>'
      ?:(coding '<a class="room" href="/apps/pataphor-native/coding" target="pataphor-project" data-native-coding-link data-work-view="changes">Changes</a><a class="room" href="/apps/pataphor-native/coding" target="pataphor-project" data-native-coding-link data-work-view="run">Run</a>' '')
      '<details><summary>Advanced workspaces</summary>'
      ?:  work
        '<a class="room private-room" href="/apps/pataphor-work?glass=1&amp;project=pataphor" target="pataphor-project">Pataphor / Codex</a><a class="room" href="/apps/pataphor-work?glass=1" target="pataphor-project">Viki / moon work</a><details><summary>Demo project</summary><a class="room" href="/apps/pataphor-work?editor=1" target="pataphor-project">Source editor</a><a class="room" href="/apps/pataphor-work?results=1" target="pataphor-project">Changes and checks</a><a class="room" href="/apps/pataphor-work?sharing=1" target="pataphor-project">Project sharing</a></details>'
      '<span class="room">Advanced Work pages unavailable</span>'
      ?:  coding
        '<a class="room" href="/apps/pataphor-native/coding" target="pataphor-project" data-native-coding-link>Native coding</a>'
      '<span class="room">Native coding unavailable</span>'
      '</details><h2>Conversations</h2><a class="room" href="/apps/pataphor">Private conversation</a></nav></aside><main class="workspace-main">'
      '<section class="project-pane" aria-label="Pataphor coding workspace"><div class="pane-bar">PROJECT / PATAPHOR <span data-native-controls hidden><select data-native-project aria-label="Native project"></select><select data-native-session aria-label="Native session"></select></span> '
      ?:(coding '<a data-native-coding-link href="/apps/pataphor-native/coding" target="pataphor-project">Native coding</a>' '')
      ?:(work ' <a href="/apps/pataphor-work?glass=1&amp;project=pataphor" target="_blank" rel="noopener noreferrer">Open separately</a>' '')
      '</div><iframe name="pataphor-project" title="Pataphor coding, changes, checks and preview" src="/apps/pataphor-terminal" data-scene="terminal" referrerpolicy="no-referrer" allow="camera &#39;none&#39;; microphone &#39;none&#39;; display-capture &#39;none&#39;"></iframe></section><section id="readymade-activity" class="conversation-pane" data-readymade-workspace="v1" aria-label="Pataphor workspace">'
      ?~  notice.v
        ''
      (rap 3 ~['<p class="notice" role="status">' (escape u.notice.v) '</p>'])
      '<iframe name="pataphor-reactive" title="Pataphor workspace rendered on Urbit" src="/apps/pataphor-reactive?view=conversation" referrerpolicy="no-referrer" allow="camera &#39;none&#39;; microphone &#39;none&#39;; display-capture &#39;none&#39;"></iframe>'
      '<noscript><p class="notice">Enable JavaScript to use the native workspace. <a href="/apps/pataphor-reactive?view=conversation" target="_blank" rel="noopener noreferrer">Open it separately</a>.</p></noscript>'
      '</section></main></div></body></html>'
  ==
++  workspace-css
  ^-  @t
  %+  rap  3
  :~  '.workspace{height:100vh;display:flex;flex-direction:column;overflow:hidden}.workspace-bar{height:44px;flex:none;padding:0 18px;border-bottom:1px solid var(--line);font-size:12px;letter-spacing:1px}.workspace-bar>a{color:var(--accent)}.workspace .layout{display:grid;grid-template-columns:220px minmax(0,1fr);min-height:0;flex:1}.workspace aside{overflow:auto;padding:18px 12px}.workspace nav{margin-top:12px}.workspace nav h2{margin-top:20px}.workspace .brand{color:var(--accent)}.workspace-main{margin:0;padding:0;display:grid;grid-template-columns:minmax(360px,1fr) minmax(300px,480px);min-height:0;height:100%}.project-pane{display:flex;flex-direction:column;min-width:0;min-height:0}.pane-bar{height:42px;flex:none;display:flex;align-items:center;justify-content:space-between;padding:0 14px;border-bottom:1px solid var(--line);font-size:11px;color:var(--accent);gap:12px}.pane-bar a{color:var(--muted)}.project-pane iframe{width:100%;flex:1;min-height:0;border:0;background:var(--bg)}.conversation-pane{display:flex;flex-direction:column;overflow:hidden;min-width:0;min-height:0;padding:0;border-left:1px solid var(--line)}.conversation-pane>iframe{display:block;width:100%;flex:1;min-height:0;border:0;background:#14120f}.conversation-pane>.notice{flex:none;margin:0;font-size:12px}'
      '@media(max-width:1100px){.workspace .layout{grid-template-columns:180px minmax(0,1fr)}.workspace-main{grid-template-columns:minmax(320px,1fr) 360px}}@media(max-width:850px){.workspace{height:auto;overflow:auto}.workspace .layout{display:block}.workspace aside{border-right:0;border-bottom:1px solid var(--line)}.workspace nav{display:flex;flex-wrap:wrap;gap:8px;align-items:center}.workspace nav h2{width:100%;margin:8px 0 0}.workspace-main{display:block;height:auto}.project-pane{height:75vh;min-height:480px}.conversation-pane{height:80vh;min-height:360px;border-left:0;border-top:1px solid var(--line)}.workspace-bar{padding:0 12px;font-size:10px}.workspace .room{margin:0}.workspace .identity{margin-left:0;display:block}}'
  ==
--
