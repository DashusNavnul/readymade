::  Owner-only archived-session pages. Older Viki saves never receive a scry.
/+  listing=native-coding-session-archive-list, terminal=native-coding-terminal,
    guard=viki-scry-guard, saved=qpc-native-app-state,
    journal=native-coding-session
|%
+$  request  [offset=@ud revision=@ud commit=@uv]
+$  archived
  $:  %native-coding-session-archive-receipt-v2  owner=@p  session=@ux  at=@da  evidence=@ux
      entry=entry:journal  binding=*  opening=*  inputs=*  input-ledger=@ux
      carried=[completions=(map @ux *) campaigns=(map @ux *) reviewed=(map @ux *)]
  ==
+$  assessment  [snapshot=@ux blockers=(list [reason=@tas reference=@ux])]
++  query
  |=  text=@t
  ^-  (unit request)
  %-  mole
  |.
  ?>  (lte (met 3 text) 180)
  =/  one  (split:terminal 38 text)
  =/  two  (split:terminal 38 tail.one)
  ?>  &(found.one found.two)
  =/  a  (split:terminal 61 head.one)
  =/  b  (split:terminal 61 head.two)
  =/  c  (split:terminal 61 tail.two)
  ?>  &(found.a found.b found.c =('offset' head.a) =('revision' head.b) =('commit' head.c))
  =/  offset=@ud  (need (slaw %ud tail.a))
  =/  revision=@ud  (need (slaw %ud tail.b))
  =/  commit=@uv  (need (slaw %uv tail.c))
  ?>  &((lte offset 9.007.199.254.740.991) (lte revision 9.007.199.254.740.991))
  ?>  &(=(tail.a (scot %ud offset)) =(tail.b (scot %ud revision)) =(tail.c (scot %uv commit)))
  ?>  =(=(0 revision) =(0 commit))
  ?>  |(!=(0 revision) =(0 offset))
  [offset revision commit]
++  projection-ready
  |=  parts=(list part:saved)
  ^-  ?
  =/  found  (skim parts |=(p=part:saved =(%native-coding-session-archive-v1 tag.p)))
  ?:  ?=([* ~] found)  %.y
  ?.  ?=(~ found)  %.n
  ::  Older console projections retain the full v32 value in %inner.
  =/  inner  (skim parts |=(p=part:saved =(%inner tag.p)))
  ?.  ?=([* ~] inner)  %.n
  ?=([%viki-familiar-state-v32 *] data.i.inner)
++  ready
  |=  [our=@p at=@da]
  ^-  ?
  ?.  (agent-live:guard our at %viki)  %.n
  =/  egg=egg-any:gall  .^(egg-any:gall %gv /(scot %p our)/viki/(scot %da at)/$)
  ?.  ?=([%20 %live *] egg)  %.n
  =/  current=egg:gall  +.egg
  ?.  ?=(%live -.current)  %.n
  =/  parts  (mole |.((viki:saved +.old-state.current)))
  ?~  parts  %.n
  (projection-ready u.parts)
++  failure
  |=  [our=@p reason=@tas]
  ^-  json
  (pairs:enjs:format ~[['schema' s+'native-coding-session-archive-page-v1'] ['owner' s+(scot %p our)] ['available' b+%.n] ['error' s+(scot %tas reason)]])
++  page
  |=  [our=@p src=@p result=(each page:listing @tas)]
  ^-  json
  ?.  =(our src)  (failure our %archive-owner-required)
  ?:  ?=(%| -.result)  (failure our p.result)
  =/  p=page:listing  p.result
  =/  anchor=json
    (pairs:enjs:format ~[['revision' (numb:enjs:format number.head.p)] ['commit' s+(scot %uv commit.head.p)]])
  (pairs:enjs:format ~[['schema' s+'native-coding-session-archive-page-v1'] ['owner' s+(scot %p our)] ['available' b+%.y] ['head' anchor] ['offset' (numb:enjs:format offset.p)] ['next' ?~(next.p ~ (numb:enjs:format u.next.p))] ['sessionIds' a+(turn ids.p |=(id=@ux s+(scot %ux id)))]])
++  route
  |=  [our=@p src=@p at=@da url=@t]
  ^-  (unit json)
  =/  prefix=@t  '/apps/pataphor-native/coding/archived-sessions?'
  ?.  =(prefix (cut 3 [0 (met 3 prefix)] url))  ~
  ?.  =(our src)  `(failure our %archive-owner-required)
  =/  parsed  (query (rsh [3 (met 3 prefix)] url))
  ?~  parsed  `(failure our %archive-page-cursor)
  ?.  (ready our at)  `(failure our %archive-history-unavailable)
  =/  q=request  u.parsed
  =/  raw=*  .^(* %gx /(scot %p our)/viki/(scot %da at)/native-coding/session-archive/page/(scot %ud offset.q)/(scot %ud revision.q)/(scot %uv commit.q)/noun)
  =/  decoded  ((soft ,(each page:listing @tas)) raw)
  ?~  decoded  `(failure our %archive-page-invalid)
  ?.  =(raw u.decoded)  `(failure our %archive-page-invalid)
  `(page our src u.decoded)
++  detail
  |=  [our=@p src=@p held=(each (unit archived) @tas) after=@ud render=$-(record:journal json)]
  ^-  json
  ?.  =(our src)  (failure our %archive-owner-required)
  ?:  ?=(%| -.held)  (failure our p.held)
  ?~  p.held  (failure our %archive-session-not-found)
  =/  cold=archived  u.p.held
  ::  Viki validates the immutable receipt and current private Clay head.
  ?.  &(=(our owner.cold) =(our owner.session.entry.cold) !=(0 session.cold) =(session.cold id.session.entry.cold))
    (failure our %archive-receipt-invalid)
  =/  e=entry:journal  entry.cold
  =/  rows=(list record:journal)  (scag 32 (skim records.e |=(r=record:journal (gte sequence.r after))))
  =/  next=@ud  ?~(rows after +((rear (turn rows |=(r=record:journal sequence.r)))))
  (pairs:enjs:format ~[['schema' s+'native-coding-session-archive-detail-v1'] ['owner' s+(scot %p our)] ['available' b+%.y] ['session' s+(scot %ux session.cold)] ['project' s+project.session.e] ['objective' s+objective.session.e] ['summary' s+summary.e] ['phase' s+(scot %tas phase.e)] ['records' a+(turn rows render)] ['after' (numb:enjs:format next)] ['more' b+(lth next sequence.e)]])
++  detail-route
  |=  [our=@p src=@p at=@da url=@t render=$-(record:journal json)]
  ^-  (unit json)
  =/  prefix=@t  '/apps/pataphor-native/coding/archived-session?'
  ?.  =(prefix (cut 3 [0 (met 3 prefix)] url))  ~
  ?.  =(our src)  `(failure our %archive-owner-required)
  =/  text=@t  (rsh [3 (met 3 prefix)] url)
  ?.  (lte (met 3 text) 120)  `(failure our %archive-page-cursor)
  =/  pair  (split:terminal 38 text)
  ?.  found.pair  `(failure our %archive-page-cursor)
  =/  first  (split:terminal 61 head.pair)
  =/  second  (split:terminal 61 tail.pair)
  ?.  &(found.first found.second =('id' head.first) =('after' head.second))  `(failure our %archive-page-cursor)
  =/  id  (slaw %ux tail.first)
  =/  after  (slaw %ud tail.second)
  ?~  id  `(failure our %archive-page-cursor)
  ?~  after  `(failure our %archive-page-cursor)
  ?.  &(!=(0 u.id) (lte u.after 9.007.199.254.740.991) =(tail.first (scot %ux u.id)) =(tail.second (scot %ud u.after)))
    `(failure our %archive-page-cursor)
  ?.  (ready our at)  `(failure our %archive-history-unavailable)
  =/  raw=*  .^(* %gx /(scot %p our)/viki/(scot %da at)/native-coding/session-archive/history/(scot %ux u.id)/noun)
  =/  decoded  ((soft ,(each (unit archived) @tas)) raw)
  ?~  decoded  `(failure our %archive-receipt-invalid)
  ?.  =(raw u.decoded)  `(failure our %archive-receipt-invalid)
  ?-  -.u.decoded
    %|  `(detail our src u.decoded u.after render)
    %&
      ?~  p.u.decoded  `(detail our src u.decoded u.after render)
      ?.  =(u.id session.u.p.u.decoded)  `(failure our %archive-receipt-invalid)
      `(detail our src u.decoded u.after render)
  ==
++  assessment-json
  |=  [our=@p id=@ux result=(each assessment @tas)]
  ^-  json
  ?:  ?=(%| -.result)  (failure our p.result)
  =/  a=assessment  p.result
  =/  blockers=(list json)
    %+  turn  blockers.a
    |=  item=[reason=@tas reference=@ux]
    (pairs:enjs:format ~[['reason' s+(scot %tas reason.item)] ['reference' s+(scot %ux reference.item)]])
  (pairs:enjs:format ~[['schema' s+'native-coding-session-archive-assessment-v1'] ['owner' s+(scot %p our)] ['session' s+(scot %ux id)] ['available' b+%.y] ['snapshot' s+(scot %ux snapshot.a)] ['blockers' a+blockers]])
++  assessment-route
  |=  [our=@p src=@p at=@da url=@t]
  ^-  (unit json)
  =/  prefix=@t  '/apps/pataphor-native/coding/archive-assessment?id='
  ?.  =(prefix (cut 3 [0 (met 3 prefix)] url))  ~
  ?.  =(our src)  `(failure our %archive-owner-required)
  =/  text=@t  (rsh [3 (met 3 prefix)] url)
  ?.  (lte (met 3 text) 82)  `(failure our %archive-page-cursor)
  =/  id  (slaw %ux text)
  ?~  id  `(failure our %archive-page-cursor)
  ?.  &(!=(0 u.id) =(text (scot %ux u.id)))  `(failure our %archive-page-cursor)
  ?.  (ready our at)  `(failure our %archive-history-unavailable)
  =/  raw=*  .^(* %gx /(scot %p our)/viki/(scot %da at)/native-coding/session-archive/assessment/(scot %ux u.id)/noun)
  =/  decoded  ((soft ,(each assessment @tas)) raw)
  ?~  decoded  `(failure our %archive-assessment-invalid)
  ?.  =(raw u.decoded)  `(failure our %archive-assessment-invalid)
  `(assessment-json our u.id u.decoded)
++  status-route
  |=  [our=@p src=@p at=@da url=@t]
  ^-  (unit json)
  ?.  =('/apps/pataphor-native/coding/archive-status' url)  ~
  ?.  =(our src)  `(failure our %archive-owner-required)
  ?.  (ready our at)  `(failure our %archive-history-unavailable)
  =/  raw=*  .^(* %gx /(scot %p our)/viki/(scot %da at)/native-coding/session-archive/status/noun)
  =/  state  ((soft ,[head=(unit [desk=@tas number=@ud commit=@uv]) writing=(unit *)]) raw)
  ?~  state  `(failure our %archive-status-invalid)
  ?.  =(raw u.state)  `(failure our %archive-status-invalid)
  `(pairs:enjs:format ~[['schema' s+'native-coding-session-archive-status-v1'] ['owner' s+(scot %p our)] ['available' b+%.y] ['configured' b+?=(^ head.u.state)] ['pending' b+?=(^ writing.u.state)]])
--
