::  /lib/multiplayer-portability
::
::  Pure authority-checkpoint and four-message handoff law.  Live Gall callers
::  must pass host and src.bowl separately; submitted nouns never authenticate
::  either side of the transfer.
::
/-  mp=multiplayer-project, mpo=multiplayer-portability,
    mr=multiplayer-receipt, mrp=multiplayer-reputation
/+  mpl=multiplayer-project, rep=multiplayer-reputation
|%
++  max-window  `@dr`~h1
++  project-digest
  |=  project=project:mp
  ^-  digest:mp
  `@ux`(shax (jam [%multiplayer-portable-project-v1 project]))
++  payload-digest
  |=  payload=*
  ^-  digest:mr
  `@ux`(shax (jam [%multiplayer-portability-payload-v1 payload]))
++  checkpoint-digest
  |=  body=checkpoint-body:mpo
  ^-  digest:mr
  `@ux`(shax (jam [%multiplayer-authority-checkpoint-v1 body]))
++  acceptance-digest
  |=  body=acceptance-body:mpo
  ^-  digest:mr
  `@ux`(shax (jam [%multiplayer-authority-acceptance-v1 body]))
++  finalization-digest
  |=  body=finalization-body:mpo
  ^-  digest:mr
  `@ux`(shax (jam [%multiplayer-authority-finalization-v1 body]))
++  phase-name
  |=  phase=phase:mpo
  ^-  @tas
  phase
::
::  History is not rewritten.  It is sealed inside the checkpoint; the new
::  authority starts a fresh epoch with members carried, old authority demoted,
::  and all old invitations closed by epoch replacement.
++  rehome
  |=  [archived=project:mp to=@p at=@da]
  ^-  (unit project:mp)
  ?.  (project-valid:mpl archived)  ~
  =/  from=@p  authority.spec.archived
  ?:  =(from to)  ~
  =/  spec=project-spec:mp
    spec.archived(authority to, created-at at)
  =/  opened=result:mp  (open:mpl spec to)
  ?.  ?=(%& -.opened)  ~
  =/  carried=(map @p member:mp)  members.archived
  =/  former=member:mp  [%maintainer at ~]
  =/  successor=member:mp  [%operator at ~]
  =/  members=(map @p member:mp)
    (~(put by (~(put by carried) from former)) to successor)
  =/  next=project:mp  p.opened(members members)
  ?.  (project-valid:mpl next)  ~
  `next
++  reject
  |=  refusal=refusal:mpo
  ^-  result:mpo
  [%| refusal]
++  checkpoint-valid
  |=  checkpoint=checkpoint:mpo
  ^-  ?
  =/  body=checkpoint-body:mpo  body.checkpoint
  =/  proof=bundle:mrp  bundle.body
  =/  chain=chain:mr  chain.body.proof
  =/  next=(unit project:mp)  (rehome archived.body to.body offered-at.body)
  ?&  =(1 version.body)
      (project-valid:mpl archived.body)
      =(project.body id.spec.archived.body)
      =(from.body authority.spec.archived.body)
      !=(from.body to.body)
      (bundle-valid:rep proof)
      =(project.body project.chain)
      =(from.body authority-host.chain)
      (~(has by members.archived.body) owner.body.proof)
      =((project-digest archived.body) archived-digest.body)
      ?=(^ next)
      =((project-digest u.next) next-digest.body)
      =(digest.proof bundle-digest.body)
      =((payload-digest payload.body) payload-digest.body)
      !=(0 nonce.body)
      (gth expires-at.body offered-at.body)
      (lte expires-at.body (add offered-at.body max-window))
      =((checkpoint-digest body) digest.checkpoint)
  ==
++  acceptance-valid
  |=  [checkpoint=checkpoint:mpo acceptance=acceptance:mpo]
  ^-  ?
  =/  body=acceptance-body:mpo  body.acceptance
  =/  expected=checkpoint-body:mpo  body.checkpoint
  ?&  =(1 version.body)
      =(digest.checkpoint checkpoint.body)
      =(from.expected from.body)
      =(to.expected to.body)
      (gte accepted-at.body offered-at.expected)
      (lth accepted-at.body expires-at.expected)
      =((acceptance-digest body) digest.acceptance)
  ==
++  finalization-valid
  |=  $:  checkpoint=checkpoint:mpo
          acceptance=acceptance:mpo
          finalization=finalization:mpo
      ==
  ^-  ?
  =/  body=finalization-body:mpo  body.finalization
  =/  expected=checkpoint-body:mpo  body.checkpoint
  ?&  (acceptance-valid checkpoint acceptance)
      =(1 version.body)
      =(digest.checkpoint checkpoint.body)
      =(digest.acceptance acceptance.body)
      =(from.expected from.body)
      =(to.expected to.body)
      (gte finalized-at.body accepted-at.body.acceptance)
      (lth finalized-at.body expires-at.expected)
      =((finalization-digest body) digest.finalization)
  ==
++  transfer-valid
  |=  transfer=transfer:mpo
  ^-  ?
  ?.  (checkpoint-valid point.transfer)  %.n
  ?-  status.transfer
    %offered
      ?&  ?=(~ accepted.transfer)
          ?=(~ finalized.transfer)
          ?=(~ rolled-back-at.transfer)
      ==
    %staged
      ?~  accepted.transfer  %.n
      ?&  ?=(~ finalized.transfer)
          ?=(~ rolled-back-at.transfer)
          (acceptance-valid point.transfer u.accepted.transfer)
      ==
    %finalized
      ?~  accepted.transfer  %.n
      ?~  finalized.transfer  %.n
      ?&  ?=(~ rolled-back-at.transfer)
          (finalization-valid point.transfer u.accepted.transfer u.finalized.transfer)
      ==
    %active
      ?~  accepted.transfer  %.n
      ?~  finalized.transfer  %.n
      ?&  ?=(~ rolled-back-at.transfer)
          (finalization-valid point.transfer u.accepted.transfer u.finalized.transfer)
      ==
    %rolled-back
      ?~  rolled-back-at.transfer  %.n
      ?&  ?=(~ accepted.transfer)
          ?=(~ finalized.transfer)
          (gte u.rolled-back-at.transfer expires-at.body.point.transfer)
      ==
  ==
++  offer
  |=  $:  archived=project:mp
          bundle=bundle:mrp
          payload=*
          host=@p
          source=@p
          to=@p
          offered-at=@da
          expires-at=@da
          nonce=digest:mr
      ==
  ^-  result:mpo
  ?.  (project-valid:mpl archived)  (reject [%invalid-project ~])
  =/  from=@p  authority.spec.archived
  ?.  =(host from)  (reject [%foreign-host from host])
  ?.  =(source from)  (reject [%foreign-source from source])
  ?:  =(from to)  (reject [%same-authority from])
  ?.  (bundle-valid:rep bundle)  (reject [%invalid-bundle ~])
  =/  proof-chain=chain:mr  chain.body.bundle
  ?.  =(id.spec.archived project.proof-chain)
    (reject [%bundle-project id.spec.archived project.proof-chain])
  ?.  =(from authority-host.proof-chain)
    (reject [%bundle-authority from authority-host.proof-chain])
  ?.  (~(has by members.archived) owner.body.bundle)
    (reject [%bundle-owner-not-member owner.body.bundle])
  ?.  ?&  (gth expires-at offered-at)
          (lte expires-at (add offered-at max-window))
      ==
    (reject [%window-invalid offered-at expires-at])
  =/  next=(unit project:mp)  (rehome archived to offered-at)
  ?~  next  (reject [%invalid-project ~])
  =/  body=checkpoint-body:mpo
    :*  1
        id.spec.archived
        from
        to
        archived
        (project-digest archived)
        (project-digest u.next)
        bundle
        digest.bundle
        payload
        (payload-digest payload)
        offered-at
        expires-at
        nonce
    ==
  =/  checkpoint=checkpoint:mpo  [body (checkpoint-digest body)]
  ?.  (checkpoint-valid checkpoint)  (reject [%invalid-checkpoint ~])
  [%& [checkpoint %offered ~ ~ ~]]
++  stage
  |=  [transfer=transfer:mpo host=@p source=@p observed-at=@da]
  ^-  result:mpo
  ?.  (transfer-valid transfer)  (reject [%invalid-transfer ~])
  ?.  =(%offered status.transfer)
    (reject [%wrong-phase %offered (phase-name status.transfer)])
  =/  body=checkpoint-body:mpo  body.point.transfer
  ?.  =(host to.body)  (reject [%foreign-host to.body host])
  ?.  =(source from.body)  (reject [%foreign-source from.body source])
  ?:  (gte observed-at expires-at.body)
    (reject [%expired expires-at.body observed-at])
  =/  acceptance-body=acceptance-body:mpo
    [1 digest.point.transfer from.body to.body observed-at]
  =/  acceptance=acceptance:mpo
    [acceptance-body (acceptance-digest acceptance-body)]
  =/  next=transfer:mpo
    transfer(status %staged, accepted `acceptance)
  ?.  (transfer-valid next)  (reject [%invalid-acceptance ~])
  [%& next]
++  finalize
  |=  $:  transfer=transfer:mpo
          acceptance=acceptance:mpo
          host=@p
          source=@p
          observed-at=@da
      ==
  ^-  result:mpo
  ?.  (transfer-valid transfer)  (reject [%invalid-transfer ~])
  ?.  =(%offered status.transfer)
    (reject [%wrong-phase %offered (phase-name status.transfer)])
  =/  body=checkpoint-body:mpo  body.point.transfer
  ?.  =(host from.body)  (reject [%foreign-host from.body host])
  ?.  =(source to.body)  (reject [%foreign-source to.body source])
  ?.  (acceptance-valid point.transfer acceptance)
    (reject [%invalid-acceptance ~])
  ?:  (gte observed-at expires-at.body)
    (reject [%expired expires-at.body observed-at])
  =/  final-body=finalization-body:mpo
    [1 digest.point.transfer digest.acceptance from.body to.body observed-at]
  =/  finalization=finalization:mpo
    [final-body (finalization-digest final-body)]
  =/  next=transfer:mpo
    transfer(status %finalized, accepted `acceptance, finalized `finalization)
  ?.  (transfer-valid next)  (reject [%invalid-finalization ~])
  [%& next]
++  activate
  |=  $:  transfer=transfer:mpo
          finalization=finalization:mpo
          host=@p
          source=@p
          observed-at=@da
      ==
  ^-  result:mpo
  ?.  (transfer-valid transfer)  (reject [%invalid-transfer ~])
  ?.  =(%staged status.transfer)
    (reject [%wrong-phase %staged (phase-name status.transfer)])
  =/  body=checkpoint-body:mpo  body.point.transfer
  ?.  =(host to.body)  (reject [%foreign-host to.body host])
  ?.  =(source from.body)  (reject [%foreign-source from.body source])
  ?~  accepted.transfer  (reject [%invalid-acceptance ~])
  ?.  (finalization-valid point.transfer u.accepted.transfer finalization)
    (reject [%invalid-finalization ~])
  ?:  (gte observed-at expires-at.body)
    (reject [%expired expires-at.body observed-at])
  =/  next=transfer:mpo
    transfer(status %active, finalized `finalization)
  ?.  (transfer-valid next)  (reject [%invalid-transfer ~])
  [%& next]
++  rollback
  |=  [transfer=transfer:mpo host=@p source=@p observed-at=@da]
  ^-  result:mpo
  ?.  (transfer-valid transfer)  (reject [%invalid-transfer ~])
  ?.  =(%offered status.transfer)
    (reject [%wrong-phase %offered (phase-name status.transfer)])
  =/  body=checkpoint-body:mpo  body.point.transfer
  ?.  =(host from.body)  (reject [%foreign-host from.body host])
  ?.  =(source from.body)  (reject [%foreign-source from.body source])
  ?:  (lth observed-at expires-at.body)
    (reject [%rollback-too-early expires-at.body observed-at])
  [%& transfer(status %rolled-back, rolled-back-at `observed-at)]
--
