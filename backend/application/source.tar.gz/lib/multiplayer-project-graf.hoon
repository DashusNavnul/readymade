::  Project and membership transitions in Graf (items 41 and 42).
::
::  Every accepted project event is lit into Graf exactly as the project law
::  appended it: actor (the authenticated src), the project's authority ship,
::  its sequence, the digest of the event before it, and its own digest. That
::  chain is the link to authority; Graf keeps it after the catalog's bounded
::  1,024-event window has dropped it.
::
::  History rebuilt from Graf is history only. It says who WAS a member at each
::  step; it never answers whether anyone may act now. That answer comes only
::  from the live catalog (++may-act-now), so a past membership is never read
::  as a current grant.
/-  mp=multiplayer-project
/+  law=multiplayer-project
|%
++  kind  %multiplayer-project-transition-v1
+$  fact  [%multiplayer-project-transition-v1 project=project-id:mp event=event:mp]
++  per-action  16
::  ---  write side (item 41)
++  fresh
  ::  Events the action appended: newer than the old head, oldest first.
  |=  [old=(unit project:mp) new=(unit project:mp)]
  ^-  (list event:mp)
  ?~  new  ~
  =/  seen=@ud  ?~(old 0 event-sequence.u.old)
  %-  flop
  (scag per-action (skim events.u.new |=(e=event:mp (gth sequence.body.e seen))))
++  light
  |=  [our=@p project=project-id:mp e=event:mp]
  ^-  card:agent:gall
  =/  value=fact  [kind project e]
  [%pass /graf/project-transition/(scot %ux digest.e) %agent [our %graf] %poke %graf-action !>([%light value])]
++  cards
  ::  Only valid events of the project they name, authored under our authority.
  |=  [our=@p project=project-id:mp old=(unit project:mp) new=(unit project:mp)]
  ^-  (list card:agent:gall)
  %+  turn
    %+  skim  (fresh old new)
    |=  e=event:mp
    &((event-valid:law e) =(project project.body.e) =(our authority.body.e))
  |=(e=event:mp (light our project e))
::  ---  read side (item 42)
+$  row
  $:  sequence=@ud
      actor=@p
      action=event-action:mp
      at=@da
      digest=@ux
      members=(set @p)                  ::  members right after this event
  ==
+$  history
  $:  project=project-id:mp
      authority=@p
      complete=?                        ::  starts at the project's opening
      head=@ux
      rows=(list row)                   ::  oldest first
      former=(set @p)                   ::  members once, not at the head
  ==
++  facts-for
  ::  Graf facts of this kind for one project, deduplicated by digest.
  |=  [project=project-id:mp raw=(list *)]
  ^-  (list event:mp)
  =/  found=(map @ux event:mp)
    %+  roll  raw
    |=  [r=* acc=(map @ux event:mp)]
    =/  f  ((soft fact) r)
    ?~  f  acc
    ?.  &(=(r u.f) =(project project.u.f))  acc
    (~(put by acc) digest.event.u.f event.u.f)
  %+  sort  ~(val by found)
  |=([a=event:mp b=event:mp] (lth sequence.body.a sequence.body.b))
++  rebuild
  |=  [project=project-id:mp raw=(list *)]
  ^-  (each history @tas)
  =/  events=(list event:mp)  (facts-for project raw)
  ?~  events  [%| %project-history-empty]
  =/  first=event:mp  i.events
  =/  complete=?  =(1 sequence.body.first)
  ?.  =(complete ?=(%project-opened -.action.body.first))  [%| %project-history-opening-invalid]
  =/  authority=@p  authority.body.first
  =|  rows=(list row)
  =|  members=(set @p)
  =|  ever=(set @p)
  =|  targets=(map @ux @p)
  =/  prev=(unit event:mp)  ~
  =/  todo=(list event:mp)  events
  |-  ^-  (each history @tas)
  ?~  todo
    ?~  prev  [%| %project-history-empty]
    [%& project authority complete digest.u.prev (flop rows) (~(dif in ever) members)]
  =/  e=event:mp  i.todo
  ?.  (event-valid:law e)  [%| %project-history-digest-invalid]
  ?.  &(=(project project.body.e) =(authority authority.body.e))  [%| %project-history-foreign]
  ?:  ?&  ?=(^ prev)
          ?!  ?&  =(sequence.body.e +(sequence.body.u.prev))
                  =(previous.body.e `digest.u.prev)
                  (gte occurred-at.body.e occurred-at.body.u.prev)
              ==
      ==
    [%| %project-history-gap]
  =/  a=event-action:mp  action.body.e
  ?:  &(?=(^ prev) ?=(%project-opened -.a))  [%| %project-history-reopened]
  =.  targets  ?.(?=(%invitation-issued -.a) targets (~(put by targets) invitation.a target.a))
  =/  joined=(unit @p)
    ?:  ?=(%project-opened -.a)  `actor.body.e
    ?.  ?=(%invitation-accepted -.a)  ~
    (~(get by targets) invitation.a)
  ::  An acceptance whose invitation lies before a partial window is unknown,
  ::  so the window refuses rather than guessing who joined.
  ?:  &(?=(%invitation-accepted -.a) ?=(~ joined))  [%| %project-history-invitation-missing]
  =.  members  ?~(joined members (~(put in members) u.joined))
  =.  members  ?.(?=(%member-left -.a) members (~(del in members) member.a))
  =.  ever  ?~(joined ever (~(put in ever) u.joined))
  %=  $
    todo    t.todo
    prev    `e
    rows    [[sequence.body.e actor.body.e a occurred-at.body.e digest.e members] rows]
  ==
++  may-act-now
  ::  The only current answer. History is never consulted: a ship acts now
  ::  only if the live catalog holds it as a member at this moment.
  |=  [live=(unit project:mp) ship=@p]
  ^-  ?
  ?~  live  %.n
  (~(has by members.u.live) ship)
--
