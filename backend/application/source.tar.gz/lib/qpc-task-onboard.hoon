::  One native onboarding from a short task description. The registration,
::  both standing grants, the adjudication cases and the paused baseline
::  opening are derived together and validated together before any of them
::  is applied. Pure: no scry, no card; no permission is created here.
::  Measured need (2026-11-01): onboarding one member by hand took about
::  forty Earthside scripts and five operator hours per task.
/-  nc=native-coding, np=native-coding-provider
/+  q=qpc-native-outcome, contract=cantrip-native-coding-contract,
    tools=cantrip-native-coding, project=native-coding-project,
    outcomes=qpc-outcome-store, reservation=qpc-session-reservation,
    sensing=qpc-task-sensing, campaign=qpc-native-campaign,
    instrument=qpc-instrument-contract, obs=qpc-observation
|%
+$  description
  $:  %qpc-task-description-v1
      project=@t  target=@tas  artifact=path
      checks=(list [name=@tas expression=@t])
      objective=@t  key=@tas  selection=selection:np  nonce=@ux
      task=@t
  ==
+$  identities
  $:  seed=@ux  baseline=@ux  baseline-grant=@ux
      member=@ux  member-grant=@ux  campaign=@ux
  ==
+$  opening
  $:  id=@ux  project=@t  objective=@t  selection=selection:np
      key=@tas  grant=@ux  worker=@p  expected=revision:nc
  ==
+$  plan
  $:  %qpc-task-onboard-plan-v1
      identities=identities  project=project:nc  cases=cases:q
      baseline=grant:contract  member=grant:contract  opening=opening
  ==
+$  phase  ?(%granting %opened %checking %checked %handing %prepared %activated %failed)
+$  record-v1
  $:  plan=plan  at=@da  phase=?(%granting %opened %failed)
      acknowledged=(set ?(%baseline %member))  reason=(unit @tas)
  ==
+$  record-v2
  $:  plan=plan  at=@da  phase=phase
      acknowledged=(set ?(%baseline %member))  reason=(unit @tas)
      check=(unit @ux)  handoff=(unit [task=@ux handoff=@ux])
      label=@t
  ==
+$  record
  $:  plan=plan  at=@da  phase=phase
      acknowledged=(set ?(%baseline %member))  reason=(unit @tas)
      check=(unit @ux)  handoff=(unit [task=@ux handoff=@ux])
      label=@t  artifact=path
  ==
+$  state-v1  [%qpc-task-onboard-v1 records=(map @ux record-v1)]
+$  state-v2  [%qpc-task-onboard-v2 records=(map @ux record-v2)]
::  v3 (2026-11-01, GOAL 32/33): a queue of declared tasks. Enqueueing is the
::  operator's authorization. The owner takes one step per event (begin, arm,
::  activate), starts a task only when no queued record is unfinished and no
::  campaign runs, and halts on the first failure with its reason.
+$  state
  $:  %qpc-task-onboard-v3
      records=(map @ux record)
      queue=(list description)
      queued=(set @ux)
      halted=(unit [id=@ux reason=@tas])
  ==
++  empty  ^-(state [%qpc-task-onboard-v3 ~ ~ ~ ~])
++  migrate
  |=  old=state-v1
  ^-  state
  %-  migrate-v2
  :-  %qpc-task-onboard-v2
  %-  ~(run by records.old)
  |=  r=record-v1
  ^-  record-v2
  [plan.r at.r phase.r acknowledged.r reason.r ~ ~ 'migrated']
++  migrate-v2
  |=  old=state-v2
  ^-  state
  :*  %qpc-task-onboard-v3
      %-  ~(run by records.old)
      |=  r=record-v2
      ^-  record
      [plan.r at.r phase.r acknowledged.r reason.r check.r handoff.r label.r ~]
      ~  ~  ~
  ==
++  queue-limit  64
++  enqueue
  ::  Declared, not started: identity is the description itself.
  |=  [held=state d=description]
  ^-  (each state @tas)
  ?:  (lien queue.held |=(q=description =(q d)))  [%| %onboard-queue-duplicate]
  ?.  (lth (lent queue.held) queue-limit)  [%| %onboard-queue-capacity]
  [%& held(queue (snoc queue.held d))]
++  dequeue
  |=  held=state
  ^-  [(unit description) state]
  ?~  queue.held  [~ held]
  [`i.queue.held held(queue t.queue.held)]
++  record-limit  256
++  grant-limit  grant-capacity:tools
++  objective-limit  16.384
++  baseline-work  2.000.000
++  member-work  8.000.000
++  baseline-operations
  ^-  (set operation:nc)
  (silt `(list operation:nc)`~[%check %read])
++  member-operations
  ^-  (set operation:nc)
  (silt `(list operation:nc)`~[%diff %patch %read %search %replace %check %compile %list])
++  digest  |=(value=* ^-(@ux (shax (jam [%qpc-task-onboard-v1 value]))))
++  seed
  ::  The same description over the same registered project names the same
  ::  identities; a new nonce names fresh ones.
  |=  [our=@p old=project:nc d=description]
  ^-  @ux
  %-  shax
  %-  jam
  :*  %qpc-task-onboard-seed-v1  our  (configuration:project old)
      target.d  artifact.d  checks.d  objective.d  key.d  selection.d  nonce.d  task.d
  ==
++  identities-of
  |=  s=@ux
  ^-  identities
  :*  s
      (shax (jam [%baseline-session s]))
      (shax (jam [%baseline-grant s]))
      (shax (jam [%member-session s]))
      (shax (jam [%member-grant s]))
      (shax (jam [%campaign s]))
  ==
++  find-target
  |=  [p=project:nc name=@tas]
  ^-  (unit build-target:nc)
  =/  rows=(list build-target:nc)  targets.p
  |-
  ?~  rows  ~
  ?:  =(name name.i.rows)  `i.rows
  $(rows t.rows)
++  derive-project
  ::  The named target's checks change, and the artifact is the only writable
  ::  file: the project says so, and the source law refuses a writable import
  ::  (2026-11-01: writes left by earlier tasks refused `refused-json`, whose
  ::  artifact imports theirs). Everything else is the live project. A target the project never carried
  ::  is registered from the description (2026-11-01, GOAL 27): entry
  ::  `/lib/<target>/hoon`, a protected check library importing the artifact,
  ::  which is its sole dependency. One target serves one artifact; a task
  ::  brings its checks as expressions. Protection is judged by the caller.
  |=  [old=project:nc target=@tas artifact=path checks=(list [name=@tas expression=@t])]
  ^-  (each project:nc @tas)
  =/  names=(list @tas)  (turn checks |=([name=@tas expression=@t] name))
  ?.  ?&  (lien names |=(n=@tas =(%compatibility n)))
          (lien names |=(n=@tas =(%intended-behavior n)))
      ==
    [%| %onboard-checks-incomplete]
  ?.  !=(0 target)  [%| %onboard-target-missing]
  ?:  (~(has in protected.policy.old) artifact)  [%| %onboard-artifact-protected]
  ::  A target's intended check belongs to the task that set it, and that task
  ::  may never land. All targets must pass, so an unlanded task's check would
  ::  fail every later task on a file it may not write (2026-11-01: `refused-json`
  ::  graded on `++line-column` and `++time-span`). Other targets keep the rest.
  =/  others=(list build-target:nc)
    %+  turn  targets.old
    |=  t=build-target:nc
    t(checks (skip checks.t |=([name=@tas expression=@t] =(%intended-behavior name))))
  =/  scoped=project:nc  old(writable.policy (silt ~[artifact]), targets others)
  =/  next=project:nc
    ?~  (find-target scoped target)
      =/  entry=path  /lib/[target]/hoon
      =/  fresh=build-target:nc  [target %hoon entry ~[artifact] checks]
      %=  scoped
        targets  (snoc targets.scoped fresh)
        protected.policy  (~(put in protected.policy.scoped) entry)
        dependencies  (~(put by dependencies.scoped) entry ~[artifact])
      ==
    %=  scoped
      targets
        %+  turn  targets.scoped
        |=  t=build-target:nc
        ?.  =(target name.t)  t
        t(checks checks)
    ==
  ?.  (valid:project next)  [%| %onboard-project-invalid]
  [%& next]
++  derive-cases
  |=  t=build-target:nc
  ^-  cases:q
  :-  %qpc-hoon-cases-v1
  ~[[%compatibility t %compatibility] [%intended-behavior t %intended-behavior]]
++  judged-objective
  ::  The builder and the reviewer both read the objective, so the checks that
  ::  judge the work travel in it: neither party works blind (2026-11-01; the
  ::  reviewer of the first queued task reported the checker was not in its packet).
  |=  d=description
  ^-  @t
  %+  rap  3
  :-  objective.d
  :-  '\0a\0aThe native checks that judge this work. Each is compiled with the artifact as its subject and must return %.y; a crash or %.n fails. They are protected.'
  %+  turn  checks.d
  |=  [name=@tas expression=@t]
  (rap 3 ~['\0a\0aCheck %' name ':\0a' expression])
++  build
  ::  Everything the four stages used to carry, derived from one description.
  |=  [our=@p old=project:nc expected=revision:nc d=description]
  ^-  (each plan @tas)
  ?.  =(project.d id.spec.old)  [%| %onboard-project-mismatch]
  ?.  =(our authority.spec.old)  [%| %onboard-authority-required]
  =/  derived  (derive-project old target.d artifact.d checks.d)
  ?:  ?=(%| -.derived)  derived
  =/  next=project:nc  p.derived
  =/  found=(unit build-target:nc)  (find-target next target.d)
  ?~  found  [%| %onboard-target-missing]
  =/  cases=cases:q  (derive-cases u.found)
  ?.  (cases-valid:outcomes cases)  [%| %onboard-cases-invalid]
  ?.  (checks-protected:sensing next artifact.d cases)  [%| %onboard-checks-unprotected]
  =/  ids=identities  (identities-of (seed our old d))
  ::  Grants fit the project's own policy (2026-11-01): the wanted operations
  ::  are cut to what the policy allows, and the essentials must survive the
  ::  cut, else the refusal names the policy rather than the grant.
  =/  allowed=(set operation:nc)  operations.policy.next
  =/  baseline-ops=(set operation:nc)  (~(int in baseline-operations) allowed)
  =/  member-ops=(set operation:nc)  (~(int in member-operations) allowed)
  ?.  ?&  (~(has in baseline-ops) %check)  (~(has in baseline-ops) %read)
          (~(has in member-ops) %read)  (~(has in member-ops) %patch)
          (~(has in member-ops) %compile)  (~(has in member-ops) %check)
      ==
    [%| %onboard-policy-operations-insufficient]
  =/  baseline=grant:contract
    [baseline-grant.ids baseline.ids our next baseline-ops ~ baseline-work]
  =/  member=grant:contract
    [member-grant.ids member.ids our next member-ops ~ member-work]
  ?.  &((grant-valid:tools our baseline) (grant-valid:tools our member))
    [%| %onboard-grant-invalid]
  ?.  ?&  !=(0 key.d)  !=(0 objective.d)  !=(0 task.d)  (lte (met 3 task.d) 128)
          (lte (met 3 (judged-objective d)) objective-limit)
      ==
    [%| %onboard-opening-invalid]
  =/  open=opening
    [baseline.ids project.d (judged-objective d) selection.d key.d baseline-grant.ids our expected]
  [%& [%qpc-task-onboard-plan-v1 ids next cases baseline member open]]
++  admit
  ::  Prospective: nothing in the live ledgers already spends these identities.
  |=  $:  p=plan  ledger=organ:contract  local=(set @ux)
          sessions=(set @ux)  projects=(map @t project:nc)  held=state
      ==
  ^-  (unit @tas)
  =/  ids=identities  identities.p
  ?:  (~(has by records.held) seed.ids)  `%onboard-already-started
  ?.  (lth ~(wyt by records.held) record-limit)  `%onboard-capacity
  ?.  (~(has by projects) project.opening.p)  `%onboard-project-unregistered
  ?:  ?|  (~(has by grants.ledger) baseline-grant.ids)
          (~(has by grants.ledger) member-grant.ids)
      ==
    `%onboard-grant-exists
  ?.  (lte (add 2 ~(wyt by grants.ledger)) grant-limit)  `%onboard-grant-capacity
  ?.  ?&  =([~ ~] (spare:reservation ledger local baseline.ids))
          =([~ ~] (spare:reservation ledger local member.ids))
      ==
    `%onboard-session-spent
  ?:  |((~(has in sessions) baseline.ids) (~(has in sessions) member.ids))
    `%onboard-session-exists
  ~
++  start
  |=  [held=state p=plan at=@da label=@t artifact=path]
  ^-  state
  held(records (~(put by records.held) seed.identities.p [p at %granting ~ ~ ~ ~ label artifact]))
++  acknowledge
  ::  A grant acknowledgment is a trigger to re-read the ledger, not proof.
  |=  [held=state id=@ux which=?(%baseline %member)]
  ^-  (each [state=state complete=?] @tas)
  =/  found  (~(get by records.held) id)
  ?~  found  [%| %onboard-record-missing]
  ?.  =(%granting phase.u.found)  [%| %onboard-not-granting]
  =/  r=record  u.found(acknowledged (~(put in acknowledged.u.found) which))
  [%& [held(records (~(put by records.held) id r)) =(2 ~(wyt in acknowledged.r))]]
++  granted
  ::  Both grants are in the ledger exactly as planned and unrevoked.
  |=  [p=plan ledger=organ:contract]
  ^-  ?
  ?&  =(`[baseline.p ~] (~(get by grants.ledger) id.baseline.p))
      =(`[member.p ~] (~(get by grants.ledger) id.member.p))
  ==
++  opened
  |=  [held=state id=@ux]
  ^-  (each state @tas)
  =/  found  (~(get by records.held) id)
  ?~  found  [%| %onboard-record-missing]
  ?.  &(=(%granting phase.u.found) =(2 ~(wyt in acknowledged.u.found)))
    [%| %onboard-not-granted]
  [%& held(records (~(put by records.held) id u.found(phase %opened)))]
++  fail
  ::  A failure after the opening is impossible to express; the record stays.
  |=  [held=state id=@ux reason=@tas]
  ^-  state
  =/  found  (~(get by records.held) id)
  ?~  found  held
  ?:  ?=(?(%opened %activated) phase.u.found)  held
  held(records (~(put by records.held) id u.found(phase %failed, reason `reason)))
++  check-text
  |=  target=@tas
  ^-  @t
  (cat 3 '/check ' target)
++  check-command
  ::  The authenticated baseline check: the paused baseline session runs the
  ::  target's checks at the exact working revision (nonce from the seed).
  |=  [p=plan working=revision:nc]
  ^-  [%native-coding-action-v1 [%terminal-at id=@ux nonce=@ux source=@ux input=@t]]
  =/  ids=identities  identities.p
  :-  %native-coding-action-v1
  :*  %terminal-at  baseline.ids  (shax (jam [%terminal-nonce seed.ids]))
      (shax (jam working))  (check-text name.target:(snag 0 rows.cases.p))
  ==
++  next-command
  ::  The next campaign is the prior's command re-pointed at this plan's
  ::  identities, this baseline check and this working revision.
  |=  [previous=command:campaign p=plan check=@ux working=revision:nc objective=@t]
  ^-  command:campaign
  =/  ids=identities  identities.p
  %=  previous
    id  campaign.ids
    member  member.ids
    grant  member-grant.ids
    baseline  check
    expected  working
    objective  objective
  ==
++  next-plan
  |=  [previous=plan:instrument p=plan task=@t objective=@t artifact=path]
  ^-  plan:instrument
  %=  previous
    session  member.identities.p
    task  task
    objective  (digest:obs objective)
    cases  (digest:q cases.p)
    artifact  artifact
  ==
++  check-started
  |=  [held=state id=@ux key=@ux]
  ^-  (each state @tas)
  =/  found  (~(get by records.held) id)
  ?~  found  [%| %onboard-record-missing]
  ?.  =(%opened phase.u.found)  [%| %onboard-not-opened]
  [%& held(records (~(put by records.held) id u.found(phase %checking, check `key)))]
++  checked
  |=  [held=state id=@ux]
  ^-  (each state @tas)
  =/  found  (~(get by records.held) id)
  ?~  found  [%| %onboard-record-missing]
  ?.  &(=(%checking phase.u.found) ?=(^ check.u.found))  [%| %onboard-not-checking]
  [%& held(records (~(put by records.held) id u.found(phase %checked)))]
++  handing
  ::  The handoff command was accepted; its Graf retention is confirmed later.
  |=  [held=state id=@ux]
  ^-  (each state @tas)
  =/  found  (~(get by records.held) id)
  ?~  found  [%| %onboard-record-missing]
  ?.  =(%checked phase.u.found)  [%| %onboard-not-checked]
  [%& held(records (~(put by records.held) id u.found(phase %handing)))]
++  prepared
  |=  [held=state id=@ux task=@ux handoff=@ux]
  ^-  (each state @tas)
  =/  found  (~(get by records.held) id)
  ?~  found  [%| %onboard-record-missing]
  ?.  =(%handing phase.u.found)  [%| %onboard-not-handing]
  [%& held(records (~(put by records.held) id u.found(phase %prepared, handoff `[task handoff])))]
++  activated
  |=  [held=state id=@ux]
  ^-  (each state @tas)
  =/  found  (~(get by records.held) id)
  ?~  found  [%| %onboard-record-missing]
  ?.  &(=(%prepared phase.u.found) ?=(^ handoff.u.found))  [%| %onboard-not-prepared]
  [%& held(records (~(put by records.held) id u.found(phase %activated)))]
++  valid
  |=  [our=@p held=state]
  ^-  ?
  ?&  (lte ~(wyt by records.held) record-limit)
      (lte (lent queue.held) queue-limit)
      (levy ~(tap in queued.held) |=(id=@ux (~(has by records.held) id)))
      %+  levy  ~(tap by records.held)
      |=  [id=@ux r=record]
      ?&  =(id seed.identities.plan.r)
          =(identities.plan.r (identities-of id))
          =(our actor.baseline.plan.r)
          =(our actor.member.plan.r)
          =(our authority.spec.project.plan.r)
          ?-  phase.r
            %granting   ?=(~ reason.r)
            %opened     &(?=(~ reason.r) =(2 ~(wyt in acknowledged.r)))
            %checking   &(?=(~ reason.r) ?=(^ check.r))
            %checked    &(?=(~ reason.r) ?=(^ check.r))
            %handing    &(?=(~ reason.r) ?=(^ check.r))
            %prepared   &(?=(~ reason.r) ?=(^ check.r) ?=(^ handoff.r))
            %activated  &(?=(~ reason.r) ?=(^ check.r) ?=(^ handoff.r))
            %failed     ?=(^ reason.r)
          ==
      ==
  ==
--
