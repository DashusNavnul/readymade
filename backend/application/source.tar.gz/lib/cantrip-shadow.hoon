::  /lib/cantrip-shadow.hoon
::
::  The shadow judge.  Beside every lane judge, geometry judges the same
::  act against the lane's type-law (/lib/flect-law), and both verdicts
::  are kept together as a shadow.  Nothing here changes what a lane
::  decides; it measures.
::
::  The law the shadow must never break: what a lane judge admitted fits
::  its type-law.  A type-law is necessary, not sufficient (it cannot see
::  a foreign actor or an unchanged source), so a refusal that fits is
::  fine and an admission that misses is not.  +sound says so for one
::  shadow, +agreement counts over many; the count must equal the total
::  before any lane is cut over to geometry (phases 9-11).
::
/+  flect, flect-law
|%
+$  shadow
  $:  lane=@tas
      act=flect:flect                       ::  the act noun's tag
      =receipt:flect-law                    ::  the act against the lane's type-law
      old=?                                 ::  the lane judge admitted it
      why=@tas                              ::  its reason, %admitted when it did
  ==
++  shadow-of
  |=  [lane=@tas law=law:flect-law act=vase old=(each * @tas)]
  ^-  shadow
  (shadow-with lane law act ~ old)
::  +shadow-with: the same, with an environment for the laws that compute
++  shadow-with
  |=  [lane=@tas law=law:flect-law act=vase env=* old=(each * @tas)]
  ^-  shadow
  :*  lane
      (tag:flect q.act)
      (judge-with:flect-law law act env)
      ?=(%& -.old)
      ?-(-.old %& %admitted, %| p.old)
  ==
::  +sound: geometry never contradicts the judge
++  sound
  |=  s=shadow
  ^-  ?
  ?|(!old.s fit.verdict.receipt.s)
::  +agreement: how many shadows are sound, of how many
++  agreement
  |=  ss=(list shadow)
  ^-  [sound=@ud total=@ud]
  [(lent (skim ss sound)) (lent ss)]
::  +fact: the shadow as an append-only graf fact, %cantrip-receipt, keyed by
::  the lane and the act's tag; the agent attests it beside the verdict
++  fact
  |=  s=shadow
  ^-  [%cantrip-receipt id=@t body=shadow]
  [%cantrip-receipt (scot %uv (sham [lane.s act.s])) s]
--
