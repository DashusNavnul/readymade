::  /lib/nick-medium.hoon -- SAFETY AS A THEOREM. The sealed code medium.
::
::  RED-TEAM HARDENED (2026-07-06). The first cut slapped the granted core
::  against the agent's full subject (!>(.)), which leaked zuse's ream/slap
::  (metaprogramming escape) and the catalog itself (capability-source
::  reconstruction). A live red-team broke it: (slap !>(~) (ream '...')) ran
::  arbitrary code; (~(got by catalog) %write) extracted an ungranted arm.
::
::  The seal: the granted core is built against the EMPTY subject (!>(~)), and
::  the capability arms are pure REQUEST CONSTRUCTORS that need no stdlib. So the
::  model's code can reach ONLY the granted arm names -- ream, slap, catalog,
::  add, and every ungranted capability are all -find (not in an empty-based
::  core). The medium is for INVOKING capabilities, not general computation;
::  there is nothing else to reach.
::
::  A request is data, though, and the model can always CONSTRUCT the tuple
::  [%cap %write ...] literally (cell-cons is a Nock primitive). So the
::  expressibility seal is necessary but NOT sufficient: the executor (cortex)
::  must also gate -- run the effect ONLY for a capability in the grant. The
::  theorem removes the easy path (naming/calling an ungranted arm); the
::  execution gate closes the forge-the-data path. Both are required.
::
/+  code-medium
|%
+$  gate  @tas
+$  request  [%cap cap=@tas arg=@t]            ::  what a granted arm produces
::  the catalog: gate -> arm SOURCE. Each arm is a pure request constructor --
::  no stdlib, so the whole granted core compiles against the EMPTY subject.
++  catalog
  ^-  (map gate @t)
  %-  malt
  ^-  (list [gate @t])
  :~  [%recall '++  recall  |=(t=@t [%cap %recall t])']
      [%read-canon '++  read-canon  |=(t=@t [%cap %read-canon t])']
      [%search '++  search  |=(t=@t [%cap %search t])']
      [%traverse '++  traverse  |=(t=@t [%cap %traverse t])']
      [%write '++  write  |=(t=@t [%cap %write t])']
      [%implement '++  implement  |=(t=@t [%cap %implement t])']
      [%promote '++  promote  |=(t=@t [%cap %promote t])']
      [%host '++  host  |=(t=@t [%cap %host t])']
      ::  de-reference a veiled handle (lib/veil). The arg is a handle; the
      ::  executor holds the sealed refs and performs reveal:veil ONLY under a
      ::  %reveal grant. Ungranted, `reveal` is -find -- the model cannot even
      ::  NAME the act that would reintroduce a sensitive value it never saw.
      [%reveal '++  reveal  |=(t=@t [%cap %reveal t])']
  ==
::  build a subject from ONLY the granted gates, on the EMPTY base. Ungranted
::  gates, the catalog, and all metaprogramming are absent and unnameable.
++  subject-for
  |=  gates=(set gate)
  ^-  vase
  =/  arms=(list @t)
    %+  murn  ~(tap in gates)
    |=(g=gate (~(get by catalog) g))
  =/  body=@t  (roll arms |=([a=@t acc=@t] (rap 3 ~[acc '  ' a])))
  =/  src=@t   (rap 3 ~['=<  .  |%  ' body '  --'])
  (slap !>(~) (ream src))
::  first-line DoS guard. The red-team's escape is sealed, but eval can still be
::  hung by a bare recursion trap (|-  $). The capability medium needs only
::  simple (cap arg) calls, so reject the recursion runes and cap the length.
::  This is NOT true step-metering -- a determined loop can still be constructed
::  through other runes; runtime fuel (a mink-based metered interpreter) is the
::  real fix, scoped but not built. This closes the trivial hang.
++  loop-safe
  |=  src=@t
  ^-  ?
  =/  tp=tape  (trip src)
  ?&  (lte (met 3 src) 256)
      ?=(~ (find "|-" tp))
      ?=(~ (find "|." tp))
  ==
++  run-in-circle
  |=  [gates=(set gate) src=@t]
  ^-  outcome:code-medium
  ?.  (loop-safe src)
    [%| 'refused: source exceeds the capability medium (loop/length guard)']
  (run:code-medium (subject-for gates) src)
++  reached  reached:code-medium
--
