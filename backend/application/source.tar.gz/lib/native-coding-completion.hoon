::  Pure evidence for an explicit owner judgment of unchanged work. The caller
::  supplies fresh canonical journals and source reads; hashes do not prove
::  their origin. This neither invokes a model nor replaces candidate review.
/-  nc=native-coding
/+  session=native-coding-session, project=native-coding-project,
    tools=cantrip-native-coding, accept=native-coding-accept
|%
+$  snapshot
  $:  entry=entry:session  project=project:nc  current=revision:nc
      accepted-source=revision:nc  grant=@ux  assignment=(unit @ux)
      tools=organ:tools  pending=(map @ux tool-request:nc)
      candidates=(map @ux candidate:nc)  accepted=ledger:accept
  ==
+$  evidence  [record=@ux tool=@ux result=@ux]
+$  proposal
  $:  %native-coding-completion-proposal-v1
      session=@ux
      project=@t
      configuration=@ux
      source=revision:nc
      accepted=revision:nc
      grant=@ux
      assignment=(unit @ux)
      objective=@t
      latest=@ux
      head=@ux
      sequence=@ud
      model=@ux
      snapshot=@ux
      evidence=(list evidence)
  ==
+$  decision
  [%native-coding-completion-decision-v1 proposal=proposal verdict=%complete reason=@t]
++  evidence-limit  128
++  digest
  |=  value=*
  ^-  @ux
  (shax (jam [%native-coding-completion-v1 value]))
++  identifier
  |=  value=@ux
  ^-  ?
  &(!=(0 value) (lte (met 0 value) 256))
++  text-valid
  |=  [value=@t limit=@ud]
  ^-  ?
  &(!=(0 value) (lte (met 3 value) limit))
++  same-desk
  |=  [a=revision:nc b=revision:nc]
  ^-  ?
  &(=(owner.a owner.b) =(desk.a desk.b))
++  journal-valid
  |=  e=entry:session
  ^-  ?
  ?.  &(?=(^ records.e) (lte (lent records.e) journal-limit:session))  %.n
  =/  rows=(list record:session)  records.e
  =/  sequence=@ud  0
  =/  previous=(unit @ux)  ~
  =/  at=@da  *@da
  |-  ^-  ?
  =/  todo=(list record:session)  rows
  ?~  todo  &(=(sequence sequence.e) =(previous head.e))
  =/  r=record:session  i.todo
  ?.  ?&  =(sequence sequence.r)  =(previous previous.r)  (gte at.r at)
          =(id.r (event-id:session id.session.e sequence previous at.r body.r))
      ==  %.n
  $(rows t.todo, sequence +(sequence), previous `id.r, at at.r)
++  objective
  |=  e=entry:session
  ^-  (each [text=@t latest=record:session] @tas)
  =/  rows=(list record:session)  records.e
  =/  text=@t  ''
  =/  latest=(unit record:session)  ~
  |-  ^-  (each [text=@t latest=record:session] @tas)
  =/  todo=(list record:session)  rows
  ?~  todo
    ?~  latest  [%| %completion-objective-missing]
    [%& [text u.latest]]
  ?.  ?=(%operator -.body.i.todo)  $(rows t.todo)
  ?.  (text-valid text.body.i.todo 65.536)  [%| %completion-objective-invalid]
  =/  next=@t  (cat 3 text (cat 3 text.body.i.todo '\0a'))
  ?.  (lte (met 3 next) 65.536)  [%| %completion-objective-capacity]
  $(rows t.todo, text next, latest `i.todo)
++  successful
  ::  %finished alone is insufficient: unchecked or failed diagnostics do not
  ::  qualify. Job-control observations and mutations are not work evidence.
  |=  [r=tool-request:nc out=tool-output:nc]
  ^-  ?
  ?+  -.arguments.r  %.n
    %list  ?=(%list -.out)
    %read  ?=(%read -.out)
    %search  ?=(%search -.out)
    %diff  ?=(%diff -.out)
    ?(%compile %check %eval %inspect)
      ?.  ?=(%diagnostics -.out)  %.n
      ?&  !=(~ values.out)  (lte (lent values.out) 64)
          (levy values.out |=(d=diagnostic:nc &(passed.d =(source.context.r source.d))))
      ==
  ==
++  context-matches
  |=  [e=entry:session c=context:nc]
  ^-  ?
  ?&  =(id.session.e session.c)  =(project.session.e project.c)
      =(configuration.e configuration.c)  =(owner.session.e actor.c)
      =(working.session.e source.c)  (identifier request.c)
  ==
++  joined
  ::  Join a journal result to the exact retained admission and historical
  ::  grant. Later revocation does not erase an already completed read.
  |=  [our=@p e=entry:session p=project:nc held=organ:tools latest=record:session r=record:session]
  ^-  (unit [tool=@ux proof=@ux])
  ?.  ?=(%tool -.body.r)  ~
  =/  result=tool-result:nc  result.body.r
  ?.  (context-matches e context.result)  ~
  =/  matches=(list [@ux record:tools])
    (skim ~(tap by records.held) |=([id=@ux job=record:tools] &(=(context.result context.request.job) =(call-id.result call-id.request.job))))
  ?~  matches  ~
  ?.  ?=(~ t.matches)  ~
  =/  id=@ux  -.i.matches
  =/  job=record:tools  +.i.matches
  ?.  ?&  =(id (key:tools request.job))  =(%finished stage.job)
          =(`result result.job)  (gth at.job at.latest)  (lte at.job at.r)
          (successful request.job output.result)
      ==  ~
  =/  grant  (~(get by grants.held) grant.job)
  ?~  grant  ~
  =/  g=grant:tools  grant.u.grant
  ?.  ?&  (grant-valid:tools our g)  =(id.g grant.job)  =(p project.g)
          =(id.session.e session.g)  =(owner.session.e actor.g)
          (~(has in operations.g) -.arguments.request.job)
      ==  ~
  ::  Admission must be strictly later than the instruction, not merely an
  ::  old in-flight job's eventual callback. This also admits direct tools.
  `[id (digest [id job grant.u.grant])]
++  candidate-pending
  |=  [e=entry:session c=candidate:nc rows=ledger:accept]
  ^-  ?
  ?.  |(=(id.session.e session.context.c) (same-desk working.session.e source.context.c))  %.n
  =/  found  (~(get by rows) id.c)
  ?~  found  %.y
  ?.  =(c candidate.u.found)  %.y
  ?.  ?=(?(%applied %refused) stage.u.found)  %.y
  ?.  =(id.session.e session.context.c)  %.n
  ::  A terminal Cantrip row whose callback Viki has not consumed is still
  ::  pending judgment here. Preserve the existing instruction-ready rule.
  =/  receipt=@ux  (digest:accept u.found)
  !(lien records.e |=(r=record:session ?.(?=(%judgment -.body.r) %.n &(=(%continue verdict.body.r) (~(has in (silt evidence.body.r)) receipt)))))
++  quiescent
  |=  [e=entry:session pending=(map @ux tool-request:nc) candidates=(map @ux candidate:nc) accepted=ledger:accept held=organ:tools]
  ^-  ?
  ?&  (lte ~(wyt by pending) 2.048)  (lte ~(wyt by candidates) capacity:accept)
      (lte ~(wyt by accepted) capacity:accept)  (lte ~(wyt by records.held) capacity:tools)
      (lte ~(wyt by grants.held) grant-capacity:tools)
      !(lien ~(val by pending) |=(r=tool-request:nc |(=(id.session.e session.context.r) (same-desk working.session.e source.context.r))))
      !(lien ~(val by records.held) |=(r=record:tools &(|(=(id.session.e session.context.request.r) (same-desk working.session.e source.context.request.r)) ?=(?(%running %unknown) stage.r))))
      !(lien ~(val by candidates) |=(c=candidate:nc (candidate-pending e c accepted)))
      !(lien ~(val by accepted) |=(r=record:accept (candidate-pending e candidate.r accepted)))
  ==
++  proposal-valid
  |=  p=proposal
  ^-  ?
  ?&  (identifier session.p)  (identifier configuration.p)
      (identifier grant.p)  ?~(assignment.p %.y (identifier u.assignment.p))
      (text-valid project.p 128)  (text-valid objective.p 65.536)
      (revision-valid:project source.p)  (revision-valid:project accepted.p)
      =(owner.source.p owner.accepted.p)  !=(desk.source.p desk.accepted.p)
      (identifier latest.p)  (identifier head.p)  (identifier model.p)
      (identifier snapshot.p)  (gte sequence.p 1)  (lte sequence.p journal-limit:session)
      (gte (lent evidence.p) 1)  (lte (lent evidence.p) evidence-limit)
      (levy evidence.p |=([record=@ux tool=@ux result=@ux] &((identifier record) (identifier tool) (identifier result))))
      =((lent evidence.p) ~(wyt in (silt (turn evidence.p |=([record=@ux tool=@ux result=@ux] tool)))))
  ==
++  decision-valid
  |=  d=decision
  ^-  ?
  &(=(%complete verdict.d) (proposal-valid proposal.d) (text-valid reason.d 8.192))
++  prepare
  |=  [our=@p s=snapshot]
  ^-  (each proposal @tas)
  =/  e=entry:session  entry.s
  ?.  ?&  =(our owner.session.e)  =(our authority.spec.project.s)
          (valid:project project.s)  =(project.session.e id.spec.project.s)
          =((configuration:project project.s) configuration.e)
          =(current.s working.session.e)  =(working.project.s desk.current.s)
          =(our owner.current.s)  (revision-valid:project current.s)
          =(our owner.accepted-source.s)
          =(base-desk.spec.project.s desk.accepted-source.s)
          (revision-valid:project accepted-source.s)
      ==  [%| %completion-source-mismatch]
  ?.  (journal-valid e)  [%| %completion-journal-invalid]
  ?~  records.e  [%| %completion-journal-invalid]
  ?~  head.e  [%| %completion-journal-invalid]
  ?.  &(?=(%operator -.body.i.records.e) =(objective.session.e text.body.i.records.e))  [%| %completion-journal-invalid]
  ?.  &(=(phase.e %judgment) =(resume.e %judgment) ?=(~ pending.e) ?=(~ calls.e))
    [%| %completion-not-quiescent]
  ?.  (quiescent e pending.s candidates.s accepted.s tools.s)
    [%| %completion-work-unresolved]
  =/  scope  (~(get by grants.tools.s) grant.s)
  ?~  scope  [%| %completion-standing-grant-missing]
  =/  g=grant:tools  grant.u.scope
  ?.  ?&  (grant-valid:tools our g)  =(grant.s id.g)  ?=(~ revoked.u.scope)
          =(project.s project.g)  =(id.session.e session.g)  =(our actor.g)
      ==  [%| %completion-standing-grant-invalid]
  =/  goal  (objective e)
  ?:  ?=(%| -.goal)  [%| p.goal]
  =/  latest=record:session  latest.p.goal
  =/  recent=(list record:session)  (slag +(sequence.latest) `(list record:session)`records.e)
  ?:  (lien recent |=(r=record:session &(?=(%tool -.body.r) ?=(%candidate -.output.result.body.r))))
    [%| %completion-candidate-path]
  =/  models=(list record:session)
    (skim recent |=(r=record:session ?=(%model -.body.r)))
  ?~  models  [%| %completion-model-turn-missing]
  =/  model=record:session  (rear `(list record:session)`models)
  ?>  ?=(%model -.body.model)
  ?.  ?&  (gth turn.e 0)  ?=(~ calls.result.body.model)
          =(id.result.body.model (request-id:session id.session.e (dec turn.e)))
          !(lien recent |=(r=record:session &((gth sequence.r sequence.model) ?=(?(%tool %operator) -.body.r))))
      ==  [%| %completion-model-tools-unresolved]
  =/  items=(list evidence)  ~
  =/  proofs=(list @ux)  ~
  |-  ^-  (each proposal @tas)
  =/  rows=(list record:session)  recent
  ?~  rows
    =/  commitment=@ux
      (digest [e project.s current.s accepted-source.s u.scope assignment.s (flop proofs)])
    =/  p=proposal
      [%native-coding-completion-proposal-v1 id.session.e project.session.e configuration.e current.s accepted-source.s grant.s assignment.s text.p.goal id.latest u.head.e sequence.e id.model commitment (flop items)]
    ?:((proposal-valid p) [%& p] [%| %completion-success-evidence-required])
  =/  r=record:session  i.rows
  =/  found  (joined our e project.s tools.s latest r)
  ?~  found  $(recent t.rows)
  ?:  (gte (lent items) evidence-limit)  [%| %completion-evidence-capacity]
  ?>  ?=(%tool -.body.r)
  =/  row=evidence  [id.r tool.u.found (digest result.body.r)]
  $(recent t.rows, items [row items], proofs [proof.u.found proofs])
++  decide
  ::  The full explicit decision must be retained by Viki with this resulting
  ::  journal record. The record commits it; no self-hash is owner consent.
  |=  [our=@p actor=@p at=@da s=snapshot d=decision]
  ^-  (each transition:session @tas)
  ?.  &(=(our actor) (decision-valid d))  [%| %completion-owner-decision-required]
  =/  current  (prepare our s)
  ?:  ?=(%| -.current)  [%| p.current]
  ?.  =(p.current proposal.d)  [%| %completion-decision-stale]
  ?~  records.entry.s  [%| %completion-journal-invalid]
  =/  last=record:session  (rear `(list record:session)`records.entry.s)
  ?.  (gte at at.last)  [%| %completion-decision-time-invalid]
  (judge:session at entry.s verdict.d ~[(digest d)] reason.d)
--
