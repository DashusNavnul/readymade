::  Pure owner command admission and immutable initial Bench receipts.
/-  ss=seat-session
/+  store=pataphor-chat-store, h=readymade-history
|%
+$  command
  $:  %readymade-bench-command-v1
      id=@uv  nonce=@uv  seat=@tas  text=@t
  ==
+$  receipt
  $:  %readymade-bench-receipt-v1
      id=@uv  at=@da  outcome=?(%accepted %refused)
      reason=(unit @t)  execution=(unit [seat=@tas request=@t])
  ==
+$  stored  [digest=@ux reply=receipt]
+$  ledger  (map @uv stored)
+$  decision
  $%  [%replay record=stored]
      [%run command=command]
      [%refuse reason=@t]
  ==
++  capacity  1.024
++  seats
  ^-  (list @tas)
  ~[%flunky %busboy %policeman %gendarme %undertaker %priest %delivery-boy %cuirassier %stationmaster]
++  seat-valid
  |=  name=@tas
  ^-  ?
  ?=(^ ((soft ,seat:ss) name))
++  token-valid
  |=  value=@uv
  ^-  ?
  &((gth value 0) (lte (met 0 value) 128))
++  trim
  |=  text=@t
  ^-  @t
  (trim:store text)
++  text-valid
  |=  text=@t
  ^-  ?
  ?.  (lte (met 3 text) 8.192)  %.n
  =/  request=@t  (trim text)
  &((gth (met 3 request) 0) (lte (met 3 request) 4.096))
++  request-valid
  |=  request=@t
  ^-  ?
  &((gth (met 3 request) 0) (lte (met 3 request) 256))
++  digest
  |=  cmd=command
  ^-  @ux
  `@ux`(shax (jam cmd))
++  admit
  |=  [our=@p src=@p cmd=command nonce=@uv receipts=ledger]
  ^-  decision
  ?.  =(our src)  [%refuse 'Only the owner ship may submit.']
  ?.  (token-valid id.cmd)
    [%refuse 'Submission id must be a nonzero 128-bit value.']
  ?.  (token-valid nonce.cmd)  [%refuse 'Invalid submission nonce.']
  ?.  (lte (met 3 text.cmd) 8.192)
    [%refuse 'Submission exceeds 8192 bytes.']
  =/  known=(unit stored)  (~(get by receipts) id.cmd)
  ?^  known
    ?.  =(digest.u.known (digest cmd))
      [%refuse 'Submission id was reused with a different command.']
    [%replay u.known]
  ?.  &((token-valid nonce) =(nonce nonce.cmd))
    [%refuse 'Invalid form. Reload before submitting again.']
  ?.  (seat-valid seat.cmd)  [%refuse 'Choose a known Bachelor seat.']
  ?.  (text-valid text.cmd)
    [%refuse 'Write a request of at most 4096 bytes.']
  ?:  (gte ~(wyt by receipts) capacity)
    [%refuse 'Submission receipt storage is full. Nothing was evicted.']
  [%run cmd]
++  refused
  |=  [now=@da cmd=command reason=@t]
  ^-  stored
  =/  clipped=text:h  (bounded:h reason 512)
  [(digest cmd) [%readymade-bench-receipt-v1 id.cmd now %refused `body.clipped ~]]
++  accepted
  ::  Observed native flight metadata, never a reconstructed request id.
  |=  [our=@p now=@da cmd=command observed=(unit [seat=@tas request=@t speaker=@p text=@t])]
  ^-  stored
  =/  why=@t  'No matching initial native Bench allocation was observed.'
  ?.  ?&  (token-valid id.cmd)  (token-valid nonce.cmd)
          (seat-valid seat.cmd)  (text-valid text.cmd)
      ==  (refused now cmd why)
  ?~  observed  (refused now cmd why)
  ?.  ?&  =(seat.cmd seat.u.observed)
          =(our speaker.u.observed)
          =((trim text.cmd) text.u.observed)
          (request-valid request.u.observed)
      ==  (refused now cmd why)
  [(digest cmd) [%readymade-bench-receipt-v1 id.cmd now %accepted ~ `[seat.u.observed request.u.observed]]]
++  valid-record
  |=  [key=@uv record=stored]
  ^-  ?
  ?.  ?&  (token-valid key)  =(key id.reply.record)
          (lte (met 0 digest.record) 256)
          ?~(reason.reply.record %.y (lte (met 3 u.reason.reply.record) 512))
      ==  %.n
  ?:  =(%refused outcome.reply.record)
    &(?=(^ reason.reply.record) =(~ execution.reply.record))
  ?.  =(~ reason.reply.record)  %.n
  ?~  execution.reply.record  %.n
  &((seat-valid seat.u.execution.reply.record) (request-valid request.u.execution.reply.record))
++  valid-ledger
  |=  receipts=ledger
  ^-  ?
  &((lte ~(wyt by receipts) capacity) (levy ~(tap by receipts) valid-record))
++  remember
  |=  [receipts=ledger record=stored]
  ^-  ledger
  ?>  (valid-record id.reply.record record)
  ?>  !(~(has by receipts) id.reply.record)
  ?>  (lth ~(wyt by receipts) capacity)
  (~(put by receipts) id.reply.record record)
++  restore
  ::  Whole Bench saved-state migration remains with the owning agent.
  |=  old=vase
  ^-  (unit ledger)
  =/  saved
    ((soft ,[%readymade-bench-ledger-v1 receipts=ledger]) q.old)
  ?~  saved  ~
  ?.  (valid-ledger receipts.u.saved)  ~
  `receipts.u.saved
--
