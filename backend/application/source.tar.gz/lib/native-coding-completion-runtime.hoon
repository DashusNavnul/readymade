::  Viki owns explicit completion receipts. Native reads establish the proposal;
::  a supplied digest, model answer, or HTTP response never establishes consent.
::  Loading validates immutable journal joins without scries or replayed effects.
/-  nc=native-coding, nf=native-coding-fleet
/+  kernel=native-coding-completion, session=native-coding-session,
    loop=native-coding-loop, project=native-coding-project,
    scoped=native-coding-session-project, tools=cantrip-native-coding,
    accept=native-coding-accept, fleet=native-coding-fleet-runtime,
    guard=viki-scry-guard
|%
+$  receipt  [decision=decision:kernel judgment=@ux]
+$  state  (map @ux receipt)
+$  command  [%native-coding-completion-decide-v1 decision=decision:kernel]
+$  change  [state=state coding=state:loop cards=(list card:agent:gall)]
++  key
  |=  d=decision:kernel
  ^-  @ux
  (digest:kernel d)
++  notice
  |=  r=receipt
  ^-  card:agent:gall
  [%give %fact ~[/native-coding] %noun !>([%native-coding-completion-retained-v1 (key decision.r) r])]
++  assignment
  ::  The digest commits the complete existing assignment, not a readiness bit.
  |=  [our=@p coding=state:loop e=entry:session accepted=revision:nc]
  ^-  (each (unit @ux) @tas)
  =/  found  (assigned:fleet fleet.coding id.session.e)
  ?:  =(our worker.e)
    ?~(found [%& ~] [%| %completion-local-assignment-conflict])
  ?~  found  [%| %completion-assignment-missing]
  =/  row=entry:nf  u.found
  ?~  assignment.row  [%| %completion-assignment-missing]
  =/  a=assignment:nf  u.assignment.row
  =/  selected  (~(get by placements.fleet.coding) id.session.e)
  ?~  selected  [%| %completion-placement-missing]
  ?.  &((placement-valid:fleet our u.selected) =(route-value.a route.u.selected) =(generation.a generation.config.u.selected) =(selection.e selection.config.u.selected))
    [%| %completion-placement-changed]
  ?.  ?&  =(%review phase.row)  !released.row
          =(id.task.row task.a)  =(context.task.row context.a)
          =(id.session.e session.context.a)  =(our actor.context.a)
          =(worker.e worker.a)  =(project.session.e project.context.a)
          =(configuration.e configuration.context.a)
          (same-desk:kernel working.session.e source.context.a)
          (gte number.working.session.e number.source.context.a)
          =(accepted accepted.task.row)
      ==  [%| %completion-assignment-mismatch]
  [%& `(digest:kernel a)]
++  read
  ::  Read only bounded canonical organs. All related candidate IDs originate
  ::  in Viki's journal or Cantrip's retained results, never in owner JSON.
  |=  [b=bowl:gall coding=state:loop id=@ux]
  ^-  (each snapshot:kernel @tas)
  ?.  =(our.b src.b)  [%| %completion-owner-required]
  =/  found  (~(get by sessions.coding) id)
  ?~  found  [%| %completion-session-missing]
  =/  e=entry:session  u.found
  ?.  =(our.b owner.session.e)  [%| %completion-owner-required]
  =/  selected  (resolve:scoped our.b now.b projects.coding id project.session.e)
  ?:  ?=(%| -.selected)  [%| p.selected]
  =/  p=project:nc  p.selected
  =/  catalog  (catalog:project our.b now.b p)
  ?:  ?=(%| -.catalog)  [%| p.catalog]
  ?.  (lien `(list operation:nc)`~[%list %read %search %diff %compile %check %eval %inspect] |=(op=operation:nc (member:project p p.catalog our.b op)))
    [%| %completion-project-access]
  =/  current  (current:project our.b now.b p)
  ?:  ?=(%| -.current)  [%| p.current]
  =/  binding  (~(get by bindings.coding) id)
  ?~  binding  [%| %completion-grant-binding-missing]
  ?.  (agent-live:guard our.b now.b %cantrip)  [%| %completion-cantrip-unavailable]
  =/  held=organ:tools
    .^(organ:tools %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/tool-state/noun)
  ?.  (valid:tools our.b held)  [%| %completion-tool-state-invalid]
  =/  bound
    (assignment our.b coding e revision.accepted.p.current)
  ?:  ?=(%| -.bound)  [%| p.bound]
  =/  known=(map @ux candidate:nc)  candidates.coding
  =/  jobs=(list record:tools)  ~(val by records.held)
  =/  merged=(each (map @ux candidate:nc) @tas)
    |-  ^-  (each (map @ux candidate:nc) @tas)
    ?~  jobs  [%& known]
    =/  result  result.i.jobs
    ?~  result  $(jobs t.jobs)
    ?.  ?=(%candidate -.output.u.result)  $(jobs t.jobs)
    =/  c=candidate:nc  value.output.u.result
    ?.  (same-desk:kernel working.session.e source.context.c)  $(jobs t.jobs)
    =/  old  (~(get by known) id.c)
    ?:  ?~(old %.n !=(u.old c))  [%| %completion-candidate-conflict]
    $(jobs t.jobs, known (~(put by known) id.c c))
  ?:  ?=(%| -.merged)  [%| p.merged]
  =.  known  p.merged
  ?:  (gth ~(wyt by known) 128)  [%| %completion-candidate-capacity]
  =/  rows=(list candidate:nc)  ~(val by known)
  =/  accepted=ledger:accept  ~
  =/  accepted=ledger:accept
    |-  ^-  ledger:accept
    ?~  rows  accepted
    =/  c=candidate:nc  i.rows
    ?.  (same-desk:kernel working.session.e source.context.c)  $(rows t.rows)
    =/  value=(unit record:accept)
      .^((unit record:accept) %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/candidate/(scot %ux id.c)/noun)
    ?~  value  $(rows t.rows)
    $(rows t.rows, accepted (~(put by accepted) id.c u.value))
  [%& [e p revision.working.p.current revision.accepted.p.current grant.u.binding p.bound held pending.coding known accepted]]
++  prepare
  |=  [b=bowl:gall coding=state:loop id=@ux]
  ^-  (each proposal:kernel @tas)
  =/  snapshot  (read b coding id)
  ?:  ?=(%| -.snapshot)  [%| p.snapshot]
  (prepare:kernel our.b p.snapshot)
++  row-valid
  ::  Historical consistency only. Later instructions/source/provider changes
  ::  need not erase a valid prior receipt. Fresh authority is checked by inspect.
  |=  [our=@p coding=state:loop id=@ux r=receipt]
  ^-  ?
  ?.  &((decision-valid:kernel decision.r) =(id (key decision.r)) (identifier:kernel judgment.r))  %.n
  =/  p=proposal:kernel  proposal.decision.r
  =/  found  (~(get by sessions.coding) session.p)
  ?~  found  %.n
  =/  e=entry:session  u.found
  ?.  &(=(our owner.session.e) =(our owner.source.p) =(project.p project.session.e) (journal-valid:kernel e) (lth sequence.p (lent records.e)))  %.n
  =/  j=record:session  (snag sequence.p records.e)
  ?.  ?&  =(judgment.r id.j)  =(previous.j `head.p)
          =(body.j [%judgment verdict.decision.r ~[id] reason.decision.r])
      ==  %.n
  =/  previous=entry:session
    e(records (scag sequence.p records.e), sequence sequence.p, head `head.p)
  =/  goal  (objective:kernel previous)
  ?:  ?=(%| -.goal)  %.n
  ?.  &(=(objective.p text.p.goal) =(latest.p id.latest.p.goal))  %.n
  =/  models=(list record:session)
    (skim records.previous |=(v=record:session ?=(%model -.body.v)))
  ?~  models  %.n
  =/  model=record:session  (rear models)
  ?.  =(model.p id.model)  %.n
  %+  levy  evidence.p
  |=  proof=evidence:kernel
  %+  lien  records.previous
  |=  v=record:session
  ?&  =(record.proof id.v)  ?=(%tool -.body.v)
      =(result.proof (digest:kernel result.body.v))
  ==
++  valid
  |=  [our=@p s=state coding=state:loop]
  ^-  ?
  &((lte ~(wyt by s) 128) (levy ~(tap by s) |=([id=@ux r=receipt] (row-valid our coding id r))))
++  selected
  ::  Only selection, never validity: a matching malformed receipt must reach
  ::  inspect and refuse, rather than falling back to candidate completion.
  |=  [s=state e=entry:session]
  ^-  (unit @ux)
  =/  rows=(list record:session)
    (flop (skim records.e |=(r=record:session ?=(%judgment -.body.r))))
  ?~  rows  ~
  =/  r=record:session  i.rows
  ?>  ?=(%judgment -.body.r)
  ?~  evidence.body.r  ~
  =/  id=@ux  i.evidence.body.r
  ?:((~(has by s) id) `id ~)
++  inspect
  ::  Current complete receipt only, used before native fleet release. Undo
  ::  precisely session.judge's one append; never guess a later changed state.
  |=  [b=bowl:gall s=state coding=state:loop id=@ux]
  ^-  (each [key=@ux receipt=receipt] @tas)
  ?.  &(=(our.b src.b) (agent-live:guard our.b now.b %viki))
    [%| %completion-owner-or-viki-unavailable]
  =/  found  (~(get by sessions.coding) id)
  ?~  found  [%| %completion-session-missing]
  =/  e=entry:session  u.found
  =/  actual=(unit public-session:loop)
    .^((unit public-session:loop) %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/session/(scot %ux id)/noun)
  ?.  =(actual `(public:loop e))  [%| %completion-session-not-retained]
  =/  chosen  (selected s e)
  ?~  chosen  [%| %completion-receipt-missing]
  =/  r=receipt  (~(got by s) u.chosen)
  =/  retained=(unit receipt)
    .^((unit receipt) %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/completion/(scot %ux u.chosen)/noun)
  ?.  =(`r retained)  [%| %completion-receipt-not-retained]
  ?.  (row-valid our.b coding u.chosen r)  [%| %completion-receipt-invalid]
  =/  p=proposal:kernel  proposal.decision.r
  ?.  ?&  =(%complete verdict.decision.r)  =(%complete phase.e)
          =(%complete resume.e)  =(head.e `judgment.r)
          =(sequence.e +(sequence.p))  ?=(~ pending.e)  ?=(~ calls.e)
      ==  [%| %completion-not-current]
  =/  previous=entry:session
    e(records (scag sequence.p records.e), sequence sequence.p, head `head.p, phase %judgment, resume %judgment)
  =/  checked
    (prepare b coding(sessions (~(put by sessions.coding) id previous)) id)
  ?:  ?=(%| -.checked)  [%| p.checked]
  ?.  =(p p.checked)  [%| %completion-evidence-changed]
  [%& [u.chosen r]]
++  act
  |=  [b=bowl:gall s=state coding=state:loop c=command]
  ^-  change
  ?.  =(our.b src.b)  [s coding ~]
  =/  d=decision:kernel  decision.c
  =/  id=@ux  (key d)
  =/  previous  (~(get by s) id)
  ?^  previous
    ?.  =(d decision.u.previous)
      [s coding ~[(refused:loop session.proposal.d %completion-decision-conflict)]]
    [s coding ~[(notice u.previous)]]
  ?:  (gte ~(wyt by s) 128)
    [s coding ~[(refused:loop session.proposal.d %completion-capacity)]]
  =/  snapshot  (read b coding session.proposal.d)
  ?:  ?=(%| -.snapshot)
    [s coding ~[(refused:loop session.proposal.d p.snapshot)]]
  =/  decided  (decide:kernel our.b src.b now.b p.snapshot d)
  ?:  ?=(%| -.decided)
    [s coding ~[(refused:loop session.proposal.d p.decided)]]
  =/  r=receipt  [d (need head.entry.p.decided)]
  =/  moved  (apply:loop b coding p.decided)
  =.  s  (~(put by s) id r)
  =/  cards=(list card:agent:gall)
    [(notice r) (weld -.moved ~[(poke:loop our.b %graf /native-coding/completion-retain [%attest [%native-coding-completion-retained-v1 id r]])])]
  [s +.moved (weld cards ~[(poke:loop our.b %viki /native-fleet-progress [%native-coding-fleet-progress-v1 session.proposal.d])])]
++  peek
  ::  Viki exposes these only through its own native projection boundary.
  |=  [s=state path=path]
  ^-  (unit (unit cage))
  ?:  =(/x/native-coding/completions path)  ``noun+!>(s)
  ?.  ?=([%x %native-coding %completion @ ~] path)  ~
  =/  id  (slaw %ux i.t.t.t.path)
  ?~  id  [~ ~]
  ?.  =(i.t.t.t.path (scot %ux u.id))  [~ ~]
  ``noun+!>((~(get by s) u.id))
--
