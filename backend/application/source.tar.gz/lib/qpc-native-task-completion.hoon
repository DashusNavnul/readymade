:: Pure landed-task completion only. A native reader must authenticate every
:: snapshot: task declaration, Cantrip, review, journals and Graf retention.
:: No command, permission, model call, observation, gap or source write here.
/-  nc=native-coding, worker=native-coding-worker
/+  session=native-coding-session, project=native-coding-project,
    accept=native-coding-accept, completion=native-coding-completion,
    local=native-coding-local-decision, outcome=qpc-native-outcome,
    tools=cantrip-native-coding, released=qpc-native-released-check
|%
+$  task
  $:  member=@ux  project=@t  configuration=@ux  objective=@t
      source=revision:nc  artifact=path  cases=cases:outcome
      graf=(list *)
  ==
+$  snapshot
  $:  task=task  entry=entry:session  project=project:nc
      current=revision:nc  applied=record:accept  review=captured:local
      pending=(map @ux tool-request:nc)  candidates=(map @ux candidate:nc)
      accepted=ledger:accept  tools=organ:tools
      graf=(list (unit *))
  ==
+$  proposal
  $%  $:  %qpc-native-task-completion-proposal-v1
          member=@ux  task=@ux  source=revision:nc  entry=@ux
          acceptance=@ux  review=@ux  graf=@ux
      ==
      $:  [%qpc-native-task-completion-proposal-v2 releases=releases]
          member=@ux  task=@ux  source=revision:nc  entry=@ux
          acceptance=@ux  review=@ux  graf=@ux
      ==
  ==
+$  release  [candidate=@ux acceptance=@ux key=@ux job=record:worker]
+$  releases  (list release)
+$  receipt  [proposal=proposal record=record:session]
+$  change  [next=transition:session receipt=receipt]
++  digest
  |=(value=* ^-(@ux (shax (jam [%qpc-native-task-completion-v1 value]))))
++  reason
  ^-  @t
  'Owner confirmed the declared task from its independently approved native landing and required retained evidence.'
++  release-evidence
  |=  p=proposal
  ^-  releases
  ?:  ?=(%qpc-native-task-completion-proposal-v1 -.p)  ~
  releases.p
++  released-check  check:released
++  release-valid
  :: Consistency only. The native owner must read this exact parent job and
  :: its pending-ticket binding; a supplied release list grants no authority.
  |=  [our=@p at=@da e=entry:session candidates=(map @ux candidate:nc) accepted=ledger:accept w=release]
  ^-  ?
  =/  found  (~(get by accepted) candidate.w)
  ?~  found  %.n
  =/  r=record:accept  u.found
  =/  c=candidate:nc  candidate.r
  ?&  =(candidate.w id.c)  =(acceptance.w (digest:accept r))
      =(`c (~(get by candidates) id.c))
      !=(id.session.e session.context.c)
      =(our actor.context.c)  =(our owner.source.context.c)
      (same-desk:completion working.session.e source.context.c)
      (lth number.source.context.c number.working.session.e)
      (released-check our at r key.w job.w)
  ==
++  releases-valid
  |=  [our=@p at=@da s=snapshot witnesses=releases]
  ^-  ?
  ?&  (lte (lent witnesses) 128)
      =((lent witnesses) ~(wyt in (silt (turn witnesses |=(w=release candidate.w)))))
      (levy witnesses |=(w=release (release-valid our at entry.s candidates.s accepted.s w)))
  ==
++  quiescent-with
  :: Preserve the complete canonical snapshot. Only this eligibility query
  :: omits authenticated old check reservations; unknown writes still block.
  |=  [our=@p at=@da s=snapshot witnesses=releases]
  ^-  ?
  ?.  &((lte ~(wyt by candidates.s) 128) (lte ~(wyt by accepted.s) 128))  %.n
  ?.  (releases-valid our at s witnesses)  %.n
  =/  released=(set @ux)  (silt (turn witnesses |=(w=release candidate.w)))
  =/  candidates=(map @ux candidate:nc)
    (malt (skim ~(tap by candidates.s) |=([id=@ux c=candidate:nc] !(~(has in released) id))))
  =/  accepted=ledger:accept
    (malt (skim ~(tap by accepted.s) |=([id=@ux r=record:accept] !(~(has in released) id))))
  ::  A pending request bound to a revision this desk has since left, and
  ::  never recorded by Cantrip, can no longer write the desk; it is resolved
  ::  by that observation, not resent (2026-11-01: a scope3b baseline request
  ::  at revision 9 blocked the first completion at revision 10). One Cantrip
  ::  recorded and ended is past doing anything either (2026-11-02: a baseline
  ::  check that failed at revision 13 blocked `line-column` at 14); running or
  ::  unknown tool records still block, through +quiescent.
  =/  superseded
    |=  [key=@ux r=tool-request:nc]
    ^-  ?
    ?&  (lth number.source.context.r number.current.s)
        =(desk.source.context.r desk.current.s)
        =(owner.source.context.r owner.current.s)
        =/  held  (~(get by records.tools.s) key)
        ?~(held %.y !?=(?(%running %unknown) stage.u.held))
    ==
  =/  live-pending=(map @ux tool-request:nc)
    (malt (skip ~(tap by pending.s) superseded))
  (quiescent:completion entry.s live-pending candidates accepted tools.s)
++  graf-retained
  :: Expected facts come from the owner task; actual values must be read from
  :: Graf, never copied from outgoing cards or their acknowledgements.
  |=  [wanted=(list *) actual=(list (unit *))]
  ^-  ?
  ?~  wanted  ?=(~ actual)
  ?~  actual  %.n
  ?~  i.actual  %.n
  &(=(i.wanted u.i.actual) $(wanted t.wanted, actual t.actual))
++  protected-passes
  |=  [p=project:nc t=task r=report:accept]
  ^-  ?
  =/  cases=(list case:outcome)  rows.cases.t
  ?.  =(2 (lent cases))  %.n
  ?.  =(~[%compatibility %intended-behavior] (turn cases |=(c=case:outcome proposition.c)))  %.n
  ?.  =(2 ~(wyt in (silt (turn cases |=(c=case:outcome [target.c check.c])))))  %.n
  %+  levy  cases
  |=  c=case:outcome
  ?.  ?&  =(%hoon kind.target.c)  !=(%compile check.c)
          (lien targets.p |=(v=build-target:nc =(v target.c)))
          !(writable:project p entry.target.c)
          (levy dependencies.target.c |=(pax=path |(=(artifact.t pax) !(writable:project p pax))))
      ==  %.n
  =/  matches=(list target-result:accept)
    (skim targets.r |=(v=target-result:accept =(target.c target.v)))
  ?.  =(1 (lent matches))  %.n
  =/  assessed  (assess:outcome c revision.staging.r (snag 0 matches))
  &(?=(%& -.assessed) =(%pass verdict.p.assessed))
++  consumed
  |=  [e=entry:session r=record:accept]
  ^-  ?
  =/  candidate=candidate:nc  candidate.r
  =/  tools=(list record:session)
    (skim records.e |=(j=record:session ?.(?=(%tool -.body.j) %.n &(?=(%candidate -.output.result.body.j) =(context.candidate context.result.body.j) =(candidate value.output.result.body.j)))))
  =/  judgments=(list record:session)
    (skim records.e |=(j=record:session ?.(?=(%judgment -.body.j) %.n &(=(%continue verdict.body.j) (~(has in (silt evidence.body.j)) (digest:accept r))))))
  ?.  &(=(1 (lent tools)) =(1 (lent judgments)))  %.n
  =/  tool=record:session  (snag 0 tools)
  =/  judgment=record:session  (snag 0 judgments)
  ?&  (lth sequence.tool sequence.judgment)
      (gte at.judgment at:(need decision.r))
      (gte at.judgment at.tool)
  ==
++  edits-declared
  ::  Every landed edit is a declared writable path and the task's artifact is
  ::  among them. A task may declare more than one writable file: the Console
  ::  status task writes its HTTP library and its app (first landing 2026-11-01).
  |=  [p=project:nc artifact=path edits=(list edit:nc)]
  ^-  ?
  ?&  !=(~ edits)  (writable:project p artifact)
      (lien edits |=(v=edit:nc =(artifact path.change.v)))
      (levy edits |=(v=edit:nc (writable:project p path.change.v)))
  ==
++  prepare
  :: Consistency only. An injected snapshot cannot prove native provenance.
  |=  [our=@p s=snapshot]
  ^-  (each proposal @tas)
  (prepare-with our *@da s ~)
++  prepare-with
  |=  [our=@p at=@da s=snapshot witnesses=releases]
  ^-  (each proposal @tas)
  =/  e=entry:session  entry.s
  =/  t=task  task.s
  =/  r=record:accept  applied.s
  =/  c=candidate:nc  candidate.r
  ?.  ?&  =(our owner.session.e)  =(our worker.e)
          =(our authority.spec.project.s)  =(member.t id.session.e)
          =(project.t project.session.e)  =(project.t id.spec.project.s)
          =(configuration.t configuration.e)
          =(configuration.e (configuration:project project.s))
          =(objective.t objective.session.e)
          =(source.t source.context.c)  =(member.t session.context.c)
          =(project.t project.context.c)  =(configuration.t configuration.context.c)
          =(our actor.context.c)  =(project.s project.r)
          (edits-declared project.s artifact.t edits.c)
          (lte (lent graf.t) 32)
      ==  [%| %task-completion-binding-mismatch]
  ?.  &(=(%paused phase.e) =(%ready resume.e) ?=(~ pending.e) ?=(~ calls.e))
    [%| %task-completion-session-not-ready]
  ?.  (journal-valid:completion e)  [%| %task-completion-journal-invalid]
  ?.  ?&  =(%applied stage.r)  ?=(^ landed.r)  ?=(^ decision.r)
          ?=(^ report.r)  =(%approve verdict.u.decision.r)
          =(current.s working.session.e)  =(current.s revision.u.landed.r)
          =(`r (~(get by accepted.s) id.c))
          (valid:accept (~(put by *ledger:accept) id.c r))
          (passed:accept u.report.r)
      ==  [%| %task-completion-landing-unconfirmed]
  ?.  (protected-passes project.s t u.report.r)
    [%| %task-completion-protected-checks-unconfirmed]
  ?.  (consumed e r)  [%| %task-completion-landing-not-consumed]
  ?.  (quiescent-with our at s witnesses)
    [%| %task-completion-work-unresolved]
  =/  objective  (objective:completion e)
  ?:  ?=(%| -.objective)  [%| p.objective]
  =/  reviewer  campaign.review.s
  =/  selected  selection.scope.request.reviewer
  ?:  =([provider.selected model.selected] [provider.selection.e model.selection.e])
    [%| %task-completion-independent-review-required]
  =/  checked
    (decide:local our at.u.decision.r review.s project.s c u.report.r text.p.objective)
  ?:  ?=(%| -.checked)  [%| p.checked]
  ?.  =(p.checked u.decision.r)  [%| %task-completion-review-mismatch]
  ?.  (graf-retained graf.t graf.s)  [%| %task-completion-graf-unconfirmed]
  ?:  =(~ witnesses)
    [%& [%qpc-native-task-completion-proposal-v1 member.t (digest t) current.s (digest e) (digest:accept r) (digest review.s) (digest [graf.t graf.s])]]
  [%& [[%qpc-native-task-completion-proposal-v2 witnesses] member.t (digest t) current.s (digest e) (digest:accept r) (digest review.s) (digest [graf.t graf.s])]]
++  judgment-body
  |=  p=proposal
  ^-  body:session
  [%judgment %complete ~[(digest p) acceptance.p] reason]
++  rewind
  :: Fresh typed sample keeps the prefix a list after the caller proved that
  :: the completed entry's records are nonempty. No state is written here.
  |=  [e=entry:session last=record:session]
  ^-  entry:session
  e(phase %paused, resume %ready, records (scag (dec (lent records.e)) records.e), head previous.last, sequence sequence.last)
++  complete
  |=  [our=@p actor=@p at=@da s=snapshot prior=(unit receipt)]
  ^-  (each change @tas)
  (complete-with our actor at s ~ prior)
++  complete-with
  |=  [our=@p actor=@p at=@da s=snapshot witnesses=releases prior=(unit receipt)]
  ^-  (each change @tas)
  ?.  =(our actor)  [%| %task-completion-owner-required]
  =/  e=entry:session  entry.s
  ?^  prior
    ?.  &(=(%complete phase.e) =(%complete resume.e) ?=(^ records.e))
      [%| %task-completion-conflict]
    =/  last=record:session  (rear records.e)
    ?.  &(=(last record.u.prior) =(head.e `id.last) (gte at at.last))
      [%| %task-completion-conflict]
    =/  before=entry:session
      (rewind e last)
    =/  prepared  (prepare-with our at.last s(entry before) witnesses)
    ?:  ?=(%| -.prepared)  [%| p.prepared]
    ?.  &(=(p.prepared proposal.u.prior) =(body.last (judgment-body p.prepared)))
      [%| %task-completion-conflict]
    =/  replay  (append:session before(phase %complete, resume %complete) at.last (judgment-body p.prepared))
    ?:  ?=(%| -.replay)  [%| p.replay]
    ?.  =(e entry.p.replay)  [%| %task-completion-conflict]
    [%& [[e ~] u.prior]]
  =/  prepared  (prepare-with our at s witnesses)
  ?:  ?=(%| -.prepared)  [%| p.prepared]
  ?~  records.e  [%| %task-completion-journal-invalid]
  ?.  (gte at at:(rear records.e))  [%| %task-completion-time-regressed]
  =/  moved  (append:session e(phase %complete, resume %complete) at (judgment-body p.prepared))
  ?:  ?=(%| -.moved)  [%| p.moved]
  [%& [p.moved [p.prepared (rear records.entry.p.moved)]]]
--
