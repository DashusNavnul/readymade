::  Source-bound, explicitly authored task/profile registration. No authority
::  to select, dispatch inference, assess candidates or execute project work.
::  Only the native wrapper supplies snapshots and authenticated build results.
/-  nc=native-coding
/+  instrument=qpc-instrument-contract, sensing=qpc-task-sensing,
    source=qpc-instrument-source, obs=qpc-observation,
    outcomes=qpc-native-outcome, project=native-coding-project,
    law=qpc-law-core, energy=qpc-energy
|%
+$  command
  $:  %qpc-profile-register-v1  session=@ux  member=@ux
      expected-law=@ux  profile=revision:nc  rationale=@t
  ==
+$  snapshot
  $:  plan=plan:instrument  project=project:nc  objective=@t
      cases=cases:outcomes  source=receipt:source  law=revision:law
      unused=?  managed=?
  ==
+$  association
  $:  owner=@p  at=@da  command=command  plan=plan:instrument
      project=project:nc  objective=@t  task=task:sensing
      source=receipt:source  law=revision:law
  ==
+$  build
  $:  %qpc-profile-build-v1  ticket=@ux  source=revision:nc
      pax=path  lobe=@ux  hash=@ux  product=*  files=@ud  bytes=@ud
  ==
+$  certificate
  $:  %qpc-profile-equivalence-v1  source=revision:nc  pax=path
      lobe=@ux  hash=@ux  evaluator=@ux  files=@ud  bytes=@ud
  ==
+$  record
  $:  id=@ux  value=association  due=@da
      phase=?(%scheduled %building %verified %refused %unknown %cancelled)
      certificate=(unit certificate)  reason=(unit @tas)
  ==
+$  state  [%qpc-native-declarations-v1 records=(map @ux record)]
++  empty  ^-(state [%qpc-native-declarations-v1 ~])
++  profile-path  /lib/qpc-energy/hoon
++  digest  |=(v=* ^-(@ux (shax (jam [%qpc-native-declaration-v1 v]))))
++  evaluator  (shax (jam q:!>(energy)))
++  command-valid
  |=  [our=@p c=command]
  ?&  (levy `(list @ux)`~[session.c member.c expected-law.c] identifier:sensing)
      !=(session.c member.c)  (revision-valid:project profile.c)
      =(our owner.profile.c)  (reason-valid:law rationale.c)
  ==
++  task-of
  |=  v=snapshot
  ^-  task:sensing
  :*  %qpc-task-binding-v1  task.plan.v  objective.plan.v  artifact.plan.v
      source.source.v  (configuration:project project.v)  cases.v
      evidence.source.v  horizon.plan.v
  ==
++  compatible
  ::  Source authenticity is the native reader's obligation. These joins do
  ::  not turn a caller-created snapshot into a canonical declaration.
  |=  [our=@p c=command v=snapshot]
  ?&  (command-valid our c)  unused.v  managed.v
      (plan-valid:instrument our plan.v)  =(member.c session.plan.v)
      (valid:project project.v)  =(our authority.spec.project.v)
      =(project.manifest.plan.v id.spec.project.v)
      =(objective.plan.v (digest:obs objective.v))
      (text-valid:obs objective.v)
      =(cases.plan.v (digest:outcomes cases.v))
      =(2 (lent rows.cases.v))
      =((turn rows.cases.v |=(c=case:outcomes proposition.c)) ~[%compatibility %intended-behavior])
      (checks-protected:sensing project.v artifact.plan.v cases.v)
      (revision-valid:project source.source.v)
      =(our owner.source.source.v)  =(working.project.v desk.source.source.v)
      (evidence-valid:obs evidence.source.v)  (gth ~(wyt by files.source.v) 0)
      (lte ~(wyt by files.source.v) 256)
      (levy ~(tap by files.source.v) |=([p=path h=@ux] &((readable:project project.v p) (identifier:sensing h))))
      (valid:law law.v)  =(our actor.law.v)
      =(expected-law.c id.law.v)  =((binding-of:instrument plan.v) binding.law.v)
      %+  levy  rows.cases.v
      |=  row=case:outcomes
      ?&  =(%hoon kind.target.row)  !=(%compile check.row)
          (lien targets.project.v |=(t=build-target:nc =(t target.row)))
          =(1 (lent (skim checks.target.row |=([name=@tas expression=@t] =(name check.row)))))
      ==
  ==
++  begin
  |=  [s=state our=@p actor=@p at=@da c=command v=snapshot]
  ^-  (each state @tas)
  ?.  =(our actor)  [%| %qpc-profile-owner-required]
  ?:  (~(has by records.s) session.c)  [%| %qpc-profile-already-registered]
  ?.  (lth ~(wyt by records.s) 64)  [%| %qpc-profile-capacity]
  ?:  (lien ~(val by records.s) |=(r=record ?=(?(%scheduled %building) phase.r)))
    [%| %qpc-profile-build-busy]
  ?.  (compatible our c v)  [%| %qpc-profile-binding-refused]
  =/  a=association
    [our at c plan.v project.v objective.v (task-of v) source.v law.v]
  =/  r=record  [(digest a) a (add at ~s1) %scheduled ~ ~]
  [%& s(records (~(put by records.s) session.c r))]
++  wire-for
  |=  [r=record phase=?(%wake %build)]
  ^-  wire
  /qpc-profile/[phase]/(scot %ux session.command.value.r)/(scot %ux id.r)
++  unchanged
  |=  [our=@p r=record v=snapshot]
  ?&  (compatible our command.value.r v)
      =(plan.value.r plan.v)  =(project.value.r project.v)
      =(objective.value.r objective.v)  =(task.value.r (task-of v))
      =(source.value.r source.v)  =(law.value.r law.v)
  ==
++  start
  |=  [s=state id=@ux ticket=@ux]
  ^-  state
  =/  found  (~(get by records.s) id)
  ?~  found  s
  =/  r=record  u.found
  ?.  &(=(ticket id.r) =(%scheduled phase.r))  s
  s(records (~(put by records.s) id r(phase %building)))
++  stop
  |=  [s=state id=@ux phase=?(%refused %unknown %cancelled) reason=@tas]
  ^-  state
  =/  found  (~(get by records.s) id)
  ?~  found  s
  =/  r=record  u.found
  ?.  ?=(?(%scheduled %building) phase.r)  s
  s(records (~(put by records.s) id r(phase phase, reason `reason)))
++  finish
  ::  The authenticated builder returns the evaluator noun, without its large
  ::  compiler type. Compare it exactly; never cast it or execute it.
  |=  [s=state id=@ux value=build]
  ^-  state
  =/  found  (~(get by records.s) id)
  ?~  found  s
  =/  r=record  u.found
  ?.  &(=(ticket.value id.r) =(%building phase.r))  s
  ?.  ?&  =(profile.command.value.r source.value)  =(profile-path pax.value)
          (identifier:sensing lobe.value)  (identifier:sensing hash.value)
          (gth files.value 0)  (lte files.value 256)
          (gth bytes.value 0)  (lte bytes.value 2.097.152)
          =(product.value q:!>(energy))
      ==
    (stop s id %refused %qpc-profile-evaluator-mismatch)
  =/  c=certificate
    [%qpc-profile-equivalence-v1 source.value pax.value lobe.value hash.value evaluator files.value bytes.value]
  s(records (~(put by records.s) id r(phase %verified, certificate `c)))
++  usable
  ::  A later code upgrade preserves old certificates without silently
  ::  authorizing a different executing evaluator with them.
  |=  r=record
  ?.  =(%verified phase.r)  %.n
  ?~  certificate.r  %.n
  =(evaluator.u.certificate.r evaluator)
++  valid
  ::  Loading verifies historical structure, never current eligibility. It
  ::  does not re-register, re-read source, compile or emit task effects.
  |=  [our=@p s=state]
  ?&  (lte ~(wyt by records.s) 64)
      (lte (lent (skim ~(val by records.s) |=(r=record ?=(?(%scheduled %building) phase.r)))) 1)
      %+  levy  ~(tap by records.s)
      |=  [id=@ux r=record]
      =/  a=association  value.r
      =/  v=snapshot  [plan.a project.a objective.a cases.task.a source.a law.a %.y %.y]
      ?&  =(id session.command.a)  =(our owner.a)
          =(id.r (digest a))  =(due.r (add at.a ~s1))
          (compatible our command.a v)  =(task.a (task-of v))
          ?:  =(%verified phase.r)
            ?~  certificate.r  %.n
            =/  c=certificate  u.certificate.r
            ?&  ?=(~ reason.r)  =(source.c profile.command.a)
                =(pax.c profile-path)  (identifier:sensing evaluator.c)
                (identifier:sensing lobe.c)  (identifier:sensing hash.c)
                (gth files.c 0)  (lte files.c 256)
                (gth bytes.c 0)  (lte bytes.c 2.097.152)
            ==
          ?&  ?=(~ certificate.r)
              ?:  ?=(?(%scheduled %building) phase.r)  ?=(~ reason.r)
              ?~  reason.r  %.n
              !=(%$ u.reason.r)
          ==
      ==
  ==
--
