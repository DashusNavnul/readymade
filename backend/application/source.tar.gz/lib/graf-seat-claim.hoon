::  /lib/graf-seat-claim
::
::  THE GRAF SEAT CLAIM LAW.  Pure: no state, no scry, no bowl.
::
::  It consults /sur/moon-grant and +lease-live:entity-subject rather than
::  inventing a grant of its own.  Viki keeps the seats; graf enforces what
::  viki granted.  A seat is a capability name -- seat/<id> -- in a live
::  lease's allowed-tools, so expiry, revocation and the fail-closed status
::  lifecycle all come from the existing model unchanged.
::
::  The app computes `(^sein:title src.bowl)` and hands it in, so a thread
::  can prove this arm.  That is the whole reason the seat NESTING bug
::  survived so long: the write gate lived inside a 5.454-line agent
::  nothing could import.
::
::  ORDER OF CHECKS is deliberate: family, lease, seat-in-lease, then
::  occupancy.  An outsider is told it is an outsider rather than told the
::  seat is taken -- a refusal that reveals more than the claimant is
::  entitled to know is its own small leak.
::
/-  gsc=graf-seat-claim, mg=moon-grant, graf-sur=graf
/+  es=entity-subject
|%
::  A seat capability is grant metadata, not an executable Guardian tool.
::  Keep the accepted set closed over the same nine constructors that define
::  seat identity; prefix matching would let `seat/anything` mint a tenth seat.
++  seat-cap-valid
  |=  cap=@t
  ^-  ?
  ?|  =((seat-cap:gsc %flunky) cap)
      =((seat-cap:gsc %busboy) cap)
      =((seat-cap:gsc %policeman) cap)
      =((seat-cap:gsc %gendarme) cap)
      =((seat-cap:gsc %undertaker) cap)
      =((seat-cap:gsc %priest) cap)
      =((seat-cap:gsc %delivery-boy) cap)
      =((seat-cap:gsc %cuirassier) cap)
      =((seat-cap:gsc %stationmaster) cap)
  ==
::
::  who holds this seat now?  +add-seat-write PREPENDS and +find-seat-write
::  takes the FIRST match, so the holder is the newest claim.  That
::  ordering is what made takeover silent; here it is read, not trusted.
::
++  holder-of
  |=  [held=(list graf-seat-write:graf-sur) seat=@tas]
  ^-  (unit @p)
  ?~  held  ~
  ?:  =(seat-id.i.held seat)
    =/  who=(unit @p)  (slaw %p assigned-ship-id.i.held)
    ?~  who  ~
    `u.who
  $(held t.held)
::
++  refuse
  |=  [why=@tas seat=@tas claimant=@p note=@t]
  ^-  verdict:gsc
  [%| why seat claimant note]
::
::  MAY THIS SHIP CLAIM THIS SEAT?
::
::    grant     the moon's lease, as viki holds it (~ if none)
::    claimant  src.bowl
::    sponsor   (^sein:title src.bowl), computed by the caller
::
++  may-claim
  |=  $:  grant=(unit moon-grant:mg)
          held=(list graf-seat-write:graf-sur)
          seat=@tas
          claimant=@p
          sponsor=@p
          our=@p
          now=@da
      ==
  ^-  verdict:gsc
  =/  cap=@t  (seat-cap:gsc seat)
  ::  the principal is the grantor; requiring it to lease itself a seat
  ::  would be ceremony, and ceremony that can be skipped is a rule nobody
  ::  follows.
  =/  is-self=?      =(our claimant)
  =/  is-our-moon=?  =(our sponsor)
  ?.  ?|(is-self is-our-moon)
    %^  refuse  %not-family  seat
    [claimant 'claimant is neither this ship nor a moon it sponsors']
  ::  occupancy binds the principal too: a silent takeover by the planet is
  ::  still a silent takeover, and the incumbent would lose work in flight.
  =/  who=(unit @p)  (holder-of held seat)
  ?:  ?&(?=(^ who) !=(u.who claimant))
    %^  refuse  %seat-held  seat
    [claimant 'another ship holds this seat; revoke its lease first']
  ?:  is-self  [%& cap]
  ::  EVERYTHING BELOW IS THE EXISTING MODEL, not a new one.
  ::  +lease-live is: exists, is yours, is %active, not expired.
  ?.  (lease-live:es grant claimant now)
    %^  refuse  %no-lease  seat
    [claimant 'no live lease for this moon: absent, not yours, inactive, or expired']
  =/  g=moon-grant:mg  (need grant)
  ::  a lease granted by another ship proves nothing to this ship.
  ?.  =(parent.g our)
    %^  refuse  %wrong-parent  seat
    [claimant 'lease was granted by another ship']
  ?.  (~(has in allowed-tools.g) cap)
    %^  refuse  %seat-not-in-lease  seat
    [claimant 'lease is live but does not carry this seat capability']
  [%& cap]
::
::  the loobean form, for a call site that only needs yes or no.  The
::  verdict form is preferred wherever a refusal can be surfaced -- rule
::  12: a gate that says only "no" turns a diagnosable problem into a
::  guessable one.
::
++  claim-allowed
  |=  $:  grant=(unit moon-grant:mg)
          held=(list graf-seat-write:graf-sur)
          seat=@tas
          claimant=@p
          sponsor=@p
          our=@p
          now=@da
      ==
  ^-  ?
  ::  scar: `-.(expr)` is not Hoon -- `-.` takes a WING.  Bind, then refine.
  =/  v=verdict:gsc  (may-claim grant held seat claimant sponsor our now)
  ?=(%& -.v)
--
