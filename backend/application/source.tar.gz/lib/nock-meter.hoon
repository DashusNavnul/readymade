::  /lib/nock-meter.hoon
::
::  METERED EVALUATION (#15). `mule` catches a crash but NOT a loop or a bomb:
::  a model-authored formula that spins hangs the poke forever. This is a
::  STEP-BUDGETED Nock interpreter -- every reduction spends one unit of fuel, so
::  a non-terminating formula returns %out-of-fuel instead of hanging. Safe
::  against denial, not just incorrectness. It is the honest fix flagged for both
::  the proof-suite RCE and the Nick medium: run untrusted code with a budget.
::  Returns the value, or a fault term (%out-of-fuel / a crash reason).
::  COMPUTED -- exact (it is the Nock spec, plus a fuel counter).
::
|%
++  status  ^-(@tas %computed)
+$  res  (each * @tas)                       ::  value | fault reason
::  axis lookup /[axe n], fault-safe.
++  slot-e
  |=  [axe=@ n=*]
  ^-  res
  ?:  =(0 axe)  [%| %slot-0]
  |-  ^-  res
  ?:  =(1 axe)  [%& n]
  ?@  n  [%| %slot-off-atom]
  ?:  =(2 (cap axe))  $(axe (mas axe), n -.n)
  $(axe (mas axe), n +.n)
::  edit #[axe small big], fault-safe.
++  edit-e
  |=  [axe=@ small=* big=*]
  ^-  res
  ?:  =(0 axe)  [%| %edit-0]
  ?:  =(1 axe)  [%& small]
  ?@  big  [%| %edit-off-atom]
  ?:  =(2 (cap axe))
    =/  l  $(axe (mas axe), big -.big)
    ?:  ?=(%| -.l)  l
    [%& [p.l +.big]]
  =/  r  $(axe (mas axe), big +.big)
  ?:  ?=(%| -.r)  r
  [%& [-.big p.r]]
::  the metered interpreter. *[subj form] with a fuel budget, dispatched on the
::  opcode by equality (a bare numeric literal is not a valid pattern head).
++  meter
  |=  [subj=* form=* fuel=@ud]
  ^-  res
  ?:  =(0 fuel)  [%| %out-of-fuel]
  =/  f  (dec fuel)
  ?@  form  [%| %atom-formula]
  =/  hed  -.form
  =/  ar   +.form
  ::  autocons: the head is itself a formula.
  ?^  hed
    =/  l  $(form hed, fuel f)
    ?:  ?=(%| -.l)  l
    =/  r  $(form ar, fuel f)
    ?:  ?=(%| -.r)  r
    [%& [p.l p.r]]
  ::  unary-ish opcodes whose argument is the whole tail.
  ?:  =(1 hed)  [%& ar]
  ?:  =(0 hed)  ?@(ar (slot-e ar subj) [%| %bad-0])
  ?:  =(4 hed)
    =/  x  $(form ar, fuel f)
    ?:  ?=(%| -.x)  x
    ?^(p.x [%| %increment-cell] [%& +(p.x)])
  ?:  =(3 hed)
    =/  x  $(form ar, fuel f)
    ?:  ?=(%| -.x)  x
    [%& ?:(?=(^ p.x) 0 1)]
  ::  the rest need the tail to be a cell [b ...].
  ?@  ar  [%| %bad-args]
  =/  b   -.ar
  =/  cd  +.ar
  ?:  =(2 hed)
    =/  s2  $(form b, fuel f)
    ?:  ?=(%| -.s2)  s2
    =/  f2  $(form cd, fuel f)
    ?:  ?=(%| -.f2)  f2
    $(subj p.s2, form p.f2, fuel f)
  ?:  =(7 hed)
    =/  s2  $(form b, fuel f)
    ?:  ?=(%| -.s2)  s2
    $(subj p.s2, form cd, fuel f)
  ?:  =(8 hed)
    =/  s2  $(form b, fuel f)
    ?:  ?=(%| -.s2)  s2
    $(subj [p.s2 subj], form cd, fuel f)
  ?:  =(5 hed)
    =/  l  $(form b, fuel f)
    ?:  ?=(%| -.l)  l
    =/  r  $(form cd, fuel f)
    ?:  ?=(%| -.r)  r
    [%& ?:(=(p.l p.r) 0 1)]
  ?:  =(9 hed)
    ?.  ?=(@ b)  [%| %bad-9-axis]
    =/  core  $(form cd, fuel f)
    ?:  ?=(%| -.core)  core
    =/  arm  (slot-e b p.core)
    ?:  ?=(%| -.arm)  arm
    $(subj p.core, form p.arm, fuel f)
  ?:  =(11 hed)
    ::  [11 [b c] d]: evaluate the dynamic hint then *[a d].  [11 b c]: *[a c].
    ?^  b
      =/  h  $(form +.b, fuel f)
      ?:  ?=(%| -.h)  h
      $(form cd, fuel f)
    $(form cd, fuel f)
  ::  6 and 10 need the tail's tail to be a cell too.
  ?@  cd  [%| %bad-args]
  =/  c  -.cd
  =/  d  +.cd
  ?:  =(6 hed)
    =/  t  $(form b, fuel f)
    ?:  ?=(%| -.t)  t
    ?:  =(0 p.t)  $(form c, fuel f)
    ?:  =(1 p.t)  $(form d, fuel f)
    [%| %bad-if]
  ?:  =(10 hed)
    ?.  ?=(@ b)  [%| %bad-10-axis]
    =/  big  $(form d, fuel f)
    ?:  ?=(%| -.big)  big
    =/  small  $(form c, fuel f)
    ?:  ?=(%| -.small)  small
    (edit-e b p.small p.big)
  [%| %unknown-op]
--
