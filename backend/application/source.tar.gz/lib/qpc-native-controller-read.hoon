::  Viki-side current authority join. Only canonical IDs cross command paths.
/+  controller=qpc-native-controller, bind=qpc-native-owner-binding,
    owner=qpc-native-owner, d=qpc-native-decision,
    a=qpc-native-assessment, admit=qpc-native-admission,
    instrument=qpc-instrument-contract, observer=qpc-observer,
    pool=qpc-native-pool, project=native-coding-project,
    tools=cantrip-native-coding, law=qpc-law-core,
    window=cantrip-law-window, guard=viki-scry-guard
|%
+$  view  [origin=record:owner input=input:pool assessment=record:a current=current:d]
+$  reader  $-([inner=agent:gall b=bowl:gall id=@ux] (each view @tas))
+$  receipts  $-([b=bowl:gall id=@ux] (each receipt:admit @tas))
++  read
  |=  [inner=agent:gall b=bowl:gall id=@ux]
  ^-  (each view @tas)
  ?.  =(our.b src.b)  [%| %qpc-controller-owner-required]
  =/  raw  (raw:instrument inner b /x/qpc/owner)
  =/  law-raw  (raw:instrument inner b /x/qpc/laws)
  =/  input  (input:observer inner b id)
  ?~  raw  [%| %qpc-controller-owner-unavailable]
  ?~  law-raw  [%| %qpc-controller-law-unavailable]
  ?~  input  [%| %qpc-controller-session-missing]
  =/  prior  ((soft state:bind) u.raw)
  =/  laws  ((soft state:law) u.law-raw)
  ?~  prior  [%| %qpc-controller-owner-invalid]
  ?~  laws  [%| %qpc-controller-law-invalid]
  ?.  (valid:bind our.b u.prior)  [%| %qpc-controller-owner-invalid]
  =/  found  (~(get by records.journal.u.prior) id)
  =/  ticket  (~(get by tickets.u.prior) id)
  ?~  found  [%| %qpc-controller-opening-missing]
  ?~  ticket  [%| %qpc-controller-registration-missing]
  =/  r=record:owner  u.found
  ?.  &(=(%sealed phase.u.ticket) ?=(~ closed.r))  [%| %qpc-controller-owner-not-sealed]
  ?~  collection.r  [%| %qpc-controller-pool-missing]
  =/  registered  registration.u.ticket
  :: The sealed opening already froze its law; later gain edits govern new
  :: decisions. Fresh source, grant, membership and Cantrip law checks follow.
  =/  frozen  (retained:law u.laws binding.law.value.registered our.b id.law.value.registered)
  ?:  ?=(%| -.frozen)  [%| p.frozen]
  ?.  =(law.value.registered p.frozen)  [%| %qpc-controller-law-changed]
  =/  p  project.grant.scope.r
  =/  current  (current:project our.b now.b p)
  ?:  ?=(%| -.current)  [%| p.current]
  =/  f=opening:d  frozen.decision.r
  ?.  &(=(source.f revision.working.p.current) =(source.f working.session.entry.u.input))
    [%| %qpc-controller-source-changed]
  =/  catalog  (catalog:project our.b now.b p)
  ?:  ?=(%| -.catalog)  [%| p.catalog]
  ?.  ?&  (member:project p p.catalog our.b %patch)
          (member:project p p.catalog our.b %compile)
          (member:project p p.catalog our.b %check)
      ==  [%| %qpc-controller-membership-refused]
  ?.  (agent-live:guard our.b now.b %cantrip)  [%| %qpc-controller-cantrip-unavailable]
  =/  book=organ:tools
    .^(organ:tools %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/tool-state/noun)
  ?.  =(`scope.r (~(get by grants.book) grant.f))
    [%| %qpc-controller-grant-changed]
  =/  window=window:window
    .^(window:window %gx /(scot %p our.b)/cantrip/(scot %da now.b)/law/window/current/noun)
  ?.  ?&  (~(has in admissible.window) %probe)  !(~(has in blocked.window) %probe)
          (~(has in admissible.window) %inscribe)  !(~(has in blocked.window) %inscribe)
      ==  [%| %qpc-controller-cantrip-law-blocked]
  =/  assessed=state:a
    .^(state:a %gx /(scot %p our.b)/cantrip/(scot %da now.b)/qpc/assessments/noun)
  ?.  (valid:a our.b assessed)  [%| %qpc-controller-assessment-invalid]
  =/  assessment  (~(get by records.assessed) id)
  ?~  assessment  [%| %qpc-controller-assessment-missing]
  =/  c=collection:owner  u.collection.r
  ?.  =(binding.u.assessment [f pool.c position.c declaration.r scope.r])
    [%| %qpc-controller-assessment-binding-mismatch]
  ?.  (levy ~(val by rows.u.assessment) |=(v=row:a ?=(?(%checked %refused %unknown) phase.v)))
    [%| %qpc-controller-assessment-unfinished]
  ?.  %+  levy  ~(val by rows.u.assessment)
      |=  v=row:a
      ?&  =(basis.candidate.v working.p.current)
          =(accepted.candidate.v revision.accepted.p.current)
          =(`tool.v (~(get by records.book) (key:tools request.tool.v)))
      ==
    [%| %qpc-controller-candidate-source-changed]
  [%& [r u.input u.assessment [source.f epoch.binding.core.decision.r authority.f]]]
++  receipt
  ::  The Cantrip wrapper must retain this before sending its owner notice.
  |=  [b=bowl:gall id=@ux]
  ^-  (each receipt:admit @tas)
  ?.  (agent-live:guard our.b now.b %cantrip)  [%| %qpc-controller-cantrip-unavailable]
  =/  held=(unit receipt:admit)
    .^((unit receipt:admit) %gx /(scot %p our.b)/cantrip/(scot %da now.b)/qpc/admissions/(scot %ux id)/noun)
  ?~  held  [%| %qpc-controller-admission-missing]
  ?.  =(id id.event.request.u.held)  [%| %qpc-controller-admission-mismatch]
  [%& u.held]
--
