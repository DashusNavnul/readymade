::  Owner-only Clay projections. Existing clay-view remains the save authority.
/+  cv=clay-view
|%
+$  request  [kind=?(%desks %tree %file) desk=@tas start=@ud pax=path]
+$  row  [pax=path lobe=@uv]
+$  catalog  [desk=@tas revision=@ud]
+$  file  [pax=path lobe=@uv bytes=@ud format=?(%raw %wain) source=(unit @t) digest=@ux writable=?]
+$  snapshot
  $:  %readymade-project-v1  owner=@p  kind=?(%desks %tree %file)
      desk=@tas  revision=@ud  start=@ud  total=@ud  next=(unit @ud)
      rows=(list row)  desks=(list catalog)  file=(unit file)  problem=(unit @t)
  ==
+$  watching  (set @tas)
++  max-rows  64
++  max-text  65.536
++  cursor
  |=  value=@t
  ^-  (unit @ud)
  ?.  (lte (met 3 value) 20)  ~
  =/  n=(unit @ud)  (slaw %ud value)
  ?~  n  ~
  ?.  &((lte (met 0 u.n) 64) =(value (scot %ud u.n)))  ~
  n
++  desk-valid
  |=  value=@t
  ^-  ?
  &((gth (met 3 value) 0) (lte (met 3 value) 128) ((sane %tas) value))
++  path-valid
  |=  pax=path
  ^-  ?
  ?~  pax  %.n
  ?.  &((lte (lent `path`pax) 32) (lte (met 3 (spat `path`pax)) 512))  %.n
  %+  levy  `path`pax
  |=  part=@ta
  ?&  (gth (met 3 part) 0)  (lte (met 3 part) 63)
      %+  levy  (trip `@t`part)
      |=  c=@tD
      |(&((gte c 'a') (lte c 'z')) &((gte c '0') (lte c '9')) =(c '-') =(c '_') =(c '~'))
  ==
++  pathname
  |=  value=@t
  ^-  (unit path)
  ?.  (lte (met 3 value) 512)  ~
  =/  parsed=(unit path)  (rush value stap)
  ?~  parsed  ~
  ?.  &((path-valid u.parsed) =(value (spat u.parsed)))  ~
  parsed
++  route
  |=  pax=path
  ^-  (unit request)
  ?+  pax  ~
    [%projects %desks @ ~]
      =/  n  (cursor i.t.t.pax)
      ?~  n  ~
      `[%desks %none u.n ~]
    [%projects %tree @ @ ~]
      ?.  (desk-valid i.t.t.pax)  ~
      =/  n  (cursor i.t.t.t.pax)
      ?~  n  ~
      `[%tree i.t.t.pax u.n ~]
    [%projects %file @ ^]
      ?.  &((desk-valid i.t.t.pax) (path-valid t.t.t.pax))  ~
      `[%file i.t.t.pax 0 t.t.t.pax]
  ==
++  path-for
  |=  req=request
  ^-  path
  ?-  kind.req
    %desks  /projects/desks/(scot %ud start.req)
    %tree   /projects/tree/[desk.req]/(scot %ud start.req)
    %file   (weld /projects/file/[desk.req] pax.req)
  ==
++  empty
  |=  [our=@p req=request]
  ^-  snapshot
  [%readymade-project-v1 our kind.req desk.req 0 start.req 0 ~ ~ ~ ~ ~]
++  page
  |=  [files=(map path lobe:clay) start=@ud]
  ^-  (list row)
  =/  sorted=(list row)
    (sort ~(tap by files) |=([a=row b=row] (aor (spat pax.a) (spat pax.b))))
  (scag max-rows (slag start sorted))
++  supported
  |=  files=(map path lobe:clay)
  ^-  (map path lobe:clay)
  %-  malt
  (skim ~(tap by files) |=(r=row (path-valid pax.r)))
++  writable
  |=  [b=bowl:gall desk=@tas]
  ^-  ?
  ?.  (~(has in seats:cv) desk)  %.n
  =/  dom=(unit dome:clay)
    (~(get by .^(cone:clay %cx /(scot %p our.b)//(scot %da now.b)/domes)) [our.b desk])
  =(`%dead (bind dom |=(d=dome:clay liv.d)))
++  project
  |=  [b=bowl:gall req=request]
  ^-  snapshot
  =/  out=snapshot  (empty our.b req)
  ?.  =(our.b src.b)  out(problem `'Only the owner may read project files.')
  =/  names=(set @tas)  .^((set @tas) %cd ~[(scot %p our.b) '' (scot %da now.b)])
  ?:  =(%desks kind.req)
    ?:  (gth ~(wyt in names) 1.024)  out(problem `'Desk catalog exceeds 1024 entries.')
    =/  ordered=(list @tas)  (sort (skim ~(tap in names) desk-valid) aor)
    =/  omitted=@ud  (sub ~(wyt in names) (lent ordered))
    =.  problem.out  ?:(=(0 omitted) ~ `'Unsupported desk names omitted from this catalog.')
    =/  rows=(list catalog)
      %+  turn  (scag max-rows (slag start.req ordered))
      |=  name=@tas
      [name (rev:cv our.b name)]
    =/  total=@ud  (lent ordered)
    out(total total, desks rows, next ?:(=(max-rows (lent rows)) ?:((lth (add start.req max-rows) total) `(add start.req max-rows) ~) ~))
  ?.  (~(has in names) desk.req)  out(problem `'The selected desk is absent.')
  =/  tree  (tree:cv our.b now.b desk.req)
  =.  revision.out  at.tree
  =.  total.out  ~(wyt by files.tree)
  ?:  (gth total.out 20.000)  out(total 0, problem `'Desk exceeds 20000 files; narrow browsing is unavailable.')
  ?:  =(%tree kind.req)
    =/  browse=(map path lobe:clay)  (supported files.tree)
    =/  omitted=@ud  (sub total.out ~(wyt by browse))
    =.  total.out  ~(wyt by browse)
    =/  rows=(list row)  (page browse start.req)
    out(rows rows, problem ?:(=(0 omitted) ~ `(crip "{(scow %ud omitted)} unsupported Clay paths omitted from this listing.")), next ?:((lth (add start.req (lent rows)) total.out) `(add start.req (lent rows)) ~))
  =/  lobe=(unit lobe:clay)  (~(get by files.tree) pax.req)
  ?~  lobe  out(problem `'The file is absent on this revision.')
  =/  at=path  (weld (root:cv our.b now.b desk.req) pax.req)
  ?.  .^(? %cu at)  out(problem `'The selected file is unavailable.')
  =/  raw=*  .^(* %cq at)
  =/  source=(unit @t)
    ?@  raw  `raw
    (bind ((soft wain) raw) of-wain:format)
  ?~  source  out(problem `'This file is not supported text.')
  =/  bytes=@ud  (met 3 u.source)
  =/  bounded=(unit @t)  ?:((lte bytes max-text) source ~)
  out(file `[pax.req u.lobe bytes ?:(?=(@ raw) %raw %wain) bounded (shax u.source) &(?=(^ bounded) (writable b desk.req))])
++  file-valid
  |=  [wanted=path value=file]
  ^-  ?
  ?.  ?&  =(wanted pax.value)  (path-valid pax.value)  !=(0 lobe.value)
          (lte (met 0 lobe.value) 256)  (lte (met 0 digest.value) 256)
          (lte (met 0 bytes.value) 64)
      ==  %.n
  ?~  source.value  &((gth bytes.value max-text) !writable.value)
  ?&  (lte bytes.value max-text)
      =(bytes.value (met 3 u.source.value))
      =(digest.value (shax u.source.value))
  ==
++  valid
  |=  [our=@p req=request value=snapshot]
  ^-  ?
  ?.  ?&  =(our owner.value)  =(kind.req kind.value)  =(desk.req desk.value)
          =(start.req start.value)  (lte (lent rows.value) max-rows)
          (lte (lent desks.value) max-rows)  (lte (met 0 revision.value) 64)
          (lte (met 0 start.value) 64)  (lte total.value 20.000)
          (levy rows.value |=(r=row &((path-valid pax.r) !=(0 lobe.r) (lte (met 0 lobe.r) 256))))
          (levy desks.value |=(d=catalog &((desk-valid desk.d) (lte (met 0 revision.d) 64))))
          ?~(problem.value %.y (lte (met 3 u.problem.value) 512))
      ==  %.n
  ?:  =(%file kind.req)
    ?&  =(~ rows.value)  =(~ desks.value)  =(~ next.value)
        ?~(file.value %.y (file-valid pax.req u.file.value))
    ==
  ?.  =(~ file.value)  %.n
  =/  count=@ud  ?:(=(%desks kind.req) (lent desks.value) (lent rows.value))
  ?.  ?:(=(%desks kind.req) &(=(~ rows.value) (lte total.value 1.024)) =(~ desks.value))  %.n
  ?.  (lte count (sub total.value (min total.value start.value)))  %.n
  ?~  next.value  %.y
  ?&  =(count max-rows)  =(u.next.value (add start.value count))
      (lth u.next.value total.value)  (lte (met 0 u.next.value) 64)
  ==
++  paths
  |=  [our=@p sup=(map duct [who=@p pax=path])]
  ^-  (list path)
  =/  found=(list path)
    %+  murn  ~(val by sup)
    |=  [who=@p pax=path]
    ^-  (unit path)
    ?.  &(=(our who) ?=(^ (route pax)))  ~
    `pax
  ~(tap in (silt found))
++  admit
  |=  [pax=path wanted=(list path)]
  ^-  ?
  &(?=(^ (route pax)) (lte (lent wanted) 32))
++  desired
  |=  b=bowl:gall
  ^-  watching
  =/  names=(set @tas)  .^((set @tas) %cd ~[(scot %p our.b) '' (scot %da now.b)])
  %-  silt
  %+  murn  (paths our.b sup.b)
  |=  pax=path
  ^-  (unit @tas)
  =/  req  (need (route pax))
  ?:  =(%desks kind.req)  ~
  ?.  (~(has in names) desk.req)  ~
  `desk.req
++  wire-for
  |=  desk=@tas
  ^-  wire
  /readymade-projects/[desk]
++  watch
  |=  [b=bowl:gall desk=@tas]
  ^-  card:agent:gall
  [%pass (wire-for desk) %arvo %c %warp our.b desk `[%next %z [%ud (rev:cv our.b desk)] /]]
++  reconcile
  |=  [b=bowl:gall previous=watching]
  ^-  [cards=(list card:agent:gall) watching=watching]
  (reconcile-desks b previous (desired b))
++  reconcile-desks
  |=  [b=bowl:gall previous=watching next=watching]
  ^-  [cards=(list card:agent:gall) watching=watching]
  =/  removed=(list @tas)  ~(tap in (~(dif in previous) next))
  =/  added=(list @tas)  ~(tap in (~(dif in next) previous))
  =/  canceled=(list card:agent:gall)
    (turn removed |=(desk=@tas `card:agent:gall`[%pass (wire-for desk) %arvo %c %warp our.b desk ~]))
  [(weld canceled (turn added |=(desk=@tas (watch b desk)))) next]
++  facts
  |=  b=bowl:gall
  ^-  (list card:agent:gall)
  %+  turn  (paths our.b sup.b)
  |=  pax=path
  [%give %fact ~[pax] %noun !>((project b (need (route pax))))]
++  wake
  |=  [wire=wire sign=sign-arvo]
  ^-  (unit @tas)
  ?.  ?=([%readymade-projects @ ~] wire)  ~
  ?.  ?=([%clay %writ *] sign)  ~
  ?.  (desk-valid i.t.wire)  ~
  `i.t.wire
++  changed
  |=  [b=bowl:gall desk=@tas]
  ^-  (list card:agent:gall)
  =/  wanted=(list path)
    %+  skim  (paths our.b sup.b)
    |=  pax=path
    =/  req=request  (need (route pax))
    |(=(%desks kind.req) =(desk desk.req))
  ?~  wanted  ~
  =/  facts=(list card:agent:gall)
    %+  turn  wanted
    |=  pax=path
    [%give %fact ~[pax] %noun !>((project b (need (route pax))))]
  ?.  (~(has in (desired b)) desk)  facts
  (snoc facts (watch b desk))
::  Fixed owner-only HTTP reads. These never call the legacy unbounded text arm.
+$  task-request
  $%  [%bad ~]
      [%desks start=@ud]
      [%tree desk=@tas revision=@ud start=@ud]
      [%file desk=@tas revision=@ud lobe=@uv pax=path]
  ==
++  task-number
  |=  value=@t
  ^-  (unit @ud)
  ?.  (lte (met 3 value) 26)  ~
  =/  n=(unit @ud)  (slaw %ud value)
  ?~  n  ~
  ?.  &((lte (met 0 u.n) 64) =(value (scot %ud u.n)))  ~
  n
++  task-lobe
  |=  value=@t
  ^-  (unit @uv)
  ?.  (lte (met 3 value) 64)  ~
  =/  n=(unit @uv)  (slaw %uv value)
  ?~  n  ~
  ?.  &(!=(0 u.n) (lte (met 0 u.n) 256) =(value (scot %uv u.n)))  ~
  n
++  task-path
  |=  url=@t
  ^-  (unit task-request)
  =/  prefix=@t  '/apps/pataphor/clay/tasks/'
  ?.  &((gte (met 3 url) (met 3 prefix)) =(prefix (end [3 (met 3 prefix)] url)))  ~
  ?:  (gth (met 3 url) 1.024)  `[%bad ~]
  =/  suffix=@t  (cat 3 '/' (rsh [3 (met 3 prefix)] url))
  =/  parsed=(unit path)  (rush suffix stap)
  ?~  parsed  `[%bad ~]
  ?.  =(suffix (spat u.parsed))  `[%bad ~]
  =/  pax=path  u.parsed
  ?+  pax  `[%bad ~]
    [%desks @ ~]
      =/  n  (task-number i.t.pax)
      ?~  n  `[%bad ~]
      `[%desks u.n]
    [%tree @ @ @ ~]
      ?.  (desk-valid i.t.pax)  `[%bad ~]
      =/  revision  (task-number i.t.t.pax)
      =/  start  (task-number i.t.t.t.pax)
      ?~  revision  `[%bad ~]
      ?~  start  `[%bad ~]
      `[%tree i.t.pax u.revision u.start]
    [%file @ @ @ ^]
      ?.  &((desk-valid i.t.pax) (path-valid t.t.t.t.pax))  `[%bad ~]
      =/  revision  (task-number i.t.t.pax)
      =/  lobe  (task-lobe i.t.t.t.pax)
      ?~  revision  `[%bad ~]
      ?~  lobe  `[%bad ~]
      `[%file i.t.pax u.revision u.lobe t.t.t.t.pax]
  ==
++  task-base
  |=  [our=@p kind=@t problem=(unit @t)]
  ^-  (list [@t json])
  :~  ['schema' s+'readymade-desk-tasks-v1']
      ['owner' s+(scot %p our)]
      ['scope' s+'owner-clay-read']
      ['kind' s+kind]
      ['problem' ?~(problem ~ s+u.problem)]
  ==
++  task-error
  |=  [our=@p status=@ud problem=@t]
  ^-  [status=@ud body=@t]
  [status (en:json:html (pairs:enjs:format (task-base our 'error' `problem)))]
++  task-names
  |=  names=(set @tas)
  ^-  [names=(list @tas) omitted=@ud]
  =/  kept=(list @tas)  (sort (skim ~(tap in names) desk-valid) aor)
  [kept (sub ~(wyt in names) (lent kept))]
++  task-pagination
  |=  [start=@ud count=@ud total=@ud omitted=@ud]
  ^-  (list [@t json])
  :~  ['cursor' s+(scot %ud start)]
      ['next' ?:(=(0 count) ~ ?:((lth (add start count) total) s+(scot %ud (add start count)) ~))]
      ['total' s+(scot %ud total)]
      ['omitted' s+(scot %ud omitted)]
      ['warning' ?:(=(0 omitted) ~ s+'Unsupported native names or paths were omitted.')]
  ==
++  task-desks-json
  |=  [our=@p start=@ud total=@ud omitted=@ud entries=(list catalog)]
  ^-  json
  %-  pairs:enjs:format
  %+  weld  (task-base our 'desks' ~)
  %+  weld  (task-pagination start (lent entries) total omitted)
  ^-  (list [@t json])
  :_  ~
  :-  'desks'
  :-  %a
  %+  turn  entries
  |=  item=catalog
  (pairs:enjs:format ~[['desk' s+desk.item] ['revision' s+(scot %ud revision.item)]])
++  task-supported
  |=  files=(map path lobe:clay)
  ^-  (map path lobe:clay)
  %-  malt
  %+  skim  ~(tap by files)
  |=  item=row
  &((path-valid pax.item) !=(0 lobe.item) (lte (met 0 lobe.item) 256))
++  task-tree-json
  |=  [our=@p desk=@tas revision=@ud start=@ud files=(map path lobe:clay)]
  ^-  json
  =/  kept=(map path lobe:clay)  (task-supported files)
  =/  entries=(list row)  (page kept start)
  =/  total=@ud  ~(wyt by kept)
  %-  pairs:enjs:format
  %+  weld  (task-base our 'tree' ~)
  %+  weld  (task-pagination start (lent entries) total (sub ~(wyt by files) total))
  ^-  (list [@t json])
  :~  ['desk' s+desk]
      ['revision' s+(scot %ud revision)]
      :-  'files'
      :-  %a
      %+  turn  entries
      |=  item=row
      (pairs:enjs:format ~[['path' s+(spat pax.item)] ['lobe' s+(scot %uv lobe.item)]])
  ==
++  task-utf8
  ::  RFC3629 byte bounds, including control characters; never UTF8-normalize.
  |=  text=@t
  ^-  ?
  ?.  (lte (met 3 text) max-text)  %.n
  =/  size=@ud  (met 3 text)
  =/  position=@ud  0
  =/  pending=@ud  0
  =/  lower=@ud  128
  =/  upper=@ud  191
  |-  ^-  ?
  ?:  =(position size)  =(0 pending)
  =/  byte=@ud  (cut 3 [position 1] text)
  =/  step=@ud  +(position)
  ?:  (gth pending 0)
    ?.  &((gte byte lower) (lte byte upper))  %.n
    $(position step, pending (dec pending), lower 128, upper 191)
  ?:  (lte byte 127)  $(position step)
  ?:  &((gte byte 194) (lte byte 223))  $(position step, pending 1)
  ?:  =(byte 224)  $(position step, pending 2, lower 160)
  ?:  |(&((gte byte 225) (lte byte 236)) &((gte byte 238) (lte byte 239)))
    $(position step, pending 2)
  ?:  =(byte 237)  $(position step, pending 2, upper 159)
  ?:  =(byte 240)  $(position step, pending 3, lower 144)
  ?:  &((gte byte 241) (lte byte 243))  $(position step, pending 3)
  ?:  =(byte 244)  $(position step, pending 3, upper 143)
  %.n
++  task-wain
  ::  Count every cord and inter-line LF before conversion. At most65537 lines.
  |=  raw=*
  ^-  (each wain @tas)
  =/  todo=*  raw
  =/  lines=@ud  0
  =/  bytes=@ud  0
  =/  out=wain  ~
  |-  ^-  (each wain @tas)
  ?:  =(~ todo)  [%& (flop out)]
  ?.  ?=([@ *] todo)  [%| %not-text]
  ?:  (gte lines (add max-text 1))  [%| %text-too-large]
  =/  count=@ud  (add bytes (add (met 3 -.todo) ?:(=(0 lines) 0 1)))
  ?:  (gth count max-text)  [%| %text-too-large]
  ?.  (task-utf8 `@t`-.todo)  [%| %invalid-utf8]
  $(todo +.todo, lines +(lines), bytes count, out [`@t`-.todo out])
++  task-text
  |=  raw=*
  ^-  (each [format=?(%raw %wain) source=@t] @tas)
  =/  text-kind=?(%raw %wain)  ?:(?=(@ raw) %raw %wain)
  =/  text=(each @t @tas)
    ?@  raw
      ?:  (gth (met 3 raw) max-text)  [%| %text-too-large]
      [%& `@t`raw]
    =/  lines=(each wain @tas)  (task-wain raw)
    ?:  ?=(%| -.lines)  [%| p.lines]
    [%& (of-wain:format p.lines)]
  ?:  ?=(%| -.text)  [%| p.text]
  ?.  (task-utf8 p.text)  [%| %invalid-utf8]
  [%& [text-kind p.text]]
++  task-file-json
  |=  [our=@p desk=@tas revision=@ud lobe=@uv pax=path raw=*]
  ^-  [status=@ud body=@t]
  =/  text  (task-text raw)
  ?:  ?=(%| -.text)
    (task-error our ?:(=(%text-too-large p.text) 413 415) 'File is not supported UTF-8 text within the 65536-byte limit.')
  :-  200
  %-  en:json:html
  %-  pairs:enjs:format
  %+  weld  (task-base our 'file' ~)
  ^-  (list [@t json])
  :~  ['desk' s+desk]
      ['revision' s+(scot %ud revision)]
      ['path' s+(spat pax)]
      ['lobe' s+(scot %uv lobe)]
      ['digest' s+(scot %ux (shax source.p.text))]
      ['bytes' s+(scot %ud (met 3 source.p.text))]
      ['format' s+(scot %tas format.p.text)]
      ['source' s+source.p.text]
      ['writable' b+%.n]
  ==
++  task-files-at
  |=  [our=@p desk=@tas revision=@ud]
  ^-  (map path lobe:clay)
  ?:  =(0 revision)  ~
  =/  at=path  /(scot %p our)/[desk]/(scot %ud revision)
  =/  commit=tako:clay  .^(tako:clay %cs (weld at /tako/now))
  q:.^(yaki:clay %cs (weld at /yaki/(scot %uv commit)))
++  task-binding
  |=  [expected=@ud current=@ud wanted=@uv actual=(unit lobe:clay)]
  ^-  ?
  ?&  =(expected current)
      ?~(actual %.n =(wanted u.actual))
  ==
++  task-valid
  |=  req=task-request
  ^-  ?
  ?:  ?=(%bad -.req)  %.n
  ?:  ?=(%desks -.req)  (lte (met 0 start.req) 64)
  ?>  ?=(?(%tree %file) -.req)
  ?.  &((desk-valid desk.req) (lte (met 0 revision.req) 64))  %.n
  ?:  ?=(%tree -.req)  (lte (met 0 start.req) 64)
  ?>  ?=(%file -.req)
  &((path-valid pax.req) !=(0 lobe.req) (lte (met 0 lobe.req) 256))
++  serve-task
  |=  [b=bowl:gall req=task-request]
  ^-  [status=@ud body=@t]
  ?.  =(our.b src.b)  (task-error our.b 403 'Only the owner may read native Clay files.')
  ?.  (task-valid req)  (task-error our.b 400 'Malformed native Clay read route.')
  =/  names=(set @tas)  .^((set @tas) %cd ~[(scot %p our.b) '' (scot %da now.b)])
  ?:  (gth ~(wyt in names) 1.024)  (task-error our.b 413 'Desk catalog exceeds 1024 names.')
  ?:  ?=(%desks -.req)
    =/  kept  (task-names names)
    =/  entries=(list catalog)
      %+  turn  (scag max-rows (slag start.req names.kept))
      |=  name=@tas
      [name (rev:cv our.b name)]
    [200 (en:json:html (task-desks-json our.b start.req (lent names.kept) omitted.kept entries))]
  ?>  ?=(?(%tree %file) -.req)
  ?.  (desk-valid desk.req)  (task-error our.b 400 'Unsupported desk name.')
  ?.  (~(has in names) desk.req)  (task-error our.b 404 'The selected desk is absent.')
  =/  current=@ud  (rev:cv our.b desk.req)
  ?.  =(current revision.req)  (task-error our.b 409 'Desk revision changed; request a fresh listing.')
  =/  files=(map path lobe:clay)  (task-files-at our.b desk.req revision.req)
  ?:  (gth ~(wyt by files) 20.000)  (task-error our.b 413 'Desk exceeds 20000 files.')
  ?:  ?=(%tree -.req)
    [200 (en:json:html (task-tree-json our.b desk.req revision.req start.req files))]
  ?>  ?=(%file -.req)
  ?.  (path-valid pax.req)  (task-error our.b 400 'Unsupported native path.')
  ?.  (task-binding revision.req current lobe.req (~(get by files) pax.req))
    (task-error our.b 409 'File lobe changed or path is absent; request a fresh listing.')
  =/  at=path  (weld /(scot %p our.b)/[desk.req]/(scot %ud revision.req) pax.req)
  ?.  .^(? %cu at)  (task-error our.b 404 'The selected pinned file is unavailable.')
  (task-file-json our.b desk.req revision.req lobe.req pax.req .^(* %cq at))
++  prove
  =/  source=(map path lobe:clay)
    %-  malt
    ^-  (list row)
    :~  [/lib/valid/hoon 0v1]
        [~['' %lib %invalid %hoon] 0v2]
    ==
  =/  browse=(map path lobe:clay)  (supported source)
  ?>  =(1 ~(wyt by browse))
  ?>  =(`0v1 (~(get by browse) /lib/valid/hoon))
  ?>  =(~[[/lib/valid/hoon 0v1]] (page browse 0))
  ?>  =(~ (page browse 1))
  ?>  =('one\0atwo' (of-wain:format (to-wain:format 'one\0atwo')))
  ?>  =('one\0atwo' (of-wain:format (to-wain:format 'one\0atwo\0a')))
  ?>  =('one\0atwo\0a' (of-wain:format ~['one' 'two' '']))
  ?>  ?=(~ (route ~[%projects %tree %repo '01']))
  ?>  ?=(~ (pathname '/lib/../hoon'))
  ?>  ?=(^ (route /projects/file/flunky/lib/test/hoon))
  =/  req=request  [%file %flunky 0 /lib/test/hoon]
  =/  seed=snapshot  (empty ~zod req)
  =.  file.seed  `[/lib/test/hoon 0v1 5 %raw `'hello' (shax 'hello') %.y]
  ?>  (valid ~zod req seed)
  ?>  !(valid ~nec req seed)
  ?>  !(valid ~zod req seed(file `[/lib/other/hoon 0v1 5 %raw `'hello' (shax 'hello') %.y]))
  ?>  !(valid ~zod req seed(next `1))
  ?>  !(valid ~zod req seed(file `[/lib/test/hoon 0v1 6 %raw `'hello' (shax 'hello') %.y]))
  ?>  (valid ~zod req seed(file `[/lib/test/hoon 0v1 65.537 %raw ~ 0x1 %.n]))
  ?>  !(valid ~zod req seed(file `[/lib/test/hoon 0v1 65.537 %raw ~ 0x1 %.y]))
  =/  unicode=@t  '🧩'
  ?>  (valid ~zod req seed(file `[/lib/test/hoon 0v1 4 %raw `unicode (shax unicode) %.y]))
  =/  files=(map path lobe:clay)
    %-  malt
    %+  turn  (gulf 1 70)
    |=(n=@ud [/(scot %ud n)/txt `@uv`n])
  ?>  =(64 (lent (page files 0)))
  ?>  =(6 (lent (page files 64)))
  ?>  =(~ (page files 70))
  =/  tree-req=request  [%tree %flunky 0 ~]
  =/  head=snapshot  (empty ~zod tree-req)
  =.  head  head(total 70, rows (page files 0), next `64)
  ?>  (valid ~zod tree-req head)
  ?>  !(valid ~zod tree-req head(next `63))
  ?>  (valid ~zod tree-req(start 64) head(start 64, rows (page files 64), next ~))
  ?>  (valid ~zod tree-req(start 70) head(start 70, rows ~, next ~))
  %readymade-projects-proof-v1
--
