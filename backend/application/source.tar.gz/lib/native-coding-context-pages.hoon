::  Select original current-revision read pages; no source reads or authority.
/-  nc=native-coding
/+  project=native-coding-project, sessions=native-coding-session,
    files=native-coding-files
|%
+$  page  [record=record:sessions value=file-read:nc priority=@ud]
++  rank
  |=  [p=project:nc pax=path]
  ^-  (unit @ud)
  ?.  (readable:project p pax)  ~
  ?:  (writable:project p pax)  `0
  ?:  (covered:project protected.policy.p pax)  `1
  ?:  (lien targets.p |=(t=build-target:nc |(=(pax entry.t) (lien dependencies.t |=(d=path =(pax d))))))  `1
  ::  Policy v3 (2026-10-12): any other readable current-source page ranks
  ::  last. It is retained only after every writable and protected page and
  ::  only while the unchanged packet budget allows. Before this tier such
  ::  reads were dropped at every compaction, so a model that reads the
  ::  libraries its patch must match forgot them each turn and reread them
  ::  (measured on the v3 session: 24 turns, 62 reads, zero proposals).
  `2
++  eligible
  |=  [p=project:nc e=entry:sessions r=record:sessions]
  ^-  (unit page)
  ?.  ?=(%tool -.body.r)  ~
  =/  result=tool-result:nc  result.body.r
  ?.  ?=(%read -.output.result)  ~
  =/  ctx=context:nc  context.result
  ?.  ?&  =(source.ctx working.session.e)
          =(configuration.ctx configuration.e)
          =((configuration:project p) configuration.ctx)
          =(session.ctx id.session.e)  =(actor.ctx owner.session.e)
          =(project.ctx id.spec.p)  =(project.ctx project.session.e)
      ==  ~
  =/  f=file-read:nc  value.output.result
  =/  priority  (rank p pax.f)
  ?~  priority  ~
  ?.  &((gth blob.f 0) (lte (met 0 blob.f) 256) (gth start.f 0) (lte start.f total.f) (lte (met 3 text.f) 16.384))  ~
  =/  end=@ud  (fall next.f +(total.f))
  ?.  &((gth end start.f) (lte end +(total.f)) =((sub end start.f) (lent (lines:files text.f))))  ~
  `[r f u.priority]
++  through
  |=  f=file-read:nc
  ^-  @ud
  (dec (fall next.f +(total.f)))
++  covered-page
  ::  Only newer originals with the same blob may cover an older range.
  ::  Keep partial overlaps intact; never synthesize or clip source bytes.
  |=  [f=file-read:nc newer=(list page)]
  ^-  ?
  =/  cursor=@ud  start.f
  =/  end=@ud  (through f)
  |-  ^-  ?
  ?:  (gth cursor end)  %.y
  =/  advance=@ud
    %+  roll  newer
    |=  [p=page n=@ud]
    =/  other=file-read:nc  value.p
    ?.  =(pax.f pax.other)  n
    ?.  &(=(blob.f blob.other) =(total.f total.other))  n
    ?.  &((lte start.other cursor) (gte (through other) cursor))  n
    (max n +((through other)))
  ?:  =(cursor advance)  %.n
  $(cursor advance)
++  select
  ::  Newest coverage wins, including coverage across adjacent pages.
  ::  Consumers still budget every whole page and report partial coverage.
  |=  [p=project:nc e=entry:sessions]
  ^-  (list page)
  =/  todo=(list record:sessions)  (flop records.e)
  =/  found=(map [path @ux @ud @ud] page)  ~
  =/  selected=(list page)
    |-  ^-  (list page)
    ?~  todo  ~(val by found)
    =/  next  (eligible p e i.todo)
    ?~  next  $(todo t.todo)
    =/  f=file-read:nc  value.u.next
    =/  key=[path @ux @ud @ud]  [pax.f blob.f start.f (through f)]
    ?:  (covered-page f ~(val by found))  $(todo t.todo)
    $(todo t.todo, found (~(put by found) key u.next))
  %+  sort  selected
  |=  [a=page b=page]
  ?:  !=(priority.a priority.b)  (lth priority.a priority.b)
  ?:  !=(pax.value.a pax.value.b)  (gor pax.value.a pax.value.b)
  ?:  !=(start.value.a start.value.b)  (lth start.value.a start.value.b)
  (gth sequence.record.a sequence.record.b)
--
