::  Cross-job reuse of complete compiler inputs at the SAME full revision.
::  No execution, new execution receipt, installation, or passing check. The
::  owning Cantrip scry supplies its canonical organs. Clay reads are finite;
::  malformed selected evidence refuses instead of silently compiling again.
/-  nc=native-coding
/+  compiler=native-coding-compiler, exports=native-coding-compiler-exports,
    er=native-coding-compiler-exports-runtime, es=native-coding-compiler-exports-store,
    attachment=native-coding-compiler-attachment,
    ar=native-coding-compiler-attachment-runtime, ast=native-coding-compiler-attachment-store,
    assembly=native-coding-terminal-assembly, profile=native-coding-compiler-profile,
    tools=cantrip-native-coding, project=native-coding-project
|%
+$  origin
  $%  [%exports value=retained:er]
      [%attachment value=retained:ar]
  ==
+$  location
  $%  [%hot ~]
      [%archive revision=revision:nc pax=path blob=lobe:clay]
  ==
+$  hit
  [%native-coding-compiler-reuse-v1 producer=@ux receipt=@ux closure=@ux location=location original=origin]
+$  route
  $%  [%exports seed=@ux profile=@ux fuel=@ud selection=selection:exports]
      [%attachment attachment=@ux profile=@ux fuel=@ud selection=selection:exports]
  ==
++  input
  |=  o=origin
  ^-  job:compiler
  ?-  -.o
    %exports  input.value.o
    %attachment  input.value.o
  ==
++  selection
  |=  o=origin
  ^-  selection:exports
  ?-  -.o
    %exports  selection.value.o
    %attachment  selection.value.o
  ==
++  receipt-id
  |=  o=origin
  ^-  @ux
  ?-  -.o
    %exports  (shax (jam value.o))
    %attachment  (shax (jam value.o))
  ==
++  original-report
  |=  o=origin
  ^-  tool-output:nc
  ?-  -.o
    %exports  (report:er value.o)
    %attachment  (report:ar value.o)
  ==
++  original-valid
  |=  [id=@ux o=origin]
  ^-  ?
  ?-  -.o
    %exports  (retained-valid:er id value.o)
    %attachment  (retained-valid:ar id value.o)
  ==
++  succeeded
  |=  o=origin
  ^-  ?
  ?-  -.o
    %exports  ?=(%& -.output.value.o)
    %attachment  ?=(%& -.output.value.o)
  ==
++  subject
  ::  Versioned exact input data, not a hash-only cache hit. Includes owner,
  ::  desk, number, root/commit, project configuration and resolved names.
  |=  j=job:compiler
  ^-  (each * @tas)
  =/  named  (named-sources:compiler j)
  ?:  ?=(%| -.named)  [%| p.named]
  [%& [%native-coding-compiler-reuse-input-v1 source.context:(job-request:compiler j) (job-project:compiler j) (job-target:compiler j) (job-module:compiler j) (job-sources:compiler j) p.named ?:(?=(%native-coding-compiler-job-v2 -.j) `mapping.j ~)]]
++  hit-valid
  ::  Pure structural/input consistency. Canonical origin requires read below.
  |=  [j=job:compiler h=hit]
  ^-  ?
  =/  old=job:compiler  (input original.h)
  ?.  &((lte (met 3 (jam h)) 4.300.000) !=(producer.h (key:tools (job-request:compiler j))) =(producer.h (key:tools (job-request:compiler old))) (original-valid producer.h original.h) (succeeded original.h) =(receipt.h (receipt-id original.h)))  %.n
  =/  wanted  (subject j)
  =/  previous  (subject old)
  ?.  &(?=(%& -.wanted) ?=(%& -.previous) =(p.wanted p.previous) =(closure.h (shax (jam p.wanted))))  %.n
  =/  selected  (inputs:exports j (selection original.h))
  ?.  ?=(%& -.selected)  %.n
  ?:  ?=(%hot -.location.h)  %.y
  ?.  (revision-valid:project revision.location.h)  %.n
  ?-  -.original.h
    %exports
      =/  r=retained:er  value.original.h
      &(=(pax.location.h (path-for:es (reference-of:es r))) =(blob.location.h (page-to-lobe:clay [%noun r])))
    %attachment
      =/  r=retained:ar  value.original.h
      &(=(pax.location.h (path-for:ast (reference-of:ast r))) =(blob.location.h (page-to-lobe:clay [%noun r])))
  ==
++  matches
  |=  [expected=route o=origin]
  ^-  ?
  ?:  ?=(%exports -.expected)
    ?.  ?=(%exports -.o)  %.n
    &(=(seed.expected seed.value.o) =(profile.expected profile.value.o) =(fuel.expected fuel.value.o) =(selection.expected selection.value.o))
  ?.  ?=(%attachment -.o)  %.n
  &(=(attachment.expected attachment.value.o) =(profile.expected profile.value.o) =(fuel.expected fuel.value.o) =(selection.expected selection.value.o))
++  consider
  |=  [j=job:compiler jobs=organ:tools expected=route id=@ux o=origin where=location]
  ^-  (each (unit hit) @tas)
  ?:  =(id (key:tools (job-request:compiler j)))  [%& ~]
  ?.  (original-valid id o)  [%| %compiler-reuse-origin-invalid]
  ?.  &((matches expected o) (succeeded o))  [%& ~]
  =/  old=job:compiler  (input o)
  =/  wanted  (subject j)
  =/  previous  (subject old)
  ?.  &(?=(%& -.wanted) ?=(%& -.previous))  [%| %compiler-reuse-input-invalid]
  ?.  =(p.wanted p.previous)  [%& ~]
  =/  found  (~(get by records.jobs) id)
  ?~  found  [%| %compiler-reuse-job-missing]
  ?.  =(%finished stage.u.found)  [%& ~]
  =/  linked=?
    ?-  -.o
      %exports  (linked:er jobs id value.o)
      %attachment  (linked:ar jobs id value.o)
    ==
  =/  r=tool-request:nc  (job-request:compiler old)
  =/  result=tool-result:nc
    [%native-coding-tool-result-v1 context.r call-id.r (original-report o)]
  ?.  &(linked =(request.u.found r) =(`result result.u.found))
    [%| %compiler-reuse-producer-not-confirmed]
  =/  h=hit
    [%native-coding-compiler-reuse-v1 id (receipt-id o) (shax (jam p.wanted)) where o]
  ?:((hit-valid j h) [%& `h] [%| %compiler-reuse-hit-invalid])
++  eligible
  ::  Archive references lack full compiler inputs. Restrict actual page reads
  ::  by exact revision and canonical finished job/target/project first.
  |=  [j=job:compiler jobs=organ:tools id=@ux source=revision:nc]
  ^-  ?
  ?.  &(!=(id (key:tools (job-request:compiler j))) =(source source.context:(job-request:compiler j)))  %.n
  =/  found  (~(get by records.jobs) id)
  ?~  found  %.n
  =/  r=tool-request:nc  request.u.found
  ?.  &(=(%finished stage.u.found) ?=(?(%compile %check) -.arguments.r) =(source source.context.r) =(target.arguments.r name:(job-target:compiler j)))  %.n
  =/  grant  (~(get by grants.jobs) grant.u.found)
  ?~  grant  %.n
  =((job-project:compiler j) project.grant.u.grant)
++  find-exports
  |=  [our=@p now=@da jobs=organ:tools held=organ:er archives=organ:es seed=seed:assembly j=job:compiler selected=selection:exports fuel=@ud]
  ^-  (each (unit hit) @tas)
  ?.  (valid:er our held `seed jobs)  [%| %compiler-reuse-exports-invalid]
  ?:  (gth ~(wyt by records.archives) 128)  [%| %compiler-reuse-archive-capacity]
  =/  expected=route  [%exports digest.seed identity:profile fuel selected]
  =/  rows=(list [id=@ux value=retained:er])  ~(tap by results.held)
  =/  hot=(each (unit hit) @tas)
    |-  ^-  (each (unit hit) @tas)
    ?~  rows  [%& ~]
    =/  rest=(list [id=@ux value=retained:er])  t.rows
    =/  checked  (consider j jobs expected id.i.rows [%exports value.i.rows] [%hot ~])
    ?:  ?=(%| -.checked)  checked
    ?^  p.checked  checked
    $(rows rest)
  ?:  ?=(%| -.hot)  hot
  ?^  p.hot  hot
  =/  rows=(list [@ux entry:es])  ~(tap by records.archives)
  =/  left=@ud  16
  |-  ^-  (each (unit hit) @tas)
  ?~  rows  [%& ~]
  =/  rest=(list [@ux entry:es])  t.rows
  =/  [id=@ux e=entry:es]  i.rows
  ?.  &(=(%confirmed phase.e) (eligible j jobs id source.ref.e))  $(rows rest)
  ?.  &(=(id job.ref.e) =(pax.e (path-for:es ref.e)) ?=(^ saved.e))
    [%| %compiler-reuse-archive-invalid]
  ?:  =(0 left)  [%| %compiler-reuse-archive-budget]
  =/  page  (exact:es our now e jobs)
  ?:  ?=(%| -.page)  [%| p.page]
  =/  checked
    (consider j jobs expected id [%exports p.page] [%archive u.saved.e pax.e blob.e])
  ?:  ?=(%| -.checked)  checked
  ?^  p.checked  checked
  $(rows rest, left (dec left))
++  find-attachment
  |=  [our=@p now=@da jobs=organ:tools held=organ:ar archives=organ:ast j=job:compiler chosen=choice:ar profile=@ux fuel=@ud]
  ^-  (each (unit hit) @tas)
  ?.  (valid:ar our held jobs)  [%| %compiler-reuse-attachments-invalid]
  ?:  (gth ~(wyt by records.archives) 128)  [%| %compiler-reuse-archive-capacity]
  =/  expected=route  [%attachment attachment.chosen profile fuel selection.chosen]
  =/  rows=(list [id=@ux value=retained:ar])  ~(tap by results.held)
  =/  hot=(each (unit hit) @tas)
    |-  ^-  (each (unit hit) @tas)
    ?~  rows  [%& ~]
    =/  rest=(list [id=@ux value=retained:ar])  t.rows
    =/  checked  (consider j jobs expected id.i.rows [%attachment value.i.rows] [%hot ~])
    ?:  ?=(%| -.checked)  checked
    ?^  p.checked  checked
    $(rows rest)
  ?:  ?=(%| -.hot)  hot
  ?^  p.hot  hot
  =/  rows=(list [@ux entry:ast])  ~(tap by records.archives)
  =/  left=@ud  16
  |-  ^-  (each (unit hit) @tas)
  ?~  rows  [%& ~]
  =/  rest=(list [@ux entry:ast])  t.rows
  =/  [id=@ux e=entry:ast]  i.rows
  ?.  &(=(%confirmed phase.e) (eligible j jobs id source.ref.e))  $(rows rest)
  ?.  &(=(id job.ref.e) =(pax.e (path-for:ast ref.e)) ?=(^ saved.e))
    [%| %compiler-reuse-archive-invalid]
  ?:  =(0 left)  [%| %compiler-reuse-archive-budget]
  =/  page  (exact:ast our now e held jobs)
  ?:  ?=(%| -.page)  [%| p.page]
  =/  checked
    (consider j jobs expected id [%attachment p.page] [%archive u.saved.e pax.e blob.e])
  ?:  ?=(%| -.checked)  checked
  ?^  p.checked  checked
  $(rows rest, left (dec left))
++  read
  ::  Owning Cantrip invokes this with its saved organs. No mutation or cards.
  ::  compiler.prepare's mapping scry terminates at Cantrip's existing mapping
  ::  projection; no reuse result is an input to that canonical source reader.
  |=  [our=@p now=@da jobs=organ:tools attachments=organ:ar attachment-archive=organ:ast compiled=organ:er exports-archive=organ:es seed=(unit seed:assembly) id=@ux]
  ^-  (each (unit hit) @tas)
  ?.  (valid:tools our jobs)  [%| %compiler-reuse-tool-state-invalid]
  =/  found  (~(get by records.jobs) id)
  ?~  found  [%| %compiler-reuse-current-job-missing]
  =/  r=tool-request:nc  request.u.found
  ?.  &(=(id (key:tools r)) =(%running stage.u.found))
    [%| %compiler-reuse-current-job-not-running]
  =/  scope  (~(get by grants.jobs) grant.u.found)
  ?~  scope  [%| %compiler-reuse-current-grant-missing]
  =/  allowed  (allowed:tools our now u.scope r)
  ?:  ?=(%| -.allowed)  [%| p.allowed]
  ?.  (pending:tools our now r)  [%| %compiler-reuse-current-not-pending]
  =/  prepared  (prepare:compiler our now project.grant.u.scope r)
  ?:  ?=(%| -.prepared)  [%| p.prepared]
  =/  j=job:compiler  p.prepared
  =/  chosen  (lookup:ar attachments j)
  ?^  chosen
    ?:  ?=(%| -.u.chosen)  [%| p.u.chosen]
    =/  executable  (~(get by attachments.attachments) attachment.p.u.chosen)
    ?~  executable  [%| %compiler-reuse-attachment-missing]
    =/  input  (inputs:attachment u.executable j selection.p.u.chosen)
    ?:  ?=(%| -.input)  [%| p.input]
    (find-attachment our now jobs attachments attachment-archive j p.u.chosen profile-id-v2:attachment fuel-v2:attachment)
  =/  selected  (lookup:er compiled j)
  ?~  selected  [%& ~]
  ?:  ?=(%| -.u.selected)  [%| p.u.selected]
  ?~  seed  [%| %compiler-reuse-seed-missing]
  ?.  &((seed-valid:assembly u.seed) (profiled-seed:assembly u.seed))
    [%| %compiler-reuse-seed-invalid]
  =/  input  (inputs:exports j p.u.selected)
  ?:  ?=(%| -.input)  [%| p.input]
  (find-exports our now jobs compiled exports-archive u.seed j p.u.selected 2.000.000)
++  report
  ::  The original receipt remains attributed to its producer. This new tool
  ::  result records reuse only, with current source and both identities.
  |=  [j=job:compiler h=hit]
  ^-  tool-output:nc
  ?.  (hit-valid j h)
    [%refused %compiler-reuse-invalid 'The compiler reuse evidence does not match this input.']
  [%diagnostics ~[[%gallowglass %.n 'Reused original native compiler output for an identical full revision, source/dependency closure and selection. No new compilation, passing check or installation is claimed.' source.context:(job-request:compiler j) ~[(identity:compiler j) producer.h receipt.h closure.h (shax (jam h))]]]]
--
