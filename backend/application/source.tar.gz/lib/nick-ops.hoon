::  /lib/nick-ops.hoon
::
::  NICK'S OPERATOR VOCABULARY (S4). The corpus IS Nick's operator library. Each
::  operator carries an honest status class -- computed / advisory / symbolic --
::  and the CITE cascade makes the honesty discipline a RUNTIME LAW of the
::  language: a model may NAME any operator (steering/annotation), but may only
::  EXECUTE a computed one. Citing an advisory or symbolic operator for
::  computation is refused %not-computed -- the same fraud-guard the QPC referee
::  enforces (lib/qpc-world class-of), now for the whole language. Advisory
::  operators are promoted to computed only when an evaluator + proof exist.
::
=,  si
|%
+$  nop        @tas                                  ::  a Nick operator name
+$  nclass     ?(%computed %advisory %symbolic)
+$  cite-code  ?(%ok %unknown-operator %not-computed)
+$  verdict    [ok=? =cite-code =nop]
::  A WARRANT: the evidence that earns an operator the right to execute.
::
::  The set used to be a hand-typed list of names with the evidence written in
::  COMMENTS -- "(lib/teleo)", "each backed by an evaluator + a green proof".
::  Nothing read those comments.  Promotion cost exactly one line, and rot was
::  invisible: `%territory` named `app/graf-core`, which DOES NOT EXIST.
::
::  So the evidence is data now.  `evaluator` is the code that computes the
::  operator; `proof` is the thread that proves the evaluator.
::
::  `proof` is a UNIT, and that is an admission rather than an omission: for
::  three operators no proof could be established, and writing `~` says so
::  where a fabricated name would have hidden it.  ph/nick-warrant-proof
::  counts them.  A missing proof is not a missing field -- it is a claim this
::  project has not yet earned.
+$  warrant
  $:  op=nop
      evaluator=path
      proof=(unit term)
  ==
::  THE WARRANTS.  Adding an operator here requires naming its evaluator; the
::  type will not accept a bare name.  That is the whole point: promotion to
::  computed is no longer free.
++  computed-warrants
  ^~  ^-  (list warrant)
  :~  [%a-ia /lib/emergenz/hoon ~]
      [%fourfold /lib/regime/hoon `%ph-regime-proof]
      [%v-teleo /lib/teleo/hoon `%ph-teleo-proof]
      [%resonance /lib/teleo/hoon `%ph-resonance-proof]
      [%trash /lib/trash-test/hoon `%ph-trash-test-proof]
      [%kappa /lib/qpc-world/hoon `%ph-qpc-world-proof]
      [%attention /lib/qpc-world/hoon `%ph-qpc-world-proof]
      [%zero-point /lib/qpc-world/hoon `%ph-qpc-world-proof]
      [%zeno /lib/zeno/hoon `%ph-zeno-proof]
      [%anti-zeno /lib/zeno/hoon `%ph-zeno-proof]
      [%double /lib/nick-eval/hoon `%ph-nick-eval-proof]
      [%negate /lib/nick-eval/hoon `%ph-nick-eval-proof]
      [%board-menu /lib/nick-board-explain/hoon ~]
      [%board-rank /lib/nick-board-explain/hoon ~]
      [%territory /lib/graf-core-engine/hoon `%ph-graf-territory-state-proof]
      ::  the SCOPED promotion (psi-eco discipline): rho-c-n is the size-derived
      ::  coupling threshold rho_c(n).  The full corpus rho_c (partition-function
      ::  form, needs Z and exp) stays advisory: computed exactly where proven.
      [%rho-c-n /lib/rho-c-derive/hoon `%ph-rho-c-derive-proof]
  ==
::  DERIVED, not typed.  Consumers still get a (set nop) and are unchanged --
::  only the source of truth moved.
++  computed-set
  ^~((silt (turn computed-warrants |=(w=warrant op.w))))
::  advisory: named + typed source math, but NO evaluator yet (do not promote).
++  advisory-set  ^~((silt `(list nop)`~[%rho-c %c-munu %z-a]))
::  everything else in the vocabulary is symbolic (ontology/correspondence).
++  vocab
  ^~  %-  silt
  ^-  (list nop)
  ;:  weld
    ~(tap in computed-set)  ~(tap in advisory-set)
    `(list nop)`~[%microvita %dharma %omega-point %arcana]
    ::  %proven-by-zk enters the vocabulary at the BOTTOM of the lattice
    ::  (program-2 step 90): named, therefore citable for steering, and
    ::  refused %not-computed the instant anything tries to execute it.
    ::  There is no prover, no cost model, and no proof artifact -- only
    ::  a word the language now knows how to refuse. It is registered
    ::  BEFORE any of that exists precisely so that the refusal is the
    ::  default, rather than a check someone remembers to add later.
    `(list nop)`~[%proven-by-zk]
  ==
++  class-of
  |=  =nop
  ^-  nclass
  ?:  (~(has in computed-set) nop)  %computed
  ?:  (~(has in advisory-set) nop)  %advisory
  %symbolic
::  THE CITE HONESTY CASCADE. `want-exec` = does the citation request computation?
::  Naming/steering (want-exec=.n) is always admissible; executing is admissible
::  only for a computed operator.
++  cite
  |=  [=nop want-exec=?]
  ^-  verdict
  ?.  (~(has in vocab) nop)          [%.n %unknown-operator nop]
  ?.  want-exec                      [%.y %ok nop]        ::  naming/steering: ok
  ?.  =(%computed (class-of nop))    [%.n %not-computed nop]
  [%.y %ok nop]
::  the a→ia self-reference rotation (Ô = ×i, a 90° rotation; period-4, Ô⁴=Ψ).
+$  psi  [re=@s im=@s]
++  a-ia  |=(p=psi ^-(psi [im.p (dif (sun 0) re.p)]))     ::  (re,im) -> (im,-re)
--
