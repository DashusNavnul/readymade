::  Viki's exact moon-source compilation and ordered check judgment.
::  No lifecycle ledger. Canonical owners retain these full values before
::  emitting effects. The compile key means proposed change, not Clay write.
/-  itn=intent, cs=vibecoding-check-spec
/+  result=glass-coding-result, protocol=vibecoding-compile-protocol,
    worker=vibecoding-compiler-runtime, image=vibecoding-local-image,
    checks=vibecoding-check-spec, generation=cantrip-glass-generation,
    editor=cantrip-editor-save, model=pataphor-editor-model,
    law=cantrip-law-window, vgc=viki-glass-coding
|%
::  Pure evidence validation is shared below this transport integration.
+$  pending  pending:result
+$  judgment  judgment:result
++  order-for  order-for:result
++  pending-valid  pending-valid:result
++  path-for
  |=  p=pending
  ^-  path
  /result/(scot %ux (digest:protocol order.p))
++  wire-for
  |=  p=pending
  ^-  wire
  /glass-coding-compile/(scot %ux (digest:protocol order.p))
++  watch
  ::  Retain pending through Viki/Graf before returning this card.
  |=  p=pending
  ^-  card:agent:gall
  ?>  (pending-valid p)
  [%pass (wire-for p) %agent [worker.order.p %vibecoding-compiler] %watch (path-for p)]
++  dispatch
  ::  Call only on acknowledged exact worker subscription. On reload, watch
  ::  retained status; do not construct a fresh order or resend implicitly.
  |=  [b=bowl:gall p=pending]
  ^-  (each card:agent:gall @tas)
  ?.  ?&  (pending-valid p)  =(our.b owner.order.p)
          =(src.b worker.order.p)  (lte at.order.p now.b)
          (lth now.b expires.order.p)
      ==  [%| %compiler-binding-invalid]
  =/  held  (~(get by wex.b) [(wire-for p) worker.order.p %vibecoding-compiler])
  ?.  =(held `[%.y (path-for p)])  [%| %compiler-watch-unconfirmed]
  [%& [%pass (wire-for p) %agent [worker.order.p %vibecoding-compiler] %poke %noun !>([%compile order.p])]]
++  evaluate  evaluate:result
++  check
  ::  This callback is usable only from the authenticated exact Gall watch.
  |=  [b=bowl:gall p=pending status=status:worker]
  ^-  (each judgment @tas)
  ?.  &((pending-valid p) =(our.b owner.order.p) =(src.b worker.order.p))
    [%| %compiler-binding-invalid]
  =/  held  (~(get by wex.b) [(wire-for p) worker.order.p %vibecoding-compiler])
  ?.  =(held `[%.y (path-for p)])  [%| %compiler-watch-unconfirmed]
  ?.  ?&  =(key.status (digest:protocol order.p))
          =(%compiled phase.status)  ?=(~ error.status)
          (lte at.order.p now.b)  (lth now.b expires.order.p)
      ==  [%| %compiler-not-completed]
  ?~  result.status  [%| %compiler-not-completed]
  ?.  ?=(%compiled -.u.result.status)  [%| %compiler-not-completed]
  =/  artifact=artifact:protocol  artifact.u.result.status
  ?.  &((matches:protocol order.p artifact) (lte at.compiler.artifact now.b))
    [%| %compiler-artifact-mismatch]
  =/  outcomes=(list check:image)  (evaluate p artifact)
  =/  decision=?(%approve-write %request-remediation)
    ?:((levy outcomes |=(c=check:image passed.c)) %approve-write %request-remediation)
  [%& [%glass-coding-judgment-v1 p artifact outcomes decision now.b]]
++  valid  judgment-valid:result
++  reject
  ::  Only an acknowledged callback from the exact owned compiler can supply
  ::  a rejection. Retain it in Viki/Graf before requesting any correction.
  |=  [b=bowl:gall p=pending status=status:worker]
  ^-  (each rejection:result @tas)
  ?.  &((pending-valid p) =(our.b owner.order.p) =(src.b worker.order.p))
    [%| %compiler-binding-invalid]
  =/  held  (~(get by wex.b) [(wire-for p) worker.order.p %vibecoding-compiler])
  ?.  =(held `[%.y (path-for p)])  [%| %compiler-watch-unconfirmed]
  ?.  ?&  =(key.status (digest:protocol order.p))
          =(%refused phase.status)  ?=(~ error.status)
      ==  [%| %compiler-rejection-unconfirmed]
  ?~  result.status  [%| %compiler-rejection-unconfirmed]
  ?.  ?=(%refused -.u.result.status)  [%| %compiler-rejection-unconfirmed]
  =/  rejected=rejection:result
    [%glass-coding-rejection-v1 p u.result.status now.b]
  ?.  (rejection-valid:result rejected)  [%| %compiler-failure-not-remediable]
  [%& rejected]
++  admit-write
  ::  Viki supplies its current intent organ and canonical current approval,
  ::  law and editor basis. Historical checks alone cannot revive authority.
  |=  $:  our=@p  actor=@p  now=@da  j=judgment  basis=basis:editor
          intent=(unit record:itn)  approval=(unit approval:cs)  window=window:law
      ==
  ^-  (each admission:editor @tas)
  ?.  &(=(our actor) =(our owner.order.pending.j))  [%| %foreign-owner]
  ?.  &((valid j) (lte at.j now))  [%| %judgment-invalid]
  ?.  =(%approve-write decision.j)  [%| %checks-failed]
  =/  p=prepared-v1:vgc  (base:vgc prepared.result.pending.j)
  =/  e=evidence:generation  evidence.admission.p
  ?.  =(`intent.context.e intent)  [%| %intent-changed]
  ?.  =(`approval.e approval)  [%| %approval-changed]
  ?.  =(window window.e)  [%| %law-changed]
  ?:  (~(has in never-auto.window) %inscribe)  [%| %delegation-required]
  ?.  (basis-valid:editor basis)  [%| %basis-invalid]
  =/  current=snapshot:model  current.basis
  ?.  ?=(%text -.body.current)  [%| %source-unavailable]
  ?.  ?&  =(base.current base.context.e)  =(work.current work.context.e)
          =(source.body.current before.context.e)
      ==  [%| %source-changed]
  =/  change=change:model
    [%pataphor-editor-change-v1 our (key:result result.pending.j) current source.result.pending.j]
  (judge:editor our actor now change basis window)
++  fact
  |=  j=judgment
  ^-  *
  [%glass-coding-judgment (scot %ux (digest:generation j)) j]
--
