::  Delayed native truth join. Only candidate and retained commitment IDs
::  enter; no caller can submit an assessment, acceptance or measurement row.
/-  nc=native-coding
/+  measured=qpc-selected-measurement, history=qpc-selected-history,
    selected=qpc-native-selected, controller=qpc-native-controller,
    assessment=qpc-native-assessment, admission=qpc-native-admission,
    observation=qpc-observation, pool=qpc-native-pool,
    tools=cantrip-native-coding, accept=native-coding-accept,
    project=native-coding-project, guard=viki-scry-guard
|%
+$  query
  $%  [%viki path=path]
      [%cantrip path=path]
      [%current project=project:nc]
  ==
+$  getter  $-([our=@p at=@da query=query] (each * @tas))
+$  reader  $-([our=@p at=@da candidate=@ux commitment=@ux] (each evidence:measured @tas))
++  get
  |=  [our=@p at=@da query=query]
  ^-  (each * @tas)
  ?:  ?=(%current -.query)
    =/  now  (current:project our at project.query)
    ?:  ?=(%| -.now)  [%| p.now]
    [%& working.p.now]
  =/  app=term  -.query
  ?.  (agent-live:guard our at app)  [%| %qpc-selected-reader-agent-unavailable]
  [%& .^(* %gx (weld /(scot %p our)/[app]/(scot %da at) (weld path.query /noun)))]
++  read-with
  ::  Getter injection is a native proof seam, never an external command.
  |=  [fetch=getter our=@p at=@da candidate=@ux commitment=@ux]
  ^-  (each evidence:measured @tas)
  ?.  &((identifier:tools candidate) (identifier:tools commitment))
    [%| %qpc-selected-reader-identifier-invalid]
  =/  raw  (fetch our at [%cantrip /native-coding/candidate/(scot %ux candidate)])
  ?:  ?=(%| -.raw)  [%| p.raw]
  =/  decoded  ((soft ,(unit record:accept)) p.raw)
  ?~  decoded  [%| %qpc-selected-reader-acceptance-invalid]
  ?.  =(p.raw u.decoded)  [%| %qpc-selected-reader-acceptance-invalid]
  ?~  u.decoded  [%| %qpc-selected-reader-acceptance-missing]
  =/  accepted=record:accept  u.u.decoded
  ?.  ?&  =(candidate id.candidate.accepted)
          =(commitment (digest:accept accepted))
          ?=(?(%applied %refused) stage.accepted)  ?=(^ decision.accepted)
          (valid:accept (malt ~[[candidate accepted]]))
      ==  [%| %qpc-selected-reader-terminal-changed]
  =/  raw  (fetch our at [%viki /qpc/selected])
  ?:  ?=(%| -.raw)  [%| p.raw]
  =/  decoded  ((soft state:selected) p.raw)
  ?~  decoded  [%| %qpc-selected-reader-execution-invalid]
  ?.  &(=(p.raw u.decoded) (valid:selected u.decoded))
    [%| %qpc-selected-reader-execution-invalid]
  =/  matches=(list record:selected)
    (skim ~(val by records.u.decoded) |=(r=record:selected &(?=(%sent phase.r) =(context.candidate.accepted context.request.plan.r))))
  ?.  =(1 (lent matches))  [%| %qpc-selected-reader-execution-missing]
  =/  execution=record:selected  (snag 0 matches)
  ?~  marker.execution  [%| %qpc-selected-reader-release-marker-missing]
  =/  session=@ux  collection.plan.execution
  =/  raw  (fetch our at [%viki /qpc/instrument/selected])
  ?:  ?=(%| -.raw)  [%| p.raw]
  =/  decoded  ((soft ,[%qpc-instrument-selected-v1 selected=state:history]) p.raw)
  ?~  decoded  [%| %qpc-selected-reader-history-invalid]
  ?.  &(=(p.raw u.decoded) (lte ~(wyt by reservations.selected.u.decoded) 128))
    [%| %qpc-selected-reader-history-invalid]
  =/  matches=(list registration:history)
    (skim ~(val by reservations.selected.u.decoded) |=(r=registration:history =(session session.work.enrollment.reservation.r)))
  ?.  =(1 (lent matches))  [%| %qpc-selected-reader-reservation-missing]
  =/  reservation=reservation:measured  reservation:(snag 0 matches)
  ?.  (reservation-valid:measured reservation)  [%| %qpc-selected-reader-reservation-invalid]
  =/  raw  (fetch our at [%viki /qpc/controller])
  ?:  ?=(%| -.raw)  [%| p.raw]
  =/  decoded  ((soft state:controller) p.raw)
  ?~  decoded  [%| %qpc-selected-reader-controller-invalid]
  ?.  &(=(p.raw u.decoded) (valid:controller u.decoded))
    [%| %qpc-selected-reader-controller-invalid]
  =/  found  (~(get by records.u.decoded) session)
  ?~  found  [%| %qpc-selected-reader-choice-missing]
  =/  choice=record:controller  u.found
  =/  raw  (fetch our at [%viki /native-coding/qpc-input/(scot %ux session)])
  ?:  ?=(%| -.raw)  [%| p.raw]
  =/  decoded  ((soft ,(unit input:pool)) p.raw)
  ?~  decoded  [%| %qpc-selected-reader-session-invalid]
  ?.  =(p.raw u.decoded)  [%| %qpc-selected-reader-session-invalid]
  ?~  u.decoded  [%| %qpc-selected-reader-session-missing]
  =/  input=input:pool  u.u.decoded
  ?.  &(=(key.input key.origin.choice) =(grant.input grant.frozen.decision.choice))
    [%| %qpc-selected-reader-session-binding-changed]
  =/  raw  (fetch our at [%viki /qpc/observations])
  ?:  ?=(%| -.raw)  [%| p.raw]
  =/  decoded  ((soft state:observation) p.raw)
  ?~  decoded  [%| %qpc-selected-reader-observation-invalid]
  ?.  &(=(p.raw u.decoded) (valid:observation our u.decoded))
    [%| %qpc-selected-reader-observation-invalid]
  =/  observed=state:observation  u.decoded
  =/  matches=(list frame:observation)
    (skim ~(val by frames.observed) |=(f=frame:observation =(work.f work.enrollment.reservation)))
  ?.  =(1 (lent matches))  [%| %qpc-selected-reader-frame-missing]
  =/  frame=@ux  id:(snag 0 matches)
  =/  raw  (fetch our at [%cantrip /qpc/assessments])
  ?:  ?=(%| -.raw)  [%| p.raw]
  =/  decoded  ((soft state:assessment) p.raw)
  ?~  decoded  [%| %qpc-selected-reader-assessment-invalid]
  ?.  &(=(p.raw u.decoded) (valid:assessment our u.decoded))
    [%| %qpc-selected-reader-assessment-invalid]
  =/  found  (~(get by records.u.decoded) session)
  ?~  found  [%| %qpc-selected-reader-assessment-missing]
  =/  assessed=record:assessment  u.found
  =/  raw  (fetch our at [%cantrip /qpc/admissions/(scot %ux id.event.u.marker.execution)])
  ?:  ?=(%| -.raw)  [%| p.raw]
  =/  decoded  ((soft ,(unit receipt:admission)) p.raw)
  ?~  decoded  [%| %qpc-selected-reader-release-invalid]
  ?.  =(p.raw u.decoded)  [%| %qpc-selected-reader-release-invalid]
  ?~  u.decoded  [%| %qpc-selected-reader-release-missing]
  =/  release=receipt:admission  u.u.decoded
  =/  raw  (fetch our at [%cantrip /native-coding/tool-state])
  ?:  ?=(%| -.raw)  [%| p.raw]
  =/  decoded  ((soft organ:tools) p.raw)
  ?~  decoded  [%| %qpc-selected-reader-ledger-invalid]
  ?.  =(p.raw u.decoded)  [%| %qpc-selected-reader-ledger-invalid]
  =/  ledger=organ:tools  u.decoded
  =/  raw  (fetch our at [%current project.accepted])
  ?:  ?=(%| -.raw)  [%| p.raw]
  =/  decoded  ((soft tree:nc) p.raw)
  ?~  decoded  [%| %qpc-selected-reader-source-invalid]
  ?.  =(p.raw u.decoded)  [%| %qpc-selected-reader-source-invalid]
  =/  current=tree:nc  u.decoded
  =/  value=evidence:measured
    [reservation observed frame entry.input choice execution assessed release ledger accepted current at]
  =/  checked  (assemble:measured value)
  ?:  ?=(%| -.checked)  [%| p.checked]
  [%& value]
++  read
  |=  [our=@p at=@da candidate=@ux commitment=@ux]
  ^-  (each evidence:measured @tas)
  (read-with get our at candidate commitment)
--
