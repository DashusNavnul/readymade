::  /lib/readymade-remote.hoon
::
::  The remote: a bounded, owner-only projection of what the workspace is
::  doing, and one way in, for a phone or tablet browser that cannot run the
::  desktop page. Served by %pataphor-page under /apps/pataphor/remote.
::
::  Reads are views over state other agents already hold: the private
::  conversation (the page's own state), Bench's seat rows
::  (/x/readymade/bench-fleet), Bench's receipts and executions, and
::  Cantrip's pending candidates (/x/readymade/permissions). The other
::  agents' nouns are decoded with PARTIAL molds (`*` where the phone does not
::  need a field) so this file imports none of their closures. A noun that no
::  longer fits reads as "unavailable", never as a crash.
::
::  The one write, /remote/submit, is the desktop composer's command with the
::  SHIP'S nonce attached here: the phone never holds a nonce. A private ask
::  runs the page's own admission; a seat task is poked to %bench. The id is
::  the phone's, so the same id with the same text replays its receipt and the
::  same id with different text is refused -- the native dedupe, unchanged.
::  Nothing here retries.
/-  pc=pataphor-chat
/+  h=readymade-history, c=readymade-compose, bc=readymade-bench-compose
|%
+$  destination  $%([%private ~] [%seat seat=@tas])
+$  submission   [id=@uv destination=destination text=@t]
+$  want
  $%  [%page ~]  [%state cursor=(unit @ud)]  [%submit ~]
      [%receipt id=@uv destination=destination]  [%execution id=@uv]
      ::  the four shells: state, or the output window from an offset
      [%terminal app=@tas offset=(unit @ud)]
      ::  the coding console: sessions, and one session's records from a sequence
      [%coding sid=@ux after=@ud]
      ::  the cockpit's board: what the ship is doing now
      [%board ~]
      ::  writes that answer later: a shell action, a candidate decision; the
      ::  answer is read back by key (one-shot subscription or reply.json)
      [%terminal-act app=@tas]
      [%decide ~]
      [%reply key=@uv]
  ==
+$  moon-terminal  [%readymade-remote-terminal-v1 key=@uv app=@tas nonce=@uv body=@t]
+$  moon-decide    [%readymade-remote-decide-v1 key=@uv source=@ux action=@tas id=@ux]
+$  reply  [status=@ud body=@t]
::  the terminal agent's /x/state, only the fields the remote reads (shells b-d
::  still save as %terminal-v3; storage is the same first field)
+$  terminal-lite
  $:  ?(%terminal-v3 %terminal-v4)
      $=  storage
      $:  %terminal-v1
          s=[phase=@ud generation=@ud input-next=@ud output-next=@ud]
          nonce=@uv  retained=octs  offset=@ud  bound=@ud  connected=?  used=?
      ==
      *
  ==
::  viki's /native-coding/sessions rows (public-session:native-coding-loop), lite
+$  session-lite
  $:  session=[%native-coding-session-v1 id=@ux project=@t owner=@p working=* directory=* objective=@t workspace=*]
      phase=@tas
      selection=[%native-coding-provider-v1 provider=* model=@t *]
      worker=@p
      records=(list [sequence=@ud previous=* at=@da body=* id=@ux])
      summary=@t
      sequence=@ud
  ==
+$  board-lite  [%readymade-board-v1 ship=@p observed=@da text=@t]
::  Bench: lib/readymade-bench-fleet row, seat-row:readymade-bench-execution-agent
+$  seat-lite
  $:  %readymade-seat-v1  seat=@tas  backend=@t  holder=(unit @p)
      away=(unit [host=@p guest=@p])
      flight=(unit [id=@t phase=@tas])
  ==
+$  ended-lite  [ctx=* kind=@tas at=@da reason=[body=@t *]]
+$  reason-lite
  (each [origin=@uv cursor=* ended=(unit ended-lite) problem=(unit [body=@t *])] @tas)
+$  row-lite
  $:  seat=seat-lite  present=?  reserved=@ud
      task=(unit [request=@t phase=@tas speaker=@p opened=@da])
      active=(unit @uv)  recent=(unit @uv)  reason=reason-lite  model=*
  ==
+$  fleet-lite  [%readymade-bench-fleet-v3 source=@ux rows=(list row-lite)]
::  Bench: lib/readymade-bench-publisher control and receipt
+$  bench-control-lite  [%readymade-bench-control-v1 nonce=@uv *]
+$  bench-receipt-lite
  $:  %readymade-bench-receipt-v1  id=@uv  at=@da  outcome=@tas
      reason=(unit @t)  execution=(unit [seat=@tas request=@t])
  ==
+$  bench-submission-lite
  [%readymade-bench-submission-v1 id=@uv reply=(unit bench-receipt-lite)]
::  Bench: lib/readymade-bench-execution root, reply
+$  turn-lite
  $:  request=@t  seat=@tas  speaker=@p  at=@da  hash=@ux
      declared=*  attested=*  prompt=*  output=[body=@t bytes=@ud *]  rest=*
  ==
+$  root-lite
  $:  origin=*
      cursor=(unit [seat=@tas speaker=@p request=@t baseline=@da phase=@tas])
      nodes=*  turns=(list turn-lite)  settlements=*
      ended=(unit ended-lite)  problem=(unit [body=@t *])
      ancestry-overflow=?  overflow=?  revision=@ud
  ==
+$  bench-execution-lite
  [%readymade-bench-execution-v1 id=@uv value=(unit root-lite)]
::  Cantrip: lib/readymade-permissions approval-row, revision:native-coding
+$  approval-lite
  $:  id=@ux  grant=@ux  project=[body=@t *]  actor=@p  session=@ux
      source=[owner=@p desk=@tas number=@ud root=@uv commit=@uv]
      accepted=*  basis=*
      stage=@tas  requested=@da  reason=(unit @tas)
      decision=(unit [verdict=@tas at=@da digest=@ux])
      report=(unit @ux)  candidate=@ux
  ==
+$  perms-lite
  $:  %readymade-permissions-v2  owner=@p  source=@ux  window=*  forbidden=*
      grants=*  approvals=(list approval-lite)  requests-overflow=?
  ==
::
++  after-prefix
  |=  [prefix=@t url=@t]
  ^-  (unit @t)
  =/  size=@ud  (met 3 prefix)
  ?.  &((gte (met 3 url) size) =(prefix (end [3 size] url)))  ~
  `(rsh [3 size] url)
++  parse-id
  |=  value=@t
  ^-  (unit @uv)
  ?.  (lte (met 3 value) 33)  ~
  =/  parsed=(unit @uv)  (slaw %uv value)
  ?~  parsed  ~
  ?.  &((gth u.parsed 0) (lte (met 0 u.parsed) 128) =(value (scot %uv u.parsed)))  ~
  parsed
++  parse-destination
  |=  value=@t
  ^-  (unit destination)
  ?:  =('private' value)  `[%private ~]
  =/  name=(unit @t)  (after-prefix 'seat:' value)
  ?~  name  ~
  ?.  (lte (met 3 u.name) 32)  ~
  ?.  ((sane %tas) u.name)  ~
  ?.  (seat-valid:bc `@tas`u.name)  ~
  `[%seat `@tas`u.name]
++  terminal-apps
  ^-  (list @tas)
  ~[%pataphor-terminal %pataphor-terminal-b %pataphor-terminal-c %pataphor-terminal-d]
++  terminal-app
  |=  name=@t
  ^-  (unit @tas)
  ?.  (lien terminal-apps |=(a=@tas =(a name)))  ~
  [~ `@tas`name]
::  the console's own query form: ?<session @ux>&<after @ud>&<cursor @ux>
++  parse-coding-query
  |=  q=@t
  ^-  (unit [sid=@ux after=@ud])
  ?.  (lte (met 3 q) 120)  ~
  =/  rest=tape  (trip q)
  =/  one=(unit @ud)  (find "&" rest)
  ?~  one  ~
  =/  sid=(unit @ux)  (slaw %ux (crip (scag u.one rest)))
  ?~  sid  ~
  =/  tail=tape  (slag +(u.one) rest)
  =/  two=(unit @ud)  (find "&" tail)
  =/  after=(unit @ud)  (rush (crip ?~(two tail (scag u.two tail))) dim:ag)
  ?~  after  ~
  ?.  (lte u.after 4.096)  ~
  `[u.sid u.after]
::  the routes shared by the planet's HTTP door and the moon's: <base>/terminal/<app>/state.json,
::  <base>/terminal/<app>/events.json?offset=N, <base>/coding/state.json?<sid>&<after>&<cursor>, <base>/board.json
++  route-extra
  |=  [base=@t url=@t]
  ^-  (unit want)
  ?:  =((cat 3 base '/board.json') url)  `[%board ~]
  ?:  =((cat 3 base '/decide') url)  `[%decide ~]
  =/  rp=(unit @t)  (after-prefix (cat 3 base '/reply.json?key=') url)
  ?^  rp
    =/  key=(unit @uv)  (parse-id u.rp)
    ?~  key  ~
    `[%reply u.key]
  =/  cq=(unit @t)  (after-prefix (cat 3 base '/coding/state.json?') url)
  ?^  cq
    =/  parsed  (parse-coding-query u.cq)
    ?~  parsed  ~
    `[%coding sid.u.parsed after.u.parsed]
  =/  tm=(unit @t)  (after-prefix (cat 3 base '/terminal/') url)
  ?~  tm  ~
  =/  rest=tape  (trip u.tm)
  =/  slash=(unit @ud)  (find "/" rest)
  ?~  slash  ~
  =/  app=(unit @tas)  (terminal-app (crip (scag u.slash rest)))
  ?~  app  ~
  =/  tail=@t  (crip (slag +(u.slash) rest))
  ?:  =('state.json' tail)  `[%terminal u.app ~]
  ?:  =('action' tail)  `[%terminal-act u.app]
  =/  off=(unit @t)  (after-prefix 'events.json?offset=' tail)
  ?~  off  ~
  ?.  (lte (met 3 u.off) 20)  ~
  =/  parsed=(unit @ud)  (rush u.off dim:ag)
  ?~  parsed  ~
  `[%terminal u.app parsed]
++  route
  |=  url=@t
  ^-  (unit want)
  ?.  (lte (met 3 url) 256)  ~
  ?:  |(=('/apps/pataphor/remote' url) =('/apps/pataphor/remote/' url))
    `[%page ~]
  ?:  =('/apps/pataphor/remote/submit' url)  `[%submit ~]
  =/  st=(unit @t)  (after-prefix '/apps/pataphor/remote/state.json' url)
  ?^  st
    ?:  =('' u.st)  `[%state ~]
    =/  cur=(unit @t)  (after-prefix '?cursor=' u.st)
    ?~  cur  ~
    ?.  (lte (met 3 u.cur) 24)  ~
    =/  parsed=(unit @ud)  (rush u.cur dim:ag)
    ?~  parsed  ~
    `[%state parsed]
  =/  extra=(unit want)  (route-extra '/apps/pataphor/remote' url)
  ?^  extra  extra
  =/  rc=(unit @t)  (after-prefix '/apps/pataphor/remote/receipt.json?id=' url)
  ?^  rc
    =/  rest=tape  (trip u.rc)
    =/  split=(unit @ud)  (find "&destination=" rest)
    ?~  split  ~
    =/  id=(unit @uv)  (parse-id (crip (scag u.split rest)))
    ?~  id  ~
    =/  dest=(unit destination)  (parse-destination (crip (slag (add u.split 13) rest)))
    ?~  dest  ~
    `[%receipt u.id u.dest]
  =/  ex=(unit @t)  (after-prefix '/apps/pataphor/remote/execution.json?id=' url)
  ?~  ex  ~
  =/  id=(unit @uv)  (parse-id u.ex)
  ?~  id  ~
  `[%execution u.id]
::  The moon's door. A moon of this ship (team:title) asks for the same reads
::  by one-shot subscription on these paths and gets ONE %noun fact
::  [%readymade-remote-json-v1 body=@t] then a kick; it submits by poking
::  [%readymade-remote-submit-v1 id destination text] and a refusal is the
::  poke's nack. Same checks, same ids, same receipts as the HTTP routes.
+$  moon-submit  [%readymade-remote-submit-v1 id=@uv destination=@t text=@t]
++  watch-route
  |=  pax=path
  ^-  (unit want)
  ?+    pax  ~
      [%remote %state ~]           `[%state ~]
      [%remote %state @ ~]
    =/  cur=(unit @ud)  (slaw %ud i.t.t.pax)
    ?~  cur  ~
    `[%state cur]
  ::
      [%remote %receipt @ @ ~]
    =/  id=(unit @uv)  (parse-id i.t.t.pax)
    ?~  id  ~
    =/  dest=(unit destination)  (parse-destination i.t.t.t.pax)
    ?~  dest  ~
    `[%receipt u.id u.dest]
  ::
      [%remote %execution @ ~]
    =/  id=(unit @uv)  (parse-id i.t.t.pax)
    ?~  id  ~
    `[%execution u.id]
  ::
      [%remote %terminal @ ~]
    =/  app=(unit @tas)  (terminal-app i.t.t.pax)
    ?~  app  ~
    `[%terminal u.app ~]
  ::
      [%remote %terminal @ @ ~]
    =/  app=(unit @tas)  (terminal-app i.t.t.pax)
    ?~  app  ~
    =/  off=(unit @ud)  (slaw %ud i.t.t.t.pax)
    ?~  off  ~
    `[%terminal u.app off]
  ::
      [%remote %coding @ @ ~]
    =/  sid=(unit @ux)  (slaw %ux i.t.t.pax)
    ?~  sid  ~
    =/  after=(unit @ud)  (slaw %ud i.t.t.t.pax)
    ?~  after  ~
    `[%coding u.sid u.after]
  ::
      [%remote %board ~]  `[%board ~]
  ::
      [%remote %reply @ ~]
    =/  key=(unit @uv)  (parse-id i.t.t.pax)
    ?~  key  ~
    `[%reply u.key]
  ==
::  a moon's shell action and candidate decision, and the synthetic Eyre
::  request the planet makes of its own terminal agent on the moon's behalf
++  parse-terminal-noun
  |=  raw=*
  ^-  (unit moon-terminal)
  =/  v=(unit moon-terminal)  ((soft moon-terminal) raw)
  ?~  v  ~
  ?~  (terminal-app app.u.v)  ~
  ?:  =(0 key.u.v)  ~
  ?.  (lte (met 3 body.u.v) 24.576)  ~
  v
++  parse-decide-noun
  |=  raw=*
  ^-  (unit moon-decide)
  =/  v=(unit moon-decide)  ((soft moon-decide) raw)
  ?~  v  ~
  ?.  ?=(?(%review %decide %observe) action.u.v)  ~
  ?:  =(0 key.u.v)  ~
  v
++  parse-act
  |=  [headers=header-list:http body=(unit octs)]
  ^-  (unit [nonce=@uv body=@t])
  =/  hm=(map @t @t)  (~(gas by *(map @t @t)) headers)
  ?.  =(`'application/json' (~(get by hm) 'content-type'))  ~
  =/  tok=(unit @t)  (~(get by hm) 'x-terminal-nonce')
  ?~  tok  ~
  =/  nonce=(unit @uv)  (slaw %uv u.tok)
  ?~  nonce  ~
  ?~  body  ~
  ?.  (lte p.u.body 24.576)  ~
  `[u.nonce q.u.body]
++  parse-decide
  |=  [headers=header-list:http body=(unit octs)]
  ^-  (unit [source=@ux action=@tas id=@ux])
  =/  hm=(map @t @t)  (~(gas by *(map @t @t)) headers)
  =/  ct=(unit @t)  (~(get by hm) 'content-type')
  ?~  ct  ~
  ?.  =('application/json' (end [3 16] u.ct))  ~
  ?~  body  ~
  ?:  (gth p.u.body 2.048)  ~
  =/  jon=(unit json)  (de:json:html q.u.body)
  ?~  jon  ~
  =/  source=(unit @ux)  (slaw %ux (text-field u.jon 'source'))
  =/  id=(unit @ux)  (slaw %ux (text-field u.jon 'id'))
  =/  action=@t  (text-field u.jon 'action')
  ?~  source  ~
  ?~  id  ~
  ?.  ?=(?(%review %decide %observe) action)  ~
  `[u.source action u.id]
++  terminal-request
  |=  [id=@ta app=@tas nonce=@uv body=@t]
  ^-  [id=@ta req=inbound-request:eyre]
  :-  id
  :*  %.y  %.n  [%ipv4 .127.0.0.1]
      :*  %'POST'  (rap 3 ~['/apps/' app '/action'])
          ~[['content-type' 'application/json'] ['x-terminal-nonce' (scot %uv nonce)]]
          `(as-octs:mimes:html body)
      ==
  ==
++  reply-json
  |=  r=(unit reply)
  ^-  json
  ?~  r  (pairs:enjs:format ~[['known' b+%.n]])
  =/  inner=(unit json)  (de:json:html body.u.r)
  %-  pairs:enjs:format
  :~  ['known' b+&]
      ['status' (numb:enjs:format status.u.r)]
      ['body' ?~(inner s+body.u.r u.inner)]
  ==
++  accepted-json
  |=  key=@uv
  ^-  json
  (pairs:enjs:format ~[['accepted' b+&] ['key' s+(scot %uv key)] ['meaning' s+'Read reply.json?key= until known. Nothing is resent.']])
++  parse-submit-noun
  |=  raw=*
  ^-  (unit submission)
  =/  sub=(unit moon-submit)  ((soft moon-submit) raw)
  ?~  sub  ~
  ?.  (lte (met 3 destination.u.sub) 40)  ~
  =/  dest=(unit destination)  (parse-destination destination.u.sub)
  ?~  dest  ~
  ?.  (text-valid:bc text.u.sub)  ~
  ?.  &((gth id.u.sub 0) (lte (met 0 id.u.sub) 128))  ~
  `[id.u.sub u.dest text.u.sub]
++  json-fact
  |=  jon=json
  ^-  (list card:agent:gall)
  :~  [%give %fact ~ %noun !>([%readymade-remote-json-v1 (en:json:html jon)])]
      [%give %kick ~ ~]
  ==
::  A JSON body: {"id": "0v...", "destination": "private" | "seat:<name>", "text": "..."}
++  text-field
  |=  [jon=json key=@t]
  ^-  @t
  ?.  ?=([%o *] jon)  ''
  =/  v=(unit json)  (~(get by p.jon) key)
  ?~  v  ''
  ?.  ?=([%s *] u.v)  ''
  p.u.v
++  parse-submit
  |=  [headers=header-list:http body=(unit octs)]
  ^-  (unit submission)
  =/  hm=(map @t @t)  (~(gas by *(map @t @t)) headers)
  =/  ct=(unit @t)  (~(get by hm) 'content-type')
  ?~  ct  ~
  ?.  =('application/json' (end [3 16] u.ct))  ~
  ?~  body  ~
  ?:  (gth p.u.body 16.384)  ~
  =/  jon=(unit json)  (de:json:html q.u.body)
  ?~  jon  ~
  =/  id=(unit @uv)  (parse-id (text-field u.jon 'id'))
  ?~  id  ~
  =/  dest=(unit destination)  (parse-destination (text-field u.jon 'destination'))
  ?~  dest  ~
  =/  text=@t  (text-field u.jon 'text')
  ?.  (text-valid:bc text)  ~
  `[u.id u.dest text]
::
++  running
  |=  [our=@p now=@da app=@tas]
  ^-  ?
  .^(? %gu /(scot %p our)/[app]/(scot %da now)/$)
++  fleet
  |=  [our=@p now=@da]
  ^-  (unit fleet-lite)
  ?.  (running our now %bench)  ~
  ((soft fleet-lite) .^(* %gx /(scot %p our)/bench/(scot %da now)/readymade/bench-fleet/noun))
++  bench-nonce
  |=  [our=@p now=@da]
  ^-  (unit @uv)
  ?.  (running our now %bench)  ~
  =/  got=(unit bench-control-lite)
    ((soft bench-control-lite) .^(* %gx /(scot %p our)/bench/(scot %da now)/readymade/compose/noun))
  ?~  got  ~
  `nonce.u.got
++  bench-receipt
  |=  [our=@p now=@da id=@uv]
  ^-  (unit bench-submission-lite)
  ?.  (running our now %bench)  ~
  %-  (soft bench-submission-lite)
  .^(* %gx /(scot %p our)/bench/(scot %da now)/readymade/submission/(scot %uv id)/noun)
++  bench-execution
  |=  [our=@p now=@da id=@uv]
  ^-  (unit bench-execution-lite)
  ?.  (running our now %bench)  ~
  %-  (soft bench-execution-lite)
  .^(* %gx /(scot %p our)/bench/(scot %da now)/readymade/execution/(scot %uv id)/noun)
++  permissions
  |=  [our=@p now=@da]
  ^-  (unit perms-lite)
  ?.  (running our now %cantrip)  ~
  ((soft perms-lite) .^(* %gx /(scot %p our)/cantrip/(scot %da now)/readymade/permissions/noun))
::  A known private id answers from its receipt. The native digest covers the
::  nonce, which the phone never holds, so the remote checks the text itself
::  against the retained entry: the same text replays, a different text is
::  refused, a pruned entry or a refusal replays (one id, one answer).
++  replay-ok
  |=  [record=stored:c st=state-0:pc text=@t]
  ^-  ?
  ?:  =(%refused outcome.reply.record)  %.y
  ?~  execution.reply.record  %.y
  =/  want=@ud  entry.u.execution.reply.record
  =/  found=(list entry:pc)  (skim entries.st |=(e=entry:pc =(want id.e)))
  ?~  found  %.y
  =(request.i.found (trim:bc text))
::  A poke-nack's reason, bounded; the phone reads it beside the receipt.
++  nack-reason
  |=  =tang
  ^-  @t
  =/  lines=(list tape)
    (zing (turn (scag 4 tang) |=(t=tank (wash [0 120] t))))
  body:(bounded:h (crip (of-wall:format lines)) 512)
++  remember-nack
  |=  [nacks=(map @uv @t) id=@uv why=@t]
  ^-  (map @uv @t)
  =/  base=(map @uv @t)  ?:((gte ~(wyt by nacks) 64) ~ nacks)
  (~(put by base) id why)
::
++  error-json
  |=  why=@t
  ^-  json
  (pairs:enjs:format ~[['error' s+why]])
++  submitted-json
  |=  [id=@uv seat=@tas]
  ^-  json
  %-  pairs:enjs:format
  :~  ['submitted' b+%.y]
      ['id' s+(scot %uv id)]
      ['seat' s+seat]
      ['meaning' s+'Handed to Bench with its current nonce. Read the receipt; do not resend.']
  ==
++  private-receipt-json
  |=  r=receipt:c
  ^-  json
  %-  pairs:enjs:format
  :~  ['known' b+%.y]
      ['destination' s+'private']
      ['id' s+(scot %uv id.r)]
      ['at' (time:enjs:format at.r)]
      ['outcome' s+outcome.r]
      ['reason' ?~(reason.r ~ s+u.reason.r)]
      :-  'execution'
      ?~  execution.r  ~
      %-  pairs:enjs:format
      :~  ['epoch' s+epoch.u.execution.r]
          ['entry' (numb:enjs:format entry.u.execution.r)]
          ['message' s+message.u.execution.r]
      ==
  ==
++  bench-receipt-json
  |=  [id=@uv r=(unit bench-receipt-lite) nack=(unit @t)]
  ^-  json
  %-  pairs:enjs:format
  :~  ['known' b+?=(^ r)]
      ['destination' s+'seat']
      ['id' s+(scot %uv id)]
      ['at' ?~(r ~ (time:enjs:format at.u.r))]
      ['outcome' ?~(r ~ s+outcome.u.r)]
      ['reason' ?~(r ~ ?~(reason.u.r ~ s+u.reason.u.r))]
      :-  'execution'
      ?~  r  ~
      ?~  execution.u.r  ~
      %-  pairs:enjs:format
      :~  ['seat' s+seat.u.execution.u.r]
          ['request' s+request.u.execution.u.r]
      ==
      ['nack' ?~(nack ~ s+u.nack)]
  ==
++  execution-json
  |=  [id=@uv e=(unit bench-execution-lite)]
  ^-  json
  =/  unknown=json
    (pairs:enjs:format ~[['known' b+%.n] ['id' s+(scot %uv id)]])
  ?~  e  unknown
  ?~  value.u.e  unknown
  =/  v=root-lite  u.value.u.e
  =/  last=(unit turn-lite)
    %+  roll  turns.v
    |=  [t=turn-lite acc=(unit turn-lite)]
    ^-  (unit turn-lite)
    ?~  acc  `t
    ?:((gte at.t at.u.acc) `t acc)
  %-  pairs:enjs:format
  :~  ['known' b+%.y]
      ['id' s+(scot %uv id)]
      ['revision' (numb:enjs:format revision.v)]
      :-  'cursor'
      ?~  cursor.v  ~
      %-  pairs:enjs:format
      :~  ['seat' s+seat.u.cursor.v]
          ['request' s+request.u.cursor.v]
          ['phase' s+phase.u.cursor.v]
          ['opened' (time:enjs:format baseline.u.cursor.v)]
      ==
      ['turns' (numb:enjs:format (lent turns.v))]
      :-  'last'
      ?~  last  ~
      %-  pairs:enjs:format
      :~  ['at' (time:enjs:format at.u.last)]
          ['seat' s+seat.u.last]
          ['output' s+(prefix:h body.output.u.last 2.048)]
          ['outputBytes' (numb:enjs:format bytes.output.u.last)]
      ==
      :-  'ended'
      ?~  ended.v  ~
      %-  pairs:enjs:format
      :~  ['kind' s+kind.u.ended.v]
          ['at' (time:enjs:format at.u.ended.v)]
          ['reason' s+body.reason.u.ended.v]
      ==
      ['problem' ?~(problem.v ~ s+body.u.problem.v)]
      ['overflow' b+overflow.v]
  ==
::
++  reason-json
  |=  r=reason-lite
  ^-  json
  ?:  ?=(%| -.r)  (pairs:enjs:format ~[['kind' s+p.r]])
  %-  pairs:enjs:format
  :~  ['kind' s+'execution']
      ['origin' s+(scot %uv origin.p.r)]
      :-  'ended'
      ?~  ended.p.r  ~
      %-  pairs:enjs:format
      :~  ['kind' s+kind.u.ended.p.r]
          ['at' (time:enjs:format at.u.ended.p.r)]
          ['reason' s+body.reason.u.ended.p.r]
      ==
      ['problem' ?~(problem.p.r ~ s+body.u.problem.p.r)]
  ==
++  seat-json
  |=  r=row-lite
  ^-  json
  %-  pairs:enjs:format
  :~  ['seat' s+seat.seat.r]
      ['backend' s+backend.seat.r]
      ['holder' ?~(holder.seat.r ~ s+(scot %p u.holder.seat.r))]
      ['away' ?~(away.seat.r ~ s+(scot %p host.u.away.seat.r))]
      ['present' b+present.r]
      ['reserved' (numb:enjs:format reserved.r)]
      :-  'task'
      ?~  task.r  ~
      %-  pairs:enjs:format
      :~  ['request' s+request.u.task.r]
          ['phase' s+phase.u.task.r]
          ['speaker' s+(scot %p speaker.u.task.r)]
          ['opened' (time:enjs:format opened.u.task.r)]
      ==
      ['active' ?~(active.r ~ s+(scot %uv u.active.r))]
      ['recent' ?~(recent.r ~ s+(scot %uv u.recent.r))]
      ['reason' (reason-json reason.r)]
  ==
++  approval-json
  |=  a=approval-lite
  ^-  json
  %-  pairs:enjs:format
  :~  ['id' s+(scot %ux id.a)]
      ['project' s+body.project.a]
      ['actor' s+(scot %p actor.a)]
      ['session' s+(scot %ux session.a)]
      ['desk' s+desk.source.a]
      ['number' (numb:enjs:format number.source.a)]
      ['stage' s+stage.a]
      ['requested' (time:enjs:format requested.a)]
      ['reason' ?~(reason.a ~ s+u.reason.a)]
      :-  'decision'
      ?~  decision.a  ~
      %-  pairs:enjs:format
      :~  ['verdict' s+verdict.u.decision.a]
          ['at' (time:enjs:format at.u.decision.a)]
      ==
      ['candidate' s+(scot %ux candidate.a)]
  ==
::  The phone shows at most 2 KiB of a request or an output.
++  entry-json
  |=  r=row:h
  ^-  json
  %-  pairs:enjs:format
  :~  ['id' (numb:enjs:format id.r)]
      ['time' (time:enjs:format time.r)]
      ['status' s+status.r]
      ['request' s+(prefix:h body.request.r 2.048)]
      ['requestBytes' (numb:enjs:format bytes.request.r)]
      ['output' ?~(output.r ~ s+(prefix:h body.u.output.r 2.048))]
      ['outputBytes' ?~(output.r ~ (numb:enjs:format bytes.u.output.r))]
  ==
++  conversation-json
  |=  [act=@ud st=state-0:pc]
  ^-  json
  =/  snap=snapshot:h  (project:h act [0 8] st)
  %-  pairs:enjs:format
  :~  ['epoch' s+epoch.snap]
      ['total' (numb:enjs:format total.snap)]
      ['active' ?~(active.snap ~ (numb:enjs:format u.active.snap))]
      ['error' ?~(error.snap ~ s+body.u.error.snap)]
      ['entries' a+(turn entries.snap entry-json)]
  ==
::  The cursor is a hash of the data the phone renders, not of the time it
::  was read, so an unchanged workspace answers with a few bytes.
++  state-json
  |=  [b=bowl:gall st=state-0:pc receipts=@ud cursor=(unit @ud)]
  ^-  json
  =/  fl=(unit fleet-lite)  (fleet our.b now.b)
  =/  pm=(unit perms-lite)  (permissions our.b now.b)
  =/  rows=(list row-lite)  ?~(fl ~ rows.u.fl)
  =/  approvals=(list approval-lite)  ?~(pm ~ approvals.u.pm)
  =/  mark=@ud
    (mug [entries.st active.st error.st rows approvals ?=(^ fl) ?=(^ pm)])
  ?:  =(cursor `mark)
    %-  pairs:enjs:format
    :~  ['unchanged' b+%.y]
        ['cursor' (numb:enjs:format mark)]
        ['observed' (time:enjs:format now.b)]
    ==
  %-  pairs:enjs:format
  :~  ['ship' s+(scot %p our.b)]
      ['observed' (time:enjs:format now.b)]
      ['cursor' (numb:enjs:format mark)]
      ['receipts' (numb:enjs:format receipts)]
      ['conversation' (conversation-json act.b st)]
      ['seatsAvailable' b+?=(^ fl)]
      ['seats' a+(turn rows seat-json)]
      ['candidatesAvailable' b+?=(^ pm)]
      ['candidatesSource' ?~(pm ~ s+(scot %ux source.u.pm))]
      ['candidates' a+(turn approvals approval-json)]
  ==
::
::  THE FOUR SHELLS, read from the terminal agent's own peek (/x/state: Gall
::  prepends the care, so the scry spur is /state/noun). The JSON is the
::  shape the terminal's HTTP gives (lib/pataphor-terminal-http state/events),
::  so one client reads either door; a requested offset returns the bytes
::  since it from the 64 KiB retained window, or the whole window with reset.
++  terminal-json
  |=  [our=@p now=@da app=@tas requested=(unit @ud)]
  ^-  json
  ?.  (running our now app)  (error-json 'Terminal not running.')
  =/  noun  .^(* %gx /(scot %p our)/[app]/(scot %da now)/state/noun)
  =/  raw=(unit terminal-lite)  ((soft terminal-lite) noun)
  ?~  raw  (error-json 'Terminal state unreadable.')
  =*  st  storage.u.raw
  ::  the control record (lib/terminal-viewer): v4 carries sharing after it, v3 ends with it
  =/  ctl=[revision=@ud viewer=@t key=@t]
    =/  v4  ((soft ,[@ * * * * c=[revision=@ud viewer=@t key=@t] *]) noun)
    ?^  v4  c.u.v4
    =/  v3  ((soft ,[@ * * * * c=[revision=@ud viewer=@t key=@t]]) noun)
    ?^  v3  c.u.v3
    [0 '' '']
  =/  base=@uv  `@uv`(sham [s.st connected.st offset.st])
  =/  snapshot=json
    %-  pairs:enjs:format
    :~  ['phase' (numb:enjs:format phase.s.st)]
        ['generation' (numb:enjs:format generation.s.st)]
        ['inputNext' (numb:enjs:format input-next.s.st)]
        ['connected' b+connected.st]
        ['nonce' s+(scot %uv nonce.st)]
        ['offset' (numb:enjs:format offset.st)]
        ['cursor' s+(scot %uv `@uv`(sham [base ctl]))]
        ['control' (pairs:enjs:format ~[['revision' (numb:enjs:format revision.ctl)] ['viewer' s+viewer.ctl]])]
    ==
  ?~  requested  snapshot
  =/  first=@ud  (sub offset.st p.retained.st)
  =/  reset=?  |((lth u.requested first) (gth u.requested offset.st))
  =/  begin=@ud  ?:(reset first u.requested)
  =/  length=@ud  (sub offset.st begin)
  =/  bytes=octs  [length (cut 3 [(sub begin first) length] q.retained.st)]
  %-  pairs:enjs:format
  :~  ['offset' (numb:enjs:format offset.st)]
      ['reset' b+reset]
      ['data' s+(en:base64:mimes:html bytes)]
      ['state' snapshot]
  ==
::  THE CODING CONSOLE, read from viki's sessions: every session's head, and
::  the selected session's records from a sequence (32 at a time, like the
::  console's own HTTP). The record's time is native (at=@da).
++  record-text
  |=  body=*
  ^-  [kind=@t text=@t]
  =/  kind=@t
    ?@  body  'unknown'
    ?^  -.body  'unknown'
    `@t`-.body
  =/  op=(unit [%operator text=@t])  ((soft ,[%operator text=@t]) body)
  ?^  op  [kind text.u.op]
  =/  tm=(unit [%terminal input=@t output=@t])  ((soft ,[%terminal input=@t output=@t]) body)
  ?^  tm  [kind (rap 3 ~[input.u.tm '\0a' output.u.tm])]
  =/  st=(unit [%status value=@tas reason=@tas])  ((soft ,[%status value=@tas reason=@tas]) body)
  ?^  st  [kind (rap 3 ~[(scot %tas value.u.st) ': ' (scot %tas reason.u.st)])]
  =/  md=(unit [%model result=[text=@t *]])  ((soft ,[%model result=[text=@t *]]) body)
  ?^  md  [kind text.result.u.md]
  =/  sl=(unit [%selection value=[%native-coding-provider-v1 provider=* model=@t *]])
    ((soft ,[%selection value=[%native-coding-provider-v1 provider=* model=@t *]]) body)
  ?^  sl  [kind (cat 3 'Provider selected: ' model.value.u.sl)]
  =/  jd=(unit [%judgment verdict=@tas evidence=* reason=@t])  ((soft ,[%judgment verdict=@tas evidence=* reason=@t]) body)
  ?^  jd  [kind (rap 3 ~[(scot %tas verdict.u.jd) ': ' reason.u.jd])]
  [kind ?:(=('tool' kind) 'Tool result (inspect on the desk).' ?:(=('context' kind) 'Prepared request context.' ''))]
++  session-json
  |=  s=session-lite
  ^-  json
  %-  pairs:enjs:format
  :~  ['id' s+(scot %ux id.session.s)]
      ['project' s+project.session.s]
      ['objective' s+objective.session.s]
      ['phase' s+phase.s]
      ['model' s+model.selection.s]
      ['worker' s+(scot %p worker.s)]
      ['records' (numb:enjs:format (lent records.s))]
      ['sequence' (numb:enjs:format sequence.s)]
      ['summary' s+summary.s]
  ==
++  coding-json
  |=  [our=@p now=@da sid=@ux after=@ud]
  ^-  json
  ?.  (running our now %viki)
    (pairs:enjs:format ~[['ready' b+%.n] ['sessions' a+~] ['records' a+~] ['session' s+(scot %ux sid)] ['phase' s+'detached']])
  =/  raw=(unit (list session-lite))
    ((soft (list session-lite)) .^(* %gx /(scot %p our)/viki/(scot %da now)/native-coding/sessions/noun))
  ?~  raw  (error-json 'Coding sessions unreadable.')
  =/  matching  (skim u.raw |=(s=session-lite =(sid id.session.s)))
  =/  found=(unit session-lite)  ?~(matching ~ `i.matching)
  =/  next=@ud  ?~(found 0 sequence.u.found)
  =/  reset=?  (gth after next)
  =/  rows  ?~(found ~ (scag 32 (skim records.u.found |=([sequence=@ud *] (gte sequence ?:(reset 0 after))))))
  =/  until=@ud
    ?~  rows  ?:(reset 0 after)
    +((roll (turn rows |=([sequence=@ud *] sequence)) max))
  %-  pairs:enjs:format
  :~  ['ready' b+&]
      ['owner' s+(scot %p our)]
      ['session' s+(scot %ux sid)]
      ['phase' s+?~(found 'detached' phase.u.found)]
      ['sessions' a+(turn u.raw session-json)]
      :-  'records'
      :-  %a
      %+  turn  rows
      |=  [sequence=@ud previous=* at=@da body=* id=@ux]
      =/  rt  (record-text body)
      %-  pairs:enjs:format
      :~  ['id' s+(scot %ux id)]
          ['sequence' (numb:enjs:format sequence)]
          ['at' (time:enjs:format at)]
          ['kind' s+kind.rt]
          ['text' s+text.rt]
      ==
      ['after' (numb:enjs:format until)]
      ['more' b+(lth until next)]
      ['reset' b+reset]
  ==
::  THE BOARD: the cockpit's own projection, its JSON text passed through.
++  board-json
  |=  [our=@p now=@da]
  ^-  json
  ?.  (running our now %cockpit)  (pairs:enjs:format ~[['known' b+%.n] ['reason' s+'cockpit not running']])
  =/  raw=(unit board-lite)
    ((soft board-lite) .^(* %gx /(scot %p our)/cockpit/(scot %da now)/readymade/board/noun))
  ?~  raw  (pairs:enjs:format ~[['known' b+%.n] ['reason' s+'board unreadable']])
  =/  inner=(unit json)  (de:json:html text.u.raw)
  %-  pairs:enjs:format
  :~  ['known' b+&]
      ['ship' s+(scot %p ship.u.raw)]
      ['observed' (time:enjs:format observed.u.raw)]
      ['board' ?~(inner ~ u.inner)]
  ==
++  css
  ^-  @t
  %+  rap  3
  :~  ':root{color-scheme:dark;--bg:#0c0c0e;--panel:#161618;--line:#2c2c30;--muted:#8c8880;--ink:#e6e2da;--accent:#e8a33d;--warn:#d97757}'
      '*{box-sizing:border-box}html{-webkit-text-size-adjust:100%}body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.5 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;padding:0 16px calc(24px + env(safe-area-inset-bottom))}'
      'header{display:flex;align-items:baseline;gap:10px;padding:14px 0 8px;border-bottom:1px solid var(--line);position:sticky;top:0;background:var(--bg);z-index:1}.brand{font-weight:700;letter-spacing:.12em}.ship{color:var(--muted);font-size:13px;overflow-wrap:anywhere}.link{margin-left:auto;font-size:12px;color:var(--muted)}.link.bad{color:var(--warn)}'
      'h2{font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:var(--muted);margin:22px 0 8px}'
      '.row{display:block;width:100%;text-align:left;background:var(--panel);color:var(--ink);border:1px solid var(--line);border-radius:6px;padding:12px 14px;margin:0 0 8px;font:inherit;min-height:44px;cursor:pointer}.row.sel{border-color:var(--accent)}.row .name{font-weight:700}.row .state{color:var(--muted);font-size:13px;margin-top:2px;overflow-wrap:anywhere}.row .pend{color:var(--accent);font-size:13px;margin-top:2px}'
      '.detail{background:var(--panel);border:1px solid var(--line);border-radius:6px;padding:14px;margin:0 0 8px}.detail .k{font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:var(--muted);margin-top:10px}.detail .k:first-child{margin-top:0}.detail pre{white-space:pre-wrap;overflow-wrap:anywhere;margin:4px 0 0;font:13px/1.45 inherit;color:var(--ink);max-height:40vh;overflow:auto;-webkit-overflow-scrolling:touch}'
      '.compose{background:var(--panel);border:1px solid var(--line);border-radius:6px;padding:14px;margin:0 0 8px}.compose textarea{display:block;width:100%;min-height:96px;background:var(--bg);color:var(--ink);border:1px solid var(--line);border-radius:6px;padding:10px;font:inherit;resize:vertical}.compose .bar{display:flex;gap:10px;align-items:center;margin-top:10px}.compose button,.act{min-height:44px;padding:0 18px;border-radius:22px;border:1px solid var(--accent);background:var(--accent);color:#141413;font:inherit;font-weight:700;cursor:pointer}.compose button:disabled{opacity:.45}.act.quiet{background:transparent;color:var(--ink);border-color:#4a4843}'
      '.receipt{font-size:13px;margin-top:8px;overflow-wrap:anywhere}.receipt.ok{color:#8fc48f}.receipt.bad{color:var(--warn)}.receipt.wait{color:var(--accent)}'
      '.notice{padding:12px 14px;border:1px solid #685038;color:#ffd59b;border-radius:6px;overflow-wrap:anywhere}.muted{color:var(--muted)}.tiny{font-size:12px}'
  ==
++  page
  |=  our=@p
  ^-  @t
  %+  rap  3
  :~  '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="referrer" content="no-referrer"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="mobile-web-app-capable" content="yes"><title>Readymade remote</title><style>'
      css
      '</style></head><body data-base="/apps/pataphor/remote" data-ship="'  (scot %p our)
      '"><header><span class="brand">READYMADE</span><span class="ship">'  (scot %p our)
      '</span><span class="link" data-link>connecting</span></header>'
      '<main data-remote><p class="notice">Loading the workspace.</p></main>'
      '<noscript><p class="notice">Enable JavaScript to use the remote.</p></noscript>'
      '<script src="/apps/pataphor/readymade-remote.js" defer></script></body></html>'
  ==
--
