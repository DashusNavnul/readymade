::  Cantrip receipt owner. Only marker ID is accepted from the owner; there
::  is no report-input endpoint, selection, build, source change or retry.
/+  store=qpc-native-admission-store, admit=qpc-native-admission,
    read=qpc-native-admission-read, tools=cantrip-native-coding
|%
++  wrap
  |=  [inner=agent:gall fetch=reader:read]
  =/  held=state:store  empty:store
  ^-  agent:gall
  |_  =bowl:gall
  +*  this  .
      ag  ~(. inner bowl)
      refuse
        |=  [id=@ux reason=@tas]
        ^-  (quip card:agent:gall _this)
        =.  held  (refuse:store held id reason)
        [~[[%give %fact ~[/qpc/admissions] %noun !>([%qpc-admission-unavailable-v1 id reason])]] this]
  ++  on-init
    =^  cards  inner  on-init:ag
    [cards this]
  ++  on-save  !>([%qpc-admission-owner-v1 held on-save:ag])
  ++  on-load
    |=  old=vase
    =/  saved=[held=state:store inner=vase]
      ?.  ?=([%qpc-admission-owner-v1 *] q.old)  [empty:store old]
      =/  prior  !<([%qpc-admission-owner-v1 held=state:store inner=vase] old)
      +.prior
    ?>  (valid:store held.saved)
    =.  held  (recover:store held.saved)
    =^  cards  inner  (on-load:ag inner.saved)
    [cards this]
  ++  on-poke
    |=  [=mark =vase]
    ?:  &(=(%noun mark) ?=([%qpc-admit-v1 @] q.vase))
      ?>  =(our.bowl src.bowl)
      =/  id=@ux  +.q.vase
      ?>  (identifier:tools id)
      ?:  |((~(has by records.held) id) (~(has by unavailable.held) id))  [~ this]
      =/  got  (fetch inner bowl id)
      ?:  ?=(%| -.got)  (refuse id p.got)
      ?.  =(now.bowl at.p.got)  (refuse id %qpc-admission-read-not-current)
      =/  next  (retain:store held id p.got (add now.bowl ~s1))
      ?:  ?=(%| -.next)  (refuse id p.next)
      =.  held  p.next
      =/  r=delivery:store  (~(got by records.held) id)
      [~[[%pass (wire-for:store id r) %arvo %b %wait due.r]] this]
    =^  cards  inner  (on-poke:ag mark vase)
    [cards this]
  ++  on-arvo
    |=  [=wire =sign-arvo]
    ?:  ?=([%qpc-admission-notify *] wire)
      ?.  &(=(our.bowl src.bowl) ?=([%qpc-admission-notify @ @ ~] wire))  [~ this]
      =/  id  (slaw %ux i.t.wire)
      ?~  id  [~ this]
      =/  found  (~(get by records.held) u.id)
      ?~  found  [~ this]
      =/  r=delivery:store  u.found
      ?.  &(=(wire (wire-for:store u.id r)) =(%scheduled notice.r) (gte now.bowl due.r))  [~ this]
      ?.  ?=([%behn %wake *] sign-arvo)  [~ this]
      ?.  ?=([%behn %wake ~] sign-arvo)
        [~ this(held held(records (~(put by records.held) u.id r(notice %unknown))))]
      =.  held  held(records (~(put by records.held) u.id r(notice %sent)))
      [~[[%pass /qpc/admission-notice/(scot %ux u.id) %agent [our.bowl %viki] %poke %noun !>([%qpc-admission-ready-v1 `@ux`u.id])]] this]
    =^  cards  inner  (on-arvo:ag wire sign-arvo)
    [cards this]
  ++  on-peek
    |=  =path
    ?:  =(/x/qpc/admissions path)
      ?.  =(our.bowl src.bowl)  ~
      ``noun+!>(held)
    ?:  ?=([%x %qpc %admissions @ ~] path)
      ?.  =(our.bowl src.bowl)  ~
      =/  id  (slaw %ux i.t.t.t.path)
      ?~  id  [~ ~]
      =/  found  (~(get by records.held) u.id)
      =/  result=(unit receipt:admit)  ?~(found ~ `receipt.u.found)
      ``noun+!>(result)
    (on-peek:ag path)
  ++  on-watch
    |=  =path
    =^  cards  inner  (on-watch:ag path)
    [cards this]
  ++  on-leave
    |=  =path
    =^  cards  inner  (on-leave:ag path)
    [cards this]
  ++  on-agent
    |=  [=wire =sign:agent:gall]
    =^  cards  inner  (on-agent:ag wire sign)
    [cards this]
  ++  on-fail
    |=  [=term =tang]
    =^  cards  inner  (on-fail:ag term tang)
    [cards this]
  --
++  agent  |=(inner=agent:gall (wrap inner read:read))
--
