::  Review context is canonical baseline source, never a test execution claim.
/-  nc=native-coding, np=native-coding-provider
/+  journal=native-coding-session, project=native-coding-project,
    files=native-coding-files
|%
+$  sources  (map path replacement:nc)
++  byte-limit
  :: Whole frozen and encoded requests still meet their existing budgets.
  request-limit:np
++  bytes
  |=  context=sources
  ^-  @ud
  (roll ~(val by context) |=([r=replacement:nc n=@ud] (add n (met 3 source.r))))
++  paths
  ::  Only retained reads from this exact session/configuration/source qualify.
  |=  [c=candidate:nc rows=(list record:journal)]
  ^-  (set path)
  %+  roll  rows
  |=  [row=record:journal out=(set path)]
  ?.  ?=(%tool -.body.row)  out
  =/  r=tool-result:nc  result.body.row
  ?.  ?=(%read -.output.r)  out
  ?.  ?&  =(project.context.c project.context.r)
          =(configuration.context.c configuration.context.r)
          =(session.context.c session.context.r)
          =(actor.context.c actor.context.r)
          =(source.context.c source.context.r)
          =(`blob.value.output.r (~(get by files.body.snapshot.basis.c) pax.value.output.r))
      ==  out
  ?:  (lien edits.c |=(e=edit:nc =(path.change.e pax.value.output.r)))  out
  (~(put in out) pax.value.output.r)
++  valid
  |=  [p=project:nc c=candidate:nc context=sources]
  ^-  ?
  ?&  ~(apt by context)  (lte (lent ~(tap by context)) 8)
      (lte (bytes context) byte-limit)
      %+  levy  ~(tap by context)
      |=  [pax=path r=replacement:nc]
      ?&  ?=(^ pax)  (readable:project p pax)
          !(lien edits.c |=(e=edit:nc =(pax path.change.e)))
          =((rear pax) mark.r)
          =(`mark.r (~(get by file-types.p) mark.r))
          (text-valid:files p source.r)
          =(``@ux`(page-to-lobe:clay [mark.r source.r]) (~(get by files.body.snapshot.basis.c) pax))
      ==
  ==
++  capture
  ::  Re-read complete files; a paginated model read is not a complete source.
  |=  [p=project:nc c=candidate:nc rows=(list record:journal)]
  ^-  (each sources @tas)
  =/  todo=(list path)  ~(tap in (paths c rows))
  ?.  (lte (lent todo) 8)  [%| %local-review-read-context-capacity]
  =|  out=sources
  |-  ^-  (each sources @tas)
  ?~  todo
    ?.  (lte (bytes out) byte-limit)  [%| %local-review-read-context-capacity]
    ?:((valid p c out) [%& out] [%| %local-review-read-context-invalid])
  =/  got  (file:files p basis.c i.todo)
  ?:  ?=(%| -.got)  [%| p.got]
  $(todo t.todo, out (~(put by out) i.todo p.got))
++  protected-paths
  ::  Check libraries the target's check expressions name: /lib/<stem>/hoon in
  ::  the basis whose stem occurs in an expression. Pure and deterministic, so
  ::  the reviewer sees exactly what is specified (measured 2026-10-31: eight
  ::  candidates refused on cases the uninspected protected check never named).
  |=  [c=candidate:nc checks=(list [name=@tas expression=@t])]
  ^-  (list path)
  %+  skim  (sort ~(tap in ~(key by files.body.snapshot.basis.c)) aor)
  |=  pax=path
  ?.  ?=([%lib @ %hoon ~] pax)  %.n
  =/  stem=tape  (trip i.t.pax)
  ?.  (gte (lent stem) 8)  %.n
  %+  lien  checks
  |=  [name=@tas expression=@t]
  ?=(^ (find stem (trip expression)))
++  protected-valid
  ::  Exact named check libraries, no more and no less, bound to the basis.
  |=  [p=project:nc c=candidate:nc checks=(list [name=@tas expression=@t]) held=sources]
  ^-  ?
  ?&  ~(apt by held)  (lte (lent ~(tap by held)) 4)  (lte (bytes held) byte-limit)
      =(~(key by held) (silt (protected-paths c checks)))
      %+  levy  ~(tap by held)
      |=  [pax=path r=replacement:nc]
      ?&  =((rear pax) mark.r)  =(`mark.r (~(get by file-types.p) mark.r))
          (text-valid:files p source.r)
          =(``@ux`(page-to-lobe:clay [mark.r source.r]) (~(get by files.body.snapshot.basis.c) pax))
      ==
  ==
++  protect
  ::  Re-read every named check library from the basis through the scoped
  ::  reader. A named check the project cannot read is a configuration error
  ::  reported here, never a silently narrower review.
  |=  [p=project:nc c=candidate:nc checks=(list [name=@tas expression=@t])]
  ^-  (each sources @tas)
  =/  todo=(list path)  (protected-paths c checks)
  ?.  (lte (lent todo) 4)  [%| %local-review-protected-capacity]
  =|  out=sources
  |-  ^-  (each sources @tas)
  ?~  todo
    ?:((protected-valid p c checks out) [%& out] [%| %local-review-protected-invalid])
  =/  got  (file:files p basis.c i.todo)
  ?:  ?=(%| -.got)
    ?:(=(%path-refused p.got) [%| %local-review-protected-unreadable] [%| p.got])
  $(todo t.todo, out (~(put by out) i.todo p.got))
++  json
  |=  context=sources
  ^-  ^json
  [%a (turn ~(tap by context) |=([pax=path r=replacement:nc] (pairs:enjs:format ~[['path' s+(spat pax)] ['mark' s+(scot %tas mark.r)] ['source' s+source.r]])))]
--
