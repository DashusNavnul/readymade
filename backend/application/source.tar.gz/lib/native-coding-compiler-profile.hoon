::  Exact-law acceleration for the retained f8187302c compiler executable.
::  Hashes are native shax(jam(full tagged law)), not names or body fragments.
::  Read from the retained raw jam without executing or regenerating PLAN.
::  Source equivalence/native execution still require separate verification.
/+  base=terminal-plan
|%
++  entry-digest
  ^-  @ux
  0x5ee4.06bf.2a5d.4694.abfb.358a.9cc2.6430.4289.d34c.8638.6ae0.4a5d.0281.c002.d33d
++  law
  |=  [name=@tas op=@tas arity=@ud digest=@ux]
  ^-  [@tas [op=@tas arity=@ud digest=@ux]]
  :-  name
  [op arity digest]
++  laws
  ^-  (map @tas [op=@tas arity=@ud digest=@ux])
  %-  malt
  :~  (law %add %add 2 0x1e54.69c6.a0d7.c8f5.32b5.b598.c017.328b.0c56.fe98.c9d6.6d01.acdf.4470.5799.0984)
      (law %sub %sub 2 0xfac2.6349.66ec.630d.b9e6.56e2.269b.6b7c.c9fe.09a1.a22a.0a92.2004.0dec.419d.c2c3)
      (law %lte %lte 2 0x23e.a330.aec6.2a53.1902.4fb5.9b51.8bae.b8ab.45d3.4517.f8cc.e7c1.85ce.4dfd.03af)
      (law `@tas`'mod_nat' %mod 2 0x21c9.d65f.f528.1d45.c825.335e.5e9b.b280.1a46.52d8.f4c6.a3a0.8741.ffd4.f17d.7c4f)
      (law `@tas`'nat_eq' %eq 2 0x4c3.e2b4.c407.1795.a8d8.45b3.bad8.0a82.170a.3669.33e6.7714.c933.7999.5d11.e329)
      (law %mul %mul 2 0xce7a.f738.f4e7.6a43.8428.c088.4dcd.8e17.0c61.a217.feb6.4bda.6be9.6f06.32b9.c351)
      (law `@tas`'div_nat' %div 2 0x546f.76a9.81c0.2e5f.8f17.b913.21ba.0e21.cc9e.0c12.4053.1eb4.e47d.5603.394c.1dcd)
      (law `@tas`'bit_or' %or 2 0x1f75.d47a.43bc.cb0c.2bd9.8c42.8727.7baa.466e.91b6.0994.69e7.1ef8.923f.0c14.6e6a)
      (law %pow2 %pow 1 0xb1e5.d057.5f35.19d8.5a54.3b77.1250.d292.fac7.3137.dfa7.5442.c214.bd48.dde6.4065)
      (law `@tas`'shift_left' %shl 2 0x99ad.3dd9.07de.699b.011f.b3b2.5849.1d3c.8eaf.be77.3fa9.c939.5139.666b.ffbb.6524)
      (law `@tas`'bit_and' %and 2 0x5e35.8d00.5cc7.ea8f.f83d.59ec.2d25.4e3f.94af.f603.343a.4958.c41e.cbe0.d2c5.e40a)
      (law `@tas`'shift_right' %shr 2 0x13db.98b1.d9b2.44bc.0c60.7d22.2d06.e32e.7d82.ff1a.5cac.f728.abe3.5327.90d4.d5c6)
      (law `@tas`'nat_byte_len' %bytes 1 0xd760.d920.5ea3.a163.a374.1447.2aca.661c.3392.18d1.8be7.f6e7.9769.b8fb.e4a7.f1ff)
      (law `@tas`'nat_lt' %lt 2 0x2a67.720c.1c83.9b58.4e68.58d7.7fcb.150b.f062.6519.4826.6b9b.c80a.f68e.b503.4a02)
  ==
++  identity
  ^-  @ux
  ::  Version contract covers arithmetic, forcing order, word-cost rules and
  ::  compiler-only inc. Changing any requires a new tag/version and retained
  ::  validator; this is a version commitment, NOT a hash of native source.
  (shax (jam [%native-coding-compiler-profile-v1 entry-digest laws 262.144 64]))
++  prepare
  |=  entry=plan:base
  ^-  (unit @ux)
  ?.  =(entry-digest (shax (jam entry)))  ~
  `identity
++  lookup
  |=  [profile=@ux value=plan:base]
  ^-  [cost=@ud found=(unit @tas)]
  ?.  =(profile identity)  [1 ~]
  ?.  ?=(%law -.value)  [1 ~]
  ?.  ?=(%nat -.name.value)  [1 ~]
  ::  Names are only a cheap candidate filter. Complete identity is mandatory.
  =/  found  (~(get by laws) `@tas`value.name.value)
  ?~  found  [1 ~]
  =/  packed=@  (jam value)
  =/  cost=@ud  +((met 6 packed))
  ?.  &(=(arity.value arity.u.found) =(digest.u.found (shax packed)))  [cost ~]
  [cost `op.u.found]
--
