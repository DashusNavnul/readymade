::  Native owner Graf selection adapter. No source release or network effects.
::  Deployment prerequisite: verify the owner's bounded memory watch route and
::  exact contains route. Missing routes cannot be caught by a Hoon mule.
/+  pick=readymade-collab-graf-selection, guard=viki-scry-guard
|%
+$  refusal  $?(refusal:pick %unavailable %not-lit)
::  Exact Graf /x/by-kind-page wire shape; no substrate implementation import.
+$  kind-page
  $:  %graf-kind-page
      %1
      kind=@tas
      offset=@ud
      limit=@ud
      returned=@ud
      more=?
      next-offset=@ud
      items=(list *)
  ==
+$  view
  $:  cache=cache:pick
      offset=@ud
      returned=@ud
      skipped=@ud
      more=?
      next=(unit @ud)
  ==
++  route
  |=  url=@t
  ^-  (unit @ud)
  =/  prefix=@t  '/apps/readymade-collab/graf.json?offset='
  ?.  =(prefix (end [3 (met 3 prefix)] url))  ~
  =/  text=@t  (rsh [3 (met 3 prefix)] url)
  ?.  (lte (met 3 text) 8)  ~
  =/  number=(unit @ud)  (slaw %ud text)
  ?~  number  ~
  ?.  &(=(text (scot %ud u.number)) (lte u.number 4.096))  ~
  number
++  project
  ::  Pages are discovery, never absence/recency/current-project authority.
  ::  Unsupported or oversized records are counted, never silently substituted.
  |=  [our=@p actor=@p offset=@ud raw=*]
  ^-  (each view refusal)
  ?.  =(our actor)  [%| %foreign]
  ?.  (lte offset 4.096)  [%| %invalid]
  =/  parsed=(unit kind-page)  ((soft kind-page) raw)
  ?~  parsed  [%| %invalid]
  =/  page=kind-page  u.parsed
  ?.  ?&  =(%operator-memory kind.page)
          =(offset offset.page)
          =(64 limit.page)
          =(returned.page (lent items.page))
          (lte returned.page 64)
          =(next-offset.page (add offset returned.page))
          ?:(more.page =(64 returned.page) %.y)
      ==
    [%| %invalid]
  =/  held=cache:pick  (empty:pick our)
  =/  skipped=@ud  0
  =/  todo=(list *)  items.page
  |-  ^-  (each view refusal)
  ?~  todo
    =/  next=(unit @ud)
      ?:(&(more.page (lte next-offset.page 4.096)) `next-offset.page ~)
    [%& [held offset returned.page skipped more.page next]]
  =/  moved=change:pick  (add:pick our actor held i.todo)
  ?:  ?=(?(%stored %duplicate) result.moved)
    $(todo t.todo, held cache.moved)
  $(todo t.todo, skipped +(skipped))
++  read
  ::  Known deployed route only. Raw read avoids native return-type mismatch.
  |=  [b=bowl:gall offset=@ud]
  ^-  (each view refusal)
  ?.  =(our.b src.b)  [%| %foreign]
  ?.  (lte offset 4.096)  [%| %invalid]
  ?.  (agent-live:guard our.b now.b %graf)  [%| %unavailable]
  =/  raw=*
    .^(* %gx /(scot %p our.b)/graf/(scot %da now.b)/by-kind-page/operator-memory/(scot %ud offset)/64/noun)
  (project our.b src.b offset raw)
++  admit
  ::  Pure decision for proof: observed must come from fresh native exact
  ::  membership, never HTTP/body fields or a retained presentation snapshot.
  |=  [our=@p actor=@p held=cache:pick id=@ux observed=(unit ?)]
  ^-  (each witness:pick refusal)
  =/  selected=(each witness:pick refusal:pick)  (select:pick our actor held id)
  ?:  ?=(%| -.selected)  [%| p.selected]
  ?~  observed  [%| %unavailable]
  ?.  u.observed  [%| %not-lit]
  [%& p.selected]
++  verify
  |=  [b=bowl:gall held=cache:pick id=@ux]
  ^-  (each witness:pick refusal)
  =/  selected=(each witness:pick refusal:pick)
    (select:pick our.b src.b held id)
  ?:  ?=(%| -.selected)  [%| p.selected]
  ?.  (agent-live:guard our.b now.b %graf)  [%| %unavailable]
  =/  observed=(unit ?)
    %-  (soft ?)
    .^(* %gx /(scot %p our.b)/graf/(scot %da now.b)/contains/(scot %uw (jam fact.p.selected))/noun)
  (admit our.b src.b held id observed)
++  row-json
  |=  row=metadata:pick
  ^-  json
  %-  pairs:enjs:format
  :~  ['root' s+(scot %ux root.row)]
      ['family' s+(scot %tas family.row)]
      ['name' s+name.row]
      ['description' s+description.row]
      ['recordType' s+kind.row]
      ['source' s+source.row]
      ['recordedAt' s+(scot %da at.row)]
      ['provenance' s+provenance.row]
      ['bodyShared' b+%.n]
      ['projectAssociated' b+%.n]
      ['membership' s+'rechecked-on-offer']
  ==
++  page-json
  |=  [our=@p actor=@p page=view]
  ^-  (unit json)
  =/  listed=(each (list metadata:pick) refusal:pick)
    (rows:pick our actor cache.page)
  ?:  ?=(%| -.listed)  ~
  :-  ~
  %-  pairs:enjs:format
  :~  ['status' s+'candidates']
      ['owner' s+(scot %p our)]
      ['offset' s+(scot %ud offset.page)]
      ['returned' (numb:enjs:format returned.page)]
      ['skipped' (numb:enjs:format skipped.page)]
      ['more' b+more.page]
      ['limited' b+&(more.page =(~ next.page))]
      ['nextOffset' ?~(next.page ~ [%s (scot %ud u.next.page)])]
      ['rows' [%a (turn p.listed row-json)]]
      ['notice' s+'Choose one exact existing Graf record. Bodies are not shared. Project association is unverified. Offers require fresh native membership.']
  ==
--
