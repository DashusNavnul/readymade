::  Private Clay evidence cache. The owner app persists change.state before
::  emitting its cards. No cached GLS assembler becomes positive check evidence.
/-  nc=native-coding
/+  compiler=native-coding-compiler, runtime=native-coding-compiler-runtime,
    tools=cantrip-native-coding, project=native-coding-project,
    private=pataphor-editor-read, bootstrap=native-coding-bootstrap,
    dsr=desk-shell-read, guard=viki-scry-guard,
    source-import=native-coding-source-reservation
|%
+$  snapshot  [revision=revision:nc files=(map path lobe:clay) parents=(list tako:clay)]
+$  config  [origin=revision:nc current=revision:nc enabled=?]
+$  entry-v1
  [key=@ux original=retained-v1:runtime before=snapshot pax=path blob=lobe:clay phase=?(%submitted %confirmed %unknown) saved=(unit revision:nc) reason=@tas]
+$  organ-v1  [config=(unit config) records=(map @ux entry-v1)]
+$  entry
  [key=@ux original=retained:runtime before=snapshot pax=path blob=lobe:clay phase=?(%submitted %confirmed %unknown) saved=(unit revision:nc) reason=@tas]
+$  organ  [config=(unit config) records=(map @ux entry)]
+$  change  [state=organ cards=(list card:agent:gall)]
+$  hit
  [%native-coding-compiler-cache-hit-v1 requested=job:compiler original=retained:runtime location=revision:nc pax=path key=@ux]
+$  command
  $%  [%native-coding-compiler-store-configure-v1 source=revision:nc]
      [%native-coding-compiler-store-revoke-v1 ~]
      [%native-coding-compiler-store-v1 id=@ux]
      [%native-coding-compiler-store-observe-v1 key=@ux]
  ==
++  migrate
  |=  old=organ-v1
  ^-  organ
  old
++  legacy
  |=  s=organ
  ^-  organ-v1
  =/  rows=(list [@ux entry-v1])
    %+  murn  ~(tap by records.s)
    |=  [id=@ux e=entry]
    ?:  ?=(%native-coding-compiler-job-v2 -.input.original.e)  ~
    =/  original=retained-v1:runtime  [input.original.e output.original.e]
    `[id [key.e original before.e pax.e blob.e phase.e saved.e reason.e]]
  [config.s (malt rows)]
++  key
  |=  [j=job:compiler bundle=@ux]
  ^-  @ux
  ?:  ?=(%native-coding-compiler-job-v2 -.j)
    (shax (jam [%native-coding-compiler-cache-key-v2 project.j configuration.context.request.j source.context.request.j target.j module.j sources.j bundle mapping.j]))
  (shax (jam [%native-coding-compiler-cache-key-v1 project.j configuration.context.request.j source.context.request.j target.j module.j sources.j bundle]))
++  path-for
  |=  id=@ux
  ^-  path
  /native-coding/compiler/(scot %ux id)/noun
++  wire-for
  |=  id=@ux
  ^-  wire
  /native-compiler-store/(scot %ux id)
++  ready
  |=  s=organ
  ^-  ?
  !(lien ~(val by records.s) |=(e=entry !=(%confirmed phase.e)))
++  body
  |=  r=retained:runtime
  ^-  *
  [%native-coding-compiler-evidence-v1 input.r output.r]
++  project-free
  |=  [our=@p now=@da desk=@tas]
  ^-  ?
  =/  available  (free:source-import our now desk)
  ?:  ?=(%| -.available)  %.n
  ?.  (agent-live:guard our now %viki)  %.n
  =/  projects=(map @t project:nc)
    .^((map @t project:nc) %gx /(scot %p our)/viki/(scot %da now)/native-coding/projects/noun)
  ?>  (agent-live:guard our now %viki)
  =/  scoped=(map @ux project:nc)
    .^((map @ux project:nc) %gx /(scot %p our)/viki/(scot %da now)/native-coding/session-projects/noun)
  !(lien (weld ~(val by projects) ~(val by scoped)) |=(p=project:nc |(=(desk working.p) =(desk base-desk.spec.p))))
++  at
  ::  Inactive/private desk and direct numbered Clay reads; no date search.
  |=  [our=@p now=@da desk=@tas number=@ud]
  ^-  (unit snapshot)
  =/  d  (dome:bootstrap our now desk)
  ?~  d  ~
  ?.  &((isolated:bootstrap u.d) (private-path:private our now desk /))  ~
  =/  commit  (~(get by hit.u.d) number)
  ?~  commit  ~
  =/  y=yaki:clay
    .^(yaki:clay %cs (beam:dsr our now desk /yaki/(scot %uv u.commit)))
  ?.  (lte ~(wyt by q.y) 4.096)  ~
  =/  root=@uv  .^(@uv %cz (beam-at:dsr our desk (scot %ud number) /))
  `[[our desk number root u.commit] q.y p.y]
++  current
  |=  [our=@p now=@da desk=@tas]
  ^-  (unit snapshot)
  =/  d  (dome:bootstrap our now desk)
  ?~  d  ~
  (at our now desk let.u.d)
++  exact
  |=  [our=@p now=@da e=entry]
  ^-  (unit revision:nc)
  ?~  saved.e  ~
  =/  r=revision:nc  u.saved.e
  =/  actual  (at our now desk.r number.r)
  ?~  actual  ~
  ?.  ?&  =(r revision.u.actual)
          =(files.u.actual (~(put by files.before.e) pax.e blob.e))
          =(parents.u.actual ~[commit.revision.before.e])
          =(`blob.e (~(get by files.u.actual) pax.e))
      ==  ~
  =/  noun=*
    .^(* %cx (beam-at:dsr our desk.r (scot %ud number.r) pax.e))
  ?:(=(noun (body original.e)) `r ~)
++  publish
  |=  e=entry
  ^-  card:agent:gall
  [%give %fact ~[/native-coding/compiler-store/(scot %ux key.e)] %noun !>([%native-coding-compiler-store-status-v1 key.e phase.e saved.e reason.e])]
++  put
  |=  [our=@p s=organ e=entry cards=(list card:agent:gall)]
  ^-  change
  [s(records (~(put by records.s) key.e e)) [(publish e) [%pass /native-compiler-store-evidence %agent [our %graf] %poke %graf-action !>([%attest [%native-coding-compiler-store-v1 key.e (shax (jam e)) phase.e saved.e]])] cards]]
++  observe
  |=  [b=bowl:gall s=organ id=@ux]
  ^-  change
  =/  held  (~(get by records.s) id)
  ?~  held  [s ~]
  =/  e=entry  u.held
  ?:  =(%confirmed phase.e)  [s ~[(publish e)]]
  =/  now  (current our.b now.b desk.revision.before.e)
  ?~  now  (put our.b s e(phase %unknown, reason %cache-desk-unavailable) ~)
  ?:  =(revision.u.now revision.before.e)
    (put our.b s e(reason %cache-write-unconfirmed) ~)
  ?.  =(number.revision.u.now +(number.revision.before.e))
    (put our.b s e(phase %unknown, reason %cache-revision-conflict) ~)
  =/  candidate=entry  e(saved `revision.u.now)
  =/  confirmed  (exact our.b now.b candidate)
  ?~  confirmed  (put our.b s e(phase %unknown, reason %cache-content-conflict) ~)
  ?>  ?=(^ config.s)
  =.  s  s(config `[origin.u.config.s u.confirmed enabled.u.config.s])
  (put our.b s candidate(phase %confirmed, reason %unchecked-output-stored) ~)
++  act
  |=  [b=bowl:gall s=organ compiled=organ:runtime jobs=organ:tools c=command idle=?]
  ^-  change
  ?>  =(our.b src.b)
  ?:  ?=(%native-coding-compiler-store-revoke-v1 -.c)
    ?~  config.s  [s ~]
    [s(config `u.config.s(enabled %.n)) ~]
  ?:  ?=(%native-coding-compiler-store-observe-v1 -.c)  (observe b s key.c)
  ?:  ?=(%native-coding-compiler-store-configure-v1 -.c)
    ?>  &(idle (ready s) =(our.b owner.source.c) (revision-valid:project source.c))
    ?>  (project-free our.b now.b desk.source.c)
    =/  found  (current our.b now.b desk.source.c)
    ?>  ?=(^ found)
    ?>  =(source.c revision.u.found)
    ?^  config.s
      ?>  =(source.c current.u.config.s)
      [s(config `u.config.s(enabled %.y)) ~]
    [s(config `[source.c source.c %.y]) ~]
  ?>  ?=(%native-coding-compiler-store-v1 -.c)
  =/  retained  (~(get by emissions.compiled) id.c)
  ?>  ?=(^ retained)
  ?>  (retained-valid:runtime id.c u.retained)
  =/  r=retained:runtime  u.retained
  ?>  &(=(%unchecked status.output.r) ?=(^ output.output.r) ?=(^ compiler.output.r))
  =/  id=@ux  (key input.r u.compiler.output.r)
  =/  prior  (~(get by records.s) id)
  ?^  prior  [s ~[(publish u.prior)]]
  ?>  &(idle (ready s) (lth ~(wyt by records.s) 32))
  ?>  ?=(^ config.s)
  ?>  enabled.u.config.s
  ?>  (project-free our.b now.b desk.current.u.config.s)
  ?>  &(=(compiler.output.r ?~(bundle.compiled ~ `digest.u.bundle.compiled)) !=(desk.current.u.config.s base-desk.spec.project.input.r) !=(desk.current.u.config.s working.project.input.r))
  =/  admitted  (~(get by records.jobs) id.c)
  ?>  ?=(^ admitted)
  ?>  =(request.input.r request.u.admitted)
  =/  scope  (~(get by grants.jobs) grant.u.admitted)
  ?>  ?=(^ scope)
  =/  allowed  (allowed:tools our.b now.b u.scope request.input.r)
  ?>  ?=(%& -.allowed)
  =/  prepared  (prepare:compiler our.b now.b project.input.r request.input.r)
  ?>  &(?=(%& -.prepared) =(p.prepared input.r))
  =/  before  (current our.b now.b desk.current.u.config.s)
  ?>  ?=(^ before)
  ?>  =(revision.u.before current.u.config.s)
  ?>  (lth ~(wyt by files.u.before) 4.096)
  =/  pax=path  (path-for id)
  ?>  !(~(has by files.u.before) pax)
  =/  page=page:clay  [%noun (body r)]
  =/  e=entry  [id r u.before pax (page-to-lobe:clay page) %submitted ~ %cache-write-submitted]
  ::  The owning Cantrip event saves e before these cards leave Gall. No other
  ::  arm emits an info for e, including observe, reuse and reload validation.
  (put our.b s e ~[[%pass (wire-for id) %arvo %c %info desk.current.u.config.s [%& [[pax %ins %noun !>((body r))] ~]]] [%pass (wire-for id) %arvo %c %warp our.b desk.current.u.config.s ~ %sing %z [%ud +(number.revision.u.before)] /]])
++  arvo
  |=  [b=bowl:gall s=organ w=wire sign=sign-arvo]
  ^-  change
  ?.  &(=(our.b src.b) ?=([%native-compiler-store @ ~] w) ?=([%clay %writ *] sign))  [s ~]
  =/  id  (slaw %ux i.t.w)
  ?~  id  [s ~]
  ?.  =(w (wire-for u.id))  [s ~]
  (observe b s u.id)
++  auto
  |=  [our=@p s=organ compiled=organ:runtime id=@ux]
  ^-  (list card:agent:gall)
  ?~  config.s  ~
  ?.  enabled.u.config.s  ~
  =/  old  (~(get by emissions.compiled) id)
  ?~  old  ~
  ?.  &(=(%unchecked status.output.u.old) ?=(^ compiler.output.u.old))  ~
  ?:  (~(has by records.s) (key input.u.old u.compiler.output.u.old))  ~
  ~[[%pass /native-compiler-store-auto %agent [our %cantrip] %poke %noun !>([%native-coding-compiler-store-v1 id])]]
++  reuse
  ::  A hit preserves the ORIGINAL job/output. Caller reports reuse/location
  ::  with passed=false, never changes the old receipt to claim a new compile.
  |=  [b=bowl:gall s=organ compiled=organ:runtime jobs=organ:tools j=job:compiler]
  ^-  (each (unit hit) @tas)
  ?.  =(our.b src.b)  [%| %cache-owner-required]
  ?~  config.s  [%& ~]
  ?.  enabled.u.config.s  [%& ~]
  ?~  bundle.compiled  [%& ~]
  =/  id=@ux  (key j digest.u.bundle.compiled)
  =/  held  (~(get by records.s) id)
  ?~  held  [%& ~]
  =/  e=entry  u.held
  ?.  =(%confirmed phase.e)  [%| %cache-write-unconfirmed]
  =/  admitted  (~(get by records.jobs) (key:tools request.j))
  ?~  admitted  [%| %cache-tool-not-admitted]
  ?.  &(=(%running stage.u.admitted) =(request.j request.u.admitted))  [%| %cache-tool-not-pending]
  =/  scope  (~(get by grants.jobs) grant.u.admitted)
  ?~  scope  [%| %cache-grant-missing]
  =/  permission  (allowed:tools our.b now.b u.scope request.j)
  ?:  ?=(%| -.permission)  [%| p.permission]
  ?.  (pending:tools our.b now.b request.j)  [%| %cache-viki-request-mismatch]
  =/  prepared  (prepare:compiler our.b now.b project.j request.j)
  ?.  &(?=(%& -.prepared) =(p.prepared j))  [%| %cache-source-mismatch]
  ?.  =(`digest.u.bundle.compiled compiler.output.original.e)  [%| %cache-compiler-mismatch]
  =/  location  (exact our.b now.b e)
  ?~  location  [%| %cache-clay-mismatch]
  [%& `[%native-coding-compiler-cache-hit-v1 j original.e u.location pax.e id]]
++  lookup
  |=  [b=bowl:gall s=organ compiled=organ:runtime jobs=organ:tools id=@ux]
  ^-  (each (unit hit) @tas)
  ?.  =(our.b src.b)  [%| %cache-owner-required]
  =/  found  (~(get by records.jobs) id)
  ?~  found  [%| %cache-tool-not-admitted]
  ?.  &(=(%running stage.u.found) =(id (key:tools request.u.found)))
    [%| %cache-tool-not-pending]
  =/  scope  (~(get by grants.jobs) grant.u.found)
  ?~  scope  [%| %cache-grant-missing]
  =/  permission  (allowed:tools our.b now.b u.scope request.u.found)
  ?:  ?=(%| -.permission)  [%| p.permission]
  =/  prepared  (prepare:compiler our.b now.b project.grant.u.scope request.u.found)
  ?:  ?=(%| -.prepared)  [%| p.prepared]
  (reuse b s compiled jobs p.prepared)
++  report
  |=  h=hit
  ^-  tool-output:nc
  =/  original=retained:runtime  original.h
  ?.  ?&  (retained-valid:runtime (key:tools request.input.original) original)
          =(%unchecked status.output.original)  ?=(^ output.output.original)
          ?=(^ compiler.output.original)
          =(key.h (key requested.h (need compiler.output.original)))
          =(key.h (key input.original (need compiler.output.original)))
          =(pax.h (path-for key.h))  (revision-valid:project location.h)
      ==  [%refused %cache-hit-invalid 'Cached output does not match the requested source and compiler.']
  =/  emitted=emission:compiler  (need output.output.original)
  =/  detail=@t
    (rap 3 ~['Reused unchecked GLS output; no fresh compilation or passing check. Original job ' (scot %ux job.output.original) '; cache ' (scot %ux key.h) '; emission ' (scot %ux digest.emitted) '; Clay ' (scot %p owner.location.h) '/' desk.location.h ' revision ' (scot %ud number.location.h) ' commit ' (scot %uv commit.location.h) ' root ' (scot %uv root.location.h) ' path ' (spat pax.h)])
  [%diagnostics ~[[%gallowglass-cache %.n detail source.context.request.requested.h ~[job.output.original key.h digest.emitted (shax (jam location.h))]]]]
++  valid
  |=  [our=@p s=organ]
  ^-  ?
  ?.  (lte ~(wyt by records.s) 32)  %.n
  ?~  config.s  ?=(~ records.s)
  ?&  (lte (lent (skim ~(val by records.s) |=(e=entry !=(%confirmed phase.e)))) 1)
      &(=(our owner.current.u.config.s) =(our owner.origin.u.config.s) =(desk.current.u.config.s desk.origin.u.config.s) (gte number.current.u.config.s number.origin.u.config.s) (revision-valid:project current.u.config.s) (revision-valid:project origin.u.config.s))
      %+  levy  ~(tap by records.s)
      |=  [id=@ux e=entry]
      ?&  =(id key.e)  =(pax.e (path-for id))
          (retained-valid:runtime (key:tools request.input.original.e) original.e)
          =(%unchecked status.output.original.e)  ?=(^ compiler.output.original.e)
          =(id (key input.original.e (need compiler.output.original.e)))
          =(blob.e (page-to-lobe:clay [%noun (body original.e)]))
          !(~(has by files.before.e) pax.e)
          =(our owner.revision.before.e)  (lte ~(wyt by files.before.e) 4.096)
          (revision-valid:project revision.before.e)
          (revision-valid:project source.context.request.input.original.e)
          =(desk.revision.before.e desk.current.u.config.s)
          (gte number.revision.before.e number.origin.u.config.s)
          ?:  =(%confirmed phase.e)
            ?~  saved.e  %.n
            &((revision-valid:project u.saved.e) =(our owner.u.saved.e) =(desk.revision.before.e desk.u.saved.e) (lte number.u.saved.e number.current.u.config.s) =(+(number.revision.before.e) number.u.saved.e))
          &(?=(~ saved.e) =(revision.before.e current.u.config.s))
      ==
  ==
--
