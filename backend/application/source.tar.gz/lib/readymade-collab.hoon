::  Pure receiver-owned workflow indexes. No transport, inspect or execution.
/-  rc=readymade-collab, pkg=readymade-package, pact=readymade-pact
/+  package=readymade-package, agreement=readymade-pact
|%
++  empty
  ^-  state:rc
  [%readymade-collab-v1 ~ ~ ~ ~]
++  bounded-text
  |=  [text=@t limit=@ud]
  ^-  ?
  (lte (met 3 text) limit)
++  identifier
  |=  text=@t
  ^-  ?
  &(!=('' text) (bounded-text text 128))
++  fingerprint
  |=  e=envelope:rc
  ^-  @ux
  (shax (jam [%readymade-collab-request-v1 e]))
++  record
  ::  Bounded presentation history, not authority or the Graf evidence store.
  |=  [s=state:rc r=receipt:rc]
  ^-  state:rc
  ?.  ?&  (bounded-text id.r 128)
          (bounded-text op.r 128)
          (bounded-text message.r 512)
      ==
    s
  =/  prior=(list receipt:rc)  (skim receipts.s |=(old=receipt:rc !=(id.old id.r)))
  s(receipts (scag 128 `(list receipt:rc)`[r prior]))
++  admitted
  |=  [s=state:rc sender=@p e=envelope:rc duplicate=?]
  ^-  change:rc
  ::  Full replay indexes never prevent revocation or grow beyond the cap.
  ::  Pact owner sequences still reject a second application of the move.
  ?:  (gte ~(wyt by requests.s) 4.096)
    [s & duplicate ?:(duplicate %duplicate %accepted)]
  [s(requests (~(put by requests.s) [sender request.e] (fingerprint e))) & duplicate ?:(duplicate %duplicate %accepted)]
++  revoking
  |=  e=envelope:rc
  ^-  ?
  ?.  ?=(%pact -.payload.e)  %.n
  ?=(%revoke -.action.move.payload.e)
++  member
  |=  [our=@p sender=@p terms=terms:pact]
  ^-  ?
  ?&  |(=(our left.terms) =(our right.terms))
      |(=(sender left.terms) =(sender right.terms))
  ==
++  receive
  ::  sender comes from Ames or a local owner-authorized action. All prior
  ::  state comes from the receiver's saved core, never an inbound noun.
  |=  [s=state:rc our=@p sender=@p e=envelope:rc]
  ^-  change:rc
  ?.  &((identifier request.e) (lte (met 3 (jam e)) 131.072))
    [s | | %invalid-envelope]
  =/  prior=(unit @ux)  (~(get by requests.s) [sender request.e])
  ?^  prior
    ?:  =(u.prior (fingerprint e))  [s & & %duplicate]
    [s | | %request-conflict]
  ?:  &((gte ~(wyt by requests.s) 4.096) !(revoking e))
    [s | | %request-capacity]
  ?-  -.payload.e
    %package
      ?.  &((identifier title.payload.e) (bounded-text summary.payload.e 4.096))
        [s | | %invalid-metadata]
      =/  o=offer:pkg  offer.payload.e
      =/  old=(unit package:rc)  (~(get by packages.s) digest.o)
      =/  prior-state=(unit state:pkg)
        ?~(old ~ `value.u.old)
      =/  result  (receive:package our sender o prior-state)
      ?.  ?=(%& -.result)  [s | | p.result]
      ?^  old  (admitted s sender e &)
      ?:  (gte ~(wyt by packages.s) 256)  [s | | %package-capacity]
      =/  entry=package:rc  [title.payload.e summary.payload.e p.result]
      (admitted s(packages (~(put by packages.s) digest.o entry)) sender e |)
    %propose
      ?.  &((identifier reference.payload.e) (bounded-text text.payload.e 16.384))
        [s | | %invalid-metadata]
      =/  terms=terms:pact  terms.payload.e
      ?.  (member our sender terms)  [s | | %not-party]
      ?.  &(!=('' text.payload.e) =(scope.terms (shax text.payload.e)))
        [s | | %scope-mismatch]
      ?.  =(reference.payload.e (scot %ux package.terms))
        [s | | %package-reference-mismatch]
      =/  source=(unit package:rc)  (~(get by packages.s) package.terms)
      ?~  source  [s | | %unknown-package]
      =/  offered=offer:pkg  offer.value.u.source
      ?.  ?&  (valid:package offered)
              =(package.terms digest.offered)
              =(graf-root.terms graf-root.body.offered)
              =(project.terms title.u.source)
              ?|  &(=(sender.body.offered left.terms) =(recipient.body.offered right.terms))
                  &(=(sender.body.offered right.terms) =(recipient.body.offered left.terms))
              ==
          ==
        [s | | %package-binding-mismatch]
      =/  fresh=(unit state:pact)  (init:agreement terms)
      ?~  fresh  [s | | %invalid-terms]
      =/  id=@ux  (digest:agreement terms)
      =/  old=(unit agreement:rc)  (~(get by pacts.s) id)
      ?^  old
        ?.  =(terms terms.value.u.old)  [s | | %terms-conflict]
        ?.  &(=(reference.payload.e reference.u.old) =(text.payload.e text.u.old))
          [s | | %metadata-conflict]
        (admitted s sender e &)
      ?:  (gte ~(wyt by pacts.s) 256)  [s | | %pact-capacity]
      =/  entry=agreement:rc  [reference.payload.e text.payload.e u.fresh]
      (admitted s(pacts (~(put by pacts.s) id entry)) sender e |)
    %pact
      =/  old=(unit agreement:rc)  (~(get by pacts.s) id.payload.e)
      ?~  old  [s | | %unknown-pact]
      =/  entry=agreement:rc  u.old
      ?.  =(id.payload.e (digest:agreement terms.value.entry))
        [s | | %terms-conflict]
      ?.  (member our sender terms.value.entry)  [s | | %not-party]
      =/  next=(unit state:pact)  (step:agreement value.entry sender move.payload.e)
      ?~  next  [s | | %pact-refused]
      (admitted s(pacts (~(put by pacts.s) id.payload.e entry(value u.next))) sender e |)
  ==
--
