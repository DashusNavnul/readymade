::  Session-bound editor feedback in the existing saved delivery cord.
|%
++  starts
  |=  [prefix=@t text=@t]
  ^-  ?
  =(prefix (cut 3 [0 (met 3 prefix)] text))
++  prefix
  |=  session=@ux
  ^-  @t
  (rap 3 ~['Editor refused for ' (scot %ux session) ': '])
++  refuse
  |=  [session=@ux reason=@tas]
  ^-  @t
  (cat 3 (prefix session) (scot %tas reason))
++  view
  |=  [session=@ux delivery=@t]
  ^-  @t
  ::  Legacy errors have no owner. Retain their saved bytes, but do not
  ::  attribute them to whichever session happens to be selected.
  ?:  (starts 'Editor refused: ' delivery)  ''
  ?.  (starts 'Editor refused for ' delivery)  delivery
  =/  expected=@t  (prefix session)
  ?.  (starts expected delivery)  ''
  (cat 3 'Editor refused: ' (rsh [3 (met 3 expected)] delivery))
++  clear
  |=  [session=@ux delivery=@t]
  ^-  @t
  ?:  (starts 'Editor refused: ' delivery)  ''
  ?:  (starts (prefix session) delivery)  ''
  delivery
--
