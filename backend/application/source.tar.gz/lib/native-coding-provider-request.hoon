::  Native Iris request construction; returned cards are not sent here.
::  References: OpenAI Responses, Anthropic Messages, xAI Chat Completions.
::  External APIs see function definitions, never Urbit permission objects.
/-  p=native-coding-provider
/+  law=native-coding-provider
|%
++  result-text
  |=  b=block:p
  ^-  @t
  ?>  ?=(%result -.b)
  (en:json:html (pairs:enjs:format ~[['failed' b+failed.b] ['output' s+text.b]]))
++  function
  |=  t=tool:p
  ^-  json
  (pairs:enjs:format ~[['name' s+name.t] ['description' s+description.t] ['parameters' parameters.t]])
++  tools
  |=  [style=wire-format:p definitions=(list tool:p)]
  ^-  json
  :-  %a
  %+  turn  definitions
  |=  t=tool:p
  ?:  =(%messages style)
    (pairs:enjs:format ~[['name' s+name.t] ['description' s+description.t] ['input_schema' parameters.t]])
  ?:  =(%chat style)
    (pairs:enjs:format ~[['type' s+'function'] ['function' (function t)]])
  (pairs:enjs:format ~[['type' s+'function'] ['name' s+name.t] ['description' s+description.t] ['parameters' parameters.t] ['strict' b+%.n]])
++  responses-block
  |=  [role=?(%user %assistant) b=block:p]
  ^-  json
  ?-  -.b
    %text
      (pairs:enjs:format ~[['role' s+role] ['content' a+~[(pairs:enjs:format ~[['type' s+'input_text'] ['text' s+text.b]])]]])
    %call
      (pairs:enjs:format ~[['type' s+'function_call'] ['call_id' s+id.call.b] ['name' s+name.call.b] ['arguments' s+(en:json:html arguments.call.b)]])
    %result
      (pairs:enjs:format ~[['type' s+'function_call_output'] ['call_id' s+id.b] ['output' s+(result-text b)]])
    %opaque  value.b
  ==
++  anthropic-block
  |=  b=block:p
  ^-  json
  ?-  -.b
    %text  (pairs:enjs:format ~[['type' s+'text'] ['text' s+text.b]])
    %call  (pairs:enjs:format ~[['type' s+'tool_use'] ['id' s+id.call.b] ['name' s+name.call.b] ['input' arguments.call.b]])
    %result  (pairs:enjs:format ~[['type' s+'tool_result'] ['tool_use_id' s+id.b] ['content' s+text.b] ['is_error' b+failed.b]])
    %opaque  value.b
  ==
++  chat-message
  |=  message=message:p
  ^-  (list json)
  ?:  =(%user role.message)
    %+  turn  content.message
    |=  b=block:p
    ?:  ?=(%result -.b)
      (pairs:enjs:format ~[['role' s+'tool'] ['tool_call_id' s+id.b] ['content' s+(result-text b)]])
    ?>  ?=(%text -.b)
    (pairs:enjs:format ~[['role' s+'user'] ['content' s+text.b]])
  =/  text=@t
    (rap 3 (murn content.message |=(b=block:p ?:(?=(%text -.b) `text.b ~))))
  =/  calls=(list json)
    %+  murn  content.message
    |=  b=block:p
    ?.  ?=(%call -.b)  ~
    `(pairs:enjs:format ~[['id' s+id.call.b] ['type' s+'function'] ['function' (pairs:enjs:format ~[['name' s+name.call.b] ['arguments' s+(en:json:html arguments.call.b)]])]])
  =/  fields=(list [@t json])  ~[['role' s+'assistant'] ['content' s+text]]
  ~[(pairs:enjs:format ?~(calls fields [['tool_calls' a+calls] fields]))]
++  history
  |=  [selection=selection:p messages=(list message:p)]
  ^-  (list json)
  =/  style=wire-format:p  format.selection
  %-  zing
  %+  turn  messages
  |=  message=message:p
  =.  content.message
    %+  skim  content.message
    |=  b=block:p
    ?.  ?=(%opaque -.b)  %.y
    &(=(provider.selection provider.b) =(model.selection model.b))
  ?~  content.message  ~
  ?:  =(%chat style)  (chat-message message)
  ?:  =(%messages style)
    ~[(pairs:enjs:format ~[['role' s+role.message] ['content' a+(turn content.message anthropic-block)]])]
  (turn content.message |=(b=block:p (responses-block role.message b)))
++  wire-bytes
  ::  History as the provider receives it: JSON, every repeat counted.
  ::  Jam shares repeated nouns, so it under-counts a resent patch.
  |=  [selection=selection:p messages=(list message:p)]
  ^-  @ud
  (met 3 (en:json:html [%a (history selection messages)]))
++  encode
  |=  r=request:p
  ^-  (each @t @tas)
  ?.  (request-valid:law r)  [%| %request-invalid]
  =/  style=wire-format:p  format.selection.r
  =/  messages=(list json)  (history selection.r history.r)
  =/  fields=(list [@t json])
    :~  ['model' s+model.selection.r]
        ['stream' b+streaming.r]
        ['tools' (tools style tools.r)]
    ==
  =.  fields
    ?:  =(%messages style)
      =/  choice=(list [@t json])
        ?~  tools.r  ~
        ~[['tool_choice' (pairs:enjs:format ~[['type' s+'auto'] ['disable_parallel_tool_use' b+=(parallel.capabilities.selection.r %.n)]])]]
      (weld fields (weld choice `(list [@t json])`~[['system' s+instructions.r] ['messages' a+messages] ['max_tokens' (numb:enjs:format max-output.r)]]))
    ?:  =(%chat style)
      =/  system=json  (pairs:enjs:format ~[['role' s+'system'] ['content' s+instructions.r]])
      ::  xAI refuses tool_choice with no tools ("A tool_choice was set on
      ::  the request but no tools were specified", measured 2026-09-14) and
      ::  OpenAI refuses parallel_tool_calls the same way. Neither field is
      ::  sent unless there is a tool to choose.
      =/  limits=(list [@t json])
        ?~  tools.r  ~[['max_tokens' (numb:enjs:format max-output.r)]]
        ~[['max_tokens' (numb:enjs:format max-output.r)] ['parallel_tool_calls' b+parallel.capabilities.selection.r]]
      =/  limits=(list [@t json])
        ?:  =(streaming.r %.n)  limits
        [['stream_options' (pairs:enjs:format ~[['include_usage' b+%.y]])] limits]
      =/  choice=(list [@t json])
        ?~  tools.r  ~
        ~[['tool_choice' s+'auto']]
      (weld fields (weld limits (weld `(list [@t json])`~[['messages' a+[system messages]]] choice)))
    =/  extra=(list [@t json])
      :~  ['instructions' s+instructions.r]
          ['input' a+messages]
          ['store' b+%.n]
          ['tool_choice' s+'auto']
          ['parallel_tool_calls' b+parallel.capabilities.selection.r]
          ['include' a+~[s+'reasoning.encrypted_content']]
      ==
    ::  The Codex login backend does not advertise max_output_tokens.
    =/  extra=(list [@t json])
      ?:  =(%codex provider.selection.r)  extra
      [['max_output_tokens' (numb:enjs:format max-output.r)] extra]
    (weld fields extra)
  =/  body=@t  (en:json:html (pairs:enjs:format fields))
  ?.  (lte (met 3 body) request-limit:p)  [%| %request-too-large]
  [%& body]
++  prepare
  ::  Private return value: includes authorization headers. Never publish it.
  |=  [r=request:p credentials=credentials:p]
  ^-  (each [request=request:http config=outbound-config:iris] @tas)
  ?.  ?&  (credentials-valid:law credentials)
          =(provider.credentials provider.selection.r)
          =(endpoint.credentials endpoint.selection.r)
      ==  [%| %credential-destination-mismatch]
  =/  body  (encode r)
  ?.  ?=(%& -.body)  [%| p.body]
  =/  headers=(list [@t @t])
    ~[['content-type' 'application/json'] ['accept' ?:(streaming.r 'text/event-stream' 'application/json')]]
  =.  headers
    ?:  =(%anthropic provider.selection.r)
      (weld headers ~[['x-api-key' secret.credentials] ['anthropic-version' anthropic-version:p]])
    =/  headers=(list [@t @t])
      [['authorization' (cat 3 'Bearer ' secret.credentials)] headers]
    ::  Grok CLI session proxy: fixed destination and headers, no custom map.
    ::  Installed CLI 1.0.13 documents the ordinary chat/SSE wire here.
    ?:  &(=(%xai provider.selection.r) =(endpoint.selection.r xai-session-endpoint:p))
      (weld headers ~[['X-XAI-Token-Auth' 'xai-grok-cli'] ['x-grok-model-override' model.selection.r] ['x-grok-client-version' grok-cli-version:p]])
    ?:  !=(%codex provider.selection.r)  headers
    (weld headers ~[['ChatGPT-Account-ID' account.credentials] ['originator' 'codex_cli_rs']])
  [%& [[%'POST' endpoint.selection.r headers `[(met 3 p.body) p.body]] [0 0]]]
++  iris-card
  ::  The Gall owner must correlate this wire, retain pending state, and send
  ::  once. Browser reconnection and provider switching do not invoke it.
  |=  [wire=path r=request:p credentials=credentials:p]
  ^-  (each card:agent:gall @tas)
  =/  prepared  (prepare r credentials)
  ?.  ?=(%& -.prepared)  [%| p.prepared]
  [%& [%pass wire %arvo %i %request request.p.prepared config.p.prepared]]
--
