::  Durable provider transport inside the existing codex-inference Gall app.
::  This owns no coding continuation or tool execution. Viki owns both.
/-  p=native-coding-provider
/+  law=native-coding-provider, outbound=native-coding-provider-request,
    inbound=native-coding-provider-response
|%
++  job-limit  256
++  pending-limit  9
+$  outcome
  $%  [%pending ~]
      [%result value=reply:p]
      [%failed error=failure:p]
      [%cancelled ~]
      [%unknown ~]
      [%missing ~]
      [%conflict ~]
      [%refused reason=@tas]
  ==
+$  event  [%native-coding-event id=@ux session=@ux outcome=outcome]
+$  evidence
  ::  Private HTTP receipt, including bounded bytes for failed normalization.
  [status=@ud bytes=@ud digest=@ux prefix=octs truncated=?]
+$  job
  [request=request:p selection=@tas body=@t started=@da outcome=outcome evidence=(unit evidence)]
+$  state
  [%native-coding-inference-state-v1 controller=@tas vault=vault:p selections=selections:p jobs=(map @ux job)]
+$  command
  $%  [%native-coding-configure key=@tas credentials=credentials:p]
      [%native-coding-disconnect key=@tas]
      [%native-coding-select key=@tas selection=selection:p]
      [%native-coding-controller agent=@tas]
      [%native-coding-infer selection=@tas request=request:p]
      [%native-coding-cancel id=@ux]
      [%native-coding-observe id=@ux]
  ==
+$  transition  [state=state cards=(list card:agent:gall)]
++  empty
  ^-  state
  [%native-coding-inference-state-v1 %viki ~ ~ ~]
++  pending
  |=  s=state
  ^-  @ud
  (lent (skim ~(tap by jobs.s) |=([id=@ux j=job] ?=(%pending -.outcome.j))))
++  credential-busy
  |=  [s=state key=@tas]
  ^-  ?
  %+  lien  ~(tap by jobs.s)
  |=  [id=@ux j=job]
  &(?=(%pending -.outcome.j) =(key credential.selection.request.j))
++  notice
  ::  Deliberate point-to-point private delivery. No public fact or scry.
  ::  Receivers validate the event value. A noun envelope keeps the provider
  ::  library's recursive type context out of Gall's message conversion.
  |=  [our=@p controller=@tas id=@ux session=@ux result=outcome]
  ^-  card:agent:gall
  [%pass /native-coding/result/(scot %ux id) %agent [our controller] %poke %noun !>(`*``event`[%native-coding-event id session result])]
++  cancel-card
  |=  id=@ux
  ^-  card:agent:gall
  [%pass /native-infer/(scot %ux id) %arvo %i %cancel-request ~]
++  refused
  |=  [our=@p s=state id=@ux session=@ux reason=@tas]
  ^-  transition
  [s ~[(notice our controller.s id session [%refused reason])]]
++  submit
  |=  [our=@p at=@da s=state key=@tas r=request:p]
  ^-  transition
  =/  previous=(unit job)  (~(get by jobs.s) id.r)
  ?^  previous
    =/  result=outcome
      ?:  &(=(key selection.u.previous) =(r request.u.previous))  outcome.u.previous
      [%conflict ~]
    [s ~[(notice our controller.s id.r session.r result)]]
  =/  selected=(unit selection:p)  (~(get by selections.s) key)
  ?.  =(`selection.r selected)  (refused our s id.r session.r %selection-mismatch)
  ?.  (lth ~(wyt by jobs.s) job-limit)  (refused our s id.r session.r %receipt-capacity)
  ?.  (lth (pending s) pending-limit)  (refused our s id.r session.r %inference-busy)
  =/  credentials=(unit credentials:p)  (~(get by vault.s) credential.selection.r)
  ?~  credentials  (refused our s id.r session.r %credential-missing)
  =/  prepared  (prepare:outbound r u.credentials)
  ?:  ?=(%| -.prepared)  (refused our s id.r session.r p.prepared)
  =/  body=octs  (need body.request.p.prepared)
  =/  j=job  [r key q.body at [%pending ~] ~]
  =/  card=card:agent:gall
    [%pass /native-infer/(scot %ux id.r) %arvo %i %request request.p.prepared config.p.prepared]
  [s(jobs (~(put by jobs.s) id.r j)) ~[(notice our controller.s id.r session.r [%pending ~]) card]]
++  handle
  |=  [our=@p src=@p at=@da s=state action=command]
  ^-  transition
  ?.  =(our src)  [s ~]
  ?:  ?=(%native-coding-controller -.action)
    ?.  (name-valid:law agent.action)  (refused our s 0x0 0x0 %controller-invalid)
    ::  A controller cannot take over somebody else's pending delivery.
    ?.  =(0 (pending s))  (refused our s 0x0 0x0 %inference-busy)
    [s(controller agent.action) ~]
  ?:  ?=(%native-coding-select -.action)
    =/  result  (select:law our src key.action selection.action selections.s)
    ?:  ?=(%| -.result)  (refused our s 0x0 0x0 p.result)
    [s(selections p.result) ~]
  ?:  ?=(%native-coding-configure -.action)
    ?:  (credential-busy s key.action)  (refused our s 0x0 0x0 %credential-busy)
    =/  result  (configure:law our src key.action credentials.action vault.s)
    ?:  ?=(%| -.result)  (refused our s 0x0 0x0 p.result)
    [s(vault p.result) ~]
  ?:  ?=(%native-coding-disconnect -.action)
    ?:  (credential-busy s key.action)  (refused our s 0x0 0x0 %credential-busy)
    [s(vault (~(del by vault.s) key.action)) ~]
  ?:  ?=(%native-coding-infer -.action)
    (submit our at s selection.action request.action)
  =/  found=(unit job)  (~(get by jobs.s) id.action)
  ?~  found  [s ~[(notice our controller.s id.action 0x0 [%missing ~])]]
  =/  j=job  u.found
  ?:  |(?=(%native-coding-observe -.action) !=(%pending -.outcome.j))
    [s ~[(notice our controller.s id.action session.request.j outcome.j)]]
  =.  outcome.j  [%cancelled ~]
  [s(jobs (~(put by jobs.s) id.action j)) ~[(cancel-card id.action) (notice our controller.s id.action session.request.j outcome.j)]]
++  receive
  |=  [our=@p s=state id=@ux response=client-response:iris]
  ^-  transition
  =/  held=(unit job)  (~(get by jobs.s) id)
  ?~  held  [s ~]
  =/  j=job  u.held
  =/  current  outcome.j
  ?.  ?=(%pending -.current)  [s ~]
  ?:  ?=(%cancel -.response)
    =.  outcome.j  [%unknown ~]
    [s(jobs (~(put by jobs.s) id j)) ~[(notice our controller.s id session.request.j outcome.j)]]
  ?.  ?=(%finished -.response)  [s ~]
  =/  status=@ud  status-code.response-header.response
  =/  data=octs  ?~(full-file.response [0 0] data.u.full-file.response)
  =/  bytes=@ud  (max p.data (met 3 q.data))
  =/  size=@ud  (min bytes response-limit:p)
  =.  evidence.j  `[status bytes (shax q.data) [size (end [3 size] q.data)] (gth bytes size)]
  =/  decoded  (decode:inbound request.j status data)
  =.  outcome.j
    ?:  ?=(%& -.decoded)  [%result p.decoded]
    [%failed p.decoded]
  =.  vault.s
    ?.  =(401 status)  vault.s
    (~(del by vault.s) credential.selection.request.j)
  [s(jobs (~(put by jobs.s) id j)) ~[(notice our controller.s id session.request.j outcome.j)]]
++  reload
  |=  [our=@p s=state]
  ^-  transition
  =/  todo=(list [@ux job])  ~(tap by jobs.s)
  =/  cards=(list card:agent:gall)  ~
  |-  ^-  transition
  =/  rest=(list [@ux job])  todo
  ?~  rest  [s cards]
  =/  id=@ux  -.i.rest
  =/  j=job  +.i.rest
  =/  current  outcome.j
  ?.  ?=(%pending -.current)  $(todo t.rest)
  =.  outcome.j  [%unknown ~]
  $(todo t.rest, s s(jobs (~(put by jobs.s) id j)), cards (weld cards ~[(cancel-card id) (notice our controller.s id session.request.j outcome.j)]))
++  state-valid
  |=  s=state
  ^-  ?
  ?&  (name-valid:law controller.s)
      (lte ~(wyt by vault.s) vault-limit:p)
      (lte ~(wyt by selections.s) selection-limit:p)
      (lte ~(wyt by jobs.s) job-limit)
      (lte (pending s) pending-limit)
      (levy ~(tap by vault.s) |=([key=@tas c=credentials:p] (credentials-valid:law c)))
      (levy ~(tap by selections.s) |=([key=@tas value=selection:p] (selection-valid:law value)))
      %+  levy  ~(tap by jobs.s)
      |=  [id=@ux j=job]
      ?&  =(id id.request.j)  (request-valid:law request.j)
          (lte (met 3 body.j) request-limit:p)
          ?~  evidence.j  %.y
          =/  e=evidence  u.evidence.j
          ?&  =(p.prefix.e (min bytes.e response-limit:p))
              (lte (met 3 q.prefix.e) p.prefix.e)
              =(truncated.e (gth bytes.e p.prefix.e))
              ?:(truncated.e %.y =(digest.e (shax q.prefix.e)))
          ==
          ?:  ?=(%result -.outcome.j)
            =/  r=reply:p  value.outcome.j
            ?&  =(id id.r)  =(provider.selection.request.j provider.r)
                (lte (met 3 raw.r) response-limit:p)
                =(raw-digest.r (shax raw.r))
                (calls-valid:law calls.r tools.request.j)
            ==
          ?:  ?=(%failed -.outcome.j)  =(id id.error.outcome.j)
          ?|(?=(%pending -.outcome.j) ?=(%unknown -.outcome.j) ?=(%cancelled -.outcome.j))
      ==
  ==
++  status
  |=  s=state
  ^-  *
  [%native-coding-inference-status-v1 controller.s ~(wyt by vault.s) ~(wyt by selections.s) (pending s) ~(wyt by jobs.s)]
--
