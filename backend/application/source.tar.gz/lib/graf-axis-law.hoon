::  /lib/graf-axis-law
::
::  THE WRITE-AUTHORITY LAW OF THE SHARED GRAPH, LIFTED OUT WHERE IT CAN BE
::  PROVEN.
::
::  %graf addresses its whole contents as a Nock-style binary tree: axis 1
::  is the root, 2 and 3 its children, and every domain and every seat owns
::  a pinned subtree beneath it.  A seat writes by naming a region axis and
::  a RELATIVE axis inside it; the absolute axis is the relative tree
::  grafted under the region root.  That is the coordinate system N agents
::  share, and +axis-write-authorized is the gate that decides whether a
::  given seat may write a given coordinate.
::
::  WHY THIS FILE EXISTS.  That gate lives inside app/graf.hoon, which is
::  5.454 lines and cannot be imported by a thread.  So the one function
::  standing between two agents and each other's work has never been
::  provable in isolation.  For a single operator poking their own ship
::  that is untidy; for multiplayer it is the whole safety argument, and an
::  authorization function with no test is not a safety argument.
::
::  STATUS: this is the law, and app/graf.hoon calls it.  One site.
::
::  Extracted verbatim from app/graf.hoon: +root-axis, +domain-trunk-axis,
::  +seat-trunk-axis, +domain-axis-for, +seat-region-axis-for,
::  +nonzero-axis, +extend-axis-under-root, +absolute-axis-for-region,
::  +structural-region-axis-authorized, +seat-write-authorizes-axis,
::  +find-seat-write, +axis-write-authorized, +axis-ancestor-axes,
::  +axis-slot-path.
::
/-  graf-sur=graf
|%
++  root-axis  1
++  domain-trunk-axis  2
++  seat-trunk-axis  3
::
::  the shared domains.  Every seat may write these -- they are the common
::  ground, and that is the point of them.
::
++  domain-axis-for
  |=  domain=@tas
  ^-  @ud
  ?+    domain  domain-trunk-axis
      %handle-registry  4
      %graph-matter  5
      %machine-topology  8
      %runtime-state  9
      %bundle-packet-state  10
      %circulation-facts  11
      %bride-memory  16
      %crossing-lane  17
      %projection-views  18
  ==
::
::  THE OLD MAP, kept only so the proof can demonstrate what was wrong
::  with it.  Nothing reads this for authority.
::
::  MEASURED 2026-08-16: these nine axes are NOT pairwise disjoint -- ten
::  nesting pairs, and axis 26 was claimed by three seats at once.  Also
::  measured, on live dashus: none of the nine were ever in use (the only
::  seat is %frag), so renumbering cost nothing.
::
++  legacy-seat-region-axis-for
  |=  seat-id=@tas
  ^-  (unit @ud)
  ?+    seat-id  ~
      %flunky  [~ 6]
      %busboy  [~ 7]
      %policeman  [~ 12]
      %gendarme  [~ 13]
      %undertaker  [~ 14]
      %priest  [~ 15]
      %delivery-boy  [~ 24]
      %cuirassier  [~ 25]
      %stationmaster  [~ 26]
  ==
::
++  nonzero-axis
  |=  axis=@ud
  ^-  ?
  ?:(=(axis 0) %.n %.y)
::
::  graft a relative tree under a base axis.  Relative 1 is the region root
::  itself; even steps go left, odd steps go right, exactly as Nock reads a
::  noun.
::
++  extend-axis-under-root
  |=  [base-axis=@ud relative-axis=@ud]
  ^-  @ud
  ?:  =(relative-axis 1)
    base-axis
  ?:  =(0 (mod relative-axis 2))
    (mul 2 $(relative-axis (div relative-axis 2)))
  (add 1 (mul 2 $(relative-axis (div relative-axis 2))))
::
++  absolute-axis-for-region
  |=  [region-axis=@ud relative-axis=@ud]
  ^-  (unit @ud)
  ?.  (nonzero-axis relative-axis)
    ~
  ?:  =(region-axis 0)
    ~
  [~ (extend-axis-under-root region-axis relative-axis)]
::
::  may this seat name this region at all?  Its own, or any shared domain.
::
++  structural-region-axis-authorized
  |=  [seat-id=@tas region-axis=@ud]
  ^-  ?
  =/  seat-region  (seat-region-axis-for seat-id)
  ?:  ?&  ?=(^ seat-region)
          =(region-axis u.seat-region)
      ==
    %.y
  ?|  =((domain-axis-for %handle-registry) region-axis)
      =((domain-axis-for %graph-matter) region-axis)
      =((domain-axis-for %machine-topology) region-axis)
      =((domain-axis-for %runtime-state) region-axis)
      =((domain-axis-for %bundle-packet-state) region-axis)
      =((domain-axis-for %circulation-facts) region-axis)
      =((domain-axis-for %bride-memory) region-axis)
      =((domain-axis-for %crossing-lane) region-axis)
      =((domain-axis-for %projection-views) region-axis)
  ==
::
::  THE LEASE.  Every field must match: a write carries the session, the
::  lease and the ship it claims to be writing under, and all three are
::  checked against the seat claim on file.  This is what makes a write
::  attributable rather than merely permitted.
::
++  seat-write-authorizes-axis
  |=  [seat-write=graf-seat-write:graf-sur axis-write=graf-axis-write:graf-sur]
  ^-  ?
  ?&  =(root-id.seat-write root-id.axis-write)
      =(seat-id.seat-write seat-id.axis-write)
      =(session-id.seat-write session-id.axis-write)
      =(lease-id.seat-write lease-id.axis-write)
      =(assigned-ship-id.seat-write assigned-ship-id.axis-write)
  ==
::
++  find-seat-write
  |=  [seat-writes=(list graf-seat-write:graf-sur) seat-id=@tas]
  ^-  (unit graf-seat-write:graf-sur)
  ?~  seat-writes  ~
  ?:  =(seat-id.i.seat-writes seat-id)
    `i.seat-writes
  $(seat-writes t.seat-writes)
::
::  THE GATE.
::
::  The last clause is the 2026-08-16 fix.  Everything above it validates
::  the REGION ROOT and then never looks at where the relative graft lands,
::  so naming another seat's region directly was refused while reaching the
::  same axis indirectly was allowed -- direct path closed, indirect path
::  open.  +absolute-axis-respects-seats closes it.
::
++  axis-write-authorized
  |=  $:  seat-writes=(list graf-seat-write:graf-sur)
          axis-write=graf-axis-write:graf-sur
      ==
  ^-  ?
  =/  current-seat  (find-seat-write seat-writes seat-id.axis-write)
  ?~  current-seat  %.n
  ?.  (structural-region-axis-authorized seat-id.axis-write region-axis.axis-write)
    %.n
  =/  absolute-axis  (absolute-axis-for-region region-axis.axis-write relative-axis.axis-write)
  ?~  absolute-axis  %.n
  ?&  (seat-write-authorizes-axis u.current-seat axis-write)
      (nonzero-axis relative-axis.axis-write)
      =(absolute-axis.axis-write u.absolute-axis)
      (absolute-axis-respects-seats seat-id.axis-write u.absolute-axis seat-region-axis-for)
  ==
::
++  axis-ancestor-axes
  |=  axis=@ud
  ^-  (list @ud)
  ?:  =(axis 1)
    ~[1]
  (weld $(axis (div axis 2)) ~[axis])
::
++  axis-slot-path
  |=  axis=@ud
  ^-  (list @ud)
  ?:  =(axis 1)
    ~
  =/  parent-axis=@ud  (div axis 2)
  =/  step=@ud
    ?:  =(axis (mul 2 parent-axis))
      2
    3
  (weld $(axis parent-axis) ~[step])
::
::  ---------------------------------------------------------------
::  ANALYSIS ARMS.  Not part of the law -- these exist so a proof can
::  MEASURE the law's shape rather than reason about it.
::
::  the roster, in axis order.
::
++  seat-roster
  ^-  (list @tas)
  :~  %flunky  %busboy  %policeman  %gendarme  %undertaker
      %priest  %delivery-boy  %cuirassier  %stationmaster
  ==
::
::  is `inner` inside the subtree rooted at `outer`?  Walk inner up to the
::  root and look for outer on the way.
::
++  axis-within
  |=  [outer=@ud inner=@ud]
  ^-  ?
  ?:  =(outer inner)  %.y
  ?:  (lth inner outer)  %.n
  |-  ^-  ?
  ?:  =(inner 1)  %.n
  =/  parent=@ud  (div inner 2)
  ?:  =(parent outer)  %.y
  $(inner parent)
::
::  which OTHER seats' regions live inside this seat's region.  If this is
::  ever non-empty the seat regions are not disjoint, and a design that
::  assumed isolation between seats is wrong.
::
++  seats-nested-under
  |=  [seat-id=@tas axis-for=$-(@tas (unit @ud))]
  ^-  (list @tas)
  =/  mine  (axis-for seat-id)
  ?~  mine  ~
  %+  murn  seat-roster
  |=  other=@tas
  ^-  (unit @tas)
  ?:  =(other seat-id)  ~
  =/  theirs  (axis-for other)
  ?~  theirs  ~
  ?:  (axis-within u.mine u.theirs)  `other
  ~
::
::  every seat whose region contains this axis.  Under a disjoint roster
::  this is at most one; under the current one it can be three.
::
++  seats-containing
  |=  [absolute=@ud axis-for=$-(@tas (unit @ud))]
  ^-  (list @tas)
  %+  murn  seat-roster
  |=  seat=@tas
  ^-  (unit @tas)
  =/  theirs  (axis-for seat)
  ?~  theirs  ~
  ?:  (axis-within u.theirs absolute)  `seat
  ~
::
::  is the roster pairwise disjoint?  Ruled 2026-08-16: seats are NOT
::  supposed to be nested, so this is the law the assignment must satisfy.
::
++  seats-disjoint
  |=  axis-for=$-(@tas (unit @ud))
  ^-  ?
  %+  levy  seat-roster
  |=(s=@tas ?=(~ (seats-nested-under s axis-for)))
::
::  ---------------------------------------------------------------
::  THE FIX, in two parts.
::
::  PART ONE -- the missing check.  +axis-write-authorized validates the
::  REGION ROOT and then never looks at where the relative graft lands.
::  So naming another seat's region directly is refused while reaching the
::  same axis indirectly is allowed: direct path closed, indirect path
::  open.  This is the arm that closes it.
::
::  The rule is not "the axis must be in my region" -- shared domains are
::  written by every seat on purpose, and they belong to no seat.  It is
::  "no OTHER seat's region may contain this axis."
::
++  absolute-axis-respects-seats
  |=  [seat-id=@tas absolute=@ud axis-for=$-(@tas (unit @ud))]
  ^-  ?
  %+  levy  (seats-containing absolute axis-for)
  |=(s=@tas =(s seat-id))
::
::  THE SEAT ROSTER.  Nine mutually disjoint subtrees.
::
::  Axes at the SAME DEPTH are never ancestors of one another, so one level
::  deep enough to hold nine is sufficient: 48-63 are the depth-4
::  descendants of the seat trunk (3 -> 6,7 -> 12..15 -> 24..31 -> 48..63),
::  of which the first nine are taken.  Domains all descend from the domain
::  trunk (axis 2), so the trunk split keeps seats and domains apart by
::  construction, and each seat keeps an unbounded subtree beneath it.
::
::  The previous assignment did not: under it %flunky's EXCLUSIVE region was
::  the single axis 6, because both its children were other seats.
::
++  seat-region-axis-for
  |=  seat-id=@tas
  ^-  (unit @ud)
  ?+    seat-id  ~
      %flunky  [~ 48]
      %busboy  [~ 49]
      %policeman  [~ 50]
      %gendarme  [~ 51]
      %undertaker  [~ 52]
      %priest  [~ 53]
      %delivery-boy  [~ 54]
      %cuirassier  [~ 55]
      %stationmaster  [~ 56]
  ==
::
::  DOES THIS WRITE NAME ITS OWN SENDER?
::
::  +axis-write-authorized above answers "is this write consistent with the
::  seat?" and every field it compares is CLAIMED BY THE WRITER -- and
::  published by graf's own /x/seat peeks.  So consistency is forgeable by
::  reading and copying.  MEASURED 2026-08-16 across two real ships: a moon
::  wrote the planet's region by copying that seat's ids, and the landed
::  write carried assigned-ship-id '~sampel-palnet' with the moon's value.
::
::  Authentication is a separate question from consistency, and Ames
::  already answers it.  This arm is the missing half.
::
::    src   src.bowl, which no caller can forge
::    host  our.bowl; exempt because the principal legitimately writes on
::          behalf of seats it grants, the same asymmetry the seat-claim
::          guard relies on
::
::  It lives HERE, not in the agent, for the reason the nesting bug taught:
::  a gate inside a 5.000-line agent is a gate nothing can prove.
::
++  axis-write-sender-authorized
  |=  [axis-write=graf-axis-write:graf-sur src=@p host=@p]
  ^-  ?
  ?:  =(host src)  %.y
  =((scot %p src) assigned-ship-id.axis-write)
::
::  the full foreign check: named by its sender AND consistent with the
::  seat it claims.  Both, in that order -- an unauthenticated write should
::  never reach the consistency logic at all.
::
::  MAY THIS SENDER LOG WORK UNDER THIS ACTOR?
::
::  circulation-fact.actor is a SEAT by convention (%flunky, %busboy), and
::  nothing bound it to the sender.  MEASURED 2026-08-16: the moon recorded
::  a fact with actor %flunky -- the planet's seat -- and it landed.  The
::  activity page is built from exactly these facts, so an unbound actor
::  means the page can be made to lie about who did what.
::
::  Weaker than the axis hole (a circulation fact grants nothing) but the
::  same defect, and worse in one way: attribution is the entire POINT of
::  an activity view.
::
::  POLICY, and it is a choice worth naming: a foreign ship may log only
::  under a seat it HOLDS.  An actor naming no seat is refused for foreign
::  senders -- otherwise the attack is just "use a name nobody claimed".
::  That does cost moons free-form role names; roles belong in `stage` and
::  `summary`, which claim nothing.  The host is exempt as principal.
::
++  circulation-actor-authorized
  |=  $:  seat-writes=(list graf-seat-write:graf-sur)
          actor=@tas
          src=@p
          host=@p
      ==
  ^-  ?
  ?:  =(host src)  %.y
  =/  seat  (find-seat-write seat-writes actor)
  ?~  seat  %.n
  =((scot %p src) assigned-ship-id.u.seat)
::
++  foreign-axis-write-authorized
  |=  $:  seat-writes=(list graf-seat-write:graf-sur)
          axis-write=graf-axis-write:graf-sur
          src=@p
          host=@p
      ==
  ^-  ?
  ?&  (axis-write-sender-authorized axis-write src host)
      (axis-write-authorized seat-writes axis-write)
  ==
--
