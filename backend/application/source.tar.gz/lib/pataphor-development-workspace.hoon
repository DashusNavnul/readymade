::  Existing-shell owner adapter; Viki owns requests, history and execution.
/-  pc=pataphor-project-coding
/+  page=pataphor-development-page, coding=pataphor-project-coding,
    http=pataphor-chat-http, guard=viki-scry-guard,
    legacy=pataphor-glass-project-workspace
|%
+$  response  [cards=(list card:agent:gall) nonce=@uv]
+$  delegated
  $%  [?(%qpc-readiness-owner-v1 %qpc-task-onboard-owner-v3 %qpc-campaign-owner-v1 %qpc-selected-owner-v1 %qpc-controller-owner-v1 %qpc-prospective-owner-v1 %qpc-native-declaration-owner-v1 %qpc-law-owner-v1 %qpc-law-owner-v2 %qpc-instrument-v1 %native-local-review-owner-v2 %native-local-review-owner-v3 %qpc-stream-v1) held=* inner=[type=* noun=*]]
      [%qpc-flow-owner-v1 %viki held=* inner=[type=* noun=*]]
      [%qpc-instrument-v2 held=* ordered=* inner=[type=* noun=*]]
      [%qpc-instrument-v3 held=* ordered=* laws=* inner=[type=* noun=*]]
      [%qpc-instrument-v4 held=* ordered=* laws=* successors=* refresh=(unit @da) inner=[type=* noun=*]]
      [%qpc-instrument-v5 held=* ordered=* laws=* successors=* refresh=(unit @da) selected=* inner=[type=* noun=*]]
      [%qpc-observer-v3 held=* checked=* settled=* inner=[type=* noun=*]]
      [%qpc-session-gate-v2 %viki required=* pools=* inner=[type=* noun=*]]
  ==
+$  native-extension
  $?  %viki-familiar-state-v17  %viki-familiar-state-v18  %viki-familiar-state-v19
      %viki-familiar-state-v20  %viki-familiar-state-v21  %viki-familiar-state-v22
      %viki-familiar-state-v23  %viki-familiar-state-v24  %viki-familiar-state-v25
      %viki-familiar-state-v26  %viki-familiar-state-v27  %viki-familiar-state-v28
      %viki-familiar-state-v29  %viki-familiar-state-v30
  ==
++  supported
  |=  saved=*
  ^-  ?
  ::  These owners delegate the same project interface while retaining the
  ::  complete inner vase. Never interpret an unknown wrapper as support.
  ::  Inspect the saved envelope, not the recursively defined inner type.
  =/  depth=@ud  0
  |-  ^-  ?
  ?:  (gte depth 32)  %.n
  =/  wrapped  ((soft ,delegated) saved)
  ?^  wrapped
    =/  inside=[type=* noun=*]
      ?:  ?=(%qpc-flow-owner-v1 -.u.wrapped)  inner.u.wrapped
      ?:  ?=(%qpc-observer-v3 -.u.wrapped)  inner.u.wrapped
      ?:  ?=(%qpc-session-gate-v2 -.u.wrapped)  inner.u.wrapped
      ?:  ?=(%qpc-instrument-v2 -.u.wrapped)  inner.u.wrapped
      ?:  ?=(%qpc-instrument-v3 -.u.wrapped)  inner.u.wrapped
      ?:  ?=(%qpc-instrument-v4 -.u.wrapped)  inner.u.wrapped
      ?:  ?=(%qpc-instrument-v5 -.u.wrapped)  inner.u.wrapped
      inner.u.wrapped
    $(saved noun.inside, depth +(depth))
  =/  shoe  ((soft ,[%shoe-app inner=[type=* noun=*] console=*]) saved)
  ?~  shoe  %.n
  =/  state=*  noun.inner.u.shoe
  |-  ^-  ?
  ?:  (gte depth 32)  %.n
  ?:  ?=([%viki-familiar-state-v16 [%viki-familiar-state-v15 *] *] state)  %.y
  ?.  ?=([native-extension * *] state)
    %.n
  $(state +<.state, depth +(depth))
++  ark-supported
  ::  v1 supports project work, but predates the ARK view path. Asking an
  ::  absent Gall path blocks the event; a crash trap cannot make it optional.
  |=  saved=*
  ^-  ?
  =/  depth=@ud  0
  |-  ^-  ?
  ?:  (gte depth 32)  %.n
  ?:  ?=([%qpc-flow-owner-v1 *] saved)
    =/  wrapped  ((soft ,[%qpc-flow-owner-v1 %viki held=* inner=[type=* noun=*]]) saved)
    ?~  wrapped  %.n
    $(saved noun.inner.u.wrapped, depth +(depth))
  ?:  ?=([?(%qpc-readiness-owner-v1 %qpc-task-onboard-owner-v3 %qpc-campaign-owner-v1 %qpc-selected-owner-v1 %qpc-controller-owner-v1 %qpc-prospective-owner-v1 %qpc-native-declaration-owner-v1) *] saved)
    =/  wrapped  ((soft ,[tag=@tas held=* inner=[type=* noun=*]]) saved)
    ?~  wrapped  %.n
    $(saved noun.inner.u.wrapped, depth +(depth))
  &(?=([%qpc-law-owner-v2 *] saved) (supported saved))
++  ark-read
  |=  [our=@p actor=@p at=@da]
  ^-  (unit json)
  ?.  =(our actor)  ~
  ?.  (agent-live:guard our at %viki)  ~
  =/  raw=*  .^(* %gv /(scot %p our)/viki/(scot %da at)/$)
  =/  egg  ((soft ,live-egg:legacy) raw)
  ?~  egg  ~
  ?.  (ark-supported noun.saved.old-state.u.egg)  ~
  ::  Read as noun before molding: a changed payload must not scry-lost.
  =/  value=*  .^(* %gx /(scot %p our)/viki/(scot %da at)/qpc/ark/view/noun)
  ((soft ,json) value)
++  service
  |=  [our=@p actor=@p at=@da]
  ^-  (unit @tas)
  ?.  =(our actor)  `%owner-required
  ?.  (agent-live:guard our at %viki)  `%viki-unavailable
  =/  raw=*  .^(* %gv /(scot %p our)/viki/(scot %da at)/$)
  =/  egg  ((soft ,live-egg:legacy) raw)
  ?~  egg  `%development-unavailable
  ?.  (supported noun.saved.old-state.u.egg)  `%development-unavailable
  ~
++  checked
  |=  [our=@p v=view:pc]
  ^-  (each view:pc @tas)
  ?.  &(=(our owner.v) =('pataphor' project.v))  [%| %project-owner-mismatch]
  ?.  (view-valid:coding v)  [%| %invalid-project-view]
  [%& v]
++  read
  |=  [our=@p actor=@p at=@da]
  ^-  (each view:pc @tas)
  =/  error  (service our actor at)
  ?^  error  [%| u.error]
  =/  v=view:pc
    .^(view:pc %gx /(scot %p our)/viki/(scot %da at)/development/pataphor/noun)
  (checked our v)
++  location
  |=  url=@t
  ^-  (each (unit @ux) @tas)
  =/  prefix=@t  '/apps/pataphor-work?'
  =/  size=@ud  (met 3 prefix)
  ?.  &((gte (met 3 url) size) =(prefix (cut 3 [0 size] url)))
    [%| %not-development]
  =/  fields  (parse-fields:http (cut 3 [size (sub (met 3 url) size)] url))
  ?~  fields  [%| %not-development]
  ?.  =(`'pataphor' (~(get by u.fields) 'project'))  [%| %not-development]
  ?.  =(`'1' (~(get by u.fields) 'glass'))  [%| %invalid-address]
  =/  key  (~(get by u.fields) 'request')
  =/  selected=(unit @ux)  ?~(key ~ (hex:page u.key))
  ?:  &(?=(^ key) ?=(~ selected))  [%| %invalid-address]
  ?.  =(url (href:page selected))  [%| %invalid-address]
  [%& selected]
++  parent
  |=  [id=@ux rows=(list result:pc)]
  ^-  (unit result:pc)
  ?~  rows  ~
  ?:  =(id (result-id:coding i.rows))  `i.rows
  $(rows t.rows)
++  prepare
  |=  [our=@p actor=@p token=@uv item=form:page v=view:pc]
  ^-  (each request:pc @tas)
  =/  valid  (checked our v)
  ?:  ?=(%| -.valid)  [%| p.valid]
  ?~  manifest.v  [%| %project-basis-unavailable]
  ?.  =(manifest.item (manifest-id:coding u.manifest.v))  [%| %project-basis-changed]
  =/  prior=(unit result:pc)
    ?~  prior.item  ~
    (parent u.prior.item results.v)
  ?:  &(?=(^ prior.item) ?=(~ prior))  [%| %prior-result-missing]
  =/  key=@ux  (nonce:page our token item)
  ?:  (lien results.v |=(r=result:pc =(key nonce.request.r)))
    [%| %request-already-retained]
  (prepare-request:coding our actor key u.manifest.v prior text.item)
++  start
  |=  [our=@p r=request:pc]
  ^-  card:agent:gall
  [%pass /glass-goal/(scot %ux nonce.r) %agent [our %viki] %poke %noun !>([%viki-project-develop r])]
++  handle
  |=  [b=bowl:gall token=@uv id=@ta req=inbound-request:eyre]
  ^-  (unit response)
  =/  route  (location url.request.req)
  ?:  =([%| %not-development] route)  ~
  =/  head=?  =('HEAD' method.request.req)
  ?.  &(authenticated.req =(our.b src.b))
    `[(respond:http id 403 'Owner authentication required.' ~ head) token]
  ?:  ?=(%| -.route)
    `[(respond:http id 404 'Invalid project address.' ~ head) token]
  ?:  head  `[(respond:http id 200 '' ~ %.y) token]
  ?:  =('GET' method.request.req)
    =/  current  (read our.b src.b now.b)
    `[(respond:http id 200 (page:page our.b token p.route current) ~ %.n) token]
  ?.  &(=('POST' method.request.req) ?=(~ p.route))
    `[(respond:http id 405 'Use a new project request form.' ~[['allow' 'GET, HEAD, POST']] %.n) token]
  =/  headers  (~(gas by *(map @t @t)) header-list.request.req)
  ?.  =(`'application/x-www-form-urlencoded' (~(get by headers) 'content-type'))
    `[(respond:http id 415 'Use the project request form.' ~ %.n) token]
  =/  body  body.request.req
  ?~  body  `[(respond:http id 400 'Empty form.' ~ %.n) token]
  ?.  &((lte p.u.body 16.384) =(p.u.body (met 3 q.u.body)))
    `[(respond:http id 413 'Invalid form size.' ~ %.n) token]
  =/  item  (decode:page token q.u.body)
  ?~  item  `[(respond:http id 403 'Invalid form. Refresh before submitting.' ~ %.n) token]
  =/  current  (read our.b src.b now.b)
  ?:  ?=(%| -.current)
    `[(respond:http id 503 'Project unavailable. No request submitted.' ~ %.n) token]
  =/  prepared  (prepare our.b src.b token u.item p.current)
  ?:  ?=(%| -.prepared)
    `[(respond:http id 409 'Project basis or prior result changed. Refresh before submitting.' ~ %.n) token]
  =/  next=@uv  `@uv`(sham [token eny.b now.b %development])
  `[(weld ~[(start our.b p.prepared)] (respond:http id 303 'Requested; Viki retention is unconfirmed.' ~[['location' (href:page `nonce.p.prepared)]] %.n)) next]
--
