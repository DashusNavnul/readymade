::  Exact, bounded candidate text for the owner's review screen. No writes.
/-  nc=native-coding
/+  files=native-coding-files, dsr=desk-shell-read
|%
++  texts
  ::  Both sides must match the retained edit's Clay lobes. Never clip a diff.
  |=  [e=edit:nc old=(unit replacement:nc)]
  ^-  (unit [original=@t proposed=@t])
  ?.  ?=(^ path.change.e)  ~
  =/  mark=@tas  (rear path.change.e)
  ?.  =(before.change.e ?~(old ~ `(page-to-lobe:clay u.old)))  ~
  ?.  =(after.change.e ?~(content.e ~ `(page-to-lobe:clay u.content.e)))  ~
  ?.  ?-  kind.change.e
        %add     &(?=(~ old) ?=(^ content.e))
        %modify  &(?=(^ old) ?=(^ content.e))
        %delete  &(?=(^ old) ?=(~ content.e))
      ==  ~
  ?.  &(?~(old %.y =(mark mark.u.old)) ?~(content.e %.y =(mark mark.u.content.e)))  ~
  =/  original=@t  ?~(old '' source.u.old)
  =/  proposed=@t  ?~(content.e '' source.u.content.e)
  ?.  &((lte (add (met 3 original) (met 3 proposed)) 65.536) (utf8:files original) (utf8:files proposed))  ~
  `[original proposed]
++  previews
  |=  [p=project:nc c=candidate:nc]
  ^-  (map path json)
  ?.  (candidate-valid:files p c)  ~
  =/  remaining=@ud  65.536
  =/  rows=(list edit:nc)  edits.c
  =|  out=(map path json)
  |-  ^-  (map path json)
  ?~  rows  out
  =/  e=edit:nc  i.rows
  ?:  |(=(0 remaining) ?~(content.e %.n (gth (met 3 source.u.content.e) remaining)))
    $(rows t.rows)
  =/  old=(unit replacement:nc)
    ?~  before.change.e  ~
    =/  r=revision:nc  source.context.c
    ?.  .^(? %cu (beam-at:dsr owner.r desk.r (scot %ud number.r) path.change.e))  ~
    =/  read  (file:files p basis.c path.change.e)
    ?:  ?=(%| -.read)  ~
    `p.read
  =/  pair  (texts e old)
  ?~  pair  $(rows t.rows)
  =/  bytes=@ud  (add (met 3 original.u.pair) (met 3 proposed.u.pair))
  ?:  (gth bytes remaining)  $(rows t.rows)
  =/  preview=json
    (pairs:enjs:format ~[['schema' s+'native-coding-candidate-text-v1'] ['original' s+original.u.pair] ['proposed' s+proposed.u.pair]])
  $(rows t.rows, remaining (sub remaining bytes), out (~(put by out) path.change.e preview))
--
