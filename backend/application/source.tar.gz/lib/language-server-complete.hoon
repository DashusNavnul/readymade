::  /lib/language-server-complete
::
::  THE TAB-COMPLETION SUBSET /lib/shoe NEEDS, and nothing else.
::
::  lib/shoe is vendored here unmodified and imports this as `auto`, but the
::  file does not exist in this ship's %base or anywhere else on this machine
::  -- so shoe has never compiled in %pataphor.  Rather than edit a vendored
::  library (which makes every future update a merge argument), the missing
::  dependency is supplied.
::
::  Upstream's file of this name is a full language server completer.  This is
::  ONLY the four arms shoe calls: +option, +get-id-cord, +search-prefix and
::  +longest-match.  If you need the rest, take upstream's, do not grow this.
::
|%
::  +option: a completion candidate -- what to insert, and how to describe it
++  option
  |*  a=mold
  $:  =cord
      a
  ==
::  characters that belong to a completable word.
::
::  `/` is included deliberately: commands in this desk are /slash-prefixed,
::  and excluding it would make tab silently useless on exactly the words
::  worth completing.  A term with a slash is not a legal @tas, but nothing
::  here validates it as one -- it is compared as bytes and then re-emitted.
++  id-char
  |=  c=@t
  ^-  ?
  ?|  &((gte c 'a') (lte c 'z'))
      &((gte c 'A') (lte c 'Z'))
      &((gte c '0') (lte c '9'))
      =(c '-')
      =(c '/')
  ==
::  +take-while: leading run of characters satisfying a test
++  take-while
  |=  [t=tape f=$-(@t ?)]
  ^-  tape
  ?~  t  ~
  ?.  (f i.t)  ~
  [i.t $(t t.t)]
::  +get-id-cord: the word under the cursor, split at the cursor
::
::  `id` is the part BEHIND the cursor -- what the user has typed so far and
::  what a candidate must match.  `forward` is the remainder ahead of it, used
::  only to work out where the cursor should end up.  Both are units because
::  "no word here" is a real answer and must not read as an empty word.
++  get-id-cord
  |=  [pos=@ud txt=tape]
  ^-  [id=(unit term) forward=(unit @t)]
  =/  before=tape  (scag pos txt)
  =/  after=tape   (slag pos txt)
  =/  back=tape    (flop (take-while (flop before) id-char))
  =/  fwd=tape     (take-while after id-char)
  :-  ?~(back ~ `(crip back))
  ?~(fwd ~ `(crip fwd))
::  +search-prefix: candidates beginning with the needle
::
::  An empty needle matches everything, which is what makes tab-on-empty list
::  the whole command set.
++  search-prefix
  |=  [needle=@t options=(list (option tank))]
  ^-  (list (option tank))
  =/  n=@ud  (met 3 needle)
  ?:  =(0 n)  options
  %+  skim  options
  |=  o=(option tank)
  =((end [3 n] cord.o) needle)
::  +common: the shared leading run of two tapes
++  common
  |=  [a=tape b=tape]
  ^-  tape
  ?~  a  ~
  ?~  b  ~
  ?.  =(i.a i.b)  ~
  [i.a $(a t.a, b t.b)]
::  +longest-match: how far every candidate agrees
::
::  Returns the WHOLE shared prefix including the needle; shoe strips the
::  needle back off itself with +rsh.  Returning only the tail here would
::  double-strip and eat the user's own typing.
++  longest-match
  |=  options=(list (option tank))
  ^-  term
  ?~  options  %$
  =/  acc=tape  (trip cord.i.options)
  |-  ^-  term
  ?~  t.options  (crip acc)
  $(options t.options, acc (common acc (trip cord.i.t.options)))
--
