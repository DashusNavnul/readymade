::  Viki-owned unchanged-work review campaigns. Intents precede effects;
::  canonical observations, never ACKs or model prose, establish progress.
/-  bx=boxy, jm=juggler-match, protocol=native-coding-completion-review,
    old-protocol=native-coding-review
/+  request=native-coding-completion-review-request,
    worker=native-coding-completion-review-worker,
    legacy=native-coding-review-request, completion=native-coding-completion,
    runtime=native-coding-completion-runtime, loop=native-coding-loop,
    admission=cantrip-native-completion-review,
    judgment=native-coding-completion-judgment, candidate=native-coding-judgment,
    boxy=boxy-law, match=boxy-match, juggler=juggler-match, guard=viki-scry-guard
|%
+$  card  card:agent:gall
+$  scopes  (map @t scope:protocol)
+$  job
  [worker=@p config=config:request request=request:request event=(unit event:worker)]
+$  campaign
  $:  packet=packet:request
      scope=scope:protocol
      workspace=@tas
      sent=(set @ux)
      jobs=(map @ux job)
      reason=@tas
      done=?
  ==
+$  state
  [%native-coding-completion-review-campaigns-v1 campaigns=(map @ux campaign)]
+$  change  [state=state cards=(list card)]
+$  action
  $%  [%start session=@ux]
      [%observe campaign=@ux]
  ==
++  empty  ^-  state  [%native-coding-completion-review-campaigns-v1 ~]
++  key
  |=  [packet=packet:request scope=scope:protocol]
  ^-  @ux
  (digest:request [proposal.packet scope])
++  workspace-for
  |=  id=@ux
  ^-  @tas
  (cat 3 'completion-' (scot %ux id))
++  title
  |=  e=campaign
  ^-  @t
  (cat 3 'native-coding-completion:' (scot %ux (digest:completion proposal.packet.e)))
++  scope-valid
  |=  [our=@p scope=scope:protocol]
  ^-  ?
  ::  The current owner must parent both independently configured reviewers.
  ?&  (text-valid:completion project.scope 128)
      !=(ship.left.scope ship.right.scope)
      (config-valid:request ship.left.scope config.left.scope)
      (config-valid:request ship.right.scope config.right.scope)
      =(our parent.config.left.scope)
      =(our parent.config.right.scope)
  ==
++  enabled
  |=  [scopes=scopes e=campaign]
  ^-  ?
  &(enabled.scope.e =(`scope.e (~(get by scopes) project.scope.e)))
++  wire-for
  |=  [id=@ux kind=@tas]
  ^-  path
  /native-completion-campaign/(scot %ux id)/[kind]
++  remote
  |=  [id=@ux moon=@p command=*]
  ^-  card
  [%pass (wire-for id %worker) %agent [moon %native-coding-reviewer] %poke %noun !>(command)]
++  put
  |=  [our=@p s=state id=@ux e=campaign cards=(list card)]
  ^-  change
  ?:  &(=(`e (~(get by campaigns.s) id)) =(~ cards))  [s ~]
  :-  s(campaigns (~(put by campaigns.s) id e))
  [[%pass (wire-for id %retain) %agent [our %graf] %poke %graf-action !>([%attest [%native-coding-completion-review-campaign-v1 id (digest:request e) reason.e done.e]])] cards]
++  once
  |=  [our=@p s=state id=@ux e=campaign intent=* cards=(list card)]
  ^-  change
  =/  token=@ux  (digest:request intent)
  ?:  (~(has in sent.e) token)  [s ~]
  (put our s id e(sent (~(put in sent.e) token)) cards)
++  emit
  |=  [our=@p s=state id=@ux e=campaign w=workspace-state:bx intent=* command=command:bx]
  ^-  change
  =/  envelope=command-envelope:bx
    [id.w membership-epoch.w law-digest.w ?~(head.w ~ ~[u.head.w]) (payload-digest-for:boxy command) (scot %ux (digest:request [id intent])) command]
  (once our s id e intent ~[[%pass (wire-for id %boxy) %agent [our %boxy] %poke %boxy-action !>(`action:bx`[%command envelope])]])
++  watch
  |=  [our=@p id=@ux e=campaign]
  ^-  card
  [%pass (wire-for id %boxy-watch) %agent [our %boxy] %watch /boxy/workspace/(scot %tas workspace.e)]
++  observations
  ::  Explicit observation/reload only. Unknown inference is never resent.
  |=  [our=@p id=@ux e=campaign]
  ^-  (list card)
  ?:  done.e  ~
  :-  (watch our id e)
  %-  zing
  %+  turn  ~(val by jobs.e)
  |=  j=job
  ^-  (list card)
  ?:  ?~(event.j %.n =(%submitted phase.u.event.j))
    ~[[%pass (wire-for id %cantrip-watch) %agent [our %cantrip] %watch /native-coding/completion-review-admission/(scot %ux id)/(scot %ux id.request.j)]]
  ?:  ?~(event.j %.n ?=(?(%refused %cancelled) phase.u.event.j))  ~
  ~[(remote id worker.j [%native-coding-completion-review-observe-v1 (digest:request config.j) generation.config.j id.request.j (digest:request request.j)])]
++  act
  |=  [b=bowl:gall s=state coding=state:loop scopes=scopes action=action]
  ^-  (each change @tas)
  ?.  =(our.b src.b)  [%| %completion-review-owner-required]
  ?:  ?=(%start -.action)  (begin b s coding scopes session.action)
  =/  found  (~(get by campaigns.s) campaign.action)
  ?~  found  [%| %completion-review-campaign-missing]
  ?:  done.u.found
    ::  Explicit owner observation may recover a failed final application.
    ::  Its original finish intent is retained; no review work is resubmitted.
    ?.  (agent-live:guard our.b now.b %viki)  [%| %completion-review-native-unavailable]
    =/  applied=(unit @ux)
      .^((unit @ux) %gx /(scot %p our.b)/viki/(scot %da now.b)/native-coding/reviewed-completion-campaign/(scot %ux campaign.action)/noun)
    ?^  applied  [%& [s ~]]
    ?.  (enabled scopes u.found)  [%| %completion-review-scope-revoked]
    =/  current  (prepare:runtime b coding session.proposal.packet.u.found)
    ?:  ?=(%| -.current)  [%| p.current]
    ?.  =(p.current proposal.packet.u.found)  [%| %completion-review-proposal-changed]
    [%& [s ~[(poke:loop our.b %viki (wire-for campaign.action %finish) [%native-coding-completion-review-finish-v1 campaign.action])]]]
  =/  next  (observe b s coding scopes campaign.action)
  [%& [state.next (weld cards.next (observations our.b campaign.action u.found))]]
++  begin
  |=  [b=bowl:gall s=state coding=state:loop scopes=scopes session=@ux]
  ^-  (each change @tas)
  ?.  =(our.b src.b)  [%| %completion-review-owner-required]
  =/  snapshot  (read:runtime b coding session)
  ?:  ?=(%| -.snapshot)  [%| p.snapshot]
  =/  captured  (capture:request our.b p.snapshot)
  ?:  ?=(%| -.captured)  [%| p.captured]
  =/  selected  (~(get by scopes) project.proposal.p.captured)
  ?~  selected  [%| %completion-review-standing-scope-required]
  ?.  &(enabled.u.selected (scope-valid our.b u.selected))
    [%| %completion-review-standing-scope-revoked]
  =/  id=@ux  (key p.captured u.selected)
  ?:  (~(has by campaigns.s) id)  [%& (observe b s coding scopes id)]
  ?:  (gte ~(wyt by campaigns.s) 32)  [%| %completion-review-campaign-capacity]
  =/  e=campaign  [p.captured u.selected (workspace-for id) ~ ~ %opening %.n]
  =/  retained  (put our.b s id e ~)
  =/  next  (observe b state.retained coding scopes id)
  [%& [state.next (weld cards.retained cards.next)]]
++  observe
  |=  [b=bowl:gall s=state coding=state:loop scopes=scopes id=@ux]
  ^-  change
  =/  found  (~(get by campaigns.s) id)
  ?~  found  [s ~]
  =/  e=campaign  u.found
  ?:  done.e  [s ~]
  ?.  (enabled scopes e)  (put our.b s id e(reason %completion-review-scope-revoked) ~)
  =/  current  (prepare:runtime b(src our.b) coding session.proposal.packet.e)
  ?:  ?=(%| -.current)  (put our.b s id e(reason p.current) ~)
  ?.  =(p.current proposal.packet.e)  (put our.b s id e(reason %completion-review-proposal-changed) ~)
  ?.  &((agent-live:guard our.b now.b %cantrip) (agent-live:guard our.b now.b %boxy))
    (put our.b s id e(reason %completion-review-native-unavailable) ~)
  =/  all=state:bx
    .^(state:bx %gx /(scot %p our.b)/boxy/(scot %da now.b)/state/noun)
  =/  found  (~(get by workspaces.all) workspace.e)
  ?~  found
    =/  config=workspace-config:bx
      [workspace.e (title e) [%unanimity ~] %review-host (silt `(list ?(%invite %revoke %publish))`~[%invite %revoke %publish])]
    (once our.b s id e %open ~[[%pass (wire-for id %boxy) %agent [our.b %boxy] %poke %boxy-action !>(`action:bx`[%open config])]])
  =/  w=workspace-state:bx  u.found
  ?.  &((event-chain-valid:boxy w) =(event-seq.w (lent events.w)) =(title.w (title e)))
    (put our.b s id e(reason %completion-review-workspace-conflict) ~)
  ?.  (~(has in sent.e) (digest:request %watch))
    (once our.b s id e %watch ~[(watch our.b id e)])
  ?.  (~(has by members.w) ship.left.scope.e)  (member b s id e w left.scope.e %left)
  ?.  (~(has by members.w) ship.right.scope.e)  (member b s id e w right.scope.e %right)
  =/  projected  (project-workspace:match w)
  =/  m=match-state:jm  match.projected
  =/  config=match-config:jm
    [workspace.e objective.proposal.packet.e our.b [ship.left.scope.e (label:request ship.left.scope.e model.selection.config.left.scope.e)] [ship.right.scope.e (label:request ship.right.scope.e model.selection.config.right.scope.e)]]
  ?~  config.m  (emit our.b s id e w %match (command-for:match [%open config]))
  ?.  &(=(u.config.m config) =(0 refused.projected))
    (put our.b s id e(reason %completion-review-match-conflict) ~)
  ?^  pending.m  (settle b s id e w m)
  ?:  (lien settlements.m |=(v=settlement:jm !accepted.admission.v))
    (put our.b s id e(reason %completion-review-admission-refused) ~)
  ?:  |(?=(^ closure.m) (lien moves.m |=(v=move:jm =(%refuse kind.contribution.v))))
    =/  ledger=ledger:admission
      .^(ledger:admission %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/completion-review-admissions/noun)
    =/  result  (evaluate:judgment our.b packet.e scope.e w ledger)
    ?:  ?=(%| -.result)  (put our.b s id e(reason p.result) ~)
    (once our.b s id e(done %.y, reason %completion-review-ready) %finish ~[[%pass (wire-for id %finish) %agent [our.b %viki] %poke %noun !>([%native-coding-completion-review-finish-v1 id])]])
  =/  targets=(list move:jm)  (skim moves.m |=(v=move:jm =(%propose kind.contribution.v)))
  ?~  targets  (dispatch b s id e w left.scope.e %propose %propose ~)
  ?^  t.targets  (put our.b s id e(reason %completion-review-target-conflict) ~)
  =/  target=move:jm  i.targets
  ?.  =(body.contribution.target (title e))  (put our.b s id e(reason %completion-review-artifact-conflict) ~)
  ?.  (challenged:candidate m target)
    (dispatch b s id e w right.scope.e %challenge %challenge `id.target)
  ?.  (accepted-by:juggler moves.m ship.left.scope.e id.target)
    (dispatch b s id e w left.scope.e %vote-left %vote `id.target)
  ?.  (accepted-by:juggler moves.m ship.right.scope.e id.target)
    (dispatch b s id e w right.scope.e %vote-right %vote `id.target)
  (dispatch b s id e w left.scope.e %close %close `id.target)
++  member
  |=  [b=bowl:gall s=state id=@ux e=campaign w=workspace-state:bx peer=reviewer:old-protocol side=@tas]
  ^-  change
  ?.  (~(has by invitations.w) ship.peer)
    (emit our.b s id e w [%invite side] [%invite ship.peer %ai-reviewer (silt ~[%publish])])
  ::  Joining is the unchanged legacy transport and uses its digest domain.
  (once our.b s id e [%join side] ~[(remote id ship.peer [%native-coding-review-join-v1 (digest:legacy config.peer) generation.config.peer w])])
++  dispatch
  |=  [b=bowl:gall s=state id=@ux e=campaign w=workspace-state:bx peer=reviewer:old-protocol intent=@tas mode=?(%propose %challenge %vote %close) target=(unit @ud)]
  ^-  change
  =/  nonce=@ux  (digest:request [id intent])
  =/  prior  (~(get by jobs.e) nonce)
  ?^  prior
    (put our.b s id e(reason ?~(event.u.prior %completion-review-awaiting-worker reason.u.event.u.prior)) ~)
  =/  r=request:request
    [%native-coding-completion-review-request-v1 nonce packet.e w mode target]
  =/  prepared  (inference:request ship.peer config.peer r)
  ?:  ?=(%| -.prepared)  (put our.b s id e(reason p.prepared) ~)
  =/  j=job  [ship.peer config.peer r ~]
  (put our.b s id e(jobs (~(put by jobs.e) nonce j), reason %completion-review-awaiting-worker) ~[(remote id ship.peer [%native-coding-completion-review-request-v1 (digest:request config.peer) generation.config.peer r])])
++  context
  |=  [s=state id=@ux request-id=@ux]
  ^-  (unit context:protocol)
  =/  found  (~(get by campaigns.s) id)
  ?~  found  ~
  =/  j  (~(get by jobs.u.found) request-id)
  ?~  j  ~
  ?~  event.u.j  ~
  ?.  =(%submitted phase.u.event.u.j)  ~
  `[%native-coding-completion-review-context-v1 id scope.u.found worker.u.j request.u.j u.event.u.j]
++  settle
  |=  [b=bowl:gall s=state id=@ux e=campaign w=workspace-state:bx m=match-state:jm]
  ^-  change
  ?.  =(1 (lent pending.m))  (put our.b s id e(reason %completion-review-pending-conflict) ~)
  =/  pending=pending-contribution:jm  (snag 0 pending.m)
  =/  jobs=(list job)
    (skim ~(val by jobs.e) |=(j=job ?~(event.j %.n &(=(worker.j actor.pending) =(contribution.u.event.j `contribution.pending)))))
  ?.  =(1 (lent jobs))  [s ~]
  =/  j=job  (snag 0 jobs)
  =/  ctx  (context s id id.request.j)
  ?~  ctx  [s ~]
  =/  verdict=(unit verdict:protocol)
    .^((unit verdict:protocol) %gx /(scot %p our.b)/cantrip/(scot %da now.b)/native-coding/completion-review-admission/(scot %ux id)/(scot %ux id.request.j)/noun)
  ?~  verdict
    (once our.b s id e [%admit id.request.j] ~[[%pass (wire-for id %cantrip-watch) %agent [our.b %cantrip] %watch /native-coding/completion-review-admission/(scot %ux id)/(scot %ux id.request.j)] [%pass (wire-for id %cantrip) %agent [our.b %cantrip] %poke %noun !>([%native-coding-completion-review-admit-v1 id id.request.j])]])
  ?.  &(=(id campaign.u.verdict) =(id.request.j request.u.verdict) =((digest:request u.ctx) context.u.verdict) =(proposal-id.contribution.pending proposal-id.admission.u.verdict) =(law:request law.admission.u.verdict))
    (put our.b s id e(reason %completion-review-admission-mismatch) ~)
  =/  applied  (apply:juggler m [%settle proposal-id.contribution.pending admission.u.verdict] [%cantrip our.b])
  ?.  ok.applied  (put our.b s id e(reason code.applied) ~)
  (emit our.b s id e w [%settle id.request.j] (command-for:match [%settle proposal-id.contribution.pending admission.u.verdict]))
++  event-valid
  |=  [j=job event=event:worker]
  ^-  ?
  ?&  =(id.request.j id.event)
      =(binding.event (digest:request config.j))
      =(generation.event generation.config.j)
      =(request.event (digest:request request.j))
      (lte (met 3 reason.event) 128)
      (lte (met 0 receipt.event) 256)
      ?:  =(%submitted phase.event)
        ?~  contribution.event  %.n
        (contribution-valid:request config.j request.j u.contribution.event receipt.event)
      &(?=(~ contribution.event) ?:(?=(?(%pending %unknown) phase.event) =(0 receipt.event) %.y))
  ==
++  receive
  |=  [b=bowl:gall s=state coding=state:loop scopes=scopes event=event:worker]
  ^-  change
  =/  ids=(list @ux)
    (murn ~(tap by campaigns.s) |=([id=@ux e=campaign] ?:((~(has by jobs.e) id.event) `id ~)))
  ?.  =(1 (lent ids))  [s ~]
  =/  id=@ux  (snag 0 ids)
  =/  e=campaign  (~(got by campaigns.s) id)
  =/  j=job  (~(got by jobs.e) id.event)
  ?.  &(=(src.b worker.j) (event-valid j event))  [s ~]
  ?:  ?~(event.j %.n ?=(?(%submitted %refused %cancelled) phase.u.event.j))  [s ~]
  ?:  ?~(event.j %.n &(=(%unknown phase.u.event.j) =(%pending phase.event)))  [s ~]
  ::  Authenticated late evidence is retained even while its scope is paused.
  =/  retained  (put our.b s id e(jobs (~(put by jobs.e) id.event j(event `event))) ~)
  =/  next  (observe b state.retained coding scopes id)
  [state.next (weld cards.retained cards.next)]
++  reload
  |=  [our=@p s=state]
  ^-  change
  [s (zing (turn ~(tap by campaigns.s) |=([id=@ux e=campaign] (observations our id e))))]
++  reconcile
  ::  Scope replacement/revocation holds immediately. Cancellation records
  ::  intent once; it never claims that a provider was physically interrupted.
  |=  [b=bowl:gall s=state scopes=scopes]
  ^-  change
  =/  rows=(list [@ux campaign])  ~(tap by campaigns.s)
  =/  cards=(list card)  ~
  |-  ^-  change
  ?~  rows  [s cards]
  =/  [id=@ux e=campaign]  i.rows
  ?:  (enabled scopes e)  $(rows t.rows)
  =/  held  (put our.b s id e(reason %completion-review-scope-revoked) ~)
  =.  s  state.held
  =.  cards  (weld cards cards.held)
  =/  jobs=(list job)  ~(val by jobs.e)
  =/  cancelled=change
    |-  ^-  change
    ?~  jobs  [s cards]
    =/  j=job  i.jobs
    ?:  ?~(event.j %.n ?=(?(%submitted %refused %cancelled) phase.u.event.j))
      $(jobs t.jobs)
    =/  current=campaign  (~(got by campaigns.s) id)
    =/  next  (once our.b s id current [%cancel id.request.j] ~[(remote id worker.j [%native-coding-completion-review-cancel-v1 (digest:request config.j) generation.config.j id.request.j (digest:request request.j)])])
    $(jobs t.jobs, s state.next, cards (weld cards cards.next))
  $(rows t.rows, s state.cancelled, cards cards.cancelled)
++  on-agent
  |=  [b=bowl:gall s=state coding=state:loop scopes=scopes path=wire sign=sign:agent:gall]
  ^-  (unit change)
  ?.  ?=([%native-completion-campaign @ @ ~] path)  ~
  =/  id  (slaw %ux i.t.path)
  ?~  id  ~
  ?.  =(i.t.path (scot %ux u.id))  ~
  =/  found  (~(get by campaigns.s) u.id)
  ?~  found  ~
  =/  kind=@tas  i.t.t.path
  ?:  =(%retain kind)  `[s ~]
  ?:  =(%finish kind)
    ?:  ?=(%poke-ack -.sign)
      ?^  p.sign  `(put our.b s u.id u.found(reason %completion-review-finalization-refused) ~)
      `[s ~]
    `[s ~]
  ?.  ?=(?(%worker %boxy %boxy-watch %cantrip %cantrip-watch) kind)  ~
  ?:  ?=(%kick -.sign)
    `(put our.b s u.id u.found(reason %completion-review-watch-ended) ~)
  ?:  ?=(%poke-ack -.sign)
    ?^  p.sign  `(put our.b s u.id u.found(reason %completion-review-delivery-refused) ~)
    `(observe b s coding scopes u.id)
  ?:  ?=(%watch-ack -.sign)
    ?^  p.sign  `(put our.b s u.id u.found(reason %completion-review-watch-refused) ~)
    `(observe b s coding scopes u.id)
  `(observe b s coding scopes u.id)
++  peek
  ::  Local canonical scries. Browser/remote projections must guard ownership.
  |=  [b=bowl:gall s=state coding=state:loop scopes=scopes path=path]
  ^-  (unit (unit cage))
  ?:  =(/x/native-coding/completion-review-campaigns path)  ``noun+!>(campaigns.s)
  ?:  ?=([%x %native-coding %completion-review-campaign @ ~] path)
    =/  id  (slaw %ux i.t.t.t.path)
    ?~  id  [~ ~]
    ?.  =(i.t.t.t.path (scot %ux u.id))  [~ ~]
    ``noun+!>((~(get by campaigns.s) u.id))
  ?.  ?=([%x %native-coding %completion-review-admission @ @ ~] path)  ~
  =/  id  (slaw %ux i.t.t.t.path)
  =/  request-id  (slaw %ux i.t.t.t.t.path)
  ?~  id  [~ ~]
  ?~  request-id  [~ ~]
  ?.  &(=(i.t.t.t.path (scot %ux u.id)) =(i.t.t.t.t.path (scot %ux u.request-id)))  [~ ~]
  =/  result=(unit context:protocol)
    =/  found  (~(get by campaigns.s) u.id)
    ?~  found  ~
    ?.  (enabled scopes u.found)  ~
    =/  current  (prepare:runtime b(src our.b) coding session.proposal.packet.u.found)
    ?:  ?=(%| -.current)  ~
    ?.  =(p.current proposal.packet.u.found)  ~
    (context s u.id u.request-id)
  ``noun+!>(result)
++  valid
  |=  [our=@p s=state]
  ^-  ?
  ?&  (lte ~(wyt by campaigns.s) 32)
      %+  levy  ~(tap by campaigns.s)
      |=  [id=@ux e=campaign]
      ?&  (identifier:completion id)
          =(id (key packet.e scope.e))
          (packet-valid:request our packet.e)
          (scope-valid our scope.e)
          enabled.scope.e
          =(project.scope.e project.proposal.packet.e)
          =(workspace.e (workspace-for id))
          (lte (met 3 reason.e) 128)
          (lte ~(wyt in sent.e) 32)
          (lte ~(wyt by jobs.e) 5)
          =(done.e (~(has in sent.e) (digest:request %finish)))
          %+  levy  ~(tap by jobs.e)
          |=  [nonce=@ux j=job]
          =/  prepared  (inference:request worker.j config.j request.j)
          ?&  =(nonce id.request.j)
              ?=(%& -.prepared)
              =(packet.e packet.request.j)
              =(workspace.e id.workspace.request.j)
              |(=([worker.j config.j] left.scope.e) =([worker.j config.j] right.scope.e))
              ?~(event.j %.y (event-valid j u.event.j))
          ==
      ==
  ==
--
