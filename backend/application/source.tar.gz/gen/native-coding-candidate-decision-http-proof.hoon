::  Inert protocol/correlation witnesses; no poke, model, or source mutation.
/-  nc=native-coding
/+  http=native-coding-candidate-decision-http,
    accept=native-coding-accept, loop=native-coding-loop,
    project=native-coding-project, files=native-coding-files,
    changes=multiplayer-changeset, tools=native-coding-tools
|=  *
::  Standalone inert fixture; all dependencies ship in the public bundle.
=/  target=build-target:nc  [%example %hoon /lib/example/hoon ~ ~[[%holds '0']]]
=/  p=project:nc  *project:nc
=.  p
  p(spec [1 'fixture' 'Decision fixture' ~zod %accepted 1 0x1 ~2026.10.10], working %work, readable.policy (silt ~[/lib]), writable.policy (silt ~[/lib]), max-file-bytes.policy 1.024, max-candidate-bytes.policy 2.048, file-types (~(put by file-types.p) %hoon %hoon), targets ~[target])
?>  (valid:project p)
=/  source=revision:nc  [~zod %work 1 0v1 0v2]
=/  ctx=context:nc  ['fixture' (configuration:project p) 0x11 0x12 ~zod source]
=/  basis=tree:nc  [source (make-snapshot:changes [1 'fixture' %work 1 ~])]
=/  content=replacement:nc  [%hoon '|=  a=@  a\0a']
=/  edit=edit:nc
  [[%add /lib/example/hoon ~ ``@ux`(page-to-lobe:clay [%hoon source.content])] `content]
=/  c=candidate:nc
  [%native-coding-candidate-v1 0x0 ctx basis [~zod %accepted 1 0v3 0v4] ~[edit] ~]
=.  c  c(id (candidate-digest:files c))
?>  (candidate-valid:files p c)
=/  desk=@tas  (staging-desk:accept id.c)
=/  stage=tree:nc
  [[~zod desk 2 0v5 0v6] (make-snapshot:changes [1 'fixture' desk 2 (after-map:files c)])]
=/  report=report:accept
  [%native-coding-candidate-report-v1 id.c stage ~[(candidate-target:tools target revision.stage `!>(0) 300.000)]]
=/  now=@da  ~2026.11.9
=/  d=decision:accept
  [%native-coding-decision-v1 id.c context.c basis.c report [%native-coding-challenge-v1 id.c (digest:accept report) %passed ~[0x1] 'Inert fixture.'] %approve source.context.c now]
=/  r=record:accept
  [%native-coding-acceptance-v1 p c 0x91 now %review `staging.report `report ~ ~ ~]
=/  e=public-session:loop  *public-session:loop
=.  e  e(session [%native-coding-session-v1 session.context.c project.context.c ~zod source.context.c ~ 'Inert fixture.' ~], worker ~zod)
=/  q=selector:http  [~zod session.context.c project.context.c id.c (shax (jam source.context.c))]
=/  accepted=tree:nc  basis.c(revision accepted.c)
?>  (decision-valid:accept project.r c d)
?>  (ready:http ~zod now q e r d accepted basis.c)
?>  !(ready:http ~nec now q e r d accepted basis.c)
?>  !(ready:http ~zod now q(owner ~nec) e r d accepted basis.c)
?>  !(ready:http ~zod now q(session 0x999) e r d accepted basis.c)
?>  !(ready:http ~zod now q(project 'other') e r d accepted basis.c)
?>  !(ready:http ~zod now q(candidate 0x999) e r d accepted basis.c)
?>  !(ready:http ~zod now q(basis 0x999) e r d accepted basis.c)
?>  !(ready:http ~zod now q e(worker ~nec) r d accepted basis.c)
?>  !(ready:http ~zod now q e(root.working.session 0v999) r d accepted basis.c)
?>  !(ready:http ~zod now q e r(stage %applied) d accepted basis.c)
?>  !(ready:http ~zod now q e r(report ~) d accepted basis.c)
?>  !(ready:http ~zod now q e r d(verdict %refuse) accepted basis.c)
?>  !(ready:http ~zod now q e r d(at ~2026.11.10) accepted basis.c)
?>  !(ready:http ~zod now q e r d(candidate 0x999) accepted basis.c)
?>  !(ready:http ~zod now q e r d accepted(root.revision 0v999) basis.c)
?>  !(ready:http ~zod now q e r d accepted basis.c(root.revision 0v999))
=/  object=json
  (pairs:enjs:format ~[['nonce' s+'0v1'] ['kind' s+'candidate-decide'] ['owner' s+'~zod'] ['session' s+(scot %ux session.q)] ['project' s+project.q] ['candidate' s+(scot %ux candidate.q)] ['basis' s+(scot %ux basis.q)] ['consent' b+%.y]])
?>  =(q (select:http object))
?>  ?=(%o -.object)
=/  bad=json  [%o (~(put by p.object) 'consent' b+%.n)]
?>  =(~ (mole |.((select:http bad))))
=.  bad  [%o (~(put by p.object) 'consent' s+'true')]
?>  =(~ (mole |.((select:http bad))))
=.  bad  [%o (~(put by p.object) 'verdict' s+'approve')]
?>  =(~ (mole |.((select:http bad))))
=.  bad  [%o (~(del by p.object) 'owner')]
?>  =(~ (mole |.((select:http bad))))
=.  bad  [%o (~(put by p.object) 'candidate' s+'0x0')]
?>  =(~ (mole |.((select:http bad))))
=.  bad  [%o (~(put by p.object) 'basis' s+'0x01')]
?>  =(~ (mole |.((select:http bad))))
=.  bad  [%o (~(put by p.object) 'session' s+(scot %ux (bex 256)))]
?>  =(~ (mole |.((select:http bad))))
%native-coding-candidate-decision-http-proof-passed
