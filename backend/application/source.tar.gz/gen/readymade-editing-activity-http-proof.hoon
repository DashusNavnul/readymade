::  Pure HTTP boundary proof; no Ames sends, source reads or permission grants.
/+  http=readymade-editing-activity-http, server=readymade-editing-activity-owner
|=  *
=/  now=@da  ~2026.11.8
=/  fields=(map @t json)
  %-  malt
  :~  ['schema' s+'readymade-editing-activity-v1']
      ['owner' s+'~zod']  ['project' s+'demo']  ['operation' s+'query']
  ==
=/  query=@t  (en:json:html [%o fields])
?>  =(`[~zod 'demo' [%query ~]] (parse:http query))
::  A query has no epoch, file or sequence and cannot become editing consent.
?>  ?=(~ (parse:http (en:json:html [%o (~(put by fields) 'sequence' s+'1')])))
=/  fields=(map @t json)
  (~(gas by fields) ~[['operation' s+'update'] ['epoch' s+(scot %da now)] ['sequence' s+'1'] ['desk' s+'demo-work'] ['path' s+'/lib/example/hoon']])
=/  raw=@t  (en:json:html [%o fields])
=/  parsed  (parse:http raw)
?>  =(`[~zod 'demo' [%update [~zod 'demo' now] [1 `[%demo-work /lib/example/hoon]]]] parsed)
=/  bad=(list [@t json])
  :~  ['schema' s+'other']  ['owner' s+'zod']  ['project' s+'']
      ['project' s+'bad\0aproject']  ['project' s+'bad:project']
      ['operation' s+'grant']  ['operation' s+'query']
      ['epoch' s+'0']  ['epoch' n+'1']  ['sequence' s+'0']
      ['sequence' s+'01']  ['sequence' s+'18.446.744.073.709.551.616']
      ['sequence' n+'1']  ['desk' s+'Demo']
      ['path' s+'lib/example/hoon']  ['path' s+'/lib/../hoon']
      ['path' s+'/lib/example/js']  ['path' s+'/']
      ['path' s+'/lib/example/hoon/']  ['actor' s+'~nec']
      ['extra' o+~]
  ==
?>  %+  levy  bad
    |=  item=[key=@t value=json]
    ?=(~ (parse:http (en:json:html [%o (~(put by fields) key.item value.item)])))
?>  ?=(~ (parse:http (cat 3 '{"owner":"~zod",' (rsh [3 1] raw))))
?>  ?=(~ (parse:http (cat 3 '{"ow\5cu006eer":"~zod",' (rsh [3 1] raw))))
?>  ?=(~ (parse:http '[]'))
?>  ?=(~ (parse:http '{'))
?>  ?=(~ (parse:http (crip (reap 8.193 ' '))))
=/  stopped=(map @t json)  (~(del by (~(del by fields) 'desk')) 'path')
=.  stopped  (~(put by stopped) 'operation' s+'stop')
?>  =(`[~zod 'demo' [%update [~zod 'demo' now] [1 ~]]] (parse:http (en:json:html [%o stopped])))
?>  ?=(~ (parse:http (en:json:html [%o (~(put by fields) 'operation' s+'stop')])))
=/  req=inbound-request:eyre  *inbound-request:eyre
=/  headers=(list [@t @t])
  ~[['host' 'localhost:8080'] ['origin' 'http://localhost:8080'] ['content-type' 'application/json'] ['x-readymade-editing-activity' 'v1']]
=.  req  req(authenticated %.y, secure %.n, method.request %'POST', header-list.request headers, body.request `[(met 3 raw) raw])
?>  =(parsed (post-request:http req))
?>  ?=(~ (post-request:http req(authenticated %.n)))
?>  ?=(~ (post-request:http req(method.request %'GET')))
?>  ?=(~ (post-request:http req(header-list.request ~)))
?>  ?=(~ (post-request:http req(body.request ~)))
?>  ?=(~ (post-request:http req(body.request `[1 raw])))
?>  ?=(~ (post-request:http req(secure %.y)))
?>  ?=(~ (post-request:http req(header-list.request [['origin' 'http://evil.invalid'] headers])))
?>  ?=(~ (post-request:http req(header-list.request [['X-Readymade-Editing-Activity' 'v1'] headers])))
?>  ?=(~ (post-request:http req(header-list.request [['host' 'localhost:8080'] headers])))
=/  key=selector:http  [~zod 'demo' 0v1]
=/  get-headers=(list [@t @t])
  ~[['x-readymade-activity-owner' '~zod'] ['x-readymade-project' 'demo'] ['x-readymade-activity-request' '0v1']]
=/  get=inbound-request:eyre
  req(method.request %'GET', header-list.request get-headers, body.request ~)
?>  =(`key (result-request:http get))
?>  ?=(~ (result-request:http get(authenticated %.n)))
?>  ?=(~ (result-request:http get(method.request %'POST')))
?>  ?=(~ (result-request:http get(header-list.request ~)))
?>  ?=(~ (result-request:http get(header-list.request [['x-readymade-activity-request' '0v1'] get-headers])))
?>  ?=(~ (result-request:http get(header-list.request ~[['x-readymade-activity-owner' '~zod'] ['x-readymade-project' 'demo'] ['x-readymade-activity-request' '0v0']])))
::  Encode only an exact correlated, already-filtered reply; no room/journal.
=/  snap=snapshot:server  *snapshot:server
=.  snap  snap(address [~zod 'demo' now], at now, rows ~[[~nec [%demo-work /lib/example/hoon]]])
=/  reply=response:server  [0v1 'demo' [%& snap]]
=/  rendered  (response:http key reply)
?>  ?=(^ rendered)
?>  ?=(%o -.u.rendered)
=/  obj=(map @t json)  p.u.rendered
?>  =(s+'ready' (~(got by obj) 'status'))
?>  =(s+'0v1' (~(got by obj) 'request'))
?>  =(b+%.n (~(got by obj) 'permissionGranted'))
?>  =(s+(scot %da now) (~(got by obj) 'epoch'))
?>  =(~ (~(got by obj) 'selfSequence'))
?>  =(11 ~(wyt by obj))
?>  =(a+~[(pairs:enjs:format ~[['ship' s+'~nec'] ['desk' s+'demo-work'] ['path' s+'/lib/example/hoon']])] (~(got by obj) 'rows'))
?>  !(~(has by obj) 'rooms')
?>  !(~(has by obj) 'journal')
?>  !(~(has by obj) 'grants')
?>  ?=(~ (response:http key(request 0v2) reply))
?>  ?=(~ (response:http key(owner ~bud) reply))
?>  ?=(~ (response:http key(project 'other') reply))
?>  ?=(~ (response:http key reply(result [%& snap(at (sub now ~s1))])))
?>  ?=(~ (response:http key reply(result [%& snap(rows (reap 33 [~nec [%demo-work /lib/example/hoon]]))])))
?>  ?=(~ (response:http key reply(result [%& snap(rows ~[[~nec [%demo-work /lib/private/js]]])])))
=/  cursor  (response:http key reply(result [%& snap(self-sequence `2)]))
?>  ?=(^ cursor)
?>  ?=(%o -.u.cursor)
?>  =(s+'2' (~(got by p.u.cursor) 'selfSequence'))
?>  ?=(~ (response:http key reply(result [%& snap(self-sequence `0)])))
?>  ?=(~ (response:http key reply(result [%& snap(self-sequence `(bex 64))])))
=/  refused  (response:http key [0v1 'demo' [%| %activity-permission-refused]])
?>  ?=(^ refused)
?>  ?=(%o -.u.refused)
?>  =(s+'refused' (~(got by p.u.refused) 'status'))
?>  =(a+~ (~(got by p.u.refused) 'rows'))
?>  =(~ (~(got by p.u.refused) 'epoch'))
?>  =(~ (~(got by p.u.refused) 'selfSequence'))
%readymade-editing-activity-http-proof-v1
