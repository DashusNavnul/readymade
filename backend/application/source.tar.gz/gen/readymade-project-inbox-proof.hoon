::  Pure owner inbox boundaries; native catalog/scry integration is separate.
/-  pa=cantrip-project-access
/+  inbox=readymade-project-inbox-http, changes=multiplayer-changeset,
    runtime=cantrip-project-access-runtime
|=  *
=/  hashes=(map path @ux)  (malt ~[[/lib/example/hoon (shax 'before')]])
=/  parent=parent:pa  [0x123 (make-snapshot:changes [1 'shared' %work 2 hashes])]
=/  request=request:pa  ['shared' 1 0x2 %suggest `parent /lib/example/hoon 'after']
=/  receipt=receipt:pa
  [~zod ~nec ~2026.11.9 0x456 request [%suggest parent [%modify /lib/example/hoon `(shax 'before') `(shax 'after')] 'after']]
?>  (receipt-valid:runtime receipt)
=/  saved=records:pa  (~(put by *records:pa) ['shared' ~nec 1 0x2] receipt)
=/  hash=@ux  (shax (jam receipt))
=/  query=selector:inbox  ['shared' ~]
?>  =(query (select:inbox 'shared' ~))
?>  =(query(receipt `hash) (select:inbox 'shared' `(scot %ux hash)))
?>  =(~ (mole |.((select:inbox '' ~))))
?>  =(~ (mole |.((select:inbox 'shared' `'0x0'))))
?>  =(~ (mole |.((select:inbox 'shared' `'0x01'))))
?>  =(~ (mole |.((select:inbox 'shared' `(scot %ux (bex 256))))))
?>  =(~[receipt] (rows:inbox ~zod ~zod query saved))
?>  =(~[receipt] (rows:inbox ~zod ~zod query(receipt `hash) saved))
?>  =(~ (rows:inbox ~zod ~zod query(project 'other') saved))
?>  =(~ (rows:inbox ~zod ~zod query(receipt `0x999) saved))
?>  =(~ (mole |.((rows:inbox ~zod ~nec query saved))))
=/  bad=records:pa  (~(put by *records:pa) ['shared' ~bud 1 0x2] receipt)
?>  =(~ (mole |.((rows:inbox ~zod ~zod query bad))))
=.  bad  (~(put by *records:pa) ['shared' ~nec 1 0x2] receipt(request request(source 'tampered')))
?>  =(~ (mole |.((rows:inbox ~zod ~zod query bad))))
=/  catalog=json  (row:inbox receipt %.n)
=/  detail=json  (row:inbox receipt %.y)
?>  ?=(%o -.catalog)
?>  ?=(%o -.detail)
?>  =(12 ~(wyt by p.catalog))
?>  =(13 ~(wyt by p.detail))
?>  !(~(has by p.catalog) 'source')
?>  =(`json`s+'after' (~(got by p.detail) 'source'))
?>  =(`json`s+(scot %ux hash) (~(got by p.detail) 'receiptHash'))
?>  =(`json`s+(scot %ux (shax 'before')) (~(got by p.detail) 'originalHash'))
=/  output=json  (encode:inbox ~zod ~zod query(receipt `hash) saved)
?>  ?=(%o -.output)
?>  =(`json`b+%.n (~(got by p.output) 'committed'))
?>  =(`json`b+%.n (~(got by p.output) 'permissionGranted'))
?>  =(`output (de:json:html (en:json:html output)))
?>  =(~ (mole |.((encode:inbox ~zod ~zod query(receipt `0x999) saved))))
=/  req=inbound-request:eyre  *inbound-request:eyre
=.  req  req(authenticated %.y, method.request %'GET', url.request '/apps/readymade-collab/project-inbox', header-list.request ~[['x-readymade-project' 'shared']])
?>  =(`query (request:inbox req))
?>  =(~ (request:inbox req(authenticated %.n)))
?>  =(~ (request:inbox req(request request.req(method %'POST'))))
?>  =(~ (request:inbox req(request request.req(url '/other'))))
::  The owner's answer to a suggestion is exact: five keys, this ship as
::  owner, a canonical receipt hash, and taken or declined.
=/  body
  |=  [who=@t receipt=@t answer=@t]
  ^-  @t
  (rap 3 ~['{"schema":"readymade-suggestion-answer-v1","owner":"' who '","project":"shared","receipt":"' receipt '","answer":"' answer '"}'])
?>  =(['shared' 0x5e55 %.y] (decode-answer:inbox ~zod (body '~zod' '0x5e55' 'taken')))
?>  =(['shared' 0x5e55 %.n] (decode-answer:inbox ~zod (body '~zod' '0x5e55' 'declined')))
=/  bad  |=(raw=@t =(~ (mole |.((decode-answer:inbox ~zod raw)))))
?>  (bad (body '~nec' '0x5e55' 'taken'))
?>  (bad (body '~zod' '0x0' 'taken'))
?>  (bad (body '~zod' '0x05e55' 'taken'))
?>  (bad (body '~zod' '0x5e55' 'maybe'))
?>  (bad '{"schema":"readymade-suggestion-answer-v1","owner":"~zod","project":"shared","receipt":"0x5e55"}')
?>  (bad '{"schema":"readymade-suggestion-answer-v1","owner":"~zod","project":"shared","receipt":"0x5e55","answer":"taken","extra":"x"}')
::  Only the owner's own authenticated same-origin JSON POST with the
::  explicit header is read at all.
=/  raw=@t  (body '~zod' '0x5e55' 'taken')
=/  post=inbound-request:eyre  *inbound-request:eyre
=.  post
  %=    post
      authenticated  %.y
      secure  %.n
      request
    :*  %'POST'  '/apps/readymade-collab/suggestion-answer'
        ~[['host' 'localhost:8080'] ['origin' 'http://localhost:8080'] ['content-type' 'application/json'] ['x-readymade-suggestion-answer' 'v1']]
        `[(met 3 raw) raw]
    ==
  ==
?>  =(`['shared' 0x5e55 %.y] (answer-request:inbox ~zod post))
?>  =(~ (answer-request:inbox ~zod post(authenticated %.n)))
::  Over TLS the origin must be https as well.
?>  =(~ (answer-request:inbox ~zod post(secure %.y)))
?>  =(~ (answer-request:inbox ~zod post(request request.post(method %'GET'))))
?>  =(~ (answer-request:inbox ~zod post(request request.post(header-list ~[['host' 'localhost:8080'] ['origin' 'http://evil.example'] ['content-type' 'application/json'] ['x-readymade-suggestion-answer' 'v1']]))))
?>  =(~ (answer-request:inbox ~zod post(request request.post(header-list ~[['host' 'localhost:8080'] ['origin' 'http://localhost:8080'] ['content-type' 'application/json']]))))
?>  =(~ (answer-request:inbox ~nec post))
?>  ?=(^ (find "\"status\":\"sent\"" (trip (en:json:html (answer-receipt:inbox %.y)))))
?>  ?=(^ (find "\"answer\":\"declined\"" (trip (en:json:html (answer-receipt:inbox %.n)))))
[%readymade-project-inbox-proof %passed]
