::  Pure owner inbox boundaries; native catalog/scry integration is separate.
/-  pa=cantrip-project-access
/+  inbox=readymade-project-inbox-http, changes=multiplayer-changeset,
    runtime=cantrip-project-access-runtime
|=  *
=/  hashes=(map path @ux)  (malt ~[[/lib/example/hoon (shax 'before')]])
=/  parent=parent:pa  [0x123 (make-snapshot:changes [1 'shared' %work 2 hashes])]
=/  request=request:pa  ['shared' 1 0x2 %suggest `parent /lib/example/hoon 'after']
=/  receipt=receipt:pa
  [~zod ~nec ~2026.11.9 0x456 request [%suggest parent [%modify /lib/example/hoon `(shax 'before') `(shax 'after')] 'after']]
?>  (receipt-valid:runtime receipt)
=/  saved=records:pa  (~(put by *records:pa) ['shared' ~nec 1 0x2] receipt)
=/  hash=@ux  (shax (jam receipt))
=/  query=selector:inbox  ['shared' ~]
?>  =(query (select:inbox 'shared' ~))
?>  =(query(receipt `hash) (select:inbox 'shared' `(scot %ux hash)))
?>  =(~ (mole |.((select:inbox '' ~))))
?>  =(~ (mole |.((select:inbox 'shared' `'0x0'))))
?>  =(~ (mole |.((select:inbox 'shared' `'0x01'))))
?>  =(~ (mole |.((select:inbox 'shared' `(scot %ux (bex 256))))))
?>  =(~[receipt] (rows:inbox ~zod ~zod query saved))
?>  =(~[receipt] (rows:inbox ~zod ~zod query(receipt `hash) saved))
?>  =(~ (rows:inbox ~zod ~zod query(project 'other') saved))
?>  =(~ (rows:inbox ~zod ~zod query(receipt `0x999) saved))
?>  =(~ (mole |.((rows:inbox ~zod ~nec query saved))))
=/  bad=records:pa  (~(put by *records:pa) ['shared' ~bud 1 0x2] receipt)
?>  =(~ (mole |.((rows:inbox ~zod ~zod query bad))))
=.  bad  (~(put by *records:pa) ['shared' ~nec 1 0x2] receipt(request request(source 'tampered')))
?>  =(~ (mole |.((rows:inbox ~zod ~zod query bad))))
=/  catalog=json  (row:inbox receipt %.n)
=/  detail=json  (row:inbox receipt %.y)
?>  ?=(%o -.catalog)
?>  ?=(%o -.detail)
?>  =(12 ~(wyt by p.catalog))
?>  =(13 ~(wyt by p.detail))
?>  !(~(has by p.catalog) 'source')
?>  =(`json`s+'after' (~(got by p.detail) 'source'))
?>  =(`json`s+(scot %ux hash) (~(got by p.detail) 'receiptHash'))
?>  =(`json`s+(scot %ux (shax 'before')) (~(got by p.detail) 'originalHash'))
=/  output=json  (encode:inbox ~zod ~zod query(receipt `hash) saved)
?>  ?=(%o -.output)
?>  =(`json`b+%.n (~(got by p.output) 'committed'))
?>  =(`json`b+%.n (~(got by p.output) 'permissionGranted'))
?>  =(`output (de:json:html (en:json:html output)))
?>  =(~ (mole |.((encode:inbox ~zod ~zod query(receipt `0x999) saved))))
=/  req=inbound-request:eyre  *inbound-request:eyre
=.  req  req(authenticated %.y, method.request %'GET', url.request '/apps/readymade-collab/project-inbox', header-list.request ~[['x-readymade-project' 'shared']])
?>  =(`query (request:inbox req))
?>  =(~ (request:inbox req(authenticated %.n)))
?>  =(~ (request:inbox req(request request.req(method %'POST'))))
?>  =(~ (request:inbox req(request request.req(url '/other'))))
[%readymade-project-inbox-proof %passed]
