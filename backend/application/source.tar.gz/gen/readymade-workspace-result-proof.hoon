/-  nc=native-coding
/+  law=readymade-workspace-result, web=readymade-workspace-result-http,
    sessions=native-coding-session, requests=readymade-workspace-requests,
    completion=readymade-workspace-completion, tools=cantrip-native-coding-contract,
    project=native-coding-project, fixture=qpc-native-outcome-proof,
    acceptance=native-coding-accept, files=native-coding-files,
    changes=multiplayer-changeset
|=  *
=/  at=@da  ~2026.11.9
=/  later=@da  (add at ~s1)
=/  last-at=@da  (add at ~s2)
=/  source=revision:nc  [~zod %work 2 0v4 0v5]
=/  make
  |=  [seq=@ud prior=(unit @ux) now=@da body=body:sessions]
  ^-  record:sessions
  [seq prior now body (event-id:sessions 0x1 seq prior now body)]
=/  first=record:sessions  (make 0 ~ at [%operator 'Review exactly this request.'])
=/  last=record:sessions  (make 1 `id.first later [%judgment %complete ~[0x8] 'Owner completed review.'])
=/  rows=(list record:sessions)  ~[first last]
=/  original=record:requests  *record:requests
=.  original  original(value value.original(session 0x1, grant 0x2, source source), instruction 'Review exactly this request.')
=/  complete=result:completion  [%complete `id.first `id.last ~[0x8] %native-completion]
=/  none  (inspect:law ~zod original complete rows *organ:tools ~ source)
?>  ?=(%& -.none)
?>  =(source final.p.none)
?>  =(~ candidates.p.none)
?>  =(~ checks.p.none)
=/  advanced  (inspect:law ~zod original complete rows *organ:tools ~ source(number 3))
?>  ?=(%| -.advanced)
?>  =(%result-unattributed-source-advance p.advanced)
=/  foreign  (inspect:law ~per original complete rows *organ:tools ~ source)
?>  ?=(%| -.foreign)
=/  corrupt  (interval:law 0x1 ~[first last(previous ~)] id.first id.last instruction.original)
?>  ?=(%| -.corrupt)
=/  missing  (interval:law 0x1 ~[first] id.first id.last instruction.original)
?>  ?=(%| -.missing)
=/  other=record:sessions  (make 1 `id.first later [%operator 'A later request.'])
=/  subsequent=record:sessions  (make 2 `id.other last-at [%judgment %complete ~[0x8] 'Other work.'])
=/  superseded  (interval:law 0x1 ~[first other subsequent] id.first id.subsequent instruction.original)
?>  ?=(%| -.superseded)
=/  ack=record:sessions  (make 1 `id.first later [%judgment %continue ~[0x9] 'Exact native candidate acknowledgment.'])
?>  =(`1 (acknowledgment:law ~[first ack] 0 0x9))
?>  =(~ (acknowledgment:law ~[first ack] 1 0x9))
?>  =(~ (acknowledgment:law ~[first ack] 0 0xa))
?>  =(~ (acknowledgment:law ~[first ack ack] 0 0x9))
=/  config=project:nc  *project:nc
=.  config  config(spec spec.config(id 'demo'))
=/  context=context:nc  ['demo' (configuration:project config) 0x1 0x4 ~zod source]
=/  request=tool-request:nc  [%native-coding-tool-request-v1 context 'check-1' [%check %main]]
=/  diagnostic=diagnostic:nc  [%multiplication %.n 'Expected 6, observed 5.' source ~[0xb]]
=/  output=tool-result:nc  [%native-coding-tool-result-v1 context 'check-1' [%diagnostics ~[diagnostic]]]
=/  job=record:tools  [0x2 request later %finished `output]
=/  held=organ:tools  [~ (~(put by *(map @ux record:tools)) (key:tools request) job)]
=/  tool=record:sessions  (make 1 `id.first last-at [%tool output])
=/  joined  (tool-join:law held at tool)
?>  ?=(^ joined)
?>  =(job value.u.joined)
?>  =(~ (tool-join:law held later tool))
?>  =(~ (tool-join:law held at tool(body [%tool output(call-id 'wrong')])))
=/  unconfirmed=organ:tools  held(records (~(put by records.held) (key:tools request) job(stage %unknown)))
?>  =(~ (tool-join:law unconfirmed at tool))
=/  unrelated  (inspect:law ~zod original complete rows held ~ source)
?>  ?=(%| -.unrelated)
?>  =(%result-unattributed-tool p.unrelated)
=/  scope=scope:tools  [[0x2 0x1 ~zod config (silt ~[%check]) ~ 1] ~]
=.  held  held(grants (~(put by grants.held) 0x2 scope))
=/  end=record:sessions  (make 2 `id.tool (add at ~s3) [%judgment %complete ~[0x8] 'Check result reviewed.'])
=/  with-check  (inspect:law ~zod original complete(judgment `id.end) ~[first tool end] held ~ source)
?>  ?=(%& -.with-check)
?>  ?=([* ~] checks.p.with-check)
?>  !passed.diagnostic.i.checks.p.with-check
?>  =((key:tools request) tool.i.checks.p.with-check)
?>  =(source source.diagnostic.i.checks.p.with-check)
=/  check-json=json  (diagnostic:web diagnostic)
?>  ?=(%o -.check-json)
?>  =(`b+%.n (~(get by p.check-json) 'passed'))
?>  =(`s+'Expected 6, observed 5.' (~(get by p.check-json) 'detail'))
=/  change-json=json
  (file:web [0xc source source(number 3) [%modify /lib/handoff/hoon `0xd `0xe] `'old\0a' `'new\0a'])
?>  ?=(%o -.change-json)
?>  =(`s+'old\0a' (~(get by p.change-json) 'beforeText'))
?>  =(`s+'new\0a' (~(get by p.change-json) 'afterText'))
::  Reuse the native outcome fixture's valid candidate and report structure.
::  Pass flags below are explicitly synthetic, not an executed compiler.
=/  [manifest=* work=* cases=* accepted=record:acceptance]  fixture:fixture
=/  candidate=candidate:nc  candidate.accepted
=/  ctx=context:nc  context.candidate
=/  config=project:nc  project.accepted
=/  report=report:acceptance  (need report.accepted)
=.  report
  report(targets (turn targets.report |=(target=target-result:acceptance target(diagnostics (turn diagnostics.target |=(d=diagnostic:nc d(passed %.y, detail 'Synthetic successful check.')))))))
?>  (report-valid:acceptance config candidate report)
=/  challenge=challenge:acceptance
  [%native-coding-challenge-v1 id.candidate (digest:acceptance report) %passed ~[0xf] 'Synthetic owner review.']
=/  decision=decision:acceptance
  [%native-coding-decision-v1 id.candidate ctx basis.candidate report challenge %approve source.ctx later]
?>  (decision-valid:acceptance config candidate decision)
=/  landed=tree:nc
  [[~zod desk.source.ctx +(number.source.ctx) 0v7 0v8] (make-snapshot:changes [1 project.ctx desk.source.ctx +(number.source.ctx) (after-map:files candidate)])]
=.  accepted  accepted(stage %applied, requested-at later, report `report, decision `decision, landed `landed)
=/  ledger=ledger:acceptance  (~(put by *ledger:acceptance) id.candidate accepted)
?>  (valid:acceptance ledger)
=/  make-c
  |=  [seq=@ud prior=(unit @ux) now=@da body=body:sessions]
  ^-  record:sessions
  [seq prior now body (event-id:sessions session.ctx seq prior now body)]
=/  begin=record:sessions  (make-c 0 ~ at [%operator 'Apply this one fixture change.'])
=/  proposal=tool-request:nc  [%native-coding-tool-request-v1 ctx 'candidate-1' [%create /lib/example/hoon [%hoon '|=  a=@  a\0a']]]
=/  returned=tool-result:nc  [%native-coding-tool-result-v1 ctx 'candidate-1' [%candidate candidate]]
=/  admitted=record:tools  [grant.accepted proposal later %finished `returned]
=/  scope=scope:tools  [[grant.accepted session.ctx ~zod config ~ ~ 1] ~]
=/  tools=organ:tools
  [(malt ~[[grant.accepted scope]]) (malt ~[[(key:tools proposal) admitted]])]
=/  produced=record:sessions  (make-c 1 `id.begin last-at [%tool returned])
=/  acknowledged=record:sessions
  (make-c 2 `id.produced (add at ~s3) [%judgment %continue ~[(digest:acceptance accepted)] 'Native landing consumed.'])
=/  terminal=record:sessions
  (make-c 3 `id.acknowledged (add at ~s4) [%judgment %complete ~[0xf] 'Fixture complete.'])
=/  request-record=record:requests
  original(value value.original(session session.ctx, grant grant.accepted, source source.ctx), instruction 'Apply this one fixture change.')
=/  completed=result:completion  [%complete `id.begin `id.terminal ~[0xf] %native-completion]
=/  journal=(list record:sessions)  ~[begin produced acknowledged terminal]
=/  applied  (inspect:law ~zod request-record completed journal tools ledger revision.landed)
?>  ?=(%& -.applied)
?>  =(revision.landed final.p.applied)
?>  ?=([* ~] candidates.p.applied)
?>  =(accepted i.candidates.p.applied)
?>  =(4 (lent checks.p.applied))
?>  (levy checks.p.applied |=(c=check:law &(=(`id.candidate candidate.c) passed.diagnostic.c)))
=/  wrong-ack=record:sessions
  (make-c 2 `id.produced (add at ~s3) [%judgment %continue ~[0xdead] 'Different candidate.'])
=/  wrong-end=record:sessions
  (make-c 3 `id.wrong-ack (add at ~s4) [%judgment %complete ~[0xf] 'Fixture complete.'])
=/  unacknowledged
  (inspect:law ~zod request-record completed(judgment `id.wrong-end) ~[begin produced wrong-ack wrong-end] tools ledger revision.landed)
?>  ?=(%| -.unacknowledged)
?>  =(%result-candidate-not-acknowledged p.unacknowledged)
=/  source-gap
  (inspect:law ~zod request-record(value value.request-record(source source.ctx(number 9))) completed journal tools ledger revision.landed)
?>  ?=(%| -.source-gap)
?>  =(%result-source-chain-gap p.source-gap)
=/  wrong-hash=ledger:acceptance
  (~(put by ledger) id.candidate accepted(candidate candidate(id 0xdead)))
=/  hash-refused  (inspect:law ~zod request-record completed journal tools wrong-hash revision.landed)
?>  ?=(%| -.hash-refused)
?>  =(%result-candidate-mismatch p.hash-refused)
%readymade-workspace-result-proof-passed
