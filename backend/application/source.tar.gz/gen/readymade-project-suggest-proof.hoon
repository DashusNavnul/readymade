::  Inert law/HTTP proof; emitted cards are values, never dispatched.
/-  pa=cantrip-project-access, v=cantrip-project-view
/+  client=readymade-project-suggest-client, http=readymade-project-suggest-http,
    view=readymade-project-view-client, changes=multiplayer-changeset,
    runtime=cantrip-project-access-runtime
|=  *
=/  now=@da  ~2026.11.9
=/  files=(map path @t)  (malt ~[[/lib/example/hoon '|=  a=@  +(a)']])
=/  hashes=(map path @ux)  (malt ~[[/lib/example/hoon (shax '|=  a=@  +(a)')]])
=/  basis=basis:pa  [~zod now 0x123 (make-snapshot:changes [1 'shared' %work 2 hashes]) files]
=/  k=selector:view  [~zod ['shared' 1 0x1]]
=/  response=response:v  [~zod ~nec query.k 0x456 basis]
=/  observed=entry:view  [k (add now ~s30) (add now ~m5) %ready %observed `response]
=/  source=@t  '|=  a=@  (add a 2)'
=/  begun  (begin:client ~nec now 0x2 observed /lib/example/hoon source ~)
?>  ?=(%& -.result.begun)
=/  e=entry:client  p.result.begun
=/  held=journal:client  journal.begun
=/  wir=wire  (wire-for:client key.e deadline.e)
?>  =(`[key.e deadline.e] (parse-wire:client wir))
?>  =(2 (lent cards.begun))
?>  =(`card:agent:gall`[%pass wir %arvo %b %wait (add now ~s30)] (head cards.begun))
?>  =(`card:agent:gall`[%pass wir %agent [~zod %cantrip] %watch (route:runtime ~nec request.e)] (head (tail cards.begun)))
=/  wrong-peer  (begin:client ~bud now 0x2 observed /lib/example/hoon source ~)
?>  ?=(%| -.result.wrong-peer)
=/  expired  (begin:client ~nec retained.observed 0x2 observed /lib/example/hoon source ~)
?>  ?=(%| -.result.expired)
=/  outside  (begin:client ~nec now 0x2 observed /lib/other/hoon source ~)
?>  ?=(%| -.result.outside)
=/  reused  (begin:client ~nec now 0x2 observed /lib/example/hoon source held)
?>  ?=(%& -.result.reused)
?>  =(~ cards.reused)
?>  =(held journal.reused)
=/  conflict  (begin:client ~nec now 0x2 observed /lib/example/hoon 'different' held)
?>  ?=(%| -.result.conflict)
=/  ready=sign:agent:gall  [%fact %noun !>(`event:pa`[%cantrip-project-ready-v1 ~zod ~nec 0x456])]
?>  =([held ~] (receive:client ~nec ~bud now held wir ready))
=/  mismatch=sign:agent:gall  [%fact %noun !>(`event:pa`[%cantrip-project-ready-v1 ~zod ~nec 0x999])]
=/  mismatched  (receive:client ~nec ~zod now held wir mismatch)
=/  mismatch-entry  (~(got by journal.mismatched) key.e)
?>  =(%uncertain phase.mismatch-entry)
?>  =((cleanup:client key.e deadline.e) cards.mismatched)
=/  sent  (receive:client ~nec ~zod now held wir ready)
=/  sent-entry  (~(got by journal.sent) key.e)
?>  =(%sent phase.sent-entry)
?>  =(1 (lent cards.sent))
?>  =(`card:agent:gall`[%pass wir %agent [~zod %cantrip] %poke %noun !>(`action:pa`[%cantrip-project-request-v1 request.e])] (head cards.sent))
::  ACK does not confirm a suggestion, duplicate ready cannot send again.
?>  =([journal.sent ~] (receive:client ~nec ~zod now journal.sent wir ready))
?>  =([journal.sent ~] (receive:client ~nec ~zod now journal.sent wir [%poke-ack ~]))
=/  r=receipt:pa
  [~zod ~nec now 0x456 request.e [%suggest [root.basis snapshot.basis] [%modify /lib/example/hoon `(~(got by hashes) /lib/example/hoon) `(shax source)] source]]
?>  (receipt-valid:runtime r)
=/  fact=sign:agent:gall  [%fact %noun !>(`event:pa`[%cantrip-project-receipt-v1 r])]
=/  recorded  (receive:client ~nec ~zod now journal.sent wir fact)
=/  record  (~(got by journal.recorded) key.e)
?>  &(=(%recorded phase.record) =(`r receipt.record))
?>  =((cleanup:client key.e deadline.e) cards.recorded)
?>  =([journal.recorded ~] (receive:client ~nec ~zod now journal.recorded wir ready))
=/  changed=sign:agent:gall  [%fact %noun !>(`event:pa`[%cantrip-project-receipt-v1 r(grant 0x999)])]
=/  rejected  (receive:client ~nec ~zod now journal.sent wir changed)
=/  rejected-entry  (~(got by journal.rejected) key.e)
?>  =(%uncertain phase.rejected-entry)
=/  timed  (wake:client deadline.e journal.sent wir)
=/  uncertain  (~(got by journal.timed) key.e)
?>  =(%uncertain phase.uncertain)
?>  =((cleanup:client key.e deadline.e) cards.timed)
?>  =([journal.timed ~] (receive:client ~nec ~zod deadline.e journal.timed wir ready))
?>  =(`uncertain (result:client deadline.e key.e journal.sent))
?>  =(~ (result:client retained.e key.e journal.sent))
=/  outgoing=boat:gall
  (malt ~[[[wir ~zod %cantrip] [%.y (route:runtime ~nec request.e)]]])
?>  =((cleanup:client key.e deadline.e) (reload:client ~nec outgoing))
?>  =(~ (reload:client ~bud outgoing))
?>  =([~ (cleanup:client key.e deadline.e)] (wake:client deadline.e ~ wir))
=/  fields=(map @t json)
  (malt ~[['schema' s+'readymade-project-suggest-v1'] ['owner' s+'~zod'] ['project' s+'shared'] ['generation' s+'1'] ['viewRequest' s+'0x1'] ['request' s+'0x2'] ['path' s+'/lib/example/hoon'] ['source' s+source]])
=/  bad-nonces=(list @t)  ~['0x0' '0x02' '0x1.0000.0000.0000.0000.0000.0000.0000.0000']
?>  %+  levy  bad-nonces
    |=  text=@t
    ?=(~ (parse:http (en:json:html [%o (~(put by fields) 'request' s+text)])))
=/  raw=@t  (en:json:html [%o fields])
?>  =(`[k 0x2 /lib/example/hoon source] (parse:http raw))
?>  =(~ (parse:http (cat 3 '{"owner":"~zod",' (rsh [3 1] raw))))
?>  =(~ (parse:http (cat 3 '{"ow\5cu006eer":"~zod",' (rsh [3 1] raw))))
=/  punctuation=@t  '::  "quoted": \5c source'
?>  ?=(^ (parse:http (en:json:html [%o (~(put by fields) 'source' s+punctuation)])))
=/  req=inbound-request:eyre  *inbound-request:eyre
=/  headers=(list [@t @t])
  ~[['host' 'localhost:8080'] ['origin' 'http://localhost:8080'] ['content-type' 'application/json'] ['x-readymade-project-suggest' 'v1']]
=.  req  req(authenticated %.y, secure %.n, method.request %'POST', url.request '/apps/readymade-collab/project-suggest', header-list.request headers, body.request `[(met 3 raw) raw])
?>  =((parse:http raw) (post-request:http req))
?>  =(~ (post-request:http req(authenticated %.n)))
?>  =(~ (post-request:http req(secure %.y)))
?>  =(~ (post-request:http req(header-list.request [['origin' 'http://evil.invalid'] headers])))
?>  =(~ (post-request:http req(body.request `[1 raw])))
=/  get-headers=(list [@t @t])
  ~[['x-readymade-project-owner' '~zod'] ['x-readymade-project' 'shared'] ['x-readymade-project-generation' '1'] ['x-readymade-project-suggest-request' '0x2']]
=/  get=inbound-request:eyre
  req(method.request %'GET', url.request '/apps/readymade-collab/project-suggest-result', header-list.request get-headers, body.request ~)
?>  =(`key.e (result-request:http get))
?>  =(~ (result-request:http get(authenticated %.n)))
?>  =(~ (result-request:http get(method.request %'POST')))
?>  =(~ (result-request:http get(header-list.request [['x-readymade-project' 'shared'] get-headers])))
=/  nack  (receive:client ~nec ~zod now held wir [%watch-ack `~[leaf+"refused"]])
=/  nack-entry  (~(got by journal.nack) key.e)
?>  =(%refused phase.nack-entry)
?>  =((cleanup:client key.e deadline.e) cards.nack)
=/  early  (receive:client ~nec ~zod now held wir fact)
=/  early-entry  (~(got by journal.early) key.e)
?>  =(%uncertain phase.early-entry)
=/  result-json=json  (response:http ~nec record)
?>  ?=(%o -.result-json)
?>  =([%b %.n] (~(got by p.result-json) 'committed'))
?>  =([%s 'recorded'] (~(got by p.result-json) 'status'))
?>  =([%s '0x1'] (~(got by p.result-json) 'viewRequest'))
?>  =([%s '0x2'] (~(got by p.result-json) 'request'))
?>  =([%s (scot %ux root.basis)] (~(got by p.result-json) 'root'))
?>  =([%s (scot %ux digest.snapshot.basis)] (~(got by p.result-json) 'snapshotDigest'))
::  Recovery has a separate journal and wire; original uncertain send stays.
=/  recovered-start  (recover:client ~nec now key.e 0x1 0x456 root.basis digest.snapshot.basis /lib/example/hoon source ~)
?>  ?=(%& -.result.recovered-start)
=/  recovery-entry=entry:client  p.result.recovered-start
=/  recovery-held=journal:client  journal.recovered-start
=/  recovery-wire=wire  (operation-wire:client key.e deadline.recovery-entry %.y)
=/  recovery-cleanup  (operation-cleanup:client key.e deadline.recovery-entry %.y)
?>  =(2 (lent cards.recovered-start))
?>  =(`card:agent:gall`[%pass recovery-wire %arvo %b %wait deadline.recovery-entry] (head cards.recovered-start))
?>  =(`card:agent:gall`[%pass recovery-wire %agent [~zod %cantrip] %watch /project-receipt/(scot %ux 'shared')/~nec/1/0x2] (head (tail cards.recovered-start)))
=/  duplicate-recovery  (recover:client ~nec now key.e 0x1 0x456 root.basis digest.snapshot.basis /lib/example/hoon source recovery-held)
?>  &(=(recovery-held journal.duplicate-recovery) =(~ cards.duplicate-recovery))
=/  conflict-recovery  (recover:client ~nec now key.e 0x1 0x456 root.basis digest.snapshot.basis /lib/example/hoon 'different' recovery-held)
?>  ?=(%| -.result.conflict-recovery)
=/  ready-on-recovery  (receive:client ~nec ~zod now recovery-held recovery-wire ready)
=/  ready-refused  (~(got by journal.ready-on-recovery) key.e)
?>  =(%uncertain phase.ready-refused)
?>  =(recovery-cleanup cards.ready-on-recovery)
=/  recovered  (receive:client ~nec ~zod now recovery-held recovery-wire fact)
=/  recovered-entry  (~(got by journal.recovered) key.e)
?>  &(=(%recorded phase.recovered-entry) =(`r receipt.recovered-entry))
?>  =(recovery-cleanup cards.recovered)
?>  =(%uncertain phase.uncertain)
?>  =(~ receipt.uncertain)
=/  adverse=(list entry:client)
  :~  recovery-entry(grant 0x999)  recovery-entry(root 0x999)
      recovery-entry(snapshot-digest 0x999)
      recovery-entry(request request.recovery-entry(source 'different'))
      recovery-entry(request request.recovery-entry(pax /lib/other/hoon))
      recovery-entry(key key.e(owner ~bud))
      recovery-entry(key key.e(query query.key.e(nonce 0x3)))
  ==
?>  %+  levy  adverse
    |=  other=entry:client
    !(receipt-matches:client ~nec other r)
?>  !(receipt-matches:client ~bud recovery-entry r)
=/  empty-recovery  (receive:client ~nec ~zod now recovery-held recovery-wire [%kick ~])
=/  empty-entry  (~(got by journal.empty-recovery) key.e)
?>  =(%uncertain phase.empty-entry)
?>  =(recovery-cleanup cards.empty-recovery)
=/  recovery-timeout  (wake:client deadline.e recovery-held recovery-wire)
?>  =(recovery-cleanup cards.recovery-timeout)
=/  recovery-outgoing=boat:gall
  (malt ~[[[recovery-wire ~zod %cantrip] [%.y /project-receipt/(scot %ux 'shared')/~nec/1/0x2]]])
?>  =(recovery-cleanup (reload:client ~nec recovery-outgoing))
?>  =(~ (reload:client ~bud recovery-outgoing))
=/  recovery-fields=(map @t json)  (~(put by fields) 'schema' s+'readymade-project-suggest-recover-v1')
=.  recovery-fields  (~(put by recovery-fields) 'grant' s+'0x456')
=.  recovery-fields  (~(put by recovery-fields) 'root' s+(scot %ux root.basis))
=.  recovery-fields  (~(put by recovery-fields) 'snapshotDigest' s+(scot %ux digest.snapshot.basis))
=/  recovery-raw=@t  (en:json:html [%o recovery-fields])
?>  =(`[[k 0x2 /lib/example/hoon source] 0x456 root.basis digest.snapshot.basis] (parse-recovery:http recovery-raw))
?>  =(~ (parse-recovery:http (cat 3 '{"owner":"~zod",' (rsh [3 1] recovery-raw))))
?>  =(~ (parse-recovery:http raw))
=/  recovery-req=inbound-request:eyre  req(url.request '/apps/readymade-collab/project-suggest-recover', body.request `[(met 3 recovery-raw) recovery-raw])
?>  =((parse-recovery:http recovery-raw) (recover-request:http recovery-req))
?>  =(~ (recover-request:http recovery-req(authenticated %.n)))
?>  =(~ (recover-request:http recovery-req(secure %.y)))
?>  =(~ (recover-request:http recovery-req(header-list.request [['origin' 'http://evil.invalid'] headers])))
=/  recovery-get=inbound-request:eyre  get(url.request '/apps/readymade-collab/project-suggest-recovery-result')
?>  =(`key.e (recovery-result-request:http recovery-get))
?>  =(~ (recovery-result-request:http recovery-get(authenticated %.n)))
=/  recovery-json=json  (recovery-response:http ~nec recovered-entry)
?>  ?=(%o -.recovery-json)
?>  =([%s 'readymade-project-suggest-recovery-result-v1'] (~(got by p.recovery-json) 'schema'))
?>  =([%b %.y] (~(got by p.recovery-json) 'recovery'))
?>  =([%b %.n] (~(got by p.recovery-json) 'committed'))
?>  (lte (met 3 (en:json:html recovery-json)) 8.192)
[%readymade-project-suggest-proof %passed]
