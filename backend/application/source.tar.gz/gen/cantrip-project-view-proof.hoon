::  Pure boundary proof; native current-source reads and Gall delivery require
::  separate owner/peer qualification. This generator sends no cards.
/-  view=cantrip-project-view, pa=cantrip-project-access
/+  runtime=cantrip-project-access-runtime, changes=multiplayer-changeset,
    law=cantrip-law-window
|=  *
=/  q=query:view  ['shared' 1 0x1]
=/  watch-path=path  (view-route:runtime ~nec q)
?>  =(`[~nec q] (view-parse:runtime watch-path))
?>  =(~ (view-parse:runtime /project-view))
?>  =(~ (view-parse:runtime (weld watch-path /extra)))
?>  =(~ (view-parse:runtime /project-view/0x0/~nec/1/0x1))
?>  =(~ (view-parse:runtime /project-view/0x1/~nec/0/0x1))
?>  =(~ (view-parse:runtime /project-view/0x1/~nec/1/0x0))
?>  =(~ (view-parse:runtime /project-view/0x1/nec/1/0x1))
?>  =(~ (view-parse:runtime `(list @ta)`~[%project-view '0x1' '~nec' '01' '0x1']))
?>  =(~ (view-parse:runtime `(list @ta)`~[%project-view '0x01' '~nec' '1' '0x1']))
?>  =(~ (view-parse:runtime (view-route:runtime ~nec q(nonce (bex 128)))))
?>  =(~ (view-parse:runtime (view-route:runtime ~nec q(generation (bex 64)))))
?>  =(~ (view-parse:runtime (view-route:runtime ~nec q(project `@t`(bex 1.024)))))
=/  now=@da  ~2026.11.8
=/  files=(map path @t)  (malt ~[[/lib/example/hoon '|=  a=@  +(a)']])
=/  hashes=(map path @ux)
  (malt ~[[/lib/example/hoon (shax '|=  a=@  +(a)')]])
=/  b=basis:pa  [~zod now 0x123 (make-snapshot:changes [1 'shared' %work 2 hashes]) files]
=/  r=response:view  [~zod ~nec q 0x456 b]
?>  (view-valid:runtime r)
?>  !(view-valid:runtime r(owner ~bud))
?>  !(view-valid:runtime r(query q(project 'another')))
?>  !(view-valid:runtime r(grant 0x0))
?>  !(view-valid:runtime r(basis b(root 0x0)))
?>  !(view-valid:runtime r(basis b(files (malt ~[[/lib/example/hoon 'changed']]))))
=/  cards  (view-cards:runtime watch-path r)
?>  =(2 (lent cards))
?>  ?=([* * ~] cards)
?>  =(`card:agent:gall`[%give %fact ~[watch-path] %noun !>(`event:view`[%cantrip-project-view-v1 r])] i.cards)
?>  =(`card:agent:gall`[%give %kick ~[watch-path] ~] i.t.cards)
::  Admission refuses an authenticated different peer before any scry.
=/  bowl=bowl:gall  *bowl:gall
=.  bowl  bowl(our ~zod, src ~bud, now now)
?>  =([%| %foreign-peer] (watch-view:runtime bowl ~ watch-path *window:law))
=.  bowl  bowl(src ~nec)
?>  =([%| %grant-missing] (watch-view:runtime bowl ~ watch-path *window:law))
::  Response/card construction has no records input/output; historical journal
::  capacity and replay remain exclusively on the old request operation.
[%cantrip-project-view-proof %passed]
