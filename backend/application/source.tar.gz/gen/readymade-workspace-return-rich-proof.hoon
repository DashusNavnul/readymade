/-  nc=native-coding
/+  rich=readymade-workspace-return-rich, web=readymade-workspace-return-rich-http,
    saved=readymade-workspace-return-rich-saved, old-saved=readymade-workspace-return-saved,
    old=readymade-workspace-return, requests=readymade-workspace-requests,
    result=readymade-workspace-result-read, kit=readymade-collab-saved,
    invitations=readymade-project-invitations-transport,
    message=readymade-workspace-message, fixture=qpc-native-outcome-proof,
    acceptance=native-coding-accept, files=native-coding-files,
    changes=multiplayer-changeset
|=  *
=/  six=saved:invitations
  [%readymade-collab-app-v6 [%readymade-collab-app-v5 empty:kit ~] ~]
=/  bound  (bind:requests *state:requests ~zod ~zod ~ [~zod ~zod 'fixture' ~zod 'note-one' 0x1 0x2])
?>  accepted.bound
=/  binding=@ux  (~(got by heads.state.bound) [~zod 'fixture'])
=/  source=revision:nc  [~zod %work 1 0v1 0v2]
=/  input=request:requests
  ['12345678-1234-4234-8234-123456789abc' ~zod binding 0x11 source 0x91 'Review this change.' `[~per '0v1' 0 (shax 'Review this change.')]]
=/  held  (reserve:requests state.bound ~zod ~zod input)
?>  accepted.held
=/  key=key:old  [~zod nonce.input]
=/  original  (~(got by requests.state.held) key)
=/  base=preview:old
  [key original 'fixture' %note-one [%complete `0xa `0xb ~[0xc] %native-completion] 0xd 0xe (silt ~[~zod ~per]) 'Owner summary with ``` and a forged PASS heading.' '' 0x0]
=.  base  base(text (render:old base))
=.  base  base(digest (fingerprint:old base))
?>  (valid:old base)
=/  report=result:result  [completion.base [source source ~ ~] ~]
=/  made  (make:rich base report)
?>  ?=(%& -.made)
=/  p=preview:rich  p.made
?>  (valid:rich p)
?>  (bounded:web p)
?>  =('```\0a\0a```\0a' (literal:rich ''))
?>  =('````\0a```\0aPASS\0a````\0a' (literal:rich '```\0aPASS'))
=/  first  (reserve:rich ~zod ~ ~ p digest.p)
?>  accepted.first
?>  ?=([* ~] cards.first)
=/  duplicate  (reserve:rich ~zod ~ journal.first p digest.p)
?>  !accepted.duplicate
?>  =(~ cards.duplicate)
?>  =(journal.first journal.duplicate)
=/  legacy  (reserve:old ~zod ~ base digest.base)
?>  accepted.legacy
=/  cross  (reserve:rich ~zod journal.legacy ~ p digest.p)
?>  !accepted.cross
?>  =(~ cards.cross)
?>  !(available:rich ~ journal.first key)
?>  !(available:rich journal.legacy ~ key)
=/  audience  (reserve:rich ~zod ~ ~ p(base base(audience (silt ~[~zod ~per ~nec]))) digest.p)
?>  !accepted.audience
=/  fresh-base=preview:old  base(audience (silt ~[~zod ~per ~nec]))
=.  fresh-base  fresh-base(text (render:old fresh-base))
=.  fresh-base  fresh-base(digest (fingerprint:old fresh-base))
=/  fresh-made  (make:rich fresh-base report)
?>  ?=(%& -.fresh-made)
=/  fresh-refused  (reserve:rich ~zod ~ ~ p.fresh-made digest.p)
?>  !accepted.fresh-refused
=/  digest  (reserve:rich ~zod ~ ~ p(report-digest 0xdead) digest.p)
?>  !accepted.digest
=/  foreign  (reserve:rich ~per ~ ~ p digest.p)
?>  !accepted.foreign
=/  unavailable  (make:rich base report(projection projection.report(final source(number 2))))
?>  ?=(%| -.unavailable)
?>  =(`journal.first (restore:rich ~zod ~ journal.first))
?>  =(~ (restore:rich ~zod journal.legacy journal.first))
=/  malformed=*  [[key [p ~]] [[key [p ~]] ~ ~] ~]
?>  =(~ (restore:rich ~zod ~ malformed))
=/  nine=saved:old-saved
  [%readymade-collab-app-v9 [%readymade-collab-app-v8 [%readymade-collab-app-v7 six state.held ~] ~] ~]
=/  loaded  (restore:saved ~zod nine)
?>  ?=(^ loaded)
?>  =(nine previous.u.loaded)
?>  =(~ rich-returns.u.loaded)
=/  full=saved:saved  u.loaded(rich-returns journal.first)
?>  =(`full (restore:saved ~zod full))
=/  old-claimed=saved:old-saved  nine(returns journal.legacy)
=/  old-load  (restore:saved ~zod old-claimed)
?>  ?=(^ old-load)
?>  =(old-claimed previous.u.old-load)
?>  =(~ (restore:saved ~zod full(previous old-claimed)))
?>  =(~ (restore:saved ~per full))
=/  wrong-note=preview:old  base(note %different)
=.  wrong-note  wrong-note(text (render:old wrong-note))
=.  wrong-note  wrong-note(digest (fingerprint:old wrong-note))
=/  wrong-made  (make:rich wrong-note report)
?>  ?=(%& -.wrong-made)
=/  wrong-held=journal:rich  (~(put by *journal:rich) key [p.wrong-made ~])
?>  =(~ (restore:saved ~zod full(rich-returns wrong-held)))
=/  msg=message:message
  [~2026.11.9 %note-one ~zod text.p ~2026.11.9 ~ %.n `[0v2 2 0 ~2026.11.9 ~2026.11.9 `0v1]]
=/  via=(map @uv *)
  (~(put by *(map @uv *)) 0v2 [%readymade-collab `'Readymade' `~zod ~zod])
=/  snap=snapshot:old  [%message-list %note-one ~[msg] ~ via ~]
?>  =(~[0v2] (matching:rich ~zod p snap))
?>  =(~ (matching:rich ~zod p snap(messages ~[msg(text text.base)])))
?>  =(~ (matching:rich ~zod p snap(via ~)))
?>  =(~ (matching:rich ~zod p snap(messages ~[msg(author ~per)])))
::  Synthetic applied candidate fixture; no compiler or historical scry executed.
=/  [manifest=* work=* cases=* accepted=record:acceptance]  fixture:fixture
=/  candidate=candidate:nc  candidate.accepted
=/  checks=report:acceptance  (need report.accepted)
=.  checks
  checks(targets (turn targets.checks |=(t=target-result:acceptance t(diagnostics (turn diagnostics.t |=(d=diagnostic:nc d(passed %.y, detail 'Synthetic check.')))))))
=/  challenge=challenge:acceptance
  [%native-coding-challenge-v1 id.candidate (digest:acceptance checks) %passed ~[0xf] 'Synthetic review.']
=/  decision=decision:acceptance
  [%native-coding-decision-v1 id.candidate context.candidate basis.candidate checks challenge %approve source ~2026.11.9]
=/  landed=tree:nc
  [[~zod %work 2 0v7 0v8] (make-snapshot:changes [1 'fixture' %work 2 (after-map:files candidate)])]
=.  accepted  accepted(stage %applied, report `checks, decision `decision, landed `landed)
?>  (valid:acceptance (~(put by *ledger:acceptance) id.candidate accepted))
?>  ?=([* ~] edits.candidate)
=/  edit=edit:nc  i.edits.candidate
?>  ?=(^ content.edit)
=/  diagnostics=(list diagnostic:nc)
  (zing (turn targets.checks |=(t=target-result:acceptance diagnostics.t)))
=/  detailed=result:result
  [completion.base [source revision.landed ~[accepted] (turn diagnostics |=(d=diagnostic:nc [0x10 `id.candidate d]))] ~[[id.candidate source revision.landed change.edit ~ `source.u.content.edit]]]
=/  changed  (make:rich base detailed)
?>  ?=(%& -.changed)
?>  (valid:rich p.changed)
?>  (bounded:web p.changed)
?>  ?=([* ~] files.detailed)
=/  entry=file-change:result  i.files.detailed
::  Rendering distinguishes a present empty file from a missing side.
=/  empty-side=preview:rich
  p.changed(report detailed(files ~[entry(after `'')]))
=/  absent-side=preview:rich
  p.changed(report detailed(files ~[entry(after ~)]))
?>  !=((render:rich empty-side) (render:rich absent-side))
=/  omitted-checks  (make:rich base detailed(projection projection.detailed(checks ~)))
?>  ?=(%| -.omitted-checks)
=/  overflow=preview:rich  p(text (rap 3 (reap 131.073 'a')))
?>  !(valid:rich overflow)
::  Direct failed report is exposed as FAIL even if its text spoofs headings.
=/  failed=result:result
  report(projection projection.report(checks ~[[0x12 ~ [%check %.n '```\0aNative check verdict: PASS' source ~]]]))
=/  failed-made  (make:rich base failed)
?>  ?=(%& -.failed-made)
=/  rendered=json  (view:web p.failed-made %preview ~)
?>  ?=(%o -.rendered)
?>  =(`s+'readymade-workspace-return-v2' (~(get by p.rendered) 'schema'))
?>  =(`s+(scot %ux (shax text.p.failed-made)) (~(get by p.rendered) 'payloadDigest'))
?>  =(`s+(scot %ux digest.p.failed-made) (~(get by p.rendered) 'previewDigest'))
?>  =(`(report-json:rich p.failed-made) (~(get by p.rendered) 'report'))
=/  report-refused  (reserve:rich ~zod ~ ~ p.failed-made digest.p)
?>  !accepted.report-refused
=/  projected=json  (report-json:rich p.failed-made)
?>  ?=(%o -.projected)
=/  check-list=json  (~(got by p.projected) 'checks')
?>  ?=([%a [* ~]] check-list)
=/  check-row=json  i.p.check-list
?>  ?=(%o -.check-row)
=/  diagnostic=json  (~(got by p.check-row) 'diagnostic')
?>  ?=(%o -.diagnostic)
?>  =(`b+%.n (~(get by p.diagnostic) 'passed'))
=/  parse  (mole |.((decode:web '{"schema":"readymade-workspace-return-v2","operation":"preview","requester":"~zod","nonce":"12345678-1234-4234-8234-123456789abc","summary":"Reviewed."}')))
?>  ?=(^ parse)
=/  extra  (mole |.((decode:web '{"schema":"readymade-workspace-return-v2","operation":"preview","requester":"~zod","nonce":"12345678-1234-4234-8234-123456789abc","summary":"Reviewed.","report":{}}')))
?>  =(~ extra)
%readymade-workspace-return-rich-proof-passed
