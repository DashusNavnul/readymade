/+  ret=readymade-workspace-return, web=readymade-workspace-return-http,
    r=readymade-workspace-requests, message=readymade-workspace-message
|=  *
=/  original=record:r  *record:r
=.  original  original(value ['12345678-1234-4234-8234-123456789abc' ~zod 0x1 0x2 [~zod %work 1 0v4 0v5] 0x6 'Original request' `[~per '0v1' 0 0x7]], original 0x8, instruction 'Original request', native-request 0x9)
=/  p=preview:ret
  [[~zod '12345678-1234-4234-8234-123456789abc'] original 'demo' %note-one [%complete `0xa `0xb ~[0xc] %native-completion] 0xd 0xe (silt ~[~zod ~per]) 'Owner reviewed the result.' '' 0x0]
=.  p  p(text (render:ret p))
=.  p  p(digest (fingerprint:ret p))
?>  (valid:ret p)
=/  first  (reserve:ret ~zod ~ p digest.p)
?>  accepted.first
?>  ?=([* ~] cards.first)
=/  second  (reserve:ret ~zod journal.first p digest.p)
?>  !accepted.second
?>  =(journal.first journal.second)
?>  =(~ cards.second)
=/  foreign  (reserve:ret ~per ~ p digest.p)
?>  !accepted.foreign
=/  changed  (reserve:ret ~zod ~ p(summary 'Different disclosure') digest.p)
?>  !accepted.changed
=/  wrong  (reserve:ret ~zod ~ p 0x1)
?>  !accepted.wrong
?>  =(`journal.first (restore:ret ~zod journal.first))
?>  =(~ (restore:ret ~per journal.first))
=/  empty=journal:ret  ~
?>  =(`empty (restore:ret ~zod ~))
=/  message=message:message
  [~2026.11.9 %note-one ~zod text.p ~2026.11.9 ~ %.n `[0v2 2 0 ~2026.11.9 ~2026.11.9 `0v1]]
=/  via=(map @uv *)
  (~(put by *(map @uv *)) 0v2 [%readymade-collab `'Readymade' `~zod ~zod])
=/  snap=snapshot:ret  [%message-list %note-one ~[message] ~ via ~]
?>  =(~[0v2] (matching:ret ~zod p snap))
?>  =(~ (matching:ret ~zod p snap(messages ~[message(text 'Other text')])))
?>  =(~ (matching:ret ~zod p snap(via ~)))
?>  =(~ (matching:ret ~per p snap))
=/  output=json  (view:web p %reserved ~)
?>  ?=(%o -.output)
?>  =(`s+'reserved' (~(get by p.output) 'status'))
?>  =(`b+%.n (~(get by p.output) 'executionAuthorized'))
=/  changed-audience  (reserve:ret ~zod ~ p(audience (silt ~[~zod ~per ~nec])) digest.p)
?>  !accepted.changed-audience
=/  parsed  (mole |.((decode:web '{"schema":"readymade-workspace-return-v1","operation":"preview","requester":"~zod","nonce":"12345678-1234-4234-8234-123456789abc","summary":"Reviewed: bounded output."}')))
?>  ?=(^ parsed)
=/  extra  (mole |.((decode:web '{"schema":"readymade-workspace-return-v1","operation":"preview","requester":"~zod","nonce":"12345678-1234-4234-8234-123456789abc","summary":"Reviewed","verdict":"complete"}')))
?>  =(~ extra)
%readymade-workspace-return-proof-passed
