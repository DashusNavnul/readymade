::  Read-only recovery law and rejection checks. No cards dispatched or scries
::  on successful admission here; live member/law readback remains native.
/-  pa=cantrip-project-access, view=cantrip-project-view
/+  recover=cantrip-project-receipt, runtime=cantrip-project-access-runtime,
    changes=multiplayer-changeset, core=cantrip-project-access,
    law=cantrip-law-window
|=  *
=/  now=@da  ~2026.11.9
=/  q=query:view  ['shared' 1 0x2]
=/  pax=path  (route:recover ~nec q)
?>  =(`[~nec q] (parse:recover pax))
?>  =(~ (parse:recover /project-receipt))
?>  =(~ (parse:recover (weld pax /extra)))
?>  =(~ (parse:recover (route:recover ~nec q(nonce 0x0))))
?>  =(~ (parse:recover (route:recover ~nec q(nonce (bex 128)))))
?>  =(~ (parse:recover (route:runtime ~nec ['shared' 1 0x2 %suggest ~ ~ `@t`0])))
=/  hashes=(map path @ux)  (malt ~[[/lib/example/hoon (shax 'before')]])
=/  parent=parent:pa  [0x123 (make-snapshot:changes [1 'shared' %work 2 hashes])]
=/  request=request:pa  ['shared' 1 0x2 %suggest `parent /lib/example/hoon 'after']
=/  receipt=receipt:pa
  [~zod ~nec now 0x456 request [%suggest parent [%modify /lib/example/hoon `(shax 'before') `(shax 'after')] 'after']]
?>  (receipt-valid:runtime receipt)
=/  records=records:pa  (~(put by *records:pa) ['shared' ~nec 1 0x2] receipt)
?>  =(`receipt (lookup:recover ~zod ~nec q 0x456 records))
?>  =(~ (lookup:recover ~bud ~nec q 0x456 records))
?>  =(~ (lookup:recover ~zod ~bud q 0x456 records))
?>  =(~ (lookup:recover ~zod ~nec q 0x999 records))
?>  =(~ (lookup:recover ~zod ~nec q(generation 2) 0x456 records))
?>  =(~ (lookup:recover ~zod ~nec q(nonce 0x3) 0x456 records))
=/  damaged=records:pa  (~(put by records) ['shared' ~nec 1 0x2] receipt(request request(source 'different')))
?>  =(~ (lookup:recover ~zod ~nec q 0x456 damaged))
=/  cards  (cards:recover pax `receipt)
?>  =(2 (lent cards))
?>  =(`card:agent:gall`[%give %fact ~[pax] %noun !>(`event:pa`[%cantrip-project-receipt-v1 receipt])] (head cards))
?>  =(`card:agent:gall`[%give %kick ~[pax] ~] (head (tail cards)))
?>  =(`(list card:agent:gall)`~[[%give %kick ~[pax] ~]] (cards:recover pax ~))
::  Current admission rejects revoked/expired/missing/generation/permission
::  cases BEFORE any native project lookup; none can retrieve an old receipt.
=/  b=bowl:gall  *bowl:gall
=.  b  b(our ~zod, src ~bud, now now)
?>  =([%| %foreign-peer] (watch:recover b ~ records pax *window:law))
=.  b  b(src ~nec)
?>  =([%| %grant-missing] (watch:recover b ~ records pax *window:law))
=/  g=grant:pa
  [~zod 'shared' ~nec [%contributor now ~] %work 1 0x55 1 now `@da`0 (silt ~[/lib/example/hoon]) [%.y %.y]]
?>  (grant-valid:core g)
=/  grants=grants:pa  (~(put by *grants:pa) ['shared' ~nec] [g %.y])
?>  =([%| %grant-revoked] (watch:recover b grants records pax *window:law))
=.  grants  (~(put by grants) ['shared' ~nec] [g(generation 2) %.n])
?>  =([%| %generation-conflict] (watch:recover b grants records pax *window:law))
=.  grants  (~(put by grants) ['shared' ~nec] [g(permissions [%.y %.n]) %.n])
?>  =([%| %permission-refused] (watch:recover b grants records pax *window:law))
=.  grants  (~(put by grants) ['shared' ~nec] [g(expires (add now ~s1)) %.n])
?>  =([%| %grant-expired] (watch:recover b(now (add now ~s1)) grants records pax *window:law))
[%cantrip-project-receipt-proof %passed]
