::  Pure contract proof. No activity broadcast or source mutation.
/-  mp=multiplayer-project, nc=native-coding, pa=cantrip-project-access
/+  activity=readymade-editing-activity, sharing=readymade-project-sharing,
    projects=multiplayer-project, law=cantrip-law-window, server=readymade-editing-activity-owner, client=readymade-editing-activity-client
|=  *
=/  now=@da  ~2026.11.8
=/  opened  (open:projects [1 'activity' 'Activity' ~zod %demo-base 1 0x1 now] ~zod)
?>  ?=(%& -.opened)
=/  invited  (invite:projects p.opened ~zod ~nec %contributor now (add now ~d1) 0x2)
?>  ?=(%& -.invited)
=/  joined  (accept:projects p.invited ~nec (~(got by pending.p.invited) ~nec) now)
?>  ?=(%& -.joined)
=/  p=project:mp  p.joined
=/  config=project:nc
  :*  %native-coding-project-v1  spec.p  %demo-work
      [(silt ~[/lib]) ~ ~ ~ 32.768 65.536]
      ''  ''  (malt ~[[%hoon %hoon]])  ~  ~
  ==
=/  o=observation:sharing  [~zod now p `config ~]
=/  w=window:law  *window:law
=.  w  w(admissible (silt `(list act:law)`~[%read %compare]))
=/  f=file:activity  [%demo-work /lib/example/hoon]
=/  u=update:activity  [1 `f]
=/  made  (apply:activity o w ~ ~zod u)
?>  ?=(%& -.made)
=/  s=state:activity  p.made
?>  =(~[[~zod f]] (visible:activity o w s ~zod))
?>  =(~ (visible:activity o w s ~nec))
?>  =([%| %activity-permission-refused] (apply:activity o w ~ ~nec u))
?>  =([%| %activity-missing] (apply:activity o w ~ ~bud [1 ~]))
?>  =([%& s] (apply:activity o(at (add now ~s20)) w s ~zod u))
?>  =(~ (visible:activity o(at (add now ~s30)) w s ~zod))
?>  =(~ (visible:activity o(at (sub now ~s1)) w s ~zod))
?>  =(~ (visible:activity o w(blocked (silt `(list act:law)`~[%read])) s ~zod))
?>  =([%| %activity-sequence-conflict] (apply:activity o w s ~zod [1 ~]))
=/  stopped  (apply:activity o w s ~zod [2 ~])
?>  ?=(%& -.stopped)
?>  =(~ (visible:activity o w p.stopped ~zod))
?>  =([%| %activity-sequence-conflict] (apply:activity o w p.stopped ~zod u))
::  Real selected-file grant; membership alone above was insufficient.
=/  g=grant:pa
  :*  ~zod  'activity'  ~nec  (~(got by members.p) ~nec)  %demo-work
      1  0x1  1  now  `@da`0  (silt ~[/lib/example/hoon])  [%.y %.y]
  ==
=.  o  o(held (~(put by held.o) ['activity' ~nec] [g %.n]))
?>  =(~[[~zod f]] (visible:activity o w s ~nec))
=/  peer  (apply:activity o w s ~nec u)
?>  ?=(%& -.peer)
?>  =(2 (lent (visible:activity o w p.peer ~zod)))
=/  revoked=observation:sharing  o(held (~(put by held.o) ['activity' ~nec] [g %.y]))
?>  =(~ (visible:activity revoked w p.peer ~nec))
?>  =(~[[~zod f]] (visible:activity revoked w p.peer ~zod))
=/  replaced=observation:sharing  o(held (~(put by held.o) ['activity' ~nec] [g(generation 2) %.n]))
?>  =(~[[~zod f]] (visible:activity replaced w p.peer ~zod))
?>  =([%| %activity-permission-refused] (apply:activity o w ~ ~nec [1 `f(desk %session-clone)]))
?>  =([%| %activity-permission-refused] (apply:activity o w ~ ~nec [1 `f(pax /lib/private/hoon)]))
::  Exact project, authenticated actor and reload epoch at the transport boundary.
=/  fresh  (open-room:activity o)
?>  ?=(%& -.fresh)
=/  r=room:activity  p.fresh
=/  msg=message:activity  [address.r u]
=/  published  (receive:activity o w r ~nec msg)
?>  ?=(%& -.published)
?>  =(~[[~nec f]] (read-room:activity o w p.published ~zod address.r))
?>  =([%| %activity-scope-mismatch] (receive:activity o w r ~nec msg(address address.r(project 'another'))))
?>  =([%| %activity-scope-mismatch] (receive:activity o w r ~nec msg(address address.r(owner ~bud))))
?>  =([%| %activity-permission-refused] (receive:activity o w r ~bud msg))
?>  =([%| %activity-epoch-not-advanced] (reset-room:activity o p.published))
=/  later=observation:sharing  o(at (add now ~s1))
=/  rotated  (reset-room:activity later p.published)
?>  ?=(%& -.rotated)
?>  =(~ entries.p.rotated)
?>  =([%| %activity-scope-mismatch] (receive:activity later w p.rotated ~nec msg))
?>  =(~ (read-room:activity later w p.rotated ~zod address.r))
=/  republished  (receive:activity later w p.rotated ~nec msg(address address.p.rotated))
?>  ?=(%& -.republished)
?>  =(~[[~nec f]] (read-room:activity later w p.republished ~zod address.p.rotated))
?>  =(~ (read-room:activity revoked(at at.later) w p.republished ~zod address.p.rotated))
::  Owner service authenticates the caller before room creation or disclosure.
=/  query=request:server  [0v1 'activity' [%query ~]]
=/  denied  (serve:server o w ~ ~bud query)
?>  =(~ rooms.denied)
?>  =([%| %activity-permission-refused] result.response.denied)
=/  answer  (serve:server o w ~ ~nec query)
?>  ?=(%& -.result.response.answer)
?>  =(~ self-sequence.p.result.response.answer)
=/  addr=address:activity  address.p.result.response.answer
=/  command=request:server  [0v2 'activity' [%update addr u]]
=/  posted  (serve:server o w rooms.answer ~nec command)
?>  ?=(%& -.result.response.posted)
?>  =(~[[~nec f]] rows.p.result.response.posted)
?>  =(`1 self-sequence.p.result.response.posted)
::  An expired activity retains only its caller's sequencing cursor for recovery.
=/  recovered  (serve:server o(at (add now ~s31)) w rooms.posted ~nec query)
?>  ?=(%& -.result.response.recovered)
?>  =(rooms.posted rooms.recovered)
?>  =(~ rows.p.result.response.recovered)
?>  =(`1 self-sequence.p.result.response.recovered)
=/  spoof  (serve:server o w rooms.posted ~bud command)
?>  =(rooms.posted rooms.spoof)
?>  =([%| %activity-permission-refused] result.response.spoof)
=/  again  (serve:server later w rooms.posted ~zod query)
?>  =(rooms.posted rooms.again)
?>  ?=(%& -.result.response.again)
?>  =(~ self-sequence.p.result.response.again)
=/  withdrawn  (serve:server revoked w rooms.posted ~nec query)
?>  =([%| %activity-permission-refused] result.response.withdrawn)
=/  end=request:server  [0v3 'activity' [%update addr [2 ~]]]
=/  ended  (serve:server revoked w rooms.posted ~nec end)
?>  ?=(%& -.result.response.ended)
?>  =(~ rows.p.result.response.ended)
?>  =(`2 self-sequence.p.result.response.ended)
=/  after-stop  (serve:server o w rooms.ended ~nec query)
?>  ?=(%& -.result.response.after-stop)
?>  =(`2 self-sequence.p.result.response.after-stop)
=/  bad-project  (serve:server o w rooms.posted ~nec query(project 'another'))
?>  =([%| %activity-request-invalid] result.response.bad-project)
=/  bad-id  (serve:server o w rooms.posted ~nec query(id 0v0))
?>  =([%| %activity-request-invalid] result.response.bad-id)
::  Only the requested owner and exact pending request may settle a reply.
=/  waiting  (begin:client now ~zod query ~)
?>  ?=(%& -.waiting)
=/  j=journal:client  p.waiting
?>  =(j (receive:client now ~bud response.answer j))
?>  =(j (receive:client now ~zod response.answer(id 0v9) j))
?>  =(j (receive:client (add now ~s30) ~zod response.answer j))
=/  delivered  (receive:client now ~zod response.answer j)
?>  =(`response.answer (result:client now ~zod 'activity' 0v1 delivered))
?>  =(delivered (receive:client (add now ~s1) ~zod response.answer delivered))
?>  =(~ (result:client (add now ~s30) ~zod 'activity' 0v1 delivered))
=/  newer  (begin:client now ~zod query(id 0v9) delivered)
?>  ?=(%& -.newer)
?>  =(p.newer (receive:client now ~zod response.answer p.newer))
?>  =([%| %activity-request-reused] (begin:client now ~zod query j))
=/  update-wait  (begin:client now ~zod command ~)
?>  ?=(%& -.update-wait)
=/  update-delivered  (receive:client now ~zod response.posted p.update-wait)
?>  =(`response.posted (result:client now ~zod 'activity' 0v2 update-delivered))
::  Another window's passive query cannot overwrite an in-flight update.
=/  concurrent  (begin:client now ~zod query p.update-wait)
?>  ?=(%& -.concurrent)
=/  both  (receive:client now ~zod response.posted p.concurrent)
=/  both  (receive:client now ~zod response.answer both)
?>  =(both (receive:client now ~zod response.posted (receive:client now ~zod response.answer p.concurrent)))
?>  =(`response.posted (result:client now ~zod 'activity' 0v2 both))
?>  =(`response.answer (result:client now ~zod 'activity' 0v1 both))
?>  =(~ (result:client now ~zod 'activity' 0v9 both))
?>  =(~ (result:client now ~bud 'activity' 0v1 both))
?>  =(~ (result:client now ~zod 'another' 0v1 both))
::  Capacity is per live request, and expiry releases it without a restart.
=/  full=journal:client
  =/  ids=(list @ud)  (gulf 1 32)
  |-  ^-  journal:client
  ?~  ids  ~
  (~(put by $(ids t.ids)) [~zod 'activity' `@uv`i.ids] [query(id `@uv`i.ids) now ~])
?>  =(32 ~(wyt by full))
?>  =([%| %activity-request-capacity] (begin:client now ~zod query(id 0v11) full))
=/  reclaimed  (begin:client (add now ~s30) ~zod query(id 0v11) full)
?>  ?=(%& -.reclaimed)
?>  =(1 ~(wyt by p.reclaimed))
?>  =(~ (prune:client (sub now ~s1) full))
=/  altered=response:server
  response.posted(result [%& p.result.response.posted(address addr(epoch (add epoch.addr ~s1)))])
?>  =(p.update-wait (receive:client now ~zod altered p.update-wait))
=/  zero-cursor=response:server
  response.answer(result [%& p.result.response.answer(self-sequence `0)])
?>  =(j (receive:client now ~zod zero-cursor j))
=/  huge-cursor=response:server
  response.answer(result [%& p.result.response.answer(self-sequence `(bex 64))])
?>  =(j (receive:client now ~zod huge-cursor j))
%readymade-editing-activity-proof-v6
