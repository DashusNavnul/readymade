::  Pure HTTP boundary proof; no source read, disclosure or network effect.
/-  view=cantrip-project-view, pa=cantrip-project-access
/+  http=readymade-project-view-http, client=readymade-project-view-client,
    changes=multiplayer-changeset
|=  *
=/  fields=(map @t json)
  (malt ~[['schema' s+'readymade-project-view-v1'] ['owner' s+'~zod'] ['project' s+'shared'] ['generation' s+'1']])
=/  raw=@t  (en:json:html [%o fields])
?>  =(`[~zod 'shared' 1] (parse:http raw))
=/  bad=(list [@t json])
  :~  ['owner' s+'zod']  ['project' s+'']  ['project' s+'bad:project']
      ['project' s+'bad\0aproject']  ['generation' s+'0']
      ['generation' s+'01']  ['generation' n+'1']
      ['generation' s+'18.446.744.073.709.551.616']
      ['schema' s+'other']  ['extra' s+'field']
  ==
?>  %+  levy  bad
    |=  row=[key=@t value=json]
    ?=(~ (parse:http (en:json:html [%o (~(put by fields) key.row value.row)])))
?>  =(~ (parse:http (cat 3 '{"owner":"~zod",' (rsh [3 1] raw))))
?>  =(~ (parse:http (cat 3 '{"ow\5cu006eer":"~zod",' (rsh [3 1] raw))))
?>  =(~ (parse:http (crip (reap 4.097 ' '))))
=/  req=inbound-request:eyre  *inbound-request:eyre
=/  headers=(list [@t @t])
  ~[['host' 'localhost:8080'] ['origin' 'http://localhost:8080'] ['content-type' 'application/json'] ['x-readymade-project-view' 'v1']]
=.  req  req(authenticated %.y, secure %.n, method.request %'POST', url.request '/apps/readymade-collab/project-view', header-list.request headers, body.request `[(met 3 raw) raw])
?>  =((parse:http raw) (post-request:http req))
?>  =(~ (post-request:http req(authenticated %.n)))
?>  =(~ (post-request:http req(method.request %'GET')))
?>  =(~ (post-request:http req(secure %.y)))
?>  =(~ (post-request:http req(url.request '/apps/readymade-collab/project-view/extra')))
?>  =(~ (post-request:http req(header-list.request [['host' 'localhost:8080'] headers])))
?>  =(~ (post-request:http req(header-list.request [['X-Readymade-Project-View' 'v1'] headers])))
?>  =(~ (post-request:http req(header-list.request [['origin' 'http://evil.invalid'] headers])))
?>  =(~ (post-request:http req(body.request `[1 raw])))
=/  k=selector:client  [~zod ['shared' 1 0x1]]
=/  get-headers=(list [@t @t])
  ~[['x-readymade-project-owner' '~zod'] ['x-readymade-project' 'shared'] ['x-readymade-project-generation' '1'] ['x-readymade-project-view-request' '0x1']]
=/  get=inbound-request:eyre
  req(method.request %'GET', url.request '/apps/readymade-collab/project-view-result', header-list.request get-headers, body.request ~)
?>  =(`k (result-request:http get))
?>  =(~ (result-request:http get(authenticated %.n)))
?>  =(~ (result-request:http get(method.request %'POST')))
?>  =(~ (result-request:http get(header-list.request [['x-readymade-project' 'shared'] get-headers])))
=/  now=@da  ~2026.11.9
=/  started  (begin:client ~nec now k ~)
?>  ?=(%& -.result.started)
=/  e=entry:client  p.result.started
?>  ?=(^ (response:http ~nec e))
::  Two maximum files with JSON-escaped characters remain within512KiB.
=/  text=@t  (crip (reap 32.768 '"'))
=/  files=(map path @t)  (malt ~[[/lib/one/hoon text] [/lib/two/hoon text]])
=/  hashes=(map path @ux)  (malt ~[[/lib/one/hoon (shax text)] [/lib/two/hoon (shax text)]])
=/  b=basis:pa  [~zod now 0x123 (make-snapshot:changes [1 'shared' %work 2 hashes]) files]
=/  r=response:view  [~zod ~nec query.k 0x456 b]
=/  ready=entry:client  e(phase %ready, reason %observed, response `r)
=/  body  (response:http ~nec ready)
?>  ?=(^ body)
?>  (lte (met 3 (en:json:html u.body)) 524.288)
?>  =(~ (response:http ~bud ready))
?>  =(~ (response:http ~nec ready(key k(owner ~bud))))
?>  =(~ (response:http ~nec ready(response ~)))
[%readymade-project-view-http-proof %passed]
