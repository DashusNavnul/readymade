::  Pure transport/lifecycle proof. No actual watches or timers are dispatched.
/-  view=cantrip-project-view, pa=cantrip-project-access
/+  client=readymade-project-view-client, runtime=cantrip-project-access-runtime,
    changes=multiplayer-changeset
|=  *
=/  now=@da  ~2026.11.9
=/  k=selector:client  [~zod ['shared' 1 0x1]]
=/  started  (begin:client ~nec now k ~)
?>  ?=(%& -.result.started)
=/  e=entry:client  p.result.started
=/  held=journal:client  journal.started
=/  wir=wire  (wire-for:client k deadline.e)
?>  =(`[k deadline.e] (parse-wire:client wir))
?>  =(~ (parse-wire:client (weld wir /extra)))
?>  =(~ (parse-wire:client /collab/project-view))
?>  ?=([* * ~] cards.started)
?>  =(`card:agent:gall`[%pass wir %arvo %b %wait deadline.e] i.cards.started)
?>  =(`card:agent:gall`[%pass wir %agent [~zod %cantrip] %watch (view-route:runtime ~nec query.k)] i.t.cards.started)
=/  reused  (begin:client ~nec now k held)
?>  ?=(%| -.result.reused)
=/  self  (begin:client ~zod now k ~)
?>  ?=(%| -.result.self)
=/  files=(map path @t)  (malt ~[[/lib/example/hoon '|=  a=@  +(a)']])
=/  hashes=(map path @ux)  (malt ~[[/lib/example/hoon (shax '|=  a=@  +(a)')]])
=/  b=basis:pa  [~zod now 0x123 (make-snapshot:changes [1 'shared' %work 2 hashes]) files]
=/  r=response:view  [~zod ~nec query.k 0x456 b]
=/  fact=sign:agent:gall  [%fact %noun !>(`event:view`[%cantrip-project-view-v1 r])]
?>  =([held ~] (receive:client ~nec ~bud now held wir fact))
?>  =([held ~] (receive:client ~nec ~zod now held /unrelated fact))
?>  =([held ~] (receive:client ~nec ~zod now held wir [%watch-ack ~]))
=/  ready  (receive:client ~nec ~zod now held wir fact)
=/  observed  (~(got by journal.ready) k)
?>  &(=(%ready phase.observed) =(`r response.observed))
?>  =((cleanup:client k deadline.e) cards.ready)
?>  =([journal.ready ~] (receive:client ~nec ~zod now journal.ready wir fact))
?>  =(`observed (result:client (add now ~s31) k journal.ready))
?>  =(~ (result:client retained.e k journal.ready))
?>  =(~ (prune:client retained.e journal.ready))
::  Active entries cannot be silently pruned, even after delayed timer delivery.
?>  =(held (prune:client retained.e held))
=/  late  (receive:client ~nec ~zod deadline.e held wir fact)
=/  late-entry  (~(got by journal.late) k)
?>  =(%uncertain phase.late-entry)
?>  =(~ response.late-entry)
?>  =((cleanup:client k deadline.e) cards.late)
?>  =(late (wake:client deadline.e held wir))
?>  =([held ~] (wake:client now held wir))
=/  kicked  (receive:client ~nec ~zod now held wir [%kick ~])
=/  kicked-entry  (~(got by journal.kicked) k)
?>  =(%uncertain phase.kicked-entry)
?>  =((cleanup:client k deadline.e) cards.kicked)
=/  nack=sign:agent:gall  [%watch-ack `~[leaf+"refused"]]
=/  rejected  (receive:client ~nec ~zod now held wir nack)
=/  rejected-entry  (~(got by journal.rejected) k)
?>  =(%refused phase.rejected-entry)
?>  =((cleanup:client k deadline.e) cards.rejected)
=/  wrong=sign:agent:gall
  [%fact %noun !>(`event:view`[%cantrip-project-view-v1 r(peer ~bud)])]
=/  refused  (receive:client ~nec ~zod now held wir wrong)
=/  refused-entry  (~(got by journal.refused) k)
?>  =(%uncertain phase.refused-entry)
?>  =(~ response.refused-entry)
::  Reload reconstructs only exact own Cantrip watches from real bowl metadata.
=/  outgoing=boat:gall
  (malt ~[[[wir ~zod %cantrip] [%.y (view-route:runtime ~nec query.k)]]])
?>  =((cleanup:client k deadline.e) (reload:client ~nec outgoing))
?>  =(~ (reload:client ~bud outgoing))
?>  =(~ (reload:client ~nec (malt ~[[[wir ~bud %cantrip] [%.y (view-route:runtime ~nec query.k)]]])))
?>  =(~ (reload:client ~nec (malt ~[[[wir ~zod %other] [%.y (view-route:runtime ~nec query.k)]]])))
?>  =([~ (cleanup:client k deadline.e)] (wake:client deadline.e ~ wir))
::  Pending and retained capacity are separate, neither silently evicts active.
=/  eight=journal:client
  =/  n=@ud  1
  =/  acc=journal:client  ~
  |-  ^-  journal:client
  ?:  =(9 n)  acc
  =/  key=selector:client  k(query query.k(nonce `@ux`n))
  $(n +(n), acc (~(put by acc) key e(key key)))
=/  ninth  (begin:client ~nec now k(query query.k(nonce 0x9)) eight)
?>  ?=(%| -.result.ninth)
=/  full=journal:client
  =/  n=@ud  1
  =/  acc=journal:client  ~
  |-  ^-  journal:client
  ?:  =(33 n)  acc
  =/  key=selector:client  k(query query.k(nonce `@ux`n))
  $(n +(n), acc (~(put by acc) key e(key key, phase %uncertain)))
=/  overflow  (begin:client ~nec now k(query query.k(nonce 0x21)) full)
?>  ?=(%| -.result.overflow)
[%readymade-project-view-client-proof %passed]
